﻿// -----------------------------------------------------------------------
// <copyright file="PLCXLService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PLCXLService </summary>
// -----------------------------------------------------------------------

using Ecolab.Dcs.CollectData.Mitsubishi;
using Entities.DataReader;
using Controller = Ecolab.Dcs.Entities.Controller;
using Timer = System.Timers.Timer;
using Washer = Ecolab.Dcs.Entities.Washer;
namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Concurrent;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Timers;
    using System.Xml;
    using System.Xml.Serialization;
    using Access.DataReader;
    using Ecolab.Dcs.CollectData;
    using Entities;
    using log4net;
    using Properties;
    using BeckhoffXmlTag = BeckhoffXmlTag;
    using Controller = Controller;
    using Timer = Timer;
    using Washer = Washer;
    public class PLCXLService
    {
        #region Variables
        #region AlarmInfoGeneral Address
        public const string R27000 = "R27000";
        #endregion
        #region AlarmInfoGeneralExtra Address
        public const string R28260 = "R28260";
        #endregion
        #region AlarmInfoPerGroup Address
        public const string R27320 = "R27320";
        #endregion
        #region AlarmProductionArray_AlarmSave Address 
        public const string D1260 = "D1260";
        private const string PLCXLServiceLogFile = "PLCXlServiceLog";
        #endregion
        private static readonly ILog Log = LogManager.GetLogger(PLCXLServiceLogFile);       
        private List<MitsubishiController> mControllers;
        object locker = new object();
        ManualResetEvent timerDead = new ManualResetEvent(false);
        private bool mServiceStopping;
        private Timer aTimer;
        readonly ProcessRollup processRollup = new ProcessRollup();
        
        MyControlAlarmData plcxlAlaramData;
        int[] alaramInfoGeneral;
        int[] alaramInfoPerGroup;
        int[] alaramInfoGeneralExtra;
        private static List<ushort> tunOnlineRes = new List<ushort>();
        readonly XmlSerializer ConventionalXmlSerializer = new XmlSerializer(typeof(ConventionalWasherData));
        readonly XmlSerializer ConventionalXmlSerializerForAccessSave = new XmlSerializer(typeof(PLCData));
        readonly XmlSerializer TunnelSerializer = new XmlSerializer(typeof(MyControlTunnel), new XmlRootAttribute("MyControlTunnel"));
        readonly XmlSerializer AlarmDataSerializer = new XmlSerializer(typeof(MyControlAlarmData));
        private static ConcurrentDictionary<string, DataReader<MitsubishiTag>> objreader = new ConcurrentDictionary<string, DataReader<MitsubishiTag>>();
        private static ConcurrentDictionary<string, DataWriter<MitsubishiTag>> objwriter = new ConcurrentDictionary<string, DataWriter<MitsubishiTag>>();
        #endregion
        int fileCounter = 1;
        #region Methods
        public PLCXLService()
        {
            aTimer = new Timer(Int32.Parse(Settings.Default.WebportReadInterval))
            {
                AutoReset = false
            };
            aTimer.Elapsed += OnTimedEvent;
            aTimer.Enabled = true;
        }
        private void GetControllers()
        {
            IEnumerable<global::Entities.DataReader.Controller> dbControllers = DataReaderAccess.GetActiveControllers();
            int[] PLCXLControllerTypes = new int[3]
            {
                Convert.ToInt32(ControllerType.TwoTunnels),
                Convert.ToInt32(ControllerType.FiveWashersOneTunnel),
                Convert.ToInt32(ControllerType.TenWasher)
            };
            if (dbControllers != null)
            {
                dbControllers = dbControllers.Where(c => PLCXLControllerTypes.Contains(c.ControllerTypeId)).ToList();
            }
            List<Controller> controllers = dbControllers != null ? dbControllers.Select(EntityConverter.Convert).ToList() : new List<Controller>();
            mControllers = controllers.FindAll(c => c is MitsubishiController).Select(c => (MitsubishiController)c).ToList();
            Log.InfoFormat("Started Tracking PLC-XL {0} controller(s)", mControllers.Count);
           
        }
        public void Start()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            foreach (MitsubishiController controller in mControllers)
            {
                if (!String.IsNullOrEmpty(controller.HostAdress))
                {
                    if (!objreader.ContainsKey(controller.HostAdress))
                    {
                        objreader.GetOrAdd(controller.HostAdress, MitsubishiFactory.GetDataReader(controller));
                    }
                    if (!objwriter.ContainsKey(controller.HostAdress))
                    {
                        objwriter.GetOrAdd(controller.HostAdress, MitsubishiFactory.GetDataWriter(controller));
                    }
                   
                }
                else
                {
                    Log.ErrorFormat("Invalid HostAdress: {0}",
                        controller.HostAdress);
                }
                InitializePlcContinuousRead(controller);
            }
        }
        public void Stop()
        {
            try
            {
                Log.Info("PLCXL : Stopping Data Communication Service...");
                mServiceStopping = true;
                timerDead.WaitOne();
                aTimer.Stop();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to stop Data Communcation Service", ex);
            }
            finally
            {
                Log.InfoFormat("{0}: Service has been stopped.", "Data Communication Service");
            }
        }
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {
                timerDead.Reset();
                GetControllers();
                Start();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to run Data Communcation Service", ex);
            }
            finally
            {
                lock (locker)
                {
                    timerDead.Set(); // allow service to stop
                    Log.Info("Signal set to indicate elapsed event to continue");
                }
                if (!mServiceStopping)	// restart the timer
                    aTimer.Start();
            }
        }
        public void InitializePlcContinuousRead(MitsubishiController controller)
        {
            try
            {
                int[] helm5Array=null;

                if (controller != null)
                    helm5Array = ReadArray(controller, "D5500", 1200);
                if (helm5Array == null)
                {
                    Log.Error("PLC XL. Controller=null or helm5Array == null. InitializePlcContinuousRead ");
                    return;
                }
                if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
                {
                    
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                          ReadOnlineDataForWashers(controller, helm5Array, 5); // 5 Washers 
                    }
                    catch(Exception exp)
                    {
                        Log.Error("Error while Processing  PLCXL Online Data for Washer", exp);
                        DisposeReadWrite(controller);
                    }
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadOnlineDataForTunnels(controller, helm5Array);// 1 Tunnel.
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while Processing  PLCXL Online Data for Tunnels", exp);
                        DisposeReadWrite(controller);
                    }
                  
                   try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadAccessSaveData(controller);
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while processing PLCXL Access Save",exp);
                        DisposeReadWrite(controller);

                    }
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadStepSave(controller, helm5Array);
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while processing PLCXL Step Save", exp);
                        DisposeReadWrite(controller);

                    }
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadCompSaveDataForTunnels(controller);
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while processing PLCXL Comp Save", exp);
                        DisposeReadWrite(controller);

                    }
                    
                }
                else if (controller.PLCType == MitsubishiPLCType.PLCXL10W)
                {
                    
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadOnlineDataForWashers(controller, helm5Array, 10); // 10 Washers 
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while Processing  PLCXL Online Data for Washer", exp);
                        DisposeReadWrite(controller);
                    }
                   
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadAccessSaveData(controller);
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while processing PLCXL Access Save", exp);
                        DisposeReadWrite(controller);

                    }
                    
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadStepSave(controller, helm5Array);
                    }
                    catch (Exception exp)
                    {
                       Log.Error("Error while processing PLCXL Step Save", exp);
                        DisposeReadWrite(controller);

                    }

                    
                }
                else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw)
                {
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadOnlineDataForTunnels(controller, helm5Array); // 2 tunnels
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while Processing  PLCXL Online Data for Tunnels", exp);
                        DisposeReadWrite(controller);
                    }
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadAccessSaveData(controller);
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while processing PLCXL Access Save", exp);
                        DisposeReadWrite(controller);

                    }
                    try
                    {
                        if (objreader.ContainsKey(controller.HostAdress))
                            ReadCompSaveDataForTunnels(controller);
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Error while processing PLCXL Comp Save", exp);
                        DisposeReadWrite(controller);

                    }
                  
                }
                ///Process alarms.................................................
                try
                {
                    if (objreader.ContainsKey(controller.HostAdress))
                        ReadAndProcessOnlineAlarmData(helm5Array, controller);
                }
                catch(Exception exp)
                {
                    Log.Error("Error while processing PLCXL Online  Alarm Data", exp);
                    DisposeReadWrite(controller);
                }
              
                
                try
                {
                    if (objreader.ContainsKey(controller.HostAdress))
                        ReadAlarmProdData(controller);
                }
                catch(Exception exp)
                {
                    Log.Error("Error while processing PLCXL Production Alarm Data", exp);
                    DisposeReadWrite(controller);
                }
              
                try
                {
                    processRollup.Rollup();
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured:processRollup: PLCXL: Controller ID:" + controller.ControllerId, ex);
                    DisposeReadWrite(controller);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error occured whlie reading Data from PLCXL - " , ex);
                DisposeReadWrite(controller);
            }
        }

        private void DisposeReadWrite(MitsubishiController controller)
        {
            #region Dispose reader/writer
            if (objreader.ContainsKey(controller.HostAdress))
            {
                PLCXLEthernetReader plcXLReader =(PLCXLEthernetReader ) objreader[controller.HostAdress];
                DataReader<MitsubishiTag> tempreader=null;
                if (!plcXLReader.IsConnected())
                {
                    objreader.TryRemove(controller.HostAdress, out tempreader);
                    plcXLReader.Dispose();
                }
                
            }
            if (objwriter.ContainsKey(controller.HostAdress))
            {
                DataWriter<MitsubishiTag> tempwriter;
                PLCXLEthernetWriter plcXLWriter = (PLCXLEthernetWriter)objwriter[controller.HostAdress];
                if (!plcXLWriter.IsConnected())
                {
                    objwriter.TryRemove(controller.HostAdress, out tempwriter);
                    plcXLWriter.Dispose();
                }
                
            }
            #endregion
        }
        /// <summary>
        /// This is the top level function for processing all online PLC XL alarms for my control plc
        /// </summary>
        /// <param name="helm5Array">The helm5Array.</param>
        /// <param name="controller">The controller.</param>
        private void ReadAndProcessOnlineAlarmData(int[] helm5Array, MitsubishiController controller)
        {
            if (helm5Array != null && controller != null)
            {
                ReadAndProcessPLCXL5W1C(helm5Array, controller);
            }
        }
        /// <summary>
        /// PLCXL5W1C is a type of plc xl online alaram data and this function gets all active alarms and  stores into helm5 array
        /// </summary>
        /// <param name="helm5Array">the helm5Array</param>
        /// <param name="controller">the controller</param>
        public void ReadAndProcessPLCXL5W1C(int[] helm5Array, MitsubishiController controller)
        {
            int count = 0;
            int alarmIndex = 0;
            int[] arr = new int[240];
            int[] skipIndexes = { 39, 40, 123, 124, 125, 208, 209, 210, 239, 240 };
            for (int helmsIndex = 0; helmsIndex <= 14; helmsIndex++)
            {
                alarmIndex = helmsIndex * 16;
                if (helm5Array[helmsIndex + 1100] > 0)
                {
                    int[] binaryValue = ConvertDecimalToBinary(helm5Array[helmsIndex + 1100]);
                    for (int i = 0; i < binaryValue.Length; i++)
                    {
                        if (!skipIndexes.Contains(alarmIndex + 1))
                        {
                            if (binaryValue[i] == 1)
                            {
                                arr[count] = alarmIndex + 1;
                                count++;
                            }
                        }
                        alarmIndex++;
                    }
                }
            }
            if (arr != null && controller != null)
            {
                GetAlaramData(arr, controller);
            }
        }
        /// <summary>
        /// GetAlaramData gets the data of the active alarm i.e alarm parameters and based on the range
        /// it is classified into 3 types i.e
        /// 1.AlarmInfoGeneral-->this takes the alarm indexes from 1 to 40. 
        /// 2.AlarmInfoPerGroup-->this takes the alarm indexes from 41 to 210. This is again classified into two groups
        ///        i.AlarmInfoPerGroupOne-->this takes the alarm indexes from 41 to 125
        ///       ii.AlarmInfoPerGroupTwo-->this takes the alarm indexes from 126 to 210
        /// 3.AlarmInfoGeneralExtra-->this takes the alarm indexes from 210 to 240
        /// after segregating all the alarms it will prepare a xml and calls a storedprocedure.
        /// </summary>
        /// <param name="activeAlarmIndex">the activeAlarmIndex</param>
        /// <param name="controller">the controller</param>
        public void GetAlaramData(int[] activeAlarmIndex, MitsubishiController controller)
        {
            plcxlAlaramData = new MyControlAlarmData();
            alaramInfoGeneral = ReadArray(controller, R27000, 40 * 8);
            alaramInfoPerGroup = ReadArray(controller, R27320, 85 * 8 * 2);
            alaramInfoGeneralExtra = ReadArray(controller, R28260, 30 * 8);
            for (int i = 0; i < activeAlarmIndex.Length; i++)
            {
                if (activeAlarmIndex[i] > 0 && activeAlarmIndex[i] <= 40)
                {
                    AlarmInfoGeneral(activeAlarmIndex[i],controller.PLCType);
                }
                else if (activeAlarmIndex[i] > 40 && activeAlarmIndex[i] < 126)
                {
                    AlarmInfoPerGroupOne(activeAlarmIndex[i], controller.PLCType);
                }
                else if (activeAlarmIndex[i] > 125 && activeAlarmIndex[i] < 211)
                {
                    AlarmInfoPerGroupTwo(activeAlarmIndex[i], controller.PLCType);
                }
                else if (activeAlarmIndex[i] > 210 && activeAlarmIndex[i] < 240)
                {
                    AlarmInfoGeneralExtra(activeAlarmIndex[i], controller.PLCType);
                }
                string xmlString = string.Empty;
                if (activeAlarmIndex[i] > 0)
                {
                    if (AlarmDataSerializer != null && plcxlAlaramData != null)
                    {
                        xmlString = SerializeXMLData(AlarmDataSerializer, plcxlAlaramData);
                    }
                    if (xmlString.Length > 0 && controller != null)
                    {
                        DataReaderAccess.ProcessPlcxlAlarmData(controller.ControllerId, xmlString);
                        


                    }
                }
            }
        }
        /// <summary>
        /// AlarmInfoGeneral method by using the active activeAlarmIndex gets all the parameters of that index.
        /// </summary>
        /// <param name="activeAlarmIndex">the activeAlarmIndex</param>
        public void AlarmInfoGeneral(int activeAlarmIndex, MitsubishiPLCType plcType)
        {
            int alaramNumber = 0;
            int washerNo;
            //for suppose there are two active alarms 1 and 2 
            //for alarm one the alarmIndexParameters=((1-1)*8) i.e. 0. So array starts from 0 to 7
            //for alarm two the alarmIndexParameters=((2-1)*8) i.e. 8. So array starts from 8 to 15
            int alarmIndexParameters = ((activeAlarmIndex - 1) * 8);
            plcxlAlaramData = GetAlarmNumber(activeAlarmIndex, plcType);
            DateTime startDateTime = new DateTime(2000, 1, 1);
            startDateTime = startDateTime.AddDays(alaramInfoGeneral[alarmIndexParameters]);
            startDateTime = startDateTime.AddMinutes(alaramInfoGeneral[alarmIndexParameters + 1]);
            string strDateTime = startDateTime.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
            plcxlAlaramData.StartDateTime = strDateTime;
            if (string.IsNullOrEmpty(plcxlAlaramData.MachineNumber) || plcxlAlaramData.MachineNumber == "0")
            {
                washerNo = alaramInfoGeneral[alarmIndexParameters + 2];
                if (washerNo !=0)
                    plcxlAlaramData.MachineNumber = washerNo.ToString();
                plcxlAlaramData.IsTunnel = "0";
                if (plcType == MitsubishiPLCType.PLCXL2Cbw)
                    plcxlAlaramData.IsTunnel = "1";
                if (plcType == MitsubishiPLCType.PLCXL5W1C  && washerNo >0)
                {
                   plcxlAlaramData.MachineNumber = (washerNo == 1 ? washerNo : washerNo - 1).ToString();
                   plcxlAlaramData.IsTunnel = washerNo == 1 ? "1" : "0";
                }
                
            }
            
            plcxlAlaramData.BatchNumber = alaramInfoGeneral[alarmIndexParameters + 3].ToString();
            plcxlAlaramData.ProgramNumber = alaramInfoGeneral[alarmIndexParameters + 4].ToString();
            plcxlAlaramData.DesiredValue = alaramInfoGeneral[alarmIndexParameters + 5].ToString();
            plcxlAlaramData.MeasuredValue = alaramInfoGeneral[alarmIndexParameters + 6].ToString();
            plcxlAlaramData.Status = alaramInfoGeneral[alarmIndexParameters + 7].ToString();

        }
        /// <summary>
        /// AlarmInfoPerGroupOne method by using the active activeAlarmIndex gets all the parameters of that index and the active alarms lies between 41 to 125.
        /// </summary>
        /// <param name="activeAlarmIndex">the activeAlarmIndex</param>
        public void AlarmInfoPerGroupOne(int activeAlarmIndex, MitsubishiPLCType plcType)
        {
            int alaramNumber = 0;
            int washerNo;
            //for suppose there are two active alarms 41 and 42 
            //for alarm one the alarmIndexParameters=((41-41)*8) i.e. 0. So array starts from 0 to 7
            //for alarm two the alarmIndexParameters=((42-41)*8) i.e. 8. So array starts from 8 to 15
            int alarmIndexParameters = (activeAlarmIndex - 41) * 8;
            plcxlAlaramData = GetAlarmNumber(activeAlarmIndex, plcType);
            DateTime startDateTime = new DateTime(2000, 1, 1);
            startDateTime = startDateTime.AddDays(alaramInfoPerGroup[alarmIndexParameters]);
            startDateTime = startDateTime.AddMinutes(alaramInfoPerGroup[alarmIndexParameters + 1]);
            string strDateTime = startDateTime.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
            plcxlAlaramData.StartDateTime = strDateTime;
            if (string.IsNullOrEmpty(plcxlAlaramData.MachineNumber) || plcxlAlaramData.MachineNumber == "0")
            {
                washerNo = alaramInfoPerGroup[alarmIndexParameters + 2];
                if (washerNo != 0)
                    plcxlAlaramData.MachineNumber = washerNo.ToString();
                plcxlAlaramData.IsTunnel = "0";
                if (plcType == MitsubishiPLCType.PLCXL2Cbw)
                    plcxlAlaramData.IsTunnel = "1";
                if (plcType == MitsubishiPLCType.PLCXL5W1C && washerNo > 0)
                {
                    plcxlAlaramData.MachineNumber = (washerNo == 1 ? washerNo : washerNo - 1).ToString();
                    plcxlAlaramData.IsTunnel = washerNo == 1 ? "1" : "0";
                }
            }
            plcxlAlaramData.BatchNumber = alaramInfoPerGroup[alarmIndexParameters + 3].ToString();
            plcxlAlaramData.ProgramNumber = alaramInfoPerGroup[alarmIndexParameters + 4].ToString();
            plcxlAlaramData.DesiredValue = alaramInfoPerGroup[alarmIndexParameters + 5].ToString();
            plcxlAlaramData.MeasuredValue = alaramInfoPerGroup[alarmIndexParameters + 6].ToString();
            plcxlAlaramData.Status = alaramInfoPerGroup[alarmIndexParameters + 7].ToString();
        }
        /// <summary>
        /// AlarmInfoPerGroupOne method by using the active activeAlarmIndex gets all the parameters of that index and the active alarms lies between 126 to 210.
        /// </summary>
        /// <param name="activeAlarmIndex">the activeAlarmIndex</param>
        public void AlarmInfoPerGroupTwo(int activeAlarmIndex, MitsubishiPLCType plcType)
        {
            int alaramNumber = 0;
            int washerNo;
            //for suppose there are two active alarms 126 and 127 
            //for alarm one the alarmIndexParameters=((126-126)*8 + (85 * 8)) i.e. 680. So array starts from 680 to 687
            //for alarm two the alarmIndexParameters=((127-126)*8 + (85 * 8)) i.e. 688. So array starts from 688 to 695
            int alarmIndexParameters = ((activeAlarmIndex - 126) * 8 + (85 * 8));
            plcxlAlaramData = GetAlarmNumber(activeAlarmIndex, plcType);
            DateTime startDateTime = new DateTime(2000, 1, 1);
            startDateTime = startDateTime.AddDays(alaramInfoPerGroup[alarmIndexParameters]);
            startDateTime = startDateTime.AddMinutes(alaramInfoPerGroup[alarmIndexParameters + 1]);
            string strDateTime = startDateTime.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
            plcxlAlaramData.StartDateTime = strDateTime;

            if (string.IsNullOrEmpty(plcxlAlaramData.MachineNumber) || plcxlAlaramData.MachineNumber == "0")
            {
                
                washerNo = alaramInfoPerGroup[alarmIndexParameters + 2];
                if (washerNo != 0)
                    plcxlAlaramData.MachineNumber = washerNo.ToString();
                plcxlAlaramData.IsTunnel = "0";
                if (plcType == MitsubishiPLCType.PLCXL2Cbw)
                    plcxlAlaramData.IsTunnel = "1";
                if (plcType == MitsubishiPLCType.PLCXL5W1C && washerNo>0)
                {
                    plcxlAlaramData.MachineNumber = (washerNo == 1 ? washerNo : washerNo - 1).ToString();
                    plcxlAlaramData.IsTunnel = washerNo == 1 ? "1" : "0";
                }
            }

            plcxlAlaramData.BatchNumber = alaramInfoPerGroup[alarmIndexParameters + 3].ToString();
            plcxlAlaramData.ProgramNumber = alaramInfoPerGroup[alarmIndexParameters + 4].ToString();
            plcxlAlaramData.DesiredValue = alaramInfoPerGroup[alarmIndexParameters + 5].ToString();
            plcxlAlaramData.MeasuredValue = alaramInfoPerGroup[alarmIndexParameters + 6].ToString();
            plcxlAlaramData.Status = alaramInfoPerGroup[alarmIndexParameters + 7].ToString();
        }
        /// <summary>
        /// AlarmInfoGeneralExtra method by using the active activeAlarmIndex gets all the parameters of that index and the active alarms lies between 210 to 240.
        /// </summary>
        /// <param name="activeAlarmIndex">the activeAlarmIndex</param>
        public void AlarmInfoGeneralExtra(int activeAlarmIndex, MitsubishiPLCType plcType)
        {
       
            //for suppose there are two active alarms 211 and 212 
            //for alarm one the alarmIndexParameters=((211-211)*8) i.e. 0. So array starts from 0 to 7
            //for alarm two the alarmIndexParameters=((212-211)*8) i.e. 8. So array starts from 8 to 15
            int alarmIndexParameters = (activeAlarmIndex - 211) * 8;
            int washerNo;
            plcxlAlaramData = GetAlarmNumber(activeAlarmIndex, plcType);
            DateTime startDateTime = new DateTime(2000, 1, 1);
            startDateTime = startDateTime.AddDays(alaramInfoGeneralExtra[alarmIndexParameters]);
            startDateTime = startDateTime.AddMinutes(alaramInfoGeneralExtra[alarmIndexParameters + 1]);
            string strDateTime = startDateTime.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
            plcxlAlaramData.StartDateTime = strDateTime;

            if (string.IsNullOrEmpty(plcxlAlaramData.MachineNumber) || plcxlAlaramData.MachineNumber == "0")
            {
                washerNo = alaramInfoGeneralExtra[alarmIndexParameters + 2];
                if (washerNo != 0)
                    plcxlAlaramData.MachineNumber = washerNo.ToString();
                plcxlAlaramData.IsTunnel = "0";
                if (plcType == MitsubishiPLCType.PLCXL2Cbw)
                    plcxlAlaramData.IsTunnel = "1";
                if (plcType == MitsubishiPLCType.PLCXL5W1C && washerNo > 0)
                {
                    plcxlAlaramData.MachineNumber = (washerNo == 1 ? washerNo : washerNo - 1).ToString();
                    plcxlAlaramData.IsTunnel = washerNo == 1 ? "1" : "0";
                }
                
            }
            
            plcxlAlaramData.BatchNumber = alaramInfoGeneralExtra[alarmIndexParameters + 3].ToString();
            plcxlAlaramData.ProgramNumber = alaramInfoGeneralExtra[alarmIndexParameters + 4].ToString();
            plcxlAlaramData.DesiredValue = alaramInfoGeneralExtra[alarmIndexParameters + 5].ToString();
            plcxlAlaramData.MeasuredValue = alaramInfoGeneralExtra[alarmIndexParameters + 6].ToString();
            plcxlAlaramData.Status = alaramInfoGeneralExtra[alarmIndexParameters + 7].ToString();
        }

        /// <summary>
        /// GetAlarmNumber method is used to get alarm number based on alarm index
        /// </summary>
        /// <param name="alarmIndex"></param>
        /// <returns>alarmIndex</returns>
        private MyControlAlarmData GetAlarmNumber(int alarmIndex, MitsubishiPLCType plcType)
        {

            if (alarmIndex <= 38)
            {
                plcxlAlaramData = AlarmInfoGeneralIndexes(alarmIndex, plcType);//Gets alarm id's from 1 to 40
            }
            else if (alarmIndex > 40 && alarmIndex < 123)
            {
                plcxlAlaramData = GetAlarmInfoPerGroupOneIndexes(alarmIndex, plcType);
            }
            else if (alarmIndex > 125 && alarmIndex < 208)
            {
                plcxlAlaramData = GetAlarmInfoPerGroupTwoIndexes(alarmIndex, plcType);
            }
            else if (alarmIndex > 210 && alarmIndex < 239)
            {
                plcxlAlaramData = AlaramInfoGeneralExtraIndexes(alarmIndex, plcType);
            }
            
            return plcxlAlaramData;
        }
    
        private MyControlAlarmData GetAlarmInfoPerGroupTwoIndexes(int alarmIndex, MitsubishiPLCType plcType)
        {
            MyControlAlarmData alarmData = new MyControlAlarmData();

            if (alarmIndex > 125 && alarmIndex < 140)
            {

                alarmData.AlarmNumber = "103";// low level alarms group 2               
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();
                if (alarmIndex == 126)
                   alarmData.PumpNbr = "27";
                else 
                    alarmData.PumpNbr = (alarmIndex < 139 ? (alarmIndex - 126 + 14) : 28).ToString();
            }
            else if (alarmIndex > 139 && alarmIndex < 154)
            {
                alarmData.AlarmNumber = "101";// Maximum dosing time alarms group 2    
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();
                if (alarmIndex == 140)
                {
                    alarmData.PumpNbr = "27";
                }
                else
                {
                    alarmData.PumpNbr = (alarmIndex < 153 ? (alarmIndex - 140 + 14) : 28).ToString();
                }
            }
            else if (alarmIndex > 153 && alarmIndex < 172)
            {
                //Alarms ME 1 & ME 2 group 2
                alarmData = GetMEAlarms(alarmIndex);
            }
            else if (alarmIndex == 172)
            {
                //No program in Cbw group 2
                alarmData.AlarmNumber = "149";
                alarmData.IsTunnel = "1";
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
            }
            else if (alarmIndex == 173)
            {
                //Maximum time conductivity Cbw group 2
                alarmData.AlarmNumber = "141";
                alarmData.IsTunnel = "1";
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();

            }
            else if (alarmIndex == 174)
            {
                //Maximum time pH Cbw group 1
                alarmData.AlarmNumber = "142";
                alarmData.IsTunnel = "1";
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
            }
            else if (alarmIndex > 174 && alarmIndex < 178)
            {
                //Temperature alarms Cbw group 2
                alarmData.AlarmNumber = "153";
                alarmData.Probe = (alarmIndex - 174).ToString();
                alarmData.AlarmType = ((int)AlarmType.ProbeAlarm).ToString();
                alarmData.IsTunnel = "1";
                alarmData.MachineNumber = (plcType == MitsubishiPLCType.PLCXL5W1C ? 1 : 2).ToString();
            }
            else if (alarmIndex == 178)
            {
                //Air pressure low group 2
                alarmData.AlarmNumber = "121";
                alarmData.AlarmType = ((int)AlarmType.GroupAlarm).ToString();
            }
            else if (alarmIndex == 179)
            {
                //No flush water group 2
                alarmData.AlarmNumber = "143";
                alarmData.AlarmType = ((int)AlarmType.GroupAlarm).ToString();
            }
            else if (alarmIndex == 180)
            {
                //220 volt low group 1
                alarmData.AlarmNumber = "146";
                alarmData.AlarmType = ((int)AlarmType.GroupAlarm).ToString();
            }
            else if (alarmIndex > 180 && alarmIndex < 193)
            {
                //Flow switch error pump 1 ... pump 12
                alarmData.AlarmNumber = "156";
                alarmData.PumpNbr = (alarmIndex - 180).ToString();
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();

            }
            else if (alarmIndex > 192 && alarmIndex < 207)
            {
                //Leak detection Main-Equipment 1,Leak detection Main-Equipment 2,Pump 1, Pump 2.... 
                alarmData.AlarmNumber = "155";
                alarmData.PumpNbr = (alarmIndex == 193 ? 27 : (alarmIndex == 206 ? 28 : (alarmIndex - 193))).ToString();

                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();
            }
            else if (alarmIndex == 207)
            {
                //Flush leak alarm G2
                alarmData.AlarmNumber = "165";
                alarmData.AlarmType = "5";//Group alarm
            }
            alarmData.Group = "2";
            return alarmData;
        }

        /// <summary>
        /// GetAlarmInfoPerGroupOneIndexes method gets the alarm id's between 41 and 125
        /// </summary>
        /// <param name="alarmIndex">the alarmIndex</param>
        /// <returns>alarmIndex</returns>
        private MyControlAlarmData GetAlarmInfoPerGroupOneIndexes(int alarmIndex, MitsubishiPLCType plcType)
        {
            MyControlAlarmData alarmData = new MyControlAlarmData();
           
            if (alarmIndex > 40 && alarmIndex < 55)
            {
                alarmData.AlarmNumber = "103";// low level alarms group 1                
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();
                if (alarmIndex ==41)
                    alarmData.PumpNbr = "13";
                else if (alarmIndex< 54)
                  alarmData.PumpNbr = (alarmIndex < 54?(alarmIndex - 41):14).ToString();
            }
            else if (alarmIndex > 54 && alarmIndex < 69)
            {
                alarmData.AlarmNumber = "101";// Maximum dosing time alarms group 1    
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();
                if (alarmIndex == 55)
                   alarmData.PumpNbr = "13";
                else
                   alarmData.PumpNbr = (alarmIndex < 68?(alarmIndex - 55):14).ToString();
            }
            else if (alarmIndex > 68 && alarmIndex < 87) //Alarms ME 1 & ME 2 group 1
            {
                alarmData = GetMEAlarms(alarmIndex);
                
            }
            else if (alarmIndex == 87)//No program in Cbw group 1
            {
                alarmData.AlarmNumber = "149";
                alarmData.IsTunnel = "1";
                alarmData.MachineNumber = "1";
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
            }
            else if (alarmIndex == 88)//Maximum time conductivity Cbw group 1
            {
                alarmData.AlarmNumber = "141";
                alarmData.IsTunnel = "1";
                alarmData.MachineNumber = "1";
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();

            }
            else if (alarmIndex == 89)//Maximum time pH Cbw group 1
            {
                alarmData.AlarmNumber = "142";
                alarmData.IsTunnel = "1";
                alarmData.MachineNumber = "1";
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
            }
            else if (alarmIndex > 89 && alarmIndex < 93) //Temperature alarms Cbw group 1
            {
                alarmData.AlarmNumber = "153";
                alarmData.Probe = (alarmIndex - 89).ToString();
                alarmData.MachineNumber = "1";
                alarmData.AlarmType = ((int)AlarmType.ProbeAlarm).ToString();
                alarmData.IsTunnel = "1";
            }
            else if (alarmIndex == 93)//Air pressure low group 1
            {
                alarmData.AlarmNumber = "121";
                alarmData.AlarmType = ((int)AlarmType.GroupAlarm).ToString();
            }
            else if (alarmIndex == 94)//No flush water group 1
            {
                alarmData.AlarmNumber = "143";
                alarmData.AlarmType = ((int)AlarmType.GroupAlarm).ToString();
            }
            else if (alarmIndex == 95)//220 volt low group 1
            {
                alarmData.AlarmNumber = "146";
                alarmData.AlarmType = ((int)AlarmType.GroupAlarm).ToString();
            }
            else if (alarmIndex >95 && alarmIndex < 108) 
            {
                alarmData.AlarmNumber = "156";//Flow switch error pump 1 ... pump 12
                alarmData.PumpNbr = (alarmIndex - 95).ToString();
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();

            }
            else if (alarmIndex > 107 && alarmIndex < 122) 
            {
                alarmData.AlarmNumber = "155";//Leak detection Main-Equipment 1,Leak detection Main-Equipment 2,Pump 1, Pump 2.... 
                alarmData.PumpNbr = (alarmIndex == 108 ? 13 : (alarmIndex == 121 ? 14 : (alarmIndex - 108))).ToString();
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();
            }
            else if (alarmIndex == 122)//Flush leak alarm G1
            {
                alarmData.AlarmNumber = "164";
                alarmData.AlarmType = ((int)AlarmType.GroupAlarm).ToString();
            }
            alarmData.Group = "1";
            return alarmData;
        }
        /// <summary>
        /// AlarmInfoGeneralIndexes method gets the alarm id's between 1 and 40
        /// </summary>
        /// <param name="alarmIndex">the alarmIndex</param>
        /// <returns>alarmIndex</returns>
        private MyControlAlarmData AlarmInfoGeneralIndexes(int alarmIndex, MitsubishiPLCType plcType)
        {
            MyControlAlarmData alarmData = new MyControlAlarmData(); 

            if (alarmIndex>0 && alarmIndex  < 11)
            {

                alarmData.AlarmNumber = "159";// No valid program number alarm for washers
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
                alarmData.IsTunnel = "0";
                alarmData.MachineNumber = alarmIndex.ToString();
            }
            else if (alarmIndex > 10 && alarmIndex < 21)
            {
                alarmData.AlarmNumber = "157";//pH to0 low alarm Washers
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
                alarmData.IsTunnel = "0";
                alarmData.MachineNumber = (alarmIndex-10).ToString();
            }
            else if (alarmIndex > 20 && alarmIndex < 31)
            {
                alarmData.AlarmNumber = "158";// pH too high Washers
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
                alarmData.IsTunnel = "0";
                alarmData.MachineNumber = (alarmIndex - 20).ToString();
            }
            else if (alarmIndex == 31)
            {
                alarmData.AlarmNumber = "154";//Temperature alarm washers
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
            else if (alarmIndex == 32)
            {
                alarmData.AlarmNumber = "120";// Emergency stop
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
            else if (alarmIndex == 33)
            {
                alarmData.AlarmNumber = "139";// 24 volt DC low
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
            else if (alarmIndex == 34)
            {
                alarmData.AlarmNumber = "144";//  Battery PLC low
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
            else if (alarmIndex == 35)
            {
                alarmData.AlarmNumber = "150";// No answer ME1 remote PLC
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
            else if (alarmIndex == 36)
            {
                alarmData.AlarmNumber = "151";// No answer ME2 remote PLC
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
            else if (alarmIndex == 37)
            {
                alarmData.AlarmNumber = "152";// Helms communication time-out
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
            else if (alarmIndex == 38)
            {
                alarmData.AlarmNumber = "163";// ConnexAlarm
                alarmData.AlarmType = ((int)AlarmType.GeneralAlarm).ToString();
            }
           
            return alarmData;
        }
     
        private MyControlAlarmData GetMEAlarms(int alarmIndex)
        {
            MyControlAlarmData alarmData = new MyControlAlarmData();
            int startIndex=0;
            int[] alarmCodes = new int[] { 104, 105, 106, 107, 108, 110, 145, 147, 148 };
            int index;
            if (alarmIndex>=69 && alarmIndex <= 77)
            {
                alarmData.PumpNbr = "13";//Group 1 ME 1 
                startIndex = 69;
            }
            else if (alarmIndex >= 78 && alarmIndex <= 86)
            {
                startIndex = 78;
                alarmData.PumpNbr = "14";//Group 1 ME 2 
            }
            else if (alarmIndex >= 154 && alarmIndex <= 162)
            {
                startIndex = 154;
                alarmData.PumpNbr = "27";//Group 2 ME  1
            }
            else if (alarmIndex >= 163 && alarmIndex <= 171)
            {
                startIndex = 163;
                alarmData.PumpNbr = "28";//Group 2 ME  2
            }
            if (startIndex > 0)
            {
                index = alarmIndex - startIndex;
                alarmData.AlarmNumber = alarmCodes[index].ToString();
                alarmData.AlarmType = ((int)AlarmType.PumpAlarm).ToString();
            }
            return alarmData;
        }

        /// <summary>
        /// AlaramInfoGeneralExtraIndexes method gets the alarm id's between 231 and 238
        /// </summary>
        /// <param name="alarmIndex">the alarmIndex</param>
        /// <returns>alarmIndex</returns>
        private MyControlAlarmData AlaramInfoGeneralExtraIndexes(int alarmIndex, MitsubishiPLCType plcType)
        {

            MyControlAlarmData alarmData = new MyControlAlarmData();
            
            if (alarmIndex > 210 && alarmIndex < 221)
            {
                alarmData.AlarmNumber = "162";//Previous program not finnished
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
                alarmData.IsTunnel = "0";
                alarmData.MachineNumber = (alarmIndex - 210).ToString();
                
            }
            else if (alarmIndex > 220 && alarmIndex < 231)
            {
                
                alarmData.AlarmNumber = "404";//  Temperature to low Washer
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
                alarmData.IsTunnel = "0";
                alarmData.MachineNumber = (alarmIndex - 220).ToString();

            }
            else if (alarmIndex >230  && alarmIndex < 235)
            {
                //Ph to low CBW1,pH to high cbw 1 
                //Ph to low CBW2,pH to high cbw 2

                alarmData.AlarmNumber = alarmIndex % 2 ==1?"400":"401";//Ph to low CBW1
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
                alarmData.IsTunnel = "1";
                alarmData.MachineNumber = (alarmIndex < 233 ? 1 : 2).ToString();
                alarmData.Group = alarmData.MachineNumber;

            }
            else if (alarmIndex > 234 && alarmIndex < 239)
            {
                alarmData.AlarmNumber = alarmIndex % 2 == 1 ? "402" : "403";//Ph to low CBW1
                alarmData.AlarmType = ((int)AlarmType.MachineAlarm).ToString();
                alarmData.IsTunnel = "1";
                alarmData.MachineNumber = (alarmIndex < 237 ? 1 : 2).ToString();
                alarmData.Group = alarmData.MachineNumber;
            }
           
            return alarmData;
        }
        /// <summary>
        /// ConvertDecimalToBinary method converts decimal number to binary and reverses that array
        /// </summary>
        /// <param name="decimalValue"></param>
        /// <returns>decimalValue</returns>
        private int[] ConvertDecimalToBinary(int decimalValue)
        {
            int remainder;
            string result = string.Empty;
            while (decimalValue > 0)
            {
                remainder = decimalValue % 2;
                decimalValue /= 2;
                result = remainder.ToString() + result;
            }
            char[] array = result.ToCharArray();
            int[] intArr = array.Select(i => Int32.Parse(i.ToString())).ToArray();
            Array.Reverse(intArr);
            return intArr;
        }
        private int[] ReadArray(MitsubishiController controller, string address, int length)
        {
            MitsubishiTag ArrayTag = new MitsubishiTag() { Address = address, TagItemType = UIInputType.TypeArray, ArrayLength = length };// Helms5Data Array
            IList<MitsubishiTag> ArrayTags = new List<MitsubishiTag>() { ArrayTag };
            DataReader<MitsubishiTag> dataReader = objreader[controller.HostAdress];
            ArrayTags = dataReader.ReadTags(ArrayTags);
            return ArrayTag.IntArrayData;
        }
        private static string GetAccessSaveAddress(MitsubishiController controller)
        {
            string address = null;
            if (controller != null)
            {
                if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
                {
                    address = "R2550";
                }
                else if (controller.PLCType == MitsubishiPLCType.PLCXL10W)
                {
                    address = "R2000";
                }
                else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw)
                {
                    address = "R400";
                }
            }
            return address;
        }
        private static string GetCompSaveAddress(MitsubishiController controller)
        {
            string address = null;
            if (controller != null)
            {
                if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
                {
                    address = "R2590";
                }
                else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw)
                {
                    address = "R415";
                }
            }
            return address;
        }
        private void ReadOnlineDataForTunnels(MitsubishiController controller, int[] helm5Array)
        {
            int programNumOffset;
            int loadOffset;
            int customerNumOffset;
            int batchNumOffset;
            int groupNum;
            if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
            {
                programNumOffset = 30;
                loadOffset = 50;
                customerNumOffset = 70;
                batchNumOffset = 185;
                groupNum = 2;
                PopulateTunnelOnlineBatchData(helm5Array, controller, programNumOffset, loadOffset, customerNumOffset, batchNumOffset, 1, groupNum);
            }
            if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw)
            {
                programNumOffset = 0;
                loadOffset = 40;
                customerNumOffset = 80;
                batchNumOffset = 140;
                groupNum = 1;
                PopulateTunnelOnlineBatchData(helm5Array, controller, programNumOffset, loadOffset, customerNumOffset, batchNumOffset, 1, groupNum);
                programNumOffset = 20;
                loadOffset = 60;
                customerNumOffset = 100;
                batchNumOffset = 160;
                groupNum = 2;
                PopulateTunnelOnlineBatchData(helm5Array, controller, programNumOffset, loadOffset, customerNumOffset, batchNumOffset, 2, groupNum);
            }
        }
        private int[] ReadTransferAndRunstateSignals(MitsubishiController controller)
        {
            try
            {
                IList<MitsubishiTag> ArrayTags = new List<MitsubishiTag>();
                if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
                {
                    ArrayTags = new List<MitsubishiTag>() { new MitsubishiTag() { Address = "M2071", TagItemType = UIInputType.TypeBool }, new MitsubishiTag() { Address = "M2070", TagItemType = UIInputType.TypeBool } };
                }
                else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw)
                {
                    ArrayTags = new List<MitsubishiTag>() { new MitsubishiTag() { Address = "M2080", TagItemType = UIInputType.TypeBool }, new MitsubishiTag() { Address = "M2088", TagItemType = UIInputType.TypeBool }, new MitsubishiTag() { Address = "M2081", TagItemType = UIInputType.TypeBool }, new MitsubishiTag() { Address = "M2089", TagItemType = UIInputType.TypeBool, } };
                }
                DataReader<MitsubishiTag> dataReader = objreader[controller.HostAdress];
                ArrayTags = dataReader.ReadTags(ArrayTags);
                return ArrayTags.Select(x => Convert.ToInt32(x.Value)).ToArray();    // Cbw 1 Transfer Signal //Cbw 1 Runstate Signal // Cbw 2 Transfer Signal //Cbw 2 Runstate Signal
            }
            catch (Exception ex)
            {

                Log.ErrorFormat("Error occured in ReadTransferAndRunstateSignals method", ex.Message);
                Log.Error(ex);
                throw ex;
            }
        }
        private void PopulateTunnelOnlineBatchData(int[] batchData, MitsubishiController controller, int programNumOffset, int loadOffset, int customerNumOffset, int batchNumOffset, int tunnelNumber, int groupNum)
        {
            MyControlTunnel tunnel = new MyControlTunnel();
            tunnel.Tunnels = new List<TunnelData>();
            int NoOfCompartments = 20;
            NoOfCompartments = CommonDataOperations.GetNoOfCompartmentsByMachineInternalId(tunnelNumber, controller.ControllerId);
            if (NoOfCompartments < 1)
                NoOfCompartments = 20;
            int[] signals = ReadTransferAndRunstateSignals(controller);
            for (int compartmentNum = 0; compartmentNum < NoOfCompartments; compartmentNum++)
            {
                TunnelData tunnelOnlineData = new TunnelData();
                tunnelOnlineData.TimeCompartment = new List<CompartmentTime>();
                tunnelOnlineData.dose = new List<Dose>();
                tunnelOnlineData.temperature = new List<TemperatureData>();
                if (tunnelNumber == 1 && signals.Length >= 2)
                {
                    tunnelOnlineData.TransferSignal = signals[0].ToString();          // signals[0] = Cbw 1 Transfer Signal
                    tunnelOnlineData.RunState = signals[1].ToString();               //  signals[1] = Cbw 1 Runstate Signal
                }
                else if (tunnelNumber == 2 && signals.Length >= 4)
                {
                    tunnelOnlineData.TransferSignal = signals[2].ToString();               // signals[0] = Cbw 2 Transfer Signal
                    tunnelOnlineData.RunState = signals[3].ToString();                     // signals[1] =  Cbw 2 Runstate Signal
                }
                tunnelOnlineData.GroupNumber = groupNum.ToString();
                tunnelOnlineData.CompartmentNumber = (compartmentNum + 1).ToString();
                tunnelOnlineData.BatchNumber = batchData[batchNumOffset].ToString();
                tunnelOnlineData.CustomerNumber = batchData[customerNumOffset].ToString();
                tunnelOnlineData.ProgramNumber = batchData[programNumOffset].ToString();
                tunnelOnlineData.TunnelNumber = tunnelNumber.ToString();
                tunnelOnlineData.MachineNumber = tunnelNumber.ToString();
                tunnelOnlineData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                if (controller.RegionID == 1) //North America
                {
                    tunnelOnlineData.Load = (batchData[loadOffset]/10).ToString();
                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    tunnelOnlineData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, batchData[loadOffset]/10).ToString();
                }
                PopulateTunnelOnlineSensorData(controller, batchData, compartmentNum + 1, ref tunnelOnlineData);
                PopulateTunnelOnlineDosingData(controller, batchData, compartmentNum + 1, ref tunnelOnlineData);
                if (tunnelOnlineData != null && tunnelOnlineData.MachineNumber != "0" && tunnelOnlineData.MachineNumber != null) tunnel.Tunnels.Add(tunnelOnlineData);

                programNumOffset++;
                loadOffset++;
                customerNumOffset++;
                batchNumOffset++;
            }
            string xmlString = SerializeXMLData(TunnelSerializer, tunnel);
            int RedFlagShiftId = 0;
            Log.InfoFormat("Processing Tunnel WasherId and XML Data {0} {1}", controller.ControllerId, xmlString);
            RedFlagShiftId = DataReaderAccess.ProcessMitsubishiTunnelWasherOnlineData(controller.ControllerId, xmlString, RedFlagShiftId);
            if (RedFlagShiftId > 0)
            {
                DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
            }
        }
        private static void PopulateTunnelOnlineSensorData(MitsubishiController controller, int[] batchData, int compartmentNum, ref TunnelData tunnelOnlineData)
        {
            if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
            {
                PopulateTunnelOnlineSensorDataFor5W1C(batchData, compartmentNum, ref tunnelOnlineData);
            }
            else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw && tunnelOnlineData.GroupNumber == "1")
            {
                PopulateTunnel1OnlineSensorDataFor2CBW(batchData, compartmentNum, ref tunnelOnlineData);
            }
            else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw && tunnelOnlineData.GroupNumber == "2")
            {
                PopulateTunnel2OnlineSensorDataFor2CBW(batchData, compartmentNum, ref tunnelOnlineData);
            }
        }
        private static void PopulateTunnelOnlineSensorDataFor5W1C(int[] batchData, int compartmentNum, ref TunnelData tunnelOnlineData)
        {
            //pH
            if (batchData[251] == compartmentNum && batchData[20] > 0)
            {
                tunnelOnlineData.Phcompartment = compartmentNum.ToString();
                tunnelOnlineData.Phvalue = batchData[20].ToString();
            }
            //Conductivity
            if (batchData[235] == compartmentNum && batchData[21] > 0)
            {
                tunnelOnlineData.ConductivityCompartment = compartmentNum.ToString();
                tunnelOnlineData.ConductivityValue = batchData[21].ToString();
            }
            tunnelOnlineData.temperature = new List<TemperatureData>();
            //Temperature1
            if (batchData[239] == compartmentNum && batchData[22] > 0)
            {
                TemperatureData temperature1 = new TemperatureData();
                temperature1.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[22]).ToString();
                temperature1.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature1);
            }
            //Temperature2
            if (batchData[243] == compartmentNum && batchData[23] > 0)
            {
                TemperatureData temperature2 = new TemperatureData();
                temperature2.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[23]).ToString();
                temperature2.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature2);
            }
            //Temperature3
            if (batchData[247] == compartmentNum && batchData[24] > 0)
            {
                TemperatureData temperature3 = new TemperatureData();
                temperature3.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[24]).ToString();
                temperature3.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature3);
            }
        }
        private static void PopulateTunnel1OnlineSensorDataFor2CBW(int[] batchData, int compartmentNum, ref TunnelData tunnelOnlineData)
        {
            //pH
            if (batchData[246] == compartmentNum && batchData[120] > 0)
            {
                tunnelOnlineData.Phcompartment = compartmentNum.ToString();
                tunnelOnlineData.Phvalue = batchData[120].ToString();
            }
            //Conductivity
            if (batchData[230] == compartmentNum && batchData[122] > 0)
            {
                tunnelOnlineData.ConductivityCompartment = compartmentNum.ToString();
                tunnelOnlineData.ConductivityValue = batchData[122].ToString();
            }
            tunnelOnlineData.temperature = new List<TemperatureData>();
            //Temperature1
            if (batchData[234] == compartmentNum && batchData[124] > 0)
            {
                TemperatureData temperature1 = new TemperatureData();
                temperature1.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[124]).ToString();
                temperature1.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature1);
            }
            //Temperature2
            if (batchData[238] == compartmentNum && batchData[125] > 0)
            {
                TemperatureData temperature2 = new TemperatureData();
                temperature2.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[125]).ToString();
                temperature2.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature2);
            }
            //Temperature3
            if (batchData[242] == compartmentNum && batchData[126] > 0)
            {
                TemperatureData temperature3 = new TemperatureData();
                temperature3.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[126]).ToString();
                temperature3.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature3);
            }
        }
        private static void PopulateTunnel2OnlineSensorDataFor2CBW(int[] batchData, int compartmentNum, ref TunnelData tunnelOnlineData)
        {
            //pH
            if (batchData[266] == compartmentNum && batchData[121] > 0)
            {
                tunnelOnlineData.Phcompartment = compartmentNum.ToString();
                tunnelOnlineData.Phvalue = batchData[121].ToString();
            }
            //Conductivity
            if (batchData[250] == compartmentNum && batchData[123] > 0)
            {
                tunnelOnlineData.ConductivityCompartment = compartmentNum.ToString();
                tunnelOnlineData.ConductivityValue = batchData[123].ToString();
            }
            tunnelOnlineData.temperature = new List<TemperatureData>();
            //Temperature1
            if (batchData[254] == compartmentNum && batchData[127] > 0)
            {
                TemperatureData temperature1 = new TemperatureData();
                temperature1.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[127]).ToString();
                temperature1.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature1);
            }
            //Temperature2
            if (batchData[258] == compartmentNum && batchData[128] > 0)
            {
                TemperatureData temperature2 = new TemperatureData();
                temperature2.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[128]).ToString();
                temperature2.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature2);
            }
            //Temperature3
            if (batchData[262] == compartmentNum && batchData[129] > 0)
            {
                TemperatureData temperature3 = new TemperatureData();
                temperature3.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, batchData[129]).ToString();
                temperature3.Compartment = compartmentNum.ToString();
                tunnelOnlineData.temperature.Add(temperature3);
            }
        }
        private static void GetTunnelOnlineDosingIndex(MitsubishiController controller, string groupNumber, out int ME1Index, out int ME2Index, out int directDosingIndex, out int pumpValveIndex)
        {
            ME1Index = 0;
            ME2Index = 0;
            directDosingIndex = 0;
            pumpValveIndex = 0;

            if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
            {
                ME1Index = 295;
                ME2Index = 313;
                directDosingIndex = 301;
                pumpValveIndex = 319;
            }
            else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw && groupNumber == "1")
            {
                ME1Index = 370;
                ME2Index = 388;
                directDosingIndex = 376;
                pumpValveIndex = 394;
            }
            else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw && groupNumber == "2")
            {
                ME1Index = 402;
                ME2Index = 420;
                directDosingIndex = 408;
                pumpValveIndex = 426;
            }
        }
        private static void GetTunnelOnlineDosingCompartmentIndex(MitsubishiController controller, string groupNumber, out int ME1CompIndex, out int ME2CompIndex, out int directDosingCompIndex, out int pumpValveCompIndex)
        {
            ME1CompIndex = 0;
            ME2CompIndex = 0;
            directDosingCompIndex = 0;
            pumpValveCompIndex = 0;
            if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
            {
                ME1CompIndex = 255;
                ME2CompIndex = 273;
                directDosingCompIndex = 261;
                pumpValveCompIndex = 279;
            }
            else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw && groupNumber == "1")
            {
                ME1CompIndex = 280;
                ME2CompIndex = 298;
                directDosingCompIndex = 286;
                pumpValveCompIndex = 304;
            }
            else if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw && groupNumber == "2")
            {
                ME1CompIndex = 330;
                ME2CompIndex = 348;
                directDosingCompIndex = 336;
                pumpValveCompIndex = 354;
            }
        }
        private static void PopulateTunnelOnlineDosingData(MitsubishiController controller, int[] batchData, int compartmentNum, ref TunnelData tunnelOnlineData)
        {
            int pumpNumIndex = 0, ME1Number = 0, ME2Number = 0;
            int ME1Index = 0, ME2Index = 0, directDosingIndex = 0, pumpValveIndex = 0;
            int ME1CompIndex = 0, ME2CompIndex = 0, directDosingCompIndex = 0, pumpValveCompIndex = 0;
            if (tunnelOnlineData.GroupNumber == "1")
            {
                pumpNumIndex = 1;
                ME1Number = 13;
                ME2Number = 14;
            }
            else if (tunnelOnlineData.GroupNumber == "2")
            {
                pumpNumIndex = 15;
                ME1Number = 27;
                ME2Number = 28;
            }
            GetTunnelOnlineDosingIndex(controller, tunnelOnlineData.GroupNumber, out ME1Index, out ME2Index, out directDosingIndex, out pumpValveIndex);
            GetTunnelOnlineDosingCompartmentIndex(controller, tunnelOnlineData.GroupNumber, out ME1CompIndex, out ME2CompIndex, out directDosingCompIndex, out pumpValveCompIndex);
            //Main Equiment 1
            for (int index = 0; index < 6; index++)
            {
                if (batchData[ME1Index + index] > 0 && batchData[ME1CompIndex + index] == compartmentNum)
                {
                    Dose ME1Dose = new Dose();
                    ME1Dose.Number = ME1Number.ToString();
                    ME1Dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, batchData[ME1Index + index]).ToString();
                    //ME1Dose.Quantity = batchData[ME1Index + index].ToString();
                    ME1Dose.IsMainEquipment = "1";
                    ME1Dose.Point = (index + 1).ToString();
                    tunnelOnlineData.dose.Add(ME1Dose);
                }
            }
            //Direct dosing pumps
            for (int index = 0; index < 12; index++)
            {
                if (batchData[directDosingIndex + index] > 0 && batchData[directDosingCompIndex + index] == compartmentNum)
                {
                    Dose directDose = new Dose();
                    directDose.Number = pumpNumIndex.ToString();
                    directDose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, batchData[directDosingIndex + index]).ToString();
                    directDose.IsMainEquipment = "0";
                    directDose.IsDirectDosing = "1";
                    tunnelOnlineData.dose.Add(directDose);
                }
                pumpNumIndex++;
            }
            //Main Equipment 2
            for (int index = 0; index < 6; index++)
            {
                if (batchData[ME2Index + index] > 0 && batchData[ME2CompIndex + index] == compartmentNum)
                {
                    Dose ME2Dose = new Dose();
                    ME2Dose.Number = ME2Number.ToString();
                    ME2Dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, batchData[ME2Index + index]).ToString();
                    ME2Dose.IsMainEquipment = "1";
                    ME2Dose.Point = (index + 1).ToString();
                    tunnelOnlineData.dose.Add(ME2Dose);
                }
            }
            //pump-valve
            for (int index = 0; index < 8; index++)
            {
                if (batchData[pumpValveIndex + index] > 0 && batchData[pumpValveCompIndex + index] == compartmentNum)
                {
                    Dose dose = new Dose();
                    dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, batchData[pumpValveIndex + index]).ToString();
                    dose.IsMainEquipment = "0";
                    dose.IsDirectDosing = "0";
                    dose.Point = (index + 1).ToString();
                    //dose.Number
                    tunnelOnlineData.dose.Add(dose);
                }
            }
        }
        private void ReadStepSave(MitsubishiController controller, int[] helm5Array)
        {
            ConventionalWasherData washerData = new ConventionalWasherData();
            int offsetStart = 940;
            int MachineNumber;
            int stepNumber;
            int equipmentNo;
            int quantity;
            int analogMin;
            int analogMax;
            bool recordTemperature = false;
            int StopDateHoures;
            int StopDateMinutes;
            int StopDateSeconds;
            int StopDay;
            int stopMonth;
            int StopYear;
            DateTime StartDate;
            string stepSaveAddress = string.Empty;
            if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
            {
                stepSaveAddress = "R2565";
            }
            else if (controller.PLCType == MitsubishiPLCType.PLCXL10W)
            {
                stepSaveAddress = "R2015";
            }
            DateTime StopDate;
            ConventionalDosingData dosingData;
            MachineNumber = helm5Array[offsetStart];
            if (MachineNumber == 0) return;
            if (helm5Array[offsetStart] < 0 || helm5Array[offsetStart] > 10)
            {
                Log.InfoFormat("Invalid data in Step Save.ControllerID{0}, Washer No{1}", controller.ControllerId, helm5Array[offsetStart]);
                return;
            }
            if (helm5Array[offsetStart + 1] <= 0)
            {
                Log.InfoFormat("Invalid data in Step Save. Batch Counter{0}", helm5Array[offsetStart + 1]);
                return;
            }
            if (helm5Array[offsetStart + 2] < 1 || helm5Array[offsetStart + 2] > 2)
            {
                Log.InfoFormat("Invalid data in Step Save.ControllerID{0}, Group Number {1}", controller.ControllerId, helm5Array[offsetStart + 2]);
                return;
            }
            try
            {
                StartDate = new DateTime(2000, 1, 1).AddDays(helm5Array[offsetStart + 3]);
            }
            catch (Exception exp)
            {
                Log.ErrorFormat("Invalid data in Step Save.ControllerID{0}, Date Field{1}", controller.ControllerId, helm5Array[offsetStart + 3]);
                Log.Error(exp);
                return;
            }
            washerData.MachineNumber = MachineNumber.ToString();
            washerData.BatchNumber = helm5Array[offsetStart + 1].ToString();
            stepNumber = helm5Array[offsetStart + 4];
            washerData.StepNumber = helm5Array[offsetStart + 4].ToString();
            washerData.StepDuration = helm5Array[offsetStart + 5].ToString();
            washerData.StartDateTime = StartDate.ToString("MM/dd/yyyy HH:mm:ss");
            int dosingOffset = 950;
            List<ConventionalDosingData> dosingDataList = new List<ConventionalDosingData>();
            for (int index = dosingOffset; index <= 961; index = index + 2)
            {
                equipmentNo = helm5Array[index];
                quantity = helm5Array[index + 1];
                if (equipmentNo == 0) continue;
                dosingData = new ConventionalDosingData();
                dosingData.Equipment = equipmentNo.ToString();
                dosingData.stepNo = stepNumber.ToString();
                dosingData.Qty = quantity.ToString();
                dosingDataList.Add(dosingData);
            }
            washerData.DosingData = dosingDataList;
            washerData.WaterConsumption1 = helm5Array[offsetStart + 6].ToString();
            if (helm5Array[offsetStart + 9] > 0)
            {
                washerData.RunTime = helm5Array[offsetStart + 9].ToString();
                StopDate = new DateTime(2000, 1, 1).AddDays(helm5Array[offsetStart + 25]);
                StopDay = StopDate.Day;
                stopMonth = StopDate.Month;
                StopYear = StopDate.Year;
                StopDateHoures = helm5Array[offsetStart + 26] / 360;
                StopDateMinutes = (helm5Array[offsetStart + 26] - (StopDateHoures * 360)) / 6;
                StopDateSeconds = (helm5Array[offsetStart + 26] - (StopDateHoures * 360) - (StopDateMinutes * 6)) * 10;

                if ((StopDateHoures < 0 || StopDateHoures > 23) || (StopDateMinutes < 0 || StopDateMinutes > 59) || (StopDateSeconds < 0 || StopDateSeconds > 59))
                {
                    Log.ErrorFormat(@"ReadSetpSave.Invalidate Time  from PLC:Controller{0}, 
                                                Machine number:{1}, BatchNumber:{2}, StopDateHours:{3},
                                                StopMinute:{4},StopDateSeconds{5}",
                                               controller.ControllerId,
                                           washerData.MachineNumber, washerData.BatchNumber,
                                           StopDateHoures, StopDateMinutes, StopDateMinutes);
                    washerData.EndDateTime = DateTime.Now.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss");
                }
                else
                {
                    washerData.EndDateTime = new DateTime(StopYear, stopMonth, StopDay, StopDateHoures, StopDateMinutes, StopDateSeconds).ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss");
                }
                analogMin = helm5Array[offsetStart + 7];
                analogMax = helm5Array[offsetStart + 8];
                if (analogMin > 0 && analogMin < 1000)
                {
                    recordTemperature = true;
                    washerData.TemperatureMin = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, analogMin).ToString();
                    if (analogMax > 0)
                        washerData.TemperatureMax = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, analogMax).ToString();
                    washerData.TemperatureMinStatus = helm5Array[offsetStart + 22].ToString();
                    washerData.CoolDownFactor = helm5Array[offsetStart + 23].ToString();
                }
                if (recordTemperature == false)
                {
                    washerData.PHValue = analogMin.ToString();
                    washerData.PHStatus = helm5Array[offsetStart + 22].ToString();
                }
            }
            string xmlString;
            xmlString = SerializeXMLData(ConventionalXmlSerializer, washerData);
            int RedFlagShiftId = 0;
            Log.InfoFormat("Processing Step Save for PLC-XL Tunnel. Controller {0} and XML Data {1}", controller.ControllerId, xmlString);
            RedFlagShiftId = DataReaderAccess.ProcessMitsubishiStepSaveData(controller.ControllerId, xmlString, RedFlagShiftId);
            if (RedFlagShiftId > 0)
            {
                DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
            }
            ResetProductionArray(controller, stepSaveAddress);
        }
        private void ReadAccessSaveData(MitsubishiController controller)
        {
            int[] accessSaveArray;
            while (true)
            {
                accessSaveArray = ReadArray(controller, GetAccessSaveAddress(controller), 15);
                if (accessSaveArray[0] == 0)
                {
                    return;
                }
                PLCData plcData = new PLCData();
                if (accessSaveArray.Length >= 9)
                {
                    plcData.MachineNumber = accessSaveArray[0].ToString();
                    plcData.GroupNumber = accessSaveArray[1].ToString();
                    plcData.BatchCounter = accessSaveArray[2].ToString();
                    plcData.ProgramNumber = accessSaveArray[5].ToString();
                    plcData.CustomerNumber = accessSaveArray[6].ToString();
                    if ((controller.PLCType == MitsubishiPLCType.PLCXL5W1C && accessSaveArray[1] == 1) || controller.PLCType == MitsubishiPLCType.PLCXL10W)
                    {
                        plcData.IsTunnel = "0";
                        if (controller.RegionID == 1) //North America
                        {
                            plcData.Load = accessSaveArray[7].ToString();
                            plcData.NominalLoad = accessSaveArray[8].ToString();
                        }
                        else if (controller.RegionID == 2) //Europe / Middle East / Africa
                        {
                            plcData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, accessSaveArray[7]).ToString();
                            plcData.NominalLoad = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, accessSaveArray[8]).ToString();
                        }
                    }
                    else
                    {
                        plcData.IsTunnel = "1";
                        if (controller.RegionID == 1) //North America
                        {
                            plcData.Load = (accessSaveArray[7] / 10).ToString();
                            plcData.NominalLoad = accessSaveArray[8].ToString();
                        }
                        else if (controller.RegionID == 2) //Europe / Middle East / Africa
                        {
                            plcData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, accessSaveArray[7] / 10).ToString();
                            plcData.NominalLoad = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, accessSaveArray[8]).ToString();
                        }
                    }
                    DateTime startDateTime = new DateTime(2000, 1, 1);
                    startDateTime = startDateTime.AddDays(accessSaveArray[3]);
                    startDateTime = startDateTime.AddSeconds(accessSaveArray[4] * 10);
                    plcData.StartDateTime = startDateTime.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                }
                int RedFlagShiftId = 0;
                string xmlString = SerializeXMLData(ConventionalXmlSerializerForAccessSave, plcData);
                Log.InfoFormat("Processing Access Save for PLC-XL Tunnel. Controller {0} and XML Data {1}", controller.ControllerId, xmlString);
                RedFlagShiftId = DataReaderAccess.ProcessMitsubishiAccessSaveData(controller.ControllerId, xmlString, RedFlagShiftId);
                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
                ResetProductionArray(controller, GetAccessSaveAddress(controller));
            }
        }
        private void WriteXMLToFile(string fileName, string xmlString)
        {
            FileStream fs = File.Create(@"D:\PLC\Log\" + fileName + fileCounter.ToString() + ".xml");
            fileCounter++;
            StreamWriter ts = new StreamWriter(fs);
            ts.Write(xmlString.Substring(41));
            ts.Close();
            fs.Close();
        }
        private void ResetProductionArray(MitsubishiController controller, string address)
        {
            //PLCXLEthernetWriter dataWriter = new PLCXLEthernetWriter(controller);
            MitsubishiTag tag = new MitsubishiTag { Address = address, Value = "0", TagItemType = UIInputType.TypeInt };
            DataWriter<MitsubishiTag> dataWriter = objwriter[controller.HostAdress];
            dataWriter.WriteTag(tag);
        }
        private void ReadCompSaveDataForTunnels(MitsubishiController controller)
        {
            int[] compSaveArray = ReadArray(controller, GetCompSaveAddress(controller), 75);

            if (compSaveArray[0] == 0)
            {
                return;
            }
            MyControlTunnel tunnel = new MyControlTunnel();
            tunnel.Tunnels = new List<TunnelData>();
            TunnelData tunnelProductionData = new TunnelData();
            tunnelProductionData.dose = new List<Dose>();
            if (compSaveArray != null)
            {
                PopulateProdTunnelBasicInfo(compSaveArray, ref tunnelProductionData);

                PopulateProdTunnelCompartmentTime(compSaveArray, ref tunnelProductionData);

                PopulateProdTunnelDosingInfo(compSaveArray, ref tunnelProductionData);

                PopulateProdTunnelBatchParameters(controller, compSaveArray, ref tunnelProductionData);
            }
            if (tunnelProductionData.BatchNumber != "0" && tunnelProductionData.BatchNumber != null) tunnel.Tunnels.Add(tunnelProductionData);
            string xmlString = SerializeXMLData(TunnelSerializer, tunnel);
            Log.InfoFormat("Processing Tunnel Production data for controller: {0} and XML Data: {1}", controller.ControllerId, xmlString);            
            DataReaderAccess.ProcessMitsubishiTunnelWasherProdData(controller.ControllerId, xmlString);
            ResetProductionArray(controller, GetCompSaveAddress(controller));
        }
        private static void PopulateProdTunnelBasicInfo(int[] compSaveArray, ref TunnelData tunnelProductionData)
        {
            tunnelProductionData.BatchNumber = compSaveArray[0].ToString();
            tunnelProductionData.GroupNumber = compSaveArray[2].ToString();
            tunnelProductionData.CompartmentNumber = "20";
            DateTime startDate = new DateTime(2000, 1, 1).AddDays(compSaveArray[3]);
            tunnelProductionData.StartDateTime = startDate.ToUniversalTime().ToString("MM/dd/yyyy", new System.Globalization.CultureInfo("en-US"));
            DateTime stopDatTime = new DateTime(2000, 1, 1).AddDays(compSaveArray[4]);
            int StopDateHoures = compSaveArray[41] / 360;
            int StopDateMinutes = (compSaveArray[41] - (StopDateHoures * 360)) / 6;
            int StopDateSeconds = (compSaveArray[41] - (StopDateHoures * 360) - (StopDateMinutes * 6)) * 10;
            tunnelProductionData.EndDateTime = stopDatTime.AddSeconds(StopDateSeconds).ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
        }
        private static void PopulateProdTunnelCompartmentTime(int[] compSaveArray, ref TunnelData tunnelProductionData)
        {
            tunnelProductionData.TimeCompartment = new List<CompartmentTime>();
            int compartmentIndex = 51;
            for (int compartmentNum = 0; compartmentNum < 20; compartmentNum++)
            {
                CompartmentTime ct = new CompartmentTime();
                ct.CompartmentNo = (compartmentNum + 1).ToString();
                ct.Time = compSaveArray[compartmentIndex + compartmentNum].ToString(); ;
                tunnelProductionData.TimeCompartment.Add(ct);
            }
        }
        private static void PopulateProdTunnelDosingInfo(int[] compSaveArray, ref TunnelData tunnelProductionData)
        {
            //Dosing Quantities indexes are 5 to 36
            //First 6 are for Main Equipment 1 (ME1V1 to ME1V6)
            //Next 12 are for direct dosing pumps (P1 to P12)
            //Next 6 are for Main Equipment 2 (ME2V1 to ME2V6)
            //Next 8 are for Pump-Vale (PV1 to PV8)
            int pumpNumIndex = 0, ME1Number = 0, ME2Number = 0;
            if (tunnelProductionData.GroupNumber == "1")
            {
                pumpNumIndex = 1;
                ME1Number = 13;
                ME2Number = 14;
            }
            else if (tunnelProductionData.GroupNumber == "2")
            {
                pumpNumIndex = 15;
                ME1Number = 27;
                ME2Number = 28;
            }
            //Main Equiment 1
            for (int index = 5; index <= 10; index++)
            {
                if (compSaveArray[index] > 0)
                {
                    Dose ME1Dose = new Dose();
                    ME1Dose.Number = ME1Number.ToString();
                    ME1Dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, compSaveArray[index]).ToString();
                    ME1Dose.IsMainEquipment = "1";
                    ME1Dose.Point = (index - 4).ToString();
                    tunnelProductionData.dose.Add(ME1Dose);
                }
            }
            //Direct dosing pumps
            for (int index = 11; index <= 22; index++)
            {
                if (compSaveArray[index] > 0)
                {
                    Dose directDose = new Dose();
                    directDose.Number = pumpNumIndex.ToString();
                    directDose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, compSaveArray[index]).ToString();
                    directDose.IsMainEquipment = "0";
                    directDose.IsDirectDosing = "1";
                    tunnelProductionData.dose.Add(directDose);
                }
                pumpNumIndex++;
            }
            //Main Equipment 2
            for (int index = 23; index <= 28; index++)
            {
                if (compSaveArray[index] > 0)
                {
                    Dose ME2Dose = new Dose();
                    ME2Dose.Number = ME2Number.ToString();
                    ME2Dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, compSaveArray[index]).ToString();
                    ME2Dose.IsMainEquipment = "1";
                    ME2Dose.Point = (index - 22).ToString();
                    tunnelProductionData.dose.Add(ME2Dose);
                }
            }
            //pump-valve
            for (int index = 29; index <= 36; index++)
            {
                if (compSaveArray[index] > 0)
                {
                    Dose dose = new Dose();
                    dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, compSaveArray[index]).ToString();
                    dose.IsMainEquipment = "0";
                    dose.IsDirectDosing = "0";
                    dose.Point = (index - 28).ToString();
                    tunnelProductionData.dose.Add(dose);
                }
            }
        }
        private static void PopulateProdTunnelBatchParameters(MitsubishiController controller, int[] compSaveArray, ref TunnelData tunnelProductionData)
        {
            PopulateProdTunnelWaterConsumption(controller, compSaveArray, ref tunnelProductionData);

            PopulateProdTunnelTemperature(controller, compSaveArray, ref tunnelProductionData);

            PopulateProdTunnelpH(compSaveArray, ref tunnelProductionData);
        }
        private static void PopulateProdTunnelWaterConsumption(MitsubishiController controller, int[] compSaveArray, ref TunnelData tunnelProductionData)
        {
            tunnelProductionData.WaterConsumption = new List<WaterConsumption>();
            WaterConsumption wc1 = new WaterConsumption();
            WaterConsumption wc2 = new WaterConsumption();
            WaterConsumption wc3 = new WaterConsumption();
            wc1.Counter = "1";
            wc2.Counter = "2";
            wc2.Counter = "3";
            if (compSaveArray[37] > 0)
            {
                if (controller.RegionID == 1) //North America
                {
                    wc1.Value = compSaveArray[37].ToString();

                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    wc1.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, compSaveArray[37]).ToString();
                }
                tunnelProductionData.WaterConsumption.Add(wc1);
            }
            if (compSaveArray[38] > 0)
            {
                if (controller.RegionID == 1) //North America
                {
                    wc2.Value = compSaveArray[38].ToString();

                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    wc2.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, compSaveArray[38]).ToString();
                }
                tunnelProductionData.WaterConsumption.Add(wc2);
            }
            if (compSaveArray[39] > 0)
            {
                if (controller.RegionID == 1) //North America
                {
                    wc3.Value = compSaveArray[39].ToString();

                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    wc3.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, compSaveArray[39]).ToString();
                }
                tunnelProductionData.WaterConsumption.Add(wc3);
            }
        }
        private static void PopulateProdTunnelTemperature(MitsubishiController controller, int[] compSaveArray, ref TunnelData tunnelProductionData)
        {
            tunnelProductionData.temperature = new List<TemperatureData>();
            TemperatureData td1 = new TemperatureData();
            TemperatureData td2 = new TemperatureData();
            TemperatureData td3 = new TemperatureData();
            if (compSaveArray[42] > 0 || compSaveArray[43] > 0)
            {
                if (controller.RegionID == 1) //North America
                {
                    td1.Minimum = compSaveArray[42].ToString();
                    td1.Maximum = compSaveArray[43].ToString();
                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    td1.Minimum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, compSaveArray[42]).ToString();
                    td1.Maximum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, compSaveArray[43]).ToString();
                }
                td1.Status = compSaveArray[44].ToString();
                tunnelProductionData.temperature.Add(td1);
            }
            if (compSaveArray[45] > 0 || compSaveArray[46] > 0)
            {
                if (controller.RegionID == 1) //North America
                {
                    td2.Minimum = compSaveArray[45].ToString();
                    td2.Maximum = compSaveArray[46].ToString();
                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    td2.Minimum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, compSaveArray[45]).ToString();
                    td2.Maximum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, compSaveArray[46]).ToString();
                }
                td2.Status = compSaveArray[47].ToString();
                tunnelProductionData.temperature.Add(td2);
            }
            if (compSaveArray[48] > 0 || compSaveArray[49] > 0)
            {
                if (controller.RegionID == 1) //North America
                {
                    td3.Minimum = compSaveArray[48].ToString();
                    td3.Maximum = compSaveArray[49].ToString();
                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    td3.Minimum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, compSaveArray[48]).ToString();
                    td3.Maximum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, compSaveArray[49]).ToString();
                }
                td3.Status = compSaveArray[50].ToString();
                tunnelProductionData.temperature.Add(td3);
            }
        }
        /// <summary>
        /// Populates the product tunnelp h.
        /// </summary>
        /// <param name="compSaveArray">The comp save array.</param>
        /// <param name="tunnelProductionData">The tunnel production data.</param>
        private static void PopulateProdTunnelpH(int[] compSaveArray, ref TunnelData tunnelProductionData)
        {
            if (compSaveArray[71] > 0)
            {
                tunnelProductionData.Phvalue = compSaveArray[71].ToString();
                tunnelProductionData.Phstatus = compSaveArray[72].ToString();
                tunnelProductionData.Phcompartment = compSaveArray[73].ToString();
            }
        }
        private void ReadOnlineDataForWashers(MitsubishiController controller, int[] helm5Array, int maxWasherCount)
        {
            DataReader<MitsubishiTag> dataReader = objreader[controller.HostAdress];
            string onLineArrayAddress;
            string onLineStepArrayAddress;
            int temperatureOffset = 0;
            int PhOffset = 0;
            int waterConsumptionOffset = 0;
            int dosingOffsetStart = 0;
            int OnlineArrayTagLength = 0;
            int OnlineStepArrayTagLength = 0;
            string xmlString;
            if (maxWasherCount == 5)
            {
                onLineArrayAddress = "R4300";
                onLineStepArrayAddress = "R3630";
                temperatureOffset = 25;
                PhOffset = 170;
                waterConsumptionOffset = 205;
                dosingOffsetStart = 90;
                OnlineArrayTagLength = 15 * 5;
                OnlineStepArrayTagLength = 10 * 5;
            }
            else if (maxWasherCount == 10)
            {
                onLineArrayAddress = "R2300";
                onLineStepArrayAddress = "R3630";
                temperatureOffset = 40;
                PhOffset = 190;
                waterConsumptionOffset = 200;
                dosingOffsetStart = 50;
                OnlineArrayTagLength = 15 * 10;
                OnlineStepArrayTagLength = 10 * 10;
            }
            else
            {
                throw new ArgumentException("Invalid value for Max Operation Count");
            }
            MitsubishiTag OnlineArrayTag = new MitsubishiTag() { Address = onLineArrayAddress, TagItemType = UIInputType.TypeArray, ArrayLength = OnlineArrayTagLength };
            MitsubishiTag OnlineStepArrayTag = new MitsubishiTag() { Address = onLineStepArrayAddress, TagItemType = UIInputType.TypeArray, ArrayLength = OnlineStepArrayTagLength };
            IList<MitsubishiTag> onlineTags = new List<MitsubishiTag>() { OnlineArrayTag, OnlineStepArrayTag };
            onlineTags = dataReader.ReadTags(onlineTags);
            ConventionalWasherData washerData;
            DateTime StartDateTime;
            int offset;
            int dosingOffset;
            int dosingStep;
            int dosingQuantity;
            ConventionalDosingData dosingData;
            List<ConventionalDosingData> dosingDataList;
            for (int washerIndex = 1; washerIndex <= maxWasherCount; washerIndex++)
            {
                washerData = new ConventionalWasherData();
                offset = (washerIndex - 1) * 10;
                if (OnlineStepArrayTag.IntArrayData[offset + 6] > 0 && OnlineStepArrayTag.IntArrayData[offset + 1] > 0) //if (BatchNumber !=0) Process further
                {
                    washerData.StepNumber = OnlineStepArrayTag.IntArrayData[offset].ToString();
                    washerData.BatchNumber = OnlineStepArrayTag.IntArrayData[offset + 6].ToString();
                    washerData.TotalWashTime = OnlineStepArrayTag.IntArrayData[offset + 5].ToString();
                    washerData.StepDuration = OnlineStepArrayTag.IntArrayData[offset + 1].ToString();
                    offset = (washerIndex - 1) * 15;
                    washerData.MachineNumber = OnlineArrayTag.IntArrayData[offset].ToString();
                    washerData.RunTime = OnlineArrayTag.IntArrayData[offset + 12].ToString();
                    StartDateTime = DateTime.Now;
                    try
                    {
                        StartDateTime = new DateTime(OnlineArrayTag.IntArrayData[offset + 1] + 2000,//Year
                                                     OnlineArrayTag.IntArrayData[offset + 2],//Month
                                                     OnlineArrayTag.IntArrayData[offset + 3],//day
                                                     OnlineArrayTag.IntArrayData[offset + 4],//hour
                                                     OnlineArrayTag.IntArrayData[offset + 5],//minute
                                                     OnlineArrayTag.IntArrayData[offset + 6]);//hour
                    }
                    catch (Exception exp)
                    {
                        Log.Error("Start Date Time Convertion " + StartDateTime + exp.Message);
                        Log.Error(exp);
                    }
                    StartDateTime = TimeZoneInfo.ConvertTimeToUtc(StartDateTime);
                    washerData.StartDateTime = StartDateTime.ToString("MM/dd/yyyy HH:mm:ss", new System.Globalization.CultureInfo("en-US"));
                    if (controller.RegionID == 1) //North America
                    {
                        washerData.Load = OnlineArrayTag.IntArrayData[offset + 10].ToString();
                        washerData.NominalLoad = OnlineArrayTag.IntArrayData[offset + 11].ToString();
                    }
                    else if (controller.RegionID == 2) //Europe / Middle East / Africa
                    {
                        washerData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, OnlineArrayTag.IntArrayData[offset + 10]).ToString();
                        washerData.NominalLoad = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, OnlineArrayTag.IntArrayData[offset + 11]).ToString();
                    }
                    washerData.ProgramNumber = OnlineArrayTag.IntArrayData[offset + 8].ToString();
                    washerData.CustomerNumber = OnlineArrayTag.IntArrayData[offset + 9].ToString();
                    if (controller.RegionID == 1) //North America
                    {
                        washerData.TemperatureMax = helm5Array[temperatureOffset + washerIndex - 1].ToString();
                    }
                    else if (controller.RegionID == 2) //Europe / Middle East / Africa
                    {
                        washerData.TemperatureMax = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, helm5Array[temperatureOffset + washerIndex - 1]).ToString();
                    }
                    washerData.PHValue = (helm5Array[PhOffset + washerIndex - 1] * 10).ToString();
                    if (controller.RegionID == 1) //North America
                    {
                        washerData.WaterConsumption1 = helm5Array[waterConsumptionOffset + washerIndex - 1].ToString();
                    }
                    else if (controller.RegionID == 2) //Europe / Middle East / Africa
                    {
                        washerData.WaterConsumption1 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, helm5Array[waterConsumptionOffset + washerIndex - 1]).ToString();
                    }
                    dosingOffset = dosingOffsetStart + ((washerIndex - 1) * 14);
                    dosingDataList = new List<ConventionalDosingData>();
                    dosingStep = helm5Array[washerIndex - 1];
                    if (dosingStep > 0)
                    {
                        for (int index = dosingOffset; index <= dosingOffset + 13; index++)
                        {
                            dosingQuantity = helm5Array[index];
                            if (dosingQuantity == 0) continue;
                            dosingData = new ConventionalDosingData();
                            dosingData.stepNo = dosingStep.ToString();

                            if (index == dosingOffset)
                            {
                                dosingData.Equipment = "25";//Main Equipment 1
                                dosingData.isMainEquipment = "true";
                            }
                            else if (index == dosingOffset + 13)
                            {
                                dosingData.Equipment = "26";//Main Equipment 2
                                dosingData.isMainEquipment = "true";
                            }
                            else
                            {
                                dosingData.Equipment = (index - dosingOffset).ToString();
                                dosingData.isMainEquipment = "false";
                            }
                            if (controller.RegionID == 1) //North America
                            {
                                dosingData.Qty = dosingQuantity.ToString();
                            }
                            else if (controller.RegionID == 2) //Europe / Middle East / Africa
                            {
                                dosingData.Qty = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, dosingQuantity).ToString();
                            }
                            dosingDataList.Add(dosingData);
                        }
                        washerData.DosingData = dosingDataList;
                    }
                    int RedFlagShiftId = 0;
                    xmlString = SerializeXMLData(ConventionalXmlSerializer, washerData);
                    Log.InfoFormat("DataReaderAccess.ProcessPLCXLOnlineConventionalData - Call Start - Controller ID {0} {1} ", controller.ControllerId.ToString(), xmlString);
                    RedFlagShiftId = DataReaderAccess.ProcessPlcxlOnlineConventionalData(controller.ControllerId, xmlString, RedFlagShiftId);
                    Log.InfoFormat("DataReaderAccess.ProcessPLCXLOnlineConventionalData - Call End - Controller ID {0} ", controller.ControllerId.ToString());
                    if (RedFlagShiftId > 0)
                    {
                        DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                    }
                }
            }
        }
        private void ReadAlarmProdData(MitsubishiController controller)
        {
            int[] alarmSave = ReadArray(controller, D1260, 12);
            if (alarmSave[0] > 0)
            {
                
                plcxlAlaramData = GetAlarmNumber(alarmSave[0],controller.PLCType);
                DateTime startDateTime = new DateTime(2000, 1, 1);
                startDateTime = startDateTime.AddDays(alarmSave[1]);
                startDateTime = startDateTime.AddMinutes(alarmSave[2]);
                string strDateTime = startDateTime.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                plcxlAlaramData.StartDateTime = strDateTime;
                int washerNo = alarmSave[3];
                if (string.IsNullOrEmpty(plcxlAlaramData.MachineNumber) || plcxlAlaramData.MachineNumber == "0")
                {
                    if (washerNo !=0)
                        plcxlAlaramData.MachineNumber = washerNo.ToString();
                    plcxlAlaramData.IsTunnel = "0";
                    if (controller.PLCType == MitsubishiPLCType.PLCXL2Cbw)
                        plcxlAlaramData.IsTunnel = "1";
                    if (controller.PLCType == MitsubishiPLCType.PLCXL5W1C  && washerNo  > 0)
                    {
                          plcxlAlaramData.MachineNumber = (washerNo == 1 ? washerNo : washerNo - 1).ToString();
                          plcxlAlaramData.IsTunnel = washerNo == 1 ? "1" : "0";
                        
                    }

                }
                plcxlAlaramData.BatchNumber = alarmSave[4].ToString();
                plcxlAlaramData.ProgramNumber = alarmSave[5].ToString();
                plcxlAlaramData.DesiredValue = alarmSave[6].ToString();
                plcxlAlaramData.MeasuredValue = alarmSave[7].ToString();
                plcxlAlaramData.Status = alarmSave[8].ToString();
                DateTime stopDateTime = new DateTime(2000, 1, 1);
                stopDateTime = stopDateTime.AddDays(alarmSave[9]);
                stopDateTime = stopDateTime.AddMinutes(alarmSave[10]);
                string stpDateTime = stopDateTime.ToUniversalTime().ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                plcxlAlaramData.StopDateTime = stpDateTime;
                string xmlString = SerializeXMLData(AlarmDataSerializer, plcxlAlaramData);
                DataReaderAccess.ProcessPlcxlAlarmData(controller.ControllerId, xmlString);
                alarmSave[0] = 0;
                ResetProductionArray(controller, D1260);
            }
        }
        private string SerializeXMLData(XmlSerializer serilizer, object objectData)
        {
            StringWriter stringWriter = new StringWriter();
            using (XmlWriter xmlWriter = new XmlTextWriter(stringWriter))
            {
                serilizer.Serialize(xmlWriter, objectData);
                return stringWriter.ToString();
            }
        }
        #endregion
    }
}