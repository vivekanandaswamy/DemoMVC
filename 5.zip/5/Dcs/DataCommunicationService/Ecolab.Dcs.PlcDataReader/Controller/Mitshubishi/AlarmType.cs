﻿// -----------------------------------------------------------------------
// <copyright file="AlarmType.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The AlarmType </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Dcs.PlcDataReader
{
    /// <summary>
    /// Enum for AlarmType
    /// </summary>
    public enum AlarmType
    {
        GeneralAlarm=1,
        MachineAlarm=2,
        PumpAlarm=3,
        ProbeAlarm=4,
        GroupAlarm=5
    }
}
