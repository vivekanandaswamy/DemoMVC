﻿// -----------------------------------------------------------------------
// <copyright file="EControlPlusService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>EControlPlus Service class</summary>
// -----------------------------------------------------------------------

using Ecolab.Dcs.CollectData.Mitsubishi;
using Entities.DataReader;
using Controller = Ecolab.Dcs.Entities.Controller;
using Timer = System.Timers.Timer;
using Washer = Ecolab.Dcs.Entities.Washer;

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Timers;
    using System.Xml;
    using System.Xml.Serialization;
    using Access.DataReader;
    using Ecolab.Dcs.CollectData;
    using Ecolab.Dcs.CollectData.Beckhoff;
    using Entities;
    using log4net;
    using Properties;
    using Controller = Controller;
    using Timer = Timer;
    using Washer = Washer;

    public class EControlPlusService
    {
        #region Varaibles
        private const string EControlPlusServiceLogFile = "EControlPlusServiceLog";
        private static readonly ILog Log = LogManager.GetLogger(EControlPlusServiceLogFile);
        private List<MitsubishiController> mControllers;
        object locker = new object();
        ManualResetEvent timerDead = new ManualResetEvent(false);
        private bool ServiceStopping;
        private Timer intervalTimer;
        readonly ProcessRollup processRollup = new ProcessRollup();
        IDictionary<int, DataReader<MitsubishiTag>> dataReaders;
        IDictionary<int, DataWriter<MitsubishiTag>> dataWriters;
        int[] onLineArray;//  '   WE & CBW OnLine informations
        int[] dosingArray;//'dosing CBW & WE1..6; P1..8+ME
        int[] compartmentDosingArray; //'Compartment Dospoint1-4 / ProductP1-8+ME
        int transferSignal; //'Run & Transfer Signal
        int[] OnLineCbwArray;////OnLineCbw[25,20]
        int[] OnlineCbwBatchesArray;
        int[] WasherDosingArray;
        int[] washerOnlineDateTimeArray;
        int[] washerOnlineBatchNoArray;
        int[] pHAndTempArray;
        private CancellationTokenSource mCancellationTokenSource;
        private static readonly string mWhileLoopStarted = "Econtrol Plus Read While Loop started....";
        private static readonly string mServiceShutdown = "Service ShutDown. Rerturning From Econtrol Plus While loop";
        #endregion
        #region Constants - Addresses and pointers
        //Address
        const string StorePointer = "D500";
        const string StorePointerR = "D501";
        const string StoreProdData = "R11160";
        //Size
        const int SizeStorePointer = 16;
        const int SizeStorePointerR = 16;
        const int SizeStoreProdData = 80;
        readonly XmlSerializer ListConventionalXmlSerializer = new XmlSerializer(typeof(List<ConventionalWasherData>));
        readonly XmlSerializer ConventionalXmlSerializer = new XmlSerializer(typeof(ConventionalWasherData));
        readonly XmlSerializer TunnelSerializer = new XmlSerializer(typeof(MyControlTunnel), new XmlRootAttribute("MyControlTunnel"));
        readonly XmlSerializer AlarmDataserializer = new XmlSerializer(typeof(List<MyControlAlarmData>));
        #endregion
        #region Methods
        private void ReadContinuous()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            while (true)
            {
                Log.Info(mWhileLoopStarted);
                try
                {
                    if (mCancellationTokenSource.IsCancellationRequested)
                    {
                        Log.Info(mServiceShutdown);
                        return;
                    }
                    foreach (MitsubishiController controller in mControllers)
                    {
                        InitializePlcContinuousRead(controller);
                    }
                    Thread.Sleep(Int32.Parse(Settings.Default.EControlPlusReadInterval));
                    GetControllers();
                }
                catch (Exception ex)
                {
                    if (typeof(ThreadAbortException) == ex.GetType())
                    {
                        Thread.ResetAbort();
                    }

                    throw ex;
                }
            }
        }
        private void CreatePLCReadThread()
        {
            try
            {
                Thread t = new Thread(ReadContinuous);
                GetControllers();
                t.SetApartmentState(ApartmentState.STA);
                t.Start();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to run Data Communcation Service", ex);
            }
        }
        public EControlPlusService(CancellationTokenSource cancellationTokenSource)
        {
            mCancellationTokenSource = cancellationTokenSource;
            CreatePLCReadThread();
        }
        private void GetControllers()
        {
            try
            {
                IEnumerable<global::Entities.DataReader.Controller> dbControllers = DataReaderAccess.GetActiveControllers();
                int[] EcontrolPlusCntrlTypes = new int[2]
                {
                    Convert.ToInt32(ControllerType.EightWashers),
                    Convert.ToInt32(ControllerType.SixWashersOneTunnel)
                };
                dbControllers = dbControllers.Where(c => EcontrolPlusCntrlTypes.Contains(c.ControllerTypeId)).ToList();
                // ControllerTypeId = 6 (8 Washers), 7 (1 Tunnel 6 Washers), ControllerModelId = 8 (EcontrolPlus)
                List<Controller> controllers = dbControllers.Select(EntityConverter.Convert).ToList();
                mControllers = controllers.FindAll(c => c is MitsubishiController).Select(c => (MitsubishiController)c).ToList();
                //Log.InfoFormat("Started Tracking EControlPlus {0} controller(s)", mControllers.Count);
                dataReaders = new Dictionary<int, DataReader<MitsubishiTag>>();
                dataWriters = new Dictionary<int, DataWriter<MitsubishiTag>>();
                foreach (MitsubishiController controller in mControllers)
                {
                    dataReaders.Add(controller.ControllerId, MitsubishiFactory.GetDataReader(controller));
                    dataWriters.Add(controller.ControllerId, MitsubishiFactory.GetDataWriter(controller));
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error occured in GetControllers() method: " + ex.Message);
            }
        }
        public void Start()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            foreach (MitsubishiController controller in mControllers)
            {
                InitializePlcContinuousRead(controller);
            }
        }
        public void Stop()
        {
            try
            {
                ServiceStopping = true;
                timerDead.WaitOne();
                intervalTimer.Stop();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to stop Data Communcation Service", ex);
            }
            finally
            {
                Log.InfoFormat("{0}: Service has been stopped.", "Data Communication Service");
            }
        }
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {
                timerDead.Reset();
                GetControllers();
                Start();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to run Data Communcation Service", ex);
            }
            finally
            {
                lock (locker)
                {
                    timerDead.Set(); // allow service to stop
                    Log.Info("Signal set to indicate elapsed event to continue");
                }
                if (!ServiceStopping)	// restart the timer
                    intervalTimer.Start();
            }
        }
        private void ReadOnlineTags(MitsubishiController controller)
        {
            try
            {
                MitsubishiTag onLineTag = new MitsubishiTag() { Address = "D10", TagItemType = UIInputType.TypeArray, ArrayLength = 107 };  //Reading Dosing Steps,Program numbers,Loads,Customer Numbers for Washers 1-8 and tunnel
                MitsubishiTag dosingTag = new MitsubishiTag() { Address = "D163", TagItemType = UIInputType.TypeArray, ArrayLength = 80 };  //Reading Batch numbers for Washers 1-8 and tunnel
                MitsubishiTag WasherDosingTag = new MitsubishiTag() { Address = "D203", TagItemType = UIInputType.TypeArray, ArrayLength = 60 };
                MitsubishiTag compartmentDosingTag = new MitsubishiTag() { Address = "D273", TagItemType = UIInputType.TypeArray, ArrayLength = 40 };
                MitsubishiTag transferSignalTag = new MitsubishiTag() { Address = "M240", TagItemType = UIInputType.TypeInt };
                MitsubishiTag onLineCBWTag = new MitsubishiTag() { Address = "R3760", TagItemType = UIInputType.TypeArray, ArrayLength = 500 };
                MitsubishiTag CBWBatchTag = new MitsubishiTag() { Address = "D6270", TagItemType = UIInputType.TypeArray, ArrayLength = 500 };
                MitsubishiTag washerOnlineDateTimeTag = new MitsubishiTag() { Address = "D484", TagItemType = UIInputType.TypeArray, ArrayLength = 16 }; //Reading Start date and start time for Washers 1-8
                MitsubishiTag washerOnlineBatchNoTag = new MitsubishiTag() { Address = "D6303", TagItemType = UIInputType.TypeArray, ArrayLength = 8 };  //Reading Batch numbers for Washers 1-8
                IList<MitsubishiTag> onlineTags = new List<MitsubishiTag>() { onLineTag, dosingTag, compartmentDosingTag, transferSignalTag, onLineCBWTag, CBWBatchTag, WasherDosingTag, washerOnlineDateTimeTag, washerOnlineBatchNoTag };//, pHAndTempTag };
                DataReader<MitsubishiTag> dataReader = dataReaders[controller.ControllerId];
                onlineTags = dataReader.ReadTagsExt(onlineTags);
                onLineArray = onLineTag.IntArrayData;
                dosingArray = dosingTag.IntArrayData;
                compartmentDosingArray = compartmentDosingTag.IntArrayData;
                transferSignal = int.Parse(transferSignalTag.Value);
                OnLineCbwArray = onLineCBWTag.IntArrayData;
                OnlineCbwBatchesArray = CBWBatchTag.IntArrayData;
                WasherDosingArray = WasherDosingTag.IntArrayData;
                washerOnlineDateTimeArray = washerOnlineDateTimeTag.IntArrayData;
                washerOnlineBatchNoArray = washerOnlineBatchNoTag.IntArrayData;
            }
            catch (Exception ex)
            {
                Log.Error("Error Occured while reading address from EControl+ Device", ex);
            }
        }
        public void InitializePlcContinuousRead(MitsubishiController controller)
       {
            ReadOnlineTags(controller);
            //Implementing conventinal online data
            if (controller.PLCType == MitsubishiPLCType.EControlPlus8W)
            {
                try
                {
                    ReadOnlineDataForWashers(controller, 8);            //8Washers.
                }
                catch (Exception ex)
                {

                    Log.Error("Error occured:ReadOnlineDataForWashers in econtrolplus for 8W:", ex);
                }
                try
                {
                    ProcessEControlPlusProdDataFor8W(controller);
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured:ReadProductionDataForWashers in econtrolplus for 8W:", ex);
                }
            }
            else if (controller.PLCType == MitsubishiPLCType.EControlPlus6W1T)
            {
                //Implement online and production data read functionality
                try
                {
                    ReadOnlineDataForWashers(controller, 6);             //6Washers.
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured:ReadOnlineDataForWashers in econtrolplus for 6W1T:", ex);
                }
                try
                {
                    ReadOnlineDataForTunnels(controller);               //1Tunnel.
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured:ReadOnlineDataForTunnels in econtrolplus for 6W1T:", ex);
                }
                try
                {
                    ProcessEControlPlusProdDataFor6W1T(controller);      //
                }
                catch (Exception ex)
                {

                    Log.Error("Error occured:ProcessEControlPlusProdDataFor6W1T in econtrolplus for 6W1T:", ex);
                }
            }
            try
            {
                ProcessAlarmData(controller);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured:ProcessAlarmData", ex);
            }
            try
            {
                processRollup.Rollup();
            }
            catch (Exception ex)
            {
                Log.Error("Error occured:processRollup: EControl Plus: Controller ID:" + controller.ControllerId, ex);
            }
        }
        private void ProcessAlarmData(MitsubishiController controller)
        {
            MitsubishiTag digitalAlarms = new MitsubishiTag() { Address = "M208", TagItemType = UIInputType.TypeArray, ArrayLength = 1 };
            MitsubishiTag analogAlarms = new MitsubishiTag() { Address = "M800", TagItemType = UIInputType.TypeArray, ArrayLength = 6 };
            MitsubishiTag analogAlarmDetail1 = new MitsubishiTag() { Address = "R8000", TagItemType = UIInputType.TypeArray, ArrayLength = 108 };
            MitsubishiTag analogAlarmDetail2 = new MitsubishiTag() { Address = "R8120", TagItemType = UIInputType.TypeArray, ArrayLength = 60 };
            MitsubishiTag digitalAlarmDetail1 = new MitsubishiTag() { Address = "D502", TagItemType = UIInputType.TypeArray, ArrayLength = 5 };
            MitsubishiTag digitalAlarmDetail2 = new MitsubishiTag() { Address = "D6095", TagItemType = UIInputType.TypeArray, ArrayLength = 11 };
            IList<MitsubishiTag> alarmTags = new List<MitsubishiTag>() { digitalAlarms, analogAlarms, analogAlarmDetail1, analogAlarmDetail2, digitalAlarmDetail1, digitalAlarmDetail2 };
            DataReader<MitsubishiTag> dataReader = dataReaders[controller.ControllerId];
            alarmTags = dataReader.ReadTagsExt(alarmTags);
            List<bool[]> alarmSettings;
            alarmSettings = GetAlarmStatus(analogAlarms.IntArrayData);
            alarmSettings.AddRange(GetAlarmStatus(digitalAlarms.IntArrayData));
            List<MyControlAlarmData> currentAlarmList = new List<MyControlAlarmData>();
            ProcessFlowMeterAlarms(controller.PLCType, alarmSettings[6], currentAlarmList, digitalAlarmDetail1.IntArrayData, digitalAlarmDetail2.IntArrayData);
            ProcessOtherDigitalAlarms(alarmSettings[6], currentAlarmList, digitalAlarmDetail2.IntArrayData);
            ProcessAlarmsInM800(controller.PLCType, alarmSettings[0], currentAlarmList, digitalAlarmDetail2.IntArrayData);
            ProcessAlarmsInM816(controller.PLCType, alarmSettings[1], currentAlarmList, digitalAlarmDetail2.IntArrayData);
            ProcessAlarmsInM832(alarmSettings[2], currentAlarmList);
            ProcessAlarmsInM848(controller.PLCType, alarmSettings[3], currentAlarmList, analogAlarmDetail1.IntArrayData);
            ProcessAlarmsInM864(controller.PLCType, alarmSettings[4], currentAlarmList, analogAlarmDetail1.IntArrayData, analogAlarmDetail2.IntArrayData, digitalAlarmDetail1.IntArrayData[0]);
            ProcessAlarmsInM880(controller.PLCType, alarmSettings[5], currentAlarmList, analogAlarmDetail2.IntArrayData, digitalAlarmDetail1.IntArrayData[0]);
            string xmlAlarmData = SerializeXMLData(AlarmDataserializer, currentAlarmList);
            Log.Info("Econtrol Plus  Alarm---");
            Log.Info(xmlAlarmData);
            DataReaderAccess.ProcessEcontrolPlusAlarmData(controller.ControllerId, xmlAlarmData);
        }
        private void ProcessFlowMeterAlarms1(List<MyControlAlarmData> currentAlarmList)
        {
            MyControlAlarmData myControlAlarmData;
            for (int i = 1; i < 11; i++)
            {
                myControlAlarmData = new MyControlAlarmData();
                myControlAlarmData.MachineNumber = i.ToString();
                myControlAlarmData.AlarmNumber = i.ToString();
                myControlAlarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                myControlAlarmData.MachineNumber = i.ToString();
                myControlAlarmData.BatchNumber = i.ToString();
                myControlAlarmData.ProgramNumber = i.ToString();
                myControlAlarmData.DesiredValue = i.ToString();
                myControlAlarmData.MeasuredValue = i.ToString();
                myControlAlarmData.Status = i.ToString();
                myControlAlarmData.StopDateTime = i.ToString();
                myControlAlarmData.IsTunnel = 1.ToString();
                myControlAlarmData.AlarmType = i.ToString();
                myControlAlarmData.PumpNbr = i.ToString();
                myControlAlarmData.ValveNbr = i.ToString();
                currentAlarmList.Add(myControlAlarmData);
            }
        }
        private void ProcessAlarmsInM880(MitsubishiPLCType plcType, bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList, int[] analogAlarmDetail2, int programNumber)
        {
            ///Process alarms betweeN bitData - 208 and 223
            MyControlAlarmData alarmData;
            int offset = 0;
            int programAlarmID = 130;
            int washerId = 5;
            int washerIDForTemperatureAlarm = 1;
            //Indexes to be skipped for EControlPlus6W1T
            int[] skipIndexes = new int[] { 3, 4, 5, 6, 13, 14 };
            Log.Info("Econtrol Plus - ProcessAlarmsInM880 ");
            for (int index = 0; index < 16; index++)
            {
                if (skipIndexes.Contains(index) && plcType == MitsubishiPLCType.EControlPlus6W1T) continue;
                if (plcType == MitsubishiPLCType.EControlPlus8W && index == 15) continue;
                programAlarmID++;
                if (index % 2 != 0)
                {
                    washerId++;
                }
                if (alarmSettings[index])
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    currentAlarmList.Add(alarmData);
                    if (index < 7) //Washer X(5-8) Program not finished, Washer X(6-8) No valid program
                    {
                        alarmData.MachineNumber = washerId.ToString();
                        alarmData.IsTunnel = "0";
                        alarmData.AlarmNumber = programAlarmID.ToString();
                        alarmData.AlarmType = "2";
                        if (index % 2 == 0)
                        {
                            alarmData.ProgramNumber = programNumber.ToString();
                        }

                    }
                    else if (index < 16)//Temperature too low Washer X(1-8),Temperature to low 2 Cbw
                    {
                        if (index == 15)
                        {
                            alarmData.AlarmNumber = "153";
                            offset = 54;
                            alarmData.Probe = "2";
                            alarmData.AlarmType = "4";
                            alarmData.MachineNumber = "1";
                            alarmData.IsTunnel = "1";
                        }
                        else
                        {
                            alarmData.AlarmNumber = "404";
                            alarmData.AlarmType = "2";
                            alarmData.IsTunnel = "0";
                            offset = (index - 7) * 6;
                            alarmData.MachineNumber = washerIDForTemperatureAlarm.ToString();
                            washerIDForTemperatureAlarm++;
                        }
                        alarmData.ProgramNumber = analogAlarmDetail2[offset + 1].ToString();
                        alarmData.BatchNumber = analogAlarmDetail2[offset + 2].ToString();
                        alarmData.DesiredValue = analogAlarmDetail2[offset + 3].ToString();
                        alarmData.MeasuredValue = analogAlarmDetail2[offset + 4].ToString();
                        alarmData.Status = analogAlarmDetail2[offset + 5].ToString();
                    }
                }
            }
        }
        private void ProcessAlarmsInM864(MitsubishiPLCType plcType, bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList, int[] analogAlarmDetail1, int[] analogAlarmDetail2, int programNumber)
        {
            ///Process alarms betweeN bitData -  192 and 207
            MyControlAlarmData alarmData;
            int offset = 0;
            int[] analogDetail;
            Log.Info("Econtrol Plus - ProcessAlarmsInM864 ");
            //PH too High alarm for Washer 8,
            //pH too low Cbw,pH too high Cbw, Conductivity too low Cbw
            //Conductivity too high Cbw,Temperature too low 1 Cbw
            int[] alarmNumbers = new int[] { 158, 400, 401, 402, 403, 153 };
            int[] offsetValues = new int[] { 48 + 7 * 6, 96, 102, 96, 102, 48 };
            int programAlarmID = 121;
            int washerId = 1;
            for (int index = 0; index < 16; index++)
            {
                //for 6W1T skip Alarm pH too high Washer 8
                if (index == 0 && plcType == MitsubishiPLCType.EControlPlus6W1T) continue;
                //Skip CBW alarms for EControlPlus8W 
                if (plcType == MitsubishiPLCType.EControlPlus8W && index > 0 && index < 6) continue;
                //Skip M870 bitData - 198
                if (index == 6) continue;
                if (index > 6) programAlarmID++;
                analogDetail = analogAlarmDetail1;
                if (alarmSettings[index])
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.IsTunnel = "0";
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    currentAlarmList.Add(alarmData);
                    if (index < 6)
                    {
                        alarmData.MachineNumber = "1";
                        alarmData.AlarmType = "2";
                        if (index == 0)
                        {
                            alarmData.MachineNumber = "8";
                        }
                        if (index == 5)
                        {
                            alarmData.Probe = "1";
                            analogDetail = analogAlarmDetail2;
                            alarmData.IsTunnel = "1";
                            alarmData.AlarmType = "4";
                        }
                        alarmData.AlarmNumber = alarmNumbers[index].ToString();
                        offset = offsetValues[index];
                        alarmData.ProgramNumber = analogDetail[offset + 1].ToString();
                        alarmData.BatchNumber = analogDetail[offset + 2].ToString();
                        alarmData.DesiredValue = analogDetail[offset + 3].ToString();
                        alarmData.MeasuredValue = analogDetail[offset + 4].ToString();
                        alarmData.Status = analogDetail[offset + 5].ToString();
                    }
                    else if (index > 6)
                    {
                        alarmData.MachineNumber = washerId.ToString();
                        alarmData.AlarmNumber = programAlarmID.ToString();
                        alarmData.AlarmType = "2";
                        if (index % 2 == 0)
                        {
                            alarmData.ProgramNumber = programNumber.ToString();
                            washerId++;
                        }
                    }
                }
            }
        }
        private void ProcessAlarmsInM848(MitsubishiPLCType plcType, bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList, int[] analogAlarmDetail1)
        {
            MyControlAlarmData alarmData;
            int offset;
            int washerId;
            Log.Info("Econtrol Plus - ProcessAlarmsInM848 ");
            for (int index = 1; index < 16; index++)
            {
                //skip Washers 7,8 for 6W1T
                if (plcType == MitsubishiPLCType.EControlPlus6W1T && (index == 7 || index == 8 || index == 15))
                    continue;
                if (alarmSettings[index])
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.IsTunnel = "0";
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    currentAlarmList.Add(alarmData);
                    if (index < 9)//PH too Low alarm for Washers 1 to 8
                    {
                        alarmData.AlarmNumber = "157";
                        alarmData.AlarmType = "2";
                        washerId = index;
                        alarmData.MachineNumber = washerId.ToString();
                        offset = (index - 1) * 6;
                    }
                    else //PH too high for washer 1 to 7
                    {
                        alarmData.AlarmNumber = "158";
                        alarmData.AlarmType = "2";
                        washerId = index - 8;
                        alarmData.MachineNumber = washerId.ToString();
                        offset = 48 + (index - 9) * 6;
                    }
                    alarmData.ProgramNumber = analogAlarmDetail1[offset + 1].ToString();
                    alarmData.BatchNumber = analogAlarmDetail1[offset + 2].ToString();
                    alarmData.DesiredValue = analogAlarmDetail1[offset + 3].ToString();
                    alarmData.MeasuredValue = analogAlarmDetail1[offset + 4].ToString();
                    alarmData.Status = analogAlarmDetail1[offset + 5].ToString();
                }
            }
        }
        private void ProcessAlarmsInM832(bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList)
        {

            MyControlAlarmData alarmData;
            Log.Info("Econtrol Plus - ProcessAlarmsInM832 ");
            for (int index = 0; index < 16; index++)
            {
                if (index == 1 || index == 6 || index == 7 || index == 10 || index == 15) continue;
                if (alarmSettings[index])
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    currentAlarmList.Add(alarmData);
                    if (index <= 5)//ME 1 Alarms
                    {
                        //Main equipment 1 - Pump / agitator fuse off - 105
                        //Main equipment 1 - Water pressure alarm - 106
                        //Main equipment 1 - Overflow alarm  -107
                        //Main equipment 1 - Empty alarm -- 108
                        //Main equipment 1 - Need to fill -- 109
                        alarmData.AlarmNumber = (105 + index).ToString();
                        alarmData.AlarmType = "3";
                        alarmData.PumpNbr = "9"; //ME 1 
                    }
                    else if (index > 5 && index < 15)
                    {
                        //Main equipment 2 - Pump / agitator fuse off - 105
                        //Main equipment 2 - Water pressure alarm - 106
                        //Main equipment 2 - Overflow alarm  -107
                        //Main equipment 2 - Empty alarm -- 108
                        //Main equipment 2 - Need to fill -- 109
                        alarmData.AlarmNumber = (104 + index - 8).ToString();
                        alarmData.AlarmType = "3";
                        alarmData.PumpNbr = "10"; //ME 2
                        alarmData.AlarmType = "3";
                    }
                }
            }
        }
        private void ProcessAlarmsInM816(MitsubishiPLCType plcType, bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList, int[] digitalAlarmDetailArray2)
        {

            MyControlAlarmData alarmData;
            Log.Info("Econtrol Plus - ProcessAlarmsInM816 ");
            for (int index = 0; index < 16; index++)
            {
                if (index == 5 || index == 14) continue;
                //skip Washer 8 for 6W1T
                if (plcType == MitsubishiPLCType.EControlPlus6W1T && index == 13) continue;
                if (alarmSettings[index])
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    currentAlarmList.Add(alarmData);
                    if (index < 5)
                    {
                        alarmData.AlarmNumber = "156";// Flowswicth
                        alarmData.AlarmType = "3";
                        if (digitalAlarmDetailArray2[0] > 0)
                        {
                            if (plcType == MitsubishiPLCType.EControlPlus6W1T)
                            {
                                alarmData.MachineNumber = (digitalAlarmDetailArray2[0] == 1 ? 1 : digitalAlarmDetailArray2[0] - 1).ToString();
                                alarmData.IsTunnel = digitalAlarmDetailArray2[0] == 1 ? "1" : "0";
                            }
                            else
                            {
                                alarmData.MachineNumber = digitalAlarmDetailArray2[0].ToString();
                                alarmData.IsTunnel = "0";
                            }
                        }
                        alarmData.ProgramNumber = digitalAlarmDetailArray2[8].ToString();
                        alarmData.BatchNumber = digitalAlarmDetailArray2[9].ToString();
                        alarmData.ValveNbr = digitalAlarmDetailArray2[10].ToString();
                        if (index == 4) alarmData.PumpNbr = "10";
                        else alarmData.PumpNbr = (index + 5).ToString();
                    }
                    else if (index > 5 && index < 14)//TOM signal alarm Washer
                    {
                        alarmData.AlarmNumber = (166 + index - 6).ToString();
                        alarmData.AlarmType = "2";
                        alarmData.MachineNumber = (index - 5).ToString();
                        alarmData.IsTunnel = "0";
                        if (plcType == MitsubishiPLCType.EControlPlus6W1T && index == 12)
                        {
                            //12 --TOM signal alarm Washer 7 / CBW
                            alarmData.AlarmNumber = "174";
                            alarmData.MachineNumber = "1";
                            alarmData.IsTunnel = "1";
                        }
                    }
                    else if (index == 15) //Main equipment 1 - Main switch off
                    {
                        alarmData.AlarmNumber = "104";
                        alarmData.PumpNbr = "9";
                        alarmData.AlarmType = "3";
                    }
                }
            }
        }
        private void ProcessAlarmsInM800(MitsubishiPLCType plcType, bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList, int[] digitalAlarmDetailArray2)
        {
            MyControlAlarmData alarmData;
            Log.Info("Econtrol Plus - ProcessAlarmsInM800 ");
            for (int index = 0; index < 16; index++)
            {
                if (alarmSettings[index])
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    currentAlarmList.Add(alarmData);
                    if (index == 0)
                    {
                        alarmData.AlarmNumber = "143";//Flush alarm
                        alarmData.AlarmType = "1";
                    }
                    else if (index > 0 && index < 11)
                    {
                        alarmData.AlarmNumber = "103";//Empty alarm
                        alarmData.AlarmType = "3";
                        alarmData.PumpNbr = index.ToString();
                    }
                    else
                    {
                        alarmData.AlarmNumber = "156";//' Flowswitch
                        alarmData.AlarmType = "3";
                        if (digitalAlarmDetailArray2[0] > 0)
                        {
                            if (plcType == MitsubishiPLCType.EControlPlus6W1T)
                            {
                                alarmData.MachineNumber = (digitalAlarmDetailArray2[0] == 1 ? 1 : digitalAlarmDetailArray2[0] - 1).ToString();
                                alarmData.IsTunnel = digitalAlarmDetailArray2[0] == 1 ? "1" : "0";
                            }
                            else
                            {
                                alarmData.MachineNumber = digitalAlarmDetailArray2[0].ToString();
                                alarmData.IsTunnel = "0";
                            }
                        }
                        alarmData.ProgramNumber = digitalAlarmDetailArray2[8].ToString();
                        alarmData.BatchNumber = digitalAlarmDetailArray2[9].ToString();
                        alarmData.ValveNbr = digitalAlarmDetailArray2[10].ToString();
                        if (index == 11) alarmData.PumpNbr = "9";
                        else alarmData.PumpNbr = (index - 11).ToString();
                    }
                }

            }
        }
        private void ProcessOtherDigitalAlarms(bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList, int[] digitalAlarmDetailArray2)
        {
            MyControlAlarmData alarmData;
            Log.Info("Econtrol Plus - ProcessOtherDigitalAlarms ");
            //Connex Alarm,Flush leak alarm,Dosing stop / Air pressure alarm,
            //CF Card alarm, CF card operation error
            int[] alarmCode = new int[] { 163, 164, 120, 175, 176 };
            for (int index = 0; index < 5; index++)
            {
                if (alarmSettings[index + 11])
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.AlarmType = "1";
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    alarmData.AlarmNumber = alarmCode[index].ToString();
                    if (alarmCode[index] == 175 || alarmCode[index] == 176)
                    {
                        alarmData.CFErrorCode = digitalAlarmDetailArray2[5].ToString();
                        alarmData.CFErrorDetail = digitalAlarmDetailArray2[6].ToString();
                    }
                    currentAlarmList.Add(alarmData);
                }
            }
        }
        private void ProcessFlowMeterAlarms(MitsubishiPLCType plcType, bool[] alarmSettings, List<MyControlAlarmData> currentAlarmList, int[] digitalAlarmArray1, int[] digitalAlarmArray2)
        {
            MyControlAlarmData alarmData;
            Log.Info("Econtrol Plus - ProcessFlowMeterAlarms ");
            for (int i = 0; i < 10; i++)
            {
                if (alarmSettings[i]) //Maximum time (Flowmeter) alarm is on
                {
                    alarmData = new MyControlAlarmData();
                    alarmData.AlarmNumber = "101";
                    if (i == 0) alarmData.PumpNbr = "9";//ME1
                    else if (i == 9) alarmData.PumpNbr = "10";//ME2
                    else alarmData.PumpNbr = i.ToString();//Pump
                    alarmData.StartDateTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss.fff", new System.Globalization.CultureInfo("en-US"));
                    alarmData.MeasuredValue = digitalAlarmArray1[3].ToString();
                    alarmData.DesiredValue = digitalAlarmArray1[2].ToString();
                    alarmData.ProgramNumber = digitalAlarmArray2[2].ToString();
                    alarmData.BatchNumber = digitalAlarmArray2[3].ToString();
                    alarmData.ValveNbr = digitalAlarmArray2[4].ToString();
                    if (digitalAlarmArray2[1] > 0)
                    {
                        if (plcType == MitsubishiPLCType.EControlPlus6W1T)
                        {
                            alarmData.MachineNumber = (digitalAlarmArray2[1] == 1 ? 1 : digitalAlarmArray2[1] - 1).ToString();
                            alarmData.IsTunnel = digitalAlarmArray2[1] == 1 ? "1" : "0";
                            alarmData.AlarmType = "3";
                        }
                        else
                        {
                            alarmData.MachineNumber = digitalAlarmArray2[1].ToString();
                            alarmData.IsTunnel = "0";
                            alarmData.AlarmType = "3";
                        }
                    }
                    currentAlarmList.Add(alarmData);
                }
            }
        }
        private List<bool[]> GetAlarmStatus(int[] alarmIntValues)
        {
            BitArray bitArray;
            int[] intValues = new int[] { 0 };
            bool[] bitSettings;
            List<bool[]> alarmList = new List<bool[]>();
            foreach (int intValue in alarmIntValues)
            {
                intValues[0] = intValue;
                bitArray = new BitArray(intValues);
                bitSettings = new bool[32];
                bitArray.CopyTo(bitSettings, 0);
                alarmList.Add(bitSettings);
            }
            return alarmList;
        }
        private void ReadOnlineDataForWashers(MitsubishiController controller, int maxWasherCount)
        {
            int offset = 0;
            int dateTimeoffset = 0;
            int RedFlagShiftId = 0;
            int dosingOffset;
            int checkPhOrTemp;
            ConventionalWasherData washerData;
            List<ConventionalWasherData> listWasherData;
            List<ConventionalDosingData> dosingDataList;
            ConventionalDosingData dosingData;
            DataReader<MitsubishiTag> dataReader = dataReaders[controller.ControllerId];
            if (onLineArray == null)
                return;
            listWasherData = new List<ConventionalWasherData>();
            for (int washerIndex = 1; washerIndex <= maxWasherCount; washerIndex++)
            {
                //storing washerData and ConventionalDosingData of washer
                washerData = new ConventionalWasherData();
                washerData.StepNumber = onLineArray[offset].ToString();
                washerData.MachineNumber = washerIndex.ToString();
                washerData.ProgramNumber = onLineArray[offset + 8].ToString();

                if (controller.RegionID == 1) //North America
                {
                    washerData.Load = onLineArray[offset + 16].ToString();
                }
                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                {
                    if (onLineArray[offset + 16] > 0)
                        washerData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, onLineArray[offset + 16]).ToString();
                }
                washerData.CustomerNumber = onLineArray[offset + 24].ToString();
                washerData.BatchNumber = washerOnlineBatchNoArray[offset].ToString();
                if (washerOnlineDateTimeArray[dateTimeoffset] > 0)
                    washerData.StartDateTime = ConvertPlcDateTime((ushort)washerOnlineDateTimeArray[dateTimeoffset], (ushort)washerOnlineDateTimeArray[dateTimeoffset + 1]);
                MitsubishiTag pHAndTempTag = new MitsubishiTag() { Address = "D6517", TagItemType = UIInputType.TypeArray, ArrayLength = 10 };  //Reading pH and Temp for Washers and tunnel 1-8
                IList<MitsubishiTag> ArrayTags = new List<MitsubishiTag>() { pHAndTempTag };
                DataReader<MitsubishiTag> dataReaderpHTemp = dataReaders[controller.ControllerId];
                ArrayTags = dataReaderpHTemp.ReadTagsExt(ArrayTags);
                pHAndTempArray = pHAndTempTag.IntArrayData;
                checkPhOrTemp = pHAndTempArray[offset];
                if (checkPhOrTemp > 0)
                {
                    string findDigit = Convert.ToString(checkPhOrTemp);
                    if (findDigit.Length >= 1)
                    {
                        if (Convert.ToInt32(findDigit[0]) == 49)         //If first digit is 1 it is pH and Ascii value of 1 - 49
                        {
                            washerData.PHValue = (checkPhOrTemp % 1000).ToString();
                        }
                        else if (Convert.ToInt32(findDigit[0]) == 50)    //If first digit is 2 it is Temperature and Ascii value of 2 - 50
                        {
                            if (controller.RegionID == 1)  //North America
                            {
                                washerData.TemperatureMax = (checkPhOrTemp % 1000).ToString();
                            }
                            else if (controller.RegionID == 2) //Europe / Middle East / Africa
                            {
                                if (checkPhOrTemp % 1000 > 0)
                                    washerData.TemperatureMax = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, checkPhOrTemp % 1000));
                            }
                        }
                    }
                }
                //Reading dosing detailsfrom plcand inserting into washer product reading table
                dosingDataList = new List<ConventionalDosingData>();
                dosingOffset = offset * 10;
                for (int EquipmentNo = 0; EquipmentNo <= 9; EquipmentNo++)
                {
                    dosingData = new ConventionalDosingData();

                    if (dosingArray[EquipmentNo + dosingOffset] > 0)
                    {
                        if (dosingOffset == EquipmentNo + dosingOffset)
                        {
                            dosingData.Equipment = "9";//Main Equipment 1
                            dosingData.isMainEquipment = "true";
                            dosingData.Qty = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, (Convert.ToUInt16(dosingArray[EquipmentNo + dosingOffset]))).ToString();
                        }
                        else if (dosingOffset + 9 == EquipmentNo + dosingOffset)
                        {
                            dosingData.Equipment = "10";//Main Equipment 2
                            dosingData.isMainEquipment = "true";
                            dosingData.Qty = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, (Convert.ToUInt16(dosingArray[EquipmentNo + dosingOffset]))).ToString();
                        }
                        else
                        {
                            dosingData.Equipment = (EquipmentNo).ToString();
                            dosingData.isMainEquipment = "false";
                            dosingData.Qty = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, (Convert.ToUInt16(dosingArray[EquipmentNo + dosingOffset]))).ToString();
                        }
                        dosingData.stepNo = washerData.StepNumber.ToString();
                        dosingDataList.Add(dosingData);
                    }
                }
                if (dosingDataList.Count > 0 && dosingDataList != null)
                    washerData.DosingData = dosingDataList;

                dateTimeoffset += 2;
                offset++;
                listWasherData.Add(washerData);
            }
            string xmlString = SerializeXMLData(ListConventionalXmlSerializer, listWasherData);
            Log.InfoFormat("DataReaderAccess.ProcessEcontrolPlusOnlineConventionalData - Call Start - Controller ID {0} {1} ", controller.ControllerId.ToString(), xmlString);
            RedFlagShiftId = DataReaderAccess.ProcessEcontrolPlusOnlineConventionalData(controller.ControllerId, xmlString, RedFlagShiftId);
            Log.InfoFormat("DataReaderAccess.ProcessEcontrolPlusOnlineConventionalData - Call End - Controller ID {0} ", controller.ControllerId.ToString());
            if (RedFlagShiftId > 0)
            {
                DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
            }
        }
        private string SerializeXMLData(XmlSerializer serilizer, object objectData)
        {
            StringWriter stringWriter = new StringWriter();
            using (XmlWriter xmlWriter = new XmlTextWriter(stringWriter))
            {
                serilizer.Serialize(xmlWriter, objectData);
                return stringWriter.ToString();
            }
        }
        private void ReadOnlineDataForTunnels(MitsubishiController controller)
        {
            try
            {
                MyControlTunnel tunnelWasher = new MyControlTunnel();
                ushort startDateValue;
                ushort startTimeValue;
                int TunnelNumber = 1;
                int groupNumber = 2;
                int checkPhOrTemp;
                int offset = 6;
                int onlineArrayOffset = 32;
                int NoOfCompartments = 25;
                int[] signals = new int[2];
                tunnelWasher.Tunnels = new List<TunnelData>();
                tunnelWasher.MachineNumber = TunnelNumber.ToString();
                NoOfCompartments = CommonDataOperations.GetNoOfCompartmentsByMachineInternalId(TunnelNumber, controller.ControllerId);
                if (NoOfCompartments < 1)
                    NoOfCompartments = 25;
                if (onLineArray == null)
                    return;
                if (controller.PLCType == MitsubishiPLCType.EControlPlus6W1T)
                {
                    DataReader<MitsubishiTag> dataReader = dataReaders[controller.ControllerId];
                    signals = (dataReader.ReadTagsExt(new List<MitsubishiTag>() { new MitsubishiTag() { Address = "M241", TagItemType = UIInputType.TypeBool }, new MitsubishiTag() { Address = "M240", TagItemType = UIInputType.TypeBool } })).Select(x => Convert.ToInt32(x.Value)).ToArray();
                }
                for (int compartmentNum = 0; compartmentNum < NoOfCompartments; compartmentNum++)
                {

                    TunnelData tunnelOnlineData = new TunnelData();
                    tunnelOnlineData.CompartmentNumber = (compartmentNum + 1).ToString();
                    tunnelOnlineData.ProgramNumber = onLineArray[onlineArrayOffset + compartmentNum].ToString();
                    tunnelOnlineData.CustomerNumber = onLineArray[onlineArrayOffset + 50 + compartmentNum].ToString();
                    tunnelOnlineData.BatchNumber = OnlineCbwBatchesArray[compartmentNum].ToString();
                    tunnelOnlineData.RunTime = OnLineCbwArray[compartmentNum * 20 + 17];//Run Time in Seconds
                    startDateValue = (ushort)OnLineCbwArray[compartmentNum * 20 + 18];//start Date Time
                    startTimeValue = (ushort)OnLineCbwArray[compartmentNum * 20 + 19];//start Time
                    tunnelOnlineData.StartDateTime = ConvertPlcDateTime(startDateValue, startTimeValue);
                    tunnelOnlineData.GroupNumber = groupNumber.ToString();
                    tunnelOnlineData.TunnelNumber = TunnelNumber.ToString();
                    tunnelOnlineData.MachineNumber = TunnelNumber.ToString();
                    if (signals.Length >= 2)
                    {
                        tunnelOnlineData.TransferSignal = signals[0].ToString();          // signals[0] = Cbw 1 Transfer Signal
                        tunnelOnlineData.RunState = signals[1].ToString();               //  signals[1] = Cbw 1 Runstate Signal
                    }
                    if (controller.RegionID == 1) //North America
                    {
                        tunnelOnlineData.Load = (onLineArray[onlineArrayOffset + 25 + compartmentNum] / 10).ToString();
                    }
                    else if (controller.RegionID == 2) //Europe / Middle East / Africa
                    {
                        tunnelOnlineData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram,
                                                                            onLineArray[onlineArrayOffset + 25 + compartmentNum] / 10
                                                                           ).ToString();
                    }
                    //Reading pH and Temperature values
                    //The same word is used in the PLC to code the pH and temperature value which are both coded on the 4 right digits. The first digit on the left is used to code the information type:
                    //  1 for pH 2 for temperature.
                    MitsubishiTag pHAndTempTag = new MitsubishiTag() { Address = "D6517", TagItemType = UIInputType.TypeArray, ArrayLength = 10 };  //Reading pH and Temp for Washers and tunnel 1-8
                    IList<MitsubishiTag> ArrayTags = new List<MitsubishiTag>() { pHAndTempTag };
                    DataReader<MitsubishiTag> dataReaderpHTemp = dataReaders[controller.ControllerId];
                    ArrayTags = dataReaderpHTemp.ReadTagsExt(ArrayTags);
                    pHAndTempArray = pHAndTempTag.IntArrayData;
                    checkPhOrTemp = pHAndTempArray[offset];
                    if (checkPhOrTemp > 0)
                    {
                        string findDigit = Convert.ToString(checkPhOrTemp);
                        if (findDigit.Length >= 1)
                        {
                            if (Convert.ToInt32(findDigit[0]) == 49)         //If first digit is 1 it is pH and Ascii value of 1 - 49
                            {
                                tunnelOnlineData.Phvalue = (checkPhOrTemp % 1000).ToString();
                            }
                            else if (Convert.ToInt32(findDigit[0]) == 50)    //If first digit is 2 it is Temperature and Ascii value of 2 - 50
                            {
                                if (controller.RegionID == 1)  //North America
                                {
                                    tunnelOnlineData.temperature1 = (checkPhOrTemp % 1000).ToString();
                                }
                                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                                {
                                    if (checkPhOrTemp % 1000 > 0)
                                        tunnelOnlineData.temperature1 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, checkPhOrTemp % 1000));
                                }
                            }
                        }
                    }
                    checkPhOrTemp = pHAndTempArray[offset + 1];   //we have both LF and temp on same value
                    if (checkPhOrTemp > 0)
                    {
                        string findDigit = Convert.ToString(checkPhOrTemp);
                        if (findDigit.Length >= 1)
                        {
                            if (Convert.ToInt32(findDigit[0]) == 49)         //If first digit is 1 it is pH and Ascii value of 1 - 49
                            {
                                tunnelOnlineData.LFValue = (checkPhOrTemp % 1000).ToString();
                            }
                            else if (Convert.ToInt32(findDigit[0]) == 50)    //If first digit is 2 it is Temperature and Ascii value of 2 - 50
                            {
                                if (controller.RegionID == 1)  //North America
                                {
                                    tunnelOnlineData.temperature2 = (checkPhOrTemp % 1000).ToString();
                                }
                                else if (controller.RegionID == 2) //Europe / Middle East / Africa
                                {
                                    if (checkPhOrTemp % 1000 > 0)
                                        tunnelOnlineData.temperature2 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, checkPhOrTemp % 1000));
                                }
                            }
                        }
                    }
                    PopulateTunnelOnlineDosingData(tunnelOnlineData, compartmentNum + 1);
                    if (tunnelOnlineData != null)
                    {
                        if (tunnelOnlineData.MachineNumber != "0" && tunnelOnlineData.MachineNumber != null)
                            tunnelWasher.Tunnels.Add(tunnelOnlineData);
                    }
                }
                string xmlString = SerializeXMLData(TunnelSerializer, tunnelWasher); ;
                Log.InfoFormat("Processing Tunnel WasherId and XML Data {0} {1}", controller.ControllerId, xmlString);
                DataReaderAccess.ProcessEcontrolPlusTunnelWasherOnlineData(controller.ControllerId, xmlString);
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
                throw exp;
            }
        }
        private void PopulateTunnelOnlineDosingData(TunnelData tunnelOnlineData, int compartNumber)
        {
            int dosingPoint = 0;
            int equipmentNo; // Pump No or Main equipment Number
            string isMainEquipment;
            int remainder;
            double quantity;
            tunnelOnlineData.dose = new List<Dose>();
            for (int dosageIndex = 0; dosageIndex < 40; dosageIndex++)
            {
                //if this Dosing point and Pump no (ME1,2) not connecting to current compartment
                if (compartmentDosingArray[dosageIndex] != compartNumber) continue;
                Entities.Dose dosing = new Entities.Dose();
                remainder = (dosageIndex + 1) % 10;
                if (remainder == 1)
                {
                    dosingPoint++;
                    isMainEquipment = "1";
                    equipmentNo = 9;
                    quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, dosingArray[dosageIndex]);
                }
                else if (remainder == 0)
                {
                    isMainEquipment = "1";
                    equipmentNo = 10;
                    quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, dosingArray[dosageIndex]);
                }
                else
                {
                    isMainEquipment = "0";
                    equipmentNo = remainder - 1;
                    quantity = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, dosingArray[dosageIndex]);
                }
                if (dosingArray[dosageIndex] > 0)
                {
                    dosing.IsDirectDosing = "0";
                    dosing.IsMainEquipment = isMainEquipment;
                    dosing.Number = equipmentNo.ToString();
                    dosing.Point = dosingPoint.ToString();
                    dosing.Quantity = quantity.ToString();
                    tunnelOnlineData.dose.Add(dosing);
                }
            }
        }
        public static string ConvertPlcDateTime(ushort PlcDate, ushort PlcTime)
        {
            try
            {
                if (PlcDate == 0) return string.Empty;
                int Month = PlcDate / 1000;
                int Day = (PlcDate - (Month * 1000)) / 10;
                int Year = PlcDate - (Month * 1000) - (Day * 10);
                double temp = (DateTime.Now.Year - 2000 - Year) / 10;
                int YearDiff = Convert.ToInt32(Math.Round(temp, MidpointRounding.AwayFromZero) * 10);
                Year = Year + YearDiff + 2000;
                Day = Day - YearDiff / 10;
                int Hours = PlcTime / 1000;
                int Minutes = (PlcTime - (Hours * 1000)) / 10;
                int Seconds = (PlcTime - (Hours * 1000) - (Minutes * 10)) * 10;
                DateTime dateValue = new DateTime(Year, Month, Day, Hours, Minutes, Seconds);
                dateValue = TimeZoneInfo.ConvertTimeToUtc(dateValue);
                string datestring = dateValue.ToString("MM/dd/yyyy HH:mm:ss", new System.Globalization.CultureInfo("en-US"));
                return datestring;
            }
            catch (Exception ex)
            {
                Log.Error("Failed due to date time convertion" + PlcDate + PlcTime + ": " + ex.Message);
                return string.Empty;
            }
        }
        public void ProcessEControlPlusProdDataFor6W1T(MitsubishiController controller)
        {
            //Process production data from Econtrol Plus 6W1T plc type
            //Process production data for Econtrol Plus 8W plc type
            if (String.IsNullOrEmpty(controller.HostAdress))
                return;
            List<MitsubishiTag> EcntrlPlusPointerTags = new List<MitsubishiTag>
            {
                new MitsubishiTag
                {
                    Address = StorePointer, SizetoRead = SizeStorePointer, TagItemType = UIInputType.TypeInt,TagType = "uint"
                },
                new MitsubishiTag
                {
                    Address = StorePointerR, SizetoRead = SizeStorePointerR, TagItemType = UIInputType.TypeInt,TagType = "uint"
                },
            };
            IList<MitsubishiTag> ECntrlPlusPointerData = dataReaders[controller.ControllerId].ReadTagsExt(EcntrlPlusPointerTags);
            // Get pointer values
            int RedFlagShiftId = 0;
            int PLCPointer = Convert.ToInt32(ECntrlPlusPointerData[0].Value);
            int dcsPointer = Convert.ToInt32(ECntrlPlusPointerData[1].Value);
            if (PLCPointer != dcsPointer)
            {
                #region Pointer Increment logic
                dcsPointer++;
                if (dcsPointer > 270)
                {
                    dcsPointer = 1;
                }
                string address;
                int adressPointer = 11160 + (dcsPointer - 1) * 80;
                address = "R" + adressPointer.ToString();
                List<MitsubishiTag> EcntrlPlusBatchDataTag = new List<MitsubishiTag>
                {
                    new MitsubishiTag
                    {
                        Address = address,
                        TagItemType = UIInputType.TypeArray,
                        ArrayLength =SizeStoreProdData
                    }
                };
                IList<MitsubishiTag> ECntrlPlusBatchData = dataReaders[controller.ControllerId].ReadTagsExt(EcntrlPlusBatchDataTag);
                #endregion
                //Get Washer number
                int MachineNum;
                MachineNum = ECntrlPlusBatchData[0].IntArrayData[0];
                /// Identify whether batch is from tunnel or washer based on washer number.
                if (MachineNum == 1)//Tunnel
                {
                    ///Process Tunnel washers
                    MyControlTunnel tunnelWasher = new MyControlTunnel();
                    tunnelWasher.Tunnels = new List<TunnelData>();
                    TunnelData tunnel;
                    tunnel = ProcessTunnelDataProd(controller.RegionID, ECntrlPlusBatchData[0].IntArrayData, MachineNum);
                    tunnelWasher.MachineNumber = tunnel.MachineNumber;
                    tunnelWasher.Tunnels.Add(tunnel);
                    string strTunnel = SerializeXMLData(TunnelSerializer, tunnelWasher);
                    Log.InfoFormat("Processing Tunnel WasherId and XML Data {0} {1}", controller.ControllerId, strTunnel);
                    RedFlagShiftId = DataReaderAccess.ProcessEControlPlusBatchTunnelProdData(controller.ControllerId, strTunnel, PLCPointer, dcsPointer, RedFlagShiftId);
                    Log.Info("DataReaderAccess.ProcessEControlPlusBatchConventionalProdData - Call End " + controller.ControllerId.ToString());
                }
                else if (MachineNum > 1)
                {
                    //Process conventional washers
                    ConventionalWasherData conventionalData = ProcessConventionalDataProd(controller.RegionID, ECntrlPlusBatchData[0].IntArrayData, 0, MachineNum - 1);
                    string xmlString = SerializeXMLData(ConventionalXmlSerializer, conventionalData);
                    Log.InfoFormat("DataReaderAccess.ProcessEControlPlusBatchConventionalProdData - Call Start {0}, {1} ", controller.ControllerId.ToString(), xmlString);
                    RedFlagShiftId = DataReaderAccess.ProcessEControlPlusBatchConventionalProdData(controller.ControllerId, xmlString, PLCPointer, dcsPointer, RedFlagShiftId);
                    Log.Info("DataReaderAccess.ProcessEControlPlusBatchConventionalProdData - Call End " + controller.ControllerId.ToString());
                }
                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
                //Write pointer value to plc
                List<MitsubishiTag> writetags = new List<MitsubishiTag> { new MitsubishiTag { Address = StorePointerR } };
                writetags[0].Value = dcsPointer.ToString();
                dataWriters[controller.ControllerId].WriteTagsExt(writetags);
                Log.Info("Completed Processing Batches Array " + controller.ControllerId.ToString());
            }
        }
        private static TunnelData ProcessTunnelDataProd(int regionId, Int32[] IntArrayData, int tunnelNumber)
        {
            TunnelData tunnelProd = new TunnelData();
            int offset = 0;
            tunnelProd.dose = new List<Dose>();//[104];
            tunnelProd.TimeCompartment = new List<CompartmentTime>();
            tunnelProd.WaterConsumption = new List<WaterConsumption>();
            tunnelProd.temperature = new List<TemperatureData>();
            TunnelData objrettunneldata = null;
            try
            {
                tunnelProd.TunnelNumber = tunnelNumber.ToString();
                tunnelProd.CompartmentNumber = "0";
                #region Process Tunnel Data
                tunnelProd.MachineNumber = IntArrayData[offset].ToString();
                if (IntArrayData[offset + 1] != 0)
                {
                    //Format the date time based on the value read from PLC and format datetime in one parameter
                    tunnelProd.StartDate = IntArrayData[offset + 1].ToString();
                    tunnelProd.StartTime = IntArrayData[offset + 2].ToString();
                    tunnelProd.StartDateTime = ConvertPlcDateTime((ushort)IntArrayData[offset + 1], (ushort)IntArrayData[offset + 2]);
                }
                else
                {
                    tunnelProd.StartDate = null;
                    tunnelProd.StartTime = null;
                    tunnelProd.StartDateTime = string.Empty;
                }

                if (IntArrayData[offset + 3] == 0)
                {
                    tunnelProd.StopDate = null;
                    tunnelProd.StopTime = null;
                    tunnelProd.EndDateTime = string.Empty;
                }
                else
                {
                    tunnelProd.StopDate = IntArrayData[offset + 3].ToString();
                    tunnelProd.StopTime = IntArrayData[offset + 4].ToString();
                    tunnelProd.EndDateTime = ConvertPlcDateTime((ushort)IntArrayData[offset + 3], (ushort)IntArrayData[offset + 4]);
                }
                tunnelProd.ProgramNumber = IntArrayData[offset + 5].ToString();

                if (regionId == 1) //North America
                {
                    tunnelProd.Load = (IntArrayData[offset + 6] / 10).ToString();
                    //tunnelProd.Nominalload = (batchData[offset + 7] / 10).ToString(); 
                    tunnelProd.Nominalload = (IntArrayData[offset + 7]).ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    tunnelProd.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(IntArrayData[offset + 6] / 10))).ToString();
                    //tunnelProd.Nominalload = ConvertUOM("kilogram", (Convert.ToUInt16(batchData[offset + 7] / 10))).ToString();
                    tunnelProd.Nominalload = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(IntArrayData[offset + 7]))).ToString();
                }
                //CustomerNumberHB and CustomerNumberLB calculations
                tunnelProd.CustomerNumberHB = (IntArrayData[offset + 8] * 10000).ToString();
                tunnelProd.CustomerNumberLB = tunnelProd.CustomerNumberHB + IntArrayData[offset + 9].ToString();
                tunnelProd.CustomerNumber = tunnelProd.CustomerNumberLB;
                tunnelProd.BatchNumber = IntArrayData[offset + 10].ToString();
                //Process Time Compartment
                ProcessTunnelTimeCompartment(IntArrayData, tunnelProd);
                //Process Dose Data
                ProcessTunnelDoseData(regionId, IntArrayData, tunnelProd);
                //Process water consumption data
                objrettunneldata = ProcessTunnelpHandTemperatureData(regionId, IntArrayData, tunnelProd);
                #endregion
                return objrettunneldata;
            }
            catch (Exception ex)
            {
                Log.Error(ex);
            }
            return tunnelProd;
        }
        private static void ProcessTunnelTimeCompartment(Int32[] batchData, TunnelData tunnelProd)
        {
            tunnelProd.RunTime = 0;
            for (int offset = 11; offset <= 35; offset++)
            {
                CompartmentTime ct = new CompartmentTime();
                ct.CompartmentNo = (offset - 10).ToString();
                ct.Time = batchData[offset].ToString();
                tunnelProd.TimeCompartment.Add(ct);
                tunnelProd.CompartmentNumber = (offset - 10).ToString();
            }

            if (tunnelProd.RunTime <= 0)
            {
                if (!string.IsNullOrEmpty(tunnelProd.EndDateTime) && !string.IsNullOrEmpty(tunnelProd.StartDateTime))
                {
                    TimeSpan diff = Convert.ToDateTime(tunnelProd.EndDateTime) - Convert.ToDateTime(tunnelProd.StartDateTime);
                    tunnelProd.RunTime = Convert.ToInt64(diff.TotalSeconds);
                }
            }

            if (tunnelProd.RunTime > 350000)
                tunnelProd.RunTime = 350000;
        }
        private static void ProcessTunnelDoseData(int regionId, Int32[] batchData, TunnelData tunnelProd)
        {
            //Process Dose data
            int dosingPoint = 1;
            int dosingPump = 1;
            int dosingRange = 1;
            for (int offset = 36; offset <= 75; offset++)
            {
                Dose dose = new Dose();

                if (batchData[offset] > 0)
                {
                    if (regionId == 1) //North America
                    {
                        dose.Quantity = batchData[offset].ToString();
                    }
                    else if (regionId == 2) //Europe / Middle East / Africa
                    {
                        if (offset >= 40 && offset <= 71)
                        {
                            dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, batchData[offset]).ToString();
                            dose.IsMainEquipment = "0";
                        }
                        else if ((offset >= 36 && offset <= 39) || (offset >= 72 && offset <= 75))
                        {
                            dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, batchData[offset]).ToString();
                            dose.IsMainEquipment = "1";
                        }
                    }
                    dose.Number = dosingPump.ToString();
                    dose.Point = dosingPoint.ToString();

                    tunnelProd.dose.Add(dose);
                }
                dosingRange++;
                dosingPoint++;

                if (dosingRange == 5)
                {
                    dosingRange = 1;
                    dosingPoint = 1;
                    dosingPump++;
                }
            }
        }
        private static TunnelData ProcessTunnelpHandTemperatureData(int regionId, Int32[] batchData, TunnelData tunnelProd)
        {
            //pH value
            if (batchData[77] != 0)
            {
                tunnelProd.Phstatus = (Convert.ToInt32(batchData[77] / 10000)).ToString();
                tunnelProd.Phvalue = (batchData[77] - (Convert.ToInt64(tunnelProd.Phstatus) * 10000)).ToString();
                tunnelProd.Phvalue = (Convert.ToInt32(tunnelProd.Phvalue) / 10).ToString();
            }
            else
            {
                tunnelProd.Phstatus = null;
                tunnelProd.Phvalue = null;
            }
            //Temperature 
            string strTemp = GetWordfromInt((ushort)batchData[78]);
            TemperatureData td = new TemperatureData();
            if (batchData[78] != 0)
            {
                if (!String.IsNullOrEmpty(strTemp))
                {
                    if (regionId == 1) //North America
                    {
                        td.Status = (Convert.ToInt32(batchData[78] / 10000)).ToString();
                        td.Minimum = ((batchData[78] - (Convert.ToInt64(td.Status) * 10000)) / 10).ToString();
                        td.Maximum = (batchData[79] / 10).ToString();
                    }
                    else if (regionId == 2) //Europe / Middle East / Africa
                    {
                        td.Status = (Convert.ToInt32(batchData[78] / 10000)).ToString();
                        td.Minimum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, Convert.ToUInt16((batchData[78] - Convert.ToInt64(td.Status) * 10000) / 10)).ToString();
                        td.Maximum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, Convert.ToUInt16(batchData[79] / 10)).ToString();
                    }
                }
                else
                {
                    td.Status = null;
                    td.Minimum = null;
                    td.Maximum = null;
                }
            }
            return tunnelProd;
        }
        private static string SerializeTunnel(MyControlTunnel tunnel)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(MyControlTunnel));
            StringWriter stringWriter = new StringWriter();
            xmlSerializer.Serialize(stringWriter, tunnel);
            string xmlString = stringWriter.GetStringBuilder().ToString();
            stringWriter.Close();
            return xmlString;
        }
        private static ConventionalWasherData ProcessConventionalDataProd(int regionId, Int32[] IntArrayData, int offset, int WasherNum)
        {
            ConventionalWasherData washerData = new ConventionalWasherData();
            //if (WasherNum == 0)
            //    return null;
            washerData.MachineNumber = WasherNum.ToString();
            washerData.StepNumber = string.Empty;
            washerData.StartDateTime = string.Empty;
            //Start Date & Time
            if (IntArrayData[offset + 1] > 0)
                washerData.StartDateTime = ConvertPlcDateTime((ushort)IntArrayData[offset + 1], (ushort)IntArrayData[offset + 2]);

            washerData.EndDateTime = string.Empty;
            //Stop Date & Time 
            if (IntArrayData[offset + 3] > 0)
                washerData.EndDateTime = ConvertPlcDateTime((ushort)IntArrayData[offset + 3], (ushort)IntArrayData[offset + 4]);
            washerData.ProgramNumber = IntArrayData[offset + 5].ToString();
            if (regionId == 1) //North America
            {
                washerData.Load = (IntArrayData[offset + 6]).ToString();
                washerData.NominalLoad = (IntArrayData[offset + 7] ).ToString();
            }
            else if (regionId == 2) //Europe / Middle East / Africa
            {
                washerData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(IntArrayData[offset + 6]))).ToString();
                washerData.NominalLoad = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(IntArrayData[offset + 7]))).ToString();
            }
            Int32 CustomerNumber;
            CustomerNumber = IntArrayData[offset + 8] * 10000;
            CustomerNumber = CustomerNumber + IntArrayData[offset + 9];
            washerData.CustomerNumber = CustomerNumber.ToString();
            washerData.BatchNumber = IntArrayData[offset + 10].ToString();
            #region Time Step 1 to 25
            washerData.StepTime = new List<ConventionalStepData>(new ConventionalStepData[25]);
            int tempOffset;
            for (int index = 1; index <= 25; index++)
            {
                tempOffset = offset + 11 + (index - 1);
                washerData.StepTime[index - 1] = new ConventionalStepData();
                washerData.StepTime[index - 1].Number = index.ToString();
                washerData.StepTime[index - 1].Time = IntArrayData[tempOffset].ToString();
            }
            #endregion
            #region Dose 1 to 20
            washerData.DosingData = new List<ConventionalDosingData>(new ConventionalDosingData[25]);
            int doseOffset = offset + 36;
            int doseStep;
            int doseFirstElement;
            int doseEquipment;
            int doseQuantity;
            for (int index = 1; index <= 20; index++)
            {
                tempOffset = doseOffset + ((index - 1) * 2);
                doseFirstElement = IntArrayData[tempOffset];
                doseStep = doseFirstElement / 100;
                doseEquipment = doseFirstElement % 100;
                doseQuantity = IntArrayData[tempOffset + 1];
                washerData.DosingData[index - 1] = new ConventionalDosingData();
                washerData.DosingData[index - 1].Equipment = doseEquipment.ToString();
                if (regionId == 1) //North America
                {
                    washerData.DosingData[index - 1].Qty = doseQuantity.ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    if (doseEquipment >= 1 && doseEquipment <= 24)
                        washerData.DosingData[index - 1].Qty = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, (Convert.ToUInt16(doseQuantity))).ToString();
                    else if (doseEquipment >= 25 && doseEquipment <= 26)
                        washerData.DosingData[index - 1].Qty = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, (Convert.ToUInt16(doseQuantity))).ToString();
                }
                washerData.DosingData[index - 1].stepNo = doseStep.ToString();
            }
            #endregion
            #region Water Consumption
            if (regionId == 1) //North America
            {
                washerData.WaterConsumption1 = IntArrayData[offset + 76].ToString();
            }
            else if (regionId == 2) //Europe / Middle East / Africa
            {
                washerData.WaterConsumption1 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, IntArrayData[offset + 76]).ToString();
            }
            #endregion
            #region pH calculation
            ushort PHData = (ushort)IntArrayData[offset + 77];//PH
            int tempphData;
            if (PHData >= 10000)
            {
                tempphData = PHData / 10000;
                washerData.PHStatus = tempphData.ToString();
                tempphData = tempphData * 10000;
                tempphData = PHData - tempphData;
                washerData.PHValue = tempphData.ToString();
            }
            else
            {
                washerData.PHStatus = "0";
                washerData.PHValue = PHData.ToString();
            }
            #endregion
            #region Temperature Min
            ushort tempratureMinData = (ushort)IntArrayData[offset + 78];
            int tempData;
            if (tempratureMinData >= 10000)
            {
                tempData = tempratureMinData / 10000;
                washerData.TemperatureMinStatus = tempData.ToString();
                tempData = tempData * 10000;
                tempData = tempratureMinData - tempData;
                if (regionId == 1) //North America
                {
                    washerData.TemperatureMin = tempratureMinData.ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    if (tempratureMinData > 0)
                        washerData.TemperatureMin = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tempratureMinData).ToString();
                }
            }
            else
            {
                washerData.TemperatureMinStatus = "0";
                if (regionId == 1) //North America
                {
                    washerData.TemperatureMin = tempratureMinData.ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    if (tempratureMinData > 0)
                        washerData.TemperatureMin = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tempratureMinData).ToString();
                }
            }
            #endregion
            #region Temperature Max
            ushort tempMaxData = (ushort)IntArrayData[offset + 79];
            int CoolDownValueTempDiff = 0;
            if (tempMaxData > tempratureMinData)
            {
                CoolDownValueTempDiff = tempMaxData - tempratureMinData;
            }
            if (regionId == 1) //North America
            {
                washerData.TemperatureMax = tempMaxData.ToString();
            }
            else if (regionId == 2) //Europe / Middle East / Africa
            {
                if (tempMaxData > 0)
                    washerData.TemperatureMax = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tempMaxData).ToString();
            }
            washerData.TemperatureMaxStatus = CoolDownValueTempDiff.ToString();
            #endregion
            return washerData;
        }
        public static string GetWordfromInt(UInt16 val)
        {
            string word = Convert.ToString(val, 2);
            return word;
        }
        public void ProcessEControlPlusProdDataFor8W(MitsubishiController controller)
        {
            //Process production data from Econtrol Plus 6W1T plc type
            //Process production data for Econtrol Plus 8W plc type
            if (String.IsNullOrEmpty(controller.HostAdress))
                return;
            List<MitsubishiTag> EcntrlPlusPointerTags = new List<MitsubishiTag>
            {
                new MitsubishiTag
                {
                    Address = StorePointer, SizetoRead = SizeStorePointer, TagItemType = UIInputType.TypeInt,TagType = "uint"
                },
                new MitsubishiTag
                {
                    Address = StorePointerR, SizetoRead = SizeStorePointerR, TagItemType = UIInputType.TypeInt,TagType = "uint"
                },
            };
            IList<MitsubishiTag> ECntrlPlusPointerData = dataReaders[controller.ControllerId].ReadTagsExt(EcntrlPlusPointerTags);
            // Get pointer values
            int RedFlagShiftId = 0;
            int PLCPointer = Convert.ToInt32(ECntrlPlusPointerData[0].Value);
            int dcsPointer = Convert.ToInt32(ECntrlPlusPointerData[1].Value);
            if (PLCPointer != dcsPointer)
            {
                dcsPointer++;
                if (dcsPointer > 270)
                {
                    dcsPointer = 1;
                }
                string address;
                int adressPointer = 11160 + (dcsPointer - 1) * 80;
                address = "R" + adressPointer.ToString();
                List<MitsubishiTag> EcntrlPlusBatchDataTag = new List<MitsubishiTag>
                {
                    new MitsubishiTag
                    {
                        Address = address,
                        TagItemType = UIInputType.TypeArray,
                        ArrayLength =SizeStoreProdData
                    }
                };
                IList<MitsubishiTag> ECntrlPlusBatchData = dataReaders[controller.ControllerId].ReadTagsExt(EcntrlPlusBatchDataTag);
                //Get Washer number
                int MachineNum;
                MachineNum = EcntrlPlusBatchDataTag[0].IntArrayData[0];
                /// Identify whether batch is from tunnel or washer based on washer number.
                    //Process conventional washers
                ConventionalWasherData conventionalData = ProcessConventionalDataProd(controller.RegionID, ECntrlPlusBatchData[0].IntArrayData, 0, MachineNum);
                string xmlString = SerializeXMLData(ConventionalXmlSerializer, conventionalData);
                Log.InfoFormat("DataReaderAccess.ProcessEControlPlusBatchConventionalProdData - Call Start{0} {1} ", controller.ControllerId.ToString(), xmlString);
                RedFlagShiftId = DataReaderAccess.ProcessEControlPlusBatchConventionalProdData(controller.ControllerId, xmlString, PLCPointer, dcsPointer, RedFlagShiftId);
                Log.Info("DataReaderAccess.ProcessEControlPlusBatchConventionalProdData - Call End " + controller.ControllerId.ToString());
                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
                //Write pointer value to plc
                List<MitsubishiTag> writetags = new List<MitsubishiTag> { new MitsubishiTag { Address = StorePointerR } };
                writetags[0].Value = dcsPointer.ToString();
                dataWriters[controller.ControllerId].WriteTagsExt(writetags);
                Log.Info("Completed Processing Batches Array " + controller.ControllerId.ToString());
            }
        }
        #endregion
    }
}
