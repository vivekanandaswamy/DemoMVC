﻿// -----------------------------------------------------------------------
// <copyright file="EntityConverter.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The EntityConverter </summary>
// -----------------------------------------------------------------------

using DbEntities = Entities.DataReader;

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using Entities;

    public static class EntityConverter
    {
        public static Controller Convert(DbEntities.Controller controller)
        {
            ControllerType controllerType = (ControllerType)controller.ControllerTypeId;
            switch (controllerType)
            {
                case ControllerType.AllenBradley:
                    return new AllenBradleyController { ControllerId = controller.ControllerId, OpcServer = controller.OpcServerName, Name = controller.Name, IsWebPortEnabled = controller.WebPortFtpEnabled, WebPortAddress = controller.WebPortIp, WebPortUserName = controller.WebPortLogin, WebPortPassword = controller.WebPortPassword, TopicName = controller.TopicName, Webportdatetime = controller.Webportdatetime };
                case ControllerType.Beckhoff:
                    return new BeckhoffController { ControllerId = controller.ControllerId, Comport = int.Parse("801"), AmsNetAddress = controller.AMSNetIdAddress, IpAddress = controller.IpAddress, Name = controller.Name, TopicName = controller.TopicName, XmlDateTime = controller.Webportdatetime, RegionID = controller.RegionID };
                case ControllerType.MyControl:
                    return new BeckhoffController { ControllerId = controller.ControllerId, Comport = int.Parse("801"), AmsNetAddress = controller.AMSNetIdAddress,IpAddress=controller.IpAddress, Name = controller.Name, TopicName = controller.TopicName, XmlDateTime = controller.Webportdatetime, RegionID = controller.RegionID };
                case ControllerType.TenWasher:
                    return new MitsubishiController() { ControllerId = controller.ControllerId, PLCType = MitsubishiPLCType.PLCXL10W, HostAdress = controller.IpAddress, COMPort = controller.Comport, Name = controller.Name, RegionID = controller.RegionID};
                case ControllerType.TwoTunnels:
                    return new MitsubishiController() { ControllerId = controller.ControllerId, PLCType = MitsubishiPLCType.PLCXL2Cbw, HostAdress = controller.IpAddress, COMPort = controller.Comport, Name = controller.Name, RegionID = controller.RegionID };
                case ControllerType.FiveWashersOneTunnel:
                    return new MitsubishiController() { ControllerId = controller.ControllerId, PLCType = MitsubishiPLCType.PLCXL5W1C, HostAdress = controller.IpAddress, COMPort = controller.Comport, Name = controller.Name, RegionID = controller.RegionID };
                case ControllerType.EightWashers:
                    return new MitsubishiController() { ControllerId = controller.ControllerId, PLCType = MitsubishiPLCType.EControlPlus8W, HostAdress = controller.IpAddress, COMPort = controller.Comport, Name = controller.Name, RegionID = controller.RegionID };
                case ControllerType.SixWashersOneTunnel:
                    return new MitsubishiController() { ControllerId = controller.ControllerId, PLCType = MitsubishiPLCType.EControlPlus6W1T, HostAdress = controller.IpAddress, COMPort = controller.Comport, Name = controller.Name, RegionID = controller.RegionID };
                default:
                    throw new NotImplementedException();
            }
        }
    }
}