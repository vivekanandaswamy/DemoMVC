﻿// -----------------------------------------------------------------------
// <copyright file="WebPortService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WebPortService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Timers;
    using System.Xml;
    using System.Xml.Serialization;
    using Access.DataReader;
    using Entities;
    using global::Entities.DataReader;
    using log4net;
    using Properties;
    using WebPortReader;
    using Controller = global::Entities.DataReader.Controller;
    using Timer = System.Timers.Timer;
    using Washer = global::Entities.DataReader.Washer;

    public class WebPortService
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(WebPortService));
        private List<AllenBradleyController> allenBradleyControllers;
        public static int NoOfCompartments { get; set; }
        private static readonly Dictionary<int, Queue<WebPortQueueItem>> QueueList = new Dictionary<int, Queue<WebPortQueueItem>>();
        object locker = new object();
        private Timer timer = null;
        ManualResetEvent timerDead = new ManualResetEvent(false);
        private bool serviceStopping = false;
        ProcessRollup processRollup = new ProcessRollup();

        /// <summary>
        ///     The WebPort PLC tag file's filename prefix.
        /// </summary>
        public const string WebPortPlcTagFilenamePrefix = "irc_";

        /// <summary>
        ///     The WebPort PLC tag file's extension.
        /// </summary>
        public const string WebPortPlcTagFileExtension = ".txt";

        public WebPortService()
        {
            timer = new Timer(Int32.Parse(Settings.Default.WebportReadInterval))
            {
                AutoReset = false
            };
            // Hook up the Elapsed event for the timer. 
            timer.Elapsed += OnTimedEvent;
            timer.Enabled = true;
        }

        public void Stop()
        {
            try
            {
                Log.Info("WebPort : Stopping Data Communication Service...");
                serviceStopping = true;
                // wait until current file collection operation is done
                timerDead.WaitOne();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to stop Data Communcation Service", ex);
            }
            finally
            {
                Log.InfoFormat("{0}: Service has been stopped.", "Data Communication Service");
            }
        }

        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {
                timerDead.Reset();	// make sure service doesn't stop until load is complete
                Start();		// run  file collection

            }
            catch (Exception ex)
            {
                Log.Error("Failed to run Data Communcation Service", ex);
            }
            finally
            {
                timerDead.Set();	// allow service to stop
                if (!serviceStopping)
                {
                    // restart the timer
                    timer.Start();
                }
            }
        }

        public void Start()
        {
            try
            {
                IEnumerable<Controller> activeControllers = DataReaderAccess.GetActiveControllers();
                List<global::Ecolab.Dcs.Entities.Controller> controllers =
                    activeControllers.Select(EntityConverter.Convert).ToList();
                allenBradleyControllers =
                    controllers.FindAll(c => c is AllenBradleyController).Select(c => (AllenBradleyController)c).ToList();

                Log.InfoFormat("Started Tracking AllenBradley {0} controller(s)", allenBradleyControllers.Count);

                foreach (AllenBradleyController controller in allenBradleyControllers)
                {
                    if (!controller.IsWebPortEnabled)
                    {
                        continue;
                    }
                    ReadFromWebPort(controller);
                    processRollup.Rollup();
                }
            }
            catch (Exception e)
            {
                Log.Error(e);
            }
        }

        public static void ReadFromWebPort(AllenBradleyController controller)
        {
            HistoricalReader historicalReaderList = new HistoricalReader();
            DateTime lastReadTimeStamp;
            var webPortTags = new List<WebPortTags>();
            if (!String.IsNullOrEmpty(controller.WebPortAddress) && !String.IsNullOrEmpty(controller.WebPortUserName) &&
                !String.IsNullOrEmpty(controller.WebPortPassword))
            {
                historicalReaderList.Uri = controller.WebPortAddress;
                historicalReaderList.Username = controller.WebPortUserName;
                historicalReaderList.Password = controller.WebPortPassword;
                historicalReaderList.Timeout = Settings.Default.FtpReadTimeout;
                if (controller.Webportdatetime == DateTime.MinValue)
                {
                    controller.Webportdatetime = DateTime.Now.AddDays(-1);
                }
                lastReadTimeStamp = controller.Webportdatetime;
                try
                {
                    Log.InfoFormat("Webport: Downloading files start time "+ DateTime.Now.ToString());                   
                    historicalReaderList.Read(controller.Webportdatetime, GetLastDownloadFileList(controller)); //Read WebPort Historical Values
                    Log.InfoFormat("Webport: Downloading files end time: "+ DateTime.Now.ToString());
                    DataReaderAccess.UpdateControllerConnectivityAlarm(controller.ControllerId, false, 9002);
                }
                catch (Exception ex)
                {
                    DataReaderAccess.UpdateControllerConnectivityAlarm(controller.ControllerId, true, 9002);
                    Log.Error("Webport Connectivity Error:" + ex.Message);
                }
                List<WebPortReader.WebPortTags> lwebporttags = new List<WebPortReader.WebPortTags>(Reader.m_WebPortTags);
                List<WebPortTags> temp = new List<WebPortTags>();//TODO:Remove this junk
                temp = lwebporttags.Select(tv => new WebPortTags
                {
                    Key = tv.Key.Replace('_', ':'),
                    Value = tv.Value.Value,
                    Timestamp = tv.Value.Timestamp
                }).ToList();

                if (temp.Count != 0)
                {
                    List<DateTime> dateList = new List<DateTime>();
                    foreach (var keys in temp.GroupBy(m => m.Key))
                    {
                        dateList.Add(temp.FindAll(k => k.Key == keys.Key).OrderBy(m => m.Timestamp).Last().Timestamp);
                    }

                    dateList.Sort((a, b) => a.CompareTo(b));
                    lastReadTimeStamp = dateList.First().AddMinutes(-10);
                }

                webPortTags.AddRange(lwebporttags.Select(tv => new WebPortTags
                {
                    Key = tv.Key.Replace('_', ':'),
                    Value = tv.Value.Value,
                    Timestamp = tv.Value.Timestamp.ToUniversalTime()
                }));

                List<WebPortReader.WebPortTags> lbadwebporttags = new List<WebPortReader.WebPortTags>(Reader.m_BadWebPortTags);
                if (lbadwebporttags.Count > 0)
                {
                    lbadwebporttags.Select(x => x.Value.Timestamp).Distinct();
                    for (int count = 0; count < lbadwebporttags.Count(); count++)
                    {
                        Log.InfoFormat("Bad Data Received From WebPort. Tag: {0} and Data: {1}", lbadwebporttags[count].Key, lbadwebporttags[count].Value.Value);
                    }
                    Reader.m_BadWebPortTags.Clear();
                }

                if (webPortTags.Count != 0)
                {
                    RegisterWasher(controller, webPortTags);
                    RegisterNowTags(controller, webPortTags);
                    RegisterModuleTags(controller, webPortTags);
                    CommonDataOperations.UpdateWebportdatetime(controller.ControllerId, lastReadTimeStamp);
                }
            }
        }

        private static void RegisterNowTags(AllenBradleyController controller, List<WebPortTags> webPortTags)
        {            
            var lnowTagValues = GetAlarmTags(controller, webPortTags);

            var groupedNowTagValues =
                lnowTagValues.OrderBy(t => t.TimeStamp).GroupBy(u => u.TimeStamp).Select(grp => new { nowList = grp.ToList() }).ToList();

            for (int p = 0; p < groupedNowTagValues.ToList().Count; p++)
            {
                TagProcessor.ProcessNowTags(groupedNowTagValues[p].nowList, controller);
            }
        }

        private static void RegisterWasher(AllenBradleyController controller, List<WebPortTags> lWebPortTags)
        {
            IEnumerable<Washer> controllerWashersTags = DataReaderAccess.GetActiveWashers(controller.ControllerId);
            IEnumerable<Washer> washersTags = controllerWashersTags as IList<Washer> ?? controllerWashersTags.ToList();
            IEnumerable<Entities.Washer> results =
                washersTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName, p.EndOfFormula, p.AWEAActive, p.RatioDosingActive })
                    .Select(
                        g =>
                            new Entities.Washer
                            {
                                WasherId = g.Key.WasherId,
                                Name = g.Key.WasherName,
                                IsTunnel = g.Key.WasherGroupTypeName == "Tunnel",
                                EndOFFormula = g.Key.EndOfFormula,
                                AWEAActive = g.Key.AWEAActive,
                                RatioDosingActive = g.Key.RatioDosingActive,
                                Tags =
                                    g.Select(
                                        m =>
                                            new OpcTag
                                            {
                                                Address = m.TagAddress,
                                                Topic = m.TopicName,
                                                TagType = m.TagType,
                                                TagId = m.TagId,
                                                TagTypeId = m.TagTypeId
                                            }).ToList<Tag>()
                            });

            Entities.Washer[] enumerable = results as Entities.Washer[] ??
                                  results.ToArray();
            for (int i = 0; i < enumerable.ToList().Count(); i++)
            {
                var lwasherTagValues = new List<OpcTag>(); //To send details in OpcTag Format XML

                Entities.Washer lwasher = new Entities.Washer
                {
                    WasherId = enumerable.ToList()[i].WasherId,
                    IsTunnel = enumerable.ToList()[i].IsTunnel,
                    Tags = enumerable.ToList()[i].Tags,
                    EndOFFormula = enumerable.ToList()[i].EndOFFormula,
                    AWEAActive = enumerable.ToList()[i].AWEAActive,
                    RatioDosingActive = enumerable.ToList()[i].RatioDosingActive
                };
                for (int o = 0; o < lwasher.Tags.ToList().Count; o++)
                {
                    if (lwasher.Tags.ToList()[o].Value == null)
                    {
                        lwasher.Tags.ToList()[o].Value = "0";
                        lwasher.Tags.ToList()[o].Quality = "Good";
                    }
                }

                if (lwasher.IsTunnel)
                {
                    #region <<<Tunnel>>>

                    Queue<WebPortQueueItem> queue = null;
                    if (!QueueList.ContainsKey(lwasher.WasherId))
                    {
                        var webPortQueue = GetWebportTunnelStatus(lwasher.WasherId);
                        QueueList.Add(lwasher.WasherId, webPortQueue);
                    }
                    queue = QueueList[lwasher.WasherId];

                    NoOfCompartments = CommonDataOperations.GetNoOfCompartments(lwasher.WasherId, controller.ControllerId);

                    for (int j = 0; j < enumerable.ToList()[i].Tags.Count(); j++)
                    {
                        for (int k = 0; k < lWebPortTags.Count; k++)
                        {
                            if (lWebPortTags[k].Key == enumerable.ToList()[i].Tags[j].Address)
                            {
                                lwasherTagValues.Add(new OpcTag
                                {
                                    Address = lWebPortTags[k].Key,
                                    Value = lWebPortTags[k].Value,
                                    TimeStamp = lWebPortTags[k].Timestamp,
                                    Topic = controller.TopicName,
                                    TagType = enumerable.ToList()[i].Tags[j].TagType,
                                    TagId = enumerable.ToList()[i].Tags[j].TagId,
                                    IsModified = true,
                                    Quality = "Good"
                                });
                            }
                        }
                    }

                    List<OpcTag> lwasherTagValuesOrderbyTimestamp = lwasherTagValues.OrderBy(p => p.TimeStamp).ToList();

                    foreach (OpcTag tagvalues in lwasherTagValuesOrderbyTimestamp)
                    {
                        if (tagvalues.TagType == "Tag_FRM" || tagvalues.TagType == "Tag_AWEW")
                        {
                            if (tagvalues.TagType == "Tag_FRM" && Convert.ToInt32(tagvalues.Value) == lwasher.EndOFFormula)
                            {
                                continue;
                            }

                            Log.InfoFormat("ControllerId {0} WasherId {1} Address {2} Value {3} TimeStamp {4}", controller.ControllerId, lwasher.WasherId, tagvalues.Address, tagvalues.Value, tagvalues.TimeStamp);
                            DataReaderAccess.ProcessAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId,
                                tagvalues.Address, tagvalues.Value,
                                tagvalues.TimeStamp);
                            Log.InfoFormat("Store Tunnel Washer tags to AllenBradleyArrayQueue {0} {1}", tagvalues.Address, lwasher.WasherId);
                        }
                    }

                    IEnumerable<AllenBradleyXmlTag> getActiveAllenBradleytagsgroup =
                        DataReaderAccess.GetActiveAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId);
                    var allenBradleyTagvalues = new List<OpcTag>();
                    var allenBradleyTagstoDelete = new List<OpcTag>();
                    IEnumerable<AllenBradleyXmlTag> allenBradleyXmlTags = getActiveAllenBradleytagsgroup as IList<AllenBradleyXmlTag> ?? getActiveAllenBradleytagsgroup.ToList();
                    for (int m = 0; m < allenBradleyXmlTags.ToList().Count; m++)
                    {
                        allenBradleyTagvalues.Add(new OpcTag
                        {
                            Address = allenBradleyXmlTags.ToList()[m].TagAddress,
                            Value = allenBradleyXmlTags.ToList()[m].Value,
                            TimeStamp = allenBradleyXmlTags.ToList()[m].DateTimestamp,
                            Topic = controller.TopicName,
                            TagType = allenBradleyXmlTags.ToList()[m].TagType,
                            TagId = 0,
                            IsModified = true,
                            Quality = "Good",
                            LoadId = allenBradleyXmlTags.ToList()[m].LoadId
                        });
                    }

                    var groupedWasherTagValues = allenBradleyTagvalues.OrderBy(x => x.TimeStamp).GroupBy(u => new { u.TimeStamp }).Select(grp => new { washerList = grp.ToList() }).ToList();

                    foreach (var taggrouped in groupedWasherTagValues)
                    {
                        var allenbradleyTempTags = taggrouped.washerList.Select(t => new OpcTag
                        {
                            Address = t.Address,
                            Value = t.Value,
                            TimeStamp = t.TimeStamp,
                            Topic = controller.TopicName,
                            TagType = t.TagType,
                            TagId = 0,
                            IsModified = true,
                            Quality = "Good",
                            LoadId = t.LoadId
                        }).ToList();

                        allenbradleyTempTags.Add(AddTags("Tag_EOF", lwasher.EndOFFormula.ToString(), controller, washersTags,
                                lwasher.WasherId, allenbradleyTempTags[0].TimeStamp));
                        if (allenbradleyTempTags.Count >= 2)
                        {
                            var tagFrm = from m in taggrouped.washerList where m.TagType == "Tag_FRM" select m;
                            if (tagFrm.ToList().Count != 0)
                            {
                                var b = allenbradleyTempTags.Find(m => m.TagType == "Tag_FRM");
                                if (queue.Count >= NoOfCompartments)
                                {
                                    queue.Dequeue();
                                }
                                queue.Enqueue(new WebPortQueueItem { FormulaId = Convert.ToInt32(b.Value), LoadId = b.LoadId, TimeStamp = b.TimeStamp });
                                Tunnel a = ProcessTunnelWasherTags(allenbradleyTempTags, lwasher, queue.Reverse(), NoOfCompartments);
                                string strTunnel = SerializeTunnel(a);
                                int redFlagShiftId = 0;
                                Log.InfoFormat("Processing Tunnel WasherId and XML Data {0} {1}", lwasher.WasherId, strTunnel);
                                redFlagShiftId = DataReaderAccess.ProcessTunnelWasherTags(lwasher.WasherId, strTunnel, redFlagShiftId);

                                try
                                {
                                    if (redFlagShiftId > 0)
                                    {
                                        DataReaderAccess.ProcessRedFlagData(redFlagShiftId);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Error("Error occured while processing Red flag data for Shift: " + redFlagShiftId, ex);
                                }

                                allenBradleyTagstoDelete.AddRange(allenbradleyTempTags.Select(t1 => new OpcTag { Address = t1.Address, Value = t1.Value, TagType = t1.TagType, TimeStamp = t1.TimeStamp }));

                            }
                            else
                            { allenBradleyTagstoDelete.AddRange(allenbradleyTempTags.Select(t1 => new OpcTag { Address = t1.Address, Value = t1.Value, TagType = t1.TagType, TimeStamp = t1.TimeStamp })); }
                        }
                    }
                    foreach (OpcTag tagDelete in allenBradleyTagstoDelete)
                    {
                        DataReaderAccess.ProcessDeleteAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId,
                            tagDelete.Address, tagDelete.Value,
                            tagDelete.TimeStamp, true);
                        Log.InfoFormat("Delete Tunnel Washer tags from AllenBradleyArrayQueue {0} {1}", tagDelete.Address, lwasher.WasherId);
                    }

                    #endregion
                }
                else
                {
                    #region <<<Conv>>>

                    for (int j = 0; j < enumerable.ToList()[i].Tags.Count(); j++)
                    {
                        for (int k = 0; k < lWebPortTags.Count(); k++)
                        {
                            if (lWebPortTags[k].Key == enumerable.ToList()[i].Tags[j].Address)
                            {
                                lwasherTagValues.Add(new OpcTag
                                {
                                    Address = lWebPortTags[k].Key,
                                    Value = lWebPortTags[k].Value,
                                    TimeStamp = lWebPortTags[k].Timestamp,
                                    Topic = controller.TopicName,
                                    TagType = enumerable.ToList()[i].Tags[j].TagType,
                                    TagId = enumerable.ToList()[i].Tags[j].TagId,
                                    IsModified = true,
                                    Quality = "Good"
                                });
                            }
                        }
                    }
                    List<OpcTag> lwasherTagValuesOrderbyTimestamp = lwasherTagValues.OrderBy(p => p.TimeStamp).ToList();

                    foreach (OpcTag tagvalues in lwasherTagValuesOrderbyTimestamp)
                    {
                        if (tagvalues.TagType == "Tag_HOLD" || tagvalues.TagType == "Tag_HOLDL")
                        {
                            //Hold signal so process it seperately and do not insert into the queue
                            DataReaderAccess.ProcessHoldSignal(controller.ControllerId, lwasher.WasherId, tagvalues.Address, tagvalues.Value, tagvalues.TimeStamp);
                            continue;
                        }

                        if(tagvalues.TagType == "Tag_AWEW" && Convert.ToInt32(tagvalues.Value) == 0)
                        {
                            Log.InfoFormat("Received AWEW with zero value even though actual value is received so ignoring {0}", tagvalues.TimeStamp);
                            continue;
                        }

                        if (tagvalues.TagType == "Tag_FRM" &&
                            tagvalues.Value != lwasher.EndOFFormula.ToString())
                        {
                            var addressInj = from m in washersTags
                                             where m.TagType == "Tag_INJ" && m.WasherId == lwasher.WasherId
                                             select m.TagAddress;
                            var addressOpc = from m in washersTags
                                             where m.TagType == "Tag_OPC" && m.WasherId == lwasher.WasherId
                                             select m.TagAddress;
                            DataReaderAccess.ProcessAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId,
                                tagvalues.Address, tagvalues.Value,
                                tagvalues.TimeStamp);
                            DataReaderAccess.ProcessAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId,
                                addressInj.ToList()[0], "0", tagvalues.TimeStamp);
                            DataReaderAccess.ProcessAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId,
                                addressOpc.ToList()[0], "0", tagvalues.TimeStamp);
                        }
                        //Code for handling INJ and OPC reset scenario - start
                        if ((tagvalues.TagType == "Tag_INJ" && tagvalues.Value == "0") || (tagvalues.TagType == "Tag_OPC" && tagvalues.Value == "0"))
                        {
                            //Handling INJ and OPC reset case
                            //Check if there is any alarm at the same timestamp of INJ and OPC reset
                            var lnowTagValues = GetAlarmTags(controller, lWebPortTags);
                            var foundAlarmObj = lnowTagValues.Find(l => l.TimeStamp == tagvalues.TimeStamp && l.TagType == "NowMessage");
                            if (foundAlarmObj != null)
                            {
                                //If there is an alarm at the same timestamp of inj and opc reset
                                //then check if the alarm is a valid for this particulat washer
                                Log.InfoFormat("Webport: INJ/OPC {0} reset and alarm {1} received at the same timestamp {2}", tagvalues.Address, Convert.ToInt32(foundAlarmObj.Value), foundAlarmObj.TimeStamp);
                                int machineInternalId = CommonDataOperations.GetMachineInternalIdByWasherId(lwasher.WasherId);
                                if (!TagProcessor.ValidAlarmToExcludeForInjectionAndOPCReset(machineInternalId, Convert.ToInt32(foundAlarmObj.Value), 1))
                                {
                                    DataReaderAccess.ProcessAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId, tagvalues.Address, tagvalues.Value, tagvalues.TimeStamp);
                                    Log.InfoFormat("Store Conv Washer tags to AllenBradleyArrayQueue {0} {1} {2}", tagvalues.Address, tagvalues.TimeStamp, lwasher.WasherId);
                                }
                                else
                                {
                                    //Received valid alarm at INJ and OPC reset so ignoring them by not inserting to queue.
                                    Log.InfoFormat("Webport: Ignoring INJ/OPC {0} reset because alarm {1} received at the same timestamp {2}", tagvalues.Address, Convert.ToInt32(foundAlarmObj.Value), foundAlarmObj.TimeStamp);
                                }
                            }
                            else
                            {
                                DataReaderAccess.ProcessAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId, tagvalues.Address, tagvalues.Value, tagvalues.TimeStamp);
                                Log.InfoFormat("Store Conv Washer tags to AllenBradleyArrayQueue {0} {1} {2}", tagvalues.Address, tagvalues.TimeStamp, lwasher.WasherId);
                            }
                        }
                        //Code for handling INJ and OPC reset scenario - end
                        else
                        {                            
                            DataReaderAccess.ProcessAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId,
                                tagvalues.Address, tagvalues.Value,
                                tagvalues.TimeStamp);
                            Log.InfoFormat("Store Conv Washer tags to AllenBradleyArrayQueue {0} {1} {2}", tagvalues.Address, tagvalues.TimeStamp, lwasher.WasherId);
                        }
                    }

                    IEnumerable<AllenBradleyXmlTag> getActiveAllenBradleytagsgroup =
                        DataReaderAccess.GetActiveAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId);
                    var allenBradleyTagvalues = new List<OpcTag>();
                    var allenBradleyTagstoDelete = new List<OpcTag>();
                    IEnumerable<AllenBradleyXmlTag> allenBradleyXmlTags = getActiveAllenBradleytagsgroup as IList<AllenBradleyXmlTag> ?? getActiveAllenBradleytagsgroup.ToList();
                    for (int m = 0; m < allenBradleyXmlTags.ToList().Count; m++)
                    {
                        allenBradleyTagvalues.Add(new OpcTag
                        {
                            Address = allenBradleyXmlTags.ToList()[m].TagAddress,
                            Value = allenBradleyXmlTags.ToList()[m].Value,
                            TimeStamp = allenBradleyXmlTags.ToList()[m].DateTimestamp,
                            Topic = controller.TopicName,
                            TagType = allenBradleyXmlTags.ToList()[m].TagType,
                            TagId = 0,
                            IsModified = true,
                            Quality = "Good"
                        });
                    }

                    bool AweaActiveCount = lwasher.AWEAActive;
                    int frmAndAwewTimestampDifference = Convert.ToInt32(Settings.Default.FrmAndAwewTimestampDifference);

                    Log.InfoFormat("Retrived AllenBradley Queue with count {0} for washer {1}", allenBradleyTagvalues.Count, lwasher.WasherId);
                    for (int p = 0; p < allenBradleyTagvalues.Count; p++)
                    {
                        p = 0;
                        if (allenBradleyTagvalues.Count < 2)
                        {
                            break;
                        }
                        //Commented below code, because FRM will be deleted only when next FRM is received
                        //Need to remove this code, once it works fine

                        //if (allenBradleyTagvalues[p].TagType == "Tag_FRM" && allenBradleyTagvalues.Count == 1)
                        //{
                        //    if (allenBradleyTagvalues[p].Value ==
                        //        lwasher.EndOFFormula.ToString())
                        //    {
                        //        //

                        //        var allenBradleyTempTags1 = new List<OpcTag>
                        //        {
                        //            new OpcTag
                        //            {
                        //                Address = allenBradleyTagvalues[p].Address,
                        //                Value = allenBradleyTagvalues[p].Value,
                        //                TimeStamp = allenBradleyTagvalues[p].TimeStamp,
                        //                Topic = controller.TopicName,
                        //                TagType = allenBradleyTagvalues[p].TagType,
                        //                TagId = 0,
                        //                IsModified = true,
                        //                Quality = "Good"
                        //            }
                        //       };
                        //        var addressInj1 = from m in washersTags
                        //                          where m.TagType == "Tag_INJ" && m.WasherId == lwasher.WasherId
                        //                          select m.TagAddress;
                        //        var addressOpc1 = from m in washersTags
                        //                          where m.TagType == "Tag_OPC" && m.WasherId == lwasher.WasherId
                        //                          select m.TagAddress;

                        //        allenBradleyTempTags1.Add(new OpcTag
                        //        {
                        //            Address = addressInj1.ToList()[0],
                        //            Value = "0",
                        //            TimeStamp = allenBradleyTagvalues[0].TimeStamp,
                        //            Topic = controller.TopicName,
                        //            TagType = "Tag_INJ",
                        //            TagId = 0,
                        //            IsModified = true,
                        //            Quality = "Good"
                        //        });
                        //        allenBradleyTempTags1.Add(new OpcTag
                        //        {
                        //            Address = addressOpc1.ToList()[0],
                        //            Value = "0",
                        //            TimeStamp = allenBradleyTagvalues[0].TimeStamp,
                        //            Topic = controller.TopicName,
                        //            TagType = "Tag_OPC",
                        //            TagId = 0,
                        //            IsModified = true,
                        //            Quality = "Good"
                        //        });

                        //        allenBradleyTempTags1.Add(AddTags("Tag_EOF", lwasher.EndOFFormula.ToString(), controller, washersTags,
                        //            lwasher.WasherId, allenBradleyTempTags1[0].TimeStamp));

                        //        if (allenBradleyTempTags1.Count >= 3)
                        //        {
                        //            TagProcessor.ProcessWasherBatchTags(allenBradleyTempTags1, lwasher);

                        //            

                        //            allenBradleyTagstoDelete.Add(new OpcTag
                        //            {
                        //                Address = allenBradleyTagvalues[p].Address,
                        //                Value = allenBradleyTagvalues[p].Value,
                        //                TimeStamp = allenBradleyTagvalues[p].TimeStamp,
                        //                Topic = controller.TopicName,
                        //                TagType = allenBradleyTagvalues[p].TagType,
                        //                TagId = 0,
                        //                IsModified = true,
                        //                Quality = "Good"
                        //            });

                        //        }

                        //        foreach (OpcTag tagTemp in allenBradleyTempTags1)
                        //        {
                        //            allenBradleyTagvalues.RemoveAll(
                        //                x => x.TagType != "Tag_FRM" && x.TimeStamp == tagTemp.TimeStamp);
                        //        }

                        //        //
                        //    }
                        //}

                        var awewTag = new List<OpcTag>();

                        if (AweaActiveCount &&
                            allenBradleyTagvalues.Count() > 2 &&
                            allenBradleyTagvalues[p].TagType == "Tag_FRM" &&
                            allenBradleyTagvalues[p + 1].TagType == "Tag_AWEW" &&
                            allenBradleyTagvalues[p + 2].TagType == "Tag_FRM" &&
                            allenBradleyTagvalues[p + 2].Value != lwasher.EndOFFormula.ToString() &&
                            allenBradleyTagvalues[p + 1].TimeStamp < allenBradleyTagvalues[p + 2].TimeStamp &&
                            (allenBradleyTagvalues[p + 2].TimeStamp - allenBradleyTagvalues[p + 1].TimeStamp).TotalSeconds <= frmAndAwewTimestampDifference)
                        {
                            Log.InfoFormat("AWEW tag {0} received before FRM {1}", allenBradleyTagvalues[p + 1].TimeStamp, allenBradleyTagvalues[p + 2].TimeStamp);
                            awewTag.Add(new OpcTag
                            {
                                Address = allenBradleyTagvalues[p + 1].Address,
                                Value = allenBradleyTagvalues[p + 1].Value,
                                TimeStamp = allenBradleyTagvalues[p + 1].TimeStamp,
                                Topic = controller.TopicName,
                                TagType = allenBradleyTagvalues[p + 1].TagType,
                                TagId = 0,
                                IsModified = true,
                                Quality = "Good"
                            });

                            allenBradleyTagstoDelete.Add(new OpcTag
                            {
                                Address = allenBradleyTagvalues[p].Address,
                                Value = allenBradleyTagvalues[p].Value,
                                TagType = allenBradleyTagvalues[p].TagType,
                                TimeStamp = allenBradleyTagvalues[p].TimeStamp
                            });
                            allenBradleyTagvalues.RemoveAt(p);

                            allenBradleyTagstoDelete.Add(new OpcTag
                            {
                                Address = allenBradleyTagvalues[p].Address,
                                Value = allenBradleyTagvalues[p].Value,
                                TagType = allenBradleyTagvalues[p].TagType,
                                TimeStamp = allenBradleyTagvalues[p].TimeStamp
                            });
                            allenBradleyTagvalues.RemoveAt(p);
                        }

                        if (allenBradleyTagvalues[p].TagType == "Tag_FRM" && allenBradleyTagvalues.Count > 1 && allenBradleyTagvalues[p + 1].TagType != "Tag_FRM")
                        {
                            var allenBradleyTempTags = new List<OpcTag>
                            {
                                new OpcTag
                                {
                                    Address = allenBradleyTagvalues[p].Address,
                                    Value = allenBradleyTagvalues[p].Value,
                                    TimeStamp = allenBradleyTagvalues[p].TimeStamp,
                                    Topic = controller.TopicName,
                                    TagType = allenBradleyTagvalues[p].TagType,
                                    TagId = 0,
                                    IsModified = true,
                                    Quality = "Good"
                                }
                            };
                            for (int q = p + 1; q < allenBradleyTagvalues.Count; q++)
                            {
                                if (allenBradleyTagvalues[q].TagType == "Tag_FRM")
                                {
                                    break;
                                }

                                for (int r = 0; r < allenBradleyTempTags.Count; r++)
                                {
                                    int q1 = q;
                                    var query =
                                        allenBradleyTempTags.Where(k => k.TagType == allenBradleyTagvalues[q1].TagType);
                                    if (query.ToList().Count == 0)
                                    {
                                        if (allenBradleyTempTags.Count > 1)
                                        {
                                            if (allenBradleyTempTags[1].TimeStamp == allenBradleyTagvalues[q].TimeStamp)
                                            {
                                                allenBradleyTempTags.Add(new OpcTag
                                                {
                                                    Address = allenBradleyTagvalues[q].Address,
                                                    Value = allenBradleyTagvalues[q].Value,
                                                    TimeStamp = allenBradleyTagvalues[q].TimeStamp,
                                                    Topic = controller.TopicName,
                                                    TagType = allenBradleyTagvalues[q].TagType,
                                                    TagId = 0,
                                                    IsModified = true,
                                                    Quality = "Good"
                                                });
                                            }
                                            if (AweaActiveCount &&
                                               allenBradleyTagvalues[q].TagType == "Tag_AWEW" &&
                                               allenBradleyTagvalues[q].TimeStamp > allenBradleyTempTags[1].TimeStamp &&
                                               (allenBradleyTagvalues[q].TimeStamp - allenBradleyTempTags[1].TimeStamp).TotalSeconds <= frmAndAwewTimestampDifference)
                                            {
                                                //Add AWEW if it is received after formula timestamp
                                                Log.InfoFormat("AWEW {0} received after FRM {1}", allenBradleyTagvalues[q].TimeStamp, allenBradleyTempTags[1].TimeStamp);
                                                allenBradleyTempTags.Add(new OpcTag
                                                {
                                                    Address = allenBradleyTagvalues[q].Address,
                                                    Value = allenBradleyTagvalues[q].Value,
                                                    TimeStamp = allenBradleyTagvalues[q].TimeStamp,
                                                    Topic = controller.TopicName,
                                                    TagType = allenBradleyTagvalues[q].TagType,
                                                    TagId = 0,
                                                    IsModified = true,
                                                    Quality = "Good"
                                                });
                                            }
                                        }
                                        else
                                        {
                                            ////Start - Code for if inj and opc of EOF are downloaded first iteration
                                            ////and then in the second iteration EOF formula is received
                                            ////so not mapping this opc and inj with the actual formula
                                            Log.InfoFormat("Adding INJ/OPC to the FRM");
                                            allenBradleyTempTags.Add(new OpcTag
                                            {
                                                Address = allenBradleyTagvalues[q].Address,
                                                Value = allenBradleyTagvalues[q].Value,
                                                TimeStamp = allenBradleyTagvalues[q].TimeStamp,
                                                Topic = controller.TopicName,
                                                TagType = allenBradleyTagvalues[q].TagType,
                                                TagId = 0,
                                                IsModified = true,
                                                Quality = "Good"
                                            });
                                        }
                                        break;
                                    }
                                }
                            }

                            var isAwewPresent = allenBradleyTempTags.Find(l => l.TagType == "Tag_AWEW");
                            if (AweaActiveCount && isAwewPresent == null)
                            {
                                //Add AWEW if it is received before formula timestamp.
                                int intOpc = -1;
                                int intInj = -1;
                                var opc = allenBradleyTempTags.Find(l => l.TagType == "Tag_OPC");
                                var inj = allenBradleyTempTags.Find(l => l.TagType == "Tag_INJ");

                                if (opc != null)
                                {
                                    intOpc = int.Parse(allenBradleyTempTags.Find(l => l.TagType == "Tag_OPC").Value);
                                }
                                if (inj != null)
                                {
                                    intInj = int.Parse(allenBradleyTempTags.Find(l => l.TagType == "Tag_INJ").Value);
                                }

                                if (intOpc == 0 && intInj == 0 && awewTag.Count > 0 && allenBradleyTagvalues[p].Value != lwasher.EndOFFormula.ToString())
                                {
                                    Log.InfoFormat("AWEW {0} received FRM and adding to the FRM", awewTag[0].TimeStamp);
                                    allenBradleyTempTags.Add(new OpcTag
                                    {
                                        Address = awewTag[0].Address,
                                        Value = awewTag[0].Value,
                                        TimeStamp = awewTag[0].TimeStamp,
                                        Topic = controller.TopicName,
                                        TagType = awewTag[0].TagType,
                                        TagId = 0,
                                        IsModified = true,
                                        Quality = "Good"
                                    });
                                }
                            }

                            if (AweaActiveCount)
                            {
                                //For the starting signal, check if we received AWEW or not from PLC, even though AWEA is enabled.
                                //AWEW is considered only while starting the batch means the timestamp of FRM, OPC=0 and INJ=0
                                //should be same as AWEW, if not ignore AWEW (if it is different time stamp)
                                //If next injection or formula is present then form the signal with manual AWEW and then insert the batch
                                int intOpc = -1;
                                int intInj = -1;
                                var opc = allenBradleyTempTags.Find(l => l.TagType == "Tag_OPC");
                                var inj = allenBradleyTempTags.Find(l => l.TagType == "Tag_INJ");

                                if (opc != null)
                                {
                                    intOpc = int.Parse(allenBradleyTempTags.Find(l => l.TagType == "Tag_OPC").Value);
                                }
                                if (inj != null)
                                {
                                    intInj = int.Parse(allenBradleyTempTags.Find(l => l.TagType == "Tag_INJ").Value);
                                }

                                if (intOpc == 0 && intInj == 0)
                                {
                                    var tagsToVerify = new List<OpcTag>();
                                    bool nextFrmFound = false;
                                    var nextInjFound = false;

                                    for (int counter = allenBradleyTempTags.Count; counter < allenBradleyTagvalues.Count; counter++)
                                    {
                                        if (allenBradleyTagvalues[counter].TagType == "Tag_FRM")
                                        {
                                            nextFrmFound = true;
                                            break;
                                        }
                                        tagsToVerify.Add(new OpcTag { Address = allenBradleyTagvalues[counter].Address, Value = allenBradleyTagvalues[counter].Value, TimeStamp = allenBradleyTagvalues[counter].TimeStamp, Topic = controller.TopicName, TagType = allenBradleyTagvalues[counter].TagType, TagId = 0, IsModified = true, Quality = "Good" });
                                    }

                                    var isAwew = allenBradleyTempTags.Find(l => l.TagType == "Tag_AWEW");

                                    if (tagsToVerify.Count > 0 &&
                                        (tagsToVerify.Find(l => l.TagType == "Tag_OPC") != null || tagsToVerify.Find(l => l.TagType == "Tag_INJ") != null))
                                    {
                                        nextInjFound = true;
                                    }

                                    if (isAwew == null && (nextInjFound || nextFrmFound))
                                    {
                                        //AWEW is not received from PLC even though AWEA is enabled. So adding AWEW as zero manually. 
                                        Log.InfoFormat("AWEW is not received from PLC even though AWEA is enabled, So adding zero to the FRM {0}", allenBradleyTempTags[p].TimeStamp);
                                        allenBradleyTempTags.Add(AddTags("Tag_AWEW", "0", controller, washersTags,
                                                                   lwasher.WasherId, allenBradleyTempTags[p].TimeStamp));
                                    }
                                }
                            }

                            int minBatchCount;

                            if (AweaActiveCount)
                            {
                                minBatchCount = 4;
                                if (!IsNotNewFormula(allenBradleyTempTags, lwasher.EndOFFormula))
                                {
                                    minBatchCount = 3;
                                }
                            }
                            else
                            {
                                minBatchCount = 3;
                            }

                            if (allenBradleyTempTags.Count >= minBatchCount)
                            {
                                allenBradleyTempTags.Add(AddTags("Tag_EOF", lwasher.EndOFFormula.ToString(), controller, washersTags,
                                lwasher.WasherId, allenBradleyTempTags[0].TimeStamp));

                                if (AweaActiveCount)
                                {
                                    string address = null;
                                    for (int j = 0; j < enumerable.ToList()[i].Tags.Count(); j++)
                                    {
                                        if (enumerable.ToList()[i].Tags[j].TagType == "Tag_AWEA")
                                        {
                                            address = enumerable.ToList()[i].Tags[j].Address;
                                        }

                                    }
                                    if (address != null)
                                    {
                                        allenBradleyTempTags.Add(new OpcTag { Address = address, Value = "1", TimeStamp = allenBradleyTempTags[p].TimeStamp, Topic = controller.TopicName, TagType = "Tag_AWEA", TagId = 0, IsModified = true, Quality = "Good" });
                                    }
                                }

                                var frm = allenBradleyTempTags.Find(l => l.TagType == "Tag_FRM");
                                var inj = allenBradleyTempTags.Find(l => l.TagType == "Tag_INJ");
                                var opc = allenBradleyTempTags.Find(l => l.TagType == "Tag_OPC");

                                if (frm != null && inj != null && opc != null)
                                {
                                    Log.InfoFormat("Calling stored procedure for inserting/updating batch");
                                    TagProcessor.ProcessWasherBatchTags(allenBradleyTempTags, lwasher);
                                }
                                foreach (OpcTag tags in allenBradleyTempTags)
                                {
                                    bool check = false;
                                    if (allenBradleyTagstoDelete.Count == 0 &&
                                        tags.TagType != "Tag_FRM")
                                    {
                                        allenBradleyTagstoDelete.Add(new OpcTag
                                        {
                                            Address = tags.Address,
                                            Value = tags.Value,
                                            TagType = tags.TagType,
                                            TimeStamp = tags.TimeStamp
                                        });
                                    }
                                    else
                                    {
                                        if (allenBradleyTagstoDelete.Any(t => tags.Address == t.Address &&
                                                                               tags.Value == t.Value &&
                                                                               tags.TagType == t.TagType &&
                                                                               tags.TimeStamp ==
                                                                               t.TimeStamp &&
                                                                               tags.TagType != "Tag_FRM"))
                                        {
                                            check = true;
                                        }
                                        if (check == false && tags.TagType != "Tag_FRM")
                                        {
                                            allenBradleyTagstoDelete.Add(new OpcTag
                                            {
                                                Address = tags.Address,
                                                Value = tags.Value,
                                                TagType = tags.TagType,
                                                TimeStamp = tags.TimeStamp
                                            });
                                        }
                                    }
                                }
                            }

                            foreach (OpcTag tagTemp in allenBradleyTempTags)
                            {
                                allenBradleyTagvalues.RemoveAll(
                                    x => x.TagType != "Tag_FRM" && x.TimeStamp == tagTemp.TimeStamp);
                            }
                        }
                        else
                        {
                            allenBradleyTagstoDelete.Add(new OpcTag
                            {
                                Address = allenBradleyTagvalues[p].Address,
                                Value = allenBradleyTagvalues[p].Value,
                                TagType = allenBradleyTagvalues[p].TagType,
                                TimeStamp = allenBradleyTagvalues[p].TimeStamp
                            });
                            allenBradleyTagvalues.RemoveAt(p);
                        }
                    }
                    foreach (OpcTag tagDelete in allenBradleyTagstoDelete)
                    {
                        DataReaderAccess.ProcessDeleteAllenBradleyArrayQueue(controller.ControllerId, lwasher.WasherId,
                            tagDelete.Address, tagDelete.Value,
                            tagDelete.TimeStamp, false);
                        Log.InfoFormat("Delete Conv Washer tags from AllenBradleyArrayQueue {0} {1} {2}", tagDelete.Address, tagDelete.TimeStamp, lwasher.WasherId);
                    }

                    #endregion
                }
            }
        }

        private static bool IsNotNewFormula(List<OpcTag> lopcTagvalues, int endOfFormula)
        {
            if (lopcTagvalues.Count < 3)
            {
                return true;
            }

            int formula = -1;
            int opc = -1;
            int inj = -1;

            var opcData = lopcTagvalues.Find(l => l.TagType == "Tag_OPC");
            var injData = lopcTagvalues.Find(l => l.TagType == "Tag_INJ");

            if (opcData != null && injData != null)
            {
                formula = int.Parse(lopcTagvalues.Find(l => l.TagType == "Tag_FRM").Value);
                opc = int.Parse(lopcTagvalues.Find(l => l.TagType == "Tag_OPC").Value);
                inj = int.Parse(lopcTagvalues.Find(l => l.TagType == "Tag_INJ").Value);
            }
            return (formula != endOfFormula && opc == 0 && inj == 0);
        }

        private static string SerializeTunnel(Tunnel tunnel)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Tunnel));
            StringWriter stringWriter = new StringWriter();
            using (XmlWriter xmlWriter = new XmlTextWriter(stringWriter))
            {
                xmlSerializer.Serialize(xmlWriter, tunnel);
                return stringWriter.ToString();
            }
        }

        private static Tunnel ProcessTunnelWasherTags(IEnumerable<Tag> tags, Entities.Washer washer, IEnumerable<WebPortQueueItem> items, int numberOfComp)
        {
            IEnumerable<Tag> enumerable = tags as IList<Tag> ?? tags.ToList();
            var opcTags = tags as Tag[] ?? enumerable.ToArray();
            Tunnel tunnel = new Tunnel
            {
                Id = washer.WasherId,
                CurrentFormula = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").Value) : 0,
                CurrentInjection = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_INJ") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_INJ").Value) : 0,
                CurrentOperationCounter = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_OPC") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_OPC").Value) : 0,
                Eof = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_EOF") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_EOF").Value) : 0,
                OnHold = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_HOLDL") && opcTags.First(t => t.TagType != null && t.TagType == "Tag_HOLDL").Value != "0",

                TimeStamp = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") ? opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").TimeStamp : DateTime.Now,
                IsFormulaModified = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") && enumerable.Where(opcTag => opcTag.TagType != null && opcTag.TagType == "Tag_FRM").Any(opcTag => opcTag.IsModified),
                IsHoldSignalModified = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_HOLDL") && enumerable.Where(opcTag => opcTag.TagType != null && opcTag.TagType == "Tag_HOLDL").Any(opcTag => opcTag.IsModified)
            };
            if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_AWEA"))
            {
                tunnel.Awea = Convert.ToBoolean(opcTags.First(t => t.TagType == "Tag_AWEA").Value);
                tunnel.Awew = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_AWEW").Value);
            }
            if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_RATA"))
            {
                tunnel.RATA = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_RATA").Value);
            }

            var compartments = new List<Compartment>();
            var a = items.ToList();
            int n = 0;

            while (n < numberOfComp)
            {
                if (a.Count < numberOfComp)
                {
                    a.Add(new WebPortQueueItem { FormulaId = 0, LoadId = 0, TimeStamp = a[0].TimeStamp });
                }
                n++;
            }

            for (int i = 0; i < numberOfComp; i++)
            {
                compartments.Add(
                    new Compartment
                    {
                        CompartmentId = i + 1,
                        FormulaId = a[i].FormulaId,
                        LoadId = a[i].LoadId,
                        TimeStamp = a[i].TimeStamp
                    });
            }
            tunnel.Comparments = compartments;
            return tunnel;
        }

        private static OpcTag AddTags(string tagType, string value, AllenBradleyController controller,
            IEnumerable<Washer> controllerWashersTags, int washerId, DateTime timestamp)
        {
            OpcTag tagsList = new OpcTag
            {
                TagType = tagType,
                Topic = controller.TopicName,
                Quality = "Good",
                Value = value,
                ServerHandle = 0,
                IsModified = true,
                TimeStamp = timestamp
            };
            var address = from m in controllerWashersTags
                          where m.TagType == tagType && m.WasherId == washerId
                          select m.TagAddress;
            tagsList.Address = address.ToList()[0];
            return tagsList;
        }

        private static List<OpcTag> UpdateTunnelTags(List<OpcTag> list, string topicName, int noOfCompartments)
        {
            for (int i = 0; i < noOfCompartments; i++)
            {
                var check = list.FindAll(m => m.Address == (string.Format("N7:{0}", 60 + i)));
                var check2 = list.FindAll(m => m.Address == (string.Format("N7:{0}", 80 + i)));

                if (check.ToList().Count == 0)
                {
                    list.Add(new OpcTag
                    {
                        Address = string.Format("N7:{0}", 60 + i),
                        TagType = string.Format("Formula_Mod_{0}", i + 1),
                        Topic = topicName,
                        Quality = "Good",
                        Value = "0"
                    });
                }

                if (check2.ToList().Count == 0)
                {
                    list.Add(new OpcTag
                    {
                        Address = string.Format("N7:{0}", 80 + i),
                        TagType = string.Format("Load_Mod_{0}", i + 1),
                        Topic = topicName,
                        Quality = "Good",
                        Value = "0"
                    });
                }
            }

            return list;
        }

        private static void RegisterModuleTags(AllenBradleyController controller, List<WebPortTags> webPortTags)
        {
            IEnumerable<ModuleTag> moduleTags = DataReaderAccess.GetActiveModuleTags(controller.ControllerId);
            IEnumerable<Module> results =
                moduleTags.GroupBy(
                    p =>
                        new
                        {
                            p.ModuleId,
                            p.ModuleTypeId,
                            p.DeadBand,
                            p.Unit,
                            RollOverPoint = p.Rolloverpoint,
                            p.Calibration,
                            p.UtilityType
                        })
                    .Select(
                        g =>
                            new Module
                            {
                                ModuleId = g.Key.ModuleId,
                                ModuleTypeId = g.Key.ModuleTypeId,
                                Deadband = g.Key.DeadBand,
                                Unit = g.Key.Unit,
                                RollOverPoint = g.Key.RollOverPoint,
                                Calibration = g.Key.Calibration,
                                UtilityType = g.Key.UtilityType,
                                Tags =
                                    g.Select(
                                        m =>
                                            new OpcTag
                                            {
                                                Address = m.TagAddress,
                                                Topic = m.TopicName,
                                                TagType = m.TagType,
                                                TagTypeId = m.TagTypeId,
                                                TagId = m.ModuleTagId
                                            }).ToList<Tag>()
                            });
            Module[] enumerable = results as Module[] ?? results.ToArray();
            for (int i = 0; i < enumerable.ToList().Count(); i++)
            {
                var lmoduleTagValues = new List<OpcTag>(); //To send details in OpcTag Format XML

                Module lmodule = new Module
                {
                    ModuleId = enumerable.ToList()[i].ModuleId,
                    Unit = enumerable.ToList()[i].Unit,
                    Calibration = enumerable.ToList()[i].Calibration,
                    UtilityType = enumerable.ToList()[i].UtilityType,
                    ModuleTypeId = enumerable.ToList()[i].ModuleTypeId,
                    RollOverPoint = enumerable.ToList()[i].RollOverPoint
                };

                for (int j = 0; j < enumerable.ToList()[i].Tags.Count(); j++)
                {
                    for (int k = 0; k < webPortTags.Count; k++)
                    {
                        if (webPortTags[k].Key == enumerable.ToList()[i].Tags[j].Address)
                        {
                            lmoduleTagValues.Add(new OpcTag
                            {
                                Address = webPortTags[k].Key,
                                Value = webPortTags[k].Value,
                                TimeStamp = webPortTags[k].Timestamp,
                                Topic = controller.TopicName,
                                TagType = enumerable.ToList()[i].Tags[j].TagType,
                                TagId = enumerable.ToList()[i].Tags[j].TagId,
                                IsModified = true,
                                Quality = "Good"
                            });
                        }
                    }
                }
                //Grouping based on timestamp and inserting the data
                var groupedModuleTagValues =
                    lmoduleTagValues.GroupBy(u => u.TimeStamp).Select(grp => new { moduleList = grp.ToList() }).ToList();
                for (int p = 0; p < groupedModuleTagValues.ToList().Count; p++)
                {
                    TagProcessor.ProcessModuleTags(groupedModuleTagValues[p].moduleList, lmodule);
                }
            }
        }

        public class WebPortTags
        {
            internal string Key { get; set; }
            internal string Value { get; set; }
            internal DateTime Timestamp { get; set; }
        }

        public class WebPortQueueItem
        {
            public int FormulaId { get; set; }
            public int LoadId { get; set; }
            public DateTime TimeStamp { get; set; }
        }

        /// <summary>
        ///     GetWebportTunnelStatus
        /// </summary>
        /// <param name="washerId">fetching data through washer id</param>
        /// <returns>returns a list.</returns>
        public static Queue<WebPortQueueItem> GetWebportTunnelStatus(int washerId)
        {
            var compartments = DataReaderAccess.GetTunnelStatus(washerId);
            Queue<WebPortQueueItem> queue = new Queue<WebPortQueueItem>();
            foreach (var comp in compartments.Reverse())
            {
                queue.Enqueue(new WebPortQueueItem
                {
                    FormulaId = comp.ProgramNumber,
                    LoadId = comp.ControllerBatchId,
                    TimeStamp = comp.StartTime
                });
            }
            return queue;
        }

        /// <summary>
        ///     GetAlarmTags
        /// </summary>
        /// <param name="controller">Controller object</param>
        /// <param name="webPortTags">webPortTags list</param>
        /// <returns>returns a list.</returns>
        private static List<OpcTag> GetAlarmTags(AllenBradleyController controller, List<WebPortTags> webPortTags)
        {           
            var tags = new List<OpcTag>
            {
                new OpcTag { Address = Settings.Default.ABAddress1NowMessage, TagType = "NowMessage", Topic = controller.TopicName }, //N7:150
                new OpcTag { Address = Settings.Default.ABAddress2NowWasher, TagType = "NowWasher", Topic = controller.TopicName  }, //N9:183
                new OpcTag { Address = Settings.Default.ABAddress3NowFormula, TagType = "NowFormula", Topic = controller.TopicName }, //N9:181
                new OpcTag { Address = Settings.Default.ABAddress4NowValve, TagType = "NowValve", Topic = controller.TopicName } // Conventional Only      //N9:191    
            };
            var lnowTagValues = new List<OpcTag>();
            for (int i = 0; i < tags.Count; i++)
            {
                for (int k = 0; k < webPortTags.Count; k++)
                {
                    if (webPortTags[k].Key == tags.ToList()[i].Address)
                    {
                        lnowTagValues.Add(new OpcTag
                        {
                            Address = webPortTags[k].Key,
                            Value = webPortTags[k].Value,
                            TimeStamp = webPortTags[k].Timestamp,
                            TagId = tags.ToList()[i].TagId,
                            TagType = tags.ToList()[i].TagType,
                            TagTypeId = tags.ToList()[i].TagTypeId,
                            Topic = controller.TopicName,
                            IsModified = true,
                            Quality = "Good"
                        });
                    }
                }
            }
            return lnowTagValues;
        }

        /// <summary>
        ///     GetWasherAWEWTagList
        /// </summary>
        /// <param name="controller">Controller object</param>
        /// <returns>returns a AWEW tag list.</returns>
        private static List<string> GetLastDownloadFileList(AllenBradleyController controller)
        {
            List<string> lastDownloadFileList = new List<string>();
            IEnumerable<Washer> controllerWashersTags = DataReaderAccess.GetActiveWashers(controller.ControllerId);
            IEnumerable<Washer> washersTags = controllerWashersTags as IList<Washer> ?? controllerWashersTags.ToList();
            IEnumerable<Entities.Washer> results =
                washersTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName, p.EndOfFormula, p.AWEAActive, p.RatioDosingActive })
                    .Select(
                        g =>
                            new Entities.Washer
                            {
                                WasherId = g.Key.WasherId,
                                Name = g.Key.WasherName,
                                IsTunnel = g.Key.WasherGroupTypeName == "Tunnel",
                                EndOFFormula = g.Key.EndOfFormula,
                                AWEAActive = g.Key.AWEAActive,
                                RatioDosingActive = g.Key.RatioDosingActive,
                                Tags =
                                    g.Select(
                                        m =>
                                            new OpcTag
                                            {
                                                Address = m.TagAddress,
                                                Topic = m.TopicName,
                                                TagType = m.TagType,
                                                TagId = m.TagId,
                                                TagTypeId = m.TagTypeId
                                            }).ToList<Tag>()
                            });

            Entities.Washer[] enumerable = results as Entities.Washer[] ??
                                  results.ToArray();

            for (int i = 0; i < enumerable.ToList().Count(); i++)
            {
                var lwasherTagValues = new List<OpcTag>(); //To send details in OpcTag Format XML

                Entities.Washer lwasher = new Entities.Washer
                {
                    WasherId = enumerable.ToList()[i].WasherId,
                    IsTunnel = enumerable.ToList()[i].IsTunnel,
                    Tags = enumerable.ToList()[i].Tags,
                    EndOFFormula = enumerable.ToList()[i].EndOFFormula,
                    AWEAActive = enumerable.ToList()[i].AWEAActive,
                    RatioDosingActive = enumerable.ToList()[i].RatioDosingActive
                };
                for (int o = 0; o < lwasher.Tags.ToList().Count; o++)
                {
                    if (lwasher.Tags.ToList()[o].TagType == "Tag_AWEW")
                    {
                        string address = lwasher.Tags.ToList()[o].Address;
                        if (address.Contains(":"))
                        {
                            address = address.Replace(':', '_');
                        }
                        lastDownloadFileList.Add(WebPortPlcTagFilenamePrefix+address+ WebPortPlcTagFileExtension);
                    }
                }
            }
            lastDownloadFileList.Add(WebPortPlcTagFilenamePrefix+Settings.Default.ABAddress1NowMessage.Replace(':', '_')+ WebPortPlcTagFileExtension);
            return lastDownloadFileList;
        }      
        }
}