﻿// -----------------------------------------------------------------------
// <copyright file="OpcService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The OpcService </summary>
// -----------------------------------------------------------------------

using DbEntities = Entities.DataReader;
using Washer = Entities.DataReader.Washer;

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Timers;
    using Access.DataReader;
    using CollectData.Opc;
    using Ecolab.Dcs.CollectData;
    using Entities;
    using global::Entities.DataReader;
    using log4net;
    using Properties;
    using Timer = System.Timers.Timer;
    using Washer = Washer;

    public class OpcService
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(OpcService));
        private static readonly string MOpcItemFormat = Settings.Default.OpcItemFormat;
        private readonly List<OpcDataReader> mAllenBradleyDataReaders = new List<OpcDataReader>();
        private IDictionary<int, OPCServerStatus> OpcAvailabilityStatus;
        private List<AllenBradleyController> mControllers;
        private List<Entities.Washer> failedWasherList = new List<Entities.Washer>();
        private List<Entities.Module> failedModuleList = new List<Entities.Module>();

        Timer aTimer;

        public OpcService(List<AllenBradleyController> controllers)
        {
            mControllers = controllers;

            aTimer = new Timer(Int32.Parse(Settings.Default.TableChangeInterval));
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            aTimer.Enabled = true;
        }

        private void OPcServerShutDown(int controllerId,string reason)
        {
            OPCServerStatus opcStatus= OpcAvailabilityStatus[controllerId];
            opcStatus.IsServerAvailable = false;
            opcStatus.ShutDownReason = reason;
            Log.InfoFormat("RS Linx Shutdown Event occurred for AllenBradley {0} reason : {1}", controllerId, reason);
        }
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            Log.Info("Started Executing Timer part");
            IEnumerable<DbEntities.Controller> dbControllers = DataReaderAccess.GetActiveControllers();
            List<Entities.Controller> controllers = dbControllers.Select(EntityConverter.Convert).ToList();
            mControllers =
                controllers.FindAll(c => c is AllenBradleyController).Select(c => (AllenBradleyController)c).ToList();

            OPCServerStatus opcStatus;
            foreach (AllenBradleyController tController in mControllers)
            {
                DateTime changeTime = DateTime.UtcNow;
                DateTime operationTimeStamp = CommonDataOperations.GetControllerOperationTimestamp(tController.ControllerId);
                if (!OpcAvailabilityStatus.ContainsKey(tController.ControllerId))
                {
                    OpcAvailabilityStatus.Add(tController.ControllerId, new OPCServerStatus(false));
                }
                opcStatus = OpcAvailabilityStatus[tController.ControllerId];


                if (operationTimeStamp.AddSeconds(30) > changeTime || !opcStatus.IsServerAvailable)
                {
                    Log.Info("Change in controller" + tController);
                    DeRegisterConrollerEntity(tController.ControllerId);
                    RegisterNowTags(tController);
                    RegisterModuleTags(tController);
                    RegisterWashers(tController);
                    opcStatus.IsServerAvailable = true;
                }

                IEnumerable<Washer> controllerWashersTags = DataReaderAccess.GetActiveWashers(tController.ControllerId);
                IEnumerable<Washer> washersTags = controllerWashersTags as IList<Washer> ?? controllerWashersTags.ToList();

                IEnumerable<Entities.Washer> resultsTemp = washersTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName,p.ETechWasherNumber,p.AWEAActive }).Select(g => new Entities.Washer
                {
                    WasherId = g.Key.WasherId,
                    Name = g.Key.WasherName,
                    IsTunnel = g.Key.WasherGroupTypeName == "Tunnel", //TODO:Need to get this property from database.
                    ETechWasherNumber = g.Key.ETechWasherNumber,
                    AWEAActive = g.Key.AWEAActive,
                    Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.TagId }).ToList<Tag>()
                });

                foreach (Entities.Washer washer in resultsTemp)
                {
                    changeTime = DateTime.UtcNow;
                    operationTimeStamp = CommonDataOperations.GetWasherOperationTimestamp(tController.ControllerId, washer.WasherId);
                    if (operationTimeStamp.AddSeconds(30) > changeTime)
                    {
                        Log.Info("Change in Washer" + washer.WasherId);
                        DeRegisterEntity(tController.ControllerId, washer.Name + "_" + washer.WasherId, "washer");
                        RegisterWashersNew(tController, washersTags, washer.WasherId);
                    }
                }

                //for (int j = 0; j < washersTags.ToList().Count; j++)
                //{
                //    changeTime = DateTime.UtcNow;
                //    operationTimeStamp = CommonDataOperations.GetWasherOperationTimeStamp(tController.ControllerId, washersTags.ToList()[j].WasherId);
                //    if (operationTimeStamp.AddSeconds(30) > changeTime)
                //    {
                //        Log.Info("Change in Washer" + washersTags.ToList()[j].WasherId);
                //        RegisterWashersNew(tController, washersTags, washersTags.ToList()[j].WasherId);
                //    }
                //}

                IEnumerable<ModuleTag> moduleTags = DataReaderAccess.GetActiveModuleTags(tController.ControllerId);
                IEnumerable<ModuleTag> modulesTags = moduleTags as IList<ModuleTag> ?? moduleTags.ToList();
                for (int j = 0; j < modulesTags.ToList().Count; j++)
                {
                    changeTime = DateTime.UtcNow;
                    if (modulesTags.ToList()[j].ModuleDescription == "Tank")
                    {
                        operationTimeStamp = CommonDataOperations.GetTankOperationTimestamp(tController.ControllerId, modulesTags.ToList()[j].ModuleId);
                        if (operationTimeStamp.AddSeconds(30) > changeTime)
                        {
                            Log.Info("Change in Tanks" + modulesTags.ToList()[j].ModuleId);
                            DeRegisterEntity(tController.ControllerId, modulesTags.ToList()[j].ModuleId + string.Empty + modulesTags.ToList()[j].ModuleTypeId + "Module_", "module");
                            RegisterModuleTagsNew(tController, modulesTags.ToList(), modulesTags.ToList()[j].ModuleId);
                        }
                    }
                    else if (modulesTags.ToList()[j].ModuleDescription == "Meter")
                    {
                        operationTimeStamp = CommonDataOperations.GetMeterOperationTimestamp(tController.ControllerId, modulesTags.ToList()[j].ModuleId);
                        if (operationTimeStamp.AddSeconds(30) > changeTime)
                        {
                            Log.Info("Change in Meters" + modulesTags.ToList()[j].ModuleId);
                            DeRegisterEntity(tController.ControllerId, modulesTags.ToList()[j].ModuleId + string.Empty + modulesTags.ToList()[j].ModuleTypeId + "Module_", "module");
                            RegisterModuleTagsNew(tController, modulesTags.ToList(), modulesTags.ToList()[j].ModuleId);
                        }
                    }
                    else
                    {
                        operationTimeStamp = CommonDataOperations.GetSensorOperationTimestamp(tController.ControllerId, modulesTags.ToList()[j].ModuleId);
                        if (operationTimeStamp.AddSeconds(30) > changeTime)
                        {
                            Log.Info("Change in Sensors" + modulesTags.ToList()[j].ModuleId);
                            DeRegisterEntity(tController.ControllerId, modulesTags.ToList()[j].ModuleId + string.Empty + modulesTags.ToList()[j].ModuleTypeId + "Module_", "module");
                            RegisterModuleTagsNew(tController, modulesTags.ToList(), modulesTags.ToList()[j].ModuleId);
                        }
                    }
                }
            }
            Thread.Sleep(10000);
        }

        public void Start()
        {
            Log.InfoFormat("Started Tracking AllenBradley {0} controller(s)", mControllers.Count);
            OpcAvailabilityStatus = new Dictionary<int, OPCServerStatus>();

            foreach (AllenBradleyController controller in mControllers)
            {
                OpcAvailabilityStatus.Add(controller.ControllerId,  new OPCServerStatus(false));

                RegisterNowTags(controller);
                RegisterModuleTags(controller);
                RegisterWashers(controller);
                OpcAvailabilityStatus[controller.ControllerId].IsServerAvailable = true;

            }
        }

        private void RegisterWashers(AllenBradleyController controller)
        {
            Log.Info("WebPort not enabled using OPC DA -> " + controller);
            if (string.IsNullOrEmpty(controller.OpcServer))
            {
                Log.Error("OPC Server not defined. Unable to connect");
                return;
            }
            Log.Info("Strated reading values from OPC -> " + controller);
            OpcDataReader.NotifyShutDown shutDownHandler = new OpcDataReader.NotifyShutDown(OPcServerShutDown);
            OpcDataReader allenBradleyDataReader = new OpcDataReader(controller, MOpcItemFormat, shutDownHandler);
            allenBradleyDataReader.TrackingType = "washer";
            IEnumerable<Washer> controllerWashersTags = DataReaderAccess.GetActiveWashers(controller.ControllerId);
            IEnumerable<Entities.Washer> results = controllerWashersTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName,p.ETechWasherNumber,p.AWEAActive }).Select(g => new Entities.Washer
            {
                WasherId = g.Key.WasherId,
                Name = g.Key.WasherName,
                IsTunnel = g.Key.WasherGroupTypeName == "Tunnel", //TODO:Need to get this property from database.
                ETechWasherNumber=g.Key.ETechWasherNumber,
                AWEAActive = g.Key.AWEAActive,
                Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.TagId }).ToList<Tag>()
            });
            
            foreach (Entities.Washer washer in results)
            {
                //Added the below line for handling INJ and OPC reset scenario
                //When INJ and OPC is reset, need alarm at that timestamp if any
                //so to have alarm notification registring alarm tag in register washer tags also.
                washer.Tags.Add(new OpcTag { Address = Settings.Default.ABAddress1NowMessage, TagType = "NowMessage", Topic = controller.TopicName });
                bool tracking;
                Log.InfoFormat("Registering washer {0} tags", washer.WasherId);
                bool isMeterExists = DataReaderAccess.GetActiveMeterConnectedtoWasher(washer.WasherId);
                if (!isMeterExists)
                {
                    tracking = allenBradleyDataReader.ReadTagsContinuously(!washer.IsTunnel ? washer.Tags.Select(t => (OpcTag)t).ToList() : UpdateTunnelTags(washer.Tags.Select(t => (OpcTag)t).ToList(), controller.TopicName), washer.Name + "_" + washer.WasherId, TagProcessor.ProcessWasherTags, washer);
                }
                else
                {
                    IEnumerable<Washer> meterTags = DataReaderAccess.GetActiveMetersByWasherandControllerId(controller.ControllerId, washer.WasherId);
                    IEnumerable<Entities.Washer> meterTagResults = meterTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName,p.ETechWasherNumber,p.AWEAActive }).Select(g => new Entities.Washer
                    {
                        WasherId = g.Key.WasherId,
                        Name = g.Key.WasherName,
                        IsTunnel = g.Key.WasherGroupTypeName == "Tunnel", //TODO:Need to get this property from database.
                        ETechWasherNumber = g.Key.ETechWasherNumber,
                        AWEAActive = g.Key.AWEAActive,
                        Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.TagId }).ToList<Tag>()
                    });

                    foreach (var meterResults in meterTagResults)
                    {
                        for (int i = 0; i < meterResults.Tags.Count; i++)
                            washer.Tags.Add(meterResults.Tags[i]);
                    }
                    tracking = allenBradleyDataReader.ReadTagsContinuously(washer.Tags.Select(t => (OpcTag)t).ToList(), washer.Name + "_" + washer.WasherId, TagProcessor.ProcessWasherTags, washer);
                }

                if (!tracking)
                {
                    Log.ErrorFormat("Unable to track the washer:{0}", washer);
                    failedWasherList.Add(washer);
                }
            }
            mAllenBradleyDataReaders.Add(allenBradleyDataReader);
        }

        private void RegisterModuleTags(AllenBradleyController controller)
        {
            IEnumerable<ModuleTag> moduleTags = DataReaderAccess.GetActiveModuleTags(controller.ControllerId);
            OpcDataReader.NotifyShutDown shutDownHandler = new OpcDataReader.NotifyShutDown(OPcServerShutDown);
            OpcDataReader allenBradleyDataReader = new OpcDataReader(controller, MOpcItemFormat,shutDownHandler);
            allenBradleyDataReader.TrackingType = "module";
            IEnumerable<Module> results = moduleTags.GroupBy(p => new { p.ModuleId, p.ModuleTypeId, p.DeadBand, p.Unit, RollOverPoint = p.Rolloverpoint, p.Calibration, p.UtilityType }).Select(g => new Module { ModuleId = g.Key.ModuleId, ModuleTypeId = g.Key.ModuleTypeId, Deadband = g.Key.DeadBand, Unit = g.Key.Unit, RollOverPoint = g.Key.RollOverPoint, Calibration = g.Key.Calibration, UtilityType = g.Key.UtilityType, Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.ModuleTagId }).ToList<Tag>() });

            foreach (Module module in results)
            {
                Log.InfoFormat("Registering module {0} tags", module.ModuleId);

                bool tracking = allenBradleyDataReader.ReadTagContinuously(new OpcTag { Address = module.Tags.First().Address, TagType = module.Tags.First().TagType, Topic = controller.TopicName, TagTypeId = module.Tags.First().TagTypeId }, module.ModuleId + string.Empty + module.ModuleTypeId + "Module_", TagProcessor.ProcessModuleTags, module, module.Deadband);

                if (!tracking)
                {
                    Log.ErrorFormat("Unable to track the module:{0}", module);
                    failedModuleList.Add(module);
                }
            }

            mAllenBradleyDataReaders.Add(allenBradleyDataReader);
        }

        private void RegisterWashersNew(AllenBradleyController controller, IEnumerable<Washer> washers, int washerid)
        {
            Log.Info("WebPort not enabled using OPC DA -> " + controller);
            if (string.IsNullOrEmpty(controller.OpcServer))
            {
                Log.Error("OPC Server not defined. Unable to connect");
                return;
            }
            Log.Info("Strated reading values from OPC -> " + controller);

            var allenBradleyDataReader = mAllenBradleyDataReaders.Find(x => x.AllenBradleyController.ControllerId == controller.ControllerId && x.TrackingType == "washer");
            if (allenBradleyDataReader == null)
            {
                OpcDataReader.NotifyShutDown shutDownHandler = new OpcDataReader.NotifyShutDown(OPcServerShutDown);
                allenBradleyDataReader = new OpcDataReader(controller, MOpcItemFormat, shutDownHandler);
            }
            //OpcDataReader allenBradleyDataReader = new OpcDataReader(controller, MOpcItemFormat);
            IEnumerable<Entities.Washer> resultsTemp = washers.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName,p.ETechWasherNumber,p.AWEAActive }).Select(g => new Entities.Washer
            {
                WasherId = g.Key.WasherId,
                Name = g.Key.WasherName,
                IsTunnel = g.Key.WasherGroupTypeName == "Tunnel", //TODO:Need to get this property from database.
                ETechWasherNumber = g.Key.ETechWasherNumber,
                AWEAActive = g.Key.AWEAActive,
                Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.TagId }).ToList<Tag>()
            });

            IEnumerable<Entities.Washer> results = resultsTemp.Where(m => m.WasherId == washerid).Select(g => new Entities.Washer
            {
                WasherId = g.WasherId,
                Name = g.Name,
                IsTunnel = g.IsTunnel,
                ETechWasherNumber=g.ETechWasherNumber,
                AWEAActive=g.AWEAActive,
                Tags = g.Tags.Select(m => new OpcTag { Address = m.Address, Topic = controller.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.TagId }).ToList<Tag>()
            });

            foreach (Entities.Washer washer in results)
            {
                bool tracking;
                Log.InfoFormat("Registering washer {0} tags", washer.WasherId);
                bool isMeterExists = DataReaderAccess.GetActiveMeterConnectedtoWasher(washer.WasherId);
                if (!isMeterExists)
                {
                    tracking = allenBradleyDataReader.ReadTagsContinuously(!washer.IsTunnel ? washer.Tags.Select(t => (OpcTag)t).ToList() : UpdateTunnelTags(washer.Tags.Select(t => (OpcTag)t).ToList(), controller.TopicName), washer.Name + "_" + washer.WasherId, TagProcessor.ProcessWasherTags, washer);
                }
                else
                {
                    IEnumerable<Washer> meterTags = DataReaderAccess.GetActiveMetersByWasherandControllerId(controller.ControllerId, washer.WasherId);
                    IEnumerable<Entities.Washer> meterTagResults = meterTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName,p.ETechWasherNumber,p.AWEAActive}).Select(g => new Entities.Washer
                    {
                        WasherId = g.Key.WasherId,
                        Name = g.Key.WasherName,
                        IsTunnel = g.Key.WasherGroupTypeName == "Tunnel", //TODO:Need to get this property from database.
                        ETechWasherNumber = g.Key.ETechWasherNumber,
                        AWEAActive = g.Key.AWEAActive,
                        Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.TagId }).ToList<Tag>()
                    });

                    foreach (var meterResults in meterTagResults)
                    {
                        for (int i = 0; i < meterResults.Tags.Count; i++)
                            washer.Tags.Add(meterResults.Tags[i]);
                    }
                    tracking = allenBradleyDataReader.ReadTagsContinuously(washer.Tags.Select(t => (OpcTag)t).ToList(), washer.Name + "_" + washer.WasherId, TagProcessor.ProcessWasherTags, washer);
                }

                if (!tracking)
                {
                    Log.ErrorFormat("Unable to track the washer:{0}", washer);
                    failedWasherList.Add(washer);
                }
            }

            if (!mAllenBradleyDataReaders.Exists(x => x.AllenBradleyController.ControllerId == controller.ControllerId && x.TrackingType == "washer"))
            {
                mAllenBradleyDataReaders.Add(allenBradleyDataReader);
            }
        }

        private void RegisterModuleTagsNew(AllenBradleyController controller, IEnumerable<ModuleTag> modulesTags, int moduleId)
        {
            OpcDataReader.NotifyShutDown shutDownHandler = new OpcDataReader.NotifyShutDown(OPcServerShutDown);
            OpcDataReader allenBradleyDataReader = new OpcDataReader(controller, MOpcItemFormat, shutDownHandler);

            IEnumerable<Module> resultsTemp = modulesTags.GroupBy(p => new { p.ModuleId, p.ModuleTypeId, p.DeadBand, p.Unit, RollOverPoint = p.Rolloverpoint, p.Calibration, p.UtilityType }).Select(g => new Module { ModuleId = g.Key.ModuleId, ModuleTypeId = g.Key.ModuleTypeId, Deadband = g.Key.DeadBand, Unit = g.Key.Unit, RollOverPoint = g.Key.RollOverPoint, Calibration = g.Key.Calibration, UtilityType = g.Key.UtilityType, Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.ModuleTagId }).ToList<Tag>() });

            IEnumerable<Module> results = resultsTemp.Where(m => m.ModuleId == moduleId).Select(g => new Module { ModuleId = g.ModuleId, ModuleTypeId = g.ModuleTypeId, Deadband = g.Deadband, Unit = g.Unit, RollOverPoint = g.RollOverPoint, Calibration = g.Calibration, UtilityType = g.UtilityType, Tags = g.Tags.Select(m => new OpcTag { Address = m.Address, Topic = controller.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.TagId }).ToList<Tag>() });

            foreach (Module module in results)
            {
                Log.InfoFormat("Registering module {0} tags", module.ModuleId);

                bool tracking = allenBradleyDataReader.ReadTagContinuously(new OpcTag { Address = module.Tags.First().Address, TagType = module.Tags.First().TagType, Topic = controller.TopicName, TagTypeId = module.Tags.First().TagTypeId }, module.ModuleId + string.Empty + module.ModuleTypeId + "Module_", TagProcessor.ProcessModuleTags, module, module.Deadband);

                if (!tracking)
                {
                    Log.ErrorFormat("Unable to track the module:{0}", module);
                    failedModuleList.Add(module);
                }
            }

            mAllenBradleyDataReaders.Add(allenBradleyDataReader);
        }

        /// <summary>
        ///     N7:150	Error Message #	int
        ///     N9:183	"Now" Washer	int
        ///     N9:181	"Now" Formula	int
        ///     N/A		"Now" Injection	int
        ///     N9:191	"Now" Valve		int
        /// </summary>
        /// <param name="controller"></param>
        private  void RegisterNowTags(AllenBradleyController controller)
        {
            var tags = new List<OpcTag>
            {
                new OpcTag { Address = Settings.Default.ABAddress1NowMessage, TagType = "NowMessage", Topic = controller.TopicName },
                //new OpcTag { Address = "N7:150", TagType = "NowMessage", Topic = controller.TopicName },
                new OpcTag { Address = Settings.Default.ABAddress2NowWasher, TagType = "NowWasher", Topic = controller.TopicName  },
                //new OpcTag(){ Address = "N/A" ,TagType  = "NowInjection",Topic = controller.TopicName},
                new OpcTag { Address = Settings.Default.ABAddress3NowFormula, TagType = "NowFormula", Topic = controller.TopicName },
                new OpcTag { Address = Settings.Default.ABAddress4NowValve, TagType = "NowValve", Topic = controller.TopicName } // Conventional Only
                //new OpcTag { Address = "N7:110", TagType = "NowMessage", Topic = controller.TopicName }
            };
            OpcDataReader.NotifyShutDown shutDownHandler = new OpcDataReader.NotifyShutDown(OPcServerShutDown);
            OpcDataReader allenBradleyDataReader = new OpcDataReader(controller, MOpcItemFormat, shutDownHandler);
            bool tracking = allenBradleyDataReader.ReadTagsContinuously(tags, controller.TopicName, TagProcessor.ProcessNowTags, controller);
            if (!tracking)
            {
                Log.ErrorFormat("Unable to track the now tags for controller :{0}", controller);
            }
        }

        private static List<OpcTag> UpdateTunnelTags(List<OpcTag> list, string topicName)
        {
            for (int i = 0; i < 20; i++)
            {
                list.Add(new OpcTag { Address = string.Format("N7:{0}", 60 + i), TagType = string.Format("Formula_Mod_{0}", i + 1), Topic = topicName });
                list.Add(new OpcTag { Address = string.Format("N7:{0}", 80 + i), TagType = string.Format("Load_Mod_{0}", i + 1), Topic = topicName });
            }

            return list;
        }

        public void Stop()
        {
            Log.Info("AllenBradley : Stopping Data Communication Service...");
            foreach (OpcDataReader allenBradleyDataReader in mAllenBradleyDataReaders)
            {
                allenBradleyDataReader.Shutdown();
            }
            aTimer.Stop(); //Stopping timer since auto reset is true
            aTimer = null;
        }

        private void DeRegisterEntity(int controllerId, string entityName, string entityType)
        {
            var allenBradleyDataReader = mAllenBradleyDataReaders.Find(x => x.AllenBradleyController.ControllerId == controllerId && x.TrackingType == entityType);
            if (allenBradleyDataReader != null)
            {
                allenBradleyDataReader.Deregister(entityName);
            }
        }

        private void DeRegisterConrollerEntity(int controllerId)
        {
            List<OpcDataReader> allenBradleyDataReader = mAllenBradleyDataReaders.FindAll(x => x.AllenBradleyController.ControllerId == controllerId);
            for (int index = 0; index < allenBradleyDataReader.Count; index++)
            {
                allenBradleyDataReader[index].DeregisterController();
            }
            mAllenBradleyDataReaders.RemoveAll(x => x.AllenBradleyController.ControllerId == controllerId);
        }
    }
    
}