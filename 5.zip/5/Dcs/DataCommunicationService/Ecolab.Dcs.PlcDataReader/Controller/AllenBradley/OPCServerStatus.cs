﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Dcs.PlcDataReader
{
    public class OPCServerStatus
    {
        public bool IsServerAvailable { get; set; }
        public string ShutDownReason { get; set; }

        public OPCServerStatus(bool isServerAvailable,string shutDownReason = "")
        {
            IsServerAvailable = isServerAvailable;
            ShutDownReason = shutDownReason;
        }
    }
}
