﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Program </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Diagnostics;
    using System.ServiceProcess;
    using System.Windows.Forms;
    using AutoMapper;
    using Services.Infra;
	using Conduit.PushHandler;
	internal static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main(string[] args)
        {
			Push.LoggerName = "PlcDataReaderService";
			Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
            if (Debugger.IsAttached || (args.Length > 0 && args[0] == "debug"))
            {
                DebugForm form = new DebugForm();
                Application.Run(form);
            }
            else
            {
                ServiceBase[] servicesToRun = { new PlcDataReaderService() };
                ServiceBase.Run(servicesToRun);
            }
        }
    }
}