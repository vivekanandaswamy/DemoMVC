﻿// -----------------------------------------------------------------------
// <copyright file="PlcDataReaderService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlcDataReaderService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.ServiceProcess;
    using System.Threading;
    using Data.Access;
    using log4net;
    using Properties;

    public partial class PlcDataReaderService : ServiceBase
    {
        private static readonly ILog Log = LogManager.GetLogger("PLC Data Reader Service");
        private DataReader dataReader;        
        ProcessRollup processRollup = new ProcessRollup();
        private CancellationTokenSource cancellationTokenSource;
        public PlcDataReaderService()
        {
            cancellationTokenSource = new CancellationTokenSource();
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                InitializeDatabase();
            }
            catch (Exception ex)
            {
                Log.Error("OnStart plc data reader service", ex);
            }

            //Commneted rollup in timer and calling it manually after the every PLC request
            //try
            //{
            //    startRollup();
            //}
            //catch (Exception ex)
            //{
            //    Log.Error("OnStart rollup data", ex);
            //}
        }
        
        private void ReconnectDatabase()
        {
            System.Threading.Thread.Sleep(30000);
            InitializeDatabase();
        }
        
        private void InitializeDatabase()
        {
            try
            {
                Database.InitializeConnection(Settings.Default.ConnectionString);
                dataReader = new DataReader(cancellationTokenSource);
            }
            catch (SqlException ex)
            {
                Log.Error("SQL Connection failed", ex);
                ReconnectDatabase();
            }
            catch (Exception ex)
            {
                Log.Error("OnStart plc data reader service", ex);
            }
        }

        protected override void OnStop()
        {
            cancellationTokenSource.Cancel();
            if (dataReader == null)
            {
                return;
            }
            dataReader.Stop();
            dataReader = null;

            //dataRollupTimer.Stop();
            //dataRollupTimer = null;
        }

        internal void Start()
        {
            OnStart(null);
        }

        //private void startRollup()
        //{
        //    dataRollupTimer = new System.Timers.Timer(Int32.Parse(Settings.Default.DataRollupInterval));
        //    dataRollupTimer.AutoReset = true;
        //    dataRollupTimer.Elapsed += new System.Timers.ElapsedEventHandler(this.timer_Elapsed);
        //    dataRollupTimer.Start();
        //}

        //private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        //{
        //    processRollup.Rollup();
        //}

    }
}