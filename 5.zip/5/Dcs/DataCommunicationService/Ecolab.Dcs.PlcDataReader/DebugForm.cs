﻿// -----------------------------------------------------------------------
// <copyright file="DebugForm.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DebugForm </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Diagnostics;
    using System.Windows.Forms;
    using log4net;

    public partial class DebugForm : Form
    {
        private static readonly ILog Log = LogManager.GetLogger("Debug form");
        private readonly PlcDataReaderService mPlcDataReaderService = new PlcDataReaderService();

        public DebugForm()
        {
            InitializeComponent();
            Trace.Listeners.Add(new DebugFormTraceListener(txtLog));
            Log.Info("Debug form loaded");
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            mPlcDataReaderService.Start();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            if (mPlcDataReaderService.CanStop)
            {
                mPlcDataReaderService.Stop();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLog.Text = string.Empty;
        }

        private void DebugForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            mPlcDataReaderService.Stop();
        }
    }

    internal class DebugFormTraceListener : TraceListener
    {
        private readonly TextBox mTxtLog;

        public DebugFormTraceListener(TextBox logTextBox)
        {
            mTxtLog = logTextBox;
        }

        public override void Write(string message)
        {
            if (mTxtLog.InvokeRequired)
            {
                mTxtLog.Invoke((MethodInvoker) ( () => Write(message) ));
                return;
            }
            mTxtLog.AppendText(message);
        }

        public override void WriteLine(string message)
        {
            //mTxtLog.AppendText("-------------------------------------------------------------------------------");
            //Write(Environment.NewLine);
            //Write(message);
            //mTxtLog.AppendText("-------------------------------------------------------------------------------");
            //Write(Environment.NewLine);
            Write(message);
            Write(Environment.NewLine);
        }
    }
}