﻿// -----------------------------------------------------------------------
// <copyright file="UnitConversion.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The UnitConversion </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Dcs.PlcDataReader
{
   
   public  class UnitConversion
   {

       public enum Units 
       {
           Litre = 1,
           MilliLitre,
           Kilogram,
           Gram,
           Celsius,
           DecaThermal,
           BTU,
           Minute,
           Hour,
           Seconds
       }

        /// <summary>
        /// This function will convert Europe metrics to US metrics
        /// </summary>
        /// <param name="sourceUnit">Name of the unit.</param>
        /// <param name="dataPoint">The data point.</param>
        /// <returns></returns>
        public static double ConvertUnit(Units sourceUnit, int dataPoint)
       {
           double readingValue;

           switch (sourceUnit)
           {
               case Units.Litre:
                   readingValue = Convert.ToDouble(dataPoint) * 0.264172; // To convert to Gallons
                   break;
               case  Units.MilliLitre:
                   readingValue = Convert.ToDouble(dataPoint) * 0.03381; // To convert to ounces
                   break;
               case Units.Kilogram:
                   readingValue = Convert.ToDouble(dataPoint) * 2.20462;//2.205 // To convert to Pounds
                   break;
               case Units.Gram:
                   //readingValue = Convert.ToDouble(dataPoint) * 0.03527; // To convert to ounces
                   readingValue = Convert.ToDouble(dataPoint) * 0.0022046; // To convert to Pounds
                   break;
               case  Units.Celsius:
                   readingValue = (Convert.ToDouble(dataPoint) * 9) / 5 + 32; // To Convert to Fahrenheit
                    break;
               case  Units.DecaThermal:
                   readingValue = Convert.ToDouble(dataPoint) * 10; // To convert to Therms
                   break;
               case  Units.BTU:
                   readingValue = Convert.ToDouble(dataPoint) * 0.0000100023877; // To convert to Therms
                   break;
               case Units.Seconds:
                   readingValue = Convert.ToDouble(dataPoint)/60.0; // To convert to mins
                   break;
               case Units.Minute: 
                   readingValue = Convert.ToDouble(dataPoint);
                   break;
               case Units.Hour:
                   readingValue = Convert.ToDouble(dataPoint) * 60.0; // To Convert to Mins
                   break;
               default:
                   readingValue = Convert.ToDouble(dataPoint);
                   break;
           }
           return readingValue;
       }
       
   }
}
