﻿// -----------------------------------------------------------------------
// <copyright file="Record.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Record </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Net;
using System.Xml;
using System.Xml.Serialization;
using Ecolab.Dcs.PlcDataReader.Properties;
using log4net;

namespace Ecolab.Dcs.PlcDataReader
{
    /// <summary>
    /// Class for Record
    /// </summary>
    public class record
    {
        /// <summary>
        /// Gets or sets the product code.
        /// </summary>
        /// <value>
        /// The product code.
        /// </value>
        [XmlElement]
        public string productCode { get; set; }
        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        [XmlElement]
        public string productName { get; set; }
        /// <summary>
        /// Gets or sets the customer codes.
        /// </summary>
        /// <value>
        /// The customer codes.
        /// </value>
        [XmlElement]
        public string customerCodes { get; set; }
        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>
        /// The name of the customer.
        /// </value>
        [XmlElement]
        public string customerName { get; set; }
        /// <summary>
        /// Gets or sets the location code.
        /// </summary>
        /// <value>
        /// The location code.
        /// </value>
        [XmlElement]
        public string locationCode { get; set; }
        /// <summary>
        /// Gets or sets the name of the location.
        /// </summary>
        /// <value>
        /// The name of the location.
        /// </value>
        [XmlElement]
        public string locationName { get; set; }
        /// <summary>
        /// Gets or sets the soiled weight.
        /// </summary>
        /// <value>
        /// The soiled weight.
        /// </value>
        [XmlElement]
        public string soiledWeight { get; set; }
        /// <summary>
        /// Gets or sets the total weight.
        /// </summary>
        /// <value>
        /// The total weight.
        /// </value>
        [XmlElement]
        public string totalWeight { get; set; }
        /// <summary>
        /// Gets or sets the batch code.
        /// </summary>
        /// <value>
        /// The batch code.
        /// </value>
        [XmlElement]
        public string batchCode { get; set; }
        /// <summary>
        /// Gets or sets the last dropped at.
        /// </summary>
        /// <value>
        /// The last dropped at.
        /// </value>
        [XmlElement]
        public string lastDroppedAt { get; set; }
        /// <summary>
        /// Gets or sets the updated at.
        /// </summary>
        /// <value>
        /// The updated at.
        /// </value>
        [XmlElement]
        public string updatedAt { get; set; }
        /// <summary>
        /// Gets or sets the endTime.
        /// </summary>
        /// <value>
        /// The endTime.
        /// </value>
        [XmlElement]
        public string endTime { get; set; }
    }
}
