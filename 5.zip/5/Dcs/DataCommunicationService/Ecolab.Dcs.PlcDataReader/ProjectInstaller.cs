﻿// -----------------------------------------------------------------------
// <copyright file="ProjectInstaller.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProjectInstaller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.PlcDataReader
{
    using System.ComponentModel;
    using System.Configuration.Install;

    [RunInstaller(true)]
    public partial class ProjectInstaller : Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }
    }
}