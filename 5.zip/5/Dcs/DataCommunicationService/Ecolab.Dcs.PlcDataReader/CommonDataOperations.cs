﻿// -----------------------------------------------------------------------
// <copyright file="CommonDataOperations.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CommonDataOperations </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Net;
using System.Xml;
using System.Data;
using System.Xml.Serialization;
using System.Linq;
using Ecolab.Dcs.PlcDataReader.Properties;
using log4net;

namespace Ecolab.Dcs.PlcDataReader
{
    /// <summary>
    /// Class for CommonDataOperations
    /// </summary>
    public class CommonDataOperations
    {
        /// <summary>
        /// The log for CommonDataOperations
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(CommonDataOperations));

        /// <summary>
        /// The e tech default proxy address
        /// </summary>
        private static string ETechDefaultProxyAddress = Settings.Default.ETechProxyAddress;

        /// <summary>
        /// Gets or sets the e tech proxy address.
        /// </summary>
        /// <value>
        /// The e tech proxy address.
        /// </value>
        public static string ETechProxyAddress
        {
            get { return ETechDefaultProxyAddress; }
            set { ETechDefaultProxyAddress = value; }
        }

        /// <summary>
        /// The e tech default proxy bypass on local
        /// </summary>
        private static string ETechDefaultProxyBypassOnLocal = Settings.Default.ETechProxyBypassOnLocal;

        /// <summary>
        /// Gets or sets the e tech proxy bypass on local.
        /// </summary>
        /// <value>
        /// The e tech proxy bypass on local.
        /// </value>
        public static string ETechProxyBypassOnLocal
        {
            get { return ETechDefaultProxyBypassOnLocal; }
            set { ETechDefaultProxyBypassOnLocal = value; }
        }

        /// <summary>
        /// The is etech default proxy enabled
        /// </summary>
        private static string IsEtechDefaultProxyEnabled = Settings.Default.IsETechProxyEnabled;

        /// <summary>
        /// Gets or sets the is etech proxy enabled.
        /// </summary>
        /// <value>
        /// The is etech proxy enabled.
        /// </value>
        public static string IsEtechProxyEnabled
        {
            get { return IsEtechDefaultProxyEnabled; }
            set { IsEtechDefaultProxyEnabled = value; }
        }

        /// <summary>
        /// Gets or sets the conduit connection.
        /// </summary>
        /// <value>
        /// The conduit connection.
        /// </value>
        public static SqlConnection ConduitConnection { get; set; }

        /// <summary>
        /// Updates the command.
        /// </summary>
        /// <param name="query">The query for CommonDataOperations.</param>
        /// <param name="connectionString">The connection string.</param>
        public static void UpdateCommand(string query, string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Connection.Open();
                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Updates the webportdatetime.
        /// </summary>
        /// <param name="controllerid">The controllerid.</param>
        /// <param name="timestamp">The time stamp.</param>
        public static void UpdateWebportdatetime(int controllerid, DateTime timestamp)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());

            UpdateCommand(
                "update [TCD].[ConduitController] set [WebportReadTime] = '" +
                timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff") + "' where [controllerid] = " + controllerid + ";",
                ConduitConnection.ConnectionString);
        }

        /// <summary>
        /// Get MaxLoadId Method
        /// </summary>
        /// <param name="washerId">The washer identifier.</param>
        /// <returns>Returns Max load Id .</returns>
        public static int GetMaxLoadId(int washerId)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            int maxLoadId = GetCommand(
                "select max(ControllerBatchId) from [TCD].[BatchData] where MachineId = '" + washerId + "'",
                ConduitConnection.ConnectionString);
            return maxLoadId;
        }

        /// <summary>
        /// Gets the no of compartments.
        /// </summary>
        /// <param name="washerId">The washer identifier.</param>
        /// <param name="controllerid">The controllerid.</param>
        /// <returns>Returns No Of Compartments</returns>
        public static int GetNoOfCompartments(int washerId, int controllerid)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            int noofComp = GetCommand(
                "select NumberOfComp from [TCD].[machinesetup] where WasherId = '" + washerId + "' and controllerid = '" + controllerid + "'",
                ConduitConnection.ConnectionString);
            return noofComp;
        }

        /// <summary>
        /// Gets the no of compartments by machine internal identifier.
        /// </summary>
        /// <param name="machineInternalId">The machine internal identifier.</param>
        /// <param name="controllerid">The controllerid.</param>
        /// <returns>Returns No of CompartmentsByMachineInternalId</returns>
        public static int GetNoOfCompartmentsByMachineInternalId(int machineInternalId, int controllerid)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            int noofComp = GetCommand(
               "select NumberOfComp from [TCD].[machinesetup] where IsTunnel = 1 and IsDeleted = 0 and MachineInternalId = '" + machineInternalId + "' and controllerid = '" + controllerid + "'",
               ConduitConnection.ConnectionString);
            return noofComp;
        }

        /// <summary>
        /// Gets the command.
        /// </summary>
        /// <param name="query">The query for CommonDataOperations.</param>
        /// <param name="connectionString">The connection string.</param>
        /// <returns>Returns integer value</returns>
        public static int GetCommand(string query, string connectionString)
        {
            try
            {
                int loadId;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Connection.Open();
                    loadId = Convert.ToInt32(command.ExecuteScalar(), CultureInfo.InvariantCulture.NumberFormat);
                }
                return loadId;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        /// <summary>
        /// Getdatetimes the command.
        /// </summary>
        /// <param name="query">The query for CommonDataOperations.</param>
        /// <param name="connectionString">The connection string.</param>
        /// <returns>Returns Date and time</returns>
        public static DateTime GetdatetimeCommand(string query, string connectionString)
        {
            try
            {
                DateTime operationTimestamp;
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Connection.Open();
                    operationTimestamp = Convert.ToDateTime(command.ExecuteScalar(), CultureInfo.InvariantCulture.NumberFormat);
                }
                return operationTimestamp;
            }
            catch (Exception)
            {
                return DateTime.MinValue;
            }
        }

        /// <summary>
        /// Gets the controller operation timestamp.
        /// </summary>
        /// <param name="controllerid">The controllerid.</param>
        /// <returns>Returns Date and time</returns>
        public static DateTime GetControllerOperationTimestamp(int controllerid)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            DateTime operationTimestamp = GetdatetimeCommand(
                //"select max(OperationTimeStamp) as OperationTimeStamp from [TCD].[ConduitControllerHistory] where controllerid = '" + controllerid + "'",
                "select max(lastmodifiedtime) as OperationTimeStamp from [TCD].[ConduitController] where controllerid = '" + controllerid + "'",
                ConduitConnection.ConnectionString);
            return operationTimestamp;
        }

        /// <summary>
        /// Gets the washer operation timestamp.
        /// </summary>
        /// <param name="controllerid">The controllerid.</param>
        /// <param name="washerid">The washerid for Common operations.</param>
        /// <returns>Returns Date and time</returns>
        public static DateTime GetWasherOperationTimestamp(int controllerid, int washerid)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            DateTime operationTimestamp = GetdatetimeCommand(
                "select max(OperationTimeStamp) as OperationTimeStamp from [TCD].[machinesetuphistory] where WasherId = '" + washerid + "' and controllerid = '" + controllerid + "'",
                ConduitConnection.ConnectionString);
            return operationTimestamp;
        }

        /// <summary>
        /// Gets the meter operation timestamp.
        /// </summary>
        /// <param name="controllerid">The controlleridfor Common operations.</param>
        /// <param name="meterid">The meteridfor Common operations.</param>
        /// <returns>Returns Date and time</returns>
        public static DateTime GetMeterOperationTimestamp(int controllerid, int meterid)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            DateTime operationTimestamp = GetdatetimeCommand(
                "select max(OperationTimeStamp) as OperationTimeStamp from [TCD].[meterHistory] where MeterId = '" + meterid + "' and controllerid = '" + controllerid + "'",
                ConduitConnection.ConnectionString);
            return operationTimestamp;
        }

        /// <summary>
        /// Gets the sensor operation timestamp.
        /// </summary>
        /// <param name="controllerid">The controllerid.</param>
        /// <param name="sensorid">The sensorid for Common operations.</param>
        /// <returns>Returns Date and time</returns>
        public static DateTime GetSensorOperationTimestamp(int controllerid, int sensorid)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            DateTime operationTimestamp = GetdatetimeCommand(
                "select max(OperationTimeStamp) as OperationTimeStamp from [TCD].[sensorHistory] where SensorId = '" + sensorid + "' and controllerid = '" + controllerid + "'",
                ConduitConnection.ConnectionString);
            return operationTimestamp;
        }

        /// <summary>
        /// Gets the tank operation timestamp.
        /// </summary>
        /// <param name="controllerid">The controllerid.</param>
        /// <param name="tankid">The tankid for Common operations.</param>
        /// <returns>Returns Date and time</returns>
        public static DateTime GetTankOperationTimestamp(int controllerid, int tankid)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            DateTime operationTimestamp = GetdatetimeCommand(
                "select max(OperationTimeStamp) as OperationTimeStamp from [TCD].[tanksetuphistory] where TankId = '" + tankid + "' and controllerid = '" + controllerid + "'",
                ConduitConnection.ConnectionString);
            return operationTimestamp;
        }

        /// <summary>
        /// Gets the e tech total weight.
        /// </summary>
        /// <param name="EtechURL">The etech URL.</param>
        /// <param name="ETechCustomerCodesText">The e tech customer codes text.</param>
        /// <returns>Returns DFLastDropped</returns>
        public static DFLastDropped GetETechTotalWeight(string EtechURL, string ETechCustomerCodesText)
        {
            #region ETech XML for ref
            ///Parse the response XML and return the ETech object.
            //< DFLastDropped >
            //     < messageRevision > 1.0 </ messageRevision >
            //     < messageSent > 2016 - 02 - 09T05: 22:51 </ messageSent >
            //         < record >
            //             < productCode > 8 </ productCode >
            //             < productName > Stretcher Sheets </ productName >
            //            < customerCode > 1 </ customerCode >
            //            < customerName > Orlando </ customerName >
            //            < locationCode > 79 </ locationCode >
            //            < locationName > Tunnel 1 </ locationName >
            //             < soiledWeight > 116 </ soiledWeight >
            //             < totalWeight > 116 </ totalWeight >
            //             < batchCode > 3255940 </ batchCode >
            //             < lastDroppedAt > 2015 - 12 - 21 03:29:41 - 0600 </ lastDroppedAt >
            //             < updatedAt > 2015 - 12 - 22T08: 29:41 </ updatedAt >
            //          </ record >
            #endregion
            try
            {
                Log.Info("Etech Request URL :" + EtechURL);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EtechURL);
                if (Convert.ToBoolean(IsEtechProxyEnabled))
                {
                    WebProxy proxy = new WebProxy(ETechProxyAddress, Convert.ToBoolean(ETechProxyBypassOnLocal));
                    request.Proxy = proxy;
                    request.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
                }
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                string value = null;
                DFLastDropped data = new DFLastDropped();
                data.record = new List<record> { new record() };
                using (var st = response.GetResponseStream())
                {
                    StreamReader sr = new StreamReader(st);
                    value = sr.ReadToEnd();
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(value);
                    XmlNodeList Xelement1 = doc.GetElementsByTagName("totalWeight");
                    XmlNodeList Xelement2 = doc.GetElementsByTagName("customerCodes");
                    if (Xelement2 == null)
                    {
                        Xelement2 = doc.GetElementsByTagName(ETechCustomerCodesText);
                    }
                    XmlNodeList Xelement3 = doc.GetElementsByTagName("lastDroppedAt");
                    if (Xelement1 != null)
                    {
                        data.record[0].totalWeight = Xelement1[0].InnerText;
                    }
                    if (Xelement2 != null)
                    {
                        data.record[0].customerCodes = Xelement2[0].InnerText;
                    }
                    if (Xelement3 != null)
                    {
                        data.record[0].lastDroppedAt = Xelement3[0].InnerText;
                    }
                    Log.Info("Etech Response XML :" + doc.InnerXml);
                }

                return data;

            }
            catch (Exception ex)
            {
                Log.Error("Failed to get ETech response", ex);
                return null;
            }
        }

        public static DFLastDropped GetETechTotalWeightBechkoff(string EtechURL, string ETechCustomerCodesText,DateTime formulaTime,int etechTimeDiff)
        {
            #region ETech XML for ref
            ///Parse the response XML and return the ETech object.
            //<DFsoiledDestinationToday>
            //  <messageRevision>1.0</messageRevision>
            //  <messageSent>2009-03-31T09:39:39</messageSent>
            //  <record>
            //    <id>4191787</id>
            //    <productCode>27</productCode>
            //    <productName>COLORED SPREADS - COBIJAS</productName>
            //    <customerCode>15</customerCode>
            //    <customerName>ISJ</customerName>
            //    <locationCode>112</locationCode>
            //    <locationName>tUNNEL 2 OPENER</locationName>
            //    <soiledweight>113</soiledweight>
            //    <batchCode>10200120</batchCode>
            //    <lotCode>1</lotCode>
            //    <dayCode>1</dayCode>
            //    <pieces>113</pieces>
            //    <endTime>2016-09-23t14:06:28</endTime>
            //    <updatedAt>2016-09-23t14:06:28</updatedAt>
            //    <productRef/>
            //  </record>
            //  <record>
            //    <id>4191793</id>
            //    <productCode>27</productCode>
            //    <productName>COLORED SPREADS - COBIJAS</productName>
            //    <customerCode>15</customerCode>
            //    <customerName>ISJ</customerName>
            //    <locationCode>112</locationCode>
            //    <locationName>tUNNEL 2 OPENER</locationName>
            //    <soiledweight>110</soiledweight>
            //    <batchCode>10199960</batchCode>
            //    <lotCode>1</lotCode>
            //    <dayCode>1</dayCode>
            //    <pieces>110</pieces>
            //    <endTime>2016-09-23t14:08:04</endTime>
            //    <updatedAt>2016-09-23t14:08:04</updatedAt>
            //    <productRef/>
            //  </record>
            //</DFsoiledDestinationToday>
            #endregion
            try
            {
                Log.Info("Etech Request URL - GetETechTotalWeightBechkoff :" + EtechURL);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EtechURL);
                if (Convert.ToBoolean(IsEtechProxyEnabled))
                {
                    WebProxy proxy = new WebProxy(ETechProxyAddress, Convert.ToBoolean(ETechProxyBypassOnLocal));
                    request.Proxy = proxy;
                    request.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
                }
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                string value = null;
                DFLastDropped data = new DFLastDropped();
                data.record = new List<record> { new record() };
                using (var st = response.GetResponseStream())
                {
                    StreamReader sr = new StreamReader(st);
                    value = sr.ReadToEnd();
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(value);
                    Log.Info("Etech Response XML - GetETechTotalWeightBechkoff :" + doc.InnerXml);
                    using (DataTable xmlDataTable = new DataTable())
                    {
                        xmlDataTable.Columns.AddRange(new DataColumn[3] { new DataColumn("soiledWeight", typeof(string)),
                            new DataColumn("customerCodes", typeof(int)),
                            new DataColumn("endTime",typeof(DateTime)) });
                        XmlNodeList records = doc.SelectNodes(Settings.Default.ETechBeckhoffXmlNode);
                        foreach (XmlNode record in records)
                        {
                            if (record.ChildNodes.Count > 0)
                            {
                                DataRow row = xmlDataTable.NewRow();
                                if (record["endTime"] == null || string.IsNullOrEmpty(Convert.ToString(record["endTime"].InnerText)) || record["soiledWeight"] == null || string.IsNullOrEmpty(Convert.ToString(record["soiledWeight"].InnerText)))
                                { continue; }
                                if (record["soiledWeight"] != null &&  !string.IsNullOrEmpty(Convert.ToString(record["soiledWeight"].InnerText)))
                                {
                                    row["soiledWeight"] = record["soiledWeight"].InnerText;
                                }
                                if (record["customerCodes"] != null && !string.IsNullOrEmpty(Convert.ToString(record["customerCodes"].InnerText)))
                                {
                                    row["customerCodes"] = record["customerCodes"].InnerText;
                                }
                                else
                                {
                                    if (record[ETechCustomerCodesText] != null && !string.IsNullOrEmpty(Convert.ToString(record[ETechCustomerCodesText].InnerText)))
                                    {
                                        row["customerCodes"] = record[ETechCustomerCodesText].InnerText;
                                    }
                                }
                                if (record["endTime"] != null && !string.IsNullOrEmpty(Convert.ToString(record["endTime"].InnerText)))
                                {
                                    row["endTime"] = DateTime.Parse(record["endTime"].InnerText).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss");
                                }

                                xmlDataTable.Rows.Add(row);
                            }
                        }
                        if (xmlDataTable.Rows.Count > 0)
                        {
                            var getRecord = (from obj in xmlDataTable.AsEnumerable()
                                             where (DateTime)obj["endTime"] >= formulaTime.AddSeconds(-etechTimeDiff) && (DateTime)obj["endTime"] <= formulaTime.AddSeconds(etechTimeDiff) && (((DateTime)obj["endTime"] - formulaTime).Seconds < 0 ? -(((DateTime)obj["endTime"] - formulaTime).Seconds) : ((DateTime)obj["endTime"] - formulaTime).Seconds) >= 0
                                             select new
                                             {
                                                 timediff = (((DateTime)obj["endTime"] - formulaTime).Seconds < 0 ? -(((DateTime)obj["endTime"] - formulaTime).Seconds) : ((DateTime)obj["endTime"] - formulaTime).Seconds),
                                                 data = obj
                                             }
                             ).OrderBy(i => i.timediff).Take(1).ToList();
                            if (getRecord.Count > 0)
                            {
                                data.record[0].soiledWeight =Convert.ToString(getRecord[0].data[0]);
                                data.record[0].customerCodes = Convert.ToString(getRecord[0].data[1]);
                                data.record[0].endTime = Convert.ToString(getRecord[0].data[2]);
                            }
                            else
                            {
                                data = null;
                            }
                        }
                        else
                        { data = null; }
                       
                    }
                    
                }
                return data;
            }
            catch (Exception ex)
            {
                Log.Error("Failed to get ETech response", ex);
                return null;
            }
        }

        public static double GetPreviousReading(int ModuleId, int ModuleTypeId)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            Double PrevReading = GetCommand(
                "select Reading as PrevReading from [TCD].[ModuleReading] where ModuleId = '" + ModuleId + "' and ModuleTypeId = '" + ModuleTypeId + "' order by TimeStamp desc",
                ConduitConnection.ConnectionString);
            return PrevReading;
        }

        /// <summary>
        /// Gets the machine internal id identifier.
        /// </summary>
        /// <param name="washerId">The washerId identifier.</param>
        /// <returns>Returns No of machine internal id</returns>
        public static int GetMachineInternalIdByWasherId(int washerId)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            int machineInternalId = GetCommand(
               "select MachineInternalId from [TCD].[machinesetup] where IsDeleted = 0 and WasherId = '" + washerId + "'",
               ConduitConnection.ConnectionString);
            return machineInternalId;
        }

        /// <summary>
        /// Gets the machine internal id identifier.
        /// </summary>
        /// <param name="controllerId">The controller Id</param>
        /// <param name="washerId">The washerId identifier.</param>
        /// <param name="address">The address</param>
        /// <param name="value">The Value</param>
        /// <param name="dateTime">The DateTime</param>
        /// <param name="isTunnel">The isTunnel Flag</param>
        /// <returns>Returns No of machine internal id</returns>
        public static void DeleteBeckhoffArrayQueueShadow(int controllerId, int washerId, string address, string value, DateTime dateTime, bool isTunnel)
        {
            ConduitConnection = new SqlConnection(Settings.Default["ConnectionString"].ToString());
            int noofComp = GetCommand(
               "delete from [TCD].[BeckhoffArrayQueue_Shadow] where WasherId = '" + washerId + "' and ControllerId = '" + controllerId + "' and Address = '" + address + "' and Value = '" + value + "' and Timestamp = '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff") + "' and IsTunnel = '" + isTunnel + "'",
               ConduitConnection.ConnectionString);
        }
    }
}
