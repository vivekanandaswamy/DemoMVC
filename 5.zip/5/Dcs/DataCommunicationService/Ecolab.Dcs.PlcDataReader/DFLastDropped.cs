﻿// -----------------------------------------------------------------------
// <copyright file="DFLastDropped.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DFLastDropped </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Net;
using System.Xml;
using System.Xml.Serialization;
using Ecolab.Dcs.PlcDataReader.Properties;
using log4net;

namespace Ecolab.Dcs.PlcDataReader
{
    /// <summary>
    /// Class for DFLastDropped
    /// </summary>
    [XmlRoot]
    public class DFLastDropped
    {
        /// <summary>
        /// Gets or sets the message revision.
        /// </summary>
        /// <value>
        /// The message revision.
        /// </value>
        [XmlElement]
        public string messageRevision { get; set; }
        /// <summary>
        /// Gets or sets the message sent.
        /// </summary>
        /// <value>
        /// The message sent.
        /// </value>
        [XmlElement]
        public string messageSent { get; set; }
        /// <summary>
        /// Gets or sets the record.
        /// </summary>
        /// <value>
        /// The record for DFLastDropped.
        /// </value>
        [XmlElement]
        public List<record> record { get; set; }
    }
}
