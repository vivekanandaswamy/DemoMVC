﻿// -----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>AssemblyInfo.cs</summary>
// -----------------------------------------------------------------------

using System.Reflection;
using log4net.Config;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("Ecolab.Dcs.PlcDataReader")]
[assembly: AssemblyDescription("")]
[assembly: XmlConfigurator(Watch = true, ConfigFile = "log4net.config")]