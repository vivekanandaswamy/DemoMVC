// -----------------------------------------------------------------------
// <copyright file="ControllerType.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>ControllerType </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    public enum ControllerType
    {
        AllenBradley = 1,
        Beckhoff = 2,
        Transactional,
        NonTransactional,
        Mitsubishi,
        EightWashers,
        SixWashersOneTunnel,
        SixWashers,
        FourWashers,
        OneTunnelFourWashers,
        OneTunnelTwoWashers,
        TenWasher,
        FiveWashersOneTunnel,
        TwoTunnels,
        MyControl,
        Washer,
        Tunnel

        /*
        SELECT * FROM TCd.ControllerType ct
Allen Bradley
Beckhoff
Transactional
Non Transactional
Mitsubishi
8 Washers
1 Tunnel 6 Washers
6 Washers
4 Washers
1 Tunnel 4 Washers
1 Tunnel 2 Washers
10 Washers
1 Tunnel 5 Washers
2 Tunnels */
    }
}
 