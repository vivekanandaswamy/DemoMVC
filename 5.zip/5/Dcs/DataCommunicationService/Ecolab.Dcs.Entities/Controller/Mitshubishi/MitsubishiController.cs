﻿// -----------------------------------------------------------------------
// <copyright file="MitsubishiController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MitsubishiController </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Dcs.Entities
{

    public enum MitsubishiPLCType
    {

        PLCXL10W = 1,
        PLCXL5W1C,
        PLCXL2Cbw,
        A1SH,
        EControlPlus,//FX3U
        EControlPlus8W,//FX3U 8W
        EControlPlus6W1T,//FX3U 6W1T
        EControl //FX2N

    }

    public class MitsubishiController : Controller
    {
        
        public string HostAdress { get; set; }
        public MitsubishiPLCType PLCType { get; set; }
        public int NetworkNumber {get;set;}
        public int StationNumber {get;set;}
        public int UnitNumber {get;set;}
        public int IONumber {get;set;}
        public int CpuType {get;set;}
        public int PortNumber { get; set; }
        public int TimeOut { get; set; }
        public string COMPort { get; set; }
    }
}
