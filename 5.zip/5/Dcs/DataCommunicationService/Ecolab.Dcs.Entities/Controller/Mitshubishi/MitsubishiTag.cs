﻿// -----------------------------------------------------------------------
// <copyright file="MitsubishiTag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MitsubishiTag </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    public class MitsubishiTag : Tag
    {
        [XmlAttribute]
        public int[] IntArrayData { get; set; }
        [XmlAttribute]
        public int ArrayLength { get; set; }
    }
}
