﻿// -----------------------------------------------------------------------
// <copyright file="PLCData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>PLCData </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    public class PLCData
    {
        [XmlAttribute]
        public string MachineNumber { get; set; }
        [XmlAttribute]
        public string GroupNumber { get; set; }
        [XmlAttribute]
        public string BatchCounter { get; set; }
        [XmlAttribute]
        public string StartDateTime { get; set; }
        [XmlAttribute]
        public string EndDateTime { get; set; }
        [XmlAttribute]
        public string ProgramNumber { get; set; }
        [XmlAttribute]
        public string Load { get; set; }
        [XmlAttribute]
        public string NominalLoad { get; set; }
        [XmlAttribute]
        public string CustomerNumber { get; set; }
        [XmlAttribute]
        public string IsTunnel { get; set; }
    }
}
