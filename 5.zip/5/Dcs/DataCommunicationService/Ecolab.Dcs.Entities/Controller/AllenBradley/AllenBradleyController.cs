﻿// -----------------------------------------------------------------------
// <copyright file="AllenBradleyController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>AllenBradleyController </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;

    public class AllenBradleyController : Controller
    {
        public string OpcServer { get; set; }
        public bool IsWebPortEnabled { get; set; }
        public string WebPortAddress { get; set; }
        public string WebPortUserName { get; set; }
        public string WebPortPassword { get; set; }
        public string TopicName { get; set; }
        public DateTime Webportdatetime { get; set; }

        public override string ToString()
        {
            return string.Format("ControllerId:{0}|ControllerName:{1}|OpcServer:{2}|IsWebPortEnabled:{3}|WebPortAddress:{4}|WebPortUserName:{5}|WebPortPassword:{6}|TopicName:{7}|Webportdatetime:{8}", this.ControllerId, this.Name, this.OpcServer, this.IsWebPortEnabled, this.WebPortAddress, this.WebPortUserName, this.WebPortPassword, this.TopicName, this.Webportdatetime);
        }
    }
}