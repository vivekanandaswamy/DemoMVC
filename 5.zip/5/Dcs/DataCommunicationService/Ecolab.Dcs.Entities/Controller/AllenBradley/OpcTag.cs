﻿// -----------------------------------------------------------------------
// <copyright file="OpcTag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>OpcTag </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Xml.Serialization;

    public class OpcTag : Tag
    {
        [XmlAttribute]
        public string Topic { get; set; }

        [XmlAttribute]
        public int ServerHandle { get; set; }

        [XmlAttribute]
        public int ClientHandle { get; set; }

        [XmlAttribute]
        public int LoadId { get; set; }

        public override string ToString()
        {
            return String.Format("Topic:{0}|Address:{1}|ServerHandle:{2}|Quality:{3}|TimeStamp:{4}|Value:{5}|IsModified:{6}|LoadId:{7}", this.Topic, this.Address, this.ServerHandle, this.Quality, this.TimeStamp, this.Value, this.IsModified ? "True" : "False", LoadId);
        }
    }
}