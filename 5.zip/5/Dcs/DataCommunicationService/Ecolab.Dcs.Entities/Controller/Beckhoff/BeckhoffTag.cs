﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffTag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>BeckhoffTag </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    public class BeckhoffTag : Tag
	{
		[XmlAttribute]
		public string Topic { get; set; }

		[XmlAttribute]
		public int NotificationHandle { get; set; }

		[XmlAttribute]
		public int indexOffset { get; set; }

		[XmlAttribute]
		public int indexGroup { get; set; }

		[XmlAttribute]
		public int LoadId { get; set; }
       
        [XmlAttribute]
        public List<Boolean> arrayDataBoolean { get; set; }

        [XmlAttribute]
        public string ComplexObjectType { get; set; }

        [XmlIgnore]
        public object ComplexObject{ get; set; }
        [XmlAttribute]
        public List<UInt32> WAndEData { get; set; }
        public override string ToString()
		{
			return String.Format("Topic:{0}|Address:{1}|ServerHandle:{2}|Quality:{3}|TimeStamp:{4}|Value:{5}|IsModified:{6}|LoadId:{7}", Topic, Address, NotificationHandle, Quality, TimeStamp, Value, IsModified ? "True" : "False", LoadId);
		}
	}
}