﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffXmlTag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>BeckhoffXmlTag </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;    

    public class BeckhoffXmlTag
    {
        public BeckhoffXmlTag()
        { }
        public BeckhoffXmlTag(string tagAddress, string tagDesc, int data, DateTime dateTimestamp)
        {
            this.Desc = tagDesc;
            this.TagAddress = tagAddress;
            this.Value = data;
            this.DateTimeStamp = dateTimestamp;
        }
        public string Desc { get; set; }
        public string TagAddress { get; set; }
        public int Value { get; set; }
        public DateTime DateTimeStamp { get; set; }
    }
}
