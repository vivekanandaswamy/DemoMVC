﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>BeckhoffController </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;

    public class BeckhoffController : Controller
    {
        public string AmsNetAddress { get; set; }
        public int Comport { get; set; }
        public string TopicName { get; set; }
        public DateTime XmlDateTime { get; set; }
        public string IpAddress { get; set; }

        public override string ToString()
        {
            return string.Format("ControllerId:{0}|ControllerName:{1}|IpAddress:{2}|ComPort:{3}|TopicName:{4}|xmldatetime:{5}", this.ControllerId, this.Name, this.AmsNetAddress, this.Comport, this.TopicName, this.XmlDateTime);
        }
    }
}