﻿// -----------------------------------------------------------------------
// <copyright file="TunnelAnalogData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TunnelAnalogData </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control TunnelAnalogData
    /// </summary>
    public class TunnelAnalogData
    {
        /// <summary>
        /// Gets or sets the tunnel no.
        /// </summary>
        /// <value>
        /// The tunnel no for TunnelAnalogData.
        /// </value>
        [XmlAttribute]
        public string TunnelNo { get; set; }

        /// <summary>
        /// </summary>
        /// <value>
        /// The p h1 for TunnelAnalogData.
        /// </value>
        [XmlAttribute]
        public string pH1 { get; set; }

        /// <summary>
        /// </summary>
        /// <value>
        /// The p h2 for TunnelAnalogData.
        /// </value>
        [XmlAttribute]
        public string pH2 { get; set; } // pH2 / pH waste water

        /// <summary>
        /// </summary>
        /// <value>
        /// The lf for TunnelAnalogData.
        /// </value>
        [XmlAttribute]
        public string LF { get; set; }

        /// <summary>
        /// Gets or sets the weight.
        /// </summary>
        /// <value>
        /// The weight for TunnelAnalogData.
        /// </value>
        [XmlAttribute]
        public string Weight { get; set; }

        /// <summary>
        /// Gets or sets the temperature1.
        /// </summary>
        /// <value>
        /// The temperature1 for TunnelAnalogData.
        /// </value>
        [XmlAttribute]
        public string Temperature1 { get; set; }

        /// <summary>
        /// Gets or sets the temperature2.
        /// </summary>
        /// <value>
        /// The temperature2 for TunnelAnalogData.
        /// </value>
        [XmlAttribute]
        public string Temperature2 { get; set; }

        /// <summary>
        /// Gets or sets the temperature3.
        /// </summary>
        /// <value>
        /// The temperature3.
        /// </value>
        [XmlAttribute]
        public string Temperature3 { get; set; }

        /// <summary>
        /// Gets or sets the temperature4.
        /// </summary>
        /// <value>
        /// The temperature4.
        /// </value>
        [XmlAttribute]
        public string Temperature4 { get; set; }

        /// <summary>
        /// Gets or sets the temperature5.
        /// </summary>
        /// <value>
        /// The temperature5.
        /// </value>
        [XmlAttribute]
        public string Temperature5 { get; set; }

        /// <summary>
        /// Gets or sets the temperature6.
        /// </summary>
        /// <value>
        /// The temperature6.
        /// </value>
        [XmlAttribute]
        public string Temperature6 { get; set; }
    }
}
