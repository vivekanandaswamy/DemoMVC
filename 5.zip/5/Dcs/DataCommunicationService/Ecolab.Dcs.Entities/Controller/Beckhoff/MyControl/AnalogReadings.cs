﻿// -----------------------------------------------------------------------
// <copyright file="AnalogReadings.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>AnalogReadings </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control AnalogReadings
    /// </summary>
    public class AnalogReadings
    {
        /// <summary>
        /// Gets or sets the we data.
        /// </summary>
        /// <value>
        /// The we data for AnalogReadings.
        /// </value>
        [XmlElement("WEAnalogData")]
        public List<WEAnalogData> WEData { get; set; } //1 To 16
        /// <summary>
        /// Gets or sets the tunnel data.
        /// </summary>
        /// <value>
        /// The tunnel data for AnalogReadings.
        /// </value>
        [XmlElement("TunnelAnalogData")]
        public List<TunnelAnalogData> TunnelData { get; set; } //1 To 2
        /// <summary>
        /// Gets or sets the lp data.
        /// </summary>
        /// <value>
        /// The lp data for AnalogReadings.
        /// </value>
        [XmlElement("LevelProduct")]
        public List<LevelProduct> LPData { get; set; } //1 To 16
    }
}
