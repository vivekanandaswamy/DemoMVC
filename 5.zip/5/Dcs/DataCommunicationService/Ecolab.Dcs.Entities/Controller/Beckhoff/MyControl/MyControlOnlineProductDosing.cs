﻿// -----------------------------------------------------------------------
// <copyright file="MyControlOnlineProductDosing.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MyControlOnlineProductDosing </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    public class MyControlOnlineProductDosing
    {
        [XmlAttribute]
        public string Time { get; set; }
        [XmlAttribute]
        public string TheoreticalQty { get; set; }
        [XmlAttribute]
        public string DosingPoint { get; set; }
        [XmlAttribute]
        public string DoseNumber { get; set; }
        [XmlAttribute]
        public string ProgramNumber { get; set; }
        [XmlAttribute]
        public string BatchNumber { get; set; }
        [XmlAttribute]
        public string ValveNumber { get; set; }
        [XmlAttribute]
        public string RealQty { get; set; }
        [XmlAttribute]
        public string PumpNum { get; set; }
    }
}
