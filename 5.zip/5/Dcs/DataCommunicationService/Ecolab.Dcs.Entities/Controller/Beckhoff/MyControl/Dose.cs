﻿// -----------------------------------------------------------------------
// <copyright file="Dose.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Dose </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control Dose
    /// </summary>
    public class Dose
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Dose"/> class.
        /// </summary>
        public Dose()
        {
            Time = string.Empty;
            Quantity = string.Empty;
            Point = string.Empty;
            Number = string.Empty;
        }

        /// <summary>
        /// Gets or sets the time.
        /// </summary>
        /// <value>
        /// The time for Dose.
        /// </value>
        [XmlAttribute]
        public string Time { get; set; }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>
        /// The quantity for Dose.
        /// </value>
        [XmlAttribute]
        public string Quantity { get; set; }

        /// <summary>
        /// Gets or sets the point.
        /// </summary>
        /// <value>
        /// The point for Dose.
        /// </value>
        [XmlAttribute]
        public string Point { get; set; }

        /// <summary>
        /// Gets or sets the number.
        /// </summary>
        /// <value>
        /// The number for Dose.
        /// </value>
        [XmlAttribute]
        public string Number { get; set; }

        /// <summary>
        /// Gets or sets the is main equipment.
        /// </summary>
        /// <value>
        /// The is main equipment.
        /// </value>
        [XmlAttribute]
        public string IsMainEquipment { get; set; }

        /// <summary>
        /// Gets or sets the is direct dosing.
        /// </summary>
        /// <value>
        /// The is direct dosing.
        /// </value>
        [XmlAttribute]
        public string IsDirectDosing { get; set; }
    }
}
