﻿// -----------------------------------------------------------------------
// <copyright file="WEAnalogData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>WEAnalogData </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control WEAnalogData
    /// </summary>
    public class WEAnalogData
    {
        /// <summary>
        /// Gets or sets the we number.
        /// </summary>
        /// <value>
        /// The we number for WEAnalogData.
        /// </value>
        [XmlAttribute]
        public string WENumber { get; set; }
        /// <summary>
        /// Gets or sets the temperature.
        /// </summary>
        /// <value>
        /// The temperature for WEAnalogData.
        /// </value>
        [XmlAttribute]
        public string Temperature { get; set; }
        /// <summary>
        /// </summary>
        /// <value>
        /// The p h for WEAnalogData.
        /// </value>
        [XmlAttribute]
        public string pH { get; set; } //TODO:Check the datatype whether int/datetime/long?
    }
}
