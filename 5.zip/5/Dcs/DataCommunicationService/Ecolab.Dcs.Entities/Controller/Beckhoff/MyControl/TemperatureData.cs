﻿// -----------------------------------------------------------------------
// <copyright file="TemperatureData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TemperatureData </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control TemperatureData
    /// </summary>
    public class TemperatureData
    {
        /// <summary>
        /// Gets or sets the minimum.
        /// </summary>
        /// <value>
        /// The minimum for TemperatureData.
        /// </value>
        [XmlAttribute]
        public string Minimum { get; set; }
        /// <summary>
        /// Gets or sets the maximum.
        /// </summary>
        /// <value>
        /// The maximum for TemperatureData.
        /// </value>
        [XmlAttribute]
        public string Maximum { get; set; }
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status for TemperatureData.
        /// </value>
        [XmlAttribute]
        public string Status { get; set; }
        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value for TemperatureData.
        /// </value>
        [XmlAttribute]
        public string Value { get; set; }
        /// <summary>
        /// Gets or sets the compartment.
        /// </summary>
        /// <value>
        /// The compartment for TemperatureData.
        /// </value>
        [XmlAttribute]
        public string Compartment { get; set; }
    }
}
