﻿// -----------------------------------------------------------------------
// <copyright file="MyControlConventionalData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MyControlConventionalData </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    public class MyControlConventionalData : ConventionalWasherData
    {        
    }
}
