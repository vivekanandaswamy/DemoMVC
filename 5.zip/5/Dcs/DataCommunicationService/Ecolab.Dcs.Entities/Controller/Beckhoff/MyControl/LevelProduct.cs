﻿// -----------------------------------------------------------------------
// <copyright file="LevelProduct.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>LevelProduct </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control LevelProduct
    /// </summary>
    public class LevelProduct
    {
        /// <summary>
        /// Gets or sets the lp number.
        /// </summary>
        /// <value>
        /// The lp number for LevelProduct.
        /// </value>
        [XmlAttribute]
        public string LPNumber { get; set; }

        /// <summary>
        /// Gets or sets me number.
        /// </summary>
        /// <value>
        /// Me number for LevelProduct.
        /// </value>
        [XmlAttribute]
        public string MENumber { get; set; }

        /// <summary>
        /// Gets or sets the lp value.
        /// </summary>
        /// <value>
        /// The lp value for LevelProduct.
        /// </value>
        [XmlAttribute]
        public string LPValue { get; set; }
    }
}
