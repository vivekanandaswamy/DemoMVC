﻿// -----------------------------------------------------------------------
// <copyright file="CompartmentTime.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>CompartmentTime </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control CompartmentTime
    /// </summary>
    public class CompartmentTime
    {
        /// <summary>
        /// Gets or sets the compartment no.
        /// </summary>
        /// <value>
        /// The compartment no.
        /// </value>
        [XmlAttribute]
        public string CompartmentNo { get; set; }

        /// <summary>
        /// Gets or sets the time.
        /// </summary>
        /// <value>
        /// The time CompartmentTime.
        /// </value>
        [XmlAttribute]
        public string Time { get; set; } //TODO:Check the datatype whether int/datetime/long?
    }
}
