﻿// -----------------------------------------------------------------------
// <copyright file="uints_Helms_HT.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>uints_Helms_ConfigCNAndHelms </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class uints_Helms_HT
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        private ushort[] Uint_Transfer_TUNValue = new ushort[2];
        public List<ushort> Uint_Transfer_TUN
        {
            get { return Uint_Transfer_TUNValue.ToList(); }          
        }
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class uints_Helms_ConfigCNAndHelms
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
       public ushort[] uint_ME_Parameter = new ushort[2];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
       public ushort[] uint_Pump_Parameter = new ushort[24];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
       public ushort[] uint_LF_Setup = new ushort[6];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
       public ushort[] uint_pH_Setup = new ushort[6];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 352)]
       public ushort[] uint_Tun_Parameter = new ushort[352];//  2*176

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 597)]
        public ushort[] uint_ProgCategory = new ushort[597]; //1   3 , 199

       public List<ushort> uint_Handshake { get; set; }
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
     public class Uints_Helms_ConfigCN
    {
        public ushort uint_Connex_Alarm_Delay { get; set; }
        public ushort uint_Connex_Level_Delay { get; set; }
        public ushort uint_FlushSystem_Alarm_Delay { get; set; }
        public ushort uint_FlushSystem_Level_Delay { get; set; }
        public ushort uint_HelmsTimout { get; set; }
        public ushort uint_ResetAlrmTime { get; set; }
        public ushort uint_StopDubixTime { get; set; }
        public ushort uint_IntermRinseTime { get; set; }
        public ushort uint_AlarmAnalogFilter { get; set; }

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public ushort[] uint_LinetoWaterFS = new ushort[16];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public ushort[] uint_FlushWEtoWaterFS = new ushort[16];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1152)]
        public ushort[] uint_WE_Parameter = new ushort[16 * 72];
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = UnmanagedType.Struct)]
        public AnalogLevelSetup[] Analog_Level_Setup = new AnalogLevelSetup[16];
        public ushort uint_Handshake { get; set; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct Uints_PumpParameter
    {
        public ushort PumpCalib;
        public ushort DosLine;
        public ushort FMCalib;
        public ushort FMMaxTime;
        public ushort FSDelay;
        public ushort AuxiliaryPumpCalib;
        public ushort TUNNb_DD;
        public ushort CompNb_DD;

    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct Uints_MEParameter
    {
        public ushort PumpCalib;
        public ushort DosLine;
        public ushort FMCalib;
        public ushort FMMaxTime;
        public ushort FSDelay;
        public ushort METype;
        public ushort PreFlushTime;
        public ushort FlushPumpingtime;
        public ushort StNightFlush;
        public ushort NightFlushTime;
    }
        
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct Uints_pHLFSetup
    {
        public ushort Setpoint;
        public ushort DelayTrsf;
        public ushort FirstDose;
        public ushort FisrtPause;
        public ushort Dose;
        public ushort Pause;
        public ushort MaxTime;
        public ushort MinVal;
        public ushort MaxVal;
        public ushort CtrlDelay;
    }
     [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct AnalogLevelSetup
    {
        public ushort uint_EmptyLevel;
	    public ushort uint_LowLevel;
	    public ushort uint_HighLevel;
	    public ushort uint_MaximumLevel;
	    public ushort uint_CalibrationLevel;
        public ushort uint_0_4mA;
        public ushort uint_Activated;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class Uints_Helms_ConfigCNAndHelms_2
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2, ArraySubType = UnmanagedType.Struct)]
        public Uints_MEParameter[] uint_ME_Parameter = new Uints_MEParameter[2];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24, ArraySubType = UnmanagedType.Struct)]
        public Uints_PumpParameter[] uint_Pump_Parameter = new Uints_PumpParameter[24];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.Struct)]
        public Uints_pHLFSetup[] uint_LF_Setup = new Uints_pHLFSetup[6];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.Struct)]
        public Uints_pHLFSetup[] uint_pH_Setup = new Uints_pHLFSetup[6];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2 * 176)]
        public ushort[] uint_Tun_Parameter = new ushort[2 * 176];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 297)]
        public ushort[] uint_ProgCategory = new ushort[3 * 99];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public ushort[] uint_TCR_PumpNb = new ushort[3];

        public ushort uint_Handshake { get; set; }

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public ushort[] uint_Tun_TempSpecial = new ushort[12];
    }
     [StructLayout(LayoutKind.Sequential, Pack = 1)]
    [Serializable]
    public class Xs_Helms_ConfigCN
    {

        [MarshalAs(UnmanagedType.I1)]
        public bool x_AlmPrgNotFinishDis;

         [MarshalAs(UnmanagedType.I1)]
        public bool x_Connex_En;

        [MarshalAs(UnmanagedType.I1)]
        public bool x_FlushControlEn;
         [MarshalAs(UnmanagedType.I1)]
        public bool x_FlushLeakEn;
        [MarshalAs(UnmanagedType.I1)]
        public bool x_FlushSystem_En;
        [MarshalAs(UnmanagedType.I1)]
        public bool x_HelmsTimoutEn;

         [MarshalAs(UnmanagedType.I1)]
        public bool x_PMREn;
         [MarshalAs(UnmanagedType.I1)]
        public bool x_Reset_Button_En;
         [MarshalAs(UnmanagedType.I1)]
        public bool x_SeparateAirStopAlarm;

         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3, ArraySubType = UnmanagedType.I1)]
        public bool[] x_UseFlowMeter_for_FlowCheck = new bool[3];

         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 648, ArraySubType = UnmanagedType.I1)]
        public bool[] x_StopEjectTunCondition = new bool[648];  //ARRAY [1..2, 1..2,1..162]

        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16 * 155)]
         [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16 * 155, ArraySubType = UnmanagedType.I1)]
        public bool[] x_StopWeCondition = new bool[16 * 155];   //ARRAY [1..16, 1..155]

         [MarshalAs(UnmanagedType.I1)]
        public bool x_Handshake;
    }

       [StructLayout(LayoutKind.Sequential, Pack = 1)]
     public struct xs_EquipParameter
     {
         [MarshalAs(UnmanagedType.I1)]
         public bool FMEnable;
         [MarshalAs(UnmanagedType.I1)]
         public bool FSEnable;
         [MarshalAs(UnmanagedType.I1)]
         public bool FMFSActive;
         [MarshalAs(UnmanagedType.I1)]
         public bool WeightControl;
         [MarshalAs(UnmanagedType.I1)]
         public bool PDosAlone;
         [MarshalAs(UnmanagedType.I1)]
         public bool FlushWDos;
         [MarshalAs(UnmanagedType.I1)]
         public bool LLAlarm;
         [MarshalAs(UnmanagedType.I1)]
         public bool LeakAlarm;
         [MarshalAs(UnmanagedType.I1)]
         public bool DirectDosing;
     }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class Xs_Helms_ConfigCNAndHelms
    {
        
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3, ArraySubType = UnmanagedType.I1)]
        public bool[] x_LineDosingMode = new bool[3];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3, ArraySubType = UnmanagedType.I1)]
        public bool[] x_AuxiliaryPumpUsed = new bool[3];

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 26, ArraySubType = UnmanagedType.Struct)]
        public xs_EquipParameter[] x_Equip_Parameter = new xs_EquipParameter[26];

        [MarshalAs(UnmanagedType.I1)]
        public bool x_Handshake;
    }

}
