﻿// -----------------------------------------------------------------------
// <copyright file="MyControlAlarmData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MyControlAlarmData </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// My Control Alarm Data
    /// </summary>
    public class MyControlAlarmData
    {
        /// <summary>
        /// Gets or sets the alarm number.
        /// </summary>
        /// <value>
        /// The alarm number.
        /// </value>
        [XmlAttribute]
        public string AlarmNumber { get; set; }

        /// <summary>
        /// Gets or sets the start date time.
        /// </summary>
        /// <value>
        /// The start date time.
        /// </value>
        [XmlAttribute]
        public string StartDateTime { get; set; }

        /// <summary>
        /// Gets or sets the machine number.
        /// </summary>
        /// <value>
        /// The machine number.
        /// </value>
        [XmlAttribute]
        public string MachineNumber { get; set; }

        /// <summary>
        /// Gets or sets the batch number.
        /// </summary>
        /// <value>
        /// The batch number.
        /// </value>
        [XmlAttribute]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets the program number.
        /// </summary>
        /// <value>
        /// The program number.
        /// </value>
        [XmlAttribute]
        public string ProgramNumber { get; set; }

        /// <summary>
        /// Gets or sets the desired value.
        /// </summary>
        /// <value>
        /// The desired value.
        /// </value>
        [XmlAttribute]
        public string DesiredValue { get; set; }

        /// <summary>
        /// Gets or sets the measured value.
        /// </summary>
        /// <value>
        /// The measured value.
        /// </value>
        [XmlAttribute]
        public string MeasuredValue { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status of MyControl Alarm Data.
        /// </value>
        [XmlAttribute]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the stop date time.
        /// </summary>
        /// <value>
        /// The stop date time.
        /// </value>
        [XmlAttribute]
        public string StopDateTime { get; set; }

        /// <summary>
        /// Gets or sets the is tunnel.
        /// </summary>
        /// <value>
        /// The is tunnel of MyControl Alarm Data.
        /// </value>
        [XmlAttribute]
        public string IsTunnel { get; set; }

        /// <summary>
        /// Gets or sets the type of the alarm.
        /// </summary>
        /// <value>
        /// The type of the alarm.
        /// </value>
        [XmlAttribute]
        public string AlarmType { get; set; }

        /// <summary>
        /// Gets or sets the pump NBR.
        /// </summary>
        /// <value>
        /// The pump NBR of MyControl Alarm Data..
        /// </value>
        [XmlAttribute]
        public string PumpNbr { get; set; }

        /// <summary>
        /// Gets or sets the valve NBR.
        /// </summary>
        /// <value>
        /// The valve NBR of MyControl Alarm Data..
        /// </value>
        [XmlAttribute]
        public string ValveNbr { get; set; }

        /// <summary>
        /// Gets or sets the cf error code.
        /// </summary>
        /// <value>
        /// The cf error code.
        /// </value>
        [XmlAttribute]
        public string CFErrorCode { get; set; }

        /// <summary>
        /// Gets or sets the cf error detail.
        /// </summary>
        /// <value>
        /// The cf error detail.
        /// </value>
        [XmlAttribute]
        public string CFErrorDetail { get; set; }

        /// <summary>
        /// Gets or sets the probe.
        /// </summary>
        /// <value>
        /// The probe of MyControl Alarm Data..
        /// </value>
        [XmlAttribute]
        public string Probe { get; set; }

        [XmlAttribute]
        public string Group { get; set; }
    }
}
