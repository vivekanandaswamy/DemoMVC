﻿// -----------------------------------------------------------------------
// <copyright file="MyControlWandEAlarmData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MyControlWandEAlarmData </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// My Control WandE AlarmData
    /// </summary>
    public class MyControlWandEAlarmData
    {
        /// <summary>
        /// Gets or sets the wand e alarm data.
        /// </summary>
        /// <value>
        /// The wand e alarm data.
        /// </value>
        [XmlArrayItem("AlarmData", typeof(MyControlAlarmData))]
        [XmlArray("AlarmValue")]
        public List<MyControlAlarmData> WandEAlarmData { get; set; }
    }
}
