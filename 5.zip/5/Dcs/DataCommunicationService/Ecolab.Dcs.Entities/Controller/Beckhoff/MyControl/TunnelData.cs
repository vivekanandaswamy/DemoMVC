﻿// -----------------------------------------------------------------------
// <copyright file="TunnelData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TunnelData </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// public class TunnelData : Tag
    /// </summary>
    public class TunnelData
    {
        /// <summary>
        /// Gets or sets the tunnel number.
        /// </summary>
        /// <value>
        /// The tunnel number.
        /// </value>
        [XmlAttribute]
        public string TunnelNumber { get; set; }

        /// <summary>
        /// Gets or sets the machine number.
        /// </summary>
        /// <value>
        /// The machine number.
        /// </value>
        [XmlAttribute]
        public string MachineNumber { get; set; }

        /// <summary>
        /// Gets or sets the group number.
        /// </summary>
        /// <value>
        /// The group number.
        /// </value>
        [XmlAttribute]
        public string GroupNumber { get; set; }

        /// <summary>
        /// Gets or sets the compartment number.
        /// </summary>
        /// <value>
        /// The compartment number.
        /// </value>
        [XmlAttribute]
        public string CompartmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the start date time.
        /// </summary>
        /// <value>
        /// The start date time.
        /// </value>
        [XmlAttribute]
        public string StartDateTime { get; set; } //StartDateTime as DateTime

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date for TunnelData.
        /// </value>
        [XmlIgnore]
        public string StartDate { get; set; }

        /// <summary>
        /// Gets or sets the start time.
        /// </summary>
        /// <value>
        /// The start time for TunnelData.
        /// </value>
        [XmlIgnore]
        public string StartTime { get; set; }

        /// <summary>
        /// Gets or sets the end date time.
        /// </summary>
        /// <value>
        /// The end date time.
        /// </value>
        [XmlAttribute]
        public string EndDateTime { get; set; } //EndDateTime as DateTime

        /// <summary>
        /// Gets or sets the stop date.
        /// </summary>
        /// <value>
        /// The stop date for TunnelData.
        /// </value>
        [XmlIgnore]
        public string StopDate { get; set; }

        /// <summary>
        /// Gets or sets the stop time.
        /// </summary>
        /// <value>
        /// The stop time for TunnelData.
        /// </value>
        [XmlIgnore]
        public string StopTime { get; set; }

        /// <summary>
        /// Gets or sets the program number.
        /// </summary>
        /// <value>
        /// The program number.
        /// </value>
        [XmlAttribute]
        public string ProgramNumber { get; set; }

        /// <summary>
        /// Gets or sets the load.
        /// </summary>
        /// <value>
        /// The load for TunnelData.
        /// </value>
        [XmlAttribute]
        public string Load { get; set; }

        /// <summary>
        /// Gets or sets the nominalload.
        /// </summary>
        /// <value>
        /// The nominalload.
        /// </value>
        [XmlAttribute]
        public string Nominalload { get; set; }

        /// <summary>
        /// Gets or sets the customer number.
        /// </summary>
        /// <value>
        /// The customer number.
        /// </value>
        [XmlAttribute]
        public string CustomerNumber { get; set; } //TODO: Discuss whether only one customerNumber is required and calculate the second one from first one

        /// <summary>
        /// Gets or sets the customer number hb.
        /// </summary>
        /// <value>
        /// The customer number hb.
        /// </value>
        [XmlIgnore]
        public string CustomerNumberHB { get; set; }

        /// <summary>
        /// Gets or sets the customer number lb.
        /// </summary>
        /// <value>
        /// The customer number lb.
        /// </value>
        [XmlIgnore]
        public string CustomerNumberLB { get; set; }

        /// <summary>
        /// Gets or sets the batch number.
        /// </summary>
        /// <value>
        /// The batch number.
        /// </value>
        [XmlAttribute]
        public string BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets the phvalue.
        /// </summary>
        /// <value>
        /// The phvalue for TunnelData.
        /// </value>
        [XmlAttribute]
        public string Phvalue { get; set; }

        /// <summary>
        /// Gets or sets the phstatus.
        /// </summary>
        /// <value>
        /// The phstatus for TunnelData.
        /// </value>
        [XmlAttribute]
        public string Phstatus { get; set; }

        /// <summary>
        /// Gets or sets the phcompartment.
        /// </summary>
        /// <value>
        /// The phcompartment.
        /// </value>
        [XmlAttribute]
        public string Phcompartment { get; set; }

        /// <summary>
        /// Gets or sets the conductivity value.
        /// </summary>
        /// <value>
        /// The conductivity value.
        /// </value>
        [XmlAttribute]
        public string ConductivityValue { get; set; }

        /// <summary>
        /// Gets or sets the conductivity status.
        /// </summary>
        /// <value>
        /// The conductivity status.
        /// </value>
        [XmlAttribute]
        public string ConductivityStatus { get; set; }

        /// <summary>
        /// Gets or sets the conductivity compartment.
        /// </summary>
        /// <value>
        /// The conductivity compartment.
        /// </value>
        [XmlAttribute]
        public string ConductivityCompartment { get; set; }

        /// <summary>
        /// Gets or sets the lf value.
        /// </summary>
        /// <value>
        /// The lf value for TunnelData.
        /// </value>
        [XmlAttribute]
        public string LFValue { get; set; }

        /// <summary>
        /// Gets or sets the lf status.
        /// </summary>
        /// <value>
        /// The lf status for TunnelData.
        /// </value>
        [XmlAttribute]
        public string LFStatus { get; set; }

        /// <summary>
        /// Gets or sets the ejection signal.
        /// </summary>
        /// <value>
        /// The ejection signal.
        /// </value>
        [XmlAttribute]
        public string EjectionSignal { get; set; }

        /// <summary>
        /// Gets or sets the textile category.
        /// </summary>
        /// <value>
        /// The textile category.
        /// </value>
        [XmlAttribute]
        public string TextileCategory { get; set; }

        /// <summary>
        /// Gets or sets the transfer signal.
        /// </summary>
        /// <value>
        /// The transfer signal.
        /// </value>
        [XmlAttribute]
        public string TransferSignal { get; set; }

        /// <summary>
        /// Gets or sets the state of the run.
        /// </summary>
        /// <value>
        /// The state of the run.
        /// </value>
        [XmlAttribute]
        public string RunState { get; set; }

        /// <summary>
        /// Gets or sets the dose.
        /// </summary>
        /// <value>
        /// The dose for TunnelData.
        /// </value>
        [XmlElement("Dose")]
        public List<Dose> dose { get; set; } //1 To 26, 1 To 4 -- produkt Nb, Dosing Point

        //public Dose[] dose; //1 To 26, 1 To 4 -- produkt Nb, Dosing Point
        //public UInt16[] Dose; //1 To 26, 1 To 4 -- produkt Nb, Dosing Point
        /// <summary>
        /// Gets or sets the water consumption.
        /// </summary>
        /// <value>
        /// The water consumption.
        /// </value>
        [XmlElement("WaterConsumption")]
        public List<WaterConsumption> WaterConsumption { get; set; } //1 To 6

        /// <summary>
        /// Gets or sets the time compartment.
        /// </summary>
        /// <value>
        /// The time compartment.
        /// </value>
        [XmlElement("CompartmentTime")]
        public List<CompartmentTime> TimeCompartment { get; set; } //1 To 25

        /// <summary>
        /// Gets or sets the run time.
        /// </summary>
        /// <value>
        /// The run time for TunnelData.
        /// </value>
        [XmlAttribute]
        public long RunTime { get; set; } //Total batch run time

        //TODO: No Parameters will be returned from PLC from addresses 116 to 119
        /// <summary>
        /// Gets or sets the temperature.
        /// </summary>
        /// <value>
        /// The temperature for TunnelData.
        /// </value>
        [XmlElement("TemperatureData")]
        public List<TemperatureData> temperature { get; set; } //1 To 6

        //Free  
        /// <summary>
        /// Gets or sets the temperature1.
        /// </summary>
        /// <value>
        /// The temperature1 for TunnelData.
        /// </value>
        [XmlAttribute]
        public string temperature1 { get; set; }

        /// <summary>
        /// Gets or sets the temperature2.
        /// </summary>
        /// <value>
        /// The temperature2 for TunnelData.
        /// </value>
        [XmlAttribute]
        public string temperature2 { get; set; }
    }
}
