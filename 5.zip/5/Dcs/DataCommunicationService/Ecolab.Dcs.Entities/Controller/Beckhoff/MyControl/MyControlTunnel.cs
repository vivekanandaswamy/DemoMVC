﻿// -----------------------------------------------------------------------
// <copyright file="MyControlTunnel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MyControlTunnel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control Tunnel
    /// </summary>
    public class MyControlTunnel
    {
        /// <summary>
        /// Gets or sets the machine number.
        /// </summary>
        /// <value>
        /// The machine number.
        /// </value>
        [XmlAttribute]
        public string MachineNumber { get; set; }
        /// <summary>
        /// 
        /// Gets or sets the tunnels.
        /// </summary>
        /// <value>
        /// The tunnels for MyControlTunnel.
        /// </value>
        [XmlElement("TunnelData")]
        public List<TunnelData> Tunnels { get; set; } //1 To 25
    }    
}
