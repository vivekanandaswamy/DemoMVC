﻿// -----------------------------------------------------------------------
// <copyright file="WaterConsumption.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>WaterConsumption </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for My Control WaterConsumption
    /// </summary>
    public class WaterConsumption
    {
        /// <summary>
        /// Gets or sets the counter.
        /// </summary>
        /// <value>
        /// The counter for TemperatureData.
        /// </value>
        [XmlAttribute]
        public string Counter { get; set; }
        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value for TemperatureData.
        /// </value>
        [XmlAttribute]
        public string Value { get; set; }
    }
}
