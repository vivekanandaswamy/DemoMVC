﻿// -----------------------------------------------------------------------
// <copyright file="Controller.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Controller </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;

    public abstract class Controller
    {
        public int RegionID { get; set; }
        public int ControllerId { get; set; }
        public string Name { get; set; }
        public List<Washer> Washers { get; set; }
    }
}