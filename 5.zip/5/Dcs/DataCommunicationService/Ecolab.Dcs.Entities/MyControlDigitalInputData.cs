﻿// -----------------------------------------------------------------------
// <copyright file="MyControlDigitalInputData.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyControlDigitalInputData</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for MyControlDigitalInputData
    /// </summary>
    public class MyControlDigitalInputData
    {
        /// <summary>
        /// Gets or sets the current day reading.
        /// </summary>
        /// <value>
        /// The current day reading.
        /// </value>
        [XmlAttribute]
        public string CurrentDayReading { get; set; }

        /// <summary>
        /// Gets or sets the current day run time.
        /// </summary>
        /// <value>
        /// The current day run time.
        /// </value>
        [XmlAttribute]
        public string CurrentDayRunTime { get; set; }

        /// <summary>
        /// Gets or sets the previous day reading.
        /// </summary>
        /// <value>
        /// The previous day reading.
        /// </value>
        [XmlAttribute]
        public string PreviousDayReading { get; set; }

        /// <summary>
        /// Gets or sets the previous day runtime.
        /// </summary>
        /// <value>
        /// The previous day runtime.
        /// </value>
        [XmlAttribute]
        public string PreviousDayRuntime { get; set; }

        /// <summary>
        /// Gets or sets the current date.
        /// </summary>
        /// <value>
        /// The current date.
        /// </value>
        [XmlAttribute]
        public string CurrentDate { get; set; }

        /// <summary>
        /// Gets or sets the prevoius date.
        /// </summary>
        /// <value>
        /// The prevoius date.
        /// </value>
        [XmlAttribute]
        public string PrevoiusDate { get; set; }

        /// <summary>
        /// Gets or sets the input number.
        /// </summary>
        /// <value>
        /// The input number.
        /// </value>
        [XmlAttribute]
        public string InputNumber { get; set; }
    }
}
