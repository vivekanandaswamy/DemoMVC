﻿// -----------------------------------------------------------------------
// <copyright file="ComplexStruct.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ComplexStruct </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{    
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Text;
    
    /// <summary>
    /// Class for Complex Struct
    /// </summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class ComplexStruct
    {        
        /// <summary>
        ///  specifies how program should marshal the array
        ///  SizeConst specifies the number of elements the array has.
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public int[] dintArr = new int[4];

        /// <summary>
        /// The bool value for ComplexStruct
        /// </summary>
        [MarshalAs(UnmanagedType.I1)]
        public bool boolVal;        

        /// <summary>
        ///  specifies how .NET should marshal the string
        ///  SizeConst specifies the number of characters the string has.
        ///  '(inclusive the terminating null ). 
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 6)]
        public string stringVal = string.Empty;

        /// <summary>
        /// Gets the simple struct1.
        /// </summary>
        /// <value>
        /// The simple struct1 for ComplexStruct.
        /// </value>
        public SimpleStruct simpleStruct1 { get { return new SimpleStruct(); } }

        /// <summary>
        /// Gets or sets the int value.
        /// </summary>
        /// <value>
        /// The int value for ComplexStruct.
        /// </value>
        public short intVal { get; set; }

        /// <summary>
        /// Gets or sets the byte value.
        /// </summary>
        /// <value>
        /// The byte value for ComplexStruct.
        /// </value>
        public byte byteVal { get; set; }
    }    
}
