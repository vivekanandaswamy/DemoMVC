﻿// -----------------------------------------------------------------------
// <copyright file="Enum.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>UIInputType </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    public enum UIInputType
    {
        /// <summary>
        /// int Type
        /// </summary>
        TypeInt,

        /// <summary>
        ///     string type
        /// </summary>
        TypeString = 1,

        /// <summary>
        ///     bool type
        /// </summary>
        TypeBool = 2,

        /// <summary>
        ///     array type
        /// </summary>
        TypeArray = 3,

        /// <summary>
        ///     array type boolean
        /// </summary>
        TypeArrayBoolean = 4,

        /// <summary>
        ///     xml type
        /// </summary>
        TypeXml = 5,

        TypeObject = 6,

        TypeFloat = 7,
        /// <summary>
        /// WAndE Logger Data UInt32
        /// </summary>
        TypeU32Array=8,
        /// <summary>
        /// WAndE Logger Data UInt16
        /// </summary>
        TypeUInt16,

        TypeRandomArray
    }

    public enum Address
    {
        L_YEAR,
        L_MNTH,
        L_DAY,
        L_HOUR,
        L_MIN,
        L_SEC
    }
}