﻿// -----------------------------------------------------------------------
// <copyright file="MyControlWaterEnergyLoggerData.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyControlWaterEnergyLoggerData</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// Class for My Control Water Energy Logger Data
    /// </summary>
    public class MyControlWaterEnergyLoggerData
    {
        /// <summary>
        /// Gets or sets the digital input data.
        /// </summary>
        /// <value>
        /// The digital input data.
        /// </value>
        [XmlArrayItem("DigitalData", typeof(MyControlDigitalInputData))]
        [XmlArray("DigitalInputData")]
        public List<MyControlDigitalInputData> DigitalInputData { get; set; }  
    }
}
