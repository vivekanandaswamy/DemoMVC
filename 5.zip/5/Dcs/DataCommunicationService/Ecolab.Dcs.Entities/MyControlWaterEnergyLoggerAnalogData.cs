﻿// -----------------------------------------------------------------------
// <copyright file="MyControlWaterEnergyLoggerAnalogData.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyControlWaterEnergyLoggerAnalogData.</summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// Class for MyControlWaterEnergyLoggerAnalogData
    /// </summary>
    public class MyControlWaterEnergyLoggerAnalogData
    {
        /// <summary>
        /// Gets or sets the analog input data.
        /// </summary>
        /// <value>
        /// The analog input data.
        /// </value>
        [XmlArrayItem("AnalogData", typeof(MyControlAnalogInputData))]
        [XmlArray("AnalogInputData")]
        public List<MyControlAnalogInputData> AnalogInputData { get; set; }
    }
}
