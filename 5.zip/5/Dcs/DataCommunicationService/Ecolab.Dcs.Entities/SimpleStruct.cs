﻿// -----------------------------------------------------------------------
// <copyright file="SimpleStruct.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>SimpleStruct </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Runtime.InteropServices;

    /// <summary>
    /// Class for Simple Struct
    /// </summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class SimpleStruct
    {
        /// <summary>
        /// Gets or sets the lreal value.
        /// </summary>
        /// <value>
        /// The lreal value.
        /// </value>
        public double lrealVal { get; set; }

        /// <summary>
        /// Gets or sets the dint val1.
        /// </summary>
        /// <value>
        /// The dint val1.
        /// </value>
        public int dintVal1 { get; set; }
    }
}
