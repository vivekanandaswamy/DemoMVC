﻿// -----------------------------------------------------------------------
// <copyright file="MyControlAnalogInputData.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The MyControl Analog InputData class </summary>
// -----------------------------------------------------------------------
using System;
using System.Xml.Serialization;
using System.Xml;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// MyControl Analog InputData class
    /// </summary>
    public class MyControlAnalogInputData
    {
        /// <summary>
        /// Gets or sets Reading
        /// </summary>
        [XmlAttribute]
        public string Reading { get; set; }

        /// <summary>
        /// Gets or sets Counter number
        /// </summary>
        [XmlAttribute]
        public string CounterNo { get; set; }
    }
}
