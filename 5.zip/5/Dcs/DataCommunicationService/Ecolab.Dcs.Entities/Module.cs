// -----------------------------------------------------------------------
// <copyright file="Module.cs" company="Ecolab">
// �2015 Ecolab All rights reserved.
// </copyright>
// <summary>Module </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System.Collections.Generic;

    public class Module
    {
        public int ModuleId { get; set; }
        public int ModuleTypeId { get; set; }
        public string Name { get; set; }
        public double Deadband { get; set; }
        public string Unit { get; set; }
        public long RollOverPoint { get; set; }
        public IList<Tag> Tags { get; set; }
        public double MaxReading { get; set; }
        public double Usage { get; set; }
        public decimal Calibration { get; set; }
        public string UtilityType { get; set; }

        public override string ToString()
        {
            return string.Format("ModuleId:{0}|ModuleTypeId:{1}|Name:{2}|NumberOfTags:{3}", this.ModuleId, this.ModuleTypeId, this.Name, this.Tags.Count);
        }
    }
}