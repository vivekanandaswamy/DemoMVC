﻿// -----------------------------------------------------------------------
// <copyright file="TagType.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TagType </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    public enum TagType
    {
        Invalid = 0
    }
}