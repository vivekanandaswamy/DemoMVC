﻿// -----------------------------------------------------------------------
// <copyright file="WasherTags.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>WasherTags </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Dcs.Entities
{
    public class WasherTags
    {
        public WasherTags(int washerTagId, int washerId, string tagAddress, string tagType)
        {

            this.WasherTagId = washerTagId;
            this.WasherId = washerId;
            this.TagAddress = tagAddress;
            this.TagType = tagType;
        }
        public int WasherTagId { get; set; }
        public string TagAddress { get; set; }
        public string TagType { get; set; }
        public int WasherId { get; set; }
    }
}
