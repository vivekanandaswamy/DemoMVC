﻿// -----------------------------------------------------------------------
// <copyright file="Compartment.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Compartment </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for Compartment
    /// </summary>
    public class Compartment
    {
        /// <summary>
        /// Gets or sets the compartment identifier.
        /// </summary>
        /// <value>
        /// The compartment identifier.
        /// </value>
        [XmlAttribute]
        public int CompartmentId { get; set; }

        /// <summary>
        /// Gets or sets the load identifier.
        /// </summary>
        /// <value>
        /// The load identifier.
        /// </value>
        [XmlAttribute]
        public int LoadId { get; set; }

        /// <summary>
        /// Gets or sets the formula identifier.
        /// </summary>
        /// <value>
        /// The formula identifier.
        /// </value>
        [XmlAttribute]
        public int FormulaId { get; set; }

        /// <summary>
        /// Gets or sets the time stamp.
        /// </summary>
        /// <value>
        /// The time stamp.
        /// </value>
        [XmlAttribute]
        public DateTime TimeStamp { get; set; }
    }
}
