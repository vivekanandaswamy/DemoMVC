﻿// -----------------------------------------------------------------------
// <copyright file="Tunnel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Tunnel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class for Tunnel
    /// </summary>
    public class Tunnel
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [XmlAttribute]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the current formula.
        /// </summary>
        /// <value>
        /// The current formula.
        /// </value>
        [XmlAttribute]
        public int CurrentFormula { get; set; }

        /// <summary>
        /// Gets or sets the current injection.
        /// </summary>
        /// <value>
        /// The current injection.
        /// </value>
        [XmlAttribute]
        public int CurrentInjection { get; set; }

        /// <summary>
        /// Gets or sets the current operation counter.
        /// </summary>
        /// <value>
        /// The current operation counter.
        /// </value>
        [XmlAttribute]
        public int CurrentOperationCounter { get; set; }

        /// <summary>
        /// Gets or sets the EOF.
        /// </summary>
        /// <value>
        /// The EOF for Tunnel.
        /// </value>
        [XmlAttribute]
        public int Eof { get; set; }

        /// <summary>
        /// Gets or sets the time stamp.
        /// </summary>
        /// <value>
        /// The time stamp for Tunnel.
        /// </value>
        [XmlAttribute]
        public DateTime TimeStamp { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [on hold].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [on hold]; otherwise, <c>false</c>.
        /// </value>
        [XmlAttribute]
        public bool OnHold { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Tunnel"/> is awea.
        /// </summary>
        /// <value>
        ///   <c>true</c> if awea; otherwise, <c>false</c>.
        /// </value>
        [XmlAttribute]
        public bool Awea { get; set; }

        /// <summary>
        /// Gets or sets the awew.
        /// </summary>
        /// <value>
        /// The awew for Tunnel.
        /// </value>
        [XmlAttribute]
        public int Awew { get; set; }

        /// <summary>
        /// Gets or sets the customer codes.
        /// </summary>
        /// <value>
        /// The customer codes.
        /// </value>
        [XmlAttribute]
        public string CustomerCodes { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is formula modified.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is formula modified; otherwise, <c>false</c>.
        /// </value>
        [XmlAttribute]
        public bool IsFormulaModified { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is hold signal modified.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is hold signal modified; otherwise, <c>false</c>.
        /// </value>
        [XmlAttribute]
        public bool IsHoldSignalModified { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is stop sinal modified.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is stop sinal modified; otherwise, <c>false</c>.
        /// </value>
        [XmlAttribute]
        public bool IsStopSinalModified { get; set; }

        /// <summary>
        /// Gets or sets the stop signal.
        /// </summary>
        /// <value>
        /// The stop signal for Tunnel.
        /// </value>
        [XmlAttribute]
        public int StopSignal { get; set; }

        /// <summary>
        /// Gets or sets the rata.
        /// </summary>
        /// <value>
        /// The rata for Tunnel.
        /// </value>
        [XmlAttribute]
        public int RATA { get; set; }

        /// <summary>
        /// Gets or sets the e tech last dropped at.
        /// </summary>
        /// <value>
        /// The e tech last dropped at.
        /// </value>
        [XmlAttribute]
        public string ETechLastDroppedAt { get; set; }

        /// <summary>
        /// Gets or sets the comparments.
        /// </summary>
        /// <value>
        /// The comparments for Tunnel.
        /// </value>
        [XmlElement("Compartment")]
        public List<Compartment> Comparments { get; set; }
    }
}