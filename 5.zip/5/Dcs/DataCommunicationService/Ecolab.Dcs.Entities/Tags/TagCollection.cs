﻿// -----------------------------------------------------------------------
// <copyright file="TagCollection.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TagCollection </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// class for dcs Tag Collection
    /// </summary>
    [XmlRoot("Tags")]
    public class TagCollection
    {
        /// <summary>
        /// Gets or sets the tags.
        /// </summary>
        /// <value>
        /// The tags for TagCollection.
        /// </value>
        [XmlElement("Tag")]
        public List<Tag> Tags { get; set; }
    }
}
