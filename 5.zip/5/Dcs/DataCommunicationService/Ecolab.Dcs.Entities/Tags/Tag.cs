﻿// -----------------------------------------------------------------------
// <copyright file="Tag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Tag </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// class for dcs tags
    /// </summary>
    [XmlRoot]
    [XmlInclude(typeof(OpcTag))]
    [XmlInclude(typeof(BeckhoffTag))]
    public abstract class Tag
    {
        /// <summary>
        /// Gets or sets the tag identifier.
        /// </summary>
        /// <value>
        /// The tag identifier.
        /// </value>
        [XmlAttribute]
        public int TagId { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address for tags.
        /// </value>
        [XmlAttribute]
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value for tags.
        /// </value>
        [XmlAttribute]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets the type of the tag.
        /// </summary>
        /// <value>
        /// The type of the tag.
        /// </value>
        [XmlAttribute]
        public string TagType { get; set; }

        /// <summary>
        /// Returns true if ... is valid.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is valid; otherwise, <c>false</c>.
        /// </value>
        [XmlAttribute]
        public bool IsValid { get; set; }

        /// <summary>
        /// Gets or sets the time stamp.
        /// </summary>
        /// <value>
        /// The time stamp for tags.
        /// </value>
        [XmlAttribute]
        public DateTime TimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the quality.
        /// </summary>
        /// <value>
        /// The quality for tags.
        /// </value>
        [XmlAttribute]
        public string Quality { get; set; }

        /// <summary>
        /// Gets or sets the tag type identifier.
        /// </summary>
        /// <value>
        /// The tag type identifier.
        /// </value>
        [XmlAttribute]
        public int TagTypeId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is modified.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is modified; otherwise, <c>false</c>.
        /// </value>
        [XmlAttribute]
        public bool IsModified { get; set; }

        /// <summary>
        /// Gets or sets the type of the tag item.
        /// </summary>
        /// <value>
        /// The type of the tag item.
        /// </value>
        [XmlAttribute]
        public UIInputType TagItemType { get; set; }

        /// <summary>
        /// Gets or sets the sizeto read.
        /// </summary>
        /// <value>
        /// The sizeto read for tags.
        /// </value>
        [XmlAttribute]
        public int SizetoRead { get; set; }

        /// <summary>
        /// Gets or sets the batch data.
        /// </summary>
        /// <value>
        /// The batch data for tags.
        /// </value>
        [XmlAttribute]
        public List<ushort> BatchData { get; set; }

        /// <summary>
        /// Gets or sets the e tech last dropped at.
        /// </summary>
        /// <value>
        /// The e tech last dropped at.
        /// </value>
        [XmlAttribute]
        public string ETechLastDroppedAt { get; set; }

        /// <summary>
        /// Gets or sets the customer codes.
        /// </summary>
        /// <value>
        /// The customer codes for tags.
        /// </value>
        [XmlAttribute]
        public string CustomerCodes { get; set; }
        /// <summary>
        /// Gets or sets the TagIdentifier.
        /// </summary>
        /// <value>
        /// TagIdentifier for tags.
        /// </value>
        [XmlAttribute]
        public string TagIdentifier { get; set; }
    }
}