﻿// -----------------------------------------------------------------------
// <copyright file="Washer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Washer </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Dcs.Entities
{
    using System.Collections.Generic;

    public class Washer
    {
        public int WasherId { get; set; }
        public int LfsNumber { get; set; }
        public string Name { get; set; }
        public string TagTypeName { get; set; }
        public int TagId { get; set; }
        public IList<Tag> Tags { get; set; }
        public bool IsTunnel { get; set; }
        public int EndOFFormula { get; set; }
        public bool AWEAActive { get; set; }
        public bool RatioDosingActive { get; set; }
        public int ETechWasherNumber { get; set; }

        public override string ToString()
        {
			return string.Format("WasherId:{0}|LfsNumber:{1}|Name:{2}|NumberOfTags:{3}|IsTunnel{4}|EndOFFormula:{5}|AWEAActive:{6}|RatioDosingActive:{7}", this.WasherId, this.LfsNumber, this.Name, this.Tags == null ? 0 : this.Tags.Count, this.IsTunnel, this.EndOFFormula, this.AWEAActive, this.RatioDosingActive);
        }
    }
}