﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasherData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ConventionalWasherData </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
namespace Ecolab.Dcs.Entities
{
    public class ConventionalWasherData
    {
        [XmlAttribute]
        public string MachineNumber { get; set; }
        [XmlAttribute]
        public string StepNumber { get; set; }
        [XmlAttribute]
        public string StartDateTime { get; set; }
        [XmlAttribute]
        public string EndDateTime { get; set; }
        [XmlAttribute]
        public string ProgramNumber { get; set; }
        [XmlAttribute]
        public string Load { get; set; }
        [XmlAttribute]
        public string NominalLoad { get; set; }
        [XmlAttribute]
        public string CustomerNumber { get; set; }
        [XmlAttribute]
        public string WaterConsumption1 { get; set; }
        [XmlAttribute]
        public string WaterConsumption2 { get; set; }
        [XmlAttribute]
        public string PHStatus { get; set; }
        [XmlAttribute]
        public string PHValue { get; set; }
        [XmlAttribute]
        public string TemperatureMin { get; set; }
        [XmlAttribute]
        public string TemperatureMax { get; set; }
        [XmlAttribute]
        public string TemperatureMaxStatus { get; set; }
        [XmlAttribute]
        public string TemperatureMinStatus { get; set; }
        [XmlAttribute]
        public string BatchNumber { get; set; }
        [XmlAttribute]
        public string StepDuration { get; set; }
        [XmlAttribute]
        public string TotalWashTime { get; set; }
        [XmlAttribute]
        public string RunTime { get; set; }
        [XmlAttribute]
        public string CoolDownFactor { get; set; }
        [XmlArrayItem("Dosing", typeof(ConventionalDosingData))]
        [XmlArray("DosingData")]
        public List<ConventionalDosingData> DosingData { get; set; }
        [XmlArrayItem("Step", typeof(ConventionalStepData))]
        [XmlArray("StepTime")]
        public List<ConventionalStepData> StepTime { get; set; }
        [XmlArrayItem("StepConsumption", typeof(ConventionalStepWaterUsageData))]
        [XmlArray("WaterConsumptionData")]
        public List<ConventionalStepWaterUsageData> StepWaterConsumption { get; set; }
    }

}
