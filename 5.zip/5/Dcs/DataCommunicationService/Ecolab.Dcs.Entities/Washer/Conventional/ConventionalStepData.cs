﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalStepData.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Conventional Step Data class </summary>
// -----------------------------------------------------------------------

using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// Conventional Step Data class
    /// </summary>
    public class ConventionalStepData
    {
        /// <summary>
        /// Gets or sets number
        /// </summary>
        [XmlAttribute]
        public string Number { get; set; }

        /// <summary>
        /// Gets or sets time
        /// </summary>
        [XmlAttribute]
        public string Time { get; set; }
    }
}
