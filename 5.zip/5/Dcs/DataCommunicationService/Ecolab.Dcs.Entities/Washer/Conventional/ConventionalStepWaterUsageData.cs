﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalStepWaterUsageData.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Conventional Step Water Usage Data class </summary>
// -----------------------------------------------------------------------

using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// Conventional Step Water Usage Data class 
    /// </summary>
    public class ConventionalStepWaterUsageData
    {
        /// <summary>
        /// Gets or sets Step number
        /// </summary>
        [XmlAttribute]
        public string StepNo { get; set; }

        /// <summary>
        /// Gets or sets WCCounter1
        /// </summary>
        [XmlAttribute]
        public string WCCounter1 { get; set; }

        /// <summary>
        /// Gets or sets WCCounter2
        /// </summary>
        [XmlAttribute]
        public string WCCounter2 { get; set; }
    }
}
