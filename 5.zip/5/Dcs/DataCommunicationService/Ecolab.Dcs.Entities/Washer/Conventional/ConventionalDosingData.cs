﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalDosingData.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Conventional Dosing Data class </summary>
// -----------------------------------------------------------------------

using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.Dcs.Entities
{
    /// <summary>
    /// Conventional Dosing Data class
    /// </summary>
    public class ConventionalDosingData
    {
        /// <summary>
        /// Gets or sets Equipment
        /// </summary>
        [XmlAttribute]
        public string Equipment { get; set; }

        /// <summary>
        /// Gets or sets  step number
        /// </summary>
        [XmlAttribute]
        public string stepNo { get; set; }

        /// <summary>
        /// Gets or sets quantity
        /// </summary>
        [XmlAttribute]
        public string Qty { get; set; }

        /// <summary>
        /// Gets or sets isMainEquipment
        /// </summary>
        [XmlAttribute]
        public string isMainEquipment { get; set; }
    }
}
