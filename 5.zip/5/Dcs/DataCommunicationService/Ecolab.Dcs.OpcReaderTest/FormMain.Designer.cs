﻿namespace Ecolab.Dcs.OpcReaderTest
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Connect = new System.Windows.Forms.Button();
            this.txtOpcServer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTopicName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtItem1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtItem2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRead = new System.Windows.Forms.Button();
            this.txtItem2Val = new System.Windows.Forms.TextBox();
            this.txtItem1Val = new System.Windows.Forms.TextBox();
            this.txtItem2State = new System.Windows.Forms.TextBox();
            this.txtItem1State = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtItem2TimeStamp = new System.Windows.Forms.TextBox();
            this.txtItem1TimeStamp = new System.Windows.Forms.TextBox();
            this.txtItem2Quality = new System.Windows.Forms.TextBox();
            this.txtItem1Quality = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtItem3TimeStamp = new System.Windows.Forms.TextBox();
            this.txtItem3Quality = new System.Windows.Forms.TextBox();
            this.txtItem3State = new System.Windows.Forms.TextBox();
            this.txtItem3Val = new System.Windows.Forms.TextBox();
            this.txtItem3 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btnStop = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnWrite = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtItem4B_Type = new System.Windows.Forms.TextBox();
            this.txtItem3B_Type = new System.Windows.Forms.TextBox();
            this.txtItem1B_Type = new System.Windows.Forms.TextBox();
            this.txtItem2B_Type = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtItemB4_TimeStamp = new System.Windows.Forms.TextBox();
            this.txtItemB4_Quantity = new System.Windows.Forms.TextBox();
            this.txtItemB4_Status = new System.Windows.Forms.TextBox();
            this.textItemB_LHSTREQVal = new System.Windows.Forms.TextBox();
            this.txtItemBLHSTXML = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.btnValidate_Beckhoff = new System.Windows.Forms.Button();
            this.txtBTopicName = new System.Windows.Forms.TextBox();
            this.lblBTopicName = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.btnWrite_Continue = new System.Windows.Forms.Button();
            this.btnWrite_Beckhoff = new System.Windows.Forms.Button();
            this.btnRead_Beckhoff = new System.Windows.Forms.Button();
            this.txtItemB1_TimeStamp = new System.Windows.Forms.TextBox();
            this.txtItemB3_TimeStamp = new System.Windows.Forms.TextBox();
            this.txtItemB3_Quantity = new System.Windows.Forms.TextBox();
            this.txtItemB3_Status = new System.Windows.Forms.TextBox();
            this.txtItemB_OpcVal = new System.Windows.Forms.TextBox();
            this.txtItemB_Opc = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtItemB_FrmVal = new System.Windows.Forms.TextBox();
            this.txtItemB_InjVal = new System.Windows.Forms.TextBox();
            this.txtItemB2_TimeStamp = new System.Windows.Forms.TextBox();
            this.txtItemB1_Status = new System.Windows.Forms.TextBox();
            this.txtItemB2_Status = new System.Windows.Forms.TextBox();
            this.txtItemB2_Quantity = new System.Windows.Forms.TextBox();
            this.txtItemB1_Quantity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtItemB_Inj = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtItem1B_Frm = new System.Windows.Forms.TextBox();
            this.txtComport = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtIpAddress = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtArrIndex = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtArrIndexVal = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.btnWordRead = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnWordWrite = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.btnReadfrom = new System.Windows.Forms.Button();
            this.btnWriteto = new System.Windows.Forms.Button();
            this.btnReadArr = new System.Windows.Forms.Button();
            this.btnWriteArr = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.lstResult = new System.Windows.Forms.ListBox();
            this.label38 = new System.Windows.Forms.Label();
            this.tBIntArr = new System.Windows.Forms.TextBox();
            this.tBByteVal = new System.Windows.Forms.TextBox();
            this.tBStr1RealVal = new System.Windows.Forms.TextBox();
            this.tBStr1IntVal = new System.Windows.Forms.TextBox();
            this.tBStrVal = new System.Windows.Forms.TextBox();
            this.tBBoolVal = new System.Windows.Forms.TextBox();
            this.tBIntVal = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.txtIPEMEA = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.gbReadBatch = new System.Windows.Forms.GroupBox();
            this.lstBatchData = new System.Windows.Forms.ListBox();
            this.dgvBatch = new System.Windows.Forms.DataGridView();
            this.btnReadBatch = new System.Windows.Forms.Button();
            this.lblControllerType = new System.Windows.Forms.Label();
            this.cbControllerType = new System.Windows.Forms.ComboBox();
            this.lblTagName = new System.Windows.Forms.Label();
            this.cbTagName = new System.Windows.Forms.ComboBox();
            this.tbTopicEMEA = new System.Windows.Forms.TextBox();
            this.lblTopicEMEA = new System.Windows.Forms.Label();
            this.tbPortEMEA = new System.Windows.Forms.TextBox();
            this.lblComPort = new System.Windows.Forms.Label();
            this.tbIPEMEA = new System.Windows.Forms.TextBox();
            this.lblAMSNetAdrs = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.txtMIIPAddress = new System.Windows.Forms.TextBox();
            this.txtArrayValues = new System.Windows.Forms.TextBox();
            this.txtMiCount = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtMiLocation = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.txtTotalWeight = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtETechXml = new System.Windows.Forms.TextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.txtETechIpAddress = new System.Windows.Forms.TextBox();
            this.txtETechlWasherId = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.gbReadBatch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBatch)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Connect
            // 
            this.btn_Connect.Location = new System.Drawing.Point(825, 46);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(75, 23);
            this.btn_Connect.TabIndex = 0;
            this.btn_Connect.Text = "Validate";
            this.btn_Connect.UseVisualStyleBackColor = true;
            this.btn_Connect.Click += new System.EventHandler(this.btn_Connect_Click);
            // 
            // txtOpcServer
            // 
            this.txtOpcServer.Location = new System.Drawing.Point(103, 14);
            this.txtOpcServer.Name = "txtOpcServer";
            this.txtOpcServer.Size = new System.Drawing.Size(205, 20);
            this.txtOpcServer.TabIndex = 6;
            this.txtOpcServer.Text = "Matrikon.OPC.Simulation.1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "OpcServer";
            // 
            // txtTopicName
            // 
            this.txtTopicName.Location = new System.Drawing.Point(103, 40);
            this.txtTopicName.Name = "txtTopicName";
            this.txtTopicName.Size = new System.Drawing.Size(205, 20);
            this.txtTopicName.TabIndex = 8;
            this.txtTopicName.Text = "UNIT6";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Topic";
            // 
            // txtItem1
            // 
            this.txtItem1.Location = new System.Drawing.Point(101, 92);
            this.txtItem1.Name = "txtItem1";
            this.txtItem1.Size = new System.Drawing.Size(41, 20);
            this.txtItem1.TabIndex = 10;
            this.txtItem1.Text = "N7:0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "ITEM 1";
            // 
            // txtItem2
            // 
            this.txtItem2.Location = new System.Drawing.Point(103, 118);
            this.txtItem2.Name = "txtItem2";
            this.txtItem2.Size = new System.Drawing.Size(41, 20);
            this.txtItem2.TabIndex = 12;
            this.txtItem2.Text = "N7:1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "ITEM 2";
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(825, 17);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(75, 23);
            this.btnRead.TabIndex = 13;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // txtItem2Val
            // 
            this.txtItem2Val.Location = new System.Drawing.Point(160, 118);
            this.txtItem2Val.Name = "txtItem2Val";
            this.txtItem2Val.Size = new System.Drawing.Size(41, 20);
            this.txtItem2Val.TabIndex = 15;
            // 
            // txtItem1Val
            // 
            this.txtItem1Val.Location = new System.Drawing.Point(160, 92);
            this.txtItem1Val.Name = "txtItem1Val";
            this.txtItem1Val.Size = new System.Drawing.Size(41, 20);
            this.txtItem1Val.TabIndex = 14;
            // 
            // txtItem2State
            // 
            this.txtItem2State.Location = new System.Drawing.Point(218, 118);
            this.txtItem2State.Name = "txtItem2State";
            this.txtItem2State.ReadOnly = true;
            this.txtItem2State.Size = new System.Drawing.Size(41, 20);
            this.txtItem2State.TabIndex = 17;
            // 
            // txtItem1State
            // 
            this.txtItem1State.Location = new System.Drawing.Point(216, 92);
            this.txtItem1State.Name = "txtItem1State";
            this.txtItem1State.ReadOnly = true;
            this.txtItem1State.Size = new System.Drawing.Size(41, 20);
            this.txtItem1State.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(100, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(159, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Value";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(215, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Status";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(326, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 26;
            this.label8.Text = "TimeStamp";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(270, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Quality";
            // 
            // txtItem2TimeStamp
            // 
            this.txtItem2TimeStamp.Location = new System.Drawing.Point(329, 118);
            this.txtItem2TimeStamp.Name = "txtItem2TimeStamp";
            this.txtItem2TimeStamp.ReadOnly = true;
            this.txtItem2TimeStamp.Size = new System.Drawing.Size(151, 20);
            this.txtItem2TimeStamp.TabIndex = 24;
            // 
            // txtItem1TimeStamp
            // 
            this.txtItem1TimeStamp.Location = new System.Drawing.Point(330, 92);
            this.txtItem1TimeStamp.Name = "txtItem1TimeStamp";
            this.txtItem1TimeStamp.ReadOnly = true;
            this.txtItem1TimeStamp.Size = new System.Drawing.Size(150, 20);
            this.txtItem1TimeStamp.TabIndex = 23;
            // 
            // txtItem2Quality
            // 
            this.txtItem2Quality.Location = new System.Drawing.Point(273, 118);
            this.txtItem2Quality.Name = "txtItem2Quality";
            this.txtItem2Quality.ReadOnly = true;
            this.txtItem2Quality.Size = new System.Drawing.Size(41, 20);
            this.txtItem2Quality.TabIndex = 22;
            // 
            // txtItem1Quality
            // 
            this.txtItem1Quality.Location = new System.Drawing.Point(271, 92);
            this.txtItem1Quality.Name = "txtItem1Quality";
            this.txtItem1Quality.ReadOnly = true;
            this.txtItem1Quality.Size = new System.Drawing.Size(41, 20);
            this.txtItem1Quality.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = "ITEM 3";
            // 
            // txtItem3TimeStamp
            // 
            this.txtItem3TimeStamp.Location = new System.Drawing.Point(330, 146);
            this.txtItem3TimeStamp.Name = "txtItem3TimeStamp";
            this.txtItem3TimeStamp.ReadOnly = true;
            this.txtItem3TimeStamp.Size = new System.Drawing.Size(150, 20);
            this.txtItem3TimeStamp.TabIndex = 32;
            // 
            // txtItem3Quality
            // 
            this.txtItem3Quality.Location = new System.Drawing.Point(274, 146);
            this.txtItem3Quality.Name = "txtItem3Quality";
            this.txtItem3Quality.ReadOnly = true;
            this.txtItem3Quality.Size = new System.Drawing.Size(41, 20);
            this.txtItem3Quality.TabIndex = 31;
            // 
            // txtItem3State
            // 
            this.txtItem3State.Location = new System.Drawing.Point(219, 146);
            this.txtItem3State.Name = "txtItem3State";
            this.txtItem3State.ReadOnly = true;
            this.txtItem3State.Size = new System.Drawing.Size(41, 20);
            this.txtItem3State.TabIndex = 30;
            // 
            // txtItem3Val
            // 
            this.txtItem3Val.Location = new System.Drawing.Point(161, 146);
            this.txtItem3Val.Name = "txtItem3Val";
            this.txtItem3Val.Size = new System.Drawing.Size(41, 20);
            this.txtItem3Val.TabIndex = 29;
            // 
            // txtItem3
            // 
            this.txtItem3.Location = new System.Drawing.Point(104, 146);
            this.txtItem3.Name = "txtItem3";
            this.txtItem3.Size = new System.Drawing.Size(41, 20);
            this.txtItem3.TabIndex = 28;
            this.txtItem3.Text = "N7:2";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(906, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 33;
            this.button1.Text = "Continue";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(11, 172);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(975, 193);
            this.dataGridView1.TabIndex = 34;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(13, 371);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(975, 162);
            this.dataGridView2.TabIndex = 35;
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(906, 46);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 36;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(997, 542);
            this.tabControl1.TabIndex = 37;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnWrite);
            this.tabPage2.Controls.Add(this.txtItem1TimeStamp);
            this.tabPage2.Controls.Add(this.btnStop);
            this.tabPage2.Controls.Add(this.btn_Connect);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Controls.Add(this.txtOpcServer);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.txtItem3TimeStamp);
            this.tabPage2.Controls.Add(this.txtTopicName);
            this.tabPage2.Controls.Add(this.txtItem3Quality);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.txtItem3State);
            this.tabPage2.Controls.Add(this.txtItem1);
            this.tabPage2.Controls.Add(this.txtItem3Val);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.txtItem3);
            this.tabPage2.Controls.Add(this.txtItem2);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.btnRead);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtItem1Val);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txtItem2Val);
            this.tabPage2.Controls.Add(this.txtItem2TimeStamp);
            this.tabPage2.Controls.Add(this.txtItem1State);
            this.tabPage2.Controls.Add(this.txtItem2State);
            this.tabPage2.Controls.Add(this.txtItem2Quality);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtItem1Quality);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(989, 516);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "AllenBradley";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(825, 76);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(75, 23);
            this.btnWrite.TabIndex = 37;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtItem4B_Type);
            this.tabPage1.Controls.Add(this.txtItem3B_Type);
            this.tabPage1.Controls.Add(this.txtItem1B_Type);
            this.tabPage1.Controls.Add(this.txtItem2B_Type);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.txtItemB4_TimeStamp);
            this.tabPage1.Controls.Add(this.txtItemB4_Quantity);
            this.tabPage1.Controls.Add(this.txtItemB4_Status);
            this.tabPage1.Controls.Add(this.textItemB_LHSTREQVal);
            this.tabPage1.Controls.Add(this.txtItemBLHSTXML);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.btnValidate_Beckhoff);
            this.tabPage1.Controls.Add(this.txtBTopicName);
            this.tabPage1.Controls.Add(this.lblBTopicName);
            this.tabPage1.Controls.Add(this.dataGridView3);
            this.tabPage1.Controls.Add(this.btnWrite_Continue);
            this.tabPage1.Controls.Add(this.btnWrite_Beckhoff);
            this.tabPage1.Controls.Add(this.btnRead_Beckhoff);
            this.tabPage1.Controls.Add(this.txtItemB1_TimeStamp);
            this.tabPage1.Controls.Add(this.txtItemB3_TimeStamp);
            this.tabPage1.Controls.Add(this.txtItemB3_Quantity);
            this.tabPage1.Controls.Add(this.txtItemB3_Status);
            this.tabPage1.Controls.Add(this.txtItemB_OpcVal);
            this.tabPage1.Controls.Add(this.txtItemB_Opc);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.txtItemB_FrmVal);
            this.tabPage1.Controls.Add(this.txtItemB_InjVal);
            this.tabPage1.Controls.Add(this.txtItemB2_TimeStamp);
            this.tabPage1.Controls.Add(this.txtItemB1_Status);
            this.tabPage1.Controls.Add(this.txtItemB2_Status);
            this.tabPage1.Controls.Add(this.txtItemB2_Quantity);
            this.tabPage1.Controls.Add(this.txtItemB1_Quantity);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.txtItemB_Inj);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.txtItem1B_Frm);
            this.tabPage1.Controls.Add(this.txtComport);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.txtIpAddress);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(989, 516);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Beckhoff-NA";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtItem4B_Type
            // 
            this.txtItem4B_Type.Location = new System.Drawing.Point(297, 173);
            this.txtItem4B_Type.Name = "txtItem4B_Type";
            this.txtItem4B_Type.ReadOnly = true;
            this.txtItem4B_Type.Size = new System.Drawing.Size(41, 20);
            this.txtItem4B_Type.TabIndex = 79;
            // 
            // txtItem3B_Type
            // 
            this.txtItem3B_Type.Location = new System.Drawing.Point(297, 146);
            this.txtItem3B_Type.Name = "txtItem3B_Type";
            this.txtItem3B_Type.Size = new System.Drawing.Size(41, 20);
            this.txtItem3B_Type.TabIndex = 78;
            this.txtItem3B_Type.Text = "0";
            // 
            // txtItem1B_Type
            // 
            this.txtItem1B_Type.Location = new System.Drawing.Point(296, 92);
            this.txtItem1B_Type.Name = "txtItem1B_Type";
            this.txtItem1B_Type.Size = new System.Drawing.Size(41, 20);
            this.txtItem1B_Type.TabIndex = 76;
            this.txtItem1B_Type.Text = "0";
            // 
            // txtItem2B_Type
            // 
            this.txtItem2B_Type.Location = new System.Drawing.Point(296, 118);
            this.txtItem2B_Type.Name = "txtItem2B_Type";
            this.txtItem2B_Type.Size = new System.Drawing.Size(41, 20);
            this.txtItem2B_Type.TabIndex = 77;
            this.txtItem2B_Type.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(293, 76);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 13);
            this.label22.TabIndex = 75;
            this.label22.Text = "DataType";
            // 
            // txtItemB4_TimeStamp
            // 
            this.txtItemB4_TimeStamp.Location = new System.Drawing.Point(484, 173);
            this.txtItemB4_TimeStamp.Name = "txtItemB4_TimeStamp";
            this.txtItemB4_TimeStamp.ReadOnly = true;
            this.txtItemB4_TimeStamp.Size = new System.Drawing.Size(150, 20);
            this.txtItemB4_TimeStamp.TabIndex = 59;
            // 
            // txtItemB4_Quantity
            // 
            this.txtItemB4_Quantity.Location = new System.Drawing.Point(428, 173);
            this.txtItemB4_Quantity.Name = "txtItemB4_Quantity";
            this.txtItemB4_Quantity.ReadOnly = true;
            this.txtItemB4_Quantity.Size = new System.Drawing.Size(41, 20);
            this.txtItemB4_Quantity.TabIndex = 58;
            // 
            // txtItemB4_Status
            // 
            this.txtItemB4_Status.Location = new System.Drawing.Point(373, 173);
            this.txtItemB4_Status.Name = "txtItemB4_Status";
            this.txtItemB4_Status.ReadOnly = true;
            this.txtItemB4_Status.Size = new System.Drawing.Size(41, 20);
            this.txtItemB4_Status.TabIndex = 57;
            // 
            // textItemB_LHSTREQVal
            // 
            this.textItemB_LHSTREQVal.Location = new System.Drawing.Point(232, 173);
            this.textItemB_LHSTREQVal.Name = "textItemB_LHSTREQVal";
            this.textItemB_LHSTREQVal.Size = new System.Drawing.Size(41, 20);
            this.textItemB_LHSTREQVal.TabIndex = 56;
            // 
            // txtItemBLHSTXML
            // 
            this.txtItemBLHSTXML.Location = new System.Drawing.Point(146, 173);
            this.txtItemBLHSTXML.Name = "txtItemBLHSTXML";
            this.txtItemBLHSTXML.Size = new System.Drawing.Size(64, 20);
            this.txtItemBLHSTXML.TabIndex = 55;
            this.txtItemBLHSTXML.Text = "L_HSTXML";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(65, 176);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(42, 13);
            this.label21.TabIndex = 54;
            this.label21.Text = "ITEM 4";
            // 
            // btnValidate_Beckhoff
            // 
            this.btnValidate_Beckhoff.Location = new System.Drawing.Point(775, 40);
            this.btnValidate_Beckhoff.Name = "btnValidate_Beckhoff";
            this.btnValidate_Beckhoff.Size = new System.Drawing.Size(75, 23);
            this.btnValidate_Beckhoff.TabIndex = 53;
            this.btnValidate_Beckhoff.Text = "Validate";
            this.btnValidate_Beckhoff.UseVisualStyleBackColor = true;
            this.btnValidate_Beckhoff.Click += new System.EventHandler(this.btnValidate_Beckhoff_Click);
            // 
            // txtBTopicName
            // 
            this.txtBTopicName.Location = new System.Drawing.Point(483, 15);
            this.txtBTopicName.Name = "txtBTopicName";
            this.txtBTopicName.Size = new System.Drawing.Size(173, 20);
            this.txtBTopicName.TabIndex = 52;
            this.txtBTopicName.Text = "Elados Smart";
            // 
            // lblBTopicName
            // 
            this.lblBTopicName.AutoSize = true;
            this.lblBTopicName.Location = new System.Drawing.Point(345, 15);
            this.lblBTopicName.Name = "lblBTopicName";
            this.lblBTopicName.Size = new System.Drawing.Size(34, 13);
            this.lblBTopicName.TabIndex = 51;
            this.lblBTopicName.Text = "Topic";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(19, 212);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(975, 227);
            this.dataGridView3.TabIndex = 50;
            // 
            // btnWrite_Continue
            // 
            this.btnWrite_Continue.Location = new System.Drawing.Point(872, 12);
            this.btnWrite_Continue.Name = "btnWrite_Continue";
            this.btnWrite_Continue.Size = new System.Drawing.Size(75, 23);
            this.btnWrite_Continue.TabIndex = 49;
            this.btnWrite_Continue.Text = "Continue";
            this.btnWrite_Continue.UseVisualStyleBackColor = true;
            this.btnWrite_Continue.Click += new System.EventHandler(this.btnWrite_Continue_Click);
            // 
            // btnWrite_Beckhoff
            // 
            this.btnWrite_Beckhoff.Location = new System.Drawing.Point(775, 66);
            this.btnWrite_Beckhoff.Name = "btnWrite_Beckhoff";
            this.btnWrite_Beckhoff.Size = new System.Drawing.Size(75, 23);
            this.btnWrite_Beckhoff.TabIndex = 48;
            this.btnWrite_Beckhoff.Text = "Write";
            this.btnWrite_Beckhoff.UseVisualStyleBackColor = true;
            this.btnWrite_Beckhoff.Click += new System.EventHandler(this.btnWrite_Beckhoff_Click);
            // 
            // btnRead_Beckhoff
            // 
            this.btnRead_Beckhoff.Location = new System.Drawing.Point(775, 11);
            this.btnRead_Beckhoff.Name = "btnRead_Beckhoff";
            this.btnRead_Beckhoff.Size = new System.Drawing.Size(75, 23);
            this.btnRead_Beckhoff.TabIndex = 47;
            this.btnRead_Beckhoff.Text = "Read";
            this.btnRead_Beckhoff.UseVisualStyleBackColor = true;
            this.btnRead_Beckhoff.Click += new System.EventHandler(this.btnRead_Beckhoff_Click);
            // 
            // txtItemB1_TimeStamp
            // 
            this.txtItemB1_TimeStamp.Location = new System.Drawing.Point(484, 92);
            this.txtItemB1_TimeStamp.Name = "txtItemB1_TimeStamp";
            this.txtItemB1_TimeStamp.ReadOnly = true;
            this.txtItemB1_TimeStamp.Size = new System.Drawing.Size(150, 20);
            this.txtItemB1_TimeStamp.TabIndex = 39;
            // 
            // txtItemB3_TimeStamp
            // 
            this.txtItemB3_TimeStamp.Location = new System.Drawing.Point(484, 146);
            this.txtItemB3_TimeStamp.Name = "txtItemB3_TimeStamp";
            this.txtItemB3_TimeStamp.ReadOnly = true;
            this.txtItemB3_TimeStamp.Size = new System.Drawing.Size(150, 20);
            this.txtItemB3_TimeStamp.TabIndex = 46;
            // 
            // txtItemB3_Quantity
            // 
            this.txtItemB3_Quantity.Location = new System.Drawing.Point(428, 146);
            this.txtItemB3_Quantity.Name = "txtItemB3_Quantity";
            this.txtItemB3_Quantity.ReadOnly = true;
            this.txtItemB3_Quantity.Size = new System.Drawing.Size(41, 20);
            this.txtItemB3_Quantity.TabIndex = 45;
            // 
            // txtItemB3_Status
            // 
            this.txtItemB3_Status.Location = new System.Drawing.Point(373, 146);
            this.txtItemB3_Status.Name = "txtItemB3_Status";
            this.txtItemB3_Status.ReadOnly = true;
            this.txtItemB3_Status.Size = new System.Drawing.Size(41, 20);
            this.txtItemB3_Status.TabIndex = 44;
            // 
            // txtItemB_OpcVal
            // 
            this.txtItemB_OpcVal.Location = new System.Drawing.Point(232, 146);
            this.txtItemB_OpcVal.Name = "txtItemB_OpcVal";
            this.txtItemB_OpcVal.Size = new System.Drawing.Size(41, 20);
            this.txtItemB_OpcVal.TabIndex = 43;
            this.txtItemB_OpcVal.Text = "0";
            // 
            // txtItemB_Opc
            // 
            this.txtItemB_Opc.Location = new System.Drawing.Point(146, 146);
            this.txtItemB_Opc.Name = "txtItemB_Opc";
            this.txtItemB_Opc.Size = new System.Drawing.Size(64, 20);
            this.txtItemB_Opc.TabIndex = 42;
            this.txtItemB_Opc.Text = "W1_OPC";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(65, 149);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 13);
            this.label20.TabIndex = 41;
            this.label20.Text = "ITEM 3";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // txtItemB_FrmVal
            // 
            this.txtItemB_FrmVal.Location = new System.Drawing.Point(231, 92);
            this.txtItemB_FrmVal.Name = "txtItemB_FrmVal";
            this.txtItemB_FrmVal.Size = new System.Drawing.Size(41, 20);
            this.txtItemB_FrmVal.TabIndex = 33;
            this.txtItemB_FrmVal.Text = "0";
            // 
            // txtItemB_InjVal
            // 
            this.txtItemB_InjVal.Location = new System.Drawing.Point(231, 118);
            this.txtItemB_InjVal.Name = "txtItemB_InjVal";
            this.txtItemB_InjVal.Size = new System.Drawing.Size(41, 20);
            this.txtItemB_InjVal.TabIndex = 34;
            this.txtItemB_InjVal.Text = "0";
            // 
            // txtItemB2_TimeStamp
            // 
            this.txtItemB2_TimeStamp.Location = new System.Drawing.Point(483, 118);
            this.txtItemB2_TimeStamp.Name = "txtItemB2_TimeStamp";
            this.txtItemB2_TimeStamp.ReadOnly = true;
            this.txtItemB2_TimeStamp.Size = new System.Drawing.Size(151, 20);
            this.txtItemB2_TimeStamp.TabIndex = 40;
            // 
            // txtItemB1_Status
            // 
            this.txtItemB1_Status.Location = new System.Drawing.Point(370, 92);
            this.txtItemB1_Status.Name = "txtItemB1_Status";
            this.txtItemB1_Status.ReadOnly = true;
            this.txtItemB1_Status.Size = new System.Drawing.Size(41, 20);
            this.txtItemB1_Status.TabIndex = 35;
            // 
            // txtItemB2_Status
            // 
            this.txtItemB2_Status.Location = new System.Drawing.Point(372, 118);
            this.txtItemB2_Status.Name = "txtItemB2_Status";
            this.txtItemB2_Status.ReadOnly = true;
            this.txtItemB2_Status.Size = new System.Drawing.Size(41, 20);
            this.txtItemB2_Status.TabIndex = 36;
            // 
            // txtItemB2_Quantity
            // 
            this.txtItemB2_Quantity.Location = new System.Drawing.Point(427, 118);
            this.txtItemB2_Quantity.Name = "txtItemB2_Quantity";
            this.txtItemB2_Quantity.ReadOnly = true;
            this.txtItemB2_Quantity.Size = new System.Drawing.Size(41, 20);
            this.txtItemB2_Quantity.TabIndex = 38;
            // 
            // txtItemB1_Quantity
            // 
            this.txtItemB1_Quantity.Location = new System.Drawing.Point(425, 92);
            this.txtItemB1_Quantity.Name = "txtItemB1_Quantity";
            this.txtItemB1_Quantity.ReadOnly = true;
            this.txtItemB1_Quantity.Size = new System.Drawing.Size(41, 20);
            this.txtItemB1_Quantity.TabIndex = 37;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(484, 76);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 30;
            this.label16.Text = "TimeStamp";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(428, 76);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 13);
            this.label17.TabIndex = 29;
            this.label17.Text = "Quality";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(234, 76);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 13);
            this.label18.TabIndex = 27;
            this.label18.Text = "Value";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(373, 76);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(37, 13);
            this.label19.TabIndex = 28;
            this.label19.Text = "Status";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(155, 76);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 19;
            this.label15.Text = "Address";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(65, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 13);
            this.label14.TabIndex = 13;
            this.label14.Text = "ITEM 1";
            // 
            // txtItemB_Inj
            // 
            this.txtItemB_Inj.Location = new System.Drawing.Point(146, 118);
            this.txtItemB_Inj.Name = "txtItemB_Inj";
            this.txtItemB_Inj.Size = new System.Drawing.Size(64, 20);
            this.txtItemB_Inj.TabIndex = 14;
            this.txtItemB_Inj.Text = "W1_INJ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(65, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 13);
            this.label13.TabIndex = 11;
            this.label13.Text = "ITEM 1";
            // 
            // txtItem1B_Frm
            // 
            this.txtItem1B_Frm.Location = new System.Drawing.Point(146, 92);
            this.txtItem1B_Frm.Name = "txtItem1B_Frm";
            this.txtItem1B_Frm.Size = new System.Drawing.Size(64, 20);
            this.txtItem1B_Frm.TabIndex = 12;
            this.txtItem1B_Frm.Text = "W1_FRM";
            // 
            // txtComport
            // 
            this.txtComport.Location = new System.Drawing.Point(154, 40);
            this.txtComport.Name = "txtComport";
            this.txtComport.Size = new System.Drawing.Size(173, 20);
            this.txtComport.TabIndex = 3;
            this.txtComport.Text = "801";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 40);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Com Port";
            // 
            // txtIpAddress
            // 
            this.txtIpAddress.Location = new System.Drawing.Point(154, 14);
            this.txtIpAddress.Name = "txtIpAddress";
            this.txtIpAddress.Size = new System.Drawing.Size(173, 20);
            this.txtIpAddress.TabIndex = 1;
            this.txtIpAddress.Text = "5.28.93.48.1.1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "AMS Net Address";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.btnWordRead);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.btnWordWrite);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.btnReadfrom);
            this.tabPage3.Controls.Add(this.btnWriteto);
            this.tabPage3.Controls.Add(this.btnReadArr);
            this.tabPage3.Controls.Add(this.btnWriteArr);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.textBox46);
            this.tabPage3.Controls.Add(this.label66);
            this.tabPage3.Controls.Add(this.textBox47);
            this.tabPage3.Controls.Add(this.label71);
            this.tabPage3.Controls.Add(this.txtIPEMEA);
            this.tabPage3.Controls.Add(this.label72);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(989, 516);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Beckhoff-EMEATest";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtArrIndex);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Controls.Add(this.txtArrIndexVal);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Location = new System.Drawing.Point(510, 140);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 321);
            this.groupBox4.TabIndex = 187;
            this.groupBox4.TabStop = false;
            // 
            // txtArrIndex
            // 
            this.txtArrIndex.Location = new System.Drawing.Point(94, 34);
            this.txtArrIndex.Name = "txtArrIndex";
            this.txtArrIndex.Size = new System.Drawing.Size(100, 20);
            this.txtArrIndex.TabIndex = 176;
            this.txtArrIndex.Text = "1";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(6, 34);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(60, 13);
            this.label37.TabIndex = 177;
            this.label37.Text = "Array Index";
            // 
            // txtArrIndexVal
            // 
            this.txtArrIndexVal.Location = new System.Drawing.Point(94, 68);
            this.txtArrIndexVal.Name = "txtArrIndexVal";
            this.txtArrIndexVal.Size = new System.Drawing.Size(100, 20);
            this.txtArrIndexVal.TabIndex = 180;
            this.txtArrIndexVal.Text = "11";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 68);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(34, 13);
            this.label36.TabIndex = 181;
            this.label36.Text = "Value";
            // 
            // btnWordRead
            // 
            this.btnWordRead.Location = new System.Drawing.Point(822, 102);
            this.btnWordRead.Name = "btnWordRead";
            this.btnWordRead.Size = new System.Drawing.Size(75, 23);
            this.btnWordRead.TabIndex = 192;
            this.btnWordRead.Text = "Read/Write";
            this.btnWordRead.UseVisualStyleBackColor = true;
            this.btnWordRead.Click += new System.EventHandler(this.btnWordRead_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.checkBox8);
            this.groupBox1.Controls.Add(this.checkBox7);
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Location = new System.Drawing.Point(716, 144);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(257, 304);
            this.groupBox1.TabIndex = 185;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Word";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(106, 34);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(145, 238);
            this.textBox1.TabIndex = 193;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(24, 269);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(61, 17);
            this.checkBox8.TabIndex = 190;
            this.checkBox8.Text = "Signal8";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(24, 232);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(61, 17);
            this.checkBox7.TabIndex = 189;
            this.checkBox7.Text = "Signal7";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(24, 200);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(61, 17);
            this.checkBox6.TabIndex = 188;
            this.checkBox6.Text = "Signal6";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(24, 163);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(61, 17);
            this.checkBox5.TabIndex = 187;
            this.checkBox5.Text = "Signal5";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(24, 131);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(61, 17);
            this.checkBox4.TabIndex = 186;
            this.checkBox4.Text = "Signal4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(24, 98);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(61, 17);
            this.checkBox3.TabIndex = 185;
            this.checkBox3.Text = "Signal3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(24, 63);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(61, 17);
            this.checkBox2.TabIndex = 184;
            this.checkBox2.Text = "Signal2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(24, 30);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(61, 17);
            this.checkBox1.TabIndex = 183;
            this.checkBox1.Text = "Signal1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnWordWrite
            // 
            this.btnWordWrite.Location = new System.Drawing.Point(726, 102);
            this.btnWordWrite.Name = "btnWordWrite";
            this.btnWordWrite.Size = new System.Drawing.Size(75, 23);
            this.btnWordWrite.TabIndex = 191;
            this.btnWordWrite.Text = "Write";
            this.btnWordWrite.UseVisualStyleBackColor = true;
            this.btnWordWrite.Click += new System.EventHandler(this.btnWordWrite_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(754, 144);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 13);
            this.label23.TabIndex = 184;
            // 
            // btnReadfrom
            // 
            this.btnReadfrom.Location = new System.Drawing.Point(604, 102);
            this.btnReadfrom.Name = "btnReadfrom";
            this.btnReadfrom.Size = new System.Drawing.Size(100, 23);
            this.btnReadfrom.TabIndex = 179;
            this.btnReadfrom.Text = "Read from Index";
            this.btnReadfrom.UseVisualStyleBackColor = true;
            this.btnReadfrom.Click += new System.EventHandler(this.btnReadfrom_Click);
            // 
            // btnWriteto
            // 
            this.btnWriteto.Location = new System.Drawing.Point(510, 102);
            this.btnWriteto.Name = "btnWriteto";
            this.btnWriteto.Size = new System.Drawing.Size(88, 23);
            this.btnWriteto.TabIndex = 178;
            this.btnWriteto.Text = "Write to Index";
            this.btnWriteto.UseVisualStyleBackColor = true;
            this.btnWriteto.Click += new System.EventHandler(this.btnWriteto_Click);
            // 
            // btnReadArr
            // 
            this.btnReadArr.Location = new System.Drawing.Point(167, 102);
            this.btnReadArr.Name = "btnReadArr";
            this.btnReadArr.Size = new System.Drawing.Size(75, 23);
            this.btnReadArr.TabIndex = 174;
            this.btnReadArr.Text = "Read Array";
            this.btnReadArr.UseVisualStyleBackColor = true;
            this.btnReadArr.Click += new System.EventHandler(this.btnReadArr_Click);
            // 
            // btnWriteArr
            // 
            this.btnWriteArr.Location = new System.Drawing.Point(46, 102);
            this.btnWriteArr.Name = "btnWriteArr";
            this.btnWriteArr.Size = new System.Drawing.Size(75, 23);
            this.btnWriteArr.TabIndex = 173;
            this.btnWriteArr.Text = "Write Array";
            this.btnWriteArr.UseVisualStyleBackColor = true;
            this.btnWriteArr.Click += new System.EventHandler(this.btnWriteArr_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox30);
            this.groupBox2.Controls.Add(this.lstResult);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.tBIntArr);
            this.groupBox2.Controls.Add(this.tBByteVal);
            this.groupBox2.Controls.Add(this.tBStr1RealVal);
            this.groupBox2.Controls.Add(this.tBStr1IntVal);
            this.groupBox2.Controls.Add(this.tBStrVal);
            this.groupBox2.Controls.Add(this.tBBoolVal);
            this.groupBox2.Controls.Add(this.tBIntVal);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Location = new System.Drawing.Point(46, 140);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(458, 321);
            this.groupBox2.TabIndex = 172;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Complex Structure";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(68, 38);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(192, 20);
            this.textBox30.TabIndex = 143;
            this.textBox30.Text = "W1_Struct";
            // 
            // lstResult
            // 
            this.lstResult.FormattingEnabled = true;
            this.lstResult.Location = new System.Drawing.Point(276, 19);
            this.lstResult.Name = "lstResult";
            this.lstResult.Size = new System.Drawing.Size(166, 290);
            this.lstResult.TabIndex = 186;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(15, 38);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(45, 13);
            this.label38.TabIndex = 144;
            this.label38.Text = "Address";
            // 
            // tBIntArr
            // 
            this.tBIntArr.Location = new System.Drawing.Point(68, 100);
            this.tBIntArr.Name = "tBIntArr";
            this.tBIntArr.Size = new System.Drawing.Size(192, 20);
            this.tBIntArr.TabIndex = 20;
            this.tBIntArr.Text = "1,2,3";
            // 
            // tBByteVal
            // 
            this.tBByteVal.Location = new System.Drawing.Point(68, 164);
            this.tBByteVal.Name = "tBByteVal";
            this.tBByteVal.Size = new System.Drawing.Size(192, 20);
            this.tBByteVal.TabIndex = 18;
            this.tBByteVal.Text = "1";
            // 
            // tBStr1RealVal
            // 
            this.tBStr1RealVal.Location = new System.Drawing.Point(108, 260);
            this.tBStr1RealVal.Name = "tBStr1RealVal";
            this.tBStr1RealVal.Size = new System.Drawing.Size(152, 20);
            this.tBStr1RealVal.TabIndex = 16;
            this.tBStr1RealVal.Text = "4.5";
            // 
            // tBStr1IntVal
            // 
            this.tBStr1IntVal.Location = new System.Drawing.Point(108, 292);
            this.tBStr1IntVal.Name = "tBStr1IntVal";
            this.tBStr1IntVal.Size = new System.Drawing.Size(152, 20);
            this.tBStr1IntVal.TabIndex = 14;
            this.tBStr1IntVal.Text = "25";
            // 
            // tBStrVal
            // 
            this.tBStrVal.Location = new System.Drawing.Point(68, 196);
            this.tBStrVal.Name = "tBStrVal";
            this.tBStrVal.Size = new System.Drawing.Size(192, 20);
            this.tBStrVal.TabIndex = 11;
            this.tBStrVal.Text = "PLCTest";
            // 
            // tBBoolVal
            // 
            this.tBBoolVal.Location = new System.Drawing.Point(68, 132);
            this.tBBoolVal.Name = "tBBoolVal";
            this.tBBoolVal.Size = new System.Drawing.Size(192, 20);
            this.tBBoolVal.TabIndex = 3;
            this.tBBoolVal.Text = "True";
            // 
            // tBIntVal
            // 
            this.tBIntVal.Location = new System.Drawing.Point(68, 71);
            this.tBIntVal.Name = "tBIntVal";
            this.tBIntVal.Size = new System.Drawing.Size(192, 20);
            this.tBIntVal.TabIndex = 1;
            this.tBIntVal.Text = "1";
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(12, 100);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(48, 16);
            this.label39.TabIndex = 19;
            this.label39.Text = "dintArr:";
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(12, 164);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(56, 16);
            this.label40.TabIndex = 17;
            this.label40.Text = "byteVal:";
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(52, 260);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(48, 16);
            this.label41.TabIndex = 15;
            this.label41.Text = "lrealVal:";
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(52, 292);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(48, 16);
            this.label42.TabIndex = 13;
            this.label42.Text = "dintVal:";
            // 
            // label43
            // 
            this.label43.Location = new System.Drawing.Point(12, 228);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(80, 23);
            this.label43.TabIndex = 12;
            this.label43.Text = "simpleStruct1:";
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(12, 196);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(56, 16);
            this.label44.TabIndex = 10;
            this.label44.Text = "stringVal:";
            // 
            // label45
            // 
            this.label45.Location = new System.Drawing.Point(12, 132);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(48, 16);
            this.label45.TabIndex = 2;
            this.label45.Text = "boolVal:";
            // 
            // label47
            // 
            this.label47.Location = new System.Drawing.Point(12, 71);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(40, 16);
            this.label47.TabIndex = 0;
            this.label47.Text = "intVal:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox42);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.textBox43);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Location = new System.Drawing.Point(52, 317);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(168, 88);
            this.groupBox3.TabIndex = 170;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "String Types";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(48, 56);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(104, 20);
            this.textBox42.TabIndex = 3;
            // 
            // label48
            // 
            this.label48.Location = new System.Drawing.Point(8, 58);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(40, 16);
            this.label48.TabIndex = 2;
            this.label48.Text = "str2:";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(48, 24);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(104, 20);
            this.textBox43.TabIndex = 1;
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(8, 27);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(40, 16);
            this.label49.TabIndex = 0;
            this.label49.Text = "str1:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox44);
            this.groupBox6.Controls.Add(this.label50);
            this.groupBox6.Controls.Add(this.textBox45);
            this.groupBox6.Controls.Add(this.label51);
            this.groupBox6.Location = new System.Drawing.Point(103, 212);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(168, 88);
            this.groupBox6.TabIndex = 171;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "String Types";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(48, 56);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(104, 20);
            this.textBox44.TabIndex = 3;
            // 
            // label50
            // 
            this.label50.Location = new System.Drawing.Point(8, 58);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(40, 16);
            this.label50.TabIndex = 2;
            this.label50.Text = "str2:";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(48, 24);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(104, 20);
            this.textBox45.TabIndex = 1;
            // 
            // label51
            // 
            this.label51.Location = new System.Drawing.Point(8, 27);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(40, 16);
            this.label51.TabIndex = 0;
            this.label51.Text = "str1:";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(510, 31);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(173, 20);
            this.textBox46.TabIndex = 169;
            this.textBox46.Text = "myControl";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(441, 33);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(34, 13);
            this.label66.TabIndex = 168;
            this.label66.Text = "Topic";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(181, 56);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(173, 20);
            this.textBox47.TabIndex = 167;
            this.textBox47.Text = "801";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(43, 56);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(50, 13);
            this.label71.TabIndex = 166;
            this.label71.Text = "Com Port";
            // 
            // txtIPEMEA
            // 
            this.txtIPEMEA.Location = new System.Drawing.Point(181, 30);
            this.txtIPEMEA.Name = "txtIPEMEA";
            this.txtIPEMEA.Size = new System.Drawing.Size(173, 20);
            this.txtIPEMEA.TabIndex = 165;
            this.txtIPEMEA.Text = "10.225.134.22.1.1";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(43, 33);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(91, 13);
            this.label72.TabIndex = 164;
            this.label72.Text = "AMS Net Address";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.gbReadBatch);
            this.tabPage5.Controls.Add(this.tbTopicEMEA);
            this.tabPage5.Controls.Add(this.lblTopicEMEA);
            this.tabPage5.Controls.Add(this.tbPortEMEA);
            this.tabPage5.Controls.Add(this.lblComPort);
            this.tabPage5.Controls.Add(this.tbIPEMEA);
            this.tabPage5.Controls.Add(this.lblAMSNetAdrs);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(989, 516);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Beckhoff-EMEA";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // gbReadBatch
            // 
            this.gbReadBatch.Controls.Add(this.lstBatchData);
            this.gbReadBatch.Controls.Add(this.dgvBatch);
            this.gbReadBatch.Controls.Add(this.btnReadBatch);
            this.gbReadBatch.Controls.Add(this.lblControllerType);
            this.gbReadBatch.Controls.Add(this.cbControllerType);
            this.gbReadBatch.Controls.Add(this.lblTagName);
            this.gbReadBatch.Controls.Add(this.cbTagName);
            this.gbReadBatch.ImeMode = System.Windows.Forms.ImeMode.On;
            this.gbReadBatch.Location = new System.Drawing.Point(53, 99);
            this.gbReadBatch.Name = "gbReadBatch";
            this.gbReadBatch.Size = new System.Drawing.Size(860, 389);
            this.gbReadBatch.TabIndex = 176;
            this.gbReadBatch.TabStop = false;
            this.gbReadBatch.Text = "Read Batch";
            // 
            // lstBatchData
            // 
            this.lstBatchData.FormattingEnabled = true;
            this.lstBatchData.Location = new System.Drawing.Point(364, 116);
            this.lstBatchData.Name = "lstBatchData";
            this.lstBatchData.Size = new System.Drawing.Size(273, 238);
            this.lstBatchData.TabIndex = 6;
            // 
            // dgvBatch
            // 
            this.dgvBatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBatch.Location = new System.Drawing.Point(20, 78);
            this.dgvBatch.Name = "dgvBatch";
            this.dgvBatch.Size = new System.Drawing.Size(104, 292);
            this.dgvBatch.TabIndex = 5;
            // 
            // btnReadBatch
            // 
            this.btnReadBatch.Location = new System.Drawing.Point(768, 24);
            this.btnReadBatch.Name = "btnReadBatch";
            this.btnReadBatch.Size = new System.Drawing.Size(75, 23);
            this.btnReadBatch.TabIndex = 4;
            this.btnReadBatch.Text = "Read";
            this.btnReadBatch.UseVisualStyleBackColor = true;
            this.btnReadBatch.Click += new System.EventHandler(this.btnReadBatch_Click);
            // 
            // lblControllerType
            // 
            this.lblControllerType.AutoSize = true;
            this.lblControllerType.Location = new System.Drawing.Point(17, 27);
            this.lblControllerType.Name = "lblControllerType";
            this.lblControllerType.Size = new System.Drawing.Size(81, 13);
            this.lblControllerType.TabIndex = 3;
            this.lblControllerType.Text = "Controller Type:";
            // 
            // cbControllerType
            // 
            this.cbControllerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbControllerType.Items.AddRange(new object[] {
            "Tunnel",
            "Conventional/Washer Extractor"});
            this.cbControllerType.Location = new System.Drawing.Point(115, 24);
            this.cbControllerType.Name = "cbControllerType";
            this.cbControllerType.Size = new System.Drawing.Size(239, 21);
            this.cbControllerType.TabIndex = 2;
            this.cbControllerType.SelectedIndexChanged += new System.EventHandler(this.cbControllerType_SelectedIndexChanged);
            // 
            // lblTagName
            // 
            this.lblTagName.AutoSize = true;
            this.lblTagName.Location = new System.Drawing.Point(381, 27);
            this.lblTagName.Name = "lblTagName";
            this.lblTagName.Size = new System.Drawing.Size(60, 13);
            this.lblTagName.TabIndex = 1;
            this.lblTagName.Text = "Tag Name:";
            // 
            // cbTagName
            // 
            this.cbTagName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTagName.FormattingEnabled = true;
            this.cbTagName.Location = new System.Drawing.Point(464, 24);
            this.cbTagName.Name = "cbTagName";
            this.cbTagName.Size = new System.Drawing.Size(239, 21);
            this.cbTagName.TabIndex = 0;
            // 
            // tbTopicEMEA
            // 
            this.tbTopicEMEA.Location = new System.Drawing.Point(517, 30);
            this.tbTopicEMEA.Name = "tbTopicEMEA";
            this.tbTopicEMEA.Size = new System.Drawing.Size(173, 20);
            this.tbTopicEMEA.TabIndex = 175;
            this.tbTopicEMEA.Text = "myControl1";
            // 
            // lblTopicEMEA
            // 
            this.lblTopicEMEA.AutoSize = true;
            this.lblTopicEMEA.Location = new System.Drawing.Point(448, 32);
            this.lblTopicEMEA.Name = "lblTopicEMEA";
            this.lblTopicEMEA.Size = new System.Drawing.Size(34, 13);
            this.lblTopicEMEA.TabIndex = 174;
            this.lblTopicEMEA.Text = "Topic";
            // 
            // tbPortEMEA
            // 
            this.tbPortEMEA.Location = new System.Drawing.Point(188, 55);
            this.tbPortEMEA.Name = "tbPortEMEA";
            this.tbPortEMEA.Size = new System.Drawing.Size(173, 20);
            this.tbPortEMEA.TabIndex = 173;
            this.tbPortEMEA.Text = "801";
            // 
            // lblComPort
            // 
            this.lblComPort.AutoSize = true;
            this.lblComPort.Location = new System.Drawing.Point(50, 55);
            this.lblComPort.Name = "lblComPort";
            this.lblComPort.Size = new System.Drawing.Size(50, 13);
            this.lblComPort.TabIndex = 172;
            this.lblComPort.Text = "Com Port";
            // 
            // tbIPEMEA
            // 
            this.tbIPEMEA.Location = new System.Drawing.Point(188, 29);
            this.tbIPEMEA.Name = "tbIPEMEA";
            this.tbIPEMEA.Size = new System.Drawing.Size(173, 20);
            this.tbIPEMEA.TabIndex = 171;
            this.tbIPEMEA.Text = "10.225.134.22.1.1";
            // 
            // lblAMSNetAdrs
            // 
            this.lblAMSNetAdrs.AutoSize = true;
            this.lblAMSNetAdrs.Location = new System.Drawing.Point(50, 32);
            this.lblAMSNetAdrs.Name = "lblAMSNetAdrs";
            this.lblAMSNetAdrs.Size = new System.Drawing.Size(91, 13);
            this.lblAMSNetAdrs.TabIndex = 170;
            this.lblAMSNetAdrs.Text = "AMS Net Address";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button4);
            this.tabPage4.Controls.Add(this.button3);
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.txtMIIPAddress);
            this.tabPage4.Controls.Add(this.txtArrayValues);
            this.tabPage4.Controls.Add(this.txtMiCount);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.txtMiLocation);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(989, 516);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Mitsubishi";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(565, 216);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 49);
            this.button3.TabIndex = 8;
            this.button3.Text = "Write";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(434, 216);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(116, 49);
            this.button2.TabIndex = 7;
            this.button2.Text = "Read";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(456, 99);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(95, 13);
            this.label26.TabIndex = 6;
            this.label26.Text = "PLC IP Address";
            // 
            // txtMIIPAddress
            // 
            this.txtMIIPAddress.Location = new System.Drawing.Point(446, 128);
            this.txtMIIPAddress.Name = "txtMIIPAddress";
            this.txtMIIPAddress.Size = new System.Drawing.Size(309, 20);
            this.txtMIIPAddress.TabIndex = 5;
            this.txtMIIPAddress.Text = "172.16.225.12";
            // 
            // txtArrayValues
            // 
            this.txtArrayValues.Location = new System.Drawing.Point(31, 143);
            this.txtArrayValues.Multiline = true;
            this.txtArrayValues.Name = "txtArrayValues";
            this.txtArrayValues.Size = new System.Drawing.Size(309, 296);
            this.txtArrayValues.TabIndex = 4;
            // 
            // txtMiCount
            // 
            this.txtMiCount.Location = new System.Drawing.Point(111, 81);
            this.txtMiCount.Name = "txtMiCount";
            this.txtMiCount.Size = new System.Drawing.Size(309, 20);
            this.txtMiCount.TabIndex = 3;
            this.txtMiCount.Text = "1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(28, 84);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 13);
            this.label25.TabIndex = 2;
            this.label25.Text = "Count";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(28, 37);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "Address";
            // 
            // txtMiLocation
            // 
            this.txtMiLocation.Location = new System.Drawing.Point(111, 37);
            this.txtMiLocation.Name = "txtMiLocation";
            this.txtMiLocation.Size = new System.Drawing.Size(309, 20);
            this.txtMiLocation.TabIndex = 0;
            this.txtMiLocation.Text = "M934";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.txtTotalWeight);
            this.tabPage6.Controls.Add(this.label29);
            this.tabPage6.Controls.Add(this.txtETechXml);
            this.tabPage6.Controls.Add(this.btnRun);
            this.tabPage6.Controls.Add(this.txtETechIpAddress);
            this.tabPage6.Controls.Add(this.txtETechlWasherId);
            this.tabPage6.Controls.Add(this.label28);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(989, 516);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "E-Tech";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // txtTotalWeight
            // 
            this.txtTotalWeight.Location = new System.Drawing.Point(517, 160);
            this.txtTotalWeight.Name = "txtTotalWeight";
            this.txtTotalWeight.ReadOnly = true;
            this.txtTotalWeight.Size = new System.Drawing.Size(309, 20);
            this.txtTotalWeight.TabIndex = 11;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(435, 167);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(76, 13);
            this.label29.TabIndex = 10;
            this.label29.Text = "TotalWeight";
            // 
            // txtETechXml
            // 
            this.txtETechXml.Location = new System.Drawing.Point(64, 151);
            this.txtETechXml.Multiline = true;
            this.txtETechXml.Name = "txtETechXml";
            this.txtETechXml.Size = new System.Drawing.Size(309, 296);
            this.txtETechXml.TabIndex = 9;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(438, 102);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(116, 33);
            this.btnRun.TabIndex = 8;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // txtETechIpAddress
            // 
            this.txtETechIpAddress.Location = new System.Drawing.Point(109, 50);
            this.txtETechIpAddress.Name = "txtETechIpAddress";
            this.txtETechIpAddress.Size = new System.Drawing.Size(309, 20);
            this.txtETechIpAddress.TabIndex = 7;
            this.txtETechIpAddress.Text = "http://vogue.etechsystems.com/datafusion/DFLastDropped";
            // 
            // txtETechlWasherId
            // 
            this.txtETechlWasherId.Location = new System.Drawing.Point(655, 50);
            this.txtETechlWasherId.Name = "txtETechlWasherId";
            this.txtETechlWasherId.Size = new System.Drawing.Size(309, 20);
            this.txtETechlWasherId.TabIndex = 5;
            this.txtETechlWasherId.Text = "77";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(528, 50);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 13);
            this.label28.TabIndex = 4;
            this.label28.Text = "E-TechWasherId";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(51, 50);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 13);
            this.label27.TabIndex = 3;
            this.label27.Text = "Address";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(710, 216);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(185, 49);
            this.button4.TabIndex = 9;
            this.button4.Text = "ReadPumpSetting(EPlus)";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 566);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormMain";
            this.Text = "PLC Tester";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.gbReadBatch.ResumeLayout(false);
            this.gbReadBatch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBatch)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.TextBox txtOpcServer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTopicName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtItem1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtItem2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.TextBox txtItem2Val;
        private System.Windows.Forms.TextBox txtItem1Val;
        private System.Windows.Forms.TextBox txtItem2State;
        private System.Windows.Forms.TextBox txtItem1State;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtItem2TimeStamp;
        private System.Windows.Forms.TextBox txtItem1TimeStamp;
        private System.Windows.Forms.TextBox txtItem2Quality;
        private System.Windows.Forms.TextBox txtItem1Quality;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtItem3TimeStamp;
        private System.Windows.Forms.TextBox txtItem3Quality;
        private System.Windows.Forms.TextBox txtItem3State;
        private System.Windows.Forms.TextBox txtItem3Val;
        private System.Windows.Forms.TextBox txtItem3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtItemB_Inj;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtItem1B_Frm;
        private System.Windows.Forms.TextBox txtComport;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtIpAddress;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtItemB1_TimeStamp;
        private System.Windows.Forms.TextBox txtItemB3_TimeStamp;
        private System.Windows.Forms.TextBox txtItemB3_Quantity;
        private System.Windows.Forms.TextBox txtItemB3_Status;
        private System.Windows.Forms.TextBox txtItemB_OpcVal;
        private System.Windows.Forms.TextBox txtItemB_Opc;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtItemB_FrmVal;
        private System.Windows.Forms.TextBox txtItemB_InjVal;
        private System.Windows.Forms.TextBox txtItemB2_TimeStamp;
        private System.Windows.Forms.TextBox txtItemB1_Status;
        private System.Windows.Forms.TextBox txtItemB2_Status;
        private System.Windows.Forms.TextBox txtItemB2_Quantity;
        private System.Windows.Forms.TextBox txtItemB1_Quantity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnRead_Beckhoff;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Button btnWrite_Beckhoff;
        private System.Windows.Forms.Button btnWrite_Continue;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TextBox txtBTopicName;
        private System.Windows.Forms.Label lblBTopicName;
        private System.Windows.Forms.Button btnValidate_Beckhoff;
        private System.Windows.Forms.TextBox txtItemB4_TimeStamp;
        private System.Windows.Forms.TextBox txtItemB4_Quantity;
        private System.Windows.Forms.TextBox txtItemB4_Status;
        private System.Windows.Forms.TextBox textItemB_LHSTREQVal;
        private System.Windows.Forms.TextBox txtItemBLHSTXML;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtItem4B_Type;
        private System.Windows.Forms.TextBox txtItem3B_Type;
        private System.Windows.Forms.TextBox txtItem1B_Type;
        private System.Windows.Forms.TextBox txtItem2B_Type;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox tbTopicEMEA;
        private System.Windows.Forms.Label lblTopicEMEA;
        private System.Windows.Forms.TextBox tbPortEMEA;
        private System.Windows.Forms.Label lblComPort;
        private System.Windows.Forms.TextBox tbIPEMEA;
        private System.Windows.Forms.Label lblAMSNetAdrs;
        private System.Windows.Forms.GroupBox gbReadBatch;
        private System.Windows.Forms.Label lblControllerType;
        private System.Windows.Forms.ComboBox cbControllerType;
        private System.Windows.Forms.Label lblTagName;
        private System.Windows.Forms.ComboBox cbTagName;
        private System.Windows.Forms.Button btnReadBatch;
        private System.Windows.Forms.DataGridView dgvBatch;
        private System.Windows.Forms.ListBox lstBatchData;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtArrIndex;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtArrIndexVal;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnWordRead;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btnWordWrite;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnReadfrom;
        private System.Windows.Forms.Button btnWriteto;
        private System.Windows.Forms.Button btnReadArr;
        private System.Windows.Forms.Button btnWriteArr;
        internal System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.ListBox lstResult;
        private System.Windows.Forms.Label label38;
        internal System.Windows.Forms.TextBox tBIntArr;
        internal System.Windows.Forms.TextBox tBByteVal;
        internal System.Windows.Forms.TextBox tBStr1RealVal;
        internal System.Windows.Forms.TextBox tBStr1IntVal;
        internal System.Windows.Forms.TextBox tBStrVal;
        internal System.Windows.Forms.TextBox tBBoolVal;
        internal System.Windows.Forms.Label label39;
        internal System.Windows.Forms.Label label40;
        internal System.Windows.Forms.Label label41;
        internal System.Windows.Forms.Label label42;
        internal System.Windows.Forms.Label label43;
        internal System.Windows.Forms.Label label44;
        internal System.Windows.Forms.Label label45;
        internal System.Windows.Forms.Label label47;
        internal System.Windows.Forms.GroupBox groupBox3;
        internal System.Windows.Forms.TextBox textBox42;
        internal System.Windows.Forms.Label label48;
        internal System.Windows.Forms.TextBox textBox43;
        internal System.Windows.Forms.Label label49;
        internal System.Windows.Forms.GroupBox groupBox6;
        internal System.Windows.Forms.TextBox textBox44;
        internal System.Windows.Forms.Label label50;
        internal System.Windows.Forms.TextBox textBox45;
        internal System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtIPEMEA;
        private System.Windows.Forms.Label label72;
        internal System.Windows.Forms.TextBox tBIntVal;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtMIIPAddress;
        private System.Windows.Forms.TextBox txtArrayValues;
        private System.Windows.Forms.TextBox txtMiCount;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtMiLocation;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtETechlWasherId;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtETechIpAddress;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.TextBox txtTotalWeight;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtETechXml;
        private System.Windows.Forms.Button button4;
    }
}

