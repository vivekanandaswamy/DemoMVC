﻿namespace Ecolab.Dcs.OpcReaderTest
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Windows.Forms;
    using CollectData;
    using CollectData.Beckhoff;
    using CollectData.Opc;
    using Entities;
    using Ecolab.Dcs.CollectData.Mitsubishi;
    using System.Net;
    using System.Xml.Serialization;
    using System.IO;
    using System.Xml;
    using System.Text;

    public partial class FormMain : Form
    {
        private OpcDataReader mDataReader;
        private BeckhoffDataReader bDataReader;
        private string ipAddress = "";
        private int port = 801;
        private CheckBox[] checkboxes;
        private int[] operators;
        string BeckhoffItemFormat = "[{0}].{1}";

        public FormMain()
        {
            InitializeComponent();
            ipAddress = txtIpAddress.Text;

            checkboxes = new[] { checkBox1, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6, checkBox7, checkBox8 };

            foreach (var cb in checkboxes)
            {
                cb.CheckedChanged += checkBox_CheckedChanged;
            }

            cbControllerType.SelectedIndex = 0;
            cbTagName.SelectedIndex = 2;
        }

        private void btn_Connect_Click(object sender, EventArgs e)
        {
            List<OpcTag> tags;
            DataReader<OpcTag> dataReader = DataReader(out tags);
            OpcTag[] result = dataReader.ValidateTags(tags).ToArray();
            txtItem1State.Text = result[0].IsValid ? "True" : "False";
            txtItem2State.Text = result[1].IsValid ? "True" : "False";
            txtItem3State.Text = result[2].IsValid ? "True" : "False";
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            List<OpcTag> tags;
            DataReader<OpcTag> dataReader = DataReader(out tags);
            dataReader.ReadTags(tags);
            OpcTag[] result = dataReader.ValidateTags(tags).ToArray();
            txtItem1State.Text = result[0].IsValid ? "True" : "False";
            txtItem2State.Text = result[1].IsValid ? "True" : "False";
            txtItem3State.Text = result[2].IsValid ? "True" : "False";
            txtItem1Val.Text = result[0].Value;
            txtItem2Val.Text = result[1].Value;
            txtItem3Val.Text = result[2].Value;
            txtItem1Quality.Text = result[0].Quality;
            txtItem2Quality.Text = result[1].Quality;
            txtItem3Quality.Text = result[2].Quality;
            txtItem1TimeStamp.Text = result[0].TimeStamp.ToString();
            txtItem2TimeStamp.Text = result[1].TimeStamp.ToString();
            txtItem3TimeStamp.Text = result[2].TimeStamp.ToString();
        }

        private DataReader<OpcTag> DataReader(out List<OpcTag> tags)
        {
            string opcItemFormat = "[{0}].{1}";
            DataReader<OpcTag> dataReader = new OpcDataReader(new AllenBradleyController { ControllerId = 1, Name = txtTopicName.Text, OpcServer = txtOpcServer.Text }, opcItemFormat);

            tags = new List<OpcTag>();
            OpcTag opcTag1 = new OpcTag { Address = txtItem1.Text, Topic = txtTopicName.Text };
            tags.Add(opcTag1);
            OpcTag opcTag2 = new OpcTag { Address = txtItem2.Text, Topic = txtTopicName.Text };
            tags.Add(opcTag2);
            OpcTag opcTag3 = new OpcTag { Address = txtItem3.Text, Topic = txtTopicName.Text };
            tags.Add(opcTag3);
            return dataReader;
        }

        private DataWriter<OpcTag> DataWriter(out List<OpcTag> tags)
        {
            string opcItemFormat = "[{0}].{1}";
            DataWriter<OpcTag> dataReader = new OpcDataWriter(new AllenBradleyController { ControllerId = 1, Name = txtTopicName.Text, OpcServer = txtOpcServer.Text }, opcItemFormat);

            tags = new List<OpcTag>();
            OpcTag opcTag1 = new OpcTag { Address = txtItem1.Text, Topic = txtTopicName.Text, Value = txtItem1Val.Text };
            tags.Add(opcTag1);
            OpcTag opcTag2 = new OpcTag { Address = txtItem2.Text, Topic = txtTopicName.Text, Value = txtItem2Val.Text };
            tags.Add(opcTag2);
            OpcTag opcTag3 = new OpcTag { Address = txtItem3.Text, Topic = txtTopicName.Text, Value = txtItem3Val.Text };
            tags.Add(opcTag3);
            return dataReader;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<OpcTag> tags;
            mDataReader = (OpcDataReader)DataReader(out tags);
            mDataReader.ReadTagsContinuously(tags, "group1", Callback);
            var washer2Tags = new List<OpcTag> { new OpcTag { Address = "N7:10", Topic = txtBTopicName.Text }, new OpcTag { Address = "N7:11", Topic = txtTopicName.Text }, new OpcTag { Address = "N7:12", Topic = txtTopicName.Text } };
            mDataReader.ReadTagsContinuously(washer2Tags, "group2", Callback2);
        }

        private void Callback(IList<OpcTag> tags, object callbackData)
        {
            // mtags.AddRange(tags);
            var blist = new BindingList<OpcTag>(tags);
            dataGridView1.DataSource = blist;
        }

        private void Callback2(IList<OpcTag> tags, object callbackData)
        {
            // mtags.AddRange(tags);
            var blist = new BindingList<OpcTag>(tags);
            dataGridView2.DataSource = blist;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            mDataReader.Shutdown();
        }

        private void label20_Click(object sender, EventArgs e)
        {
        }

        private void btnRead_Beckhoff_Click(object sender, EventArgs e)
        {
            ipAddress = txtIpAddress.Text;
            List<BeckhoffTag> tags;
            DataReader<BeckhoffTag> dataReader = BeckHoffDataReader(out tags);
            dataReader.ReadTags(tags);
            BeckhoffTag[] result = dataReader.ValidateTags(tags).ToArray();
            txtItemB1_Status.Text = result[0].IsValid ? "True" : "False";
            txtItemB2_Status.Text = result[1].IsValid ? "True" : "False";
            txtItemB3_Status.Text = result[2].IsValid ? "True" : "False";
            txtItemB4_Status.Text = result[3].IsValid ? "True" : "False";
            txtItemB_FrmVal.Text = result[0].Value;
            txtItemB_InjVal.Text = result[1].Value;
            txtItemB_OpcVal.Text = result[2].Value;
            textItemB_LHSTREQVal.Text = result[3].Value;
            txtItemB1_Quantity.Text = result[0].Quality;
            txtItemB2_Quantity.Text = result[1].Quality;
            txtItemB3_Quantity.Text = result[2].Quality;
            txtItemB4_Quantity.Text = result[3].Quality;
            txtItemB1_TimeStamp.Text = result[0].TimeStamp.ToString();
            txtItemB2_TimeStamp.Text = result[1].TimeStamp.ToString();
            txtItemB3_TimeStamp.Text = result[2].TimeStamp.ToString();
            txtItemB4_TimeStamp.Text = result[3].TimeStamp.ToString();

            //string beckhoffItemFormat = "[{0}].{1}";
            //BeckhoffDataReader beckhoffDataReader = new BeckhoffDataReader(new BeckhoffController { IpAddress = txtIpAddress.Text, ComPort = int.Parse(txtComport.Text) }, beckhoffItemFormat);

            //beckhoffDataReader.ValidateTag(null);     


        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            List<OpcTag> tags;
            DataWriter<OpcTag> dataWriter = DataWriter(out tags);
            IList<OpcTag> result = dataWriter.WriteTags(tags);
            txtItem1State.Text = result[0].IsValid ? "True" : "False";
            txtItem2State.Text = result[1].IsValid ? "True" : "False";
            txtItem3State.Text = result[2].IsValid ? "True" : "False";
        }

        private DataReader<BeckhoffTag> BeckHoffDataReader(out List<BeckhoffTag> tags)
        {
            string opcItemFormat = "[{0}].{1}";
            DataReader<BeckhoffTag> dataReader = new BeckhoffDataReader(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, opcItemFormat, txtIpAddress.Text, 801);


            tags = new List<BeckhoffTag>();
            BeckhoffTag opcTag1 = new BeckhoffTag { Address = txtItem1B_Frm.Text, TagItemType = (UIInputType)Enum.Parse(typeof(UIInputType), txtItem1B_Type.Text.ToString()), SizetoRead = 80 };
            tags.Add(opcTag1);
            BeckhoffTag opcTag2 = new BeckhoffTag { Address = txtItemB_Inj.Text, TagItemType = (UIInputType)Enum.Parse(typeof(UIInputType), txtItem2B_Type.Text.ToString()), SizetoRead = 80 };
            tags.Add(opcTag2);
            BeckhoffTag opcTag3 = new BeckhoffTag { Address = txtItemB_Opc.Text, TagItemType = (UIInputType)Enum.Parse(typeof(UIInputType), txtItem3B_Type.Text.ToString()), SizetoRead = 80 };
            tags.Add(opcTag3);
            BeckhoffTag opcTag4 = new BeckhoffTag { Address = txtItemBLHSTXML.Text, SizetoRead = 20000 };
            tags.Add(opcTag4);
            return dataReader;
        }

        private DataWriter<BeckhoffTag> DataWriter(out List<BeckhoffTag> tags)
        {
            string BeckhoffItemFormat = "[{0}].{1}";
            DataWriter<BeckhoffTag> dataReader = new BeckoffDataWriter(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, BeckhoffItemFormat, txtIpAddress.Text, 801);

            tags = new List<BeckhoffTag>();
            BeckhoffTag opcTag1 = new BeckhoffTag { Address = txtItem1B_Frm.Text, Value = txtItemB_FrmVal.Text, TagItemType = (UIInputType)Enum.Parse(typeof(UIInputType), txtItem1B_Type.Text.ToString()) };
            tags.Add(opcTag1);
            BeckhoffTag opcTag2 = new BeckhoffTag { Address = txtItemB_Inj.Text, Value = txtItemB_InjVal.Text, TagItemType = (UIInputType)Enum.Parse(typeof(UIInputType), txtItem2B_Type.Text.ToString()) };
            tags.Add(opcTag2);
            BeckhoffTag opcTag3 = new BeckhoffTag { Address = txtItemB_Opc.Text, Value = txtItemB_OpcVal.Text, TagItemType = (UIInputType)Enum.Parse(typeof(UIInputType), txtItem3B_Type.Text.ToString()) };
            tags.Add(opcTag3);
            BeckhoffTag opcTag4 = new BeckhoffTag { Address = "L_HSTREQ", Value = textItemB_LHSTREQVal.Text }; //, TagItemType = (UIInputType)Enum.Parse(typeof(UIInputType), txtItem4B_Type.Text.ToString()) };
            tags.Add(opcTag4);

            return dataReader;
        }


        private void btnWrite_Beckhoff_Click(object sender, EventArgs e)
        {
            ipAddress = txtIpAddress.Text;
            List<BeckhoffTag> tags;
            DataWriter<BeckhoffTag> dataWriter = DataWriter(out tags);
            IList<BeckhoffTag> result = dataWriter.WriteTags(tags);
            txtItemB1_Status.Text = result[0].IsValid ? "True" : "False";
            txtItemB2_Status.Text = result[1].IsValid ? "True" : "False";
            txtItemB3_Status.Text = result[2].IsValid ? "True" : "False";
            txtItemB4_Status.Text = result[3].IsValid ? "True" : "False";
        }

        private void btnWrite_Continue_Click(object sender, EventArgs e)
        {
            ipAddress = txtIpAddress.Text;
            List<BeckhoffTag> tags;
            object oBeckhoff = "Beckhoff";
            bDataReader = (BeckhoffDataReader)BeckHoffDataReader(out tags);

            IEnumerable<BeckhoffTag> beckhoffTags = tags;
            // bDataReader.ReadTagsContinuously(tags, "group1", Callback);
            var washer2Tags = new List<BeckhoffTag> { new BeckhoffTag { Address = "W1_FRM", Topic = txtBTopicName.Text }, new BeckhoffTag { Address = "W1_INJ", Topic = txtBTopicName.Text }, new BeckhoffTag { Address = "W1_OPC", Topic = txtBTopicName.Text } };
            // bDataReader.ReadTagsContinuously(washer2Tags, "group2", Callback2);
            bDataReader.ReadTagsContinuously(washer2Tags, ProcessBeckhoffWasherTags, oBeckhoff);
        }

        public void ProcessBeckhoffWasherTags(IList<BeckhoffTag> beckhoffTags, object valData)
        {
            try
            {
                //Washer washer = (Washer)valData;

                //BeckhoffTag[] tags = beckhoffTags as BeckhoffTag[] ?? beckhoffTags.ToArray();
                var blist = new BindingList<BeckhoffTag>(beckhoffTags);
                //dataGridView3.DataSource = blist;
                dataGridView3.DataSource = blist;


            }
            catch (Exception)
            {

            }
        }

        private void btnValidate_Beckhoff_Click(object sender, EventArgs e)
        {
            ipAddress = txtIpAddress.Text;
            List<BeckhoffTag> tags;
            DataReader<BeckhoffTag> dataReader = BeckHoffDataReader(out tags);
            BeckhoffTag[] result = dataReader.ValidateTags(tags).ToArray();
            txtItemB1_Status.Text = result[0].IsValid ? "True" : "False";
            txtItemB2_Status.Text = result[1].IsValid ? "True" : "False";
            txtItemB3_Status.Text = result[2].IsValid ? "True" : "False";
            txtItemB4_Status.Text = result[3].IsValid ? "True" : "False";
        }

        private void btnWriteArr_Click(object sender, EventArgs e)
        {
            ipAddress = txtIPEMEA.Text;
            // List<BeckhoffTag> tags;
            string BeckhoffItemFormat = "[{0}].{1}";
            DataWriter<BeckhoffTag> dataWriter = new BeckoffDataWriter(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, BeckhoffItemFormat, ipAddress, port);

            ComplexStruct tagStruct = GetStructFromControls();
            ComplexStruct result = dataWriter.WriteArrayTags(tagStruct);
        }

        private ComplexStruct GetStructFromControls()
        {
            ComplexStruct structure = new ComplexStruct();
            String[] stringArr = tBIntArr.Text.Split(new char[] { ',' });
            structure.intVal = short.Parse(tBIntVal.Text);
            for (int i = 0; i < stringArr.Length; i++)
                structure.dintArr[i] = int.Parse(stringArr[i]);

            structure.boolVal = Boolean.Parse(tBBoolVal.Text);
            structure.byteVal = Byte.Parse(tBByteVal.Text);
            structure.stringVal = tBStrVal.Text;
            structure.simpleStruct1.dintVal1 = int.Parse(tBStr1IntVal.Text);
            structure.simpleStruct1.lrealVal = double.Parse(tBStr1RealVal.Text);
            return structure;
        }

        private void btnReadArr_Click(object sender, EventArgs e)
        {
            ipAddress = txtIPEMEA.Text;
            string opcItemFormat = "[{0}].{1}";
            DataReader<BeckhoffTag> dataReader = new BeckhoffDataReader(new BeckhoffController { ControllerId = 1, Name = textBox46.Text }, opcItemFormat, ipAddress, 801);
        }

        private void btnWriteto_Click(object sender, EventArgs e)
        {
            ipAddress = txtIPEMEA.Text;
            string BeckhoffItemFormat = "[{0}].{1}";
            DataWriter<BeckhoffTag> dataWriter = new BeckoffDataWriter(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, BeckhoffItemFormat, ipAddress, port);

        }

        private void btnReadfrom_Click(object sender, EventArgs e)
        {
            ipAddress = txtIPEMEA.Text;
            int val;
            int[] dintArr = new int[4];
            string BeckhoffItemFormat = "[{0}].{1}";
            DataReader<BeckhoffTag> dataReader = new BeckhoffDataReader(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, BeckhoffItemFormat, ipAddress, port);

            string arrIndex = txtArrIndex.Text.ToString();
            int result = dataReader.ReadArrayPos(int.Parse(arrIndex));
            txtArrIndexVal.Text = "";

            String[] stringArr = tBIntArr.Text.Split(new char[] { ',' });
            val = short.Parse(tBIntVal.Text);
            for (int i = 0; i < stringArr.Length; i++)
                dintArr[i] = int.Parse(stringArr[i]);

            dintArr[int.Parse(arrIndex)] = result;

            tBIntArr.Text = String.Format("{0:d}, {1:d}, {2:d}, {3:d}", dintArr[0],
                dintArr[1], dintArr[2], dintArr[3]);
            txtArrIndexVal.Text = result.ToString();
            lstResult.Items.Add(String.Format("{0:d}, {1:d}, {2:d}, {3:d}", dintArr[0],
                dintArr[1], dintArr[2], dintArr[3]));
        }

        private void btnWordWrite_Click(object sender, EventArgs e)
        {
            ipAddress = txtIPEMEA.Text;
            string BeckhoffItemFormat = "[{0}].{1}";
            DataWriter<BeckhoffTag> dataWriter = new BeckoffDataWriter(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, BeckhoffItemFormat, ipAddress, port);
        }

        private void btnWordRead_Click(object sender, EventArgs e)
        {
            ipAddress = txtIPEMEA.Text;
            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            List<BeckhoffTag> writeTags = new List<BeckhoffTag>();

            DataReader<BeckhoffTag> dataReader = new BeckhoffDataReader(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, BeckhoffItemFormat, txtIPEMEA.Text, 801);

            BeckhoffTag tag1 = new BeckhoffTag() { Address = "Helms_Info.x_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Xs_Helms_ConfigCN).AssemblyQualifiedName };
            BeckhoffTag tag2 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCN).AssemblyQualifiedName };
            BeckhoffTag tag3 = new BeckhoffTag() { Address = "Helms_Info.x_Helms_ConfigCNAndHelms", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Xs_Helms_ConfigCNAndHelms).AssemblyQualifiedName };
            BeckhoffTag tag4 = new BeckhoffTag() { Address = "x_invertMachineStop", TagItemType = UIInputType.TypeBool };
            BeckhoffTag tag5 = new BeckhoffTag() { Address = "x_AlarmRackLeakageEnable", TagItemType = UIInputType.TypeBool };
            BeckhoffTag tag6 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCNAndHelms_2", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(Uints_Helms_ConfigCNAndHelms_2).AssemblyQualifiedName };
            BeckhoffTag tag7 = new BeckhoffTag() { Address = "Helms_Info.uint_Helms_ConfigCN.uint_Connex_Alarm_Delay", TagItemType = UIInputType.TypeInt, Value = "111" };



            //Helms_Info.x_Helms_ConfigCNAndHelms

            tags.Add(tag1);
            tags.Add(tag2);
            tags.Add(tag3);
            tags.Add(tag4);
            tags.Add(tag5);
            tags.Add(tag6);

            dataReader.ReadTags(tags);
            Xs_Helms_ConfigCN x_Helms_ConfigCN;
            Uints_Helms_ConfigCN uint_Helm_ConfigCN;
            Xs_Helms_ConfigCNAndHelms x_Helms_ConfigCNAndHelms;
            Uints_Helms_ConfigCNAndHelms_2 uint_Helms_ConfigCNAndHelms_2;

            x_Helms_ConfigCN = (Xs_Helms_ConfigCN)tag1.ComplexObject;
            uint_Helm_ConfigCN = (Uints_Helms_ConfigCN)tag2.ComplexObject;
            x_Helms_ConfigCNAndHelms = (Xs_Helms_ConfigCNAndHelms)tag3.ComplexObject;


            string soutput;
            soutput = string.Format("uint_Connex_Alarm_Delay:{0};\nuint_IntermRinseTime{1}", uint_Helm_ConfigCN.uint_Connex_Alarm_Delay, uint_Helm_ConfigCN.uint_IntermRinseTime);
            textBox1.Text = soutput;

            string x_invertMachineStop = tag4.Value;
            string x_AlarmRackLeakageEnable = tag5.Value;
            uint_Helms_ConfigCNAndHelms_2 = (Uints_Helms_ConfigCNAndHelms_2)tag6.ComplexObject;
            tag4.Value = "false";
            writeTags.Add(tag2);
            writeTags.Add(tag1);
            writeTags.Add(tag4);
            uint_Helm_ConfigCN.uint_Connex_Alarm_Delay = 177;
            uint_Helm_ConfigCN.uint_IntermRinseTime = 9;
            uint_Helm_ConfigCN.uint_Handshake = 65535;
            x_Helms_ConfigCN.x_Handshake = true;
            x_Helms_ConfigCN.x_Connex_En = true;




            DataWriter<BeckhoffTag> dataWriter = new BeckoffDataWriter(new BeckhoffController { ControllerId = 1, Name = txtTopicName.Text }, BeckhoffItemFormat, txtIPEMEA.Text, 801);
            dataWriter.WriteTags(writeTags);


            if (x_Helms_ConfigCN != null)
            {
                string sData;
                sData = string.Format("x_Connex_En: {0},\n x_AlmPrgNotFinishDis: {1},\n x_FlushControlEn: {2},\n x_PMREn: {3},\nx_Reset_Button_En: {4}", x_Helms_ConfigCN.x_Connex_En,
                                   x_Helms_ConfigCN.x_AlmPrgNotFinishDis,
                                   x_Helms_ConfigCN.x_FlushControlEn,
                                   x_Helms_ConfigCN.x_PMREn,
                                   x_Helms_ConfigCN.x_Reset_Button_En);

                System.Diagnostics.Debug.WriteLine(sData);

            }
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            operators = checkboxes
                .Select(cb => cb.CheckState)
                .Cast<int>()
                .ToArray();
            string result = string.Join("", operators);
            String Ans = Convert.ToInt32(result, 2).ToString();

            textBox1.Text = Ans;
        }

        private void cbControllerType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbControllerType.SelectedIndex == 0) //"Tunnel"
            {
                cbTagName.Items.Clear();
                cbTagName.Items.Add(".uint_StorePointerTUN");
                cbTagName.Items.Add(".uint_StorePointerTUN_R");
                cbTagName.Items.Add("uint_StoreProdDataTun");
            }
            else if (cbControllerType.SelectedIndex == 1) //"Conventional/Washer Extractor"
            {
                cbTagName.Items.Clear();
                cbTagName.Items.Add(".uint_StorePointerWE");
                cbTagName.Items.Add(".uint_StorePointerWE_R");
                cbTagName.Items.Add("uint_StoreProdDataWE");
            }
        }

        private void btnReadBatch_Click(object sender, EventArgs e)
        {
            lstBatchData.Items.Clear();
            ipAddress = tbIPEMEA.Text;
            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            string opcItemFormat = "[{0}].{1}";

            DataReader<BeckhoffTag> dataReader = new BeckhoffDataReader(new BeckhoffController { ControllerId = 1, Name = tbTopicEMEA.Text }, opcItemFormat, tbIPEMEA.Text, 801);

            if (cbTagName.SelectedItem.ToString() == "uint_StoreProdDataTun")
            {
                BeckhoffTag bhTag = new BeckhoffTag { Address = "uint_StorePointerTUN_R", TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead = 80 };
                tags.Add(bhTag);
                tags.Clear();

                BeckhoffTag bhTags = new BeckhoffTag { Address = "uint_StorePointerTUN", TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead = 80 };
                tags.Add(bhTags);
                IList<BeckhoffTag> total = dataReader.ReadTags(tags);
                tags.Clear();

                BeckhoffTag batchTag = new BeckhoffTag { Address = "uint_StoreProdDataTun", TagItemType = UIInputType.TypeArray, TagType = "uint", SizetoRead = (167 * Convert.ToInt16(total[0].Value)) };
                batchTag.BatchData = new List<ushort>(batchTag.SizetoRead);
                tags.Add(batchTag);
                IList<BeckhoffTag> batchData = dataReader.ReadTags(tags);
                tags.Clear();

                for (int i = 0; i < batchTag.SizetoRead; i++)
                {
                    lstBatchData.Items.Add(batchData[0].BatchData[i]);
                }
            }
            else if (cbTagName.SelectedItem.ToString() == "uint_StoreProdDataWE")
            {
                BeckhoffTag bhTag = new BeckhoffTag { Address = "uint_StorePointerWE_R", TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead = 80 };
                tags.Add(bhTag);
                tags.Clear();

                BeckhoffTag bhTags = new BeckhoffTag { Address = "uint_StorePointerWE", TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead = 80 };
                tags.Add(bhTags);
                IList<BeckhoffTag> total = dataReader.ReadTags(tags);
                tags.Clear();

                BeckhoffTag batchTag = new BeckhoffTag { Address = "uint_StoreProdDataWE", TagItemType = UIInputType.TypeArray, TagType = "uint", SizetoRead = (82 * Convert.ToInt16(total[0].Value)) };

                batchTag.BatchData = new List<ushort>(batchTag.SizetoRead);
                tags.Add(batchTag);
                IList<BeckhoffTag> batchData = dataReader.ReadTags(tags);
                tags.Clear();

                for (int i = 0; i < batchTag.SizetoRead; i++)
                {
                    lstBatchData.Items.Add(batchData[0].BatchData[i]);
                }
            }
            else
            {
                BeckhoffTag bhTags = new BeckhoffTag { Address = cbTagName.SelectedItem.ToString(), TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead = 80 };
                tags.Add(bhTags);
                IList<BeckhoffTag> total = dataReader.ReadTags(tags);
                lstBatchData.Items.Add(total[0].Value);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MitsubishiTag tag1 = new MitsubishiTag() { Address = txtMiLocation.Text, TagItemType = UIInputType.TypeRandomArray, ArrayLength = Int16.Parse(txtMiCount.Text) };

            tag1.Address = "R4300\nR4302\nR4305";
            MitsubishiController controller = new MitsubishiController() { HostAdress = txtMIIPAddress.Text, PLCType = MitsubishiPLCType.EControlPlus6W1T };
            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            IList<MitsubishiTag> tags = new List<MitsubishiTag>();
            tags.Add(tag1);
            dataReader.ReadTags(tags);
            string sResult = "";
            foreach (int number in tag1.IntArrayData)
            {
                sResult = sResult + number.ToString() + "\r\n";
            }



            txtArrayValues.Text = sResult;





        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {


            MitsubishiTag tag1 = new MitsubishiTag() { Address = txtMiLocation.Text, TagItemType = UIInputType.TypeArray, ArrayLength = Int16.Parse(txtMiCount.Text) };
            MitsubishiController controller = new MitsubishiController() { HostAdress = txtMIIPAddress.Text, PLCType = MitsubishiPLCType.EControlPlus6W1T };
            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            IList<MitsubishiTag> tags = new List<MitsubishiTag>();
            tags.Add(tag1);
            dataReader.ReadTags(tags);

            DataWriter<MitsubishiTag> writer = MitsubishiFactory.GetDataWriter(controller);
            string sResult = txtArrayValues.Text;
            sResult = sResult.Replace("\r", "");
            string[] dataValues = sResult.Split('\n');
            int i = 0;
            foreach (string value in dataValues)
            {
                if (string.IsNullOrEmpty(value.Trim())) break;
                tag1.IntArrayData[i] = int.Parse(value);
                i++;
            }


            writer.WriteTags(tags);
        }

        public static string GetETechXml(string EtechURL)
        {
            #region ETech XML for ref
            ///Parse the response XML and return the ETech object.
            //< DFLastDropped >
            //     < messageRevision > 1.0 </ messageRevision >
            //     < messageSent > 2016 - 02 - 09T05: 22:51 </ messageSent >
            //         < record >
            //             < productCode > 8 </ productCode >
            //             < productName > Stretcher Sheets </ productName >
            //            < customerCode > 1 </ customerCode >
            //            < customerName > Orlando </ customerName >
            //            < locationCode > 79 </ locationCode >
            //            < locationName > Tunnel 1 </ locationName >
            //             < soiledWeight > 116 </ soiledWeight >
            //             < totalWeight > 116 </ totalWeight >
            //             < batchCode > 3255940 </ batchCode >
            //             < lastDroppedAt > 2015 - 12 - 21 03:29:41 - 0600 </ lastDroppedAt >
            //             < updatedAt > 2015 - 12 - 22T08: 29:41 </ updatedAt >
            //          </ record >
            #endregion
            //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EtechURL);
            //HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            //XmlDocument xmlDoc = new XmlDocument();
            //xmlDoc.Load(response.GetResponseStream());
            //return xmlDoc.InnerXml;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(EtechURL);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            string value = null;
            DFLastDropped data = null;
            using (var st = response.GetResponseStream())
            {
                StreamReader sr = new StreamReader(st);
                value = sr.ReadToEnd();
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(value);

                return doc.InnerXml;

            }

        }
        public class DFLastDropped
        {
            [XmlElement]
            public string messageRevision { get; set; }
            [XmlElement]
            public string messageSent { get; set; }
            [XmlElement]
            public List<record> record { get; set; }
        }
        public class record
        {
            [XmlElement]
            public string productCode { get; set; }
            [XmlElement]
            public string productName { get; set; }
            [XmlElement]
            public string customerCode { get; set; }
            [XmlElement]
            public string customerName { get; set; }
            [XmlElement]
            public string locationCode { get; set; }
            [XmlElement]
            public string locationName { get; set; }
            [XmlElement]
            public string soiledWeight { get; set; }
            [XmlElement]
            public string totalWeight { get; set; }
            [XmlElement]
            public string batchCode { get; set; }
            [XmlElement]
            public string lastDroppedAt { get; set; }
            [XmlElement]
            public string updatedAt { get; set; }
        }
        private void btnRun_Click(object sender, EventArgs e)
        {
            try
            {
                string etechurl = txtETechIpAddress.Text + "/" + txtETechlWasherId.Text;
                txtETechXml.Text = GetETechXml(etechurl);
                if (!string.IsNullOrEmpty(txtETechXml.Text))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(DFLastDropped));
                    StringReader rdr = new StringReader(txtETechXml.Text);
                    DFLastDropped data = (DFLastDropped)serializer.Deserialize(rdr);
                    if (data.record.Count > 0)
                        txtTotalWeight.Text = data.record[0].totalWeight;
                    else
                        txtTotalWeight.Text = string.Empty;
                }
                else
                    txtTotalWeight.Text = string.Empty;
            }
            catch (Exception ex)
            {
                txtTotalWeight.Text = string.Empty;
                txtETechXml.Text = ex.Message;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            ReadEControlPlusDeviceTags("172.16.225.12", 2, 7);


        }

        public void ReadEControlPlusDeviceTags(string IpAddress, int controllerID, int controllerTypeID)
        {
            MitsubishiTag cbwParametersTag = new MitsubishiTag() { Address = "D317", TagItemType = UIInputType.TypeArray, ArrayLength = 68 };
            MitsubishiTag weParametersTag = new MitsubishiTag() { Address = "D16", TagItemType = UIInputType.TypeArray, ArrayLength = 30 * 8 };
            MitsubishiTag pumpParametersTag = new MitsubishiTag() { Address = "D390", TagItemType = UIInputType.TypeArray, ArrayLength = 60 };//FlushWhileDosingME(2),Pump_Parameters,ME_Parameters
            MitsubishiTag flowTag = new MitsubishiTag() { Address = "M901", TagItemType = UIInputType.TypeRandomArray, ArrayLength = 100 };//Equipment_Settings,FlowMeter_EN,Fl_Switch_EN,FMS_Activ,EquipmentAlone
            MitsubishiTag flowIntTags = new MitsubishiTag() { Address = "D464", TagItemType = UIInputType.TypeArray, ArrayLength = 20 };//FlowMeterPulsesPerLiter,MaxTimeFlowMeter

            IList<MitsubishiTag> onlineTags = new List<MitsubishiTag>() { cbwParametersTag, weParametersTag, pumpParametersTag, flowTag, flowIntTags };
            MitsubishiController controller = new MitsubishiController() { ControllerId = controllerID, HostAdress = IpAddress };
            controller.PLCType = (MitsubishiPLCType)controllerTypeID;



            StringBuilder tagAdress = new StringBuilder(1000);
            for (int i = 901; i <= 1000; i++)
            {
                if (i > 901)
                    tagAdress.Append("\n");
                tagAdress.Append("M" + i.ToString());
            }
            flowTag.Address = tagAdress.ToString();
            DataReader<MitsubishiTag> dataReader = MitsubishiFactory.GetDataReader(controller);
            DataWriter<MitsubishiTag> dataWriter = MitsubishiFactory.GetDataWriter(controller);
            onlineTags = dataReader.ReadTags(onlineTags);
            flowTag.IntArrayData[0] = 0;
            flowTag.IntArrayData[1] = 0;
            flowTag.IntArrayData[75] = 1;
            dataWriter.WriteTag(flowTag);




        }
    }
}