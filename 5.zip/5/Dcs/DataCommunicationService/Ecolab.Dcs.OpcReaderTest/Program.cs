﻿namespace Ecolab.Dcs.OpcReaderTest
{
    using System;
    using System.Threading;
    using System.Windows.Forms;
    using Properties;

    internal static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormMain());
            Application.ThreadException += CommonExceptionHandlingMethod;
        }

        private static void CommonExceptionHandlingMethod(object sender, ThreadExceptionEventArgs t)
        {
            MessageBox.Show(t.Exception.ToString(), Resources.Program_CommonExceptionHandlingMethod_Error, MessageBoxButtons.OK);
        }
    }
}