Interop.OPCAutomation.DLL which Interops the COM OPCDAAuto.DLL. 

Both of these were created by OPC Foundation and uses DA1 (Data Access 1) which was the original OPC (OLE for Process Control) standard. 

Ecolab.Dcs.CollectData DLL makes it easier to create a client that communicates to a device through an OPC server.

Register the COM OPCDAAuto.DLL located in solution items.

If 64 bit machine register in c:\windows\SysWOW64 regsvr32 OPCDAAuto.DLL (Append the path if needed)
If 32 bit machine register in c:\windows\System32 regsvr32 OPCDAAuto.DLL (Append the path if needed)

For Webport, Register the necessary tags of the washer(both conventional and Tunnel) in the eWon Tool, so that they will write to the FTP site.
Refer the Webport Technical approach document for complete details on how to register. (Doc is stored in Insideview\projectartifacts\plc\)