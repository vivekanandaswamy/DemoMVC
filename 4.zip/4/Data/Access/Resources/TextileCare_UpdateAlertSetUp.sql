Update TCD.AlertAutoNotificationDelta
	SET ResolutionText=@ResolutionText
	WHERE AlertNotificationId = @AlertNotificationId