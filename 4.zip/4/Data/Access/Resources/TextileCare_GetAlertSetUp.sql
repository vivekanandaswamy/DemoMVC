DECLARE @TEMP table (
AlertNotificationId INT,
 PlantId INT,
 PlantName NVARCHAR(100),
 RedFlagId INT,
 AlarmGroupMasterId INT,
 AlarmAlertDescription NVARCHAR(2000),
 DispenserName NVARCHAR(1000),
 EscalationThreshold INT,
 ResolutionText NVARCHAR(100),
 CreatedOn DATETIME2)

INSERT INTO @TEMP
	SELECT DISTINCT
			AU.AlertNotificationId,
			AU.PlantId,
			P.Name AS PlantName,
			AU.RedFlagId,
			AU.AlarmGroupMasterId,
			AG.Description AS AlarmAlertDescription,
		CONVERT(varchar(10), CC.ControllerNumber )+'('+CC.TopicName+')' as DispenserName,
			AU.EscalationThreshold,
			ISNULL(AN.ResolutionText,''),
			AN.CreatedOn
		FROM [TCD].AlertAutoNotificationDelta AS AN
			INNER JOIN [TCD].AlertSetUp AS AU ON AN.AlertNotificationId = AU.AlertNotificationId
			JOIN [TCD].Plant AS P ON P.PlantId = AU.PlantId
			JOIN [TCD].AlarmGroupMaster AS AG ON AG.AlarmGroupMasterId = AU.AlarmGroupMasterId 
			JOIN [TCD].ConduitController AS CC ON CC.ControllerId = AU.ControllerId
												AND CC.EcoalabAccountNumber = (SELECT 
															EcolabAccountNumber 
														FROM TCD.plant AS PL 
														WHERE PL.PlantId= P.PlantId )

INSERT INTO @TEMP
	SELECT DISTINCT
			AU.AlertNotificationId,
			AU.PlantId,
			P.Name AS PlantName,
			AU.RedFlagId,
			AU.AlarmGroupMasterId,
			RF.ItemName AS AlarmAlertDescription,
		'' as DispenserName,
			AU.EscalationThreshold,
			ISNULL(AN.ResolutionText,''),
			AN.CreatedOn
		FROM [TCD].AlertAutoNotificationDelta AS AN
			INNER JOIN [TCD].AlertSetUp AS AU ON AN.AlertNotificationId = AU.AlertNotificationId
						JOIN [TCD].Plant AS P ON P.PlantId = AU.PlantId
			JOIN [TCD].RedFlagItemList AS RF ON RF.Id = AU.RedFlagId 
												AND AU.AlarmGroupMasterId IS NULL
SELECT
		T.AlertNotificationId,
		T.PlantId,
		T.PlantName,
		T.RedFlagId,
		T.AlarmGroupMasterId,
		T.AlarmAlertDescription,
		T.DispenserName,
		T.EscalationThreshold,
		T.ResolutionText,
		T.CreatedOn
	FROM @TEMP AS T