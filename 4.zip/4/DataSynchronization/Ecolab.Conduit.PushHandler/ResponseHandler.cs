﻿// -----------------------------------------------------------------------
// <copyright file="ResponseHandler.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Response Handler </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.PushHandler
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Xml;
    using System.Xml.Linq;
    using Library.Enums;
    using log4net;

    [CLSCompliant(false)]
    public static class ResponseHandler
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ResponseHandler));

        public static void ProcessResponse(TcdErrCodes errorCode, TcdAdminMessageTypes messageType, string ecolabAccountNumber)
        {
			if (errorCode == TcdErrCodes.RecordCountNotMatch || errorCode == TcdErrCodes.RecordNotInSynch || errorCode == TcdErrCodes.ResyncImportFormula || errorCode == TcdErrCodes.ResyncMovePump)
            {
                XDocument xdoc = GetResyncXml();
                if (xdoc != null)
                {
                    XElement ele = xdoc.Root.Elements("Group").First(x => x.Attribute("Value").Value.Split(',').Contains(messageType.ToString()));
                    Log.Info("Resync started for : ");
                    foreach (var item in ele.Descendants("Item"))
                    {
                        Log.Info(item.Value);
                        ResyncEngine.Resync((TcdAdminMessageTypes)Enum.Parse(typeof(TcdAdminMessageTypes), item.Value), ecolabAccountNumber);
                    }
                }

            }
        }

        /// <summary>
        /// Get the sync configuration xml
        /// </summary>
        /// <returns>Xdocumnet</returns>
        private static XDocument GetResyncXml()
        {
            var basePath = AppDomain.CurrentDomain.RelativeSearchPath ?? AppDomain.CurrentDomain.BaseDirectory;
            XDocument xdoc = null;
            try
            {
                xdoc = XDocument.Load(Path.Combine(basePath, @"Resync.xml"));
            }
            catch (FileNotFoundException ex)
            {
                Log.Error(ex.Message + "GetResyncXml Method");
            }
            catch (Exception e)
            {
                Log.Fatal(e.Message + "GetResyncXml Method");
                throw;
            }

            return xdoc;
        }
    }
}