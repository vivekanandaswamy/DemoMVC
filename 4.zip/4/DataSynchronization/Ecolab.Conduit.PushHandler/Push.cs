﻿// -----------------------------------------------------------------------
// <copyright file="Push.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Push class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.PushHandler
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Globalization;
    using System.Linq;
    using System.Net.Sockets;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Models;
    using Ecolab.Models.Washers.Conventional;
    using Ecolab.Models.Washers.Tunnel;
    using Ecolab.Services;
    using Ecolab.Services.Interfaces;
    using Ecolab.Services.SyncConfigSettingService;
    using Ecolab.Services.Washers.conventional;
    using Ecolab.Services.Washers.Tunnel;
    using log4net;
    using Models.ControllerSetup;
    using Models.SyncMessages;
    using Models.TcpMessageQueue;
    using Newtonsoft.Json;
    using Services.SyncQueue;

    /// <summary>
    /// Push (Send message on TCP and receive the response)
    /// </summary>
    public static class Push
    {
        private static ILog Log = null;
        private static Dictionary<string, string> dicPushConfigSettings = new Dictionary<string, string>();
        private static PlantSettings plantSettingPush;
        private static string _loggerName = "PushHandler";

        public static string LoggerName
        {
            get { return _loggerName; }
            set { _loggerName = value; }
        }

        /// <summary>
        /// Push the entity to queue to process
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="t">object of type param T</param>
        /// <param name="userId">User ID</param>
        /// <param name="messageId">Message ID</param>
        /// <param name="actionType">Action Type</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Success=0,Failure=1</returns>
        public static int PushToQueue<T>(T t, int userId, int messageId, int actionType, string ecolabAccountNumber)
        {
            Log = LogManager.GetLogger(LoggerName);
            int status = 1; //0 = success, 1 = failure
            try
            {
                byte[] buffer = SerializeHelper.Serialize<T>(t);
                string requestEntity = Convert.ToBase64String(buffer);

                Log.Info("Entity serilized to json");

                // push message to queue.
                TcpMessageQueue objSyncData = new TcpMessageQueue()
                {
                    RequestMessage = requestEntity,
                    EntityType = t.GetType().ToString(),
                    CreatedDate = DateTime.UtcNow,
                    UserId = userId,
                    MessageId = messageId,
                    ActionType = actionType,
                    EcolabAccountNumber = ecolabAccountNumber
                };

                SyncQueueServices objSyncQueServices = new SyncQueueServices();
                status = objSyncQueServices.SaveTcpMessageQueueData(objSyncData);

                Log.Info(string.Format("PushToQueue : Saved Tcp message to queue, Action type :: {0} Queue Data :: {1}", actionType.ToString(), ImportExportUtility.SerializeToJsonFromEntity(t)));

                return status;
            }
            catch (Exception ex)
            {
                Log.Error("PushToQueue : Error Received While Push To Queue ", ex);
                return status;
            }
        }

        /// <summary>
        /// Push the entity to local
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="t">object of type param T</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="userId">User Id</param>
        /// <param name="actionType">Action Type</param>
        /// <returns>Success=0, Failure=1</returns>
        public static int PushToLocal<T>(T t, string ecolabAccountNumber, int userId, int actionType)
        {
            Log = LogManager.GetLogger(LoggerName);
            int status = 1; //0 = success, 1 = failure
            try
            {
                if (!string.IsNullOrEmpty(ecolabAccountNumber))
                {
                    UpdateCentralLastModifiedTime(t, actionType, ecolabAccountNumber);

                    byte[] buffer = SerializeHelper.Serialize<T>(t);

                    using (TcpClient client = new TcpClient())
                    {
                        PlantService plantService = new PlantService();
                        PlantSettings plantSettings = plantService.GetPlantSettings(ecolabAccountNumber);
                        client.ReceiveTimeout = int.Parse(plantSettings.ReadTimeout, CultureInfo.CurrentCulture);
                        client.Connect(plantSettings.IpAddress, Convert.ToInt32(plantSettings.PortNumber, CultureInfo.CurrentCulture));

                        Log.Info(string.Format("Server connection with HostName: {0}, Port Number: {1} Established. ", plantSettings.IpAddress, int.Parse(plantSettings.PortNumber, CultureInfo.CurrentCulture)));

                        using (NetworkStream stream = client.GetStream())
                        {
                            //Transport header
                            SendTransportHeader transportHeader = new SendTransportHeader();
                            transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                            transportHeader.Body.ServiceType = ServiceType.TcdAdmin;
                            Log.Info("PushToLocal : Header information" + "::" + ExportHelper.StructToString(transportHeader) + "Sent to stream. ");

                            //Admin Header
                            TcdAdminRequestHeader adminHeader = new TcdAdminRequestHeader
                            {
                                AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                                MessageType = (TcdAdminMessageTypes)actionType,
                                PayloadSize = (uint)buffer.Length,
                                MessageFormat = TcdMessageFormatTypes.MessagePack,
                                UserId = userId
                            };

                            Log.Info("PushToLocal : Admin Header Information" + "::" + ExportHelper.StructToString(adminHeader) + "sent to stream");

                            Log.Info("PushToLocal : Entity information :: " + ImportExportUtility.SerializeToJsonFromEntity(t));

                            stream.Write(transportHeader);
                            stream.Write(adminHeader);
                            stream.Write(buffer, 0, buffer.Length);

                            Log.Info("PushToLocal : Admin request sent to stream");

                            //read the response from tcp server
                            TcdAdminResponse response = stream.ReadAllOf<TcdAdminResponse>();
                            Log.Info("PushToLocal : Response received from local :: " + ExportHelper.StructToString(response));

                            //Resync in case of failure
                            if (response.ErrorCode != TcdErrCodes.Success)
                            {
                                ResponseHandler.ProcessResponse(response.ErrorCode, (TcdAdminMessageTypes)actionType, ecolabAccountNumber);
                            }

                            status = (int)response.ErrorCode;
                        }
                    }
                }
                else
                {
                    Log.Info("PushToLocal : Invalid EcolabAccountNumber");
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While Push To Local", socEx);
                return 51060;
            }
            catch (Exception ex)
            {
                Log.Error("Error Received While Push To Local", ex);
            }
            return status;
        }

        /// <summary>
        /// Push the entity to local
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="t">object of type param T</param>
        /// <param name="ecolabAccountNumber">ecolab account number</param>
        /// <param name="userId">the user id.</param>
        /// <param name="actionType">action type.</param>
        /// <param name="id">output parameter param.</param>
        /// <returns>Success=0, Failure=1</returns>
        public static int PushToLocal<T>(T t, string ecolabAccountNumber, int userId, int actionType, out int id)
        {
            Log = LogManager.GetLogger(LoggerName);
            int status = 1; //0 = success, 1 = failure
            id = 0;
            try
            {
                if (!string.IsNullOrEmpty(ecolabAccountNumber))
                {
                    UpdateCentralLastModifiedTime(t, actionType, ecolabAccountNumber);

                    byte[] buffer = SerializeHelper.Serialize<T>(t);

                    using (TcpClient client = new TcpClient())
                    {
                        PlantService plantService = new PlantService();
                        PlantSettings plantSettings = plantService.GetPlantSettings(ecolabAccountNumber);
                        client.ReceiveTimeout = int.Parse(plantSettings.ReadTimeout, CultureInfo.CurrentCulture);
                        client.Connect(plantSettings.IpAddress, Convert.ToInt32(plantSettings.PortNumber, CultureInfo.CurrentCulture));

                        Log.Info("Server connection with HostName:" + plantSettings.IpAddress + "Port Number:" + int.Parse(plantSettings.PortNumber, CultureInfo.CurrentCulture) + "Established. ");

                        using (NetworkStream stream = client.GetStream())
                        {
                            //Transport header
                            SendTransportHeader transportHeader = new SendTransportHeader();
                            transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                            transportHeader.Body.ServiceType = ServiceType.TcdAdmin;
                            Log.Info("PushToLocal : Header information" + "::" + ExportHelper.StructToString(transportHeader) + "Sent to stream. ");

                            //Admin Header
                            TcdAdminRequestHeader adminHeader = new TcdAdminRequestHeader
                            {
                                AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                                MessageType = (TcdAdminMessageTypes)actionType,
                                PayloadSize = (uint)buffer.Length,
                                MessageFormat = TcdMessageFormatTypes.MessagePack,
                                UserId = userId
                            };

                            Log.Info("PushToLocal : Admin Header Information" + "::" + ExportHelper.StructToString(adminHeader) + "sent to stream");

                            Log.Info("PushToLocal : Entity information :: " + ImportExportUtility.SerializeToJsonFromEntity(t));

                            stream.Write(transportHeader);
                            stream.Write(adminHeader);
                            stream.Write(buffer, 0, buffer.Length);

                            //read the response from tcp server
                            TcdAdminResponse response = stream.ReadAllOf<TcdAdminResponse>();
                            Log.Info("PushToLocal : Response received from local :: " + ExportHelper.StructToString(response));

                            //Resync in case of failure
                            if (response.ErrorCode != TcdErrCodes.Success)
                            {
                                ResponseHandler.ProcessResponse(response.ErrorCode, (TcdAdminMessageTypes)actionType, ecolabAccountNumber);
                            }

                            Log.Info("PushToLocal : Id value recieved in response :: " + response.Id.ToString(CultureInfo.CurrentCulture));
                            id = response.Id;

                            status = (int)response.ErrorCode;
                        }
                    }
                }
                else
                {
                    Log.Info("PushToLocal : Invalid EcolabAccountNumber");
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While Push To Local", socEx);
                return 51060;
            }
            catch (Exception ex)
            {
                Log.Error("Error Received While Push To Local", ex);
            }
            return status;
        }

        /// <summary>
        /// Push the  Master entity data to local
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="t">object of type param T</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="userId">UserId</param>
        /// <param name="actionType">Which action we need to performe</param>
        /// <returns>Success=0, Failure=1</returns>
        public static int PushMasterData<T>(T t, string ecolabAccountNumber, int userId, int actionType)
        {
            Log = LogManager.GetLogger(LoggerName);
            int status = 1; //0 = success, 1 = failure
            try
            {
                if (!string.IsNullOrEmpty(ecolabAccountNumber))
                {
                    byte[] buffer = SerializeHelper.Serialize<T>(t);

                    using (TcpClient client = new TcpClient())
                    {
                        PlantService plantService = new PlantService();
                        PlantSettings plantSettings = plantService.GetPlantSettings(ecolabAccountNumber);
                        client.ReceiveTimeout = int.Parse(plantSettings.ReadTimeout, CultureInfo.CurrentCulture);
                        client.Connect(plantSettings.IpAddress, Convert.ToInt32(plantSettings.PortNumber, CultureInfo.CurrentCulture));

                        Log.Info("Server connection with HostName:" + plantSettings.IpAddress + "Port Number:" + int.Parse(plantSettings.PortNumber, CultureInfo.CurrentCulture) + "Established. ");

                        using (NetworkStream stream = client.GetStream())
                        {
                            //Transport header
                            SendTransportHeader transportHeader = new SendTransportHeader();
                            transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                            transportHeader.Body.ServiceType = ServiceType.TcdMaster;
                            Log.Info("PushMasterData : Header information" + "::" + ExportHelper.StructToString(transportHeader) + "Sent to stream. ");

                            //Admin Header
                            TcdAdminRequestHeader adminHeader = new TcdAdminRequestHeader
                            {
                                AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                                MessageType = (TcdAdminMessageTypes)actionType,
                                PayloadSize = (uint)buffer.Length,
                                MessageFormat = TcdMessageFormatTypes.MessagePack,
                                UserId = userId
                            };

                            Log.Info("PushMasterData : Admin Header Information" + "::" + ExportHelper.StructToString(adminHeader) + "sent to stream");

                            Log.Info("PushMasterData : Entity information :: " + ImportExportUtility.SerializeToJsonFromEntity(t));

                            stream.Write(transportHeader);
                            stream.Write(adminHeader);
                            stream.Write(buffer, 0, buffer.Length);

                            Log.Info("PushMasterData : Admin request sent to stream.");

                            //read the response from tcp server
                            TcdAdminResponse response = stream.ReadAllOf<TcdAdminResponse>();
                            Log.Info("PushMasterData : Response received from local :: " + ExportHelper.StructToString(response));

                            status = (int)response.ErrorCode;
                        }
                    }
                }
                else
                {
                    Log.Info("PushMasterData : Invalid EcolabAccountNumber");
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While Push To Master", socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error Received While Push To Master", ex);
            }
            return status;
        }

        /// <summary>
        ///  Push the entity to Central
        /// </summary>
        /// <param name="arrByte">Array of Byte</param>        
        /// <param name="userId">user Id</param>
        /// <param name="actionType">action Type</param>
        /// <returns>TCD Admin Response Entity</returns>
        [CLSCompliant(false)]
        public static TcdAdminResponse PushToCentral(byte[] arrByte, int userId, int actionType)
        {
            Log = LogManager.GetLogger(LoggerName);
            try
            {
                Log.Info("Push to central process started. ");

                using (TcpClient client = new TcpClient())
                {
                    dicPushConfigSettings = GetConfigSettings("PushToCentral");//TODO: NEED To Change

                    client.ReceiveTimeout = int.Parse(dicPushConfigSettings["ReadTimeout"], CultureInfo.CurrentCulture);
                    client.Connect(dicPushConfigSettings["HostName"], int.Parse(dicPushConfigSettings["PortNumber"], CultureInfo.CurrentCulture));
                    Log.Info("Server connection with HostName:" + dicPushConfigSettings["HostName"] + "Port Number:" + int.Parse(dicPushConfigSettings["PortNumber"], CultureInfo.CurrentCulture) + "Established. ");

                    using (NetworkStream stream = client.GetStream())
                    {
                        //send transport header
                        SendTransportHeader transportHeader = new SendTransportHeader();
                        transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                        transportHeader.Body.ServiceType = ServiceType.TcdAdmin;

                        Log.Info("PushToCentral:Header information" + "::" + ExportHelper.StructToString(transportHeader) + "Sent to stream. ");

                        //Admin Header
                        TcdAdminRequestHeader adminHeader = new TcdAdminRequestHeader
                        {
                            AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                            MessageType = (TcdAdminMessageTypes)actionType,
                            PayloadSize = (uint)arrByte.Length,
                            MessageFormat = TcdMessageFormatTypes.MessagePack,
                            UserId = userId
                        };

                        Log.Info("PushToCentral:Admin Header Information" + "::" + ExportHelper.StructToString(adminHeader) + "sent to stream");

                        stream.Write(transportHeader);
                        stream.Write(adminHeader);
                        stream.Write(arrByte, 0, arrByte.Length);

                        Log.Info("PushToCentral: Admin request send to stream. ");

                        //read the response from tcp server
                        TcdAdminResponse response = stream.ReadAllOf<TcdAdminResponse>();
                        Log.Info("PushToCentral : Response received from central :: " + ExportHelper.StructToString(response));

                        if (response.ErrorCode == TcdErrCodes.Success)
                        {
                            //Update EcolabWasherId
                            if ((TcdAdminMessageTypes)actionType ==
                                        TcdAdminMessageTypes.TcdAddConventionaGeneral)
                            {
                                ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();

                                var obj = SerializeHelper.Deserialize<ConventionalGeneral>(arrByte);
                                conventionalGeneralServices.UpdateEcolabWasherId(response.EcolabWasherId, obj.Id, obj.EcolabAccountNumber);
                            }
                            else if ((TcdAdminMessageTypes)actionType ==
                                TcdAdminMessageTypes.TcdAddTunnelGeneral)
                            {
                                TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();

                                var obj = SerializeHelper.Deserialize<TunnelContainer>(arrByte);
                                tunnelGeneralServices.UpdateEcolabWasherId(response.EcolabWasherId, obj.TunnelGeneral.Id, obj.TunnelGeneral.EcolabAccountNumber);
                            }
                            else if ((TcdAdminMessageTypes)actionType ==
                                TcdAdminMessageTypes.TcdAddController)
                            {
                                var obj = SerializeHelper.Deserialize<ControllerSetupDataDetails>(arrByte);
                                ResponseHandler.ProcessResponse(TcdErrCodes.RecordNotInSynch, TcdAdminMessageTypes.TcdAddWasherGroup, obj.EcolabAccountNumber);
                            }
                        }
                        return response;
                    }
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While Push To Central", socEx);
                throw;
            }
            catch (Exception ex)
            {
                Log.Error("Error Received While Push To Central", ex);
                throw;
            }
        }

        /// <summary>
        /// Creates the First time request and sends it to Central server
        /// </summary>
        ///
        [CLSCompliant(false)]
        public static TcdErrCodes PushPlantSettings()
        {
            Log = LogManager.GetLogger(LoggerName);
            try
            {
                PlantSettings plantSettings = NggConfigSettingService.GetDeviceSettings(ConfigurationManager.AppSettings["N2g2Ip"], TcdAppVersion.VersionCurrent.ToString());

                if (NggConfigSettingService.ExceptionDetails != null)
                {
                    Log.Error(" Ngg: Error Occurred: ", NggConfigSettingService.ExceptionDetails);
                    Log.Error("FirstTimeRequest: Plant settings: " + JsonConvert.SerializeObject(plantSettings));
                    NggConfigSettingService.ExceptionDetails = null;
                }

                if (plantSettings.UpdateFlag)
                {
                    byte[] buffer = SerializeHelper.Serialize<PlantSettings>(plantSettings);
                    using (TcpClient client = new TcpClient())
                    {
                        Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
                        dicSyncConfigSettings = GetConfigSettings("PushAllEntities");

                        client.ReceiveTimeout = int.Parse(dicSyncConfigSettings["ReadTimeout"], CultureInfo.CurrentCulture);
                        client.Connect(dicSyncConfigSettings["HostName"], int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));
                        Log.Info(" Connected to Server for sending first time request. HostName: " +
                                 dicSyncConfigSettings["HostName"] +
                                 ", PortNumber: " + int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                        using (NetworkStream stream = client.GetStream())
                        {
                            //send transport header
                            SendTransportHeader transportHeader = new SendTransportHeader();
                            transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                            transportHeader.Body.ServiceType = ServiceType.FirstRequest;
                            Log.Info("FirstTimeRequest : Header information" + "::" + ExportHelper.StructToString(transportHeader));

                            //Admin Header
                            TcdFirstTimeRequestHeader adminHeader = new TcdFirstTimeRequestHeader
                            {
                                AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                                PayloadSize = (uint)buffer.Length,
                                MessageFormat = TcdMessageFormatTypes.MessagePack,
                                Timestamp = DateTime.UtcNow,
                                UserId = int.Parse(ConfigurationManager.AppSettings["SystemUserId"], CultureInfo.InvariantCulture.NumberFormat)
                            };
                            Log.Info("FirstTimeRequest:Admin Header Information" + "::" + ExportHelper.StructToString(adminHeader) + "sent to stream");
                            Log.Info("FirstTimeRequest: Plant settings: " + JsonConvert.SerializeObject(plantSettings));

                            stream.Write(transportHeader);
                            stream.Write(adminHeader);
                            stream.Write(buffer, 0, buffer.Length);

                            Log.Info("FirstTimeRequest: Request send to stream. ");

                            //read the response from tcp server
                            TcdFirstTimeMessageResponse response = stream.ReadAllOf<TcdFirstTimeMessageResponse>();
                            Log.Info("FirstTimeRequest: Response received " + JsonConvert.SerializeObject(response));
                            if (response.ErrorCode == TcdErrCodes.Success)
                            {
                                if (response.NodeId > 0)
                                {
                                    PlantService plantService = new PlantService();
                                    plantService.UpdateNodeId(plantSettings.EcolabAccountNumber, response.NodeId, response.Timestamp);
                                }
                            }
                            return response.ErrorCode;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("FirstTimeRequest: Error Occurred: ", ex);
            }

            return TcdErrCodes.RequestFailed;
        }

        /// <summary>
        /// Push NGG device details along with FTR
        /// </summary>
        /// <param name="plant">Plant details</param>
        public static void PushDeviceSettings(Plant plant)
        {
            Log = LogManager.GetLogger(LoggerName);
            TcdErrCodes response = TcdErrCodes.Success;
            int userID = int.Parse(ConfigurationManager.AppSettings["SystemUserId"], CultureInfo.InvariantCulture.NumberFormat);
            bool enableFtr = bool.Parse(ConfigurationManager.AppSettings["EnableAutoFTR"]);
            PushPlantSettings();
            PlantService plantService = new PlantService();
            if (enableFtr)
            {
                try
                {
                    if (plantSettingPush == null || (plantSettingPush != null && (plantSettingPush.NodeId <= 0 || plantSettingPush.FtrLastModifiedTime == DateTime.MinValue || plantSettingPush.FtrLastModifiedTime == null)))
                    {
                        plantSettingPush = plantService.GetPlantSettings(plant.EcoalabAccountNumber);
                        if (plantSettingPush == null)
                        {
                            return;
                        }
                    }
                    if (plantSettingPush.NodeId > 0 && (plantSettingPush.FtrLastModifiedTime == DateTime.MinValue || plantSettingPush.FtrLastModifiedTime == null))
                    {
                        for (int iterator = 1; iterator < 15; iterator++)
                        {
                            response = FirstTimeSyncFromLocal(plant.EcoalabAccountNumber, userID, iterator);
                            if (response != TcdErrCodes.Success)
                            {
                                break;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("FTR PushAllEntities : Error Occurred: ", ex);
                    if (plantSettingPush != null)
                    {
                        plantSettingPush.FtrLastModifiedTime = DateTime.MinValue;
                        plantSettingPush.EcolabAccountNumber = plant.EcoalabAccountNumber;
                        plantService.UpdateFtrModifiedTime(plantSettingPush, 1);
                    }
                }
            }
        }

        /// <summary>
        /// Push All Entities
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="userId">User Id</param>
        [CLSCompliant(false)]
        public static TcdErrCodes PushAllPlantEntities(string ecolabAccountNumber, int userId)
        {
            Log = LogManager.GetLogger(LoggerName);
            TcdErrCodes response = TcdErrCodes.Success;
            try
            {
                if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsNggConnected"]))
                {
                    TcdErrCodes err = PushPlantSettings();
                    if (err != TcdErrCodes.Success)
                    {
                        return TcdErrCodes.NggNotConnected;
                    }
                }

                for (int iterator = 1; iterator < 20; iterator++)
                {
                    response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, iterator);
                    if (response != TcdErrCodes.Success)
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("FTR PushAllEntities : Error Occurred: ", ex);
            }
            return response;
        }

        /// <summary>
        /// First Time Sync From Local
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="userId">The User Id</param>
        /// <param name="iterator">The Iterator</param>
        /// <param name="ftrTimeUpdate">First Time Upadte</param>
        /// <returns></returns>
        private static TcdErrCodes FirstTimeSyncFromLocal(string ecolabAccountNumber, int userId, int iterator, bool ftrTimeUpdate = true)
        {
            Log = LogManager.GetLogger(LoggerName);
            // Data in json format
            string data = ImportExportUtility.GetJsonData(ecolabAccountNumber, iterator);

            //Convert to byte[]
            byte[] buffer = SerializeHelper.ConvertStringToByteArray(data);

            using (TcpClient client = new TcpClient())
            {
                Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
                dicSyncConfigSettings = GetConfigSettings("PushAllEntities");

                client.ReceiveTimeout = int.Parse(dicSyncConfigSettings["ReadTimeout"], CultureInfo.CurrentCulture);
                client.Connect(dicSyncConfigSettings["HostName"], int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                Log.Info("FTR PushAllEntities : Connected to Server for sending first time request. HostName: "
                    + dicSyncConfigSettings["HostName"]
                    + ", PortNumber: " + int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                using (NetworkStream stream = client.GetStream())
                {
                    //send transport header
                    SendTransportHeader transportHeader = new SendTransportHeader();
                    transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                    transportHeader.Body.ServiceType = ServiceType.TcdAdminResync;

                    Log.Info("FTR PushAllEntities : Header information : " + ExportHelper.StructToString(transportHeader));

                    //First Time Request Admin Header
                    TcdFirstTimeRequestHeader adminHeader = new TcdFirstTimeRequestHeader
                    {
                        AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                        PayloadSize = (uint)buffer.Length,
                        MessageFormat = TcdMessageFormatTypes.MessagePack,
                        Timestamp = DateTime.UtcNow,
                        UserId = userId,
                        OffSet = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).TotalHours
                    };

                    Log.Info("FTR PushAllEntities : Admin Header Information : " + ExportHelper.StructToString(adminHeader) + " sent to stream ");
                    Log.Info("FTR PushAllEntities : Plant settings: " + JsonConvert.SerializeObject(data));

                    stream.Write(transportHeader);
                    stream.Write(adminHeader);
                    stream.Write(buffer, 0, buffer.Length);

                    Log.Info("FTR PushAllEntities : Request send to stream. ");

                    //read the response from tcp server
                    TcdFirstTimeMessageResponse response = stream.ReadAllOf<TcdFirstTimeMessageResponse>();
                    Log.Info("FTR PushAllEntities : Response received " + JsonConvert.SerializeObject(response));

                    if (response.ErrorCode == TcdErrCodes.Success)
                    {
                        byte[] inputBuffer = stream.ReadAllOf(response.PayloadSize);
                        string ecolabWasherIds = SerializeHelper.ConvertByteArrayToString(inputBuffer);
                        if (!string.IsNullOrEmpty(ecolabWasherIds))
                        {
                            foreach (string ids in ecolabWasherIds.Split(';'))
                            {
                                if (!string.IsNullOrEmpty(ids))
                                {
                                    int washerId = Convert.ToInt32(ids.Split(':')[0]);
                                    int ecoWasherId = Convert.ToInt32(ids.Split(':')[1]);
                                    if (washerId != 0 && ecoWasherId != 0)
                                    {
                                        ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();
                                        conventionalGeneralServices.UpdateEcolabWasherId(ecoWasherId, washerId, ecolabAccountNumber);
                                    }
                                }
                            }
                        }

                        if (iterator == 16 && ftrTimeUpdate)
                        {
                            PlantSettings plantSettings = new PlantSettings();
                            if (response.ErrorCode != TcdErrCodes.Success)
                            {
                                plantSettings.FtrLastModifiedTime = DateTime.MinValue;
                            }
                            else
                            {
                                plantSettings.FtrLastModifiedTime = response.Timestamp;
                            }
                            plantSettings.EcolabAccountNumber = ecolabAccountNumber;
                            PlantService plantService = new PlantService();
                            plantService.UpdateFtrModifiedTime(plantSettings, iterator);
                        }
                    }

                    return response.ErrorCode;
                }
            }
        }

        /// <summary>
        /// Push All Plant Entities
        /// </summary>
        /// <param name="buffer">Array of Buffer</param>
        /// <param name="userId">The User Id</param>
        public static void PushAllPlantEntities(byte[] buffer, int userId)
        {
            Log = LogManager.GetLogger(LoggerName);
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
                    dicSyncConfigSettings = GetConfigSettings("PushAllEntities");

                    client.ReceiveTimeout = int.Parse(dicSyncConfigSettings["ReadTimeout"], CultureInfo.CurrentCulture);
                    client.Connect(dicSyncConfigSettings["HostName"], int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                    Log.Info("Resync Push Entities : Connected to Server for Resync. HostName: " +
                             dicSyncConfigSettings["HostName"]
                             + ", PortNumber: " + int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                    using (NetworkStream stream = client.GetStream())
                    {
                        //send transport header
                        SendTransportHeader transportHeader = new SendTransportHeader();
                        transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                        transportHeader.Body.ServiceType = ServiceType.TcdAdminResync;

                        Log.Info("Resync Push Entities : Header information => " + ExportHelper.StructToString(transportHeader));

                        //First Time Request Admin Header
                        TcdFirstTimeRequestHeader adminHeader = new TcdFirstTimeRequestHeader
                        {
                            AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                            PayloadSize = (uint)buffer.Length,
                            MessageFormat = TcdMessageFormatTypes.MessagePack,
                            Timestamp = DateTime.UtcNow,
                            UserId = userId
                        };

                        Log.Info("Resync Push Entities : Admin Header Information => " + ExportHelper.StructToString(adminHeader) + "sent to stream");

                        stream.Write(transportHeader);
                        stream.Write(adminHeader);
                        stream.Write(buffer, 0, buffer.Length);

                        Log.Info("FTR PushAllEntities : Request send to central TCP. ");

                        //read the response from tcp server
                        TcdFirstTimeMessageResponse response = stream.ReadAllOf<TcdFirstTimeMessageResponse>();
                        Log.Info("Resync Push Entities : Response received => " + JsonConvert.SerializeObject(response));

                        if (response.ErrorCode == TcdErrCodes.Success)
                        {
                            byte[] inputBuffer = stream.ReadAllOf(response.PayloadSize);
                            string ecolabWasherIds = SerializeHelper.ConvertByteArrayToString(inputBuffer);
                            if (!string.IsNullOrEmpty(ecolabWasherIds))
                            {
                                PlantService plantService = new PlantService();
                                Plant plant = plantService.GetPlantDetails();
                                foreach (string ids in ecolabWasherIds.Split(';'))
                                {
                                    if (!string.IsNullOrEmpty(ids))
                                    {
                                        int washerId = Convert.ToInt32(ids.Split(':')[0]);
                                        int ecoWasherId = Convert.ToInt32(ids.Split(':')[1]);
                                        if (washerId != 0 && ecoWasherId != 0)
                                        {
                                            ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();
                                            conventionalGeneralServices.UpdateEcolabWasherId(ecoWasherId, washerId, plant.EcoalabAccountNumber);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Resync Push Entities  : Error Occurred: ", ex);
            }
        }

        /// <summary>
        /// Get Sync Configuration settings
        /// </summary>
        /// <param name="typeOfService">Type Of Service</param>
        /// <returns></returns>
        public static Dictionary<string, string> GetConfigSettings(string typeOfService)
        {
            SyncConfigSettingService objSyncConfigSettingService = new SyncConfigSettingService();
            return objSyncConfigSettingService.GetAppConfigKeyValueDetails(typeOfService);
        }

        /// <summary>
        /// Updates the central last modified time.
        /// </summary>
        /// <typeparam name="T">The Param T</typeparam>
        /// <param name="t">object of type param T</param>
        /// <param name="actionType">Type of the action.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>object of type param T</returns>
        public static T UpdateCentralLastModifiedTime<T>(T t, int actionType, string ecolabAccountNumber)
        {
            Log = LogManager.GetLogger(LoggerName);
            ISyncService syncService = new SyncService();
            string tableName = TableEntityMap.GetTable(t.GetType().ToString());
            string typeName = string.Empty;
            if (t.GetType().ToString().Equals("Ecolab.Models.PlantSetup.Dryer.DryerGroup"))
            {
                typeName = "DryerGroup";
            }
            else if (t.GetType().ToString().Equals("Ecolab.Models.PlantSetup.Finnisher.FinnisherGroup"))
            {
                typeName = "FinnisherGroup";
            }
            else if (t.GetType().ToString().Equals("Ecolab.Models.WasherGroup.WasherGroup"))
            {
                typeName = "WasherGroup";
            }
            else if (t.GetType().ToString().Equals("Ecolab.Models.Washers.Conventional.ConventionalGeneral") || (t.GetType().ToString().Equals("Ecolab.Models.Washers.Washers") && t.GetType().GetProperty("WasherTypeFlag").GetValue(t, null).ToString().Equals("False")))
            {
                typeName = "ConventionalGeneral";
            }
            else if (t.GetType().ToString().Equals("Ecolab.Models.Washers.Tunnel.TunnelContainer") || t.GetType().ToString().Equals("Ecolab.Models.Washers.Tunnel.TunnelGeneral") || (t.GetType().ToString().Equals("Ecolab.Models.Washers.Washers") && t.GetType().GetProperty("WasherTypeFlag").GetValue(t, null).ToString().Equals("True")))
            {
                typeName = "Tunnel";
            }
            else
            {
                typeName = string.Empty;
            }

            if (t.GetType().ToString().Equals("Ecolab.Models.PlantSetup.ShiftLabor.ShiftSyncContainer") && Convert.ToBoolean(t.GetType().GetProperty("IsLabor").GetValue(t, null)))
            {
                tableName = "ShiftLaborData";
            }
            if (t.GetType().ToString().Equals("Ecolab.Models.Washers.Alarms") && Convert.ToBoolean(t.GetType().GetProperty("IsBatchEjectCondition").GetValue(t, null)))
            {
                tableName = "BatchEjectConditionStatus";
                if (t.GetType().GetProperty("LastModifiedTimeBatchEjectionCentral") != null)
                {
                    Log.Info("Fetching Last modified time for Message Type: " + (TcdAdminMessageTypes)actionType + " TableName: BatchEjectConditionStatus");
                    typeName = "PlantId";
                }
            }

            if (t.GetType().ToString().Equals("Ecolab.Models.WasherGroup.CopyFormulaContainer") && Convert.ToBoolean(t.GetType().GetProperty("IsConventional").GetValue(t, null).ToString().Equals("True")))
            {
                tableName = "WasherProgramSetup";
            }
            if (t.GetType().ToString().Equals("Ecolab.Models.WasherGroup.CopyFormulaContainer") && Convert.ToBoolean(t.GetType().GetProperty("IsConventional").GetValue(t, null).ToString().Equals("False")))
            {
                tableName = "TunnelProgramSetup";
            }

            if (t.GetType().GetProperty("LastModifiedTimestampAtCentral") != null && !string.IsNullOrEmpty(tableName))
            {
                Log.Info("Fetching Last modified time for Message Type: " + (TcdAdminMessageTypes)actionType + " TableName: " + tableName);
                DateTime lastModifiedTimeCentral = syncService.GetLatestLastModifiedTime(tableName, ecolabAccountNumber, typeName);
                Log.Info("Last Modified Time at Central : " + lastModifiedTimeCentral);

                t.GetType().GetProperty("LastModifiedTimestampAtCentral").SetValue(t, DateTime.SpecifyKind(lastModifiedTimeCentral, DateTimeKind.Utc));
            }

            if (t.GetType().GetProperty("LastModifiedTimeWasherFlushCentral") != null && t.GetType().GetProperty("LastModifiedTimeTimeOutMachineCentral") != null)
            {
                Log.Info("Fetching Last modified time for Message Type: " + (TcdAdminMessageTypes)actionType + " TableName: WasherFlushTime and WasherTimeOutMachine");
                typeName = "PlantId";

                DateTime lastModifiedTimeCentral = syncService.GetLatestLastModifiedTime("WasherFlushTime", ecolabAccountNumber, typeName);
                Log.Info("Last Modified Time at Central for WasherFlushTime: " + lastModifiedTimeCentral);
                t.GetType().GetProperty("LastModifiedTimeWasherFlushCentral").SetValue(t, DateTime.SpecifyKind(lastModifiedTimeCentral, DateTimeKind.Utc));

                lastModifiedTimeCentral = syncService.GetLatestLastModifiedTime("WasherTimeOutMachine", ecolabAccountNumber, typeName);
                Log.Info("Last Modified Time at Central for WasherTimeOutMachine: " + lastModifiedTimeCentral);
                t.GetType().GetProperty("LastModifiedTimeTimeOutMachineCentral").SetValue(t, DateTime.SpecifyKind(lastModifiedTimeCentral, DateTimeKind.Utc));
            }
            if (t.GetType().GetProperty("LastModifiedProductDeviationCentral") != null)
            {
                Log.Info("Fetching Last modified time for Message Type: " + (TcdAdminMessageTypes)actionType + " TableName: WasherProductDeviations");
                typeName = "PlantId";

                DateTime lastModifiedTimeCentral = syncService.GetLatestLastModifiedTime("WasherProductDeviations", ecolabAccountNumber, typeName);
                Log.Info("Last Modified Time at Central for ProductDeviations: " + lastModifiedTimeCentral);
                t.GetType().GetProperty("LastModifiedProductDeviationCentral").SetValue(t, DateTime.SpecifyKind(lastModifiedTimeCentral, DateTimeKind.Utc));
            }
            if (t.GetType().GetProperty("LastModifiedAnalogueDosingControlCentral") != null)
            {
                Log.Info("Fetching Last modified time for Message Type: " + (TcdAdminMessageTypes)actionType + " TableName: TunnelAnalogControlLevel");
                typeName = "PlantId";

                DateTime lastModifiedTimeCentral = syncService.GetLatestLastModifiedTime("TunnelAnalogControlLevel", ecolabAccountNumber, typeName);
                Log.Info("Last Modified Time at Central for Tunnel Analogue Dosing Control: " + lastModifiedTimeCentral);
                t.GetType().GetProperty("LastModifiedAnalogueDosingControlCentral").SetValue(t, DateTime.SpecifyKind(lastModifiedTimeCentral, DateTimeKind.Utc));
            }

            return t;
        }

        /// <summary>
        /// Get the details from Central
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="actionType">Action Type from TcdAdmin Message</param>
        /// <returns>responceFromCentral</returns>
        public static TcdErrCodes FetchCentralData(string ecolabAccountNumber, int actionType)
        {
            return FetchCentralData(ecolabAccountNumber, actionType, string.Empty, 1);
        }

        /// <summary>
        /// Get the details from Central
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="actionType">Action Type from TcdAdmin Message</param>
        /// <param name="csvPath">csv path to download data to</param>
        /// <param name="iterator">count of chunk data to download</param>
        /// <returns>responceFromCentral</returns>
        public static TcdErrCodes FetchCentralData(string ecolabAccountNumber, int actionType, string csvPath, int iterator)
        {
            Log = LogManager.GetLogger(LoggerName);
            string responseData = string.Empty;
            TcdErrCodes responseError = TcdErrCodes.RequestFailed;
            try
            {
                byte[] buffer = SerializeHelper.Serialize<String>(ecolabAccountNumber);

                using (TcpClient client = new TcpClient())
                {
                    Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
                    dicSyncConfigSettings = GetConfigSettings("PushAllEntities");

                    client.ReceiveTimeout = int.Parse(dicSyncConfigSettings["ReadTimeout"], CultureInfo.CurrentCulture);
                    client.Connect(dicSyncConfigSettings["HostName"], int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                    Log.Info("Fetch Central Data : Connected to Server. HostName: " +
                             dicSyncConfigSettings["HostName"]
                             + ", PortNumber: " + int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                    using (NetworkStream stream = client.GetStream())
                    {
                        //send transport header
                        SendTransportHeader transportHeader = new SendTransportHeader();
                        transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                        transportHeader.Body.ServiceType = ServiceType.TcdFetchCentralData;

                        Log.Info("Fetch Central Data : Header information => " + ExportHelper.StructToString(transportHeader));

                        //Admin Header
                        TcdFirstTimeRequestHeader firstTimeRequestHeader = new TcdFirstTimeRequestHeader
                        {
                            AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                            MessageType = (TcdAdminMessageTypes)actionType,
                            PayloadSize = (uint)buffer.Length,
                            MessageFormat = TcdMessageFormatTypes.MessagePack,
                            Iterator = (uint)iterator
                        };

                        Log.Info("Fetch Central Data : First Header Information => " + ExportHelper.StructToString(firstTimeRequestHeader) + "sent to stream");

                        stream.Write(transportHeader);
                        stream.Write(firstTimeRequestHeader);
                        stream.Write(buffer, 0, buffer.Length);

                        Log.Info("Fetch Central Data : Request send to central TCP. ");

                        //read the response from tcp server
                        TcdFirstTimeMessageResponse response = stream.ReadAllOf<TcdFirstTimeMessageResponse>();
                        responseError = response.ErrorCode;
                        if (response.ErrorCode == TcdErrCodes.Success)
                        {
                            byte[] inputBuffer = stream.ReadAllOf(response.PayloadSize);
                            responseData = SerializeHelper.ConvertByteArrayToString(inputBuffer);
                            if (response.MessageType == TcdAdminMessageTypes.TcdGetPlantEntities)
                            {
                                ImportExportUtility.SaveAllEntities(responseData, iterator);
                                if (iterator == 14)
                                {
                                    PlantSettings plantSettings = new PlantSettings();
                                    plantSettings.EcolabAccountNumber = ecolabAccountNumber;
                                    plantSettings.FtrLastModifiedTime = DateTime.UtcNow;
                                    plantSettings.PlantVersion = ((int)TcdAppVersion.VersionCurrent).ToString();
                                    PlantService plantService = new PlantService();
                                    plantService.InsertUpdatePlantSettings(plantSettings);
                                }
                            }
                            else if (response.MessageType == TcdAdminMessageTypes.TcdGetPlantEntitiesForCSV)
                            {
                                ImportExportUtility importExportUtility = new ImportExportUtility();
                                importExportUtility.ExportMigrationDataFromCentralToCSV(responseData, csvPath, iterator);
                            }
                        }
                        Log.Info("Fetch Central Data : Response received from central :: " + JsonConvert.SerializeObject(response));
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Fetch Central Data  : Error Occurred: " + ex.ToString());
                responseError = TcdErrCodes.SaveFailure;
            }

            return responseError;
        }

        /// <summary>
        /// Get the details from Central
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="actionType">Action Type from TcdAdmin Message</param>
        /// <returns>
        /// responceFromCentral
        /// </returns>
        public static string FetchenVisionVersion(string ecolabAccountNumber, int actionType)
        {
            Log = LogManager.GetLogger(LoggerName);
            string responseData = string.Empty;
            //TcdErrCodes responseError = TcdErrCodes.RequestFailed;
            try
            {
                byte[] buffer = SerializeHelper.Serialize<String>(ecolabAccountNumber);

                using (TcpClient client = new TcpClient())
                {
                    Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
                    dicSyncConfigSettings = GetConfigSettings("PushAllEntities");

                    client.ReceiveTimeout = int.Parse(dicSyncConfigSettings["ReadTimeout"], CultureInfo.CurrentCulture);
                    client.Connect(dicSyncConfigSettings["HostName"], int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                    Log.Info("Fetch Central Data : Connected to Server. HostName: " +
                             dicSyncConfigSettings["HostName"]
                             + ", PortNumber: " + int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                    using (NetworkStream stream = client.GetStream())
                    {
                        //send transport header
                        SendTransportHeader transportHeader = new SendTransportHeader();
                        transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                        transportHeader.Body.ServiceType = ServiceType.TcdFetchCentralData;

                        Log.Info("Fetch Central Data : Header information => " + ExportHelper.StructToString(transportHeader));

                        //Admin Header
                        TcdFirstTimeRequestHeader firstTimeRequestHeader = new TcdFirstTimeRequestHeader
                        {
                            AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                            MessageType = (TcdAdminMessageTypes)actionType,
                            PayloadSize = (uint)buffer.Length,
                            MessageFormat = TcdMessageFormatTypes.MessagePack
                        };

                        Log.Info("Fetch Central Data : First Header Information => " + ExportHelper.StructToString(firstTimeRequestHeader) + "sent to stream");

                        stream.Write(transportHeader);
                        stream.Write(firstTimeRequestHeader);
                        stream.Write(buffer, 0, buffer.Length);

                        Log.Info("Fetch Central Data : Request send to central TCP. ");

                        //read the response from tcp server
                        TcdFirstTimeMessageResponse response = stream.ReadAllOf<TcdFirstTimeMessageResponse>();
                        //responseError = response.ErrorCode;
                        if (response.ErrorCode == TcdErrCodes.Success)
                        {
                            byte[] inputBuffer = stream.ReadAllOf(response.PayloadSize);
                            responseData = SerializeHelper.ConvertByteArrayToString(inputBuffer);
                        }
                        Log.Info("Fetch Central Data : Response received from central :: " + JsonConvert.SerializeObject(response));
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Fetch Central Data  : Error Occurred: " + ex.ToString());
            }

            return responseData;
        }

        /// <summary>
        /// Resync Formula
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="userId">The USer ID</param>
        /// <returns>Error Code</returns>
        public static TcdErrCodes ResyncFormula(string ecolabAccountNumber, int userId)
        {
            Log = LogManager.GetLogger(LoggerName);
            TcdErrCodes response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, 2);
            if (response == TcdErrCodes.Success)
            {
                response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, 3);
            }
            if (response == TcdErrCodes.Success)
            {
                response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, 4);
            }
            if (response == TcdErrCodes.Success)
            {
                response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, 7);
            }
            if (response == TcdErrCodes.Success)
            {
                response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, 8);
            }
            if (response == TcdErrCodes.Success)
            {
                response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, 9);
            }
            if (response == TcdErrCodes.Success)
            {
                response = FirstTimeSyncFromLocal(ecolabAccountNumber, userId, 16, false);
            }
            return response;
        }

        /// <summary>
        /// Push Production shift data from local plant to central
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber of Plant</param>
        /// <param name="plantEntities">Production shift data Object</param>
        /// <returns>Error if any otherwise success</returns>
        public static int PushProductionShiftData(string ecolabAccountNumber, TcdAllPlantEntities plantEntities)
        {
            Log = LogManager.GetLogger(LoggerName);
            SyncQueueServices syncQueueServices = new SyncQueueServices();
            string data = JsonConvert.SerializeObject(plantEntities);
            //Convert to byte[]
            byte[] buffer = SerializeHelper.ConvertStringToByteArray(data);

            using (TcpClient client = new TcpClient())
            {
                Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
                dicSyncConfigSettings = GetConfigSettings("PushAllEntities");

                client.ReceiveTimeout = int.Parse(dicSyncConfigSettings["ReadTimeout"], CultureInfo.CurrentCulture);
                client.Connect(dicSyncConfigSettings["HostName"], int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                Log.Info("ProductionShiftData : Connected to Server for sending ProductionShiftData request. HostName: "
                    + dicSyncConfigSettings["HostName"]
                    + ", PortNumber: " + int.Parse(dicSyncConfigSettings["PortNumber"], CultureInfo.CurrentCulture));

                using (NetworkStream stream = client.GetStream())
                {
                    //send transport header
                    SendTransportHeader transportHeader = new SendTransportHeader();
                    transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                    transportHeader.Body.ServiceType = ServiceType.TcdAdminResync;

                    Log.Info("ProductionShiftData : Header information : " + ExportHelper.StructToString(transportHeader));

                    //First Time Request Admin Header
                    TcdFirstTimeRequestHeader adminHeader = new TcdFirstTimeRequestHeader
                    {
                        AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                        PayloadSize = (uint)buffer.Length,
                        MessageFormat = TcdMessageFormatTypes.MessagePack,
                        Timestamp = DateTime.UtcNow,
                        UserId = 0
                    };

                    Log.Info("ProductionShiftData : Admin Header Information : " + ExportHelper.StructToString(adminHeader) + " sent to stream ");
                    Log.Info("ProductionShiftData : Plant settings: " + JsonConvert.SerializeObject(data));

                    stream.Write(transportHeader);
                    stream.Write(adminHeader);
                    stream.Write(buffer, 0, buffer.Length);

                    Log.Info("ProductionShiftData : Request send to stream. ");

                    //read the response from tcp server
                    TcdFirstTimeMessageResponse response = stream.ReadAllOf<TcdFirstTimeMessageResponse>();
                    Log.Info("ProductionShiftData : Response received " + JsonConvert.SerializeObject(response));

                    if (response.ErrorCode == TcdErrCodes.Success)
                    {
                        foreach (Ecolab.Models.PlantSetup.ShiftLabor.ProductionShiftData item in plantEntities.ProductionShiftDataContainerList.FirstOrDefault().ProductionShiftData)
                        {
                            syncQueueServices.LastSyncUpdate("ProductionShiftData", item.ShiftId, "ShiftId", ecolabAccountNumber, response.Timestamp); 
                        }
                    }
                    return (int)response.ErrorCode;
                }
            }
        }
    }
}