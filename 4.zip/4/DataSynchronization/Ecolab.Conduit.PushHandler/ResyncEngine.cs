﻿// -----------------------------------------------------------------------
// <copyright file="ResyncEngine.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Resync Engine </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.PushHandler
{
    using System;
    using System.Configuration;
    using System.Globalization;
    using System.Net.Sockets;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.SyncLibrary.Enum;
    using Ecolab.Models.SyncMessages;
    using Ecolab.Services;
    using log4net;

    [CLSCompliant(false)]
    public static class ResyncEngine
    {
        private static readonly ILog Log = LogManager.GetLogger("ReSyncEngine");
        /// <summary>
        /// Resync
        /// </summary>
        /// <param name="messageType">Message Type</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>It will return result code of resync</returns>
        public static PushResult Resync(TcdAdminMessageTypes messageType, string ecolabAccountNumber)
        {
            try
            {
                Log.Info("Resync started for message type: " + messageType.ToString() + " and EcolabAccountNumber: " + ecolabAccountNumber);
                PlantService plantService = new PlantService();
                PlantSettings plantSettings = plantService.GetPlantSettings(ecolabAccountNumber);

                using (TcpClient client = new TcpClient())
                {
                    client.ReceiveTimeout = Properties.Settings.Default.ReceiveTimeout;
                    Log.Info("Trying to connect server with IpAddress : " + plantSettings.IpAddress + ", Port Number: " + plantSettings.PortNumber + ". ");
                    client.Connect(plantSettings.IpAddress, Convert.ToInt32(plantSettings.PortNumber, CultureInfo.InvariantCulture));

                    using (NetworkStream stream = client.GetStream())
                    {
                        //send transport header
                        SendTransportHeader transportHeader = new SendTransportHeader();
                        transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                        transportHeader.Body.ServiceType = ServiceType.TcdAdminResync;

                        Log.Info("Resync: Header information" + "::" + ExportHelper.StructToString(transportHeader) + "Sent to stream. ");

                        TcdAdminRequestHeader adminHeader = new TcdAdminRequestHeader
                        {
                            AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                            MessageType = messageType,
                            MessageFormat = TcdMessageFormatTypes.MessagePack,
                            UserId = int.Parse(ConfigurationManager.AppSettings["SystemUserId"], CultureInfo.InvariantCulture.NumberFormat)
                        };

                        Log.Info("Resync: Admin Header Information" + "::" + ExportHelper.StructToString(adminHeader) + "sent to stream");

                        stream.Write(transportHeader);
                        stream.Write(adminHeader);
                    }
                }
            }
            catch (SocketException ex)
            {
                Log.Error("Resync error for message type: " + messageType.ToString() + " and EcolabAccountNumber: " + ecolabAccountNumber + " Exception: " + ex.Message + "; StackTrace: " + ex.StackTrace);
                return PushResult.CommunicationFailure;
            }
            catch (Exception ex)
            {
                Log.Error("Resync error for message type: " + messageType.ToString() + " and EcolabAccountNumber: " + ecolabAccountNumber + " Exception: " + ex.Message + "; StackTrace: " + ex.StackTrace);
                return PushResult.CommunicationFailure;
            }
            return PushResult.Success;
        }

        /// <summary>
        /// Resync All
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>It will return result code of resync</returns>
        public static PushResult ResyncAll(string ecolabAccountNumber)
        {
            try
            {
                PlantService plantService = new PlantService();
                PlantSettings plantSettings = plantService.GetPlantSettings(ecolabAccountNumber);

                using (TcpClient client = new TcpClient())
                {
                    client.ReceiveTimeout = Properties.Settings.Default.ReceiveTimeout;
                    Log.Info("Trying to connect server with IpAddress : " + plantSettings.IpAddress + ", Port Number: " + plantSettings.PortNumber + ". ");
                    client.Connect(plantSettings.IpAddress, Convert.ToInt32(plantSettings.PortNumber, CultureInfo.InvariantCulture));

                    using (NetworkStream stream = client.GetStream())
                    {
                        //send transport header
                        SendTransportHeader transportHeader = new SendTransportHeader();
                        transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                        transportHeader.Body.ServiceType = ServiceType.TcdAdminResync;
                        Log.Info("Resync: Header information" + "::" + ExportHelper.StructToString(transportHeader) + "Sent to stream. ");

                        TcdAdminRequestHeader adminHeader = new TcdAdminRequestHeader
                        {
                            AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
                            MessageType = TcdAdminMessageTypes.TcdResyncAll,
                            MessageFormat = TcdMessageFormatTypes.MessagePack,
                        };

                        Log.Info("Resync: Admin Header Information" + "::" + ExportHelper.StructToString(adminHeader) + "sent to stream");

                        stream.Write(transportHeader);
                        stream.Write(adminHeader);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Resync error for EcolabAccountNumber: " + ecolabAccountNumber + " Exception: " + ex.Message + "; StackTrace: " + ex.StackTrace);
                return PushResult.CommunicationFailure;
            }
            return PushResult.Success;
        }
    }
}
