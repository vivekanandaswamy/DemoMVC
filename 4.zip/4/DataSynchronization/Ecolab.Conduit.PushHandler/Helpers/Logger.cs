﻿// -----------------------------------------------------------------------
// <copyright file="Logger.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Logger</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.PushHandler.Helpers
{
    using System;
    using log4net;

    public static class Logger
    {
        /// <summary>
        ///      Initializes static members of the <see cref="Logger" /> class.
        /// </summary>
        static Logger()
        {
            Log = LogManager.GetLogger(typeof(Logger));
        }

        private static ILog Log { get; set; }

        /// <summary>
        ///     Logs error with message
        /// </summary>
        /// <param name="msg">Message</param>
        public static void Error(object msg)
        {
            Log.Error(msg);
        }

        /// <summary>
        ///     Logs error with message and exception
        /// </summary>
        /// <param name="msg">Message</param>
        /// <param name="ex">Object of type exception</param>
        public static void Error(object msg, Exception ex)
        {
            Log.Error(msg, ex);
        }

        /// <summary>
        ///     Logs error with exception
        /// </summary>
        /// <param name="ex">Object of type exception</param>
        public static void Error(Exception ex)
        {
            Log.Error(ex.Message, ex);
        }

        /// <summary>
        ///     Information regarding Message
        /// </summary>
        /// <param name="msg">Message</param>
        public static void Info(object msg)
        {
            Log.Info(msg);
        }
    }
}