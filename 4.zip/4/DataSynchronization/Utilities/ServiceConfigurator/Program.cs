﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Program </summary>
// -----------------------------------------------------------------------

namespace ServiceConfigurator
{
    using System;
    using System.Windows.Forms;

    internal static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmServiceConfigurator());
        }
    }
}