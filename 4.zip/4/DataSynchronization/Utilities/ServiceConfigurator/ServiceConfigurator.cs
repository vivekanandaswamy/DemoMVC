﻿// -----------------------------------------------------------------------
// <copyright file="ServiceConfigurator.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The frmServiceConfigurator </summary>
// -----------------------------------------------------------------------

namespace ServiceConfigurator
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Windows.Forms;
    using Ecolab.Data.Access;
    using Ecolab.Services.SyncConfigSettingService;

	/// <summary>
	/// The frmServiceConfigurator partial class
	/// </summary>
    public partial class frmServiceConfigurator : Form
    {
        private static Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
        private readonly SyncConfigSettingService configurationService = new SyncConfigSettingService();

        /// <summary>
        ///     Service Configurator
        /// </summary>
        public frmServiceConfigurator()
        {
            InitializeComponent();
        }

        private Dictionary<string, string> GetConfiguration(string serviceName)
        {
            return configurationService.GetAppConfigKeyValueDetails(serviceName);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string serviceName = cmbService.SelectedItem.ToString().Trim();
            int result = 0;
            result = configurationService.UpdateConfiguration(serviceName, cmbKey.SelectedValue.ToString().Trim(), txtValue.Text);

            if (result == 1)
            {
                lblStatus.Text = "Data updated successfully.";
            }
            else
            {
                lblStatus.Text = "Error in updation";
            }

            FillGrid(serviceName);
            txtValue.Text = string.Empty;
        }

        private void cmbService_SelectedIndexChanged(object sender, EventArgs e)
        {
            string serviceName = cmbService.SelectedItem.ToString().Trim();
            FillGrid(serviceName);
            dicSyncConfigSettings = GetConfiguration(serviceName);
            cmbKey.DataSource = dicSyncConfigSettings.Keys.ToList();
        }

        private void FillGrid(string serviceName)
        {
            dataGridView1.DataSource = configurationService.GetAppConfigKeyValueDetails(serviceName).ToList();
        }

        private void frmServiceConfigurator_Load(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
        }
    }
}