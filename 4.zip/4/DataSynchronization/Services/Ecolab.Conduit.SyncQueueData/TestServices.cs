﻿// -----------------------------------------------------------------------
// <copyright file="TestServices.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TestServices </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncQueueData
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Windows.Forms;
    using log4net;

	/// <summary>
	/// The Test Services.
	/// </summary>
    public partial class TestServices : Form
    {
        private static readonly ILog Log = LogManager.GetLogger("SyncQueueDataService");
        private static Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
        private readonly SyncQueueService objSyncQueueService = new SyncQueueService();

        public TestServices()
        {
            InitializeComponent();
            Trace.Listeners.Add(new TestServicesFormTraceListener(LogOutput));
        }

        private void BtnStartSyncQueueServices_Click(object sender, EventArgs e)
        {
            objSyncQueueService.Start();
        }

        private void BtnStopServices_Click(object sender, EventArgs e)
        {
            if (objSyncQueueService.CanStop)
            {
                objSyncQueueService.Stop();
            }
        }

        private void TestServices_Load(object sender, EventArgs e)
        {
            //TO DO :: Need to check why log4net throwing security permission error at load.
            // which get cleaned by below line. once fixed, below line need to be removed.
            LogOutput.Text = string.Empty;
            lblError.Text = string.Empty;
            try
            {
                dicSyncConfigSettings = SyncQueueService.GetConfiguration("SyncQueuedata");
                if (dicSyncConfigSettings != null && dicSyncConfigSettings.Count() > 5)
                {
                    txtServer.Text = dicSyncConfigSettings["HostName"];
                    txtPort.Text = dicSyncConfigSettings["PortNumber"];
                    txtTimeOut.Text = dicSyncConfigSettings["ReadTimeout"];
                    txtAutoReset.Text = dicSyncConfigSettings["TimerAutoReset"];
                    txtTimerEnabled.Text = dicSyncConfigSettings["TimerEnabled"];
                    txtTimerInterval.Text = dicSyncConfigSettings["TimerInterval"];
                }
                else
                {
                    lblError.Text = "Configuration setting is missing.";
                    Log.Error("Configuration setting is missing.");
                }
            }
            catch (Exception ex)
            {
                Log.Info("Configuration setting is missing.");
                Log.Error("Error : " + ex.Message);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
        }
    }

    internal class TestServicesFormTraceListener : TraceListener
    {
        private readonly TextBox LogTextBox;

        public TestServicesFormTraceListener(TextBox logTextBox)
        {
            LogTextBox = logTextBox;
        }

        public override void Write(string message)
        {
            if (LogTextBox.InvokeRequired)
            {
                LogTextBox.Invoke((MethodInvoker) delegate { Write(message); });
                return;
            }

            LogTextBox.AppendText(message);
        }

        public override void WriteLine(string message)
        {
            Write(message);
            Write(Environment.NewLine);
        }
    }
}