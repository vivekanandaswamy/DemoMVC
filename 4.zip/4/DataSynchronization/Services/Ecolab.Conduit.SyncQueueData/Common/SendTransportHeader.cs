﻿using System;
using System.Runtime.InteropServices;

namespace Ecolab.Conduit.SyncQueueData.Common
{
    [CLSCompliant(false)]
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct SendTransportHeader
    {
        /// <summary>
        /// Version
        /// </summary>
        public uint Version;
        
        /// <summary>
        /// Body
        /// </summary>
        public EcpTransportHeader Body;

        /// <summary>
        /// ToString
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Body.ToString();
        }
    }
}
