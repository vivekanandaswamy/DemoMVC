﻿using Ecolab.Conduit.SyncQueueData.Enums;
using System;
using System.Runtime.InteropServices;

namespace Ecolab.Conduit.SyncQueueData.Common
{
    [CLSCompliant(false)]
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct EcpTransportHeader
    {
        public const uint SUPPORTEDVERSION = 4;

        public ServiceType ServiceType;

        public EcpString32 ControllerId;

        public override string ToString()
        {
            return string.Format("{0}-{1}",
                ServiceType,
                ControllerId);
        }
    }
}
