﻿// -----------------------------------------------------------------------
// <copyright file="TcdAdminRequestBase.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd Admin Request Base</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncQueueData.Common
{
    using System;
    using System.IO;
    using System.Runtime.Remoting.Contexts;
    using log4net;
    using Library.Common;
    using Library.Enums;

    /// <summary>
    /// Class for TcdAdminRequestBase
    /// </summary>
    /// <typeparam name="T">T is the dynamic value of TcdAdminRequestBase</typeparam>
    /// <seealso cref="Ecolab.Conduit.SyncQueueData.Common.TcdAdminRequestBase" />
    [CLSCompliant(false)]
    public abstract class TcdAdminRequestBase<T> : TcdAdminRequestBase where T : class
    {
        private ILog Log;
        //*Header Data Ends*//

        /// <summary>
        /// Initializes a new instance of the <see cref="TcdAdminRequestBase{T}"/> class.
        /// </summary>
        /// <param name="logger">The logger for TcdAdminRequest.</param>
        /// <param name="adminHeader">The admin header.</param>
        /// <param name="appVersion">The application version.</param>
        /// <param name="inputBuffer">The input buffer.</param>
        public TcdAdminRequestBase(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
        {
            RequestMessageType = adminHeader.MessageType;
            RequestPayloadSize = adminHeader.PayloadSize;
            RequestUserId = adminHeader.UserId;
            AppVersion = appVersion;
            Initialize(logger, inputBuffer);
        }

        //*Header Data Starts*//
        /// <summary>
        /// Gets the size of the request payload.
        /// </summary>
        /// <value>
        /// The size of the request payload.
        /// </value>
        public uint RequestPayloadSize { get; private set; }
        /// <summary>
        /// Gets the request user identifier.
        /// </summary>
        /// <value>
        /// The request user identifier.
        /// </value>
        public int RequestUserId { get; private set; }
        /// <summary>
        /// Gets the request timestamp UTC.
        /// </summary>
        /// <value>
        /// The request timestamp UTC.
        /// </value>
        public DateTime RequestTimestampUtc { get; private set; }

        /// <summary>
        /// Initializes the specified logger.
        /// </summary>
        /// <param name="logger">The logger for tcd admin.</param>
        /// <param name="inputBuffer">The input buffer.</param>
        private void Initialize(ILog logger, byte[] inputBuffer)
        {
            Log = logger;

            InitializePayloadWithInputBuffer(inputBuffer);
        }

        /// <summary>
        /// Override this method to use a different structure for different app versions.
        /// </summary>
        /// <param name="inputBuffer">The input buffer.</param>
        protected virtual void InitializePayloadWithInputBuffer(byte[] inputBuffer)
        {
                        
        }

        /// <summary>
        /// GetPayloadType
        /// </summary>
        /// <param name="version">The version for tcd admin.</param>
        /// <returns>
        /// The Type return.
        /// </returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(T);
        }
    }

    /// <summary>
    /// TcdAdminRequestBase
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.SyncQueueData.Common.TcdAdminRequestBase" />
    [CLSCompliant(false)]
    public abstract class TcdAdminRequestBase
    {
        /// <summary>
        /// RequestMessageType
        /// </summary>
        /// <value>
        /// The type of the request message.
        /// </value>
        public TcdAdminMessageTypes RequestMessageType { get; protected set; }

        /// <summary>
        /// Gets or sets The AppVersion
        /// </summary>
        /// <value>
        /// The application version.
        /// </value>
        public TcdAppVersion AppVersion { get; set; }

        /// <summary>
        /// ProcessMessageInternal
        /// </summary>
        /// <param name="outputStream">outputStream for tcd admin</param>
        /// <param name="context">The context for tcd admin</param>
        /// <param name="state">The state param for tcd admin.</param>
        /// <returns>
        /// TcdErrCodes from tcd admin
        /// </returns>
        protected abstract TcdErrCodes ProcessMessageInternal(Stream outputStream, Context context, object state);

        /// <summary>
        /// ProcessMessage
        /// </summary>
        /// <param name="outputStream">outputStream for tcd admin</param>
        /// <param name="context">The context for tcd admin</param>
        /// <param name="state">the state param.</param>
        /// <returns>
        /// TcdErrCodes from tcd admin
        /// </returns>
        public TcdErrCodes ProcessMessage(Stream outputStream, Context context, object state)
        {
            return ProcessMessageInternal(outputStream, context, state);
        }

        /// <summary>
        /// GetPayloadType
        /// </summary>
        /// <param name="version">The version for tcd admin.</param>
        /// <returns>
        /// The type retuns.
        /// </returns>
        public abstract Type GetPayloadType(TcdAppVersion version);
    }
}