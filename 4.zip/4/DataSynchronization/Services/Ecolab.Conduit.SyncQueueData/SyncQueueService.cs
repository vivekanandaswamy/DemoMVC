﻿// -----------------------------------------------------------------------
// <copyright file="SyncQueueService.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Sync Queue Service class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncQueueData
{
	using System;
	using System.Collections.Generic;
	using System.Configuration;
	using System.Diagnostics;
	using System.Globalization;
	using System.Net.Sockets;
	using System.ServiceProcess;
	using System.Threading;
	using Ecolab.Conduit.PushHandler;
	using Ecolab.Models.SyncMessages;
	using Ecolab.Services;
	using Entities.TcpMessageQueue;
	using Library.Common;
	using Library.Enums;
	using Library.Helpers;
	using log4net;
	using Models;
	using Models.PlantSetup;
	using Models.PlantSetup.Dryer;
	using Models.PlantSetup.Finnisher;
	using Models.PlantSetup.RedFlag;
	using Models.PlantSetup.ShiftLabor;
	using Models.Washers;
	using Models.Washers.Conventional;
	using Models.Washers.Tunnel;
	using Services.SyncConfigSettingService;
	using Services.SyncQueue;
	using Services.Washers.conventional;
	using Services.Washers.Tunnel;
	using ServiceType = Library.Enums.ServiceType;
	using Timer = System.Timers.Timer;

	/// <summary>
	///     SyncQueueService
	/// </summary>
	public partial class SyncQueueService : ServiceBase
	{
		private static Dictionary<string, string> dicSyncConfiguration = new Dictionary<string, string>();
		private static readonly ILog Log = LogManager.GetLogger("SyncQueueDataService");
		private Timer batchTimer;
        ManualResetEvent timerDead = new ManualResetEvent(false);
        private bool serviceStopping;
        private static PlantSettings plantSettingQueue;
		private static Plant plantQueue;

		/// <summary>
		///     Default System UserId
		/// </summary>
		private static readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"], CultureInfo.InvariantCulture);

		/// <summary>
		///     SyncQueueService
		/// </summary>
		public SyncQueueService()
		{
			this.InitializeComponent();
		}

		/// <summary>
		/// OnStart method
		/// </summary>
		/// <param name="args">array argument</param>
		protected override void OnStart(string[] args)
		{
			dicSyncConfiguration = GetConfiguration("SyncQueuedata");

			//configuration READTIMEOUT, HOSTNAME, PORTNUMBER, TIMERINTERVAL, TIMERAUTORESET and TIMERENABLED is required
			if (dicSyncConfiguration.Count >= 6)
			{
				try
				{
					Log.Info("SyncQueueService : Get All sync configuration. ");
					Log.Info("================================================");
					Log.Info(" Host Name = " + dicSyncConfiguration["HostName"] + " , PortNumber = " +
							 int.Parse(dicSyncConfiguration["PortNumber"], CultureInfo.CurrentCulture) + " , Timeout = " +
							 int.Parse(dicSyncConfiguration["ReadTimeout"], CultureInfo.CurrentCulture) +
							 " , Timer Auto Reset = " + bool.Parse(dicSyncConfiguration["TimerAutoReset"]) +
							 " , Timer Enabled = " + bool.Parse(dicSyncConfiguration["TimerEnabled"]) +
							 " , Timer Interval = " +
							 double.Parse(dicSyncConfiguration["TimerInterval"], CultureInfo.CurrentCulture));
					Log.Info("================================================");

					//Check for null values of mandatory configuration
					if (String.IsNullOrEmpty(dicSyncConfiguration["HostName"]))
					{
						Log.Info(" Host Name is null.");
						return;
					}
					if (string.IsNullOrEmpty(dicSyncConfiguration["PortNumber"]))
					{
						Log.Info(" Port Number is null.");
						return;
					}
					if (string.IsNullOrEmpty(dicSyncConfiguration["ReadTimeout"]))
					{
						Log.Info(" Timeout  is null.");
						return;
					}
					if (string.IsNullOrEmpty(dicSyncConfiguration["TimerAutoReset"]))
					{
						Log.Info(" Timer AutoReset is null.");
						return;
					}
					if (string.IsNullOrEmpty(dicSyncConfiguration["TimerEnabled"]))
					{
						Log.Info(" Timer enabled is null.");
						return;
					}
					if (string.IsNullOrEmpty(dicSyncConfiguration["TimerInterval"]))
					{
						Log.Info(" Timer Interval is null.");
						return;
					}
				}
				catch (Exception ex)
				{
					if (ex.Message == "The given key was not present in the dictionary.")
					{
						Log.Info("Sync config data has not been configured or few configuration missing.");
					}
					else
					{
						Log.Info("Error " + ex.Message);
					}
					return;
				}
			}
			else
			{
				Log.Info("SyncQueueService : Sync config data has not been configured or few configuration missing.");
				return;
			}
			if (!Debugger.IsAttached)
			{
                this.batchTimer = new Timer(double.Parse(dicSyncConfiguration["TimerInterval"], CultureInfo.CurrentCulture))
                {
                    AutoReset = false
				};
                this.batchTimer.Elapsed += this.ReCallProcess;
                this.batchTimer.Enabled = true;
				Log.Info("SyncQueueService : Timer property set successfully. ");
			}
			else
			{
				ProcessQueue();
			}
		}

		/// <summary>
		/// ReCallProcess
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">parameter e</param>
		private void ReCallProcess(object sender, EventArgs e)
		{
            timerDead.Reset();
            ProcessQueue();
            timerDead.Set();
            if (!serviceStopping)
                batchTimer.Start(); // start the time. It will take Interval time ( 15 min ) to fire next time.
		}

		/// <summary>
		///     Only used to start the service when debugging
		/// </summary>
		internal void Start()
		{
			this.OnStart(null);
		}

		/// <summary>
		/// ProcessQueue Method
		/// </summary>
		private static void ProcessQueue()
		{
			try
			{
				PlantService plantService = new PlantService();
				if (plantQueue == null)
				{
					plantQueue = plantService.GetPlantDetails();
					if (plantQueue == null)
					{
						return;
					}
				}
				if (plantSettingQueue == null || (plantSettingQueue != null && (plantSettingQueue.NodeId <= 0 || plantSettingQueue.FtrLastModifiedTime == DateTime.MinValue || plantSettingQueue.FtrLastModifiedTime == null)))
				{
					plantSettingQueue = plantService.GetPlantSettings(plantQueue.EcoalabAccountNumber);
					if (plantSettingQueue == null)
					{
						return;
					}
				}
				if (plantSettingQueue.NodeId <= 0 || plantSettingQueue.FtrLastModifiedTime == DateTime.MinValue || plantSettingQueue.FtrLastModifiedTime == null)
				{
					return;
				}
				else
				{
					SyncQueueServices syncQueueServices = new SyncQueueServices();
					List<TcpMessageQueueEntity> queueRequest = syncQueueServices.GetQueueRequest();
					if (queueRequest.Count > 0)
					{
						for (int count = 0; count < queueRequest.Count; count++)
						{
							if (queueRequest[count].FailureCount < 11)
							{
                                Log.Info("Get data from queue. Data count = " + queueRequest.Count);
								if (queueRequest[count].ActionType == (int)TcdAdminMessageTypes.TcdSubstituteChemical 
                                    || queueRequest[count].ActionType == (int)TcdAdminMessageTypes.TcdCopyFormula
                                    || queueRequest[count].ActionType == (int)TcdAdminMessageTypes.TcdMovePump)
								{
                                    TcdErrCodes response = Push.ResyncFormula(queueRequest[count].EcolabAccountNumber, SystemUserId);
                                    int tcpId = queueRequest[count].Id;
                                    if (response == TcdErrCodes.Success)
                                    {
                                        syncQueueServices.DeleteTcpMessage(tcpId);
                                    }
                                    else if (response == TcdErrCodes.RequestFailed)
                                    {
                                        syncQueueServices.UpdateFailureCount(tcpId);
                                    }
								}
								else
								{
									using (TcpClient client = new TcpClient())
									{
										client.ReceiveTimeout = int.Parse(dicSyncConfiguration["ReadTimeout"],
											CultureInfo.CurrentCulture);
                                        client.Connect(dicSyncConfiguration["HostName"],
											int.Parse(dicSyncConfiguration["PortNumber"], CultureInfo.CurrentCulture));

										using (NetworkStream stream = client.GetStream())
										{
											byte[] buffer = null;
											byte[] logoBuffer = null;
											//send transport header
											SendTransportHeader transportHeader = new SendTransportHeader();
											transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
											transportHeader.Body.ServiceType = ServiceType.TcdAdmin;

											string messageDetails = queueRequest[count].RequestMessage;
											int actionType = queueRequest[count].ActionType;
											string entityName = queueRequest[count].EntityType;
											if (((TcdAdminMessageTypes)actionType) == TcdAdminMessageTypes.TcdUpdatePlant)
											{
												logoBuffer = Convert.FromBase64String(plantQueue.Logo);
											}

											buffer = Convert.FromBase64String(messageDetails);
											LogMessageDetails(entityName, buffer);

											//Admin Header
											TcdAdminRequestHeader adminHeader = new TcdAdminRequestHeader
											{
												AppVersion = (uint)((int)TcdAppVersion.VersionCurrent),
												MessageType = (TcdAdminMessageTypes)actionType,
												PayloadSize = (uint)buffer.Length,
												LogoSize = logoBuffer != null ? (uint)logoBuffer.Length : 0,
												MessageFormat = TcdMessageFormatTypes.MessagePack,
												UserId = SystemUserId,
												Timestamp = DateTimeHelper.ConvertToUnixTimestamp(DateTime.UtcNow)
											};

											stream.Write(transportHeader);
											stream.Write(adminHeader);
											stream.Write(buffer, 0, buffer.Length);
											if (((TcdAdminMessageTypes)actionType) == TcdAdminMessageTypes.TcdUpdatePlant)
											{
												stream.Write(logoBuffer, 0, logoBuffer.Length);
											}

											Log.Info("Process Queue:Admin Header Information" + "::" +
													 ExportHelper.StructToString(adminHeader) + "sent to stream");

											//read the response from tcp server
											TcdAdminResponse response = stream.ReadAllOf<TcdAdminResponse>();
											Log.Info("Process Queue : Response received from central :: " + ExportHelper.StructToString(response));

											//Once successfully send to TCP server. delete from queue.
											int tcpId = queueRequest[count].Id;
											int messageId = queueRequest[count].MessageId;
											string entityType = queueRequest[count].EntityType;

											if (response.ErrorCode == TcdErrCodes.Success)
											{
												//Update EcolabWasherId
												if ((TcdAdminMessageTypes)actionType ==
													TcdAdminMessageTypes.TcdAddConventionaGeneral)
												{
													ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();

													ConventionalGeneral obj = SerializeHelper.Deserialize<ConventionalGeneral>(buffer);
													conventionalGeneralServices.UpdateEcolabWasherId(response.EcolabWasherId, obj.Id,
														obj.EcolabAccountNumber);
												}
												else if ((TcdAdminMessageTypes)actionType ==
														 TcdAdminMessageTypes.TcdAddTunnelGeneral)
												{
													TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();

													TunnelContainer obj = SerializeHelper.Deserialize<TunnelContainer>(buffer);
													tunnelGeneralServices.UpdateEcolabWasherId(response.EcolabWasherId, obj.TunnelGeneral.Id,
														obj.TunnelGeneral.EcolabAccountNumber);
												}

												if (syncQueueServices.DeleteTcpMessage(tcpId))
												{
													string tableName = TableEntityMap.GetTable(entityType);
													string columnName = TableEntityMap.GetColumn(entityType);
													if (tableName.Equals("ShiftData"))
													{
														ShiftSyncContainer obj = SerializeHelper.Deserialize<ShiftSyncContainer>(buffer);
														if (obj.IsLabor)
														{
															tableName = "ShiftLaborData";
														}
													}
													syncQueueServices.LastSyncUpdate(tableName, messageId, columnName, queueRequest[count].EcolabAccountNumber,
														response.LastSyncTime);
												}
											}
											else if (response.ErrorCode == TcdErrCodes.RequestFailed)
											{
                                                syncQueueServices.UpdateFailureCount(tcpId);
											}
										}
									}
								}
							}
						}
					}
					Thread.Sleep(60);
				}
			}
			catch (SocketException socEx)
			{
				Log.Error("Error Received While process queue :" + socEx);
			}
			catch (Exception ex)
			{
				Log.Error("Error occured while process queue :" + ex);
			}
		}

		/// <summary>
		///     On Stop
		/// </summary>
		protected override void OnStop()
		{
			//if (!Debugger.IsAttached)
			//{
			//	this.batchTimer.Stop();
			//}
			//Log.Info("Service stopped.");
            try
            {
                serviceStopping = true;
                // wait until current file collection operation is done
                timerDead.WaitOne();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to stop Data SyncQueueDate Service", ex);
            }
            finally
            {
                Log.InfoFormat("{0}: Service has been stopped.", "SyncQueueData");
            }
        }

		/// <summary>
		///     Get Sync Configuration settings
		/// </summary>
		/// <param name="serviceName"></param>
		/// <returns></returns>
		public static Dictionary<string, string> GetConfiguration(string serviceName)
		{
			SyncConfigSettingService syncConfigSettingService = new SyncConfigSettingService();
			return syncConfigSettingService.GetAppConfigKeyValueDetails(serviceName);
		}

		/// <summary>
		///     Log Message Details
		/// </summary>
		/// <param name="entityName"></param>
		/// <param name="buffer"></param>
		public static void LogMessageDetails(string entityName, byte[] buffer)
		{
			//TO DO :: Need to make it generic
			switch (entityName)
			{
				case "Ecolab.Models.PlantSetup.Dryer.Dryer":
					Log.Info("Message Details " + ExportHelper.ClassToString(SerializeHelper.Deserialize<Dryer>(buffer)));
					break;

				case "Ecolab.Models.PlantSetup.Finnisher.Finnisher":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<Finnisher>(buffer)));
					break;

				case "Ecolab.Models.PlantSetup.SensorModel":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<SensorModel>(buffer)));
					break;

				case "Ecolab.Models.Washers.Tunnel.TunnelGeneral":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<TunnelGeneral>(buffer)));
					break;

				case "Ecolab.Models.PlantSetup.ShiftLabor.LaborCost":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<LaborCost>(buffer)));
					break;

				case "Ecolab.Models.PlantSetup.ShiftLabor.ShiftLabor":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<ShiftLabor>(buffer)));
					break;

				case "Ecolab.Models.Washers.Alarms":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<Alarms>(buffer)));
					break;

				case "Ecolab.Models.Washers.Tunnel.TunnelCompartment":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<TunnelCompartment>(buffer)));
					break;

				case "Ecolab.Models.PlantSetup.RedFlag":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<RedFlag>(buffer)));
					break;

				case "Ecolab.Models.PlantContact":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<PlantContact>(buffer)));
					break;

				case "Ecolab.Models.PlantCustomer":
					Log.Info("Message Details " +
							 ExportHelper.ClassToString(SerializeHelper.Deserialize<PlantCustomer>(buffer)));
					break;

				case "Ecolab.Models.Plant":
					Log.Info("Message Details " + ExportHelper.ClassToString(SerializeHelper.Deserialize<Plant>(buffer)));
					break;
			}
		}
	}
}