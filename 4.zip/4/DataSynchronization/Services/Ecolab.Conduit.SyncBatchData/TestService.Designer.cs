﻿// -----------------------------------------------------------------------
// <copyright file="TestService.Designer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TestService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncBatchData
{
    partial class TestService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LogOutput = new System.Windows.Forms.TextBox();
            this.lblBatch = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnStopServices = new System.Windows.Forms.Button();
            this.btnStartServices = new System.Windows.Forms.Button();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtTimeOut = new System.Windows.Forms.TextBox();
            this.txtAutoReset = new System.Windows.Forms.TextBox();
            this.txtTimerEnabled = new System.Windows.Forms.TextBox();
            this.txtTimerInterval = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblError = new System.Windows.Forms.Label();
            this.txtRecordToProcessed = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.LogOutput);
            this.groupBox2.Controls.Add(this.lblBatch);
            this.groupBox2.Controls.Add(this.btnClear);
            this.groupBox2.Controls.Add(this.btnStopServices);
            this.groupBox2.Controls.Add(this.btnStartServices);
            this.groupBox2.Location = new System.Drawing.Point(2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(581, 484);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Batch Data Service";
            // 
            // LogOutput
            // 
            this.LogOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogOutput.Location = new System.Drawing.Point(9, 52);
            this.LogOutput.Multiline = true;
            this.LogOutput.Name = "LogOutput";
            this.LogOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LogOutput.Size = new System.Drawing.Size(566, 426);
            this.LogOutput.TabIndex = 11;
            // 
            // lblBatch
            // 
            this.lblBatch.AutoSize = true;
            this.lblBatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBatch.Location = new System.Drawing.Point(474, 27);
            this.lblBatch.Name = "lblBatch";
            this.lblBatch.Size = new System.Drawing.Size(11, 13);
            this.lblBatch.TabIndex = 12;
            this.lblBatch.Text = ".";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(324, 19);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(142, 27);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // btnStopServices
            // 
            this.btnStopServices.Location = new System.Drawing.Point(162, 19);
            this.btnStopServices.Name = "btnStopServices";
            this.btnStopServices.Size = new System.Drawing.Size(149, 27);
            this.btnStopServices.TabIndex = 9;
            this.btnStopServices.Text = "Stop Batch Data Services";
            this.btnStopServices.UseVisualStyleBackColor = true;
            this.btnStopServices.Click += new System.EventHandler(this.BtnStopServices_Click);
            // 
            // btnStartServices
            // 
            this.btnStartServices.Location = new System.Drawing.Point(9, 19);
            this.btnStartServices.Name = "btnStartServices";
            this.btnStartServices.Size = new System.Drawing.Size(147, 27);
            this.btnStartServices.TabIndex = 8;
            this.btnStartServices.Text = "Start Batch Data Service";
            this.btnStartServices.UseVisualStyleBackColor = true;
            this.btnStartServices.Click += new System.EventHandler(this.BtnStartServices_Click);
            // 
            // txtServer
            // 
            this.txtServer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtServer.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtServer.Location = new System.Drawing.Point(120, 22);
            this.txtServer.Name = "txtServer";
            this.txtServer.ReadOnly = true;
            this.txtServer.Size = new System.Drawing.Size(100, 20);
            this.txtServer.TabIndex = 0;
            // 
            // txtPort
            // 
            this.txtPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPort.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtPort.Location = new System.Drawing.Point(120, 49);
            this.txtPort.Name = "txtPort";
            this.txtPort.ReadOnly = true;
            this.txtPort.Size = new System.Drawing.Size(100, 20);
            this.txtPort.TabIndex = 1;
            // 
            // txtTimeOut
            // 
            this.txtTimeOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimeOut.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtTimeOut.Location = new System.Drawing.Point(120, 76);
            this.txtTimeOut.Name = "txtTimeOut";
            this.txtTimeOut.ReadOnly = true;
            this.txtTimeOut.Size = new System.Drawing.Size(100, 20);
            this.txtTimeOut.TabIndex = 2;
            // 
            // txtAutoReset
            // 
            this.txtAutoReset.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAutoReset.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtAutoReset.Location = new System.Drawing.Point(120, 103);
            this.txtAutoReset.Name = "txtAutoReset";
            this.txtAutoReset.ReadOnly = true;
            this.txtAutoReset.Size = new System.Drawing.Size(100, 20);
            this.txtAutoReset.TabIndex = 3;
            // 
            // txtTimerEnabled
            // 
            this.txtTimerEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimerEnabled.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtTimerEnabled.Location = new System.Drawing.Point(120, 130);
            this.txtTimerEnabled.Name = "txtTimerEnabled";
            this.txtTimerEnabled.ReadOnly = true;
            this.txtTimerEnabled.Size = new System.Drawing.Size(100, 20);
            this.txtTimerEnabled.TabIndex = 4;
            // 
            // txtTimerInterval
            // 
            this.txtTimerInterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimerInterval.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtTimerInterval.Location = new System.Drawing.Point(120, 157);
            this.txtTimerInterval.Name = "txtTimerInterval";
            this.txtTimerInterval.ReadOnly = true;
            this.txtTimerInterval.Size = new System.Drawing.Size(100, 20);
            this.txtTimerInterval.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(9, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Host Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(9, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Port Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(9, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Read Timeout";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(9, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Timer AutoReset";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(9, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Timer Enabled";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(9, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Timer Interval";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(23, 225);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 13);
            this.lblError.TabIndex = 5;
            // 
            // txtRecordToProcessed
            // 
            this.txtRecordToProcessed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRecordToProcessed.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtRecordToProcessed.Location = new System.Drawing.Point(121, 181);
            this.txtRecordToProcessed.Name = "txtRecordToProcessed";
            this.txtRecordToProcessed.ReadOnly = true;
            this.txtRecordToProcessed.Size = new System.Drawing.Size(100, 20);
            this.txtRecordToProcessed.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Maroon;
            this.label7.Location = new System.Drawing.Point(10, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Record to processed";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtRecordToProcessed);
            this.groupBox1.Controls.Add(this.lblError);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtTimerInterval);
            this.groupBox1.Controls.Add(this.txtTimerEnabled);
            this.groupBox1.Controls.Add(this.txtAutoReset);
            this.groupBox1.Controls.Add(this.txtTimeOut);
            this.groupBox1.Controls.Add(this.txtPort);
            this.groupBox1.Controls.Add(this.txtServer);
            this.groupBox1.ForeColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Location = new System.Drawing.Point(587, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 254);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Configuration Details";
            // 
            // TestService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 499);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "TestService";
            this.Text = "Sync Batch Data Service Test";
            this.Load += new System.EventHandler(this.TestService_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnStopServices;
        private System.Windows.Forms.Button btnStartServices;
        private System.Windows.Forms.TextBox LogOutput;
        private System.Windows.Forms.Label lblBatch;
        private System.Windows.Forms.TextBox txtServer;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.TextBox txtTimeOut;
        private System.Windows.Forms.TextBox txtAutoReset;
        private System.Windows.Forms.TextBox txtTimerEnabled;
        private System.Windows.Forms.TextBox txtTimerInterval;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.TextBox txtRecordToProcessed;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}