﻿// -----------------------------------------------------------------------
// <copyright file="SyncBatchDataService.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Sync Batch Data Service</summary>
// -----------------------------------------------------------------------

using Enms = Ecolab.Conduit.Library.Enums;

namespace Ecolab.Conduit.SyncBatchData
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.Globalization;
    using System.Linq;
    using System.Net.Sockets;
    using System.ServiceProcess;
    using System.Threading;
    using System.Timers;
    using Access.PlantSetup.ShiftLabor;
    using Conduit.Library.Enums;
    using Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.SyncMessages;
    using Ecolab.Services;
    using Library.Common;
    using Library.Helpers;
    using log4net;
    using Models.Batch;
    using Models.PlantSetup.ShiftLabor;
    using Newtonsoft.Json;
    using Services.Batch;
    using Services.SyncConfigSettingService;
    using Services.SyncQueue;
    using SyncLibrary.Common;
    using SyncLibrary.Enum;
    using ShiftLabor_ProductionShiftData = Entities.PlantSetup.ShiftLabor.ProductionShiftData;

    /// <summary>
    /// The Sync Batch Data Service.
    /// </summary>
    public partial class SyncBatchDataService : ServiceBase
    {
        /// <summary>
        /// Logger Instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("SyncBatchDataService");
        /// <summary>
        /// Batch data configuration
        /// </summary>
        private static Dictionary<string, string> dicBatchDataConfiguration = new Dictionary<string, string>();
        /// <summary>
        /// Plant setting batch
        /// </summary>
        private static PlantSettings plantSettingBatch;
        /// <summary>
        /// Plant Batch Model
        /// </summary>
        private static Plant plantBatch; 
        /// <summary>
        /// Request Delay Time
        /// </summary>
        private static int requestDelayTime = Convert.ToInt32(ConfigurationManager.AppSettings["requestDelayTime"].ToString());
        /// <summary>
        /// Batch Priority
        /// </summary>
        private static bool batchPriority = Convert.ToBoolean(ConfigurationManager.AppSettings["BatchPriority"].ToString());
        /// <summary>
        /// Batch Timer
        /// </summary>
        private System.Timers.Timer batchTimer;
        /// <summary>
        ///     Initializes a new instance of the <see cref="SyncBatchDataService"/> class.
        /// </summary>
        public SyncBatchDataService()
        {
            InitializeComponent();
        }

        /// <summary>
        ///     Process Batch Data
        /// </summary>
        private static void ProcessBatchData()
        {
            try
            {
                PlantService plantService = new PlantService();
                if (plantBatch == null)
                {
                    plantBatch = plantService.GetPlantDetails();
                    if (plantBatch == null)
                    {
                        return;
                    }
                }
                if (plantSettingBatch == null || (plantSettingBatch != null && (plantSettingBatch.NodeId <= 0 || plantSettingBatch.FtrLastModifiedTime == DateTime.MinValue || plantSettingBatch.FtrLastModifiedTime == null)))
                {
                    plantSettingBatch = plantService.GetPlantSettings(plantBatch.EcoalabAccountNumber);
                    if (plantSettingBatch == null)
                    {
                        return;
                    }
                }
                if (plantSettingBatch.NodeId <= 0 || plantSettingBatch.FtrLastModifiedTime == DateTime.MinValue || plantSettingBatch.FtrLastModifiedTime == null)
                {
                    return;
                }
                else
                {
                    List<BatchData> batchData = new List<BatchData>();
                    dicBatchDataConfiguration = GetConfiguration("SyncBatchData");
                    BatchService batchService = new BatchService();
                    int errorCode = 1;
                    int priority = 1;

                    if (batchPriority)
                    {
                        int threeMonthsBatchDataCount = batchService.GetThreeMonthsDataCount();

                        if (threeMonthsBatchDataCount > 0)
                        {
                            batchData.ToList().Clear();
                            batchData = GetBatchDataForFirstThreeMonths();
                            Log.Info("Priority1 three months data is synched");
                        }
                        else
                        {
                            int liveBatchDataCount = batchService.GetLiveBatchDataCount();
                            if (liveBatchDataCount > 0)
                            {
                                batchData.ToList().Clear();
                                batchData = GetLiveBatchData();
                                Log.Info("Priority1 Live data is synched");
                            }
                            else
                            {
                                batchData.ToList().Clear();
                                batchData = GetBatchData();
                                priority = 2;
                                Log.Info("Priority2 Historical data is synched");
                            }
                        }
                    }
                    else
                    {
                        batchData = GetBatchData();
                        priority = 2;
                        Log.Info("Priority2 Historical data is synched");
                    }
                    do
                    {
                        errorCode = PushBatchDataToMSMQ(batchData, priority);
                    }
                    while (errorCode == 0);
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While process batch data :" + socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured while process batch data :" + ex);
            }
        }

        /// <summary>
        /// Push Batch data to msmq
        /// </summary>
        /// <param name="batchData">Batch data object</param>
        /// <param name="priority">Priority</param>
        /// <returns>Error code 0 if fail otherwise</returns>
        private static int PushBatchDataToMSMQ(List<BatchData> batchData, int priority)
        {
            int errorCode = 0;
            using (TcpClient client = new TcpClient())
            {
                try
                {
                        if (batchData.Count > 0)
                        {
                            client.ReceiveTimeout = int.Parse(dicBatchDataConfiguration["ReadTimeout"], CultureInfo.CurrentCulture);
                            client.Connect(dicBatchDataConfiguration["HostName"], int.Parse(dicBatchDataConfiguration["PortNumber"], CultureInfo.CurrentCulture));

                            var requestIds = string.Join(",", batchData.Select(p => p.BatchId.ToString()));

                            string queueLabel = string.Format("{0}_{1}", (int)plantBatch.PlantId, DateTime.UtcNow.ToString("MMddyyyyhhmmssfff"));

                            Log.Info("No of Batch count = " + batchData.Count);
                            //Log.Info("Batch Data Details : " + Environment.NewLine + JsonConvert.SerializeObject(batchData));

                            using (NetworkStream stream = client.GetStream())
                            {
                                //======= transport header =========================================================
                                SendTransportHeader transportHeader = new SendTransportHeader();
                                transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                                transportHeader.Body.ServiceType = Enms.ServiceType.TcdLogRequest;

                                Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + Enms.ServiceType.TcdLogRequest);

                                XMLSerializing xmlserialize = new XMLSerializing();
                                string xmlString = xmlserialize.ConvertToXML(batchData);
                                Log.Info("Batch Data XML : " + Environment.NewLine + xmlString);

                                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(xmlString);
                                byte[] requestBuffer = null;

                                requestBuffer = System.Text.Encoding.UTF8.GetBytes(queueLabel);

                                //============ TcdBatch Request Header =============================================
                                TcdLogRequest batchHeader = new TcdLogRequest { AppVersion = (uint)((int)TcdAppVersion.VersionCurrent), MessageType = TcdMessageTypes.BatchRequest, PayloadSize = (uint)buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack, PlantId = (uint)plantBatch.PlantId, RequestLabelSize = (requestBuffer != null ? (uint)requestBuffer.Length : 0), NumberOfRecords = (uint)batchData.Count, Priority = priority };
                                Log.Info("Message Type = " + TcdMessageTypes.BatchRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                                // ============== Write to stream ==================================================
                                stream.Write(transportHeader);
                                stream.Write(batchHeader);
                                stream.Write(requestBuffer, 0, requestBuffer.Length);
                                stream.Write(buffer, 0, buffer.Length);
                                //======== read the response from tcp server =======================================
                                TcdLogResponse response = stream.ReadAllOf<TcdLogResponse>();
                                Log.Info("Response Details : " + Environment.NewLine + JsonConvert.SerializeObject(response));

                                if (response.ErrorCode == Enms.TcdErrCodes.Success)
                                {
                                    SyncQueueServices objSyncQueueServices = new SyncQueueServices();
                                    objSyncQueueServices.SaveSyncLoggingRequestDetails(requestIds, queueLabel, TcdMessageTypes.BatchRequest.ToString(), batchData.Count, plantBatch.PlantId);
                                    foreach (BatchData batch in batchData)
                                    {
                                        int batchId = batch.BatchId;
                                        objSyncQueueServices.LastSyncUpdate(TableEntityMap.GetTable(typeof(BatchData).FullName), batchId, TableEntityMap.GetColumn(typeof(BatchData).FullName), batchData[0].EcolabAccountNumber, DateTime.UtcNow);
                                    }
                                    errorCode = 1;
                                    Thread.Sleep(requestDelayTime);
                                }
                                else
                                {
                                    Log.Info("Error in batch request send.");
                                    Log.Error(JsonConvert.SerializeObject(response));
                                }
                            }
                    }
                }
                catch (SocketException socEx)
                {
                    Log.Error("Error Received While process batch data :" + socEx);
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured while process batch data :" + ex);
                }
                return errorCode;
            }
        }

        /// <summary>
        ///     Get Batch Data
        /// </summary>
        /// <returns>List of Batch data</returns>
        private static List<BatchData> GetBatchData()
        {
            int NoOfRecordsToBeProcessed = int.Parse(dicBatchDataConfiguration["NoOfRecordsToBeProcessed"], CultureInfo.CurrentCulture);
            BatchService batchService = new BatchService();
            List<BatchData> batchCollection = batchService.GetBatchCollectionDetails(NoOfRecordsToBeProcessed);
            foreach (BatchData batch in batchCollection)
            {
                batch.BatchCustomerList = batchService.GetBatchCustomerData(batch.BatchId);
                batch.BatchProductList = batchService.GetBatchProductData(batch.BatchId);
                batch.BatchWashStepList = batchService.GetBatchWashStepData(batch.BatchId);
                batch.BatchStepWaterUsageList = batchService.GetBatchStepWaterUsageData(batch.BatchId);
                batch.BatchStepEnergyUsageList = batchService.GetBatchStepEnergyUsageData(batch.BatchId);
                batch.BatchParameterDataList = batchService.GetBatchParameterData(batch.BatchId);
            }
            return batchCollection.ToList();
        }

        /// <summary>
        ///     Get Batch Data For First Three Months
        /// </summary>
        /// <returns>List of Batch Data</returns>
        private static List<BatchData> GetBatchDataForFirstThreeMonths()
        {
            int NoOfRecordsToBeProcessed = int.Parse(dicBatchDataConfiguration["NoOfRecordsToBeProcessed"], CultureInfo.CurrentCulture);
            BatchService batchService = new BatchService();
            List<BatchData> batchCollection = batchService.GetBatchCollectionThreeMonths(NoOfRecordsToBeProcessed);
            foreach (BatchData batch in batchCollection)
            {
                batch.BatchCustomerList = batchService.GetBatchCustomerData(batch.BatchId);
                batch.BatchProductList = batchService.GetBatchProductData(batch.BatchId);
                batch.BatchWashStepList = batchService.GetBatchWashStepData(batch.BatchId);
                batch.BatchStepWaterUsageList = batchService.GetBatchStepWaterUsageData(batch.BatchId);
                batch.BatchStepEnergyUsageList = batchService.GetBatchStepEnergyUsageData(batch.BatchId);
                batch.BatchParameterDataList = batchService.GetBatchParameterData(batch.BatchId);
            }
            return batchCollection.ToList();
        }

        /// <summary>
        ///     Get Live Batch Data
        /// </summary>
        /// <returns>List of Batch Data</returns>
        private static List<BatchData> GetLiveBatchData()
        {
            int NoOfRecordsToBeProcessed = int.Parse(dicBatchDataConfiguration["NoOfRecordsToBeProcessed"], CultureInfo.CurrentCulture);
            BatchService batchService = new BatchService();
            List<BatchData> batchCollection = batchService.GetLiveDataBatchCollection(NoOfRecordsToBeProcessed);
            foreach (BatchData batch in batchCollection)
            {
                batch.BatchCustomerList = batchService.GetBatchCustomerData(batch.BatchId);
                batch.BatchProductList = batchService.GetBatchProductData(batch.BatchId);
                batch.BatchWashStepList = batchService.GetBatchWashStepData(batch.BatchId);
                batch.BatchStepWaterUsageList = batchService.GetBatchStepWaterUsageData(batch.BatchId);
                batch.BatchStepEnergyUsageList = batchService.GetBatchStepEnergyUsageData(batch.BatchId);
                batch.BatchParameterDataList = batchService.GetBatchParameterData(batch.BatchId);
            }
            return batchCollection.ToList();
        }

        /// <summary>
        ///     On Start SyncBatchData
        /// </summary>
        /// <param name="args">Command line arguments</param>
        protected override void OnStart(string[] args)
        {
            try
            {
                dicBatchDataConfiguration = GetConfiguration("SyncBatchData");
            }
            catch (Exception ex)
            {
                Log.Error("Error Received While getting configuration setting : " + ex);
                throw ex;
            }

            if (dicBatchDataConfiguration.Count > 0)
            {
                Log.Info(" Get All batch data configuration. ");

                Log.Info(" Host Name = " + dicBatchDataConfiguration["HostName"] + " , Port Number = " + dicBatchDataConfiguration["PortNumber"] + " , Receive Timeout = " + dicBatchDataConfiguration["ReadTimeout"] + " , Timer Enabled = " + dicBatchDataConfiguration["TimerEnabled"] + " , Timer Interval = " + dicBatchDataConfiguration["TimerInterval"] + " , Timer AutoReset = " + dicBatchDataConfiguration["TimerAutoReset"] + " , No of records to be processed = " + dicBatchDataConfiguration["NoOfRecordsToBeProcessed"]);
            }
            else
            {
                Log.Info("Configuration settings missing for SyncBatchDataService.");
                return;
            }

            if (!Debugger.IsAttached)
            {
                batchTimer = new System.Timers.Timer();
                batchTimer.AutoReset = bool.Parse(dicBatchDataConfiguration["TimerAutoReset"]);
                batchTimer.Start();
                batchTimer.Elapsed += RestartProcess;
            }
            else
            {
                ProcessShiftData();
                ProcessBatchData();
            }
        }

        /// <summary>
        /// Restart SyncBatchData process
        /// </summary>
        /// <param name="sender">reference to the object</param>
        /// <param name="e">contains the event data</param>
        private void RestartProcess(object sender, EventArgs e)
        {
            try
            {
                Log.Info("Batch Timer stopped.");
                batchTimer.Stop(); //stop the timer till batch process doesn't complete.
                ProcessShiftData();
                BatchService batchService = new BatchService();
                int batchCount = batchService.GetBatchCount();
                while (batchCount > 0)
                {
                    ProcessBatchData();
                    batchCount = batchService.GetBatchCount();
                }
                Log.Info("All records are synced.");
            }
            catch (Exception ex)
            {
                Log.Error("Error Received While process batch data :" + ex);
            }
            finally
            {
                Log.Info("Batch Timer started.");
                batchTimer.Enabled = bool.Parse(dicBatchDataConfiguration["TimerEnabled"]);
                batchTimer.Interval = double.Parse(dicBatchDataConfiguration["TimerInterval"], CultureInfo.CurrentCulture);
                batchTimer.Start();
            }
        }

        /// <summary>
        ///     Only used to start the service when debugging
        /// </summary>
        internal void Start()
        {
            Log.Info("Service started.");
            OnStart(null);
        }

        /// <summary>
        ///     On Stop SyncBatchData
        /// </summary>
        protected override void OnStop()
        {
            Log.Info("Service stopped.");
            if (!Debugger.IsAttached)
            {
                batchTimer.Stop();
            }
        }

        /// <summary>
        /// Syncs Production shift data
        /// </summary>
        public static void ProcessShiftData()
        {
            try
            {
                TcdAllPlantEntities plantEntities = new TcdAllPlantEntities();
                plantEntities.ProductionShiftDataContainerList = new List<ProductionShiftContainer>();
                List<ShiftLabor_ProductionShiftData> productionShiftData = ShiftAccess.FetchShiftProductionData();
                if (productionShiftData != null && productionShiftData.Count > 0)
                {
                    List<ProductionShiftData> productionShift = AutoMapper.Mapper.Map<List<ShiftLabor_ProductionShiftData>, List<ProductionShiftData>>(productionShiftData);
                    ProductionShiftContainer productionShiftContainer = new ProductionShiftContainer();
                    productionShiftContainer.ProductionShiftData = new List<ProductionShiftData>();
                    productionShiftContainer.ProductionShiftData = productionShift;
                    Log.Info("Production Shift data sync : " + JsonConvert.SerializeObject(productionShiftContainer));
                    productionShiftContainer.ProductionShiftData.ForEach(c => c.StartDate = c.StartDate.ToLocalTime());
                    productionShiftContainer.ProductionShiftData.ForEach(c => c.StartDate = DateTime.SpecifyKind(c.StartDate, DateTimeKind.Utc));
                    productionShiftContainer.ProductionShiftData.ForEach(c => c.EndDate = c.EndDate.ToLocalTime());
                    productionShiftContainer.ProductionShiftData.ForEach(c => c.EndDate = DateTime.SpecifyKind(c.EndDate, DateTimeKind.Utc));
                    Log.Info("Production Shift data sync : " + JsonConvert.SerializeObject(productionShiftContainer));
                    plantEntities.ProductionShiftDataContainerList.Add(productionShiftContainer);
                    Push.PushProductionShiftData(productionShiftData.FirstOrDefault().EcolabAccountNumber, plantEntities);
                }
            }
            catch (System.Exception ex)
            {
                Log.Error("Production Shift data sync failed : " + ex);
            }
        }

        /// <summary>
        ///     Get Sync Configuration settings
        /// </summary>
        /// <param name="serviceName">service name syncbatchdata</param>
        /// <returns>Dictionary object</returns>
        public static Dictionary<string, string> GetConfiguration(string serviceName)
        {
            SyncConfigSettingService syncConfigSettingService = new SyncConfigSettingService();
            return syncConfigSettingService.GetAppConfigKeyValueDetails(serviceName);
        }
    }
}