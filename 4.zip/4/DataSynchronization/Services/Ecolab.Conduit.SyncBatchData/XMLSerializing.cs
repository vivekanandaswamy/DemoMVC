﻿// -----------------------------------------------------------------------
// <copyright file="XMLSerializing.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The XMLSerializing </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncBatchData
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;
    using Ecolab.Models.Batch;
    using test = Ecolab.Conduit.SyncBatchData.XMLSerializerTableFormat;
    /// <summary>
    /// XML Serialize class
    /// </summary>
    public class XMLSerializing
    {
        /// <summary>
        /// Method ConvertTOXML
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns String</returns>
        public string ConvertToXML(List<BatchData> batchData)
        {
            test.Tables tables = new test.Tables();

            List<test.Table> listOfTable = new List<test.Table>();

            test.Table table1 = new test.Table();
            table1 = CreateBatchTable(batchData);
            listOfTable.Add(table1);

            test.Table table2 = new test.Table();
            table2 = CreateCustomerTable(batchData);
            listOfTable.Add(table2);

            test.Table table3 = new test.Table();
            table3 = CreateWashStepTable(batchData);
            listOfTable.Add(table3);

            test.Table table4 = new test.Table();
            table4 = CreateWaterUsageTable(batchData);
            listOfTable.Add(table4);

            test.Table table5 = new test.Table();
            table5 = CreateProductTable(batchData);
            listOfTable.Add(table5);

            test.Table table6 = new test.Table();
            table6 = CreateEnergyUsageTable(batchData);
            listOfTable.Add(table6);

            test.Table table7 = new test.Table();
            table7 = CreateParameterDataTable(batchData);
            listOfTable.Add(table7);

            tables.Table = listOfTable;

            string fileName = Path.GetTempPath() + @"\NewXml.xml";           //To Do
            var serializer = new XmlSerializer(typeof(test.Tables));
            using (var stream = File.Create(fileName))
            {
                serializer.Serialize(stream, tables);
            }
            string fileContents = File.ReadAllText(fileName);

            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }
            return fileContents;
        }

        /// <summary>
        /// Method CreateProductTable
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns Table</returns>
        private test.Table CreateProductTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchProductData]";
            test.Rows rows5 = new test.Rows();
            List<test.Row> ListOfrowsforProductData = new List<test.Row>();
            ListOfrowsforProductData = FormatBatchProductData(batchData);
            rows5.Row = ListOfrowsforProductData;
            table.Rows = rows5;

            return table;
        }

        /// <summary>
        /// Method CreateWaterUsageTable
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns Table</returns>
        private test.Table CreateWaterUsageTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchStepWaterUsageData]";
            test.Rows rows4 = new test.Rows();
            List<test.Row> ListOfrowsforWaterUsageData = new List<test.Row>();
            ListOfrowsforWaterUsageData = FormatBatchWaterUsageData(batchData);
            rows4.Row = ListOfrowsforWaterUsageData;
            table.Rows = rows4;

            return table;
        }

        /// <summary>
        /// Method CreateEnergyUsageTable
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns Table</returns>
        private test.Table CreateEnergyUsageTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchStepEnergyUsageData]";
            test.Rows rows4 = new test.Rows();
            List<test.Row> ListOfrowsforEnergyUsageData = new List<test.Row>();
            ListOfrowsforEnergyUsageData = FormatBatchEnergyUsageData(batchData);
            rows4.Row = ListOfrowsforEnergyUsageData;
            table.Rows = rows4;

            return table;
        }

        /// <summary>
        /// Method CreateParameterDataTable
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns Table</returns>
        private test.Table CreateParameterDataTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchParameterData]";
            test.Rows rows4 = new test.Rows();
            List<test.Row> ListOfrowsforParameterData = new List<test.Row>();
            ListOfrowsforParameterData = FormatBatchParameterData(batchData);
            rows4.Row = ListOfrowsforParameterData;
            table.Rows = rows4;

            return table;
        }

        /// <summary>
        /// Method CreateWashStepTable
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns Table</returns>
        private test.Table CreateWashStepTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchWashStepData]";
            test.Rows rows3 = new test.Rows();
            List<test.Row> ListOfrowsforWashStepData = new List<test.Row>();
            ListOfrowsforWashStepData = FormatBatchWashStepData(batchData);
            rows3.Row = ListOfrowsforWashStepData;
            table.Rows = rows3;

            return table;
        }

        /// <summary>
        /// Method CreateCustomerTable
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns Table</returns>
        private test.Table CreateCustomerTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchCustomerData]";
            test.Rows rows2 = new test.Rows();
            List<test.Row> ListOfrowsforCustomerData = new List<test.Row>();
            ListOfrowsforCustomerData = FormatBatchCustomerData(batchData);
            rows2.Row = ListOfrowsforCustomerData;
            table.Rows = rows2;

            return table;
        }

        /// <summary>
        /// Method CreateBatchTable
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>Returns Table</returns>
        private test.Table CreateBatchTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchData]";
            test.Rows rows = new test.Rows();
            List<test.Row> ListOfrowsforBatchData = new List<test.Row>();
            ListOfrowsforBatchData = FormatBatchData(batchData);
            rows.Row = ListOfrowsforBatchData;
            table.Rows = rows;

            return table;
        }

        /// <summary>
        /// Method FormatBatchProductData
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>List of Rows in Table</returns>
        private List<test.Row> FormatBatchProductData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforProductData = new List<test.Row>();

            foreach (var item in batchData)
            {
                foreach (var prodData in item.BatchProductList)
                {
                    test.Row row = new test.Row();
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in prodData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                          property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(Boolean)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        if (prop.PropertyType.FullName == typeof(DateTime).FullName)
                        {
                            var value = prop.GetValue(prodData, null).ToString();
                            value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                            col.Value = value;
                        }
                        else
                        {
                            var value = Convert.ToString(prop.GetValue(prodData, null),CultureInfo.InvariantCulture);
                            col.Value = value;
                        }

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforProductData.Add(row);
                }
            }

            return ListOfrowsforProductData;
        }

        /// <summary>
        /// Method FormatBatchWaterUsageData
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>List of Rows in Table</returns>
        private List<test.Row> FormatBatchWaterUsageData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforWaterUsageData = new List<test.Row>();

            foreach (var item in batchData)
            {
                foreach (var waterUsageData in item.BatchStepWaterUsageList)
                {
                    test.Row row = new test.Row();
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in waterUsageData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        if (prop.PropertyType.FullName == typeof(DateTime).FullName)
                        {
                            var value = prop.GetValue(waterUsageData, null).ToString();
                            value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                            col.Value = value;
                        }
                        else
                        {
                            var value = Convert.ToString(prop.GetValue(waterUsageData, null), CultureInfo.InvariantCulture);
                            col.Value = value;
                        }

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforWaterUsageData.Add(row);
                }
            }

            return ListOfrowsforWaterUsageData;
        }

        /// <summary>
        /// Method FormatBatchEnergyUsageData
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>List of Rows in Table</returns>
        private List<test.Row> FormatBatchEnergyUsageData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforEnergyUsageData = new List<test.Row>();

            foreach (var item in batchData)
            {
                foreach (var energyUsageData in item.BatchStepEnergyUsageList)
                {
                    test.Row row = new test.Row();
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in energyUsageData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        if (prop.PropertyType.FullName == typeof(DateTime).FullName)
                        {
                            var value = prop.GetValue(energyUsageData, null).ToString();
                            value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                            col.Value = value;
                        }
                        else
                        {
                            var value = Convert.ToString(prop.GetValue(energyUsageData, null), CultureInfo.InvariantCulture);
                            col.Value = value;
                        }

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforEnergyUsageData.Add(row);
                }
            }

            return ListOfrowsforEnergyUsageData;
        }

        /// <summary>
        /// Method FormatBatchParameterData
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>List of rows in Table</returns>
        private List<test.Row> FormatBatchParameterData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforParameterData = new List<test.Row>();

            foreach (var item in batchData)
            {
                foreach (var energyUsageData in item.BatchParameterDataList)
                {
                    test.Row row = new test.Row();
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in energyUsageData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        if (prop.PropertyType.FullName == typeof(DateTime).FullName)
                        {
                            var value = prop.GetValue(energyUsageData, null).ToString();
                            value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                            col.Value = value;
                        }
                        else
                        {
                            var value = Convert.ToString(prop.GetValue(energyUsageData, null), CultureInfo.InvariantCulture);
                            col.Value = value;
                        }

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforParameterData.Add(row);
                }
            }

            return ListOfrowsforParameterData;
        }

        /// <summary>
        /// Method FormatBatchWashStepData
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>List of rows in Table</returns>
        private List<test.Row> FormatBatchWashStepData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforWashStepData = new List<test.Row>();

            foreach (var item in batchData)
            {
                foreach (var washStepData in item.BatchWashStepList)
                {
                    test.Row row = new test.Row();

                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in washStepData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        if (prop.PropertyType.FullName == typeof(DateTime).FullName)
                        {
                            var value = prop.GetValue(washStepData, null).ToString();
                            value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                            col.Value = value;
                        }
                        else
                        {
                            var value = Convert.ToString(prop.GetValue(washStepData, null), CultureInfo.InvariantCulture);
                            col.Value = value;
                        }

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforWashStepData.Add(row);
                }
            }
            return ListOfrowsforWashStepData;
        }

        /// <summary>
        /// Method FormatBatchCustomerData
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>List of rows in Table</returns>
        private List<test.Row> FormatBatchCustomerData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforCustomerData = new List<test.Row>();

            foreach (var item in batchData)
            {
                foreach (var custData in item.BatchCustomerList)
                {
                    test.Row row = new test.Row();
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();
                    var properties = from property in custData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                          property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        if (prop.PropertyType.FullName == typeof(DateTime).FullName)
                        {
                            var value = prop.GetValue(custData, null).ToString();
                            value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                            col.Value = value;
                        }
                        else
                        {
                            var value = Convert.ToString(prop.GetValue(custData, null), CultureInfo.InvariantCulture);
                            col.Value = value;
                        }

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforCustomerData.Add(row);
                }
            }
            return ListOfrowsforCustomerData;
        }

        /// <summary>
        /// Method FormatBatchData
        /// </summary>
        /// <param name="batchData">Batch Data</param>
        /// <returns>List of rows in Table</returns>
        private List<test.Row> FormatBatchData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrows = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();
                test.Columns cols = new test.Columns();
                List<test.Column> listOfColumn = new List<test.Column>();

                var properties = from property in item.GetType().GetProperties()
                                 where property.PropertyType.IsPrimitive ||
                                       property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                 select property;

                foreach (var property in properties)
                {
                    test.Column col = new test.Column();

                    var name = property.Name;

                    if (name == "BatchCustomerList" || name == "EcolabAccountNumber" || name == "Id")
                    {
                        break;
                    }
                    if (name == "EcolabWasherId")
                    {
                        var valueforWasherId = Convert.ToString(property.GetValue(item, null), CultureInfo.InvariantCulture);
                        if (valueforWasherId == null)
                        {
                            break;
                        }
                    }
                    col.Name = name;
					if(property.PropertyType.FullName == typeof(DateTime).FullName)
					{
						var value = property.GetValue(item, null).ToString();
						value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
						col.Value = value;
					}
					else
					{
                        var value = property.GetValue(item);
                        if (value != null)
                        {
                            col.Value = Convert.ToString(value, CultureInfo.InvariantCulture);
                        }
                        else
                        {
                            col.Value = String.Empty;
                        }
                        
					}

                    listOfColumn.Add(col);
                }

                cols.Column = listOfColumn;
                row.Columns = cols;

                ListOfrows.Add(row);
            }
            return ListOfrows;
        }
    }
}