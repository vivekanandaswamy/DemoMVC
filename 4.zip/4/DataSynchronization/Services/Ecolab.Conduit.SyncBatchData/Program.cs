﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Program </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncBatchData
{
    using System.Configuration;
    using System.Diagnostics;
    using System.ServiceProcess;
    using System.Windows.Forms;
    using AutoMapper;
    using Data.Access;
    using log4net.Config;
    using Services.Infra;

    /// <summary>
    /// Main Program class
    /// </summary>
	internal static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        private static void Main()
        {
            if (Debugger.IsAttached)
            {
                using (TestService form = new TestService())
                {
                    XmlConfigurator.Configure();
                    Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
					Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
                    Application.Run(form);
                }
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new SyncBatchDataService() };
                XmlConfigurator.Configure();
                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
				Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}