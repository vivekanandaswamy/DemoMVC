﻿// -----------------------------------------------------------------------
// <copyright file="TestService.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>The TestService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncBatchData
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.Windows.Forms;
    using log4net;

	/// <summary>
	/// The Test Service
	/// </summary>
    public partial class TestService : Form
    {
        /// <summary>
        /// Logger Instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("SyncBatchDataService");
        /// <summary>
        /// Configuration Setting
        /// </summary>
        private static Dictionary<string, string> dicConfiguration = new Dictionary<string, string>();
        /// <summary>
        /// Sync Batch Data Services
        /// </summary>
        private readonly SyncBatchDataService objSyncBatchDataServices = new SyncBatchDataService();

        /// <summary>
        /// Initializes a new instance of the <see cref="TestService"/> class.
        /// </summary>
        public TestService()
        {
            InitializeComponent();
            Trace.Listeners.Add(new DebugFormTraceListener(LogOutput));
        }

        /// <summary>
        /// On Start services method
        /// </summary>
        /// <param name="sender">reference to the object</param>
        /// <param name="e">contains the event data</param>
        private void BtnStartServices_Click(object sender, EventArgs e)
        {
            objSyncBatchDataServices.Start();
            lblBatch.Text = "Service Running.";
            lblBatch.ForeColor = Color.Green;
        }

        /// <summary>
        /// On stop services method
        /// </summary>
        /// <param name="sender">reference to the object</param>
        /// <param name="e">contains the event data</param>
        private void BtnStopServices_Click(object sender, EventArgs e)
        {
            if (objSyncBatchDataServices.CanStop)
            {
                objSyncBatchDataServices.Stop();
                lblBatch.ForeColor = Color.Red;
                lblBatch.Text = "Service Stopped.";
            }
        }

        /// <summary>
        /// Method BtnClear_Click
        /// </summary>
        /// <param name="sender">reference to the object</param>
        /// <param name="e">contains the event data</param>
        private void BtnClear_Click(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
        }

        /// <summary>
        /// On Service Load
        /// </summary>
        /// <param name="sender">reference to the object</param>
        /// <param name="e">contains the event data</param>
        private void TestService_Load(object sender, EventArgs e)
        {
            //TO DO :: Need to check why log4net throwing security permission error at load.
            // which get cleaned by below line. once fixed, below line need to be removed.
            LogOutput.Text = string.Empty;
            lblError.Text = string.Empty;
            try
            {
                dicConfiguration = SyncBatchDataService.GetConfiguration("SyncBatchData");
                if (dicConfiguration != null && dicConfiguration.Count > 6)
                {
                    txtServer.Text = dicConfiguration["HostName"];
                    txtPort.Text = dicConfiguration["PortNumber"];
                    txtTimeOut.Text = dicConfiguration["ReadTimeout"];
                    txtAutoReset.Text = dicConfiguration["TimerAutoReset"];
                    txtTimerEnabled.Text = dicConfiguration["TimerEnabled"];
                    txtTimerInterval.Text = dicConfiguration["TimerInterval"];
                    txtRecordToProcessed.Text = dicConfiguration["NoOfRecordsToBeProcessed"];
                }
                else
                {
                    lblError.Text = "Configuration setting is missing.";
                    Log.Error("Configuration setting is missing.");
                }
            }
            catch (Exception ex)
            {
                Log.Info("Configuration setting is missing.");
                Log.Error("Error : " + ex.Message);
            }
        }
    }

    /// <summary>
    /// Class DebugFormTraceListener
    /// </summary>
    internal class DebugFormTraceListener : TraceListener
    {
        /// <summary>
        /// LogTextBox
        /// </summary>
        private readonly TextBox LogTextBox;

        /// <summary>
        /// Initializes a new instance of the <see cref="DebugFormTraceListener"/> class.
        /// </summary>
        /// <param name="logTextBox">logTextBox</param>
        public DebugFormTraceListener(TextBox logTextBox)
        {
            LogTextBox = logTextBox;
        }

        /// <summary>
        /// Method Write
        /// </summary>
        /// <param name="message">message</param>
        public override void Write(string message)
        {
            if (LogTextBox.InvokeRequired)
            {
                LogTextBox.Invoke((MethodInvoker) delegate { Write(message); });
                return;
            }

            LogTextBox.AppendText(message);
        }

        /// <summary>
        /// Method WriteLine
        /// </summary>
        /// <param name="message">message</param>
        public override void WriteLine(string message)
        {
            Write(message);
            Write(Environment.NewLine);
        }
    }
}