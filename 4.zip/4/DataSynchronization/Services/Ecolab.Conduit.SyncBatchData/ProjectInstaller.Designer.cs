﻿// -----------------------------------------------------------------------
// <copyright file="ProjectInstaller.Designer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProjectInstaller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncBatchData
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.syncBatchDataProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.syncBatchDataInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // syncBatchDataProcessInstaller
            // 
            this.syncBatchDataProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalService;
            this.syncBatchDataProcessInstaller.Password = null;
            this.syncBatchDataProcessInstaller.Username = null;
            this.syncBatchDataProcessInstaller.AfterInstall += new System.Configuration.Install.InstallEventHandler(this.SyncBatchDataProcessInstaller_AfterInstall);
            // 
            // syncBatchDataInstaller
            // 
            this.syncBatchDataInstaller.Description = "This service will pick batch data and send to TCP.";
            this.syncBatchDataInstaller.ServiceName = "Ecolab Sync Batch Data Service";
            this.syncBatchDataInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.syncBatchDataProcessInstaller,
            this.syncBatchDataInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller syncBatchDataProcessInstaller;
        private System.ServiceProcess.ServiceInstaller syncBatchDataInstaller;
    }
}