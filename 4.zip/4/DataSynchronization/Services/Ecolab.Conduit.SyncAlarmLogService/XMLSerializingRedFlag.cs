﻿// -----------------------------------------------------------------------
// <copyright file="XMLSerializingRedFlag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The XMLSerializingRedFlag </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using test = Ecolab.Conduit.SyncAlarmLogService.XMLSerializerTableFormat;

namespace Ecolab.Conduit.SyncAlarmLogService
{
    public class XMLSerializingRedFlag
    {
        public string ConvertToXML(List<Models.PlantSetup.RedFlag.RedFlagData> redFlagData)
        {
            test.Data data = new XMLSerializerTableFormat.Data();
            data.Tables = new test.Tables();

            List<test.Table> listOfTable = new List<test.Table>();

            test.Table table1 = new test.Table();
            table1 = CreateRedFlagDataTable(redFlagData);
            listOfTable.Add(table1);

            data.Tables.Table = listOfTable;

            string fileName = Path.GetTempPath() + @"\RedFlagDataXML.XML";
            var serializer = new XmlSerializer(typeof(test.Data));
            using (var stream = File.Create(fileName))
            {
                serializer.Serialize(stream, data);
            }
            string fileContents = File.ReadAllText(fileName);
            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }

            return fileContents;
        }

        private test.Table CreateRedFlagDataTable(List<Models.PlantSetup.RedFlag.RedFlagData> redFlagData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[RedFlagData]";
            test.Rows rows = new test.Rows();
            List<test.Row> ListOfrowsforRedFlagData = new List<test.Row>();
            ListOfrowsforRedFlagData = FormatRedFlagData(redFlagData);
            rows.Row = ListOfrowsforRedFlagData;
            table.Rows = rows;

            return table;
        }

        private List<test.Row> FormatRedFlagData(List<Models.PlantSetup.RedFlag.RedFlagData> redFlagData)
        {
            List<test.Row> ListOfrows = new List<test.Row>();

            foreach (var item in redFlagData)
            {
                test.Row row = new test.Row();
                test.Columns cols = new test.Columns();
                List<test.Column> listOfColumn = new List<test.Column>();

                var properties = from property in item.GetType().GetProperties()
                                 where property.PropertyType.IsPrimitive ||
                                      property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(decimal)
                                 select property;

                foreach (var property in properties)
                {
                    test.Column col = new test.Column();

                    var name = property.Name;
                    
                    col.Name = name;
                    if (property.PropertyType.FullName == typeof(DateTime).FullName)
                    {
                        var value = property.GetValue(item, null).ToString();
                        value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                        col.Value = value;
                    }
                    else
                    {
                        var value = Convert.ToString(property.GetValue(item, null), System.Globalization.CultureInfo.InvariantCulture);
                        col.Value = value;
                    }

                    listOfColumn.Add(col);
                }

                cols.Column = listOfColumn;
                row.Columns = cols;

                ListOfrows.Add(row);
            }

            return ListOfrows;
        }
    }
}
