﻿// -----------------------------------------------------------------------
// <copyright file="XMLSerializerTableFormat.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The XMLSerializerTableFormat </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Ecolab.Conduit.SyncAlarmLogService
{
    public class XMLSerializerTableFormat
    {
        [XmlRoot("Data")]
        public class Data
        {
            [XmlElement("Tables")]
            public Tables Tables { get; set; }

        }

        [XmlRoot("Tables")]
        public class AlarmTables 
        { 
            [XmlElement("Table")]
            public List<AlarmTable> Table { get; set; }
  
        }

        [XmlRoot("Tables")]
        public class Tables
        {
            [XmlElement("Table")]
            public List<Table> Table { get; set; }

        }

        [XmlRoot("Table")]
        public class Table
        {

            [XmlAttribute("name")]
            public string TableName { get; set; }

            [XmlElement("Rows")]
            public Rows Rows { get; set; }
        }

        [XmlRoot("Table")]
        public class AlarmTable
        {

            [XmlAttribute("Name")]
            public string TableName { get; set; }

            [XmlElement("Rows")]
            public Rows Rows { get; set; }
        }

        [XmlRoot("Rows")]
        public class Rows
        {
            [XmlElement("Row")]
            public List<Row> Row { get; set; }
        }

        [XmlRoot("Row")]
        public class Row
        {
            [XmlElement("Columns")]
            public Columns Columns { get; set; }

        }

        [XmlRoot("Columns")]
        public class Columns
        {
            [XmlElement("Column")]
            public List<Column> Column { get; set; }
        }

        public class Column
        {
            [XmlAttribute("name")]
            public string Name { get; set; }

            [XmlText]
            public string Value { get; set; }
        }
    }
}
