﻿// -----------------------------------------------------------------------
// <copyright file="XMLSerializing.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The XMLSerializing </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using test = Ecolab.Conduit.SyncAlarmLogService.XMLSerializerTableFormat;

namespace Ecolab.Conduit.SyncAlarmLogService
{
    public class XMLSerializing
    {
        public string ConvertToXML(List<Models.Alarm> alarmLogData)
        {
            test.AlarmTables tables = new test.AlarmTables();

            List<test.AlarmTable> listOfTable = new List<test.AlarmTable>();

            test.AlarmTable table1 = new test.AlarmTable();
            table1 = CreateAlarmDataTable(alarmLogData);
            listOfTable.Add(table1);

            tables.Table = listOfTable;

            string fileName = Path.GetTempPath() + @"\AlarmXML.XML";
            var serializer = new XmlSerializer(typeof(test.AlarmTables));
            using (var stream = File.Create(fileName))
            {
                serializer.Serialize(stream, tables);
            }
            string fileContents = File.ReadAllText(fileName);
            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }

            return fileContents;
        }

        private test.AlarmTable CreateAlarmDataTable(List<Models.Alarm> alarmLogData)
        {
            test.AlarmTable table = new test.AlarmTable();

            table.TableName = "[TCD].[AlarmData]";
            test.Rows rows = new test.Rows();
            List<test.Row> ListOfrowsforAlarmData = new List<test.Row>();
            ListOfrowsforAlarmData = FormatAlarmData(alarmLogData);
            rows.Row = ListOfrowsforAlarmData;
            table.Rows = rows;

            return table;
        }

        private List<test.Row> FormatAlarmData(List<Models.Alarm> alarmLogData)
        {
            List<test.Row> ListOfrows = new List<test.Row>();

            foreach (var item in alarmLogData)
            {
                test.Row row = new test.Row();
                test.Columns cols = new test.Columns();
                List<test.Column> listOfColumn = new List<test.Column>();

                var properties = from property in item.GetType().GetProperties()
                                 where property.PropertyType.IsPrimitive ||
                                      property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(Boolean)
                                 select property;

                foreach (var property in properties)
                {
                    test.Column col = new test.Column();

                    var name = property.Name;
                    if (name == "EcolabAccountNumber")
					{
						break;
					}
                    if (name == "MachineName" || name == "AlarmDescription" || name == "StartDateFormatted")
                    {
                        continue;
                    }
                    col.Name = name;
                    if (property.PropertyType.FullName == typeof(DateTime).FullName)
                    {
                        var value = property.GetValue(item, null).ToString();
                        value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                        col.Value = value;
                    }
                    else
                    {
                        var value = Convert.ToString(property.GetValue(item, null), System.Globalization.CultureInfo.InvariantCulture);
                        col.Value = value;
                    }

                    listOfColumn.Add(col);
                }

                cols.Column = listOfColumn;
                row.Columns = cols;

                ListOfrows.Add(row);
            }

            return ListOfrows;
        }
    }
}
