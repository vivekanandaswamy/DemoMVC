﻿// -----------------------------------------------------------------------
// <copyright file="TestService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TestService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncAlarmLogService
{
    using System;
    using System.Diagnostics;
    using System.Drawing;
    using System.Windows.Forms;
    using log4net;

	/// <summary>
	/// The test Service
	/// </summary>
    public partial class TestService : Form
    {
        private readonly SyncAlarmLogService syncAlarmLogService = new SyncAlarmLogService();

        public TestService()
        {
            InitializeComponent();
            Trace.Listeners.Add(new DebugFormTraceListener(LogOutput));
        }

        private void btnStartServices_Click(object sender, EventArgs e)
        {
            syncAlarmLogService.Start();
            lblStatus.Text = "Service Running.";
            lblStatus.ForeColor = Color.Green;
        }

        private void btnStopServices_Click(object sender, EventArgs e)
        {
            if (syncAlarmLogService.CanStop)
            {
                syncAlarmLogService.Stop();
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Service Stopped.";
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
        }

        private void TestService_Load(object sender, EventArgs e)
        {
            //TO DO :: Need to check why log4net throwing security permission error at load.
            // which get cleaned by below line. once fixed, below line need to be removed.
            LogOutput.Text = string.Empty;
        }
    }

    internal class DebugFormTraceListener : TraceListener
    {
        private readonly TextBox LogTextBox;

        public DebugFormTraceListener(TextBox logTextBox)
        {
            LogTextBox = logTextBox;
        }

        public override void Write(string message)
        {
            if (LogTextBox.InvokeRequired)
            {
                LogTextBox.Invoke((MethodInvoker) delegate { Write(message); });
                return;
            }

            LogTextBox.AppendText(message);
        }

        public override void WriteLine(string message)
        {
            Write(message);
            Write(Environment.NewLine);
        }
    }
}