﻿// -----------------------------------------------------------------------
// <copyright file="XMLSerializingModuleRead.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The XML Serializing Module Read </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using test = Ecolab.Conduit.SyncAlarmLogService.XMLSerializerTableFormat;

namespace Ecolab.Conduit.SyncAlarmLogService
{
    /// <summary>
    /// Class for XML Serializing Module Read
    /// </summary>
    public class XMLSerializingModuleRead
    {
        /// <summary>
        /// Converts to XML.
        /// </summary>
        /// <param name="moduleReadData">The module read data.</param>
        /// <returns>Returns xml string</returns>
        public string ConvertToXML(List<Models.PlantSetup.ModuleRead.ModuleReadData> moduleReadData)
        {
            test.Data data = new XMLSerializerTableFormat.Data();
            data.Tables = new test.Tables();

            List<test.Table> listOfTable = new List<test.Table>();

            test.Table table1 = new test.Table();
            table1 = CreateModuleReadDataTable(moduleReadData);
            listOfTable.Add(table1);

            data.Tables.Table = listOfTable;

            string fileName = Path.GetTempPath() + @"\RedFlagDataXML.XML";
            var serializer = new XmlSerializer(typeof(test.Data));
            using (var stream = File.Create(fileName))
            {
                serializer.Serialize(stream, data);
            }
            string fileContents = File.ReadAllText(fileName);
            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }

            return fileContents;
        }

        /// <summary>
        /// Creates the module read data table.
        /// </summary>
        /// <param name="moduleReadData">The module read data.</param>
        /// <returns>Returns table data</returns>
        private test.Table CreateModuleReadDataTable(List<Models.PlantSetup.ModuleRead.ModuleReadData> moduleReadData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[ModuleReading]";
            test.Rows rows = new test.Rows();
            List<test.Row> ListOfrowsforMeterReadData = new List<test.Row>();
            ListOfrowsforMeterReadData = FormatMeterReadData(moduleReadData);
            rows.Row = ListOfrowsforMeterReadData;
            table.Rows = rows;

            return table;
        }

        /// <summary>
        /// Formats the meter read data.
        /// </summary>
        /// <param name="modduleReadData">The moddule read data.</param>
        /// <returns>Returns list of rows</returns>
        private List<test.Row> FormatMeterReadData(List<Models.PlantSetup.ModuleRead.ModuleReadData> modduleReadData)
        {
            List<test.Row> ListOfrows = new List<test.Row>();

            foreach (var item in modduleReadData)
            {
                test.Row row = new test.Row();
                test.Columns cols = new test.Columns();
                List<test.Column> listOfColumn = new List<test.Column>();

                var properties = from property in item.GetType().GetProperties()
                                 where property.PropertyType.IsPrimitive ||
                                      property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(decimal)
                                 select property;

                foreach (var property in properties)
                {
                    test.Column col = new test.Column();

                    var name = property.Name;

                    col.Name = name;
                    if (property.PropertyType.FullName == typeof(DateTime).FullName)
                    {
                        var value = property.GetValue(item, null).ToString();
                        value = DateTime.Parse(value).ToString("yyyy-MM-dd HH:mm:ss");
                        col.Value = value;
                    }
                    else
                    {
                        var value = Convert.ToString(property.GetValue(item, null), System.Globalization.CultureInfo.InvariantCulture);
                        col.Value = value;
                    }

                    listOfColumn.Add(col);
                }

                cols.Column = listOfColumn;
                row.Columns = cols;

                ListOfrows.Add(row);
            }

            return ListOfrows;
        }
    }
}
