﻿// -----------------------------------------------------------------------
// <copyright file="TestService.Designer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TestService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncAlarmLogService
{
    partial class TestService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LogOutput = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnStopServices = new System.Windows.Forms.Button();
            this.btnStartServices = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.LogOutput);
            this.groupBox2.Controls.Add(this.lblStatus);
            this.groupBox2.Controls.Add(this.btnClear);
            this.groupBox2.Controls.Add(this.btnStopServices);
            this.groupBox2.Controls.Add(this.btnStartServices);
            this.groupBox2.Location = new System.Drawing.Point(12, 8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(588, 487);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sync Alarm Log Service";
            // 
            // LogOutput
            // 
            this.LogOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogOutput.Location = new System.Drawing.Point(9, 52);
            this.LogOutput.Multiline = true;
            this.LogOutput.Name = "LogOutput";
            this.LogOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LogOutput.Size = new System.Drawing.Size(573, 429);
            this.LogOutput.TabIndex = 11;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(487, 27);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(11, 13);
            this.lblStatus.TabIndex = 12;
            this.lblStatus.Text = ".";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(335, 19);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(142, 27);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnStopServices
            // 
            this.btnStopServices.Location = new System.Drawing.Point(162, 19);
            this.btnStopServices.Name = "btnStopServices";
            this.btnStopServices.Size = new System.Drawing.Size(149, 27);
            this.btnStopServices.TabIndex = 9;
            this.btnStopServices.Text = "Stop Alarm Log Services";
            this.btnStopServices.UseVisualStyleBackColor = true;
            this.btnStopServices.Click += new System.EventHandler(this.btnStopServices_Click);
            // 
            // btnStartServices
            // 
            this.btnStartServices.Location = new System.Drawing.Point(9, 19);
            this.btnStartServices.Name = "btnStartServices";
            this.btnStartServices.Size = new System.Drawing.Size(147, 27);
            this.btnStartServices.TabIndex = 8;
            this.btnStartServices.Text = "Start Alarm Log Service";
            this.btnStartServices.UseVisualStyleBackColor = true;
            this.btnStartServices.Click += new System.EventHandler(this.btnStartServices_Click);
            // 
            // TestService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 502);
            this.Controls.Add(this.groupBox2);
            this.Name = "TestService";
            this.Text = "Sync Alarm Log Service Test";
            this.Load += new System.EventHandler(this.TestService_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox LogOutput;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnStopServices;
        private System.Windows.Forms.Button btnStartServices;
    }
}