﻿// -----------------------------------------------------------------------
// <copyright file="ProjectInstaller.Designer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Project Installer </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncAlarmLogService
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.syncAlarmLogProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.syncAlarmLogInstaller = new System.ServiceProcess.ServiceInstaller();
            
            // syncAlarmLogProcessInstaller
            this.syncAlarmLogProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalService;
            this.syncAlarmLogProcessInstaller.Password = null;
            this.syncAlarmLogProcessInstaller.Username = null;

            // syncAlarmLogInstaller
            this.syncAlarmLogInstaller.Description = "This service will pick alarm log data and send to TCP.";
            this.syncAlarmLogInstaller.ServiceName = "Ecolab Sync Alarm Log Service";
            this.syncAlarmLogInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;

            // ProjectInstaller
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.syncAlarmLogProcessInstaller,
            this.syncAlarmLogInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller syncAlarmLogProcessInstaller;
        private System.ServiceProcess.ServiceInstaller syncAlarmLogInstaller;
    }
}