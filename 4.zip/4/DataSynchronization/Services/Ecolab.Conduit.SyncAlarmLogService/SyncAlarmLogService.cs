﻿// -----------------------------------------------------------------------
// <copyright file="SyncAlarmLogService.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Sync Alarm Log Service </summary>
// -----------------------------------------------------------------------

using Enum = Ecolab.Conduit.Library.Enums;

namespace Ecolab.Conduit.SyncAlarmLogService
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.Linq;
    using System.Net.Sockets;
    using System.ServiceProcess;
    using System.Threading;
    using System.Timers;
    using AutoMapper;
    using Ecolab.Models.SyncMessages;
    using Enum;
    using Library.Common;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.PlantSetup.ModuleRead;
    using Models.PlantSetup.RedFlag;
    using Newtonsoft.Json;
    using Services;
    using Services.Infra;
    using Services.PlantSetup;
    using Services.SyncConfigSettingService;
    using Services.SyncQueue;
    using SyncLibrary.Common;
    using SyncLibrary.Enum;
    using ServiceType = Enum.ServiceType;

    /// <summary>
    /// The Sync Alarm Log Service
    /// </summary>
    public partial class SyncAlarmLogService : ServiceBase
    {
        private static Dictionary<string, string> dicAlarmLogConfiguration = new Dictionary<string, string>();
        private static readonly ILog Log = LogManager.GetLogger("SyncAlarmLogService");
        private System.Timers.Timer alarmTimer;
        private static PlantSettings plantSettingAlarm;
        private static Plant plantAlarm;

        private static int requestDelayTime = Convert.ToInt32(ConfigurationManager.AppSettings["requestDelayTime"].ToString());

        /// <summary>
        ///     Sync Alarm Log Service
        /// </summary>
        public SyncAlarmLogService()
        {
            InitializeComponent();
        }

        /// <summary>
        /// On Start Sync Alarm Log Services
        /// </summary>
        /// <param name="args">The arguments.</param>
        protected override void OnStart(string[] args)
        {
            dicAlarmLogConfiguration = GetAlarmLogConfiguration("SyncAlarmLog");
            Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));

            if (dicAlarmLogConfiguration.Count >= 7)
            {
                Log.Info(" Alarm Log Service : Get All sync Alarm configuration. ");

                Log.Info(" Host Name = " + dicAlarmLogConfiguration["HostName"] + " , Port Number = " + dicAlarmLogConfiguration["PortNumber"] + " , Receive Timeout = " + dicAlarmLogConfiguration["ReceiveTimeout"] + " , Timer Enabled = " + dicAlarmLogConfiguration["TimerEnabled"] + " , Timer Interval = " + dicAlarmLogConfiguration["TimerInterval"] + " , Timer AutoReset = " + dicAlarmLogConfiguration["TimerAutoReset"] + " , No of records to be processed = " + dicAlarmLogConfiguration["NoOfRecordsToBeProcessed"]);
            }
            else
            {
                Log.Info("Configuration settings missing for Alarm Log services.");
                return;
            }

            if (!Debugger.IsAttached)
            {
                alarmTimer = new System.Timers.Timer();
                alarmTimer.AutoReset = bool.Parse(dicAlarmLogConfiguration["TimerAutoReset"]);

                alarmTimer.Start();
                alarmTimer.Elapsed += RestartProcess;
            }
            else
            {

                ProcessAlarmLog();
                ProcessRedFlagData();
                ProcessModuleReadingData();
            }
        }

        /// <summary>
        /// Restarts the process.
        /// </summary>
        /// <param name="sender">The sender for Sync Alarm Log Services.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void RestartProcess(object sender, EventArgs e)
        {
            try
            {
                Log.Info("Alarm Timer stopped.");
                alarmTimer.Stop(); //stop the timer till Alarm process doesn't complete.

                AlarmService alarmService = new AlarmService();
                int alarmCount = alarmService.GetAlarmCount();
                while (alarmCount > 0)
                {
                    ProcessAlarmLog();
                    alarmCount = alarmService.GetAlarmCount();
                }
                Log.Info("All records are synced for Alarms.");

                RedFlagService redFlagService = new RedFlagService();
                int redFlagCount = redFlagService.GetRedFlagDataCount();
                while (redFlagCount > 0)
                {
                    ProcessRedFlagData();
                    redFlagCount = redFlagService.GetRedFlagDataCount();
                }
                Log.Info("All records are synced for Redflag.");

                MeterService meterService = new MeterService();
                int meterCount = meterService.GetMeterDataCount();
                while (meterCount > 0)
                {
                    ProcessModuleReadingData();
                    meterCount = meterService.GetMeterDataCount();
                }
                Log.Info("All records are synced for Module Readings.");
            }
            catch (Exception ex)
            {
                Log.Error("Error Received While process sync of Alarm or Redflag :" + ex);
            }
            finally
            {
                Log.Info("Alarm Timer started.");
                alarmTimer.Enabled = bool.Parse(dicAlarmLogConfiguration["TimerEnabled"]);
                alarmTimer.Interval = double.Parse(dicAlarmLogConfiguration["TimerInterval"]);
                alarmTimer.Start(); // start the time. It will take Interval time to fire next time.
            }
        }

        /// <summary>
        ///     Only used to start the service when debugging
        /// </summary>
        internal void Start()
        {
            Log.Info("Service started.");
            OnStart(null);
        }

        /// <summary>
        /// On Stop for Sync Alarm Log Services
        /// </summary>
        protected override void OnStop()
        {
            Log.Info("Service stopped.");
            if (!Debugger.IsAttached)
            {
                alarmTimer.Stop();
            }
        }

        /// <summary>
        /// Process Alarm Log
        /// </summary>
        private static void ProcessAlarmLog()
        {
            try
            {
                PlantService plantService = new PlantService();
                if (plantAlarm == null)
                {
                    plantAlarm = plantService.GetPlantDetails();
                    if (plantAlarm == null)
                    {
                        return;
                    }
                }
                if (plantSettingAlarm == null || (plantSettingAlarm != null && (plantSettingAlarm.NodeId <= 0 || plantSettingAlarm.FtrLastModifiedTime == DateTime.MinValue || plantSettingAlarm.FtrLastModifiedTime == null)))
                {
                    plantSettingAlarm = plantService.GetPlantSettings(plantAlarm.EcoalabAccountNumber);
                    if (plantSettingAlarm == null)
                    {
                        return;
                    }
                }
                if (plantSettingAlarm.NodeId <= 0 || plantSettingAlarm.FtrLastModifiedTime == DateTime.MinValue || plantSettingAlarm.FtrLastModifiedTime == null)
                {
                    return;
                }
                else
                {
                    List<Alarm> alarmLogData = GetAlarmLogData();
                    dicAlarmLogConfiguration = GetAlarmLogConfiguration("SyncAlarmLog");
                    int errorCode = 1;
                    do
                    {
                        errorCode = PushAlarmDataToMSMQ(alarmLogData);
                    }
                    while (errorCode == 0);
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While process alarm log data :" + socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured while process alarm log data :" + ex);
            }
        }

        /// <summary>
        /// Push Alarm data to msmq
        /// </summary>
        /// <param name="alarmLogData">Alarm data List</param>
        /// <returns>Error code 0 if fail otherwise</returns>
        private static int PushAlarmDataToMSMQ(List<Alarm> alarmLogData)
        {
            int errorCode = 0;
            using (TcpClient client = new TcpClient())
                try
                {
                    {
                        if (alarmLogData.Count > 0)
                        {
                            client.ReceiveTimeout = int.Parse(dicAlarmLogConfiguration["ReceiveTimeout"]);
                            client.Connect(dicAlarmLogConfiguration["HostName"], int.Parse(dicAlarmLogConfiguration["PortNumber"]));

                            DateTime lastSyncTime = DateTime.UtcNow;
                            foreach (Alarm alarmData in alarmLogData)
                            {
                                alarmData.LastSyncTime = lastSyncTime;
                            }

                            var requestIds = string.Join(",", alarmLogData.Select(p => p.Id.ToString()));

                            string queueLabel = string.Format("{0}_{1}", (int)plantAlarm.PlantId, DateTime.UtcNow.ToString("MMddyyyyhhmmssfff"));

                            Log.Info("No of Alarm Log records = " + alarmLogData.Count);
                            //Log.Info("Alarm Log Data Details : " + Environment.NewLine + JsonConvert.SerializeObject(alarmLogData));

                            using (NetworkStream stream = client.GetStream())
                            {
                                //======= transport header =========================================================
                                SendTransportHeader tHeader = new SendTransportHeader();
                                tHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                                tHeader.Body.ServiceType = ServiceType.TcdLogRequest;

                                Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogRequest);

                                XMLSerializing xmlserialize = new XMLSerializing();
                                string xmlString = xmlserialize.ConvertToXML(alarmLogData);
                                Log.Info("Alarm Data XML : " + Environment.NewLine + xmlString);

                                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(xmlString);

                                byte[] requestBuffer = null;
                                //byte[] requestBuffer = System.Text.Encoding.UTF8.GetBytes(queueLabel);

                                requestBuffer = System.Text.Encoding.UTF8.GetBytes(queueLabel);

                                //============ Alarm Request Header =============================================
                                TcdLogRequest alarmHeader = new TcdLogRequest { AppVersion = (uint)((int)TcdAppVersion.VersionCurrent), MessageType = TcdMessageTypes.AlarmRequest, PayloadSize = (uint)buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack, PlantId = (uint)plantAlarm.PlantId, RequestLabelSize = (requestBuffer != null ? (uint)requestBuffer.Length : 0), NumberOfRecords = (uint)alarmLogData.Count };
                                Log.Info("Message Type = " + TcdMessageTypes.AlarmRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                                // ============== Write to stream ==================================================
                                stream.Write(tHeader);
                                stream.Write(alarmHeader);
                                stream.Write(requestBuffer, 0, requestBuffer.Length);
                                stream.Write(buffer, 0, buffer.Length);

                                //======== read the response from tcp server =======================================
                                TcdLogResponse response = stream.ReadAllOf<TcdLogResponse>();
                                Log.Info("Response Details : " + Environment.NewLine + JsonConvert.SerializeObject(response));

                                if (response.ErrorCode == TcdErrCodes.Success)
                                {
                                    SyncQueueServices objSyncQueueServices = new SyncQueueServices();
                                    objSyncQueueServices.SaveSyncLoggingRequestDetails(requestIds, queueLabel, TcdMessageTypes.AlarmRequest.ToString(), alarmLogData.Count, plantAlarm.PlantId);
                                    Log.Info("Alarm Request send to message queue.");
                                    foreach (Alarm alarm in alarmLogData)
                                    {
                                        int alarmId = alarm.Id;
                                        objSyncQueueServices.LastSyncUpdate(TableEntityMap.GetTable(typeof(Alarm).FullName), alarmId, TableEntityMap.GetColumn(typeof(Alarm).FullName), plantAlarm.EcoalabAccountNumber, lastSyncTime);
                                        Log.Info("Last Sync time Updated for alarm Id = " + alarmId);
                                    }
                                    errorCode = 1;
                                    Thread.Sleep(requestDelayTime);
                                }
                                else
                                {
                                    Log.Info("Error in alarm request send.");
                                    Log.Error(JsonConvert.SerializeObject(response));
                                }
                            }

                        }
                    }
                }
                catch (SocketException socEx)
                {
                    Log.Error("Error Received While process alarm data :" + socEx);
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured while process alarm data :" + ex);
                }

            return errorCode;
        }

        /// <summary>
        /// Processes the red flag data.
        /// </summary>
        private static void ProcessRedFlagData()
        {
            try
            {
                PlantService plantService = new PlantService();
                if (plantAlarm == null)
                {
                    plantAlarm = plantService.GetPlantDetails();
                    if (plantAlarm == null)
                    {
                        return;
                    }
                }
                if (plantSettingAlarm == null || (plantSettingAlarm != null && (plantSettingAlarm.NodeId <= 0 || plantSettingAlarm.FtrLastModifiedTime == DateTime.MinValue || plantSettingAlarm.FtrLastModifiedTime == null)))
                {
                    plantSettingAlarm = plantService.GetPlantSettings(plantAlarm.EcoalabAccountNumber);
                    if (plantSettingAlarm == null)
                    {
                        return;
                    }
                }
                if (plantSettingAlarm.NodeId <= 0 || plantSettingAlarm.FtrLastModifiedTime == DateTime.MinValue || plantSettingAlarm.FtrLastModifiedTime == null)
                {
                    return;
                }
                else
                {
                    List<RedFlagData> redFlagData = GetRedFlagData();
                    dicAlarmLogConfiguration = GetAlarmLogConfiguration("SyncAlarmLog");
                    int errorCode = 1;
                    do
                    {
                        errorCode = PushRedFlagDataToMSMQ(redFlagData);
                    }
                    while (errorCode == 0);
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While process redflag data :" + socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured while process redflag data :" + ex);
            }
        }

        /// <summary>
        /// Push RedFlag data to msmq
        /// </summary>
        /// <param name="redFlagData">RedFlag data object</param>
        /// <returns>Error code 0 if fail otherwise</returns>
        private static int PushRedFlagDataToMSMQ(List<RedFlagData> redFlagData)
        {
            int errorCode = 0;
            using (TcpClient client = new TcpClient())
                try
                {
                    {
                        if (redFlagData.Count > 0)
                        {
                            client.ReceiveTimeout = int.Parse(dicAlarmLogConfiguration["ReceiveTimeout"]);
                            client.Connect(dicAlarmLogConfiguration["HostName"], int.Parse(dicAlarmLogConfiguration["PortNumber"]));

                            DateTime lastSyncTime = DateTime.UtcNow;

                            foreach (RedFlagData redData in redFlagData)
                            {
                                redData.LastSyncTime = lastSyncTime;
                            }

                            var requestIds = string.Join(",", redFlagData.Select(p => p.RedFlagId.ToString()));

                            string queueLabel = string.Format("{0}_{1}", (int)plantAlarm.PlantId, DateTime.UtcNow.ToString("MMddyyyyhhmmssfff"));

                            Log.Info("No of Red Flag Data records = " + redFlagData.Count);
                            //Log.Info("RedFlag Data Details : " + Environment.NewLine + JsonConvert.SerializeObject(alarmLogData));

                            using (NetworkStream stream = client.GetStream())
                            {
                                //======= transport header =========================================================
                                SendTransportHeader tHeader = new SendTransportHeader();
                                tHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                                tHeader.Body.ServiceType = ServiceType.TcdLogRequest;

                                Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogRequest);

                                XMLSerializingRedFlag xmlserialize = new XMLSerializingRedFlag();
                                string xmlString = xmlserialize.ConvertToXML(redFlagData);
                                Log.Info("RedFlag Data XML : " + Environment.NewLine + xmlString);

                                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(xmlString);

                                byte[] requestBuffer = null;
                                //byte[] requestBuffer = System.Text.Encoding.UTF8.GetBytes(queueLabel);

                                requestBuffer = System.Text.Encoding.UTF8.GetBytes(queueLabel);

                                //============ RedFlag Request Header =============================================
                                TcdLogRequest redFlagHeader = new TcdLogRequest { AppVersion = (uint)((int)TcdAppVersion.VersionCurrent), MessageType = TcdMessageTypes.RedFlagRequest, PayloadSize = (uint)buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack, PlantId = (uint)plantAlarm.PlantId, RequestLabelSize = (requestBuffer != null ? (uint)requestBuffer.Length : 0), NumberOfRecords = (uint)redFlagData.Count };
                                Log.Info("Message Type = " + TcdMessageTypes.RedFlagRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                                // ============== Write to stream ==================================================
                                stream.Write(tHeader);
                                stream.Write(redFlagHeader);
                                stream.Write(requestBuffer, 0, requestBuffer.Length);
                                stream.Write(buffer, 0, buffer.Length);

                                //======== read the response from tcp server =======================================
                                TcdLogResponse response = stream.ReadAllOf<TcdLogResponse>();
                                Log.Info("Response Details : " + Environment.NewLine + JsonConvert.SerializeObject(response));

                                if (response.ErrorCode == TcdErrCodes.Success)
                                {
                                    SyncQueueServices objSyncQueueServices = new SyncQueueServices();
                                    objSyncQueueServices.SaveSyncLoggingRequestDetails(requestIds, queueLabel, TcdMessageTypes.RedFlagRequest.ToString(), redFlagData.Count, plantAlarm.PlantId);
                                    Log.Info("RedFlag Request send to message queue.");
                                    foreach (RedFlagData redFlag in redFlagData)
                                    {
                                        int redFlagId = redFlag.RedFlagId;
                                        objSyncQueueServices.LastSyncUpdate(TableEntityMap.GetTable(typeof(RedFlagData).FullName), redFlagId, TableEntityMap.GetColumn(typeof(RedFlagData).FullName), plantAlarm.EcoalabAccountNumber, lastSyncTime);
                                        Log.Info("Last Sync time Updated for alarm Id = " + redFlagId);
                                    }
                                    errorCode = 1;
                                    Thread.Sleep(requestDelayTime);
                                }
                                else
                                {
                                    Log.Info("Error in redflag request send.");
                                    Log.Error(JsonConvert.SerializeObject(response));
                                }
                            }

                        }
                    }
                }
                catch (SocketException socEx)
                {
                    Log.Error("Error Received While process redflag data :" + socEx);
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured while process redflag data :" + ex);
                }

            return errorCode;
        }

        /// <summary>
        /// Process RedFlag Data
        /// </summary>
        private static void ProcessModuleReadingData()
        {
            try
            {
                PlantService plantService = new PlantService();
                List<ModuleReadData> moduleReadData = GetModuleReadData();
                try
                {
                    if (moduleReadData != null && moduleReadData.Count > 0)
                    {
                        SaveModuleReadingRollupData(moduleReadData); 
                    }
                    else
                    {
                        Log.Info("No Module Reading Data available for sync.");
                    }
                }
                catch (Exception e)
                {
                    Log.Error("Error Received While Saving module reading data in ModuleReadingDataRollup Table :" + e);
                }
                if (plantAlarm == null)
                {
                    plantAlarm = plantService.GetPlantDetails();
                    if (plantAlarm == null)
                    {
                        return;
                    }
                }
                if (plantSettingAlarm == null || (plantSettingAlarm != null && (plantSettingAlarm.NodeId <= 0 || plantSettingAlarm.FtrLastModifiedTime == DateTime.MinValue || plantSettingAlarm.FtrLastModifiedTime == null)))
                {
                    plantSettingAlarm = plantService.GetPlantSettings(plantAlarm.EcoalabAccountNumber);
                    if (plantSettingAlarm == null)
                    {
                        return;
                    }
                }
                if (plantSettingAlarm.NodeId <= 0 || plantSettingAlarm.FtrLastModifiedTime == DateTime.MinValue || plantSettingAlarm.FtrLastModifiedTime == null)
                {
                    return;
                }
                else
                {
                    dicAlarmLogConfiguration = GetAlarmLogConfiguration("SyncAlarmLog");
                    int errorCode = 1;
                    do
                    {
                        errorCode = PushModuleReadDataToMSMQ(moduleReadData);
                    }
                    while (errorCode == 0);
                }
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While process module reading data :" + socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured while process module reading data :" + ex);
            }
        }

        /// <summary>
        /// Push ModuleRead data to msmq
        /// </summary>
        /// <param name="moduleReadData">ModuleRead data object</param>
        /// <returns>Error code 0 if fail otherwise</returns>
        private static int PushModuleReadDataToMSMQ(List<ModuleReadData> moduleReadData)
        {
            int errorCode = 0;
            using (TcpClient client = new TcpClient())
                try
                {
                    {
                        if (moduleReadData.Count > 0)
                        {
                            client.ReceiveTimeout = int.Parse(dicAlarmLogConfiguration["ReceiveTimeout"]);
                            client.Connect(dicAlarmLogConfiguration["HostName"], int.Parse(dicAlarmLogConfiguration["PortNumber"]));

                            DateTime lastSyncTime = DateTime.UtcNow;

                            foreach (ModuleReadData modReaddata in moduleReadData)
                            {
                                modReaddata.LastSyncTime = lastSyncTime;
                            }

                            var requestIds = string.Join(",", moduleReadData.Select(p => p.ModuleId.ToString()));

                            string queueLabel = string.Format("{0}_{1}", (int)plantAlarm.PlantId, DateTime.UtcNow.ToString("MMddyyyyhhmmssfff"));

                            Log.Info("No of Module Read Data records = " + moduleReadData.Count);
                            //Log.Info("ModuleRead Data Details : " + Environment.NewLine + JsonConvert.SerializeObject(alarmLogData));

                            using (NetworkStream stream = client.GetStream())
                            {
                                //======= transport header =========================================================
                                SendTransportHeader tHeader = new SendTransportHeader();
                                tHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                                tHeader.Body.ServiceType = ServiceType.TcdLogRequest;

                                Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogRequest);

                                XMLSerializingModuleRead xmlserialize = new XMLSerializingModuleRead();
                                string xmlString = xmlserialize.ConvertToXML(moduleReadData);
                                Log.Info("Module Read Data XML : " + Environment.NewLine + xmlString);

                                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(xmlString);

                                byte[] requestBuffer = null;
                                //byte[] requestBuffer = System.Text.Encoding.UTF8.GetBytes(queueLabel);

                                requestBuffer = System.Text.Encoding.UTF8.GetBytes(queueLabel);

                                //============ Module Read Request Header =============================================
                                TcdLogRequest moduleReadHeader = new TcdLogRequest { AppVersion = (uint)((int)TcdAppVersion.VersionCurrent), MessageType = TcdMessageTypes.ModuleReadRequest, PayloadSize = (uint)buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack, PlantId = (uint)plantAlarm.PlantId, RequestLabelSize = (requestBuffer != null ? (uint)requestBuffer.Length : 0), NumberOfRecords = (uint)moduleReadData.Count };
                                Log.Info("Message Type = " + TcdMessageTypes.ModuleReadRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                                // ============== Write to stream ==================================================
                                stream.Write(tHeader);
                                stream.Write(moduleReadHeader);
                                stream.Write(requestBuffer, 0, requestBuffer.Length);
                                stream.Write(buffer, 0, buffer.Length);

                                //======== read the response from tcp server =======================================
                                TcdLogResponse response = stream.ReadAllOf<TcdLogResponse>();
                                Log.Info("Response Details : " + Environment.NewLine + JsonConvert.SerializeObject(response));

                                if (response.ErrorCode == TcdErrCodes.Success)
                                {
                                    SyncQueueServices objSyncQueueServices = new SyncQueueServices();
                                    objSyncQueueServices.SaveSyncLoggingRequestDetails(requestIds, queueLabel, TcdMessageTypes.ModuleReadRequest.ToString(), moduleReadData.Count, plantAlarm.PlantId);
                                    Log.Info("ModuleRead Request send to message queue.");
                                    foreach (ModuleReadData moduleRead in moduleReadData)
                                    {
                                        int moduleId = moduleRead.ModuleId;
                                        objSyncQueueServices.ModuleReadDataLastSyncUpdate(moduleRead.ShiftId, moduleRead.LastSyncTime, moduleId);
                                        Log.Info("Last Sync time Updated for Module Id = " + moduleId);
                                    }
                                    errorCode = 1;
                                    Thread.Sleep(requestDelayTime);
                                }
                                else
                                {
                                    Log.Info("Error in module read request send.");
                                    Log.Error(JsonConvert.SerializeObject(response));
                                }
                            }

                        }
                    }
                }
                catch (SocketException socEx)
                {
                    Log.Error("Error Received While process moduleread data :" + socEx);
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured while process moduleread data :" + ex);
                }

            return errorCode;
        }

        /// <summary>
        /// Get Alarm Log Configuration
        /// </summary>
        /// <param name="serviceName">Name of the service.</param>
        /// <returns>Returns Dictionary</returns>
        public static Dictionary<string, string> GetAlarmLogConfiguration(string serviceName)
        {
            SyncConfigSettingService objSyncConfigSettingService = new SyncConfigSettingService();
            return objSyncConfigSettingService.GetAppConfigKeyValueDetails(serviceName);
        }

        /// <summary>
        /// Get Alarm Log Data
        /// </summary>
        /// <returns>Returns List of Alarms</returns>
        private static List<Alarm> GetAlarmLogData()
        {
            int NoOfRecordsToBeProcessed = int.Parse(dicAlarmLogConfiguration["NoOfRecordsToBeProcessed"]);
            AlarmService alarmService = new AlarmService();

            List<Alarm> alarmCollection = alarmService.FetchAlarmDetailsForSync(NoOfRecordsToBeProcessed);
            return alarmCollection;
        }

        /// <summary>
        /// Gets the red flag data.
        /// </summary>
        /// <returns>List of RedFlagData</returns>
        private static List<RedFlagData> GetRedFlagData()
        {
            int NoOfRecordsToBeProcessed = int.Parse(dicAlarmLogConfiguration["NoOfRecordsToBeProcessed"]);
            RedFlagService redFlagService = new RedFlagService();

            List<RedFlagData> redFlagDetailsCollection = redFlagService.FetchRedFlagDetailsForSync(NoOfRecordsToBeProcessed);
            return redFlagDetailsCollection;
        }

        /// <summary>
        /// Gets the module read data.
        /// </summary>
        /// <returns>List of Module Read Data</returns>
        private static List<ModuleReadData> GetModuleReadData()
        {
            int NoOfRecordsToBeProcessed = int.Parse(dicAlarmLogConfiguration["NoOfRecordsToBeProcessed"]);
            MeterService meterService = new MeterService();

            List<ModuleReadData> moduleDataDetailsCollection = meterService.FetchModuleReadDetailsForSync(NoOfRecordsToBeProcessed);
            return moduleDataDetailsCollection;
        }

        /// <summary>
        /// Saves the module reading rollup data.
        /// </summary>
        /// <param name="moduleReadingData">The module reading data.</param>
        private static void SaveModuleReadingRollupData(List<ModuleReadData> moduleReadingData)
        {
            MeterService meterService = new MeterService();
            foreach (ModuleReadData moduleData in moduleReadingData)
            {
                meterService.SaveModuleReadingRollupData(moduleData);
            }
        }
    }
}