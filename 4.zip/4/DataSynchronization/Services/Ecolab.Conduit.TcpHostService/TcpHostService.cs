﻿// -----------------------------------------------------------------------
// <copyright file="TcpHostService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TcpHostService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.ServiceProcess;
    using System.Timers;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Models.SyncMessages;
    using Ecolab.Models;
    using Ecolab.Services;
    using log4net;
    using Properties;
    using Services.SyncConfigSettingService;  

    /// <summary>
    /// The TcpHostService.
    /// </summary>
    public partial class TcpHostService : ServiceBase
    {
        /// <summary>
        ///     Sync Config Settings
        /// </summary>
        private static Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
        /// <summary>
        ///     Logger Instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("TcpHostService");
        /// <summary>
        ///     TCP Host Server Instance
        /// </summary>
        private TcpHostServer tcpHostServerInstance;
        /// <summary>
        ///     Batch Timer
        /// </summary>
        private Timer batchTimer;
        /// <summary>
        ///     Plant Model
        /// </summary>
        private static Plant plant;
        /// <summary>
        /// Initializes a new instance of the <see cref="TcpHostService"/> class.
        /// </summary>
        public TcpHostService()
        {
            InitializeComponent();
        }
        /// <summary>
        /// On Start TCPHostService
        /// </summary>
        internal void Start()
        {
            OnStart(null);
        }
        /// <summary>
        /// On Start TCPHostService
        /// </summary>
        /// <param name="args">Command Line arguments</param>
        protected override void OnStart(string[] args)
        {
            try
            {
                tcpHostServerInstance = new TcpHostServer(Settings.Default.SocketPort);

                if (!Debugger.IsAttached)
                {
                    dicSyncConfigSettings = GetConfiguration("PushAllEntities");
                    this.batchTimer = new Timer
                    {
                        AutoReset = bool.Parse(dicSyncConfigSettings["TimerAutoReset"])
                    };
                    this.batchTimer.Start();
                    this.batchTimer.Elapsed += this.ReCallProcess;
                    Log.Info("N2G2 Service : Timer property set successfully. ");
                }
                else
                {
                    PlantService plantService = new PlantService();
                    if (plant == null)
                    {
                        plant = plantService.GetPlantDetails();
                        if (plant == null)
                        {
                            return;
                        }
                    }
                    Push.PushDeviceSettings(plant);
                }
            }
            catch (Exception ex)
            {
                Log.Error("OnStart", ex);
            }
        }
        /// <summary>
        /// Recall Process
        /// </summary>
        /// <param name="sender">The sender for TCPHostService</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void ReCallProcess(object sender, ElapsedEventArgs e)
        {
            try
            {
                batchTimer.Stop();
                PlantService plantService = new PlantService();
                if (plant == null)
                {
                    plant = plantService.GetPlantDetails();
                    if (plant == null)
                    {
                        return;
                    }
                }
                Push.PushDeviceSettings(plant);
            }
            catch (Exception ex)
            {
                Log.Error("ReCallProcess", ex);
            }
            finally
            {
                batchTimer.Enabled = bool.Parse(dicSyncConfigSettings["TimerEnabled"]);
                batchTimer.Interval = double.Parse(dicSyncConfigSettings["TimerInterval"], CultureInfo.CurrentCulture);
                batchTimer.Start();
            }
        }
        /// <summary>
        /// On stop TCPHostService
        /// </summary>
        protected override void OnStop()
        {
            if (tcpHostServerInstance != null)
            {
                tcpHostServerInstance.Stop();
                tcpHostServerInstance = null;
            }
        }

        /// <summary>
        ///     Get Sync Configuration settings
        /// </summary>
        /// <param name="serviceName">Service Name</param>
        /// <returns>Dictionary of Objects</returns>
        public static Dictionary<string, string> GetConfiguration(string serviceName)
        {
            SyncConfigSettingService syncConfigSettingService = new SyncConfigSettingService();
            return syncConfigSettingService.GetAppConfigKeyValueDetails(serviceName);
        }
    }
}