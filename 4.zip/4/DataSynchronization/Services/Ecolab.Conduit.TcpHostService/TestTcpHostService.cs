﻿// -----------------------------------------------------------------------
// <copyright file="TestTcpHostService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FrmTestTcpHostService </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Windows.Forms;
    using Properties;

	/// <summary>
	/// Test Tcp host services. 
	/// </summary>
    public partial class FrmTestTcpHostService : Form
    {
        /// <summary>
        /// TCP Configuration
        /// </summary>
        private static Dictionary<string, string> dicTcpConfiguration = new Dictionary<string, string>();
        /// <summary>
        /// TCP Host Service Object
        /// </summary>
        private readonly TcpHostService objTcpHostService = new TcpHostService();
        /// <summary>
        /// Initializes a new instance of the <see cref="FrmTestTcpHostService"/> class.
        /// </summary>
        public FrmTestTcpHostService()
        {
            InitializeComponent();
            Trace.Listeners.Add(new TestServicesFormTraceListener(LogOutput));
        }
        /// <summary>
        /// On clicking Buttonclear
        /// </summary>
        /// <param name="sender">The sender for TestTCPHostService</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnClear_Click(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
        }
        /// <summary>
        /// On clicking start service
        /// </summary>
        /// <param name="sender">The sender for TestTCPHostService</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnStartService_Click(object sender, EventArgs e)
        {
            objTcpHostService.Start();
        }
        /// <summary>
        /// On clicking stop service
        /// </summary>
        /// <param name="sender">The sender for TestTCPHostService</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void BtnStopService_Click(object sender, EventArgs e)
        {
            if (objTcpHostService.CanStop)
            {
                objTcpHostService.Stop();
            }
        }
        /// <summary>
        /// On load service
        /// </summary>
        /// <param name="sender">The sender for TestTCPHostService</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void FrmTestTcpHostService_Load(object sender, EventArgs e)
        {
            //TO DO :: Need to check why log4net throwing security permission error at load.
            // which get cleaned by below line. once fixed, below line need to be removed.
            LogOutput.Text = string.Empty;

            lblError.Text = string.Empty;
            dicTcpConfiguration = TcpHostService.GetConfiguration("TcpHostService");
            if (dicTcpConfiguration != null && dicTcpConfiguration.Count() > 3)
            {
                txtServer.Text = dicTcpConfiguration["HostName"];
                txtPort.Text = dicTcpConfiguration["PortNumber"];
                txtTimeOut.Text = dicTcpConfiguration["ReadTimeout"];
                txtSocketPort.Text =Settings.Default.SocketPort.ToString();
            }
            else
            {
                lblError.Text = "Configuration setting is missing.";
            }
        }
    }
    /// <summary>
    /// class Test Services from Listener
    /// </summary>
    internal class TestServicesFormTraceListener : TraceListener
    {
        /// <summary>
        ///  Log Text box
        /// </summary>
        private readonly TextBox LogTextBox;
        /// <summary>
        /// Initializes a new instance of the <see cref="TestServicesFormTraceListener"/> class.
        /// </summary>
        /// <param name="logTextBox">log textbox</param>
        public TestServicesFormTraceListener(TextBox logTextBox)
        {
            LogTextBox = logTextBox;
        }
        /// <summary>
        /// On write method
        /// </summary>
        /// <param name="message">The message</param>
        public override void Write(string message)
        {
            if (LogTextBox.InvokeRequired)
            {
                LogTextBox.Invoke((MethodInvoker) delegate { Write(message); });
                return;
            }

            LogTextBox.AppendText(message);
        }
        /// <summary>
        /// On writeline method
        /// </summary>
        /// <param name="message">The message</param>
        public override void WriteLine(string message)
        {
            Write(message);
            Write(Environment.NewLine);
        }
    }
}