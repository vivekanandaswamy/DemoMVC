﻿// -----------------------------------------------------------------------
// <copyright file="ChainTextileCategoryAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Chain TextileCategory Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Services;
    using log4net;
       
    [MessageType(TcdAdminMessageTypes.TcdUpdateChainTextileCategory)]
    public class ChainTextileCategoryAdminRequest : TcdAdminRequestBase<ChainTextileCategory>
    {
        private static readonly ILog Log = LogManager.GetLogger("ChainTextileCategoryAdminRequest");

        public ChainTextileCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        public ChainTextileCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        public ChainTextileCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ChainTextileCategory);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            Log.Info("ChainTextileCategory: Processing MyService data to Local");
            Log.Info("ChainTextileCategory: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            ProgramMasterService programMasterService = new ProgramMasterService();
            programMasterService.SaveChainTextileCategoryDetails(mPayloadList);
            Log.Info("ChainTextileCategory: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<ChainTextileCategory>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
