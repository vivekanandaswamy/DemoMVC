﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Drain Destination Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
	using System;
	using System.IO;
	using Common;
	using Ecolab.Services;
	using Library.Common;
	using Library.Enums;
	using Library.Helpers;
	using log4net;
	using Models;
	using Services.WasherGroup;
	using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceDrainDestination)]
    public class DrainDestinationAdminRequest : TcdAdminRequestBase<DrainDestination>
    {
        private static readonly ILog Log = LogManager.GetLogger("DrainDestinationAdminRequest");

        public DrainDestinationAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(DrainDestination);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            Log.Info("DrainDestination: Processing MyService data to Local");
            Log.Info("DrainDestination: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            var washerGroupFormulaService = new WasherGroupFormulaService();
            washerGroupFormulaService.SaveDrainDestinationDetails(this.mPayloadList);
            Log.Info("DrainDestination: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(this.mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}