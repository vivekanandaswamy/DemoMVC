﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Contact Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using Common;
    using log4net;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using Models;
    using Models.SyncMessages;
    using Services;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdAddPlantContact)]
    [MessageType(TcdAdminMessageTypes.TcdUpdatePlantContact)]
    [MessageType(TcdAdminMessageTypes.TcdDeletePlantContact)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePlantContact)]
    public class PlantContactAdminRequest : TcdAdminRequestBase<PlantContact>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("PlantContactAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private readonly TcdAdminRequestHeader adminRequestHeader;

        public PlantContactAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer) : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public PlantContactAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion) : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PlantContact);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            PlantContactService plantContactService = new PlantContactService();
            int i;
            if (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdUpdateMyServicePlantContact)
            {
                Log.Info("PlantContact: Processing My Service data to Local.");
                Log.Info("PlantContact: My Service data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));
                i = plantContactService.SaveMyServicePlantContactDetails(mPayload, adminRequestHeader.UserId, out errorCode, out lastModifiedTimeStamp);
            }
            else
            {
                Log.Info("PlantContact: Synch started...Saving in Local.");
                Log.Info("PlantContact: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));
                i = plantContactService.ValidateAndSavePlantContactDetails(mPayload, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            }

            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("PlantContact: Synch successful.");
                mPayload.Id = i;
                mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcoalabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("PlantContact: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("PlantContact: Getting List of data for resynch..");
            PlantContactService plantContactService = new PlantContactService();
            psm.PlantContactList = plantContactService.GetPlantContactDetails(plant.EcoalabAccountNumber);
            psm.PlantContactList.ForEach(c => c.LastModifiedTimeStamp = DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity(psm);
            Log.Info("PlantContact: Resynch data: " + xmlData);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdPlantContactResync;
        }
    }
}