﻿// -----------------------------------------------------------------------
// <copyright file="FormulaSegmentsAdminRequest.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FormulaSegmentsAdminRequest</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Services;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    /// <summary>
    /// FormulaSegments Admin TCP Request
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdFormulaSegment)]
    public class FormulaSegmentsAdminRequest : TcdAdminRequestBase<FormulaSegment>
    {
        /// <summary>
        /// The log for FormulaSegmentsAdminRequest
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("FormulaSegmentsAdminRequest");
        /// <summary>
        /// The p header for FormulaSegmentsAdminRequest
        /// </summary>
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        /// <summary>
        /// Initializes a new instance of the <see cref="FormulaSegmentsAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader for FormulaSegmentsAdminRequest</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload for FormulaSegmentsAdminRequest</param>
        public FormulaSegmentsAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FormulaSegmentsAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">The logger for FormulaSegmentsAdminRequest.</param>
        /// <param name="adminHeader">The admin header.</param>
        /// <param name="appVersion">The application version.</param>
        public FormulaSegmentsAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FormulaSegmentsAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload for FormulaSegmentsAdminRequest</param>
        /// <param name="isListObject">List object for FormulaSegmentsAdminRequest</param>
        public FormulaSegmentsAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>Returns the straing value of EcolabAccountNumber</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>Returns the byte array</returns>
        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<FormulaSegment>(mPayload); ;
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>Returns the byte array</returns>
        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>Returns the integer value</returns>
        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>Returns the errorcodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            _log.Info("FormulaSegment: Processing Central Master data to Local");
            _log.Info("FormulaSegment: Central Master data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            try
            {
                FormulaSegmentService formulaSegemntService = new FormulaSegmentService();
                formulaSegemntService.SaveFormulaSegments(mPayloadList);
                _log.Info("FormulaSegment: Central Master data: to Local");
                return TcdErrCodes.Success;
            }
            catch (Exception ex)
            {
                _log.Info("FormulaSegment: Central Master data: to Local fail : " + ex.Message);
                return TcdErrCodes.UpdateFailure;
            }
        }
    }
}
