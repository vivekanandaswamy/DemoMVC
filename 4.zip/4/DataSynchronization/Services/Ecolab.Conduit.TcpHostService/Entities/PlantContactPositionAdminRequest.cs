﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactPositionAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantContactPositionAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models.Common;
using Ecolab.Services;
using Ecolab.Services.Washers.conventional;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceContactPosition)]
    public class PlantContactPositionAdminRequest : TcdAdminRequestBase<PlantContactPosition>
    {
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader _pHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("PlantContactPositionAdminRequest");

        public PlantContactPositionAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public PlantContactPositionAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public PlantContactPositionAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PlantContactPosition);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            _log.Info("PlantContactPosition: Processing MyService data to Local");
            _log.Info("PlantContactPosition: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            Ecolab.Services.PlantContactService plantContactService = new Services.PlantContactService();
            plantContactService.SaveMyServicePlantContactPositionDetails(mPayloadList);
            _log.Info("PlantContactPosition: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
			return null;
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
