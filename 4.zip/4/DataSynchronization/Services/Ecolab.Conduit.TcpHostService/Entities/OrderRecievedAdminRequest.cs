﻿// -----------------------------------------------------------------------
// <copyright file="OrderRecievedAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Order Recieved Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using Access;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Services;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdUpdateOrderRecieved)]
    public class OrderRecievedAdminRequest : TcdAdminRequestBase<Models.OrderRecieved>
    {

        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("OrderRecievedAdminRequest");

        /// <summary>
        /// The p header
        /// </summary>
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public OrderRecievedAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public OrderRecievedAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
             : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(OrderRecieved);
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Ecolab.Models.OrderRecieved>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int i;
            int errorCode;
            Log.Info("OrderRecieved: Processing MyService data to Local");
            Log.Info("OrderRecieved: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

            Ecolab.Services.OrderRecievedService orderRecievedservice = new OrderRecievedService();
            i = orderRecievedservice.SaveMyServiceOrderRecievedDetails(mPayload, out errorCode);

            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("OrderRecieved: Synch successful.");
                mPayload.Id = i;
            }
            return result;
        }
    }
}
