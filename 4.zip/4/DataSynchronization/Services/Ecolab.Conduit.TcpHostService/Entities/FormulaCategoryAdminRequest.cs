﻿// -----------------------------------------------------------------------
// <copyright file="FormulaCategoryAdminRequest.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>Formula Category Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Services;
    using log4net;
       
    [MessageType(TcdAdminMessageTypes.TcdUpdateFormulaCategory)]
    public class FormulaCategoryAdminRequest : TcdAdminRequestBase<FormulaCategory>
    {
        private static readonly ILog Log = LogManager.GetLogger("FormulaCategoryAdminRequest");

        public FormulaCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        public FormulaCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        public FormulaCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(FormulaCategory);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            Log.Info("FormulaCategory: Processing Central data to Local");
            Log.Info("FormulaCategory: Central data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            ProgramMasterService programMasterService = new ProgramMasterService();
            programMasterService.SaveFormulaCategoryDetails(mPayloadList);
            Log.Info("FormulaCategory: Saved Central data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<FormulaCategory>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
