﻿// -----------------------------------------------------------------------
// <copyright file="ResourceKeyValueAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ResourceKeyValueAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.Common;
using Ecolab.Services;
using Ecolab.Services.PlantSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    /// <summary>
    /// ResourceKeyValueAdminRequest Handler class
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestBase{Ecolab.Models.ResourceKeyValue}" />
    [MessageType(TcdAdminMessageTypes.TcdUpdateResourceKeyValue)]
    public class ResourceKeyValueAdminRequest : TcdAdminRequestBase<ResourceKeyValue>
    {
        private static readonly ILog Log = LogManager.GetLogger("ResourceKeyValueAdminRequest");

        /// <summary>
        /// Initializes a new instance of the <see cref="ResourceKeyValueAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Pay load Value</param>
        public ResourceKeyValueAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResourceKeyValueAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">The logger Value.</param>
        /// <param name="adminHeader">The admin header.</param>
        /// <param name="appVersion">The application version.</param>
        public ResourceKeyValueAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ResourceKeyValueAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Pay load Value</param>
        /// <param name="isListObject">is List Object</param>
        public ResourceKeyValueAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        /// <summary>
        /// Gets type of the Entity
        /// </summary>
        /// <param name="version">Plant app Version</param>
        /// <returns>
        /// Pay load Type 
        /// </returns>
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ResourceKeyValue);
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>Ecolab Account Number</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>Payload Internal</returns>
        protected override byte[] GetPayloadInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>Returns Byte array</returns>
        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>Returns Integer</returns>
        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>Returns Error codes</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int returnStatus = 0;
            Log.Info("ResourceKeyValue: Processing Central data to Local");
            Log.Info("ResourceKeyValue: Central data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));

            ResourceKeyValueService ResourceKeyValueService = new ResourceKeyValueService();
            returnStatus = ResourceKeyValueService.SaveResourceKeyValueDetails(mPayloadList);

            Log.Info("ResourceKeyValue: Saved Central data to Local");

            if (returnStatus == 0)
            {
                return TcdErrCodes.Success;
            }
            else
            {
                return TcdErrCodes.SaveFailure;
            }
        }
    }
}
