﻿// -----------------------------------------------------------------------
// <copyright file="OpenActionItemsAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Open Action Items Admin Request handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities
{
	using System;
	using System.IO;
	using Access;
	using Common;
	using Library.Common;
	using Library.Enums;
	using Library.Helpers;
	using log4net;
	using Models;
	using Services;
	using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    /// <summary>
    /// TunnelWaterFlowTypeAdminRequest
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdUpdateOpenActionItems)]
    public class OpenActionItemsAdminRequest : TcdAdminRequestBase<Models.OpenActionItems>
    {
        private static readonly ILog Log = LogManager.GetLogger("OpenActionItemsAdminRequest");

        public OpenActionItemsAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(OpenActionItems);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            Log.Info("OpenActionItems: Processing MyService data to Local");
            Log.Info("OpenActionItems: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));

            OpenActionItemsService openActionItemsServices = new OpenActionItemsService();
            openActionItemsServices.SaveMyServiceOpenActionItemsDetails(this.mPayloadList);

            Log.Info("OpenActionItems: Saved MyService data in Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
			return null;
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
