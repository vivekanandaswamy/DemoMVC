﻿// -----------------------------------------------------------------------
// <copyright file="AlarmsAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The AlarmsAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.Washers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Common;
    using Ecolab.Models.SyncMessages;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models.Washers;
    using Services;
    using Services.Washers;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    /// <summary>
    /// Class for AlarmsAdminRequest
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestBase{Ecolab.Models.Washers.Alarms}" />
    [MessageType(TcdAdminMessageTypes.TcdAddAlarmStatus)]
    [MessageType(TcdAdminMessageTypes.TcdAddBatchEjectConditionStatus)]
    public class AlarmsAdminRequest : TcdAdminRequestBase<Alarms>
    {
        private static readonly ILog Log = LogManager.GetLogger("AlarmsAdminRequest");
        private TcdAdminRequestHeader pHeader;

        /// <summary>
        /// Initializes a new instance of the <see cref="AlarmsAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin Header</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Pay load Value</param>
        public AlarmsAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer) : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
		public AlarmsAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
        }

        /// <summary>
        /// Gets type of the Entity
        /// </summary>
        /// <param name="version">Plant app Version</param>
        /// <returns>
        /// Returns the Type
        /// </returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Alarms);
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>Returns the error codes</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            WasherServices washerServices = new WasherServices();

            Log.Info("Alarm: Synch started...Saving in Local.");
            Log.Info("Alarm: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));
            if (mPayload.IsBatchEjectCondition)
            {
                washerServices.ValidateAndSaveBatchEjectConditionStatus(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode);
            }
            else
            {
                washerServices.ValidateAndSaveAlarmStatus(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode);
            }
            TcdErrCodes result = (TcdErrCodes)errorCode;

            if (result == TcdErrCodes.Success)
            {
                Log.Info("Alarm: Synch successful.");
            }
            return result;
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>Returns the string</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>Returns the byte array</returns>
        protected override byte[] GetPayloadInternal()
        {
            if (pHeader.MessageType == Ecolab.Conduit.Library.Enums.TcdAdminMessageTypes.TcdAddBatchEjectConditionStatus)
            {
                return SerializeHelper.Serialize(mPayload);
            }
            else
            {
                WasherServices washerService = new WasherServices();
                List<Alarms> lstAlarms = washerService.GetAlarmStatusDataForWasher(mPayload.EcolabAccountNumber, mPayload.MachineNumber, mPayload.TunnelId);
                if (lstAlarms != null && mPayload != null && lstAlarms.Count == 0)
                {
                    lstAlarms.Add(mPayload);
                }
                Alarms alarm = lstAlarms.Count > 0 ? lstAlarms.First() : new Alarms();
                alarm.AlarmMachineMappingIds = mPayload.AlarmMachineMappingIds;
                alarm.Ids = lstAlarms.Select(a => a.Id).ToList<int>();
                alarm.LastModifiedTimeStamp = DateTime.SpecifyKind(alarm.LastModifiedTimeStamp ?? DateTime.Now, DateTimeKind.Utc);
                return SerializeHelper.Serialize(alarm);
            }
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>Returns the byte array</returns>
        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("Alarm: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Log.Info("Alarm: Getting List of data for resynch..");
            PlantService plantService = new PlantService();
            Models.Plant plantDetails = plantService.GetPlantDetails();
            WasherServices washerService = new WasherServices();
            if (pHeader.MessageType == Ecolab.Conduit.Library.Enums.TcdAdminMessageTypes.TcdAddBatchEjectConditionStatus)
            {
                psm.BatchEjectList = washerService.GetBatchEjectStatusForResync(plantDetails.EcoalabAccountNumber);
            }
            else
            {
                psm.AlarmList = washerService.GetAlarmDataForResync(plantDetails.EcoalabAccountNumber);
            }
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            Log.Info("Alarm: Resynch data: " + jsonData);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>Returns the integer value</returns>
        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdPlantContactResync;
        }
    }
}