﻿// -----------------------------------------------------------------------
// <copyright file="WashersAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WashersAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.Washers
{
	using System;
	using System.IO;
	using Common;
	using Ecolab.Services;
	using Library.Common;
	using Library.Enums;
	using Library.Helpers;
	using log4net;
	using Models.Washers;
	using Services.Washers;
	using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdDeleteConventionaGeneral)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteTunnelGeneral)]
    public class WashersAdminRequest : TcdAdminRequestBase<Washers>
    {
        private static readonly ILog Log = LogManager.GetLogger("WashersAdminRequest");
        private TcdAdminRequestHeader pHeader;

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public WashersAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer) : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

        /// <summary>
        ///     Gets the type of the ConventionalGeneral entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Washers);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;

            Log.Info("Washers: Synch started...Saving in Local.");
            Log.Info("Washers: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

            WasherServices washerServices = new WasherServices();

            int i = washerServices.ValidateAndSaveWasherDetails(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes) errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("Washers: Synch successful.");
                mPayload.Id = i;
                mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}