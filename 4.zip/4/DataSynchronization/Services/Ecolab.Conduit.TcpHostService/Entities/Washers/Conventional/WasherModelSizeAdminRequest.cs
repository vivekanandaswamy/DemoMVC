﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSizeAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModelSizeAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models.Washers.Conventional;
using Ecolab.Services;
using Ecolab.Services.Washers.conventional;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Conventional
{
    /// <summary>
    /// ConventionalGeneral Admin Request Handler class
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceWasherModelSize)]
    public class WasherModelSizeAdminRequest : TcdAdminRequestBase<WasherModelSize>
    {
        private static readonly ILog Log = LogManager.GetLogger("WasherModelSizeAdminRequest");

        public WasherModelSizeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        public WasherModelSizeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        public WasherModelSizeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(WasherModelSize);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            Log.Info("WashOperation: Processing MyService data to Local");
            Log.Info("WashOperation: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));

            ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();
            conventionalGeneralServices.SaveWasherModelSizeDetails(mPayloadList);

            Log.Info("WashOperation: Saved MyService data to Local");

            return TcdErrCodes.Success;
            
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
			return null;
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
