﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalGeneralAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionalGeneralAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.Washers.Conventional;
using Ecolab.Services;
using Ecolab.Services.Washers.conventional;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Conventional
{
    using Ecolab.Models.WasherGroup;
    using Ecolab.Services.WasherGroup;
    using Models.SyncMessages;

    /// <summary>
    /// ConventionalGeneral Admin Request Handler class
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdAddConventionaGeneral)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateConventionaGeneral)]
    public class ConventionalGeneralAdminRequest : TcdAdminRequestBase<ConventionalGeneral>
    {
        private static readonly ILog Log = LogManager.GetLogger("ConventionalGeneralAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public ConventionalGeneralAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        public ConventionalGeneralAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
        }

        /// <summary>
        /// Gets the type of the ConventionalGeneral entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ConventionalGeneral);
        }

        /// <summary>
        /// Process the Meters request
        /// </summary>
        /// <param name="outputStream">Stream</param>
        /// <returns>TcdErrorCodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;

            Log.Info("ConventionalGeneral: Synch started...Saving in Local.");
            Log.Info("ConventionalGeneral: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

            ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();

            int i = conventionalGeneralServices.ValidateAndSaveConventionalGeneralDetails(mPayload, pHeader.UserId, mPayload.Role, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("ConventionalGeneral: Synch successful.");
                if (pHeader.MessageType == TcdAdminMessageTypes.TcdAddConventionaGeneral)
                {
                    mPayload.Id = i;
                    Id = i;
                    mPayload.ConventionalWasherTagList = conventionalGeneralServices.GetConventionalWasherTagsByWasherId(i, mPayload.EcolabAccountNumber);
                }
                mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
			InjectionService injectionService = new InjectionService();
			if (mPayload.WasherGroupIdNew > 0 && mPayload.WasherGroupId != mPayload.WasherGroupIdNew)
			{
				var oldWasherGroupInjectionData = injectionService.GetInjectionDetailsForSynch(mPayload.WasherGroupId);
				mPayload.InjectionData.AddRange(oldWasherGroupInjectionData);
				var newWasherGroupInjectionData = injectionService.GetInjectionDetailsForSynch(mPayload.WasherGroupIdNew);
				mPayload.InjectionData.AddRange(newWasherGroupInjectionData);
			}
			else
			{
				mPayload.InjectionData = injectionService.GetInjectionDetailsForSynch(mPayload.WasherGroupId);
			}
			return SerializeHelper.Serialize<ConventionalGeneral>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("ConventionalGeneral: Resynch started...");

            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("ConventionalGeneral: Getting List of data for resynch..");

            ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();
            InjectionService injectionService = new InjectionService();

            psm.ConventionalGeneralList = conventionalGeneralServices.GetConventionalDataForResync(null, null, plant.EcoalabAccountNumber, true);
            foreach (var conventionalgeneral in psm.ConventionalGeneralList)
            {
                conventionalgeneral.InjectionData = injectionService.GetInjectionDetailsForSynch(conventionalgeneral.WasherGroupId);
            }
            psm.ConventionalGeneralList.ForEach(c => DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);

            Log.Info("ConventionalGeneral: Resynch data: " + xmlData);

            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdConventionalGeneralResync;
        }
    }
}
