﻿// -----------------------------------------------------------------------
// <copyright file="WasherOperationAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherOperationAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models.WasherGroup;
using Ecolab.Models.Washers.Conventional;
using Ecolab.Services;
using Ecolab.Services.WasherGroup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Conventional
{
    /// <summary>
    /// Class for WasherOperationAdminRequest
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestBase{Ecolab.Models.WasherGroup.WashStep}" />
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceWashOperation)]
    public class WasherOperationAdminRequest : TcdAdminRequestBase<WashStep>
    {
        /// <summary>
        /// The log values for logger
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("WasherOperationAdminRequest");

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherOperationAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin Header</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Pay load value</param>
        public WasherOperationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherOperationAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">The logger value.</param>
        /// <param name="adminHeader">The admin header.</param>
        /// <param name="appVersion">The application version.</param>
        public WasherOperationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherOperationAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload value</param>
        /// <param name="isListObject">Is list object </param>
        public WasherOperationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        /// <summary>
        /// Gets type of the Entity
        /// </summary>
        /// <param name="version">Plant app Version</param>
        /// <returns>
        /// Returns the Type value
        /// </returns>
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(WashStep);
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>Tcd Error Codes</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            Log.Info("WashOperation: Processing MyService data to Local");
            Log.Info("WashOperation: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));

            WasherGroupFormulaService washerGroupFormulaServices = new WasherGroupFormulaService();
            washerGroupFormulaServices.SaveWashOperationDetails(mPayloadList);

            Log.Info("WashOperation: Saved MyService data to Local");

            return TcdErrCodes.Success;
            
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>Returns the string.</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>Returns the array bite</returns>
        protected override byte[] GetPayloadInternal()
        {
			return null;
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>Returns the array bite<</returns>
        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>Returns the integer</returns>
        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
