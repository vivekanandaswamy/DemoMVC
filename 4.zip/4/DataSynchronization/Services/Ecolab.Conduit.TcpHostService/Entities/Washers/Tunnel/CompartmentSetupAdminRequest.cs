﻿// -----------------------------------------------------------------------
// <copyright file="CompartmentSetupAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CompartmentSetupAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.Washers.Tunnel;
using Ecolab.Services;
using Ecolab.Services.Washers.Tunnel;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Tunnel
{
    using Models.SyncMessages;

    /// <summary>
    /// Tunnel Compartment Setup Admin Request Handler class
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdSaveTunnnelCompartment)]
    [MessageType(TcdAdminMessageTypes.TcdCompartmentSetupResync)]
	[MessageType(TcdAdminMessageTypes.TcdMovePump)]
    public class CompartmentSetupAdminRequest : TcdAdminRequestBase<TunnelCompartment>
    {
          private static readonly ILog Log = LogManager.GetLogger("CompartmentSetupAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public CompartmentSetupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }     
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(TunnelCompartment);
        }     
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            TunnelCompartmentServices tunnelCompartmentService = new TunnelCompartmentServices();

            Log.Info("TunnelCompartment: Synch started...Saving in Local.");
            Log.Info("TunnelCompartment: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

            int i = tunnelCompartmentService.ValidateAndSaveTunnelCompartmentDetails(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("TunnelCompartment: Synch successful.");
                Id = i;
                mPayload.TunnelCompartmentId = i;
                Id = i;
                mPayload.LastModifiedTimeStamp = lastModifiedTimeStamp;
            }
            return result;
        }
        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }
        protected override byte[] GetPayloadInternal()
        {
            TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            TunnelCompartmentServices tunnelCompartmentServices = new TunnelCompartmentServices();
            TunnelContainer container = new TunnelContainer();
            container.TunnelCompartments = new List<TunnelCompartment>();
            container.TunnelGeneral = tunnelGeneralServices.GetTunnelData(mPayload.Id, mPayload.WasherGroupId, mPayload.EcolabAccountNumber);
            container.TunnelGeneral.LastModifiedTimeStamp = DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
            container.TunnelGeneral.TunnelTagsList = tunnelGeneralServices.GetTunnelWasherTagsByWasherId(mPayload.Id, mPayload.EcolabAccountNumber);
            TunnelCompartment compartment = tunnelCompartmentServices.GetCompartmentData(mPayload.Id, mPayload.WasherGroupId, mPayload.EcolabAccountNumber, Convert.ToByte(mPayload.CompartmentNumber), true);
            compartment.LastModifiedTimeStamp = DateTime.SpecifyKind(compartment.LastModifiedTimeStamp, DateTimeKind.Utc);
            container.TunnelCompartments.Add(compartment);

            return SerializeHelper.Serialize<TunnelContainer>(container);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("TunnelCompartment: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("TunnelCompartment: Getting List of data for resynch..");
            TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            psm.TunnelList = tunnelGeneralServices.GetTunnelDataForReSync(plant.EcoalabAccountNumber);
            
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);

            Log.Info("TunnelCompartment: Resynch data: " + jsonData);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdTunnelResync;
        }
    }
}
