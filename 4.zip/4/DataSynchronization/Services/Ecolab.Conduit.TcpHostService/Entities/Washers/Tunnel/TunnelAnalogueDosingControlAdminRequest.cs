﻿// -----------------------------------------------------------------------
// <copyright file="TunnelAnalogueDosingControlAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tunnel Analogue Dosing Control Admin Request</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.SyncMessages;
using Ecolab.Models.Washers.Tunnel;
using Ecolab.Services;
using Ecolab.Services.Washers.Tunnel;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Tunnel
{
	 ///<summary>
	 ///TunnelAnalogueDosingControlAdminRequest
	 ///</summary>
	[MessageType(TcdAdminMessageTypes.TcdAddTunnelAnalogueDosingControl)]
	public class TunnelAnalogueDosingControlAdminRequest : TcdAdminRequestBase<TunnelAnalogueDosingControlContainer>
	{
		private static readonly ILog Log = LogManager.GetLogger("TunnelAnalogueDosingControlAdminRequest");
		private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

		/// <summary>
		///     Constructor with parameters
		/// </summary>
		/// <param name="logger">Log4Net object</param>
		/// <param name="adminHeader">Admin header</param>
		/// <param name="appVersion">Plant App Version</param>
		/// <param name="inputBuffer">Payload</param>
		public TunnelAnalogueDosingControlAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
			: base(logger, adminHeader, appVersion, inputBuffer)
		{
			pHeader = adminHeader;
		}

		/// <summary>
		/// Constructor with parameters
		/// </summary>
		/// <param name="logger">Log4Net object</param>
		/// <param name="adminHeader">Admin header</param>
		/// <param name="appVersion">Plant App Version</param>
		public TunnelAnalogueDosingControlAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
			: base(adminHeader, appVersion)
		{
			pHeader = adminHeader;
		}

		/// <summary>
		///     Gets the type of the ConventionalGeneral entity
		/// </summary>
		/// <param name="version">Plant appVersion</param>
		/// <returns>Type</returns>
		public override Type GetPayloadType(TcdAppVersion version)
		{
			return typeof(TunnelAnalogueDosingControlContainer);
		}

		/// <summary>
		/// process Tunnel Analogue Dosing Control
		/// </summary>
		/// <param name="outputStream">outputStream</param>
		/// <returns>tcd error codes</returns>
		protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
		{
			int errorCode;
			DateTime lastModifiedTimeStamp;
			if (base.CheckContainerResync(mPayload.LastModifiedAnalogueDosingControlCentral, mPayload.AnalogueDosingControlList.FirstOrDefault().EcolabAccountNumber, "TunnelAnalogControlLevel"))
			{
				return TcdErrCodes.RecordNotInSynch;
			}

			Log.Info("TunnelAnalogueDosingControl: Synch started...Saving in Local.");
			Log.Info("TunnelAnalogueDosingControl: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

			TunnelAnalogueDosingControlServices tunnelAnalogueDosingControlServices = new TunnelAnalogueDosingControlServices();

			tunnelAnalogueDosingControlServices.ValidateAndSaveTunnelAnalogueDosingControlDetails(mPayload.AnalogueDosingControlList, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);

			TcdErrCodes result = (TcdErrCodes)errorCode;
			if (result == TcdErrCodes.Success)
			{
				Log.Info("TunnelAnalogueDosingControl: Synch successful.");
				List<AnalogueDosing> analogDosing = tunnelAnalogueDosingControlServices.GetTunnelAnalogueDosingControlForResynch(mPayload.AnalogueDosingControlList.FirstOrDefault().WasherId, mPayload.AnalogueDosingControlList.FirstOrDefault().EcolabAccountNumber);
				analogDosing.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
				analogDosing.ForEach(t => t.EcolabAccountNumber = mPayload.AnalogueDosingControlList.FirstOrDefault().EcolabAccountNumber);
				mPayload.AnalogueDosingControlList = analogDosing;
			}
			return result;
		}

		/// <summary>
		/// GetEcolabAccountNumberInternal
		/// </summary>
		/// <returns>ecolab account number</returns>
		protected override string GetEcolabAccountNumberInternal()
		{
			return mPayload.AnalogueDosingControlList.FirstOrDefault().EcolabAccountNumber;
		}

		/// <summary>
		/// GetPayloadInternal
		/// </summary>
		/// <returns>get the payload for central</returns>
		protected override byte[] GetPayloadInternal()
		{
			return SerializeHelper.Serialize(mPayload);
		}

		/// <summary>
		/// GetResyncDataInternal
		/// </summary>
		/// <returns>get resync data</returns>
		protected override byte[] GetResyncDataInternal()
		{
			Log.Info("FlushTimesAndSetupTom: Resynch started...");
			TcdAllPlantEntities psm = new TcdAllPlantEntities();
			Plant plant = new Plant();
			PlantService plantService = new PlantService();
			plant = plantService.GetPlantDetails();

			Log.Info("FlushTimesAndSetupTom: Getting List of data for resynch..");
			TunnelAnalogueDosingControlServices tunnelAnalogueDosingControlServices = new TunnelAnalogueDosingControlServices();
			List<AnalogueDosing> analogDosing = tunnelAnalogueDosingControlServices.GetTunnelAnalogueDosingControlForResynch(null, plant.EcoalabAccountNumber);
			analogDosing.ForEach(t => t.EcolabAccountNumber = plant.EcoalabAccountNumber);
			analogDosing.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
			psm.TunnelAnalogueDosingControlContainerList = new List<TunnelAnalogueDosingControlContainer>();
			psm.TunnelAnalogueDosingControlContainerList.Add(new TunnelAnalogueDosingControlContainer());
			psm.TunnelAnalogueDosingControlContainerList.FirstOrDefault().AnalogueDosingControlList = analogDosing;
			
			string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);

			Log.Info("FlushTimesAndSetupTom: Resynch data: " + jsonData);
			return SerializeHelper.ConvertStringToByteArray(jsonData);
		}

		/// <summary>
		/// GetResyncTypeInternal
		/// </summary>
		/// <returns>Get resync type</returns>
		protected override int GetResyncTypeInternal()
		{
			return (int)TcdAdminMessageTypes.TcdTunnelAnalogueDosingControlResync;
		}
	}
}
