﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWaterInletDrainLookupAdminRequest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelWaterInletDrainLookupAdminRequest class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Tunnel
{
	using System;
	using System.Collections.Generic;
	using System.IO;
	using Common;
	using Ecolab.Services;
	using Library.Common;
	using Library.Enums;
	using log4net;
	using Models.Washers.Tunnel;
	using Services.Washers.Tunnel;
	using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceTunnelWaterInletDrainLookup)]
    public class TunnelWaterInletDrainLookupAdminRequest : TcdAdminRequestBase<PressExtractor>
    {
        private static ILog Log = LogManager.GetLogger("TunnelWaterInletDrainLookupAdminRequest");

        public TunnelWaterInletDrainLookupAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader,
            TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(List<PressExtractor>);
        }

        /// <summary>
        /// To Process myService Master Data to Local
        /// </summary>
        /// <param name="outputStream">outputStream</param>
        /// <returns>tcdErrcode for success/failure</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            Log.Info("TunnelWaterInletDrainLookup: Processing MyService data to Local");
            Log.Info("TunnelWaterInletDrainLookup: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            tunnelGeneralServices.SaveTunnelWaterInletDrainLookupDetails(this.mPayloadList);
            Log.Info("TunnelWaterInletDrainLookup: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return null;
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}