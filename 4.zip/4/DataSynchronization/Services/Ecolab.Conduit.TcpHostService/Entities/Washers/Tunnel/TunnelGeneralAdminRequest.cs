﻿// -----------------------------------------------------------------------
// <copyright file="TunnelGeneralAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelGeneralAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Tunnel
{
    using System;
    using System.IO;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.SyncMessages;
    using Models.Washers.Tunnel;
    using Services;
    using Services.Washers.Tunnel;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    /// <summary>
    ///     ConventionalGeneral Admin Request Handler class
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdAddTunnelGeneral)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateTunnelGeneral)]
    public class TunnelGeneralAdminRequest : TcdAdminRequestBase<TunnelGeneral>
    {
        private static readonly ILog Log = LogManager.GetLogger("TunnelGeneralAdminRequest");
        private TcdAdminRequestHeader pHeader;

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public TunnelGeneralAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            this.pHeader = adminHeader;
        }

        public TunnelGeneralAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            this.pHeader = adminHeader;
            
        }

        /// <summary>
        ///     Gets the type of the ConventionalGeneral entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(TunnelGeneral);
        }

        /// <summary>
        ///     Process the Meters request
        /// </summary>
        /// <param name="outputStream">Stream</param>
        /// <returns>TcdErrorCodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;

            Log.Info("TunnelGeneral: Synch started...Saving in Local.");
            Log.Info("TunnelGeneral: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(this.mPayload));
            TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            int i = tunnelGeneralServices.ValidateAndSaveTunnelGeneralDetails(this.mPayload, this.pHeader.UserId,
                this.mPayload.Role, this.mPayload.EcolabAccountNumber, this.pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("TunnelGeneral: Synch successful.");
				if(this.pHeader.MessageType == TcdAdminMessageTypes.TcdAddTunnelGeneral)
				{
                    Id = i;
					this.mPayload.Id = i;
                    mPayload.TunnelTagsList = tunnelGeneralServices.GetTunnelWasherTagsByWasherId(this.mPayload.Id, this.mPayload.EcolabAccountNumber);
				}
                this.mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return this.mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            TunnelContainer container = new TunnelContainer();
            container.TunnelGeneral = tunnelGeneralServices.GetTunnelData(this.mPayload.Id, this.mPayload.WasherGroupId,
                this.mPayload.EcolabAccountNumber);
            container.TunnelGeneral.LastModifiedTimeStamp =
                DateTime.SpecifyKind(container.TunnelGeneral.LastModifiedTimeStamp, DateTimeKind.Utc);
            container.TunnelGeneral.TunnelTagsList =
                tunnelGeneralServices.GetTunnelWasherTagsByWasherId(this.mPayload.Id, this.mPayload.EcolabAccountNumber);
            return SerializeHelper.Serialize(container);
        }

        /// <summary>
        /// GetResyncDataInternal
        /// </summary>
        /// <returns>serialised data in byte array</returns>
        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("TunnelGeneral: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("TunnelGeneral: Getting List of data for resynch..");

            TunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            psm.TunnelList = tunnelGeneralServices.GetTunnelDataForReSync(plant.EcoalabAccountNumber);
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity(psm);

            Log.Info("TunnelGeneral: Resynch data: " + jsonData);

            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        /// <summary>
        /// GetResyncTypeInternal
        /// </summary>
        /// <returns>TcdAdminMessageTypes</returns>
        protected override int GetResyncTypeInternal()
        {
            return (int) TcdAdminMessageTypes.TcdTunnelResync;
        }
    }
}