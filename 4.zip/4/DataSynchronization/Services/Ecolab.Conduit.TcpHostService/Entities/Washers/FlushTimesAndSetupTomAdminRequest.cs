﻿// -----------------------------------------------------------------------
// <copyright file="FlushTimesAndSetupTomAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Flush Times And Setup Tom Admin Request</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.Washers
{
	using System;
	using System.IO;
	using Common;
	using Ecolab.Services;
	using Library.Common;
	using Library.Enums;
	using Library.Helpers;
	using log4net;
	using Models.Washers;
	using Services.Washers;
	using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;
    using Ecolab.Models.SyncMessages;
    using Ecolab.Models;

    [MessageType(TcdAdminMessageTypes.TcdAddFlushTimesAndSetupTom)]
    public class FlushTimesAndSetupTomAdminRequest : TcdAdminRequestBase<FlushTimesAndSetupTom>
    {
        private static readonly ILog Log = LogManager.GetLogger("FlushTimesAndSetupTomAdminRequest");
        private TcdAdminRequestHeader pHeader;

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public FlushTimesAndSetupTomAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer) : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

		/// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
		public FlushTimesAndSetupTomAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
        }

        /// <summary>
        ///     Gets the type of the ConventionalGeneral entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Washers);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            if (base.CheckContainerResync(mPayload.LastModifiedTimeWasherFlushCentral, mPayload.EcolabAccountNumber, "WasherFlushTime") ||
                base.CheckContainerResync(mPayload.LastModifiedTimeTimeOutMachineCentral, mPayload.EcolabAccountNumber, "WasherTimeOutMachine"))
            {
                return TcdErrCodes.RecordNotInSynch;
            }

            Log.Info("FlushTimesAndSetupTom: Synch started...Saving in Local.");
            Log.Info("FlushTimesAndSetupTom: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

            FlushTimesAndSetupTomServices flushTimesAndSetupTomServices = new FlushTimesAndSetupTomServices();

            int i = flushTimesAndSetupTomServices.ValidateAndSaveflushTimesAndSetupTomDetails(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            
            TcdErrCodes result = (TcdErrCodes) errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("FlushTimesAndSetupTom: Synch successful.");
                mPayload.Id = i;
                mPayload.WasherFlushTime[0].LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                mPayload = GetflushTimesAndSetupTomData(mPayload.WasherFlushTime[0].WasherId, mPayload.EcolabAccountNumber, mPayload.ControllerModelId);
                mPayload.WasherFlushTime.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
                mPayload.WasherTimeOutMachine.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            }
            return result;
        }

		private FlushTimesAndSetupTom GetflushTimesAndSetupTomData(int washerId, string ecolabAccountNumber, int controllerModelId)
		{
			string ecolabAccNo = ecolabAccountNumber;
			int controllerMId = controllerModelId;
			FlushTimesAndSetupTomServices flushTimesAndSetupTomServices = new FlushTimesAndSetupTomServices();
			FlushTimesAndSetupTom flushTimeSetupTom = flushTimesAndSetupTomServices.GetWasherFlushTimeAndSetupForResynch(washerId, ecolabAccountNumber, controllerModelId);
			flushTimeSetupTom.EcolabAccountNumber = ecolabAccNo;
			flushTimeSetupTom.ControllerModelId = controllerMId;
			return flushTimeSetupTom;
		}

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("FlushTimesAndSetupTom: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("FlushTimesAndSetupTom: Getting List of data for resynch..");
            FlushTimesAndSetupTomServices flushTimesAndSetupTomServices = new FlushTimesAndSetupTomServices();
			psm.FlushTimesAndSetupTomList = flushTimesAndSetupTomServices.GetWasherFlushTimeAndSetupForResync(plant.EcoalabAccountNumber);

            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);

            Log.Info("FlushTimesAndSetupTom: Resynch data: " + jsonData);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdFlushTimesAndSetupTomDataResync;
        }
    }
}