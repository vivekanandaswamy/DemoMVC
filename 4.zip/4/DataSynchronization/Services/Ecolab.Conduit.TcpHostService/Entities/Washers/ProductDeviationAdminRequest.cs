﻿// -----------------------------------------------------------------------
// <copyright file="ProductDeviationAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductDeviationAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.Washers.Tunnel;
using Ecolab.Services;
using Ecolab.Services.Washers.Tunnel;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.Washers.Tunnel
{
    using Ecolab.Models.Washers;
    using Ecolab.Services.Washers;
    using Models.SyncMessages;

    /// <summary>
    /// Tunnel Compartment Setup Admin Request Handler class
    /// </summary>
	[MessageType(TcdAdminMessageTypes.TcdAddProductDeviation)]
	[MessageType(TcdAdminMessageTypes.TcdProductDeviationResync)]
	public class ProductDeviationAdminRequest : TcdAdminRequestBase<ProductDeviationContainer>
	{
		private static readonly ILog Log = LogManager.GetLogger("ProductDeviationAdminRequest");
		private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

		/// <summary>
		/// Constructor with parameters
		/// </summary>
		/// <param name="logger">Log4Net object</param>
		/// <param name="adminHeader">Admin header</param>
		/// <param name="appVersion">Plant App Version</param>
		/// <param name="inputBuffer">Payload</param>
		public ProductDeviationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
			: base(logger, adminHeader, appVersion, inputBuffer)
		{
			pHeader = adminHeader;
		}

		/// <summary>
		/// Constructor with parameters
		/// </summary>
		/// <param name="logger">Log4Net object</param>
		/// <param name="adminHeader">Admin header</param>
		/// <param name="appVersion">Plant App Version</param>
		public ProductDeviationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
			: base(adminHeader, appVersion)
		{
			pHeader = adminHeader;
		}

		/// <summary>
		/// Get Paylod type
		/// </summary>
		/// <param name="version">the tcd app version</param>
		/// <returns>type of payload</returns>
		public override System.Type GetPayloadType(TcdAppVersion version)
		{
			return typeof(ProductDeviationContainer);
		}

		/// <summary>
		/// ProcessMessageInternal
		/// </summary>
		/// <param name="outputStream">the outputStream</param>
		/// <returns>tcd error codes</returns>
		protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
		{
			int errorCode;
			DateTime lastModifiedTimeStamp;
			if (base.CheckContainerResync(mPayload.LastModifiedProductDeviationCentral, mPayload.EcolabAccountNumber, "WasherProductDeviations"))
			{
				return TcdErrCodes.RecordNotInSynch;
			}
			ProductDeviationService productDeviationService = new ProductDeviationService();

			Log.Info("ProductDeviation: Synch started...Saving in Local.");
			Log.Info("ProductDeviation: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

			productDeviationService.ValidateAndSaveProductDeviationDetails(mPayload, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);

			TcdErrCodes result = (TcdErrCodes)errorCode;
			if (result == TcdErrCodes.Success)
			{
				Log.Info("ProductDeviation: Synch successful.");
			}
			return result;
		}

		/// <summary>
		/// GetEcolabAccountNumberInternal
		/// </summary>
		/// <returns>ecolab account number</returns>
		protected override string GetEcolabAccountNumberInternal()
		{
			return mPayload.EcolabAccountNumber;
		}

		/// <summary>
		/// GetPayloadInternal
		/// </summary>
		/// <returns>pay load internal</returns>
		protected override byte[] GetPayloadInternal()
		{
			ProductDeviationService productDeviationServices = new ProductDeviationService();
			ProductDeviationContainer container = new ProductDeviationContainer();

			List<ProductDeviation> lstProductDev = productDeviationServices.GetProductDeviationList(mPayload.LstProductDeviation[0].WasherId, mPayload.EcolabAccountNumber);
			container.LstProductDeviation = lstProductDev;
			container.LstProductDeviation.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));

			return SerializeHelper.Serialize<ProductDeviationContainer>(container);
		}

		/// <summary>
		/// GetResyncDataInternal
		/// </summary>
		/// <returns>resync data for product deviations</returns>
		protected override byte[] GetResyncDataInternal()
		{
			Log.Info("ProductDeviation: Resynch started...");
			TcdAllPlantEntities psm = new TcdAllPlantEntities();
			Plant plant = new Plant();
			PlantService plantService = new PlantService();
			plant = plantService.GetPlantDetails();

			Log.Info("ProductDeviation: Getting List of data for resynch..");
			ProductDeviationService productDeviationServices = new ProductDeviationService();
			List<ProductDeviationContainer> productDeviationContainerList = new List<ProductDeviationContainer>();
			productDeviationContainerList.Add(new ProductDeviationContainer());

			List<ProductDeviation> productDeviation = new List<ProductDeviation>();
			productDeviation = productDeviationServices.GetProductDeviationDataForReSync(plant.EcoalabAccountNumber);
			productDeviation.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
			productDeviationContainerList[0].LstProductDeviation = productDeviation;
			psm.ProductDeviationList = productDeviationContainerList;

			string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);

			Log.Info("TunnelCompartment: Resynch data: " + jsonData);
			return SerializeHelper.ConvertStringToByteArray(jsonData);
		}

		/// <summary>
		/// GetResyncTypeInternal
		/// </summary>
		/// <returns>resync message type for product deviations</returns>
		protected override int GetResyncTypeInternal()
		{
			return (int)TcdAdminMessageTypes.TcdProductDeviationResync;
		}
	}
}
