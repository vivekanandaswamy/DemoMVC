﻿// -----------------------------------------------------------------------
// <copyright file="TunnelPressExtractorAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tunnel PressExtractor Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Services;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;
    using Ecolab.Models.Washers.Tunnel;
    using Ecolab.Services.Washers.Tunnel;

    /// <summary>
    /// TunnelPressExtractorAdminRequest
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceTunnelPressExtractor)]
    public class TunnelPressExtractorAdminRequest : TcdAdminRequestBase<PressExtractor>
    {
        private static readonly ILog Log = LogManager.GetLogger("TunnelPressExtractorAdminRequest");

        public TunnelPressExtractorAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(TunnelWaterFlowType);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            Log.Info("TunnelPressExtractor: Processing MyService data to Local");
            Log.Info("TunnelPressExtractor: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            TunnelGeneralServices tunnelGeneralService = new TunnelGeneralServices();
            tunnelGeneralService.SaveTunnelPressExtractorDetails(this.mPayloadList);
            Log.Info("TunnelPressExtractor: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(this.mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}