﻿// -----------------------------------------------------------------------
// <copyright file="ChainFormulaAdminRequest.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>Chain Formula Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Services;
    using log4net;

    [MessageType(TcdAdminMessageTypes.TcdUpdateChainFormula)]
    public class ChainFormulaAdminRequest : TcdAdminRequestBase<ChainFormula>
    {
        private static readonly ILog Log = LogManager.GetLogger("ChainTextileCategoryAdminRequest");

        public ChainFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        public ChainFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        public ChainFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ChainFormula);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            Log.Info("ChainFormula: Processing Central data to Local");
            Log.Info("ChainFormula: Central data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            ProgramMasterService programMasterService = new ProgramMasterService();
            programMasterService.SaveChainFormulaDetails(mPayloadList);
            Log.Info("ChainFormula: Saved Central data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<ChainFormula>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
