﻿// -----------------------------------------------------------------------
// <copyright file="RewashReasonAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Chain TextileCategory Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models.ManualInput.Rewash;
    using Ecolab.Services;
    using Ecolab.Services.ManualInput;
    using log4net;

    [MessageType(TcdAdminMessageTypes.TcdUpdateRewashReasons)]
    public class RewashReasonAdminRequest : TcdAdminRequestBase<RewashReason>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("RewashReasonAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public RewashReasonAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public RewashReasonAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public RewashReasonAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<RewashReason>(mPayload); ;
        }

        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            _log.Info("RewashReason: Processing Central Master data to Local");
            _log.Info("RewashReason: Central Master data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            try
            {
                ManualRewashService rewashService = new ManualRewashService();
                rewashService.SaveRewashReason(mPayloadList);
                _log.Info("RewashReason: Central Master data: to Local");
                return TcdErrCodes.Success;
            }
            catch (Exception ex)
            {
                _log.Info("RewashReason: Central Master data: to Local fail : " + ex.Message);
                return TcdErrCodes.UpdateFailure;
            }
        }
    }
}
