﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainProgramAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant ChainProgram Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Serialization.Formatters.Binary;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Services;
    using Ecolab.Services.PlantSetup;
    using log4net;

    [MessageType(TcdAdminMessageTypes.TcdUpdatePlantChainProgram)]
    public class PlantChainProgramAdminRequest : TcdAdminRequestBase<PlantChainProgram>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("PlantChainProgramAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public PlantChainProgramAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public PlantChainProgramAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public PlantChainProgramAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PlantChainProgram);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            _log.Info("PlantChainProgram: Processing MyService data to Local");
            _log.Info("PlantChainProgram: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            ProgramMasterService programMasterService = new ProgramMasterService();
            programMasterService.SavePlantChainProgramDetails(mPayloadList, adminRequestHeader.UserId);
            _log.Info("PlantChainProgram: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<PlantChainProgram>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

    }
}
