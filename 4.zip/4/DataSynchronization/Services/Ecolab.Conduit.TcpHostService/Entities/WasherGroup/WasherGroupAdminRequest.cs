﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherGroupAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using Ecolab.Services.WasherGroup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.WasherGroup
{

    [MessageType(TcdAdminMessageTypes.TcdAddWasherGroup)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateWasherGroup)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteWasherGroup)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceWasherGroup)]
    public class WasherGroupAdminRequest : TcdAdminRequestBase<Ecolab.Models.WasherGroup.WasherGroup>
    {

        private static readonly ILog Log = LogManager.GetLogger("WasherGroupAdminRequest");
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public WasherGroupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
        }

        public WasherGroupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Ecolab.Models.WasherGroup.WasherGroup);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp = System.DateTime.UtcNow;
            WasherGroupService washerGroupService = new WasherGroupService();
            int i;
            if (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdUpdateMyServiceWasherGroup)
            {
                Log.Info("WasherGroup: Processing My Service data to Local.");
                Log.Info("WasherGroup: My Service data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));
                i = washerGroupService.SaveMyServiceWasherGroupDetails(mPayload, adminRequestHeader.UserId, out errorCode, out lastModifiedTimeStamp);
            }
            else
            {
                Log.Info("WasherGroup: Synch started...Saving in Local.");
                Log.Info("WasherGroup: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));
                i = washerGroupService.ValidateAndSaveWasherGroupDetails(mPayload, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
                Id = i;
            }

            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("WasherGroup: Synch successful.");
                mPayload.WasherGroupId = i;
                mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Ecolab.Models.WasherGroup.WasherGroup>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("WasherGroup: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("WasherGroup: Getting List of data for resynch..");
            WasherGroupService washerGroupService = new WasherGroupService();
            psm.WasherGroupList = washerGroupService.GetWasherGroupDetailsForResync(null, plant.EcoalabAccountNumber, true);
            psm.WasherGroupList.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            Log.Info("WasherGroup: Resynch data: " + xmlData);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdWasherGroupResync;
        }

    }
}
