﻿// -----------------------------------------------------------------------
// <copyright file="CopyFormulaAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CopyFormulaAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.SyncMessages;
using Ecolab.Models.WasherGroup;
using Ecolab.Services;
using Ecolab.Services.WasherGroup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.WasherGroup
{
    using Models.NavigationMenu;

    [MessageType(TcdAdminMessageTypes.TcdCopyFormula)]
    public class CopyFormulaAdminRequest : TcdAdminRequestBase<CopyFormulaContainer>
    {
        private static readonly ILog Log = LogManager.GetLogger("CopyFormulaAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public CopyFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
        }

        public CopyFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(CopyFormulaContainer);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;

            WasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            if (base.CheckContainerResync(mPayload.LastModifiedTimestampAtCentral, mPayload.EcolabAccountNumber, string.Empty))
            {
                return TcdErrCodes.RecordNotInSynch;
            }
            Id = washerGroupFormulaService.ValidateAndSaveCopyFormula(mPayload, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode);
            TcdErrCodes result = (TcdErrCodes)errorCode;

            if (result == TcdErrCodes.Success)
            {
                Log.Info("WasherGroup Copy Formula: Synch successful.");
                return TcdErrCodes.ResyncImportFormula;
            }

            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<CopyFormulaContainer>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("WasherGroupFormula: Resynch started...");

            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("WasherGroupFormula: Getting List of data for resynch..");

            WasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            WasherGroupService washerGroupService = new WasherGroupService();
            List<Ecolab.Models.WasherGroup.WasherGroup> lstWasherGroup = new List<Ecolab.Models.WasherGroup.WasherGroup>();
            lstWasherGroup = washerGroupService.GetWasherGroupDetailsForResync(null, plant.EcoalabAccountNumber, true);
            lstWasherGroup = lstWasherGroup.Where(n => n.WasherGroupTypeName == "Conventional").ToList();
            List<WasherFormulaModel> lstWasherFormula = new List<WasherFormulaModel>();
            psm.WasherFormulaList = new List<WasherFormulaModel>();
            if (lstWasherGroup != null && lstWasherGroup.Count != 0)
            {
                foreach (Ecolab.Models.WasherGroup.WasherGroup washerGroup in lstWasherGroup)
                {
                    lstWasherFormula = washerGroupFormulaService.GetWasherGroupFormulaResync(plant.EcoalabAccountNumber, washerGroup.WasherGroupId, 0, true);

                    if (lstWasherFormula != null && lstWasherFormula.Count != 0)
                    {
                        psm.WasherFormulaList.AddRange(lstWasherFormula);
                    }
                }
                psm.WasherFormulaList.ForEach(c => c.washerFormula.LastModifiedTime = DateTime.SpecifyKind(c.washerFormula.LastModifiedTime, DateTimeKind.Utc));
            }

            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);

            Log.Info("WasherGroupFormula: Resynch data: " + xmlData);

            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            throw new NotImplementedException();
        }
    }
}