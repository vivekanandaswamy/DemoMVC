﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWasherGroupFormulaAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelWasherGroupFormulaAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.SyncMessages;
using Ecolab.Models.WasherGroup;
using Ecolab.Services;
using Ecolab.Services.WasherGroup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.WasherGroup
{
    [MessageType(TcdAdminMessageTypes.TcdAddTunnelFormula)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateTunnelFormula)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteTunnelFormula)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateTunnelFormulaWashStep)]
    [MessageType(TcdAdminMessageTypes.TcdTunnelGroupFormulaResync)]
    [MessageType(TcdAdminMessageTypes.TcdAddTunnelFormulaFromMyService)]
    public class TunnelWasherGroupFormulaAdminRequest : TcdAdminRequestBase<TunnelFormulaModel>
    {
        private static readonly ILog Log = LogManager.GetLogger("TunnelWasherGroupFormulaAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public TunnelWasherGroupFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
        }
        public TunnelWasherGroupFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
        }
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(TunnelFormulaModel);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp = System.DateTime.UtcNow;

            Log.Info("TunnelFormula: Synch started...Saving in Local.");
            Log.Info("TunnelFormula: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

            WasherGroupFormulaService washerGroupService = new WasherGroupFormulaService();
            int i = washerGroupService.ValidateAndSaveTunnelFormula(mPayload, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("TunnelFormula: Synch successful.");
                if (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdAddTunnelFormula)
                {
                    mPayload.tunnelFormula.Id = i;
                    Id = i;
                }
                mPayload.tunnelFormula.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.tunnelFormula.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            WasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            TunnelFormulaModel tunnelModel = washerGroupFormulaService.GetTunnelGroupFormulaResync(mPayload.tunnelFormula.EcolabAccountNumber, mPayload.tunnelFormula.WasherGroupId, mPayload.tunnelFormula.Id, true).FirstOrDefault();
            return SerializeHelper.Serialize<TunnelFormulaModel>(tunnelModel);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("TunnelFormula: Resynch started...");

            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("TunnelFormula: Getting List of data for resynch..");

            WasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            WasherGroupService washerGroupService = new WasherGroupService();
            List<Ecolab.Models.WasherGroup.WasherGroup> lstWasherGroup = new List<Ecolab.Models.WasherGroup.WasherGroup>();
            lstWasherGroup = washerGroupService.GetWasherGroupDetailsForResync(null, plant.EcoalabAccountNumber, true);
            lstWasherGroup = lstWasherGroup.Where(n => n.WasherGroupTypeName == "Tunnel").ToList();
            List<TunnelFormulaModel> lstTunnelFormula = new List<TunnelFormulaModel>();
            psm.TunnelFormulaList = new List<TunnelFormulaModel>();
            if (lstWasherGroup != null && lstWasherGroup.Count != 0)
            {
                foreach (Ecolab.Models.WasherGroup.WasherGroup washerGroup in lstWasherGroup)
                {
                    lstTunnelFormula = washerGroupFormulaService.GetTunnelGroupFormulaResync(plant.EcoalabAccountNumber, washerGroup.WasherGroupId, 0, true);
                    if (lstTunnelFormula != null && lstTunnelFormula.Count != 0)
                    {
                        psm.TunnelFormulaList.AddRange(lstTunnelFormula);
                        psm.TunnelFormulaList.ForEach(t => t.tunnelFormula.LastModifiedTime = DateTime.SpecifyKind(t.tunnelFormula.LastModifiedTime, DateTimeKind.Utc));
                    }
                }
            }
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            Log.Info("TunnelFormula: Resynch data: " + xmlData);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdTunnelGroupFormulaResync;
        }
    }
}
