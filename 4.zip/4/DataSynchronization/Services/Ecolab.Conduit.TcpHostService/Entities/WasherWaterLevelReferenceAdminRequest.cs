﻿// -----------------------------------------------------------------------
// <copyright file="WasherWaterLevelReferenceAdminRequest.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherWaterLevelReferenceAdminRequest</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Services;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;
    using Ecolab.Models.Washers.Tunnel;
    using Ecolab.Services.Washers.Tunnel;

    /// <summary>
    /// Class for WasherWaterLevelReferenceAdminRequest
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestBase{Ecolab.Models.WasherWaterLevelReference}" />
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceWasherWaterLevelReference)]
    public class WasherWaterLevelReferenceAdminRequest : TcdAdminRequestBase<WasherWaterLevelReference>
    {
        /// <summary>
        /// The log for WasherWaterLevelReferenceAdminRequest
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("WasherWaterLevelReferenceAdminRequest");

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherWaterLevelReferenceAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload for WasherWaterLevelReferenceAdminRequest</param>
        /// <param name="isListObject">List object for WasherWaterLevelReferenceAdminRequest</param>
        public WasherWaterLevelReferenceAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        /// <summary>
        /// Gets type of the Entity
        /// </summary>
        /// <param name="version">Plant app Version</param>
        /// <returns>
        /// Returns the Type
        /// </returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(TunnelWaterFlowType);
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>Returns the error codes</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            Log.Info("WasherWaterLevelReference: Processing MyService data to Local");
            Log.Info("WasherWaterLevelReference: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            TunnelGeneralServices tunnelGeneralService = new TunnelGeneralServices();
            tunnelGeneralService.SaveWasherWaterLevelReferenceDetails(this.mPayloadList);
            Log.Info("WasherWaterLevelReference: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>EcolabAccountNumberInternal</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>Returns the byte array</returns>
        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(this.mPayload);
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>Returns the byte array</returns>
        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>Returns the integer value</returns>
        protected override int GetResyncTypeInternal()
        {
            return 0;
        }
    }
}
