﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The UserManagementAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using System.Linq;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.PlantSetup.UserManagement;
    using Models.SyncMessages;
    using Services;   
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdAddUserManagement)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateUserManagement)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteUserManagement)]
    public class UserManagementAdminRequest : TcdAdminRequestBase<UserManagement>
    {
        private static readonly ILog Log = LogManager.GetLogger("UserManagementAdminRequest");
        private TcdAdminRequestHeader adminRequestHeader;

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public UserManagementAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
        }

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        public UserManagementAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
        }

        /// <summary>
        ///     Gets the type of the Meter entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(UserManagement);
        }

        /// <summary>
        ///     Process the Meters request
        /// </summary>
        /// <param name="outputStream">Stream</param>
        /// <returns>TcdErrorCodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            Log.Info("User Management: Sync data: " + ImportExportUtility.SerializeToJsonFromEntity(this.mPayload));
            UserManagementService userManagementService = new UserManagementService();

            int i = userManagementService.ValidateAndSaveUserManagementDetails(mPayload, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            Id = i;
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("User Management: Saving to Local SUCCESS..");
                if (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdAddUserManagement)
                {
                    mPayload.UserNumber = i;
                    Log.Info("UserId:" + i);
                }
                mPayload.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            else
            {
                Log.Info("User Management: Saving to Local FAILED..." + result);
            }
            return result;
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("User Management: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            Log.Info("User Management: Getting list of Data for ReSync..");
            UserManagementService userManagementService = new UserManagementService();
            psm.UserManagementList = userManagementService.FetchUserManagementDetails(null, plant.EcoalabAccountNumber).ToList();
            psm.UserManagementList.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity(psm);
            Log.Info("User Management: Resynch data: " + jsonData);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdUserManagementResync;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<UserManagement>(mPayload);
        }
    }
}
