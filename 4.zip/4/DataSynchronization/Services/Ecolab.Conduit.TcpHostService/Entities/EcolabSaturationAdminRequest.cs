﻿// -----------------------------------------------------------------------
// <copyright file="EcolabSaturationAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Ecolab Saturation Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.Serialization.Formatters.Binary;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Services;
    using Ecolab.Services.PlantSetup;
    using log4net;    

    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceEcolabSaturation)]
    public class EcolabSaturationAdminRequest : TcdAdminRequestBase<EcolabSaturation>
    {
        private static readonly ILog Log = LogManager.GetLogger("EcolabSaturationAdminRequest");

        public EcolabSaturationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        public EcolabSaturationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        public EcolabSaturationAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(EcolabSaturation);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            ProgramMasterService programMasterService = new ProgramMasterService();
            Log.Info("Ecolab Saturation: Processing MyService data to Local");
            Log.Info("Ecolab Saturation: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            programMasterService.SaveEcolabSaturationDetails(mPayloadList);
            Log.Info("Ecolab Saturation: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<EcolabSaturation>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null; 
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }

    }
}
