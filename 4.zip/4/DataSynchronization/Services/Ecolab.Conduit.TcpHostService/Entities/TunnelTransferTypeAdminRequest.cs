﻿// -----------------------------------------------------------------------
// <copyright file="TunnelTransferTypeAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tunnel TransferType Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Services;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;
    using Ecolab.Models.Washers.Tunnel;
    using Ecolab.Services.Washers.Tunnel;

    /// <summary>
    /// TunnelTransferTypeAdminRequest
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceTunnelTransferType)]
    public class TunnelTransferTypeAdminRequest : TcdAdminRequestBase<PressExtractor>
    {
        private static readonly ILog Log = LogManager.GetLogger("TunnelTransferTypeAdminRequest");

        public TunnelTransferTypeAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(TunnelWaterFlowType);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            Log.Info("TunnelTransferType: Processing MyService data to Local");
            Log.Info("TunnelTransferType: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            TunnelGeneralServices tunnelGeneralService = new TunnelGeneralServices();
            tunnelGeneralService.SaveTunnelTransferTypeDetails(this.mPayloadList);
            Log.Info("TunnelTransferType: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(this.mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}