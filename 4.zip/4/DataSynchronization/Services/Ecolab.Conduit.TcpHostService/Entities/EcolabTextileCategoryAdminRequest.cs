﻿// -----------------------------------------------------------------------
// <copyright file="EcolabTextileCategoryAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Ecolab TextileCategory Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.Runtime.Serialization.Formatters.Binary;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Services;
    using Ecolab.Services.PlantSetup;
    using log4net;
    
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceEcolabTextileCategory)]
    public class EcolabTextileCategoryAdminRequest : TcdAdminRequestBase<EcolabTextileCategory>
    {
        private static readonly ILog Log = LogManager.GetLogger("EcolabTextileCategoryAdminRequest");

        public EcolabTextileCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        public EcolabTextileCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        public EcolabTextileCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(EcolabTextileCategory);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            Log.Info("EcolabTextileCategory: Processing MyService data to Local");
            Log.Info("EcolabTextileCategory: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            ProgramMasterService programMasterService = new ProgramMasterService();
            programMasterService.SaveEcolabTextileCategoryDetails(mPayloadList);
            Log.Info("EcolabTextileCategory: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<EcolabTextileCategory>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }

    }
}
