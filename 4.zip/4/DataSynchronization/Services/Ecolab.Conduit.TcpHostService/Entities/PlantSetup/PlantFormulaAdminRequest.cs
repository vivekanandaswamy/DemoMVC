﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Formula Admin Request handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.SyncMessages;
    using Services;

    /// <summary>
    /// Class PlantFormulaAdminRequest.
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdAddPlantFormula)]
    [MessageType(TcdAdminMessageTypes.TcdUpdatePlantFormula)]
    [MessageType(TcdAdminMessageTypes.TcdDeletePlantFormula)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePlantFormula)]
    public class PlantFormulaAdminRequest : TcdAdminRequestBase<Formula>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("PlantFormulaAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload</param>
        public PlantFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PlantFormulaAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="adminHeader">The admin header.</param>
        /// <param name="appVersion">The application version.</param>
        public PlantFormulaAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        /// <summary>
        /// Gets type of the Entity
        /// </summary>
        /// <param name="version">Plant app Version</param>
        /// <returns>Type</returns>
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Formula);
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>TcdErrCodes.</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode = 0;
            int i = 0;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            ProgramMasterService programMasterService = new ProgramMasterService();
            if (pHeader.MessageType == TcdAdminMessageTypes.TcdUpdateMyServicePlantFormula)
            {
                Log.Info("PlantFormula: Processing My Service data to Local.");
                Log.Info("PlantFormula: My Service data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));
                i = programMasterService.SaveMyServicePlantFormulaDetails(mPayload, pHeader.UserId, out errorCode, out lastModifiedTimeStamp);
            }
            else
            {
                i = programMasterService.ValidateAndSavePlantFormulaDetails(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            }
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                if ((pHeader.MessageType == TcdAdminMessageTypes.TcdAddPlantFormula) || (pHeader.MessageType == TcdAdminMessageTypes.TcdUpdateMyServicePlantFormula))
                {
                    mPayload.ProgramId = i;
                }
                List<Formula> formulaList = new List<Formula>();
                formulaList = programMasterService.GetPlantFormulasForSync(mPayload.ProgramId, mPayload.EcolabAccountNumber);
                if (formulaList != null && formulaList.Count > 0)
                {
                    mPayload = formulaList.FirstOrDefault();
                    mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(mPayload.LastModifiedTimeStamp, DateTimeKind.Utc);
                }
            }
            return result;
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>System.String.</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>System.Byte[].</returns>
        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Formula>(mPayload);
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>System.Byte[].</returns>
        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            ProgramMasterService programMasterService = new ProgramMasterService();
            psm.FormulaList = programMasterService.GetPlantFormulasForSync(null, plant.EcoalabAccountNumber);
            psm.FormulaList.ForEach(c => c.LastModifiedTimeStamp = DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>System.Int32.</returns>
        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdPlantContactResync;
        }
    }

}
