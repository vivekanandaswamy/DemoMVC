﻿// -----------------------------------------------------------------------
// <copyright file="UtilityAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Utility Admin Request handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;    
    using Models;
    using Models.PlantSetup;
    using Models.SyncMessages;
    using Services;
    using Services.PlantSetup;

    [MessageType(TcdAdminMessageTypes.TcdAddUtility)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateUtility)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteUtility)]
    public class UtilityAdminRequest : TcdAdminRequestBase<Utility>
    {
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;
        private readonly ILog Log = LogManager.GetLogger("UtilityAdminRequest");
        public UtilityAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public UtilityAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Utility);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            UtilityService utilityService = new UtilityService();
            int i = utilityService.ValidateAndSaveUtilityDetails(mPayload, adminRequestHeader.UserId,
                adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                mPayload.Id = i;
                mPayload.LastModifiedTimeStamp = lastModifiedTimeStamp;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Utility>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            PlantService plantService = new PlantService();
            Plant plant = plantService.GetPlantDetails();
            UtilityService utilityService = new UtilityService();
            psm.WaterAndEnergyUtilityList = utilityService.GetUtilityDetailsforResync(plant.EcoalabAccountNumber);
            psm.WaterAndEnergyUtilityList.ForEach(c => DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdPlantUtilityResync;
        }
    }
}
