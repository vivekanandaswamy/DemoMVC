﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Customer Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Services;
    using log4net;    
    using Models.SyncMessages;

    [MessageType(TcdAdminMessageTypes.TcdAddPlantCustomer)]
    [MessageType(TcdAdminMessageTypes.TcdUpdatePlantCustomer)]
    [MessageType(TcdAdminMessageTypes.TcdDeletePlantCustomer)]
    public class PlantCustomerAdminRequest : TcdAdminRequestBase<PlantCustomer>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("PlantCustomerAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        public PlantCustomerAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public PlantCustomerAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PlantCustomer);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;;
            PlantCustomerService plantCustomerService = new PlantCustomerService();
            int i = plantCustomerService.ValidateAndSavePlantCustomerDetails(mPayload, pHeader.UserId,
                pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            Id = i;
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                mPayload.Id = i;
                mPayload.LastModifiedTimeStamp = lastModifiedTimeStamp;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcoalabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<PlantCustomer>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            PlantCustomerService plantCustomerService = new PlantCustomerService();
            psm.PlantCustomerList = plantCustomerService.GetPlantCustomer(plant.EcoalabAccountNumber);
            psm.PlantCustomerList.ForEach(c => c.LastModifiedTimeStamp = DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdPlantCustomerResync;
        }
    }
}
