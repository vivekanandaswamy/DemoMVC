﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilitySetupAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Utility Setup Admin Request handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.PlantSetup;
    using Models.SyncMessages;
    using Services;
    using Services.PlantSetup;
    using Host = Ecolab.Conduit.TcpHostService.Common;

    [MessageType(TcdAdminMessageTypes.TcdUpdateUtilityFactor)]
    public class PlantUtilitySetupAdminRequest : Host.TcdAdminRequestBase<PlantUtilityContainer>
    {
        private Host.TcdAdminRequestHeader pHeader;
        //private TcdAdminMessageTypes mType;
        private readonly ILog Log = LogManager.GetLogger("PlantUtilitySetupAdminRequest");

        public PlantUtilitySetupAdminRequest(ILog logger, Host.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

        public PlantUtilitySetupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PlantUtilityContainer);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            Log.Info("Plant Utility factor Types Sync data: " + ImportExportUtility.SerializeToJsonFromEntity(this.mPayload));
            int errorCode;
			if (base.CheckContainerResync(mPayload.LastModifiedTimestampAtCentral, mPayload.PlantUtilityFactorTypes.FirstOrDefault().EcolabAccountNumber, string.Empty))
			{
				return TcdErrCodes.RecordNotInSynch;
			}
            PlantUtilityService utilityService = new PlantUtilityService();
            utilityService.ValidateAndSavePlantUtility(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("Plant Utility factor Types: Saving to Local is Success");
                mPayload.PlantUtilityFactorTypes.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc));
            }
            else
            {
                Log.Info("Plant Utility factor Types: Saving to Local is failed" + result);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            if (mPayload.PlantUtilityFactorTypes != null && mPayload.PlantUtilityFactorTypes.Count > 0)
            {
                return mPayload.PlantUtilityFactorTypes.FirstOrDefault().EcolabAccountNumber;
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        protected override byte[] GetPayloadInternal()
        {
            PlantUtilityService plantUtilityService = new PlantUtilityService();
            PlantUtilityContainer plantUtilityContainer = new PlantUtilityContainer();
            if (mPayload.PlantUtilityFactorTypes != null && mPayload.PlantUtilityFactorTypes.Count > 0)
            {
                plantUtilityContainer.PlantUtilityFactorTypes = plantUtilityService.GetPlantUtilityDetails(mPayload.PlantUtilityFactorTypes.FirstOrDefault().EcolabAccountNumber);
                plantUtilityContainer.PlantUtilityFactorTypes.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc)); 
            }

            return SerializeHelper.Serialize<PlantUtilityContainer>(plantUtilityContainer);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("Plant Utility Resync Started");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            Log.Info("Plant Utility Factor Types: Getting list of Data for ReSync..");
			PlantUtilityService plantUtilityService = new PlantUtilityService();
			PlantUtilityContainer plantUtilityContainer = new PlantUtilityContainer();
			psm.PlantUtilityContainerList = new List<PlantUtilityContainer>();
			plantUtilityContainer.PlantUtilityFactorTypes = plantUtilityService.GetPlantUtilityDetails(plant.EcoalabAccountNumber);
			plantUtilityContainer.PlantUtilityFactorTypes.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
			psm.PlantUtilityContainerList.Add(plantUtilityContainer);
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity(psm);
            Log.Info("Plant Utility Factor Types: Resynch data: " + jsonData);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdPlantUtilityResync;
        }
    }
}
