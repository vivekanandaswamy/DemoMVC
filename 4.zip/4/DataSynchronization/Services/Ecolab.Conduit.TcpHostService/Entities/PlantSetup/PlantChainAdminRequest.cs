﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Chain Admin Request handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Services;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    /// <summary>
    /// PlantChainAdminRequest
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePlantChain)]
    public class PlantChainAdminRequest : TcdAdminRequestBase<PlantChain>
    {
        private static readonly ILog Log = LogManager.GetLogger("PlantChainAdminRequest");

        /// <summary>
        /// Admin request constructor for Myservice Master Data
        /// </summary>
        /// <param name="logger">logger object</param>
        /// <param name="adminHeader">admin header</param>
        /// <param name="appVersion">App Version</param>
        /// <param name="inputBuffer">input Buffer</param>
        /// <param name="isListObject">Is List object</param>
        public PlantChainAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PlantChain);
        }

        /// <summary>
        /// ProcessMessageInternal
        /// </summary>
        /// <param name="outputStream">outputStream</param>
        /// <returns>Tcd error codes for success/failure</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            PlantService plantData = new PlantService();
            Log.Info("PlantChain: Processing MyService data to Local");
            Log.Info("PlantChain: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            plantData.SaveMyServicePlantChainDetails(this.mPayloadList);
            Log.Info("PlantChain: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize(this.mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}