﻿// -----------------------------------------------------------------------
// <copyright file="PlantProductStandardPriceAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Chemical Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup.Chemical;
    using Ecolab.Services;
    using log4net;
    using Models.SyncMessages;
    
   // [MessageType(TcdAdminMessageTypes.TcdAddPlantChemical)]
   // [MessageType(TcdAdminMessageTypes.TcdUpdatePlantChemical)]
   // [MessageType(TcdAdminMessageTypes.TcdDeletePlantChemical)]
  //  [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceProductMasterDetails)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePlantProductStandardPrice)]
    public class PlantProductStandardPriceAdminRequest : TcdAdminRequestBase<ProductStandardPrice>
    {
        private readonly ILog Log = LogManager.GetLogger("PlantProductStandardPriceAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        public PlantProductStandardPriceAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

        public PlantProductStandardPriceAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public PlantProductStandardPriceAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            pHeader = adminHeader;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ProductStandardPrice);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            TcdErrCodes result = TcdErrCodes.Success;
            DateTime lastModifiedTimeStamp;
            try
            {

                ProductMasterService productMasterService = new ProductMasterService();
                if (pHeader.MessageType == TcdAdminMessageTypes.TcdUpdateMyServicePlantProductStandardPrice)
                {
                    Log.Info("Proccessing TcdUpdateMyServiceProductMasterDetails AdminMessageType");
                    mPayload.Id= productMasterService.SaveMyServiceProductStandardPrice(mPayload, out lastModifiedTimeStamp);
                    mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                }
                //else
                //{
                //    i = productMasterService.ValidateAndSavePlantChemicalDetails(mPayload, pHeader.UserId,
                //        pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
                //    result = (TcdErrCodes) errorCode;
                //    if (result == TcdErrCodes.Success)
                //    {
                //        mPayload.Id = i;
                //        mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                //    }
                //}
            }
            catch (Exception ex)
            {
                Log.Error("Process sync message failed for Plant chemicals with error: " + ex.Message);
                throw;
            }

            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<ProductStandardPrice>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            ProductMasterService productMasterService = new ProductMasterService();
            psm.ProductStandardPriceList = productMasterService.FetchPlantProductStandardPriceForReSync(plant.EcoalabAccountNumber);
            foreach (var item in psm.ProductStandardPriceList)
            {
                item.LastModifiedTimeStamp = DateTime.SpecifyKind(item.LastModifiedTimeStamp, DateTimeKind.Utc);
            }
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdProductStandardPriceResync;
        }
    }
}
