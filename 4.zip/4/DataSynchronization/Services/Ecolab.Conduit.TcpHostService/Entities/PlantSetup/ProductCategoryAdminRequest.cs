﻿// -----------------------------------------------------------------------
// <copyright file="ProductCategoryAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Product Category Admin Request handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using Common;
    using Library.Common;
    using Library.Enums;
    using log4net;
    using Models.PlantSetup.Chemical;
    using Services;
    
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceProductCategory)]
    public class ProductCategoryAdminRequest : TcdAdminRequestBase<ProductMaster>
    {
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader _pHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("ProductCategoryAdminRequest");
        public ProductCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public ProductCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public ProductCategoryAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ProductMaster);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            ProductMasterService productMasterServices = new ProductMasterService();
            productMasterServices.SaveProductCategoryDetails(mPayloadList);
            return TcdErrCodes.Success;
        }
        
        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
			return null;
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

    }
}
