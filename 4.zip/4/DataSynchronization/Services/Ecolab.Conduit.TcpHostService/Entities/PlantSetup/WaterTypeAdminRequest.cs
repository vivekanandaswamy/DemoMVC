﻿// -----------------------------------------------------------------------
// <copyright file="WaterTypeAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Device Model Water Type Admin Request handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models.PlantSetup;
    using Services.PlantSetup;    

    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceWaterType)]
    public class WaterTypeAdminRequest : TcdAdminRequestBase<PlantUtilityWaterTypeMaster>
    {
        private readonly ILog _log = LogManager.GetLogger("WaterTypeAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public WaterTypeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            _log = logger;
            adminRequestHeader = adminHeader;
        }

        public WaterTypeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            _log = logger;
            adminRequestHeader = adminHeader;
        }

        public WaterTypeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PlantUtilityWaterTypeMaster);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            PlantUtilityService utilityService = new PlantUtilityService();
            utilityService.SaveWaterTypeDetails(mPayloadList);
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<PlantUtilityWaterTypeMaster>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
