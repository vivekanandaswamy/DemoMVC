﻿// -----------------------------------------------------------------------
// <copyright file="SensorAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.PlantSetup;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using Ecolab.Services.PlantSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup.Sensor
{
    [MessageType(TcdAdminMessageTypes.TcdAddSensor)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateSensor)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteSensor)]
    public class SensorAdminRequest : TcdAdminRequestBase<Ecolab.Models.PlantSetup.Sensor>
    {
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("SensorAdminRequest");

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public SensorAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        public SensorAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        /// <summary>
        /// Gets the type of the Meter entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(SensorModel);
        }

        /// <summary>
        /// Process the Meters request
        /// </summary>
        /// <param name="outputStream">Stream</param>
        /// <returns>TcdErrorCodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            SensorService sensorService = new SensorService();

            int i = sensorService.ValidateAndSavePlantSensorDetails(mPayload, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success && adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdAddSensor)
            {
                mPayload.SensorNumber = i;
                mPayload.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            else
            {
                mPayload.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc); 
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            SensorService sensorService = new SensorService();
            SensorModel payLoad = sensorService.GetPlantSensorDetailsBySensorId(mPayload.SensorNumber.Value, mPayload.EcolabAccountNumber);
            payLoad.LastModifiedTime = DateTime.SpecifyKind(payLoad.LastModifiedTime, DateTimeKind.Utc);
            payLoad.ModuleTags = sensorService.GetModuleTagsDetails(mPayload.SensorNumber.Value, 3, mPayload.EcolabAccountNumber);
            return SerializeHelper.Serialize<Ecolab.Models.PlantSetup.SensorModel>(payLoad);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            SensorService ss = new SensorService();
            psm.SensorList = ss.GetPlantSensorDetailsForResync(plant.EcoalabAccountNumber);
            psm.SensorList.ForEach(c => c.LastModifiedTime = DateTime.SpecifyKind(c.LastModifiedTime, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdSensorResync;
        }
    }
}
