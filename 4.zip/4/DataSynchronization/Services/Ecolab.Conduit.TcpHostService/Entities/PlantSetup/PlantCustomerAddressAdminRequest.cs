﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerAddressAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantCustomerAddressAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Services;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePlantAddress)]
    public class PlantCustomerAddressAdminRequest : TcdAdminRequestBase<PlantCustomerAddress>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("PlantCustomerAddressAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader _pHeader;

        public PlantCustomerAddressAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public PlantCustomerAddressAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Plant);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            PlantService plantData = new PlantService();
            plantData.SaveMyServicePlantAddress(mPayload);
            TcdErrCodes result = TcdErrCodes.Success;
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<PlantCustomerAddress>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }

    }
}
