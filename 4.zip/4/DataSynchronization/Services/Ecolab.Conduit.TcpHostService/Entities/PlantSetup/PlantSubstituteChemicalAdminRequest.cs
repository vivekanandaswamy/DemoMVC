﻿// -----------------------------------------------------------------------
// <copyright file="PlantSubstituteChemicalAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Chemical Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
	using System;
	using Ecolab.Conduit.Library.Common;
	using Ecolab.Conduit.Library.Enums;
	using Ecolab.Conduit.Library.Helpers;
	using Ecolab.Conduit.TcpHostService.Common;
	using Ecolab.Models.PlantSetup.Chemical;
	using Ecolab.Services;
	using log4net;

	[MessageType(TcdAdminMessageTypes.TcdSubstituteChemical)]
	public class PlantSubstituteChemicalAdminRequest : TcdAdminRequestBase<SubstituteChemical>
	{
		private readonly ILog Log = LogManager.GetLogger("PlantSubstituteChemicalAdminRequest");
		private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

		public PlantSubstituteChemicalAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
			: base(logger, adminHeader, appVersion, inputBuffer)
		{
			pHeader = adminHeader;
		}

		public PlantSubstituteChemicalAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
			: base(adminHeader, appVersion)
		{
			pHeader = adminHeader;
			Log = logger;
		}

		public PlantSubstituteChemicalAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
			: base(logger, adminHeader, appVersion, inputBuffer, isListObject)
		{
			pHeader = adminHeader;
		}

		public override System.Type GetPayloadType(TcdAppVersion version)
		{
			return typeof(SubstituteChemical);
		}

		protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
		{
			try
			{
				ProductMasterService productMasterService = new ProductMasterService();
				int result = productMasterService.SaveSubstitueChemical(mPayload, this.pHeader.UserId);
				Log.Info("Proccessing TcdUpdateMyServiceProductMasterDetails AdminMessageType");
				if (result == 0)
                {
					return TcdErrCodes.RecordCountNotMatch;
				}
			}
			catch (Exception ex)
			{
				Log.Error("Process sync message failed for Plant chemicals with error: " + ex.Message);
				throw;
			}

			return TcdErrCodes.SaveFailure;
		}

		protected override string GetEcolabAccountNumberInternal()
		{
			return mPayload.EcolabAccountNumber;
		}

		protected override byte[] GetPayloadInternal()
		{
			return SerializeHelper.Serialize<SubstituteChemical>(mPayload);
		}

		protected override byte[] GetResyncDataInternal()
		{
			throw new NotImplementedException();
		}

		protected override int GetResyncTypeInternal()
		{
			throw new NotImplementedException();
		}
	}
}