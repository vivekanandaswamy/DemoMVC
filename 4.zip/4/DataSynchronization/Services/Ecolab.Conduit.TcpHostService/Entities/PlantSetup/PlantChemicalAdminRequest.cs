﻿// -----------------------------------------------------------------------
// <copyright file="PlantChemicalAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Chemical Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using System;
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup.Chemical;
    using Ecolab.Services;
    using log4net;
    using Models.SyncMessages;
    
    [MessageType(TcdAdminMessageTypes.TcdAddPlantChemical)]
    [MessageType(TcdAdminMessageTypes.TcdUpdatePlantChemical)]
    [MessageType(TcdAdminMessageTypes.TcdDeletePlantChemical)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceProductMasterDetails)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePlantChemical)]
    public class PlantChemicalAdminRequest : TcdAdminRequestBase<ProductMaster>
    {
        private readonly ILog Log = LogManager.GetLogger("PlantChemicalAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        public PlantChemicalAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

        public PlantChemicalAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public PlantChemicalAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            pHeader = adminHeader;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ProductMaster);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            int i;
            TcdErrCodes result = TcdErrCodes.Success;
            DateTime lastModifiedTimeStamp;
            try
            {

                ProductMasterService productMasterService = new ProductMasterService();
                if (pHeader.MessageType == TcdAdminMessageTypes.TcdUpdateMyServiceProductMasterDetails)
                {
                    Log.Info("Proccessing TcdUpdateMyServiceProductMasterDetails AdminMessageType");
                    productMasterService.SaveMyServiceProductMasterDetails(mPayloadList);
                }
                else
                {
                    i = productMasterService.ValidateAndSavePlantChemicalDetails(mPayload, pHeader.UserId,
                        pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
                    result = (TcdErrCodes) errorCode;
                    if (result == TcdErrCodes.Success)
                    {
                        mPayload.Id = i;
                        mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Process sync message failed for Plant chemicals with error: " + ex.Message);
                throw;
            }

            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<ProductMaster>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            ProductMasterService productMasterService = new ProductMasterService();
            psm.ChemicalsList = productMasterService.FetchPlantChemicalListForResync(plant.EcoalabAccountNumber);
	        foreach (var item in psm.ChemicalsList)
	        {
		        item.LastModifiedTimeStamp = DateTime.SpecifyKind(item.LastModifiedTimeStamp, DateTimeKind.Utc);
	        }
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdChemicalsResync;
        }
    }
}
