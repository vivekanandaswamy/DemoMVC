﻿// -----------------------------------------------------------------------
// <copyright file="GasOilTypesAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Gas Oil Types Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
	using System;
	using System.Collections.Generic;
	using System.IO;
	using Common;
	using Ecolab.Services;
	using Library.Common;
	using Library.Enums;
	using log4net;
	using Models.PlantSetup;
	using Services.PlantSetup;
	using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    /// <summary>
    ///     GasOilTypesAdminRequest for Myservice
    /// </summary>
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceGasOilTypes)]
    internal class GasOilTypesAdminRequest : TcdAdminRequestBase<PlantUtilityGasoilTypes>
    {
        /// <summary>
        ///     Log object created
        /// </summary>
        private static ILog Log;

        /// <summary>
        ///     GasOilTypesAdminRequest constructor
        /// </summary>
        /// <param name="logger">logger for logging the request</param>
        /// <param name="adminHeader">admin Header</param>
        /// <param name="appVersion">app version</param>
        /// <param name="inputBuffer">input buffer.</param>
        /// <param name="isListObject">for saving the list of records</param>
        public GasOilTypesAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
            byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            Log = logger;
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(List<PlantUtilityGasoilTypes>);
        }

        /// <summary>
        ///     Processing of message to Local
        /// </summary>
        /// <param name="outputStream">output stream.</param>
        /// <returns>TcdError codes for succes/failure.</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            PlantUtilityService plantUtilityService = new PlantUtilityService();
            Log.Info("GasOilTypes: Processing MyService data to Local");
            Log.Info("GasOilTypes: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            plantUtilityService.SaveGasoilTypesDetails(this.mPayloadList);
            Log.Info("GasOilTypes: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
			return null;
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}