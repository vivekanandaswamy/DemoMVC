﻿// -----------------------------------------------------------------------
// <copyright file="DeviceModelAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Device Model Admin Request handler</summary>
// -----------------------------------------------------------------------

using System;
using System.Runtime.Serialization.Formatters.Binary;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.PlantSetup;
using Ecolab.Services;
using Ecolab.Services.PlantSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceDeviceModel)]
    public class DeviceModelAdminRequest : TcdAdminRequestBase<DeviceModel>
    {
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader _pHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("DeviceModelAdminRequest");

        public DeviceModelAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public DeviceModelAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public DeviceModelAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            _pHeader = adminHeader;
            _log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(DeviceModel);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            _log.Info("DeviceModel: Processing MyService data to Local");
            _log.Info("DeviceModel: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));

            UtilityService utilityService = new UtilityService();
            utilityService.SaveDeviceModelDetails(mPayloadList);

            _log.Info("DeviceModel: Saved MyService data to Local");

            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
			return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<DeviceModel>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
			return null;
        }

        protected override int GetResyncTypeInternal()
        {
			return 0;
        }
    }
}
