﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlagAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup.RedFlag
{
    using System;
    using System.Collections.Generic;
	using System.Linq;
	using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Conduit.TcpHostService.Common;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup.RedFlag;
    using Ecolab.Services;
    using Ecolab.Services.PlantSetup;
    using log4net;
    using Models.SyncMessages;

    [MessageType(TcdAdminMessageTypes.TcdAddRedFlag)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateRedFlag)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteRedFlag)]
    public class RedFlagAdminRequest : TcdAdminRequestBase<RedFlag>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("RedFlagAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        public RedFlagAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public RedFlagAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(RedFlag);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            RedFlagService redFlagService = new RedFlagService();
            int i = redFlagService.ValidateAndSaveRedFlagDetails(mPayload, pHeader.UserId,
                pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Id = i;
                if (pHeader.MessageType == TcdAdminMessageTypes.TcdAddRedFlag)
                {
                    mPayload.Id = i;
                }
                mPayload.LastModifiedTimeStamp = lastModifiedTimeStamp;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
			RedFlagService redFlagService = new RedFlagService();
	        List<RedFlag> redFlag = redFlagService.FetchRedFlagDetailsForReSync(mPayload.Id, mPayload.EcolabAccountNumber);
			return SerializeHelper.Serialize<RedFlag>(redFlag.FirstOrDefault());
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            RedFlagService redFlagService = new RedFlagService();
            psm.RedFlagList = redFlagService.FetchRedFlagDetailsForReSync(null, plant.EcoalabAccountNumber);
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdRedFlagResync;
        }
    }
}
