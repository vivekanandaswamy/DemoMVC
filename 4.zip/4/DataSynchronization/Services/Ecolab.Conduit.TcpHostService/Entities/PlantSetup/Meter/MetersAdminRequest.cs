﻿// -----------------------------------------------------------------------
// <copyright file="MetersAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MetersAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup.Meter
{
    using System;
    using System.IO;
    using Common;
    using log4net;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using Models;
    using Models.Common;
    using Models.PlantSetup;
    using Models.SyncMessages;
    using Services;
    using Services.PlantSetup;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdAddMeters)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMeters)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteMeters)]
    public class MetersAdminRequest : TcdAdminRequestBase<Meter>
    {
        /// <summary>
        /// The p header
        /// </summary>
        private TcdAdminRequestHeader pHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("MetersAdminRequest");

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public MetersAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer) : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        public MetersAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion) : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        /// <summary>
        ///     Gets the type of the Meter entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(MeterModel);
        }

        /// <summary>
        ///     Process the Meters request
        /// </summary>
        /// <param name="outputStream">Stream</param>
        /// <returns>TcdErrorCodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            MeterService meterService = new MeterService();

            int i = meterService.ValidateAndSavePlantMeterDetails(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes) errorCode;
            if (result == TcdErrCodes.Success)
            {
                mPayload.MeterId = i;
                mPayload.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            MeterService meterService = new MeterService();
            MeterModel payLoad = meterService.GetPlantMeterDetailsByMeterId(mPayload.MeterId.Value, mPayload.EcolabAccountNumber);
            payLoad.LastModifiedTime = DateTime.SpecifyKind(payLoad.LastModifiedTime, DateTimeKind.Utc);
            ModuleTagsModel objModuleTags = meterService.GetModuleTagsDetails(mPayload.MeterId.Value, 2, mPayload.EcolabAccountNumber);
            if (objModuleTags != null)
            {
                payLoad.ModuleTagId = objModuleTags.ModuleTagId;
                payLoad.TagType = objModuleTags.TagType;
                if (objModuleTags.Active)
                {
                    payLoad.TagAddress = objModuleTags.TagAddress;
                }
                else
                {
                    payLoad.TagAddress = string.Empty;
                }
                payLoad.ModuleTypeId = objModuleTags.ModuleTypeId;
                payLoad.ModuleId = objModuleTags.ModuleId;
                payLoad.DeadBand = objModuleTags.DeadBand;
                payLoad.Active = objModuleTags.Active;
            }
            return SerializeHelper.Serialize(payLoad);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            MeterService ms = new MeterService();
            psm.MeterList = ms.GetPlantMeterDetailsForResync(plant.EcoalabAccountNumber);
            psm.MeterList.ForEach(c => c.LastModifiedTime = DateTime.SpecifyKind(c.LastModifiedTime, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int) TcdAdminMessageTypes.TcdMeterResync;
        }
    }
}