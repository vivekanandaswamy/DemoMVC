﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FinnisherAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Services;
using Ecolab.Services.PlantSetup.Dryer;
using Ecolab.Services.PlantSetup.Finnisher;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    using Models.SyncMessages;

    [MessageType(TcdAdminMessageTypes.TcdAddFinnisher)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateFinnisher)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteFinnisher)]
    public class FinnisherAdminRequest : TcdAdminRequestBase<Ecolab.Models.PlantSetup.Finnisher.Finnisher> 
    {
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("FinnisherAdminRequest");

        public FinnisherAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public FinnisherAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Ecolab.Models.PlantSetup.Finnisher.Finnisher);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            FinnisherService finnisherService = new FinnisherService();

            int i = finnisherService.ValidateAndSaveFinnisherDetails(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                mPayload.FinisherId = i;
                mPayload.LastModifiedTimeStampFinnisher = lastModifiedTimeStamp;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Ecolab.Models.PlantSetup.Finnisher.Finnisher>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            FinnisherService finnisherService = new FinnisherService();
            psm.FinnisherList = finnisherService.FetchFinnishers(plant.EcoalabAccountNumber);
            psm.FinnisherList.ForEach(c => c.LastModifiedTimeStampFinnisher = DateTime.SpecifyKind(c.LastModifiedTimeStampFinnisher, DateTimeKind.Utc));
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdFinnisherResync;
        }
    }
}
