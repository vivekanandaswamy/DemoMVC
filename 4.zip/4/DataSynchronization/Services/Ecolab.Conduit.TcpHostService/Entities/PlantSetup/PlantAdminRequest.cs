﻿// -----------------------------------------------------------------------
// <copyright file="PlantAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{    

    [MessageType(TcdAdminMessageTypes.TcdUpdatePlant)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePlantDetails)]
    public class PlantAdminRequest : TcdAdminRequestBase<Plant>
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("PlantAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        public PlantAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public PlantAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Plant);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            PlantService plantData = new PlantService();
			DateTime? lastServiceVisitDate = null;
			DateTime? nextServiceVisitDate = null;

			lastServiceVisitDate = mPayload.LastServiceVisitDate;
			nextServiceVisitDate = mPayload.NextServiceVisitDate;

            plantData.ValidateAndSavePlant(mPayload, pHeader.UserId, pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                PlantService plantService = new PlantService();
                mPayload = plantService.GetPlantDetails(mPayload.EcoalabAccountNumber);
                mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(mPayload.LastModifiedTimeStamp, DateTimeKind.Utc);
				mPayload.LastServiceVisitDate = lastServiceVisitDate;
				mPayload.NextServiceVisitDate = nextServiceVisitDate;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcoalabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Plant>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            psm.PlantDetails = plantService.GetPlantDetails(plant.EcoalabAccountNumber);
            psm.PlantDetails.LastModifiedTimeStamp = DateTime.SpecifyKind(psm.PlantDetails.LastModifiedTimeStamp,
                DateTimeKind.Utc); 
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdPlantDetailsResync;
        }

    }
}
