﻿// -----------------------------------------------------------------------
// <copyright file="LaborCostAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>LaborCost Admin Request handler</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.PlantSetup.ShiftLabor;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using Ecolab.Services.PlantSetup.ShiftLabor;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
    
    [MessageType(TcdAdminMessageTypes.TcdAddLaborCost)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateLaborCost)]
    public class LaborCostAdminRequest : TcdAdminRequestBase<LaborCostContainer>
    {
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;
        private readonly ILog Log = LogManager.GetLogger("LaborCostAdminRequest");
        public LaborCostAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public LaborCostAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(LaborCost);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;

            LaborCostService laborCostService = new LaborCostService();
            laborCostService.ValidateAndSaveLaborCost(mPayload.LaborCostList, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);

            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                //mPayload.LaborCostList[0].Id = i;
                mPayload.LaborCostList.ForEach(_ => _.LastModifiedTimeStamp = lastModifiedTimeStamp);
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.LaborCostList[0].EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            LaborCostService laborCostService = new LaborCostService();
            LaborCostContainer laborcostcontainer = new LaborCostContainer();
            laborcostcontainer.LaborCostList = new List<LaborCost>();

            laborcostcontainer.LaborCostList = laborCostService.FetchLaborTypeCostDetails(mPayload.LaborCostList[0].EcolabAccountNumber);

            laborcostcontainer.LaborCostList.ForEach(c => c.LastModifiedTimeStamp = DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            return SerializeHelper.Serialize<LaborCostContainer>(laborcostcontainer);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            LaborCostService laborCostService = new LaborCostService();
            LaborCostContainer laborCostCon = new LaborCostContainer();

            laborCostCon.LaborCostList = laborCostService.FetchLaborTypeCostDetails(plant.EcoalabAccountNumber);
            laborCostCon.LaborCostList.ForEach(c => c.LastModifiedTimeStamp = DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));

            psm.LaborCostContainerList = new List<LaborCostContainer>();
            psm.LaborCostContainerList.Add(laborCostCon);

            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdLaborCostResync;
        }
    }
}
