﻿// -----------------------------------------------------------------------
// <copyright file="ShiftAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Shift Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup
{
	using System;
	using System.Collections.Generic;
	using System.IO;
	using System.Linq;
	using Common;
	using Ecolab.Models;
	using Ecolab.Services;
	using Library.Common;
	using Library.Enums;
	using Library.Helpers;
	using log4net;
	using Models.PlantSetup.ShiftLabor;
	using Models.SyncMessages;
	using Services.PlantSetup.ShiftLabor;
	using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdAddShift)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateShift)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteShift)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteBreak)]
    [MessageType(TcdAdminMessageTypes.TcdAddShiftLabor)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateShiftLabor)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteShiftLabor)]
    public class ShiftAdminRequest : TcdAdminRequestBase<ShiftSyncContainer>
    {
        private readonly ILog Log = LogManager.GetLogger("ShiftAdminRequest");
        private TcdAdminRequestHeader adminRequestHeader;

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">logger</param>
        /// <param name="adminHeader">adminHeader</param>
        /// <param name="appVersion">appVersion</param>
        /// <param name="inputBuffer">inputBuffer</param>
        public ShiftAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            Log = logger;

        }

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        public ShiftAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            Log = logger;
        }

        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ShiftSyncContainer);
        }

        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            TcdErrCodes result = TcdErrCodes.Success;
            ShiftBreakService shiftBreakService = new ShiftBreakService();
            int errorCode;
            DateTime lastModifiedTimeStamp;
            if ((adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdAddShift) || (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdUpdateShift) || (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdDeleteShift) || (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdDeleteBreak))
            {
				if (base.CheckContainerResync(mPayload.LastModifiedTimestampAtCentral, mPayload.Shift.FirstOrDefault().EcolabAccountNumber, string.Empty))
				{
					return TcdErrCodes.RecordNotInSynch;
				}
                Log.Info("Shift: TcdAdminMessageType Recieved: " + adminRequestHeader.MessageType);
                string outErrorCode = shiftBreakService.ValidateAndSaveShiftBreakDetails(mPayload.Shift, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
                result = (TcdErrCodes)errorCode;
                if (result == TcdErrCodes.Success)
                {
                    int shiftId = mPayload.Shift.FirstOrDefault().Id > 0 ? mPayload.Shift.FirstOrDefault().Id : mPayload.Shift.FirstOrDefault().ShiftId.Value;
                    Log.Info("Shift: Data Saved to Local Successfully: new Shift Id: " + shiftId);
                }
                else
                {
                    Log.Info("Shift: Saving to Local Failed." + result);
                }
            }
            else
            {
                if ((adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdAddShiftLabor) || (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdUpdateShiftLabor) || (adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdDeleteShiftLabor))
                {
					if (base.CheckContainerResync(mPayload.LastModifiedTimestampAtCentral, mPayload.ShiftLabor.FirstOrDefault().EcolabAccountNumber, string.Empty))
					{
						return TcdErrCodes.RecordNotInSynch;
					}
                    Log.Info("Shift: Labor: TcdAdminMessageType Recieved: " + adminRequestHeader.MessageType);
                    LaborService laborService = new LaborService();
                    int i = laborService.ValidateAndSaveShiftLaborDetails(mPayload.ShiftLabor, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode);
                    int laborId = mPayload.ShiftLabor.FirstOrDefault().LaborId > 0 ? mPayload.ShiftLabor.FirstOrDefault().LaborId.Value : 0;
                    result = (TcdErrCodes)errorCode;
                    if (result == TcdErrCodes.Success)
                    {
	                    Id = i; // this is the error code.
                        Log.Info("Shift: LaborData: Data saved to Local Successfully: new laborId: " + laborId);
                    }
                    else
                    {
                        Log.Info("Shift: LaborData: Saving to Local Failed." + result);
                    }
                }
            }
            return result;
        }
        protected override string GetEcolabAccountNumberInternal()
        {
            if (mPayload.Shift != null && mPayload.Shift.Count > 0)
            {
                return mPayload.Shift.FirstOrDefault().EcolabAccountNumber; 
            }
            else if (mPayload.ShiftLabor != null && mPayload.ShiftLabor.Count > 0)
            {
                return mPayload.ShiftLabor.FirstOrDefault().EcolabAccountNumber;
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        protected override byte[] GetPayloadInternal()
        {
            Log.Info("Shift: Fetching Shift, shiftBreak and Shift Labor data for Sync");
            ShiftSyncContainer syncContainer = new ShiftSyncContainer();

            if (mPayload.Shift != null && mPayload.Shift.Count > 0)
            {
                syncContainer = GetSyncShiftData(mPayload.Shift.FirstOrDefault().EcolabAccountNumber); 
            }
            else if (mPayload.ShiftLabor != null && mPayload.ShiftLabor.Count > 0)
            {
                syncContainer = GetSyncShiftData(mPayload.ShiftLabor.FirstOrDefault().EcolabAccountNumber);
            }
            else
            {
                throw new NotImplementedException();
            }

            Log.Info("Shift: Data Recieved: " + ImportExportUtility.SerializeToJsonFromEntity(syncContainer));
            return SerializeHelper.Serialize(syncContainer);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            psm.ShiftList = new List<ShiftSyncContainer>();
            ShiftSyncContainer syncContainer = new ShiftSyncContainer();
            plant = plantService.GetPlantDetails();
            Log.Info("Shift: Fetching Shift, shiftBreak and Shift Labor data for ReSync");
            syncContainer = GetSyncShiftData(plant.EcoalabAccountNumber);
            
            psm.ShiftList.Add(syncContainer);
            
            Log.Info("Shift: Data Recieved: " + syncContainer);
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity(psm);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdShiftResync;
        }

        public ShiftSyncContainer GetSyncShiftData(string ecolabAccountNumber)
        {
            ShiftSyncContainer syncContainer = new ShiftSyncContainer();
            ShiftBreakService shiftBreakService = new ShiftBreakService();
            LaborService laborService = new LaborService();
            syncContainer.Shift = new List<Shift>();
            syncContainer.ShiftLabor = new List<Models.PlantSetup.ShiftLabor.ShiftLabor>();
            syncContainer.Shift = shiftBreakService.FetchShiftDetailsForSync(null, null, ecolabAccountNumber, true);
            syncContainer.Shift.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
            syncContainer.ShiftLabor = laborService.FetchShiftLaborDetailsForSync(ecolabAccountNumber, true);
            syncContainer.ShiftLabor.ForEach(t => t.LastModifiedTimeStamp = DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
            return syncContainer;
        }
    }
}