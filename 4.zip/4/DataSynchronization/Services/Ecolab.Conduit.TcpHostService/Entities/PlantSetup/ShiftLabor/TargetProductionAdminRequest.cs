﻿// -----------------------------------------------------------------------
// <copyright file="TargetProductionAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Target Production Admin Request handler</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.PlantSetup.ShiftLabor;
    using Models.SyncMessages;
    using Services;
    using Services.PlantSetup.ShiftLabor;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdUpdateTargetProduction)]
    public class TargetProductionAdminRequest : TcdAdminRequestBase<TargetProductionContainer>
    {
        private readonly ILog _log = LogManager.GetLogger("TargetProductionAdminRequest");
        private TcdAdminRequestHeader adminRequestHeader;

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        /// <param name="logger">logger</param>
        /// <param name="adminHeader">adminHeader</param>
        /// <param name="appVersion">appVersion</param>
        /// <param name="inputBuffer">inputBuffer</param>
        public TargetProductionAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        public TargetProductionAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
        }

        /// <summary>
        /// GetPayloadType
        /// </summary>
        /// <param name="version">version</param>
        /// <returns>type of payload</returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(TargetProductionContainer);
        }

        /// <summary>
        /// ProcessMessageInternal
        /// </summary>
        /// <param name="outputStream">outputStream</param>
        /// <returns>errCodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            ShiftBreakService shiftBreakService = new ShiftBreakService();
            _log.Info("TargetProduction: PushToLocal: Message Recieved: " + adminRequestHeader.MessageType);
            shiftBreakService.ValidateAndSaveTargetProductionDetails(mPayload, adminRequestHeader.UserId, adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                _log.Info("TargetProduction: Sync to Local: Success");
            }
            else
            {
                _log.Info("TargetProduction: Sync to Local: Failed");
            }
            return result;
        }

        /// <summary>
        /// GetEcolabAccountNumberInternal
        /// </summary>
        /// <returns>ecolabAccountNumber</returns>
        protected override string GetEcolabAccountNumberInternal()
        {

            if (mPayload.TargetProduction != null && mPayload.TargetProduction.Count > 0)
            {
                return mPayload.TargetProduction.FirstOrDefault().EcolabAccountNumber;
            }
            else
            {
                throw new NotImplementedException();
            }
            
        }

        /// <summary>
        /// GetPayloadInternal
        /// </summary>
        /// <returns>payload for Sync</returns>
        protected override byte[] GetPayloadInternal()
        {
            TargetProductionContainer targetProductionContainer  = new TargetProductionContainer();
            if (mPayload.TargetProduction != null && mPayload.TargetProduction.Count > 0)
            {
                targetProductionContainer =
                    this.GetTargetProductionSyncData(mPayload.TargetProduction.FirstOrDefault().EcolabAccountNumber);
            }
            else
            {
                throw new NotImplementedException();
            }
            _log.Info("Shift: Data Recieved: " + ImportExportUtility.SerializeToJsonFromEntity(targetProductionContainer));
            return SerializeHelper.Serialize(targetProductionContainer);
        }

        /// <summary>
        /// GetResyncDataInternal
        /// </summary>
        /// <returns>ReSync Data</returns>
        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            TargetProductionContainer targetProductionContainer = new TargetProductionContainer();
            psm.TargetProductionContainerList = new List<TargetProductionContainer>();
            plant = plantService.GetPlantDetails();
            _log.Info("TargetProduction: Fetching TargetProduction data for ReSync for ecolabAccountNumber: " + plant.EcoalabAccountNumber);
            targetProductionContainer = this.GetTargetProductionSyncData(plant.EcoalabAccountNumber);
            psm.TargetProductionContainerList.Add(targetProductionContainer);
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity(psm);
            _log.Info("TargetProduction: Data recieved for ReSync: " + jsonData);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        /// <summary>
        /// GetResyncTypeInternal
        /// </summary>
        /// <returns>type ofd resync</returns>
        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdTargetProductionResync;
        }

        /// <summary>
        /// GetTargetProductionSyncData
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>List of target production</returns>
        public TargetProductionContainer GetTargetProductionSyncData(string ecolabAccountNumber)
        {
            TargetProductionContainer targetProductionContainer = new TargetProductionContainer();
            ShiftBreakService shiftBreakService = new ShiftBreakService();
            targetProductionContainer.TargetProduction = new List<TargetProduction>();
            targetProductionContainer.TargetProduction = shiftBreakService.FetchTargetProductionDetailsForSync(ecolabAccountNumber);
            targetProductionContainer.TargetProduction.ForEach(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));
            return targetProductionContainer;
        }
    }
}
