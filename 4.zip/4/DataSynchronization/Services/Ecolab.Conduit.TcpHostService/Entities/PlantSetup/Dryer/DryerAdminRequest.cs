﻿// -----------------------------------------------------------------------
// <copyright file="DryerAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using Ecolab.Services.PlantSetup.Dryer;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup.Dryer
{
    using Models;

    [MessageType(TcdAdminMessageTypes.TcdAddDryers)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateDryers)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteDryers)]
    public class DryerAdminRequest : TcdAdminRequestBase<Ecolab.Models.PlantSetup.Dryer.Dryer> 
    {
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("DryerAdminRequest");
        public DryerAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public DryerAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }
    
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Ecolab.Models.PlantSetup.Dryer.Dryer);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            DryerService dryerService = new DryerService();
            int i = dryerService.ValidateAndSaveDryersDetails(mPayload, pHeader.UserId,pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                mPayload.Id = i;
                mPayload.LastModifiedTimeStampDryer = lastModifiedTimeStamp;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Ecolab.Models.PlantSetup.Dryer.Dryer>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
			DryerService dryerService = new DryerService();
            psm.DryerList = dryerService.FetchDryers(plant.EcoalabAccountNumber);
            psm.DryerList.ForEach(c => c.LastModifiedTimeStampDryer = DateTime.SpecifyKind(c.LastModifiedTimeStampDryer, DateTimeKind.Utc));
            string jsonData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(jsonData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdDryerResync;
        }
    }
}
