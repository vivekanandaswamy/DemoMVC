﻿// -----------------------------------------------------------------------
// <copyright file="DryerGroupAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerGroupAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.PlantSetup.Dryer;
using Ecolab.Services;
using Ecolab.Services.PlantSetup.Dryer;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.PlantSetup.Dryer
{
    using Models.SyncMessages;

    [MessageType(TcdAdminMessageTypes.TcdAddDryerGroup)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateDryerGroup)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteDryerGroup)]
    public class DryerGroupAdminRequest : TcdAdminRequestBase<DryerGroup>
    {
        /// <summary>
        /// The p header
        /// </summary>
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("DryerGroupAdminRequest");

        public DryerGroupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public DryerGroupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            Log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(DryerGroup);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode;
            DateTime lastModifiedTimeStamp;
            DryerGroupService dryerGroupService = new DryerGroupService();

            int i = dryerGroupService.ValidateAndSaveDryerGroupDetails(mPayload, pHeader.UserId,
                pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
            TcdErrCodes result = (TcdErrCodes) errorCode;
            if (result == TcdErrCodes.Success)
            {
                mPayload.Id = i;
                mPayload.LastModifiedTimeStampDryerGroup = lastModifiedTimeStamp;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<DryerGroup>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            DryerGroupService dryerGroupService = new DryerGroupService();
            psm.DryerGroupList = dryerGroupService.FetchDryerGroupDetails(plant.EcoalabAccountNumber);
            psm.DryerGroupList.ForEach(c => c.LastModifiedTimeStampDryerGroup = DateTime.SpecifyKind(c.LastModifiedTimeStampDryerGroup, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdDryerGroupResync;
        }
    }
}
