﻿// -----------------------------------------------------------------------
// <copyright file="LanguageMasterAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The LanguageMasterAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.Common;
using Ecolab.Services;
using Ecolab.Services.PlantSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    /// <summary>
    /// LanguageMaster Admin Request Handler class
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestBase{Ecolab.Models.LanguageMaster}" />
    [MessageType(TcdAdminMessageTypes.TcdUpdateLanguageMaster)]
    public class LanguageMasterAdminRequest : TcdAdminRequestBase<LanguageMaster>
    {
        /// <summary>
        /// The log value
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("LanguageMasterAdminRequest");
        /// <summary>
        /// The p header
        /// </summary>
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        /// <summary>
        /// Initializes a new instance of the <see cref="LanguageMasterAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Pay load Data</param>
        public LanguageMasterAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LanguageMasterAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">The logger data.</param>
        /// <param name="adminHeader">The admin header.</param>
        /// <param name="appVersion">The application version.</param>
        public LanguageMasterAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LanguageMasterAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Pay load Data</param>
        /// <param name="isListObject">Is List Object</param>
        public LanguageMasterAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        /// <summary>
        /// Gets type of the Entity
        /// </summary>
        /// <param name="version">Plant app Version</param>
        /// <returns>
        /// Pay load Type
        /// </returns>
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(LanguageMaster);
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>Returns EcolabAccountNumber</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>Returns byte array</returns>
        protected override byte[] GetPayloadInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>Returns byte array</returns>
        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>Returns integer</returns>
        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>Returns Error codes</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int returnStatus = 0;
            _log.Info("LanguageMaster: Processing Central data to Local");
            _log.Info("LanguageMaster: Central data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));

            LanguageService languageMasterService = new LanguageService();
            returnStatus = languageMasterService.SaveLanguageMasterDetails(mPayloadList);

            _log.Info("LanguageService: Saved Central data to Local");

            if (returnStatus == 0)
            {
                return TcdErrCodes.Success;
            }
            else
            {
                return TcdErrCodes.SaveFailure;
            }
        }
    }
}
