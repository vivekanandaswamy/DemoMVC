﻿// -----------------------------------------------------------------------
// <copyright file="StorageTanksAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Storage Tanks Admin Request  handler</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.StorageTanks;
    using Models.SyncMessages;
    using Services;
    using Services.StorageTanks;
    
    [MessageType(TcdAdminMessageTypes.TcdAddStorageTanks)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateStorageTanks)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteStorageTanks)]
    public class StorageTanksAdminRequest : TcdAdminRequestBase<Tanks>
    {
        private static readonly ILog Log = LogManager.GetLogger("StorageTanksAdminRequest");
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;

        public StorageTanksAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
        }

        public StorageTanksAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Tanks);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            Log.Info("StorageTanks: Synch started...Saving in Local.");
            Log.Info("StorageTanks: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

            int errorCode;
            DateTime lastModifiedTimeStamp;
            StorageTanksService storageTanksService = new StorageTanksService();
            int i = storageTanksService.ValidateAndSaveStorageTanksDetails(mPayload, adminRequestHeader.UserId,
                adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);

            TcdErrCodes result = (TcdErrCodes)errorCode;
            if (result == TcdErrCodes.Success)
            {
                Log.Info("StorageTanks: Synch successful.");
                mPayload.TankId = i;
                mPayload.LastModifiedTimeStamp = lastModifiedTimeStamp;
            }
            return result;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Tanks>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("StorageTanks: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            Log.Info("StorageTanks: Getting List of data for resynch..");
            StorageTanksService storageTanksService = new StorageTanksService();
            psm.TanksList = storageTanksService.GetTanksDetailsForResync(plant.EcoalabAccountNumber);
            psm.TanksList.ForEach(t => DateTime.SpecifyKind(t.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            Log.Info("StorageTanks: Resynch data: " + xmlData);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdStorageTanksResync;
        }
    }
}
