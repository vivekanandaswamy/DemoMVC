﻿// -----------------------------------------------------------------------
// <copyright file="TcdTcpEntityFactory.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd Tcp entity factory  </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using Common;
    using Library.Common;
    using Library.Enums;
    using log4net;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    /// <summary>
    ///     Tcp Entity Factory
    /// </summary>
    public class TcdTcpEntityFactory
    {
        private static readonly Dictionary<TcdAdminMessageTypes, Type> adminMessageType;

        /// <summary>
        ///     This static constructor is used to fill in the cache of Admin message types to classes
        ///     that will handle those message types.
        /// </summary>
        static TcdTcpEntityFactory()
        {
            //Get Admin messages
            adminMessageType = new Dictionary<TcdAdminMessageTypes, Type>();

            foreach (Type t in Assembly.GetAssembly(typeof(TcdAdminRequestBase)).GetTypes())
            {
                object[] attribs = t.GetCustomAttributes(typeof(MessageTypeAttribute), false);

                //There can only ever be zero or one because of the attribute usage of this attribute
                foreach (MessageTypeAttribute msgTypeAttrib in attribs)
                {
                    adminMessageType[msgTypeAttrib.MessageType] = t;
                }
            }
        }

        /// <summary>
        ///     Gets an entity based on the admin message type and constructs an AdminRequestBase
        ///     based message entity.
        /// </summary>
        /// <param name="logger">Log4Net logger</param>
        /// <param name="appVersion">Application version from plant</param>
        /// <param name="adminHeader">Admin Request Header structure for this message</param>
        /// <param name="payloadBuffer">Payload for this message</param>
        /// <returns>An AdminRequestBase based object initialize with this message or null if the message type is not found.</returns>
        public static TcdAdminRequestBase GetRequestEntity(ILog logger, TcdAppVersion appVersion, TcdAdminRequestHeader adminHeader, byte[] payloadBuffer)
        {
            Type type;
            if (adminMessageType.TryGetValue(adminHeader.MessageType, out type))
            {
                TcdAdminRequestBase adminRequestBase = (TcdAdminRequestBase) Activator.CreateInstance(type, logger, adminHeader, appVersion, payloadBuffer);

                return adminRequestBase;
            }
            return null;
        }

        /// <summary>
        ///     Gets an entity based on the admin message type and constructs an AdminRequestBase
        ///     based message entity.
        /// </summary>
        /// <param name="logger">Log4Net logger</param>
        /// <param name="appVersion">Application version from plant</param>
        /// <param name="adminHeader">Admin Request Header structure for this message</param>
        /// <returns>An AdminRequestBase based object initialize with this message or null if the message type is not found.</returns>
        public static TcdAdminRequestBase GetResyncRequestEntity(ILog logger, TcdAppVersion appVersion, TcdAdminRequestHeader adminHeader)
        {
            Type type;
            if (adminMessageType.TryGetValue(adminHeader.MessageType, out type))
            {
                TcdAdminRequestBase adminRequestBase = (TcdAdminRequestBase) Activator.CreateInstance(type, logger, adminHeader, appVersion);

                return adminRequestBase;
            }
            return null;
        }

        /// <summary>
        /// Gets an entity based on the admin message type and constructs an AdminRequestBase
        /// based message entity.  
        /// </summary>
        /// <param name="logger">Log4Net logger</param>
        /// <param name="appVersion">Application version from plant</param>
        /// <param name="adminHeader">Admin Request Header structure for this message</param>
        /// <param name="payloadBuffer">Payload for this message</param>
        /// <returns>An AdminRequestBase based object initialize with this message or null if the message type is not found.</returns>
        public static TcdAdminRequestBase GetListRequestEntity(ILog logger, TcdAppVersion appVersion, TcdAdminRequestHeader adminHeader, byte[] payloadBuffer)
        {
            Type type;
            if (adminMessageType.TryGetValue(adminHeader.MessageType, out type))
            {
                TcdAdminRequestBase adminRequestBase =
                    (TcdAdminRequestBase)Activator.CreateInstance(type,
                                    new object[] { logger, adminHeader, appVersion, payloadBuffer, true });

                return adminRequestBase;
            }
            return null;
        }
    }
}