﻿// -----------------------------------------------------------------------
// <copyright file="AlarmMasterAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The AlarmMasterAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.Common;
using Ecolab.Services;
using Ecolab.Services.PlantSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    /// <summary>
    /// DeviceType Admin Request Handler class
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestBase{Ecolab.Models.AlarmMaster}" />
    [MessageType(TcdAdminMessageTypes.TcdUpdateAlarmMaster)]
    public class AlarmMasterAdminRequest : TcdAdminRequestBase<AlarmMaster>
    {
        /// <summary>
        /// The log data
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("AlarmMasterAdminRequest");

        /// <summary>
        /// Initializes a new instance of the <see cref="AlarmMasterAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload Data</param>
        public AlarmMasterAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlarmMasterAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">The logger Data.</param>
        /// <param name="adminHeader">The admin header.</param>
        /// <param name="appVersion">The application version.</param>
        public AlarmMasterAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlarmMasterAdminRequest"/> class.
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload Data</param>
        /// <param name="isListObject">Is List Object</param>
        public AlarmMasterAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
        }

        /// <summary>
        /// Gets type of the Entity
        /// </summary>
        /// <param name="version">Plant app Version</param>
        /// <returns>
        /// Pay load Type
        /// </returns>
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(AlarmMaster);
        }

        /// <summary>
        /// Gets the ecolab account number internal.
        /// </summary>
        /// <returns>Ecolab account number</returns>
        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        /// <summary>
        /// Gets the payload internal.
        /// </summary>
        /// <returns>Returns byte array</returns>
        protected override byte[] GetPayloadInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync data internal.
        /// </summary>
        /// <returns>Returns byte array</returns>
        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        /// <summary>
        /// Gets the resync type internal.
        /// </summary>
        /// <returns>Returns integer</returns>
        protected override int GetResyncTypeInternal()
        {
            return 0;
        }

        /// <summary>
        /// Processes the message internal.
        /// </summary>
        /// <param name="outputStream">The output stream.</param>
        /// <returns>Returns Error codes</returns>
        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int returnStatus = 0;
            Log.Info("AlarmMaster: Processing Central data to Local");
            Log.Info("AlarmMaster: Central data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));

            AlarmService alarmMasterService = new AlarmService();
            returnStatus = alarmMasterService.SaveAlarmMasterDetails(mPayloadList);

            Log.Info("AlarmService: Saved Central data to Local");

            if (returnStatus == 0)
            {
                return TcdErrCodes.Success;
            }
            else
            {
                return TcdErrCodes.SaveFailure;
            }
        }
    }
}
