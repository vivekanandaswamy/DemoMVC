﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceManualProductionAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MyServiceManualProductionAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Entities
{
    using System;
    using System.IO;
    using System.Linq;
    using Common;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using log4net;
    using Models;
    using Models.PlantSetup.UserManagement;
    using Models.SyncMessages;
    using Services;
    using TcdAdminRequestHeader = Common.TcdAdminRequestHeader;

    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServiceManualProduction)]
    public class MyServiceManualProductionAdminRequest : TcdAdminRequestBase<MyServiceManualProduction>
    {
        private static readonly ILog Log = LogManager.GetLogger("MyServiceManualProductionAdminRequest");
        private readonly TcdAdminRequestHeader adminRequestHeader;

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        /// <param name="inputBuffer">Payload</param>
        public MyServiceManualProductionAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
        }

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">Admin header</param>
        /// <param name="appVersion">Plant App Version</param>
        public MyServiceManualProductionAdminRequest(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
        }

        /// <summary>
        ///     Gets the type of the Meter entity
        /// </summary>
        /// <param name="version">Plant appVersion</param>
        /// <returns>Type</returns>
        public override Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(MyServiceManualProduction);
        }

        /// <summary>
        ///     Process the Meters request
        /// </summary>
        /// <param name="outputStream">Stream</param>
        /// <returns>TcdErrorCodes</returns>
        protected override TcdErrCodes ProcessMessageInternal(Stream outputStream)
        {
            Log.Info("ManualProduction: Sync data: " + ImportExportUtility.SerializeToJsonFromEntity(this.mPayload));
            MyServiceManualProductionService myServiceManualProductionService = new MyServiceManualProductionService();

            myServiceManualProductionService.SaveMyServiceManualProductionDetails(mPayload, mPayload.EcolabAccountNumber);

            return TcdErrCodes.Success;
        }

        protected override byte[] GetResyncDataInternal()
        {
            throw new NotImplementedException();
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdUpdateMyServiceManualProduction;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<MyServiceManualProduction>(mPayload);
        }
    }
}
