﻿// -----------------------------------------------------------------------
// <copyright file="PackageSizeAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PackageSizeAdminRequest </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Services;
using Ecolab.Services.Washers.conventional;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities
{
    [MessageType(TcdAdminMessageTypes.TcdUpdateMyServicePackageSize)]
    public class PackageSizeAdminRequest : TcdAdminRequestBase<PackageSize>
    {
        /// <summary>
        /// The p header
        /// </summary>
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("PackageSizeAdminRequest");

        public PackageSizeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public PackageSizeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public PackageSizeAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer, bool isListObject)
            : base(logger, adminHeader, appVersion, inputBuffer, isListObject)
        {
            adminRequestHeader = adminHeader;
            _log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PackageSizeAdminRequest);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            _log.Info("PackageSize: Processing MyService data to Local");
            _log.Info("PackageSize: MyService data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayloadList));
            Ecolab.Services.PackageSizeService packageSizeService = new Services.PackageSizeService();
            packageSizeService.SaveMyServicePackageSizeDetails(mPayloadList);
            _log.Info("PackageSize: Saved MyService data to Local");
            return TcdErrCodes.Success;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return string.Empty;
        }

        protected override byte[] GetPayloadInternal()
        {
            return null;
        }

        protected override byte[] GetResyncDataInternal()
        {
            return null;
        }

        protected override int GetResyncTypeInternal()
        {
            return 0;
        }
    }
}
