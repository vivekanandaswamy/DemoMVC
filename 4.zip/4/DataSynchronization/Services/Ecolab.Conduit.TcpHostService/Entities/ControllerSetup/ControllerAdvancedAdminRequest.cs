﻿// -----------------------------------------------------------------------
// <copyright file="ControllerAdvancedAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Controller Advanced Admin Request handler</summary>
// -----------------------------------------------------------------------

using System;
using System.Text.RegularExpressions;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.ControllerSetup;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using Ecolab.Services.ControllerSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.ControllerSetup
{
    [MessageType(TcdAdminMessageTypes.TcdAddControllerAdvanced)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateControllerAdvanced)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteControllerAdvanced)]
    [MessageType(TcdAdminMessageTypes.TcdControllerAdvancedResync)]
    public class ControllerAdvancedAdminRequest : TcdAdminRequestBase<ControllerSetupDataDetails>
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ControllerAdvancedAdminRequest));

        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;
        //private TcdAdminMessageTypes mType;
        private ILog log;

        public ControllerAdvancedAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
            log = logger;
        }

        public ControllerAdvancedAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
            log = logger;
        }
        
        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ControllerSetupDataDetails);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int returnValue = 0;
            try
            {
                int errorCode;
                DateTime lastModifiedTimeStamp;
                ControllerSetupService controllerSetupService = new ControllerSetupService();
                Log.Info("ControllerAdvance: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

                controllerSetupService.ValidateAndSaveControllerAdvanceDetails(mPayload, mPayload.UserId,
                    pHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
                TcdErrCodes result = (TcdErrCodes) errorCode;
                if (result == TcdErrCodes.Success)
                {
                    mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc); 
                }
                return result;
            }
            catch (Exception ex)
            {
                log.Error("Error is occured in ControllerAdvancedAdminRequest for ecolabAccountNumber ::" + mPayload.EcolabAccountNumber + " Exception :: " + ex);
                log.Error("Data ::" + ImportExportUtility.SerializeToJsonFromEntity<ControllerSetupDataDetails>(base.mPayload));
                returnValue = (int)TcdErrCodes.RequestFailed;
            }
            return (TcdErrCodes)returnValue;
        }
        
        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<ControllerSetupDataDetails>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();

            ControllerSetupService controllerSetupService = new ControllerSetupService();
            psm.ControllerSetupDataListForAdvanced = controllerSetupService.GetControllerSetupDetailsForResync(plant.EcoalabAccountNumber, 3);

            psm.ControllerSetupDataListForAdvanced.ForEach(c => DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);

            Log.Info("ControllerAdvance: Resynch data: " + xmlData);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdControllerAdvancedResync;
        }
    }
}
