﻿// -----------------------------------------------------------------------
// <copyright file="ControllerGeneralAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Controller general Admin Request handler</summary>
// -----------------------------------------------------------------------

using System;
using System.Text.RegularExpressions;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.ControllerSetup;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using Ecolab.Services.ControllerSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.ControllerSetup
{
    [MessageType(TcdAdminMessageTypes.TcdAddController)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateController)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteController)]
    public class ControllerGeneralAdminRequest : TcdAdminRequestBase<ControllerSetupDataDetails>
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ControllerGeneralAdminRequest));
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminRequestHeader;        
        private ILog log;

        public ControllerGeneralAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            adminRequestHeader = adminHeader;
            log = logger;
        }

        public ControllerGeneralAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            adminRequestHeader = adminHeader;
            log = logger;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(ControllerSetupDataDetails);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int returnValue = 0;
            try
            {
                int errorCode;
                DateTime lastModifiedTimeStamp;
                Log.Info("ControllerGeneral: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

                ControllerSetupService controllerService = new ControllerSetupService();
                int i = controllerService.ValidateAndSaveControllerDetails(mPayload, adminRequestHeader.UserId,
                    adminRequestHeader.MessageType, out errorCode, out lastModifiedTimeStamp);
                TcdErrCodes result = (TcdErrCodes)errorCode;
                if (result == TcdErrCodes.Success)
                {
					if(adminRequestHeader.MessageType == TcdAdminMessageTypes.TcdAddController)
					{
						mPayload.ControllerId = i;
                        Id = i;
					}
                    mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                }
                return result;
            }
            catch (Exception ex)
            {
                Log.Error("Error is occured in ControllerGeneralAdminRequest for ecolabAccountNumber ::" + mPayload.EcolabAccountNumber + " Exception :: " + ex);
                Log.Error("Data ::" + ImportExportUtility.SerializeToJsonFromEntity<ControllerSetupDataDetails>(base.mPayload));
                returnValue = (int)TcdErrCodes.RequestFailed;
            }
            return (TcdErrCodes)returnValue;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<ControllerSetupDataDetails>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            ControllerSetupService controllerSetupService = new ControllerSetupService();
            psm.ControllerSetupDataListForGeneral = controllerSetupService.GetControllerSetupDetailsForResync(plant.EcoalabAccountNumber, 1);
            psm.ControllerSetupDataListForGeneral.ForEach(c => DateTime.SpecifyKind(c.LastModifiedTimeStamp, DateTimeKind.Utc));
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            Log.Info("ControllerGeneral: Resynch data: " + xmlData);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdControllerGeneralResync;
        }
    }
}
