﻿// -----------------------------------------------------------------------
// <copyright file="ControllerEquipmentSetupAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Controller Equipment Setup Admin Request handler</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.ControllerSetup;
using Ecolab.Models.ControllerSetup.Pumps;
using Ecolab.Models.SyncMessages;
using Ecolab.Services;
using Ecolab.Services.ControllerSetup;
using Ecolab.Services.ControllerSetup.Pumps;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.ControllerSetup
{
    [MessageType(TcdAdminMessageTypes.TcdAddControllerEquipmentSetup)]
    [MessageType(TcdAdminMessageTypes.TcdUpdateControllerEquipmentSetup)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteControllerEquipmentSetup)]
    [MessageType(TcdAdminMessageTypes.TcdUpdatePump)]
    public class ControllerEquipmentSetupAdminRequest : TcdAdminRequestBase<PumpsModel>
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ControllerEquipmentSetupAdminRequest));
        private Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader pHeader;

        public ControllerEquipmentSetupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            pHeader = adminHeader;
        }

        public ControllerEquipmentSetupAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            pHeader = adminHeader;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(PumpsModel);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode = (int)TcdErrCodes.Success;
            try
            {
                DateTime lastModifiedTimeStamp = System.DateTime.UtcNow;

                PumpsServices pumpService = new PumpsServices();
                Log.Info("Pumps: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

                int i = pumpService.ValidateAndSavePump(mPayload, pHeader.UserId, mPayload.LastModifiedTimeStamp, out lastModifiedTimeStamp, out errorCode);
                TcdErrCodes result = (TcdErrCodes)errorCode;
                if (result == TcdErrCodes.Success)
                {
                    mPayload.ControllerEquipmentSetupId = i;
                    mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error is occured in ControllerEquipmentSetupAdminRequest for ecolabAccountNumber ::" + mPayload.EcolabAccountNumber + " Exception :: " + ex);
                Log.Error("Data ::" + ImportExportUtility.SerializeToJsonFromEntity<PumpsModel>(base.mPayload));
            }

            return (TcdErrCodes)errorCode;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            PumpsServices pumpService = new PumpsServices();
			List<Ecolab.Models.ControllerSetup.Pumps.PumpsModel> pumpList = pumpService.GetPumpsForResync(mPayload.EcolabAccountNumber, mPayload.ControllerId, mPayload.ControllerEquipmentSetupId);
            Ecolab.Models.ControllerSetup.Pumps.PumpsModel objPump = pumpList.Where(p => p.ControllerEquipmentSetupId == mPayload.ControllerEquipmentSetupId).FirstOrDefault();
            objPump.LastModifiedTimeStamp = DateTime.SpecifyKind(objPump.LastModifiedTimeStamp, DateTimeKind.Utc);
            return SerializeHelper.Serialize<PumpsModel>(objPump);
        }

        protected override byte[] GetResyncDataInternal()
        {
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            ControllerSetupService controllerSetupService = new ControllerSetupService();
            List<ControllerSetupDataDetails> controllerSetupDataListForGeneral = controllerSetupService.GetControllerSetupDetailsForResync(plant.EcoalabAccountNumber, 1);
            PumpsServices pumpService = new PumpsServices();
            psm.PumpsDetails = new List<PumpsModel>();
            if (controllerSetupDataListForGeneral != null && controllerSetupDataListForGeneral.Count > 0)
            {
                foreach (var item in controllerSetupDataListForGeneral)
                {
                    psm.PumpsDetails.AddRange(pumpService.GetPumpsForResync(plant.EcoalabAccountNumber, item.ControllerId, null));
                }
            }
            else
            {
                Log.Info("No controller information available in local. Resync of pump failed.");
            }

            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdControllerEquipmentSetupResync;
        }
    }
}
