﻿// -----------------------------------------------------------------------
// <copyright file="ControllerListingAdminRequest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Controller Listing Admin Request handler</summary>
// -----------------------------------------------------------------------

using System;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Models;
using Ecolab.Models.ControllerSetup;
using Ecolab.Services;
using Ecolab.Services.ControllerSetup;
using log4net;

namespace Ecolab.Conduit.TcpHostService.Entities.ControllerSetup
{
    using Models.SyncMessages;

    [MessageType(TcdAdminMessageTypes.TcdUpdateControllerSetupListing)]
    [MessageType(TcdAdminMessageTypes.TcdDeleteControllerSetupListing)]    
    public class ControllerListingAdminRequest : TcdAdminRequestBase<Controller> 
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ControllerListingAdminRequest));
        private readonly Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader AdminRequestHeader;

        public ControllerListingAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion, byte[] inputBuffer)
            : base(logger, adminHeader, appVersion, inputBuffer)
        {
            AdminRequestHeader = adminHeader;
        }

        public ControllerListingAdminRequest(ILog logger, Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
            : base(adminHeader, appVersion)
        {
            AdminRequestHeader = adminHeader;
        }

        public override System.Type GetPayloadType(TcdAppVersion version)
        {
            return typeof(Controller);
        }

        protected override TcdErrCodes ProcessMessageInternal(System.IO.Stream outputStream)
        {
            int errorCode = (int)TcdErrCodes.Success;
            try
            {
                DateTime lastModifiedTimeStamp = System.DateTime.UtcNow;

                Log.Info("ControllerListing: Synch data: " + ImportExportUtility.SerializeToJsonFromEntity(mPayload));

                ControllerSetupService controllerSetupService = new ControllerSetupService();
                controllerSetupService.ValidateAndSaveControllerListDetails(mPayload, AdminRequestHeader.UserId, AdminRequestHeader.MessageType,
                    out errorCode, out lastModifiedTimeStamp);
                if (errorCode == (int)TcdErrCodes.Success)
                {
                    mPayload.LastModifiedTimeStamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error is occured in ControllerListingAdminRequest for ecolabAccountNumber ::" + mPayload.EcolabAccountNumber + " Exception :: " + ex);
                Log.Error("Data ::" + ImportExportUtility.SerializeToJsonFromEntity<Controller>(base.mPayload));
                return TcdErrCodes.RequestFailed;
            }
            
            return (TcdErrCodes)errorCode;
        }

        protected override string GetEcolabAccountNumberInternal()
        {
            return mPayload.EcolabAccountNumber;
        }

        protected override byte[] GetPayloadInternal()
        {
            return SerializeHelper.Serialize<Controller>(mPayload);
        }

        protected override byte[] GetResyncDataInternal()
        {
            Log.Info("ControllerListing: Resynch started...");
            TcdAllPlantEntities psm = new TcdAllPlantEntities();
            Plant plant = new Plant();
            PlantService plantService = new PlantService();
            plant = plantService.GetPlantDetails();
            Log.Info("ControllerListing: Getting List of data for resynch..");
            ControllerSetupService controllerSetupService = new ControllerSetupService();
            psm.ControllerList = controllerSetupService.GetControllerDetails(plant.EcoalabAccountNumber, null, true);
            foreach (var item in psm.ControllerList)
            {
                item.LastModifiedTimeStamp = DateTime.SpecifyKind(item.LastModifiedTimeStamp, DateTimeKind.Utc);
            }
            string xmlData = ImportExportUtility.SerializeToJsonFromEntity<TcdAllPlantEntities>(psm);
            Log.Info("ControllerListing: Resynch data: " + xmlData);
            return SerializeHelper.ConvertStringToByteArray(xmlData);
        }

        protected override int GetResyncTypeInternal()
        {
            return (int)TcdAdminMessageTypes.TcdControllerListingResync;
        }
        
    }
}
