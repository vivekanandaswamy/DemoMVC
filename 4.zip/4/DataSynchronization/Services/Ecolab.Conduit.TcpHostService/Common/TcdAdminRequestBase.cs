﻿// -----------------------------------------------------------------------
// <copyright file="TcdAdminRequestBase.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd Admin Request base</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Common
{
	using System;
	using System.Collections.Generic;
	using System.IO;
	using Helpers;
	using Library.Common;
	using Library.Enums;
	using Library.Helpers;
	using log4net;
	using Ecolab.Services.Interfaces;
	using Ecolab.Services;
	using Models.WasherGroup;

    /// <summary>
    ///     TcdAdminRequest base class
    /// </summary>
    /// <typeparam name="T">Type</typeparam>
      
    public abstract class TcdAdminRequestBase<T> : TcdAdminRequestBase where T : class
	{
		private ILog mLog;
		protected T mPayload { get; set; }
		protected List<T> mPayloadList { get; set; }

        //*Header Data Ends*//

        /// <summary>
        ///     Constructor with parameters
        /// </summary>
        /// <param name="logger">Log4Net object</param>
        /// <param name="adminHeader">AdminHeader</param>
        /// <param name="appVersion">Plant app version</param>
        /// <param name="inputBuffer">Payload</param>
        public TcdAdminRequestBase(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
			byte[] inputBuffer)
		{
			this.RequestMessageType = adminHeader.MessageType;
			this.RequestPayloadSize = adminHeader.PayloadSize;
			this.RequestUserId = adminHeader.UserId;
			this.RequestTimestampUtc = DateTimeHelper.UnixEpoc.AddSeconds(adminHeader.Timestamp);
			this.AppVersion = appVersion;
			this.Initialize(logger, inputBuffer);
		}

		/// <summary>
		///     Constructor with parameters
		/// </summary>
		/// <param name="adminHeader">AdminHeader</param>
		/// <param name="appVersion">Plant app version</param>
		public TcdAdminRequestBase(TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion)
		{
			this.RequestMessageType = adminHeader.MessageType;
			this.RequestPayloadSize = adminHeader.PayloadSize;
			this.RequestUserId = adminHeader.UserId;
			this.RequestTimestampUtc = DateTimeHelper.UnixEpoc.AddSeconds(adminHeader.Timestamp);
			this.AppVersion = appVersion;
		}

		/// <summary>
		///     Constructor with parameters
		/// </summary>
		/// <param name="logger">Log4Net object</param>
		/// <param name="adminHeader">AdminHeader</param>
		/// <param name="appVersion">Plant app version</param>
		/// <param name="inputBuffer">Payload</param>
		public TcdAdminRequestBase(ILog logger, TcdAdminRequestHeader adminHeader, TcdAppVersion appVersion,
			byte[] inputBuffer, bool isListObject)
		{
			this.RequestMessageType = adminHeader.MessageType;
			this.RequestPayloadSize = adminHeader.PayloadSize;
			this.RequestUserId = adminHeader.UserId;
			this.RequestTimestampUtc = DateTimeHelper.UnixEpoc.AddSeconds(adminHeader.Timestamp);
			this.AppVersion = appVersion;
			this.InitializeList(logger, inputBuffer);
		}

		/// <summary>
		///     *Header Data Starts*
		/// </summary>
		public uint RequestPayloadSize { get; private set; }

		public int RequestUserId { get; private set; }
		public DateTime RequestTimestampUtc { get; private set; }

		/// <summary>
		///     Initialize entity
		/// </summary>
		/// <param name="logger">Log4Net object</param>
		/// <param name="inputBuffer">Payload</param>
		private void Initialize(ILog logger, byte[] inputBuffer)
		{
			this.mLog = logger;
			this.Id = 0;
			if (this.mLog.IsDebugEnabled)
			{
				this.mLog.Debug("Admin Request Bytes: " + ExportHelper.WriteBytes(inputBuffer));
			}
			this.InitializePayloadWithInputBuffer(inputBuffer);
			if (this.mLog.IsInfoEnabled)
			{
				this.mLog.Info(this.RequestMessageType + "::" + ExportHelper.ClassToString(this.mPayload));
			}
		}

		/// <summary>
		///     Initialize entity
		/// </summary>
		/// <param name="logger">Log4Net object</param>
		/// <param name="inputBuffer">Payload</param>
		private void InitializeList(ILog logger, byte[] inputBuffer)
		{
			this.mLog = logger;
			this.Id = 0;
			if (this.mLog.IsDebugEnabled)
			{
				this.mLog.Debug("Admin Request Bytes: " + ExportHelper.WriteBytes(inputBuffer));
			}
			this.mPayloadList = MsgPackConverter.GetData<List<T>>(inputBuffer);
		}

		/// <summary>
		/// Checks if resync is required
		/// </summary>
		/// <returns>bool</returns>
		public override bool CheckResync()
		{
			ISyncService syncService = new SyncService();
			string tableName = TableEntityMap.GetTable(this.mPayload.GetType().ToString());
			string typeName = this.GetTypeName();

			if (this.mPayload.GetType().GetProperty("LastModifiedTimestampAtCentral") != null && !string.IsNullOrEmpty(tableName))
			{
				this.mLog.Info("Checking for Resync:: Message Type: " + this.RequestMessageType + " TableName: " + tableName);

				string ecolabAccountNumber = GetAccNumber();
				if (string.IsNullOrEmpty(ecolabAccountNumber))
				{
					this.mLog.Info("Resync not required as there is no EcolabAccountNumber property in the received data");
					return false;
				}
				this.mLog.Info("Checking for Resync:: EcolabAccountNumber: " + ecolabAccountNumber);
				DateTime lastModifiedTimeLocal = syncService.GetLatestLastModifiedTime(tableName, ecolabAccountNumber, typeName);
				this.mLog.Info("Checking for Resync:: Last Modified Time at local : " + lastModifiedTimeLocal);
				DateTime? lastModifiedTimeCentral = Convert.ToDateTime(this.mPayload.GetType().GetProperty("LastModifiedTimestampAtCentral").GetValue(this.mPayload, null));
				this.mLog.Info("Checking for Resync:: Last Modified Time at central : " + lastModifiedTimeCentral);

				if (lastModifiedTimeCentral != null && lastModifiedTimeLocal != lastModifiedTimeCentral)
				{
					this.mLog.Info("Table: " + tableName + " not is sync. Resync triggered.");
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Check resync required for container models
		/// </summary>
		/// <param name="lastModifiedTimeCentral">last modified time at central</param>
		/// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
		/// <param name="typeName">Type Name</param>
		/// <returns>boolean</returns>
		protected bool CheckContainerResync(DateTime? lastModifiedTimeCentral, string ecolabAccountNumber, string typeName)
		{
			ISyncService syncService = new SyncService();
			string tableName = TableEntityMap.GetTable(this.mPayload.GetType().ToString());
			if (mPayload.GetType().ToString().Equals("Ecolab.Models.PlantSetup.ShiftLabor.ShiftSyncContainer") && Convert.ToBoolean(mPayload.GetType().GetProperty("IsLabor").GetValue(this.mPayload, null)))
			{
				tableName = "ShiftLaborData";
			}
            else if (mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.FlushTimesAndSetupTom") && typeName.Equals("WasherFlushTime"))
            {
                tableName = "WasherFlushTime";
				typeName = "PlantId";
            }
            else if (mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.FlushTimesAndSetupTom") && typeName.Equals("WasherTimeOutMachine"))
            {
                tableName = "WasherTimeOutMachine";
				typeName = "PlantId";
            }
            else if (mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.ProductDeviationContainer") && typeName.Equals("WasherProductDeviations"))
            {
                tableName = "WasherProductDeviations";
                typeName = "PlantId";
            }
			else if (mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.Tunnel.TunnelAnalogueDosingControlContainer") && typeName.Equals("TunnelAnalogControlLevel"))
			{
				tableName = "TunnelAnalogControlLevel";
				typeName = "PlantId";
			}
			if (mPayload.GetType().ToString().Equals("Ecolab.Models.WasherGroup.CopyFormulaContainer") && Convert.ToBoolean(mPayload.GetType().GetProperty("IsConventional").GetValue(this.mPayload, null).ToString().Equals("True")))
			{
				tableName = "WasherProgramSetup";
			}
			if (mPayload.GetType().ToString().Equals("Ecolab.Models.WasherGroup.CopyFormulaContainer") && Convert.ToBoolean(mPayload.GetType().GetProperty("IsConventional").GetValue(this.mPayload, null).ToString().Equals("False")))
			{
				tableName = "TunnelProgramSetup";
			}
			DateTime lastModifiedTimeLocal = syncService.GetLatestLastModifiedTime(tableName, ecolabAccountNumber, typeName);
			this.mLog.Info("Checking for Resync:: Last Modified Time at local : " + lastModifiedTimeLocal + ", Central Last Modified Time : " + lastModifiedTimeCentral);
			if (lastModifiedTimeCentral != null && lastModifiedTimeLocal != lastModifiedTimeCentral)
			{
				this.mLog.Info("Table: " + tableName + " not is sync. Resync triggered.");
				return true;
			}
			return false;
		}

		/// <summary>
		/// Gets the type name based on mPayload type.
		/// </summary>
		/// <returns>string</returns>
		private string GetTypeName()
		{
			string typeName = string.Empty;
			if (this.mPayload.GetType().ToString().Equals("Ecolab.Models.PlantSetup.Dryer.DryerGroup"))
			{
				typeName = "DryerGroup";
			}
			else if (this.mPayload.GetType().ToString().Equals("Ecolab.Models.PlantSetup.Finnisher.FinnisherGroup"))
			{
				typeName = "FinnisherGroup";
			}
			else if (this.mPayload.GetType().ToString().Equals("Ecolab.Models.WasherGroup.WasherGroup"))
			{
				typeName = "WasherGroup";
			}
			else if (this.mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.Conventional.ConventionalGeneral") || ((this.mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.Washers") && this.mPayload.GetType().GetProperty("WasherTypeFlag").GetValue(this.mPayload, null).ToString().Equals("False"))))
			{
				typeName = "ConventionalGeneral";
			}
			else if (this.mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.Tunnel.TunnelContainer") || this.mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.Tunnel.TunnelGeneral") || ((this.mPayload.GetType().ToString().Equals("Ecolab.Models.Washers.Washers") && this.mPayload.GetType().GetProperty("WasherTypeFlag").GetValue(this.mPayload, null).ToString().Equals("True"))))
			{
				typeName = "Tunnel";
			}
			return typeName;
		}

		/// <summary>
		/// Gets the EcolabAccNumber from the model
		/// </summary>
		/// <returns>string</returns>
		private string GetAccNumber()
		{
			string ecolabAccountNumber = string.Empty;
			if (this.mPayload.GetType().GetProperty("EcolabAccountNumber") != null)
			{
				ecolabAccountNumber = this.mPayload.GetType().GetProperty("EcolabAccountNumber").GetValue(this.mPayload, null).ToString();
			}
			else if (this.mPayload.GetType().GetProperty("EcoalabAccountNumber") != null)
			{
				ecolabAccountNumber = this.mPayload.GetType().GetProperty("EcoalabAccountNumber").GetValue(this.mPayload, null).ToString();
			}
			return ecolabAccountNumber;
		}

		/// <summary>
		///     Override this method to use a different structure for different app versions.
		/// </summary>
		/// <param name="inputBuffer"></param>
		protected virtual void InitializePayloadWithInputBuffer(byte[] inputBuffer)
		{
			this.mPayload = MsgPackConverter.GetData<T>(inputBuffer);
		}

		/// <summary>
		///     Gets type of the Entity
		/// </summary>
		/// <param name="version">Plant app Version</param>
		/// <returns>Type</returns>
		public override Type GetPayloadType(TcdAppVersion version)
		{
			return typeof(T);
		}
	}

	/// <summary>
	///     TcdAdminRequestBase class
	/// </summary>
	public abstract class TcdAdminRequestBase
	{
		public TcdAdminMessageTypes RequestMessageType { get; protected set; }
		public TcdAppVersion AppVersion { get; set; }
		public int Id { get; set; }
		protected abstract string GetEcolabAccountNumberInternal();
		protected abstract byte[] GetPayloadInternal();
		protected abstract byte[] GetResyncDataInternal();
		protected abstract int GetResyncTypeInternal();
		protected abstract TcdErrCodes ProcessMessageInternal(Stream outputStream);

		/// <summary>
		///     Process the request message
		/// </summary>
		/// <param name="outputStream">Stream</param>
		/// <returns>TcdErrorCodes</returns>
		public TcdErrCodes ProcessMessage(Stream outputStream)
		{
			return this.ProcessMessageInternal(outputStream);
		}

		/// <summary>
		///     Get Ecolab Account Number
		/// </summary>
		/// <returns>string</returns>
		public string GetEcolabAccountNumber()
		{
			return this.GetEcolabAccountNumberInternal();
		}

		/// <summary>
		///     Gets the byte array of the request to send to Central
		/// </summary>
		/// <returns>Byte[]</returns>
		public byte[] GetPayload()
		{
			return this.GetPayloadInternal();
		}

		public byte[] GetResyncData()
		{
			return this.GetResyncDataInternal();
		}

		public int GetResyncType()
		{
			return this.GetResyncTypeInternal();
		}

		/// <summary>
		///     Gets the Type of the Entity
		/// </summary>
		/// <param name="version">Plant app version</param>
		/// <returns>Type</returns>
		public abstract Type GetPayloadType(TcdAppVersion version);

		/// <summary>
		/// check to trigger resync
		/// </summary>
		/// <returns>bool</returns>
		public abstract bool CheckResync();
	}
}