﻿// -----------------------------------------------------------------------
// <copyright file="TcdAdminRequestHeader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TcdAdminRequestHeader struct</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Common
{
    using System;
    using System.Runtime.InteropServices;
    using Library.Common;
    using Library.Enums;

    /// <summary>
    ///     This structure is used for all four message types (Get/Update/Push/Re-sync).
    ///     It is used for the request of those four types.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    
    public struct TcdAdminRequestHeader
    {
        public TcdAdminMessageTypes MessageType;

        public uint PayloadSize;

        public uint LogoSize;

        public TcdMessageFormatTypes MessageFormat;

        public int UserId;

        public long Timestamp;
    }
}