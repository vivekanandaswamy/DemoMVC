﻿// -----------------------------------------------------------------------
// <copyright file="TcpHostServer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TcpHostServer </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.PushHandler;
using Ecolab.Conduit.TcpHostService.Common;
using Ecolab.Conduit.TcpHostService.Entities;
using Ecolab.Conduit.TcpHostService.Properties;
using Ecolab.Models;
using Ecolab.Services;
using Ecolab.Services.SyncConfigSettingService;
using Ecolab.Services.SyncQueue;
using log4net;

namespace Ecolab.Conduit.TcpHostService
{
    public class TcpHostServer
    {
        private static readonly ILog Log = LogManager.GetLogger("TcpHostServer");

        private static Dictionary<string, string> dicTcpHostServiceConfigSettings = new Dictionary<string, string>();

        private TcpListener listener;
        private int activeThreadCount = 0;
        private int modelPort;

        private ManualResetEvent exitLoopEvent = new ManualResetEvent(false);
        private AutoResetEvent acceptCompleteEvent = new AutoResetEvent(false);
        private Thread listenerThread;
        private int TCPRECEIVETIMEOUT = 30000; //30 seconds

        public TcpHostServer(int port)
        {
            dicTcpHostServiceConfigSettings = GetConfiguration("TcpHostService");
            if (int.Parse(dicTcpHostServiceConfigSettings["WorkerThreads"], CultureInfo.CurrentCulture) > 0 && int.Parse(dicTcpHostServiceConfigSettings["CompletionPortThreads"], CultureInfo.CurrentCulture) > 0)
            {
                ThreadPool.SetMaxThreads(int.Parse(dicTcpHostServiceConfigSettings["WorkerThreads"], CultureInfo.CurrentCulture), (int.Parse(dicTcpHostServiceConfigSettings["CompletionPortThreads"], CultureInfo.CurrentCulture)));
            }
            modelPort = port;
            listenerThread = new Thread(ListenerLoop);
            listenerThread.Start();
            Log.Info("Service Started.");
        }

        private void ListenerLoop(object obj)
        {
            listener = new TcpListener(IPAddress.Any, modelPort);
            listener.Start();
            WaitHandle[] waitHandles = new WaitHandle[] { exitLoopEvent, acceptCompleteEvent };
            while (true)
            {
                listener.BeginAcceptTcpClient(OnClientAvalable, null);
                int handleIndex = WaitHandle.WaitAny(waitHandles);
                if (handleIndex == 0) //Exit Loop Event
                {
                    break;
                }
            }
            listener.Stop();
        }

        public void Stop()
        {
            exitLoopEvent.Set();
            int loops = 600; //60 seconds
            while (activeThreadCount > 0 && loops > 0)
            {
                Thread.Sleep(100);
                loops--;
            }
            Log.Info("Service Stopped.");
        }

        private void OnClientAvalable(IAsyncResult ar)
        {
            //If exit is set, just leave..
            if (exitLoopEvent.WaitOne(0))
            {
                acceptCompleteEvent.Set();
                return;
            }
            Interlocked.Increment(ref activeThreadCount);
            try
            {
                using (TcpClient client = listener.EndAcceptTcpClient(ar))
                {
                    acceptCompleteEvent.Set();
                    client.ReceiveTimeout = TCPRECEIVETIMEOUT;
                    using (NetworkStream stream = client.GetStream())
                    {
                        uint version = 0;
                        try
                        {
                            version = stream.ReadVersion();
                        }
                        catch (ApplicationException)
                        {
                            //Dropped connection likely
                            Log.InfoFormat("Dropped Connection from {0}", client.Client.RemoteEndPoint.ToString());
                            return;
                        }
                        catch (IOException)
                        {
                            //Dropped connection likely
                            Log.InfoFormat("Dropped Connection from {0}", client.Client.RemoteEndPoint.ToString());
                            return;
                        }
                        if (version != EcpTransportHeader.SUPPORTEDVERSION)
                        {
                            //Log and forcibly close the connection.
                            throw new NotSupportedException("Invalid version received = " + version.ToString(CultureInfo.InvariantCulture.NumberFormat));
                        }
                        EcpTransportHeader transportHeader = stream.ReadAllOf<EcpTransportHeader>();
                        switch (transportHeader.ServiceType)
                        {
                            case ServiceType.TcdAdmin:
                                HandleTcdAdminMessage(transportHeader, stream);
                                break;
                            case ServiceType.TcdAdminResync:
                                HandleTcdAdminResyncMessage(stream);
                                break;
                            case ServiceType.TcdMaster:
                                HandleTcdMasterMessage(transportHeader, stream);
                                break;

                            default:
                                throw new NotSupportedException("Invalid Service Type Received:" + transportHeader.ToString());
                        }
                        //Read to block for other end to close the connection.                        
                        stream.Close();
                    }
                    client.Close();
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error received while handling client.", ex);
            }
            finally
            {
                Interlocked.Decrement(ref activeThreadCount);
            }
        }

        private void HandleTcdAdminResyncMessage(NetworkStream stream)
        {
            try
            {
                byte[] buffer;
                int appVersion = (int)stream.ReadVersion();
                Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader = stream.ReadAllOf<Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader>();

                if (adminHeader.MessageType != TcdAdminMessageTypes.TcdResyncAll)
                {
                    Log.Info("Resynch All started..");
                    TcdAdminRequestBase request = TcdTcpEntityFactory.GetResyncRequestEntity(Log, (TcdAppVersion)appVersion, adminHeader);
                    buffer = request.GetResyncData();
                    Push.PushAllPlantEntities(buffer, adminHeader.UserId);
                }
                else
                {
                    PlantService plantService = new PlantService();
                    Plant plant = plantService.GetPlantDetails();

                    Push.PushAllPlantEntities(plant.EcoalabAccountNumber, adminHeader.UserId);
                }

            }
            catch (Exception ex)
            {
                Log.Error("Exception Received in HandleTcdAdminMessage", ex);
            }

        }

        private void HandleTcdAdminMessage(EcpTransportHeader transportHeader, NetworkStream stream)
        {
            try
            {
                int appVersion = (int)stream.ReadVersion();
                Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader = stream.ReadAllOf<Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader>();
                byte[] inputBuffer = stream.ReadAllOf(adminHeader.PayloadSize);

                if (Log.IsInfoEnabled)
                {
                    Log.InfoFormat("{0}-{1}-{2}", transportHeader.ControllerId, appVersion, ExportHelper.StructToString(adminHeader));
                }
                int userId = adminHeader.UserId;
                adminHeader.UserId = 0;
                TcdAdminRequestBase request = TcdTcpEntityFactory.GetRequestEntity(Log, (TcdAppVersion)appVersion, adminHeader, inputBuffer);

                if (request != null)
                {                    
                    TcdErrCodes result = TcdErrCodes.RequestFailed;
                    if (request.CheckResync())
                    {
                        result = TcdErrCodes.RecordNotInSynch;
                    }
                    else
                    {
                        Log.Info("Going for saving in Local..");
                        result = request.ProcessMessage(stream);
                    }
                    Log.Info("Result: " + result.ToString());
                    if (result == TcdErrCodes.Success)
                    {
                        byte[] resultBuffer = request.GetPayload();

                        TcdAdminResponse response = new TcdAdminResponse();
                        Log.Info("Saved in Local..Call to Push to Central..");
                        response = Push.PushToCentral(resultBuffer, userId, (int)adminHeader.MessageType);
                        response.MessageType = (TcdAdminMessageTypes)adminHeader.MessageType;
                        response.Id = request.Id;
                        if (response.ErrorCode == TcdErrCodes.Success)
                        {
                            stream.Write(response);
                        }
                        else
                        {
                            response.ErrorCode = TcdErrCodes.RequestFailed;
                            stream.Write(response);
                        }
                    }
                    else
                    {
                        TcdAdminResponse header = new TcdAdminResponse();
                        header.MessageType = (TcdAdminMessageTypes)adminHeader.MessageType;
                        header.ErrorCode = result;
                        header.Id = request.Id;
                        stream.Write(header);
                    }
                }
                else
                {
                    Log.WarnFormat("Got Update Message Type we don't recognize = {0}", adminHeader.MessageType);

                    //This is NOT an update message  Respond with failure
                    TcdAdminResponse header = new TcdAdminResponse();
                    header.MessageType = (TcdAdminMessageTypes)(adminHeader.MessageType + 1);
                    header.ErrorCode = TcdErrCodes.RequestFailed;
                    stream.Write(header);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Exception Received in HandleTcdAdminMessage", ex);
            }
        }

        private void HandleTcdMasterMessage(EcpTransportHeader transportHeader, NetworkStream stream)
        {
            try
            {
                int appVersion = (int)stream.ReadVersion();
                Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader adminHeader = stream.ReadAllOf<Ecolab.Conduit.TcpHostService.Common.TcdAdminRequestHeader>();
                byte[] inputBuffer = stream.ReadAllOf(adminHeader.PayloadSize);

                if (Log.IsInfoEnabled)
                {
                    Log.InfoFormat("{0}-{1}-{2}", transportHeader.ControllerId, appVersion, ExportHelper.StructToString(adminHeader));
                }

                TcdAdminRequestBase request = TcdTcpEntityFactory.GetListRequestEntity(Log, (TcdAppVersion)appVersion, adminHeader, inputBuffer);

                if (request != null)
                {
                    TcdErrCodes result = request.ProcessMessage(stream);
                    TcdAdminResponse header = new TcdAdminResponse();
                    header.MessageType = (TcdAdminMessageTypes)adminHeader.MessageType;
                    header.ErrorCode = result;
                    stream.Write(header);
                }
                else
                {
                    Log.WarnFormat("Got Update Message Type we don't recognize = {0}", adminHeader.MessageType);

                    //This is NOT an update message  Respond with failure
                    TcdAdminResponse header = new TcdAdminResponse();
                    header.MessageType = (TcdAdminMessageTypes)(adminHeader.MessageType + 1);
                    header.ErrorCode = TcdErrCodes.RequestFailed;
                    stream.Write(header);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Exception Received in HandleTcdAdminMessage", ex);
            }
        }

        /// <summary>
        /// Get Sync Configuration settings
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetConfiguration(string serviceName)
        {
            SyncConfigSettingService syncConfigSettingService = new SyncConfigSettingService();
            return syncConfigSettingService.GetAppConfigKeyValueDetails(serviceName);
        }

    }
}
