﻿// -----------------------------------------------------------------------
// <copyright file="MsgPackConverter.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Message pack converter</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.TcpHostService.Helpers
{
    using System.IO;
    using MsgPack.Serialization;

    /// <summary>
    ///     Message pack converter class
    /// </summary>
    public static class MsgPackConverter
    {
        /// <summary>
        ///     Gets the desrialized object for Type T
        /// </summary>
        /// <typeparam name="T">Type</typeparam>
        /// <param name="data">Byte array</param>
        /// <returns>Entity T</returns>
        public static T GetData<T>(byte[] data)
        {
            T objDeSer = Deserialize<T>(data);
            return objDeSer;
        }

        /// <summary>
        ///     Unpack message pack
        /// </summary>
        /// <typeparam name="T">Type T</typeparam>
        /// <param name="bytes">byte array</param>
        /// <returns>Type T Entity</returns>
        private static T Deserialize<T>(byte[] bytes)
        {
            MessagePackSerializer<T> serializer = MessagePackSerializer.Get<T>();
            using (MemoryStream byteStream = new MemoryStream(bytes))
            {
                return serializer.Unpack(byteStream);
            }
        }
    }
}