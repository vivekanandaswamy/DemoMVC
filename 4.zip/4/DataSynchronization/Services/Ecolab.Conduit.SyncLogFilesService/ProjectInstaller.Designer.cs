﻿// -----------------------------------------------------------------------
// <copyright file="ProjectInstaller.Designer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ProjectInstaller </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLogFilesService
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.syncLogFilesProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.syncLogFileServiceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // syncLogFilesProcessInstaller
            // 
            this.syncLogFilesProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalService;
            this.syncLogFilesProcessInstaller.Password = null;
            this.syncLogFilesProcessInstaller.Username = null;
            // 
            // syncLogFileServiceInstaller
            // 
            this.syncLogFileServiceInstaller.Description = "This service will pick log files and send to TCP.";
            this.syncLogFileServiceInstaller.DisplayName = "Ecolab Sync Log File Service.";
            this.syncLogFileServiceInstaller.ServiceName = "Ecolab Sync Log File Service.";
            this.syncLogFileServiceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.syncLogFilesProcessInstaller,
            this.syncLogFileServiceInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller syncLogFilesProcessInstaller;
        private System.ServiceProcess.ServiceInstaller syncLogFileServiceInstaller;
    }
}