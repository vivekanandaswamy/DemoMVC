﻿// -----------------------------------------------------------------------
// <copyright file="TestService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TestService </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLogFilesService
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;
    using log4net;

	/// <summary>
	/// The Test Service
	/// </summary>
    public partial class TestService : Form
    {
        private static readonly ILog Log = LogManager.GetLogger("SyncLogFileService");
        private static Dictionary<string, string> dicLogConfigSettings = new Dictionary<string, string>();
        private readonly SyncLogFileService syncLogFileServices = new SyncLogFileService();

        public TestService()
        {
            InitializeComponent();
            Trace.Listeners.Add(new DebugFormTraceListener(LogOutput));
        }

        private void BtnStartLogFileService_Click(object sender, EventArgs e)
        {
            syncLogFileServices.Start();
            lblLog.Text = "Service Running.";
            lblLog.ForeColor = Color.Green;
        }

        private void BtnStopLogFileService_Click(object sender, EventArgs e)
        {
            if (syncLogFileServices.CanStop)
            {
                syncLogFileServices.Stop();
                lblLog.ForeColor = Color.Red;
                lblLog.Text = "Service Stopped.";
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
        }

        private void TestService_Load(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;
            try
            {
                dicLogConfigSettings = SyncLogFileService.GetConfiguration("SyncLogFile");
                if (dicLogConfigSettings != null && dicLogConfigSettings.Count() > 5)
                {
                    txtServer.Text = dicLogConfigSettings["HostName"];
                    txtPort.Text = dicLogConfigSettings["PortNumber"];
                    txtTimeOut.Text = dicLogConfigSettings["ReadTimeout"];
                    txtAutoReset.Text = dicLogConfigSettings["AutoReset"];
                    txtTimerEnabled.Text = dicLogConfigSettings["TimerEnabled"];
                    txtTimerInterval.Text = dicLogConfigSettings["TimerInterval"];
                }
                else
                {
                    lblError.Text = "Configuration setting is missing.";
                    Log.Error("Configuration setting is missing.");
                }
            }
            catch (Exception ex)
            {
                Log.Info("Configuration setting is missing.");
                Log.Error("Error : " + ex.Message);
            }
        }
    }

    internal class DebugFormTraceListener : TraceListener
    {
        private readonly TextBox LogTextBox;

        public DebugFormTraceListener(TextBox logTextBox)
        {
            LogTextBox = logTextBox;
        }

        public override void Write(string message)
        {
            if (LogTextBox.InvokeRequired)
            {
                LogTextBox.Invoke((MethodInvoker) delegate { Write(message); });
                return;
            }

            LogTextBox.AppendText(message);
        }

        public override void WriteLine(string message)
        {
            Write(message);
            Write(Environment.NewLine);
        }
    }
}