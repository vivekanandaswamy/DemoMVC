﻿// -----------------------------------------------------------------------
// <copyright file="ProjectInstaller.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ProjectInstaller </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLogFilesService
{
    using System.ComponentModel;
    using System.Configuration.Install;

    [RunInstaller(true)]
    public partial class ProjectInstaller : Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }
    }
}