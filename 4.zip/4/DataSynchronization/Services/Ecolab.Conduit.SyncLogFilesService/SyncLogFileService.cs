﻿// -----------------------------------------------------------------------
// <copyright file="SyncLogFileService.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Sync LogFile Service</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncLogFilesService
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net.Sockets;
    using System.Runtime.Serialization.Formatters.Binary;
    using System.ServiceProcess;
    using System.Timers;
    using Ecolab.Models;
    using Ecolab.Services;
    using Library.Common;
    using Library.Helpers;
    using log4net;
    using MsgPack.Serialization;
    using Services.SyncConfigSettingService;
    using SyncLibrary.Common;
    using SyncLibrary.Enum;
    using ServiceType = Library.Enums.ServiceType;

    public partial class SyncLogFileService : ServiceBase
    {
        private static Dictionary<string, string> dicLogConfiguration = new Dictionary<string, string>();
        private static readonly ILog Log = LogManager.GetLogger("SyncLogFileService");
        private Timer processTimer;
        private static bool DblogSync = true;

        public SyncLogFileService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (!Debugger.IsAttached)
            {
                dicLogConfiguration = GetConfiguration("SyncLogFile");
                processTimer = new Timer();
                processTimer.AutoReset = bool.Parse(dicLogConfiguration["AutoReset"]);

                processTimer.Start();
                processTimer.Elapsed += RestartProcess;
            }
            else
            {
                ProcessSyncLogData();
            }
        }

        private void RestartProcess(object sender, EventArgs e)
        {
            processTimer.Stop(); //stop the timer till process doesn't complete.
            ProcessSyncLogData();
            processTimer.Enabled = bool.Parse(dicLogConfiguration["TimerEnabled"]);
            processTimer.Interval = double.Parse(dicLogConfiguration["TimerInterval"], CultureInfo.InvariantCulture.NumberFormat);
            processTimer.Start(); // start the time. It will take Interval time to fire next time.
        }

        internal void Start()
        {
            Log.Info("Log File Service started.");
            OnStart(null);
        }

        protected override void OnStop()
        {
            Log.Info("Log File Service stopped.");
            if (!Debugger.IsAttached)
            {
                processTimer.Stop();
            }
        }

        private static void ProcessSyncLogData()
        {
            try
            {
                dicLogConfiguration = GetConfiguration("SyncLogFile");
                Log.Info(" ** Sync Log Data process started. ** ");

                string folderPath = dicLogConfiguration["FolderPath"];
                DirectoryInfo directory = new DirectoryInfo(folderPath);

                if (DblogSync == true)
                {
                    List<Logs> logsdata = GetLogsData();

                    if (logsdata.Count > 0)
                    {
                        Log.Info("No of Logs count = " + logsdata.Count);

                        using (TcpClient client = new TcpClient())
                        {
                            client.ReceiveTimeout = int.Parse(dicLogConfiguration["ReadTimeout"], CultureInfo.InvariantCulture.NumberFormat);
                            client.Connect(dicLogConfiguration["HostName"], int.Parse(dicLogConfiguration["PortNumber"], CultureInfo.InvariantCulture.NumberFormat));

                            Log.Info("Process Sync Log Data: Host Name = " + dicLogConfiguration["HostName"] + " , PortNumber = " + int.Parse(dicLogConfiguration["PortNumber"], CultureInfo.InvariantCulture) + " , Server connection established. ");

                            using (NetworkStream stream = client.GetStream())
                            {
                                //======= transport header =========================================================
                                SendTransportHeader transportHeader = new SendTransportHeader();
                                transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                                transportHeader.Body.ServiceType = ServiceType.TcdLogging;

                                Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogging);

                                XMLSerializing xmlserialize = new XMLSerializing();
                                string xmlString = xmlserialize.ConvertToXML(logsdata);

                                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(xmlString);

                                TcdLogRequest loggingRequest = new TcdLogRequest { AppVersion = (uint)((int)TcdAppVersion.VersionCurrent), MessageType = TcdMessageTypes.LogRequest, PayloadSize = (uint)buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack };

                                Log.Info("Message Type = " + TcdMessageTypes.LogRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                                // ============== Write to stream ==================================================
                                stream.Write(transportHeader);
                                stream.Write(loggingRequest);
                                stream.Write(buffer, 0, buffer.Length);

                                //======== read the response from tcp server =======================================
                                TcdLoggingResponse response = stream.ReadAllOf<TcdLoggingResponse>();
                                Log.Info("Response " + response);
                            }
                        }
                    }
                }
                else
                {
                    foreach (FileInfo file in directory.GetFiles())
                    {
                        using (TcpClient client = new TcpClient())
                        {
                            client.ReceiveTimeout = int.Parse(dicLogConfiguration["ReadTimeout"], CultureInfo.InvariantCulture.NumberFormat);
                            client.Connect(dicLogConfiguration["HostName"], int.Parse(dicLogConfiguration["PortNumber"], CultureInfo.InvariantCulture.NumberFormat));

                            Log.Info("Process Sync Log Data: Host Name = " + dicLogConfiguration["HostName"] + " , PortNumber = " + int.Parse(dicLogConfiguration["PortNumber"], CultureInfo.InvariantCulture) + " , Server connection established. ");

                            using (NetworkStream stream = client.GetStream())
                            {
                                //======= transport header =========================================================
                                SendTransportHeader transportHeader = new SendTransportHeader();
                                transportHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                                transportHeader.Body.ServiceType = ServiceType.TcdLogging;

                                Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogging);

                                byte[] buffer = CompressHelper.Compress(File.ReadAllBytes(file.FullName));

                                TcdLoggingRequest loggingRequest = new TcdLoggingRequest { FileName = file.FullName, LogFileType = TcdLoggingFileType.Sync_Batch_Data_Log, PayloadSize = (uint)buffer.Length };

                                Log.Info("File Type = " + TcdLoggingFileType.Sync_Batch_Data_Log + " , Payload Size = " + buffer.Length + " , File Name = " + file.FullName);

                                // ============== Write to stream ==================================================
                                stream.Write(transportHeader);
                                stream.Write(loggingRequest);
                                stream.Write(buffer, 0, buffer.Length);

                                //======== read the response from tcp server =======================================
                                TcdLoggingResponse response = stream.ReadAllOf<TcdLoggingResponse>();
                                Log.Info("Response " + response);
                            }
                        }
                    }
                }

            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While process Log data :" + socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured while process Log data :" + ex);
            }
        }

        private static List<Logs> GetLogsData()
        {
            int NoOfRecordsToBeProcessed = int.Parse(dicLogConfiguration["NoOfRecordsToBeProcessed"], CultureInfo.CurrentCulture);
            LogService logService = new LogService();
            List<Logs> logs = logService.GetLogsData();

            return logs.Take(NoOfRecordsToBeProcessed).ToList();
        }

        /// <summary>
        ///     Get Configuration
        /// </summary>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetConfiguration(string serviceName)
        {
            SyncConfigSettingService objSyncConfigSettingService = new SyncConfigSettingService();
            return objSyncConfigSettingService.GetAppConfigKeyValueDetails(serviceName);
        }
    }
}