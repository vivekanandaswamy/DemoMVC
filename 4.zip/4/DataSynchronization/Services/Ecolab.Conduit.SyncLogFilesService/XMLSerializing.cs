﻿// -----------------------------------------------------------------------
// <copyright file="XMLSerializing.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>XMLSerializing </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using test = Ecolab.Conduit.SyncLogFilesService.XMLSerializerTableFormat;

namespace Ecolab.Conduit.SyncLogFilesService
{
    public class XMLSerializing
    {
        public string ConvertToXML(List<Models.Logs> logsdata)
        {
            test.Tables tables = new test.Tables();

            List<test.Table> listOfTable = new List<test.Table>();

            test.Table table = new test.Table();
            table = CreateLogTable(logsdata);
            listOfTable.Add(table);

            tables.Table = listOfTable;

            string fileName = "D:\\LogXML.XML";
            var serializer = new XmlSerializer(typeof(test.Tables));
            using (var stream = File.Create(fileName))
            {
                serializer.Serialize(stream, tables);
            }
            string fileContents = File.ReadAllText(fileName);

            return fileContents;
        }

        private test.Table CreateLogTable(List<Models.Logs> logsdata)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[Logs]";
            test.Rows rows = new test.Rows();
            List<test.Row> ListOfrowsforLogsData = new List<test.Row>();
            ListOfrowsforLogsData = FormatLogData(logsdata);
            rows.Row = ListOfrowsforLogsData;
            table.Rows = rows;

            return table;
        }

        private List<test.Row> FormatLogData(List<Models.Logs> logsdata)
        {
            List<test.Row> ListOfrows = new List<test.Row>();

            foreach (var item in logsdata)
            {
                test.Row row = new test.Row();
                test.Columns cols = new test.Columns();
                List<test.Column> listOfColumn = new List<test.Column>();

                var properties = from property in item.GetType().GetProperties()
                                 where property.PropertyType.IsPrimitive ||
                                       property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                 select property;

                foreach (var property in properties)
                {
                    test.Column col = new test.Column();
                    var name = property.Name;
                    col.Name = name;
                    var value = property.GetValue(item, null);
                    if (value != null)
                    {
                        col.Value = value.ToString();
                    }

                    listOfColumn.Add(col);
                }

                cols.Column = listOfColumn;
                row.Columns = cols;

                ListOfrows.Add(row);
            }
            return ListOfrows;
        }
    }
}
