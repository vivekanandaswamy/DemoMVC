﻿// -----------------------------------------------------------------------
// <copyright file="TestService.Designer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TestService </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLogFilesService
{
    partial class TestService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.LogOutput = new System.Windows.Forms.TextBox();
            this.lblLog = new System.Windows.Forms.Label();
            this.btnStopLogFileService = new System.Windows.Forms.Button();
            this.btnStartLogFileService = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTimerInterval = new System.Windows.Forms.TextBox();
            this.txtTimerEnabled = new System.Windows.Forms.TextBox();
            this.txtAutoReset = new System.Windows.Forms.TextBox();
            this.txtTimeOut = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtServer = new System.Windows.Forms.TextBox();
            this.lblError = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.LogOutput);
            this.groupBox1.Controls.Add(this.lblLog);
            this.groupBox1.Controls.Add(this.btnStopLogFileService);
            this.groupBox1.Controls.Add(this.btnStartLogFileService);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(7, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(610, 472);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Log File Service";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(340, 22);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(99, 27);
            this.btnClear.TabIndex = 13;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // LogOutput
            // 
            this.LogOutput.Location = new System.Drawing.Point(11, 64);
            this.LogOutput.Multiline = true;
            this.LogOutput.Name = "LogOutput";
            this.LogOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LogOutput.Size = new System.Drawing.Size(575, 402);
            this.LogOutput.TabIndex = 12;
            // 
            // lblLog
            // 
            this.lblLog.AutoSize = true;
            this.lblLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLog.Location = new System.Drawing.Point(489, 30);
            this.lblLog.Name = "lblLog";
            this.lblLog.Size = new System.Drawing.Size(11, 13);
            this.lblLog.TabIndex = 11;
            this.lblLog.Text = ".";
            // 
            // btnStopLogFileService
            // 
            this.btnStopLogFileService.Location = new System.Drawing.Point(172, 22);
            this.btnStopLogFileService.Name = "btnStopLogFileService";
            this.btnStopLogFileService.Size = new System.Drawing.Size(149, 27);
            this.btnStopLogFileService.TabIndex = 9;
            this.btnStopLogFileService.Text = "Stop Log File Services";
            this.btnStopLogFileService.UseVisualStyleBackColor = true;
            this.btnStopLogFileService.Click += new System.EventHandler(this.BtnStopLogFileService_Click);
            // 
            // btnStartLogFileService
            // 
            this.btnStartLogFileService.Location = new System.Drawing.Point(16, 23);
            this.btnStartLogFileService.Name = "btnStartLogFileService";
            this.btnStartLogFileService.Size = new System.Drawing.Size(150, 27);
            this.btnStartLogFileService.TabIndex = 8;
            this.btnStartLogFileService.Text = "Start Log File Service";
            this.btnStartLogFileService.UseVisualStyleBackColor = true;
            this.btnStartLogFileService.Click += new System.EventHandler(this.BtnStartLogFileService_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblError);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtTimerInterval);
            this.groupBox2.Controls.Add(this.txtTimerEnabled);
            this.groupBox2.Controls.Add(this.txtAutoReset);
            this.groupBox2.Controls.Add(this.txtTimeOut);
            this.groupBox2.Controls.Add(this.txtPort);
            this.groupBox2.Controls.Add(this.txtServer);
            this.groupBox2.ForeColor = System.Drawing.Color.ForestGreen;
            this.groupBox2.Location = new System.Drawing.Point(623, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(226, 233);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Configuration Details";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(13, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Timer Interval";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(13, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Timer Enabled";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(13, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Timer AutoReset";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(13, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Read Timeout";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(13, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Port Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Host Name";
            // 
            // txtTimerInterval
            // 
            this.txtTimerInterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimerInterval.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtTimerInterval.Location = new System.Drawing.Point(111, 157);
            this.txtTimerInterval.Name = "txtTimerInterval";
            this.txtTimerInterval.ReadOnly = true;
            this.txtTimerInterval.Size = new System.Drawing.Size(100, 20);
            this.txtTimerInterval.TabIndex = 5;
            // 
            // txtTimerEnabled
            // 
            this.txtTimerEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimerEnabled.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtTimerEnabled.Location = new System.Drawing.Point(111, 130);
            this.txtTimerEnabled.Name = "txtTimerEnabled";
            this.txtTimerEnabled.ReadOnly = true;
            this.txtTimerEnabled.Size = new System.Drawing.Size(100, 20);
            this.txtTimerEnabled.TabIndex = 4;
            // 
            // txtAutoReset
            // 
            this.txtAutoReset.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAutoReset.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtAutoReset.Location = new System.Drawing.Point(111, 103);
            this.txtAutoReset.Name = "txtAutoReset";
            this.txtAutoReset.ReadOnly = true;
            this.txtAutoReset.Size = new System.Drawing.Size(100, 20);
            this.txtAutoReset.TabIndex = 3;
            // 
            // txtTimeOut
            // 
            this.txtTimeOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTimeOut.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtTimeOut.Location = new System.Drawing.Point(111, 76);
            this.txtTimeOut.Name = "txtTimeOut";
            this.txtTimeOut.ReadOnly = true;
            this.txtTimeOut.Size = new System.Drawing.Size(100, 20);
            this.txtTimeOut.TabIndex = 2;
            // 
            // txtPort
            // 
            this.txtPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPort.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtPort.Location = new System.Drawing.Point(111, 49);
            this.txtPort.Name = "txtPort";
            this.txtPort.ReadOnly = true;
            this.txtPort.Size = new System.Drawing.Size(100, 20);
            this.txtPort.TabIndex = 1;
            // 
            // txtServer
            // 
            this.txtServer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtServer.ForeColor = System.Drawing.Color.ForestGreen;
            this.txtServer.Location = new System.Drawing.Point(111, 22);
            this.txtServer.Name = "txtServer";
            this.txtServer.ReadOnly = true;
            this.txtServer.Size = new System.Drawing.Size(100, 20);
            this.txtServer.TabIndex = 0;
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(24, 201);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 13);
            this.lblError.TabIndex = 12;
            // 
            // TestService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 481);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "TestService";
            this.Text = "Log File Service Test";
            this.Load += new System.EventHandler(this.TestService_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblLog;
        private System.Windows.Forms.Button btnStopLogFileService;
        private System.Windows.Forms.Button btnStartLogFileService;
        private System.Windows.Forms.TextBox LogOutput;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTimerInterval;
        private System.Windows.Forms.TextBox txtTimerEnabled;
        private System.Windows.Forms.TextBox txtAutoReset;
        private System.Windows.Forms.TextBox txtTimeOut;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.TextBox txtServer;
        private System.Windows.Forms.Label lblError;
    }
}