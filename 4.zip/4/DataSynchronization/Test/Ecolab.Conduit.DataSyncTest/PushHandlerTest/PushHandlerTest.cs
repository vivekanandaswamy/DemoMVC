﻿namespace Ecolab.Conduit.DataSyncTest.PushHandlerTest
{
    using System;
    using System.Configuration;
    using Data.Access;
    using Library.Enums;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using PushHandler;

    [TestClass]
    public class PushHandlerTest : TestBase
    {
        [TestMethod]
        public void PushToQueueTest()
        {
            int status = 1;
            PlantContact plantContact = new PlantContact { ContactFirstName = "FNAme", ContactLastName = "LName", ContactEmailAdresss = "mail@mail.com", ContactFaxNumber = "12345678", ContactMobilePhone = "8080808808", ContactOfficePhone = "4568923", ContactPositionId = 5, ContactTitle = "Mr", EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), ContactPositionName = "testPostition" };
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            status = Push.PushToQueue(plantContact, 1, 2, (int) TcdAdminMessageTypes.TcdAddPlantContact, plantContact.EcoalabAccountNumber);
            Assert.AreEqual(0, status);
        }

        //[TestMethod]
        //public void PushToLocalTest()
        //{
        //    int status = 1;
        //    PlantContact objPlantContact = new PlantContact { Id = 1, EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), ContactFirstName = "Local", ContactLastName = "One", ContactTitle = "LocalToCentral", ContactPositionId = 1, ContactPositionName = "PositionLocal", ContactEmailAdresss = "abc@abc.com", ContactOfficePhone = "1234abc", ContactMobilePhone = "4754", ContactFaxNumber = "fax123", LastSyncTime = DateTime.UtcNow };

        //    Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
        //    status = Push.PushToLocal(objPlantContact, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1, 1);
        //    Assert.AreEqual(0, status);
        //}

        [TestMethod]
        public void PushToCentral()
        {
            //PlantContact objPlantContact = new PlantContact
            //{
            //    Id = 1,
            //    EcoalabAccountNumber = "ECOPLANT5",
            //    ContactFirstName = "Central",
            //    ContactLastName = "One",
            //    ContactTitle = "CentraltoLocal",
            //    ContactPositionId = 1,
            //    ContactPositionName = "PositionCentral",
            //    ContactEmailAdresss = "abc@abc.com",
            //    ContactOfficePhone = "1234abc",
            //    ContactMobilePhone = "4754",
            //    ContactFaxNumber = "fax123",
            //    LastSyncTime = DateTime.UtcNow

            //};

            //Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            //byte[] arrBytePlantContact = Ecolab.Models.SyncMessages.Helpers.ObjectToByteArrayHelper.ObjectToByteArray<PlantContact>(objPlantContact);
            //TcdAdminResponse objTcdAdminResponse = new TcdAdminResponse();
            //objTcdAdminResponse = Push.PushToCentral(arrBytePlantContact, "ECOPLANT5", 1, 1);
            //Assert.IsNotNull(objTcdAdminResponse);
        }
    }
}