﻿namespace Ecolab.Conduit.PushHandler.Test.PushHandlerTest
{
    using DataSyncTest;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ResyncEngineTest : TestBase
    {
    }
}