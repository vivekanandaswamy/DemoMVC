﻿namespace Ecolab.Conduit.DataSyncTest
{
    using System.Configuration;
    using Data.Access;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    ///     TestBase
    /// </summary>
    [TestClass]
    public class TestBase
    {
        [TestInitialize]
        public void Init()
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
        }
    }
}