﻿namespace Ecolab.Conduit.PushHandler.Test.SyncBatchDataTest
{
    using DataSyncTest;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class SyncBatchDataTest : TestBase
    {
        [TestMethod]
        public void SyncBatchDataServiceTest()
        {
            //TO DO
        }
    }
}