﻿namespace Ecolab.Conduit.PushHandler.Test.TcpHostTest
{
    using DataSyncTest;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TcpHostTest : TestBase
    {
        [TestMethod]
        public void TcpHostServiceTest()
        {
            //TO DO
        }
    }
}