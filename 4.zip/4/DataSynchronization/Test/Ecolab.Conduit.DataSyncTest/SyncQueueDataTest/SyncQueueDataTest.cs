﻿namespace Ecolab.Conduit.PushHandler.Test.SyncQueueDataTest
{
    using DataSyncTest;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class SyncQueueDataTest : TestBase
    {
        [TestMethod]
        public void SyncQueueDataServiceTest()
        {
            //TO DO
        }
    }
}