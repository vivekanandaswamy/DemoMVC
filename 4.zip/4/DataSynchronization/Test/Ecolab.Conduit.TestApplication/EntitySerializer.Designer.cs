﻿namespace Ecolab.Conduit.PushTest
{
    partial class EntitySerializer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnXmlSerializer = new System.Windows.Forms.Button();
			this.btnXmlDeSerializer = new System.Windows.Forms.Button();
			this.btnPushAllEntities = new System.Windows.Forms.Button();
			this.FTR = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnXmlSerializer
			// 
			this.btnXmlSerializer.Location = new System.Drawing.Point(38, 33);
			this.btnXmlSerializer.Name = "btnXmlSerializer";
			this.btnXmlSerializer.Size = new System.Drawing.Size(209, 35);
			this.btnXmlSerializer.TabIndex = 0;
			this.btnXmlSerializer.Text = "XML Serializer";
			this.btnXmlSerializer.UseVisualStyleBackColor = true;
			this.btnXmlSerializer.Click += new System.EventHandler(this.btnXmlSerializer_Click);
			// 
			// btnXmlDeSerializer
			// 
			this.btnXmlDeSerializer.Location = new System.Drawing.Point(38, 76);
			this.btnXmlDeSerializer.Name = "btnXmlDeSerializer";
			this.btnXmlDeSerializer.Size = new System.Drawing.Size(209, 35);
			this.btnXmlDeSerializer.TabIndex = 1;
			this.btnXmlDeSerializer.Text = "Xml DeSerializer";
			this.btnXmlDeSerializer.UseVisualStyleBackColor = true;
			this.btnXmlDeSerializer.Click += new System.EventHandler(this.btnXmlDeSerializer_Click);
			// 
			// btnPushAllEntities
			// 
			this.btnPushAllEntities.Location = new System.Drawing.Point(38, 118);
			this.btnPushAllEntities.Name = "btnPushAllEntities";
			this.btnPushAllEntities.Size = new System.Drawing.Size(209, 42);
			this.btnPushAllEntities.TabIndex = 2;
			this.btnPushAllEntities.Text = "Push All Entities";
			this.btnPushAllEntities.UseVisualStyleBackColor = true;
			this.btnPushAllEntities.Click += new System.EventHandler(this.btnPushAllEntities_Click);
			// 
			// FTR
			// 
			this.FTR.Location = new System.Drawing.Point(38, 166);
			this.FTR.Name = "FTR";
			this.FTR.Size = new System.Drawing.Size(209, 41);
			this.FTR.TabIndex = 3;
			this.FTR.Text = "FirstTimeRequest(local-central)";
			this.FTR.UseVisualStyleBackColor = true;
			this.FTR.Click += new System.EventHandler(this.FTR_Click);
			// 
			// EntitySerializer
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(293, 338);
			this.Controls.Add(this.FTR);
			this.Controls.Add(this.btnPushAllEntities);
			this.Controls.Add(this.btnXmlDeSerializer);
			this.Controls.Add(this.btnXmlSerializer);
			this.Name = "EntitySerializer";
			this.Text = "XmlSerializer";
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnXmlSerializer;
        private System.Windows.Forms.Button btnXmlDeSerializer;
        private System.Windows.Forms.Button btnPushAllEntities;
		private System.Windows.Forms.Button FTR;
    }
}