﻿namespace Ecolab.Conduit.PushTest
{
    using System;
    using System.Windows.Forms;
    using log4net.Config;

    internal static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            XmlConfigurator.Configure();
            Application.Run(new Main());
        }
    }
}