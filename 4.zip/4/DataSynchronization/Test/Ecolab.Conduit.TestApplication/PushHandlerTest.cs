﻿using Ecolab.Conduit.PushHandler;

namespace Ecolab.Conduit.PushTest
{
    using Ecolab.Conduit.Library.Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.Library.Helpers;
    using Ecolab.Data.Access;
    using Ecolab.Models;
    using Ecolab.Models.SyncMessages;
    using Ecolab.Services;
    using Entities.PlantSetup;
    using System;
    using System.Configuration;
    using System.Windows.Forms;

    public partial class PushHandlerTest : Form
    {
        public PushHandlerTest()
        {
            InitializeComponent();
        }

        private void frmPushWrapperTest_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Push To Queue Button Click Event
        /// </summary>      
        private void btnPushToQueue_Click(object sender, EventArgs e)
        {
            int status = 1;

            if (chkMeter.Checked == false && chkPlantData.Checked == false && ChkPlantSetupData.Checked == false)
            {
                MessageBox.Show("Pls. select meter or plant or plant setup.");
                return;
            }

            if (chkMeter.Checked && chkPlantData.Checked && ChkPlantSetupData.Checked)
            {
                MessageBox.Show("Pls. select either meter or plant or plant setup.");
                return;
            }
            else
                if (chkMeter.Checked && chkPlantData.Checked)
            {
                MessageBox.Show("Pls. select either meter or plant.");
                return;
            }
            else
                    if (chkPlantData.Checked && ChkPlantSetupData.Checked)
            {
                MessageBox.Show("Pls. select either plant or plant setup.");
                return;
            }
            else if (chkMeter.Checked && ChkPlantSetupData.Checked)
            {
                MessageBox.Show("Pls. select either meter or plant setup.");
                return;
            }


            try
            {
                if (chkMeter.Checked)
                {
                    Meter meter = new Meter
                    {
                        EcolabAccountNumber = "ECOPLANT5",
                        Description = "Meter1",
                        MeterType = "MeterType1",
                        UtilityLocation = "UT1",
                        MaxValueLimit = 1,
                        MeterTickUnit = "1",
                        UsageFactor = 1
                    };
                    Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                    status = PushHandler.Push.PushToQueue<Meter>(meter, 1, 5, (int)TcdAdminMessageTypes.TcdAddMeters, meter.EcolabAccountNumber);
                }

                if (chkPlantData.Checked)
                {
                    PlantContact plantContact = new PlantContact
                    {
                        Id = 23,
                        ContactFirstName = "FName",
                        ContactLastName = "LName",
                        ContactEmailAdresss = "mail@mail.com",
                        ContactFaxNumber = "12345678",
                        ContactMobilePhone = "8080808808",
                        ContactOfficePhone = "4568923",
                        ContactPositionId = 5,
                        ContactTitle = "Mr",
                        EcoalabAccountNumber = "1",
                        ContactPositionName = "testPostition",
                        IsDelete = false,
                        MaxNumberOfRecords = 5,
                        LastModifiedTimeStamp = DateTime.Now
                    };
                    Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                    status = PushHandler.Push.PushToQueue<PlantContact>(plantContact, 1, 2, (int)TcdAdminMessageTypes.TcdAddPlantContact, plantContact.EcoalabAccountNumber);
                }
                if (ChkPlantSetupData.Checked)
                {
                    Plant plantData = new Plant
                    {
                        EcoalabAccountNumber = "5",
                        LanguageId = 2,
                        CurrencyCode = "CurrencyCode1",
                        ExportPath = "D:\\Test",
                        DataLiveTime = 3,
                        BudgetCustomer = false,
                        UomId = 2,
                        Rate = 7,
                        Logo = "testlogo",
                        ModifiedBy = "7",
                        AllowManualRewash = false,
                        ModifiedOn = DateTime.Now


                    };
                    Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                    status = PushHandler.Push.PushToQueue<Plant>(plantData, 1, 2, (int)TcdAdminMessageTypes.TcdUpdatePlant, "7");
                }

                if (status == 0)
                    MessageBox.Show("Data send to queue successfully.");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }




        /// <summary>
        /// Push To Local Button Click Event
        /// </summary>      
        private void btnPushToLocal_Click(object sender, EventArgs e)
        {
            try
            {
                Entities.PlantContact objPlantContact = new Entities.PlantContact
                {
                    Id = 1,
                    EcoalabAccountNumber = "1",
                    ContactFirstName = "Local",
                    ContactLastName = "One",
                    ContactTitle = "LocalToCentral",
                    ContactPositionId = 1,
                    ContactPositionName = "PositionLocal",
                    ContactEmailAdresss = "abc@abc.com",
                    ContactOfficePhone = "1234abc",
                    ContactMobilePhone = "4754",
                    ContactFaxNumber = "fax123",
                    LastSyncTime = DateTime.UtcNow,
                    MaxNumberOfRecords = 20

                };

                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());


                int status = PushHandler.Push.PushToLocal<Entities.PlantContact>(objPlantContact, "ECOPLANT5", 1, (int)TcdAdminMessageTypes.TcdAddPlantContact);

                if (status == 0)
                    MessageBox.Show("Data send to Local successfully.");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Push To Central Button Click Event
        /// </summary>      
        private void btnPushToCentral_Click(object sender, EventArgs e)
        {
            try
            {
                Entities.PlantContact objPlantContact = new Entities.PlantContact
                {
                    Id = 1,
                    EcoalabAccountNumber = "ECOPLANT5",
                    ContactFirstName = "Central",
                    ContactLastName = "One",
                    ContactTitle = "CentraltoLocal",
                    ContactPositionId = 1,
                    ContactPositionName = "PositionCentral",
                    ContactEmailAdresss = "abc@abc.com",
                    ContactOfficePhone = "1234abc",
                    ContactMobilePhone = "4754",
                    ContactFaxNumber = "fax123",
                    LastSyncTime = DateTime.UtcNow
                };

                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                byte[] arrBytePlantContact = ObjectToByteArrayHelper.ObjectToByteArray<Entities.PlantContact>(objPlantContact);
                TcdAdminResponse objTcdAdminResponse = new TcdAdminResponse();
                objTcdAdminResponse = PushHandler.Push.PushToCentral(arrBytePlantContact, 1, 1);
                MessageBox.Show("Data send to Central successfully.");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFirstRequest_Click(object sender, EventArgs e)
        {
            try
            {
                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                Push.PushPlantSettings();
                MessageBox.Show("First Time request sent.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR :: " + ex);
            }
        }

        private void btnResync_Click(object sender, EventArgs e)
        {
            try
            {
                TcdAdminMessageTypes tcdAdminMessageTypes = 0;
                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["Trasar3IntegrationConnection"].ToString());

                if (rbtPlantContact.Checked)
                    tcdAdminMessageTypes = TcdAdminMessageTypes.TcdAddPlantContact;
                else if (rbtPlantCustomer.Checked)
                    tcdAdminMessageTypes = TcdAdminMessageTypes.TcdAddPlantCustomer;
                else
                {
                    MessageBox.Show("Plase select a Entity");
                    return;
                }

                ResponseHandler.ProcessResponse(TcdErrCodes.RecordCountNotMatch, tcdAdminMessageTypes, "1");
                MessageBox.Show("Resync Successful");
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR ::: " + ex);
            }
        }

        private void btnReSyncToCentral_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            TcdAllPlantEntities psm = new TcdAllPlantEntities();

            PlantContactService plantContactService = new PlantContactService();
            psm.PlantContactList = plantContactService.GetPlantContactDetails("1");
            string xmlData = ImportExportUtility.SerializeToXmlFromEntity<TcdAllPlantEntities>(psm);
            Push.PushAllPlantEntities(SerializeHelper.ConvertStringToByteArray(xmlData), 1);
        }

        private void btnReSyncAll_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            ResyncEngine.ResyncAll("1");
        }

        private void btnGetPlantSettings_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["Trasar3Connection"].ToString());

            PlantService plantService = new PlantService();
            PlantSettings plantSettings = plantService.GetPlantSettings(txtEcolabAccountNo.Text);

            txtIP.Text = plantSettings.IpAddress;
            txtPort.Text = plantSettings.PortNumber;
        }

        private void btnGetFromCentral_Click(object sender, EventArgs e)
        {
            try
            {
                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                TcdErrCodes status = Push.FetchCentralData("040242802", (int)TcdAdminMessageTypes.TcdGetPlantEntities);
                MessageBox.Show("First Time request sent.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR :: " + ex);
            }
        }
    }
}