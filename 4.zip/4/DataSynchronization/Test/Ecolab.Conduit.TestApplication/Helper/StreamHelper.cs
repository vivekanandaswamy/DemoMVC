﻿namespace Ecolab.Conduit.SyncQueueData.Helpers
{
    using System;
    using System.IO;
    using System.Runtime.InteropServices;

    /// <summary>
    ///     Stream Helper
    /// </summary>
    [CLSCompliant(false)]
    public static class StreamHelper
    {
        /// <summary>
        ///     Read All
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static byte[] ReadAllOf(this Stream stream, long length)
        {
            var buffer = new byte[length];

            int bytesRead = 0;
            int newByteCount;

            while(bytesRead < buffer.Length)
            {
                newByteCount = stream.Read(buffer, bytesRead, buffer.Length - bytesRead);
                bytesRead += newByteCount;
                if(newByteCount == 0)
                {
                    //This connection has been closed.
                    throw new ApplicationException("Socked closed in the middle of a read");
                }
            }

            return buffer;
        }

        /// <summary>
        ///     Read All
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="stream"></param>
        /// <returns></returns>
        public static T ReadAllOf<T>(this Stream stream)
        {
            long length = Marshal.SizeOf(typeof(T));

            byte[] buffer = ReadAllOf(stream, length);

            return StructConverter.GetData<T>(buffer);
        }

        /// <summary>
        ///     Read Version
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public static uint ReadVersion(this Stream stream)
        {
            //4 bytes for an int.
            byte[] buffer = stream.ReadAllOf(4);

            uint version = buffer[0] + ((uint)buffer[1] << 8) + ((uint)buffer[2] << 16) + ((uint)buffer[3] << 24);

            return version;
        }

        /// <summary>
        ///     Write
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="stream"></param>
        /// <param name="toWrite"></param>
        public static void Write<T>(this Stream stream, T toWrite) where T : struct
        {
            byte[] structInBytes = StructureToBytes(toWrite);
            stream.Write(structInBytes, 0, structInBytes.Length);
        }

        /// <summary>
        ///     WriteVersion
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="version"></param>
        public static void WriteVersion(this Stream stream, uint version)
        {
            stream.Write(new[] { (byte)(version & 0xFF), (byte)((version >> 8) & 0xFF), (byte)((version >> 16) & 0xFF), (byte)((version >> 24) & 0xFF) }, 0, 4); //Write version
        }

        /// <summary>
        ///     StructureToBytes
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="structure"></param>
        /// <returns></returns>
        public static byte[] StructureToBytes<T>(T structure)
        {
            int size = Marshal.SizeOf(structure);
            var rtn = new byte[size];
            IntPtr ptr = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(structure, ptr, true);
                Marshal.Copy(ptr, rtn, 0, size);
            }
            finally
            {
                Marshal.FreeHGlobal(ptr);
            }
            return rtn;
        }
    }

    public static class StructConverter
    {
        /// <summary>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public static T GetData<T>(byte[] data)
        {
            GCHandle handle = GCHandle.Alloc(data, GCHandleType.Pinned);
            T val = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
            handle.Free();
            return val;
        }

        /// <summary>
        ///     Get Data
        /// </summary>
        /// <param name="data"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static object GetData(byte[] data, Type type)
        {
            GCHandle handle = GCHandle.Alloc(data, GCHandleType.Pinned);
            object val = Marshal.PtrToStructure(handle.AddrOfPinnedObject(), type);
            handle.Free();
            return val;
        }
    }
}