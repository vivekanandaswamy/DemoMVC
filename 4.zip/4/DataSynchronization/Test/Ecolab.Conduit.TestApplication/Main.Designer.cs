﻿namespace Ecolab.Conduit.PushTest
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPushHandlerTest = new System.Windows.Forms.Button();
            this.btnBatchRequestTest = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnEntitySerializer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPushHandlerTest
            // 
            this.btnPushHandlerTest.Location = new System.Drawing.Point(51, 57);
            this.btnPushHandlerTest.Name = "btnPushHandlerTest";
            this.btnPushHandlerTest.Size = new System.Drawing.Size(187, 36);
            this.btnPushHandlerTest.TabIndex = 0;
            this.btnPushHandlerTest.Text = "Push Handler Test";
            this.btnPushHandlerTest.UseVisualStyleBackColor = true;
            this.btnPushHandlerTest.Click += new System.EventHandler(this.btnPushHandlerTest_Click);
            // 
            // btnBatchRequestTest
            // 
            this.btnBatchRequestTest.Location = new System.Drawing.Point(51, 106);
            this.btnBatchRequestTest.Name = "btnBatchRequestTest";
            this.btnBatchRequestTest.Size = new System.Drawing.Size(187, 36);
            this.btnBatchRequestTest.TabIndex = 1;
            this.btnBatchRequestTest.Text = "Batch Request Test";
            this.btnBatchRequestTest.UseVisualStyleBackColor = true;
            this.btnBatchRequestTest.Click += new System.EventHandler(this.btnBatchRequestTest_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(0, 263);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(299, 37);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "To Add a new test. Add a new form and call that form from Main form.";
            // 
            // btnEntitySerializer
            // 
            this.btnEntitySerializer.Location = new System.Drawing.Point(51, 157);
            this.btnEntitySerializer.Name = "btnEntitySerializer";
            this.btnEntitySerializer.Size = new System.Drawing.Size(187, 36);
            this.btnEntitySerializer.TabIndex = 4;
            this.btnEntitySerializer.Text = "Entity Serializer";
            this.btnEntitySerializer.UseVisualStyleBackColor = true;
            this.btnEntitySerializer.Click += new System.EventHandler(this.btnEntitySerializer_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 300);
            this.Controls.Add(this.btnEntitySerializer);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnBatchRequestTest);
            this.Controls.Add(this.btnPushHandlerTest);
            this.MinimizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Test Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPushHandlerTest;
        private System.Windows.Forms.Button btnBatchRequestTest;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnEntitySerializer;
    }
}