﻿namespace Ecolab.Conduit.PushTest
{
    using System;

    [CLSCompliant(false)]
    public class BaseEntity
    {
        /// <summary>
        ///     Gets or sets the id.
        /// </summary>
        /// <value>The id. field</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> Is Deleted. </value>
        public bool IsDeleted { get; set; }
    }
}