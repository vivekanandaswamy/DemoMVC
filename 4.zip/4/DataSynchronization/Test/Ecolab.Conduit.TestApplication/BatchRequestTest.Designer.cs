﻿namespace Ecolab.Conduit.PushTest
{
    partial class BatchRequestTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetAppConfigKeyValueInfo = new System.Windows.Forms.Button();
            this.btnGetBatchStepWaterUsageData = new System.Windows.Forms.Button();
            this.btnGetBatchWashStepData = new System.Windows.Forms.Button();
            this.btnGetBatchProductData = new System.Windows.Forms.Button();
            this.BatchIdtxt = new System.Windows.Forms.TextBox();
            this.btnGetBatchCustomerData = new System.Windows.Forms.Button();
            this.btnGetBatchData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGetAppConfigKeyValueInfo
            // 
            this.btnGetAppConfigKeyValueInfo.Location = new System.Drawing.Point(55, 236);
            this.btnGetAppConfigKeyValueInfo.Name = "btnGetAppConfigKeyValueInfo";
            this.btnGetAppConfigKeyValueInfo.Size = new System.Drawing.Size(198, 36);
            this.btnGetAppConfigKeyValueInfo.TabIndex = 13;
            this.btnGetAppConfigKeyValueInfo.Text = "Get App Config KeyValue Info";
            this.btnGetAppConfigKeyValueInfo.UseVisualStyleBackColor = true;
           // this.btnGetAppConfigKeyValueInfo.Click += new System.EventHandler(this.btnGetAppConfigKeyValueInfo_Click);
            // 
            // btnGetBatchStepWaterUsageData
            // 
            this.btnGetBatchStepWaterUsageData.Location = new System.Drawing.Point(55, 194);
            this.btnGetBatchStepWaterUsageData.Name = "btnGetBatchStepWaterUsageData";
            this.btnGetBatchStepWaterUsageData.Size = new System.Drawing.Size(198, 36);
            this.btnGetBatchStepWaterUsageData.TabIndex = 12;
            this.btnGetBatchStepWaterUsageData.Text = "Get Batch Step Water UsageData";
            this.btnGetBatchStepWaterUsageData.UseVisualStyleBackColor = true;
            this.btnGetBatchStepWaterUsageData.Click += new System.EventHandler(this.btnGetBatchStepWaterUsageData_Click);
            // 
            // btnGetBatchWashStepData
            // 
            this.btnGetBatchWashStepData.Location = new System.Drawing.Point(55, 152);
            this.btnGetBatchWashStepData.Name = "btnGetBatchWashStepData";
            this.btnGetBatchWashStepData.Size = new System.Drawing.Size(198, 36);
            this.btnGetBatchWashStepData.TabIndex = 11;
            this.btnGetBatchWashStepData.Text = "Get Batch Wash Step Data";
            this.btnGetBatchWashStepData.UseVisualStyleBackColor = true;
            this.btnGetBatchWashStepData.Click += new System.EventHandler(this.btnGetBatchWashStepData_Click);
            // 
            // btnGetBatchProductData
            // 
            this.btnGetBatchProductData.Location = new System.Drawing.Point(55, 110);
            this.btnGetBatchProductData.Name = "btnGetBatchProductData";
            this.btnGetBatchProductData.Size = new System.Drawing.Size(198, 36);
            this.btnGetBatchProductData.TabIndex = 10;
            this.btnGetBatchProductData.Text = "Get Batch Product Data";
            this.btnGetBatchProductData.UseVisualStyleBackColor = true;
            this.btnGetBatchProductData.Click += new System.EventHandler(this.btnGetBatchProductData_Click);
            // 
            // BatchIdtxt
            // 
            this.BatchIdtxt.Location = new System.Drawing.Point(55, 279);
            this.BatchIdtxt.Name = "BatchIdtxt";
            this.BatchIdtxt.Size = new System.Drawing.Size(198, 20);
            this.BatchIdtxt.TabIndex = 9;
            // 
            // btnGetBatchCustomerData
            // 
            this.btnGetBatchCustomerData.Location = new System.Drawing.Point(55, 68);
            this.btnGetBatchCustomerData.Name = "btnGetBatchCustomerData";
            this.btnGetBatchCustomerData.Size = new System.Drawing.Size(198, 36);
            this.btnGetBatchCustomerData.TabIndex = 8;
            this.btnGetBatchCustomerData.Text = "Get Batch Customer Data";
            this.btnGetBatchCustomerData.UseVisualStyleBackColor = true;
            this.btnGetBatchCustomerData.Click += new System.EventHandler(this.btnGetBatchCustomerData_Click);
            // 
            // btnGetBatchData
            // 
            this.btnGetBatchData.Location = new System.Drawing.Point(55, 26);
            this.btnGetBatchData.Name = "btnGetBatchData";
            this.btnGetBatchData.Size = new System.Drawing.Size(198, 36);
            this.btnGetBatchData.TabIndex = 7;
            this.btnGetBatchData.Text = "Get Batch Data";
            this.btnGetBatchData.UseVisualStyleBackColor = true;
            this.btnGetBatchData.Click += new System.EventHandler(this.btnGetBatchData_Click);
            // 
            // BatchRequestTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 348);
            this.Controls.Add(this.btnGetAppConfigKeyValueInfo);
            this.Controls.Add(this.btnGetBatchStepWaterUsageData);
            this.Controls.Add(this.btnGetBatchWashStepData);
            this.Controls.Add(this.btnGetBatchProductData);
            this.Controls.Add(this.BatchIdtxt);
            this.Controls.Add(this.btnGetBatchCustomerData);
            this.Controls.Add(this.btnGetBatchData);
            this.Name = "BatchRequestTest";
            this.Text = "Batch Request Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGetAppConfigKeyValueInfo;
        private System.Windows.Forms.Button btnGetBatchStepWaterUsageData;
        private System.Windows.Forms.Button btnGetBatchWashStepData;
        private System.Windows.Forms.Button btnGetBatchProductData;
        private System.Windows.Forms.TextBox BatchIdtxt;
        private System.Windows.Forms.Button btnGetBatchCustomerData;
        private System.Windows.Forms.Button btnGetBatchData;
    }
}