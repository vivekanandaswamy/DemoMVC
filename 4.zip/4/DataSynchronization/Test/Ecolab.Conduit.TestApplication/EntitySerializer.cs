﻿using Ecolab.Data.Access;
using Ecolab.Services;
using System;
using System.Configuration;
using System.Windows.Forms;

namespace Ecolab.Conduit.PushTest
{
    using Models.SyncMessages;

    /// <summary>
    /// entity serializer class
    /// </summary>
    public partial class EntitySerializer : Form
    {
        public EntitySerializer()
        {
            InitializeComponent();
        }

        /// <summary>
        /// button for xml Serializer
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">event parameter e</param>
        private void btnXmlSerializer_Click(object sender, EventArgs e)
        {
            string xmlData = string.Empty;
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            xmlData = ImportExportUtility.GetSerializedXmlData("1");          
        }

        /// <summary>
        /// button for xml DeSerializer
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">event parameter e</param>
        private void btnXmlDeSerializer_Click(object sender, EventArgs e)
        {
            string xml = string.Empty;
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            xml = ImportExportUtility.GetSerializedXmlData("1");  
            //List<object> psList = new List<object>();
            TcdAllPlantEntities pms = new TcdAllPlantEntities();
            pms = ImportExportUtility.XmlDeserialize<TcdAllPlantEntities>(pms, xml);
        }
                

        private void btnPushAllEntities_Click(object sender, EventArgs e)
        {
            try
            {
                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                PushHandler.Push.PushAllPlantEntities("040242802",0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :: " + ex);
            }
        }

		private void FTR_Click(object sender, EventArgs e)
		{
			try
			{
				Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
				PushHandler.Push.PushAllPlantEntities("040000282", 0);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error :: " + ex);
			}
		}        
    }
}
