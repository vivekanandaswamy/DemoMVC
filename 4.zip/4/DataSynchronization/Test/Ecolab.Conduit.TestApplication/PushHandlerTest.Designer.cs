﻿namespace Ecolab.Conduit.PushTest
{
    partial class PushHandlerTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPushToQueue = new System.Windows.Forms.Button();
            this.btnPushToLocal = new System.Windows.Forms.Button();
            this.btnPushToCentral = new System.Windows.Forms.Button();
            this.chkMeter = new System.Windows.Forms.CheckBox();
            this.chkPlantData = new System.Windows.Forms.CheckBox();
            this.btnFirstRequest = new System.Windows.Forms.Button();
            this.ChkPlantSetupData = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnResync = new System.Windows.Forms.Button();
            this.btnReSyncToCentral = new System.Windows.Forms.Button();
            this.btnResyncAll = new System.Windows.Forms.Button();
            this.btnGetPlantSettings = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEcolabAccountNo = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbtPlantCustomer = new System.Windows.Forms.RadioButton();
            this.rbtPlantContact = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnGetFromCentral = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPushToQueue
            // 
            this.btnPushToQueue.Location = new System.Drawing.Point(28, 117);
            this.btnPushToQueue.Name = "btnPushToQueue";
            this.btnPushToQueue.Size = new System.Drawing.Size(121, 37);
            this.btnPushToQueue.TabIndex = 5;
            this.btnPushToQueue.Text = "Push To Queue";
            this.btnPushToQueue.UseVisualStyleBackColor = true;
            this.btnPushToQueue.Click += new System.EventHandler(this.btnPushToQueue_Click);
            // 
            // btnPushToLocal
            // 
            this.btnPushToLocal.Location = new System.Drawing.Point(7, 19);
            this.btnPushToLocal.Name = "btnPushToLocal";
            this.btnPushToLocal.Size = new System.Drawing.Size(110, 36);
            this.btnPushToLocal.TabIndex = 9;
            this.btnPushToLocal.Text = "Push To Local";
            this.btnPushToLocal.UseVisualStyleBackColor = true;
            this.btnPushToLocal.Click += new System.EventHandler(this.btnPushToLocal_Click);
            // 
            // btnPushToCentral
            // 
            this.btnPushToCentral.Location = new System.Drawing.Point(7, 61);
            this.btnPushToCentral.Name = "btnPushToCentral";
            this.btnPushToCentral.Size = new System.Drawing.Size(110, 41);
            this.btnPushToCentral.TabIndex = 10;
            this.btnPushToCentral.Text = "Push To Central";
            this.btnPushToCentral.UseVisualStyleBackColor = true;
            this.btnPushToCentral.Click += new System.EventHandler(this.btnPushToCentral_Click);
            // 
            // chkMeter
            // 
            this.chkMeter.AutoSize = true;
            this.chkMeter.Location = new System.Drawing.Point(16, 47);
            this.chkMeter.Name = "chkMeter";
            this.chkMeter.Size = new System.Drawing.Size(79, 17);
            this.chkMeter.TabIndex = 11;
            this.chkMeter.Text = "Meter Data";
            this.chkMeter.UseVisualStyleBackColor = true;
            // 
            // chkPlantData
            // 
            this.chkPlantData.AutoSize = true;
            this.chkPlantData.Location = new System.Drawing.Point(16, 24);
            this.chkPlantData.Name = "chkPlantData";
            this.chkPlantData.Size = new System.Drawing.Size(90, 17);
            this.chkPlantData.TabIndex = 12;
            this.chkPlantData.Text = "Plant Contact";
            this.chkPlantData.UseVisualStyleBackColor = true;
            // 
            // btnFirstRequest
            // 
            this.btnFirstRequest.Location = new System.Drawing.Point(6, 28);
            this.btnFirstRequest.Name = "btnFirstRequest";
            this.btnFirstRequest.Size = new System.Drawing.Size(111, 41);
            this.btnFirstRequest.TabIndex = 11;
            this.btnFirstRequest.Text = "First Time Request";
            this.btnFirstRequest.UseVisualStyleBackColor = true;
            this.btnFirstRequest.Click += new System.EventHandler(this.btnFirstRequest_Click);
            // 
            // ChkPlantSetupData
            // 
            this.ChkPlantSetupData.AutoSize = true;
            this.ChkPlantSetupData.Location = new System.Drawing.Point(16, 70);
            this.ChkPlantSetupData.Name = "ChkPlantSetupData";
            this.ChkPlantSetupData.Size = new System.Drawing.Size(78, 17);
            this.ChkPlantSetupData.TabIndex = 13;
            this.ChkPlantSetupData.Text = "PlantSetup";
            this.ChkPlantSetupData.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkMeter);
            this.groupBox1.Controls.Add(this.ChkPlantSetupData);
            this.groupBox1.Controls.Add(this.chkPlantData);
            this.groupBox1.Controls.Add(this.btnPushToQueue);
            this.groupBox1.Location = new System.Drawing.Point(413, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(182, 160);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Push To Queue";
            // 
            // btnResync
            // 
            this.btnResync.Location = new System.Drawing.Point(11, 68);
            this.btnResync.Name = "btnResync";
            this.btnResync.Size = new System.Drawing.Size(100, 34);
            this.btnResync.TabIndex = 15;
            this.btnResync.Text = "ReSync";
            this.btnResync.UseVisualStyleBackColor = true;
            this.btnResync.Click += new System.EventHandler(this.btnResync_Click);
            // 
            // btnReSyncToCentral
            // 
            this.btnReSyncToCentral.Location = new System.Drawing.Point(123, 119);
            this.btnReSyncToCentral.Name = "btnReSyncToCentral";
            this.btnReSyncToCentral.Size = new System.Drawing.Size(109, 35);
            this.btnReSyncToCentral.TabIndex = 16;
            this.btnReSyncToCentral.Text = "ReSync To Central";
            this.btnReSyncToCentral.UseVisualStyleBackColor = true;
            this.btnReSyncToCentral.Click += new System.EventHandler(this.btnReSyncToCentral_Click);
            // 
            // btnResyncAll
            // 
            this.btnResyncAll.Location = new System.Drawing.Point(123, 68);
            this.btnResyncAll.Name = "btnResyncAll";
            this.btnResyncAll.Size = new System.Drawing.Size(109, 34);
            this.btnResyncAll.TabIndex = 17;
            this.btnResyncAll.Text = "Resync All";
            this.btnResyncAll.UseVisualStyleBackColor = true;
            this.btnResyncAll.Click += new System.EventHandler(this.btnReSyncAll_Click);
            // 
            // btnGetPlantSettings
            // 
            this.btnGetPlantSettings.Location = new System.Drawing.Point(131, 19);
            this.btnGetPlantSettings.Name = "btnGetPlantSettings";
            this.btnGetPlantSettings.Size = new System.Drawing.Size(111, 31);
            this.btnGetPlantSettings.TabIndex = 18;
            this.btnGetPlantSettings.Text = "Get Plant Settings";
            this.btnGetPlantSettings.UseVisualStyleBackColor = true;
            this.btnGetPlantSettings.Click += new System.EventHandler(this.btnGetPlantSettings_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtPort);
            this.groupBox2.Controls.Add(this.txtIP);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtEcolabAccountNo);
            this.groupBox2.Controls.Add(this.btnGetPlantSettings);
            this.groupBox2.Location = new System.Drawing.Point(160, 178);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(248, 115);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Plant Setting Details";
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(142, 82);
            this.txtPort.Name = "txtPort";
            this.txtPort.ReadOnly = true;
            this.txtPort.Size = new System.Drawing.Size(100, 20);
            this.txtPort.TabIndex = 23;
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(142, 56);
            this.txtIP.Name = "txtIP";
            this.txtIP.ReadOnly = true;
            this.txtIP.Size = new System.Drawing.Size(100, 20);
            this.txtIP.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Port";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "IP Address";
            // 
            // txtEcolabAccountNo
            // 
            this.txtEcolabAccountNo.Location = new System.Drawing.Point(11, 28);
            this.txtEcolabAccountNo.Name = "txtEcolabAccountNo";
            this.txtEcolabAccountNo.Size = new System.Drawing.Size(114, 20);
            this.txtEcolabAccountNo.TabIndex = 19;
            this.txtEcolabAccountNo.Text = "ECOPLANT5";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnResyncAll);
            this.groupBox3.Controls.Add(this.rbtPlantCustomer);
            this.groupBox3.Controls.Add(this.rbtPlantContact);
            this.groupBox3.Controls.Add(this.btnResync);
            this.groupBox3.Controls.Add(this.btnReSyncToCentral);
            this.groupBox3.Location = new System.Drawing.Point(160, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(247, 160);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Resync";
            // 
            // rbtPlantCustomer
            // 
            this.rbtPlantCustomer.AutoSize = true;
            this.rbtPlantCustomer.Location = new System.Drawing.Point(136, 24);
            this.rbtPlantCustomer.Name = "rbtPlantCustomer";
            this.rbtPlantCustomer.Size = new System.Drawing.Size(96, 17);
            this.rbtPlantCustomer.TabIndex = 1;
            this.rbtPlantCustomer.TabStop = true;
            this.rbtPlantCustomer.Text = "Plant Customer";
            this.rbtPlantCustomer.UseVisualStyleBackColor = true;
            // 
            // rbtPlantContact
            // 
            this.rbtPlantContact.AutoSize = true;
            this.rbtPlantContact.Location = new System.Drawing.Point(7, 23);
            this.rbtPlantContact.Name = "rbtPlantContact";
            this.rbtPlantContact.Size = new System.Drawing.Size(89, 17);
            this.rbtPlantContact.TabIndex = 0;
            this.rbtPlantContact.TabStop = true;
            this.rbtPlantContact.Text = "Plant Contact";
            this.rbtPlantContact.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnPushToLocal);
            this.groupBox4.Controls.Add(this.btnPushToCentral);
            this.groupBox4.Location = new System.Drawing.Point(3, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(144, 160);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Push";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnFirstRequest);
            this.groupBox5.Location = new System.Drawing.Point(3, 178);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(144, 115);
            this.groupBox5.TabIndex = 22;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "FTR";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnGetFromCentral);
            this.groupBox6.Location = new System.Drawing.Point(429, 178);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(144, 115);
            this.groupBox6.TabIndex = 23;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "GET Request";
            // 
            // btnGetFromCentral
            // 
            this.btnGetFromCentral.Location = new System.Drawing.Point(6, 28);
            this.btnGetFromCentral.Name = "btnGetFromCentral";
            this.btnGetFromCentral.Size = new System.Drawing.Size(111, 41);
            this.btnGetFromCentral.TabIndex = 11;
            this.btnGetFromCentral.Text = "Get From Central";
            this.btnGetFromCentral.UseVisualStyleBackColor = true;
            this.btnGetFromCentral.Click += new System.EventHandler(this.btnGetFromCentral_Click);
            // 
            // PushHandlerTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 322);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "PushHandlerTest";
            this.Text = "Push Handler Test";
            this.Load += new System.EventHandler(this.frmPushWrapperTest_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPushToQueue;
        private System.Windows.Forms.Button btnPushToLocal;
        private System.Windows.Forms.Button btnPushToCentral;
        private System.Windows.Forms.CheckBox chkMeter;
        private System.Windows.Forms.CheckBox chkPlantData;
        private System.Windows.Forms.Button btnFirstRequest;
        private System.Windows.Forms.CheckBox ChkPlantSetupData;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnResync;
        private System.Windows.Forms.Button btnReSyncToCentral;
        private System.Windows.Forms.Button btnResyncAll;
        private System.Windows.Forms.Button btnGetPlantSettings;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEcolabAccountNo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbtPlantCustomer;
        private System.Windows.Forms.RadioButton rbtPlantContact;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnGetFromCentral;
    }
}

