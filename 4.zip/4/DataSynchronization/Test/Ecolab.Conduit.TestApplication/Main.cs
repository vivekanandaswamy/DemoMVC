﻿namespace Ecolab.Conduit.PushTest
{
    using System;
    using System.Windows.Forms;
    using AutoMapper;
    using Services.Infra;

    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            Mapper.Initialize(cfg => { cfg.AddProfile(new ServiceMappingProfile()); });
        }

        private void btnPushHandlerTest_Click(object sender, EventArgs e)
        {
            PushHandlerTest objPushHandlerTest = new PushHandlerTest();
            objPushHandlerTest.Show();
        }

        private void btnBatchRequestTest_Click(object sender, EventArgs e)
        {
            BatchRequestTest objBatchRequestTest = new BatchRequestTest();
            objBatchRequestTest.Show();
        }

        private void btnEntitySerializer_Click(object sender, EventArgs e)
        {
            EntitySerializer entitySerializer = new EntitySerializer();
            entitySerializer.Show();
        }
    }
}