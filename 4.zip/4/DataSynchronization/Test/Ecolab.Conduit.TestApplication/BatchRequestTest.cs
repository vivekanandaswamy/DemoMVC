﻿namespace Ecolab.Conduit.PushTest
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Windows.Forms;
    using Data.Access;
    using Models.Batch;
    using Services.Batch;

    public partial class BatchRequestTest : Form
    {
        public BatchRequestTest()
        {
            InitializeComponent();
        }

        private void btnGetBatchData_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            BatchService batchService = new BatchService();
            List<BatchData> batchCollection = batchService.GetBatchCollectionDetails(10);

            foreach (BatchData batch in batchCollection)
            {
                batch.BatchCustomerList = batchService.GetBatchCustomerData(batch.BatchId);
                batch.BatchProductList = batchService.GetBatchProductData(batch.BatchId);
                batch.BatchWashStepList = batchService.GetBatchWashStepData(batch.BatchId);
                batch.BatchStepWaterUsageList = batchService.GetBatchStepWaterUsageData(batch.BatchId);
            }
        }

        private void btnGetBatchCustomerData_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            BatchService batchService = new BatchService();
            int id = Convert.ToInt32(BatchIdtxt.Text);
            batchService.GetBatchCustomerData(id);
        }

        private void btnGetBatchProductData_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            BatchService batchService = new BatchService();
            int id = Convert.ToInt32(BatchIdtxt.Text);
            batchService.GetBatchProductData(id);
        }

        private void btnGetBatchWashStepData_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            BatchService batchService = new BatchService();
            int id = Convert.ToInt32(BatchIdtxt.Text);
            batchService.GetBatchWashStepData(id);
        }

        private void btnGetBatchStepWaterUsageData_Click(object sender, EventArgs e)
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            BatchService batchService = new BatchService();
            int id = Convert.ToInt32(BatchIdtxt.Text);
            batchService.GetBatchStepWaterUsageData(id);
        }
    }
}