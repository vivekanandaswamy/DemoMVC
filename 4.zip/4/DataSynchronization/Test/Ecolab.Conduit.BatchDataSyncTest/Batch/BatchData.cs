﻿namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    using System;
    using System.Collections.Generic;

    public class BatchData
    {
        public int BatchId { get; set; }
        public int ControllerBatchId { get; set; }
        public int EcolabWasherId { get; set; }
        public Int16 PlantWasherNumber { get; set; }
        public int GroupId { get; set; }
        public byte MachineInternalId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int ProgramNumber { get; set; }
        public int ProgramMasterId { get; set; }
        public int MachineId { get; set; }
        public int ActualWeight { get; set; }
        public int StandardWeight { get; set; }
        public string CurrencyCode { get; set; }
        public DateTime LastSyncTime { get; set; }
        public int ManualInputWeight { get; set; }
        public int LastModifiedByUserId { get; set; }
        public int HoldTime { get; set; }
        public DateTime PartitionOn { get; set; }
        public byte BatchStatus { get; set; }
        public DateTime EndDateFormula { get; set; }
        public int ShiftId { get; set; }

        public int TargetTurnTime { get; set; }

        public int EcolabTextileCategoryId { get; set; }

        public int ChainTextileCategoryId { get; set; }

        public int FormulaSegmentId { get; set; }

        public int EcolabSaturationId { get; set; }

        public int PlantProgramId { get; set; }

        public bool SyncReady { get; set; }

        public int StdInjectionSteps { get; set; }

        public int StdWashSteps { get; set; }

        public DateTime? ETechlastDroppedTimeStamp { get; set; }
        public List<BatchCustomerData> BatchCustomerList { get; set; }
        public List<BatchProductData> BatchProductList { get; set; }
        public List<BatchStepWaterUsageData> BatchStepWaterUsageList { get; set; }
        public List<BatchWashStepData> BatchWashStepList { get; set; }
        public List<BatchStepEnergyUsageData> BatchStepEnergyUsageList { get; set; }
        public List<BatchParameterData> BatchParameterDataList { get; set; }
    }
}