﻿namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    using System;

    public class BatchWashStepData
    {
        public int BatchId { get; set; }
        public int EcolabWasherId { get; set; }
        public int StepCompartment { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}