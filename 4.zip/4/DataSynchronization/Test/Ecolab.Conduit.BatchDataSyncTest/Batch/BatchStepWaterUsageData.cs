﻿using System;
namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    public class BatchStepWaterUsageData
    {
        public int BatchId { get; set; }
        public int EcolabWasherId { get; set; }
        public int StepCompartment { get; set; }
        public int WaterTypeId { get; set; }
        public double ActualQuantity { get; set; }
        public double StandardQuantity { get; set; }
        public double Price { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}