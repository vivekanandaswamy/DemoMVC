﻿using System;
namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    public class BatchProductData
    {
        public int BatchId { get; set; }
        public int EcolabWasherId { get; set; }
        public int StepCompartment { get; set; }
        public double ActualQuantity { get; set; }
        public double StandardQuantity { get; set; }
        public double Price { get; set; }
        public DateTime Timestamp { get; set; }
        public bool Status { get; set; }
        public DateTime PartitionOn { get; set; }
        public int ProductId { get; set; }
    }
}