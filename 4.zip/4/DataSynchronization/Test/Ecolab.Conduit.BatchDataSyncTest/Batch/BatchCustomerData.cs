﻿using System;
namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    public class BatchCustomerData
    {
        public int BatchId { get; set; }
        public int EcolabWasherId { get; set; }
        public int CustomerId { get; set; }
        public int PiecesCount { get; set; }
        public int Weight { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}