﻿namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    public class BatchCollection
    {
        public BatchCollection BatchDataCollection { get; set; }
        //public BatchData batchData { get; set; }
        public int BatchID { get; set; }
    }
}