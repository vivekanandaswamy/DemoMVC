﻿using System;
namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    public class BatchStepEnergyUsageData
    {
        public int BatchId { get; set; }
        public int StepCompartment { get; set; }
        public int GasOilTypeId { get; set; }
        public double ActualQuantity { get; set; }
        public double StandardQuantity { get; set; }
        public double Price { get; set; }
        public int EcolabWasherId { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}
