﻿using System;

namespace Ecolab.Conduit.BatchDataSyncTest.Batch
{
    public class BatchParameterData
    {
        public int BatchId { get; set; }
        public int EcolabWasherId { get; set; }
        public float ParameterId { get; set; }
        public float ParameterValue { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}
