﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Ecolab.Conduit.BatchDataSyncTest.Helpers
{
    public class XMLSerializerTableFormat
    {
        [XmlRoot("Tables")]
        public class Tables
        {

            [XmlElement("Table")]
            public List<Table> Table { get; set; }
        }

        [XmlRoot("Table")]
        public class Table
        {

            [XmlAttribute("Name")]
            public string TableName { get; set; }

            [XmlElement("Rows")]
            public Rows Rows { get; set; }
        }

        [XmlRoot("Rows")]
        public class Rows
        {
            [XmlElement("Row")]
            public List<Row> Row { get; set; }
        }

        [XmlRoot("Row")]
        public class Row
        {
            [XmlElement("Columns")]
            public Columns Columns { get; set; }

        }

        [XmlRoot("Columns")]
        public class Columns
        {
            [XmlElement("Column")]
            public List<Column> Column { get; set; }
        }

        public class Column
        {
            [XmlAttribute("name")]
            public string Name { get; set; }

            [XmlText]
            public string Value { get; set; }
        }
    }
}
