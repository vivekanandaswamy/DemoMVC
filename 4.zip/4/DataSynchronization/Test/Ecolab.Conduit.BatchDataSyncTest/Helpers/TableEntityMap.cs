﻿namespace Ecolab.Conduit.Library.Helpers
{
    using System.Collections.Generic;
    using System.Linq;

    public static class TableEntityMap
    {
        public static string GetTable(string entityType)
        {
            string tableName = string.Empty;
            var dt = new Dictionary<string, string>();

            dt.Add("Entities.PlantSetup.Meter", "Meter"); // Need to check and removed later
            dt.Add("Entities.PlantContact", "PlantContact");
            dt.Add("PlantContact", "PlantContact");
            dt.Add("BatchData", "BatchData");
            dt.Add("Meter", "Meter");
            dt.Add("Ecolab.Models.PlantContact", "PlantContact");
            dt.Add("Ecolab.Models.PlantCustomer", "PlantCustomer");
            dt.Add("Ecolab.Models.PlantSetup.Chemical", "ProductdataMapping");
            dt.Add("Ecolab.Models.Plant", "Plant");
            tableName = (dt.Keys.Contains(entityType)) ? dt[entityType] : string.Empty;
            return tableName;
        }

        public static string GetColumn(string entityType)
        {
            string columnName = string.Empty;
            var dt = new Dictionary<string, string>();

            dt.Add("Entities.PlantSetup.Meter", "MeterId"); // Need to check and removed later
            dt.Add("Entities.PlantContact", "Id");
            dt.Add("BatchData", "BatchId");
            dt.Add("Meter", "MeterId");
            dt.Add("Ecolab.Models.PlantContact", "Id");
            dt.Add("Ecolab.Models.PlantCustomer", "Id");
            dt.Add("Ecolab.Models.PlantSetup.Chemical", "Id");
            dt.Add("Ecolab.Models.Plant", "EcolabAccountNumber");
            columnName = (dt.Keys.Contains(entityType)) ? dt[entityType] : string.Empty;
            return columnName;
        }

        public static string GetEntityName(string headerMessageType)
        {
            string entityName = string.Empty;
            var dt = new Dictionary<string, string>();

            dt.Add("TcdAddPlantContact", "PlantContact");
            dt.Add("TcdUpdatePlantContact", "PlantContact");
            dt.Add("TcdDeletePlantContact", "PlantContact");

            dt.Add("TcdUpdatePlant", "Plant");

            dt.Add("TcdAddPlantFormula", "PlantFormula");
            dt.Add("TcdUpdatePlantFormula", "PlantFormula");
            dt.Add("TcdDeletePlantFormula", "PlantFormula");

            dt.Add("TcdAddMeters", "Meter");
            dt.Add("TcdUpdateMeters", "Meter");

            dt.Add("TcdAddPlantCustomer", "PlantCustomer");
            dt.Add("TcdUpdatePlantCustomer", "PlantCustomer");
            dt.Add("TcdDeletePlantCustomer", "PlantCustomer");

            dt.Add("TcdAddDryerGroup", "DryerGroup");
            dt.Add("TcdUpdateDryerGroup", "DryerGroup");
            dt.Add("TcdDeleteDryerGroup", "DryerGroup");

            dt.Add("TcdAddDryers", "Dryers");
            dt.Add("TcdUpdateDryers", "Dryers");
            dt.Add("TcdDeleteDryers", "Dryers");

            entityName = (dt.Keys.Contains(headerMessageType)) ? dt[headerMessageType] : string.Empty;
            return entityName;
        }
    }
}