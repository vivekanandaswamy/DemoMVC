﻿namespace Ecolab.Conduit.Library.Helpers
{
    using System;
    using System.Globalization;
    using System.Reflection;
    using System.Text;

    public static class ExportHelper
    {
        public const string DefaultDelimiter = "  ";

        public static string StructToString<T>(T obj, string delim = DefaultDelimiter) where T : struct
        {
            return StructToString(string.Empty, obj, typeof(T), delim);
        }

        private static string StructToString(string postfix, object obj, Type t, string delim = DefaultDelimiter)
        {
            StringBuilder sb = new StringBuilder();

            foreach(FieldInfo fi in t.GetFields(BindingFlags.Public | BindingFlags.Instance))
            {
                if(fi.FieldType.Name.StartsWith("EcpString"))
                {
                    sb.AppendFormat("{0}{2} : '{1}'{3}", fi.Name, fi.GetValue(obj), postfix, delim, CultureInfo.CurrentCulture);
                }
                else if(fi.FieldType.IsPrimitive || fi.FieldType.Name == "String")
                {
                    sb.AppendFormat("{0}{2} : '{1}'{3}", fi.Name, fi.GetValue(obj), postfix, delim, CultureInfo.CurrentCulture);
                }
                else if(fi.FieldType.BaseType.Name == "Enum")
                {
                    IConvertible o = (IConvertible)fi.GetValue(obj);
                    sb.AppendFormat("{0}{3} : '{1}' ({2}){4}", fi.Name, o, o.ToInt64(CultureInfo.InvariantCulture), postfix, delim, CultureInfo.CurrentCulture);
                }
                else if(fi.FieldType.IsArray)
                {
                    Array a = (Array)fi.GetValue(obj);
                    if(a != null)
                    {
                        for(int i = 0; i < a.Length; i++)
                        {
                            sb.Append(StructToString("[" + i.ToString(CultureInfo.InvariantCulture) + "]", a.GetValue(i), a.GetValue(i).GetType(), delim));
                        }
                    }
                    else
                    {
                        sb.AppendFormat("{0}[] is null{1}", fi.Name, delim);
                    }
                }
                else
                {
                    sb.Append(StructToString(postfix, fi.GetValue(obj), fi.FieldType, delim));
                }
            }

            return sb.ToString();
        }

        public static string ClassToString<T>(T obj, string delim = DefaultDelimiter) where T : class
        {
            return ClassToString(string.Empty, obj, typeof(T), delim);
        }

        private static string ClassToString(string postfix, object obj, Type t, string delim = DefaultDelimiter)
        {
            StringBuilder sb = new StringBuilder();

            foreach(PropertyInfo pi in t.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if(pi.PropertyType.IsPrimitive || pi.PropertyType.Name == "String")
                {
                    sb.AppendFormat("{0}{2} : '{1}'{3}", pi.Name, pi.GetValue(obj, null), postfix, delim);
                }
                else if(pi.PropertyType.BaseType.Name == "Enum")
                {
                    IConvertible o = (IConvertible)pi.GetValue(obj, null);
                    sb.AppendFormat("{0}{3} : '{1}' ({2}){4}", pi.Name, o, o.ToInt64(CultureInfo.InvariantCulture), postfix, delim);
                }
                else if(pi.PropertyType.IsArray)
                {
                    Array a = (Array)pi.GetValue(obj, null);
                    if(a != null)
                    {
                        for(int i = 0; i < a.Length; i++)
                        {
                            sb.Append(StructToString("[" + i + "]", a.GetValue(i), a.GetValue(i).GetType(), delim));
                        }
                    }
                    else
                    {
                        sb.AppendFormat("{0}[] is null{1}", pi.Name, delim);
                    }
                }
                else
                {
                    sb.Append(StructToString(postfix, pi.GetValue(obj, null), pi.PropertyType, delim));
                }
            }

            return sb.ToString();
        }

        public static string WriteBytes(byte[] buffer)
        {
            StringBuilder sb = new StringBuilder();
            for(int i = 0; i < buffer.Length; i++)
            {
                sb.AppendFormat("{0:X2} ", buffer[i]);
            }

            return sb.ToString();
        }
    }
}