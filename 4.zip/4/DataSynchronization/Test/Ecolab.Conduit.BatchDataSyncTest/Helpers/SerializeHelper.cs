﻿namespace Ecolab.Conduit.Library.Helpers
{
    using System.IO;
    using System.Text;
    using MsgPack.Serialization;

    /// <summary>
    ///     Serialize Helper
    /// </summary>
    public static class SerializeHelper
    {
        /// <summary>
        ///     Serialize
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="thisObj">Object of type param T</param>
        /// <returns>Returns byte array</returns>
        public static byte[] Serialize<T>(T thisObj)
        {
            MessagePackSerializer<T> serializer = MessagePackSerializer.Get<T>();

            using (MemoryStream byteStream = new MemoryStream())
            {
                serializer.Pack(byteStream, thisObj);
                return byteStream.ToArray();
            }
        }

        /// <summary>
        ///     Convert String To ByteArray
        /// </summary>
        /// <param name="stringData"></param>
        /// <returns>Returns byte array</returns>
        public static byte[] ConvertStringToByteArray(string stringData)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(stringData);
            return buffer;
        }

        /// <summary>
        ///     Convert Byte Array To String
        /// </summary>
        /// <param name="byteData"></param>
        /// <returns>Returns String</returns>
        public static string ConvertByteArrayToString(byte[] byteData)
        {
            string outputString = string.Empty;
            outputString = Encoding.UTF8.GetString(byteData);
            return outputString;
        }
    }
}