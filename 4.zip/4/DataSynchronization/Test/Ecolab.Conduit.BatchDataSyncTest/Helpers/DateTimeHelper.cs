﻿namespace Ecolab.Conduit.Library.Helpers
{
    using System;

    public static class DateTimeHelper
    {
        public static readonly DateTime UnixEpoc = new DateTime(1970, 1, 1);

        public static long ConvertToUnixTimestamp(DateTime date)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0);

            TimeSpan dateDiff = date - origin;

            return (long) dateDiff.TotalSeconds;
        }
    }
}