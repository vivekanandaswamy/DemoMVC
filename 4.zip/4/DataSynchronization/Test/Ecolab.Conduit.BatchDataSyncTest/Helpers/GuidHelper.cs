﻿// -----------------------------------------------------------------------
// <copyright file="GuidHelper.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Guid Helper class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Helpers
{
    using System;
    using Common;

    /// <summary>
    ///     Guid Helper
    /// </summary>
    public static class GuidHelper
    {
        /// <summary>
        ///     Invalid Controller GUID
        /// </summary>
        public static Guid InvalidControllerGuid = Guid.Empty;

        /// <summary>
        ///     To ECP Format
        /// </summary>
        /// <param name="guid">Guid object</param>
        /// <returns>Returns string</returns>
        public static string ToEcpFormat(this Guid guid)
        {
            if (guid == Guid.Empty)
            {
                return string.Empty;
            }
            return Base32Encoder.ToBase32String(guid.ToByteArray());
        }

        /// <summary>
        ///     From ECP Format
        /// </summary>
        /// <param name="ecpFormattedGuid">ECP formatted GUID</param>
        /// <returns>Returns GUID object</returns>
        public static Guid FromEcpFormat(string ecpFormattedGuid)
        {
            return new Guid(Base32Encoder.FromBase32String(ecpFormattedGuid));
        }
    }
}