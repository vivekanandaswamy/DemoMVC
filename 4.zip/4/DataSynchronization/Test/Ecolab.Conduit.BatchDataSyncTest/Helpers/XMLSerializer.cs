﻿using Ecolab.Conduit.BatchDataSyncTest.Batch;
using Ecolab.Conduit.BatchDataSyncTest.Alarm;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using test = Ecolab.Conduit.BatchDataSyncTest.Helpers.XMLSerializerTableFormat;
namespace Ecolab.Conduit.BatchDataSyncTest.Helpers
{
    public class XMLSerializer
    {
        public string ConvertToXML(List<BatchData> batchData)
        {
            XMLSerializerTableFormat xml = new XMLSerializerTableFormat();

            test.Tables tables = new test.Tables();

            List<test.Table> listOfTable = new List<test.Table>();


            test.Table table1 = new test.Table();
            table1 = CreateBatchTable(batchData);
            listOfTable.Add(table1);

            test.Table table2 = new test.Table();
            table2 = CreateCustomerTable(batchData);
            listOfTable.Add(table2);

            test.Table table3 = new test.Table();
            table3 = CreateWashStepTable(batchData);
            listOfTable.Add(table3);

            test.Table table4 = new test.Table();
            table4 = CreateWaterUsageTable(batchData);
            listOfTable.Add(table4);

            test.Table table5 = new test.Table();
            table5 = CreateProductTable(batchData);
            listOfTable.Add(table5);

            test.Table table6 = new test.Table();
            table6 = CreateEnergyUsageTable(batchData);
            listOfTable.Add(table6);

            test.Table table7 = new test.Table();
            table7 = CreateParameterDataTable(batchData);
            listOfTable.Add(table7);

            tables.Table = listOfTable;

            string fileName = "D:\\NewXML.XML";

            SaveFileDialog SaveFileDialog1 = new SaveFileDialog();
            SaveFileDialog1.Title = "Save Batch Data File";
            SaveFileDialog1.Filter = "XML File|*.xml";
            SaveFileDialog1.ShowDialog();


            fileName = SaveFileDialog1.FileName;
            var serializer = new XmlSerializer(typeof(test.Tables));
            using (var stream = File.Create(fileName))
            {
                serializer.Serialize(stream, tables);
            }
            string fileContents = File.ReadAllText(fileName);

            return fileContents;
        }

        public string ConvertToXML(List<AlarmData> alarmData)
        {
            XMLSerializerTableFormat xml = new XMLSerializerTableFormat();

            test.Tables tables = new test.Tables();

            List<test.Table> listOfTable = new List<test.Table>();


            test.Table table1 = new test.Table();
            table1 = CreateAlarmTable(alarmData);
            listOfTable.Add(table1);

            test.Table table2 = new test.Table();
            table2 = CreateAlarmMasterTable(alarmData);
            listOfTable.Add(table2);

            tables.Table = listOfTable;

            string fileName = "D:\\NewXML.XML";

            SaveFileDialog SaveFileDialog1 = new SaveFileDialog();
            SaveFileDialog1.Title = "Save Alarm Data File";
            SaveFileDialog1.Filter = "XML File|*.xml";
            SaveFileDialog1.ShowDialog();


            fileName = SaveFileDialog1.FileName;
            var serializer = new XmlSerializer(typeof(test.Tables));
            using (var stream = File.Create(fileName))
            {
                serializer.Serialize(stream, tables);
            }
            string fileContents = File.ReadAllText(fileName);

            return fileContents;
        }

        private test.Table CreateParameterDataTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();
            table.TableName = "[TCD].[BatchParameterData]";
            test.Rows rows7 = new test.Rows();
            List<test.Row> ListofrowsforParameterData = new List<test.Row>();
            ListofrowsforParameterData = FormatBatchParameterData(batchData);
            rows7.Row = ListofrowsforParameterData;
            table.Rows = rows7;

            return table;
        }
        private test.Table CreateEnergyUsageTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();
            table.TableName = "[TCD].[BatchEnergyUsageData]";
            test.Rows rows6 = new test.Rows();
            List<test.Row> ListofrowsforEnergyUsageData = new List<test.Row>();
            ListofrowsforEnergyUsageData = FormatBatchEnergyUsageData(batchData);
            rows6.Row = ListofrowsforEnergyUsageData;
            table.Rows = rows6;

            return table;
        }
        private test.Table CreateProductTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchProductData]";
            test.Rows rows5 = new test.Rows();
            List<test.Row> ListOfrowsforProductData = new List<test.Row>();
            ListOfrowsforProductData = FormatBatchProductData(batchData);
            rows5.Row = ListOfrowsforProductData;
            table.Rows = rows5;

            return table;
        }

        private test.Table CreateWaterUsageTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchWaterUsageData]";
            test.Rows rows4 = new test.Rows();
            List<test.Row> ListOfrowsforWaterUsageData = new List<test.Row>();
            ListOfrowsforWaterUsageData = FormatBatchWaterUsageData(batchData);
            rows4.Row = ListOfrowsforWaterUsageData;
            table.Rows = rows4;

            return table;
        }

        private test.Table CreateWashStepTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchWashStepData]";
            test.Rows rows3 = new test.Rows();
            List<test.Row> ListOfrowsforWashStepData = new List<test.Row>();
            ListOfrowsforWashStepData = FormatBatchWashStepData(batchData);
            rows3.Row = ListOfrowsforWashStepData;
            table.Rows = rows3;

            return table;
        }

        private test.Table CreateCustomerTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchCustomerData]";
            test.Rows rows2 = new test.Rows();
            List<test.Row> ListOfrowsforCustomerData = new List<test.Row>();
            ListOfrowsforCustomerData = FormatBatchCustomerData(batchData);
            rows2.Row = ListOfrowsforCustomerData;
            table.Rows = rows2;

            return table;
        }

        private test.Table CreateBatchTable(List<BatchData> batchData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[BatchData]";
            test.Rows rows = new test.Rows();
            List<test.Row> ListOfrowsforBatchData = new List<test.Row>();
            ListOfrowsforBatchData = FormatBatchData(batchData);
            rows.Row = ListOfrowsforBatchData;
            table.Rows = rows;

            return table;
        }

        private test.Table CreateAlarmMasterTable(List<AlarmData> alarmData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[AlarmMaster]";
            test.Rows rows1 = new test.Rows();
            List<test.Row> ListOfrowsforAlarmMaster = new List<test.Row>();
            ListOfrowsforAlarmMaster = FormatAlarmMasterData(alarmData);
            rows1.Row = ListOfrowsforAlarmMaster;
            table.Rows = rows1;

            return table;
        }

        private test.Table CreateAlarmTable(List<AlarmData> alarmData)
        {
            test.Table table = new test.Table();

            table.TableName = "[TCD].[AlarmData]";
            test.Rows rows = new test.Rows();
            List<test.Row> ListOfrowsforAlarmData = new List<test.Row>();
            ListOfrowsforAlarmData = FormatAlarmData(alarmData);
            rows.Row = ListOfrowsforAlarmData;
            table.Rows = rows;

            return table;
        }
        private List<test.Row> FormatBatchParameterData(List<BatchData> batchData)
        {
            List<test.Row> ListofrowsforParameterData = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();


                foreach (var parameterData in item.BatchStepEnergyUsageList)
                {
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in parameterData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        var value = prop.GetValue(parameterData, null).ToString();
                        col.Value = value;

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListofrowsforParameterData.Add(row);
                }


            }

            return ListofrowsforParameterData;
        }
        private List<test.Row> FormatBatchEnergyUsageData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforEnergyUsageData = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();


                foreach (var energyUsageData in item.BatchStepEnergyUsageList)
                {
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in energyUsageData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        var value = prop.GetValue(energyUsageData, null).ToString();
                        col.Value = value;

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforEnergyUsageData.Add(row);
                }


            }

            return ListOfrowsforEnergyUsageData;
        }

        private List<test.Row> FormatBatchProductData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforProductData = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();


                foreach (var prodData in item.BatchProductList)
                {
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in prodData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime) || property.PropertyType == typeof(Boolean)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        var value = prop.GetValue(prodData, null).ToString();
                        col.Value = value;

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforProductData.Add(row);
                }


            }

            return ListOfrowsforProductData;
        }

        private List<test.Row> FormatBatchWaterUsageData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforWaterUsageData = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();


                foreach (var waterUsageData in item.BatchStepWaterUsageList)
                {
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in waterUsageData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        var value = prop.GetValue(waterUsageData, null).ToString();
                        col.Value = value;

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforWaterUsageData.Add(row);
                }


            }

            return ListOfrowsforWaterUsageData;
        }

        private List<test.Row> FormatBatchWashStepData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforWashStepData = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();


                foreach (var washStepData in item.BatchWashStepList)
                {
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();

                    var properties = from property in washStepData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        var value = prop.GetValue(washStepData, null).ToString();
                        col.Value = value;

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforWashStepData.Add(row);
                }


            }

            return ListOfrowsforWashStepData;
        }

        private List<test.Row> FormatBatchCustomerData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrowsforCustomerData = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();

                foreach (var custData in item.BatchCustomerList)
                {
                    test.Columns cols = new test.Columns();
                    List<test.Column> listOfColumn = new List<test.Column>();
                    var properties = from property in custData.GetType().GetProperties()
                                     where property.PropertyType.IsPrimitive ||
                                           property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                     select property;

                    foreach (var prop in properties)
                    {
                        test.Column col = new test.Column();
                        var name = prop.Name;
                        col.Name = name;
                        var value = prop.GetValue(custData, null).ToString();
                        col.Value = value;

                        listOfColumn.Add(col);
                    }

                    cols.Column = listOfColumn;
                    row.Columns = cols;

                    ListOfrowsforCustomerData.Add(row);
                }


            }

            return ListOfrowsforCustomerData;
        }

        private List<test.Row> FormatBatchData(List<BatchData> batchData)
        {
            List<test.Row> ListOfrows = new List<test.Row>();

            foreach (var item in batchData)
            {
                test.Row row = new test.Row();
                test.Columns cols = new test.Columns();
                List<test.Column> listOfColumn = new List<test.Column>();

                var properties = from property in item.GetType().GetProperties()
                                 where property.PropertyType.IsPrimitive ||
                                       property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                 select property;

                foreach (var property in properties)
                {
                    test.Column col = new test.Column();

                    var name = property.Name;

                    if (name == "BatchCustomerList" || name == "EcolabAccountNumber")
                    {
                        break;
                    }
                    if (name == "EcolabWasherId")
                    {
                        var valueforWasherId = property.GetValue(item, null).ToString();
                        if (valueforWasherId == null)
                            break;
                    }
                    col.Name = name;
                    var value = property.GetValue(item, null).ToString();
                    col.Value = value;

                    listOfColumn.Add(col);
                }

                cols.Column = listOfColumn;
                row.Columns = cols;

                ListOfrows.Add(row);
            }

            return ListOfrows;
        }

        private List<test.Row> FormatAlarmMasterData(List<AlarmData> alarmData)
        {
            List<test.Row> ListOfrows = new List<test.Row>();
            
            foreach (var item in alarmData)
                {
                test.Row row = new test.Row();

                foreach (var alarmMasterData in item.AlarmMasterList)
                    {
                        test.Columns cols = new test.Columns();
                        List<test.Column> listOfColumn = new List<test.Column>();
                        var properties = from property in alarmMasterData.GetType().GetProperties()
                                         where property.PropertyType.IsPrimitive ||
                                               property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                         select property;

                        foreach (var prop in properties)
                        {
                            test.Column col = new test.Column();
                            var name = prop.Name;
                            col.Name = name;
                            var value = prop.GetValue(alarmMasterData, null).ToString();
                            col.Value = value;

                            listOfColumn.Add(col);
                        }

                        cols.Column = listOfColumn;
                        row.Columns = cols;

                        ListOfrows.Add(row);
                    }
                }
                return ListOfrows;
        }

        private List<test.Row> FormatAlarmData(List<AlarmData> alarmData)
        {
            List<test.Row> ListOfrows = new List<test.Row>();

            foreach (var item in alarmData)
            {
                test.Row row = new test.Row();
                test.Columns cols = new test.Columns();
                List<test.Column> listOfColumn = new List<test.Column>();

                var properties = from property in item.GetType().GetProperties()
                                 where property.PropertyType.IsPrimitive ||
                                       property.PropertyType == typeof(string) || property.PropertyType == typeof(DateTime)
                                 select property;

                foreach (var property in properties)
                {
                    test.Column col = new test.Column();

                    var name = property.Name;
                    col.Name = name;
                    var value = property.GetValue(item, null).ToString();
                    col.Value = value;

                    listOfColumn.Add(col);
                }

                cols.Column = listOfColumn;
                row.Columns = cols;

                ListOfrows.Add(row);
            }

            return ListOfrows;
        }
    }
}
