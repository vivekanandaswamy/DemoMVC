﻿namespace Ecolab.Conduit.Library.Enums
{
    public enum ServiceType : uint
    {
        Admin = 1,
        Logging = 2,
        Service = 3,
        XBox = 10000, //Logging for the XBox membranes controller.
        TcdAdmin = 9,
        TcdLogRequest = 10,
        FirstRequest = 11,
        TcdLogging = 12,
        TcdAdminResync = 13
    }
}