﻿// -----------------------------------------------------------------------
// <copyright file="TcdErrCodes.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd error codes</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Enums
{
    /// <summary>
    ///     Tcd error codes enum
    /// </summary>
    public enum TcdErrCodes : uint
    {
        //TODO: Need to cleanup error codes
        NotConfigured = uint.MaxValue - 1,
        CommunicationFailure = uint.MaxValue - 2,

        Success = 0,
        RequestFailed = 99,
        InvalidTrackingNumber = 5,
        InvalidSystemType = 6,
        InvalidSoldToAndShipTo = 7,
        InvalidControllerId = 8,
        InvalidConfigName = 9,
        InvalidControlLoopId = 10,
        ControllerIdDoesNotExist = 11,
        ControllerSoftwareError = 12,
        InvalidSequenceNumber = 13,
        InvalidRecordNumber = 14,
        InvalidServerVersion = 15,
        InvalidMessageType = 16,
        InvalidPushRequest = 17,
        InvalidSuSource = 18, //TFTP IP or Unix source path invalid
        SuAlreadyInProgress = 19, // already in progress
        WrongSuLevel = 20, // SU level or SU stream is wrong
        SuBackoutNotAllowed = 21,
        UpdaterIncomplete = 22,
        UpdaterSkip = 23,
        ViewTupleFailedValidation = 24,
        TimerOutputConflict = 25,
        TimerProductConflict = 26,
        TimerBlowdownConflict = 27,
        PushOkUpdateFailed = 28,
        SlugConflict = 29,
        CleaningFull = 30,
        InvalidBlowdownTimer = 31,
        MakeupCycleNoDigitalInput = 32,
        UserRejectRebootRequest = 34,
        ControllerRejectRebootRequest = 35,
        ClearAlarmFailed = 36,
        FluorometerInactive = 37,
        DataAcquisitionUpdating = 38,
        // TCD Error Codes
        SaveFailure = 39,
        UpdateFailure = 40,
        DeleteFailure = 41,
        RecordCountNotMatch = 51030,
        RecordNotInSynch = 60000
    }
}