﻿namespace Ecolab.Conduit.SyncBatchData.Enums
{
    public enum TcdMessageTypes : uint
    {
        BatchRequest = 1,
        AlarmRequest = 2
    }
}