﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Xml.Serialization;
using MsgPack.Serialization;
using log4net;
using Ecolab.Conduit.BatchDataSyncTest.Alarm;
using Newtonsoft.Json;
using Ecolab.Conduit.Library.Common;
using Ecolab.Conduit.Library.Enums;
using Ecolab.Conduit.Library.Helpers;
using Ecolab.Conduit.BatchDataSyncTest.Helpers;
using Ecolab.Conduit.SyncBatchData.Common;
using Ecolab.Conduit.SyncBatchData.Enums;

namespace Ecolab.Conduit.BatchDataSyncTest
{
    public partial class AlarmDataSyncForm : Form
    {
        public AlarmDataSyncForm()
        {
            InitializeComponent();
        }

        private static readonly ILog Log = LogManager.GetLogger("SyncBatchDataService");
        private List<AlarmData> alarmCollection = new List<AlarmData>();
        private List<AlarmMaster> alarmMasterCollection = new List<AlarmMaster>();

        private void ProcessBatchData(List<AlarmData> data)
        {
            try
            {
                string ipAddress = txtIPAddressAlarm.Text;
                int port = Convert.ToInt32(txtPortNumber.Text);

                Log.Info("Sync Alarm Data process started. ");
                using (TcpClient client = new TcpClient())
                {
                    client.ReceiveTimeout = 30000;
                    client.Connect(ipAddress, port);

                    List<AlarmData> alarmData = data;

                    if (alarmData.Count > 0)
                    {
                        Log.Info("No of Alarm count = " + alarmData.Count);
                        Log.Info("Alarm Data Details : " + Environment.NewLine + JsonConvert.SerializeObject(alarmData));

                        using (NetworkStream stream = client.GetStream())
                        {
                            //======= transport header =========================================================
                            SendTransportHeader tHeader = new SendTransportHeader();
                            tHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                            tHeader.Body.ServiceType = ServiceType.TcdLogRequest;
                            Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogRequest);

                            XMLSerializer xmlserialize = new XMLSerializer();
                            string xmlString = xmlserialize.ConvertToXML(alarmData);

                            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(xmlString);

                            //============ TcdBatch Request Header =============================================
                            TcdBatchRequestHeader alarmHeader = new TcdBatchRequestHeader { MessageType = TcdMessageTypes.AlarmRequest, PayloadSize = (uint)buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack };
                            Log.Info("Message Type = " + TcdMessageTypes.AlarmRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                            // ============== Write to stream ==================================================
                            stream.Write(tHeader);
                            stream.Write(alarmHeader);
                            stream.Write(buffer, 0, buffer.Length);

                            MessageBox.Show("Data send on stream.");

                            //======== read the response from tcp server =======================================
                            TcdBatchResponse response = stream.ReadAllOf<TcdBatchResponse>();
                            Log.Info("Response Details : " + Environment.NewLine + JsonConvert.SerializeObject(response));

                            MessageBox.Show("Response Received. Response = " + response.ErrorCode);
                            if (response.ErrorCode == TcdErrCodes.Success)
                            {
                                Log.Info("Request send to message queue.");
                                
                            }
                            else
                            {
                                Log.Info("Error in alarm request send.");
                                MessageBox.Show("Error in alarm request send.");
                            }
                        }
                    }
                    else
                    {
                        Log.Info("alarm Data Count is zero.");
                        MessageBox.Show("alarm Data Count is zero.");
                    }
                }
            }
            catch (SocketException socEx)
            {
                MessageBox.Show("Error ::" + socEx);
                Log.Error("Error Received While process alarm data :" + socEx);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error ::" + ex);
                Log.Error("Error occured while process alarm data :" + ex);
            }
        }

        /// <summary>
        ///     Serialize
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="thisObj">object of type param</param>
        /// <returns></returns>
        public byte[] Serialize<T>(T thisObj)
        {
            MessagePackSerializer<T> serializer = MessagePackSerializer.Get<T>();
            using (MemoryStream byteStream = new MemoryStream())
            {
                serializer.Pack(byteStream, thisObj);
                return byteStream.ToArray();
            }
        }

        private AlarmData GetAlarmData()
        {
            AlarmData alarmData = new AlarmData();
            alarmData.StartDate = Convert.ToDateTime(txtStartDate.Text);
            alarmData.StartDateFormatted = Convert.ToString(txtStartDateFormatted.Text);
            alarmData.MachineName = Convert.ToString(txtMachineName.Text);
            alarmData.AlarmDescription = Convert.ToString(txtAlarmDescription.Text);
            alarmData.AlarmCode = int.Parse(txtAlarmCode.Text);
            alarmData.ControllerId = int.Parse(txtControllerId.Text);
            alarmData.GroupId = int.Parse(txtGroupId.Text);
            alarmData.MachineInternalId = int.Parse(txtMachineInternalId.Text);
            alarmData.ProgramId = int.Parse(txtProgramId.Text);
            alarmData.MENumber = int.Parse(txtMENumber.Text);
            alarmData.BatchId = int.Parse(txtBatchId.Text);
            alarmData.Valve = int.Parse(txtValve.Text);
            alarmData.InjectionNumber = int.Parse(txtInjectionNumber.Text);
            alarmData.MachineId = int.Parse(txtMachineId.Text);
            alarmData.IsActive = bool.Parse(txtIsActive.Text);
            alarmData.EndDate = Convert.ToDateTime(txtEndDate.Text);
            alarmData.DesiredQuantity = int.Parse(txtDesiredQuatity.Text);
            alarmData.MeasuredQuantity = int.Parse(txtMeasuredQuantity.Text);
            alarmData.TempStatus = int.Parse(txtTempStatus.Text);
            alarmData.ProbeNumber = int.Parse(txtProbeNumber.Text);
            alarmData.UserId = int.Parse(txtUserId.Text);
            alarmData.StepId = Convert.ToString(txtStepId.Text);
            alarmData.PartitionOn = Convert.ToDateTime(txtPartitionOn.Text);
            alarmData.LastSyncTime = Convert.ToDateTime(txtLastSyncTime.Text);
            alarmData.EcoalabAccountNumber = Convert.ToString(txtEcoalabAccountNumber.Text);
            alarmData.AlarmGroupMasterId = int.Parse(txtAlarmGroupMasterId.Text);

            alarmData.AlarmMasterList = new List<AlarmMaster>();
            foreach (AlarmMaster alarmMasterData in alarmMasterCollection)
            {
                alarmData.AlarmMasterList.Add(alarmMasterData);
            }

            return alarmData;
        }

        private void btnAddAlarmMasterData_Click(object sender, EventArgs e)
        {
            AlarmMaster alarmMaster = new AlarmMaster();
            alarmMaster.AlarmCode = int.Parse(txtAlarmCodeAlarmMaster.Text);
            alarmMaster.Description = Convert.ToString(txtDescriptionAlarmMaster.Text);
            alarmMaster.ControllerModelTypeId = int.Parse(txtControllerModelTypeId.Text);
            alarmMaster.ResourceKey = Convert.ToString(txtResourceKey.Text);
            alarmMaster.IsDefault = bool.Parse(txtIsDefault.Text);
            alarmMaster.AlarmMaachineMappingId = int.Parse(txtAlarmMaachineMappingId.Text);
            alarmMaster.MachineNumber = int.Parse(txtMachineNumber.Text);
            alarmMaster.ControllerModelId = int.Parse(txtControllerModelId.Text);
            alarmMaster.ControllerTypeId = int.Parse(txtControllerTypeId.Text);
            alarmMaster.LastModifiedTime = Convert.ToDateTime(txtLastModifiedTime.Text);
            alarmMaster.WasherType = Convert.ToString(txtWasherType.Text);
            alarmMaster.IsDeleteAlarmMapping = bool.Parse(txtIsDeleteAlarmMapping.Text);
            alarmMaster.MachineNumberMappingId = int.Parse(txtMachineNumberMappingId.Text);
            alarmMaster.IsHoldCondition = bool.Parse(txtIsHoldCondition.Text);
            alarmMaster.AlarmNumber = int.Parse(txtAlarmNumber.Text);
            alarmMasterCollection.Add(alarmMaster);

            lblAlarmMasterStatus.Text = "Alarm Master data added successfully. Count = " + alarmMasterCollection.Count;

        }

        private void btnAddAlarmData_Click(object sender, EventArgs e)
        {
            AlarmData alarmData = GetAlarmData();
            alarmCollection.Add(alarmData);
            lblAlarmDataCount.Text = "Alarm Data Count = " + alarmCollection.Count;
            MessageBox.Show("Alarm Data added successfully.");
         

            alarmMasterCollection = new List<AlarmMaster>();
            

            lblAlarmMasterStatus.Text = "Data Added to main Alarm.";
            lblAlarmDataCount.Text = "Data Added to main Alarm.";


        }

        private void btnGenerateXML_Click(object sender, EventArgs e)
        {
            List<AlarmData> alarmData = alarmCollection;
            XMLSerializer xmlserialize = new XMLSerializer();
            string xmlString = xmlserialize.ConvertToXML(alarmData);
        }
    }

   

}
