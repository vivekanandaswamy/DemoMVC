﻿namespace Ecolab.Conduit.BatchDataSyncTest
{
    partial class AlarmDataSyncForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnGenerateXML = new System.Windows.Forms.Button();
            this.btnSendAlarmDataToTCP = new System.Windows.Forms.Button();
            this.btnAddAlarmData = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAddAlarmMasterData = new System.Windows.Forms.Button();
            this.txtAlarmNumber = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtIsHoldCondition = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtMachineNumberMappingId = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtIsDeleteAlarmMapping = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtWasherType = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtLastModifiedTime = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtControllerTypeId = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtControllerModelId = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtMachineNumber = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtAlarmMaachineMappingId = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtIsDefault = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtResourceKey = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtControllerModelTypeId = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtDescriptionAlarmMaster = new System.Windows.Forms.TextBox();
            this.lable30 = new System.Windows.Forms.Label();
            this.txtAlarmCodeAlarmMaster = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAlarmGroupMasterId = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtEcoalabAccountNumber = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtLastSyncTime = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtPartitionOn = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtStepId = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtProbeNumber = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtTempStatus = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtMeasuredQuantity = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtDesiredQuatity = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtEndDate = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtIsActive = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMachineId = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtInjectionNumber = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtValve = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtBatchId = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtMENumber = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProgramId = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMachineInternalId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtGroupId = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtControllerId = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtAlarmCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAlarmDescription = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMachineName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtStartDateFormatted = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtStartDate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPortNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIPAddressAlarm = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblAlarmMasterStatus = new System.Windows.Forms.Label();
            this.lblAlarmDataCount = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1038, 707);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.Controls.Add(this.lblAlarmDataCount);
            this.tabPage1.Controls.Add(this.btnGenerateXML);
            this.tabPage1.Controls.Add(this.btnSendAlarmDataToTCP);
            this.tabPage1.Controls.Add(this.btnAddAlarmData);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.txtPortNumber);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtIPAddressAlarm);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1030, 681);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Alarm Data (Object)";
            // 
            // btnGenerateXML
            // 
            this.btnGenerateXML.Location = new System.Drawing.Point(439, 637);
            this.btnGenerateXML.Name = "btnGenerateXML";
            this.btnGenerateXML.Size = new System.Drawing.Size(154, 30);
            this.btnGenerateXML.TabIndex = 8;
            this.btnGenerateXML.Text = "Generate XML";
            this.btnGenerateXML.UseVisualStyleBackColor = true;
            this.btnGenerateXML.Click += new System.EventHandler(this.btnGenerateXML_Click);
            // 
            // btnSendAlarmDataToTCP
            // 
            this.btnSendAlarmDataToTCP.Location = new System.Drawing.Point(728, 612);
            this.btnSendAlarmDataToTCP.Name = "btnSendAlarmDataToTCP";
            this.btnSendAlarmDataToTCP.Size = new System.Drawing.Size(138, 23);
            this.btnSendAlarmDataToTCP.TabIndex = 7;
            this.btnSendAlarmDataToTCP.Text = "Send Alarm Data to TCP";
            this.btnSendAlarmDataToTCP.UseVisualStyleBackColor = true;
            // 
            // btnAddAlarmData
            // 
            this.btnAddAlarmData.Location = new System.Drawing.Point(166, 612);
            this.btnAddAlarmData.Name = "btnAddAlarmData";
            this.btnAddAlarmData.Size = new System.Drawing.Size(154, 23);
            this.btnAddAlarmData.TabIndex = 6;
            this.btnAddAlarmData.Text = "Add Alarm Data";
            this.btnAddAlarmData.UseVisualStyleBackColor = true;
            this.btnAddAlarmData.Click += new System.EventHandler(this.btnAddAlarmData_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.groupBox2.Controls.Add(this.lblAlarmMasterStatus);
            this.groupBox2.Controls.Add(this.btnAddAlarmMasterData);
            this.groupBox2.Controls.Add(this.txtAlarmNumber);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.txtIsHoldCondition);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.txtMachineNumberMappingId);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.txtIsDeleteAlarmMapping);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.txtWasherType);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.txtLastModifiedTime);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.txtControllerTypeId);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.txtControllerModelId);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.txtMachineNumber);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.txtAlarmMaachineMappingId);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.txtIsDefault);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.txtResourceKey);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.txtControllerModelTypeId);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.txtDescriptionAlarmMaster);
            this.groupBox2.Controls.Add(this.lable30);
            this.groupBox2.Controls.Add(this.txtAlarmCodeAlarmMaster);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Location = new System.Drawing.Point(28, 350);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(971, 245);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Alarm Master";
            // 
            // btnAddAlarmMasterData
            // 
            this.btnAddAlarmMasterData.Location = new System.Drawing.Point(714, 198);
            this.btnAddAlarmMasterData.Name = "btnAddAlarmMasterData";
            this.btnAddAlarmMasterData.Size = new System.Drawing.Size(134, 23);
            this.btnAddAlarmMasterData.TabIndex = 30;
            this.btnAddAlarmMasterData.Text = "Add Alarm Master Data";
            this.btnAddAlarmMasterData.UseVisualStyleBackColor = true;
            this.btnAddAlarmMasterData.Click += new System.EventHandler(this.btnAddAlarmMasterData_Click);
            // 
            // txtAlarmNumber
            // 
            this.txtAlarmNumber.Location = new System.Drawing.Point(713, 150);
            this.txtAlarmNumber.Name = "txtAlarmNumber";
            this.txtAlarmNumber.Size = new System.Drawing.Size(100, 20);
            this.txtAlarmNumber.TabIndex = 29;
            this.txtAlarmNumber.Text = "1";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(566, 158);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(73, 13);
            this.label42.TabIndex = 28;
            this.label42.Text = "Alarm Number";
            // 
            // txtIsHoldCondition
            // 
            this.txtIsHoldCondition.Location = new System.Drawing.Point(712, 121);
            this.txtIsHoldCondition.Name = "txtIsHoldCondition";
            this.txtIsHoldCondition.Size = new System.Drawing.Size(100, 20);
            this.txtIsHoldCondition.TabIndex = 27;
            this.txtIsHoldCondition.Text = "True";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(566, 124);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(84, 13);
            this.label41.TabIndex = 26;
            this.label41.Text = "IsHold Condition";
            // 
            // txtMachineNumberMappingId
            // 
            this.txtMachineNumberMappingId.Location = new System.Drawing.Point(713, 90);
            this.txtMachineNumberMappingId.Name = "txtMachineNumberMappingId";
            this.txtMachineNumberMappingId.Size = new System.Drawing.Size(100, 20);
            this.txtMachineNumberMappingId.TabIndex = 25;
            this.txtMachineNumberMappingId.Text = "1";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(563, 93);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(144, 13);
            this.label40.TabIndex = 24;
            this.label40.Text = "Machine Number Mapping Id";
            // 
            // txtIsDeleteAlarmMapping
            // 
            this.txtIsDeleteAlarmMapping.Location = new System.Drawing.Point(712, 58);
            this.txtIsDeleteAlarmMapping.Name = "txtIsDeleteAlarmMapping";
            this.txtIsDeleteAlarmMapping.Size = new System.Drawing.Size(100, 20);
            this.txtIsDeleteAlarmMapping.TabIndex = 23;
            this.txtIsDeleteAlarmMapping.Text = "True";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(563, 65);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(119, 13);
            this.label39.TabIndex = 22;
            this.label39.Text = "IsDelete Alarm Mapping";
            // 
            // txtWasherType
            // 
            this.txtWasherType.Location = new System.Drawing.Point(712, 26);
            this.txtWasherType.Name = "txtWasherType";
            this.txtWasherType.Size = new System.Drawing.Size(100, 20);
            this.txtWasherType.TabIndex = 21;
            this.txtWasherType.Text = "Washer Type";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(563, 29);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(71, 13);
            this.label38.TabIndex = 20;
            this.label38.Text = "Washer Type";
            // 
            // txtLastModifiedTime
            // 
            this.txtLastModifiedTime.Location = new System.Drawing.Point(432, 158);
            this.txtLastModifiedTime.Name = "txtLastModifiedTime";
            this.txtLastModifiedTime.Size = new System.Drawing.Size(100, 20);
            this.txtLastModifiedTime.TabIndex = 19;
            this.txtLastModifiedTime.Text = "2014-12-05 17:49:39.670";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(280, 161);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(96, 13);
            this.label37.TabIndex = 18;
            this.label37.Text = "Last Modified Time";
            // 
            // txtControllerTypeId
            // 
            this.txtControllerTypeId.Location = new System.Drawing.Point(432, 123);
            this.txtControllerTypeId.Name = "txtControllerTypeId";
            this.txtControllerTypeId.Size = new System.Drawing.Size(100, 20);
            this.txtControllerTypeId.TabIndex = 17;
            this.txtControllerTypeId.Text = "1";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(280, 126);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(90, 13);
            this.label36.TabIndex = 16;
            this.label36.Text = "Controller Type Id";
            // 
            // txtControllerModelId
            // 
            this.txtControllerModelId.Location = new System.Drawing.Point(432, 89);
            this.txtControllerModelId.Name = "txtControllerModelId";
            this.txtControllerModelId.Size = new System.Drawing.Size(100, 20);
            this.txtControllerModelId.TabIndex = 15;
            this.txtControllerModelId.Text = "1";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(280, 97);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(95, 13);
            this.label35.TabIndex = 14;
            this.label35.Text = "Controller Model Id";
            // 
            // txtMachineNumber
            // 
            this.txtMachineNumber.Location = new System.Drawing.Point(432, 56);
            this.txtMachineNumber.Name = "txtMachineNumber";
            this.txtMachineNumber.Size = new System.Drawing.Size(100, 20);
            this.txtMachineNumber.TabIndex = 13;
            this.txtMachineNumber.Text = "1";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(280, 65);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(88, 13);
            this.label34.TabIndex = 12;
            this.label34.Text = "Machine Number";
            // 
            // txtAlarmMaachineMappingId
            // 
            this.txtAlarmMaachineMappingId.Location = new System.Drawing.Point(432, 25);
            this.txtAlarmMaachineMappingId.Name = "txtAlarmMaachineMappingId";
            this.txtAlarmMaachineMappingId.Size = new System.Drawing.Size(100, 20);
            this.txtAlarmMaachineMappingId.TabIndex = 11;
            this.txtAlarmMaachineMappingId.Text = "1";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(280, 33);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(130, 13);
            this.label33.TabIndex = 10;
            this.label33.Text = "Alarm Machine MappingId";
            // 
            // txtIsDefault
            // 
            this.txtIsDefault.Location = new System.Drawing.Point(157, 158);
            this.txtIsDefault.Name = "txtIsDefault";
            this.txtIsDefault.Size = new System.Drawing.Size(100, 20);
            this.txtIsDefault.TabIndex = 9;
            this.txtIsDefault.Text = "True";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(31, 158);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(49, 13);
            this.label32.TabIndex = 8;
            this.label32.Text = "IsDefault";
            // 
            // txtResourceKey
            // 
            this.txtResourceKey.Location = new System.Drawing.Point(157, 124);
            this.txtResourceKey.Name = "txtResourceKey";
            this.txtResourceKey.Size = new System.Drawing.Size(100, 20);
            this.txtResourceKey.TabIndex = 7;
            this.txtResourceKey.Text = "Resource Key";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(27, 127);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 13);
            this.label31.TabIndex = 6;
            this.label31.Text = "Resource Key";
            // 
            // txtControllerModelTypeId
            // 
            this.txtControllerModelTypeId.Location = new System.Drawing.Point(157, 97);
            this.txtControllerModelTypeId.Name = "txtControllerModelTypeId";
            this.txtControllerModelTypeId.Size = new System.Drawing.Size(100, 20);
            this.txtControllerModelTypeId.TabIndex = 5;
            this.txtControllerModelTypeId.Text = "1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(27, 100);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(122, 13);
            this.label30.TabIndex = 4;
            this.label30.Text = "Controller Model Type Id";
            // 
            // txtDescriptionAlarmMaster
            // 
            this.txtDescriptionAlarmMaster.Location = new System.Drawing.Point(157, 65);
            this.txtDescriptionAlarmMaster.Name = "txtDescriptionAlarmMaster";
            this.txtDescriptionAlarmMaster.Size = new System.Drawing.Size(100, 20);
            this.txtDescriptionAlarmMaster.TabIndex = 3;
            this.txtDescriptionAlarmMaster.Text = "Description";
            // 
            // lable30
            // 
            this.lable30.AutoSize = true;
            this.lable30.Location = new System.Drawing.Point(27, 65);
            this.lable30.Name = "lable30";
            this.lable30.Size = new System.Drawing.Size(60, 13);
            this.lable30.TabIndex = 2;
            this.lable30.Text = "Description";
            // 
            // txtAlarmCodeAlarmMaster
            // 
            this.txtAlarmCodeAlarmMaster.Location = new System.Drawing.Point(157, 26);
            this.txtAlarmCodeAlarmMaster.Name = "txtAlarmCodeAlarmMaster";
            this.txtAlarmCodeAlarmMaster.Size = new System.Drawing.Size(100, 20);
            this.txtAlarmCodeAlarmMaster.TabIndex = 1;
            this.txtAlarmCodeAlarmMaster.Text = "1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(27, 33);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Alarm Code";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.groupBox1.Controls.Add(this.txtAlarmGroupMasterId);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtEcoalabAccountNumber);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.txtLastSyncTime);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.txtPartitionOn);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.txtStepId);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.txtUserId);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtProbeNumber);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.txtTempStatus);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.txtMeasuredQuantity);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtDesiredQuatity);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtEndDate);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtIsActive);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtMachineId);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtInjectionNumber);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtValve);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtBatchId);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtMENumber);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtProgramId);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtMachineInternalId);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtGroupId);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtControllerId);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtAlarmCode);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtAlarmDescription);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtMachineName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtStartDateFormatted);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtStartDate);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(28, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(971, 302);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Alarm Data";
            // 
            // txtAlarmGroupMasterId
            // 
            this.txtAlarmGroupMasterId.Location = new System.Drawing.Point(844, 169);
            this.txtAlarmGroupMasterId.Name = "txtAlarmGroupMasterId";
            this.txtAlarmGroupMasterId.Size = new System.Drawing.Size(100, 20);
            this.txtAlarmGroupMasterId.TabIndex = 51;
            this.txtAlarmGroupMasterId.Text = "1";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(709, 169);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(112, 13);
            this.label28.TabIndex = 50;
            this.label28.Text = "Alarm Group Master Id";
            // 
            // txtEcoalabAccountNumber
            // 
            this.txtEcoalabAccountNumber.Location = new System.Drawing.Point(844, 136);
            this.txtEcoalabAccountNumber.Name = "txtEcoalabAccountNumber";
            this.txtEcoalabAccountNumber.Size = new System.Drawing.Size(100, 20);
            this.txtEcoalabAccountNumber.TabIndex = 49;
            this.txtEcoalabAccountNumber.Text = "0123456789";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(709, 139);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(129, 13);
            this.label27.TabIndex = 48;
            this.label27.Text = "Ecoalab Account Number";
            // 
            // txtLastSyncTime
            // 
            this.txtLastSyncTime.Location = new System.Drawing.Point(844, 98);
            this.txtLastSyncTime.Name = "txtLastSyncTime";
            this.txtLastSyncTime.Size = new System.Drawing.Size(100, 20);
            this.txtLastSyncTime.TabIndex = 47;
            this.txtLastSyncTime.Text = "2014-12-05 17:49:39.670";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(711, 101);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(80, 13);
            this.label26.TabIndex = 46;
            this.label26.Text = "LastSync Time ";
            // 
            // txtPartitionOn
            // 
            this.txtPartitionOn.Location = new System.Drawing.Point(844, 63);
            this.txtPartitionOn.Name = "txtPartitionOn";
            this.txtPartitionOn.Size = new System.Drawing.Size(100, 20);
            this.txtPartitionOn.TabIndex = 45;
            this.txtPartitionOn.Text = "2014-12-05 17:49:39.670";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(711, 68);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(62, 13);
            this.label25.TabIndex = 44;
            this.label25.Text = "Partition On";
            // 
            // txtStepId
            // 
            this.txtStepId.Location = new System.Drawing.Point(844, 37);
            this.txtStepId.Name = "txtStepId";
            this.txtStepId.Size = new System.Drawing.Size(100, 20);
            this.txtStepId.TabIndex = 43;
            this.txtStepId.Text = "1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(711, 40);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 13);
            this.label24.TabIndex = 42;
            this.label24.Text = "Step Id ";
            // 
            // txtUserId
            // 
            this.txtUserId.Location = new System.Drawing.Point(588, 218);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(100, 20);
            this.txtUserId.TabIndex = 41;
            this.txtUserId.Text = "1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(490, 221);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 13);
            this.label23.TabIndex = 40;
            this.label23.Text = "User Id";
            // 
            // txtProbeNumber
            // 
            this.txtProbeNumber.Location = new System.Drawing.Point(588, 192);
            this.txtProbeNumber.Name = "txtProbeNumber";
            this.txtProbeNumber.Size = new System.Drawing.Size(100, 20);
            this.txtProbeNumber.TabIndex = 39;
            this.txtProbeNumber.Text = "1";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(490, 192);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "Probe Number";
            // 
            // txtTempStatus
            // 
            this.txtTempStatus.Location = new System.Drawing.Point(588, 162);
            this.txtTempStatus.Name = "txtTempStatus";
            this.txtTempStatus.Size = new System.Drawing.Size(100, 20);
            this.txtTempStatus.TabIndex = 37;
            this.txtTempStatus.Text = "1";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(486, 162);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 13);
            this.label21.TabIndex = 36;
            this.label21.Text = "Temp Status";
            // 
            // txtMeasuredQuantity
            // 
            this.txtMeasuredQuantity.Location = new System.Drawing.Point(588, 130);
            this.txtMeasuredQuantity.Name = "txtMeasuredQuantity";
            this.txtMeasuredQuantity.Size = new System.Drawing.Size(100, 20);
            this.txtMeasuredQuantity.TabIndex = 35;
            this.txtMeasuredQuantity.Text = "1";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(486, 130);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 13);
            this.label20.TabIndex = 34;
            this.label20.Text = "Measured Quantity";
            // 
            // txtDesiredQuatity
            // 
            this.txtDesiredQuatity.Location = new System.Drawing.Point(588, 104);
            this.txtDesiredQuatity.Name = "txtDesiredQuatity";
            this.txtDesiredQuatity.Size = new System.Drawing.Size(100, 20);
            this.txtDesiredQuatity.TabIndex = 33;
            this.txtDesiredQuatity.Text = "1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(486, 104);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 13);
            this.label19.TabIndex = 32;
            this.label19.Text = "Desired Quatity";
            // 
            // txtEndDate
            // 
            this.txtEndDate.Location = new System.Drawing.Point(588, 68);
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(100, 20);
            this.txtEndDate.TabIndex = 31;
            this.txtEndDate.Text = "2014-12-05 17:49:39.670";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(486, 75);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 13);
            this.label18.TabIndex = 30;
            this.label18.Text = "End Date";
            // 
            // txtIsActive
            // 
            this.txtIsActive.Location = new System.Drawing.Point(588, 34);
            this.txtIsActive.Name = "txtIsActive";
            this.txtIsActive.Size = new System.Drawing.Size(100, 20);
            this.txtIsActive.TabIndex = 29;
            this.txtIsActive.Text = "True";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(486, 40);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "IsActive";
            // 
            // txtMachineId
            // 
            this.txtMachineId.Location = new System.Drawing.Point(359, 221);
            this.txtMachineId.Name = "txtMachineId";
            this.txtMachineId.Size = new System.Drawing.Size(100, 20);
            this.txtMachineId.TabIndex = 27;
            this.txtMachineId.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(261, 221);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 26;
            this.label16.Text = "Machine Id";
            // 
            // txtInjectionNumber
            // 
            this.txtInjectionNumber.Location = new System.Drawing.Point(359, 192);
            this.txtInjectionNumber.Name = "txtInjectionNumber";
            this.txtInjectionNumber.Size = new System.Drawing.Size(100, 20);
            this.txtInjectionNumber.TabIndex = 25;
            this.txtInjectionNumber.Text = "1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(258, 192);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 13);
            this.label15.TabIndex = 24;
            this.label15.Text = "Injection Number";
            // 
            // txtValve
            // 
            this.txtValve.Location = new System.Drawing.Point(359, 159);
            this.txtValve.Name = "txtValve";
            this.txtValve.Size = new System.Drawing.Size(100, 20);
            this.txtValve.TabIndex = 23;
            this.txtValve.Text = "1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(258, 161);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(34, 13);
            this.label14.TabIndex = 22;
            this.label14.Text = "Valve";
            // 
            // txtBatchId
            // 
            this.txtBatchId.Location = new System.Drawing.Point(359, 127);
            this.txtBatchId.Name = "txtBatchId";
            this.txtBatchId.Size = new System.Drawing.Size(100, 20);
            this.txtBatchId.TabIndex = 21;
            this.txtBatchId.Text = "1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(258, 130);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "Batch Id";
            // 
            // txtMENumber
            // 
            this.txtMENumber.Location = new System.Drawing.Point(359, 97);
            this.txtMENumber.Name = "txtMENumber";
            this.txtMENumber.Size = new System.Drawing.Size(100, 20);
            this.txtMENumber.TabIndex = 19;
            this.txtMENumber.Text = "1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(258, 97);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 18;
            this.label12.Text = "ME Number";
            // 
            // txtProgramId
            // 
            this.txtProgramId.Location = new System.Drawing.Point(359, 68);
            this.txtProgramId.Name = "txtProgramId";
            this.txtProgramId.Size = new System.Drawing.Size(100, 20);
            this.txtProgramId.TabIndex = 17;
            this.txtProgramId.Text = "1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(255, 71);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "Program Id";
            // 
            // txtMachineInternalId
            // 
            this.txtMachineInternalId.Location = new System.Drawing.Point(359, 37);
            this.txtMachineInternalId.Name = "txtMachineInternalId";
            this.txtMachineInternalId.Size = new System.Drawing.Size(100, 20);
            this.txtMachineInternalId.TabIndex = 15;
            this.txtMachineInternalId.Text = "1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(255, 35);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Machine Internal Id";
            // 
            // txtGroupId
            // 
            this.txtGroupId.Location = new System.Drawing.Point(138, 215);
            this.txtGroupId.Name = "txtGroupId";
            this.txtGroupId.Size = new System.Drawing.Size(100, 20);
            this.txtGroupId.TabIndex = 13;
            this.txtGroupId.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 215);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Group Id";
            // 
            // txtControllerId
            // 
            this.txtControllerId.Location = new System.Drawing.Point(138, 188);
            this.txtControllerId.Name = "txtControllerId";
            this.txtControllerId.Size = new System.Drawing.Size(100, 20);
            this.txtControllerId.TabIndex = 11;
            this.txtControllerId.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 188);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Controller Id";
            // 
            // txtAlarmCode
            // 
            this.txtAlarmCode.Location = new System.Drawing.Point(138, 155);
            this.txtAlarmCode.Name = "txtAlarmCode";
            this.txtAlarmCode.Size = new System.Drawing.Size(100, 20);
            this.txtAlarmCode.TabIndex = 9;
            this.txtAlarmCode.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Alarm Code";
            // 
            // txtAlarmDescription
            // 
            this.txtAlarmDescription.Location = new System.Drawing.Point(138, 123);
            this.txtAlarmDescription.Name = "txtAlarmDescription";
            this.txtAlarmDescription.Size = new System.Drawing.Size(100, 20);
            this.txtAlarmDescription.TabIndex = 7;
            this.txtAlarmDescription.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Alarm Description";
            // 
            // txtMachineName
            // 
            this.txtMachineName.Location = new System.Drawing.Point(138, 94);
            this.txtMachineName.Name = "txtMachineName";
            this.txtMachineName.Size = new System.Drawing.Size(100, 20);
            this.txtMachineName.TabIndex = 5;
            this.txtMachineName.Text = "Machine";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Machine Name";
            // 
            // txtStartDateFormatted
            // 
            this.txtStartDateFormatted.Location = new System.Drawing.Point(138, 61);
            this.txtStartDateFormatted.Name = "txtStartDateFormatted";
            this.txtStartDateFormatted.Size = new System.Drawing.Size(100, 20);
            this.txtStartDateFormatted.TabIndex = 3;
            this.txtStartDateFormatted.Text = "1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Start Date Formatted";
            // 
            // txtStartDate
            // 
            this.txtStartDate.Location = new System.Drawing.Point(138, 31);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(100, 20);
            this.txtStartDate.TabIndex = 1;
            this.txtStartDate.Text = "2014-12-05 17:49:39.670";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Start Date";
            // 
            // txtPortNumber
            // 
            this.txtPortNumber.Location = new System.Drawing.Point(366, 16);
            this.txtPortNumber.Name = "txtPortNumber";
            this.txtPortNumber.Size = new System.Drawing.Size(100, 20);
            this.txtPortNumber.TabIndex = 3;
            this.txtPortNumber.Text = "9340";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(283, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Port Number";
            // 
            // txtIPAddressAlarm
            // 
            this.txtIPAddressAlarm.Location = new System.Drawing.Point(128, 16);
            this.txtIPAddressAlarm.Name = "txtIPAddressAlarm";
            this.txtIPAddressAlarm.Size = new System.Drawing.Size(100, 20);
            this.txtIPAddressAlarm.TabIndex = 1;
            this.txtIPAddressAlarm.Text = "localhost";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "IP Address";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1030, 681);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Alarm Data (XML File)";
            // 
            // lblAlarmMasterStatus
            // 
            this.lblAlarmMasterStatus.AutoSize = true;
            this.lblAlarmMasterStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblAlarmMasterStatus.Location = new System.Drawing.Point(59, 198);
            this.lblAlarmMasterStatus.Name = "lblAlarmMasterStatus";
            this.lblAlarmMasterStatus.Size = new System.Drawing.Size(143, 13);
            this.lblAlarmMasterStatus.TabIndex = 31;
            this.lblAlarmMasterStatus.Text = "Alarm Master Data Count = 0";
            // 
            // lblAlarmDataCount
            // 
            this.lblAlarmDataCount.AutoSize = true;
            this.lblAlarmDataCount.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblAlarmDataCount.Location = new System.Drawing.Point(458, 612);
            this.lblAlarmDataCount.Name = "lblAlarmDataCount";
            this.lblAlarmDataCount.Size = new System.Drawing.Size(108, 13);
            this.lblAlarmDataCount.TabIndex = 9;
            this.lblAlarmDataCount.Text = "Alarm Data Count = 0";
            // 
            // AlarmDataSyncForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1105, 731);
            this.Controls.Add(this.tabControl1);
            this.Name = "AlarmDataSyncForm";
            this.Text = "AlarmDataSyncTest";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtIPAddressAlarm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPortNumber;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStartDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtStartDateFormatted;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMachineName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAlarmDescription;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAlarmCode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtControllerId;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtGroupId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtMachineInternalId;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtProgramId;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtMENumber;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtBatchId;
        private System.Windows.Forms.TextBox txtValve;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtInjectionNumber;
        private System.Windows.Forms.TextBox txtMachineId;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtIsActive;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtEndDate;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtDesiredQuatity;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtMeasuredQuantity;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtTempStatus;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtProbeNumber;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtStepId;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtPartitionOn;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtLastSyncTime;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtEcoalabAccountNumber;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtAlarmGroupMasterId;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtAlarmCodeAlarmMaster;
        private System.Windows.Forms.Label lable30;
        private System.Windows.Forms.TextBox txtDescriptionAlarmMaster;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtControllerModelTypeId;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtResourceKey;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtIsDefault;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtAlarmMaachineMappingId;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtMachineNumber;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtControllerModelId;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtControllerTypeId;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtLastModifiedTime;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtWasherType;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtIsDeleteAlarmMapping;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtMachineNumberMappingId;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtIsHoldCondition;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtAlarmNumber;
        private System.Windows.Forms.Button btnAddAlarmMasterData;
        private System.Windows.Forms.Button btnAddAlarmData;
        private System.Windows.Forms.Button btnSendAlarmDataToTCP;
        private System.Windows.Forms.Button btnGenerateXML;
        private System.Windows.Forms.Label lblAlarmMasterStatus;
        private System.Windows.Forms.Label lblAlarmDataCount;
    }
}