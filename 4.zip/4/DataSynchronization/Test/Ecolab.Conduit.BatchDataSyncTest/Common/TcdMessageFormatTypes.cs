﻿// -----------------------------------------------------------------------
// <copyright file="TcdMessageFormatTypes.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd message format types</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Common
{
    /// <summary>
    ///     Tcd message format types enum
    /// </summary>
    public enum TcdMessageFormatTypes : uint
    {
        MessagePack = 1
    }
}