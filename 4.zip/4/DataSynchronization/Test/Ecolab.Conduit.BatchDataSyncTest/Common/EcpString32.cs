﻿namespace Ecolab.Conduit.Library.Common
{
    using System.Runtime.InteropServices;
    using Helpers;

    [StructLayout(LayoutKind.Sequential, Size = STRINGLEN, Pack = 4)]
    public struct EcpString32
    {
        private const int STRINGLEN = 32;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = STRINGLEN)] private byte[] mUtf8Bytes;

        public string Value
        {
            get { return Utf8Helper.FromUtf8Bytes(mUtf8Bytes); }

            set { mUtf8Bytes = Utf8Helper.ToFixedLengthUtf8Bytes(value, STRINGLEN); }
        }

        public static implicit operator string(EcpString32 source)
        {
            return source.Value;
        }

        public static implicit operator EcpString32(string source)
        {
            EcpString32 dest = new EcpString32();

            dest.Value = source;
            return dest;
        }

        public override int GetHashCode()
        {
            return Value.GetHashCode();
        }

        public override string ToString()
        {
            return Value;
        }

        public override bool Equals(object obj)
        {
            if (obj is EcpString32)
            {
                return Value.Equals((EcpString32) obj);
            }
            return false;
        }
    }
}