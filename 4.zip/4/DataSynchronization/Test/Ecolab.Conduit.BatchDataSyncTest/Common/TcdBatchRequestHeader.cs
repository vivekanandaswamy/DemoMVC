﻿namespace Ecolab.Conduit.SyncBatchData.Common
{
    using System.Runtime.InteropServices;
    using Enums;
    using Library.Common;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdBatchRequestHeader
    {
        /// <summary>
        ///     Message Type
        /// </summary>
        public TcdMessageTypes MessageType;

        /// <summary>
        ///     Payload Size
        /// </summary>
        public uint PayloadSize;

        /// <summary>
        ///     Message Format
        /// </summary>
        public TcdMessageFormatTypes MessageFormat;

        /// <summary>
        ///     User Id
        /// </summary>
        public uint UserId;

        /// <summary>
        ///     Timestamp
        /// </summary>
        public long Timestamp;
    }
}