﻿// -----------------------------------------------------------------------
// <copyright file="TcdBatchResponse.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd Admin Request header</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncBatchData.Common
{
    using System.Runtime.InteropServices;
    using Enums;
    using Library.Enums;

    /// <summary>
    ///     TcdBatchResponse
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdBatchResponse
    {
        /// <summary>
        ///     Message Type
        /// </summary>
        public TcdMessageTypes MessageType;

        /// <summary>
        ///     Time stamp
        /// </summary>
        public long Timestamp;

        /// <summary>
        ///     Error code
        /// </summary>
        public TcdErrCodes ErrorCode;
    }
}