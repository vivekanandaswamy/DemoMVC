﻿namespace Ecolab.Conduit.BatchDataSyncTest
{
    partial class BatchDataSyncForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.xmlFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.tabBatchSync = new System.Windows.Forms.TabControl();
            this.tabBatchData = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lblParameterDataStatus = new System.Windows.Forms.Label();
            this.btnAddParameter = new System.Windows.Forms.Button();
            this.txtPartitionOnParameter = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.txtParameterValue = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.txtParameterId = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.txtEcolabWasherIdParameter = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtBatchIdParameter = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblEnergyUsageStatus = new System.Windows.Forms.Label();
            this.btnAddEnergyUsage = new System.Windows.Forms.Button();
            this.txtPartitionOnEnergyUsage = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txtEcolabWasherIdEnergyUsage = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.txtPriceEnergyUsage = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.txtStandardQuantityEnergyUsage = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtActualQuantityEnergyUsage = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtGasOilTypeIdEnergyUsage = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtStepCompartmentEnergyUsage = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.txtBatchIdEnergyUsageData = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.txtETechlastDroppedTimeStamp = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtStdWashSteps = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtStdInjectionSteps = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtSyncReady = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtPlantProgramId = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtEcolabSaturationId = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtFormulaSegmentId = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtChainTextileCategoryId = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtEcolabTextileCategoryId = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txtTargetTurnTime = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtShiftId = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.BtnGenearateXML = new System.Windows.Forms.Button();
            this.TxtMachineId = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtProgramMasterId = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtEndDateFormula = new System.Windows.Forms.TextBox();
            this.txtBatchStatus = new System.Windows.Forms.TextBox();
            this.txtHoldTime = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtManualWeight = new System.Windows.Forms.TextBox();
            this.lblManualWeight = new System.Windows.Forms.Label();
            this.lblBatchDataCount = new System.Windows.Forms.Label();
            this.btnSendBatchDataToTcp = new System.Windows.Forms.Button();
            this.btnAddBatchData = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblWashStepStatus = new System.Windows.Forms.Label();
            this.btnAddWashStep = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtBatchIdWS = new System.Windows.Forms.TextBox();
            this.txtStepCompartment = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtStartTime = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtEndTime = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblWaterUsageStatus = new System.Windows.Forms.Label();
            this.btnAddWaterUsages = new System.Windows.Forms.Button();
            this.txtStepCompartmentSWU = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txtbatchIdWU = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtWaterTypeId = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtPriceWU = new System.Windows.Forms.TextBox();
            this.txtActualQuantityWU = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtStdQuantityWU = new System.Windows.Forms.TextBox();
            this.txtCurrencyCode = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtProductId = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txtPartitionOn = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtTimestampProduct = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtEcolabWasherIdProduct = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lblProductStatus = new System.Windows.Forms.Label();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.txtBatchIdProduct = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtStepCmprtment = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtActualQuantity = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtStandardQuantity = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtPlantWasherNumber = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblBatchCustomerStatus = new System.Windows.Forms.Label();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.txtCustomerId = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtLoad = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPiecesCount = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtBatchIdCustomer = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBatchId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtControllerBatchId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEcolabWasherId = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGroupId = new System.Windows.Forms.TextBox();
            this.txtMachineInternalId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtStartDate = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtEndDate = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProgramNumber = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtActualWeight = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtStandardWeight = new System.Windows.Forms.TextBox();
            this.txtPortNumber = new System.Windows.Forms.TextBox();
            this.txtIpAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabBatchDataByXml = new System.Windows.Forms.TabPage();
            this.txtPortNumberBatchXml = new System.Windows.Forms.TextBox();
            this.txtIpAddressBatchXml = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.btnSendToTcp = new System.Windows.Forms.Button();
            this.txtSelectedFile = new System.Windows.Forms.TextBox();
            this.btnSelectFile = new System.Windows.Forms.Button();
            this.tabBatchSync.SuspendLayout();
            this.tabBatchData.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabBatchDataByXml.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabBatchSync
            // 
            this.tabBatchSync.Controls.Add(this.tabBatchData);
            this.tabBatchSync.Controls.Add(this.tabBatchDataByXml);
            this.tabBatchSync.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabBatchSync.Location = new System.Drawing.Point(0, 0);
            this.tabBatchSync.Name = "tabBatchSync";
            this.tabBatchSync.SelectedIndex = 0;
            this.tabBatchSync.Size = new System.Drawing.Size(1177, 750);
            this.tabBatchSync.TabIndex = 86;
            // 
            // tabBatchData
            // 
            this.tabBatchData.BackColor = System.Drawing.Color.Silver;
            this.tabBatchData.Controls.Add(this.groupBox1);
            this.tabBatchData.Controls.Add(this.txtPortNumber);
            this.tabBatchData.Controls.Add(this.txtIpAddress);
            this.tabBatchData.Controls.Add(this.label3);
            this.tabBatchData.Controls.Add(this.label2);
            this.tabBatchData.Controls.Add(this.label1);
            this.tabBatchData.Location = new System.Drawing.Point(4, 22);
            this.tabBatchData.Name = "tabBatchData";
            this.tabBatchData.Padding = new System.Windows.Forms.Padding(3);
            this.tabBatchData.Size = new System.Drawing.Size(1169, 724);
            this.tabBatchData.TabIndex = 0;
            this.tabBatchData.Text = "Batch Data ( Object ) ";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.txtETechlastDroppedTimeStamp);
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.txtStdWashSteps);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.txtStdInjectionSteps);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.txtSyncReady);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.txtPlantProgramId);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Controls.Add(this.txtEcolabSaturationId);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.txtFormulaSegmentId);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.txtChainTextileCategoryId);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.txtEcolabTextileCategoryId);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.txtTargetTurnTime);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Controls.Add(this.txtShiftId);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.BtnGenearateXML);
            this.groupBox1.Controls.Add(this.TxtMachineId);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.txtProgramMasterId);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.txtEndDateFormula);
            this.groupBox1.Controls.Add(this.txtBatchStatus);
            this.groupBox1.Controls.Add(this.txtHoldTime);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.txtManualWeight);
            this.groupBox1.Controls.Add(this.lblManualWeight);
            this.groupBox1.Controls.Add(this.lblBatchDataCount);
            this.groupBox1.Controls.Add(this.btnSendBatchDataToTcp);
            this.groupBox1.Controls.Add(this.btnAddBatchData);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.txtCurrencyCode);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.txtPlantWasherNumber);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtBatchId);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtControllerBatchId);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtEcolabWasherId);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtGroupId);
            this.groupBox1.Controls.Add(this.txtMachineInternalId);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtStartDate);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtEndDate);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtProgramNumber);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtActualWeight);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtStandardWeight);
            this.groupBox1.Location = new System.Drawing.Point(5, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1156, 677);
            this.groupBox1.TabIndex = 90;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Batch Data";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.lblParameterDataStatus);
            this.groupBox7.Controls.Add(this.btnAddParameter);
            this.groupBox7.Controls.Add(this.txtPartitionOnParameter);
            this.groupBox7.Controls.Add(this.label70);
            this.groupBox7.Controls.Add(this.txtParameterValue);
            this.groupBox7.Controls.Add(this.label69);
            this.groupBox7.Controls.Add(this.txtParameterId);
            this.groupBox7.Controls.Add(this.label68);
            this.groupBox7.Controls.Add(this.txtEcolabWasherIdParameter);
            this.groupBox7.Controls.Add(this.label67);
            this.groupBox7.Controls.Add(this.txtBatchIdParameter);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Location = new System.Drawing.Point(756, 428);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(380, 153);
            this.groupBox7.TabIndex = 135;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Batch Parameter Data";
            // 
            // lblParameterDataStatus
            // 
            this.lblParameterDataStatus.AutoSize = true;
            this.lblParameterDataStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblParameterDataStatus.Location = new System.Drawing.Point(17, 113);
            this.lblParameterDataStatus.Name = "lblParameterDataStatus";
            this.lblParameterDataStatus.Size = new System.Drawing.Size(161, 13);
            this.lblParameterDataStatus.TabIndex = 11;
            this.lblParameterDataStatus.Text = "Batch Parameter Data Count = 0";
            // 
            // btnAddParameter
            // 
            this.btnAddParameter.Location = new System.Drawing.Point(252, 103);
            this.btnAddParameter.Name = "btnAddParameter";
            this.btnAddParameter.Size = new System.Drawing.Size(115, 23);
            this.btnAddParameter.TabIndex = 10;
            this.btnAddParameter.Text = "Add Parameter Data";
            this.btnAddParameter.UseVisualStyleBackColor = true;
            this.btnAddParameter.Click += new System.EventHandler(this.btnAddParameter_Click);
            // 
            // txtPartitionOnParameter
            // 
            this.txtPartitionOnParameter.Location = new System.Drawing.Point(108, 70);
            this.txtPartitionOnParameter.Name = "txtPartitionOnParameter";
            this.txtPartitionOnParameter.Size = new System.Drawing.Size(61, 20);
            this.txtPartitionOnParameter.TabIndex = 9;
            this.txtPartitionOnParameter.Text = "2014-12-05 17:49:39.670";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(16, 72);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(62, 13);
            this.label70.TabIndex = 8;
            this.label70.Text = "Partition On";
            // 
            // txtParameterValue
            // 
            this.txtParameterValue.Location = new System.Drawing.Point(266, 43);
            this.txtParameterValue.Name = "txtParameterValue";
            this.txtParameterValue.Size = new System.Drawing.Size(52, 20);
            this.txtParameterValue.TabIndex = 7;
            this.txtParameterValue.Text = "1";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(178, 47);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(85, 13);
            this.label69.TabIndex = 6;
            this.label69.Text = "Parameter Value";
            // 
            // txtParameterId
            // 
            this.txtParameterId.Location = new System.Drawing.Point(266, 17);
            this.txtParameterId.Name = "txtParameterId";
            this.txtParameterId.Size = new System.Drawing.Size(52, 20);
            this.txtParameterId.TabIndex = 5;
            this.txtParameterId.Text = "1";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(178, 23);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(67, 13);
            this.label68.TabIndex = 4;
            this.label68.Text = "Parameter Id";
            // 
            // txtEcolabWasherIdParameter
            // 
            this.txtEcolabWasherIdParameter.Location = new System.Drawing.Point(108, 44);
            this.txtEcolabWasherIdParameter.Name = "txtEcolabWasherIdParameter";
            this.txtEcolabWasherIdParameter.Size = new System.Drawing.Size(61, 20);
            this.txtEcolabWasherIdParameter.TabIndex = 3;
            this.txtEcolabWasherIdParameter.Text = "1";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(13, 49);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(89, 13);
            this.label67.TabIndex = 2;
            this.label67.Text = "Ecolab WasherId";
            // 
            // txtBatchIdParameter
            // 
            this.txtBatchIdParameter.Location = new System.Drawing.Point(108, 20);
            this.txtBatchIdParameter.Name = "txtBatchIdParameter";
            this.txtBatchIdParameter.Size = new System.Drawing.Size(61, 20);
            this.txtBatchIdParameter.TabIndex = 1;
            this.txtBatchIdParameter.Text = "1";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(13, 21);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(47, 13);
            this.label66.TabIndex = 0;
            this.label66.Text = "Batch Id";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.lblEnergyUsageStatus);
            this.groupBox6.Controls.Add(this.btnAddEnergyUsage);
            this.groupBox6.Controls.Add(this.txtPartitionOnEnergyUsage);
            this.groupBox6.Controls.Add(this.label65);
            this.groupBox6.Controls.Add(this.txtEcolabWasherIdEnergyUsage);
            this.groupBox6.Controls.Add(this.label64);
            this.groupBox6.Controls.Add(this.txtPriceEnergyUsage);
            this.groupBox6.Controls.Add(this.label63);
            this.groupBox6.Controls.Add(this.txtStandardQuantityEnergyUsage);
            this.groupBox6.Controls.Add(this.label62);
            this.groupBox6.Controls.Add(this.txtActualQuantityEnergyUsage);
            this.groupBox6.Controls.Add(this.label61);
            this.groupBox6.Controls.Add(this.txtGasOilTypeIdEnergyUsage);
            this.groupBox6.Controls.Add(this.label60);
            this.groupBox6.Controls.Add(this.txtStepCompartmentEnergyUsage);
            this.groupBox6.Controls.Add(this.label59);
            this.groupBox6.Controls.Add(this.txtBatchIdEnergyUsageData);
            this.groupBox6.Controls.Add(this.label58);
            this.groupBox6.Location = new System.Drawing.Point(756, 247);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(380, 175);
            this.groupBox6.TabIndex = 134;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Batch Step Energy Usage Data";
            // 
            // lblEnergyUsageStatus
            // 
            this.lblEnergyUsageStatus.AutoSize = true;
            this.lblEnergyUsageStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblEnergyUsageStatus.Location = new System.Drawing.Point(13, 140);
            this.lblEnergyUsageStatus.Name = "lblEnergyUsageStatus";
            this.lblEnergyUsageStatus.Size = new System.Drawing.Size(180, 13);
            this.lblEnergyUsageStatus.TabIndex = 17;
            this.lblEnergyUsageStatus.Text = "Batch Energy Usage Data Count = 0";
            // 
            // btnAddEnergyUsage
            // 
            this.btnAddEnergyUsage.Location = new System.Drawing.Point(267, 131);
            this.btnAddEnergyUsage.Name = "btnAddEnergyUsage";
            this.btnAddEnergyUsage.Size = new System.Drawing.Size(107, 23);
            this.btnAddEnergyUsage.TabIndex = 16;
            this.btnAddEnergyUsage.Text = "Add Energy Usage";
            this.btnAddEnergyUsage.UseVisualStyleBackColor = true;
            this.btnAddEnergyUsage.Click += new System.EventHandler(this.btnAddEnergyUsage_Click);
            // 
            // txtPartitionOnEnergyUsage
            // 
            this.txtPartitionOnEnergyUsage.Location = new System.Drawing.Point(98, 99);
            this.txtPartitionOnEnergyUsage.Name = "txtPartitionOnEnergyUsage";
            this.txtPartitionOnEnergyUsage.Size = new System.Drawing.Size(44, 20);
            this.txtPartitionOnEnergyUsage.TabIndex = 15;
            this.txtPartitionOnEnergyUsage.Text = "2014-12-05 17:49:39.670";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(13, 106);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(62, 13);
            this.label65.TabIndex = 14;
            this.label65.Text = "Partition On";
            // 
            // txtEcolabWasherIdEnergyUsage
            // 
            this.txtEcolabWasherIdEnergyUsage.Location = new System.Drawing.Point(252, 98);
            this.txtEcolabWasherIdEnergyUsage.Name = "txtEcolabWasherIdEnergyUsage";
            this.txtEcolabWasherIdEnergyUsage.Size = new System.Drawing.Size(50, 20);
            this.txtEcolabWasherIdEnergyUsage.TabIndex = 13;
            this.txtEcolabWasherIdEnergyUsage.Text = "1";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(157, 99);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(89, 13);
            this.label64.TabIndex = 12;
            this.label64.Text = "Ecolab WasherId";
            // 
            // txtPriceEnergyUsage
            // 
            this.txtPriceEnergyUsage.Location = new System.Drawing.Point(98, 72);
            this.txtPriceEnergyUsage.Name = "txtPriceEnergyUsage";
            this.txtPriceEnergyUsage.Size = new System.Drawing.Size(44, 20);
            this.txtPriceEnergyUsage.TabIndex = 11;
            this.txtPriceEnergyUsage.Text = "1";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(10, 75);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(31, 13);
            this.label63.TabIndex = 10;
            this.label63.Text = "Price";
            // 
            // txtStandardQuantityEnergyUsage
            // 
            this.txtStandardQuantityEnergyUsage.Location = new System.Drawing.Point(252, 71);
            this.txtStandardQuantityEnergyUsage.Name = "txtStandardQuantityEnergyUsage";
            this.txtStandardQuantityEnergyUsage.Size = new System.Drawing.Size(50, 20);
            this.txtStandardQuantityEnergyUsage.TabIndex = 9;
            this.txtStandardQuantityEnergyUsage.Text = "1";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(155, 72);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(92, 13);
            this.label62.TabIndex = 8;
            this.label62.Text = "Standard Quantity";
            // 
            // txtActualQuantityEnergyUsage
            // 
            this.txtActualQuantityEnergyUsage.Location = new System.Drawing.Point(252, 43);
            this.txtActualQuantityEnergyUsage.Name = "txtActualQuantityEnergyUsage";
            this.txtActualQuantityEnergyUsage.Size = new System.Drawing.Size(50, 20);
            this.txtActualQuantityEnergyUsage.TabIndex = 7;
            this.txtActualQuantityEnergyUsage.Text = "1";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(155, 46);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(79, 13);
            this.label61.TabIndex = 6;
            this.label61.Text = "Actual Quantity";
            // 
            // txtGasOilTypeIdEnergyUsage
            // 
            this.txtGasOilTypeIdEnergyUsage.Location = new System.Drawing.Point(98, 44);
            this.txtGasOilTypeIdEnergyUsage.Name = "txtGasOilTypeIdEnergyUsage";
            this.txtGasOilTypeIdEnergyUsage.Size = new System.Drawing.Size(44, 20);
            this.txtGasOilTypeIdEnergyUsage.TabIndex = 5;
            this.txtGasOilTypeIdEnergyUsage.Text = "1";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(10, 51);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(77, 13);
            this.label60.TabIndex = 4;
            this.label60.Text = "GasOil Type Id";
            // 
            // txtStepCompartmentEnergyUsage
            // 
            this.txtStepCompartmentEnergyUsage.Location = new System.Drawing.Point(252, 19);
            this.txtStepCompartmentEnergyUsage.Name = "txtStepCompartmentEnergyUsage";
            this.txtStepCompartmentEnergyUsage.Size = new System.Drawing.Size(50, 20);
            this.txtStepCompartmentEnergyUsage.TabIndex = 3;
            this.txtStepCompartmentEnergyUsage.Text = "1";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(152, 22);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(94, 13);
            this.label59.TabIndex = 2;
            this.label59.Text = "Step Compartment";
            // 
            // txtBatchIdEnergyUsageData
            // 
            this.txtBatchIdEnergyUsageData.Location = new System.Drawing.Point(98, 19);
            this.txtBatchIdEnergyUsageData.Name = "txtBatchIdEnergyUsageData";
            this.txtBatchIdEnergyUsageData.Size = new System.Drawing.Size(44, 20);
            this.txtBatchIdEnergyUsageData.TabIndex = 1;
            this.txtBatchIdEnergyUsageData.Text = "1";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(7, 20);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(47, 13);
            this.label58.TabIndex = 0;
            this.label58.Text = "Batch Id";
            // 
            // txtETechlastDroppedTimeStamp
            // 
            this.txtETechlastDroppedTimeStamp.Location = new System.Drawing.Point(937, 221);
            this.txtETechlastDroppedTimeStamp.Name = "txtETechlastDroppedTimeStamp";
            this.txtETechlastDroppedTimeStamp.Size = new System.Drawing.Size(137, 20);
            this.txtETechlastDroppedTimeStamp.TabIndex = 133;
            this.txtETechlastDroppedTimeStamp.Text = "2014-12-05 17:49:39.800";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(779, 221);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(158, 13);
            this.label53.TabIndex = 132;
            this.label53.Text = "ETech last Dropped TimeStamp";
            // 
            // txtStdWashSteps
            // 
            this.txtStdWashSteps.Location = new System.Drawing.Point(937, 191);
            this.txtStdWashSteps.Name = "txtStdWashSteps";
            this.txtStdWashSteps.Size = new System.Drawing.Size(137, 20);
            this.txtStdWashSteps.TabIndex = 131;
            this.txtStdWashSteps.Text = "1";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(779, 192);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(84, 13);
            this.label52.TabIndex = 130;
            this.label52.Text = "Std Wash Steps";
            // 
            // txtStdInjectionSteps
            // 
            this.txtStdInjectionSteps.Location = new System.Drawing.Point(937, 153);
            this.txtStdInjectionSteps.Name = "txtStdInjectionSteps";
            this.txtStdInjectionSteps.Size = new System.Drawing.Size(137, 20);
            this.txtStdInjectionSteps.TabIndex = 129;
            this.txtStdInjectionSteps.Text = "1";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(776, 160);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(96, 13);
            this.label51.TabIndex = 128;
            this.label51.Text = "Std Injection Steps";
            // 
            // txtSyncReady
            // 
            this.txtSyncReady.Location = new System.Drawing.Point(937, 126);
            this.txtSyncReady.Name = "txtSyncReady";
            this.txtSyncReady.Size = new System.Drawing.Size(137, 20);
            this.txtSyncReady.TabIndex = 127;
            this.txtSyncReady.Text = "True";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(776, 129);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(65, 13);
            this.label50.TabIndex = 126;
            this.label50.Text = "Sync Ready";
            // 
            // txtPlantProgramId
            // 
            this.txtPlantProgramId.Location = new System.Drawing.Point(937, 100);
            this.txtPlantProgramId.Name = "txtPlantProgramId";
            this.txtPlantProgramId.Size = new System.Drawing.Size(137, 20);
            this.txtPlantProgramId.TabIndex = 125;
            this.txtPlantProgramId.Text = "1";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(776, 103);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(85, 13);
            this.label49.TabIndex = 124;
            this.label49.Text = "Plant Program Id";
            // 
            // txtEcolabSaturationId
            // 
            this.txtEcolabSaturationId.Location = new System.Drawing.Point(937, 76);
            this.txtEcolabSaturationId.Name = "txtEcolabSaturationId";
            this.txtEcolabSaturationId.Size = new System.Drawing.Size(137, 20);
            this.txtEcolabSaturationId.TabIndex = 123;
            this.txtEcolabSaturationId.Text = "1";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(776, 76);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(103, 13);
            this.label48.TabIndex = 122;
            this.label48.Text = "Ecolab Saturation Id";
            // 
            // txtFormulaSegmentId
            // 
            this.txtFormulaSegmentId.Location = new System.Drawing.Point(937, 44);
            this.txtFormulaSegmentId.Name = "txtFormulaSegmentId";
            this.txtFormulaSegmentId.Size = new System.Drawing.Size(137, 20);
            this.txtFormulaSegmentId.TabIndex = 121;
            this.txtFormulaSegmentId.Text = "1";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(776, 51);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(101, 13);
            this.label47.TabIndex = 120;
            this.label47.Text = "Formula SegmentI d";
            // 
            // txtChainTextileCategoryId
            // 
            this.txtChainTextileCategoryId.Location = new System.Drawing.Point(937, 20);
            this.txtChainTextileCategoryId.Name = "txtChainTextileCategoryId";
            this.txtChainTextileCategoryId.Size = new System.Drawing.Size(137, 20);
            this.txtChainTextileCategoryId.TabIndex = 119;
            this.txtChainTextileCategoryId.Text = "1";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(773, 22);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(125, 13);
            this.label46.TabIndex = 118;
            this.label46.Text = "Chain Textile Category Id";
            // 
            // txtEcolabTextileCategoryId
            // 
            this.txtEcolabTextileCategoryId.Location = new System.Drawing.Point(599, 192);
            this.txtEcolabTextileCategoryId.Name = "txtEcolabTextileCategoryId";
            this.txtEcolabTextileCategoryId.Size = new System.Drawing.Size(126, 20);
            this.txtEcolabTextileCategoryId.TabIndex = 117;
            this.txtEcolabTextileCategoryId.Text = "1";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(466, 194);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(131, 13);
            this.label45.TabIndex = 116;
            this.label45.Text = "Ecolab Textile Category Id";
            // 
            // txtTargetTurnTime
            // 
            this.txtTargetTurnTime.Location = new System.Drawing.Point(321, 187);
            this.txtTargetTurnTime.Name = "txtTargetTurnTime";
            this.txtTargetTurnTime.Size = new System.Drawing.Size(132, 20);
            this.txtTargetTurnTime.TabIndex = 115;
            this.txtTargetTurnTime.Text = "1";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(204, 192);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(89, 13);
            this.label44.TabIndex = 114;
            this.label44.Text = "Target Turn Time";
            // 
            // txtShiftId
            // 
            this.txtShiftId.Location = new System.Drawing.Point(132, 186);
            this.txtShiftId.Name = "txtShiftId";
            this.txtShiftId.Size = new System.Drawing.Size(52, 20);
            this.txtShiftId.TabIndex = 113;
            this.txtShiftId.Text = "1";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(26, 186);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(40, 13);
            this.label43.TabIndex = 112;
            this.label43.Text = "Shift Id";
            // 
            // BtnGenearateXML
            // 
            this.BtnGenearateXML.Location = new System.Drawing.Point(439, 612);
            this.BtnGenearateXML.Name = "BtnGenearateXML";
            this.BtnGenearateXML.Size = new System.Drawing.Size(158, 48);
            this.BtnGenearateXML.TabIndex = 111;
            this.BtnGenearateXML.Text = "Generate XML";
            this.BtnGenearateXML.UseVisualStyleBackColor = true;
            this.BtnGenearateXML.Click += new System.EventHandler(this.BtnGenearateXML_Click);
            // 
            // TxtMachineId
            // 
            this.TxtMachineId.Location = new System.Drawing.Point(599, 161);
            this.TxtMachineId.Name = "TxtMachineId";
            this.TxtMachineId.Size = new System.Drawing.Size(126, 20);
            this.TxtMachineId.TabIndex = 110;
            this.TxtMachineId.Text = "1";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(466, 167);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(60, 13);
            this.label42.TabIndex = 109;
            this.label42.Text = "Machine Id";
            // 
            // txtProgramMasterId
            // 
            this.txtProgramMasterId.Location = new System.Drawing.Point(321, 161);
            this.txtProgramMasterId.Name = "txtProgramMasterId";
            this.txtProgramMasterId.Size = new System.Drawing.Size(134, 20);
            this.txtProgramMasterId.TabIndex = 108;
            this.txtProgramMasterId.Text = "1";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(201, 167);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(90, 13);
            this.label36.TabIndex = 107;
            this.label36.Text = "Program MasterId";
            // 
            // txtEndDateFormula
            // 
            this.txtEndDateFormula.Location = new System.Drawing.Point(131, 160);
            this.txtEndDateFormula.Name = "txtEndDateFormula";
            this.txtEndDateFormula.Size = new System.Drawing.Size(52, 20);
            this.txtEndDateFormula.TabIndex = 106;
            this.txtEndDateFormula.Text = "2014-12-05 17:49:39.670";
            // 
            // txtBatchStatus
            // 
            this.txtBatchStatus.Location = new System.Drawing.Point(599, 132);
            this.txtBatchStatus.Name = "txtBatchStatus";
            this.txtBatchStatus.Size = new System.Drawing.Size(126, 20);
            this.txtBatchStatus.TabIndex = 105;
            this.txtBatchStatus.Text = "1";
            // 
            // txtHoldTime
            // 
            this.txtHoldTime.Location = new System.Drawing.Point(323, 132);
            this.txtHoldTime.Name = "txtHoldTime";
            this.txtHoldTime.Size = new System.Drawing.Size(132, 20);
            this.txtHoldTime.TabIndex = 104;
            this.txtHoldTime.Text = "10";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(23, 161);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(92, 13);
            this.label33.TabIndex = 102;
            this.label33.Text = "End Date Formula";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(466, 136);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(68, 13);
            this.label31.TabIndex = 101;
            this.label31.Text = "Batch Status";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(204, 129);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 13);
            this.label30.TabIndex = 100;
            this.label30.Text = "Hold Time";
            // 
            // txtManualWeight
            // 
            this.txtManualWeight.Location = new System.Drawing.Point(131, 129);
            this.txtManualWeight.Name = "txtManualWeight";
            this.txtManualWeight.Size = new System.Drawing.Size(52, 20);
            this.txtManualWeight.TabIndex = 99;
            this.txtManualWeight.Text = "20";
            // 
            // lblManualWeight
            // 
            this.lblManualWeight.AutoSize = true;
            this.lblManualWeight.Location = new System.Drawing.Point(20, 129);
            this.lblManualWeight.Name = "lblManualWeight";
            this.lblManualWeight.Size = new System.Drawing.Size(106, 13);
            this.lblManualWeight.TabIndex = 98;
            this.lblManualWeight.Text = "Manual Input Weight";
            // 
            // lblBatchDataCount
            // 
            this.lblBatchDataCount.AutoSize = true;
            this.lblBatchDataCount.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblBatchDataCount.Location = new System.Drawing.Point(463, 585);
            this.lblBatchDataCount.Name = "lblBatchDataCount";
            this.lblBatchDataCount.Size = new System.Drawing.Size(110, 13);
            this.lblBatchDataCount.TabIndex = 97;
            this.lblBatchDataCount.Text = "Batch Data Count = 0";
            // 
            // btnSendBatchDataToTcp
            // 
            this.btnSendBatchDataToTcp.Location = new System.Drawing.Point(593, 552);
            this.btnSendBatchDataToTcp.Name = "btnSendBatchDataToTcp";
            this.btnSendBatchDataToTcp.Size = new System.Drawing.Size(139, 39);
            this.btnSendBatchDataToTcp.TabIndex = 96;
            this.btnSendBatchDataToTcp.Text = "Send Batch Data to TCP";
            this.btnSendBatchDataToTcp.UseVisualStyleBackColor = true;
            this.btnSendBatchDataToTcp.Click += new System.EventHandler(this.btnSendBatchDataToTcp_Click);
            // 
            // btnAddBatchData
            // 
            this.btnAddBatchData.Location = new System.Drawing.Point(305, 552);
            this.btnAddBatchData.Name = "btnAddBatchData";
            this.btnAddBatchData.Size = new System.Drawing.Size(136, 40);
            this.btnAddBatchData.TabIndex = 95;
            this.btnAddBatchData.Text = "Add Batch Data";
            this.btnAddBatchData.UseVisualStyleBackColor = true;
            this.btnAddBatchData.Click += new System.EventHandler(this.btnAddBatchData_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblWashStepStatus);
            this.groupBox4.Controls.Add(this.btnAddWashStep);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.txtBatchIdWS);
            this.groupBox4.Controls.Add(this.txtStepCompartment);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.txtStartTime);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.txtEndTime);
            this.groupBox4.Location = new System.Drawing.Point(272, 422);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(460, 119);
            this.groupBox4.TabIndex = 93;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Batch Wash Step Data";
            // 
            // lblWashStepStatus
            // 
            this.lblWashStepStatus.AutoSize = true;
            this.lblWashStepStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblWashStepStatus.Location = new System.Drawing.Point(12, 94);
            this.lblWashStepStatus.Name = "lblWashStepStatus";
            this.lblWashStepStatus.Size = new System.Drawing.Size(166, 13);
            this.lblWashStepStatus.TabIndex = 83;
            this.lblWashStepStatus.Text = "Batch Wash Step Data Count = 0";
            // 
            // btnAddWashStep
            // 
            this.btnAddWashStep.Location = new System.Drawing.Point(239, 86);
            this.btnAddWashStep.Name = "btnAddWashStep";
            this.btnAddWashStep.Size = new System.Drawing.Size(180, 23);
            this.btnAddWashStep.TabIndex = 37;
            this.btnAddWashStep.Text = "Add Wash Step";
            this.btnAddWashStep.UseVisualStyleBackColor = true;
            this.btnAddWashStep.Click += new System.EventHandler(this.btnAddWashStep_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(12, 59);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(94, 13);
            this.label32.TabIndex = 57;
            this.label32.Text = "Step Compartment";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(12, 27);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(47, 13);
            this.label34.TabIndex = 53;
            this.label34.Text = "Batch Id";
            // 
            // txtBatchIdWS
            // 
            this.txtBatchIdWS.Location = new System.Drawing.Point(125, 21);
            this.txtBatchIdWS.Name = "txtBatchIdWS";
            this.txtBatchIdWS.Size = new System.Drawing.Size(36, 20);
            this.txtBatchIdWS.TabIndex = 33;
            this.txtBatchIdWS.Text = "1";
            // 
            // txtStepCompartment
            // 
            this.txtStepCompartment.Location = new System.Drawing.Point(125, 56);
            this.txtStepCompartment.Name = "txtStepCompartment";
            this.txtStepCompartment.Size = new System.Drawing.Size(36, 20);
            this.txtStepCompartment.TabIndex = 35;
            this.txtStepCompartment.Text = "1";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(230, 23);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(55, 13);
            this.label35.TabIndex = 63;
            this.label35.Text = "Start Time";
            // 
            // txtStartTime
            // 
            this.txtStartTime.Location = new System.Drawing.Point(292, 23);
            this.txtStartTime.Name = "txtStartTime";
            this.txtStartTime.Size = new System.Drawing.Size(126, 20);
            this.txtStartTime.TabIndex = 34;
            this.txtStartTime.Text = "2014-12-05 17:49:39.670";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(233, 55);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(52, 13);
            this.label29.TabIndex = 65;
            this.label29.Text = "End Time";
            // 
            // txtEndTime
            // 
            this.txtEndTime.Location = new System.Drawing.Point(292, 55);
            this.txtEndTime.Name = "txtEndTime";
            this.txtEndTime.Size = new System.Drawing.Size(126, 20);
            this.txtEndTime.TabIndex = 36;
            this.txtEndTime.Text = "2014-12-05 17:50:39.700";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblWaterUsageStatus);
            this.groupBox5.Controls.Add(this.btnAddWaterUsages);
            this.groupBox5.Controls.Add(this.txtStepCompartmentSWU);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.txtbatchIdWU);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.txtWaterTypeId);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.txtPriceWU);
            this.groupBox5.Controls.Add(this.txtActualQuantityWU);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.txtStdQuantityWU);
            this.groupBox5.Location = new System.Drawing.Point(11, 422);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(255, 238);
            this.groupBox5.TabIndex = 94;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Batch Step Water usage data";
            // 
            // lblWaterUsageStatus
            // 
            this.lblWaterUsageStatus.AutoSize = true;
            this.lblWaterUsageStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblWaterUsageStatus.Location = new System.Drawing.Point(9, 186);
            this.lblWaterUsageStatus.Name = "lblWaterUsageStatus";
            this.lblWaterUsageStatus.Size = new System.Drawing.Size(196, 13);
            this.lblWaterUsageStatus.TabIndex = 82;
            this.lblWaterUsageStatus.Text = "Batch Step Water usage data count = 0";
            // 
            // btnAddWaterUsages
            // 
            this.btnAddWaterUsages.Location = new System.Drawing.Point(9, 211);
            this.btnAddWaterUsages.Name = "btnAddWaterUsages";
            this.btnAddWaterUsages.Size = new System.Drawing.Size(149, 23);
            this.btnAddWaterUsages.TabIndex = 32;
            this.btnAddWaterUsages.Text = "Add Water usages";
            this.btnAddWaterUsages.UseVisualStyleBackColor = true;
            this.btnAddWaterUsages.Click += new System.EventHandler(this.btnAddWaterUsages_Click);
            // 
            // txtStepCompartmentSWU
            // 
            this.txtStepCompartmentSWU.Location = new System.Drawing.Point(125, 156);
            this.txtStepCompartmentSWU.Name = "txtStepCompartmentSWU";
            this.txtStepCompartmentSWU.Size = new System.Drawing.Size(36, 20);
            this.txtStepCompartmentSWU.TabIndex = 31;
            this.txtStepCompartmentSWU.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 156);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 13);
            this.label16.TabIndex = 79;
            this.label16.Text = "StepCompartment";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(7, 26);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(47, 13);
            this.label37.TabIndex = 69;
            this.label37.Text = "Batch Id";
            // 
            // txtbatchIdWU
            // 
            this.txtbatchIdWU.Location = new System.Drawing.Point(125, 23);
            this.txtbatchIdWU.Name = "txtbatchIdWU";
            this.txtbatchIdWU.Size = new System.Drawing.Size(36, 20);
            this.txtbatchIdWU.TabIndex = 26;
            this.txtbatchIdWU.Text = "1";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(7, 50);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(75, 13);
            this.label38.TabIndex = 71;
            this.label38.Text = "Water Type Id";
            // 
            // txtWaterTypeId
            // 
            this.txtWaterTypeId.Location = new System.Drawing.Point(125, 50);
            this.txtWaterTypeId.Name = "txtWaterTypeId";
            this.txtWaterTypeId.Size = new System.Drawing.Size(36, 20);
            this.txtWaterTypeId.TabIndex = 27;
            this.txtWaterTypeId.Text = "1";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(7, 78);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(79, 13);
            this.label41.TabIndex = 73;
            this.label41.Text = "Actual Quantity";
            // 
            // txtPriceWU
            // 
            this.txtPriceWU.Location = new System.Drawing.Point(125, 130);
            this.txtPriceWU.Name = "txtPriceWU";
            this.txtPriceWU.Size = new System.Drawing.Size(36, 20);
            this.txtPriceWU.TabIndex = 30;
            this.txtPriceWU.Text = "10";
            // 
            // txtActualQuantityWU
            // 
            this.txtActualQuantityWU.Location = new System.Drawing.Point(125, 78);
            this.txtActualQuantityWU.Name = "txtActualQuantityWU";
            this.txtActualQuantityWU.Size = new System.Drawing.Size(36, 20);
            this.txtActualQuantityWU.TabIndex = 28;
            this.txtActualQuantityWU.Text = "2";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(7, 129);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(31, 13);
            this.label39.TabIndex = 77;
            this.label39.Text = "Price";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(7, 106);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(92, 13);
            this.label40.TabIndex = 75;
            this.label40.Text = "Standard Quantity";
            // 
            // txtStdQuantityWU
            // 
            this.txtStdQuantityWU.Location = new System.Drawing.Point(125, 104);
            this.txtStdQuantityWU.Name = "txtStdQuantityWU";
            this.txtStdQuantityWU.Size = new System.Drawing.Size(36, 20);
            this.txtStdQuantityWU.TabIndex = 29;
            this.txtStdQuantityWU.Text = "3";
            // 
            // txtCurrencyCode
            // 
            this.txtCurrencyCode.Location = new System.Drawing.Point(599, 103);
            this.txtCurrencyCode.Name = "txtCurrencyCode";
            this.txtCurrencyCode.Size = new System.Drawing.Size(126, 20);
            this.txtCurrencyCode.TabIndex = 30;
            this.txtCurrencyCode.Text = "USD";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(466, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "Currency Code";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtProductId);
            this.groupBox3.Controls.Add(this.label57);
            this.groupBox3.Controls.Add(this.txtPartitionOn);
            this.groupBox3.Controls.Add(this.label56);
            this.groupBox3.Controls.Add(this.txtTimestampProduct);
            this.groupBox3.Controls.Add(this.label55);
            this.groupBox3.Controls.Add(this.txtEcolabWasherIdProduct);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.txtStatus);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.lblProductStatus);
            this.groupBox3.Controls.Add(this.btnAddProduct);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.txtBatchIdProduct);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.txtStepCmprtment);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.txtActualQuantity);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.txtStandardQuantity);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.txtPrice);
            this.groupBox3.Location = new System.Drawing.Point(272, 244);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(463, 172);
            this.groupBox3.TabIndex = 92;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Batch Product Data";
            // 
            // txtProductId
            // 
            this.txtProductId.Location = new System.Drawing.Point(133, 99);
            this.txtProductId.Name = "txtProductId";
            this.txtProductId.Size = new System.Drawing.Size(36, 20);
            this.txtProductId.TabIndex = 62;
            this.txtProductId.Text = "1";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(6, 100);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(56, 13);
            this.label57.TabIndex = 61;
            this.label57.Text = "Product Id";
            // 
            // txtPartitionOn
            // 
            this.txtPartitionOn.Location = new System.Drawing.Point(408, 75);
            this.txtPartitionOn.Name = "txtPartitionOn";
            this.txtPartitionOn.Size = new System.Drawing.Size(39, 20);
            this.txtPartitionOn.TabIndex = 60;
            this.txtPartitionOn.Text = "2014-12-05 49:39:800";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(327, 75);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(62, 13);
            this.label56.TabIndex = 59;
            this.label56.Text = "Partition On";
            // 
            // txtTimestampProduct
            // 
            this.txtTimestampProduct.Location = new System.Drawing.Point(282, 75);
            this.txtTimestampProduct.Name = "txtTimestampProduct";
            this.txtTimestampProduct.Size = new System.Drawing.Size(36, 20);
            this.txtTimestampProduct.TabIndex = 58;
            this.txtTimestampProduct.Text = "2014-12-05 17:49:39.800";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(176, 75);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(63, 13);
            this.label55.TabIndex = 57;
            this.label55.Text = "Time Stamp";
            // 
            // txtEcolabWasherIdProduct
            // 
            this.txtEcolabWasherIdProduct.Location = new System.Drawing.Point(133, 72);
            this.txtEcolabWasherIdProduct.Name = "txtEcolabWasherIdProduct";
            this.txtEcolabWasherIdProduct.Size = new System.Drawing.Size(36, 20);
            this.txtEcolabWasherIdProduct.TabIndex = 56;
            this.txtEcolabWasherIdProduct.Text = "1";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 75);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(89, 13);
            this.label54.TabIndex = 55;
            this.label54.Text = "Ecolab WasherId";
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(408, 48);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(36, 20);
            this.txtStatus.TabIndex = 54;
            this.txtStatus.Text = "True";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(324, 49);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(37, 13);
            this.label24.TabIndex = 53;
            this.label24.Text = "Status";
            // 
            // lblProductStatus
            // 
            this.lblProductStatus.AutoSize = true;
            this.lblProductStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblProductStatus.Location = new System.Drawing.Point(12, 134);
            this.lblProductStatus.Name = "lblProductStatus";
            this.lblProductStatus.Size = new System.Drawing.Size(150, 13);
            this.lblProductStatus.TabIndex = 52;
            this.lblProductStatus.Text = "Batch Product Data Count = 0";
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Location = new System.Drawing.Point(330, 124);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(117, 23);
            this.btnAddProduct.TabIndex = 25;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 13);
            this.label22.TabIndex = 40;
            this.label22.Text = "Batch Id";
            // 
            // txtBatchIdProduct
            // 
            this.txtBatchIdProduct.Location = new System.Drawing.Point(133, 22);
            this.txtBatchIdProduct.Name = "txtBatchIdProduct";
            this.txtBatchIdProduct.Size = new System.Drawing.Size(36, 20);
            this.txtBatchIdProduct.TabIndex = 19;
            this.txtBatchIdProduct.Text = "1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(5, 49);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 13);
            this.label23.TabIndex = 42;
            this.label23.Text = "Step Compartment";
            // 
            // txtStepCmprtment
            // 
            this.txtStepCmprtment.Location = new System.Drawing.Point(133, 45);
            this.txtStepCmprtment.Name = "txtStepCmprtment";
            this.txtStepCmprtment.Size = new System.Drawing.Size(36, 20);
            this.txtStepCmprtment.TabIndex = 22;
            this.txtStepCmprtment.Text = "1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(175, 22);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(79, 13);
            this.label25.TabIndex = 46;
            this.label25.Text = "Actual Quantity";
            // 
            // txtActualQuantity
            // 
            this.txtActualQuantity.Location = new System.Drawing.Point(282, 22);
            this.txtActualQuantity.Name = "txtActualQuantity";
            this.txtActualQuantity.Size = new System.Drawing.Size(36, 20);
            this.txtActualQuantity.TabIndex = 20;
            this.txtActualQuantity.Text = "2";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(175, 48);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(92, 13);
            this.label26.TabIndex = 48;
            this.label26.Text = "Standard Quantity";
            // 
            // txtStandardQuantity
            // 
            this.txtStandardQuantity.Location = new System.Drawing.Point(282, 45);
            this.txtStandardQuantity.Name = "txtStandardQuantity";
            this.txtStandardQuantity.Size = new System.Drawing.Size(36, 20);
            this.txtStandardQuantity.TabIndex = 23;
            this.txtStandardQuantity.Text = "3";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(324, 25);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(31, 13);
            this.label27.TabIndex = 50;
            this.label27.Text = "Price";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(411, 18);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(36, 20);
            this.txtPrice.TabIndex = 21;
            this.txtPrice.Text = "10";
            // 
            // txtPlantWasherNumber
            // 
            this.txtPlantWasherNumber.Location = new System.Drawing.Point(323, 102);
            this.txtPlantWasherNumber.Name = "txtPlantWasherNumber";
            this.txtPlantWasherNumber.Size = new System.Drawing.Size(132, 20);
            this.txtPlantWasherNumber.TabIndex = 28;
            this.txtPlantWasherNumber.Text = "6";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblBatchCustomerStatus);
            this.groupBox2.Controls.Add(this.btnAddCustomer);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.txtCustomerId);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtLoad);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtPiecesCount);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.txtBatchIdCustomer);
            this.groupBox2.Location = new System.Drawing.Point(11, 235);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 181);
            this.groupBox2.TabIndex = 91;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Batch Customer Data";
            // 
            // lblBatchCustomerStatus
            // 
            this.lblBatchCustomerStatus.AutoSize = true;
            this.lblBatchCustomerStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblBatchCustomerStatus.Location = new System.Drawing.Point(15, 118);
            this.lblBatchCustomerStatus.Name = "lblBatchCustomerStatus";
            this.lblBatchCustomerStatus.Size = new System.Drawing.Size(157, 13);
            this.lblBatchCustomerStatus.TabIndex = 39;
            this.lblBatchCustomerStatus.Text = "Batch Customer Data Count = 0";
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(65, 133);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(117, 23);
            this.btnAddCustomer.TabIndex = 18;
            this.btnAddCustomer.Text = "Add Customer";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(63, 13);
            this.label19.TabIndex = 31;
            this.label19.Text = "Customer Id";
            // 
            // txtCustomerId
            // 
            this.txtCustomerId.Location = new System.Drawing.Point(121, 47);
            this.txtCustomerId.Name = "txtCustomerId";
            this.txtCustomerId.Size = new System.Drawing.Size(36, 20);
            this.txtCustomerId.TabIndex = 15;
            this.txtCustomerId.Text = "1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 13);
            this.label18.TabIndex = 33;
            this.label18.Text = "Weight_lbs";
            // 
            // txtLoad
            // 
            this.txtLoad.Location = new System.Drawing.Point(121, 70);
            this.txtLoad.Name = "txtLoad";
            this.txtLoad.Size = new System.Drawing.Size(36, 20);
            this.txtLoad.TabIndex = 16;
            this.txtLoad.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 13);
            this.label17.TabIndex = 35;
            this.label17.Text = "Pieces Count";
            // 
            // txtPiecesCount
            // 
            this.txtPiecesCount.Location = new System.Drawing.Point(121, 93);
            this.txtPiecesCount.Name = "txtPiecesCount";
            this.txtPiecesCount.Size = new System.Drawing.Size(36, 20);
            this.txtPiecesCount.TabIndex = 17;
            this.txtPiecesCount.Text = "27";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 23);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 13);
            this.label20.TabIndex = 37;
            this.label20.Text = "Batch Id";
            // 
            // txtBatchIdCustomer
            // 
            this.txtBatchIdCustomer.Location = new System.Drawing.Point(121, 23);
            this.txtBatchIdCustomer.Name = "txtBatchIdCustomer";
            this.txtBatchIdCustomer.Size = new System.Drawing.Size(36, 20);
            this.txtBatchIdCustomer.TabIndex = 14;
            this.txtBatchIdCustomer.Text = "1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(201, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Plant Washer Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(201, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Machine Internal Id";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Batch Id";
            // 
            // txtBatchId
            // 
            this.txtBatchId.Location = new System.Drawing.Point(131, 27);
            this.txtBatchId.Name = "txtBatchId";
            this.txtBatchId.Size = new System.Drawing.Size(52, 20);
            this.txtBatchId.TabIndex = 3;
            this.txtBatchId.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Controller Batch Id";
            // 
            // txtControllerBatchId
            // 
            this.txtControllerBatchId.Location = new System.Drawing.Point(131, 52);
            this.txtControllerBatchId.Name = "txtControllerBatchId";
            this.txtControllerBatchId.Size = new System.Drawing.Size(52, 20);
            this.txtControllerBatchId.TabIndex = 6;
            this.txtControllerBatchId.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "EcolabWasherId";
            // 
            // txtEcolabWasherId
            // 
            this.txtEcolabWasherId.Location = new System.Drawing.Point(131, 76);
            this.txtEcolabWasherId.Name = "txtEcolabWasherId";
            this.txtEcolabWasherId.Size = new System.Drawing.Size(52, 20);
            this.txtEcolabWasherId.TabIndex = 9;
            this.txtEcolabWasherId.Text = "1001";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(201, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Group Id";
            // 
            // txtGroupId
            // 
            this.txtGroupId.Location = new System.Drawing.Point(323, 27);
            this.txtGroupId.Name = "txtGroupId";
            this.txtGroupId.Size = new System.Drawing.Size(134, 20);
            this.txtGroupId.TabIndex = 4;
            this.txtGroupId.Text = "17";
            // 
            // txtMachineInternalId
            // 
            this.txtMachineInternalId.Location = new System.Drawing.Point(323, 52);
            this.txtMachineInternalId.Name = "txtMachineInternalId";
            this.txtMachineInternalId.Size = new System.Drawing.Size(134, 20);
            this.txtMachineInternalId.TabIndex = 7;
            this.txtMachineInternalId.Text = "1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(463, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "Start Date";
            // 
            // txtStartDate
            // 
            this.txtStartDate.Location = new System.Drawing.Point(599, 19);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(126, 20);
            this.txtStartDate.TabIndex = 5;
            this.txtStartDate.Text = "2014-12-05 17:49:39.670";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(466, 52);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "End Date";
            // 
            // txtEndDate
            // 
            this.txtEndDate.Location = new System.Drawing.Point(599, 45);
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(126, 20);
            this.txtEndDate.TabIndex = 8;
            this.txtEndDate.Text = "2014-12-05 17:50:39.700";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(201, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "Program Number";
            // 
            // txtProgramNumber
            // 
            this.txtProgramNumber.Location = new System.Drawing.Point(323, 76);
            this.txtProgramNumber.Name = "txtProgramNumber";
            this.txtProgramNumber.Size = new System.Drawing.Size(134, 20);
            this.txtProgramNumber.TabIndex = 10;
            this.txtProgramNumber.Text = "1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(466, 76);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "Actual Weight";
            // 
            // txtActualWeight
            // 
            this.txtActualWeight.Location = new System.Drawing.Point(599, 73);
            this.txtActualWeight.Name = "txtActualWeight";
            this.txtActualWeight.Size = new System.Drawing.Size(126, 20);
            this.txtActualWeight.TabIndex = 11;
            this.txtActualWeight.Text = "149";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 102);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 13);
            this.label14.TabIndex = 24;
            this.label14.Text = "Standard Weight";
            // 
            // txtStandardWeight
            // 
            this.txtStandardWeight.Location = new System.Drawing.Point(131, 102);
            this.txtStandardWeight.Name = "txtStandardWeight";
            this.txtStandardWeight.Size = new System.Drawing.Size(52, 20);
            this.txtStandardWeight.TabIndex = 12;
            this.txtStandardWeight.Text = "150";
            // 
            // txtPortNumber
            // 
            this.txtPortNumber.Location = new System.Drawing.Point(311, 9);
            this.txtPortNumber.Name = "txtPortNumber";
            this.txtPortNumber.Size = new System.Drawing.Size(100, 20);
            this.txtPortNumber.TabIndex = 87;
            this.txtPortNumber.Text = "9340";
            // 
            // txtIpAddress
            // 
            this.txtIpAddress.Location = new System.Drawing.Point(107, 9);
            this.txtIpAddress.Name = "txtIpAddress";
            this.txtIpAddress.Size = new System.Drawing.Size(100, 20);
            this.txtIpAddress.TabIndex = 85;
            this.txtIpAddress.Text = "localhost";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(220, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 88;
            this.label3.Text = "Port Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 86;
            this.label2.Text = "IP Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 84;
            // 
            // tabBatchDataByXml
            // 
            this.tabBatchDataByXml.BackColor = System.Drawing.Color.Silver;
            this.tabBatchDataByXml.Controls.Add(this.txtPortNumberBatchXml);
            this.tabBatchDataByXml.Controls.Add(this.txtIpAddressBatchXml);
            this.tabBatchDataByXml.Controls.Add(this.label21);
            this.tabBatchDataByXml.Controls.Add(this.label28);
            this.tabBatchDataByXml.Controls.Add(this.btnSendToTcp);
            this.tabBatchDataByXml.Controls.Add(this.txtSelectedFile);
            this.tabBatchDataByXml.Controls.Add(this.btnSelectFile);
            this.tabBatchDataByXml.Location = new System.Drawing.Point(4, 22);
            this.tabBatchDataByXml.Name = "tabBatchDataByXml";
            this.tabBatchDataByXml.Padding = new System.Windows.Forms.Padding(3);
            this.tabBatchDataByXml.Size = new System.Drawing.Size(1169, 724);
            this.tabBatchDataByXml.TabIndex = 1;
            this.tabBatchDataByXml.Text = "Batch Data ( Xml File )";
            // 
            // txtPortNumberBatchXml
            // 
            this.txtPortNumberBatchXml.Location = new System.Drawing.Point(238, 81);
            this.txtPortNumberBatchXml.Name = "txtPortNumberBatchXml";
            this.txtPortNumberBatchXml.Size = new System.Drawing.Size(100, 20);
            this.txtPortNumberBatchXml.TabIndex = 91;
            this.txtPortNumberBatchXml.Text = "9340";
            // 
            // txtIpAddressBatchXml
            // 
            this.txtIpAddressBatchXml.Location = new System.Drawing.Point(238, 47);
            this.txtIpAddressBatchXml.Name = "txtIpAddressBatchXml";
            this.txtIpAddressBatchXml.Size = new System.Drawing.Size(100, 20);
            this.txtIpAddressBatchXml.TabIndex = 89;
            this.txtIpAddressBatchXml.Text = "localhost";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(161, 85);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 13);
            this.label21.TabIndex = 92;
            this.label21.Text = "Port Number";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(161, 48);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(58, 13);
            this.label28.TabIndex = 90;
            this.label28.Text = "IP Address";
            // 
            // btnSendToTcp
            // 
            this.btnSendToTcp.Location = new System.Drawing.Point(156, 172);
            this.btnSendToTcp.Name = "btnSendToTcp";
            this.btnSendToTcp.Size = new System.Drawing.Size(230, 23);
            this.btnSendToTcp.TabIndex = 44;
            this.btnSendToTcp.Text = "Send to TCP";
            this.btnSendToTcp.UseVisualStyleBackColor = true;
            this.btnSendToTcp.Click += new System.EventHandler(this.btnSendToTcp_Click);
            // 
            // txtSelectedFile
            // 
            this.txtSelectedFile.Location = new System.Drawing.Point(156, 145);
            this.txtSelectedFile.Name = "txtSelectedFile";
            this.txtSelectedFile.ReadOnly = true;
            this.txtSelectedFile.Size = new System.Drawing.Size(230, 20);
            this.txtSelectedFile.TabIndex = 43;
            // 
            // btnSelectFile
            // 
            this.btnSelectFile.Location = new System.Drawing.Point(156, 116);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Size = new System.Drawing.Size(230, 23);
            this.btnSelectFile.TabIndex = 42;
            this.btnSelectFile.Text = "Select File";
            this.btnSelectFile.UseVisualStyleBackColor = true;
            this.btnSelectFile.Click += new System.EventHandler(this.btnSelectFile_Click);
            // 
            // BatchDataSyncForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 750);
            this.Controls.Add(this.tabBatchSync);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "BatchDataSyncForm";
            this.Text = "Batch Data Sync";
            this.tabBatchSync.ResumeLayout(false);
            this.tabBatchData.ResumeLayout(false);
            this.tabBatchData.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabBatchDataByXml.ResumeLayout(false);
            this.tabBatchDataByXml.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog xmlFileDialog;
        private System.Windows.Forms.TabControl tabBatchSync;
        private System.Windows.Forms.TabPage tabBatchData;
        private System.Windows.Forms.TabPage tabBatchDataByXml;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblWaterUsageStatus;
        private System.Windows.Forms.Button btnAddWaterUsages;
        private System.Windows.Forms.TextBox txtStepCompartmentSWU;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtbatchIdWU;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtWaterTypeId;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtPriceWU;
        private System.Windows.Forms.TextBox txtActualQuantityWU;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtStdQuantityWU;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblWashStepStatus;
        private System.Windows.Forms.Button btnAddWashStep;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtBatchIdWS;
        private System.Windows.Forms.TextBox txtStepCompartment;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtStartTime;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtEndTime;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblProductStatus;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtBatchIdProduct;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtStepCmprtment;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtActualQuantity;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtStandardQuantity;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblBatchCustomerStatus;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtCustomerId;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtLoad;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtPiecesCount;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtBatchIdCustomer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCurrencyCode;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtPlantWasherNumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBatchId;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtControllerBatchId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEcolabWasherId;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGroupId;
        private System.Windows.Forms.TextBox txtMachineInternalId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtStartDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtEndDate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProgramNumber;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtActualWeight;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtStandardWeight;
        private System.Windows.Forms.TextBox txtPortNumber;
        private System.Windows.Forms.TextBox txtIpAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSendToTcp;
        private System.Windows.Forms.TextBox txtSelectedFile;
        private System.Windows.Forms.Button btnSelectFile;
        private System.Windows.Forms.Button btnSendBatchDataToTcp;
        private System.Windows.Forms.Button btnAddBatchData;
        private System.Windows.Forms.Label lblBatchDataCount;
        private System.Windows.Forms.TextBox txtPortNumberBatchXml;
        private System.Windows.Forms.TextBox txtIpAddressBatchXml;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtEndDateFormula;
        private System.Windows.Forms.TextBox txtBatchStatus;
        private System.Windows.Forms.TextBox txtHoldTime;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtManualWeight;
        private System.Windows.Forms.Label lblManualWeight;
        private System.Windows.Forms.TextBox TxtMachineId;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtProgramMasterId;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button BtnGenearateXML;
        private System.Windows.Forms.TextBox txtShiftId;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtTargetTurnTime;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtEcolabTextileCategoryId;
        private System.Windows.Forms.TextBox txtChainTextileCategoryId;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtFormulaSegmentId;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtEcolabSaturationId;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtPlantProgramId;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtSyncReady;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtStdInjectionSteps;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtStdWashSteps;
        private System.Windows.Forms.TextBox txtETechlastDroppedTimeStamp;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtEcolabWasherIdProduct;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtTimestampProduct;
        private System.Windows.Forms.TextBox txtPartitionOn;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtProductId;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtBatchIdEnergyUsageData;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtStepCompartmentEnergyUsage;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtGasOilTypeIdEnergyUsage;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtActualQuantityEnergyUsage;
        private System.Windows.Forms.TextBox txtStandardQuantityEnergyUsage;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtPriceEnergyUsage;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txtEcolabWasherIdEnergyUsage;
        private System.Windows.Forms.TextBox txtPartitionOnEnergyUsage;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button btnAddEnergyUsage;
        private System.Windows.Forms.Label lblEnergyUsageStatus;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtBatchIdParameter;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtEcolabWasherIdParameter;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox txtParameterId;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox txtParameterValue;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtPartitionOnParameter;
        private System.Windows.Forms.Button btnAddParameter;
        private System.Windows.Forms.Label lblParameterDataStatus;
    }
}

