﻿namespace Ecolab.Conduit.BatchDataSyncTest
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net.Sockets;
    using System.Windows.Forms;
    using System.Xml.Serialization;
    using Batch;
    using log4net;
    using Library.Common;
    using Library.Enums;
    using Library.Helpers;
    using MsgPack.Serialization;
    using Newtonsoft.Json;
    using SyncBatchData.Common;
    using SyncBatchData.Enums;
    using Ecolab.Conduit.BatchDataSyncTest.Helpers;

    public partial class BatchDataSyncForm : Form
    {
        private static readonly ILog Log = LogManager.GetLogger("SyncBatchDataService");
        private List<BatchData> batchCollection = new List<BatchData>();
        private List<BatchCustomerData> customerCollection = new List<BatchCustomerData>();
        private List<BatchProductData> productCollection = new List<BatchProductData>();
        private List<BatchStepWaterUsageData> stepWaterUsageCollection = new List<BatchStepWaterUsageData>();
        private List<BatchWashStepData> washStepCollection = new List<BatchWashStepData>();
        private List<BatchStepEnergyUsageData> stepEnergyUsageCollection = new List<BatchStepEnergyUsageData>();
        private List<BatchParameterData> parameterCollection = new List<BatchParameterData>();

        public BatchDataSyncForm()
        {
            InitializeComponent();
        }

        private void ProcessBatchData(List<BatchData> data)
        {
            try
            {
                string ipAddress = txtIpAddress.Text;
                int port = Convert.ToInt32(txtPortNumber.Text);

                Log.Info("Sync Batch Data process started. ");
                using (TcpClient client = new TcpClient())
                {
                    client.ReceiveTimeout = 30000;
                    client.Connect(ipAddress, port);

                    List<BatchData> batchData = data;

                    if (batchData.Count > 0)
                    {
                        Log.Info("No of Batch count = " + batchData.Count);
                        Log.Info("Batch Data Details : " + Environment.NewLine + JsonConvert.SerializeObject(batchData));

                        using (NetworkStream stream = client.GetStream())
                        {
                            //======= transport header =========================================================
                            SendTransportHeader tHeader = new SendTransportHeader();
                            tHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                            tHeader.Body.ServiceType = ServiceType.TcdLogRequest;
                            Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogRequest);

                            XMLSerializer xmlserialize = new XMLSerializer();
                            string xmlString = xmlserialize.ConvertToXML(batchData);

                            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(xmlString);

                            //============ TcdBatch Request Header =============================================
                            TcdBatchRequestHeader batchHeader = new TcdBatchRequestHeader { MessageType = TcdMessageTypes.BatchRequest, PayloadSize = (uint) buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack };
                            Log.Info("Message Type = " + TcdMessageTypes.BatchRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                            // ============== Write to stream ==================================================
                            stream.Write(tHeader);
                            stream.Write(batchHeader);
                            stream.Write(buffer, 0, buffer.Length);

                            MessageBox.Show("Data send on stream.");

                            //======== read the response from tcp server =======================================
                            TcdBatchResponse response = stream.ReadAllOf<TcdBatchResponse>();
                            Log.Info("Response Details : " + Environment.NewLine + JsonConvert.SerializeObject(response));

                            MessageBox.Show("Response Received. Response = " + response.ErrorCode);
                            if (response.ErrorCode == TcdErrCodes.Success)
                            {
                                Log.Info("Request send to message queue.");
                                //foreach (Ecolab.Models.Batch.BatchData batch in batchData)
                                //{
                                //    int batchId = batch.BatchId;
                                //    SyncQueueServices objSyncQueueServices = new SyncQueueServices();
                                //    objSyncQueueServices.LastSyncUpdate(TableEntityMap.GetTable(typeof(Ecolab.Models.Batch.BatchData).Name),
                                //        batchId, TableEntityMap.GetColumn(typeof(Ecolab.Models.Batch.BatchData).Name), batchData[0].EcolabAccountNumber);
                                //}
                            }
                            else
                            {
                                Log.Info("Error in batch request send.");
                                MessageBox.Show("Error in batch request send.");
                            }
                        }
                    }
                    else
                    {
                        Log.Info("Batch Data Count is zero.");
                        MessageBox.Show("Batch Data Count is zero.");
                    }
                }
            }
            catch (SocketException socEx)
            {
                MessageBox.Show("Error ::" + socEx);
                Log.Error("Error Received While process batch data :" + socEx);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error ::" + ex);
                Log.Error("Error occured while process batch data :" + ex);
            }
        }

        /// <summary>
        ///     Serialize
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="thisObj">object of type param</param>
        /// <returns></returns>
        public byte[] Serialize<T>(T thisObj)
        {
            MessagePackSerializer<T> serializer = MessagePackSerializer.Get<T>();
            using (MemoryStream byteStream = new MemoryStream())
            {
                serializer.Pack(byteStream, thisObj);
                return byteStream.ToArray();
            }
        }

        private BatchData GetBatchData()
        {
            BatchData batchData = new BatchData();
            batchData.BatchId = int.Parse(txtBatchId.Text);
            batchData.ControllerBatchId = int.Parse(txtControllerBatchId.Text);
            batchData.EcolabWasherId = Int16.Parse(txtEcolabWasherId.Text);
            batchData.GroupId = int.Parse(txtGroupId.Text);
            batchData.MachineInternalId = byte.Parse(txtMachineInternalId.Text);
            batchData.StartDate = Convert.ToDateTime(txtStartDate.Text);
            batchData.EndDate = Convert.ToDateTime(txtEndDate.Text);
            batchData.ProgramNumber = int.Parse(txtProgramNumber.Text);
            batchData.ProgramMasterId = int.Parse(txtProgramMasterId.Text);
            batchData.MachineId = int.Parse(TxtMachineId.Text);
            batchData.ActualWeight = int.Parse(txtActualWeight.Text);
            batchData.StandardWeight = int.Parse(txtStandardWeight.Text);
            batchData.ProgramNumber = int.Parse(txtProgramNumber.Text);
            batchData.CurrencyCode = txtCurrencyCode.Text;
            batchData.PlantWasherNumber = Int16.Parse(txtPlantWasherNumber.Text);
            batchData.ManualInputWeight = int.Parse(txtManualWeight.Text);
            batchData.HoldTime = int.Parse(txtHoldTime.Text);
            batchData.BatchStatus = byte.Parse(txtBatchStatus.Text);
            batchData.EndDateFormula = Convert.ToDateTime(txtEndDateFormula.Text);
            batchData.PartitionOn = Convert.ToDateTime(txtStartDate.Text);
            batchData.LastSyncTime = Convert.ToDateTime(txtEndDate.Text);
            batchData.ShiftId = int.Parse(txtShiftId.Text);
            batchData.TargetTurnTime = int.Parse(txtTargetTurnTime.Text);
            batchData.EcolabTextileCategoryId = int.Parse(txtEcolabTextileCategoryId.Text);
            batchData.ChainTextileCategoryId = int.Parse(txtChainTextileCategoryId.Text);
            batchData.FormulaSegmentId = int.Parse(txtFormulaSegmentId.Text);
            batchData.EcolabSaturationId = int.Parse(txtEcolabSaturationId.Text);
            batchData.PlantProgramId = int.Parse(txtPlantProgramId.Text);
            batchData.SyncReady = bool.Parse(txtSyncReady.Text);
            batchData.StdInjectionSteps = int.Parse(txtStdInjectionSteps.Text);
            batchData.StdWashSteps = int.Parse(txtStdWashSteps.Text);
            batchData.ETechlastDroppedTimeStamp = Convert.ToDateTime(txtETechlastDroppedTimeStamp.Text);

            batchData.BatchCustomerList = new List<BatchCustomerData>();
            foreach (BatchCustomerData batchCustomerData in customerCollection)
            {
                batchData.BatchCustomerList.Add(batchCustomerData);
            }

            batchData.BatchProductList = new List<BatchProductData>();
            foreach (BatchProductData batchProductData in productCollection)
            {
                batchData.BatchProductList.Add(batchProductData);
            }

            batchData.BatchWashStepList = new List<BatchWashStepData>();
            foreach (BatchWashStepData batchWashStepData in washStepCollection)
            {
                batchData.BatchWashStepList.Add(batchWashStepData);
            }

            batchData.BatchStepWaterUsageList = new List<BatchStepWaterUsageData>();
            foreach (BatchStepWaterUsageData batchStepWaterUsageData in stepWaterUsageCollection)
            {
                batchData.BatchStepWaterUsageList.Add(batchStepWaterUsageData);
            }
            batchData.BatchStepEnergyUsageList = new List<BatchStepEnergyUsageData>();
            foreach (BatchStepEnergyUsageData batchStepEnergyUsageData in stepEnergyUsageCollection)
            {
                batchData.BatchStepEnergyUsageList.Add(batchStepEnergyUsageData);
            }
            batchData.BatchParameterDataList = new List<BatchParameterData>();
            foreach (BatchParameterData batchParameterData in parameterCollection)
            {
                batchData.BatchParameterDataList.Add(batchParameterData);
            }


            return batchData;
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            BatchCustomerData batchCustomerData = new BatchCustomerData();
            batchCustomerData.BatchId = int.Parse(txtBatchIdCustomer.Text);
            batchCustomerData.CustomerId = int.Parse(txtCustomerId.Text);
            batchCustomerData.Weight = int.Parse(txtLoad.Text);
            batchCustomerData.PiecesCount = int.Parse(txtPiecesCount.Text);
            batchCustomerData.EcolabWasherId = Int16.Parse(txtEcolabWasherId.Text);
            batchCustomerData.PartitionOn = Convert.ToDateTime(txtStartDate.Text);
            customerCollection.Add(batchCustomerData);

            //txtBatchIdCustomer.Text = string.Empty;
            //txtCustomerId.Text = string.Empty;
            //txtLoad.Text = string.Empty;
            //txtPiecesCount.Text = string.Empty;

            lblBatchCustomerStatus.Text = "Batch Customer added successfully. Count = " + customerCollection.Count;
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            BatchProductData batchProductData = new BatchProductData();
            batchProductData.BatchId = int.Parse(txtBatchIdProduct.Text);
            batchProductData.StepCompartment = int.Parse(txtStepCmprtment.Text);
            batchProductData.ActualQuantity = int.Parse(txtActualQuantity.Text);
            batchProductData.StandardQuantity = int.Parse(txtStandardQuantity.Text);
            batchProductData.Price = int.Parse(txtPrice.Text);
            batchProductData.EcolabWasherId = Int16.Parse(txtEcolabWasherId.Text);
            batchProductData.PartitionOn = Convert.ToDateTime(txtStartDate.Text);
            batchProductData.Timestamp = Convert.ToDateTime(txtStartDate.Text);
            batchProductData.Status = Convert.ToBoolean(txtStatus.Text);
            batchProductData.ProductId = int.Parse(txtProductId.Text);
            productCollection.Add(batchProductData);

            //txtBatchIdProduct.Text = string.Empty;
            //txtStepCmprtment.Text = string.Empty;
            //txtSKU.Text = string.Empty;
            //txtActualQuantity.Text = string.Empty;
            //txtStandardQuantity.Text = string.Empty;
            //txtPrice.Text = string.Empty;

            lblProductStatus.Text = "Product Data added successfully. Count = " + productCollection.Count;
        }

        private void btnAddWashStep_Click(object sender, EventArgs e)
        {
            BatchWashStepData batchWashStepData = new BatchWashStepData();
            batchWashStepData.BatchId = int.Parse(txtBatchIdWS.Text);
            batchWashStepData.StepCompartment = int.Parse(txtStepCompartment.Text);
            batchWashStepData.StartTime = Convert.ToDateTime(txtStartTime.Text);
            batchWashStepData.EndTime = Convert.ToDateTime(txtEndTime.Text);
            batchWashStepData.EcolabWasherId = Int16.Parse(txtEcolabWasherId.Text);
            batchWashStepData.PartitionOn = Convert.ToDateTime(txtStartDate.Text);

            washStepCollection.Add(batchWashStepData);

            //txtBatchIdWS.Text = string.Empty;
            //txtStepCompartment.Text = string.Empty;
            //txtStartTime.Text = string.Empty;
            //txtEndTime.Text = string.Empty;

            lblWashStepStatus.Text = "WashStep Data added successfully. Count = " + washStepCollection.Count;
        }

        private void btnAddWaterUsages_Click(object sender, EventArgs e)
        {
            BatchStepWaterUsageData stepWaterUsageData = new BatchStepWaterUsageData();
            stepWaterUsageData.BatchId = int.Parse(txtbatchIdWU.Text);
            stepWaterUsageData.WaterTypeId = int.Parse(txtWaterTypeId.Text);
            stepWaterUsageData.ActualQuantity = int.Parse(txtActualQuantityWU.Text);
            stepWaterUsageData.StandardQuantity = int.Parse(txtStdQuantityWU.Text);
            stepWaterUsageData.Price = int.Parse(txtPriceWU.Text);
            stepWaterUsageData.StepCompartment = int.Parse(txtStepCompartmentSWU.Text);
            stepWaterUsageData.EcolabWasherId = Int16.Parse(txtEcolabWasherId.Text);
            stepWaterUsageData.PartitionOn = Convert.ToDateTime(txtStartDate.Text);

            stepWaterUsageCollection.Add(stepWaterUsageData);

            //txtbatchIdWU.Text = string.Empty;
            //txtWaterTypeId.Text = string.Empty;
            //txtActualQuantityWU.Text = string.Empty;
            //txtStdQuantityWU.Text = string.Empty;
            //txtPriceWU.Text = string.Empty;
            //txtStepCompartmentSWU.Text = string.Empty;

            lblWaterUsageStatus.Text = "Water usages Data added successfully. Count = " + stepWaterUsageCollection.Count;
        }

        private void btnAddEnergyUsage_Click(object sender, EventArgs e)
        {
            BatchStepEnergyUsageData stepEnergyUsageData = new BatchStepEnergyUsageData();
            stepEnergyUsageData.BatchId = int.Parse(txtBatchIdEnergyUsageData.Text);
            stepEnergyUsageData.StepCompartment = int.Parse(txtStepCompartmentEnergyUsage.Text);
            stepEnergyUsageData.GasOilTypeId = int.Parse(txtGasOilTypeIdEnergyUsage.Text);
            stepEnergyUsageData.ActualQuantity = double.Parse(txtActualQuantityEnergyUsage.Text);
            stepEnergyUsageData.StandardQuantity = double.Parse(txtStandardQuantityEnergyUsage.Text);
            stepEnergyUsageData.Price = double.Parse(txtPriceEnergyUsage.Text);
            stepEnergyUsageData.EcolabWasherId = int.Parse(txtEcolabWasherIdEnergyUsage.Text);
            stepEnergyUsageData.PartitionOn = Convert.ToDateTime(txtPartitionOnEnergyUsage.Text);

            stepEnergyUsageCollection.Add(stepEnergyUsageData);

            lblEnergyUsageStatus.Text = "Energy usages Data added successfully. Count = " + stepEnergyUsageCollection.Count;

        }

        private void btnAddParameter_Click(object sender, EventArgs e)
        {
            BatchParameterData batchParameterData = new BatchParameterData();
            batchParameterData.BatchId = int.Parse(txtBatchIdParameter.Text);
            batchParameterData.EcolabWasherId = int.Parse(txtEcolabWasherIdParameter.Text);
            batchParameterData.ParameterId = float.Parse(txtParameterId.Text);
            batchParameterData.ParameterValue = float.Parse(txtParameterValue.Text);
            batchParameterData.PartitionOn = Convert.ToDateTime(txtPartitionOnParameter.Text);

            parameterCollection.Add(batchParameterData);

            lblParameterDataStatus.Text = " Parameter Data added successfully. Count = " + parameterCollection.Count;

        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            txtSelectedFile.Text = string.Empty;
            xmlFileDialog.ShowDialog();
            txtSelectedFile.Text = xmlFileDialog.FileName;
        }

        private void btnSendToTcp_Click(object sender, EventArgs e)
        {
            //Read file data, convert to object and send to TCP
            string xmlData = File.ReadAllText(txtSelectedFile.Text);
            ProcessXmlBatchData(xmlData);
        }

        private void ProcessXmlBatchData(string xmlData)
        {
            try
            {
                string ipAddress = txtIpAddressBatchXml.Text;
                int port = Convert.ToInt32(txtPortNumberBatchXml.Text);

                Log.Info("Sync Batch Data process started. ");
                using (TcpClient client = new TcpClient())
                {
                    client.ReceiveTimeout = 30000;
                    client.Connect(ipAddress, port);

                    var batchDataList = new List<BatchData>();
                    XmlSerializer oXmlSerializer = new XmlSerializer(batchDataList.GetType());
                    batchDataList = (List<BatchData>) oXmlSerializer.Deserialize(new StringReader(xmlData));

                    List<BatchData> batchData = batchDataList;

                    if (batchData.Count > 0)
                    {
                        Log.Info("No of Batch count = " + batchData.Count);
                        Log.Info("Batch Data Details : " + Environment.NewLine + JsonConvert.SerializeObject(batchData));

                        using (NetworkStream stream = client.GetStream())
                        {
                            //======= transport header =========================================================
                            SendTransportHeader tHeader = new SendTransportHeader();
                            tHeader.Version = EcpTransportHeader.SUPPORTEDVERSION;
                            tHeader.Body.ServiceType = ServiceType.TcdLogRequest;
                            Log.Info("Supported Version = " + EcpTransportHeader.SUPPORTEDVERSION + " , ServiceType = " + ServiceType.TcdLogRequest);

                            byte[] buffer = Serialize(batchData);
                            //============ TcdBatch Request Header =============================================
                            TcdBatchRequestHeader batchHeader = new TcdBatchRequestHeader { MessageType = TcdMessageTypes.BatchRequest, PayloadSize = (uint) buffer.Length, MessageFormat = TcdMessageFormatTypes.MessagePack };
                            Log.Info("Message Type = " + TcdMessageTypes.BatchRequest + " , Payload Size = " + buffer.Length + " , MessageFormat = " + TcdMessageFormatTypes.MessagePack);

                            // ============== Write to stream ==================================================
                            stream.Write(tHeader);
                            stream.Write(batchHeader);
                            stream.Write(buffer, 0, buffer.Length);

                            MessageBox.Show("Data send on stream.");

                            //======== read the response from tcp server =======================================
                            TcdBatchResponse response = stream.ReadAllOf<TcdBatchResponse>();
                            Log.Info("Response Details : " + Environment.NewLine + JsonConvert.SerializeObject(response));

                            MessageBox.Show("Response Received : Response " + response.ErrorCode);

                            if (response.ErrorCode == TcdErrCodes.Success)
                            {
                                Log.Info("Request send to message queue.");
                                //foreach (Ecolab.Models.Batch.BatchData batch in batchData)
                                //{
                                //    int batchId = batch.BatchId;
                                //    SyncQueueServices objSyncQueueServices = new SyncQueueServices();
                                //    objSyncQueueServices.LastSyncUpdate(TableEntityMap.GetTable(typeof(Ecolab.Models.Batch.BatchData).Name),
                                //        batchId, TableEntityMap.GetColumn(typeof(Ecolab.Models.Batch.BatchData).Name), batchData[0].EcolabAccountNumber);
                                //}
                            }
                            else
                            {
                                Log.Info("Error in batch request send.");
                                MessageBox.Show("Error in batch request send.");
                            }
                        }
                    }
                    else
                    {
                        Log.Info("Batch Data Count is zero.");
                        MessageBox.Show("Batch Data Count is zero.");
                    }
                }
            }
            catch (SocketException socEx)
            {
                MessageBox.Show("Error ::" + socEx);
                Log.Error("Error Received While process batch data :" + socEx);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error ::" + ex);
                Log.Error("Error occured while process batch data :" + ex);
            }
        }

        private void btnSendBatchDataToTcp_Click(object sender, EventArgs e)
        {
            ProcessBatchData(batchCollection);
            batchCollection = new List<BatchData>();
            lblBatchDataCount.Text = "Batch Data Count = " + batchCollection.Count;
        }

        private void btnAddBatchData_Click(object sender, EventArgs e)
        {
            BatchData batchData = GetBatchData();
            batchCollection.Add(batchData);
            lblBatchDataCount.Text = "Batch Data Count = " + batchCollection.Count;
            MessageBox.Show("Batch Data added successfully.");
            ;

            //txtBatchId.Text = string.Empty;
            //txtControllerBatchId.Text = string.Empty;
            //txtEcolabWasherId.Text = string.Empty;
            //txtGroupId.Text = string.Empty;
            //txtMachineInternalId.Text = string.Empty;
            //txtStartDate.Text = string.Empty;
            //txtEndDate.Text = string.Empty;
            //txtProgramNumber.Text = string.Empty;
            //txtActualWeight.Text = string.Empty;
            //txtStandardWeight.Text = string.Empty;
            //txtProgramNumber.Text = string.Empty;
            //txtCurrencyCode.Text = string.Empty;

            customerCollection = new List<BatchCustomerData>();
            productCollection = new List<BatchProductData>();
            washStepCollection = new List<BatchWashStepData>();
            stepWaterUsageCollection = new List<BatchStepWaterUsageData>();
            stepEnergyUsageCollection = new List<BatchStepEnergyUsageData>();
            parameterCollection = new List<BatchParameterData>();

            lblBatchCustomerStatus.Text = "Data Added to main Batch.";
            lblProductStatus.Text = "Data Added to main Batch.";
            lblWashStepStatus.Text = "Data Added to main Batch.";
            lblWaterUsageStatus.Text = "Data Added to main Batch.";
            lblEnergyUsageStatus.Text = "Data Added to main Batch.";
            lblParameterDataStatus.Text = "Data Added to main Batch.";
        }

        private void BtnGenearateXML_Click(object sender, EventArgs e)
        {
            List<BatchData> batchdata = batchCollection;
            XMLSerializer xmlserialize = new XMLSerializer();
            string xmlString = xmlserialize.ConvertToXML(batchdata);
        }
    }
}