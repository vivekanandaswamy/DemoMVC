﻿using System;
using System.Collections.Generic;

namespace Ecolab.Conduit.BatchDataSyncTest.Alarm
{
    public class AlarmData
    {
        public DateTime StartDate { get; set; }
        public string StartDateFormatted { get; set; }  
        public string MachineName { get; set; }
        public string AlarmDescription { get; set; }
        public int AlarmCode { get; set; }
        public int ControllerId { get; set; }
        public int GroupId { get; set; }
        public int MachineInternalId { get; set; }
        public int ProgramId { get; set; }
        public int MENumber { get; set; }
        public int BatchId { get; set; }
        public int Valve { get; set; }
        public int InjectionNumber { get; set; }
        public int MachineId { get; set; }
        public bool IsActive { get; set; }
        public DateTime EndDate { get; set; }
        public int DesiredQuantity { get; set; }
        public int MeasuredQuantity { get; set; }
        public int TempStatus { get; set; }
        public int ProbeNumber { get; set; }
        public int UserId { get; set; }
        public string StepId { get; set; }
        public DateTime PartitionOn { get; set; }
        public DateTime LastSyncTime { get; set; }
        public string EcoalabAccountNumber { get; set; }
        public int AlarmGroupMasterId { get; set; }
        public List<AlarmMaster> AlarmMasterList { get; set; }

    }
}
