﻿using System;


namespace Ecolab.Conduit.BatchDataSyncTest.Alarm
{
    public class AlarmMaster
    {
        public int AlarmCode { get; set; }
        public string Description { get; set; }
        public int ControllerModelTypeId { get; set; }
        public string ResourceKey { get; set; }
        public bool IsDefault { get; set; }
        public int AlarmMaachineMappingId { get; set; }
        public int MachineNumber { get; set; }
        public int ControllerModelId { get; set; }
        public int ControllerTypeId { get; set; }
        public DateTime LastModifiedTime { get; set; }
        public string WasherType { get; set; }
        public bool IsDeleteAlarmMapping { get; set; }
        public int MachineNumberMappingId { get; set; }
        public bool IsHoldCondition { get; set; }
        public int AlarmNumber { get; set; }
    }
}
