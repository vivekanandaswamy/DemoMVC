﻿// -----------------------------------------------------------------------
// <copyright file="Utf8Helper.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Utf8Helper </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Helpers
{
    using System;
    using System.Text;

    public static class Utf8Helper
    {
        public static byte[] ToFixedLengthUtf8Bytes(string from, int length)
        {
            var result = new byte[length];
            if (from == null)
            {
                return result;
            }
            Encoding.UTF8.GetBytes(from, 0, from.Length, result, 0);
            return result;
        }

        public static string FromUtf8Bytes(byte[] utf8)
        {
            if (utf8 == null || utf8[0] == 0)
            {
                return string.Empty;
            }

            //Check for a completely full array
            int length = Array.IndexOf(utf8, (byte) 0);
            if (length == -1)
            {
                length = utf8.Length;
            }
            return Encoding.UTF8.GetString(utf8, 0, length);
        }

        public static string FromUtf8Bytes(byte[] utf8, int startIndex, int length)
        {
            if (utf8 == null || utf8[startIndex] == 0)
            {
                return string.Empty;
            }

            //Check for a completely full array
            int computedLength = Array.IndexOf(utf8, (byte) 0, startIndex);
            if (computedLength == -1)
            {
                computedLength = length;
            }
            return Encoding.UTF8.GetString(utf8, startIndex, computedLength);
        }
    }
}