﻿// -----------------------------------------------------------------------
// <copyright file="ObjectToByteArrayHelper.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>TheObject To Byte Array Helper </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Helpers
{
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;

    /// <summary>
    ///     Object To Byte Array Helper
    /// </summary>
    public static class ObjectToByteArrayHelper
    {
        /// <summary>
        /// Object To Byte Array
        /// </summary>
        /// <param name="obj">obj</param>
        /// <typeparam name="T">Type param</typeparam>
        /// <returns>Byte Array</returns>
        public static byte[] ObjectToByteArray<T>(T obj)
        {
            if (obj == null)
            {
                return null;
            }
            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, obj);
            return ms.ToArray();
        }
    }
}