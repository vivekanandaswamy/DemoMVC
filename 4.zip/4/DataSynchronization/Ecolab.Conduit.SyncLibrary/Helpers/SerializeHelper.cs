﻿// -----------------------------------------------------------------------
// <copyright file="SerializeHelper.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>SerializeHelper </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Helpers
{
    using System.IO;
    using System.Text;
    using MsgPack.Serialization;

    /// <summary>
    ///     Serialize Helper
    /// </summary>
    public static class SerializeHelper
    {
        /// <summary>
        ///     Serialize
        /// </summary>
        /// <typeparam name="T">type param T</typeparam>
        /// <param name="thisObj">Object of type param T</param>
        /// <returns></returns>
        public static byte[] Serialize<T>(T thisObj)
        {
            MessagePackSerializer<T> serializer = MessagePackSerializer.Get<T>();

            using (MemoryStream byteStream = new MemoryStream())
            {
                serializer.Pack(byteStream, thisObj);
                return byteStream.ToArray();
            }
        }

        /// <summary>
        ///     Convert String To ByteArray
        /// </summary>
        /// <param name="stringData"></param>
        /// <returns></returns>
        public static byte[] ConvertStringToByteArray(string stringData)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(stringData);
            return buffer;
        }

        /// <summary>
        ///     Convert Byte Array To String
        /// </summary>
        /// <param name="byteData"></param>
        /// <returns></returns>
        public static string ConvertByteArrayToString(byte[] byteData)
        {
            string outputString = string.Empty;
            outputString = Encoding.UTF8.GetString(byteData);
            return outputString;
        }

        /// <summary>
        ///     Unpack message pack
        /// </summary>
        /// <typeparam name="T">Type T</typeparam>
        /// <param name="bytes">byte array</param>
        /// <returns>Type T Entity</returns>
        public static T Deserialize<T>(byte[] bytes)
        {
            MessagePackSerializer<T> serializer = MessagePackSerializer.Get<T>();
            using (MemoryStream byteStream = new MemoryStream(bytes))
            {
                return serializer.Unpack(byteStream);
            }
        }
    }
}