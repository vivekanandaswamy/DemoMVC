﻿// -----------------------------------------------------------------------
// <copyright file="CompressHelper.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>CompressHelper </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Helpers
{
    using System.IO;
    using System.IO.Compression;

    /// <summary>
    ///     Compress Helper
    /// </summary>
    public static class CompressHelper
    {
        /// <summary>
        ///     Compress
        /// </summary>
        /// <param name="raw"></param>
        /// <returns>byte[]</returns>
        public static byte[] Compress(byte[] raw)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                using (GZipStream gzip = new GZipStream(memory, CompressionMode.Compress, true))
                {
                    gzip.Write(raw, 0, raw.Length);
                }
                return memory.ToArray();
            }
        }
    }
}