﻿// -----------------------------------------------------------------------
// <copyright file="TableEntityMap.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TableEntityMap </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Helpers
{
    using System.Collections.Generic;
    using System.Linq;

    public static class TableEntityMap
    {
        public static string GetTable(string entityType)
        {
            string tableName = string.Empty;
            var dt = new Dictionary<string, string>();

            dt.Add("Ecolab.Models.PlantSetup.Chemical.ProductMaster", "ProductdataMapping");
            dt.Add("Ecolab.Models.PlantContact", "PlantContact");
            dt.Add("Ecolab.Models.ControllerSetup.ControllerSetupDataDetails", "ConduitController");
            dt.Add("Ecolab.Models.ControllerSetup.Controller", "ConduitController");
            dt.Add("Ecolab.Models.ControllerSetup.Pumps.PumpsModel", "ControllerEquipmentSetup");
            dt.Add("Ecolab.Models.PlantSetup.Dryer.Dryer", "Dryers");
            dt.Add("Ecolab.Models.PlantSetup.Dryer.DryerGroup", "MachineGroup");
            dt.Add("Ecolab.Models.PlantSetup.Finnisher.FinnisherGroup", "MachineGroup");
            dt.Add("Ecolab.Models.PlantSetup.Finnisher.Finnisher", "Finnishers");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.LaborCostContainer", "LaborCost");
            dt.Add("Ecolab.Models.PlantSetup.MeterModel", "Meter");
            dt.Add("Ecolab.Models.PlantCustomer", "PlantCustomer");
            dt.Add("Ecolab.Models.Plant", "Plant");
            dt.Add("Ecolab.Models.Formula", "ProgramMaster");
            dt.Add("Ecolab.Models.PlantSetup.PlantUtilitySetup", "EnergyUtilityDetails");
            dt.Add("Ecolab.Models.PlantSetup.PlantUtilityContainer", "EnergyUtilityDetails");
            dt.Add("Ecolab.Models.PlantSetup.RedFlag.RedFlag", "RedFlag");
            dt.Add("Ecolab.Models.PlantSetup.SensorModel", "Sensor");
            dt.Add("Ecolab.Models.StorageTanks.Tanks", "TankSetup");
            dt.Add("Ecolab.Models.PlantSetup.Utility", "WaterAndEnergy");
            dt.Add("Ecolab.Models.WasherGroup.WasherGroup", "MachineGroup");
            dt.Add("Ecolab.Models.WasherGroup.TunnelFormulaModel", "TunnelProgramSetup");
            dt.Add("Ecolab.Models.WasherGroup.WasherFormulaModel", "WasherProgramSetup");
            dt.Add("Ecolab.Models.Washers.Conventional.ConventionalGeneral", "Washer");
            dt.Add("Ecolab.Models.Washers.Tunnel.TunnelContainer", "Tunnel");
            dt.Add("Ecolab.Models.Washers.Tunnel.TunnelCompartment", "TunnelCompartment");
            dt.Add("Ecolab.Models.PlantSetup.UserManagement.UserManagement", "UserMaster");
            dt.Add("Ecolab.Models.ManualInput.ManualUtility", "ManualUtility");
            dt.Add("Ecolab.Models.Batch.BatchData", "BatchData");
            dt.Add("Ecolab.Models.Washers.Washers", "Washer");
            dt.Add("Ecolab.Models.PlantSetup.ShiftLabor", "ShiftData");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.TargetProductionContainer", "TARGETPRODUCTIONDETAILS");
            dt.Add("Ecolab.Models.ManualInput.Rewash.ManualRewashContainer", "ManualRewash");
			dt.Add("Ecolab.Models.ManualInput.Production.ManualProductionSyncContainer", "ManualProduction");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.ProductionShiftContainer", "ProductionShiftData");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.ShiftSyncContainer", "ShiftData");
			dt.Add("Ecolab.Models.PlantSetup.Sensor", "Sensor");
			dt.Add("Ecolab.Models.PlantSetup.Meter", "Meter");
			dt.Add("Ecolab.Models.Washers.FlushTimesAndSetupTom", "WasherFlushTime");
			dt.Add("Ecolab.Models.Washers.Tunnel.TunnelAnalogueDosingControlContainer", "TunnelAnalogControlLevel");
            dt.Add("Ecolab.Models.Alarm", "AlarmData");
            dt.Add("Ecolab.Models.PlantSetup.Chemical.ProductStandardPrice", "ProductStandardPrice");
            dt.Add("Ecolab.Models.PlantSetup.RedFlag.RedFlagData", "RedFlagData");
            dt.Add("Ecolab.Models.PlantSetup.ModuleRead.ModuleReadData", "ModuleReading");
            dt.Add("Ecolab.Models.ManualInput.ManualLabor.ManualLabor", "ManualLabor");
            dt.Add("Ecolab.Models.Washers.Alarms", "AlarmStatus");

             tableName = dt.Keys.Contains(entityType) ? dt[entityType] : string.Empty;
            return tableName;
        }

        public static string GetColumn(string entityType)
        {
            string columnName = string.Empty;
            var dt = new Dictionary<string, string>();

            dt.Add("Ecolab.Models.PlantSetup.Chemical.ProductMaster", "Id");
            dt.Add("Ecolab.Models.PlantContact", "ID");
            dt.Add("Ecolab.Models.ControllerSetup.ControllerSetupDataDetails", "ControllerId");
            dt.Add("Ecolab.Models.ControllerSetup.Controller", "ControllerId");
            dt.Add("Ecolab.Models.ControllerSetup.Pumps.PumpsModel", "ControllerId");
            dt.Add("Ecolab.Models.PlantSetup.Dryer.Dryer", "Id");
            dt.Add("Ecolab.Models.PlantSetup.Dryer.DryerGroup", "Id");
            dt.Add("Ecolab.Models.PlantSetup.Finnisher.FinnisherGroup", "Id");
            dt.Add("Ecolab.Models.PlantSetup.Finnisher.Finnisher", "FinnisherId");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.LaborCostContainer", "LaborCostId");
            dt.Add("Ecolab.Models.PlantSetup.MeterModel", "MeterId");
            dt.Add("Ecolab.Models.PlantCustomer", "Id");
            dt.Add("Ecolab.Models.Formula", "ProgramId");
            dt.Add("Ecolab.Models.PlantSetup.PlantUtilitySetup", "UtilityId");
            dt.Add("Ecolab.Models.PlantSetup.PlantUtilityContainer", "GasOilTypeId");
            dt.Add("Ecolab.Models.PlantSetup.RedFlag.RedFlag", "Id");
            dt.Add("Ecolab.Models.PlantSetup.SensorModel", "SensorId");
            dt.Add("Ecolab.Models.StorageTanks.Tanks", "TankId");
            dt.Add("Ecolab.Models.PlantSetup.Utility", "GroupId");
            dt.Add("Ecolab.Models.WasherGroup.WasherGroup", "Id");
            dt.Add("Ecolab.Models.WasherGroup.TunnelFormulaModel", "TunnelProgramSetupId");
            dt.Add("Ecolab.Models.WasherGroup.WasherFormulaModel", "WasherProgramSetupId");
            dt.Add("Ecolab.Models.Washers.Conventional.ConventionalGeneral", "WasherId");
            dt.Add("Ecolab.Models.Washers.Tunnel.TunnelContainer", "WasherId");
            dt.Add("Ecolab.Models.Washers.Tunnel.TunnelCompartment", "TunnelCompartmentId");
            dt.Add("Ecolab.Models.PlantSetup.UserManagement.UserManagement", "UserId");
            dt.Add("Ecolab.Models.ManualInput.ManualUtility", "UtilityId");
            dt.Add("Ecolab.Models.Batch.BatchData", "BatchId");
            dt.Add("Ecolab.Models.PlantSetup.ShiftLabor", "ShiftId");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.TargetProductionContainer", "Id");
            dt.Add("Ecolab.Models.ManualInput.Rewash.ManualRewashContainer", "RewashId");
			dt.Add("Ecolab.Models.ManualInput.Production.ManualProductionSyncContainer", "ProductionId");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.ProductionShiftContainer", "ShiftId");
			dt.Add("Ecolab.Models.PlantSetup.ShiftLabor.ShiftSyncContainer", "ShiftId");
			dt.Add("Ecolab.Models.PlantSetup.Sensor", "SensorId");
			dt.Add("Ecolab.Models.PlantSetup.Meter", "MeterId");
			dt.Add("Ecolab.Models.Washers.FlushTimesAndSetupTom", "WasherId");
			dt.Add("Ecolab.Models.Washers.Tunnel.TunnelAnalogueDosingControlContainer", "WasherId");
            dt.Add("Ecolab.Models.Alarm", "Id");
            dt.Add("Ecolab.Models.PlantSetup.RedFlag.RedFlagData", "RedFlagId");
            dt.Add("Ecolab.Models.PlantSetup.ModuleRead.ModuleReadData", "ModuleId");
            dt.Add("Ecolab.Models.ManualInput.ManualLabor.ManualLabor", "Id");
            dt.Add("Ecolab.Models.Washers.Alarms", "Id");

            columnName = dt.Keys.Contains(entityType) ? dt[entityType] : string.Empty;
            return columnName;
        }
    }
}