﻿// -----------------------------------------------------------------------
// <copyright file="StructConverter.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>StructConverter </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Helpers
{
	using System;
	using System.Runtime.InteropServices;

	/// <summary>
	///     StructConverter
	/// </summary>
	public static class StructConverter
	{
		/// <summary>
		///     The GetData.
		/// </summary>
		/// <typeparam name="T">type param T</typeparam>
		/// <param name="data">The data param.</param>
		/// <returns>returns type T</returns>
		public static T GetData<T>(byte[] data)
		{
			GCHandle handle = GCHandle.Alloc(data, GCHandleType.Pinned);
			T val = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
			handle.Free();
			return val;
		}

		/// <summary>
		///     Get Data
		/// </summary>
		/// <param name="data">The data param.</param>
		/// <param name="type">type param.</param>
		/// <returns>the object.</returns>
		public static object GetData(byte[] data, Type type)
		{
			GCHandle handle = GCHandle.Alloc(data, GCHandleType.Pinned);
			object val = Marshal.PtrToStructure(handle.AddrOfPinnedObject(), type);
			handle.Free();
			return val;
		}
	}
}