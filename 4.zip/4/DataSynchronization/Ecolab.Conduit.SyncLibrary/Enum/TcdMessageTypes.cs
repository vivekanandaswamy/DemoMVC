﻿// -----------------------------------------------------------------------
// <copyright file="TcdMessageTypes.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TcdMessageTypes </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLibrary.Enum
{
    /// <summary>
    ///     Tcd Message Types
    /// </summary>
    public enum TcdMessageTypes : uint
    {
		None = 0,
        BatchRequest = 1,
        AlarmRequest = 2,
        LogRequest = 3,
        RedFlagRequest = 4,
		ModuleReadRequest = 5
    }
}