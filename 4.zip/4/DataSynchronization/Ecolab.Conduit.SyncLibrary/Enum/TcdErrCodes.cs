﻿// -----------------------------------------------------------------------
// <copyright file="TcdErrCodes.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd error codes</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Enums
{
    /// <summary>
    ///     Tcd error codes enum
    /// </summary>
    public enum TcdErrCodes : uint
    {
        //TODO: Need to cleanup error codes
        NotConfigured = uint.MaxValue - 1,
        CommunicationFailure = uint.MaxValue - 2,

        Success = 0,
        RequestFailed = 99,

        // TCD Error Codes
        SaveFailure = 39,
        UpdateFailure = 40,
        DeleteFailure = 41, 

        DryerNumberAlreadyExist = 42,
        DryerNameAlreadyExist = 43,
        FinnisherNumberAlreadyExist = 44,
        FinnisherNameAlreadyExist = 45,
        DryerGroupAlreadyExist = 46,
        FinnisherGroupAlreadyExist = 47,
        RedFlagAlreadyExists = 48,
        CustomerAlreadyExists = 49,
		MeterSensorNotAssociated = 50,
        LoginNameAlreadyExists = 51,
        EmailAlreadyExists  = 52,
        MeterOrSensorMappedToRedflag = 53,
        OneSensorSameWasherTunnel = 54,
        OneCondSensorSameWasherTunnel = 55,
        Max2PhSesnorSameWasherTunnel = 56,
        Max6TempSesnorSameWasherTunnel = 57,
        MaxOneSensorSameCompartment = 58,
        UnableToUpdateSensorMappedToRedFlag = 59,
        UtitlityLoggerNotAvailable = 60,
        Max1MeterSameUtility = 61,
        Max2WaterMetersSameWaherTunnel = 62,
        DispenserEmpty = 63,
        DuplicateMeterName = 64,
        MeterCanNotEmpty = 65,
        MeterLocationNotEmpty = 66,
        MeterUtilityLoggerNotAvaialable = 67,
        MeterMachineMappedToRedFlag = 68,
        Max6WaterMeters = 69,
        MeterRecordNotinSynch = 70,
        MeterRecordCountDontMatch = 71,
        MeterConnectivityIssue = 72,
        RecordCountNotMatch = 51030,
        RecordAlreadyExist = 51031,
		NggNotConnected = 51032,
		ResyncImportFormula = 51033,
		ResyncMovePump = 51034,
		RecordNotInSynch = 60000,

        WasherGroupNumberAlreadyExist = 51000, // Since data for WasherGroup is across 2 tables... we will need to check for the uniqueness of WasherGroupNumber/Name here...
        WasherGroupIsNotValid = 51001, // Check that the WasherGroup being associated-to is a valid Tunnel-type  
        PlantWasherNumberAlreadyExist = 51002,
        ControllerIsNotValid = 51003, //Check that it's a valid Controller type/model (one that can control a Tunnel)
        EOFIsNotValid = 51004, //EOF should not be an asocciated formula for the WG
        WasherModeIsNotValid = 51005, //Check provided washer mode being associated to is a valid tunnel
        WasherIdIsNotValidForUpdatingRecord = 51006, //Provided washer id is not valid for updating record
        WasherIdIsNotValidForDeletingRecord = 51007,
        TunnelAlreadyExistForProvidedWasherGroup = 51008,
        LFSWasherNumberAlreadyExist = 51010,
        ControllerNumberAlreadyExists = 303,
        ControllerNameAlreadyExists = 304,
        ControllerNotAllowed = 51011,
        MSMQIsDisabled = 60001,
        MaxFormulasReached = 51012
    }
}