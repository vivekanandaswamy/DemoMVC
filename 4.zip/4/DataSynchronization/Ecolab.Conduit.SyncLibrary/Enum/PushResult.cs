﻿// -----------------------------------------------------------------------
// <copyright file="PushResult.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>PushResult </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLibrary.Enum
{
    public enum PushResult
    {
        NoPermissions = -2,
        NoChange = -1,
        Success = 0,
        CommunicationFailure,
        ResyncPerformed,
        NotConfigured,
        OtherFailure,
        UpdaterIncomplete,
        ViewTupleFailedValidation,
        TimerOutputConflict,
        TimerProductConflict,
        TimerBlowdownConflict,
        PushOkUpdateFailed,
        SlugConflict,
        RecordNumberNoMatch,
        WrongSuLevel,
        InvalidSuSource,
        FluorometerInActive,
        ControlOverrideCombinationExists
    }
}