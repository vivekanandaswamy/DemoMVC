﻿// -----------------------------------------------------------------------
// <copyright file="TcdLoggingFileTypeConverter.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TcdLoggingFileTypeConverter class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Common
{
    using System.Globalization;

    /// <summary>
    /// Enum for TcdLoggingFileType
    /// </summary>
    public enum TcdLoggingFileType : uint
    {
		None = 0,
        Sync_Batch_Data_Log = 1,
        System_Event_Log = 2,
        Alarm_Data_Log = 3
    }

    /// <summary>
    /// Tcd Logging File Type Converter
    /// </summary>
    public static class TcdLoggingFileTypeConverter
    {
        /// <summary>
        /// To String
        /// </summary>
        /// <param name="fileType">file Type</param>
        /// <returns>Returns string</returns>
        public static string ToString(TcdLoggingFileType fileType)
        {
            switch(fileType)
            {
                case TcdLoggingFileType.Sync_Batch_Data_Log:
                    return "Sync Batch Data Log";
                case TcdLoggingFileType.System_Event_Log:
                    return "Sync Queue Log";
                case TcdLoggingFileType.Alarm_Data_Log:
                    return "Tcp Host Service Log";
                default:
                    return ((uint)fileType).ToString(CultureInfo.InvariantCulture);
            }
        }
    }
}