﻿// -----------------------------------------------------------------------
// <copyright file="TcdString64.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TcdString64 </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Common
{
    using System.Runtime.InteropServices;
    using Helpers;

    [StructLayout(LayoutKind.Sequential, Size = STRINGLEN, Pack = 4)]
    public struct TcdString64
    {
        private const int STRINGLEN = 64;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = STRINGLEN)] private byte[] mUtf8Bytes;

        public string Value
        {
            get { return Utf8Helper.FromUtf8Bytes(mUtf8Bytes); }

            set { mUtf8Bytes = Utf8Helper.ToFixedLengthUtf8Bytes(value, STRINGLEN); }
        }

        public static implicit operator string(TcdString64 source)
        {
            return source.Value;
        }

        public static implicit operator TcdString64(string source)
        {
            TcdString64 dest = new TcdString64();

            dest.Value = source;

            return dest;
        }

        public override int GetHashCode()
        {
            return Value.GetHashCode();
        }

        public override string ToString()
        {
            return Value;
        }

        public override bool Equals(object obj)
        {
            if (obj is TcdString64)
            {
                return Value.Equals((TcdString64) obj);
            }
            return false;
        }
    }
}