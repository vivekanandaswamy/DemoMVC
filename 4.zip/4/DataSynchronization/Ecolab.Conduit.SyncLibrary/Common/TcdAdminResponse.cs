﻿// -----------------------------------------------------------------------
// <copyright file="TcdAdminResponse.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TcdAdminResponse </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Common
{
    using System;
    using System.Runtime.InteropServices;
    using Enums;

    /// <summary>
    ///     This structure is used for get and Re-sync Acknowledgements
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdAdminResponse
    {
        public uint AppVersion;

        public uint PayloadSize;

        public TcdAdminMessageTypes MessageType;

        public long Timestamp;

        public TcdErrCodes ErrorCode;

        public int EcolabWasherId;

        public int Id;

        public DateTime LastSyncTime;
    }
}