﻿// -----------------------------------------------------------------------
// <copyright file="TcdLoggingRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>tcd logging request </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Common
{
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdLoggingRequest
    {
        public uint PayloadSize;

        public TcdLoggingFileType LogFileType;

        public TcdString64 FileName;
    }
}