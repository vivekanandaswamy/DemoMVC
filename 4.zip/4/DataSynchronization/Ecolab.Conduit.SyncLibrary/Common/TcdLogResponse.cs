﻿// -----------------------------------------------------------------------
// <copyright file="TcdLogResponse.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TcdLogResponse </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLibrary.Common
{
    using System.Runtime.InteropServices;
    using Enum;
    using Library.Enums;

    /// <summary>
    ///     Tcd Log Response
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdLogResponse
    {
        /// <summary>
        ///     Message Type
        /// </summary>
        public TcdMessageTypes MessageType;

        /// <summary>
        ///     Time stamp
        /// </summary>
        public long Timestamp;

        /// <summary>
        ///     Error code
        /// </summary>
        public TcdErrCodes ErrorCode;
    }
}