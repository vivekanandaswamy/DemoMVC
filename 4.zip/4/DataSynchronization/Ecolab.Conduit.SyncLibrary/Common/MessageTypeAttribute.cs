﻿// -----------------------------------------------------------------------
// <copyright file="MessageTypeAttribute.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Message Type custom attribute</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Common
{
    using System;
    using Enums;

    /// <summary>
    ///     Message type custom attribute class
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class MessageTypeAttribute : Attribute
    {
        /// <summary>
        ///     Constructor for this attribute.  This attribute is used by the TcpEntityFactory
        ///     to find message entities and create the for the particular message.
        /// </summary>
        /// <param name="msgType">Message Type</param>
        public MessageTypeAttribute(TcdAdminMessageTypes msgType)
        {
            MessageType = msgType;
        }

        /// <summary>
        ///     Message Type that the class that this attribute is applied to can handle/parse.
        /// </summary>
        public TcdAdminMessageTypes MessageType { get; set; }
    }
}