﻿// -----------------------------------------------------------------------
// <copyright file="TcdLoggingResponse.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TcdLoggingResponse </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Common
{
    using System.Globalization;
    using System.Runtime.InteropServices;
    using Enums;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdLoggingResponse
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string FileName;

        /// <summary>
        ///     Error code
        /// </summary>
        public TcdErrCodes ErrorCode;

        public override string ToString()
        {
            return string.Format("TcdLoggingResponse:  FileName: {0}", FileName, CultureInfo.CurrentCulture);
        }
    }
}