﻿// -----------------------------------------------------------------------
// <copyright file="TcdAppVersion.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd App version</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Common
{
    /// <summary>
    ///     Tcd App version enum
    /// </summary>
    public enum TcdAppVersion
    {
		None = 0,
        Version1A = 1,
        VersionCurrent = 1
    }
}