﻿// -----------------------------------------------------------------------
// <copyright file="TcdFirstTimeRequestHeader.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd First Time Request Header</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Common
{
    using System;
    using System.Runtime.InteropServices;
    using Ecolab.Conduit.Library.Enums;

    /// <summary>
    ///     TcdFirstTimeRequestHeader class
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdFirstTimeRequestHeader
    {
        /// <summary>
		/// Application Current Version
		/// </summary>
		public uint AppVersion;

		/// <summary>
        /// The payload size
        /// </summary>
        public uint PayloadSize;

        /// <summary>
        /// The message format
        /// </summary>
        public TcdMessageFormatTypes MessageFormat;

        /// <summary>
        /// The timestamp
        /// </summary>
        public DateTime Timestamp;

        /// <summary>
        /// The user identifier
        /// </summary>
        public int UserId;

        /// <summary>
        /// The message type
        /// </summary>
        public TcdAdminMessageTypes MessageType;

        /// <summary>
		/// Number to fetch data in a chunk
		/// </summary>
		public uint Iterator;

        /// <summary>
        /// Offset of local timezone
        /// </summary>
        public double? OffSet;
    }
}