﻿// -----------------------------------------------------------------------
// <copyright file="TcdLogRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TcdLogRequest </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncLibrary.Common
{
    using System.Runtime.InteropServices;
    using Enum;
    using Library.Common;

    /// <summary>
    ///     Tcd Log Request
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdLogRequest
    {

		/// <summary>
		/// Application Current Version
		/// </summary>
		public uint AppVersion;

        /// <summary>
        ///     Message Type
        /// </summary>
        public TcdMessageTypes MessageType;

        /// <summary>
        ///     Payload Size
        /// </summary>
        public uint PayloadSize;

        /// <summary>
        ///     Message Format
        /// </summary>
        public TcdMessageFormatTypes MessageFormat;

        /// <summary>
        ///     User Id
        /// </summary>
        public uint UserId;

        /// <summary>
        ///     Timestamp
        /// </summary>
        public long Timestamp;

        /// <summary>
        /// Plant ID
        /// </summary>
        public uint PlantId;

        /// <summary>
        /// Request Label Size
        /// </summary>
        public uint RequestLabelSize;

        /// <summary>
        /// The number of records
        /// </summary>
        public uint NumberOfRecords;

        /// <summary>
        /// Priority
        /// </summary>
        public int Priority;
    }
}