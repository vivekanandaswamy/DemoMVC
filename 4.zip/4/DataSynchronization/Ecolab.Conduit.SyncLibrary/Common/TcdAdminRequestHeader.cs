﻿// -----------------------------------------------------------------------
// <copyright file="TcdAdminRequestHeader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TcdAdminRequestHeader </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Common
{
    using System.Runtime.InteropServices;
    using Enums;

    /// <summary>
    ///     This structure is used for all four message types (Get/Update/Push/Re-sync).
    ///     It is used for the request of those four types.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdAdminRequestHeader
    {
        public uint AppVersion;

        public TcdAdminMessageTypes MessageType;

        public uint PayloadSize;

        public uint LogoSize;

        public TcdMessageFormatTypes MessageFormat;

        public int UserId;

        public long Timestamp;
    }
}