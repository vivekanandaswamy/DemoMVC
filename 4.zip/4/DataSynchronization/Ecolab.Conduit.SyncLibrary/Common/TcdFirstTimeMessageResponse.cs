﻿// -----------------------------------------------------------------------
// <copyright file="TcdFirstTimeMessageResponse.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tcd First Time Response</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Library.Common
{
    using System;
    using System.Runtime.InteropServices;
    using Enums;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct TcdFirstTimeMessageResponse
    {
        /// <summary>
        /// Time stamp
        /// </summary>
        public DateTime Timestamp;

        /// <summary>
        /// Error code
        /// </summary>
        public TcdErrCodes ErrorCode;

        /// <summary>
        /// The payload size
        /// </summary>
        public uint PayloadSize;

        /// <summary>
        /// The message type
        /// </summary>
        public TcdAdminMessageTypes MessageType;
        /// <summary>
		/// Gets or sets NodeId
		/// </summary>
		public int NodeId;
    }
}