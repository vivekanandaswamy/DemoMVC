﻿// -----------------------------------------------------------------------
// <copyright file="SendTransportHeader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>SendTransportHeader </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Common
{
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct SendTransportHeader
    {
        /// <summary>
        ///     Version
        /// </summary>
        public uint Version;

        /// <summary>
        ///     Body
        /// </summary>
        public EcpTransportHeader Body;

        /// <summary>
        ///     ToString
        /// </summary>
        /// <returns>Returns string</returns>
        public override string ToString()
        {
            return Body.ToString();
        }
    }
}