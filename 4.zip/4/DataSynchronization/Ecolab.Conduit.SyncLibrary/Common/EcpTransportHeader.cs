﻿// -----------------------------------------------------------------------
// <copyright file="EcpTransportHeader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>EcpTransportHeader </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Library.Common
{
    using System.Globalization;
    using System.Runtime.InteropServices;
    using Enums;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public struct EcpTransportHeader
    {
        public const uint SUPPORTEDVERSION = 4;

        public ServiceType ServiceType;

        public EcpString32 ControllerId;

        public override string ToString()
        {
            return string.Format("{0}-{1}", ServiceType, ControllerId, CultureInfo.InvariantCulture);
        }
    }
}