The Batch File DBBackup_old will take the following inputs.
�DB Server Name
�DB Name
�Back up Path
�Back up Name

The Batch File DBBackup will take the following inputs.
�DB Server Name
�DB Name
�Back up Name

The Export path in the plant table will be taken as the Backuppath