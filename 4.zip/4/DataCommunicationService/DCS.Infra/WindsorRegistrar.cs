﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Ecolab.Library.Infra
{
    public class WindsorRegistrar
    {
        /// <summary>
        /// Registers singleton object
        /// </summary>
        /// <param name="interfaceType">Type of interfaceType</param>
        /// <param name="implementationType">Type of implementationType</param>
        public static void RegisterSingleton(Type interfaceType, Type implementationType)
        {
            IoC.Container.Register(Component.For(interfaceType).ImplementedBy(implementationType).LifeStyle.Singleton);
        }

        /// <summary>
        /// Register information.
        /// </summary>
        /// <param name="interfaceType">Type of interfaceType object.</param>
        /// <param name="implementationType">Type of interfaceType obejct.</param>
        public static void Register(Type interfaceType, Type implementationType)
        {
            IoC.Container.Register(Component.For(interfaceType).ImplementedBy(implementationType).LifeStyle.PerWebRequest);
        }

        /// <summary>
        /// Registers All Assemblies
        /// </summary>
        /// <param name="a">string a</param>
        public static void RegisterAllFromAssemblies(string a)
        {
            IoC.Container.Register(AllTypes.FromAssemblyNamed(a).Pick().WithService.FirstInterface().Configure(o => o.LifestylePerWebRequest()));
        }

        /// <summary>
        /// Registera All Assemblies
        /// </summary>
        /// <param name="a">string a</param>
        /// <param name="basedOn">Type of basedOn</param>
        public static void RegisterAllFromAssemblies(string a, Type basedOn)
        {
            IoC.Container.Register(AllTypes.FromAssemblyNamed(a).BasedOn(basedOn).WithService.FirstInterface().Configure(o => o.LifestylePerWebRequest()));
        }
    }
}
