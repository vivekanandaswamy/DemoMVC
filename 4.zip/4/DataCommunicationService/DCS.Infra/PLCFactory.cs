﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  Creates instance specific to the controller type.
 Author:  Pavan Sriramula
 Date Created: 05-Sep-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      06-SEP-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Library.Interfaces;
using Ecolab.Library.Services;
using Ecolab.Data.Entities;
using Ecolab.Library.Shared;


namespace Ecolab.Library.Infra
{

	public class PLCFactory : PLCCreator
	{
		//Logging Varable
		ILogService logService;
		/// <summary>
		/// PLCFactory
		/// </summary>
		public PLCFactory()
		{
			logService = new FileLogService(typeof(PLCFactory));

		}
		/// <summary>
		/// IPLCFactory
		/// </summary>
		/// <param name="strController"></param>
		/// <returns></returns>
        public override IPLCFactory CreatePLC(string strController, bool IsSimulationMode)
		{
			try
			{
                
                if (strController == Resources.PLC_AllenBradley)
                {
                    return IsSimulationMode ? new AllenBradleyPLC(IsSimulationMode) : new AllenBradleyPLC();
                }
                else if (strController == Resources.PLC_Beckhoff)
                {
                    return new BeckhoffPLC();
                }
                else if (strController == Resources.PLC_Mitsubishi)
                {
                    return new MitsubishiPLC();
                }
                else
                    throw new Exception(string.Format("NO Controller implementation found with value: '{0}'", strController));
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: PLCFactory -> CreatePLC():" + ex.StackTrace.ToString());
				return null;
			}
		}
	}
}
