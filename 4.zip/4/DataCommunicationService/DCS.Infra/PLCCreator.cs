﻿
/*  
 ************************************************************************************************************************************************************************
 Purpose:  Abstract Class to provide instances specific to the controller type.
 Author:  Pavan Sriramula
 Date Created: 05-Sep-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      06-SEP-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Web;
using Ecolab.Library.Interfaces;
using Ecolab.Data.Entities;

namespace Ecolab.Library.Infra
{
	public abstract class PLCCreator
	{
		/// <summary>
		/// CreatePLC
		/// </summary>
		/// <param name="controller"></param>
		/// <returns></returns>
		public abstract IPLCFactory CreatePLC(string strController, bool IsSimulationMode);
	}
}
