﻿
// -----------------------------------------------------------------------
// <copyright file="IoC.cs" company="Ecolab">
// TODO: Update copyright text.
// </copyright>
// <summary>The IoC object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Library.Infra
{
    using Castle.Windsor;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// IoC information.
    /// </summary>
    public static class IoC
    {
        /// <summary>
        /// Lock Parameter
        /// </summary>
        private static readonly object LockObj = new object();

        /// <summary>
        /// Container Parameter.
        /// </summary>
        private static IWindsorContainer container = new WindsorContainer();

        /// <summary>
        /// Gets or sets IWindsorContainer parameter.
        /// </summary>
        /// <value>The container.</value>
        public static IWindsorContainer Container
        {
            get
            {
                return container;
            }

            set
            {
                lock (LockObj)
                {
                    container = value;
                }
            }
        }

        /// <summary>
        /// Container resolve.
        /// </summary>
        /// <typeparam name="T">Generic Type.</typeparam>
        /// <returns>Container resolver.</returns>
        public static T Resolve<T>()
        {
            return container.Resolve<T>();
        }

        /// <summary>
        /// Container resolve.
        /// </summary>
        /// <param name="type">Type Parameter.</param>
        /// <returns>Container Resolve.</returns>
        public static object Resolve(Type type)
        {
            return container.Resolve(type);
        }
    }
}
