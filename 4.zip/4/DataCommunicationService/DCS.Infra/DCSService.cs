﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Library.Interfaces;
using Ecolab.Library.Infra;
using Ecolab.Data.Entities;
using Ecolab.Library.Shared;

namespace Ecolab.Library.Infra
{
	public class DCSService
	{
		//Logging Varable
		ILogService logService;

		/// <summary>
		/// DCSService
		/// </summary>
		public DCSService()
		{
			logService = new FileLogService(typeof(DCSService));
		}
		/// <summary>
		/// InitializeService
		/// </summary>
		/// <param name="ctrl"></param>
        //public void InitializeService(List<PLCController> ctrl)
        //{
        //    //To Do: Pavan
        //    //Get Controllers associated to the plant

        //    //List<Controller> ctrl = ControllerAccess.GetControllersByPlant(ecolabAccntNo);
        //    try
        //    {
        //        if (ctrl.Count > 0)
        //        {
                    
        //            for (int i = 0; i < ctrl.Count; i++)
        //            {
        //                PLCCreator creator = new PLCFactory();
        //                IPLCFactory ObjPLC = creator.CreatePLC(ctrl[i].controllerType.ToString());
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        logService.LogError("Error Occurred at class: DCSService -> InitializeService():" + ex.StackTrace.ToString());

        //    }

        //    //To Do: Pavan
        //    //Based on the controller create PLCClient
        //    //PLCCreator creator = new PLCFactory();
        //    //IPLCFactory ObjPLC = creator.CreatePLC(Controllers[i].Item1, Controllers[i].Item2);
        //}
	}
}
