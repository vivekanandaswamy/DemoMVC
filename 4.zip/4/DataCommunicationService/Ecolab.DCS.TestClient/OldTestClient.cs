﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ecolab.Library.Interfaces;
using Ecolab.Library.Infra;
using System.Configuration;
using System.Collections.Specialized;
using Ecolab.Data.Access;
using Ecolab.Library.Shared;
using System.ServiceModel;
using System.Web;


namespace Ecolab.DCS.TestClient
{
	/// <summary>
	/// 
	/// </summary>
	public partial class OldTestClient : Form
	{
		//Logging Varable
		ILogService logService;
		/// <summary>
		/// TestClientForm
		/// </summary>
		public OldTestClient()
		{
			InitializeComponent();
			logService = new FileLogService(typeof(OldTestClient));
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				//This code would move to service
				//DCSService svc = new DCSService();
				string[] configKeys = new string[2] { "ConnectionString", "ecolabAccountNo" };
				List<Tuple<string, string>> configKeyValues = new List<Tuple<string, string>>();
				int ecolabAccntNo;
				configKeyValues = GetConfigKey(configKeys);
				Database.InitializeConnection(configKeyValues[0].Item2.ToString());
				ecolabAccntNo = int.Parse(configKeyValues[1].Item2.ToString());
				List<Ecolab.Data.Entities.PLCController> ctrl = PlantAccess.GetControllersByPlant(ecolabAccntNo);
				InitializeService(ctrl);
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at: Form1 -> button1_Click():" + ex.StackTrace.ToString());
			}
		}

		public void InitializeService(List<Ecolab.Data.Entities.PLCController> ctrl)
		{
			//To Do: Pavan
			//Get Controllers associated to the plant

			//List<Controller> ctrl = ControllerAccess.GetControllersByPlant(ecolabAccntNo);
			try
			{
				if (ctrl.Count > 0)
				{
					for (int i = 0; i < ctrl.Count; i++)
					{
						PLCCreator creator = new PLCFactory();
						IPLCFactory ObjPLC = creator.CreatePLC(ctrl[i].controllerType.ToString());
						ObjPLC.InitializePLCContinuousRead(ctrl[i]);
					}
				}

			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: DCSService -> InitializeService():" + ex.StackTrace.ToString());

			}

			//To Do: Pavan
			//Based on the controller create PLCClient
			//PLCCreator creator = new PLCFactory();
			//IPLCFactory ObjPLC = creator.CreatePLC(Controllers[i].Item1, Controllers[i].Item2);
		}

		/// <summary>
		/// GetConfigKey: Returns the config keys defined in the Configuration file.
		/// </summary>
		/// <param name="keysTofind"></param>
		/// <returns></returns>
		private List<Tuple<string, string>> GetConfigKey(string[] keysTofind)
		{
			try
			{
				//This method would be moved to service.
				List<Tuple<string, string>> ctrlObj = new List<Tuple<string, string>>();
                NameValueCollection appSettings = ConfigurationSettings.AppSettings;
                    //ConfigurationManager.AppSettings;
				for (int i = 0; i < keysTofind.Count(); i++)
				{
					foreach (string ctrl in appSettings.AllKeys)
					{
						if (ctrl.StartsWith(keysTofind[i]))
						{
							ctrlObj.Add(Tuple.Create<string, string>(ctrl[1].ToString(), appSettings[ctrl]));
						}
					}
				}
				return ctrlObj;
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at: Form1 -> GetConfigKey():" + ex.StackTrace.ToString());
				return null;
			}
		}
	}
}
