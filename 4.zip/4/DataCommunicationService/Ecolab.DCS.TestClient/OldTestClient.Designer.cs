﻿namespace Ecolab.DCS.TestClient
{
    partial class OldTestClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_WinService = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_WinService
            // 
            this.btn_WinService.Location = new System.Drawing.Point(67, 63);
            this.btn_WinService.Name = "btn_WinService";
            this.btn_WinService.Size = new System.Drawing.Size(132, 39);
            this.btn_WinService.TabIndex = 0;
            this.btn_WinService.Text = "Invoke Windows Service";
            this.btn_WinService.UseVisualStyleBackColor = true;
            this.btn_WinService.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_WinService);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_WinService;
    }
}

