﻿namespace Ecolab.DCS.TestClient
{
    partial class WebClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnWriteTag = new System.Windows.Forms.Button();
            this.btnValidateTag = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTagValue = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnWriteTag
            // 
            this.btnWriteTag.Location = new System.Drawing.Point(75, 207);
            this.btnWriteTag.Name = "btnWriteTag";
            this.btnWriteTag.Size = new System.Drawing.Size(75, 23);
            this.btnWriteTag.TabIndex = 0;
            this.btnWriteTag.Text = "Write Tag Data";
            this.btnWriteTag.UseVisualStyleBackColor = true;
            this.btnWriteTag.Click += new System.EventHandler(this.btnWriteTag_Click);
            // 
            // btnValidateTag
            // 
            this.btnValidateTag.Location = new System.Drawing.Point(205, 206);
            this.btnValidateTag.Name = "btnValidateTag";
            this.btnValidateTag.Size = new System.Drawing.Size(84, 24);
            this.btnValidateTag.TabIndex = 1;
            this.btnValidateTag.Text = "Validate Tag";
            this.btnValidateTag.UseVisualStyleBackColor = true;
            this.btnValidateTag.Click += new System.EventHandler(this.btnValidateTag_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Here you will see the status of your actions.";
            // 
            // txtTagValue
            // 
            this.txtTagValue.Location = new System.Drawing.Point(178, 57);
            this.txtTagValue.Name = "txtTagValue";
            this.txtTagValue.Size = new System.Drawing.Size(100, 20);
            this.txtTagValue.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tag Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tag Value";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(178, 93);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(178, 129);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(146, 71);
            this.textBox1.TabIndex = 7;
            // 
            // WebClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 242);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTagValue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnValidateTag);
            this.Controls.Add(this.btnWriteTag);
            this.Name = "WebClient";
            this.Text = "WebClient";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnWriteTag;
        private System.Windows.Forms.Button btnValidateTag;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTagValue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }
}