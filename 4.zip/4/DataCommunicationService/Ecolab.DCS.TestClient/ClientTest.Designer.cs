﻿namespace Ecolab.DCS.TestClient
{
    partial class ClientTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnectToOPC = new System.Windows.Forms.Button();
            this.cmbOPCServer = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnConnectToOPC
            // 
            this.btnConnectToOPC.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnConnectToOPC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConnectToOPC.Location = new System.Drawing.Point(108, 139);
            this.btnConnectToOPC.Name = "btnConnectToOPC";
            this.btnConnectToOPC.Size = new System.Drawing.Size(99, 31);
            this.btnConnectToOPC.TabIndex = 0;
            this.btnConnectToOPC.Text = "Connect To OPC";
            this.btnConnectToOPC.UseVisualStyleBackColor = false;
            this.btnConnectToOPC.Click += new System.EventHandler(this.btnConnectToOPC_Click);
            // 
            // cmbOPCServer
            // 
            this.cmbOPCServer.FormattingEnabled = true;
            this.cmbOPCServer.Items.AddRange(new object[] {
            "Matrikon.OPC.AllenBradley",
            "Matrikon.OPC.Simulation",
            "Matrikon.OPC.Simulation.1",
            "RSLinx OPC Server",
            "RSLinx Remote OPC Server"});
            this.cmbOPCServer.Location = new System.Drawing.Point(108, 64);
            this.cmbOPCServer.Name = "cmbOPCServer";
            this.cmbOPCServer.Size = new System.Drawing.Size(140, 21);
            this.cmbOPCServer.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "OPC Server ";
            // 
            // ClientTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(322, 250);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbOPCServer);
            this.Controls.Add(this.btnConnectToOPC);
            this.Name = "ClientTest";
            this.Text = "OPC Connector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnectToOPC;
        private System.Windows.Forms.ComboBox cmbOPCServer;
        private System.Windows.Forms.Label label1;
    }
}