﻿using Ecolab.Data.Access;
using Ecolab.Library.Infra;
using Ecolab.Library.Interfaces;
using Ecolab.Library.Shared;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.ServiceModel;
using System.Web;

namespace Ecolab.DCS.TestClient
{
    public partial class ClientTest : Form
    {
        //Logging Varable
        ILogService logService;
        bool IsSimulationMode = true;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public ClientTest()
        {
            InitializeComponent();
            logService = new FileLogService(typeof(ClientTest));
        }


        private void btnConnectToOPC_Click(object sender, EventArgs e)
        {
            try
            {
                string[] configKeys = new string[2] { "ConnectionString", "ecolabAccountNo" };
                List<Tuple<string, string>> configKeyValues = new List<Tuple<string, string>>();
                int ecolabAccntNo;
                configKeyValues = GetConfigKey(configKeys);
                Database.InitializeConnection(configKeyValues[0].Item2.ToString());
                ecolabAccntNo = int.Parse(configKeyValues[1].Item2.ToString());
                List<Ecolab.Data.Entities.PLCController> ctrl = PlantAccess.GetControllersByPlant(ecolabAccntNo);
                IsSimulationMode = !cmbOPCServer.SelectedItem.ToString().Contains("RSLinx");
                InitializeService(ctrl);
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at: Form1 -> button1_Click():" + ex.StackTrace.ToString());
            }
        }
        public void InitializeService(List<Ecolab.Data.Entities.PLCController> ctrl)
        {
            //To Do: Pavan
            //Get Controllers associated to the plant

            //List<Controller> ctrl = ControllerAccess.GetControllersByPlant(ecolabAccntNo);
            try
            {
                if (ctrl.Count > 0)
                {
                    for (int i = 0; i < ctrl.Count; i++)
                    {
                        PLCCreator creator = new PLCFactory();
                        IPLCFactory ObjPLC = creator.CreatePLC(ctrl[i].controllerType.ToString(), IsSimulationMode);
                        ObjPLC.InitializePLCContinuousRead(ctrl[i]);
                    }
                }

            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: DCSService -> InitializeService():" + ex.StackTrace.ToString());

            }
        }

        /// <summary>
        /// GetConfigKey: Returns the config keys defined in the Configuration file.
        /// </summary>
        /// <param name="keysTofind"></param>
        /// <returns></returns>
        private List<Tuple<string, string>> GetConfigKey(string[] keysTofind)
        {
            try
            {
                //This method would be moved to service.
                List<Tuple<string, string>> ctrlObj = new List<Tuple<string, string>>();
                NameValueCollection appSettings = ConfigurationManager.AppSettings;
                for (int i = 0; i < keysTofind.Count(); i++)
                {
                    foreach (string ctrl in appSettings.AllKeys)
                    {
                        if (ctrl.StartsWith(keysTofind[i]))
                        {
                            ctrlObj.Add(Tuple.Create<string, string>(ctrl[1].ToString(), appSettings[ctrl]));
                        }
                    }
                }
                return ctrlObj;
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at: Form1 -> GetConfigKey():" + ex.StackTrace.ToString());
                return null;
            }
        }

       
    }
}
