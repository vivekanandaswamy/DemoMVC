﻿namespace Ecolab.DCS.TestClient
{
    partial class AllenAllenBradleyTester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnectPLC = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtWasherID = new System.Windows.Forms.TextBox();
            this.btnWriteTest = new System.Windows.Forms.Button();
            this.btnReadTest = new System.Windows.Forms.Button();
            this.btnBatchSimulator = new System.Windows.Forms.Button();
            this.btnWebPortSimulator = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtOpCount = new System.Windows.Forms.TextBox();
            this.txtFormula = new System.Windows.Forms.TextBox();
            this.txtInjection = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.txtCurrentDay = new System.Windows.Forms.TextBox();
            this.txtCurrentMonth = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCurrentYear = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.bntConnectPLC = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnConnectPLC
            // 
            this.btnConnectPLC.Location = new System.Drawing.Point(71, 252);
            this.btnConnectPLC.Name = "btnConnectPLC";
            this.btnConnectPLC.Size = new System.Drawing.Size(96, 23);
            this.btnConnectPLC.TabIndex = 0;
            this.btnConnectPLC.Text = "Connect To PLC";
            this.btnConnectPLC.UseVisualStyleBackColor = true;
            this.btnConnectPLC.Click += new System.EventHandler(this.btnConnectPLC_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "WasherID";
            // 
            // txtWasherID
            // 
            this.txtWasherID.Location = new System.Drawing.Point(211, 38);
            this.txtWasherID.Name = "txtWasherID";
            this.txtWasherID.Size = new System.Drawing.Size(100, 20);
            this.txtWasherID.TabIndex = 2;
            // 
            // btnWriteTest
            // 
            this.btnWriteTest.Location = new System.Drawing.Point(208, 252);
            this.btnWriteTest.Name = "btnWriteTest";
            this.btnWriteTest.Size = new System.Drawing.Size(75, 23);
            this.btnWriteTest.TabIndex = 3;
            this.btnWriteTest.Text = "Write Test";
            this.btnWriteTest.UseVisualStyleBackColor = true;
            this.btnWriteTest.Click += new System.EventHandler(this.btnWriteTest_Click);
            // 
            // btnReadTest
            // 
            this.btnReadTest.Location = new System.Drawing.Point(350, 252);
            this.btnReadTest.Name = "btnReadTest";
            this.btnReadTest.Size = new System.Drawing.Size(75, 23);
            this.btnReadTest.TabIndex = 4;
            this.btnReadTest.Text = "Read Test";
            this.btnReadTest.UseVisualStyleBackColor = true;
            this.btnReadTest.Click += new System.EventHandler(this.btnReadTest_Click);
            // 
            // btnBatchSimulator
            // 
            this.btnBatchSimulator.Location = new System.Drawing.Point(71, 301);
            this.btnBatchSimulator.Name = "btnBatchSimulator";
            this.btnBatchSimulator.Size = new System.Drawing.Size(103, 23);
            this.btnBatchSimulator.TabIndex = 5;
            this.btnBatchSimulator.Text = "BatchSimulator ";
            this.btnBatchSimulator.UseVisualStyleBackColor = true;
            // 
            // btnWebPortSimulator
            // 
            this.btnWebPortSimulator.Location = new System.Drawing.Point(208, 301);
            this.btnWebPortSimulator.Name = "btnWebPortSimulator";
            this.btnWebPortSimulator.Size = new System.Drawing.Size(103, 23);
            this.btnWebPortSimulator.TabIndex = 6;
            this.btnWebPortSimulator.Text = "WebPortSimulator ";
            this.btnWebPortSimulator.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "OpCount";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(84, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Formula";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Injection";
            // 
            // txtOpCount
            // 
            this.txtOpCount.Location = new System.Drawing.Point(211, 77);
            this.txtOpCount.Name = "txtOpCount";
            this.txtOpCount.Size = new System.Drawing.Size(100, 20);
            this.txtOpCount.TabIndex = 12;
            // 
            // txtFormula
            // 
            this.txtFormula.Location = new System.Drawing.Point(211, 107);
            this.txtFormula.Name = "txtFormula";
            this.txtFormula.Size = new System.Drawing.Size(100, 20);
            this.txtFormula.TabIndex = 13;
            // 
            // txtInjection
            // 
            this.txtInjection.Location = new System.Drawing.Point(211, 145);
            this.txtInjection.Name = "txtInjection";
            this.txtInjection.Size = new System.Drawing.Size(100, 20);
            this.txtInjection.TabIndex = 14;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(473, 158);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 24;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(473, 129);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 23;
            // 
            // txtCurrentDay
            // 
            this.txtCurrentDay.Location = new System.Drawing.Point(473, 100);
            this.txtCurrentDay.Name = "txtCurrentDay";
            this.txtCurrentDay.Size = new System.Drawing.Size(100, 20);
            this.txtCurrentDay.TabIndex = 22;
            // 
            // txtCurrentMonth
            // 
            this.txtCurrentMonth.Location = new System.Drawing.Point(473, 70);
            this.txtCurrentMonth.Name = "txtCurrentMonth";
            this.txtCurrentMonth.Size = new System.Drawing.Size(100, 20);
            this.txtCurrentMonth.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(351, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Current Minute";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(351, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Current Hour";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(351, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Current Day";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(351, 73);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Current Month";
            // 
            // txtCurrentYear
            // 
            this.txtCurrentYear.Location = new System.Drawing.Point(473, 35);
            this.txtCurrentYear.Name = "txtCurrentYear";
            this.txtCurrentYear.Size = new System.Drawing.Size(100, 20);
            this.txtCurrentYear.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(351, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "Current Year";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(473, 188);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 20);
            this.textBox11.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(351, 195);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "Current Second";
            // 
            // bntConnectPLC
            // 
            this.bntConnectPLC.Location = new System.Drawing.Point(357, 301);
            this.bntConnectPLC.Name = "bntConnectPLC";
            this.bntConnectPLC.Size = new System.Drawing.Size(75, 23);
            this.bntConnectPLC.TabIndex = 27;
            this.bntConnectPLC.Text = "DisconnectPLC";
            this.bntConnectPLC.UseVisualStyleBackColor = true;
            this.bntConnectPLC.Click += new System.EventHandler(this.bntConnectPLC_Click);
            // 
            // AllenAllenBradleyTester
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 336);
            this.Controls.Add(this.bntConnectPLC);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.txtCurrentDay);
            this.Controls.Add(this.txtCurrentMonth);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtCurrentYear);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtInjection);
            this.Controls.Add(this.txtFormula);
            this.Controls.Add(this.txtOpCount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnWebPortSimulator);
            this.Controls.Add(this.btnBatchSimulator);
            this.Controls.Add(this.btnReadTest);
            this.Controls.Add(this.btnWriteTest);
            this.Controls.Add(this.txtWasherID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnConnectPLC);
            this.Name = "AllenAllenBradleyTester";
            this.Text = "Allen Bradley Tester ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnectPLC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtWasherID;
        private System.Windows.Forms.Button btnWriteTest;
        private System.Windows.Forms.Button btnReadTest;
        private System.Windows.Forms.Button btnBatchSimulator;
        private System.Windows.Forms.Button btnWebPortSimulator;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtOpCount;
        private System.Windows.Forms.TextBox txtFormula;
        private System.Windows.Forms.TextBox txtInjection;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox txtCurrentDay;
        private System.Windows.Forms.TextBox txtCurrentMonth;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCurrentYear;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bntConnectPLC;
    }
}

