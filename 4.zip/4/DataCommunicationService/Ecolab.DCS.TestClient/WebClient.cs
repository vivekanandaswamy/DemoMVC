﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EcolabPlc.WebClient.ServiceReference1;
using Ecolab.DCS.TestClient.ServiceReference2;
using Ecolab.Data.Entities;
using System.Threading;
using System.ServiceModel;
using Ecolab.Library.Shared;

namespace Ecolab.DCS.TestClient
{

    public class CallBack : EcolabPlc.WebClient.ServiceReference1.IWritePLCServiceCallback
    {


        public string Message
        {
            get;
            set;
        }

        public void IsWriteSuccessful(bool isSuccess, string tagWritten)
        {
            Thread.Sleep(5000);
            if (isSuccess)
                this.Message = "Received and written Values:" + tagWritten;
            else
                this.Message = "Faile to write Tag:" + tagWritten;

        }
    }
    public partial class WebClient : Form
    {
        ILogService logService;
        static CallBack callback;
        public WebClient()
        {
            InitializeComponent();
        }

        private void btnWriteTag_Click(object sender, EventArgs e)
        {          
            List<Tuple<string, string>> writetagValues = new List<Tuple<string, string>>();
            writetagValues.Add(new Tuple<string, string>("T1_SIZ", "2"));
            writetagValues.Add(new Tuple<string, string>("T1_DEV", "687"));
            WriteToPLC(writetagValues, 125);
        }

        public void WriteToPLC(List<Tuple<string, string>> tagsValues, int controllerId)
        {
            try
            {
                callback = new CallBack();
                InstanceContext ic = new InstanceContext(callback);
                WritePLCServiceClient a = new WritePLCServiceClient(ic);              
                a.WritePLCData(tagsValues, controllerId, "AllenBradley");
            }
            catch (System.Exception ex)
            {
                logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
            }

        }

        private void btnValidateTag_Click(object sender, EventArgs e)
        {
            List<ConduitTag> validTags = new List<ConduitTag>();
            ConduitTag CTag;
            string[] strTags = new string[2] { "N7:0", "N7:1" };
            for (int i = 0; i < 2; i++)
            {
                CTag = new ConduitTag();
                CTag.TagName = strTags[i];
                validTags.Add(CTag);
            }
            ValidateTagsList(validTags, 125);
        }
        private void ValidateTagsList(List<ConduitTag> validTags, int controllerId)
        {
            StringBuilder returnNumber = new StringBuilder();
            try
            {
                callback = new CallBack();
                InstanceContext ic = new InstanceContext(callback);
                WritePLCServiceClient a = new WritePLCServiceClient(ic);

                var res = a.ValidateTags(validTags, controllerId);
                string y = null;
                for (int i = 0; i < res.Count; i++)
                {
                    y = returnNumber.AppendLine(res[i].TagName + " " + res[i].TagValue + "" + res[i].IsValidTag + "" + res[i].ExceptionCode).ToString();
                }

                textBox1.Text = y;

            }
            catch (System.Exception ex)
            {
                //Response.Write(ex.InnerException);
                logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
            }
        }
    }
}
