﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.DCS.TestClient
{
    public partial class DCSTestClient : Form
    {
        public DCSTestClient()
        {
            InitializeComponent();
        }

        private void tsMenuPLCTestSimulation_Click(object sender, EventArgs e)
        {
            AllenAllenBradleyTester abTest = new AllenAllenBradleyTester();
            abTest.Show();
        }

        private void tsMenDCSClient_Click(object sender, EventArgs e)
        {
            ClientTest clientTest = new ClientTest();
            clientTest.Show();
        }

        private void tsMenuDCSWebClient_Click(object sender, EventArgs e)
        {
            WebClient webClientTesting = new WebClient();
            webClientTesting.Show();
        }
    }
}
