﻿using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using OPCAutomation;
using System;

namespace Ecolab.DCS.TestClient
{
    public partial class AllenAllenBradleyTester  : Form
    {
        public string OPCServerName = "Matrikon.OPC.Simulation";
        public bool PLCConnected = false;
        public bool ReadEvent = false;
        public int[] cH = new int[2] { 1, 2 };
        private OPCServer OPCMyServer;
        private OPCGroups OPCMyGroups;
        private OPCGroup OPCMyGroup;
        private System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();       
        Array OPCItemIDs = Array.CreateInstance(typeof(string), 10);
        Array ItemServerHandles = Array.CreateInstance(typeof(Int32), 10);
        Array ItemServerErrors = Array.CreateInstance(typeof(Int32), 10);
        Array ClientHandles = Array.CreateInstance(typeof(Int32), 10);
        Array RequestedDataTypes = Array.CreateInstance(typeof(Int16), 10);
        Array AccessPaths = Array.CreateInstance(typeof(string), 10);
        Array WriteItems = Array.CreateInstance(typeof(object), 10);

        public AllenAllenBradleyTester()
        {
            InitializeComponent();
            //t.Tick += new EventHandler(tm_Tick);
            //t.Interval = 10000;// GetInterval(); //1000;
            //t.Enabled = true;
        }       
        

        private void btnConnectPLC_Click(object sender, EventArgs e)
        {
           ConnectToPLC();
        }
        
        private void ObjOPCGroup_DataChange(int transactionID, int numItems, ref Array clientHandles, ref Array itemValues, ref Array qualities, ref Array timeStamps)
        {
            try
            {
                txtInjection.Text = "1";
                txtOpCount.Text = "1";
                //txtFrequency.Text = "2";
                //txtTimeTags.Text = "12:04";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        public int GetInterval()
        {
            DateTime now = DateTime.Now;
            int i = ((60 - now.Second) * 1000 - now.Millisecond);
            return i;
        }

        void tm_Tick(object sender, EventArgs e)
        {
            try
            {

                OPCMyGroup.IsActive = true;
                int ItemCount = 2;
                OPCMyGroup.OPCItems.DefaultIsActive = true;
                OPCItemIDs.SetValue("Unit1.T1_SIZ", 1);
                ClientHandles.SetValue(1, 1);
                OPCItemIDs.SetValue("Unit1.T1_DEV", 2);
                OPCMyGroup.OPCItems.AddItems(ItemCount, OPCItemIDs, ref ClientHandles, out ItemServerHandles, out ItemServerErrors, RequestedDataTypes, AccessPaths);
                ClientHandles.SetValue(2, 2);
                OPCMyGroup.IsSubscribed = OPCMyGroup.IsActive;
                OPCMyGroup.SyncWrite(ItemCount, ref ItemServerHandles, ref WriteItems, out ItemServerErrors);
                MessageBox.Show("Write Successfull. . .");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        public void ConnectToPLC()
        {
            try
            {
                if (!PLCConnected)
                {
                    //--- connect OPCServer
                    OPCMyServer = new OPCServer();
                    OPCMyServer.Connect(OPCServerName, "localhost");
                    OPCMyGroups = OPCMyServer.OPCGroups;
                    OPCMyGroup = OPCMyServer.OPCGroups.Add("Unit1");
                    OPCMyGroup.IsSubscribed = true;
                    OPCMyGroup.IsActive = false;
                    OPCMyGroup.DataChange += new DIOPCGroupEvent_DataChangeEventHandler(ObjOPCGroup_DataChange);

                    OPCMyGroup.UpdateRate = 1000;
                    // "New Alias 2.VarString", "New Alias 2.VarInt2"

                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnReadTest_Click(object sender, EventArgs e)
        {
            object Qualities;
            object Timestamps;

            try
            {
                OPCMyGroup.IsActive = true;
                OPCMyGroup.IsSubscribed = OPCMyGroup.IsActive;                
                OPCMyGroup.SyncRead((short)OPCAutomation.OPCDataSource.OPCDevice, 2, ref ItemServerHandles, out OPCItemIDs, out ItemServerErrors, out Qualities, out Timestamps);
                MessageBox.Show("Read Successfull. . .");
                txtFormula.Text = OPCItemIDs.GetValue(7).ToString();
                txtInjection.Text = OPCItemIDs.GetValue(0).ToString();
                txtOpCount.Text = OPCItemIDs.GetValue(0).ToString();
                //txtTimeTag.Text = OPCItemIDs.GetValue(2).ToString();
                txtWasherID.Text = OPCItemIDs.GetValue(32).ToString();

            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWriteTest_Click(object sender, EventArgs e)
        {
            try
            {
                OPCMyGroup.SyncWrite(2, ref ItemServerHandles, ref WriteItems, out ItemServerErrors);
                MessageBox.Show("Write Successfull. . .");

            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bntConnectPLC_Click(object sender, EventArgs e)
        {
            try
            {
                OPCMyServer.Disconnect();
                MessageBox.Show("Server Disconnected. You will now stop receiving any further data from PLC", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnConnectPLC.Enabled = true;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       
    }
}
