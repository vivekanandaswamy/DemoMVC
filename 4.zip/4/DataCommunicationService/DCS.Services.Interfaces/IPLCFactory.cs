﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  Interface tp provide instance specific to the controller type.
 Author:  Pavan Sriramula
 Date Created: 05-Sep-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      06-SEP-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using Ecolab.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Ecolab.Data.Entities;

namespace Ecolab.Library.Interfaces
{
    [ServiceContract]
    public interface IPLCFactory
    {
        /// <summary>
        /// For the Service to keep track of the tags and perform further actions based on the entire tag list it has.
        /// </summary>
        /// <param name="TagToRead"></param>
        [OperationContract]
        void ReadAllPLCTags(List<Tuple<string, int, string, string>> tagsToRead, string node, bool isPLCRequest);
        /// <summary>
        /// InitializeCntinuousRead: This is for the windows service to automatically read the PLC Tags continuously.
        /// </summary>
        /// <param name="ABCtrl"></param>
        [OperationContract]
        void InitializePLCContinuousRead(PLCController abCtrl);
        [OperationContract]
        void InitializeXMLContinuousRead(PLCController abCtrl);
        /// <summary>
        /// RequestRead: For the external applications to read the requested tags
        /// </summary>
        /// <param name="TagsToRead"></param>
        /// <param name="Node"></param> 
        [OperationContract]
        void RequestRead(List<Tuple<string, int>> tagsToRead, string node);
        /// <summary>
        /// WriteToPLC: For the service to write back the values to the PLC.
        /// </summary>
        /// <param name="TagsValues"></param>
        [OperationContract]
        void WriteToPLC(List<Tuple<string, string>> tagsValues, int controllerId);

        /// <summary>
        ///ValidateTags
        /// </summary>
        /// <param name="validTag"></param>
        /// <param name="controllerId"></param>
        /// <returns></returns>
        [OperationContract]
        List<ConduitTag> ValidateTags(List<ConduitTag> validTag, int controllerId);

    }
}
