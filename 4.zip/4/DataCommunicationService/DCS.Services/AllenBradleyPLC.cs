﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  OPC Client for Alllen Bradley PLC Controllers.
 Author:  Pavan Sriramula
 Date Created: 05-Sep-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      06-SEP-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Ecolab.Library.Interfaces;
using Ecolab.Data.Entities;
using Ecolab.Data.Access;
using Ecolab.Data.Access.Properties;
using OPCAutomation;
using System.Diagnostics;
using Ecolab.Library.Shared;
using System.Xml;
using System.Text.RegularExpressions;
using System.Collections.Specialized;
using System.Configuration;
using Ecolab.Data.Entities.Batch;
using Ecolab.Library.Services.Batch;

namespace Ecolab.Library.Services
{
    public class AllenBradleyPLC : IPLCFactory
    {
        # region Variables
             
        private OPCServer RsLnxOPCServer;
        private OPCGroups RsOPCGroups;
        private OPCGroup OPCNode;
        private string RsGroupName;

        //Parameters to Read    
        private List<Tuple<string, int, string, string>> CurrentTagsList = null;
        private List<Tuple<string, int, string, string>> prm_NowTags;
        private List<Tuple<string, int, string, string>> prm_WasherTags;
        private List<Tuple<string, int, string, string>> prm_ModuleTags;

        Array OPCItemIDs = null;
        Array ItemServerHandles = null;
        Array ItemServerErrors = null;
        Array ClientHandles = null;
        Array RequestedDataTypes = null;
        Array AccessPaths = null;
        Array WriteItems = null;
        WasherTag CurrentWasherTag = null;
        List<WasherTag> AllWashers = new List<WasherTag>();
        BatchQueue<WasherTag> ActiveBatches = new BatchQueue<WasherTag>();
        BatchQueue<Tuple<int, int>> AllBatches = new BatchQueue<Tuple<int, int>>();
        bool SimulationMode = false;
        //Logging Varable
        ILogService logService;

        # endregion Variables

        /// <summary>
        /// AllenBradleyPLC
        /// </summary>
        /// <param name="ABCtrl"></param>
        public AllenBradleyPLC()
        {
            try
            {
                logService = new FileLogService(typeof(AllenBradleyPLC));
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> AllenBradleyPLC():" + ex.StackTrace.ToString());
            }
        }
        public AllenBradleyPLC(bool SimulationMode)
        {
            try
            {
                this.SimulationMode = SimulationMode;
                logService = new FileLogService(typeof(AllenBradleyPLC));
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> AllenBradleyPLC():" + ex.StackTrace.ToString());
            }
        }

      
        
        private enum ExceptionCode
        {
            InvalidTag,
            TagNotExists,
            InvalidNode,
            NodeNotExists,
            AccessViloationException
        }
        /// <summary>
        /// MultipleRead
        /// </summary>
        /// <param name="tagsToRead"></param>
        public void ContinuousPLCRead(List<Tuple<string, int, string, string>> tagsToRead, string node)
        {
            object Qualities;
            object Timestamps;

            Array Cont_OPCItemIDs = Array.CreateInstance(typeof(string), tagsToRead.Count + 1);
            Array Cont_ItemServerHandles = Array.CreateInstance(typeof(int), tagsToRead.Count + 1);
            Array Cont_ItemServerErrors = Array.CreateInstance(typeof(int), tagsToRead.Count);
            Array Cont_ClientHandles = Array.CreateInstance(typeof(int), tagsToRead.Count + 1);
            Array Cont_RequestedDataTypes = Array.CreateInstance(typeof(short), tagsToRead.Count);
            Array Cont_AccessPaths = Array.CreateInstance(typeof(string), tagsToRead.Count);
            Array Cont_WriteItems = Array.CreateInstance(typeof(object), tagsToRead.Count);
            string sourceXml = string.Empty;

            string[] TagValues = new string[tagsToRead.Count];
            try
            {
                for (int i = 0; i < tagsToRead.Count; i++)
                {
                    Cont_OPCItemIDs.SetValue(node + tagsToRead[i].Item1, i + 1);
                    CurrentTagsList = tagsToRead;
                    Cont_ClientHandles.SetValue(i + 1, i + 1);
                }
                OPCNode.OPCItems.DefaultIsActive = true;
                OPCNode.OPCItems.AddItems(tagsToRead.Count, Cont_OPCItemIDs, ref Cont_ClientHandles, out Cont_ItemServerHandles, out Cont_ItemServerErrors, Cont_RequestedDataTypes, Cont_AccessPaths);

                OPCNode.IsActive = true;
                OPCNode.IsSubscribed = OPCNode.IsActive;
                OPCNode.SyncRead((short)OPCAutomation.OPCDataSource.OPCDevice, tagsToRead.Count + 1, ref Cont_ItemServerHandles, out Cont_OPCItemIDs, out Cont_ItemServerErrors, out Qualities, out Timestamps);

                //sending the table name has to be revisited and has to be retrieved dynamically in the DB Object (SP) based on the Tag.
                sourceXml = ConvertToXml(Cont_OPCItemIDs, tagsToRead, "controllerTagValues");
                if (sourceXml.Trim() != "")
                    SaveDataToDB(sourceXml);
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> MultipleRead():" + ex.StackTrace.ToString());
            }
        }

        private void ProcessBatchTags(List<Tuple<string, int, string, string>> currentTagsList, List<Tuple<string, string>> values)
        {
            try
            {
                CurrentWasherTag = new WasherTag();
                List<string> UpdatedObjects = new List<string>();
                for (int i = 0; i < values.Count; i++)
                {
                    var res = CurrentTagsList.ElementAt(Convert.ToInt32(values[i].Item1) - 1);
                    UpdatedObjects.Add(res.Item3.Trim());
                    //Fetch the Washer Id
                    CurrentWasherTag.WasherGroup = res.Item4.StartsWith(WasherType.Conventional.ToString()) ? WasherType.Conventional.ToString() : (res.Item4.StartsWith(WasherType.Tunnel.ToString()) ? WasherType.Tunnel.ToString() : "");
                    CurrentWasherTag.WasherId = Convert.ToInt32(res.Item4.Replace(CurrentWasherTag.WasherGroup + " " + TagType.Washer.ToString(), ""));


                    //Get the run time tag values
                    if (res.Item3.ToString().Trim() == Resources.WasherCurrentFormula)
                        CurrentWasherTag.CurrentFormula = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherCurrentInjection)
                        CurrentWasherTag.CurrentInjection = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherCurrentOperationCounter)
                        CurrentWasherTag.OperationCounter = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherAWEFormula)
                        CurrentWasherTag.AWEFormula = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherEOFSignal)
                        CurrentWasherTag.EOFSignal = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherMode)
                        CurrentWasherTag.Mode = values[i].Item2;
                    if (res.Item3.ToString().Trim() == Resources.WasherFlushTime)
                        CurrentWasherTag.FlushTime = values[i].Item2;
                    if (res.Item3.ToString().Trim() == Resources.WasherInjectionClass)
                        CurrentWasherTag.InjectionClass = values[i].Item2;
                    if (res.Item3.ToString().Trim() == Resources.WasherInjectionRatio)
                        CurrentWasherTag.InjectionRatio = values[i].Item2;
                    if (res.Item3.ToString().Trim() == Resources.WasherOnHold)
                        CurrentWasherTag.OnHold = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherAWEActive)
                        CurrentWasherTag.AWEActive = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherHoldDelay)
                        CurrentWasherTag.HoldDelay = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherRatioDosingActive)
                        CurrentWasherTag.RatioDosingActive = Convert.ToInt32(values[i].Item2);
                    if (res.Item3.ToString().Trim() == Resources.WasherRatioDosingPercentage)
                        CurrentWasherTag.RatioDosingPercentage = values[i].Item2;
                    if (res.Item3.ToString().Trim() == Resources.WasherNumber)
                        CurrentWasherTag.WasherNumber = Convert.ToInt32(values[i].Item2);

                }

                if (CurrentWasherTag.WasherGroup == WasherType.Conventional.ToString())
                {
                    ProcessConventionalBatch(CurrentWasherTag, UpdatedObjects);
                }
                else if (CurrentWasherTag.WasherGroup == WasherType.Tunnel.ToString())
                    ProcessTunnelBatch(CurrentWasherTag, UpdatedObjects);

            }
            catch (System.Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> SaveToDB():" + ex.StackTrace.ToString());
            }

        }
        public void ProcessConventionalBatch(WasherTag currentWasher, List<string> updatedObjects)
        {
            WasherTag CompareWasher = new WasherTag();
            WasherTag SaveWasher = new WasherTag();
            bool SaveToDB = false;
            bool IsNewBatch = false;
            int PrevFormula = 0;

            if (AllWashers.Count <= 0)
            {
                AllWashers.Add(currentWasher);
                SaveConventionalBatchData(currentWasher, true);

            }
            else
            {
                CompareWasher = AllWashers.TakeWhile((AW => AW.WasherId == currentWasher.WasherId)).ToList().FirstOrDefault();
                //exists 
                if (CompareWasher != null)
                {
                    PrevFormula = CompareWasher.CurrentFormula;

                    SaveToDB = ((currentWasher.CurrentFormula != CompareWasher.CurrentFormula) || (currentWasher.CurrentInjection != CompareWasher.CurrentInjection) || (currentWasher.OperationCounter != CompareWasher.OperationCounter));
                    for (int i = 0; i < updatedObjects.Count; i++)
                    {
                        if (updatedObjects[i] == Resources.WasherCurrentFormula)
                           CompareWasher.CurrentFormula = currentWasher.CurrentFormula;
                        if (updatedObjects[i] == Resources.WasherCurrentInjection)
                            CompareWasher.CurrentInjection = currentWasher.CurrentInjection;
                        if (updatedObjects[i] == Resources.WasherCurrentOperationCounter)
                            CompareWasher.OperationCounter = currentWasher.OperationCounter;
                        if (updatedObjects[i] == Resources.WasherAWEFormula)
                            CompareWasher.AWEFormula = currentWasher.AWEFormula;
                        if (updatedObjects[i] == Resources.WasherEOFSignal)
                            CompareWasher.EOFSignal = currentWasher.EOFSignal;
                        if (updatedObjects[i] == Resources.WasherMode)
                            CompareWasher.Mode = currentWasher.Mode;
                        if (updatedObjects[i] == Resources.WasherFlushTime)
                            CompareWasher.FlushTime = currentWasher.FlushTime;
                        if (updatedObjects[i] == Resources.WasherInjectionClass)
                            CompareWasher.InjectionClass = currentWasher.InjectionClass;
                        if (updatedObjects[i] == Resources.WasherInjectionRatio)
                            CompareWasher.InjectionRatio = currentWasher.InjectionRatio;
                        if (updatedObjects[i] == Resources.WasherOnHold)
                            CompareWasher.OnHold = currentWasher.OnHold;
                        if (updatedObjects[i] == Resources.WasherAWEActive)
                            CompareWasher.AWEActive = currentWasher.AWEActive;
                        if (updatedObjects[i] == Resources.WasherHoldDelay)
                            CompareWasher.HoldDelay = currentWasher.HoldDelay;
                        if (updatedObjects[i] == Resources.WasherRatioDosingActive)
                            CompareWasher.RatioDosingActive = currentWasher.RatioDosingActive;
                        if (updatedObjects[i] ==Resources.WasherRatioDosingPercentage)
                            CompareWasher.RatioDosingPercentage = currentWasher.RatioDosingPercentage;
                        if (updatedObjects[i] == Resources.WasherNumber)
                            CompareWasher.WasherNumber = currentWasher.WasherNumber;
                    }
                    SaveWasher = CompareWasher;
                    if ((CompareWasher.CurrentFormula == CompareWasher.EOFSignal))
                    {
                        SaveWasher.CurrentFormula = 128;
                        SaveToDB = true;
                    }

                    else if (((CompareWasher.CurrentInjection == 0) && (CompareWasher.OperationCounter == 0)) || (CompareWasher.CurrentFormula != PrevFormula))
                    {
                        PrevFormula = SaveWasher.CurrentFormula;
                        SaveWasher.CurrentFormula = 128;
                        SetEndOfBatch(SaveWasher);

                        IsNewBatch = true;
                    }

                }

                //If there is a change then save to database
            }
            if (SaveToDB)
            {

                CompareWasher.CurrentFormula = IsNewBatch ? PrevFormula : CompareWasher.CurrentFormula;
                SaveConventionalBatchData(CompareWasher, IsNewBatch);
                AllWashers.RemoveAt(AllWashers.FindIndex(AW => AW.WasherId == currentWasher.WasherId));
                CompareWasher.CurrentFormula = PrevFormula;
                AllWashers.Add(CompareWasher);

            }
        }


        public void ProcessTunnelBatch(WasherTag currentWasher, List<string> updatedObjects)
        {
            WasherTag CompareWasher = new WasherTag();
            WasherTag SaveWasher = new WasherTag();
            WasherTag removedWasher = new WasherTag();
            int BatchID, CompartmentNo;

            bool SaveToDB = false;
            bool IsNewBatch = false;
            int PrevFormula = 0;

            TunnelWasher washer = GetWasherDetails(currentWasher.WasherId);
            currentWasher.NumberOfCompartments = washer.NumberOfCompartments;


            if (AllWashers.Count <= 0)
            {
                currentWasher.BatchID = SaveTunnelBatchData(currentWasher, true);
                AllWashers.Add(currentWasher);

                if (ActiveBatches.Count < washer.NumberOfCompartments)
                {
                    //BatchID = currentWasher.BatchID;
                    //CompartmentNo = AllBatches.Count + 1;
                    //AllBatches.Enqueue(Tuple.Create<int, int>(BatchID,CompartmentNo));
                    ActiveBatches.QueueBatch(currentWasher);

                }
                //ActiveBatches.QueueBatch(ref currentWasher);

                else
                    removedWasher = (WasherTag)ActiveBatches.RemoveBatch();
                //Launch a thread and set the interval with the maximum steprun time.
            }
            else
            {
                CompareWasher = AllWashers.TakeWhile((AW => AW.WasherId == currentWasher.WasherId)).ToList().FirstOrDefault();
                //exists 
                if (CompareWasher != null)
                {
                    PrevFormula = CompareWasher.CurrentFormula;

                    SaveToDB = ((currentWasher.CurrentFormula != CompareWasher.CurrentFormula) || (currentWasher.CurrentInjection != CompareWasher.CurrentInjection) || (currentWasher.OperationCounter != CompareWasher.OperationCounter));

                  for (int i = 0; i < updatedObjects.Count; i++)
                    {
                        if (updatedObjects[i] ==  Resources.WasherCurrentFormula)
                            CompareWasher.CurrentFormula = currentWasher.CurrentFormula;
                        if (updatedObjects[i] == Resources.WasherCurrentInjection)
                            CompareWasher.CurrentInjection = currentWasher.CurrentInjection;
                        if (updatedObjects[i] == Resources.WasherCurrentOperationCounter)
                            CompareWasher.OperationCounter = currentWasher.OperationCounter;
                        if (updatedObjects[i] == Resources.WasherAWEFormula)
                            CompareWasher.AWEFormula = currentWasher.AWEFormula;
                        if (updatedObjects[i] == Resources.WasherEOFSignal)
                            CompareWasher.EOFSignal = currentWasher.EOFSignal;
                        if (updatedObjects[i] == Resources.WasherMode)
                            CompareWasher.Mode = currentWasher.Mode;
                        if (updatedObjects[i] == Resources.WasherFlushTime)
                            CompareWasher.FlushTime = currentWasher.FlushTime;
                        if (updatedObjects[i] == Resources.WasherInjectionClass)
                            CompareWasher.InjectionClass = currentWasher.InjectionClass;
                        if (updatedObjects[i] == Resources.WasherInjectionRatio)
                            CompareWasher.InjectionRatio = currentWasher.InjectionRatio;
                        if (updatedObjects[i] == Resources.WasherOnHold)
                            CompareWasher.OnHold = currentWasher.OnHold;
                        if (updatedObjects[i] == Resources.WasherAWEActive)
                            CompareWasher.AWEActive = currentWasher.AWEActive;
                        if (updatedObjects[i] == Resources.WasherHoldDelay)
                            CompareWasher.HoldDelay = currentWasher.HoldDelay;
                        if (updatedObjects[i] == Resources.WasherRatioDosingActive)
                            CompareWasher.RatioDosingActive = currentWasher.RatioDosingActive;
                        if (updatedObjects[i] == Resources.WasherRatioDosingPercentage)
                            CompareWasher.RatioDosingPercentage = currentWasher.RatioDosingPercentage;
                        if (updatedObjects[i] == Resources.WasherNumber)
                            CompareWasher.WasherNumber = currentWasher.WasherNumber;
                    }
                    SaveWasher = CompareWasher;
                    IsNewBatch = ((CompareWasher.CurrentInjection == 0) && (CompareWasher.OperationCounter == 0)) || (CompareWasher.CurrentFormula != PrevFormula);

                }            
            }
            //Save to DataBase only when there is a change.
            if (SaveToDB)
            {
                CompareWasher.BatchID = SaveTunnelBatchData(CompareWasher, IsNewBatch);
                BatchID = CompareWasher.BatchID;
                CompartmentNo = AllBatches.Count + 1;
                //AllBatches.Enqueue(Tuple.Create<int, int>(BatchID, CompartmentNo));

                //    foreach(System.Collections.Generic.List<Tuple<int,int>> obj in AllBatches)
                //    {
                //        var mybatch = obj[0].Item1;
                //        var mycompartment = obj[0].Item1;
                //    }

                ActiveBatches.QueueBatch(SaveWasher);

                if (ActiveBatches.Count > CompareWasher.NumberOfCompartments)
                {
                    //SaveWasher.CurrentFormula = 128;
                    //WasherTag removedwasher = (WasherTag)ActiveBatches.RemoveBatch();
                    CompareWasher.CurrentFormula = 128;
                    CompareWasher.BatchID = SaveTunnelBatchData(CompareWasher, false);
                    CompareWasher.CurrentFormula = currentWasher.CurrentFormula;
                }

                AllWashers.RemoveAt(AllWashers.FindIndex(AW => AW.WasherId == currentWasher.WasherId));
                AllWashers.Add(CompareWasher);
            }
        }

        private TunnelWasher GetWasherDetails(int washerId)
        {
            return BatchAccess.GetTunnelWasherDetails(washerId);
        }
        private void SetEndOfBatch(WasherTag tagToSave)
        {
            SaveConventionalBatchData(tagToSave, false);
        }

        private void SaveConventionalBatchData(WasherTag tag, bool isNewBatch)
        {
            BatchAccess.SaveConventionalBatchData(tag, isNewBatch);
        }

        private int SaveTunnelBatchData(WasherTag batchDtls, bool isNewBatch)
        {
            try
            {
                return BatchAccess.SaveTunnelBatchData(batchDtls, isNewBatch);
            }

            catch (System.Exception ex)
            {
                return 0;
            }
        }

        /// <summary>
        /// Read XML Data Continuously
        /// </summary>
        /// <param name="TagsToRead"></param>
        /// <param name="node"></param>
        public void continuousXMLRead(List<Tuple<string, int>> tagsToRead, string node)
        {
            //Your code here
        }

        /// <summary>
        /// ReadPLCTags : Full Read Has all the master objects.
        /// </summary>
        /// <param name="tagsToRead"></param>
        /// <param name="node"></param>
        public void ReadAllPLCTags(List<Tuple<string, int, string, string>> tagsToRead, string node, bool isPLCRequest)
        {
            object Qualities;
            object Timestamps;

            OPCItemIDs = Array.CreateInstance(typeof(string), tagsToRead.Count + 1);
            ItemServerHandles = Array.CreateInstance(typeof(int), tagsToRead.Count + 1);
            ItemServerErrors = Array.CreateInstance(typeof(int), tagsToRead.Count);
            ClientHandles = Array.CreateInstance(typeof(int), tagsToRead.Count + 1);
            RequestedDataTypes = Array.CreateInstance(typeof(short), tagsToRead.Count);
            AccessPaths = Array.CreateInstance(typeof(string), tagsToRead.Count);
            WriteItems = Array.CreateInstance(typeof(object), tagsToRead.Count);
            string sourceXml = string.Empty;
            string AliasString = string.Empty;

            string[] TagValues = new string[tagsToRead.Count];
            try
            {
                AliasString = SimulationMode ? "." : "";
                for (int i = 0; i < tagsToRead.Count; i++)
                {
                    OPCItemIDs.SetValue(node + AliasString + tagsToRead[i].Item1, i + 1);
                    CurrentTagsList = tagsToRead;
                    ClientHandles.SetValue(i + 1, i + 1);
                }
                OPCNode.OPCItems.DefaultIsActive = true;
                OPCNode.OPCItems.AddItems(tagsToRead.Count, OPCItemIDs, ref ClientHandles, out ItemServerHandles, out ItemServerErrors, RequestedDataTypes, AccessPaths);

                OPCNode.IsActive = true;
                OPCNode.IsSubscribed = OPCNode.IsActive;
                OPCNode.SyncRead((short)OPCAutomation.OPCDataSource.OPCDevice, tagsToRead.Count, ref ItemServerHandles, out OPCItemIDs, out ItemServerErrors, out Qualities, out Timestamps);
                if (!isPLCRequest)
                {
                    //Revisit the code to get the Table names dynamically.
                    sourceXml = ConvertToXml(OPCItemIDs, tagsToRead, "controllerTagValues");
                    if (sourceXml.Trim() != "")
                        SaveDataToDB(sourceXml);
                }
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> MultipleRead():" + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// ConvertToXml
        /// </summary>
        /// <param name="input"></param>
        /// <param name="Tags"></param>
        /// <param name="TableName"></param>
        public string ConvertToXml(Array input, List<Tuple<string, int, string, string>> tags, string tableName)
        {
            XmlDocument doc = new XmlDocument();
            XmlElement root = doc.CreateElement("Tables");
            XmlElement tablenode = doc.CreateElement("Table");
            tablenode.SetAttribute("TableName", tableName);
            root.AppendChild(tablenode);

            for (int i = 0; i < tags.Count; i++)
            {
                XmlElement TagNode = doc.CreateElement("Tag");
                TagNode.SetAttribute("Id", tags[i].Item2.ToString());
                TagNode.SetAttribute("Value", input.GetValue(i + 1).ToString());
                tablenode.AppendChild(TagNode);
            }

            doc.AppendChild(root);
            doc.Save("TagData.xml");
            return doc.InnerXml.ToString();
            //return CleanInvalidXmlChars(doc.InnerXml.ToString());
        }

        /// <summary>
        /// setupController
        /// </summary>
        /// <param name="ABCtrl"></param>
        public void InitializePLCContinuousRead(PLCController abCtrl)
        {
            try
            {
                List<PLCTag> TotalParams = GetControllerTagDetails(abCtrl);
                List<PLCTag> NowTags = null, WasherTags = null, ModuleTags = null;
                if (TotalParams.Count > 0)
                {

                    NowTags = TotalParams.Where(tag => tag.AssociatedTo.Contains(Resources.NowTagsText)).ToList();
                    WasherTags = TotalParams.Where(tag => tag.AssociatedTo.Contains(Resources.WasherTagsText)).ToList();
                    ModuleTags = TotalParams.Where(tag => tag.AssociatedTo.Contains(Resources.TankTagsText)).ToList();

                    RsGroupName = SimulationMode ? abCtrl.node : "[" + abCtrl.node + "]";

                    ConnectToPLC(abCtrl.opcServerName, RsGroupName, abCtrl.ipAddress, abCtrl.comPort);

                    //Read the entire list of tags.
                    List<Tuple<string, int, string, string>> tagValues;
                    AssignTags(TotalParams, out tagValues);
                    ReadAllPLCTags(tagValues, RsGroupName, false);

                    if (WasherTags.Count > 0)
                    {
                        AssignTags(WasherTags, out prm_WasherTags);
                        ContinuousPLCRead(prm_WasherTags, RsGroupName);
                    }

                    /**** Future Code ****/
                    ////Assign the groups to Timers
                    //if (NowTags.Count > 0)
                    //{
                    //	AssignTags(NowTags, out prm_PriorityHighTags);
                    //	AssignTimers(NowTags);
                    //}
                    //if (WasherTags.Count > 0)
                    //{
                    //	AssignTags(WasherTags, out prm_PriorityMedTags);
                    //	AssignTimers(WasherTags);
                    //}
                    //if (ModuleTags.Count > 0)
                    //{
                    //	AssignTags(ModuleTags, out prm_PriorityLowTags);
                    //	AssignTimers(ModuleTags);
                    //}
                }
            }

            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> SetupController():" + ex.StackTrace.ToString());
            }

        }
        /// <summary>
        /// AssignTags
        /// </summary>
        /// <param name="param"></param>
        /// <param name="tagValues"></param>
        /// <returns></returns>
        public void AssignTags(List<PLCTag> param, out List<Tuple<string, int, string, string>> tagValues)
        {
            try
            {
                List<Tuple<string, int, string, string>> priorityTags;
                priorityTags = param.Select(x => new Tuple<string, int, string, string>(x.TagAddress, x.TagId, x.TagDescription, x.AssociatedTo)).ToList();
                tagValues = priorityTags;
            }
            catch (Exception ex)
            {
                tagValues = null;
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> AssignTags():" + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// AssignTimers
        /// </summary>
        /// <param name="param"></param>
        public void AssignTimers(List<PLCTag> param)
        {
            try
            {
                if (param.Count > 0)
                {
                    int frequency = param.Select(x => x.Readfrequency).FirstOrDefault();
                    TimerCallback TimerDelegate = null;

                    TimerDelegate = param.FirstOrDefault().AssociatedTo.Contains("Now") ? new TimerCallback(NowTagsTimer)
                                            : (param.FirstOrDefault().AssociatedTo.Contains("Washer") ? new TimerCallback(WasherTagsTimer)
                                            : new TimerCallback(ModuleTagsTimer));
                    System.Threading.Timer ABFreqTimer = new System.Threading.Timer(TimerDelegate, null, 60000, 60000);
                }
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> AssignTimers():" + ex.StackTrace.ToString());
            }

        }
        /// <summary>
        /// GetControllerParameterDetails
        /// </summary>
        /// <param name="ABCtrl"></param>
        /// <returns></returns>
        private List<PLCTag> GetControllerTagDetails(PLCController abCtrl)
        {
            try
            {
                int ecolabAcntNo;
                ecolabAcntNo = int.Parse(abCtrl.ecolabAccountNumber.ToString());
                return ControllerAccess.GetPlantTagDetails(ecolabAcntNo, abCtrl.controllerId);
            }

            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> GetControllerParameterDetails():" + ex.StackTrace.ToString());
                return null;
            }
        }
        //To Do: Include code to Stop the Timers
        /// <summary>
        /// StopTimers
        /// </summary>
        public void StopTimers()
        {
            //Functionality to be implemented
        }
        /// <summary>
        /// HighFrequencyTimer
        /// </summary>
        /// <param name="StateObj"></param>
        private void NowTagsTimer(object stateObj)
        {
            try
            {
                //Call the Read Operation method and start reading
                Debug.WriteLine("High Priority Tags");
                prm_NowTags.ToList().ForEach(lst => Debug.WriteLine(lst));
                ContinuousPLCRead(prm_NowTags, RsGroupName);
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> HighFrequencyTimer():" + ex.StackTrace.ToString());
            }
        }


        /// <summary>
        /// MediumFrequencyTimer
        /// </summary>
        /// <param name="StateObj"></param>
        private void WasherTagsTimer(object stateObj)
        {
            try
            {
                //Call the Read Operation method and start reading
                Debug.WriteLine("Medium Priority Tags");
                prm_WasherTags.ToList().ForEach(lst => Debug.WriteLine(lst));
                ContinuousPLCRead(prm_WasherTags, RsGroupName);
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> MediumFrequencyTimer():" + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// LowFrequencyTimer
        /// </summary>
        /// <param name="StateObj"></param>
        private void ModuleTagsTimer(object stateObj)
        {
            try
            {
                //Call the Read Operation method and start reading
                Debug.WriteLine("Low Priority Tags");
                prm_ModuleTags.ToList().ForEach(lst => Debug.WriteLine(lst));
                ContinuousPLCRead(prm_ModuleTags, RsGroupName);
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> LowFrequencyTimer():" + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// ConnectToPLC
        /// </summary>
        /// <param name="OPCServerName"></param>
        /// <param name="Node"></param>
        /// <param name="IpAdress"></param>
        /// <param name="Port"></param>
        public void ConnectToPLC(string opcServerName, string node, string ipAdress, int port)
        {
            try
            {
                RsLnxOPCServer = new OPCServer();
                RsLnxOPCServer.Connect(opcServerName, "localhost");

                RsOPCGroups = RsLnxOPCServer.OPCGroups;
                OPCNode = RsLnxOPCServer.OPCGroups.Add(node);
                OPCNode.IsSubscribed = true;
                OPCNode.IsActive = false;

                OPCNode.DataChange += new DIOPCGroupEvent_DataChangeEventHandler(OPCNode_DataChange);

            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> ConnectToPLC():" + ex.StackTrace.ToString());
            }

        }

        /// <summary>
        /// OPCNode_DataChange
        /// </summary>
        /// <param name="TransactionID"></param>
        /// <param name="NumItems"></param>
        /// <param name="ClientHandles"></param>
        /// <param name="ItemValues"></param>
        /// <param name="Qualities"></param>
        /// <param name="TimeStamps"></param>
        void OPCNode_DataChange(int transactionID, int numItems, ref Array clientHandles, ref Array itemValues, ref Array qualities, ref Array timeStamps)
        {
            //Include logic to compare the values and send alarm / notifications (Approach to be decided).
            try
            {
                List<Tuple<string, string>> Values = new List<Tuple<string, string>>();

                for (int i = 1; i <= numItems; i++)
                {
                    Values.Add(Tuple.Create<string, string>(clientHandles.GetValue(i).ToString(), itemValues.GetValue(i).ToString()));
                }

                ProcessBatchTags(CurrentTagsList, Values);
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> OPCNode_DataChange():" + ex.StackTrace.ToString());
            }
        }
    
        /// <summary>
        /// WriteToPLC
        /// </summary>
        /// <param name="TagsToWrite"></param>
        public void WriteToPLC(List<Tuple<string, string>> tagsValues, int controllerId)
        {
            List<Tuple<string, int, string, string>> tagValues = null;
            PLCController ControllerToConnect = null;
            List<PLCTag> TotalParams = null;

            try
            {
                InitializeDBConnection();
                ControllerToConnect = ControllerAccess.GetPLCController(controllerId).FirstOrDefault();
                TotalParams = GetControllerTagDetails(ControllerToConnect);
                RsGroupName = ControllerToConnect.node.ToString();

                //Connect to the PLC
                ConnectToPLC(ControllerToConnect.opcServerName, ControllerToConnect.node, ControllerToConnect.ipAddress, ControllerToConnect.comPort);

                AssignTags(TotalParams, out tagValues);
                ReadAllPLCTags(tagValues, RsGroupName, true);

                for (int i = 0; i < tagsValues.Count; i++)
                {
                    int idx = tagValues.FindIndex(indx => indx.Item1 == tagsValues[i].Item1);
                    WriteItems.SetValue(tagsValues[i].Item2, idx + 1);
                    OPCNode.SyncWrite(tagsValues.Count, ref ItemServerHandles, ref WriteItems, out ItemServerErrors);
                }

            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> BatchWrite():" + ex.StackTrace.ToString());
            }
        }
        /// <summary>
        /// Test string using Regex.IsMatch static method.
        /// </summary>
        static bool IsValidTag(string value)
        {
            return Regex.IsMatch(value, @"(\\<[a-z]+\\>)[[:blank:]]+\\<\\1\\>");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ValiidTag"></param>

        public List<ConduitTag> ValidateTags(List<ConduitTag> validTag, int controllerId)
        {
            List<ConduitTag> ResultList = new List<ConduitTag>();
            List<ConduitTag> ExceptionList = new List<ConduitTag>();
            List<string> TagsToValidate = new List<string>();
            TagsToValidate = validTag.Select(vt => vt.TagName).ToList();
            for (int i = 0; i < TagsToValidate.Count; i++)
            {
                // Check to see if the tag is valid.
                try
                {
                    List<Tuple<string, int, string, string>> tagValues = null;
                    PLCController ControllerToConnect = null;
                    List<PLCTag> TotalParams = null;

                    InitializeDBConnection();
                    ControllerToConnect = ControllerAccess.GetPLCController(controllerId).FirstOrDefault();
                    TotalParams = GetControllerTagDetails(ControllerToConnect);
                    RsGroupName = ControllerToConnect.node.ToString();

                    //Connect to the PLC
                    ConnectToPLC(ControllerToConnect.opcServerName, ControllerToConnect.node, ControllerToConnect.ipAddress, ControllerToConnect.comPort);

                    if (ValidatePLCRead(TagsToValidate[i], ControllerToConnect.node))
                    {
                        var r = TagsToValidate[i];
                        ResultList.Add(new ConduitTag { TagName = r, IsValidTag = true });
                    }
                    else
                    {
                        var r = TagsToValidate[i];
                        if(r==null)
                        { 
                        ExceptionList.Add(new ConduitTag { TagName = r, IsValidTag = false, ExceptionCode = ExceptionCode.InvalidTag.ToString()});
                        }
                        if (!IsValidTag(r))//(\\<[a-z]+\\>)[[:blank:]]+\\<\\1\\>
                        {
                            ExceptionList.Add(new ConduitTag { TagName = r, IsValidTag = false, ExceptionCode = ExceptionCode.TagNotExists.ToString() });
                        }
                        if (OPCNode == null)
                        {
                            ExceptionList.Add(new ConduitTag { TagName = r, IsValidTag = false, ExceptionCode = ExceptionCode.NodeNotExists.ToString() });
                        }
                        if (OPCNode != RsOPCGroups)
                        {
                            ExceptionList.Add(new ConduitTag { TagName = r, IsValidTag = false, ExceptionCode = ExceptionCode.InvalidNode.ToString() });
                        }
                        else
                        {
                            ExceptionList.Add(new ConduitTag { TagName = r, IsValidTag = false, ExceptionCode = ExceptionCode.AccessViloationException.ToString() });
                        }

                    }

                }
                catch (System.Exception ex)
                {
                    //ExceptionList.Add(validTag[i]);
                    logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
                    return ExceptionList;
                }
            }

            return ResultList;


        }
        public bool ValidatePLCRead(string tagsToRead, string node)
        {
            object Qualities;
            object Timestamps;
            int TagstoCompare = 10;
            OPCItemIDs = Array.CreateInstance(typeof(string), 2);
            ItemServerHandles = Array.CreateInstance(typeof(int), 2);
            ItemServerErrors = Array.CreateInstance(typeof(int), 1);
            ClientHandles = Array.CreateInstance(typeof(int), 2);
            RequestedDataTypes = Array.CreateInstance(typeof(short), 1);
            AccessPaths = Array.CreateInstance(typeof(string), 1);
            WriteItems = Array.CreateInstance(typeof(object), 1);
            string sourceXml = string.Empty;

            string[] TagValues = new string[1];
            try
            {
                for (int i = 0; i < 1; i++)
                {
                    OPCItemIDs.SetValue(node + "." + tagsToRead, i + 1);
                    ClientHandles.SetValue(i + 1, i + 1);
                }

                OPCNode.OPCItems.DefaultIsActive = true;
                OPCNode.OPCItems.AddItems(1, OPCItemIDs, ref ClientHandles, out ItemServerHandles, out ItemServerErrors, RequestedDataTypes, AccessPaths);

                OPCNode.SyncRead((short)OPCAutomation.OPCDataSource.OPCDevice, 1, ref ItemServerHandles, out OPCItemIDs, out ItemServerErrors, out Qualities, out Timestamps);

                return true;
            }
            catch (System.Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> SaveToDB():" + ex.StackTrace.ToString());
                return false;

            }
        }

        private List<Tuple<int, string>> GetTagIndexes()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// SaveDataToDB
        /// </summary>
        /// <param name="xmlToSave"></param>
        public void SaveDataToDB(string xmlToSave)
        {
            try
            {
                if (ControllerAccess.SaveControllerData(xmlToSave))
                    logService.LogInfo("Save data successful at:" + System.DateTime.Now.ToLongDateString());
            }
            catch (System.Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> SaveToDB():" + ex.StackTrace.ToString());
            }
        }
        public void MultipleWrite(string[] TagsToWrite)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Test Method to WritePLC
        /// </summary>
        public void TestPLCWrite()
        {
            List<Tuple<string, string>> writetagValues = new List<Tuple<string, string>>();
            writetagValues.Add(new Tuple<string, string>("10", "N10:100"));
            writetagValues.Add(new Tuple<string, string>("20", "N10:121"));
            writetagValues.Add(new Tuple<string, string>("30", "N10:150"));
            writetagValues.Add(new Tuple<string, string>("40", "N10:80"));
            writetagValues.Add(new Tuple<string, string>("50", "N148:1"));
            //WriteToPLC(writetagValues);


        }
        public void ValiatePLCRead(List<Tuple<string, int, string, string>> tagsToRead, string node)
        {
            object Qualities;
            object Timestamps;

            OPCItemIDs = Array.CreateInstance(typeof(string), tagsToRead.Count + 1);
            ItemServerHandles = Array.CreateInstance(typeof(int), tagsToRead.Count + 1);
            ItemServerErrors = Array.CreateInstance(typeof(int), tagsToRead.Count);
            ClientHandles = Array.CreateInstance(typeof(int), tagsToRead.Count + 1);
            RequestedDataTypes = Array.CreateInstance(typeof(short), tagsToRead.Count);
            AccessPaths = Array.CreateInstance(typeof(string), tagsToRead.Count);
            WriteItems = Array.CreateInstance(typeof(object), tagsToRead.Count);
            string sourceXml = string.Empty;

            string[] TagValues = new string[tagsToRead.Count];
            try
            {
                for (int i = 0; i < tagsToRead.Count; i++)
                {
                    OPCItemIDs.SetValue(node + "." + tagsToRead[i].Item1, i + 1);
                    ClientHandles.SetValue(i + 1, i + 1);
                }
                OPCNode.OPCItems.DefaultIsActive = true;
                OPCNode.OPCItems.AddItems(tagsToRead.Count, OPCItemIDs, ref ClientHandles, out ItemServerHandles, out ItemServerErrors, RequestedDataTypes, AccessPaths);

                //OPCNode.IsActive = true;
                //OPCNode.IsSubscribed = OPCNode.IsActive;
                OPCNode.SyncRead((short)OPCAutomation.OPCDataSource.OPCDevice, tagsToRead.Count, ref ItemServerHandles, out OPCItemIDs, out ItemServerErrors, out Qualities, out Timestamps);
            }
            catch (System.Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> SaveToDB():" + ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// For Reading dynamic & historical values from PLC through XML Tag
        /// </summary>
        /// <param name="ABCtrl"></param>
        public void InitializeXMLContinuousRead(PLCController ABCtrl)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Initialize DB Connection
        /// </summary>
        private void InitializeDBConnection()
        {
            ///Add any new config keys to the below
            string[] configKeys = new string[1] { "ConnectionString" };

            List<Tuple<string, string>> configKeyValues = new List<Tuple<string, string>>();
            configKeyValues = GetConfigKey(configKeys);
            Database.InitializeConnection(configKeyValues[0].Item2.ToString());
        }

        /// <summary>
        /// Method to read the config keys from the config file
        /// </summary>
        /// <param name="keysTofind"></param>
        /// <returns></returns>
        private List<Tuple<string, string>> GetConfigKey(string[] keysTofind)
        {
            try
            {
                //This method would be moved to service.
                List<Tuple<string, string>> ctrlObj = new List<Tuple<string, string>>();
                NameValueCollection appSettings = ConfigurationManager.AppSettings;
                for (int i = 0; i < keysTofind.Count(); i++)
                {
                    foreach (string ctrl in appSettings.AllKeys)
                    {
                        if (ctrl.StartsWith(keysTofind[i]))
                        {
                            ctrlObj.Add(Tuple.Create<string, string>(ctrl[1].ToString(), appSettings[ctrl]));
                        }
                    }
                }
                return ctrlObj;
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at: Form1 -> GetConfigKey():" + ex.StackTrace.ToString());
                return null;
            }
        }


        public void RequestRead(List<Tuple<string, int>> tagsToRead, string node)
        {
            throw new NotImplementedException();
        }
    }
}