﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Library.Services.Batch
{
    class BatchQueue<T> : Queue
    {
        public void QueueBatch(object obj)
        {
            base.Enqueue(obj);
        }

        public object RemoveBatch()
        {
            return base.Dequeue();
        }
        public object VerifyBatch()
        {
            return base.Peek();
        }

        public override int Count
        {
            get
            {
                return base.Count;
            }
        }

    }
}
