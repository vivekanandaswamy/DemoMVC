﻿// -----------------------------------------------------------------------
// <copyright file="TagTypeEnum.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The TagTypeEnum </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Library.Services
{

    public enum EnumTagType
    {
        Tag_FRM,
        Tag_INJ,
        Tag_OPC,
        Tag_AWEF,
        Tag_EOF,
        Tag_MODE,
        Tag_FLSHT,
        Tag_ICLAS,
        Tag_INJRO,
        Tag_HOLD,
        Tag_AWEA,
        Tag_HOLDD,
        Tag_RATA,
        Tag_RATP,
        Tag_WSNO
    }

    public enum WasherType
    {
        Conventional,
        Tunnel
    }

    public enum TagType
    {
        Washer,
        Tank,
        Sensor,
        Controller
    }
}
