﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  OPC Client for Mitsubishi PLC Controllers.
 Author:  Pavan Sriramula
 Date Created: 05-Sep-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      06-SEP-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Library.Interfaces;
using Ecolab.Library.Shared;
using Ecolab.Data.Entities;

namespace Ecolab.Library.Services
{
    public class MitsubishiPLC : IPLCFactory
    {
        //Logging Varable
        ILogService logService;

        /// <summary>
        /// MitsubishiPLC
        /// </summary>
        public MitsubishiPLC()
        {
            logService = new FileLogService(typeof(MitsubishiPLC));
        }


		/// <summary>
		/// ReadAllPLCTags
		/// </summary>
		/// <param name="TagsToRead"></param>
		/// <param name="Node"></param>
		public void ReadAllPLCTags(List<Tuple<string, int, string,string>> tagsToRead, string node, bool isPLCRequest)
		{
			try
			{
				//Code specific to the data change.
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
			}
		}
		/// <summary>
		/// InitializeContinuousRead
		/// </summary>
		/// <param name="ABCtrl"></param>
		public void InitializePLCContinuousRead(Data.Entities.PLCController ABCtrl)
		{
			try
			{
				//Code specific to the data change.
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
			}
		}
		/// <summary>
		/// RequestRead
		/// </summary>
		/// <param name="TagsToRead"></param>
		/// <param name="Node"></param>
		public void RequestRead(List<Tuple<string, int>> TagsToRead, string Node)
		{
			try
			{
				//Code specific to the data change.
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
			}
		}
		/// <summary>
		/// WriteToPLC
		/// </summary>
		/// <param name="TagsValues"></param>
		public void WriteToPLC(List<Tuple<string, string>> tagsValues, int controllerId)
		{
			try
			{
				//Code specific to the data change.
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
			}
		}        
		/// <summary>
		/// For Reading dynamic & historical values from PLC through XML Tag
		/// </summary>
		/// <param name="ABCtrl"></param>
		public void InitializeXMLContinuousRead(PLCController abCtrl)
		{
			throw new NotImplementedException();
		}


        public List<ConduitTag> ValidateTags(List<ConduitTag> validTag, int controllerId)
        {
            throw new NotImplementedException();
        }
    }
}
