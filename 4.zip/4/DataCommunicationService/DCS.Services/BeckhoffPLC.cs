﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffPLC.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The BeckhoffPLC </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Library.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Ecolab.Library.Interfaces;
    using Ecolab.Data.Entities;
    using Ecolab.Data.Access;
    using Ecolab.Data.Access.Properties;
    using OPCAutomation;
    using System.Diagnostics;
    using Ecolab.Library.Shared;
    using System.Xml.Serialization;
    using System.IO;
    using System.Xml;
    using System.Text.RegularExpressions;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Globalization;
    using Ecolab.Data.Entities.Batch;
    public class BeckhoffPLC : IPLCFactory
	{
       
       private string RsGroupName;
       WasherTag currentWasherTag;
       List<WasherTag> AllWashers = new List<WasherTag>();
       //List<BatchD> ActiveBatches = new List<Batch>();
		//Logging Varable
		ILogService logService;
		/// <summary>
		/// BeckhoffPLC
		/// </summary>
		public BeckhoffPLC()
		{
			logService = new FileLogService(typeof(BeckhoffPLC));
		}

        /// <summary>
        /// ReadAllPLCTags
        /// </summary>
        /// <param name="TagsToRead"></param>
        /// <param name="Node"></param>
        public void ReadAllPLCTags(List<Tuple<string, int, string, string>> tagsToRead, string node, bool isPLCRequest)
        {            
            try
            {                
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
            }
        }
		/// <summary>
        /// InitializePLCContinuousRead method will be reaing all Beckhoff Tag, Xml taga and compaing the both tags.
		/// </summary>
		/// <param name="ABCtrl"></param>
        public void InitializePLCContinuousRead(Data.Entities.PLCController beckHoffCtrl)
        {
            ////throw new NotImplementedException();
            //try
            //{
            //    currentWasherTag = new WasherTag();          
            //    List<PLCTag> totalBeckhoffParams = GetBeckhoffControllerTagDetails(beckHoffCtrl);               
            //    List<BeckhoffXmlTag> totalXmlTags = GetBeckhoffXmlTags(@"C:\Users\bindrakanti\documents\visual studio 2013\Projects\TestingList\TestingList\Beckhoff.L_HSTXML.Conventional Washer.xml");
            //    string format = "dd-MM-yyyy HH:mm:ss";
            //    List<DateTime> ReadDateTimeStamp = new List<DateTime>();
            //    DateTime xmlDateTime;

            //    var availableBeckhoffTags =
            //                             (from t in totalBeckhoffParams
            //                              join p in totalXmlTags on
            //                                 t.TagId equals p.TagId
            //                              group t by new
            //                              {
            //                                  t.TagId,
            //                                  t.TagAddress,
            //                                  t.TagDescription,
            //                                  t.ControllerId,
            //                                  t.AssociatedTo,
            //                                  t.Readfrequency,
            //                                  t.AllowableDeviation,
            //                                  p.Data,
            //                                  p.DateTimeStamp
            //                              }
            //                                  into grp
            //                                  select new
            //                                  {
            //                                      grp.Key.TagId,
            //                                      grp.Key.TagAddress,
            //                                      grp.Key.TagDescription,
            //                                      grp.Key.ControllerId,
            //                                      grp.Key.AssociatedTo,
            //                                      grp.Key.Readfrequency,
            //                                      grp.Key.AllowableDeviation,
            //                                      grp.Key.Data,
            //                                      grp.Key.DateTimeStamp
            //                                  })
            //                                .OrderBy(x => x.DateTimeStamp)
            //        // .Where(z => z.DateTimeStamp == Convert.ToDateTime("13-10-2014 12:03:00"))
            //                              .ToList();

            //    var grpOrderedDate = availableBeckhoffTags.GroupBy(employees => employees.DateTimeStamp).OrderBy(xmlDate => xmlDate.Key.ToString());
            //    foreach (var a in grpOrderedDate)
            //    {
            //        if (DateTime.TryParseExact(a.Key.ToString(), format, null, DateTimeStyles.None, out xmlDateTime))
            //            ReadDateTimeStamp.Add(xmlDateTime);
            //    }

            //    int PrevFormula = 0;
            //    for (int i = 0; i < ReadDateTimeStamp.Count; i++)
            //    {
            //        bool IsNewBatch = false;
            //        string xmlDateTime1 = ReadDateTimeStamp[i].ToString("dd-MM-yyyy HH:mm:ss");
            //        List<DateTime> prevDateTimeStamp =  GetBeckhoffPlcDateTimeStamp();
            //        for (int j = i; j < availableBeckhoffTags.Count; j++)
            //        {
            //            if (Convert.ToDateTime(xmlDateTime1) == availableBeckhoffTags[j].DateTimeStamp)
            //            {

            //                currentWasherTag.WasherId = Convert.ToInt32(availableBeckhoffTags[i].AssociatedTo.Replace("Washer", ""));
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_FRM.ToString())
            //                    currentWasherTag.CurrentFormula = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_INJ.ToString())
            //                    currentWasherTag.CurrentInjection = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_OPC.ToString())
            //                    currentWasherTag.OperationCounter = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_AWEF.ToString())
            //                    currentWasherTag.AWEFormula = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_EOF.ToString())
            //                    currentWasherTag.EOFSignal = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_MODE.ToString())
            //                    currentWasherTag.Mode = availableBeckhoffTags[j].TagId.ToString();
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_FLSHT.ToString())
            //                    currentWasherTag.FlushTime = availableBeckhoffTags[j].TagId.ToString();
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_ICLAS.ToString())
            //                    currentWasherTag.InjectionClass = availableBeckhoffTags[j].TagId.ToString();
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_INJRO.ToString())
            //                    currentWasherTag.InjectionRatio = availableBeckhoffTags[j].TagId.ToString();
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_HOLD.ToString())
            //                    currentWasherTag.OnHold = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_AWEA.ToString())
            //                    currentWasherTag.AWEActive = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_HOLDD.ToString())
            //                    currentWasherTag.HoldDelay = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_RATA.ToString())
            //                    currentWasherTag.RatioDosingActive = availableBeckhoffTags[j].Data;
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_RATP.ToString())
            //                    currentWasherTag.RatioDosingPercentage = availableBeckhoffTags[j].TagId.ToString();
            //                if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_WSNO.ToString())
            //                    currentWasherTag.WasherNumber = availableBeckhoffTags[j].Data;

            //                currentWasherTag.DateTimeStamp = availableBeckhoffTags[i].DateTimeStamp;
            //            }

            //        }
            //        if (currentWasherTag.CurrentFormula != PrevFormula)
            //        {
            //            IsNewBatch = true;

            //            if (prevDateTimeStamp.Count > 0)
            //            {
            //                PrevFormula = currentWasherTag.CurrentFormula;
            //                currentWasherTag.CurrentFormula = 128;
            //                SaveBatchData(currentWasherTag, false);
            //                currentWasherTag.CurrentFormula = PrevFormula;

            //            }
            //        }
                
            //        SaveBatchData(currentWasherTag, IsNewBatch);
            //        PrevFormula = currentWasherTag.CurrentFormula;                  
            //    }                                               
            //}
            //catch (Exception ex)
            //{
            //    logService.LogError("Error Occurred at class: AllenBradleyPLC -> SetupController():" + ex.StackTrace.ToString());
            //}
            try
            {
                currentWasherTag = new WasherTag();

                List<string> TagsToValidate = new List<string>();
                List<PLCTag> totalBeckhoffParams = GetBeckhoffControllerTagDetails(beckHoffCtrl);    

                List<BeckhoffXmlTag> totalXmlTags = GetBeckhoffXmlTags(@"C:\Users\bindrakanti\documents\visual studio 2013\Projects\TestingList\TestingList\Beckhoff.L_HSTXML.Conventional Washer.xml");
                string format = "dd-MM-yyyy HH:mm:ss";
                List<DateTime> ReadDateTimeStamp = new List<DateTime>();
                DateTime xmlDateTime;

                var availableBeckhoffTags =
                                         (from t in totalBeckhoffParams
                                          join p in totalXmlTags on
                                             t.TagId equals p.TagId
                                          group t by new
                                          {
                                              t.TagId,
                                              t.TagAddress,
                                              t.TagDescription,
                                              t.ControllerId,
                                              t.AssociatedTo,
                                              t.Readfrequency,
                                              t.AllowableDeviation,
                                              p.Data,
                                              p.DateTimeStamp
                                          }
                                              into grp
                                              select new
                                              {
                                                  grp.Key.TagId,
                                                  grp.Key.TagAddress,
                                                  grp.Key.TagDescription,
                                                  grp.Key.ControllerId,
                                                  grp.Key.AssociatedTo,
                                                  grp.Key.Readfrequency,
                                                  grp.Key.AllowableDeviation,
                                                  grp.Key.Data,
                                                  grp.Key.DateTimeStamp
                                              })
                                            .OrderBy(x => x.DateTimeStamp)
                    // .Where(z => z.DateTimeStamp == Convert.ToDateTime("13-10-2014 12:03:00"))
                                          .ToList();

                var grpOrderedDate = availableBeckhoffTags.GroupBy(employees => employees.DateTimeStamp).OrderBy(xmlDate => xmlDate.Key.ToString());
                foreach (var a in grpOrderedDate)
                {
                    if (DateTime.TryParseExact(a.Key.ToString(), format, null, DateTimeStyles.None, out xmlDateTime))
                        ReadDateTimeStamp.Add(xmlDateTime);
                }
                List<string> UpdatedObjects = new List<string>();
                int PrevFormula = 0;
                for (int i = 0; i < ReadDateTimeStamp.Count; i++)
                {
                    bool IsNewBatch = false;
                    string xmlDateTime1 = ReadDateTimeStamp[i].ToString("dd-MM-yyyy HH:mm:ss");
                    // if (DateTime.TryParseExact(ReadDateTimeStamp[i].ToString(), format, null, DateTimeStyles.None, out xmlDateTime1))

                    List<DateTime> prevDateTimeStamp = GetBeckhoffPlcDateTimeStamp();
                    //   string s = prevDateTimeStamp[0].ToString("dd-MM-yyyy HH:mm:ss");
                    for (int j = i; j < availableBeckhoffTags.Count; j++)
                    {
                        if (Convert.ToDateTime(xmlDateTime1) == availableBeckhoffTags[j].DateTimeStamp)
                        {

                            UpdatedObjects.Add(availableBeckhoffTags[j].TagDescription.Trim());

                            currentWasherTag.WasherId = Convert.ToInt32(availableBeckhoffTags[i].AssociatedTo.Replace("Washer", ""));

                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_FRM.ToString())
                                currentWasherTag.CurrentFormula = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_INJ.ToString())
                                currentWasherTag.CurrentInjection = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_OPC.ToString())
                                currentWasherTag.OperationCounter = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_AWEF.ToString())
                                currentWasherTag.AWEFormula = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_EOF.ToString())
                                currentWasherTag.EOFSignal = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_MODE.ToString())
                                currentWasherTag.Mode = availableBeckhoffTags[j].TagId.ToString();
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_FLSHT.ToString())
                                currentWasherTag.FlushTime = availableBeckhoffTags[j].TagId.ToString();
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_ICLAS.ToString())
                                currentWasherTag.InjectionClass = availableBeckhoffTags[j].TagId.ToString();
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_INJRO.ToString())
                                currentWasherTag.InjectionRatio = availableBeckhoffTags[j].TagId.ToString();
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_HOLD.ToString())
                                currentWasherTag.OnHold = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_AWEA.ToString())
                                currentWasherTag.AWEActive = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_HOLDD.ToString())
                                currentWasherTag.HoldDelay = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_RATA.ToString())
                                currentWasherTag.RatioDosingActive = availableBeckhoffTags[j].Data;
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_RATP.ToString())
                                currentWasherTag.RatioDosingPercentage = availableBeckhoffTags[j].TagId.ToString();
                            if (availableBeckhoffTags[j].TagDescription.Trim() == EnumTagType.Tag_WSNO.ToString())
                                currentWasherTag.WasherNumber = availableBeckhoffTags[j].Data;

                            currentWasherTag.DateTimeStamp = availableBeckhoffTags[j].DateTimeStamp;
                        }

                    }
                    if (currentWasherTag.CurrentFormula != PrevFormula)
                    {
                        IsNewBatch = true;

                        if (prevDateTimeStamp.Count > 0)
                        {
                            PrevFormula = currentWasherTag.CurrentFormula;
                            currentWasherTag.CurrentFormula = 128;
                            SaveBhPlcConventionalBatchData(currentWasherTag, false);
                            currentWasherTag.CurrentFormula = PrevFormula;

                        }
                    }


                    ////dataGridView1.DataSource = availableBeckhoffTags.ToList();
                    SaveBhPlcConventionalBatchData(currentWasherTag, IsNewBatch);
                    PrevFormula = currentWasherTag.CurrentFormula;


                }
            }
            catch (Exception ex)
            {

            }
        }

        private List<DateTime> GetBeckhoffPlcDateTimeStamp()
        {
            try
            {                              
                return BeckhoffControllerAccess.GetBeckhoffPlcDateTimeStamp();
            }

            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> GetControllerParameterDetails():" + ex.StackTrace.ToString());
                return null;
            }
        }
        
        /// <summary>
        /// Save Beckhoff plc data in to the BatchData
        /// </summary>
        /// <param name="tag"></param>
        /// <param name="isNewBatch"></param>
        private void SaveBhPlcConventionalBatchData(WasherTag tag, bool isNewBatch)
        {

            BeckhoffControllerAccess.SaveBhPlcConventionalBatchData(tag, isNewBatch);
        }
        /// <summary>
        /// GetBeckhoffXmlTags method will reading the xml tags 
        /// </summary>
        /// <param name="myXmlString"></param>
        /// <returns></returns>
        private List<BeckhoffXmlTag> GetBeckhoffXmlTags(string xmlString)
        {           
            XmlDocument xmlDoc = new XmlDocument();
            FileStream readXmlFile = null;

            if (File.Exists(xmlString))
            {
                readXmlFile = new FileStream(xmlString,
                                                 FileMode.Open,
                                                 FileAccess.Read);

                xmlDoc.Load(readXmlFile);
            }
            BeckhoffXmlTag bhxr = new BeckhoffXmlTag();
            List<BeckhoffXmlTag> beckHoffXmlReadTags = new List<BeckhoffXmlTag>();            
            XmlNodeList xnList = xmlDoc.SelectNodes("/MyRoot/Entry");            
            DateTime beckDateTime;
            foreach (XmlNode xn in xnList)
            {               
                string format = "MM-dd-yyyy HH:mm:ss";
                if (DateTime.TryParseExact(xn["ts"].InnerText, format, null, DateTimeStyles.None, out beckDateTime))
                {
                    beckHoffXmlReadTags.Add(new BeckhoffXmlTag(Convert.ToInt32(xn["tag"].InnerText), xn["desc"].InnerText, Convert.ToInt32(xn["data"].InnerText), beckDateTime));
                }                                                          
            }

            return beckHoffXmlReadTags.ToList();
        }
    
		/// <summary>
        /// RequestRead
		/// </summary>
		/// <param name="TagsToRead"></param>
		/// <param name="Node"></param>
		public void RequestRead(List<Tuple<string, int>> tagsToRead, string node)
		{
			try
			{
				//Code specific to the data change.
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
			}
		}
		/// <summary>
        /// WriteToPLC
		/// </summary>
		/// <param name="TagsValues"></param>
		public void WriteToPLC(List<Tuple<string, string>> tagsValues, int controllerId)
		{
			try
			{
				//Code specific to the data change.
			}
			catch (Exception ex)
			{
				logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
			}
		}
        /// <summary>
        /// InitializeXMLContinuousRead
        /// </summary>
        /// <param name="ABCtrl"></param>
        public void InitializeXMLContinuousRead(PLCController beckHoffCtrl)
        {
            try
            {
                //Code specific to the data change.
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: BeckhoffPLC -> SingleRead():" + ex.StackTrace.ToString());
            }
        }
         /// <summary>
        /// GetBeckhoffControllerTagDetails method will get the all beckhoff tags
         /// </summary>
         /// <param name="ABCtrl"></param>
         /// <returns></returns>
        private List<PLCTag> GetBeckhoffControllerTagDetails(PLCController beckHoffCtrl)
        {
            try
            {
                int ecolabAcntNo;
                ecolabAcntNo = int.Parse(beckHoffCtrl.ecolabAccountNumber.ToString());
                return BeckhoffControllerAccess.GetBeckhoffPlcController(ecolabAcntNo, beckHoffCtrl.controllerId);
            }

            catch (Exception ex)
            {
                logService.LogError("Error Occurred at class: AllenBradleyPLC -> GetControllerParameterDetails():" + ex.StackTrace.ToString());
                return null;
            }
        }
        public List<ConduitTag> ValidateTags(List<ConduitTag> validTag, int controllerId)
        {
            throw new NotImplementedException();
        }
    }
}
