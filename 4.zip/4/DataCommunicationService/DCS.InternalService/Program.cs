﻿
/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace EcolabPLC.InternalSvc
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new PLCExternalWriteService() 
            };
            ServiceBase.Run(ServicesToRun);
        }
    }
}
