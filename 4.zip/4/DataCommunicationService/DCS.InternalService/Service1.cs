﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Data.Access;
using System.Configuration;
using System.Collections.Specialized;
using Ecolab.Library.Shared;

namespace EcolabPLC.InternalSvc
{
	/// <summary>
	/// 
	/// </summary>
    public partial class PLCExternalWriteService : ServiceBase
    {
        ILogService logService;
        public PLCExternalWriteService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                string[] configKeys = new string[2] { "ConnectionString", "ecolabAccountNo" };
                List<Tuple<string, string>> configKeyValues = new List<Tuple<string, string>>();
                int ecolabAccntNo;
                configKeyValues = GetConfigKey(configKeys);
                Database.InitializeConnection(configKeyValues[0].Item2.ToString());
                ecolabAccntNo = int.Parse(configKeyValues[1].Item2.ToString());
                List<Ecolab.Data.Entities.PLCController> ctrl = PlantAccess.GetControllersByPlant(ecolabAccntNo);
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at: Form1 -> GetConfigKey():" + ex.StackTrace.ToString());
                //return null;
            }

        }

        protected override void OnStop()
        {
        }
        /// <summary>
        /// GetConfigKey: Returns the config keys defined in the Configuration file.
        /// </summary>
        /// <param name="keysTofind"></param>
        /// <returns></returns>
        private List<Tuple<string, string>> GetConfigKey(string[] keysTofind)
        {
            try
            {
                //This method would be moved to service.
                List<Tuple<string, string>> ctrlObj = new List<Tuple<string, string>>();
                NameValueCollection appSettings = ConfigurationManager.AppSettings;
                for (int i = 0; i < keysTofind.Count(); i++)
                {
                    foreach (string ctrl in appSettings.AllKeys)
                    {
                        if (ctrl.StartsWith(keysTofind[i]))
                        {
                            ctrlObj.Add(Tuple.Create<string, string>(ctrl[1].ToString(), appSettings[ctrl]));
                        }
                    }
                }
                return ctrlObj;
            }
            catch (Exception ex)
            {
                logService.LogError("Error Occurred at: Form1 -> GetConfigKey():" + ex.StackTrace.ToString());
                return null;
            }
        }
    }
}
