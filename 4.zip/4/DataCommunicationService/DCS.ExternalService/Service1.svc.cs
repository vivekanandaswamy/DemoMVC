﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Ecolab.Library.Infra;
using Ecolab.Library.Interfaces;
using Ecolab.Data.Entities;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.

	
    public class Service1 : IWritePLCService
    {


		//public void WriteData(List<Tuple<string,string>> TagValuestoWrite, int ControllerId)
		//{
		//	string Tag_Value = string.Empty;
		//	IWriteCallBack calllback = OperationContext.Current.GetCallbackChannel<IWriteCallBack>();
		//	bool success = true;
			
		//	PLCCreator creator = new PLCFactory();
		//	IPLCFactory ObjPLC = creator.CreatePLC("AllenBradley");
		//	ObjPLC.WriteToPLC(TagValuestoWrite, ControllerId);

            
		//	//Tag_Value = "From Server: Completed writting. Acknowledging Client. Tag Sent: " + value.TagName.ToString() + "Value Of Tag: " + value.TagValue.ToString();
		//	calllback.IsWriteSuccessful(success, Tag_Value);
		//}


		public void WritePLCData(List<Tuple<string, string>> TagValuestoWrite, int ControllerId)
		{
			string Tag_Value = string.Empty;
			//IWritePLCService calllback = OperationContext.Current.GetCallbackChannel<IWritePLCService>();
			//bool success = true;

			PLCCreator creator = new PLCFactory();
			IPLCFactory ObjPLC = creator.CreatePLC("AllenBradley");
			ObjPLC.WriteToPLC(TagValuestoWrite, ControllerId);


			//Tag_Value = "From Server: Completed writting. Acknowledging Client. Tag Sent: " + value.TagName.ToString() + "Value Of Tag: " + value.TagValue.ToString();
			//calllback.IsWriteSuccessful(success, Tag_Value);
		}
	}
}
