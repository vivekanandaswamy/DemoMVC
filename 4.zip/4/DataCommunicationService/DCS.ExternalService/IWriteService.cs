﻿using Ecolab.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace PLCWriteService
{
	/// <summary>
	/// IWritePLCService
	/// </summary>
	[ServiceContract(CallbackContract = (typeof(IWriteServiceCallback)))]
	public interface IWritePLCService
	{

		[OperationContract]
		void WritePLCData(List<Tuple<string, string>> tagValuestoWrite, int controllerId, string controllerType);

        [OperationContract]
        List<ConduitTag> ValidateTags(List<ConduitTag> validTag, int controllerId);   

	}

	/// <summary>
	/// IWriteServiceCallback
	/// </summary>
	public interface IWriteServiceCallback
	{
		[OperationContract(IsOneWay = true)]
		void IsWriteSuccessful(bool isSuccess, string tagWritten);
	}
}
