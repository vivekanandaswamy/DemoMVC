﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Ecolab.Library.Infra;
using Ecolab.Library.Interfaces;
using Ecolab.Data.Entities;

namespace PLCWriteService
{
	// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "PLCExternalWriteService" in code, svc and config file together.
	// NOTE: In order to launch WCF Test Client for testing this service, please select PLCExternalWriteService.svc or PLCExternalWriteService.svc.cs at the Solution Explorer and start debugging.


	public class PLCExternalWriteService : IWritePLCService
	{
        public void WritePLCData(List<Tuple<string, string>> tagValuestoWrite, int controllerId, string controllerType)
		{
			string writeMsg = "Tags written successflly to PLC";
			IWriteServiceCallback calllback = OperationContext.Current.GetCallbackChannel<IWriteServiceCallback>();
			bool success = true;

			PLCCreator plc = new PLCFactory();
            IPLCFactory plcFactory = plc.CreatePLC(controllerType,false);
            plcFactory.WriteToPLC(tagValuestoWrite, controllerId);
            calllback.IsWriteSuccessful(success, writeMsg);
		}       

        public List<ConduitTag> ValidateTags(List<ConduitTag> validTag, int controllerId)
        {
            string writeMsg = "Tags written successflly to PLC";
            IWriteServiceCallback calllback = OperationContext.Current.GetCallbackChannel<IWriteServiceCallback>();
            bool success = true;

            PLCCreator plc = new PLCFactory();
            IPLCFactory plcFactory = plc.CreatePLC("AllenBradley", false);
            var result = plcFactory.ValidateTags(validTag, controllerId);
            calllback.IsWriteSuccessful(success, writeMsg);
            return result;
           
        }
	}
}
