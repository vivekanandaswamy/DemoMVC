﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Library.Models
{
   public class ControllerParameters
    {

        # region Properties

        /// <summary>
        /// Gets or sets ParameterId 
        /// </summary>
        /// <value> Parameter Id.</value> 
        public int ParameterId { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        /// <value>Description.</value> 
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ResourceKey 
        /// </summary>
        /// <value> ResourceKey.</value> 
        public string ResourceKey { get; set; }

        /// <summary>
        /// Gets or sets PLCTypeId 
        /// </summary>
        /// <value> PLCTypeId.</value> 
        public int PLCTypeId { get; set; }

        /// <summary>
        /// Gets or sets AddressValue 
        /// </summary>
        /// <value> AddressValue.</value> 
        public string AddressValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue 
        /// </summary>
        /// <value> DefaultValue.</value> 
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets IsDisplay 
        /// </summary>
        /// <value> IsDisplay.</value> 
        public char IsDisplay { get; set; }

        #endregion Properties
    }
}
