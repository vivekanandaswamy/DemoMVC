﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Library.Models
{
    public class ControllerType
    {
        #region Properties

        /// <summary>
        /// Gets or sets ControllerTypeId 
        /// </summary>
        /// <value> ControllerTypeId.</value> 
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or sets Name 
        /// </summary>
        /// <value>Name.</value> 
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets RegionId 
        /// </summary>
        /// <value> RegionId.</value> 
        public int RegionId { get; set; }

        /// <summary>
        /// Gets or sets Active 
        /// </summary>
        /// <value> Active.</value> 
        public char Active { get; set; }

        /// <summary>
        /// Gets or sets Version 
        /// </summary>
        /// <value> Version.</value> 
        public int Version { get; set; }

        #endregion Properties
    }
}
