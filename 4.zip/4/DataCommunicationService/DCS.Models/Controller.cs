﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Library.Models
{
    public class Controller
    {
        # region Properties

        /// <summary>
        /// Gets or sets ControllerId 
        /// </summary>
        /// <value> Controller Id.</value>        
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets EcoalabAccountNumber 
        /// </summary>
        /// <value> EcoalabAccountNumber.</value>        
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ControllerTypeId 
        /// </summary>
        /// <value> Controller Type Id.</value>        
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or sets Name 
        /// </summary>
        /// <value> Name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        /// <value> Description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets IPAddress 
        /// </summary>
        /// <value> IPAddress.</value>
        public string IPAddress { get; set; }

        /// <summary>
        /// Gets or sets ComPort 
        /// </summary>
        /// <value> ComPort.</value>
        public int ComPort { get; set; }

        /// <summary>
        /// Gets or sets LastConnectedTime 
        /// </summary>
        /// <value> LastConnectedTime.</value>
        public string LastConnectedTime { get; set; }

        /// <summary>
        /// Gets or sets Active 
        /// </summary>
        /// <value> Active.</value>
        public char Active { get; set; }

        /// <summary>
        /// Gets or sets WashersCount 
        /// </summary>
        /// <value> WashersCount.</value>
        public int WashersCount { get; set; }

        /// <summary>
        /// Gets or sets TunnelsCount 
        /// </summary>
        /// <value> TunnelsCount.</value>
        public int TunnelsCount { get; set; }

        /// <summary>
        /// Gets or sets PumpsCount 
        /// </summary>
        /// <value> PumpsCount.</value>
        public int PumpsCount { get; set; }

        /// <summary>
        /// Gets or sets EquipmentsCount 
        /// </summary>
        /// <value> EquipmentsCount.</value>
        public int EquipmentsCount { get; set; }

        # endregion Properties
    }
}
