﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Library.Models
{
   public  class ControllerParameterValues
    {
        #region Properties

        /// <summary>
        /// Gets or sets ControllerId 
        /// </summary>
        /// <value> ControllerId.</value> 
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets ParameterId 
        /// </summary>
        /// <value> ParameterId.</value> 
        public string ParameterId { get; set; }

        /// <summary>
        /// Gets or sets Value 
        /// </summary>
        /// <value> Value.</value> 
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets TimeStamp 
        /// </summary>
        /// <value> TimeStamp.</value> 
        public string TimeStamp { get; set; }

        #endregion Properties
    }
}
