﻿// -----------------------------------------------------------------------
// <copyright file="ControllerAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The ControllerAccess </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Data.Access
{
	using System;
	using Nalco.Data.Common;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.Common;
	using System.Linq;
	using Ecolab.Data.Entities;
	using Ecolab.Data.Access.Properties;
	using Ecolab.Library.Shared;

	/// <summary>
	/// Access class for ControllerAccess
	/// </summary>
	public class ControllerAccess
	{
		

		/// <summary>
		/// GetPlantParameterDetails
		/// </summary>
		/// <returns></returns>        
		public static List<PLCTag> GetPlantTagDetails(int ecolabAccountNo, int controllerId)
		{
			try
			{
				return DbClient.ExecuteReader<PLCTag>(Resources.Ecolab_GetPlcPlantParameters,
				 delegate(DbCommand cmd, DbContext context)
				 {
					// cmd.CommandType = CommandType.Text;
					 cmd.AddParameter("@ecolabAccountNumber", ecolabAccountNo);
					 cmd.AddParameter("@ControllerId ", controllerId);
				 }).ToList();
			}
			catch (System.Exception ex)
			{
				ILogService logService = new FileLogService(typeof(ControllerAccess));
				logService.LogError("Error Occurred at: ControllerAccess -> GetPlantParameterDetails:" + ex.StackTrace.ToString());
				return null;
			}
		}

		/// <summary>
		/// Saving the SaveControllerData in the Database.
		/// </summary>
		/// <param name="xmlToSave"></param>
		/// <returns></returns>
		public static bool SaveControllerData(string xmlToSave)
		{
			try
			{
				DbClient.ExecuteNonQuery(Resources.Ecolab_SavePLCParameterValues,
				   delegate(DbCommand cmd, DbContext context)
				   {
					   cmd.CommandType = CommandType.StoredProcedure;
					   cmd.AddParameter("xml", DbType.String, 100000, xmlToSave);
					   cmd.AddParameter("tableName", DbType.String, 200, "controllerTagValues");
				   });
				return true;
			}
			catch (System.Exception ex)
			{
				ILogService logService = new FileLogService(typeof(ControllerAccess));
				logService.LogError("Error Occurred at: ControllerAccess -> SaveControllerData:" + ex.StackTrace.ToString());
				return false;
			}
		}

		/// <summary>
		/// Get plc controllers data 
		/// </summary>
		/// <param name="ControllerId"></param>
		/// <returns></returns>
		public static IList<PLCController> GetPLCController(int controllerId)
		{
			return DbClient.ExecuteReader<PLCController>(Resources.Ecolab_GetPLCControllerById,
				delegate(DbCommand cmd, DbContext context)
				{
                    //cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("controllerId", controllerId);
				}).ToList();


		}		
	}
}
