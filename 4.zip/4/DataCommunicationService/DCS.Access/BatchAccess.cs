﻿// -----------------------------------------------------------------------
// <copyright file="BatchAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The BatchAccess </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Data.Access
{
    using System;
    using Nalco.Data.Common;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Ecolab.Data.Entities;
    using Ecolab.Data.Access.Properties;
    using Ecolab.Library.Shared;
    using Ecolab.Data.Entities.Batch;
    using System.Data.SqlClient;

    /// <summary>
    /// Access class for BatchAccess
    /// </summary>
    public class BatchAccess
    {
        /// <summary>
        /// SaveBatchData
        /// </summary>
        /// <param name="TagInfo"></param>
        /// <returns></returns>
        public static bool SaveConventionalBatchData(WasherTag tagInfo, bool isNewBatch)
        {
            try
            {
                bool IsEndOfBatch = false;
                IsEndOfBatch = (tagInfo.CurrentFormula == 128) ? true : false;
                DbClient.ExecuteNonQuery("[TCD].[SaveAbPlcConventionalBatchData]",
                   delegate(DbCommand cmd, DbContext context)
                   {
                       cmd.CommandType = CommandType.StoredProcedure;
                       cmd.AddParameter("WasherId ", tagInfo.WasherId);
                       cmd.AddParameter("OperationalCount", tagInfo.OperationCounter);
                       cmd.AddParameter("CurrentFormula", tagInfo.CurrentFormula);
                       cmd.AddParameter("CurrentInjection", tagInfo.CurrentInjection);
                       //Update this to send from the actual tag values
                       //cmd.AddParameter("RecordedTime", Convert.ToString(DateTime.Now.ToLongTimeString()));
                       cmd.AddParameter("IsNewBatch", isNewBatch);
                       cmd.AddParameter("IsEndOfBatch", IsEndOfBatch);
                   });
                return true;
            }
            catch (System.Exception ex)
            {
                ILogService logService = new FileLogService(typeof(ControllerAccess));
                logService.LogError("Error Occurred at: ControllerAccess -> GetPlantParameterDetails:" + ex.StackTrace.ToString());
                return false;
            }
        }



        public static int SaveTunnelBatchData(WasherTag batchInfo, bool isNewBatch)
        {
            try
            {
                //int BatchID = 0;
                SqlParameter param = new SqlParameter();
                param.ParameterName = "BatchID";
                param.SqlDbType = SqlDbType.Int;
                param.Size = 4;
                param.Direction = ParameterDirection.Output;

                DbClient.ExecuteNonQuery("[TCD].[SavePLCTunnelBatchData]",
                   delegate(DbCommand cmd, DbContext context)
                   {
                       cmd.CommandType = CommandType.StoredProcedure;
                       cmd.AddParameter("WasherId ", batchInfo.WasherId);
                       cmd.AddParameter("OperationalCount", batchInfo.OperationCounter);
                       cmd.AddParameter("CurrentFormula", batchInfo.CurrentFormula);
                       cmd.AddParameter("CurrentInjection", batchInfo.CurrentInjection);
                       //Update this to send from the actual tag values
                       //cmd.AddParameter("RecordedTime", Convert.ToString(DateTime.Now.ToLongTimeString()));
                       cmd.AddParameter("IsNewBatch", isNewBatch);
                       cmd.AddParameter("IsEOB", isNewBatch);
                       //cmd.AddParameter("RemoveBatchID", batchInfo.BatchID);
                       cmd.AddParameter("MaxCompartments", batchInfo.NumberOfCompartments);

                       cmd.Parameters.Add(param);
                   });
                return Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            }
            catch (System.Exception ex)
            {
                ILogService logService = new FileLogService(typeof(ControllerAccess));
                logService.LogError("Error Occurred at: ControllerAccess -> GetPlantParameterDetails:" + ex.StackTrace.ToString());
                return 0;
            }
        }

        public static TunnelWasher GetTunnelWasherDetails(int washerId)
        {
            try
            {
                return DbClient.ExecuteReader<TunnelWasher>("[TCD].[GetTunnelWasherDetails]",
                 delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.StoredProcedure;
                     cmd.AddParameter("@washerID", washerId);
                 }).FirstOrDefault();
            }
            catch (System.Exception ex)
            {
                ILogService logService = new FileLogService(typeof(BatchAccess));
                logService.LogError("Error Occurred at: BatchAccess -> GetTunnelWasherDetails:" + ex.StackTrace.ToString());
                return null;
            }
        }
    }


}
