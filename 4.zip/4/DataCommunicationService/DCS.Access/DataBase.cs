﻿// -----------------------------------------------------------------------
// <copyright file="Database.cs" company="Ecolab">
// TODO: Update copyright text.
// </copyright>
// <summary>The Database object</summary>
// -----------------------------------------------------------------------
using Nalco.Data.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ecolab.Library.Shared;

namespace Ecolab.Data.Access
{
    
    /// <summary>
    /// Initializes the connection string to connect to database
    /// </summary>
    public static class Database
    {
        /// <summary>
        /// InitializeConnection
        /// </summary>
        /// <param name="connectionString"></param>
        public static void InitializeConnection(string connectionString)
        {
            try
            {
                DbContext.AddConnectionString(connectionString);
            }
            catch (System.Exception ex)
            {
                ILogService logService = new FileLogService(typeof(ControllerAccess));
				logService.LogError("Error Occurred at class: Database -> InitializeConnection():" + ex.StackTrace.ToString());            

            }
        }
    }
}
