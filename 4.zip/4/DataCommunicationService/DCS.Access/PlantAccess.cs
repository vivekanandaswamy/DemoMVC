﻿// -----------------------------------------------------------------------
// <copyright file="PlantAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The PlantAccess </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Data.Access
{
	using System;
	using Nalco.Data.Common;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.Common;
	using System.Linq;
	using Ecolab.Data.Entities;
	using Ecolab.Data.Access.Properties;
	using Ecolab.Library.Shared;

	/// <summary>
	/// Access class for PlantAccess
	/// </summary>
	public class PlantAccess
	{
		/// <summary>
		/// Get controller for plant
		/// </summary>
		/// <param name="ecolabAccountNo"></param>
		/// <returns>returns the plant number</returns>
		public static List<PLCController> GetControllersByPlant(int ecolabAccountNo)
		{
			try
			{
				return DbClient.ExecuteReader<PLCController>(Resources.Ecolab_GetPlcPlantControllers,
				 delegate(DbCommand cmd, DbContext context)
				 {
					// cmd.CommandType = CommandType.Text;
					 cmd.AddParameter("@ecolabAccountNumber", ecolabAccountNo);					 				
				 }).ToList();
			}
			catch (System.Exception ex)
			{
				ILogService logService = new FileLogService(typeof(ControllerAccess));
				logService.LogError("Error Occurred at: ControllerAccess -> GetControllersByPlant:" + ex.StackTrace.ToString());
				return null;
			}
		}
	}
}
