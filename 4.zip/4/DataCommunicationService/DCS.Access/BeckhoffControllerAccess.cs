﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffControllerAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The BeckhoffControllerAccess </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Data.Access
{
    using System;
    using Nalco.Data.Common;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Ecolab.Data.Entities;
    using Ecolab.Data.Access.Properties;
    using Ecolab.Library.Shared;

    public class BeckhoffControllerAccess
    {
        /// <summary>
        /// Ecolab_GetBeckhoffPlcTags method will get all beckhoff tags realated to the plant
        /// </summary>
        /// <param name="ecolabAccountNo"></param>
        /// <param name="ControllerId"></param>
        /// <returns></returns>
        public static List<PLCTag> GetBeckhoffPlcController(int ecolabAccountNo, int ControllerId)
        {
            try
            {
                return DbClient.ExecuteReader<PLCTag>(Resources.Ecolab_GetBeckhoffPlcTags,
                 delegate(DbCommand cmd, DbContext context)
                 {
                     // cmd.CommandType = CommandType.Text;
                     cmd.AddParameter("@ecolabAccountNumber", ecolabAccountNo);
                     cmd.AddParameter("@ControllerId ", ControllerId);
                 }).ToList();
            }
            catch (System.Exception ex)
            {
                ILogService logService = new FileLogService(typeof(ControllerAccess));
                logService.LogError("Error Occurred at: ControllerAccess -> GetPlantParameterDetails:" + ex.StackTrace.ToString());
                return null;
            }
        }

        public static List<DateTime> GetBeckhoffPlcDateTimeStamp()
        {
            try
            {
                return DbClient.ExecuteReader<DateTime>(Resources.Ecolab_GetBeckhoffPlcDateTime,
                 delegate(DbCommand cmd, DbContext context)
                 {
                     // cmd.CommandType = CommandType.Text;
                     //cmd.AddParameter("@ecolabAccountNumber", ecolabAccountNo);
                     // cmd.AddParameter("@ControllerId ", ControllerId);
                 }).ToList();
            }
            catch (System.Exception ex)
            {
                return null;

            }
        }
        public static bool SaveBhPlcConventionalBatchData(WasherTag TagInfo, bool IsNewBatch)
        {
            try
            {
                DbClient.ExecuteNonQuery("TCD.SaveBhPlcConventionalBatchData",
                   delegate(DbCommand cmd, DbContext context)
                   {
                       cmd.CommandType = CommandType.StoredProcedure;
                       cmd.AddParameter("WasherId ", TagInfo.WasherId);
                       cmd.AddParameter("OperationalCount", TagInfo.OperationCounter);
                       cmd.AddParameter("CurrentFormula", TagInfo.CurrentFormula);
                       cmd.AddParameter("CurrentInjection", TagInfo.CurrentInjection);
                       //Update this to send from the actual tag values
                       cmd.AddParameter("DateTimeStamp", DbType.DateTime, TagInfo.DateTimeStamp);
                       cmd.AddParameter("IsNewBatch", IsNewBatch);
                   });
                return true;
            }
            catch (System.Exception ex)
            {

                return false;
            }
        }
      
    }
}
