﻿SELECT DISTINCT Bht.BeckhoffTagId
				,Bht.TagAddress
				,Tt.TagType
				,Mst.ControllerId
				,'Washer' + convert(varchar(100),Mst.WasherId )[AssociatedTo]				
				, 0 AS Readfrequency
				, 0 AS AllowableDeviation																			
		FROM [TCD].WasherTags Wt 
		INNER JOIN [TCD].BeckhoffTagMapping Bhtm ON Bhtm.WasherTagId=Wt.WasherTagId and Bhtm.Active=1
		INNER JOIN  [TCD].BeckhoffTags Bht ON Bht.BeckhoffTagId=Bhtm.BeckhoffTagId and Wt.Active=1
		INNER JOIN  [TCD].MachineSetup Mst ON Mst.WasherId=Wt.WasherId
		INNER JOIN [TCD].WasherGroup Wsg ON Wsg.WasherGroupId=Mst.GroupId 
		INNER JOIN [TCD].Washer WS ON ws.WasherId = Mst.WasherId and ws.AWEActive=1
		INNER JOIN [TCD].WasherTags Wat ON Wat.washerID = WS.washerId and Wat.Active=1
		INNER JOIN [TCD].TagType Tt ON Tt.TagType = WT.Tagtype and Wt.Active=1
		WHERE Bht.Active=1 AND MST.EcoalabAccountNumber=@ecolabAccountNumber AND MST.ControllerId=@ControllerId
		ORDER BY bht.BeckhoffTagId ASC