﻿SELECT Top 1 StartDate	FROM [TCD].BatchData
