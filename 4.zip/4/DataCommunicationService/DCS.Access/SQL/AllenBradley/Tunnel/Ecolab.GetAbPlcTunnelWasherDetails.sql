﻿SELECT   TDS.CompartmentNumber
		,TDPM.ProductId
		,TDPM.Quantity AS StandardQuantity
		,ws.WasherId
		,TPS.NominalLoad [Standard Quantity]
		,MST.NumberOfComp [NumberOfCompartments]
		,TPS.ProgramNumber 
		,TPS.TunnelProgramSetupId
		,TDPM.InjectionNumber
		,TDPM.TunnelDosingSetupId
		,TDPM.TunnelDosingProductMappingId
FROM [TCD].Washer WS
INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId
INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.WasherGroupId = WG.WasherGroupId
INNER JOIN [TCD].TunnelDosingSetup TDS ON TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId
LEFT JOIN [TCD].TunnelDosingProductMapping  TDPM ON TDPM.TunnelDosingSetupId =TDS.TunnelDosingSetupId
where MST.WasherId = @WasherId