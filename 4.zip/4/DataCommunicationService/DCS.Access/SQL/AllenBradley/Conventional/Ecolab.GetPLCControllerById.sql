﻿	SELECT	Ctrl.ControllerId
			,Ctrl.EcoalabAccountNumber
			,CT.Name[ControllerType]			
			,Ctrl.Description
			,Ctrl.IPAddress
			,Ctrl.ComPort
			,Ctrl.LastConnectedTime			
			,Ctrl.InstallDate
			,'Matrikon.OPC.Simulation' as OPCServerName 
			,Ctrl.Name[Node]
			FROM   [TCD].[ConduitController] Ctrl
			INNER JOIN [TCD].ControllerType CT ON Ctrl.ControllerTypeId = CT.Id	
			INNER JOIN [TCD].Plant PL ON PL.EcolabAccountNumber = Ctrl.EcoalabAccountNumber	
			LEFT JOIN [TCD].ControllerTagNode CPN ON CPN.ControllerID = Ctrl.ControllerId
			WHERE ctrl.ControllerId = @controllerId