﻿SELECT WT.WasherTagId as 'TagId'
	 ,WT.TagAddress
	 ,TT.TagDescription
	 ,CC.ControllerId
	 ,WGT.WasherGroupTypeName  + ' Washer' + convert(varchar(100),MS.WasherId )[AssociatedTo]
	 , 0 AS Readfrequency
	 , 0 AS AllowableDeviation
	 FROM [TCD].MachineSetup  MS 
JOIN [TCD].Washer WS ON ws.WasherId = MS.WasherId and Ws.AWEActive=1
JOIN [TCD].WasherTags WT ON WT.washerID = WS.washerId and WT.Active=1
JOIN [TCD].TagType TT ON TT.TagType = WT.Tagtype and TT.Active=1
JOIN [TCD].ConduitController CC ON CC.ControllerId  = MS.ControllerId and CC.Active=1
JOIN [TCD].Plant PL ON PL.EcolabAccountNumber = CC.EcoalabAccountNumber 
JOIN [TCD].WasherGroup WG on WG.WasherGroupId = MS.GroupId 
JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId  
WHERE PL.EcolabAccountNumber= @ecolabAccountNumber AND CC.ControllerId = @ControllerId