﻿BEGIN
		DECLARE @EcolabWaherId int,@EndofFormula INT=128 -- Need to check with other team
		select @EcolabWaherId=EcolabWasherId from [TCD].Washer where WasherId= @WasherId
		SELECT @BatchID =  batchid from Batchdata where EcolabWasherId  = @EcolabWaherId AND EndDate is null
		DECLARE @MachineInternalId INT , @GroupId INT 

	BEGIN TRANSACTION
	BEGIN TRY
	SELECT @BatchID AS BatchId,@EcolabWaherId as EcolabWaherId
		IF (@BatchID IS NULL)
		BEGIN		
			
			INSERT INTO BatchData(
						ControllerBatchId ,
						EcolabWasherId,
						WasherGroupId ,
						MachineInternalId,
						StartDate ,
						EndDate ,
						ProgramNumber,
						ActualWeight,
						StandardWeight,
						CurrencyCode)

			SELECT DISTINCT 0
						,@EcolabWaherId
						,MST.GroupId
						,Mst.MachineInternalId
						,GETUTCDATE()AS StartDate
						,NULL
						,CPS.ProgramNumber
						,NULL
						,cps.NominalLoad StandardWeight
						,Pl.CurrencyCode
			FROM [TCD].Washer Ws
				INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = Ws.WasherId
				INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
				INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
				INNER JOIN [TCD].WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
				INNER JOIN [TCD].WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
				INNER JOIN [TCD].WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupId
				INNER JOIN [TCD].Plant Pl on Pl.EcolabAccountNumber=Ws.EcoLabAccountNumber
			WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula
		
			SET @BatchId=SCOPE_IDENTITY()	

			INSERT INTO BatchProductData(BatchId,BatchWashStepId,ProductID,ActualQuantity,StandardQuantity,Price)
			SELECT @BatchId		
				,NULL--CDS.StepNumber        
				,CDPM.ProductId
				,NULL
				,CDPM.Quantity AS StandardQuantity
				,NULL
			FROM [TCD].Washer WS
				INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId
				INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
				INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = 
				WG.WasherGroupTypeId
				INNER JOIN [TCD].WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
				INNER JOIN [TCD].WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
				LEFT JOIN [TCD].WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupID
			WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula

		END	
		ELSE IF((@BatchID IS NOT NULL) AND (@CurrentFormula = @EndofFormula))
			BEGIN
				
				IF EXISTS (SELECT TOP 1 * FROM BatchData WHERE  BatchId=@BatchId)
				BEGIN				
					UPDATE BatchData
					SET EndDate= GETUTCDATE()
					WHERE  BatchId=@BatchId
				END 				
			END

			SELECT @MachineInternalId=MachineInternalId,@GroupId=GroupId FROM MachineSetup WHERE WasherId=@WasherId

			INSERT INTO [TCD].WasherReading(GroupId,MachineInternalId,WasherId,ProgramNumber,CurrentInjection,OperationCounter,DosingAmount,CreatedDate) VALUES(
			@MachineInternalId , @GroupId, @WasherId , @CurrentFormula,@Injection,@OperationalCount, NULL,GETUTCDATE()  )
		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
	 DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();
    
    RAISERROR (@ErrorMessage, -- Message text.
               @ErrorSeverity, -- Severity.
               @ErrorState -- State.
               );
		ROLLBACK TRANSACTION;
	END CATCH;
END