﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Library.Shared
{
    public sealed class FileLogService : ILogService
   { 
        //Logging Varable
        readonly ILog _logger;

        /// <summary>
        /// FileLogService
        /// </summary>
        static FileLogService()
        {

            // Gets directory path of the calling application
            // RelativeSearchPath is null if the executing assembly i.e. calling assembly is a
            // stand alone exe file (Console, WinForm, etc). 
            // RelativeSearchPath is not null if the calling assembly is a web hosted application i.e. a web site
            var log4NetConfigDirectory = AppDomain.CurrentDomain.RelativeSearchPath ?? AppDomain.CurrentDomain.BaseDirectory;

            var log4NetConfigFilePath = Path.Combine(log4NetConfigDirectory, "log4net.config");
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(log4NetConfigFilePath));

        }
        /// <summary>
        /// FileLogService
        /// </summary>
        /// <param name="logClass"></param>
        public FileLogService(Type logClass)
        {
            _logger = LogManager.GetLogger(logClass);
        }
        /// <summary>
        /// Fatal
        /// </summary>
        /// <param name="errorMessage"></param>
        public void LogFatal(string errorMessage)
        {
            if (_logger.IsFatalEnabled)
                _logger.Fatal(errorMessage);
        }
        /// <summary>
        /// Error
        /// </summary>
        /// <param name="errorMessage"></param>
		public void LogError(string errorMessage)
        {
            if (_logger.IsErrorEnabled)
                _logger.Error(errorMessage);
        }
        /// <summary>
        /// Warning
        /// </summary>
        /// <param name="message"></param>
        public void LogWarning(string message)
        {
            if (_logger.IsWarnEnabled)
                _logger.Warn(message);
        }
        /// <summary>
        /// Info
        /// </summary>
        /// <param name="message"></param>
        public void LogInfo(string message)
        {
            if (_logger.IsInfoEnabled)
                _logger.Info(message);
        }
        /// <summary>
        /// Debug
        /// </summary>
        /// <param name="message"></param>
        public void LogDebug(string message)
        {
            if (_logger.IsDebugEnabled)
                _logger.Debug(message);
        }
    }
}
