﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Library.Shared
{
    public interface ILogService
    {
        /// <summary>
        /// Fatal
        /// </summary>
        /// <param name="message"></param>
        void LogFatal(string message);
        /// <summary>
        /// Error
        /// </summary>
        /// <param name="message"></param>
        void LogError(string message);
        /// <summary>
        /// Warning
        /// </summary>
        /// <param name="message"></param>
        void LogWarning(string message);
        /// <summary>
        /// Info
        /// </summary>
        /// <param name="message"></param>
        void LogInfo(string message);
        /// <summary>
        /// Debug
        /// </summary>
        /// <param name="message"></param>
        void LogDebug(string message);
    }
}
