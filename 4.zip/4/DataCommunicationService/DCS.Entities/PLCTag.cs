﻿// -----------------------------------------------------------------------
// <copyright file="PLCTag.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The PLCTag </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Data.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    public class PLCTag
    {
        public PLCTag(int tagId, string tagAddress, string tagDescription, int controllerId, string associatedTo,int readfrequency, int allowableDeviation)
        {
            this.TagId = tagId;
            this.TagAddress = tagAddress;
            this.TagDescription = tagDescription;
            this.ControllerId = controllerId;
            this.AssociatedTo = associatedTo;
            this.Readfrequency = readfrequency;
            this.AllowableDeviation = allowableDeviation;

        }

        public PLCTag(int tagId, string tagAddress, string tagDescription, int controllerId, string associatedTo,
       int readfrequency, int allowableDeviation, int beckHoffData, DateTime dateTimeStamp)
        {
            this.TagId = tagId;
            this.TagAddress = tagAddress;
            this.TagDescription = tagDescription;
            this.ControllerId = controllerId;
            this.AssociatedTo = associatedTo;
            this.Readfrequency = readfrequency;
            this.AllowableDeviation = allowableDeviation;
            this.BeckHoffData = beckHoffData;


        }

        /// <summary>
        /// Gets or sets TagId
        /// </summary>
        public int TagId { get; set; }

        /// <summary>
        ///  Gets or sets TagAddress
        /// </summary>
        public string TagAddress { get; set; }

        /// <summary>
        ///  Gets or sets TagDescription
        /// </summary>
        public string TagDescription { get; set; }

        /// <summary>
        ///  Gets or sets ControllerId
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        ///  Gets or sets AssociatedTo
        /// </summary>
        public string AssociatedTo { get; set; }

        /// <summary>
        ///  Gets or sets Readfrequency
        /// </summary>
        public int Readfrequency { get; set; }        
        /// <summary>
        ///  Gets or sets AllowableDeviation
        /// </summary>
        public int AllowableDeviation { get; set; }
        /// <summary>
        ///  Gets or sets BeckHoffData
        /// </summary>
        public int BeckHoffData { get; set; }
        /// <summary>
        ///  Gets or sets DateTimeStamp
        /// </summary>
        public DateTime DateTimeStamp { get; set; }

    }
}