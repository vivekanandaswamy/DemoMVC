﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities
{
    public class BeckhoffXmlTag
    {

        public BeckhoffXmlTag()
        { }
        public BeckhoffXmlTag(int tagId, string tagAddress, int data, DateTime dateTimeStamp)
        {
            this.TagId = tagId;
            this.TagAddress = tagAddress;
            this.Data = data;
            this.DateTimeStamp = dateTimeStamp;
        }
        public int TagId { get; set; }
        public string TagAddress { get; set; }
        public int Data { get; set; }
        public DateTime DateTimeStamp { get; set; }
    }
}
