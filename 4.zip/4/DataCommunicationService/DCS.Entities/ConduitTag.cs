﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities
{
    public class ConduitTag
    {

        /// <summary>
        /// TagName
        /// </summary>
        public string TagName { get; set; }

        /// <summary>
        /// TagValue
        /// </summary>        
        public string TagValue { get; set; }

        /// <summary>
        /// IsValidTag
        /// </summary>
        public bool IsValidTag { get; set; }

        /// <summary>
        /// ExceptionCode 
        /// </summary>
        public string ExceptionCode { get; set; }

        /// <summary>
        /// ExceptionCode 
        /// </summary>
        public string TimeStamp { get; set; }

    }
}