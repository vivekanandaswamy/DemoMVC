﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities
{
    public class WasherTag
    {
        public int WasherId
        {
            get;
            set;
        }

        public int CurrentFormula
        {
            get;
            set;
        }
        public int CurrentInjection
        {
            get;
            set;
        }
        public int OperationCounter
        {
            get;
            set;
        }
        public int AWEFormula
        {
            get;
            set;
        }
        public int EOFSignal
        {
            get;
            set;
        }
        public string Mode
        {
            get;
            set;
        }
        public string FlushTime
        {
            get;
            set;
        }
        public String InjectionClass
        {
            get;
            set;
        }
        public string InjectionRatio
        {
            get;
            set;
        }
        public int OnHold
        {
            get;
            set;
        }
        public int AWEActive
        {
            get;
            set;
        }
        public int HoldDelay
        {
            get;
            set;
        }
        public int RatioDosingActive
        {
            get;
            set;
        }
        public string RatioDosingPercentage
        {
            get;
            set;
        }
        public int WasherNumber
        {
            get;
            set;
        }
        public int EOFValue
        {
            get;
            set;
        }

        public string WasherGroup
        {
            get;
            set;
        }
        public DateTime DateTimeStamp
        {
            get;
            set;
        }
        public int BatchID
        {
            get;
            set;
        }
        public int steprunTime
        {
            get;
            set;
        }
        public int NumberOfCompartments
        {
            get;
            set;
        }
    }
}
