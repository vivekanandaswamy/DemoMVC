﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace Ecolab.Data.Entities
{
	[DataContract]
	public class PLCController
	{
		/// <summary>
		/// Controller
		/// </summary>
		/// <param name="controllerId"></param>
		/// <param name="ecolabAccountNumber"></param>
		/// <param name="controllerType"></param>
		/// <param name="name"></param>
		/// <param name="description"></param>
		/// <param name="ipAddress"></param>
		/// <param name="comPort"></param>
		/// <param name="lastConnectedTime"></param>
		/// <param name="active"></param>
		/// <param name="washersCount"></param>
		/// <param name="tunnelsCount"></param>
		/// <param name="pumpsCount"></param>
		/// <param name="equipmentsCount"></param>
		/// <param name="createdDate"></param>
		/// <param name="opcServerName"></param>
		/// <param name="groupName"></param>
        public PLCController(int controllerId, string ecolabAccountNumber, string controllerType
                            , string description, string ipAddress, int comPort, DateTime lastConnectedTime, DateTime createdDate, string opcServerName, string Name)
		{

			this.controllerId = controllerId;
			this.ecolabAccountNumber = ecolabAccountNumber;
			this.controllerType = controllerType;
			this.description = description;
			this.ipAddress = ipAddress;
			this.comPort = comPort;
			this.lastConnectedTime = lastConnectedTime;
			this.createdDate = createdDate;
			this.opcServerName = opcServerName;
			this.node = Name;
		}
		# region Properties

		/// <summary>
		/// Gets or sets controllerId 
		/// </summary>
		/// <value> Controller Id.</value>        
		public int controllerId { get; set; }

		/// <summary>
		/// Gets or sets EcoalabAccountNumber 
		/// </summary>
		/// <value> EcoalabAccountNumber.</value>        
		public string ecolabAccountNumber { get; set; }

		/// <summary>
		/// Gets or sets controllerTypeId 
		/// </summary>
		/// <value> Controller Type Id.</value>        
		public string controllerType { get; set; }

		/// <summary>
		/// Gets or sets Name 
		/// </summary>
		/// <value> Name.</value>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets description 
		/// </summary>
		/// <value> description.</value>
		public string description { get; set; }

		/// <summary>
		/// Gets or sets ipAddress 
		/// </summary>
		/// <value> ipAddress.</value>
		public string ipAddress { get; set; }

		/// <summary>
		/// Gets or sets comPort 
		/// </summary>
		/// <value> comPort.</value>
		public int comPort { get; set; }

		/// <summary>
		/// Gets or sets lastConnectedTime 
		/// </summary>
		/// <value> lastConnectedTime.</value>
		public DateTime lastConnectedTime { get; set; }
		
		/// <summary>
		/// Gets or sets createdDate 
		/// </summary>
		/// <value> createdDate.</value>		
		public DateTime createdDate { get; set; }

		/// <summary>
		/// Gets or sets opcServerName 
		/// </summary>
		/// <value> opcServerName.</value>
		public string opcServerName { get; set; }

		/// <summary>
		/// Gets or sets node 
		/// </summary>
		/// <value> node.</value>
		public string node { get; set; }

		# endregion Properties


	}
}
