﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
    public class BatchParameters
    {
		public BatchParameters(int batchParameterTypeId, int batchWashStepId, float averageValue, float minimumValue, float maximumValue, int parameterStatus)
		{
			this.BatchParameterTypeId = batchParameterTypeId;
			this.BatchWashStepId = batchWashStepId;
			this.AverageValue = averageValue;
			this.MinimumValue = minimumValue;
			this.MaximumValue = maximumValue;
			this.ParameterStatus = parameterStatus;
		}
		public int BatchParameterTypeId { get; set; }
		public int BatchWashStepId { get; set; }
		public float AverageValue { get; set; }
		public float MinimumValue { get; set; }
		public float MaximumValue { get; set; }
		public int ParameterStatus { get; set; }
    }
}
