﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
   public class BatchData
    {
       public BatchData(int batchId, int controllerBatchId, string ecoLabWasherId, int groupId, int machineInternalId, DateTime startDate, DateTime endDate, int programNumber, int actualWeight, int standardWeight, int currencyTypeId)
       {
           this.BatchId = batchId;
           this.ControllerBatchId = controllerBatchId;
           this.EcoLabWasherId = ecoLabWasherId;
           this.GroupId = groupId;
           this.MachineInternalId = machineInternalId;
           this.StartDate = startDate;
           this.EndDate = endDate;
           this.ProgramNumber = programNumber;
           this.ActualWeight = actualWeight;
           this.StandardWeight = standardWeight;
           this.CurrencyTypeId = currencyTypeId;
       }
	   public int BatchId { get; set; }
       public int ControllerBatchId { get; set; }
       public string EcoLabWasherId { get; set; }
       public int GroupId { get; set; }
       public int MachineInternalId { get; set; }
       public DateTime StartDate { get; set; }
       public DateTime EndDate { get; set; }
       public int ProgramNumber { get; set; }
       public int ActualWeight { get; set; }
       public int StandardWeight { get; set; }
       public int CurrencyTypeId { get; set; }
    }
}
