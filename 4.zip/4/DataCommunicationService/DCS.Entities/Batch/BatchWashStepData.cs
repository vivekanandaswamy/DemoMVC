﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
	public class BatchWashStepData
	{
		public BatchWashStepData(int batchWashStepId, int batchId, int stepCompartment, int washTime, int currentInjection, DateTime startTime, DateTime endTime)
		{
			this.BatchWashStepId = batchWashStepId;
			this.BatchId = batchId;
			this.StepCompartment = stepCompartment;
			this.WashTime = washTime;
			this.CurrentInjection = currentInjection;
			this.StartTime = startTime;
			this.EndTime = endTime;
		}
		public int BatchWashStepId { get; set; }
		public int BatchId { get; set; }
		public int StepCompartment { get; set; }
		public int WashTime { get; set; }
		public int CurrentInjection { get; set; }
		public DateTime StartTime { get; set; }
		public DateTime EndTime { get; set; }

	}
}
