﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
	public class BatchStepWaterUsageData
	{
		public BatchStepWaterUsageData(int batchWashStepId, int waterTypeId, float actualQuantity, float standardQuantity, float price)
		{
			this.BatchWashStepId = batchWashStepId;
			this.WaterTypeId = waterTypeId;
			this.ActualQuantity = actualQuantity;
			this.StandardQuantity = standardQuantity;
			this.Price = price;
		}
		public int BatchWashStepId { get; set; }
		public int WaterTypeId { get; set; }
		public float ActualQuantity { get; set; }
		public float StandardQuantity { get; set; }
		public float Price { get; set; }
	}
}
