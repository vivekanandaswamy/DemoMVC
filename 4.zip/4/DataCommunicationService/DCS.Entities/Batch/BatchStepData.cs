﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
	public class BatchStepData
	{
        public int BatchId
        {
            get;
            set;
        }
        public int BatchFormula
        {
            get;
            set;
        }
        public int BatchInjection
        {
            get;
            set;
        }
        public int BatchOPCounter
        {
            get;
            set;
        }
        public int BatchStepCompartment
        {
            get;
            set;
        }
		
        public string StepRunTime
        {
            get;
            set;
        }
        public int TransferTime
        {
            get;
            set;

        }
	}
}
