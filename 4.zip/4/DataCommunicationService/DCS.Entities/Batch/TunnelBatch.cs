﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
    public class TunnelBatch
    {
        /// <summary>
        /// BatchId
        /// </summary>
        public int BatchId
        {
            get;
            set;
        }

        public int WasherId
        {
            get;
            set;
        }
        public int washerType
        {
            get;
            set;
        }
        
        public int StepCompartments
        {
            get;
            set;
        }

    }
}
