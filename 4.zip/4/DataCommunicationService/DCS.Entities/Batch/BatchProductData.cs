﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
	public class BatchProductData
	{
		public BatchProductData(int batchId, int batchWashStepId, int productId, float actualQuantity, float standardQuantity, float price)
		{
			this.BatchId = batchId;
			this.BatchWashStepId = batchWashStepId;
			this.ProductId = productId;
			this.ActualQuantity = actualQuantity;
			this.StandardQuantity = standardQuantity;
			this.Price = price;
		}
		public int BatchId { get; set; }
		public int BatchWashStepId { get; set; }
		public int ProductId { get; set; }
		public float ActualQuantity { get; set; }
		public float StandardQuantity { get; set; }
		public float Price { get; set; }
	}
}
