﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
   public class BatchCustomerData
    {
       public BatchCustomerData(int batchId, int customerId, int load, int piecesCount)
       {
		   this.BatchId = batchId;
		   this.CustomerId = customerId;
           this.Load = load;
           this.PiecesCount = piecesCount;

       }
       public int BatchId { get; set; }
       public int CustomerId { get; set; }
       public int Load { get; set; }
       public int PiecesCount { get; set; }
    }
}
