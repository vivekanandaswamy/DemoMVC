﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
   public	class BatchParameterTypes
	{
	   public BatchParameterTypes(int batchParameterTypeId, string parameterName, DateTime createdDate)
	   {
		   this.BatchParameterTypeId = batchParameterTypeId;
		   this.ParameterName = parameterName;
		   this.CreatedDate = createdDate;
	   }
	   public int BatchParameterTypeId { get; set; }
	   public string ParameterName { get; set; }
	   public DateTime CreatedDate { get; set; }
	}
}
