﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Controller
{
   public class ControllerType
    {
        public ControllerType(int controllerTypeId, string name, int regionId, char active, int version)
        {
			this.controllerTypeId = controllerTypeId;
            this.name = name;
            this.regionId = regionId;
            this.active = active;
            this.version = version;

        }

        #region Properties

        /// <summary>
        /// Gets or sets controllerTypeId 
        /// </summary>
        /// <value> controllerTypeId.</value> 
        public int controllerTypeId { get; set; }

        /// <summary>
        /// Gets or sets name 
        /// </summary>
        /// <value>name.</value> 
        public string name { get; set; }

        /// <summary>
        /// Gets or sets regionId 
        /// </summary>
        /// <value> regionId.</value> 
        public int regionId { get; set; }

        /// <summary>
        /// Gets or sets active 
        /// </summary>
        /// <value> active.</value> 
        public char active { get; set; }

        /// <summary>
        /// Gets or sets version 
        /// </summary>
        /// <value> version.</value> 
        public int version { get; set; }

        #endregion Properties
    }
}
