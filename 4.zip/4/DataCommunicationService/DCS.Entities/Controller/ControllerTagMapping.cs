﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Controller
{
	public class ControllerTagMapping
	{
		/// <summary>
		/// ControllerParameters
		/// </summary>
		/// <param name="tagId"></param>
		/// <param name="tagAddress"></param>
		/// <param name="tagDescription"></param>
		/// <param name="resourceKey"></param>
		/// <param name="controllerId"></param>
		/// <param name="controllerGroupID"></param>
		/// <param name="ecolabAccountNumber"></param>
		/// <param name="defaultValue"></param>
		/// <param name="allowableDeviation"></param>
		/// <param name="active"></param>
		/// <param name="createdDate"></param>
		/// <param name="groupName"></param>
		/// <param name="readFrequency"></param>
		public ControllerTagMapping(int tagId, string tagAddress, string tagDescription, string resourceKey, int controllerId
								   , int controllerGroupID, string ecolabAccountNumber, string defaultValue
								   , int allowableDeviation, bool active, DateTime createdDate, string groupName, int readFrequency)
		{
			this.tagId = tagId;
			this.tagAddress = tagAddress;
			this.tagDescription = tagDescription;
			this.controllerId = controllerId;
			this.controllerGroupID = controllerGroupID;
			this.ecolabAccountNumber = ecolabAccountNumber;
			this.defaultValue = defaultValue;
			this.allowableDeviation = allowableDeviation;
			this.createdDate = createdDate.ToLongDateString();
			this.groupName = groupName;
			this.readFrequency = readFrequency;
		}

		# region Properties
		/// <summary>
		/// Gets or sets ControllerParameterId 
		/// </summary>
		/// <value> ControllerParameterId.</value> 
		public int tagId { get; set; }
		/// <summary>
		/// Gets or sets AddressValue 
		/// </summary>
		/// <value>AddressValue.</value> 
		public string tagAddress { get; set; }
		/// <summary>
		/// Gets or sets Description 
		/// </summary>
		/// <value> Description.</value> 
		public string tagDescription { get; set; }
		/// <summary>
		/// Gets or sets resourceKey 
		/// </summary>
		/// <value> resourceKey.</value> 
		public string resourceKey { get; set; }
		/// <summary>
		/// Gets or sets ControllerTypeId 
		/// </summary>
		/// <value> ControllerTypeId.</value> 
		public int controllerId { get; set; }
		/// <summary>
		/// Gets or sets controllerGroupID 
		/// </summary>
		/// <value> controllerGroupID.</value> 
		public int controllerGroupID { get; set; }
		/// <summary>
		/// Gets or sets ecolabAccountNumber 
		/// </summary>
		/// <value> ecolabAccountNumber.</value> 
		public string ecolabAccountNumber { get; set; }
		/// <summary>
		/// Gets or sets defaultValue 
		/// </summary>
		/// <value> defaultValue.</value> 
		public string defaultValue { get; set; }
		/// <summary>
		/// Gets or sets TrackChangeVal 
		/// </summary>
		/// <value> TrackChangeVal.</value> 
		public int allowableDeviation { get; set; }
		/// <summary>
		/// Gets or sets IsDisplay 
		/// </summary>
		/// <value> IsDisplay.</value> 
		public bool active { get; set; }
		/// <summary>
		/// Gets or sets createdDate 
		/// </summary>
		/// <value> createdDate.</value> 
		public string createdDate { get; set; }
		/// <summary>
		/// Gets or sets groupName 
		/// </summary>
		/// <value> groupName.</value> 
		public string groupName { get; set; }
		/// <summary>
		/// Gets or sets readFrequency 
		/// </summary>
		/// <value> readFrequency.</value> 
		public int readFrequency { get; set; }
		#endregion Properties
	}
}
