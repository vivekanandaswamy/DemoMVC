﻿/*  
 ************************************************************************************************************************************************************************
 Purpose:  
 Author:  Pavan Sriramula
 Date Created: 10-Oct-2014

 Modification History:
 ************************************************************************************************************************************************************************
 Author                  Date             Modification Details
 ======                 ======           ======================= 
 Pavan Sriramula      10-Oct-2014          1)  
										   2) 
										   3) 
 ************************************************************************************************************************************************************************
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Controller
{
	public class ControllerParameterValues
	{
		/// <summary>
		/// ControllerParameterValues
		/// </summary>
		/// <param name="controllerId"></param>
		/// <param name="parameterId"></param>
		/// <param name="value"></param>
		/// <param name="timeStamp"></param>
		public ControllerParameterValues(int controllerId, string parameterId, string value, string timeStamp)
		{
			this.controllerId = controllerId;
			this.parameterId = parameterId;
			this.Value = value;
			this.timeStamp = timeStamp;
		}
		#region Properties

		/// <summary>
		/// Gets or sets controllerId 
		/// </summary>
		/// <value> controllerId.</value> 
		public int controllerId { get; set; }
		/// <summary>
		/// Gets or sets parameterId 
		/// </summary>
		/// <value> parameterId.</value> 
		public string parameterId { get; set; }
		/// <summary>
		/// Gets or sets Value 
		/// </summary>
		/// <value> Value.</value> 
		public string Value { get; set; }
		/// <summary>
		/// Gets or sets timeStamp 
		/// </summary>
		/// <value> timeStamp.</value> 
		public string timeStamp { get; set; }

		#endregion Properties
	}
}
