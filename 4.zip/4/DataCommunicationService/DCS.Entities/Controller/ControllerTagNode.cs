﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Controller
{
   public class ControllerTagNode
    {
	   public ControllerTagNode(string controllerTagNodeId, string node, int controllerId, bool active, DateTime createdDate)
        {
            this.controllerTagNodeId = controllerTagNodeId;
			this.node = node;
            this.controllerId = controllerId;
            this.createdDate = createdDate;
            this.active = active;
        }
        public string controllerTagNodeId { get; set; }
		public string node { get; set; }
        public int controllerId { get; set; }        
        public bool active { get; set; }
        public DateTime createdDate { get; set; }
    }
}
