﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Controller
{
    public class ControllerGroups
    {
		public ControllerGroups(int controllerGroupId, string groupName, int controllerTypeId, int readFrequency)
        {
            this.controllerGroupId = controllerGroupId;
            this.groupName = groupName;
            this.controllerGroupId = controllerTypeId;
			this.readFrequency = readFrequency;
        }
        public int controllerGroupId { get; set; }
        public string groupName { get; set; }
        public int controllerTypeId { get; set; }
        public int readFrequency { get; set; }

    }
}
