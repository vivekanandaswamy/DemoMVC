﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Controller
{
   public class ControllerTagValues
    {
	   public ControllerTagValues(int controllerParameterValueId, int controllerParameterId, string value, DateTime receivedTime)
       {
           this.controllerParameterValueId = controllerParameterValueId;
           this.controllerParameterId = controllerParameterId;
		   this.value = value;
           this.receivedTime = receivedTime;
       }
       public int controllerParameterValueId { get; set; }
       public int controllerParameterId { get; set; }
	   public string value { get; set; }
       public DateTime receivedTime { get; set; }
    }
}
