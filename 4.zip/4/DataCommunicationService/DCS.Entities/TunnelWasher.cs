﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Data.Entities.Batch
{
    public class TunnelWasher
    {
        public TunnelWasher(Int32 washerId, Int16 standardWeight, Int32 numberOfCompartments, Int16 currentFormula)
        {
            this.WasherId = washerId;
            this.NumberOfCompartments = numberOfCompartments;
            this.CurrentFormula = CurrentFormula;
            this.StandardWeight = standardWeight;
        }

        public int WasherId
        {
            get;
            set;
        }

        public int NumberOfCompartments
        {
            get;
            set;
        }

        public int CurrentFormula
        {
            get;
            set;
        }
        public int StandardWeight
        {
            get;
            set;
        }
    }
}
