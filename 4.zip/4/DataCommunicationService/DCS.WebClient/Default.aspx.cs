﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EcolabPlc.WebClient.ServiceReference1;
using System.Text;
using Ecolab.Data.Entities;

namespace EcolabPlc.WebClient
{


	public class CallBack : EcolabPlc.WebClient.ServiceReference1.IWritePLCServiceCallback
	{
		public string Message
		{
			get;
			set;
		}

		public void IsWriteSuccessful(bool isSuccess, string tagWritten)
		{
			Thread.Sleep(5000);
			if (isSuccess)
				this.Message = "Received and written Values:" + tagWritten;
			else
				this.Message = "Faile to write Tag:" + tagWritten;
		}
	}

	public partial class Default : System.Web.UI.Page, ICallbackEventHandler
	{
		static CallBack callback;
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				try
				{
					//Response.Write("abc");
					//Server.MapPath("abc.aspx");
				}
				catch
				{
				}
			}
		}




		protected void setupClientSideCallback()
		{
			string ScriptRef = this.ClientScript.GetCallbackEventReference(this, "'" + 0 +

		"'", "OnCallback", "'" + lblMsg.ClientID + "'");

			formBody.Attributes.Add("onload", ScriptRef);
			string script = "<script language='javascript' type='text/javascript'> " +

						 " function getServerTime() " +

						 " { " + ScriptRef + " } " +

						 " function OnCallback(Result,Context) " +

						 " { " +

						 " var lbl=document.getElementById(Context); " +

						  " lbl.innerText=Result ; " +

						  " setTimeout(getServerTime, 1000); " +

						  " } " +

						 " </script> ";

			this.ClientScript.RegisterClientScriptBlock(this.GetType(), "ClientCallback", script);

		}

		string ICallbackEventHandler.GetCallbackResult()
		{
			if (callback != null && callback.Message != null)
			{
				this.lblMsg.Text = callback.Message;
				return callback.Message;
			}
			return "From Client: Completed writting. Waiting for server to acknowledge. Please wait...";


		}

		string eventArgument;

		void ICallbackEventHandler.RaiseCallbackEvent(string eventArgument)
		{
			this.eventArgument = eventArgument;
		}

		protected void Button1_Click(object sender, EventArgs e)
		{		

			List<Tuple<string, string>> writetagValues = new List<Tuple<string, string>>();
			writetagValues.Add(new Tuple<string, string>("T1_SIZ", "2"));
			writetagValues.Add(new Tuple<string, string>("T1_DEV", "687"));
			WriteToPLC(writetagValues, 125);
		}

		public void WriteToPLC(List<Tuple<string, string>> tagsValues, int controllerId)
		{		
            try
            {
                callback = new CallBack();
                InstanceContext ic = new InstanceContext(callback);
                WritePLCServiceClient writePlcClient = new WritePLCServiceClient(ic);
                writePlcClient.WritePLCData(tagsValues, controllerId, "AllenBradley");
            }
            catch(System.Exception ex)
            {
                Response.Write(ex.InnerException);
            }          

		}

        protected void btnValidateTag_Click(object sender, EventArgs e)
        {            
            List<ConduitTag> validTags = new List<ConduitTag>();
            ConduitTag CTag;
            string[] strTags = new string[2] {"N7:0", "N7:1" };
            for (int i = 0; i < 2;i++ )
            {
                CTag = new ConduitTag();
                CTag.TagName =strTags[i];
                validTags.Add(CTag);
            }
            ValidateTagsList(validTags, 125);
        }

        private void ValidateTagsList(List<ConduitTag> validTags, int controllerId)
        {          
            StringBuilder returnNumber = new StringBuilder();
            try
            {
                callback = new CallBack();
                InstanceContext ic = new InstanceContext(callback);
                WritePLCServiceClient writePlcClient = new WritePLCServiceClient(ic);

                var res = writePlcClient.ValidateTags(validTags, controllerId);
               string y = null;
               for (int i = 0; i < res.Count; i++)
               {
                   y = returnNumber.AppendLine(res[i].TagName + " " + res[i].TagValue + "" + res[i].IsValidTag + "" + res[i].ExceptionCode).ToString();
               }
               TextBox1.Text = y;
             
            }
            catch (System.Exception ex)
            {
                Response.Write(ex.InnerException);
            }          
        }
	}
}
