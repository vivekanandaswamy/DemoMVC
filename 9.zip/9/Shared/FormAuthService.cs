﻿// -----------------------------------------------------------------------
// <copyright file="FormAuthService.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FormAuthService object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Shared.Authentication
{
    using System;
    using System.Linq;
    using System.Web;
    using System.Web.Script.Serialization;
    using System.Web.Security;
    using Ecolab.Models;
    using Services;
    using Services.Interfaces;

    /// <summary>
    ///     class FormAuthService
    /// </summary>
    public class FormAuthService : IFormsAuthentication
    {
        /// <summary>
        ///     Forms authentication login,uses login and password provided
        /// </summary>
        /// <param name="user">The User</param>
        /// <param name="createPersistentCookie">creates persistent cookie</param>
        public void SignIn(User user, bool createPersistentCookie)
        {
            CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
            serializeModel.UserId = user.UserId;
            serializeModel.UserName = user.Name;
            serializeModel.UserRoles = string.Join(",", user.Roles.Select(i => i.Code).ToArray());
            serializeModel.UserRoleIds = string.Join(",", user.Roles.Select(i => i.RoleId.ToString()).ToArray());
            serializeModel.EcolabAccountNumber = user.EcolabAccountNumber;
            serializeModel.RegionId = user.RegionId;
            serializeModel.LanguageId = user.LanguageId;
            serializeModel.Locale = user.Locale;
            JavaScriptSerializer serializer = new JavaScriptSerializer();

            string userData = serializer.Serialize(serializeModel);

            FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(1, user.Name, DateTime.Now, DateTime.Now.AddDays(30), createPersistentCookie, userData, "/");

            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(authTicket));

            if (authTicket.IsPersistent)
            {
                cookie.Expires = authTicket.Expiration;
            }

            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        /// <summary>
        ///     This method logout the logged in user
        /// </summary>
        public void SignOut()
        {
            FormsAuthentication.SignOut();
        }
    }
}