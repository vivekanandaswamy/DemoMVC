﻿// -----------------------------------------------------------------------
// <copyright file="ConduitLocalException.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved. 
// </copyright>
// <summary>The ConduitLocalException object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.ConduitLocal.Shared
{
    using System;
    using System.Web;
    using Elmah;

    /// <summary>
    ///     Enum ExceptionType
    /// </summary>
    public enum ExceptionType
    {
        /// <summary>
        ///     Indicates cache expired.
        /// </summary>
        Cache_Expired,

        /// <summary>
        ///     Indicates duplicates session.
        /// </summary>
        Duplicate_Session,

        /// <summary>
        ///     Indicates Invalid_UserName_Or_Password.
        /// </summary>
        Invalid_UserName_Or_Password,

        /// <summary>
        ///     Indicates ChangePassword_Failed.
        /// </summary>
        ChangePassword_Failed,

        /// <summary>
        ///     Indicates Generic type.
        /// </summary>
        Generic
    }

    [Serializable]
    public class ConduitLocalException : Exception
    {
        /// <summary>
        ///     ExceptionType object
        /// </summary>
        private readonly ExceptionType type;

        /// <summary>
        ///     Initializes a new instance of the <see cref="ConduitLocalException" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="type">The ExceptionType.</param>
        /// <param name="exception">The exception.</param>
        public ConduitLocalException(string message, ExceptionType type, Exception exception = null) : base(message)
        {
            this.type = type;
            Error error;
            error = exception != null ? new Error(exception) { Message = message } : new Error { Message = message };
            ErrorLog.GetDefault(HttpContext.Current).Log(error);
        }

        /// <summary>
        ///     Gets ExceptionType
        /// </summary>
        /// <value>The exception type.</value>
        public ExceptionType Type
        {
            get { return type; }
        }
    }
}