﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Ecolab.Dcs.CollectData;
using Ecolab.Dcs.CollectData.Beckhoff;
using Ecolab.Dcs.Entities;

namespace BeckhoffClient
{
    public class TestBeckhoffClient
    {
        private BeckoffDataWriter client;
        public BeckoffDataWriter Client 
        { 
            get
            { 
                client = new BeckoffDataWriter(new BeckhoffController 
                { 
                    //IpAddress = IpAddress,
                    //ComPort = Port,
                    TopicName = TopicName
                }, ".{0}");                
                return client;
            }          
        }
        public string IpAddress { get; set; }
        public int Port { get; set; }
        public string TopicName { get; set; }

        public TestBeckhoffClient()
        { }

        public TestBeckhoffClient(string ipAddress, int port, string topicName)
        {
            IpAddress = ipAddress;
            Port = port;
            TopicName = topicName;
        }

        //public ReadOnlyCollection<ClientTag> ValidateTags(List<ClientTag> tagsList)
        //{
        //    List<WCFService.BeckhoffTag> tagToValidate = GetPLCTagsFromClientTags(tagsList);

        //    tagToValidate = Client.ValidateTags(tagToValidate, IpAddress, Port);

        //    return GetClientTagsFromPLCTags(tagToValidate).AsReadOnly();
        //}

        //public ReadOnlyCollection<ClientTag> ReadAllTags(List<ClientTag> tagsList)
        //{
        //    List<WCFService.BeckhoffTag> tagToValidate = GetPLCTagsFromClientTags(tagsList);
        //    tagToValidate = Client.ReadAllPLCTags(tagToValidate, IpAddress, Port);
        //    return GetClientTagsFromPLCTags(tagToValidate).AsReadOnly();
        //    return null;
        //}

        public ReadOnlyCollection<ClientTag> WriteTags(List<ClientTag> tagsList)
        {
            List<BeckhoffTag> tagToValidate = GetPLCTagsFromClientTags(tagsList);
            tagToValidate = Client.WriteTags(tagToValidate, IpAddress, Port).ToList();
            return GetClientTagsFromPLCTags(tagToValidate).AsReadOnly();               
           
        }

        //public ReadOnlyCollection<ClientTag> WriteTags(List<ClientTag> tagsList, string amsNetAddress, int port)
        //{
        //    List<BeckhoffTag> tagToValidate = GetPLCTagsFromClientTags(tagsList);
        //    tagToValidate = Client.WriteTags(tagToValidate, amsNetAddress, port).ToList();
        //    return GetClientTagsFromPLCTags(tagToValidate).AsReadOnly();           
        //}

        private List<BeckhoffTag> GetPLCTagsFromClientTags(List<ClientTag> clientTags)
        {
            List<BeckhoffTag> tags = new List<BeckhoffTag>();
            foreach (ClientTag tag in clientTags)
            {
                tags.Add(new BeckhoffTag 
                { 
                    Address = tag.TagAddress ,
                    Value = tag.Value
                });
            }
            return tags;
        }
        
        private List<ClientTag> GetClientTagsFromPLCTags(List<BeckhoffTag> tags)
        {
            List<ClientTag> clientTags = new List<ClientTag>();

            foreach(BeckhoffTag tag in tags)
            {
                clientTags.Add(new ClientTag
                {
                    TagAddress = tag.Address,
                    Value = tag.Value
                });
            }
            return clientTags;
        }
    }
}
