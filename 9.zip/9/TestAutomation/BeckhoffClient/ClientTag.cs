﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeckhoffClient
{
    public class ClientTag
    {
        public string TagAddress { get; set; }
        public string Value { get; set; }
    }
}
