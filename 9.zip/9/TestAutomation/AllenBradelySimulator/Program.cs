﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllenBradelySimulator
{
    class Program
    {
        public static string TestParamPath
        {
            get
            {
                return string.Format(@"{0}\TestParameters\PLC\", Directory.GetCurrentDirectory());
            }
        }

        private static Ecolab.PLCTest.Utils.Injector injector;
        private static Ecolab.PLCTest.Utils.TunnelInjector tunnelInjector;
        private static string testParameter;

        static void Main(string[] args)
        {
            //Console.Title = "Beckhoff Conventional Washer Simulator";
            //testParameter = string.Format("{0}{1}", TestParamPath, "BeckhoffConvPLC.xml");

            //injector = new Ecolab.PLCTest.Utils.Injector(testParameter, "BeckSimulation");
            //injector.InjectToOPCServer();
            //Console.WriteLine("Type any key to stop simulation");

            if (null != args.FirstOrDefault())
            {
                switch (args.FirstOrDefault().ToLower())
                {
                    case "conv":
                        Console.Title = "Allen-Bradely Conventional Washer Simulator";

                        testParameter = string.Format("{0}{1}", TestParamPath, "PLC.xml");

                        injector = new Ecolab.PLCTest.Utils.Injector(testParameter, "ABSimulation");
                        injector.InjectToOPCServer();                        
                        Console.WriteLine("Type any key to stop simulation");
                        Console.Read();
                        injector.SendEOFToAllNodes();
                        break;

                    case "tunnel":
                        Console.Title = "Allen-Bradely Tunnel Simulator";
                        testParameter = string.Format("{0}{1}", TestParamPath, "ABTunnelTest.xml");
                        string tunnelConfigParameter = string.Format("{0}{1}", TestParamPath, "ABTunnelConfig.xml");

                        tunnelInjector = new Ecolab.PLCTest.Utils.TunnelInjector();
                        tunnelInjector.ExecuteTunnelInjection(testParameter, "ABTunnelSimulation", tunnelConfigParameter);
                        Console.Read();
                        tunnelInjector.CloseTunnels();
                        break;

                    case "beckconv":
                        Console.Title = "Beckhoff Conventional Washer Simulator";
                        testParameter = string.Format("{0}{1}", TestParamPath, "BeckhoffConvPLC.xml");

                        injector = new Ecolab.PLCTest.Utils.Injector(testParameter, "BeckSimulation");
                        injector.InjectToOPCServer();                        
                        Console.WriteLine("Type any key to stop simulation");
                        Console.Read();
                        injector.SendEOFToAllNodes();
                        break;
                    case "becktunnel":
                        Console.Title = "Beckhoff Tunnel Simulator";
                        testParameter = string.Format("{0}{1}", TestParamPath, "BeckhoffTunnelTest.xml");
                        string becktunnelConfigParameter = string.Format("{0}{1}", TestParamPath, "BeckhoffTunnelConfig.xml");

                        tunnelInjector = new Ecolab.PLCTest.Utils.TunnelInjector();
                        tunnelInjector.ExecuteBeckhoffTunnelInjection(testParameter, "BeckhoffTunnelSimulation", becktunnelConfigParameter);
                        Console.Read();
                        tunnelInjector.CloseTunnels();
                        break;
                }
            }
        }
    }
}
