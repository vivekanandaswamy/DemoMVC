﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Ecolab
{
    public class BaseSetings
    {
        protected static string GetValue(string XMLPath, string key)
        {
            XmlDocument xmlDoc = GetXmlDoc(XMLPath);
            XmlNodeList settingList = xmlDoc.SelectNodes("/TestSettings/TestSetting");
            foreach (XmlNode valueNode in settingList)
            {
                if (valueNode.FirstChild.Name.Equals(key))
                {
                    return valueNode.FirstChild.InnerText;
                }
            }
            //return xmlDoc.SelectNodes("/TestSettings/TestSetting");
            return null;
        }

        protected static ReadOnlyCollection<string> GetUser(string XMLPath, string key)
        {
            XmlDocument xmlDoc = GetXmlDoc(XMLPath);
            XmlNodeList settingList = xmlDoc.SelectNodes("/TestSettings/TestSetting");
            List<string> values = new List<string>();
            foreach (XmlNode valueNode in settingList)
            {
                if (valueNode["UserRoleCode"].InnerText.Equals(key))
                {
                    values.Add(valueNode["User"].InnerText);
                    values.Add(valueNode["Password"].InnerText);
                    return values.AsReadOnly();
                }
            }
            //return xmlDoc.SelectNodes("/TestSettings/TestSetting");
            return null;
        }

        protected static ReadOnlyCollection<List<string>> GetAllUsers(string XMLPath)
        {
            XmlDocument xmlDoc = GetXmlDoc(XMLPath);
            XmlNodeList settingList = xmlDoc.SelectNodes("/TestSettings/TestSetting");
            List<List<string>> mainList = new List<List<string>>();
            foreach (XmlNode valueNode in settingList)
            {
                List<string> subList = new List<string>();
                subList.Add(valueNode["User"].InnerText);
                subList.Add(valueNode["Password"].InnerText);
                subList.Add(valueNode["UserRoleCode"].InnerText);
                mainList.Add(subList);
                subList = null;
            }
            return mainList.AsReadOnly();
        }

        protected static XmlDocument GetXmlDoc(string XMLPath)
        {
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(XMLPath);
            return XmlDoc;
        }
    }
}
    