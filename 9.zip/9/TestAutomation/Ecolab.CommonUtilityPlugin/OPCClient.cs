﻿using Ecolab.Dcs.CollectData;
using Ecolab.Dcs.CollectData.Opc;
using Ecolab.Dcs.Entities;
using Framework;
using OPCAutomation;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.CommonUtilityPlugin
{
    [Export(typeof(IContainerPlugin))]
    public class OPCClient : IContainerPlugin
    {
        private List<OpcTag> abtagList = new List<OpcTag>();
        public string OPCServerAB { get; set; }
        public string TopicAB { get; set; }
        public int controllerIdAB { get; set; }
        
        public void CreateABTags(Dictionary<string,string> addressValue)
        {
            ClearTags();
            foreach(KeyValuePair<string,string> value in addressValue)
            {
                abtagList.Add(new OpcTag() { Address = value.Key , Topic = TopicAB, Value = value.Value});
            }

        }

        public void ClearTags()
        {
           abtagList.Clear();                      
        }

        public void WriteDataToABController()
        {
            var dataWriter = WriteToABController();
            dataWriter.WriteTags(abtagList, string.Empty, 0);             
        }

        private DataWriter<OpcTag> WriteToABController()
        {
            DataWriter<OpcTag> dataReader = new OpcDataWriter(new AllenBradleyController()
            {
                ControllerId = controllerIdAB,
                Name = TopicAB,
                OpcServer = OPCServerAB
            }, "[{0}]{1}");

            //tags = new List<OpcTag>();
            //OpcTag opcTag1 = new OpcTag()
            //{
            //    Address = "N7:0",
            //    Topic = "PLCNode",
            //    Value = "21"
            //};
            //tags.Add(opcTag1);
            
            return dataReader;
        }

        public OPCClient GetInstance 
        { 
            get
            {
                return new OPCClient();
            }
        }

        
        public string Description
        {
            get
            {
                return "OPCServer Plugin";
            }
            set
            {
                Description = value;
            }
        }
    }
}

    
