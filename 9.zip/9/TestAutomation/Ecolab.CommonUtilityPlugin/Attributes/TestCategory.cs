﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NUnit.Framework;
using System.Xml;
using System.IO;
using System.Diagnostics;

namespace Ecolab
{
    public enum TestType
    {
        functional,
        regression,
        bvt,
        ondemand,
        dcsAB,
        plc,
        reports,
        businessScenarios,
        NA_Regression,
        EU_Regression,
        NA_Sanity,
        EU_Sanity,
        NA_NonSanityRegression
    }
    public class TestCategoryAttribute : CategoryAttribute
    {

        private static string ExcludedFilePath 
        { 
            get
            {
                return string.Format(@"{0}\Config\ExcludedTest.xml", Directory.GetCurrentDirectory());
            }
        }
        
        private static List<XmlNode> excludedTestList;
        private static List<XmlNode> ExcludedTestList 
        { 
            get
            {
                if(null == excludedTestList)
                {
                    excludedTestList = new List<XmlNode>();
                    foreach (XmlNode node in GetExcludedTests(ExcludedFilePath))
                    {                        
                        excludedTestList.Add(node);
                    }
                }

                return excludedTestList;

            }
            
        }
        
        public TestCategoryAttribute(TestType type)
            : base(ConvertTestTypeToString(type))
        {}

        public TestCategoryAttribute(TestType type,string testName)
            : base(ConvertTestTypeToString(type, testName))
        { }

        private static string ConvertTestTypeToString(TestType type)
        {
             switch(type)
            {
                 case TestType.functional:
                    return "Functional";
                    
                 case TestType.regression:
                    return "Regression";

                 case TestType.bvt:
                    return "BVT";

                 case TestType.ondemand:
                    return "OnDemand";

                 case TestType.dcsAB:
                    return "DCS(Allen Bradely)";

                 case TestType.plc:
                    return "PLC";

                 case TestType.reports:
                    return "Reports";

                 case TestType.businessScenarios:
                    return "businessScenarios";

                 case TestType.NA_Regression:
                    return "NA_Regression";

                 case TestType.EU_Regression:
                    return "EU_Regression";

                 case TestType.NA_Sanity:
                    return "NA_Sanity";

                 case TestType.EU_Sanity:
                    return "EU_Sanity";

                 case TestType.NA_NonSanityRegression:
                    return "NA_NonSanityRegression";

                 default:
                    return "Regression";
            }
        }

        private static string ConvertTestTypeToString(TestType type, string testName)
        {
            foreach(XmlNode excludedTestName in ExcludedTestList)
            {
               if (excludedTestName.SelectSingleNode("./TestName").InnerText.Equals(testName))
                {
                    if (null != excludedTestName.SelectSingleNode("./TestSuit"))
                    {
                        return excludedTestName.SelectSingleNode("./TestSuit").InnerText;
                    }
                    else
                    {
                        return "Excluded";
                    }
                   
                }
            }

            return ConvertTestTypeToString(type);
        }

        private static XmlNodeList GetExcludedTests(string XMLPath)
        {
            XmlDocument xmlDoc = GetXmlDoc(XMLPath);

            return xmlDoc.SelectNodes("/TestCases/Test");
        }

        private static XmlDocument GetXmlDoc(string XMLPath)
        {
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(XMLPath);
            return XmlDoc;
        }       
    }
}
