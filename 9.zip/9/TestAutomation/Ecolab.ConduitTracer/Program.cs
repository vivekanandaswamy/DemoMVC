﻿using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using Ecolab.AppStateHandler.Validators;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.ConduitTracer
{
    class Program
    {
        static void Main(string[] args)
        {
            AppState.ConnectionString = ConfigurationManager.ConnectionStrings["Connection"].ToString();
            Console.ForegroundColor = ConsoleColor.Yellow;            
            Console.WriteLine("Conduit Tracer Started ... \r\n");
            Console.WriteLine("Initializing tracer ...  \r\n");
            Console.ForegroundColor = ConsoleColor.Green;

            Console.WriteLine("Presereving State \r\n");
            AppState.PreserveState<SPCallState, DBObject>();

            Console.WriteLine(string.Format("Trace result will be saved in [{0}]", Directory.GetCurrentDirectory() + @"\SPCalls"));
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Initialization Complete \r\n");           
            
            List<DBObject> spCalls;
            Console.WriteLine("Started Tracing ... \r\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            while (true)
            {
                spCalls = SPCallValidator.AddedSPCalls();
                CreateDirectory();
                if (spCalls.Count > 0)
                {
                    AppState.PreserveState<SPCallState, DBObject>();
                    foreach (DBObject sp in spCalls)
                    {
                        Console.WriteLine("SP called:{0} , timestamp:{1}", sp.ProcName, sp.LastExecutionTime);
                        LogQuery(sp);
                    }
                }

                //Console.ReadKey();
            }
        }

        static void LogQuery(DBObject spCall)
        {
            string path = @".\SPCalls\" + spCall.ProcName + ".sql";

            if (!File.Exists(path))
            {
                File.Create(path).Close();
            }

            if (!IsQueryLogged(path, spCall.SQLStatement))
            {
                File.AppendAllText(path, spCall.SQLStatement);
                File.AppendAllText(path, Environment.NewLine);
                File.AppendAllText(path, "--==============================================================================================================================");
                File.AppendAllText(path, Environment.NewLine);
            }
        }

        static bool IsQueryLogged(string path, string query)
        {
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    string line = sr.ReadToEnd();
                    if (line.Contains(query))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
                return false;
            }
        }

        static void CreateDirectory()
        {
            if (!Directory.Exists(@".\SPCalls"))
            {
                Directory.CreateDirectory(@".\SPCalls");
            }
        }        
        
    }
}
