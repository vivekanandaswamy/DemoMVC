﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Config
{
    class TestSettings : BaseSetings
    {
        private static TestSettings defaultInstance = new TestSettings();
        private static string settingsFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Config");
        private static string settingsFile;
                
        public static TestSettings Default
        {
            get
            {
                settingsFile = Path.Combine(settingsFilePath, "PLCTestSettings.xml");
                return defaultInstance;
            }

        }
        
        //[global::System.Configuration.DefaultSettingValueAttribute("Data Source=HYD-ECOLABDB\\SQLExpress;Initial Catalog=ConduitLocalQA;User ID=tcddev" +
        //    ";Password=Agstcd@1")]
        string dBConnection = "Data Source=HYD-APAL1\\SQLExpress;Initial Catalog=ConduitLocal;User ID=sa;Password=Agstcd@1";
        public string DBConnectionString
        {
            get
            {
                string value = GetValue(settingsFile, "DBConnection");
                if (null != value)
                {
                    dBConnection = value;
                }
                return dBConnection;
                //return ((string)(this["DBConnection"]));
            }
            //set
            //{
            //    this["DBConnection"] = value;
            //}
        }
		
    }
}
