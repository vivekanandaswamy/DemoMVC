﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Ecolab.PLCTest.Entities
{
    [Serializable]
    [XmlRoot("Entry")]
    public class BeckhoffXmlNode
    {        
        public DateTime ts { get; set; }
       
        public int data { get; set; }
       
        public string tag { get; set; }
      
        public string desc { get; set; }
    }
}
