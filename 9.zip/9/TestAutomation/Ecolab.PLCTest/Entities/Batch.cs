﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Entities
{
    public class Batch
    {
        public Batch(int batchId, int programNumber,short plantWasherNumber, int controllerBatchId, DateTime startDate)
        {
            BatchId = batchId;
            StartDate = startDate;
            ProgramNumber = programNumber;
            PlantWasherNumber = plantWasherNumber;
            ControllerBatchId = controllerBatchId;
        }

        public Batch(DateTime endDate)
        {
            EndDate = endDate;
        }

        public int BatchId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int ProgramNumber { get; set; }
        public short PlantWasherNumber { get; set; }
        public int ControllerBatchId { get; set; }
    }
}
