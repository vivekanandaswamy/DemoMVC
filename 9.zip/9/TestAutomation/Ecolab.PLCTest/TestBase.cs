﻿using Ecolab.PLCTest.Utils;
using Framework;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Ecolab.CommonUtilityPlugin;

namespace Ecolab.PLCTest
{
    public class TestBase
    {
        //private OPCClient opcClient;
        //private OPCClient OPCClient
        //{
        //    get
        //    {
        //        opcClient = new CommonUtilityPlugin.OPCClient();
        //        return opcClient;
        //    }
        //}

        public string ConnectionString { get; set; }

        public DataMapper Mapper 
        { 
            get
            {
                return  new DataMapper(ConnectionString);
            }
        }

        protected Conduit Conduit 
        { 
            get
            {
                return new Conduit(ConnectionString);
            }
        }

        public AllenBradely AllenBradely 
        { 
            get
            {
                return new AllenBradely();
            }
        }

        public Beckhoff Beckhoff 
        { 
            get
            {
                return new Beckhoff(ConnectionString);
            }
        }

        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            ConnectionString = Config.TestSettings.Default.DBConnectionString;
        }
        
    }
}
