﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public class AlarmData
    {
        public string ErrorMessageTagAddress { get; set; }
        public int ErrorMessageCode { get; set; }
        public string FormulaTagAddress { get; set; }
    }
}
