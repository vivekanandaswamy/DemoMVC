﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public class TunnelBatchData
    {
        public int TunnelId { get; set; }
        public TunnelData Tunnel { get; set; }
        public int BatchId { get; set; }
        public int MaxTransferTime { get; set; }
        //public string InjectionCounter { get; set; }
        //public string OperationCounter { get; set; }
        //public string FormulaNumberTag { get; set; }
        public ReadOnlyCollection<int> Steps { get; set; }
        public int ProcessStep { get; set; }
        public int FormulaNumber { get; set; }
        public int EOF { get; set; }
    }
}
