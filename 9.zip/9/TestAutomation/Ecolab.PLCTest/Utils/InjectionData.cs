﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public enum ControllerType
    {
        AllenBradely,
        Beckhoff
    }

    public class InjectionData
    {
        public int InjectionFrequency { get; set; }
        public string WasherTagAddress { get; set; }
        public string TagAddress { get; set; }
        public int WasherValue { get; set; }
        public int TagStartValue { get; set; }
        public int NumberOfInjection { get; set; }
        public string OperationCounter { get; set; }
        public List<int> HoldOn { get; set; }
        public CurrentFormulaData CurrentFormula { get; set; }
        public string TopicName { get; set; }
        public int batchId { get; set; }
        public AlarmData AlarmDetails { get; set; }
        public string AWEActive { get; set; }
        public string AWEActiveTagAddress { get; set; }
        public int AWEWeight { get; set; }
        public string AWEWeightTagAddress { get; set; }
        public int TurnTime { get; set; }
        public ControllerType ControllerType { get; set; }
        public bool IsActive { get; set; }
    }
}
