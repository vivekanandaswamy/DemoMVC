﻿using BeckhoffClient;
using Ecolab.CommonUtilityPlugin;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public class TunnelInjector
    {
        private static int loadIndex = 1;
        private List<ContinuousTask> continuousTask;
        private List<ContinuousTask> ContinuousTask
        {
            get
            {
                if(null == continuousTask)
                {
                    continuousTask = new List<ContinuousTask>();
                }
                return continuousTask;
            }
        }
        private static log4net.ILog Logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public TunnelInjector()
        {
            log4net.ThreadContext.Properties["myContext"] = "ABTunnelInjector Class:";            
            Logger.Debug("Inside Allen Bradely Tunnel Injector Constructor!");
        }

        public void ExecuteTunnelInjection(string testParam, string testname, string tunnelConfig)
        {
            TunnelParam tunnelParam = new Utils.TunnelParam(testParam, tunnelConfig, testname);
            ReadOnlyCollection<TunnelData> tunnelDataList = tunnelParam.GetBatchData();
            TunnelInjector tunnelInjector = new TunnelInjector();

            //Parallel.ForEach(tunnelDataList, tunnelData => tunnelInjector.InjectBatch(tunnelData));

            //if (null == continuousTask)
            //{
            //    continuousTask = new List<ContinuousTask>();

            //}

            ContinuousTask newTask;
            foreach (TunnelData tunnel in tunnelDataList)
            {
                newTask = new ContinuousTask();
                ContinuousTask.Add(newTask);
                TunnelData tunnelDataCopy = tunnel;
                List<TunnelBatchData> batches = tunnel.Batch.ToList();
                List<Compartment> compartments = tunnel.Compartments.ToList();
                newTask.StartWorkAsync(
                    () =>
                    {
                        foreach (TunnelBatchData batch in batches)
                        {
                            compartments = PushBatches(compartments, batch, tunnelDataCopy);
                            tunnelDataCopy.Compartments = compartments.AsReadOnly();
                        }

                        //Console.WriteLine("Injected Batch in tunnel : " + ContinuousTask.Count);                        
                    });
            }           
        }

        public void ExecuteBeckhoffTunnelInjection(string testParam, string testname, string tunnelConfig)
        {
            TunnelParam tunnelParam = new Utils.TunnelParam(testParam, tunnelConfig, testname);
            ReadOnlyCollection<TunnelData> tunnelDataList = tunnelParam.GetBeckhoffBatchData();
            TunnelInjector tunnelInjector = new TunnelInjector();

            ContinuousTask newTask;
            foreach (TunnelData tunnel in tunnelDataList)
            {
                newTask = new ContinuousTask();
                ContinuousTask.Add(newTask);
                TunnelData tunnelDataCopy = tunnel;
                List<TunnelBatchData> batches = tunnel.Batch.ToList();
                //List<Compartment> compartments = tunnel.Compartments.ToList();
                newTask.StartWorkAsync(
                    () =>
                    {
                        foreach (TunnelBatchData batch in batches)
                        {
                            PushBeckhoffBatches(batch, tunnelDataCopy);
                            //tunnelDataCopy.Compartments = compartments.AsReadOnly();
                        }

                        //Console.WriteLine("Injected Batch in tunnel : " + ContinuousTask.Count);                        
                    });
            }       
        }

        public void CloseTunnels()
        {
            foreach (ContinuousTask task in ContinuousTask)
            {
                task.StopWork();
            }
        }

        public void InjectBatch(TunnelData tunnelData)
        {
            TunnelData tunnelDataCopy = tunnelData;
            List<TunnelBatchData> batches = tunnelData.Batch.ToList();
            List<Compartment> compartments = tunnelData.Compartments.ToList();
            while(true)
            {
                foreach (TunnelBatchData batch in batches)
                {
                    compartments = PushBatches(compartments, batch, tunnelDataCopy);
                    tunnelDataCopy.Compartments = compartments.AsReadOnly();
                }
            }
           
        }

        private List<Compartment> PushBatches(List<Compartment> compartments, TunnelBatchData batch, TunnelData tunnel)
        {
            for (int i = compartments.Count - 1 ; i >= 0; i--)
            {
                if (i > 0)
                {
                    compartments[i].LoadNumber = compartments[i - 1].LoadNumber;
                    compartments[i].FormulaNumber = compartments[i - 1].FormulaNumber;
                    compartments[i].ProcessTime = compartments[i - 1].ProcessTime;
                }
            }

            compartments[0].FormulaNumber = batch.FormulaNumber;
            //compartments[0].LoadNumber = loadIndex++;
            compartments[0].LoadNumber = compartments[1].LoadNumber + 1;
            compartments[0].ProcessTime = batch.MaxTransferTime;
           
            tunnel.InjectionCounterNumber = 0;
            tunnel.FormulaNumber = batch.FormulaNumber;
            tunnel.OperationCounterNumber = 0;
            SendToOPCServer(tunnel, compartments);
            Thread.Sleep(2000);
            SendInjections(tunnel, batch);
            return compartments;
        }

        private void PushBeckhoffBatches(TunnelBatchData batch, TunnelData tunnel)
        {
            Dictionary<string, string> tags = new Dictionary<string, string>();

            tags.Add(tunnel.OperationCounterTag, "0");
            tags.Add(tunnel.FormulaTag, batch.FormulaNumber.ToString());
            tags.Add(tunnel.InjectionCounterTag, "0");
            TunnelInjection(tags, tunnel);

            for (int i = 1; i <= 5; i++)
            {
                tags.Add(tunnel.OperationCounterTag, i.ToString());
                tags.Add(tunnel.FormulaTag, batch.FormulaNumber.ToString());
                tags.Add(tunnel.InjectionCounterTag, i.ToString());
                TunnelInjection(tags, tunnel);
                Thread.Sleep(2000);                
            }

            tags.Add(tunnel.OperationCounterTag, "0");
            tags.Add(tunnel.FormulaTag, batch.EOF.ToString());
            tags.Add(tunnel.InjectionCounterTag, "0");
           
            TunnelInjection(tags, tunnel);
            Thread.Sleep(2000);

            Thread.Sleep(new TimeSpan(0, 0, tunnel.MaxProcessingTime));
            //Thread.Sleep(new TimeSpan(0, 0, GetMaxTransferTime(tunnel.Compartments.ToList()) - 12));
            //Thread.Sleep(new TimeSpan(0, 0, GetMaxTransferTime(tunnel.Batch.ToList()) - 12));

        }

        private void SendToOPCServer(TunnelData tunnel, List<Compartment> compartments)
        {
            //OPCClient opcClient = new OPCClient();
            Dictionary<string, string> tags = new Dictionary<string, string>();
            List<string> logValues = new List<string>();
            //opcClient.controllerIdAB = 1;
            //opcClient.TopicAB = tunnel.TopicName;
            //opcClient.OPCServerAB = tunnel.OPCServerName;

            //Console.WriteLine("Tunnel: Topic:{0} , InjCntr:{0} , OpCntr:{2}, FormulaTag:{3}", tunnel.TopicName, tunnel.OperationCounterTag, tunnel.InjectionCounterTag, tunnel.FormulaTag);
            //Log.AddDebugLog(Logger, string.Format("Tunnel: Topic:{0} , InjCntr:{1} , OpCntr:{2}, FormulaTag:{3}"
            //                , tunnel.TopicName, tunnel.InjectionCounterTag, tunnel.OperationCounterTag, tunnel.FormulaTag));

            logValues.Add(string.Format("Tunnel: Topic:{0} , InjCntr:{1} , OpCntr:{2}, FormulaTag:{3}"
                            , tunnel.TopicName, tunnel.InjectionCounterTag, tunnel.OperationCounterTag, tunnel.FormulaTag));

            foreach(Compartment compartment in compartments)
            {
                tags.Add(compartment.LoadIDTag, compartment.LoadNumber.ToString());
                tags.Add(compartment.FormulaIdTag, compartment.FormulaNumber.ToString());
                //Console.WriteLine("Compartment:{0} , LoadId:{1}={2} , Formula:{3}={4}", compartment.CompartmentId, compartment.LoadIDTag, compartment.LoadNumber, compartment.FormulaIdTag, compartment.FormulaNumber);
                //Log.AddDebugLog(Logger,string.Format("Compartment:{0} , LoadId:{1}={2} , Formula:{3}={4}"
                //                                    , compartment.CompartmentId, compartment.LoadIDTag, compartment.LoadNumber
                //                                    , compartment.FormulaIdTag, compartment.FormulaNumber));
                logValues.Add(string.Format("Compartment:{0} , LoadId:{1}={2} , Formula:{3}={4}"
                                                    , compartment.CompartmentId, compartment.LoadIDTag, compartment.LoadNumber
                                                    , compartment.FormulaIdTag, compartment.FormulaNumber));
            }

            tags.Add(tunnel.OperationCounterTag, tunnel.OperationCounterNumber.ToString());
            tags.Add(tunnel.FormulaTag, tunnel.FormulaNumber.ToString());
            tags.Add(tunnel.InjectionCounterTag, tunnel.InjectionCounterNumber.ToString());

            //opcClient.CreateABTags(tags);
            //opcClient.WriteDataToABController();
            //tags.Clear();
            TunnelInjection(tags, tunnel);
            Log.AddTunnelDebuglog(Logger, logValues);
            logValues.Clear();
        }

        private void SendInjections(TunnelData tunnel, TunnelBatchData batch)
        {
            //OPCClient opcClient = new OPCClient();
            Dictionary<string, string> tags = new Dictionary<string, string>();
            //opcClient.controllerIdAB = 1;
            //opcClient.TopicAB = tunnel.TopicName;
            //opcClient.OPCServerAB = tunnel.OPCServerName;

            for (int i = 1; i <= 5; i++ )
            {
                tags.Add(tunnel.OperationCounterTag, i.ToString());
                tags.Add(tunnel.FormulaTag, batch.FormulaNumber.ToString());
                tags.Add(tunnel.InjectionCounterTag, i.ToString());
                //opcClient.CreateABTags(tags);
                //opcClient.WriteDataToABController();
                TunnelInjection(tags, tunnel);
                Thread.Sleep(2000);
                //tags.Clear();
            }
            
            tags.Add(tunnel.OperationCounterTag, "0");
            tags.Add(tunnel.FormulaTag, batch.EOF.ToString());
            tags.Add(tunnel.InjectionCounterTag, "0");
            //opcClient.CreateABTags(tags);
            //opcClient.WriteDataToABController();
            //tags.Clear();
            TunnelInjection(tags, tunnel);
            Thread.Sleep(2000);

            var test = GetMaxTransferTime(tunnel.Compartments.ToList());
            //Console.WriteLine(GetMaxTransferTime(tunnel.Compartments.ToList()));
            int waitFor = GetMaxTransferTime(tunnel.Compartments.ToList()) - 12 > 0 ? GetMaxTransferTime(tunnel.Compartments.ToList()) - 12 : 0;

            Thread.Sleep(new TimeSpan(0, 0, waitFor));
            //Thread.Sleep(new TimeSpan(0, 0, GetMaxTransferTime(tunnel.Compartments.ToList()) - 12));
            //Thread.Sleep(new TimeSpan(0, 0, GetMaxTransferTime(tunnel.Batch.ToList()) - 12));
        }

        private void TunnelInjection(Dictionary<string, string> tags, TunnelData tunnel)
        {
            if (!tunnel.OPCServerName.Contains(":"))
            {
                OPCClient opcClient = new OPCClient();
                opcClient.controllerIdAB = 1;
                opcClient.TopicAB = tunnel.TopicName;
                opcClient.OPCServerAB = tunnel.OPCServerName;
                opcClient.CreateABTags(tags);
                opcClient.WriteDataToABController();               
            }
            else
            {
                string[] values = tunnel.OPCServerName.Split(':');
                List<ClientTag> beckClientTag = new List<ClientTag>();
                TestBeckhoffClient beckhoffClient = new TestBeckhoffClient(values[0], Convert.ToInt32(values[1]), tunnel.TopicName);
                foreach (KeyValuePair<string, string> tag in tags)
                {
                    beckClientTag.Add(new ClientTag
                    {
                        TagAddress = tag.Key,
                        Value = tag.Value
                    });
                }
                beckhoffClient.WriteTags(beckClientTag);                
            }

            tags.Clear();
        }

        private int GetMaxTransferTime(List<TunnelBatchData> batchData)
        {
            int maxValue = 0;
            foreach(TunnelBatchData batch in batchData)
            {
                if(batch.MaxTransferTime > maxValue)
                {
                    maxValue = batch.MaxTransferTime;
                }
            }

            return maxValue;
        }

        private int GetMaxTransferTime(List<Compartment> compartments)
        {
            int maxValue = 0;
            foreach (Compartment compartment in compartments)
            {
                if (compartment.ProcessTime > maxValue)
                {
                    maxValue = compartment.ProcessTime;
                }
            }

            return maxValue;
        }
    }
}
