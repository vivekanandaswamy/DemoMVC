﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Ecolab.CommonUtilityPlugin;
using System.ComponentModel;
using BeckhoffClient;

namespace Ecolab.PLCTest.Utils
{
    public class Injector : IDisposable
    {
        public int AlarmCounter = 0;

        private List<List<InjectionData>> sortedwasherSpecificInjection;
        private TestParam injectiondata;       
        public TestParam InjectionData
        {
            get
            {
                return injectiondata;
            }
        }
        private List<ContinuousTask> continuousTask;
        private string testParameterFile;
        private string testname;

        private static log4net.ILog Logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public Injector(string testParamFileName , string testcaseName)
        {
            testParameterFile = testParamFileName;
            testname = testcaseName;
            injectiondata = new Utils.TestParam(testParameterFile, testname);
            //ThreadPool.SetMaxThreads(40, 40);
            log4net.ThreadContext.Properties["myContext"] = "ABInjector Class:";
            Logger.Debug("Inside Allen Bradely Injector Constructor!");
        }

        public void InjectToOPCServer()
        {
            List<List<InjectionData>> washerSpecificInjection = new List<List<Utils.InjectionData>>();
            sortedwasherSpecificInjection = new List<List<Utils.InjectionData>>();
            Dictionary<string, List<InjectionData>> sortedInjectiondata = new Dictionary<string, List<InjectionData>>();

            var injectionDataList = injectiondata.GetInjectionData;
            foreach (InjectionData injData in injectionDataList)
            {
               if (!sortedInjectiondata.ContainsKey(injData.TopicName + injData.TagAddress))
               {
                   List<InjectionData> temp = new List<InjectionData>();
                   temp.Add(injData);
                   sortedInjectiondata.Add(injData.TopicName + injData.TagAddress, temp);
               }
               else
               {
                   List<InjectionData> existingValue = sortedInjectiondata[injData.TopicName + injData.TagAddress];
                   existingValue.Add(injData);
                   sortedInjectiondata[injData.TopicName + injData.TagAddress] = existingValue;
               }
            }

            foreach (KeyValuePair<string, List<InjectionData>> value in sortedInjectiondata)
            {
                washerSpecificInjection.Add(value.Value);
            }

            sortedwasherSpecificInjection = sortBatches(washerSpecificInjection);
            
            if (null == continuousTask)
            {
                continuousTask = new List<ContinuousTask>();
            }

            //for (int i = 0; i < 2;i++ )
            //{
            //    InjectDataToOPCServer(sortedwasherSpecificInjection.FirstOrDefault().FirstOrDefault());
            //}
                

            ContinuousTask newTask;
            foreach (List<InjectionData> data in sortedwasherSpecificInjection)
            {
                //Thread thread = new Thread(() => { InjectWasher(data); });
                //thread.Start();
                //thread.Join();


                newTask = new ContinuousTask();
                continuousTask.Add(newTask);
                newTask.StartWorkAsync(
                    () =>
                    {
                        injectiondata = new Utils.TestParam(testParameterFile, testname);
                        SortWasherBatches();
                        foreach (InjectionData injection in data)
                        {
                            if (null != injection)
                            {
                               
                                if(injection.IsActive)
                                {
                                    InjectDataToOPCServer(injection);
                                }                                
                            }                                
                        }
                                                                       
                        //Console.WriteLine("Injected : " + continuousTask.Count);
                    });
            }        
        }

        private void InjectWasher(List<InjectionData> injectionList)
        {
            
            
            while(true)
            {
                foreach (InjectionData injection in injectionList)
                {
                    InjectDataToOPCServer(injection);
                }

                Console.WriteLine("Injected");

                //foreach (InjectionData data in injectionList)
                //{
                //    new Thread(() => { InjectDataToOPCServer(data); }).Start();                    
                //}  
                //foreach(InjectionData data in injectionList)
                //{
                //    data.cancelToken = new CancellationTokenSource();
                //}

                //var cts = new CancellationTokenSource();
                //var po = new ParallelOptions();
                //po.CancellationToken = cts.Token;

                //Parallel.ForEach(injectionList,
                //    (data) => 
                //    { 
                //        InjectDataToOPCServer(data);
                //        po.CancellationToken.ThrowIfCancellationRequested();
                //    });
            }            
        }
      
        private void InjectDataToOPCServer(InjectionData injection)
        {
            //OPCClient opcClient = new OPCClient();
            Dictionary<string, string> tags = new Dictionary<string, string>();
            //opcClient.controllerIdAB = injectiondata.GetControllerId;
            //opcClient.TopicAB = injection.TopicName;
            //opcClient.OPCServerAB = injectiondata.GetOPCServerName;

            int operationCounter = injection.TagStartValue;
            int injectionCounter = injection.TagStartValue;
            int formulaValue = injection.CurrentFormula.FormulaValue;
            int eof = injection.CurrentFormula.EndOfFormula;
            int injectionStartValue = injection.TagStartValue;
            int injectionFrequency = injection.InjectionFrequency;
            bool injectionMissed = false;
            int alarmCode = injection.AlarmDetails.ErrorMessageCode;
            int washerName = injection.WasherValue;
            //AlarmCounter = 0;
            for (int i = 0; i < injection.NumberOfInjection; i++, operationCounter++)
            {
                if (tags.Count <= 0)
                {              
                    tags.Add(injection.TagAddress, injectionCounter.ToString());
                    tags.Add(injection.OperationCounter, operationCounter.ToString());
                    tags.Add(injection.CurrentFormula.TagAddress, formulaValue.ToString());
                    tags.Add(injection.AWEActiveTagAddress, injection.AWEActive);
                    tags.Add(injection.AWEWeightTagAddress, injection.AWEWeight.ToString());
                    //tags.Add(injection.AlarmDetails.ErrorMessageTagAddress, alarmCode.ToString());
                    //tags.Add(injection.AlarmDetails.FormulaTagAddress, formulaValue.ToString());
                    //tags.Add(injection.WasherTagAddress, washerName.ToString());
                    injectionCounter++;
                }
                else
                {
                    if(null == injection.HoldOn)
                    {
                        tags[injection.TagAddress] = injectionCounter.ToString();                        
                        injectionCounter++;
                    }
                    else
                    {
                        if (!injection.HoldOn.Contains(operationCounter))
                        {
                            tags[injection.TagAddress] = injectionCounter.ToString();
                            injectionCounter++;
                            injectionMissed = true;
                        }
                    }
                    tags[injection.OperationCounter] = operationCounter.ToString();
                }
                if (AlarmCounter == 3)
                {
                    tags.Add(injection.AlarmDetails.ErrorMessageTagAddress, alarmCode.ToString());
                    tags.Add(injection.AlarmDetails.FormulaTagAddress, formulaValue.ToString());
                    tags.Add(injection.WasherTagAddress, washerName.ToString());
                    AlarmCounter = 0;
                }

                ConventionalInjection(tags, injection);
                //opcClient.CreateABTags(tags);
                ////Console.WriteLine("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4}", opcClient.TopicAB, injection.TagAddress, injectionCounter , injection.OperationCounter, operationCounter);
                //Log.AddDebugLog(Logger, string.Format("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4} , Formaula:{5}:{6}"
                //                , opcClient.TopicAB, injection.TagAddress, tags[injection.TagAddress]
                //                , injection.OperationCounter,tags[injection.OperationCounter]
                //                , injection.CurrentFormula.TagAddress, tags[injection.CurrentFormula.TagAddress]));
                //opcClient.WriteDataToABController();
                tags.Clear();
                //opcServer.ClearTags();
                Thread.Sleep(injectionFrequency);
                AlarmCounter++;
            }

            if (!injectionMissed)
            {
                tags.Add(injection.TagAddress, "0");
                //tags[injection.TagAddress] = "0";
                tags.Add(injection.OperationCounter,"0");
                tags.Add(injection.CurrentFormula.TagAddress,eof.ToString());
                tags.Add(injection.WasherTagAddress,"0");
                tags.Add(injection.AlarmDetails.ErrorMessageTagAddress,"0");
                tags.Add(injection.AlarmDetails.FormulaTagAddress,"0");
                if (injection.ControllerType == ControllerType.AllenBradely)
                {
                    tags.Add(injection.AWEActiveTagAddress, "0");
                }
                else
                {
                    tags.Add(injection.AWEActiveTagAddress, "FALSE");
                }                
                //opcServer.ClearTags();
                ConventionalInjection(tags, injection);
                //opcClient.CreateABTags(tags);
                //Log.AddDebugLog(Logger, string.Format("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4} , Formaula:{5}:{6}"
                //                , opcClient.TopicAB, injection.TagAddress, tags[injection.TagAddress]
                //                , injection.OperationCounter, tags[injection.OperationCounter]
                //                , injection.CurrentFormula.TagAddress, tags[injection.CurrentFormula.TagAddress]));
                //opcClient.WriteDataToABController();
                
                //Log.AddDebugLog(Logger, string.Format("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4} , Formaula:{5}:{6}, TurnTime({7}s) waiting..."
                //               , injection.TopicName, injection.TagAddress, tags[injection.TagAddress]
                //               , injection.OperationCounter, tags[injection.OperationCounter]
                //               , injection.CurrentFormula.TagAddress, tags[injection.CurrentFormula.TagAddress], injection.TurnTime));
                //Thread.Sleep(new TimeSpan(0, injection.TurnTime, 0));
               
                //AlarmCounter++;
                Log.AddDebugLog(Logger, string.Format("Topic:{0} , InjCntr:{1} , OpCntr:{2} , Formaula:{3}, TurnTime({4}m) waiting..."
                             , injection.TopicName, injection.TagAddress
                             , injection.OperationCounter
                             , injection.CurrentFormula.TagAddress
                             , injection.TurnTime));
                Thread.Sleep(new TimeSpan(0, injection.TurnTime, 0));
                tags.Clear();
            }         
        }

        public void SendEOFToAllNodes()
        {
            if (null != sortedwasherSpecificInjection)
            {
                //Parallel.ForEach(sortedwasherSpecificInjection, data => SendAllEOF(data));
                //Console.WriteLine();
                Log.AddDebugLog(Logger, string.Empty);

                //Console.WriteLine("Starting Conventional Washer stop process ....");
                Log.AddDebugLog(Logger, "Starting Conventional Washer stop process ....");

                //Console.WriteLine();
                Log.AddDebugLog(Logger, string.Empty);

                foreach(ContinuousTask task in continuousTask)
                {
                    task.StopWork();
                }

                //Console.WriteLine("Stopped running tasks for conventional washers ....");
                Log.AddDebugLog(Logger, "Stopped running tasks for conventional washers ....");

                //Console.WriteLine();
                Log.AddDebugLog(Logger, string.Empty);

                //Console.WriteLine("Sending EOF Signals to conventional washers ......");
                Log.AddDebugLog(Logger, "Sending EOF Signals to conventional washers ......");

                //Console.WriteLine();
                Log.AddDebugLog(Logger, string.Empty);

                foreach(List<InjectionData> injectionList in sortedwasherSpecificInjection)
                {
                    SendAllEOF(injectionList);
                }

                //Console.WriteLine();
                Log.AddDebugLog(Logger, string.Empty);
                //Console.WriteLine("Conventional washers stopped successfully ......");
                Log.AddDebugLog(Logger, "Conventional washers stopped successfully ......");

            }
        }

        private void SendAllEOF(List<InjectionData> injectionList)
        {
            //Parallel.ForEach(injectionList, data => SendEOF(data));
            foreach (InjectionData injection in injectionList)
            {               
                SendEOF(injection);
                //injection.cancelToken.Cancel();               
            }
        }

        private void SendEOF(InjectionData injection)
        {
            OPCClient opcClient = new OPCClient();
            Dictionary<string, string> tags = new Dictionary<string, string>();
            opcClient.controllerIdAB = injectiondata.GetControllerId;
            opcClient.TopicAB = injection.TopicName;
            opcClient.OPCServerAB = injectiondata.GetOPCServerName;

            tags[injection.TagAddress] = "0";
            tags[injection.OperationCounter] = "0";
            tags[injection.CurrentFormula.TagAddress] = injection.CurrentFormula.EndOfFormula.ToString();
            
            //opcClient.CreateABTags(tags);
            //opcClient.WriteDataToABController();
            ////Console.WriteLine("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4} , Formula:{5}={6}", injection.TopicName
            ////                    , injection.TagAddress, tags[injection.TagAddress], injection.OperationCounter, tags[injection.OperationCounter]
            ////                    , injection.CurrentFormula.TagAddress, tags[injection.CurrentFormula.TagAddress]);
            //Log.AddDebugLog(Logger,string.Format("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4} , Formula:{5}={6}", injection.TopicName
            //                    , injection.TagAddress, tags[injection.TagAddress], injection.OperationCounter, tags[injection.OperationCounter]
            //                    , injection.CurrentFormula.TagAddress, tags[injection.CurrentFormula.TagAddress]));
            //tags.Clear();
            ConventionalInjection(tags, injection);
        }

        private void ConventionalInjection(Dictionary<string, string> tags, InjectionData injection)
        {
            if (injection.ControllerType == ControllerType.AllenBradely)
            {
                OPCClient opcClient = new OPCClient();
                opcClient.controllerIdAB = injectiondata.GetControllerId;
                opcClient.TopicAB = injection.TopicName;
                opcClient.OPCServerAB = injectiondata.GetOPCServerName;
                opcClient.CreateABTags(tags);
                opcClient.WriteDataToABController();
                Log.AddDebugLog(Logger, string.Format("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4} , Formaula:{5}:{6}"
                                , opcClient.TopicAB, injection.TagAddress, tags[injection.TagAddress]
                                , injection.OperationCounter, tags[injection.OperationCounter]
                                , injection.CurrentFormula.TagAddress, tags[injection.CurrentFormula.TagAddress]));                            
            }
            else
            {
                string[] values = injectiondata.GetOPCServerName.Split(':');
                List<ClientTag> beckClientTag = new List<ClientTag>();                 
                //Console.WriteLine(string.Format("ip:{0}, port:{1}, Topic:{2}", values[0], Convert.ToInt32(values[1]), injection.TopicName));
                TestBeckhoffClient beckhoffClient = new TestBeckhoffClient(values[0], Convert.ToInt32(values[1]),injection.TopicName);  
                foreach(KeyValuePair<string,string> tag in tags)
                {
                    beckClientTag.Add(new ClientTag 
                    {
                        TagAddress = tag.Key,
                        Value = tag.Value
                    });
                }
                
                beckClientTag = beckhoffClient.WriteTags(beckClientTag).ToList();
                Log.AddDebugLog(Logger, string.Format("Topic:{0} , InjCntr:{1}={2} , OpCntr:{3}={4} , Formaula:{5}:{6}"
                                    , injection.TopicName, injection.TagAddress, tags[injection.TagAddress]
                                    , injection.OperationCounter, tags[injection.OperationCounter]
                                    , injection.CurrentFormula.TagAddress, tags[injection.CurrentFormula.TagAddress]));
                beckClientTag.Clear();

                //beckhoffReturnValues = "Return Values: ";
                //foreach(ClientTag tag in beckClientTag)
                //{
                //    beckhoffReturnValues = string.Concat(beckhoffReturnValues, string.Format("{0}:{1},", tag.TagAddress, tag.Value));
                //}
                //Log.AddDebugLog(Logger, beckhoffReturnValues);
            }
            
            tags.Clear();
        }

        private List<List<InjectionData>> sortBatches(List<List<InjectionData>> valuesLists)
        {
            InjectionData min = new InjectionData();
            List<List<InjectionData>> sortedList = new List<List<InjectionData>>();
            min.batchId = 0;
            
            foreach(List<InjectionData> values in valuesLists)
            {
                IOrderedEnumerable<InjectionData> sorted = from element in values
                                                             orderby element.batchId
                                                             select element;
                
                sortedList.Add(sorted.ToList());

                //foreach (InjectionData value in values)
                //{
                    
                //    //if(value.batchId < min.batchId)
                //    //{
                //    //   sortedList.Add()

                //    //}
                //}
            }
            return sortedList;
        }       

        private void SortWasherBatches()
        {
            List<List<InjectionData>> washerSpecificInjection = new List<List<Utils.InjectionData>>();
            List<List<Utils.InjectionData>>  tempsortedwasherSpecificInjection = new List<List<Utils.InjectionData>>();
            Dictionary<string, List<InjectionData>> sortedInjectiondata = new Dictionary<string, List<InjectionData>>();

            
            var injectionDataList = injectiondata.GetInjectionData;
            foreach (InjectionData injData in injectionDataList)
            {
                if (!sortedInjectiondata.ContainsKey(injData.TopicName + injData.TagAddress))
                {
                    List<InjectionData> temp = new List<InjectionData>();
                    temp.Add(injData);
                    sortedInjectiondata.Add(injData.TopicName + injData.TagAddress, temp);
                }
                else
                {
                    List<InjectionData> existingValue = sortedInjectiondata[injData.TopicName + injData.TagAddress];
                    existingValue.Add(injData);
                    sortedInjectiondata[injData.TopicName + injData.TagAddress] = existingValue;
                }
            }

            foreach (KeyValuePair<string, List<InjectionData>> value in sortedInjectiondata)
            {
                washerSpecificInjection.Add(value.Value);
            }

            tempsortedwasherSpecificInjection = sortBatches(washerSpecificInjection);
            CopyBatches(tempsortedwasherSpecificInjection, sortedwasherSpecificInjection);
            AddNewDataToTarget(tempsortedwasherSpecificInjection, sortedwasherSpecificInjection);
            sortedwasherSpecificInjection = sortBatches(sortedwasherSpecificInjection);
        }
             
        //private bool IsHoldInjection(InjectionData injection)
        //{
        //    List<int> holdInjections = new List<int>();
        //    if (null != injection.HoldOn)
        //    {
        //        foreach (string holdInjection in injection.HoldOn.Split(','))
        //        {
        //            holdInjections.Add(Convert.ToInt32(holdInjection.Trim()));
        //        }
        //    }
        //}        

        private void CopyBatches(List<List<Utils.InjectionData>> sourceBatchData, List<List<Utils.InjectionData>> targetBatchData)
        {
            int index;
            Utils.InjectionData temp = new InjectionData();
            List<Utils.InjectionData> newdataList = new List<InjectionData>();
            foreach(List<Utils.InjectionData> dataList in targetBatchData)
            {               
                index = targetBatchData.IndexOf(dataList);                
                foreach(Utils.InjectionData data in dataList)
                {
                   
                    temp = GetBatch(sourceBatchData, data);
                    if(null != temp)
                    {
                        data.IsActive = true;
                        data.AlarmDetails = temp.AlarmDetails;
                        data.AWEActive = temp.AWEActive;
                        data.AWEActiveTagAddress = temp.AWEActiveTagAddress;
                        data.AWEWeight = temp.AWEWeight;
                        data.AWEWeightTagAddress = temp.AWEWeightTagAddress;
                        data.ControllerType = temp.ControllerType;
                        data.CurrentFormula = temp.CurrentFormula;
                        data.InjectionFrequency = temp.InjectionFrequency;
                        data.NumberOfInjection = temp.NumberOfInjection;
                        data.OperationCounter = temp.OperationCounter;
                        data.TagAddress = temp.TagAddress;
                        data.TagStartValue = temp.TagStartValue;
                        data.TopicName = temp.TopicName;
                        data.TurnTime = temp.TurnTime;
                        data.WasherTagAddress = temp.WasherTagAddress;
                        data.WasherValue = temp.WasherValue;
                    }
                    else
                    {
                        data.IsActive = false;
                    }
                }
            }
        }

        private Utils.InjectionData GetBatch(List<List<Utils.InjectionData>> sourceBatchData, Utils.InjectionData match)
        {
            foreach(List<Utils.InjectionData> dataList in sourceBatchData)
            {
                foreach(Utils.InjectionData data in dataList)
                {
                    if(data.batchId == match.batchId && data.TagAddress.Equals(match.TagAddress) && data.TopicName.Equals(match.TopicName))
                    {
                        return data;
                    }
                }
            }
            return null;

        }

        private void AddNewDataToTarget(List<List<Utils.InjectionData>> sourceBatchData, List<List<Utils.InjectionData>> targetBatchData)
        {
            List<Utils.InjectionData> washerBatches = new List<Utils.InjectionData>();
            Utils.InjectionData temp = new InjectionData();
            foreach(List<Utils.InjectionData> dataList in sourceBatchData)
            {
                foreach(Utils.InjectionData data in dataList)
                {
                    if (null == GetBatch(targetBatchData,data))
                    {
                        washerBatches = GetRunningBatchList(targetBatchData,data);
                        washerBatches.Add(data);
                    }                  
                }
            }
        }

        private List<Utils.InjectionData> GetRunningBatchList(List<List<Utils.InjectionData>> targetBatchData, Utils.InjectionData match)
        {
            foreach(List<Utils.InjectionData> dataList in targetBatchData)
            {
                if(dataList.FirstOrDefault().TagAddress.Equals(match.TagAddress) && dataList.FirstOrDefault().TopicName.Equals(match.TopicName))
                {
                    return dataList;
                }
            }
            return null;
        }

        public void Dispose()
        {
            //SendEOFToAllNodes();
        }
    }
}
