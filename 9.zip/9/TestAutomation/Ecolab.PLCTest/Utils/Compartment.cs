﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public class Compartment
    {
        public int CompartmentId { get; set; }
        public int StepId { get; set; }
        public string TagAddress { get; set; }
        public int TagStartValue { get; set; }
        public int ProcessingBatchId { get; set; }
        public int ProcessTime { get; set; }
        public Compartment NextCompartment { get; set; }
        public string LoadIDTag { get; set; }
        public string FormulaIdTag { get; set; }
        public int FormulaNumber { get; set; }
        public int LoadNumber { get; set; }
    }
}
