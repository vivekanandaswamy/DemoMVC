﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Ecolab.PLCTest.Utils
{
    public class TunnelParam
    {
        private XmlNode testcase;
        public string XmlFilePath { get; set; }
        public string TunnelConfig { get; set; }
        public string TestcaseName { get; set; }
        private List<TunnelData> assignedTunnels;
        public List<TunnelData> AssignedTunnels 
        { 
            get
            {
                if(null == assignedTunnels)
                {
                    assignedTunnels = new List<TunnelData>();
                }
                return assignedTunnels;
            }
        }        

        public TunnelParam(string filename, string tunnelConfiguration, string testcase)
        {
            XmlFilePath = filename;
            TunnelConfig = tunnelConfiguration;
            TestcaseName = testcase;
            GetTestcase(XmlFilePath);
        }

        public ReadOnlyCollection<TunnelData> GetBatchData()
        {
            List<TunnelBatchData> batches = new List<TunnelBatchData>();
            List<TunnelData> tunnels = new List<TunnelData>();
            TunnelBatchData tunnelBatch;
            TunnelData tunnelData;
            //XmlNode tunnel;
            var test = testcase.SelectNodes("./Tunnel");

            foreach (XmlNode tunnel in testcase.SelectNodes("./Tunnel"))
            {
                //tunnelData = new TunnelData();
                tunnelData = GetTunnelData(GetTunnel(Convert.ToInt32(((XmlElement)tunnel).GetAttribute("id"))));               

                foreach(XmlNode batch in tunnel.SelectNodes("./Batch"))
                {
                    tunnelBatch = new TunnelBatchData();
                    tunnelBatch.BatchId = Convert.ToInt32(((XmlElement)batch).GetAttribute("id"));
                    tunnelBatch.MaxTransferTime = Convert.ToInt32(batch.SelectSingleNode("./MaxTransferTime").InnerText);
                    tunnelBatch.FormulaNumber = Convert.ToInt32(batch.SelectSingleNode("./CurrentFormula/FormulaNumber").InnerText);
                    tunnelBatch.EOF = Convert.ToInt32(batch.SelectSingleNode("./CurrentFormula/EndOfFormula").InnerText);
                    //List<int> stepNumber = new List<int>();
                    //foreach (XmlNode step in batch.SelectNodes("./CurrentFormula/Step"))
                    //{
                    //    stepNumber.Add(Convert.ToInt32(step.InnerText));
                    //}
                    //tunnelBatch.Steps = stepNumber.AsReadOnly();
                    batches.Add(tunnelBatch);
                    //Batches.Add(tunnelBatch);
                }
                tunnelData.Batch = batches.AsReadOnly();
                batches = new List<TunnelBatchData>();
                //Batches.Add(tunnelBatch);
                tunnels.Add(tunnelData);
                //AssignedTunnels.Add(tunnelData);
            }

            return tunnels.AsReadOnly();            
        }

        public ReadOnlyCollection<TunnelData> GetBeckhoffBatchData()
        {
            List<TunnelBatchData> batches = new List<TunnelBatchData>();
            List<TunnelData> tunnels = new List<TunnelData>();
            TunnelBatchData tunnelBatch;
            TunnelData tunnelData;

             var test = testcase.SelectNodes("./Tunnel");

             foreach (XmlNode tunnel in testcase.SelectNodes("./Tunnel"))
             {
                 tunnelData = GetBeckhoffTunnelData(GetTunnel(Convert.ToInt32(((XmlElement)tunnel).GetAttribute("id"))));
                 //tunnelData.FormulaTag = tunnel.SelectSingleNode("./FormulaTag").InnerText;
                 //tunnelData.InjectionCounterTag = tunnel.SelectSingleNode("./InjectionCounter").InnerText;
                 //tunnelData.OperationCounterTag = tunnel.SelectSingleNode("./OperationCounter").InnerText;
                 //tunnelData.BeckhoffTransferTime = Convert.ToInt32(tunnel.SelectSingleNode("./TransferTime").InnerText);
                 foreach (XmlNode batch in tunnel.SelectNodes("./Batch"))
                 {
                     tunnelBatch = new TunnelBatchData();
                     tunnelBatch.BatchId = Convert.ToInt32(((XmlElement)batch).GetAttribute("id"));
                    
                     tunnelBatch.FormulaNumber = Convert.ToInt32(batch.SelectSingleNode("./CurrentFormula/FormulaNumber").InnerText);
                     tunnelBatch.EOF = Convert.ToInt32(batch.SelectSingleNode("./CurrentFormula/EndOfFormula").InnerText);
                     batches.Add(tunnelBatch);
                 }
                 tunnelData.Batch = batches.AsReadOnly();
                 batches = new List<TunnelBatchData>();
                 //Batches.Add(tunnelBatch);
                 tunnels.Add(tunnelData);
             }
             return tunnels.AsReadOnly(); 
        }

        private TunnelData GetTunnelData(XmlNode tunnel)
        {
            TunnelData tunnelData = new TunnelData()
            {
                TopicName = TopicName(tunnel),
                OPCServerName = OPCServerName(tunnel),
                OperationCounterTag = OperationCounter(tunnel),
                InjectionCounterTag = InjectionCounter(tunnel),
                FormulaTag = FormulaTag(tunnel),
                TunnelId = Convert.ToInt32(((XmlElement)tunnel).GetAttribute("id")),
                Compartments = Compartments(tunnel)
            };

            return tunnelData;
        }

        private TunnelData GetBeckhoffTunnelData(XmlNode tunnel)
        {
            TunnelData tunnelData = new TunnelData()
            {
                TopicName = TopicName(tunnel),
                OPCServerName = OPCServerName(tunnel),
                OperationCounterTag = OperationCounter(tunnel),
                InjectionCounterTag = InjectionCounter(tunnel),
                FormulaTag = FormulaTag(tunnel),
                TunnelId = Convert.ToInt32(((XmlElement)tunnel).GetAttribute("id")),
                //Compartments = Compartments(tunnel)
            };

            return tunnelData;
        }

        private string TopicName(XmlNode tunnel)
        {
            return tunnel.SelectSingleNode("./TopicName").InnerText;
        }

        private string OPCServerName(XmlNode tunnel)
        {
            return tunnel.SelectSingleNode("./OPCServerName").InnerText;
        }

        private string OperationCounter(XmlNode tunnel)
        {
            return tunnel.SelectSingleNode("./OperationCounterTag").InnerText;
        }

        private string InjectionCounter(XmlNode tunnel)
        {
            return tunnel.SelectSingleNode("./InjectionCounterTag").InnerText;
        }

        private string FormulaTag(XmlNode tunnel)
        {
            return tunnel.SelectSingleNode("./FormulaTag").InnerText;
        }

        private ReadOnlyCollection<Compartment> Compartments(XmlNode tunnel)
        {
            List<XmlNode> comparmentNodes = new List<XmlNode>(tunnel.SelectNodes("./Compartments/Compartment").Cast<XmlNode>());
            List<Compartment> compartments = new List<Compartment>();

            foreach(XmlNode compartnode in comparmentNodes)
            {
                compartments.Add(new Compartment()
                    {
                        CompartmentId = Convert.ToInt32(((XmlElement)compartnode).GetAttribute("id")),
                        //StepId = Convert.ToInt32(compartnode.SelectSingleNode("./StepId").InnerText),
                        //TagAddress = compartnode.SelectSingleNode("./TagAddress").InnerText,
                        //TagStartValue = Convert.ToInt32(compartnode.SelectSingleNode("./TagStartValue").InnerText),
                        FormulaIdTag = compartnode.SelectSingleNode("./FormulaIdTag").InnerText,
                        LoadIDTag = compartnode.SelectSingleNode("./LoadIdTag").InnerText,
                        //ProcessingBatchId = Convert.ToInt32(compartnode.SelectSingleNode("./ProcessingBatchId").InnerText),
                        //ProcessTime = Convert.ToInt32(compartnode.SelectSingleNode("./ProcessingTime").InnerText)
                    });
            }
            compartments = CreateMapping(compartments);
            return compartments.AsReadOnly();             
        }

        private List<Compartment> CreateMapping(List<Compartment> unMappedCompartment)
        {
            for(int i = 0 ; i < unMappedCompartment.Count; i++)
            {
                //if (i == unMappedCompartment.Count - 1)
                //{
                //    unMappedCompartment[i].NextCompartment = unMappedCompartment[0];
                //}
                //else
                //{
                //    unMappedCompartment[i].NextCompartment = unMappedCompartment[i + 1];
                //}
                if(i < unMappedCompartment.Count - 1    )
                {
                    unMappedCompartment[i].NextCompartment = unMappedCompartment[i + 1];
                }

            }
            return unMappedCompartment;
        }

        private XmlNodeList GetTunnels 
        { 
            get
            {
                XmlDocument xmlDoc = GetXmlDoc(TunnelConfig);
                return xmlDoc.SelectNodes("/TunnelConfig/Tunnels/Tunnel");
            }
        }
        
        private XmlNode GetTunnel(int tunnelid)
        {
            XmlDocument xmlDoc = GetXmlDoc(TunnelConfig);
            XmlNode tunnel = xmlDoc.SelectSingleNode(string.Format("/TunnelConfig/Tunnels/Tunnel[@id='{0}']", tunnelid));
            return tunnel;
        }

        private void GetTestcase(string filePath)
        {
            XmlDocument xmlDoc = GetXmlDoc(filePath);
            testcase = xmlDoc.SelectSingleNode(string.Format("/TestCases/TestCase[@name='{0}']", TestcaseName));
        }

        private XmlDocument GetXmlDoc(string filepath)
        {
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(filepath);
            return XmlDoc;
        }
    }
}
