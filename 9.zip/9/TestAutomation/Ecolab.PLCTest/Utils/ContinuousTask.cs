﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public class ContinuousTask
    {
        CancellationTokenSource wtoken;
        Task task;

        public void StopWork()
        {
            wtoken.Cancel();
            //try
            //{

            //    task.Wait();
            //}
            //catch (AggregateException) { }

        }

        public void StartWork(Action action)
        {
            wtoken = new CancellationTokenSource();

            task = Task.Factory.StartNew(() =>
            {
                try
                {
                    while (true)
                    {
                        wtoken.Token.ThrowIfCancellationRequested();
                        action();
                        Thread.Sleep(1000);                        
                    }
                }
                catch (OperationCanceledException e)
                {
                    Console.WriteLine(e);
                }


            }, TaskCreationOptions.LongRunning);            
        }

        public void StartWorkAsync(Action action)
        {
            wtoken = new CancellationTokenSource();

            task = Task.Factory.StartNew(async () =>  // <- marked async
            {
                while (true)
                {
                    action();                    
                    //await Task.Delay(1000, wtoken.Token); // <- await with cancellation
                }
            }, TaskCreationOptions.AttachedToParent);
        }

    }
}
