﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public class CurrentFormulaData
    {
        public string TagAddress { get; set; }
        public int EndOfFormula { get; set; }
        public int FormulaValue { get; set; }
    }
}
