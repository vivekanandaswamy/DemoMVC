﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest.Utils
{
    public class TunnelData
    {
        public string TopicName { get; set; }
        public string OPCServerName { get; set; }
        public int TunnelId { get; set; }
        public int MaxProcessingTime { get; set; }
        public ReadOnlyCollection<Compartment> Compartments { get; set; }
        public string OperationCounterTag { get; set; }
        public string InjectionCounterTag { get; set; }
        public string FormulaTag { get; set; }
        public int OperationCounterNumber { get; set; }
        public int InjectionCounterNumber { get; set; }
        public int FormulaNumber { get; set; }
        public ReadOnlyCollection<TunnelBatchData> Batch { get; set; }
    }
}
