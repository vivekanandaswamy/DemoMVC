﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest
{
    public static class Log
    {
        public static void AddDebugLog(log4net.ILog logger,string value)
        {
            //SetColour(value);
            lock(Console.Out)
            {
                WriteValueToConsole(value);
                logger.Debug(value);
            }
            
            
            //SetDefaultColour();
        }

        public static void AddTunnelDebuglog(log4net.ILog logger,List<string> values)
        {
            //SetColour(value);
            lock (Console.Out)
            {
                foreach(string value in values)
                {
                    WriteValueToConsole(value);
                    logger.Debug(value);
                }                
            }
        }

        private static void WriteValueToConsole(string value)
        {
            ConsoleColor prevColour = Console.ForegroundColor;
            Console.ForegroundColor = SetColour(value);
            Console.WriteLine(value);
            Console.ForegroundColor = prevColour;
        }

        private static ConsoleColor SetColour(string value)
        {
            ConsoleColor colour = Console.ForegroundColor;
 
            if (value.Contains("Topic:"))
            {
                colour = ConsoleColor.Yellow;
            }

            if(value.Contains("Compartment:"))
            {
                colour = ConsoleColor.Green;
            }

            return colour;
        }

        private static void SetDefaultColour()
        {
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
