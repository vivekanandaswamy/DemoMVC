﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Ecolab.PLCTest.Utils
{
    public class TestParam
    {
        private XmlNode testcase;
        public TestParam()
        {}
        public TestParam(string filename, string testcase)
        {
            XmlFilePath = filename;
            TestcaseName = testcase;
            GetTestcase();
        }
        
        public string XmlFilePath { get; set; }
        public string TestcaseName { get; set; }

        public string GetTopicName 
        { 
            get
            {
                return testcase.SelectSingleNode("./ControllerId/TopicName").InnerText;
            }
        }
       
        public string GetOPCServerName 
        { 
            get
            {
                return testcase.SelectSingleNode("./OPCServerName").InnerText;
            }
        }

        public int GetControllerId 
        { 
            get
            {
                return Convert.ToInt32(((XmlElement)testcase.SelectSingleNode("./ControllerId")).GetAttribute("id"));
            }
        }

        public ControllerType GetControllerType(XmlNode controllerNode)
        {
           
            ControllerType type = ControllerType.AllenBradely;
            if (((XmlElement)controllerNode).GetAttribute("Type").ToLower().Trim().Equals("beckhoff"))
            {
                type = ControllerType.Beckhoff;
            }

            if (((XmlElement)controllerNode).GetAttribute("Type").ToLower().Trim().Equals("AllenBradely"))
            {
                type = ControllerType.AllenBradely;
            }
            return type;            
        }

        public ReadOnlyCollection<InjectionData> GetInjectionData 
        { 
            get
            {
                List<InjectionData> injectionDataList = new List<InjectionData>();
                XmlNodeList controllers = ((XmlElement)testcase).GetElementsByTagName("ControllerId");
                foreach(XmlNode controller in controllers)
                {
                    
                    XmlNodeList washers = controller.SelectNodes("./Washer");
                    foreach (XmlNode washer in washers)
                    {
                        InjectionData injectionData = new InjectionData();
                        injectionData.IsActive = true;
                        injectionData.TopicName = controller.SelectSingleNode("./TopicName").InnerText;
                        injectionData.ControllerType = GetControllerType(controller);
                        injectionData.InjectionFrequency = Convert.ToInt32(washer.SelectSingleNode("./InjectionFrequency").InnerText);
                        injectionData.TagAddress = washer.SelectSingleNode("./TagAddress").InnerText;
                        injectionData.TagStartValue = Convert.ToInt32(washer.SelectSingleNode("./TagStartValue").InnerText);
                        injectionData.NumberOfInjection = Convert.ToInt32(washer.SelectSingleNode("./NumberOfInjection").InnerText);
                        injectionData.OperationCounter = washer.SelectSingleNode("./OperationCounterTag").InnerText;
                        injectionData.batchId = Convert.ToInt32(((XmlElement)washer).GetAttribute("BatchId"));
                        injectionData.WasherTagAddress = washer.SelectSingleNode("./WasherTagAddress").InnerText;
                        injectionData.WasherValue = Convert.ToInt32(washer.SelectSingleNode("./WasherValue").InnerText);
                        injectionData.AWEActiveTagAddress = washer.SelectSingleNode("./AutoWeightEntryActiveTagAddress").InnerText;
                        injectionData.AWEActive = washer.SelectSingleNode("./AutoWeightEntryActive").InnerText;
                        injectionData.AWEWeightTagAddress = washer.SelectSingleNode("./AutoWeightEntryWeightTagAddress").InnerText;
                        injectionData.AWEWeight = Convert.ToInt32(washer.SelectSingleNode("./AutoWeightEntryWeight").InnerText);
                        injectionData.TurnTime = Convert.ToInt32(washer.SelectSingleNode("./TurnTime").InnerText);

                        CurrentFormulaData currentFormula = new CurrentFormulaData();
                        currentFormula.TagAddress = washer.SelectSingleNode("./CurrentFormula/TagAddress").InnerText;
                        currentFormula.FormulaValue = Convert.ToInt32(washer.SelectSingleNode("./CurrentFormula/FormulaValue").InnerText);
                        currentFormula.EndOfFormula = Convert.ToInt32(washer.SelectSingleNode("./CurrentFormula/EndOfFormula").InnerText);
                        injectionData.CurrentFormula = currentFormula;

                        AlarmData alarmData = new AlarmData();
                        alarmData.ErrorMessageTagAddress = washer.SelectSingleNode("./Alarm/ErrorMsgTagAddress").InnerText;
                        alarmData.ErrorMessageCode = Convert.ToInt32(washer.SelectSingleNode("./Alarm/ErrorCode").InnerText);
                        alarmData.FormulaTagAddress = washer.SelectSingleNode("./Alarm/FormulaTagAddress").InnerText;
                        injectionData.AlarmDetails = alarmData;

                        if (null != washer.SelectSingleNode("./HoldOn"))
                        {
                            string holdOnValue = washer.SelectSingleNode("./HoldOn").InnerText;
                            List<int> holdInjectionValueList = new List<int>();
                            foreach (string holdInjection in holdOnValue.Split(','))
                            {
                                holdInjectionValueList.Add(Convert.ToInt32(holdInjection.Trim()));
                            }

                            injectionData.HoldOn = holdInjectionValueList;
                        }
                        injectionDataList.Add(injectionData);
                    }
                }
                
                return injectionDataList.AsReadOnly();   
            }
        }

        //public CurrentFormulaData GetFormulaData 
        //{
        //    get
        //    {
        //        CurrentFormulaData currentFormula = new CurrentFormulaData();
        //        currentFormula.TagAddress = testcase.SelectSingleNode("./CurrentFormula/TagAddress").InnerText;
        //        currentFormula.FormulaValue = Convert.ToInt32(testcase.SelectSingleNode("./CurrentFormula/FormulaValue").InnerText);
        //        currentFormula.EndOfFormula = Convert.ToInt32(testcase.SelectSingleNode("./CurrentFormula/EndOfFormula").InnerText);
        //        return currentFormula;
        //    }
        //}

        private void GetTestcase()
        {
            XmlDocument xmlDoc = GetXmlDoc();
            testcase = xmlDoc.SelectSingleNode(string.Format("/TestCases/TestCase[@name='{0}']",TestcaseName));           
        }       

        private XmlDocument GetXmlDoc()
        {
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(XmlFilePath);
            return XmlDoc;
        }
    }
}
