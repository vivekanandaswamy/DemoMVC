﻿using Ecolab.PLCTest.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Ecolab.PLCTest
{
    class BeckhoffTest : TestBase
    {
        [TestCategory(TestType.dcsAB, "TC01_InjectSingleBeckConv")]
        [Test]
        public void TC01_InjectSingleBeckConv()
        {
            Entities.BeckhoffXmlNode beck = new Entities.BeckhoffXmlNode
            {
                ts = DateTime.UtcNow,
                data = 2,
                tag = "N7:0",
                desc = "Test"
            };

            var test = SerializeToXmlElement(beck);
            Beckhoff.InjectToDCS(1, "");

            //XmlSerializer serializer = new XmlSerializer(typeof(Entities.BeckhoffXmlNode));
            //StringWriter sww = new StringWriter();
            //XmlWriter writer = XmlWriter.Create(sww);
            //serializer.Serialize(writer, beck);
        }


        public static XmlElement SerializeToXmlElement(object o)
        {
            XmlDocument doc = new XmlDocument();

            using (XmlWriter writer = doc.CreateNavigator().AppendChild())
            {
                new XmlSerializer(o.GetType()).Serialize(writer, o);
            }

            return doc.DocumentElement;
        }
    }
}
