﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest
{
    public static class Wait
    {
        public delegate bool waitForTrueAction();
        public static bool WaitforAction(waitForTrueAction decisionAction, int MaxWaitTime)
        {
            DateTime start;
            double timeElapsed = 0;
            
            start = DateTime.Now;

            while (false == decisionAction() && timeElapsed < MaxWaitTime)
            {
                timeElapsed = ((TimeSpan)(DateTime.Now - start)).TotalMilliseconds;
            }

            return decisionAction();
        }
               

        public delegate Object waitForObjectAction();
        public static Object WaitforAction(waitForObjectAction decisionAction, int MaxWaitTime)
        {
            DateTime start;
            double timeElapsed = 0;            

            start = DateTime.Now;

            while (null == decisionAction() && timeElapsed < MaxWaitTime)
            {                
                timeElapsed = ((TimeSpan)(DateTime.Now - start)).TotalMilliseconds;
            }

            return decisionAction();
        }

        
        public static T WaitforNullAction<T>(waitForObjectAction decisionAction, int MaxWaitTime)
        {
            DateTime start;
            double timeElapsed = 0;
           
            start = DateTime.Now;
            while (null != decisionAction() && timeElapsed < MaxWaitTime)
            {
                var test = decisionAction();
               timeElapsed = ((TimeSpan)(DateTime.Now - start)).TotalMilliseconds;
            }

            return (T)decisionAction();
        }

        public delegate T waitForCountAction<T>() where T : ICollection;
        public static T WaitforCountAction<T>(waitForCountAction<T> decisionAction, int countValue, int MaxWaitTime) where T : ICollection
        {
            DateTime start;
            double timeElapsed = 0;
            
            start = DateTime.Now;

            int test = 3;
            while (decisionAction().Count != countValue && timeElapsed < MaxWaitTime)
            {
                test = decisionAction().Count;
                timeElapsed = ((TimeSpan)(DateTime.Now - start)).TotalMilliseconds;
            }
            //int test2 = test;
            return (T)decisionAction();
        }
    }
}
