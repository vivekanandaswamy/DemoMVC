﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Ecolab.PLCTest
{
    public class Beckhoff
    {
        private string connectionString;

        public Beckhoff(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public void InjectToDCS(int washerId, string xml)
        {
            DataMapper map = new DataMapper(connectionString);

            XmlDocument xmlToSave = new XmlDocument();
            xmlToSave.Load(@".\Beckhoff\Xml1.xml");

            map.CreateCommand("tcd.ProcessConventionalWasherData");
            map.Command.CommandType = System.Data.CommandType.StoredProcedure;
            map.Command.Parameters.AddWithValue("@WasherId", washerId);
            //map.Command.Parameters.AddWithValue("@xmlTags", xml);
            map.Command.Parameters.Add(
              new SqlParameter("@xmlTags", SqlDbType.Xml)
              {
                  Value = new SqlXml(new XmlTextReader(xmlToSave.InnerXml
                             , XmlNodeType.Document, null))
              });
            map.Command.ExecuteNonQuery();
        }
    }
}
