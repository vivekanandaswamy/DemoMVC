﻿using Ecolab.CommonUtilityPlugin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.PLCTest
{
    public class AllenBradely
    {
        public void InjectABCovnentionalWasher(List<Dictionary<string, string>> tagsList, string topicName, int stepWait)
        {
            OPCClient client = new CommonUtilityPlugin.OPCClient();
            client.TopicAB = topicName;
            client.OPCServerAB = "Matrikon.OPC.Simulation.1";

            foreach (Dictionary<string, string> tags in tagsList)
            {
                client.CreateABTags(tags);
                client.WriteDataToABController();
                Thread.Sleep(stepWait);
            }

            tagsList.Clear();
        }
    }
}
