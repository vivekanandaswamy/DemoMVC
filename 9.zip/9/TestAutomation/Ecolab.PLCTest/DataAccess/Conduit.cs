﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.PLCTest
{
    public class Conduit
    {
        private string connectionString;

        public Conduit(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public List<Entities.Batch> GetBatch(int value)
        {
            DataMapper map = new DataMapper(connectionString);
            map.CreateCommand(Resource.Getbatch);
            map.Command.Parameters.AddWithValue("@BatchId", value);
            return map.GetData<Entities.Batch>();
        }

        public Entities.Batch GetOpenBatch()
        {
            List<Entities.Batch> batches = new List<Entities.Batch>();
            Wait.WaitforAction(() =>
            {
                DataMapper map = new DataMapper(connectionString);
                map.CreateCommand(Resource.GetOpenBatch);
                batches = map.GetData<Entities.Batch>();

                return batches != null ? batches.Count > 0 : false;
            }, 10000);
            return batches.FirstOrDefault();
        }
    }
}
