SELECT	BatchId,
		ProgramNumber,
		PlantWasherNumber,
		ControllerBatchId,
		StartDate
FROM	TCD.BatchData
WHERE	EndDate	is Null

	