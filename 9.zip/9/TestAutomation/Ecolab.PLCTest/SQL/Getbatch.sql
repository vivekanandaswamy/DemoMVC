SELECT	EndDate
FROM	TCD.BatchData
WHERE	BatchId	=	@BatchId

	