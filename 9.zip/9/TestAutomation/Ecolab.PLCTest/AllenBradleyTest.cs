﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.PLCTest
{
    public class AllenBradelyTest : TestBase
    {

        [TestCategory(TestType.dcsAB, "TC01_InjectSingleABConv")]
        [Test]
        public void TC01_InjectSingleABConv()
        {
            List<Dictionary<string, string>> tags = new List<Dictionary<string, string>>();
            int programNumber = 2;

            tags.Add(new Dictionary<string, string>() { { "N7:0", programNumber.ToString() }, { "N7:1", "0" }, { "N7:2", "0" } });

            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 4000);
            Entities.Batch batch = Conduit.GetOpenBatch();

            tags.Add(new Dictionary<string, string>() { { "N7:0", programNumber.ToString() }, { "N7:1", "1" }, { "N7:2", "1" } });
            tags.Add(new Dictionary<string, string>() { { "N7:0", programNumber.ToString() }, { "N7:1", "2" }, { "N7:2", "2" } });

           

            tags.Add(new Dictionary<string, string>() { { "N7:0", "31" }, { "N7:1", "0" }, { "N7:2", "0" } });
            
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1",4000);

            var test = Conduit.GetBatch(batch.BatchId);
            batch.EndDate = Conduit.GetBatch(batch.BatchId).FirstOrDefault().EndDate;

            if (null == batch.EndDate)
            {
                Assert.Fail("Batch end time is null after sending EOF");
            }

            if(batch.StartDate == batch.EndDate)
            {
                Assert.Fail("Start and end date are equal");
            }

            if(!batch.ProgramNumber.Equals(programNumber))
            {
                Assert.Fail("Program number is incorrectly updated in conduit");
            }

            if(batch.ControllerBatchId != 0)
            {
                Assert.Fail("Controller batch id is not 0");
            }

        }

        [TestCategory(TestType.dcsAB, "TC02_InjectABBatchWithoutEOF")]
        [Test]
        public void TC02_InjectABBatchWithoutEOF()
        {
            List<Dictionary<string, string>> tags = new List<Dictionary<string, string>>();
            int firstProgramNumber = 2;
            int secondProgramNumber = 3;

            tags.Add(new Dictionary<string, string>() { { "N7:0", firstProgramNumber.ToString() }, { "N7:1", "0" }, { "N7:2", "0" } });

            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 4000);
            Entities.Batch batch1 = Conduit.GetOpenBatch();

            tags.Add(new Dictionary<string, string>() { { "N7:0", firstProgramNumber.ToString() }, { "N7:1", "1" }, { "N7:2", "1" } });
            tags.Add(new Dictionary<string, string>() { { "N7:0", firstProgramNumber.ToString() }, { "N7:1", "2" }, { "N7:2", "2" } });
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 4000);

            tags.Clear();

            tags.Add(new Dictionary<string, string>() { { "N7:0", secondProgramNumber.ToString() }, { "N7:1", "0" }, { "N7:2", "0" } });

            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 4000);
            Entities.Batch batch2 = Conduit.GetOpenBatch();

            tags.Add(new Dictionary<string, string>() { { "N7:0", secondProgramNumber.ToString() }, { "N7:1", "1" }, { "N7:2", "1" } });
            tags.Add(new Dictionary<string, string>() { { "N7:0", secondProgramNumber.ToString() }, { "N7:1", "2" }, { "N7:2", "2" } });

            tags.Add(new Dictionary<string, string>() { { "N7:0", "31" }, { "N7:1", "0" }, { "N7:2", "0" } });

            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 4000);

            batch1.EndDate = Conduit.GetBatch(batch1.BatchId).FirstOrDefault().EndDate;
            batch2.EndDate = Conduit.GetBatch(batch2.BatchId).FirstOrDefault().EndDate;

            if(batch1.BatchId == batch2.BatchId)
            {
                Assert.Fail("New batch is not created if EOF is not sent");
            }

            if(null == batch1.EndDate)
            {
                Assert.Fail("Batch is not ended if EOF is not sent");
            }

            if(batch1.ProgramNumber != firstProgramNumber)
            {
                Assert.Fail("Batch 1 program number is not correct");
            }

            if(batch2.ProgramNumber != secondProgramNumber)
            {
                Assert.Fail("Batch 2 program number is not correct");
            }
        }

        [TestCategory(TestType.dcsAB, "TC03_SendABConsecutiveBeginFormula")]
        [Test]
        public void TC03_SendABConsecutiveBeginFormula()
        {
            List<Dictionary<string, string>> tags = new List<Dictionary<string, string>>();
            int firstProgramNumber = 2;
            int secondProgramNumber = 3;

            tags.Add(new Dictionary<string, string>() { { "N7:0", firstProgramNumber.ToString() }, { "N7:1", "0" }, { "N7:2", "0" } });
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 2000);
            Entities.Batch batch1 = Conduit.GetOpenBatch();

            tags.Add(new Dictionary<string, string>() { { "N7:0", secondProgramNumber.ToString() }, { "N7:1", "0" }, { "N7:2", "0" } });
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 2000);
            Entities.Batch batch2 = Conduit.GetOpenBatch();

            tags.Add(new Dictionary<string, string>() { { "N7:0", secondProgramNumber.ToString() }, { "N7:1", "1" }, { "N7:2", "1" } });
            tags.Add(new Dictionary<string, string>() { { "N7:0", secondProgramNumber.ToString() }, { "N7:1", "2" }, { "N7:2", "2" } });
            tags.Add(new Dictionary<string, string>() { { "N7:0", "31" }, { "N7:1", "0" }, { "N7:2", "0" } });
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 2000);

            batch1.EndDate = Conduit.GetBatch(batch1.BatchId).FirstOrDefault().EndDate;
            batch2.EndDate = Conduit.GetBatch(batch2.BatchId).FirstOrDefault().EndDate;

            if(null == batch1.EndDate)
            {
                Assert.Fail("First batch is not closed if consecutive begin formula is sent");
            }

            if(batch1.StartDate == batch1.EndDate)
            {
                Assert.Fail("Batch start and end date are for batch whose EOF is not sent");
            }
        }

        [TestCategory(TestType.dcsAB, "TC04_SendABOnlyFRMConscutively")]
        [Test]
        public void TC04_SendABOnlyFRMConscutively()
        {
            List<Dictionary<string, string>> tags = new List<Dictionary<string, string>>();
            int firstProgramNumber = 2;
            int secondProgramNumber = 3;

            tags.Add(new Dictionary<string, string>() { { "N7:0", firstProgramNumber.ToString() }});
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 2000);
            Entities.Batch batch1 = Conduit.GetOpenBatch();

            tags.Add(new Dictionary<string, string>() { { "N7:0", secondProgramNumber.ToString() }});
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 2000);
            Entities.Batch batch2 = Conduit.GetOpenBatch();

            tags.Add(new Dictionary<string, string>() { { "N7:0", "31" } });
            AllenBradely.InjectABCovnentionalWasher(tags, "UNIT1", 2000);


            batch1.EndDate = Conduit.GetBatch(batch1.BatchId).FirstOrDefault().EndDate;
            batch2.EndDate = Conduit.GetBatch(batch2.BatchId).FirstOrDefault().EndDate;

            if(null == batch1.EndDate)
            {
                Assert.Fail("If only FRM is sent without OPC and INJ, batch is not ended");
            }

            if (null == batch2.EndDate)
            {
                Assert.Fail("If only EOF is sent without OPC and INJ, batch is not ended");
            }

        }

    }
}
