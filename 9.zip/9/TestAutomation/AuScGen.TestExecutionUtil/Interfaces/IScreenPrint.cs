﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AuScGen.TestExecutionUtil
{
    public interface IScreenPrint
    {
        void ScreenPrint();
        void ScreenPrint(string message);
        void ScreenPrint(string message, string method);
    }
}
