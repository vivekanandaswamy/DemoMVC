﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class StorageTanksCondition : Ecolab.BaseSetings, IDataCondition
    {
        private void DeleteAllStorageTanks()
        {
            AppState.GetState<StorageTankState>().DeleteAllStorageTanks();
        }

        public void Execute()
        {
            DeleteAllStorageTanks();
        }
    }
}
