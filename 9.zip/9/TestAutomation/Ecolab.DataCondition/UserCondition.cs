﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class UserCondition : Ecolab.BaseSetings , IDataCondition
    {
        private void CleanupAndCreateUsers()
        {
            AppState.GetState<UserState>().DeleteAllUserExceptAdmin();            
            foreach (List<string> list in GetAllUsers("../../../bin/Config/Users.xml"))
            {
                AppState.GetState<UserState>().CreateUser(list[0], list[1], list[2]);             
            }        
        }

        public void Execute()
        {
            CleanupAndCreateUsers();
        }
    }
}
