﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class ContactsCondition : Ecolab.BaseSetings, IDataCondition
    {
        private void DeleteAllPlantContacts()
        {
            AppState.GetState<PlantContactState>().DeleteAllPlantContacts();
        }

        public void Execute()
        {
            DeleteAllPlantContacts();
        }
    }
}
