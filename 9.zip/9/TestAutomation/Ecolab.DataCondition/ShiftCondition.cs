﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class ShiftCondition : Ecolab.BaseSetings, IDataCondition
    {
        private void DeleteAllShift()
        {            
            AppState.GetState<ShiftState>().DeleteAllShift();            
        }

        public void Execute()
        {
            DeleteAllShift();
        }
    }
}
