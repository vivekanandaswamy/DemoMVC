﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class RewashCondition : Ecolab.BaseSetings , IDataCondition
    {
        private void AllowAllFormulasForRewash()
        {
            AppState.GetState<ProgramState>().AllowAllFormulaForManualRewash();
        }

        public void Execute()
        {
            AllowAllFormulasForRewash();
        }
    }
}
