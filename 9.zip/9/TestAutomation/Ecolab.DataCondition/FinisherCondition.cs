﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class FinisherCondition : Ecolab.BaseSetings, IDataCondition
    {
        private void DeleteAllFinishers()
        {
            AppState.GetState<FinisherState>().DeleteAllFinishers();
        }

        public void Execute()
        {
            DeleteAllFinishers();
        }
    }
}
