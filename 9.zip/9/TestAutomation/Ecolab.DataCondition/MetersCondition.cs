﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class MetersCondition : Ecolab.BaseSetings, IDataCondition
    {
        private void DeleteAllMeters()
        {
            AppState.GetState<MeterState>().DeleteAllMeters();
        }

        public void Execute()
        {
            DeleteAllMeters();
        }
    }
}
