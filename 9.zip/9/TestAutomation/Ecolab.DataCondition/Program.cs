﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class Program
    {
        public static void Main(string[] args)
        {
            AppState.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            NameValueCollection dataConditions = ConfigurationManager.AppSettings;
            
            Type type;
            foreach(string conditon in GetDataConditionContexts())
            {
                type = Type.GetType(string.Format("Ecolab.DataCondition.{0}",conditon));
                IDataCondition condition = (IDataCondition)Activator.CreateInstance(type);
                condition.Execute();
                Console.WriteLine(string.Format("{0} : Conditioning is complete ...",conditon));
            }

            Console.Read();
        }

        static List<string> GetDataConditionContexts()
        {
            return ConfigurationManager.AppSettings.AllKeys.ToList().Where(data => IsConditonData(data)).ToList();                        
        }

        static bool IsConditonData(string key)
        {
            return Convert.ToBoolean(ConfigurationManager.AppSettings[key]);            
        }
    }
}
