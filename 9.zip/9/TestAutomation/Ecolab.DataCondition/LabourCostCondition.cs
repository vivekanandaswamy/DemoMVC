﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class LabourCostCondition : Ecolab.BaseSetings, IDataCondition
    {
        private void ResetLabourCost()
        {            
            AppState.GetState<LabourCostState>().ResetLabourCost(15, 15, 15, 15);            
        }

        public void Execute()
        {
            ResetLabourCost();
        }
    }
}
