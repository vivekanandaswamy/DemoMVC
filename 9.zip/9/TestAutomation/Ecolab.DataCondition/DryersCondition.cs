﻿using Ecolab.AppStateHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.DataCondition
{
    class DryersCondition : Ecolab.BaseSetings, IDataCondition
    {
        private void DeleteAllDryers()
        {
            AppState.GetState<DryerState>().DeleteAllDryers();
        }

        public void Execute()
        {
            DeleteAllDryers();
        }
    }
}
