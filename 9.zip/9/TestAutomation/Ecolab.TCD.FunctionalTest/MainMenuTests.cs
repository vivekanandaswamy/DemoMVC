﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using System.Threading;

namespace Ecolab.FunctionalTest
{
	public class MainMenuTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);            
        }

        [TestCategory(TestType.bvt, "TC01_VerySetupMenuItem")]
        [TestCategory(TestType.regression, "TC01_VerySetupMenuItem")]
        [TestCategory(TestType.functional, "TC01_VerySetupMenuItem")]
		[Test, Description("Test case 18624: Verify availability of Setup fromTop menu in the Homepage ;" +
		"Test case 18643: Verify Setup displays list with two options ;")]
        public void TC01_VerySetupMenuItem()
        {
			Runner.DoStep("'Setup' from Top menu in the Homepage", () => Assert.True(Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Setup")));
			Runner.DoStep("'Plant Setup' from Top menu in the Homepage", () => Assert.True(Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Plant Setup")));
			Runner.DoStep("'Dispenser Setup' from Top menu in the Homepage", () => Assert.True(Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Dispenser Setup")));
			Runner.DoStep("'Washer Groups' from Top menu in the Homepage", () => Assert.True(Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Washer Groups")));
			Runner.DoStep("'Storage Tanks' from Top menu in the Homepage", () => Assert.True(Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Storage Tanks")));
        }

        [TestCategory(TestType.bvt, "TC02_VerifyPlantSetup")]
        [TestCategory(TestType.regression, "TC02_VerifyPlantSetup")]
        [TestCategory(TestType.functional, "TC02_VerifyPlantSetup")]
		[Test, Description("Test case 18624: Verify availability of SETUP fromTop menu in the Homepage ;")]
        public void TC02_VerifyPlantSetup()
        {
			Runner.DoStep("'Plant Setup and General' from Top menu in the Homepage", () =>
            {
                Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
                Thread.Sleep(3000);
                Assert.True(Page.PlantSetupPage.BreadCrumbDetailsList().Contains("Plant Setup"));
                Assert.True(string.Equals(Page.PlantSetupPage.ActiveTabItem, "General"));
            });

			Runner.DoStep("'Dispenser Setup' from Top menu in the Homepage", () => 
            {
                Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
                Thread.Sleep(3000);
                Assert.True(Page.PlantSetupPage.BreadCrumbDetailsList().Contains("Dispenser Setup"));
            });

			Runner.DoStep("'Washer Groups' from Top menu in the Homepage", () => 
            {
                Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
                Thread.Sleep(3000);
                Assert.True(Page.PlantSetupPage.BreadCrumbDetailsList().Contains("Washer Groups"));
            });

			Runner.DoStep("'Storage Tanks' from Top menu in the Homepage", () => 
            {
                Page.LoginPage.TopMainMenu.NavigateToStorageTanksPage();
                Thread.Sleep(3000);
                Assert.True(Page.PlantSetupPage.BreadCrumbDetailsList().Contains("Storage Tanks"));
            });            
        }


        [TestCategory(TestType.bvt, "TC03_VerifyControllerToPlantSetupNavigation")]
        [TestCategory(TestType.regression, "TC03_VerifyControllerToPlantSetupNavigation")]
        [TestCategory(TestType.functional, "TC03_VerifyControllerToPlantSetupNavigation")]
		[Test, Description("Test case 20650: Verify user able to navigate to PlantSetup from Controller Setup ;")]
        public void TC03_VerifyControllerToPlantSetupNavigation()
        {
            Runner.DoStep("'Navigate Controller Setup Page' from Top menu in the Homepage", () => Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage());
            Runner.DoStep("'Navigate Plant Setup Page' from Top menu in the Homepage", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
            Thread.Sleep(3000);
            Runner.DoStep("'Plant Setup' from Top menu in the Homepage", () => Assert.True(Page.PlantSetupPage.BreadCrumbDetailsList().Contains("Plant Setup")));
        }

        [TestCategory(TestType.bvt, "TC04_VerifyLogOut")]
        [TestCategory(TestType.regression, "TC04_VerifyLogOut")]
        [TestCategory(TestType.functional, "TC04_VerifyLogOut")]
		[Test, Description("'Logout' of the Application")]
        public void TC04_VerifyLogOut()
        {
            Runner.DoStep("'Logout' from Top menu in the Homepage", () => Page.LoginPage.TopMainMenu.LogOut());
        }
    }
}
