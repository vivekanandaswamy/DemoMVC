﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.CommonUtilityPlugin;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
	public class UserProfilePageTests : TestBase
	{
		[TestFixtureSetUp]
		public void TestFixture()
		{
			Console.WriteLine("Test Fixture overridden");
			Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
			//Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
			Thread.Sleep(2000);
			Page.PlantSetupPage.TopMainMenu.NavigateToUserProfile();

		}

		private void CloseBrowser()
		{
			Telerik.Shutdown();
			Telerik.CleanUp();
		}

		[TestCategory(TestType.functional, "TC01_VerifyAndValidateMyProfilepage")]
		[TestCategory(TestType.regression, "TC01_VerifyAndValidateMyProfilepage")]
		[Test, Description("Test case 38757: RG: Verify the UI fields are displaying on 'MyProfile' page. ;" +
		"Test case 38758: RG Verify the navigation when user clicks on 'Change Password' button ;" +
		"Test case 38788: RG Verify the 'Save' button functionaliy. ;" +
		"Test case 38793: RG Verify the 'Cancel' button Functionality. ;")]
		public void TC01_VerifyAndValidateMyProfilepage()
		{
			Random rand = new Random();
			long ranMobileNumber = rand.Next(100000000, 999999999) * 10;
			Runner.DoStep("'EnterData' on User Profile Page.", () => EnterData(ranMobileNumber, "English US"));
			Runner.DoStep("'Verify User Interface' on User Profile Page.", () => VerifyUI());
			Runner.DoStep("'Cancel' button click.", () => Page.UserProfilePage.BtnCancelAdd.Click());
			Runner.DoStep("'No' button click", () => DialogHandler.NoButton.Click());
			Runner.DoStep("'Database' validation.", () => DBCheck(false, ranMobileNumber));
			Runner.DoStep("'EnterData' on User Profile Page.", () => EnterData(ranMobileNumber, "English US"));
			Runner.DoStep("'Cancel Add' button click", () => Page.UserProfilePage.BtnCancelAdd.Click());
			Runner.DoStep("'Yes' button click", () => DialogHandler.YesButton.Click());
            Thread.Sleep(2000);
			Runner.DoStep("'Success' message validation", () => VerifySuccessMessage());
			Runner.DoStep("'Database' verification", () => DBCheck(true, ranMobileNumber));
			Runner.DoStep("'Setup' from Top menu in the Homepage", () => EnterData(ranMobileNumber, "English US"));
            Thread.Sleep(2000);
			Runner.DoStep("'Save Add' button click", () => Page.UserProfilePage.BtnSaveAdd.Click());
            Thread.Sleep(2000);
			Runner.DoStep("'Success' message verification", () => VerifySuccessMessage());
			Runner.DoStep("'Database' verification", () => DBCheck(true, ranMobileNumber));
		}

		[TestCategory(TestType.functional, "TC02_VerifyChangePasswordOnMyProfilepage")]
		[TestCategory(TestType.regression, "TC02_VerifyChangePasswordOnMyProfilepage")]
		[Test, Description("Test case 38811: RG Verify the 'Change Password' page functionlity. ;" +
		"Test case 38817: RG Verify the 'Save' button functionality on 'change password' pop-up. ;")]
		public void TC02_VerifyChangePasswordOnMyProfilepage()
		{
			Runner.DoStep("'Verify User Interface' on User Profile Page.", () => VerifyUI());
			Runner.DoStep("'Link change Password' click", () => Page.UserProfilePage.LnkChangePwd.Click());
			Runner.DoStep("'Change Password' data entered on screen.", () => ChangePassword());
			Runner.DoStep("'Cancel Password' button click", () => Page.UserProfilePage.BtnCancelPassword.Click());
			Thread.Sleep(2000);
			Runner.DoStep("'Link change Password' click", () => Page.UserProfilePage.LnkChangePwd.Click());
			Runner.DoStep("'Change Password' data entered on screen. ", () => ChangePassword());
			Runner.DoStep("'Save Password' button click", () => Page.UserProfilePage.BtnSavePassword.Click());
			Runner.DoStep("'Database' verification", () => VerifyChangePasswordDB());
			if (VerifyChangePasswordDB() == true)
			{
				Runner.DoStep("'Change Password' on User Profile page", () => Assert.True(true, string.Format("Expected Password successfully changed to 'test'")));
			}
			else
			{
				Runner.DoStep("'Change Password' on User Profile page", () => Assert.Fail(string.Format("Password change was not successfully")));
			}
		}

		[TestCategory(TestType.functional, "TC03_Verifythelocalization")]
		//[TestCategory(TestType.regression, "TC03_Verifythelocalization")]
		[Test, Description("Test case 40788: RG Verify the localization ;")]
		public void TC03_Verifythelocalization()
		{
			Random rand = new Random();
			long ranMobileNumber = rand.Next(100000000, 999999999) * 10;
			Thread.Sleep(2000);
			Runner.DoStep("'Language Change to Deutsch' on User Profile page.", () => Page.UserProfilePage.LanguagePreferred.SelectByText("Deutsch", Timeout));
			Runner.DoStep("'Save Add' click on user profile page", () => Page.UserProfilePage.BtnSaveAdd.Click());
			Runner.DoStep("'Logout' button click", () => Page.LoginPage.TopMainMenu.LogOut());
			Runner.DoStep("'Close Browser' button click", () => CloseBrowser());
			Runner.DoStep("'Setup Base' Text fixture execution", () => TestFixtureSetupBase());
			Thread.Sleep(2000);
			Runner.DoStep("'Test Fixture' Execution", () => TestFixture());
			Thread.Sleep(2000);
			if (Page.UserProfilePage.BtnSaveAdd.InnerText != "Opslaan")
			{
				Runner.DoStep("'Deutch Language' valdiation of language change", () => Assert.Fail("Actual Found -" + Page.UserProfilePage.BtnSaveAdd.InnerText + "; Expected Deutch Language change is not reflecting for 'Save' Button 'Opslaan'"));
			}
			Runner.DoStep("'English' language change on user profile page", () => Page.UserProfilePage.LanguagePreferred.SelectByText("English US", Timeout));
			Runner.DoStep("'Save Add' button click", () => Page.UserProfilePage.BtnSaveAdd.Click());
			Runner.DoStep("'Logout' button click", () => Page.LoginPage.TopMainMenu.LogOut());
			Runner.DoStep("'Close Browser' button click", () => CloseBrowser());
		}

		private bool VerifyDB(long ranMobileNumber)
		{
			string strCommand = string.Format("select Phone from TCD.UserMaster where LoginName = 'Admin' and Phone='{0}'", ranMobileNumber);
			DataRowCollection rows = DBValidation.DataRows(strCommand);
			Thread.Sleep(2000);
			return rows.Count > 0;
		}

		private void VerifyUI()
		{
			if (null != Page.UserProfilePage.UserRole)
			{
				string userRole = Page.UserProfilePage.UserRole.BaseElement.InnerText;
				if (!userRole.Equals("Adminstrator"))
				{
					Runner.DoStep("'User Role' validation on User Profile Page.", () => Assert.Fail("User role is incorrectly displayed in profile page, Expected role:Adminstrator, Actual:{0}", userRole));
				}
			}
			else
			{
				Runner.DoStep("'User Role' validation on User Profile Page.e", () => Assert.Fail("User role is not displayed in the profile page Expected role:Adminstrator"));
			}

			if (null != Page.UserProfilePage.LnkChangePwd)
			{
				if (!Page.UserProfilePage.LnkChangePwd.IsVisible())
				{
					Runner.DoStep("'Change Password' button validation", () => Assert.Fail("Change Password button is not displayed on the My Profile screen."));
				}
			}
			else
			{
				Runner.DoStep("'Change Password' button validation", () => Assert.Fail("User role is not displayed in the profile page Expected role:Adminstrator"));
			}
		}

		private void EnterData(long ranMobileNumber, string language)
		{
			//Page.PlantSetupPage.TopMainMenu.UserProfileLink.DeskTopMouseClick();
			Runner.DoStep("'Title' enter details", () => Page.UserProfilePage.DdlTitle.SelectByText("Mr.", Timeout));
			Runner.DoStep("'First Name' enter details", () => Page.UserProfilePage.TxtFirstName.TypeText("Admin"));
			Runner.DoStep("'Last Name' enter details", () => Page.UserProfilePage.TxtLastName.TypeText("Test"));
			Runner.DoStep("'Language' enter details", () => Page.UserProfilePage.LanguagePreferred.SelectByText(language, Timeout));
			Runner.DoStep("'Email' enter details", () => Page.UserProfilePage.TxtEmail.TypeText("Admin@ecolab.com"));
			Runner.DoStep("'Office Phone' enter details", () => Page.UserProfilePage.TxtOfficePhone.TypeText(ranMobileNumber.ToString()));
			Runner.DoStep("'Mobile Phone' enter details", () => Page.UserProfilePage.TxtMobilePhone.TypeText("9848230919"));
			Runner.DoStep("'Fax No.' enter details", () => Page.UserProfilePage.TxtFaxNo.TypeText("9848230919"));
		}

		private void VerifySuccessMessage()
		{
			if (null != Page.UserProfilePage.SuccessMsg)
			{
				string message = Page.UserProfilePage.SuccessMsg.BaseElement.InnerText;
				if (!message.Contains("Saved successfully"))
				{
					Runner.DoStep("'Saved Successfully' message validation on User Profile Page", () => Assert.Fail("Incorrect error message is displayed,Expected:Saved successfully but Actual:{0}", message));
				}
			}
			else
			{
				Runner.DoStep("'Saved Successfully' message validation on User Profile Page", () => Assert.Fail("Success message is not displayed"));
			}
		}

		private void DBCheck(bool returnValue, long ranMobileNumber)
		{
			if (VerifyDB(ranMobileNumber) == returnValue)
			{
				Runner.DoStep("'Database' validation", () => Assert.True(true, string.Format("Expected Office Phone Number - {0} which doesn't exist in DB", ranMobileNumber)));
			}
			else
			{
				Runner.DoStep("'Database' validation", () =>  Assert.Fail(string.Format("Expected Office Phone Number- {0} which doesn't exist in DB", ranMobileNumber)));
			}
		}

		private void ChangePassword()
		{
			Runner.DoStep("'Old Password' on Change Password", () => Page.UserProfilePage.TxtOldPassword.DeskTopMouseClick());
			Thread.Sleep(2000);
			Runner.DoStep("'Enter Old Password' on Change Password", () => KeyBoardSimulator.SetText("test"));
			Thread.Sleep(2000);
			Runner.DoStep("'New Password' on Change Password", () => Page.UserProfilePage.TxtNewPassword.Text = "test");
			Thread.Sleep(2000);
			Runner.DoStep("'Confirm New Password' on Change Password", () => Page.UserProfilePage.TxtConfirmPassword.Text = "test");
		}

		private bool VerifyChangePasswordDB()
		{
			string strCommand = string.Format("select Password from TCD.UserMaster where LoginName = 'Admin' and Email= 'Admin@ecolab.com'");
			DataRowCollection rows = DBValidation.DataRows(strCommand);
			Thread.Sleep(2000);
			return rows.Count > 0;
		}
	}
}
