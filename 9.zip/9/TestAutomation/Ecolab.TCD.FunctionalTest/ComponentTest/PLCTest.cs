﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using Ecolab.CommonUtilityPlugin;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class PLCTest : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Thread.Sleep(2000);
        }

        [TestCategory(TestType.plc, "TC01_AddAChemical")]
        [Test(Description = "Add chemicals")]
        public void TC01_AddAChemical()
        {
            List<int> chemicalList = new List<int> { 1207340, 1200400, 9047900, 1507170, 1200170, 1012670, 1200410, 1200630, 1017570, 1204240 };
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.ChemicalsTab.Click();
            Thread.Sleep(3000);
            bool verifyAddChemicalButton = Page.ChemicalsTabPage.BtnAddChemical.IsVisible();
            Runner.DoStep("Verify whether 'Add Chemical' button is available or not", () =>
            {
                if (verifyAddChemicalButton == false)
                {
                    Assert.Fail("AddChemical button not found");
                }
            });

            foreach (int chemical in chemicalList)
            {
                Runner.DoStep("Click on 'Chemicals' tab", () =>
                {
                    Page.ChemicalsTabPage.BtnAddChemical.Click();
                });
                // Page.ChemicalsTabPage.SelectChemicalName("In");
                SelectChemicalName(chemical.ToString());
                string verifyCostValue = Page.ChemicalsTabPage.TxtCostAdd.Value;
                if (verifyCostValue == "0")
                {
                    Page.ChemicalsTabPage.TxtCostAdd.TypeText("45");
                }
                //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                //Page.ChemicalsTabPage.ChkIncludeinCIAdd.Checked = true;
                Page.ChemicalsTabPage.BtnSaveAdd.Focus();
                Page.ChemicalsTabPage.BtnSaveAdd.MouseClick();
                Runner.DoStep("Enter Chemical details and click on Save button", () =>
                {
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Enter);
                });
                Thread.Sleep(1000);
                Runner.DoStep("Verify Chemical addition", () =>
                {
                    Assert.True(Page.ChemicalsTabPage.VerifySuccessMsg.IsVisible(), "Failed to add the chemical");
                });
            }
        }

        [TestCategory(TestType.plc, "TC02_AddAFormula")]
        [Test(Description = "Add a Formulas")]
        public void TC02_AddAFormula()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulasTab.Click();
            for (int i = 1; i <= 4; i++)
            {
                Runner.DoStep("Add a Formula", () =>
                {
                    Page.FormulasTabPage.AddFormula.Click();
                    Page.FormulasTabPage.AddChainFormulaName.SelectByIndex(i);
                    Page.FormulasTabPage.FormulaName.TypeText("ChainProgram" + i);
                    Page.FormulasTabPage.RewashCheckBox.Click();
                    Page.FormulasTabPage.RewashCheckBox.Click();
                    Page.FormulasTabPage.FormulaFrameSave.Click();
                    Thread.Sleep(2000);
                });
                Thread.Sleep(2000);
                Runner.DoStep("Verify the Formula's addition", () =>
                {
                    if (null != Page.ChemicalsTabPage.UpdateSuccessMessage)
                    {
                        string message = Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText;
                        if (!message.ToLower().Contains(@"new formula added successfully"))
                        {
                            Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                        }
                    }
                    else
                    {
                        Assert.Fail("Error message is not displayed");
                    }
                });
            }    
        }

        [TestCategory(TestType.plc, "TC03_AddmyControlDispenser")]
        [Test(Description = "Add a myControl Dispenser")]
        public void TC03_AddmyControlDispenser()
        {
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            AddAndVerifymyControl("1", true);
        }

        [TestCategory(TestType.plc, "TC04_CreateWashers")]
        [Test(Description = "Create washer groups and washers")]
        public void TC04_CreateWashers()
        {
            //Ecolab.AppStateHandler.StateTransformation.ControllerTransform.PLC();                 
            //Ecolab.AppStateHandler.Entities.WasherGroup ConventionalWasherGroup = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "myControl Conven WG");            
            //Thread.Sleep(2000);
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.BtnAddWasherGroup.Click();
            AddWasherGroupItems("10", "myControl Conv WG", "Conventional");
            Thread.Sleep(2000);
            AddTunnelWashers();
            AddConventionalWashers();
        }

        [TestCategory(TestType.plc, "TC05_AddDevices")]
        [Test(Description = "Attach products to Devices")]
        public void TC05_AddDevices()
        {
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.ControllersTabGrid.Rows[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(5000);
            for (int i = 1; i <= 10; i++)
            {
                Page.ControllerSetupPage.PumpsValvesTab.DeskTopMouseClick();
                Page.ControllerPumpValvesPage.PumpsAndValvesTabGrid.Rows[i - 1].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Page.ControllerPumpValvesPage.ProductNameAB.SelectByIndex(i, Timeout);
                Page.ControllerPumpValvesPage.PumpType.SelectByIndex(1, Timeout);
                Page.PumpsValvesPage.LineNumber.SelectByIndex(i, Timeout);
                Page.PumpsValvesPage.CompartmentForDPT1.SelectByIndex(i, Timeout);
                Page.PumpsValvesPage.CompartmentForDPT2.SelectByIndex(i, Timeout);
                Page.PumpsValvesPage.txtPumpCalibration.TypeText("100");
                Page.PumpsValvesPage.SavePump.Click();
                Thread.Sleep(2000);
                string message = Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText;

                if (null != message)
                {
                    if (!message.ToLower().Contains("successfully"))
                    {
                        Assert.Fail("Message incorrect after controller addition. Expected Message : Pump details updated successfully., Actual Message: {0}", message);
                    }
                }
            }
        }

        [TestCategory(TestType.plc, "TC06_AddFormulaAndProduct")]
        [Test(Description = "Create formulas for Conventional")]
        public void TC06_AddFormulaAndProduct()
        {
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional")[0].GetButtonControls()[4].DeskTopMouseClick();
            Thread.Sleep(2000);
            Random rand = new Random();
            for (int i = 1; i <= 4; i++)
            {
                Page.WasherGroupFormulasPage.FormulaTab.Click();
                Thread.Sleep(2000);
                Page.WasherGroupFormulasPage.AddFormula.Click();
                Thread.Sleep(2000);
                AddingFormula(i.ToString(), "101", "0", "0", i);
                Thread.Sleep(3000);
                Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.Focus();
                if (null != Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg)
                {
                    string message = Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.BaseElement.InnerText;
                    if (!message.ToLower().Contains(@"successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
                AddProductsConv(i);
            }
            //Page.FormulasTabPage.FormulasTableGridAtWasher.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();                        
        }

        [TestCategory(TestType.plc, "TC07_CreateCompartments")]
        [Test(Description = "Create Compartments to Tunnel washers")]
        public void TC07_CreateCompartments()
        {
            for (int i = 0; i < 2; i++)
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Tunnel")[i].Focus();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Tunnel")[i].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Thread.Sleep(2000);
                Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Thread.Sleep(2000);
                Page.WashersPage.CompartmentsTab.Click();
                Thread.Sleep(2000);
                for (int j = 1; j < 5; j++)
                {
                    Page.WashersPage.NextCompartment.Click();
                    if (j == 1)
                    {
                        Page.WashersPage.PreviousCompartment.Click();
                    }
                    Page.WashersPage.WaterInlet.SelectByIndex(1, Timeout);
                    Page.WashersPage.WashZone.SelectByIndex(1, Timeout);
                    Page.WashersPage.WaterFlow.SelectByIndex(2, Timeout);
                    Page.WashersPage.SaveCompartment.Click();
                    if (null != Page.WashersPage.ErrorMessageTunnel)
                    {
                        string message = Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText;
                        if (!message.ToLower().Contains(@"successfully"))
                        {
                            Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                        }
                    }
                    else
                    {
                        Assert.Fail("Error message is not displayed");
                    }
                }
            }
        }

        [TestCategory(TestType.plc, "TC08_CreateFormulasForTunnels")]
        [Test(Description = "Create formulas for tunnels")]
        public void TC08_CreateFormulasForTunnels()
        {
            for (int i = 1; i < 3; i++)
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Tunnel")[i - 1].Focus();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Tunnel")[i - 1].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Thread.Sleep(2000);
                Page.WasherGroupFormulasPage.FormulaTab.Click();
                Thread.Sleep(2000);
                Page.WasherGroupFormulasPage.AddFormula.Click();
                Thread.Sleep(2000);
                AddFormulaTunnel(i.ToString(), "101", "0", "0", i);
                Thread.Sleep(3000);
            }
        }

        private void AddAndVerifymyControl(string controllerNumber, bool enterAMSNetId)
        {
            Page.ControllerSetupPage.AddControllerButton.Click();
            Runner.DoStep("Select dispenser model and type", () =>
            {
                Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("myControl", Timeout);
            });

            Runner.DoStep("Enter dispenser details", () =>
            {
                KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                Page.ControllerGeneralSetupTabPage.myControlName.TypeText("myControl Dispenser");
                Page.ControllerGeneralSetupTabPage.AMSNetIDmyControlBEC.TypeText("10.225.134.22.1.1");
                Page.ControllerGeneralSetupTabPage.myControlActive.Click();
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.TypeText(controllerNumber);
                Page.ControllerGeneralSetupTabPage.myControlSerialNumber.TypeText("1");
            });
            Runner.DoStep("Save dispenser", () =>
            {
                if (!Page.ControllerSetupPage.IsSaveButtonEnabled())
                {
                    Page.ControllerSetupPage.Save.DeskTopMouseClick();
                }
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
            });
            Thread.Sleep(3000);
            ValidateControllerAddition(controllerNumber, "myControlBeckhoff");
        }

        private void ValidateControllerAddition(string controllerNumber, string controllerType)
        {
            Runner.DoStep("Verify addition of dispenser", () =>
            {
                string message = Page.ControllerGeneralSetupTabPage.SuccessMessage.BaseElement.InnerText;

                if (null != message)
                {
                    if (!message.ToLower().Contains("successfully"))
                    {
                        Assert.Fail("Message incorrect after controller addition. Expected Message : Controller Saved Successfully, Actual Message: {0}", message);
                    }
                }
            });
        }

        private void AddConventionalWashers()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            Runner.DoStep("Click on 'SAVE' button of a AB Washer group", () =>
            {
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional")[0].GetButtonControls()[4].DeskTopMouseClick();
            });
            for (int i = 0; i < 16; i++)
            {
                Page.WashersPage.AddWasher.DeskTopMouseClick();
                Thread.Sleep(2000);
                Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
                if (i == 0)
                {
                    Page.WashersPage.DdlController.SelectByIndex(1, Timeout);
                }
                Page.WashersPage.TxtName.TypeText("myControl Conv washer " + (i + 1));
                Page.WashersPage.LFSWasher.SelectByIndex(i, Timeout);
                Page.WashersPage.Size.SelectByIndex(1, Timeout);
                Random random = new Random();
                Page.WashersPage.PlantWasherNumber.TypeText(random.Next(1, 29999).ToString());
                Page.WashersPage.WasherCapacity.TypeText(random.Next(1, 999).ToString());
                Page.WashersPage.MinimumMachineLoad.TypeText("1");
                Runner.DoStep("Enter washer details and click Save", () =>
                {
                    Page.WashersPage.SaveCoventionalWasher.Click();
                });
                Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
                {
                    if (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                    {
                        do
                        {
                            Page.WashersPage.PlantWasherNumber.TypeText(random.Next(1, 29999).ToString());
                            Page.WashersPage.SaveCoventionalWasher.Click();
                        }
                        while (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                    }
                });
                if (!Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Washer not created");
                }
                Page.WasherGroupFormulasPage.WashergroupTab.Click();
                Thread.Sleep(2000);
            }
        }

        private void AddTunnelWashers()
        {
            for (int i = 0; i < 2; i++)
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Tunnel")[i].Focus();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Tunnel")[i].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                // Page.WasherGroupPage.WasherGroupTableGrid.GetRow("Tunnel Group -2").GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Random random = new Random();
                Page.WasherGroupFormulasPage.WasherGroupSaveSave.Click();
                Page.WashersPage.DdlModel.Focus();
                Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
                //Page.WashersPage.DdlController.SelectByPartialText("TrialABUltraxTD1", true);
                Page.WashersPage.TxtName.TypeText("myControl tunnel " + (i + 1));
                Page.WashersPage.LFSWasher.SelectByIndex(i, Timeout);
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("12");
                Page.WashersPage.NumberOfCompartments.TypeText("13");
                Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlPress.Focus();
                Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 99).ToString());
                Runner.DoStep("Enter washer details and click Save", () =>
                {
                    Page.WashersPage.BtnSaveTunnel.Click();
                });
                //Thread.Sleep(8000);
                Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
                {
                    if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                    {
                        do
                        {
                            Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                            Page.WashersPage.BtnSaveTunnel.Click();
                            //Thread.Sleep(8000);
                        } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                    }
                });
            }
        }

        private void AddProductsConv(int productNumber)
        {
            Random random = new Random();
            Page.WasherGroupPage.BtnAddWashStep.Click();
            Page.WasherGroupPage.Operations.SelectByIndex(1, Timeout);
            Thread.Sleep(2000);
            Page.FormulasTabPage.ViewInjectionsForPLC.Click();
            Page.FormulasTabPage.SelectProduct.SelectByIndex(productNumber, Timeout);
            Page.FormulasTabPage.AddProduct.Click();
            Page.FormulasTabPage.QuantityForPLC.SetText(random.Next(4,10).ToString());
            Thread.Sleep(1000);
            Page.FormulasTabPage.SaveProducts.Click();
            if (null != Page.FormulasTabPage.ErrorMessage)
            {
                string message = Page.FormulasTabPage.ErrorMessage.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
        }

        public void AddingFormula(string number, string nominalLoad, string loadsPerMonth, string extraTime, int formulaIndex)
        {
            //Page.WasherGroupFormulasPage.Number.TypeText(number);
            Page.WasherGroupFormulasPage.FormulaName.Focus();
            Page.WasherGroupFormulasPage.FormulaName.SelectByIndex(formulaIndex, Timeout);
            //Page.WasherGroupFormulasPage.NominalLoadForConventional.TypeText(nominalLoad);
            //Page.WasherGroupFormulasPage.ExtraTime.TypeText(extraTime);
            Page.WasherGroupFormulasPage.Save.Focus();
            Page.WasherGroupFormulasPage.Save.Click();
        }

        private void AddFormulaTunnel(string number, string nominalLoad, string loadsPerMonth, string extraTime, int formulaIndex)
        {
            //Page.WasherGroupFormulasPage.Number.TypeText(number);
            Page.WasherGroupFormulasPage.FormulaName.Focus();
            Page.WasherGroupFormulasPage.FormulaName.SelectByIndex(formulaIndex, Timeout);
            Page.WasherGroupFormulasPage.Save.Focus();
            Page.WasherGroupFormulasPage.Save.Click();
        }

        /// <summary>
        /// Selects the name of the chemical.
        /// </summary>
        /// <param name="txtChemName">Name of the text chem.</param>
        public void SelectChemicalName(string txtChemName)
        {
            MouseKeyBoardSimulator objKeyPress = new MouseKeyBoardSimulator();
            objKeyPress.KeyPress(System.Windows.Forms.Keys.Tab);
            Page.ChemicalsTabPage.TxtNameorSkuNumberAdd.Value = "";
            Page.ChemicalsTabPage.TxtNameorSkuNumberAdd.Focus();
            Page.ChemicalsTabPage.TxtNameorSkuNumberAdd.DeskTopMouseClick();
            objKeyPress.SetNumeric(txtChemName);
            Thread.Sleep(2000);
            objKeyPress.KeyDown(System.Windows.Forms.Keys.Select);
            objKeyPress.KeyPress(System.Windows.Forms.Keys.Tab);
        }

        public void AddWasherGroupItems(string washerGroupNumber, string washerGroupName, string washerGroupType)
        {

            Page.WasherGroupPage.TxtGroupNumber.Focus();

            Page.WasherGroupPage.TxtGroupNumber.TypeText(washerGroupNumber);
            Page.WasherGroupPage.TxtGroupName.Focus();
            Page.WasherGroupPage.TxtGroupName.SetText(washerGroupName);
            Page.WasherGroupPage.DdlGroupType.SelectByIndex(1, Timeout);
            Page.WasherGroupPage.DdlGroupType.SelectByIndex(0, Timeout);
            Page.WasherGroupPage.BtnSaveAdd.Focus();
            Page.WasherGroupPage.BtnSaveAdd.Click();
            if (!Page.WasherGroupFormulasPage.divMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Washer group not created");
            }
        }
    }
}
