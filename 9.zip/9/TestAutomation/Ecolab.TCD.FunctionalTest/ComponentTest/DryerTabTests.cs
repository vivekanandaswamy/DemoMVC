﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using NUnit.Framework;
using ArtOfTest.WebAii.Win32.Dialogs;
using System.Threading;
using System.Data;


namespace Ecolab.FunctionalTest.ComponentTest
{
    public class DryerTabTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);

            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.CleanSideTab.Click();            
            Page.DryerTabPage.DryerTab.Click();            
        }


        /// <summary>
        /// Tests the fixture tear down.
        /// </summary>
        //[TestFixtureTearDown]
        //public void TestFixtureTearDown()
        //{
        //    Console.WriteLine("Test Fixture Teardown overriden");
        //    //base.TestFixtureTearDown();
        //}

        /// <summary>
        /// Test case 27564: Verify whether the "Dryers" menu is displaying in the menu bar
        /// </summary>
        [TestCategory(TestType.functional, "TC01_VerifyDryerMenu")]
        [TestCategory(TestType.regression, "TC01_VerifyDryerMenu")]
		[Test, Description("Test case 27564: Verify whether the 'Dryers' menu is displaying in the menu bar ;" +
		"Test case 27563: Verify the application functionality when user login into the application;")]
        public void TC01_VerifyDryerMenu()
        {
			if (null != Page.DryerTabPage.DryerTab.BaseElement.InnerText)
			{
				if (!Page.DryerTabPage.DryerTab.BaseElement.InnerText
					.Equals(@"Dryer"))
				{
					Assert.Fail("Incorrect menu name displayed");
				}
			}
			else
			{
				Assert.Fail("Dryer menu is not displayed");
			}
            Page.DryerTabPage.DryerTab.Click();
        }

        /// <summary>
        /// Test case 27579: RG: Verify the "Add Dryer Group" button functionality
        /// </summary>
        [TestCategory(TestType.functional, "TC02_VerifyAddDryerGroup")]
        [TestCategory(TestType.regression, "TC02_VerifyAddDryerGroup")]
		[Test, Description("Test case 27580: RG: Verify the 'Save' button functionality on 'Add Dryer Group' pop-up ;" +
		"Test case 27579: RG: Verify the 'Add Dryer Group' button functionality ;" + 
		"Test case 27580: RG: Verify the 'Save' button functionality on 'Add Dryer Group' pop-up ;")]
		public void TC02_VerifyAddDryerGroup()
        {
			Random rand = new Random();
			Int32 ranDryerGroupNumber = rand.Next(10, 999);
			string dryerGroupName = "AutoTestDryerGroup" + ranDryerGroupNumber.ToString();
            Runner.DoStep("Delete all existing Dryer groups", () =>
            {
                Page.DryerTabPage.DeleteAllDryerGroup();
            });			
			Page.DryerTabPage.CancelingDryerGroup(dryerGroupName);
            Runner.DoStep("Add a dryer group", () =>
            {
                Page.DryerTabPage.AddingDryerGroup(dryerGroupName);
            });
            Runner.DoStep("Verify addition of dryer group", () =>
            {
                MessageVerification("successfully");
            });            
			Thread.Sleep(2000);
			DBVerificationForDryerGroupAdded();
			//DBVerificationOfDryerGroupOnHistoryTableAdded();

			Page.DryerTabPage.GetAddDryerGroupActionItems(dryerGroupName)[0].Click();
			Page.DryerTabPage.CancelingEditDryerGroup("EditCancel" + dryerGroupName);
			Thread.Sleep(2000);
			Page.DryerTabPage.GetAddDryerGroupActionItems(dryerGroupName)[0].Click();
            Runner.DoStep("Edit dryer group", () =>
            {
                Page.DryerTabPage.EditDryerGroup("EditSave" + dryerGroupName);
            });			
			Thread.Sleep(2000);
			DBVerificationForDryerGroupAdded();
			//DBVerificationOfDryerGroupOnHistoryTableAdded();

            Runner.DoStep("Try adding a dryer group with the name of an already existing one", () =>
            {
                Page.DryerTabPage.AddingDryerGroup("EditSave" + dryerGroupName);
                Thread.Sleep(3000);
            });			
			//string message = Page.DryerTabPage.DryerErrorMessage.BaseElement.InnerText;
            Runner.DoStep("Check for Error message", () =>
            {
                if (null != Page.DryerTabPage.DryerErrorMessage)
                {
                    string message = Page.DryerTabPage.DryerErrorMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Name already exists"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                    else
                    {
                        Page.DryerTabPage.CancelDryerGroup.Click();
                    }
                }
            });            
			Thread.Sleep(3000);
            Runner.DoStep("Delete the added dryer group", () =>
            {
                DeleteDryerGroup("EditSave" + dryerGroupName);
            });
            Runner.DoStep("Verify the deletion", () =>
            {
                MessageVerification("successfully");
            });			            
			//DBVerificationForDryerGroupAdded();
        }

        /// <summary>
        /// Test case 27649: RG: Verify the "Save" button functionality on "Add New Dryer" pop-up
        /// </summary>
        [TestCategory(TestType.functional, "TC03_VerifyDryerFunctionality")]
		[TestCategory(TestType.regression, "TC03_VerifyDryerFunctionality")]
        [Test, Description("Test case 27649: RG: Verify the 'Save' button functionality on 'Add New Dryer' pop-up ;")]
		public void TC03_VerifyDryerFunctionality()
        {
			Random rand = new Random();
			Int32 ranDryerGroupNumber = rand.Next(10, 99);
			string dryerGroupName = "AutoTestDryerGroup" + ranDryerGroupNumber.ToString();
            Runner.DoStep("Add a dryer group", () =>
            {
                Page.DryerTabPage.AddingDryerGroup(dryerGroupName);
            });			
			Thread.Sleep(2000);
			Page.DryerTabPage.GetAddDryerButton(dryerGroupName).Click();
			string dryerName = "Dryer" + ranDryerGroupNumber.ToString();
			//Cancelling the Dryer Name
			Page.DryerTabPage.CancellingDryer(ranDryerGroupNumber.ToString(), "Cancel"+ dryerName, "1");
			Thread.Sleep(2000);
			Page.DryerTabPage.GetAddDryerButton(dryerGroupName).Click();
            Runner.DoStep("Add a dryer to the dryer group created", () =>
            {
                Page.DryerTabPage.AddingDryer(ranDryerGroupNumber.ToString(), dryerName, "DryerType 01", "1");         
            });
            Runner.DoStep("Verify dryer is added successfully", () =>
            {
                if (null != Page.DryerTabPage.AddDryerMessage)
                {
                    string message = Page.DryerTabPage.AddDryerMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Dryer added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
			Page.DryerTabPage.GetAddDryerButton(dryerGroupName).Click();
            //Duplicate Dryer verification
            Page.DryerTabPage.AddingDryer(ranDryerGroupNumber.ToString(), dryerName, "DryerType 01", "1");      
            if (null != Page.DryerTabPage.DryerErrorMessage)
            {
				string message = Page.DryerTabPage.DryerErrorMessage.BaseElement.InnerText;
				if (!message.Contains(@"Number & name already exists."))
                {
                    Assert.Fail("Incorrect error message is displayed , Actual:{0}",message);
                }
                else
                {
                    Page.DryerTabPage.CancelDryer.TypeEnterKey();
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            //TO-DO-Audit Table Validation 
			DBVerifyforDryer(dryerName);
			//TO-DO-Audit Table Validation 
			Page.DryerTabPage.GetDryerButtonControls(dryerGroupName, dryerName)[4].Click();
			Page.DryerTabPage.CancelingEditDryer("102", "Cancel" + dryerName, "4");
			Page.DryerTabPage.GetDryerButtonControls(dryerGroupName, dryerName)[4].Click();
            Runner.DoStep("Edit the dryer", () =>
            {
                Page.DryerTabPage.EditDryer("103", "Edit" + dryerName, "2");
            });			
			DBVerifyforDryer("Edit" + dryerName);
            Runner.DoStep("Delete the dryer", () =>
            {
                DeleteDryer("Edit" + dryerName, dryerGroupName);
            });            
        }

        /// <summary>
        /// Test case 28457: RG: Verify Localization on Dryers Page
        /// </summary>
		[TestCategory(TestType.functional, "TC04_LocalizationDryers")]
		[TestCategory(TestType.regression, "TC04_LocalizationDryers")]
        [Test, Description("Test case 28457: RG: Verify Localization on Dryers Page ;")]
        public void TC04_LocalizationDryers()
        {
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("Deutsch", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.PlantSetupPage.CleanSideTab.Click();
            Page.DryerTabPage.DryerTab.Click();
            if (Page.DryerTabPage.DryerTab.BaseElement.InnerText != "Droger")
            {
                Assert.Fail(string.Format("Incorrect Label is displayed in Dryer Tab - {0} when localization changed to Deutsch, Expected - Droger", Page.DryerTabPage.DryerTab.BaseElement.InnerText));
            }
        }

		[TestCategory(TestType.functional, "TC05_PostLocalizationDryers")]
		[TestCategory(TestType.regression, "TC05_PostLocalizationDryers")]
        [Test]
        public void TC05_PostLocalizationDryers()
        {
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("English US", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.PlantSetupPage.CleanSideTab.Click();
            Page.DryerTabPage.DryerTab.Click();
            if (Page.DryerTabPage.DryerTab.BaseElement.InnerText != "Dryer")
            {
                Assert.Fail(string.Format("Incorrect Label is displayed in Dryer Tab - {0} when localization changed to English, Expected - Dryer", Page.DryerTabPage.DryerTab.BaseElement.InnerText));
            }
        }

		private void EnterDryerGroupName(string groupname)
		{
			Page.DryerTabPage.AddDryerGroup.Click();
			if (!Page.DryerTabPage.DryerGroupName.IsEnabled)
			{
				Assert.Fail("Dryer GroupName textbox not enabled");
			}
			else
			{
				Page.DryerTabPage.DryerGroupName.Focus();
				Page.DryerTabPage.DryerGroupName.ExtendedMouseClick();
				Page.DryerTabPage.DryerGroupName.SetText(groupname);
			}
		}

		private void SaveButtonClickOnDryerGroup()
		{
			Page.DryerTabPage.SaveDryerGroup.Click();
		}

		private void CancelButtonClickOnDryerGroup()
		{
			Page.DryerTabPage.CancelDryerGroup.Click();
		}

		private void SaveButtonEnabledOnDryerGroup()
		{
			if (null != Page.DryerTabPage.SaveDryerGroup)
            {
                if (!Page.DryerTabPage.SaveDryerGroup.IsEnabled)
                {
					Thread.Sleep(2000);
                    Assert.Fail("Save DryerGroup button not enabled");
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
		}

		private void CancelDryerGroup()
		{
			Page.DryerTabPage.CancelDryerGroup.DeskTopMouseClick();
			//if (null != Page.DryerTabPage.CancelDryerGroup)
			//{
			//	if (!Page.DryerTabPage.CancelDryerGroup.IsEnabled)
			//	{
			//		Assert.Fail("Cancel DryerGroup button not enabled");
			//	}
			//	else
			//	{
			//		Page.DryerTabPage.CancelDryerGroup.Click();
			//	}
			//}
			//else
			//{
			//	Assert.Fail("Error message is not displayed");
			//}
		}

		private void DBVerificationOfDryerGroupOnHistoryTableAdded()
		{
			//string strGroupType = "Select [GroupTypeId] from [TCD].[GroupType] where [GroupDescription] = '" + "Dryer Group" + "'" + "And [Is_Deleted] = 0";
			string strGroupType = "Select [GroupTypeId] from [TCD].[MachineGroup] where [GroupTypeId] = 3 And [Is_Deleted] = 0";
			string outType = DBValidation.GetData(strGroupType).Tables[0].Rows[0]["GroupTypeId"].ToString();
			string strAduit = "Select * from [TCD].[MachineGroupHistory] where [GroupDescription] = '" + "Dryer Group" + "'" + "And [Is_Deleted] = 0 And [OperationId] = 1 And [GroupTypeId] = " + outType;
			//DataRow[] AuditRows = DBValidation.GetData(strAduit).Tables[0].Select("GroupDescription = " + "'Dryer Group'");
			DataRow[] AuditRows = DBValidation.GetData(strAduit).Tables[0].Select("GroupTypeId = 3");
			int nAuditcount = AuditRows.Length;
			if (nAuditcount >= 1)
			{
				Assert.True(true, "Dryer Group" + " DryerGroup added successfully in Audit Tables in DB");
			}
			else
			{
				Assert.Fail("Dryer Group" + " record not saved/ created Audit Tables in DB");
			}
		}

		private void DBVerificationForDryerGroupAdded()
		{
			//string strCommand = "Select * from [TCD].[GroupType] where [GroupDescription] = '" + "Dryer Group" + "'" + "And [Is_Deleted] = 0";
			string strCommand = "Select * from [TCD].[MachineGroup] where [GroupTypeId] = 3 And [Is_Deleted] = 0";
			DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("GroupTypeId = 3");
			int count = foundRows.Length;
			if (count >= 1)
			{
				Assert.True(true, "Dryer Group" + " DryerGroup added successfully in DB");
			}
			else
			{
				Assert.Fail("Dryer Group" + " record not saved/ created in DB");
			}
		}

		private void DBVerificationForDryerGroupCancel()
		{
			//string strCommand = "Select * from [TCD].[GroupType] where [GroupDescription] = '" + "Dryer Group" + "'" + "And [Is_Deleted] = 0";
			string strCommand = "Select * from [TCD].[MachineGroup] where [GroupTypeId] = 3 And [Is_Deleted] = 0";
			DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("GroupTypeId = 3");
			int count = foundRows.Length;
			if (count < 1)
			{
				Assert.True(true, "CancelEditDryerGroup : " + " DryerGroup not added in DB");
			}
			else
			{
				Assert.Fail("CancelEditDryerGroup : " + " record saved / created in DB on clicking on Cancel button in popup");
			}
		}

		private void DBVerificationOfDryerGroupOnHistoryTableCancel()
		{
			//string strGroupType = "Select [GroupTypeId] from [TCD].[GroupType] where [GroupDescription] = '" + "Dryer Group" + "'" + "And [Is_Deleted] = 0";
			string strGroupType = "Select [GroupTypeId] from [TCD].[MachineGroup] where [GroupTypeId] = 3 And [Is_Deleted] = 0";
			string outType = DBValidation.GetData(strGroupType).Tables[0].Rows[0]["GroupTypeId"].ToString();
			string strAduit = "Select * from [TCD].[MachineGroupHistory] where [GroupDescription] = '" + "Dryer Group" + "'" + "And [Is_Deleted] = 0 And [OperationId] = 1 And [GroupTypeId] = " + outType;
			//DataRow[] AuditRows = DBValidation.GetData(strAduit).Tables[0].Select("GroupDescription = " + "'Dryer Group'");
			DataRow[] AuditRows = DBValidation.GetData(strAduit).Tables[0].Select("GroupTypeId = 3");
			int nAuditcount = AuditRows.Length;
			if (nAuditcount < 1)
			{
				Assert.True(true, "CancelEditDryerGroup : " + " DryerGroup not added in Audit Tables in DB");
			}
			else
			{
				Assert.Fail("CancelEditDryerGroup : " + " record created in Audit Tables in DB");
			}
		}

		private void MessageVerification(string message)
		{
			if (null != Page.DryerTabPage.AddDryerMessage)
			{
				Thread.Sleep(2000);
                string actualmessage = Page.DryerTabPage.AddDryerMessage.BaseElement.InnerText.ToLower();
                if (!actualmessage.Contains(@message))
				{
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", actualmessage);
				}
			}
			else
			{
				Assert.Fail("Error message is not displayed");
			}
		}

		private void EditDryerGroup()
		{
			Page.DryerTabPage.GetAddDryerGroupActionItems("Dryer Group")[0].Click();
			Page.DryerTabPage.EditDryerGroup("EditDryerGroup01");
			Thread.Sleep(3000);
			MessageVerification("Record updated successfully");
		}

		private void DeleteDryerGroup(string dryerGroupName)
		{
			Page.DryerTabPage.GetAddDryerGroupActionItems(dryerGroupName)[1].Click();
			DialogHandler.NoButton.Click();
			if (Page.DryerTabPage.IsContainsDryerGroup(dryerGroupName) == false)
			{
				Assert.Fail("DryerGroup deleted on clicking on Cancel button in delete confirmation popup");
			}
			Thread.Sleep(2000);
			Page.DryerTabPage.GetAddDryerGroupActionItems(dryerGroupName)[1].Click();
			Thread.Sleep(2000);
			DialogHandler.YesButton.Click();
			Thread.Sleep(2000);
			if (Page.DryerTabPage.IsContainsDryerGroup(dryerGroupName) == true)
			{
				Assert.Fail("DryerGroup not deleted on clicking on Ok button in delete confirmation popup");
			}
		}

		private void DBVerifyforDryer(string dryerName)
		{
			string strCommand = "Select * from [TCD].[Dryers] where [Description] = '" + dryerName + "'" + "And [Is_Deleted] = 0";
			DataRow[] FoundRows = DBValidation.GetData(strCommand).Tables[0].Select("Description = '" + dryerName +"'");
			int ncount = FoundRows.Length;
			if (ncount >= 1)
			{
				Assert.True(true, dryerName + ": Dryer is inserted / modified in the DB");
			}
			else
			{
				Assert.Fail(dryerName + ": Dryer is not inserted / modified Audit Tables in DB");
			}
		}

		private void DeleteDryer(string dryerName, string dryerGroupName)
		{
			Page.DryerTabPage.GetDryerButtonControls("AutoTestDryerGroup", dryerName)[3].Click();
			DialogHandler.NoButton.Click();
			if (Page.DryerTabPage.IsContainsDryer("AutoTestDryerGroup", dryerName) != true)
			{
				Assert.Fail("Dryer deleted on clicking on Cancel button in delete confirmation popup");
			}
			Thread.Sleep(3000);
			Page.DryerTabPage.GetDryerButtonControls("AutoTestDryerGroup", dryerName)[3].Click();
			DialogHandler.YesButton.Click();
			Thread.Sleep(3000);
			if (null != Page.DryerTabPage.AddDryerMessage)
			{
                string message = Page.DryerTabPage.AddDryerMessage.BaseElement.InnerText;
                if (!message.Contains(@"Dryer deleted successfully"))
				{
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
				}
			}
			else
			{
				Assert.Fail("Error message is not displayed");
			}
			Thread.Sleep(3000);
			if (Page.DryerTabPage.IsContainsDryer("AutoTestDryerGroup", dryerName))
			{
				Assert.Fail("Dryer not deleted on clicking on Ok button in delete confirmation popup");
			}
			Thread.Sleep(3000);
			Page.DryerTabPage.GetAddDryerGroupActionItems("AutoTestDryerGroup")[1].Click();
			DialogHandler.YesButton.Click();
			Thread.Sleep(3000);
            if (Page.DryerTabPage.IsContainsDryerGroup(dryerGroupName))
			{
				Assert.Fail("DryerGroup not deleted on clicking on OK button in delete confirmation popup");
			}
			string strCommand = "Select * from [TCD].[Dryers] where [Description] = '" + dryerName + "'" + "And [Is_Deleted] = 1";
			DataRow[] FoundRows = DBValidation.GetData(strCommand).Tables[0].Select("Description = '" + dryerName +"'");
			int ncount = FoundRows.Length;
			if (ncount >= 1)
			{
				Assert.True(true, dryerName + ": Dryer deleted successfully in DB");
			}
			else
			{
				Assert.Fail(dryerName + ": record not deleted in DB");
			}
		}
    }
}



