﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using Ecolab.CommonUtilityPlugin;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class WashersTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }
        private void CloseBrowser()
        {
            Telerik.Shutdown();
            Telerik.CleanUp();
        }
        
        string[] UpdateValues = {"TunnelOne","5","8"};
        [TestCategory(TestType.functional, "TC01_VerifyUpdateWasherFunctionality")]
        [TestCategory(TestType.regression, "TC01_VerifyUpdateWasherFunctionality")]
        [Test, Description("Test case 38803: RG: Verifyt the Update functionality ;")]
        public void TC01_VerifyUpdateWasherFunctionality()
        {
            try
            {
                Ecolab.AppStateHandler.StateTransformation.ControllerTransform.WasherTest();
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Exception : ", ex);
            }
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
            Thread.Sleep(2000);
            //for (int i = 0; i <= Page.WashersPage.WashersListGridTable.Rows.Count - 1; i++)
            //{
            //    if (Page.WashersPage.WashersListGridTable.Rows[i].GetColumnValues()[3].ToString() == "WasherTestTunnel")
            //    {
            //        //Page.WashersPage.WashersListGridTable.SelectedRows("WasherTestTunnel")[0].GetButtonControls()[1].DeskTopMouseClick();
            //        Page.WashersPage.WashersListGridTable.Rows[i].ScrollToVisible();
            //        Thread.Sleep(1000);
            //        Page.WashersPage.WashersListGridTable.Rows[i].GetButtonControls()[1].Click();
            //        bool value =  Page.WashersPage.UpdateWasherDetails(UpdateValues);
            //        if(value == false)
            //        {
            //            Assert.Fail("Failed to update the washers data Expected- Data for Models,Controllers and Washers");
            //        }
            //        break;
            //    }
            //}
            Page.WashersPage.WashersListGridTable.SelectedRows("WasherTestTunnel")[0].ScrollToVisible();
            Page.WashersPage.WashersListGridTable.SelectedRows("WasherTestTunnel")[0].GetButtonControls()[1].Click();
            bool value = Page.WashersPage.UpdateWasherDetails(UpdateValues);
            if (value == false)
            {
                Assert.Fail("Failed to update the washers data Expected- Data for Models,Controllers and Washers");
            }
            
            Thread.Sleep(4000);
            if (Page.WashersPage.ResultMessageTunnel.IsVisible())
            {
                if (!Page.WashersPage.ResultMessageTunnel.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Washer updation not successful");
                }
            }
            else
            {
                if (null != Page.WashersPage.ResultMessageTunnel)
                {
                    string message = Page.WashersPage.ResultMessageTunnel.BaseElement.InnerText;
                    if (!message.Contains(@"successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Tunnel Details Updated successfully."
                                        + " but Actual:" + message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            }            
            Thread.Sleep(2000);
            string strCommand = "Select MachineName from [TCD].[MachineSetup] where MachineName = '" + UpdateValues[0] + "'";
            DataSet ds = DBValidation.GetData(strCommand);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Assert.True(true, "Expected MachineName -" + UpdateValues[0] + " which doesn't exist in DB");
            }
            else
            {
                Assert.Fail("Expected MachineName - " + UpdateValues[0] + " which doesn't exist in DB");
            }
        }

        [TestCategory(TestType.functional, "TC02_VerifyPromptPopUpOnNavigation")]
        [TestCategory(TestType.regression, "TC02_VerifyPromptPopUpOnNavigation")]
        [Test, Description("Test case 38805: RG:Verify the prompt is displayed when user navigates to other tab with out saving record ;")]
        public void TC02_VerifyPromptPopUpOnNavigation()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
            Thread.Sleep(2000);
            if (Page.WashersPage.WashersListGridTable.Rows.Count > 0)
            {
                Page.WashersPage.WashersListGridTable.Rows[1].GetButtonControls()[1].DeskTopMouseClick();
                Thread.Sleep(2000);
                Page.WashersPage.TxtName.Focus();
                Page.WashersPage.TxtName.Text = string.Empty;
                Page.WashersPage.TxtName.SetText("TunnelTesting");
                KeyBoardSimulator.KeyPress(Keys.Tab);
                Thread.Sleep(1000);
                Page.WashersPage.BtnBacktoWashersLink.Focus();
                Page.WashersPage.BtnBacktoWashersLink.DeskTopMouseClick();
                Thread.Sleep(2000);
                if (Page.WashersPage.BtnNoPopUp.IsVisible() == true)
                {
                    Page.WashersPage.BtnNoPopUp.DeskTopMouseClick();
                    Assert.True(true, "Expected - Prompt PopUp message on navigation with out saving the washers data");
                }
                else
                {
                    Assert.Fail("Expected - Prompt PopUp message not displayed on navigation with out saving the washers data");
                }
            }
            else
            {
                Assert.Fail("Data not found in the Washers List Page.");
            }
        }

        [TestCategory(TestType.functional, "TC03_VerifyDeleteWasherFunctionality")]
        [TestCategory(TestType.regression, "TC03_VerifyDeleteWasherFunctionality")]
        [Test, Description("Test case 38804: RG:Verify the Delete functionality;Test case 40642: RG: Verify the Delete Washer functionality ;")]
        public void TC03_VerifyDeleteWasherFunctionality()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
            Thread.Sleep(2000);
            if (Page.WashersPage.WashersListGridTable.Rows.Count > 0)
            {
                ReadOnlyCollection<string> delWasher = Page.WashersPage.WashersListGridTable.Rows[1].GetColumnValues();
                Thread.Sleep(1000);
                Page.WashersPage.DeleteWasherFromGridList(delWasher[2]);
                Thread.Sleep(1000);
                //Page.WashersPage.BtnOkDelete.DeskTopMouseClick();
                DialogHandler.YesButton.DeskTopMouseClick();
                Thread.Sleep(2000);
                if (null != Page.WashersPage.SuccessMessage)
                {
                    string message = Page.WashersPage.SuccessMessage.BaseElement.InnerText;
                    if (!message.Contains(@"successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Washer deleted successfully."
                                        + " but Actual:" + message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
                //Thread.Sleep(1000);
                //ReadOnlyCollection<string> delWasherCancel = Page.WashersPage.WashersListGridTable.Rows[1].GetColumnValues();
                //Page.WashersPage.DeleteWasherFromGridList(delWasherCancel[1]);
                //Page.WashersPage.BtnCancelDelete.DeskTopMouseClick();

                //EcolabDataGridItems deletedRow = Page.WashersPage.WashersListGridTable.GetRow(delWasher[2]);
                //Assert.True(deletedRow == null, "Washer details not found in grid");
                //string strCommand = "Select MachineName from [TCD].[MachineSetup] where isdeleted=0";
                //DataSet ds = DBValidation.GetData(strCommand);
                //Thread.Sleep(1000);
                //if (ds.Tables[0].Rows.Count >= 0)
                //{
                //    Assert.True(true, delWasher[2] + "Washer details deleted successfully in DB");
                //}
            }
            else
            {
                Assert.Fail("Washer details not found in gridview.Expected- Washer Data");
            }
        }

        [TestCategory(TestType.bvt, "TC04_VerifyAccessToWasherListPageUserRole789")]
        [TestCategory(TestType.regression, "TC04_VerifyAccessToWasherListPageUserRole789")]
        [Test, Description("Test case 38887: RG: Verify the Access to Washer List page for User Role 7/8/9 ;")]
        public void TC04_VerifyAccessToWasherListPageUserRole789()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.EngineerUser[0], Users.EngineerUser[1]);
            userAccess.Add(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {
                Page.LoginPage.VerifyLogin(pair.Key, pair.Value);
                Thread.Sleep(2000);
                List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;
                Thread.Sleep(2000);
                if (Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Washers"))
                {
                    Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
                    Thread.Sleep(2000);
                    //for (int i = 0; i <= Page.WashersPage.WashersListGridTable.Rows.Count - 1; i++)
                    //{
                    //    if (Page.WashersPage.WashersListGridTable.Rows[i].GetColumnValues()[3].ToString() == "Tunnel")
                    //    {
                    //        Page.WashersPage.WashersListGridTable.SelectedRows("Tunnel")[0].GetButtonControls()[1].DeskTopMouseClick();                            
                    //        Page.WashersPage.UpdateWasherDetails(UpdateValues);
                    //        break;
                    //    }
                    //}
                    Page.WashersPage.WashersListGridTable.SelectedRows("TunnelOne")[0].ScrollToVisible();
                    Page.WashersPage.WashersListGridTable.SelectedRows("TunnelOne")[0].GetButtonControls()[1].Click();
                    Page.WashersPage.UpdateWasherDetails(UpdateValues);
                }
                else
                {
                    Assert.Fail("Logged in with user " + pair.Key + " Actual- Washers tab not found in setup menu list.Expected- Washers tab should display.");
                }
                Page.PlantSetupPage.TopMainMenu.LogOut();
            }
        }

        [TestCategory(TestType.bvt, "TC05_VerifyAccessToWasherListPageUserRole123456")]
        [TestCategory(TestType.regression, "TC05_VerifyAccessToWasherListPageUserRole123456")]
        [Test, Description("Test case 38888: RG: Verify the Access to Washer List page for User Role 1/2/3/4/5;Test case 43203: RG: Verify the Access for User Role 1 to 5 ;")]
        public void TC05_VerifyAccessToWasherListPageUserRole123456()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.PEngineerUser[0], Users.PEngineerUser[1]);
            userAccess.Add(Users.PManagerUser[0], Users.PManagerUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {
                Page.LoginPage.VerifyLogin(pair.Key, pair.Value);
                Thread.Sleep(2000);
                List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;
                Thread.Sleep(2000);
                if (Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Washers"))
                {
                    Assert.Fail("Logged in with user " + pair.Key + " Actual-Found Washers tab in the setup menu list.Expected- Washers tab should not display.");
                }
                Page.PlantSetupPage.TopMainMenu.LogOut();
            }
        }

        [TestCategory(TestType.bvt, "TC06_VerifyAccessToWasherListPageUserRole6")]
        [TestCategory(TestType.regression, "TC06_VerifyAccessToWasherListPageUserRole6")]
        [Test, Description("Test case 43204: RG: Verify the Access for User Role 6 ;")]
        public void TC06_VerifyAccessToWasherListPageUserRole6()
        {
            //TestFixture();
            //Page.PlantSetupPage.TopMainMenu.LogOut();
            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {
                Page.LoginPage.VerifyLogin(pair.Key, pair.Value);
                Thread.Sleep(2000);
                List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;
                Thread.Sleep(2000);
                if (!Page.LoginPage.TopMainMenu.MenuItemsList.LastOrDefault().Contains("Washers"))
                {
                    Assert.Fail("Logged in with user " + pair.Key + " Actual-Found Washers tab in the setup menu list.Expected- Washers tab should not display.");
                } 
            }
        }

        /// <summary>
        /// Test case 28455: RG: Verify Localization
        /// </summary>
        [TestCategory(TestType.functional, "TC07_VerifyWashersLocalization")]
        //[TestCategory(TestType.regression, "TC07_VerifyWashersLocalization")]
        [Test, Description("Test case 38808: RG:Verify the Localization criteria ;")]
        public void TC07_VerifyWashersLocalization()
        {
            Thread.Sleep(2000);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.WasherGroupPage.LanguagePreferred.Focus();
            Page.WasherGroupPage.LanguagePreferred.SelectByText("Deutsch", true);
            Page.WasherGroupPage.LanguagePreferred.ScrollToVisible();
            Page.WasherGroupPage.GeneralTabSaveButton.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            CloseBrowser();
            TestFixtureSetupBase();
            TestFixture();
            Thread.Sleep(1000);
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
            Thread.Sleep(2000);
            if (Page.WashersPage.WashersTab.ChildNodes[0].Content == "Washers")
            {
                Assert.Fail("Incorrect label displayed when localization changed to Deutsch language.Expected - Deutsh lang, but Actual-"
                    + Page.WashersPage.WashersTab.ChildNodes[0].Content);
            }
        }

        /// <summary>
        /// Post Localization 
        /// </summary>
        [TestCategory(TestType.functional, "TC08_WashersPostLocalization")]
        //[TestCategory(TestType.regression, "TC08_WashersPostLocalization")]
        [Test, Description("Test case 34205: RG: Verify the Localization criteria ;")]
        public void TC08_WashersPostLocalization()
        {
            //Post Condition to revert back the localization
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.ShiftTabPage.LanguagePreferred.Focus();
            Page.ShiftTabPage.LanguagePreferred.SelectByText("English US", true);
            Page.ShiftTabPage.LanguagePreferred.ScrollToVisible();
            Page.ShiftTabPage.GeneralTabSaveButton.Click();
        }

        [TestCategory(TestType.functional, "TC09_WasherMove")]
        [TestCategory(TestType.regression, "TC09_WasherMove")]
        [Test, Description(" Verify move from one washer group to another washer group;")]
        public void TC09_WasherMove()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            int controllerId1 = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxForConvWshrGrp");
            WasherGroup group1 = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialConvWasherGroupForWshrGrpMove1");
            WasherGroup group2 = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialConvWasherGroupForWshrGrpMove2");
            AppState.GetState<WasherState>().CreateConventionalWasher(group1.Id, group1.Id, "TrialConvWshr1", controllerId1, 1);        
            
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialConvWasherGroupForWshrGrpMove1'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WashersPage.WashersListGridTable.SelectedRows("TrialConvWshr1")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WashersPage.WashersListGridTable.SelectedRows("TrialConvWshr1")[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(2000);
            Page.WashersPage.DdlWasherGroups.SelectByPartialText("TrialConvWasherGroupForWshrGrpMove2", true);
            Page.WashersPage.SaveCoventionalWasher.Click();
            if (null != Page.WashersPage.SuccessMessage)
            {
                string message = Page.WashersPage.SuccessMessage.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed,Expected: Washer deleted successfully."
                                    + " but Actual:" + message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
            if (Page.WashersPage.WashersListGridTable.SelectedRows("TrialConvWshr1").Count != 0)
            {
                List<HtmlTableCell> cells = Page.WashersPage.WashersListGridTable.GetRow("TrialConvWshr1").Cells;

                foreach (HtmlTableCell cell in cells)
                {
                    if (cell.BaseElement.InnerText.Contains("TrialConvWasherGroupForWshrGrpMove2"))
                    {
                        Assert.Pass("Washer is moved from one group to another group");
                    }
                }
            }
            else
                Assert.Fail("Unable to move from one group to another group");           
           
        }

        [TestCategory(TestType.functional, "TC10_VerifySaveCloseWasherFunctionality")]
        [TestCategory(TestType.regression, "TC10_VerifySaveCloseWasherFunctionality")]		
        [Test, Description("Test case: Verify Save & Close button functionality on washer page;")]		
        public void TC10_VerifySaveCloseWasherFunctionality()		
        {           		
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();		
            Thread.Sleep(2000);
            Page.WashersPage.WashersListGridTable.SelectedRows("WasherExtractor")[0].ScrollToVisible();		
            Page.WashersPage.WashersListGridTable.SelectedRows("WasherExtractor")[0].GetButtonControls()[1].Click();           		
            Page.WashersPage.TxtName.Focus();		
            Page.WashersPage.TxtName.Text = string.Empty;		
            Page.WashersPage.TxtName.Click();		
            Thread.Sleep(1000);		
            string newWasherName = "milnorlb";
          //  KeyBoardSimulator.SetText(newWasherName);
           Page.WashersPage.TxtName.SetText(newWasherName);
           Page.WashersPage.chkRatioDosingActive.Click();
           Page.WashersPage.chkRatioDosingActive.Click();
           Page.WashersPage.Size.SelectByIndex(1, Timeout);
            Thread.Sleep(1000);		
            Page.WashersPage.btnSaveAndCloseConventionalGeneral.DeskTopMouseClick();		
            Thread.Sleep(2000);		
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();		
            Thread.Sleep(1000);		
            string UpdatedWasherName = Page.WashersPage.WashersListGridTable.SelectedRows("WasherExtractor")[0].GetColumnValues()[2].ToString();		
            Thread.Sleep(1000);		
            if (newWasherName != UpdatedWasherName)		
            {		
                Assert.Fail("Washer Name is not Updated Successully");		
            }		
          		
        }



        [TestCategory(TestType.functional, "TC11_VerifyCancelWasherFunctionality")]
        [TestCategory(TestType.regression, "TC11_VerifyCancelWasherFunctionality")]
        [Test, Description("Test case: Verify Cancel button functionality on washer page;")]
        public void TC11_VerifyCancelWasherFunctionality()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
            Thread.Sleep(2000);
            string beforeUpdateWasher = Page.WashersPage.WashersListGridTable.Rows[0].GetColumnValues()[2].ToString();
            Page.WashersPage.WashersListGridTable.Rows[0].ScrollToVisible();
            Page.WashersPage.WashersListGridTable.Rows[0].GetButtonControls()[1].Click();
            Page.WashersPage.TxtName.Focus();
            Page.WashersPage.TxtName.Text = string.Empty;
            Page.WashersPage.TxtName.DeskTopMouseClick();
            Thread.Sleep(1000);
            string newWasherName = "milnorlb";
            KeyBoardSimulator.SetText(newWasherName);
            Thread.Sleep(1000);
            Page.WashersPage.btnCancelWasher.DeskTopMouseClick();
            //Thread.Sleep(1000);		
            //Assert.True(Page.WasherGroupPage.BtnYesPopUpOnCancel.IsVisible(),		
            //                "Expected PopUp on Washer Group Edit functionality while clicking on Cancel Button.");		
            Thread.Sleep(1000);
            Page.WashersPage.btnWasherPopUpCancelNo.DeskTopMouseClick();
            Thread.Sleep(1000);
            string AfterUpdateWasher = Page.WashersPage.WashersListGridTable.Rows[0].GetColumnValues()[2].ToString();
            if (beforeUpdateWasher != AfterUpdateWasher)
            {
                Assert.Fail("Data is saved when click on Cancel Cancel");
            }
        }
    }
}
