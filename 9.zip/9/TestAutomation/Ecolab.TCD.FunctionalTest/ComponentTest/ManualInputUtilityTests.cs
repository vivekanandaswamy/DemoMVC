﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class ManualInputUtilityTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>dryerName
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            //Precondition();
            Thread.Sleep(1000);
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Thread.Sleep(4000);
            Page.ManualInputUtilityTabPage.UtilityTab.Click();
            Thread.Sleep(2000);
        }

        ///// <summary>
        ///// Tests the fixture tear down.
        ///// </summary>
        //protected override void TestFixtureTearDown()
        //{
        //    Console.WriteLine("Test Fixture Teardown overriden");
        //    base.TestFixtureTearDown();
        //}

        /// <summary>
        /// Test case 31940: RG: Verify Whether User able to see Utility meters in Utility page
        /// </summary>
        [TestCategory(TestType.functional, "TC01_VerifyManualEntry")]
        //[TestCategory(TestType.regression, "TC01_VerifyManualEntry")]
        [Test, Description("Test case 31940: RG: Verify Whether User able to see Utility meters in Utility page ;")]
        public void TC01_VerifyManualEntry()
        {
            //Dictionary<string, string> data = new Dictionary<string, string>();
            //data.Add("MeterName", "withoutmanualentry");
            //data.Add("UtilityType", "Gas");
            //data.Add("UtilityLocation", "WGTH");
            //data.Add("MachineCompartment", "Compartment1");
            ////data.Add("Parent", "m");
            //data.Add("Calibration", "1");
            //data.Add("UOM", "DTH");
            //data.Add("Controller", "12345 (UNIT001)");
            //data.Add("MaxRollOverPoint", "12000");

            //AddMeter(data,false);

            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Page.ManualInputUtilityTabPage.UtilityTab.Click();

            if (Page.ManualInputUtilityTabPage.MeterName.BaseElement.InnerText.Contains("withoutmanualentry"))
            {
                Assert.Fail("Meter without allow manual entry is displayed in manual entry page");
            }
        }

        /// <summary>
        /// Test case 31945: RG: Verify Utility meters displayed in the grid
        /// Test case 33582: RG: Verify whether user able to delete the current recording from the popup
        /// Test case 33592: RG: Verify whether User able to SAVE the New recording
        /// Test case 33594: RG: Verify whether saved details are displayed in the grid
        /// Test case 33596: RG: Verify whether UOM's are displayed properly
        /// Test case 33597: RG: verify whether deleted current record shows effect on the grid
        /// </summary>
        [TestCategory(TestType.functional, "TC02_UpdateRecord")]
        [TestCategory(TestType.regression, "TC02_UpdateRecord")]
        [Test, Description("Test case 31945: RG: Verify Utility meters displayed in the grid ;" +
                           "Test case 33582: RG: Verify whether user able to delete the current recording from the popup ;" +
                           "Test case 33592: RG: Verify whether User able to SAVE the New recording ;" +
                           "Test case 33594: RG: Verify whether saved details are displayed in the grid ;" +
                           "Test case 33596: RG: Verify whether UOM's are displayed properly ;" +
                           "Test case 33597: RG: verify whether deleted current record shows effect on the grid ;")]
        public void TC02_UpdateRecord()
        {
            //List<EcolabDataGridItems> rows = Page.ManualInputUtilityTabPage.UtilityTabGrid.SelectedRows("allowmanualentry");
            //List<HtmlControl> controls = rows.FirstOrDefault().GetButtonControls();
            //controls.LastOrDefault().DeskTopMouseClick();
            //Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            //Page.ManualInputUtilityTabPage.UtilityTab.Click();            

            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.MIUtility();
            NavigateToMetersPage();
            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText("MI Utility Meter");
            //string parentMeterName = Page.MetersTabPage.MeterName.Value.TrimEnd();
            Page.MetersTabPage.UtilityType.SelectByText("Gas", Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText("WasherGroupForMIMeter", Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByIndex(1, Timeout);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            Page.MetersTabPage.AllowManualEntry.ScrollToVisible();
            Page.MetersTabPage.AllowManualEntry.Click();
            //Page.MetersTabPage.Controller.SelectByPartialText("MeterDispenser", true);            
            Runner.DoStep("Add a Meter without a parent", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.ScrollToVisible();
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.MeterSuccessMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }

            Thread.Sleep(1000);
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Thread.Sleep(2000);            

            if (Page.ManualInputUtilityTabPage.Controls.ChildNodes.Count > 3)
            {
                Page.ManualInputUtilityTabPage.UpdateMeter.DeskTopMouseClick();
            }
            else
            {
                Page.ManualInputUtilityTabPage.UpdateMeter2.DeskTopMouseClick();
            }
            //Page.ManualInputUtilityTabPage.NewValue.TypeText("12");            
            Page.ManualInputUtilityTabPage.MINewValue.TypeText("12");            
            //Page.ManualInputUtilityTabPage.NewUsage.TypeText("12");
            //Page.ManualInputUtilityTabPage.NewValue.DeskTopMouseClick();
            //KeyBoardSimulator.SetNumeric("13");

            if (null != Page.ManualInputUtilityTabPage.UOM)
            {
                string message = Page.ManualInputUtilityTabPage.UOM.BaseElement.InnerText;
                if (!message.Equals(@"Therm"))
                {
                    Assert.Fail("Incorrect UOM displayed, Expected:{0} , Actual:{1}", "Therm", message);
                }
            }
            else
            {
                Assert.Fail("UOM is not displayed while editing utility through manual input");
            }

            Runner.DoStep("Edit some details", () =>
            {
                Page.ManualInputUtilityTabPage.SaveManualInput.Focus();
                Page.ManualInputUtilityTabPage.SaveManualInput.Click();
            });            

            Thread.Sleep(2000);
            Runner.DoStep("Verify updation successful message", () =>
            {
                if (null != Page.ManualInputUtilityTabPage.SuccessMessage)
                {
                    string message = Page.ManualInputUtilityTabPage.SuccessMessage.BaseElement.InnerText;
                    if (!message.ToLower().Contains(@"successfully"))
                    {
                        Assert.Fail("Incorrect Message, Expected:{0} , Actual:{1}", "Saved successfully", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            

            if (!Page.ManualInputUtilityTabPage.UsageValueInTable.BaseElement.InnerText.Contains("12"))
            {
                Assert.Fail("On editing utility through manual input , value is not saved");
            }
            
            //List<EcolabDataGridItems> gridValues = Page.ManualInputUtilityTabPage.UtilityTabGrid.SelectedRows("12");

            //if (gridValues.Count < 0)
            //{
            //    Assert.Fail("On editing utility through manual input , value is not saved");
            //}
           
            //{
            //    EcolabDataGridItems editedGrid = gridValues.FirstOrDefault();

            //    IReadOnlyCollection<string> columnvlaues = editedGrid.GetColumnValues();
            //    if(!columnvlaues.Contains("12 "))
            //    {
            //        Assert.Fail("Cell values are not saved after editing utility through manual input");
            //    }

            //    //if(!columnvlaues.Contains("13"))
            //    //{
            //    //    Assert.Fail("Cell values are not saved after editing utility through manual input");
            //    //}

            //}

            //rows = Page.ManualInputUtilityTabPage.UtilityTabGrid.SelectedRows("allowmanualentry");
            //controls = rows.FirstOrDefault().GetButtonControls();
            //controls.LastOrDefault().DeskTopMouseClick();
            //Page.ManualInputUtilityTabPage.LastRecordDeleteButton.DeskTopMouseClick();
            //if (null != Page.ManualInputUtilityTabPage.PopupMessage)
            //{
            //    string message = Page.ManualInputUtilityTabPage.PopupMessage.BaseElement.InnerText;
            //    if (!message.Equals(@"Deleted successfully"))
            //    {
            //        Assert.Fail("Incorrect Message, Expected:{0} , Actual:{1}", "Deleted successfully", message);
            //    }
            //}
           
            //{
            //    Assert.Fail("Delete message is not displayed");
            //}

            //Page.ManualInputUtilityTabPage.CancelManualInput.DeskTopMouseClick();

            //gridValues = Page.ManualInputUtilityTabPage.UtilityTabGrid.SelectedRows("12");

            //if (gridValues.Count > 0)
            //{
            //    Assert.Fail("On deleting utility through manual input , value is not saved");
            //}
        }

        [TestCategory(TestType.functional, "TC03_UnAllowMeter")]
        //[TestCategory(TestType.regression, "TC03_UnAllowMeter")]
        [Test]
        public void TC03_UnAllowMeter()
        {
            NavigateToMetersPage();
            Page.MetersTabPage.MetersTabGrid.SelectedRows("allowmanualentry").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            Page.MetersTabPage.ManualEntryEdit.DeskTopMouseClick();
            Page.MetersTabPage.ManualEntryEdit.Check(false, true);
            Page.MetersTabPage.EditMeterSaveButton.DeskTopMouseClick();
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Page.ManualInputUtilityTabPage.UtilityTab.Click();
            if (Page.ManualInputUtilityTabPage.UtilityTabGrid.ChildNodes.Count > 0)
            {
                Assert.Fail("After editing meter to un-allow meter for manual input, the meter is still visible in manual input tab");
            }

        }

        //private void NavigateToMetersPage()
        //{
        //    Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
        //    Thread.Sleep(2000);
        //    Page.PlantSetupPage.UtilityTab.Click();
        //    Thread.Sleep(2000);
        //    Page.PlantSetupPage.MeterTab.Click();
        //    KeyBoardSimulator.KeyPress(Keys.Tab);
        //    Thread.Sleep(2000);
        //}

        private void AddMeter(Dictionary<string, string> testdata, bool isAllowManualEntry)
        {
            NavigateToMetersPage();
            Page.MetersTabPage.AddMeterButton.Click();

            KeyBoardSimulator.KeyPress(Keys.Tab);
            Thread.Sleep(2000);

            Page.MetersTabPage.MeterName.Focus();
            Page.MetersTabPage.MeterName.DeskTopMouseClick();
            Telerik.Desktop.KeyBoard.TypeText(testdata["MeterName"]);
            KeyBoardSimulator.SetText(testdata["MeterName"]);

            Page.MetersTabPage.UtilityType.SelectByText(testdata["UtilityType"], Timeout);

            Page.MetersTabPage.UtilityLocation.SelectByPartialText(testdata["UtilityLocation"], true);

            Page.MetersTabPage.MachineCompartment.SelectByPartialText(testdata["MachineCompartment"], true);

            //Page.MetersTabPage.Parent.SelectByText(testdata["Parent"], Timeout);

            Page.MetersTabPage.Calibration.Focus();
            Page.MetersTabPage.Calibration.DeskTopMouseClick();
            //KeyBoardSimulator.SetText(testdata["Calibration"]);

            Page.MetersTabPage.UOM.SelectByText(testdata["UOM"], Timeout);

            //Page.MetersTabPage.Controller.SelectByText(testdata["Controller"], Timeout);

            Page.MetersTabPage.AllowManualEntry.Check(isAllowManualEntry, true);
            Page.MetersTabPage.MaxRollOverPoint.Focus();
            //Page.MetersTabPage.MaxRollOverPoint.ExtendedMouseClick();
            KeyBoardSimulator.SetText(testdata["MaxRollOverPoint"]);


            Page.MetersTabPage.AddMeterSaveButton.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);


        }

        private void Precondition()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.MIProduction();
            Dictionary<string, string> data = new Dictionary<string, string>();
            data.Add("MeterName", "allowmanualentry");
            data.Add("UtilityType", "Oil");
            data.Add("UtilityLocation", "MIProductionWasherGroup");
            data.Add("MachineCompartment", "MIProductionWasher");
            //data.Add("Parent", "m8");
            data.Add("Calibration", "1");
            data.Add("UOM", "gallon");
            data.Add("Controller", "61298 (TestUtilityLogger2)");
            data.Add("MaxRollOverPoint", "12000");

            AddMeter(data, true);
        }
    }
}
