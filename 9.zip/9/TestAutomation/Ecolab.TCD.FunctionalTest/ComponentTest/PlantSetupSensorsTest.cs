﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class PlantSetupSensorsTest : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CWGSensor();
            PreCondition();
        }

        private void CloseBrowser()
        {
            Telerik.Shutdown();
            Telerik.CleanUp();
        }

        /// <summary>
        /// Preconditions this instance.
        /// </summary>        
        public void PreCondition()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(5000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(5000);
            //while (Page.SensorTabPage.SensorTableGrid.Rows.Count > 0)
            //{
            //    Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls()[1].Click();
            //    DialogHandler.FormulaYesButton.Click();
            //}                        
            Dictionary<string, string> data = new Dictionary<string, string>();
            data.Add("SensorName", "Sample1");
            data.Add("SensorType", "Weight");
            data.Add("SensorLocation", "SensorWasherGroup");
            data.Add("Machine", "SensorWasher 1");
            data.Add("OutputType", "0-20mA");            
            data.Add("UOM", "kilogram");
            data.Add("Controller", "SensorDispenser");
            data.Add("Calibration", "1");
            AddSensor(data);
            Thread.Sleep(2000);
            Runner.DoStep("Add a Sensor", () =>
            {
                Page.SensorTabPage.btnSave.Focus();
                KeyBoardSimulator.KeyPress(Keys.Enter);
            });            
            Thread.Sleep(2000);
            string name = Page.SensorTabPage.SensorAddedSuccess.BaseElement.InnerText.ToLower();
            if (Page.SensorTabPage.SensorAddedSuccess.BaseElement.InnerText.ToLower().Contains("sensor added successfully"))
            {
                Assert.True(true, "Sensor added successfully");
            }
            else
            {
                Assert.Fail("Sensor add success message not found");
            }                        
        }

        /// <summary>
        /// Postconditions this instance.
        /// </summary>
        public void PostCondition()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetButtonControls()[0].Click();
            Runner.DoStep("Delete a Sensor", () =>
            {
                DialogHandler.FormulaYesButton.Click();
            });            
        }

        public void SaveAndCancelFunctionality()
        {                   
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetEditableControls()[2].Focus();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetEditableControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.N);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.M);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.E);
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (!Page.RedFlagTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Save functionality failed");
            }

            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetEditableControls()[2].Focus();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetEditableControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Shift);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.S);
            KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Shift);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.M);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.P);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.L);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.E);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D1);
            Page.ChemicalsTabPage.CancelChange.Click();
            DialogHandler.YesButton.Click();
            Thread.Sleep(2000);
        }

        /// <summary>
        /// Adds the sensor.
        /// </summary>
        /// <param name="testData">The testdata.</param>
        private void AddSensor(Dictionary<string, string> testData)
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.AddSensorButton.Click();
            Page.SensorTabPage.AddSensorButton.ScrollToVisible();
            Page.SensorTabPage.SensorName.TypeText(testData["SensorName"]);            
            //Page.SensorTabPage.SensorType.SelectByText(testData["SensorType"], true);   
            Page.SensorTabPage.SensorType.SelectByIndex(1, Timeout);
            Page.SensorTabPage.SensorLocation.SelectByPartialText(testData["SensorLocation"], true);
            Thread.Sleep(3000);
            //Page.SensorTabPage.MachineName.SelectByText(testData["Machine"], true);
            Page.SensorTabPage.MachineName.SelectByPartialText(testData["Machine"], true);
            //Page.SensorTabPage.OutputType.SelectByText(testData["OutputType"], true);            
            Page.SensorTabPage.OutputType.SelectByIndex(1, Timeout);        
            //Page.SensorTabPage.UoM.SelectByText(testData["UOM"], true);
            Page.SensorTabPage.UoM.SelectByIndex(1, Timeout);
            //Page.SensorTabPage.SensorController.SelectByText(testData["Controller"], true);
            //Page.SensorTabPage.SensorController.SelectByIndex(1, Timeout);
            Page.SensorTabPage.Calibration.TypeText(testData["Calibration"]);
            Thread.Sleep(1000);

        }

        [TestCategory(TestType.functional, "TC01_SensorsCountConnectToSameMachine")]
        [TestCategory(TestType.regression, "TC01_SensorsCountConnectToSameMachine")]
        [Test, Description("Test case 23629:  RG:18999 : Plant Setup -> Sensors:Verify the maximum Sensors with same utility can be connected to machine/compartment ;")]
        public void TC01_SensorsCountConnectToSameMachine()
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            data.Add("SensorName", "Sample2");
            data.Add("SensorType", "Weight");
            data.Add("SensorLocation", "SensorWasherGroup");
            data.Add("Machine", "SensorWasher 1");
            data.Add("OutputType", "0-20mA");
            data.Add("UOM", "pound");
            data.Add("Controller", "SensorDispenser");
            data.Add("Calibration", "1");
            //Assert.True(Page.SensorTabPage.AddSensorAndVerify());
            AddSensor(data);
            Thread.Sleep(5000);
            Runner.DoStep("Try adding a Sensor with the Machine/Compartment same as another", () =>
            {
                Page.SensorTabPage.btnSave.Focus();
                KeyBoardSimulator.KeyPress(Keys.Enter);
            });
            Thread.Sleep(5000);
            string msg = Page.SensorTabPage.ErrorMessage.BaseElement.InnerText; 
            Runner.DoStep("Verify that the error message has arrived", () =>
            {
                if (null != Page.SensorTabPage.ErrorMessage)
                {
                    if (!Page.SensorTabPage.ErrorMessage.BaseElement.InnerText
                        .Contains(@"Maximum one Sensor with the same type can be connected to one machine/Compartement"))
                    {
                        Assert.Fail("Incorrect error message is displayed");
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
            Runner.DoStep("Click on 'Cancel' button", () =>
            {
                Page.SensorTabPage.btnCancel.Focus();
                Page.SensorTabPage.btnCancel.Click();
            });
            SaveAndCancelFunctionality();
            PostCondition();
        }

        /// <summary>
        /// Test case 23675:  RG:18999 : Plant Setup -> Sensors:Verify the maximum Temperature sensors
        /// connected to same Washer-Tunnel
        /// </summary>
        [TestCategory(TestType.functional, "TC02_VerifyTemperatureSensorsMaxCount")]
        [Test]
        public void TC02_VerifyTemperatureSensorsMaxCount()
        {
            Dictionary<string, string> data1 = new Dictionary<string, string>();
            data1.Add("SensorName", "Temp1");
            data1.Add("SensorType", "Temperature");
            data1.Add("SensorLocation", "Senking CBW");
            data1.Add("Machine", "Compartment1");
            data1.Add("OutputType", "0-20mA");
            data1.Add("Calibration", "1");
            data1.Add("UOM", "Celsius");
            data1.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data1);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data2 = new Dictionary<string, string>();
            data2.Add("SensorName", "Temp2");
            data2.Add("SensorType", "Temperature");
            data2.Add("SensorLocation", "Senking CBW");
            data2.Add("Machine", "Compartment2");
            data2.Add("OutputType", "0-20mA");
            data2.Add("Calibration", "1");
            data2.Add("UOM", "Celsius");
            data2.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data2);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data3 = new Dictionary<string, string>();
            data3.Add("SensorName", "Temp3");
            data3.Add("SensorType", "Temperature");
            data3.Add("SensorLocation", "Senking CBW");
            data3.Add("Machine", "Compartment3");
            data3.Add("OutputType", "0-20mA");
            data3.Add("Calibration", "1");
            data3.Add("UOM", "Celsius");
            data3.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data3);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data4 = new Dictionary<string, string>();
            data4.Add("SensorName", "Temp4");
            data4.Add("SensorType", "Temperature");
            data4.Add("SensorLocation", "Senking CBW");
            data4.Add("Machine", "Compartment4");
            data4.Add("OutputType", "0-20mA");
            data4.Add("Calibration", "1");
            data4.Add("UOM", "Celsius");
            data4.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data4);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data5 = new Dictionary<string, string>();
            data5.Add("SensorName", "Temp5");
            data5.Add("SensorType", "Temperature");
            data5.Add("SensorLocation", "Senking CBW");
            data5.Add("Machine", "Compartment5");
            data5.Add("OutputType", "0-20mA");
            data5.Add("Calibration", "1");
            data5.Add("UOM", "Celsius");
            data5.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data5);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data6 = new Dictionary<string, string>();
            data6.Add("SensorName", "STemp6");
            data6.Add("SensorType", "Temperature");
            data6.Add("SensorLocation", "Senking CBW");
            data6.Add("Machine", "Compartment6");
            data6.Add("OutputType", "0-20mA");
            data6.Add("Calibration", "1");
            data6.Add("UOM", "Celsius");
            data6.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data6);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data7 = new Dictionary<string, string>();
            data7.Add("SensorName", "temp7");
            data7.Add("SensorType", "Temperature");
            data7.Add("SensorLocation", "Senking CBW"); 
            data7.Add("Machine", "Compartment7");
            data7.Add("OutputType", "0-20mA");
            data7.Add("Calibration", "1");
            data7.Add("UOM", "Celsius");
            data7.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data7);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);


            Dictionary<string, string> data8 = new Dictionary<string, string>();
            data8.Add("SensorName", "temp8");
            data8.Add("SensorType", "Temperature");
            data8.Add("SensorLocation", "Senking CBW");
            data8.Add("Machine", "Compartment8");
            data8.Add("OutputType", "0-20mA");
            data8.Add("Calibration", "1");
            data8.Add("UOM", "Celsius");
            data8.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data8);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Thread.Sleep(5000);
            if (null != Page.SensorTabPage.ErrorMessage)
            {
                if (!Page.SensorTabPage.ErrorMessage.BaseElement.InnerText
                    .Equals("Maximum 6 Temperatures sensor can be connected to the same Washter-Tunnel"))
                {
                    Assert.Fail(string.Format("Incorrect error message is displayed {0}", Page.SensorTabPage.ErrorMessage.BaseElement.InnerText));
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            Page.SensorTabPage.btnCancel.Focus();
            Page.SensorTabPage.btnCancel.Click();

            PostCondition();
        }

        /// <summary>
        /// Test case 23677:  RG:18999 : Plant Setup -> Sensors:Verify the maximum pH sensor connected to the same Washer-Tunnel
        /// </summary>
        [TestCategory(TestType.functional, "TC03_VerifypHSensorsMaxCount")]
        [Test]
        public void TC03_VerifypHSensorsMaxCount()
        {
            Dictionary<string, string> data1 = new Dictionary<string, string>();
            data1.Add("SensorName", "S1");
            data1.Add("SensorType", "pH");
            data1.Add("SensorLocation", "tunnel45");
            data1.Add("Machine", "Compartment1");
            data1.Add("OutputType", "0-20mA");
            data1.Add("Calibration", "1");
            data1.Add("UOM", "pH");
            data1.Add("Controller", "5432(UNIT032144)");
            AddSensor(data1);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data2 = new Dictionary<string, string>();
            data2.Add("SensorName", "S2");
            data2.Add("SensorType", "pH");
            data2.Add("SensorLocation", "tunnel45");
            data2.Add("Machine", "Compartment2");
            data2.Add("OutputType", "0-20mA");
            data2.Add("Calibration", "1");
            data2.Add("UOM", "pH");
            data2.Add("Controller", "5432(UNIT032144)");
            AddSensor(data2);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data3 = new Dictionary<string, string>();
            data3.Add("SensorName", "S3");
            data3.Add("SensorType", "pH");
            data3.Add("SensorLocation", "tunnel45");
            data3.Add("Machine", "Compartment3");
            data3.Add("OutputType", "0-20mA");
            data3.Add("Calibration", "1");
            data3.Add("UOM", "pH");
            data3.Add("Controller", "5432(UNIT032144)");
            AddSensor(data3);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data4 = new Dictionary<string, string>();
            data4.Add("SensorName", "S4");
            data4.Add("SensorType", "pH");
            data4.Add("SensorLocation", "tunnel45");
            data4.Add("Machine", "Compartment4");
            data4.Add("OutputType", "0-20mA");
            data4.Add("Calibration", "1");
            data4.Add("UOM", "pH");
            data4.Add("Controller", "5432(UNIT032144)");
            AddSensor(data4);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data5 = new Dictionary<string, string>();
            data5.Add("SensorName", "S5");
            data5.Add("SensorType", "pH");
            data5.Add("SensorLocation", "tunnel45");
            data5.Add("Machine", "Compartment5");
            data5.Add("OutputType", "0-20mA");
            data5.Add("Calibration", "1");
            data5.Add("UOM", "pH");
            data5.Add("Controller", "5432(UNIT032144)");
            AddSensor(data5);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data6 = new Dictionary<string, string>();
            data6.Add("SensorName", "S6");
            data6.Add("SensorType", "pH");
            data6.Add("SensorLocation", "tunnel45");
            data6.Add("Machine", "Compartment6");
            data6.Add("OutputType", "0-20mA");
            data6.Add("Calibration", "1");
            data6.Add("UOM", "pH");
            data6.Add("Controller", "5432(UNIT032144)");
            AddSensor(data6);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data7 = new Dictionary<string, string>();
            data7.Add("SensorName", "S7");
            data7.Add("SensorType", "Temperature");
            data7.Add("SensorLocation", "tunnel45");
            data7.Add("Machine", "Compartment7");
            data7.Add("OutputType", "0-20mA");
            data7.Add("Calibration", "1");
            data7.Add("UOM", "Celsius");
            data7.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data7);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data8 = new Dictionary<string, string>();
            data8.Add("SensorName", "S8");
            data8.Add("SensorType", "Temperature");
            data8.Add("SensorLocation", "tunnel45");
            data8.Add("Machine", "Compartment8");
            data8.Add("OutputType", "0-20mA");
            data8.Add("Calibration", "1");
            data8.Add("UOM", "Celsius");
            data8.Add("Controller", "6214 (UNIT5498)");
            AddSensor(data8);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data9 = new Dictionary<string, string>();
            data9.Add("SensorName", "S9");
            data9.Add("SensorType", "pH");
            data9.Add("SensorLocation", "tunnel45");
            data9.Add("Machine", "Compartment9");
            data9.Add("OutputType", "0-20mA");
            data9.Add("Calibration", "1");
            data9.Add("UOM", "pH");
            data9.Add("Controller", "5432(UNIT032144)");
            AddSensor(data9);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data10 = new Dictionary<string, string>();
            data10.Add("SensorName", "S10");
            data10.Add("SensorType", "pH");
            data10.Add("SensorLocation", "tunnel45");
            data10.Add("Machine", "Compartment10");
            data10.Add("OutputType", "0-20mA");
            data10.Add("Calibration", "1");
            data10.Add("UOM", "pH");
            data10.Add("Controller", "5432(UNIT032144)");
            AddSensor(data10);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data11 = new Dictionary<string, string>();
            data11.Add("SensorName", "S11");
            data11.Add("SensorType", "pH");
            data11.Add("SensorLocation", "tunnel45");
            data11.Add("Machine", "Compartment11");
            data11.Add("OutputType", "0-20mA");
            data11.Add("Calibration", "1");
            data11.Add("UOM", "pH");
            data11.Add("Controller", "5432(UNIT032144)");
            AddSensor(data11);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data12 = new Dictionary<string, string>();
            data12.Add("SensorName", "S12");
            data12.Add("SensorType", "pH");
            data12.Add("SensorLocation", "tunnel45");
            data12.Add("Machine", "Compartment12");
            data12.Add("OutputType", "0-20mA");
            data12.Add("Calibration", "1");
            data12.Add("UOM", "pH");
            data12.Add("Controller", "5432(UNIT032144)");
            AddSensor(data12);
            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);


            Thread.Sleep(5000);
            if (null != Page.SensorTabPage.ErrorMessage)
            {
                if (!Page.SensorTabPage.ErrorMessage.BaseElement.InnerText
                    .Equals("Maximum 2 pH sensors can be connected to the same Washter-Tunnel"))
                {
                    Assert.Fail(string.Format("Incorrect error message is displayed {0}", Page.SensorTabPage.ErrorMessage.BaseElement.InnerText));
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            Page.SensorTabPage.btnCancel.Focus();
            Page.SensorTabPage.btnCancel.Click();

            PostCondition();
        }

        /// <summary>
        /// Test case 23683: RG:18999 : Plant Setup -> Sensors:Verify the application functionality when the Sensor is not mapped to a washer  
        /// </summary>
        [TestCategory(TestType.functional, "TC04_VerifySensorNotMappedToWasher")]
        [Test]
        public void TC04_VerifySensorNotMappedToWasher()
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            data.Add("SensorName", "SNMP");
            data.Add("SensorType", "Weight");
            data.Add("SensorLocation", "conv");
            data.Add("Machine", "ALL");
            data.Add("OutputType", "0-20mA");
            data.Add("Calibration", "1");
            data.Add("UOM", "pound");
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();  
                
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.AddSensorButton.Click();
            Page.SensorTabPage.AddSensorButton.ScrollToVisible();
            Page.SensorTabPage.SensorName.TypeText(data["SensorName"]);
            Page.SensorTabPage.SensorType.SelectByText(data["SensorType"], true);
            Page.SensorTabPage.SensorLocation.SelectByText(data["SensorLocation"], true);
            Thread.Sleep(3000);
            Page.SensorTabPage.MachineName.SelectByText(data["Machine"], true);
            Page.SensorTabPage.OutputType.SelectByText(data["OutputType"], true);
            Page.SensorTabPage.Calibration.TypeText(data["Calibration"]);
            Page.SensorTabPage.UoM.SelectByText(data["UOM"], true);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Page.SensorTabPage.SensorTableGrid.SelectedRows("SNMP")[0].GetButtonControls()[2].Click();
            string strControlName = Page.SensorTabPage.EditSensorController.BaseElement.InnerText;
            if (strControlName == "UtilityLogger")
            {
                Assert.True(true, "Sensor mapped to UtilityLogger when not assigned a washer ");
            }
            else
            {
                Assert.Fail(string.Format("Incorrect control mapped to the Sensor {0}", Page.SensorTabPage.EditSensorController.BaseElement.InnerText));
            }
            Page.SensorTabPage.btnCancel.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            PostCondition();
        }

        /// <summary>
        /// Test case 23887: RG:18999 : Plant Setup -> Sensors:Verify whether the field name "Machine/Compartment" is changing dynamically
        /// </summary>
        [TestCategory(TestType.functional, "TC05_VerifyAddMachineCompartment")]
        [Test]
        public void TC05_VerifyAddMachineCompartment()
        {

            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.SensorTabPage.SensorTab.Click();
            Page.SensorTabPage.AddSensorButton.Click();
            Page.SensorTabPage.AddSensorButton.ScrollToVisible();
            Page.SensorTabPage.SensorName.TypeText("SS");
            Page.SensorTabPage.SensorType.SelectByText("Temperature", true);
            //Page.SensorTabPage.SensorLocation.SelectByText("Washer-Extractor1", true);
            Page.SensorTabPage.SensorLocation.SelectByText("Senking T2", true);
            Thread.Sleep(3000);
            if (Page.SensorTabPage.LabelAddMachineCompartment.BaseElement.InnerText != "Machine")
            {
                Assert.Fail(string.Format("Incorrect Label is displayed {0} when selected Washer", Page.SensorTabPage.LabelAddMachineCompartment.BaseElement.InnerText));
            }
            //Page.SensorTabPage.SensorLocation.SelectByText("Tunnel-Washer1", true);
            Page.SensorTabPage.SensorLocation.SelectByText("Senking CBW", true);
            Thread.Sleep(3000); 
                
            if (Page.SensorTabPage.LabelAddMachineCompartment.BaseElement.InnerText != "Compartment")
            {
                Assert.Fail(string.Format("Incorrect Label is displayed {0} when selected Tunnel", Page.SensorTabPage.LabelAddMachineCompartment.BaseElement.InnerText));
            }
            Page.SensorTabPage.btnCancel.MultiTabClickButton();

            PostCondition();
        }

        /// <summary>
        /// Test case 23924: RG:18999 : Plant Setup -> Sensors:Verify the "Save" button functionality on "Update Sensor" pop-up
        /// </summary>
        [TestCategory(TestType.functional, "TC06_VerifyEditPopupSaveButton")]
        [TestCategory(TestType.regression, "TC06_VerifyEditPopupSaveButton")]
        [Test]
        public void TC06_VerifyEditPopupSaveButton()
        {
            //PostCondition();

            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.AddSensorButton.Click();
            Page.SensorTabPage.AddSensorButton.ScrollToVisible();
            Page.SensorTabPage.SensorName.TypeText("Sample Sensor");
            Page.SensorTabPage.SensorType.SelectByIndex(1, Timeout);
            Page.SensorTabPage.SensorLocation.SelectByPartialText("SensorWasherGroup", true);
            Thread.Sleep(3000);
            Page.SensorTabPage.MachineName.SelectByPartialText("SensorWasher 2", true);
            Page.SensorTabPage.OutputType.SelectByIndex(1, Timeout);
            Page.SensorTabPage.UoM.SelectByIndex(1, Timeout);
            //Page.SensorTabPage.SensorController.SelectByIndex(1, Timeout);
            Thread.Sleep(1000);
            Runner.DoStep("Add a Sensor", () =>
            {
                Page.SensorTabPage.btnSave.Focus();
                KeyBoardSimulator.KeyPress(Keys.Enter);
            });
            Thread.Sleep(2000);                        
       
            //string intialSensorNameValue = Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetColumnValues()[2];
            //string intialSensorNameValue = Page.SensorTabPage.SensorTableGrid.SelectedRows("TrialBeckConventionalWasherGroup")[0].GetColumnValues()[2];
            string intialSensorNameValue = "Sample Sensor";
            //Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetButtonControls().LastOrDefault().Click();
            Page.SensorTabPage.EditSensorName.TypeText("EditPopupTest");
            //Page.SensorTabPage.UoMEdited.SelectByIndex(2, Timeout);
            Runner.DoStep("Edit the Sensor", () =>
            {
                Page.SensorTabPage.SaveEditedSensor.ScrollToVisible();
                Page.SensorTabPage.SaveEditedSensor.Focus();
                Page.SensorTabPage.SaveEditedSensor.DeskTopMouseClick();
            });            

            //Page.SensorTabPage.Close.Click();

            Runner.DoStep("Verify the successful sensor updation message", () =>
            {
                if (!Page.SensorTabPage.SensorAddedSuccess.BaseElement.InnerText.ToLower().Contains("sensor updated successfully"))
                {
                    Assert.Fail("Sensor update success message not found");
                }
            });            
            //string editedValue = Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().InnerText;
            //string editedValue = "EditPopupTest";
            //Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetButtonControls().LastOrDefault().Click();

            Page.SensorTabPage.EditSensorName.TypeText(intialSensorNameValue);
            //Page.SensorTabPage.UoMEdited.SelectByIndex(1, Timeout);
            //Page.SensorTabPage.btnEditSave.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.SensorTabPage.SaveEditedSensor.Click();
            Thread.Sleep(2000);

            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Sensor update success messgae not found");
            }

            //if (null != editedValue)
            //{
            //    if (!editedValue.Contains("EditPopupTest"))
            //    {
            //        Assert.Fail("Edited value not saved, Sensor name value");
            //    }
            //}
            //else
            //{
            //    Assert.Fail("Sensor name not displayed");
            //}

            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetButtonControls()[0].DeskTopMouseClick();
            DialogHandler.FormulaYesButton.DeskTopMouseClick();
        }

        /// <summary>
        /// Test case 23932: RG:18999 : Plant Setup -> Sensors:Verify whether the application is displaying prompt message while "Saving/Deleting" the records
        /// </summary>
        [TestCategory(TestType.functional, "TC07_VerifyDeletePromptMessage")]
        //[TestCategory(TestType.regression, "TC07_VerifyDeletePromptMessage")]
        [Test]
        public void TC07_VerifyDeletePromptMessage()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.SensorTabPage.SensorTab.Click();
            DialogHandler.GetMessageAndOKButton();
            Page.SensorTabPage.SensorTableGrid.SelectedRows("dryers")[0].GetButtonControls()[1].Click();
            Thread.Sleep(5000);

            if (null != DialogHandler.GetConfirmationDialogMessage)
            {
                if (!DialogHandler.GetConfirmationDialogMessage
                    .Equals(@"Are you sure you want to delete record?"))
                {
                    Assert.Fail(string.Format("Incorrect error message is displayed in dialog box : {0}", DialogHandler.LastDialogMessage));
                }
            }
            else
            {
                Assert.Fail("Dialog box with confirmation to delete row is not displayed");
            }
            PostCondition();
        }

        /// <summary>
        /// Test case 23951: RG:18999 : Plant Setup -> Sensors:Verify the application localization functionality on Sensors Page
        /// </summary>
        [TestCategory(TestType.functional, "TC08_VerifyLocalizationSensorPage")]
        [Test]
        public void TC08_VerifyLocalizationSensorPage()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            //Page.PlantSetupPage.GeneralTab.Click();
            //Page.SensorTabPage.Language.Focus();
            //Page.SensorTabPage.Language.SelectByText("Deutsch", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
           
            Page.SensorTabPage.SensorTab.Click();
          
            Page.SensorTabPage.AddSensorButton.Click();
            if (Page.SensorTabPage.AddPopupTitle.BaseElement.InnerText != "Voeg Sensor")
            {
                Assert.Fail(string.Format("Incorrect Label is displayed {0} when localization changed to Deutsch", Page.SensorTabPage.AddPopupTitle.BaseElement.InnerText));
            }
            Page.SensorTabPage.btnCancel.MultiTabClickButton();
            PostCondition();
        }

        /// <summary>
        /// Test Case:- 23681: RG:18999: Plant SetUp - Sensors- Verify the maximum conductivity sensors can be connected to the same washer action
        /// </summary>
        [TestCategory(TestType.functional, "TC09_VerifyConductivityMaxSensors")]
        [Test]
        public void TC09_VerifyConductivityMaxSensors()
        {
            Dictionary<string, string> data1 = new Dictionary<string, string>();    
            data1.Add("SensorName", "conduct1");
            data1.Add("SensorType", "Conductivity");
            data1.Add("SensorLocation", "Tunnel S T1");
            data1.Add("Machine", "Compartment1");
            data1.Add("OutputType", "0-20mA");
            data1.Add("Calibration", "12");
            data1.Add("UOM", "µS/cm");
            data1.Add("Controller", "5432(UNIT032144)");
            AddSensor(data1);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data2 = new Dictionary<string, string>();
            data2.Add("SensorName", "conduct2");
            data2.Add("SensorType", "Conductivity");
            data2.Add("SensorLocation", "Tunnel S T1");
            data2.Add("Machine", "Compartment2");
            data2.Add("OutputType", "0-20mA");
            data2.Add("Calibration", "12");
            data2.Add("UOM", "µS/cm");
            data2.Add("Controller", "5432(UNIT032144)");    
            AddSensor(data2);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data3 = new Dictionary<string, string>();
            data3.Add("SensorName", "conduct3");
            data3.Add("SensorType", "Conductivity");
            data3.Add("SensorLocation", "Tunnel S T1");
            data3.Add("Machine", "Compartment3");
            data3.Add("OutputType", "0-20mA");
            data3.Add("Calibration", "12");
            data3.Add("UOM", "µS/cm");
            data3.Add("Controller", "5432(UNIT032144)");
            AddSensor(data3);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data4 = new Dictionary<string, string>();
            data4.Add("SensorName", "conduct4");
            data4.Add("SensorType", "Conductivity");
            data4.Add("SensorLocation", "Tunnel S T1");
            data4.Add("Machine", "Compartment4");       
            data4.Add("OutputType", "0-20mA");
            data4.Add("Calibration", "12");
            data4.Add("UOM", "µS/cm");
            data4.Add("Controller", "5432(UNIT032144)");
            AddSensor(data4);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data5 = new Dictionary<string, string>();
            data5.Add("SensorName", "conduct5");
            data5.Add("SensorType", "Conductivity");
            data5.Add("SensorLocation", "Tunnel S T1");
            data5.Add("Machine", "Compartment5");
            data5.Add("OutputType", "0-20mA");
            data5.Add("Calibration", "12");
            data5.Add("UOM", "µS/cm");
            data5.Add("Controller", "5432(UNIT032144)");
            AddSensor(data5);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data6 = new Dictionary<string, string>();
            data6.Add("SensorName", "conduct6");
            data6.Add("SensorType", "Conductivity");
            data6.Add("SensorLocation", "Tunnel S T1");
            data6.Add("Machine", "Compartment6");
            data6.Add("OutputType", "0-20mA");
            data6.Add("Calibration", "12");
            data6.Add("UOM", "µS/cm");
            data6.Add("Controller", "5432(UNIT032144)");
            AddSensor(data6);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data7 = new Dictionary<string, string>();
            data7.Add("SensorName", "conduct7");
            data7.Add("SensorType", "Conductivity");
            data7.Add("SensorLocation", "Tunnel S T1");
            data7.Add("Machine", "Compartment7");
            data7.Add("OutputType", "0-20mA");
            data7.Add("Calibration", "12");
            data7.Add("UOM", "µS/cm");
            data7.Add("Controller", "5432(UNIT032144)");
            AddSensor(data7);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data8 = new Dictionary<string, string>();
            data8.Add("SensorName", "conduct8");
            data8.Add("SensorType", "Conductivity");
            data8.Add("SensorLocation", "Tunnel S T1");
            data8.Add("Machine", "Compartment8");
            data8.Add("OutputType", "0-20mA");
            data8.Add("Calibration", "12");
            data8.Add("UOM", "µS/cm");
            data8.Add("Controller", "5432(UNIT032144)");
            AddSensor(data8);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data9 = new Dictionary<string, string>();
            data9.Add("SensorName", "conduct9");
            data9.Add("SensorType", "Conductivity");
            data9.Add("SensorLocation", "Tunnel S T1");
            data9.Add("Machine", "Compartment9");
            data9.Add("OutputType", "0-20mA");
            data9.Add("Calibration", "12");
            data9.Add("UOM", "µS/cm");
            data9.Add("Controller", "5432(UNIT032144)");
            AddSensor(data9);

            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data10 = new Dictionary<string, string>();
            data10.Add("SensorName", "conduct10");
            data10.Add("SensorType", "Conductivity");
            data10.Add("SensorLocation", "Tunnel S T1");
            data10.Add("Machine", "Compartment10");
            data10.Add("OutputType", "0-20mA");
            data10.Add("Calibration", "12");
            data10.Add("UOM", "µS/cm");
            data10.Add("Controller", "5432(UNIT032144)");
            AddSensor(data10);           

            Thread.Sleep(2000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);
            Thread.Sleep(1000);
            if (null != Page.SensorTabPage.ErrorMessage)
            {
                if (!Page.SensorTabPage.ErrorMessage.BaseElement.InnerText
                    .Equals(@"Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel"))
                {
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            Page.SensorTabPage.btnCancel.Click();
            PostCondition();
        }

        /// <summary>
        /// Test Case:- 23682: RG:18999: Plant SetUp - Sensors- Verify the maximum conductivity sensors can be connected to the same washer action
        /// </summary>
        [TestCategory(TestType.functional, "TC10_VerifyWeightMaxSensors")]
        [Test]
        public void TC10_VerifyWeightMaxSensors()
        {
            Dictionary<string, string> data1 = new Dictionary<string, string>();
            data1.Add("SensorName", "WeightSensor1");
            data1.Add("SensorType", "Weight");
            data1.Add("SensorLocation", "tunnel-oresextractor");
            data1.Add("Machine", "Compartment1");
            data1.Add("OutputType", "0-20mA");
            data1.Add("Calibration", "15");
            data1.Add("UOM", "kilogram");
            data1.Add("Controller", "12345 (UNIT001)");
            AddSensor(data1);
            Assert.True(Page.SensorTabPage.AddSensorAndVerify(), "Maximum 1 Weight sensor can be connected to the same Washter-Tunnel");

            Dictionary<string, string> data2 = new Dictionary<string, string>();
            data2.Add("SensorName", "WeightSensor2");
            data2.Add("SensorType", "Weight");  
            data2.Add("SensorLocation", "tunnel-oresextractor");
            data2.Add("Machine", "Compartment2");
            data2.Add("OutputType", "0-20mA");
            data2.Add("Calibration", "15");
            data2.Add("UOM", "kilogram");
            data2.Add("Controller", "12345 (UNIT001)");
            AddSensor(data2);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data3 = new Dictionary<string, string>();
            data3.Add("SensorName", "WeightSensor3");
            data3.Add("SensorType", "Weight");
            data3.Add("SensorLocation", "tunnel-oresextractor");
            data3.Add("Machine", "Compartment3");
            data3.Add("OutputType", "0-20mA");
            data3.Add("Calibration", "15");
            data3.Add("UOM", "kilogram");
            data3.Add("Controller", "12345 (UNIT001)");
            AddSensor(data3);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data4 = new Dictionary<string, string>();
            data4.Add("SensorName", "WeightSensor4");
            data4.Add("SensorType", "Weight");
            data4.Add("SensorLocation", "tunnel-oresextractor");
            data4.Add("Machine", "Compartment4");
            data4.Add("OutputType", "0-20mA");
            data4.Add("Calibration", "15");
            data4.Add("UOM", "kilogram");
            data4.Add("Controller", "12345 (UNIT001)");
            AddSensor(data4);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data5 = new Dictionary<string, string>();
            data5.Add("SensorName", "WeightSensor5");
            data5.Add("SensorType", "Weight");
            data5.Add("SensorLocation", "tunnel-oresextractor");
            data5.Add("Machine", "Compartment5");
            data5.Add("OutputType", "0-20mA");
            data5.Add("Calibration", "15");
            data5.Add("UOM", "kilogram");
            data5.Add("Controller", "12345 (UNIT001)");
            AddSensor(data5);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data6 = new Dictionary<string, string>();
            data6.Add("SensorName", "WeightSensor6");
            data6.Add("SensorType", "Weight");
            data6.Add("SensorLocation", "tunnel-oresextractor");
            data6.Add("Machine", "Compartment6");
            data6.Add("OutputType", "0-20mA");
            data6.Add("Calibration", "15");
            data6.Add("UOM", "kilogram");
            data6.Add("Controller", "12345 (UNIT001)");
            AddSensor(data6);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data7 = new Dictionary<string, string>();
            data7.Add("SensorName", "WeightSensor7");
            data7.Add("SensorType", "Weight");
            data7.Add("SensorLocation", "tunnel-oresextractor");
            data7.Add("Machine", "Compartment7");
            data7.Add("OutputType", "0-20mA");
            data7.Add("Calibration", "15");
            data7.Add("UOM", "kilogram");
            data7.Add("Controller", "12345 (UNIT001)");
            AddSensor(data7);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data8 = new Dictionary<string, string>();
            data8.Add("SensorName", "WeightSensor8");
            data8.Add("SensorType", "Weight");
            data8.Add("SensorLocation", "tunnel-oresextractor");
            data8.Add("Machine", "Compartment8");
            data8.Add("OutputType", "0-20mA");
            data8.Add("Calibration", "15");
            data8.Add("UOM", "kilogram");
            data8.Add("Controller", "12345 (UNIT001)");
            AddSensor(data8);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data9 = new Dictionary<string, string>();
            data9.Add("SensorName", "WeightSensor9");
            data9.Add("SensorType", "Weight");
            data9.Add("SensorLocation", "tunnel-oresextractor");
            data9.Add("Machine", "Compartment9");
            data9.Add("OutputType", "0-20mA");
            data9.Add("Calibration", "15");
            data9.Add("UOM", "kilogram");
            data9.Add("Controller", "12345 (UNIT001)");
            AddSensor(data9);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Dictionary<string, string> data10 = new Dictionary<string, string>();
            data10.Add("SensorName", "WeightSensor10");
            data10.Add("SensorType", "Weight");
            data10.Add("SensorLocation", "tunnel-oresextractor");
            data10.Add("Machine", "Compartment10");
            data10.Add("OutputType", "0-20mA");
            data10.Add("Calibration", "15");
            data10.Add("UOM", "kilogram");
            data10.Add("Controller", "12345 (UNIT001)");
            AddSensor(data10);

            Thread.Sleep(5000);
            Page.SensorTabPage.btnSave.Focus();
            KeyBoardSimulator.KeyPress(Keys.Enter);

            Thread.Sleep(5000);
            if (null != Page.SensorTabPage.ErrorMessage)
            {
                if (!Page.SensorTabPage.ErrorMessage.BaseElement.InnerText
                    .Equals(@"Maximum 1 Weight sensor can be connected to the same Washter-Tunnel"))
                {
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            Page.SensorTabPage.btnCancel.Click();
            PostCondition();
        }

        /// <summary>
        /// Test Case:- 23926 : RG:18999: PlantSetUp:- Sensors:- Verify the Save Button functionality on Edit Sensor PopUp
        ///  Note:- this Test Case we are considering as Inline Editing and Updating the Sensors Data...
        /// </summary>
        [TestCategory(TestType.functional, "TC11_VerifyInLineEditUpdateSensorsData")]
        [Test]
        public void TC11_VerifyInLineEditUpdateSensorsData()
        {

            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(1000);
            Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Page.SensorTabPage.InLineSensorEdit("SensorUpdated");
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls()[1].Click();
            Thread.Sleep(3000);
            Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Page.SensorTabPage.InLineSensorEdit("SensorUpdated");
            Telerik.ActiveBrowser.RefreshDomTree();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Thread.Sleep(2000);
            if (!Page.SensorTabPage.SensorAddedSuccess.BaseElement.InnerText.Contains("Sensor details updated successfully"))
            {
                Assert.Fail("Sensor update success messgae not found");
            }
            PostCondition();
        }

        /// <summary>
        /// Test Case:-23928 RG:-18999 PlantSetUp - Verify the Delete Button Functionality
        /// </summary>
        [TestCategory(TestType.functional, "TC12_VerifyDeleteButtonSensorsFunctionality")]
        [TestCategory(TestType.regression, "TC12_VerifyDeleteButtonSensorsFunctionality")]
        [Test]
        public void TC12_VerifyDeleteButtonSensorsFunctionality()
        {
            PreCondition();
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(5000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(5000);
            DialogHandler.GetMessageAndOKButton();
            Page.SensorTabPage.SensorTableGrid.SelectedRows("SensorWasherGroup")[0].GetButtonControls()[0].Click();
            //if (null != DialogHandler.GetConfirmationDialogMessage)
            //{
            //    if (!DialogHandler.GetConfirmationDialogMessage
            //        .Equals(@"Are you sure you want to delete record?"))
            //    {
            //        Assert.Fail(string.Format("Incorrect error message is displayed in dialog box : {0}", DialogHandler.LastDialogMessage));
            //    }
            //}
            //else
            //{
            //    Assert.Fail("Dialog box with confirmation to delete row is not displayed");
            //}
            Runner.DoStep("Delete a Sensor", () =>
            {
                DialogHandler.FormulaYesButton.Click();
            });
            Runner.DoStep("Verify the successful Sensor deletion message", () =>
            {
                Assert.IsTrue(Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.Contains("Successfully"), "Success Message not matched");            
            });            
        }

        /// <summary>
        /// Test case 23685: Verify the page view access permissions
        /// </summary>
        [TestCategory(TestType.functional, "TC13_VerifyPageViewAccessPermissions")]
        //[TestCategory(TestType.regression, "TC13_VerifyPageViewAccessPermissions")]
        [Test]
        public void TC13_VerifyPageViewAccessPermissions()
        {
            //TestFixtureTearDown();
            //PostCondition();
            CloseBrowser();
            TestFixtureSetupBase();
            TestFixture();
            Runner.DoStep("Logout the user ADMIN", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });            
            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.TMBasicUser[0], Users.TMBasicUser[1]);
            userAccess.Add(Users.AdminUser[0], Users.AdminUser[1]);
            userAccess.Add(Users.PEngineerUser[0], Users.PEngineerUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {
                Runner.DoStep("Verify the access that user "+pair.Key+" has over Sensors", () =>
                {
                    Page.LoginPage.VerifyLogin(pair.Key, pair.Value);
                    Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
                    Page.PlantSetupPage.UtilityTab.Click();
                    HtmlControl utilityContainersTab = Page.SensorTabPage.UtilityContainerSubMenu;
                    string strbreadCrumb = string.Empty;
                    List<string> myList = new List<string>();
                    ICollection<Element> ctrl = utilityContainersTab.ChildNodes;
                    foreach (Element e in ctrl)
                    {
                        myList.Add(e.InnerText.Trim());
                    }
                    if (pair.Key == Users.PEngineerUser[0])
                    {
                        if (!myList.Contains("Sensors"))
                        {
                            Assert.Fail("Sensors tab is not visible for user :" + pair.Key);
                        }
                    }
                    else
                    {
                        Page.SensorTabPage.SensorTab.Click();
                    }
                });                                
                Page.PlantSetupPage.TopMainMenu.LogOut();
            }
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            PostCondition();
        }

        /// <summary>
        /// Test case 23686: Verify the Edit access permissions on Meters Page 
        /// </summary>
        [TestCategory(TestType.functional, "TC14_VerifyEditAccessPermissionOnSensors")]
        //[TestCategory(TestType.regression, "TC14_VerifyEditAccessPermissionOnSensors")]
        [Test]
        public void TC14_VerifyEditAccessPermissionOnSensors()
        {
            //TestFixtureTearDown();
            //PostCondition();
            CloseBrowser();
            TestFixtureSetupBase();
            TestFixture();
            Runner.DoStep("Logout the user ADMIN", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });            
            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.EngineerUser[0], Users.EngineerUser[1]);
            userAccess.Add(Users.AdminUser[0], Users.AdminUser[1]);
            userAccess.Add(Users.TMBasicUser[0], Users.TMBasicUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {
                Runner.DoStep("Verify the access that user " + pair.Key + " has over Sensors", () =>
                {
                    Page.LoginPage.VerifyLogin(pair.Key, pair.Value);
                    Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
                    Page.PlantSetupPage.UtilityTab.Click();
                    Page.SensorTabPage.SensorTab.Click();
                    if (pair.Key == Users.TMBasicUser[0])
                    {
                        Thread.Sleep(2000);
                        Page.SensorTabPage.UsersRolesSensorsTabGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
                        HtmlControl ctrlSensorslabel = Page.SensorTabPage.ViewSensorsLabel;
                        if (ctrlSensorslabel.ChildNodes[0].Content == "View Sensor")
                        {
                            Assert.True(true, "Logged in with level 6 user:" + pair.Key + " but found edit option is visible");
                        }
                    }
                    else
                    {
                        Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls()[2].Click();
                        //Page.SensorTabPage.SensorTableGrid.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().Click();
                        HtmlControl ctrlSensors = Page.SensorTabPage.EditSensorsLabel;
                        if (ctrlSensors.ChildNodes[0].Content == "Edit Sensor")
                        {
                            Assert.True(true, "Logged in with level 8 & 9 user:" + pair.Key + " but found edit option is not visible");
                        }
                    }
                });                                
                Page.PlantSetupPage.TopMainMenu.LogOut();
            }
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            PostCondition();
        }
    }
}
