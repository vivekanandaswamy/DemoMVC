﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.AppStateHandler;
using Ecolab.CommonUtilityPlugin;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class MaxStorageTanksValidationTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.LoginPage.TopMainMenu.NavigateToStorageTanksPage();            
        }
      
        /// <summary>
        ///
        /// </summary>
        [TestCategory(TestType.functional, "TC01_ValidateMaxStorageTanks")]
        [TestCategory(TestType.regression, "TC01_ValidateMaxStorageTanks")]
        [Test]
        public void TC01_ValidateMaxStorageTanks()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.AddControllerAndStorageTanks();

            Page.LoginPage.TopMainMenu.NavigateToStorageTanksPage();
            Runner.DoStep("Enter Storage tank details and click Save", () =>
            {
                Page.StorageTanksTabPage.AddStorageTanks.Click();
                Page.StorageTanksTabPage.TankName.TypeText(DateTime.Now.ToString());
                Page.StorageTanksTabPage.ProductName.SelectByIndex(1, Timeout);

                Page.StorageTanksTabPage.LowLevel.TypeText("36");
                Page.StorageTanksTabPage.EmptyLevel.TypeText("45");
                Page.StorageTanksTabPage.CallibrationLevel.TypeText("18");

                Page.StorageTanksTabPage.InputType.SelectByIndex(1, Timeout);
                Page.StorageTanksTabPage.ControllerName.SelectByPartialText("TrialABUltraxForStorageTanks", true);
                Page.StorageTanksTabPage.Save.DeskTopMouseClick();
            });

            Runner.DoStep("Verify whether Low-Calibration values error has occured or not", () =>
            {
                if (!Page.StorageTanksTabPage.LowAndCalibrationLevelsError.BaseElement.InnerText.Contains("Low Level should be less than Calibration Level"))
                {
                    Assert.Fail("Expected error message after comparing Low and Calibration levels' values not visble", true);
                }
            });

            Runner.DoStep("Verify whether Empty-Low values error has occured or not", () =>
            {
                if (!Page.StorageTanksTabPage.EmptyAndLowLevelsError.BaseElement.InnerText.Contains("Empty level should be less than Low Level"))
                {
                    Assert.Fail("Expected error message after comparing Empty and Low levels' values not visble", true);
                }
            });
            
            Page.StorageTanksTabPage.LowLevel.TypeText("36");
            Page.StorageTanksTabPage.EmptyLevel.TypeText("18");
            Page.StorageTanksTabPage.CallibrationLevel.TypeText("45");
            Runner.DoStep("Edit the Low, Calibration and Empty level values and click Save", () =>
            {
                Page.StorageTanksTabPage.Save.DeskTopMouseClick();
            });            

            //Thread.Sleep(4000);
            Runner.DoStep("Verify the expected MAX STORAGE TANKS LIMIT message appeared or not", () =>
            {
                if (!Page.StorageTanksTabPage.MaxTanksReachedError.BaseElement.InnerText.Contains("Dispenser cannot have more than 8 Tanks"))
                {
                    Assert.Fail("Max Storage tanks for a Dispenser limit reached but the error message is not shown", true);
                }
            });            
            Thread.Sleep(2000);
        }        
    }
}
