﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class PlantSetupShiftTests: TestBase
    {
        private static string testData = TestDataPath + "testdata.xlsx";

        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();            
            Runner.DoStep("Navigate to Shifts tab in Plant Setup page", () =>
            {
                Page.ShiftTabPage.ShiftTab.Click();
            });
        }

        private void CloseBrowser()
        {
            Telerik.Shutdown();
            Telerik.CleanUp();
        }

        /// <summary>
        /// Test case 27574: RG:17908 : Verify Shift time and Break time
        /// Test case 27602: RG:17908 : Verify SAVE functionality on ADD Shift
        /// Test case 27606: RG:17908 : Verify Delete functionality
        /// </summary>
        [TestCategory(TestType.regression, "TC01_AddAndDeleteShift")]
        [TestCategory(TestType.functional, "TC01_AddAndDeleteShift")]
        [Test(Description = "Test case 27574 ;Test case 27602 ;Test case 27606 ;")]
        public void TC01_AddAndDeleteShift()
        {
            //Precondition: Delete existing shifts for wednesday
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Tuesday");
            Page.ShiftTabPage.DeleteAllShifts();

            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });            
            string addShiftUoM = Page.ShiftTabPage.TargetProdAddShiftUoM;

            Runner.DoStep("Verify that Sunday and Saturday are by default unselected", () =>
            {
                if (Page.ShiftTabPage.IsDaySelected(DayOfWeek.Sunday))
                {
                    Assert.Fail("By default Sunday should be inactive");
                }

                if (Page.ShiftTabPage.IsDaySelected(DayOfWeek.Saturday))
                {
                    Assert.Fail("By default Saturday should be inactive");
                }
            });

            Runner.DoStep("Verify that other days [weekdays] are by default selected", () =>
            {
                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Monday))
                {
                    Assert.Fail("By default Monday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Tuesday))
                {
                    Assert.Fail("By default Tuesday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Wednesday))
                {
                    Assert.Fail("By default Wednesday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Thursday))
                {
                    Assert.Fail("By default Thursday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Friday))
                {
                    Assert.Fail("By default Friday should be active");
                }
            });            

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Auto Test Shift");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("13:00");
            Thread.Sleep(5000);
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.DeskTopMouseClick();
            });            

            Thread.Sleep(5000);
            Runner.DoStep("Verify the creation of the Shift", () =>
            {
                if (null != Page.ShiftTabPage.ShiftAddMessage)
                {
                    string message = Page.ShiftTabPage.ShiftAddMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Shift created successfully"))
                    {
                        Assert.Fail("Incorrect message is displayed while adding shift , Expected: Shift created successfully ,Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Shift added message is not displayed");
                }
            });                    
           
            // TODO: Uncomment after DB fix ---------------------
            //DataRowCollection dbValues = DBValidation.DataRows(@"select ShiftName from Shift where ShiftId = (select ShiftId from ShiftData where StartTime='10:00 AM' and EndTime='01:00 PM' and Is_Deleted=0)");

            //if(dbValues.Count <= 0)
            //{
            //    Assert.Fail("After shift addition data base is not updated");
            //}

            //if(!dbValues[0].ItemArray[0].ToString().Equals("Auto Test Shift"))
            //{
            //    Assert.Fail("Shift name is incorrectly updated in DB");
            //}
            // TODO: Uncomment after DB fix ---------------------

            Page.ShiftTabPage.ShiftDeleteButton("Tuesday", "Auto Test Shift").Click();
            Runner.DoStep("Delete the Shift", () =>
            {
                DialogHandler.YesButton.DeskTopMouseClick();
            });            

            // TODO: Uncomment after DB fix ---------------------
            //dbValues = DBValidation.DataRows(@"select ShiftName from Shift where ShiftId = (select ShiftId from ShiftData where StartTime='10:00 AM' and EndTime='01:00 PM' and Is_Deleted=0)");

            //if (dbValues.Count > 0)
            //{
            //    Assert.Fail("After shift deleation data base is not updated");
            //}
            // TODO: Uncomment after DB fix ---------------------
        }

        /// <summary>
        /// Test case 27603: RG:17908 : Verify SAVE functionality on Edit shift
        /// Test case 27610: RG:17908 : Verify whether shift creates with already existed shift timings
        /// Test case 27612: RG:17908 : Verify whether user creates a shift break with already existed break
        /// </summary>
        [TestCategory(TestType.regression, "TC02_AddShiftWithBreakAndUpdateBreak")]
        [TestCategory(TestType.functional, "TC02_AddShiftWithBreakAndUpdateBreak")]
        [Test, Description("Test case 27603: RG:17908 : Verify SAVE functionality on Edit shift ;" +
                           "Test case 27610: RG:17908 : Verify whether shift creates with already existed shift timings ;" +
                           "Test case 27612: RG:17908 : Verify whether user creates a shift break with already existed break ;")]
        public void TC02_AddShiftWithBreakAndUpdateBreak()
        {
            //Precondition: Delete existing shifts for wednesday
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Wednesday");
            Page.ShiftTabPage.DeleteAllShifts();

            Page.ShiftTabPage.AddShift.Click();         

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Auto Test Shift With Break");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("18:00");
            Runner.DoStep("Add a Shift with no break", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });

            Runner.DoStep("Verify that the NO BREAKS FOUND message is displayed", () =>
            {
                if (null != Page.ShiftTabPage.NoBreakMessage("Wednesday", "Auto Test Shift With Break"))
                {
                    if (!Page.ShiftTabPage.NoBreakMessage("Wednesday", "Auto Test Shift With Break").BaseElement.InnerText
                        .Equals("No Breaks Found"))
                    {
                        Assert.Fail("No breaks found message is incorrect: Actual:{0}", Page.ShiftTabPage.NoBreakMessage("Wednesday", "Auto Test Shift With Break").BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("No breaks found message is not displayed");
                }
            });

            Page.ShiftTabPage.ShiftEditButton("Wednesday", "Auto Test Shift With Break").Click();
            Page.ShiftTabPage.AddBreak.Click();           
            Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText("14:10");
            Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText("15:00");
            Runner.DoStep("Add a break to the above added shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });            

            if (null != Page.ShiftTabPage.ShiftTexts("Wednesday", "Auto Test Shift With Break"))
            {
                if (!Page.ShiftTabPage.ShiftTexts("Wednesday", "Auto Test Shift With Break").Contains("14:10 to 15:00"))
                {
                    Assert.Fail("Shift text for Wednesday is not correct , Actual:{0}", Page.ShiftTabPage.ShiftTexts("Wednesday", "Auto Test Shift With Break").FirstOrDefault());
                }
            }
            else
            {
                Assert.Fail("Shift message is not displayed in shift page");
            }

            Page.ShiftTabPage.ShiftEditButton("Wednesday", "Auto Test Shift With Break").Click();            
            //Page.ShiftTabPage.AddBreak.Click();           
            Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText("13:00");
            Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText("14:30");
            Runner.DoStep("Update Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();            
            });
            Runner.DoStep("Verify that the shift is updated", () =>
            {
                if (null != Page.ShiftTabPage.ShiftTexts("Wednesday", "Auto Test Shift With Break"))
                {
                    if (!Page.ShiftTabPage.ShiftTexts("Wednesday", "Auto Test Shift With Break").Contains("13:00 to 14:30"))
                    {
                        Assert.Fail("Shift text for Wednesday is not correct , Actual:{0}", Page.ShiftTabPage.ShiftTexts("Wednesday", "Auto Test Shift With Break").FirstOrDefault());
                    }
                }
                else
                {
                    Assert.Fail("Shift message is not displayed in shift page");
                }
            });            

            Page.ShiftTabPage.AddShift.Click();
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Auto Test Shift With Break");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("14:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("16:00");
            Runner.DoStep("Try adding a shift with the same name as previous", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });
            Runner.DoStep("Verify that the SHIFT NAME OVERLAPPING message has arrived", () =>
            {
                if (null != Page.ShiftTabPage.ShiftOverlapMessage)
                {
                    if (!Page.ShiftTabPage.ShiftOverlapMessage.BaseElement.InnerText
                        .Contains(@"Shift name overlapping"))
                    {
                        Assert.Fail("Incorrect message is displayed while adding overlapping shift Actual:{0}", Page.ShiftTabPage.ShiftOverlapMessage.BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("Shift overlap message is not displayed");
                }
            });            

            Page.ShiftTabPage.CancelShiftButton.TypeEnterKey();

            Page.ShiftTabPage.ShiftEditButton("Wednesday", "Auto Test Shift With Break").Click();            
            Page.ShiftTabPage.AddBreak.Click();
            Page.ShiftTabPage.BreakFromTime[1].TypeText("14:00");
            Page.ShiftTabPage.BreakToTime[1].TypeText("15:30");
            Runner.DoStep("Edit the shift and try adding an overlaping break", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });
            Runner.DoStep("Verify that the BREAKS OVERLAPPING message has arrived", () =>
            {
                if (!Page.ShiftTabPage.IsBreakOverlapping.Equals("Breaks overlapping"))
                {
                    Assert.Fail("Overlapping breaks are allowed");
                }
            });            
            Page.ShiftTabPage.CancelShiftButton.Click();            

            //DialogHandler.ClickonOKButton();
            Page.ShiftTabPage.ShiftDeleteButton("Wednesday", "Auto Test Shift With Break").Click();
            Runner.DoStep("Delete Shift", () =>
            {
                DialogHandler.YesButton.DeskTopMouseClick();
            });                        
        }

        /// <summary>
        /// Test case 27616: RG:17908 : Verify whether Shift break is created with in the shift timings only
        /// Test case 27632: RG:17908 : Verify whether Shift break is deleted
        /// </summary>
        [TestCategory(TestType.regression, "TC03_BreakOutsideShiftTimeAndDeleteBreak")]
        [TestCategory(TestType.functional, "TC03_BreakOutsideShiftTimeAndDeleteBreak")]
        [Test, Description("Test case 27616: RG:17908 : Verify whether Shift break is created with in the shift timings only ;" +
                           "Test case 27632: RG:17908 : Verify whether Shift break is deleted ;")]
        public void TC03_BreakOutsideShiftTimeAndDeleteBreak()
        {
            //Precondition: Delete existing shifts for wednesday
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Thursday");
            Page.ShiftTabPage.DeleteAllShifts();

            Page.ShiftTabPage.AddShift.Click();           

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Auto Break Outside Shift");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("14:00");
            Runner.DoStep("Add a shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });            

            Page.ShiftTabPage.ShiftEditButton("Thursday", "Auto Break Outside Shift").Click();
            Page.ShiftTabPage.AddBreak.Click();
            Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText("13:00");
            Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText("14:30");
            Runner.DoStep("Try adding a break that goes beyond the shift time", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });
            Runner.DoStep("Verify that the BREAKS OVERLAPPING message has arrived", () =>
            {
                if (!Page.ShiftTabPage.IsBreakOverlapping.Equals("Breaks overlapping"))
                {
                    Assert.Fail("Break timings are not within shift timings, break is still allowed");
                }
            });            

            Page.ShiftTabPage.CancelShiftButton.Click();

            Page.ShiftTabPage.ShiftEditButton("Thursday", "Auto Break Outside Shift").Click();
            Page.ShiftTabPage.AddBreak.Click();
            Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText("13:00");
            Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText("13:30");
            Runner.DoStep("Add a break within shift time", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });           

            //DialogHandler.ClickonOKButton();
            Page.ShiftTabPage.DeleteBreakButtonsFromShiftPage("Thursday", "Auto Break Outside Shift").FirstOrDefault().Click();
            Runner.DoStep("Delete the shift break", () =>
            {
                DialogHandler.YesButton.DeskTopMouseClick();
            });            

            // Remove after DB fix ---------------------
            //DataRowCollection dbValues = DBValidation.DataRows(@"select top 1 IS_Deleted from ShiftBreakDataHistory order by OperationTimestamp desc");
            //if (!Convert.ToBoolean(dbValues[0].ItemArray[0]))
            //{
            //    Assert.Fail("Shift break deletion is not updated in DB");
            //}
            // Remove after DB fix ---------------------

            //DialogHandler.ClickonOKButton();
            Page.ShiftTabPage.ShiftDeleteButton("Thursday", "Auto Break Outside Shift").Click();
            Runner.DoStep("Delete the Shift", () =>
            {
                DialogHandler.YesButton.DeskTopMouseClick();
            });            
        }

        /// <summary>
        /// Test case 27838: RG:17908 : Verify Delete functionality of labor
        /// Test case 27797: RG:17908 : Verify whether same timings are updated in database(12hrs/24hrs)
        /// </summary>
        [TestCategory(TestType.regression, "TC04_AddUpdateDeleteLaborToShift")]
        [TestCategory(TestType.functional, "TC04_AddUpdateDeleteLaborToShift")]
        [Test, Description("Test case 27838: RG:17908 : Verify Delete functionality of labor ;" +
                           "Test case 27797: RG:17908 : Verify whether same timings are updated in database(12hrs/24hrs) ;")]
        public void TC04_AddUpdateDeleteLaborToShift()
        {
            //Precondition: Delete existing shifts for wednesday
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Wednesday");
            Page.ShiftTabPage.DeleteAllShifts();

            Page.ShiftTabPage.AddShift.Click();
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Auto Test Shift With Break");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("18:00");
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });            

            // Remove after DB fix ---------------------
            //DataRowCollection shiftDBData = DBValidation.DataRows("select top 1 * from ShiftData order by ID desc");

            //if (!shiftDBData[0].ItemArray[2].ToString().Equals("10:00:00"))
            //{
            //    Assert.Fail("Shift start time for created shift is incorrectly updated in DB, Actual:{0}", shiftDBData[0].ItemArray[2].ToString());
            //}

            //if (!shiftDBData[0].ItemArray[3].ToString().Equals("18:00:00"))
            //{
            //    Assert.Fail("End time for created shift is incorrectly updated in DB, Actual:{0}", shiftDBData[0].ItemArray[3].ToString());
            //}
            // Remove after DB fix ---------------------

            Page.ShiftTabPage.AddLabour("Wednesday", "Auto Test Shift With Break").Click();

            string labourType = Page.ShiftTabPage.LabourType.Options[1].Text;
            Page.ShiftTabPage.LabourType.SelectByText(labourType, true);

            string labourLocation = Page.ShiftTabPage.LabourLocation.Options[1].Text;
            Page.ShiftTabPage.LabourLocation.SelectByText(labourLocation, true);

            Page.ShiftTabPage.ManHours.TypeText("12");
            //string avgPrice = Page.ShiftTabPage.AvgPricePerHr.BaseElement.InnerText;
            Runner.DoStep("Add Labor to that shift", () =>
            {
                Page.ShiftTabPage.AddLabourSaveButton.TypeEnterKey();
            });            

            HtmlControl firstRow = Page.ShiftTabPage.LabourRows("Wednesday", "Auto").FirstOrDefault();
            List<string> labourValues = Page.ShiftTabPage.RowValues(firstRow);

            if(labourValues.Count < 4)
            {
                Assert.Fail("Labour table  did not get populated after adding labour to shift");
            }
            else
            {
                Runner.DoStep("Verify that the Labor details are displayed correctly", () =>
                {
                    if (!labourValues[0].Equals(labourType))
                    {
                        Assert.Fail("Labour type is incorrectly displayed in table after adding labour to shift");
                    }

                    if (!labourValues[1].Equals(labourLocation))
                    {
                        Assert.Fail("Labour location is incorrectly displayed in table after adding labour to shift");
                    }

                    if (!labourValues[2].Equals("12"))
                    {
                        Assert.Fail("Man hours is incorrectly displayed in table after adding labour to shift");
                    }
                });                

                //if (!labourValues[3].Equals(avgPrice))
                //{
                //    Assert.Fail("Average price is incorrectly displayed in table after adding labour to shift, Actual:{0}", avgPrice);
                //}
                //DialogHandler.ClickonOKButton();

                Page.ShiftTabPage.LabourRowUpdateButton(firstRow).Click();
                Page.ShiftTabPage.ManHours.TypeText("10");
                Runner.DoStep("Update Labor", () =>
                {
                    Page.ShiftTabPage.ManHours.Focus();
                    Page.ShiftTabPage.AddLabourSaveButton.TypeEnterKey();
                });                

                Page.ShiftTabPage.LabourRowDeleteButton(firstRow).Click();
                Runner.DoStep("Delete Labor to that shift", () =>
                {
                    DialogHandler.YesButton.DeskTopMouseClick();
                });
                Runner.DoStep("Verify that the Labor has been deleted", () =>
                {
                    if (!Page.ShiftTabPage.IsLaborRowAbsent("Wednesday", "Auto"))
                    {
                        Assert.Fail("After labour is deleted, the labour grid is not updated in UI");
                    }
                });                
            }

        }

        /// <summary>
        /// Test case 28348: RG:17908 : Verify whether shift modified/edited is reflected in other weekday when days are selected
        /// TODO: Editing option for the day of the shift is removed from application, check the above requirement
        /// </summary>
        //[TestCategory(TestType.regression, "TC05_EditShiftDay")]
        //[TestCategory(TestType.functional, "TC05_EditShiftDay")]
        [Test, Description("Test case 28348: RG:17908 : Verify whether shift modified/edited is reflected in other weekday when days are selected ;")]
        public void TC05_EditShiftDay()
        {
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Monday");
            //Page.ShiftTabPage.DeleteAllShifts("Tuesday");
            Page.ShiftTabPage.DeleteAllShifts();

            Page.ShiftTabPage.AddShift.Click();
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Auto Test Shift For Day Edit");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("18:00");
            Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();

            Page.ShiftTabPage.ShiftEditButton("Monday", "Auto Test Shift For Day Edit").Click();
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.Tuesday.Click();
            Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();

            var test = Page.ShiftTabPage.ShiftsPresent("Tuesday");
            
            //if (!Page.ShiftTabPage.ShiftsPresent("Tuesday").Contains("Auto Test Shift For Day Edit"))
            //{
            //    Assert.Fail("Shift is not displayed for the new day after editing shift day");
            //}

            var test2 = Page.ShiftTabPage.ShiftsPresent("Monday");
            if (Page.ShiftTabPage.ShiftsPresent("Monday").Contains("Auto Test Shift For Day Edit"))
            {
                Assert.Fail("Shift is still displayed for the same day after editing shift day");
            }

            if (null == Page.ShiftTabPage.ShiftDeleteButton("Tuesday", "Auto Test Shift For Day Edit"))
            {
                Assert.Fail("Shift is not displayed for the new day after editing shift day");
            }
            else
            {
                Page.ShiftTabPage.ShiftDeleteButton("Tuesday", "Auto Test Shift For Day Edit").Click();
            }
        }
        
        /// <summary>
        /// Test case 28762: RG:17908 : Verify whether the created shift is displayed
        /// </summary>
        [TestCategory(TestType.regression, "TC06_VerifyCreatedShiftDisplayed")]
        [TestCategory(TestType.functional, "TC06_VerifyCreatedShiftDisplayed")]
        [Test, Description("Test case 28762: RG:17908 : Verify whether the created shift is displayed ;")]
        public void TC06_VerifyCreatedShiftDisplayed()
        {
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Monday");
            //Page.ShiftTabPage.DeleteAllShifts("Tuesday");
            //Page.ShiftTabPage.DeleteAllShifts("Wednesday");
            //Page.ShiftTabPage.DeleteAllShifts("Thursday");
            //Page.ShiftTabPage.DeleteAllShifts("Friday");
            Page.ShiftTabPage.DeleteAllShifts();
            Page.ShiftTabPage.AddShift.Click();           
            Thread.Sleep(2000);
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> {DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday});
            Thread.Sleep(3000);
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("New Shift Added");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("7373");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("13:00");
            Page.ShiftTabPage.AddBreak.Click();
            Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText("10:30");
            Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText("11:30");
            Page.ShiftTabPage.AddBreak.Click();
            Page.ShiftTabPage.BreakFromTime[1].TypeText("14:30");
            Page.ShiftTabPage.BreakToTime[1].TypeText("15:30");
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });            
            Thread.Sleep(3000);
            Runner.DoStep("Verify that the shift added is displayed but not multiple times", () =>
            {
                List<string> getShiftCountList = new List<string>();
                getShiftCountList = Page.ShiftTabPage.GetShiftDetails("Monday", "New Shift Added");
                if (getShiftCountList.Count > 1)
                {
                    Assert.Fail("Shift created multiple times");
                }
                else
                {
                    Assert.True(true, "Shift created multiple times");
                }
                List<string> getBreakTimeList = new List<string>();
                getBreakTimeList = Page.ShiftTabPage.ShiftTexts("Monday", "New Shift Added");
                if (getBreakTimeList.Count > 2)
                {
                    Assert.Fail("Break added more than 2 times");
                }
                else
                {
                    Assert.True(true, "Break added more than 2 times");
                }
            });            
            Thread.Sleep(3000);
        }

        /// <summary>
        /// Test case 30355: RG:17908 : Verify whether break is created even after shift is created
        /// </summary>
        [TestCategory(TestType.regression, "TC07_CreateBreakAfterCreatingShift")]
        [TestCategory(TestType.functional, "TC07_CreateBreakAfterCreatingShift")]
        [Test, Description("Test case 30355: RG:17908 : Verify whether break is created even after shift is created ;")]
        public void TC07_CreateBreakAfterCreatingShift()
        {
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Monday");
            Page.ShiftTabPage.DeleteAllShifts();
            
            Page.ShiftTabPage.AddShift.Click();
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Creating Break in Shift");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("7373");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("19:00");
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });            
            Page.ShiftTabPage.ShiftEditButton("Monday", "Creating Break in Shift").Click();
            Runner.DoStep("Edit shift by adding breaks", () =>
            {
                Page.ShiftTabPage.AddBreak.Click();
                Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText("10:30");
                Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText("11:30");
                Page.ShiftTabPage.AddBreak.Click();
                Page.ShiftTabPage.BreakFromTime[1].TypeText("14:30");
                Page.ShiftTabPage.BreakToTime[1].TypeText("15:30");
            });            
            Thread.Sleep(3000);
            List<string> getShiftNameList = new List<string>();
            getShiftNameList = Page.ShiftTabPage.GetShiftDetails("Monday", "Creating Break in Shift");
            Runner.DoStep("Verify the added shift and respective breaks", () =>
            {
                if (getShiftNameList.Count > 1)
                {
                    Assert.Fail("Shift created multiple times");
                }
                else
                {
                    Assert.True(true, "Shift created multiple times");
                }
                List<string> getBreakTimeList = new List<string>();
                getBreakTimeList = Page.ShiftTabPage.ShiftTexts("Monday", "Creating Break in Shift");
                if (getBreakTimeList.Count > 2)
                {
                    Assert.Fail("Break added more than 2 times");
                }
                else
                {
                    Assert.True(true, "Break added more than 2 times");
                }
            });            
        }

        /// <summary>
        /// Test case 30356: RG:17908 : Verify whether shift created is reflected in other weekday when days are selected
        /// </summary>
        [TestCategory(TestType.regression, "TC08_VerifyShiftReflectedinOtherWeekDays")]
        [TestCategory(TestType.functional, "TC08_VerifyShiftReflectedinOtherWeekDays")]
        [Test, Description("Test case 30356: RG:17908 : Verify whether shift created is reflected in other weekday when days are selected ;")]
        public void TC08_VerifyShiftReflectedinOtherWeekDays()
        {
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Monday");
            //Page.ShiftTabPage.DeleteAllShifts("Tuesday");
            //Page.ShiftTabPage.DeleteAllShifts("Wednesday");
            //Page.ShiftTabPage.DeleteAllShifts("Thursday");
            //Page.ShiftTabPage.DeleteAllShifts("Friday");
            Page.ShiftTabPage.DeleteAllShifts();

            Page.ShiftTabPage.AddShift.Click();            
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Saturday, DayOfWeek.Sunday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Shift for Multiple WeekDays");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("7373");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("19:00");
            Runner.DoStep("Add shift for multiple weekdays", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });            
            List<string> getShiftList = new List<string>();
            Runner.DoStep("Verify that the shift is created for the selected days", () =>
            {
                getShiftList = Page.ShiftTabPage.GetShiftDetails("Shift for Multiple WeekDays");
                if (getShiftList.Count == 5)
                {
                    Assert.True(true, "Shift added to multiple weekdays");
                }
                else
                {
                    Assert.Fail("Shifts not added to multiple weekdays");
                }
            });            
        }

        /// <summary>
        /// Test case 28456: RG:17908 : Verify localization
        /// </summary>
        //[TestCategory(TestType.regression, "TC09_VerifyLocalization")]
        [TestCategory(TestType.functional, "TC09_VerifyLocalization")]
        [Test, Description("Test case 28456: RG:17908 : Verify localization ;")]
        public void TC09_VerifyLocalization()
        {
            //Pre-Condition of localization Language changing
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.ShiftTabPage.LanguagePreferred.Focus();
            Page.ShiftTabPage.LanguagePreferred.SelectByText("English US", true);
            Page.ShiftTabPage.LanguagePreferred.ScrollToVisible();
            Page.ShiftTabPage.GeneralTabSaveButton.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            //TestFixtureTearDown();
            CloseBrowser();
            TestFixtureSetupBase();
            TestFixture();
            //Changing language from English US to Deutsch
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.ShiftTabPage.LanguagePreferred.Focus();
            Page.ShiftTabPage.LanguagePreferred.SelectByText("Deutsch", true);
            Page.ShiftTabPage.LanguagePreferred.ScrollToVisible();
            Page.ShiftTabPage.GeneralTabSaveButton.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            //TestFixtureTearDown();
            CloseBrowser();
            TestFixtureSetupBase();
            TestFixture();
            string text = Page.ShiftTabPage.ShiftTab.ChildNodes[0].Content;
            if (Page.ShiftTabPage.ShiftTab.ChildNodes[0].Content == "Verschuiving")
            {
                Assert.True(true, "Incorrect label name found when localized changed to Deutsch Language");
            }
            List<string> getShiftNameList = new List<string>();
            getShiftNameList = Page.ShiftTabPage.GetShiftDetails("Shift for Multiple WeekDays");
            if (getShiftNameList.Count > 0)
            {
                Assert.Fail("Shift name not changed when localization changed to Deutsch language");
            }
            else
            {
                Assert.True(true, "Shift name not changed when localization changed to Deutsch language");
            }
        }

        //[TestCategory(TestType.regression, "TC10_PostLocalization")]
        [TestCategory(TestType.functional, "TC10_PostLocalization")]
        [Test]
        public void TC10_PostLocalization()
        {
            //Post Condition to revert back the localization
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.ShiftTabPage.LanguagePreferred.Focus();
            Page.ShiftTabPage.LanguagePreferred.SelectByText("English US", true);
            Page.ShiftTabPage.LanguagePreferred.ScrollToVisible();
            Page.ShiftTabPage.GeneralTabSaveButton.Click();
            //Telerik.ActiveBrowser.RefreshDomTree();
            //TestFixtureTearDown();
        }

        [TestCategory(TestType.regression, "TC11_VerifyShiftForLevel3")]
        [TestCategory(TestType.functional, "TC11_VerifyShiftForLevel3")]
        [Test]
        public void TC11_VerifyShiftForLevel3()
        {            
            Runner.DoStep("Logout the user ADMIN", () =>
            {
                Page.LoginPage.TopMainMenu.LogOut();
            });
            Runner.DoStep("Login as user PEngineer", () =>
            {
                Page.LoginPage.VerifyLogin(Users.PEngineerUser[0], Users.PEngineerUser[1]);

            });
            Runner.DoStep("Navigate to Shift tab in Plant Setup page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
                Page.ShiftTabPage.ShiftTab.Click();
            });
            Runner.DoStep("Verify that 'Add Shift' button is not available for the user PEngineer", () =>
            {
                if (Page.ShiftTabPage.IsShiftAddButtonPresent)
                {
                    Assert.Fail("'Add Shift' button is present for user with level 3");
                }
            });            
            
        }

        [TestCategory(TestType.regression, "TC12_VerifyShiftForLevel4")]
        [TestCategory(TestType.functional, "TC12_VerifyShiftForLevel4")]
        [Test]
        public void TC12_VerifyShiftForLevel4()
        {
            Runner.DoStep("Logout the user ADMIN", () =>
            {
                Page.LoginPage.TopMainMenu.LogOut();
            });
            Runner.DoStep("Login as user PManager", () =>
            {
                Page.LoginPage.VerifyLogin(Users.PManagerUser[0], Users.PManagerUser[1]);
            });
            Runner.DoStep("Navigate to Shift tab in Plant Setup page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
                Page.ShiftTabPage.ShiftTab.Click();
            });
            Runner.DoStep("Verify that 'Add Shift' button is available for the user PManager", () =>
            {
                if (null == Page.ShiftTabPage.AddShift)
                {
                    Assert.Fail("Add shift button is not present with level 4 user");
                }
            });            
        }

        
        [TestCategory(TestType.functional, "TC13_AddShiftWith15mntsBreakTime")]
        [TestCategory(TestType.regression, "TC13_AddShiftWith15mntsBreakTime")]
        [Test]
        public void TC13_AddShiftWith15mntsBreakTime()
        {
            //Precondition: Delete existing shifts for wednesday
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Wednesday");
            Page.ShiftTabPage.DeleteAllShifts();

            Page.ShiftTabPage.AddShift.Click();

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Shift With 15 minutes Break");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("20:00");
            Runner.DoStep("Add a Shift with no break(s)", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });
            Runner.DoStep("Verify that the NO BREAKS FOUND message has arrived", () =>
            {
                if (null != Page.ShiftTabPage.NoBreakMessage("Wednesday", "Shift With 15 minutes Break"))
                {
                    if (!Page.ShiftTabPage.NoBreakMessage("Wednesday", "Shift With 15 minutes Break").BaseElement.InnerText
                        .Equals("No Breaks Found"))
                    {
                        Assert.Fail("No breaks found message is incorrect: Actual:{0}", Page.ShiftTabPage.NoBreakMessage("Wednesday", "Shift With 15 minutes Break").BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("No breaks found message is not displayed");
                }
            });            

            Page.ShiftTabPage.ShiftEditButton("Wednesday", "Shift With 15 minutes Break").Click();
            Page.ShiftTabPage.AddBreak.Click();      
            if ((Page.ShiftTabPage.BreakFromTime.FirstOrDefault().GetValue("value", false, "") != "15:00") || (Page.ShiftTabPage.BreakToTime.FirstOrDefault().GetValue("value", false, "") != "15:15"))
            {   
                Assert.Fail("Default break time is not correct");
            }

            Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText("14:00");
            Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText("14:15");
            Runner.DoStep("Add a 15 minutes break to the above shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });
            Runner.DoStep("Verify that the break has been added", () =>
            {
                if (null != Page.ShiftTabPage.ShiftTexts("Wednesday", "Shift With 15 minutes Break"))
                {
                    if (!Page.ShiftTabPage.ShiftTexts("Wednesday", "Shift With 15 minutes Break").Contains("14:00 to 14:15"))
                    {
                        Assert.Fail("Shift text for Wednesday is not correct , Actual:{0}", Page.ShiftTabPage.ShiftTexts("Wednesday", "Shift With 15 minutes Break").FirstOrDefault());
                    }
                }
                else
                {
                    Assert.Fail("Shift message is not displayed in shift page");
                }
            });            
        }

        [TestCategory(TestType.functional, "TC14_DefaultStartTimesOfSecondAndThirdShits")]
        [TestCategory(TestType.regression, "TC14_DefaultStartTimesOfSecondAndThirdShits")]
        [Test]
        public void TC14_DefaultStartTimesOfSecondAndThirdShits()
        {
            //Precondition: Delete existing shifts for wednesday
            HtmlControl temp = Page.ShiftTabPage.AddShift;
            //Page.ShiftTabPage.DeleteAllShifts("Tuesday");
            Page.ShiftTabPage.DeleteAllShifts();

            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });
            string addShiftUoM = Page.ShiftTabPage.TargetProdAddShiftUoM;

            CheckDaysSelectedStatus();

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Shift 101");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("00:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("08:00");
            Thread.Sleep(5000);
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.DeskTopMouseClick();
            });

            Thread.Sleep(5000);
            Runner.DoStep("Verify the creation of the Shift", () =>
            {
                if (null != Page.ShiftTabPage.ShiftAddMessage)
                {
                    string message = Page.ShiftTabPage.ShiftAddMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Shift created successfully"))
                    {
                        Assert.Fail("Incorrect message is displayed while adding shift , Expected: Shift created successfully ,Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Shift added message is not displayed");
                }
            });
            Thread.Sleep(2000);

            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });            

            CheckDaysSelectedStatus();

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Shift 102");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.Focus();
            Thread.Sleep(1000);          
            if (!Page.ShiftTabPage.ShiftFromTime.Value.Contains("08:00"))
            {
                Assert.Fail("Start time not aligned with end time of previous shift");
            }                        
            Thread.Sleep(5000);
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.DeskTopMouseClick();
            });

            Thread.Sleep(5000);
            Runner.DoStep("Verify the creation of the Shift", () =>
            {
                if (null != Page.ShiftTabPage.ShiftAddMessage)
                {
                    string message = Page.ShiftTabPage.ShiftAddMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Shift created successfully"))
                    {
                        Assert.Fail("Incorrect message is displayed while adding shift , Expected: Shift created successfully ,Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Shift added message is not displayed");
                }
            });
            Thread.Sleep(2000);

            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });

            CheckDaysSelectedStatus();

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftFromTime.Focus();
            Thread.Sleep(1000);   
            if (!Page.ShiftTabPage.ShiftFromTime.Value.Contains("16:00"))
            {
                Assert.Fail("Start time not aligned with end time of previous shift");
            }            

        }

        private void CheckDaysSelectedStatus()
        {
            Runner.DoStep("Verify that Sunday and Saturday are by default unselected", () =>
            {
                if (Page.ShiftTabPage.IsDaySelected(DayOfWeek.Sunday))
                {
                    Assert.Fail("By default Sunday should be inactive");
                }

                if (Page.ShiftTabPage.IsDaySelected(DayOfWeek.Saturday))
                {
                    Assert.Fail("By default Saturday should be inactive");
                }
            });

            Runner.DoStep("Verify that other days [weekdays] are by default selected", () =>
            {
                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Monday))
                {
                    Assert.Fail("By default Monday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Tuesday))
                {
                    Assert.Fail("By default Tuesday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Wednesday))
                {
                    Assert.Fail("By default Wednesday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Thursday))
                {
                    Assert.Fail("By default Thursday should be active");
                }

                if (!Page.ShiftTabPage.IsDaySelected(DayOfWeek.Friday))
                {
                    Assert.Fail("By default Friday should be active");
                }
            });
        } 
    }
}
