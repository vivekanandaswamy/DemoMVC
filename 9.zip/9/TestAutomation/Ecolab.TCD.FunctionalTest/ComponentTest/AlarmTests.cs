﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class AlarmTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");            
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);            
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }

        [TestCategory(TestType.functional, "TC01_Verify_AlarmData")]
        [TestCategory(TestType.regression, "TC01_Verify_AlarmData")]
        [Test, Description("Test Case 38713:RG Verify whether Alarm related information i.e displayed in the popup are same as in the database" +
			"Test Case 38700:RG Verify whether Active alarm flashes immediately" +
			"Test Case 38732:RG Verify whether Notification number gets cleared after alarm has viewed")]
        public void TC01_Verify_AlarmData()
        {
            Runner.DoStep("Click on alarm icon", () => Page.AlarmPage.AlarmIcon.Click());
            Thread.Sleep(3000);
            //Page.AlarmPage.AlarmIcon.Click();
            Runner.DoStep("Verify alarm message", () => 
            {
                string alarmMessage = Page.AlarmPage.AlarmTableGrid.MainTable.BaseElement.InnerText;
                if (alarmMessage.Contains("No Active Alarms"))
                {
                    Assert.True(true, "No Active Alarm lilsted");
                }
                else
                {
                    string alarmNumber = Page.AlarmPage.AlarmTableGrid.Rows.FirstOrDefault().GetColumnValues()[0];
                    Thread.Sleep(3000);
                    if (alarmNumber != "")
                    {
                        Assert.True(true, "Active Alarm record available and listed on the Alarm grid.");
                    }
                    else
                    {
                        Page.AlarmPage.Close.Click();
                        Assert.Fail("Active AlarmNumber are not reflected and Error message is not displayed. ");
                    }
                }
                Thread.Sleep(2000);
            });

            Runner.DoStep("Close alarm dialog", () => Page.AlarmPage.Close.Click());            
        }

        [TestCategory(TestType.functional, "TC02_Verify_Localization_Alarm")]
        [TestCategory(TestType.regression, "TC02_Verify_Localization_Alarm")]
        [Test, Description("Test Case 38739:RG Verify Localization")]
        public void TC02_Verify_Localization_Alarm()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("Deutsch", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.AlarmPage.AlarmIcon.Click();
            if(Page.AlarmPage.AlarmPopupTitle.BaseElement.InnerText != "")
            {
                PostLocalizationAlarm();
                Assert.Fail(string.Format("Incorrect Label is displayed in Alarms - {0} when localization changed to Detsuch, Expected - aktive Alarme", Page.AlarmPage.AlarmPopupTitle.BaseElement.InnerText));
            }
            PostLocalizationAlarm();
        }

        private void PostLocalizationAlarm()
        {
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("English US", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.AlarmPage.AlarmIcon.Click();
            if (Page.AlarmPage.AlarmPopupTitle.BaseElement.InnerText != "Active Alarms")
            {
                Assert.Fail(string.Format("Incorrect Label is displayed in Alarms - {0} when localization changed to English, Expected - Active Alarms", Page.AlarmPage.AlarmPopupTitle.BaseElement.InnerText));
            }
        }
    }
}
