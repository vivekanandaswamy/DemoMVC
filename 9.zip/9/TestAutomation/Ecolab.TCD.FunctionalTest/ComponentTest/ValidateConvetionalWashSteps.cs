﻿using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using NUnit.Framework;
using System;
using System.Data;
using System.Linq;
using System.Threading;
//using Ecolab.FunctionalTest.WebLocal;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class ValidateConvetionalWashSteps : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            try
            {
                Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
                Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                // Creating conventional Despenser,washer group and washer
                int controllerId1 = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxForConvWshrGrpFrmula");
                WasherGroup group1 = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialConvWasherGroupForWshrGrpFrmula");
                AppState.GetState<WasherState>().CreateConventionalWasher(group1.Id, group1.Id, "TrialConvWshrGrpFrmula", controllerId1, 1);
                WasherProgramSetup setup1 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(1, group1);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }

        [Test]
        public void TC01_VerifySaveForCVWashStep()
        {
            Telerik.ActiveBrowser.Refresh();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional").LastOrDefault().GetButtonControls()[4].ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional").LastOrDefault().GetButtonControls()[4].DeskTopMouseClick();
            Page.WasherGroupPage.TabFormula.DeskTopMouseClick();
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].GetButtonControls()[4].DeskTopMouseClick();
            int rowCount = Page.WasherGroupPage.WashStepsTableGrid.Rows.Count;
            Page.WasherGroupPage.BtnAddWashStep.Click();
            int s = Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetSelectControls().Count;
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetSelectControls()[0].SelectByPartialText("A/C", true);
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[0].SetText("90:40");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[1].TypeText("25");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[2].TypeText("15");
            Page.WasherGroupPage.BtnSaveAddFormula.DeskTopMouseClick();
            if (null == Page.WasherGroupPage.SuccessMessage)
            {
                Assert.Fail("Error message is not displayed.OR Failed to add the Formula");
            }
        }

        [Test]
        public void TC02_VerifyCancelForCVWashStep()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional").LastOrDefault().GetButtonControls()[4].ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional").LastOrDefault().GetButtonControls()[4].DeskTopMouseClick();
            Page.WasherGroupPage.TabFormula.DeskTopMouseClick();
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].GetButtonControls()[4].DeskTopMouseClick();

            int rowCount = Page.WasherGroupPage.WashStepsTableGrid.Rows.Count;
            //if (rowCount > 0)
            //{
            //    Page.WasherGroupPage.WashStepsTableGrid.Rows[0].GetEditables()[1].TypeText("12");
            //    Page.WasherGroupPage.WashStepsTableGrid.Rows[0].GetEditables()[2].TypeText("44");
            //    Thread.Sleep(3000);  Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[2].TypeText("14");
            //}
            //else
            //{
            //string a = Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].Cells[1].BaseElement.InnerText;
            Page.WasherGroupPage.BtnAddWashStep.Click();
            int s = Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetSelectControls().Count;
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetSelectControls()[0].SelectByPartialText("A/C", true);
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[0].SetText("10:40");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[1].TypeText("21");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[2].TypeText("14");
            string ha = Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].Cells[3].BaseElement.InnerText;
            //Page.WasherGroupPage.BtnSaveAddFormula.DeskTopMouseClick();
            //if (null == Page.WasherGroupPage.SuccessMessage)
            //{
            //    Assert.Fail("Error message is not displayed.OR Failed to add the Formula");
            //}
            //}
            Page.WasherGroupPage.BtnCancel.Click();
            Page.WasherGroupPage.BtnYesPopUpOnCancel.Click();
        }

        [Test]
        public void TC03_VerifySaveAndCloseForCVWashStep()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional").LastOrDefault().GetButtonControls()[4].ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("Conventional").LastOrDefault().GetButtonControls()[4].DeskTopMouseClick();
            Page.WasherGroupPage.TabFormula.DeskTopMouseClick();
            string formulaNumber = Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].Cells[2].BaseElement.InnerText;
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].GetButtonControls()[4].DeskTopMouseClick();
            int rowCount = Page.WasherGroupPage.WashStepsTableGrid.Rows.Count;
            Page.WasherGroupPage.BtnAddWashStep.Click();
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetSelectControls()[0].SelectByPartialText("A/C", true);
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[0].SetText("10:40");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[1].TypeText("21");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[2].TypeText("14");
            string washstep = Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].Cells[1].BaseElement.InnerText;
            Page.WasherGroupPage.BtnSaveAndClose.Click();
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.SelectedRows(formulaNumber)[0].GetButtonControls()[4].DeskTopMouseClick();
            //List<string> a = Page.WasherGroupPage.WashStepsTableGrid.GetColumnValues(2);
             if (Page.WasherGroupPage.WashStepsTableGrid.GetColumnValues(2).Contains(washstep))
            {
                Assert.Pass();
            }
            else
                Assert.Fail("Save And close not working properly");
        }

        [TestCategory(TestType.functional, "TC04_ChemicalReplaceVerification")]
        [TestCategory(TestType.regression, "TC04_ChemicalReplaceVerification")]
        [Test, Description("Replace chemicals from all formulas where it being used")]
        public void TC04_ChemicalReplaceVerification()
        {
            //Save something in Advanced tab of Dispenser
            Page.LoginPage.TopMainMenu.NavigateToDispenserSetupPage();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxForConvWshrGrpFrmula").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            //DispenserPage abc = new DispenserPage();
            //abc.VerifyAdvancedSaveAB();
            //abc.VerifyPumpsAndValvesSaveAB();
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.PostFlushTimeAB.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.PostFlushTimeAB.TypeText("37");
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();

            //Adding chemical in dispenser tab
            Page.ControllerSetupPage.PumpsValvesTab.Click();
            Page.ControllerPumpValvesPage.PumpsAndValvesTabGrid.Rows[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ControllerPumpValvesPage.ProductNameAB.SelectByPartialText("GENERIC BLEACH", true);
            Page.PumpsValvesPage.txtPumpCalibration.TypeText("160");
            Page.ControllerPumpValvesPage.SaveButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (!Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Device wasn't added successfully");
            }
            //adding washstep to the formula tab in washer group
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialConvWasherGroupForWshrGrpFrmula'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Page.WasherGroupFormulasPage.AddingFormula("Baby", "150"); 
            Page.WasherGroupFormulasPage.Save.Click();
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            int rowCount = Page.WasherGroupPage.WashStepsTableGrid.Rows.Count;
            Page.WasherGroupPage.BtnAddWashStep.Click();
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetSelectControls()[0].SelectByPartialText("A/C", true);
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[0].SetText("03:40");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[1].TypeText("25");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[2].TypeText("15");

            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetButtonControl().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetButtonControl().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.FormulasTabPage.SelectProduct.SelectByPartialText("GENERIC BLEACH", true);
            Page.FormulasTabPage.AddProduct.Click();
            Page.FormulasTabPage.Quantity.SetText("2");
            Page.FormulasTabPage.SaveProducts.Click();
            Thread.Sleep(2000);
            Page.WasherGroupPage.BtnSaveAddFormula.DeskTopMouseClick();
            Thread.Sleep(2000);

            //replacing the chemical name in plant setup
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.ChemicalsTab.Click();
            Page.ChemicalsTabPage.ChemicalsTabGrid.SelectedRows("GENERIC BLEACH")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ChemicalsTabPage.ChemicalsTabGrid.SelectedRows("GENERIC BLEACH")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ChemicalsTabPage.ChemicalThatReplaces.SelectByPartialText("APOLLO BUFFER", true);
            
            Page.ChemicalsTabPage.SaveSubstitute.Click();
            Thread.Sleep(2000);

            //verification point for replacing the chemical
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            if (Page.WasherGroupPage.WashStepsTableGrid.SelectedRows("GENERIC BLEACH").Count > 0)
            {
                Assert.Fail("chemical is not replaced successfully");
            }
            else if (Page.WasherGroupPage.WashStepsTableGrid.SelectedRows("APOLLO BUFFER").Count > 0)
            {
                Assert.IsTrue(true, "chemical is replaced successfully");
            }
            else
                Assert.Fail("chemical is not replaced successfully"); 
        }

        [TestCategory(TestType.functional, "TC05_PriceColumnVerification")]
        [TestCategory(TestType.regression, "TC05_PriceColumnVerification")]
        [Test, Description("Price Column, Which will be calculated based on customer price and total quantity")]
        public void TC05_PriceColumnVerification()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.ChemicalsTab.Click();
            Thread.Sleep(2000);
            Page.ChemicalsTabPage.ChemicalsTabGrid.SelectedRows("DELUXE DYE-BROWN")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            string pkgSize = Page.ChemicalsTabPage.ChemicalsTabGrid.SelectedRows("DELUXE DYE-BROWN")[0].Cells[5].BaseElement.InnerText;
            string[] result = pkgSize.Split(new string[] { "-", " " }, StringSplitOptions.RemoveEmptyEntries);
            int a = Convert.ToInt32(result[0]);
            int b = Convert.ToInt32(result[1]);
            string priceId = Page.ChemicalsTabPage.ChemicalsTabGrid.SelectedRows("DELUXE DYE-BROWN")[0].GetEditables().FirstOrDefault().Attributes[3].Value;
            decimal price = Convert.ToDecimal(GetAttributeValue(priceId));
            string chemical = "DELUXE DYE-BROWN";
            GetValueForPrice set1 = AppState.GetState<PlantState>().GetValueForPriceCalculation(chemical);
            int pkgwt = a * b;
            decimal y = price / pkgwt * set1.ValueBasedUOMID;
           
            //Save something in Advanced tab of Dispenser
            Page.LoginPage.TopMainMenu.NavigateToDispenserSetupPage();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxForConvWshrGrpFrmula").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            //DispenserPage abc = new DispenserPage();
            //abc.VerifyAdvancedSaveAB();
            //abc.VerifyPumpsAndValvesSaveAB();
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.PostFlushTimeAB.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.PostFlushTimeAB.TypeText("37");
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();

            //Adding chemical in dispenser tab
            Page.ControllerSetupPage.PumpsValvesTab.Click();
            Thread.Sleep(2000);
            Page.ControllerPumpValvesPage.PumpsAndValvesTabGrid.Rows[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ControllerPumpValvesPage.ProductNameAB.SelectByPartialText("DELUXE DYE-BROWN", true);
            Page.PumpsValvesPage.txtPumpCalibration.TypeText("160");
            Page.ControllerPumpValvesPage.SaveButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (!Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Device wasn't added successfully");
            }
            //adding washstep to the formula tab in washer group
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialConvWasherGroupForWshrGrpFrmula'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupFormulaTabelGrid.Rows[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);

            int rowCount = Page.WasherGroupPage.WashStepsTableGrid.Rows.Count;
            Page.WasherGroupPage.BtnAddWashStep.Click();
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetSelectControls()[0].SelectByPartialText("A/C", true);
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[0].SetText("03:40");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[1].TypeText("25");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetEditables()[2].TypeText("15");

            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetButtonControl().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WashStepsTableGrid.Rows[rowCount].GetButtonControl().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.FormulasTabPage.SelectProduct.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.AddProduct.Click();
            Page.FormulasTabPage.TotalQuantity.SetText("50");
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Tab);  
            Page.FormulasTabPage.GetPrice.Focus();
            decimal productPrice = Math.Floor( (y * 50)* 100) / 100;
            
            string id = Page.FormulasTabPage.GetPrice.Attributes[3].Value;
            decimal priceValue = Convert.ToDecimal(GetAttributeValue(id));
          
            if (productPrice != priceValue)
            {
                Assert.Fail("Price is not displaying correctly");
            }          

        }
        private string GetAttributeValue(string id)
        {
            return Telerik.Actions.InvokeScript("$('#"+id+"').val()");
        } 
    }
}
