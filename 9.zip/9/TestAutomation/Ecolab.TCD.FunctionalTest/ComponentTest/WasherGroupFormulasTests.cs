﻿using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Data;
using System.Linq;
using System.Threading;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class WasherGroupFormulasTests : TestBase
    {        

        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);

           // Creating conventional Dispenser,washer group and washer
            int controllerId1 = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxForConvWshrGrpFrmulas");
            WasherGroup group1 = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialConvWasherGroupForWshrGrpFrmulas");
            AppState.GetState<WasherState>().CreateConventionalWasher(group1.Id, group1.Id, "TrialConvWshrGrpFrmulas", controllerId1, 1);
            setup1 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(1, group1);

            // Creating Tunnel Dispenser,washer group and washer
            int controllerId2 = AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxForTunlWshrGrpFrmulas");
            WasherGroup group2 = AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialTunlWasherGroupForWshrGrpFrmulas");
            AppState.GetState<WasherState>().CreateTunnelWasher(group2.Id, "TrialTunlWshrGrpFrmulas", controllerId2);
            setup2 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(1, group2);


            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialConvWasherGroupForWshrGrpFrmulas'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            //Page.WasherGroupFormulasPage.AddWasherGroup.Click();
            //Thread.Sleep(2000);
            //Page.WasherGroupFormulasPage.WasherGroupsTableGrid.Rows[1].GetButtonControls()[4].DeskTopMouseClick();
            //Page.WasherGroupFormulasPage.AddingWasherGroup("4345", "ABCD");
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
        }

        WasherProgramSetup setup1, setup2;

        [TestCategory(TestType.functional, "TC01_VerifyDefaultValues_WasherGroupFormaulas")]
        [TestCategory(TestType.regression, "TC01_VerifyDefaultValues_WasherGroupFormaulas")]
        [Test, Description("Test Case 32967:RG Verify default values in Washer Group Formulas Tab ;")]
        public void TC01_VerifyDefaultValues_WasherGroupFormaulas()
        {
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.Number.Focus();
            if (Page.WasherGroupFormulasPage.Number.Text == "0")
            {
                Assert.Fail("Default value of Number is 0");
                //Assert.Fail("Default value of Number is not 0, displayed value is " + (Page.WasherGroupFormulasPage.Number.Text));
            }
            Page.FormulasTabPage.NominalLoadForConventional.Focus();
            if (Page.FormulasTabPage.NominalLoadForConventional.Text != "100")
            {
                Assert.Fail("Default value of NominalLoad is not 100, displayed value is " + (Page.WasherGroupFormulasPage.NominalLoad.BaseElement.GetAttribute("value").Value));
            }
            //if (Page.WasherGroupFormulasPage.LoadsPerMonth.Text != "0")
            //{
            //    Assert.Fail("Default value of LoadsPerMonth is not 0, displayed value is " + (Page.WasherGroupFormulasPage.LoadsPerMonth.Value));
            //}
            if (Page.WasherGroupFormulasPage.ExtraTime.IsVisible())
            {
                if (Page.WasherGroupFormulasPage.ExtraTime.Text != "30")
                {
                    Assert.Fail("Default value of ExtraTime is not 30, displayed value is " + (Page.WasherGroupFormulasPage.NominalLoad.BaseElement.GetAttribute("value").Value));
                }
            }            
            //Page.WasherGroupFormulasPage.BacktoFormula.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulaTab.Click();

        }

        [TestCategory(TestType.functional, "TC02_VerifyAddingFormula")]
        [TestCategory(TestType.regression, "TC02_VerifyAddingFormula")]
        [Test, Description("Test Case 32968:RG Verify Save functionality in Washer Group Formulas Tab ;")]
        public void TC02_VerifyAddingFormula()
        {
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);

            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddingFormula(randNumb.ToString(), "100", "0", "0");
            Page.WasherGroupFormulasPage.Save.Click();
            Thread.Sleep(3000);
            if (Page.WasherGroupFormulasPage.IsFormulaCreationSuccessMsgPresent)
            {
                string message = Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                }
            }
            else
            {
                Assert.Fail("Message is not displayed");
            }
            Page.WasherGroupFormulasPage.Cancel.Click();
            Thread.Sleep(1000);
            if (Page.WasherGroupFormulasPage.FormulasTableGrid.SelectedRows(randNumb.ToString()).Count == 0)
            {
                Assert.Fail("Formula is not added into grid after clicking on Save button");
            }      
            
        }

        [TestCategory(TestType.functional, "TC03_VerifyUpdatingFormula")]
        [TestCategory(TestType.regression, "TC03_VerifyUpdatingFormula")]
        [Test, Description("Test Case 32971:RG Verify Update functionality in Washer Group Formulas Tab ;")]
        public void TC03_VerifyUpdatingFormula()
        {
            string time1 = "03:45";
            string time2 = "01:67";

            AppState.GetState<WasherState>().AddWashStep(setup1, 1, RunTimeCalculation(time1));
            AppState.GetState<WasherState>().AddWashStep(setup1, 2, RunTimeCalculation(time2)); 
               
            Page.WasherGroupFormulasPage.FormulaTab.Click();

            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulasTableGrid.Rows[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(1500);
            Page.WasherGroupPage.WashStepsTableGrid.Rows[0].GetEditables()[2].TypeText("6");
            Page.WasherGroupPage.WashStepsTableGrid.Rows[1].GetEditables()[2].TypeText("7");
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.UpdatingFormula("100", "0", "0");
            if (null != Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg)
            {
                string message = Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"successfully"))
                {
                    //Page.WasherGroupFormulasPage.FormulaTab.Click();
                    Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                }
            }
            else
            {
                //Page.WasherGroupFormulasPage.FormulaTab.Click();
                Assert.Fail("Error message is not displayed");
            }
            //Page.WasherGroupFormulasPage.FormulaTab.Click();
        }

        [TestCategory(TestType.functional, "TC04_InLineEditingFormula")]
        //[TestCategory(TestType.regression, "TC04_InLineEditingFormula")]
        [Test, Description("Test Case 32970:RG Verify Inline Edit functionality in Washer Group Formulas Tab ;")]
        public void TC04_InLineEditingFormula()
        {
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            EcolabDataGridItems row = Page.WasherGroupFormulasPage.FormulasTableGrid.Rows[1];
            row.GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.InLineEditingFormula("80", "60", "0");
            Thread.Sleep(2000);
            row.GetButtonControls()[0].DeskTopMouseClick();
            Thread.Sleep(2000);
            if (null != Page.WasherGroupFormulasPage.divMessage)
            {
                if (!Page.WasherGroupFormulasPage.divMessage.BaseElement.InnerText.ToLower()
                    .Equals(@"formula updated successfully"))
                {
                    Page.WasherGroupFormulasPage.FormulaTab.Click();
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Page.WasherGroupFormulasPage.FormulaTab.Click();
                Assert.Fail("Error message is not displayed");
            }
            Page.WasherGroupFormulasPage.FormulaTab.Click();
        }

        [TestCategory(TestType.functional, "TC05_DeleteFormula")]
        [TestCategory(TestType.regression, "TC05_DeleteFormula")]
        [Test, Description("Test Case 32972:RG Verify Delete functionality in Washer Group Formulas Tab ;")]
        public void TC05_DeleteFormula()
        {
            //TC01_VerifyDefaultValues_WasherGroupFormaulas();

            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulasTableGrid.Rows[0].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            DialogHandler.NoButton.Click();
            Page.WasherGroupFormulasPage.FormulasTableGrid.Rows[0].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            DialogHandler.YesButton.Click();
            if (null != Page.WasherGroupFormulasPage.FormulaSuccessMessage)
            {
                if (!Page.WasherGroupFormulasPage.FormulaSuccessMessage.BaseElement.InnerText.ToLower()
                    .Contains(@"formula deleted successfully"))
                {
                    Page.WasherGroupFormulasPage.FormulaTab.Click();
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Page.WasherGroupFormulasPage.FormulaTab.Click();
                Assert.Fail("Error message is not displayed");
            }
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            //Thread.Sleep(2000);
            //Page.WasherGroupFormulasPage.BacktoWasherGroups.Click();
        }

        [TestCategory(TestType.functional, "TC06_VerifyFormulasLocalization")]
        //[TestCategory(TestType.regression, "TC06_VerifyFormulasLocalization")]
        [Test, Description("Test Case 34216:RG Verify the Localization criteria ;")]
        public void TC06_VerifyFormulasLocalization()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("Deutsch", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            //Page.WasherGroupFormulasPage.AddWasherGroup.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.WasherGroupsTableGrid.Rows[1].GetButtonControls()[4].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            if (Page.WasherGroupFormulasPage.FormulaTab.BaseElement.InnerText != "formules")
            {
                PostLocalizationStorageTanks();
                Assert.Fail(string.Format("Incorrert Tab name displayed in  - {0} when localization changed to Deutsch, Expected - formules", Page.WasherGroupFormulasPage.FormulaTab.BaseElement.InnerText));
            }
            PostLocalizationStorageTanks();
        }

        private void PostLocalizationStorageTanks()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("English US", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            //Page.WasherGroupFormulasPage.AddWasherGroup.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.WasherGroupsTableGrid.Rows[1].GetButtonControls()[4].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            if (Page.WasherGroupFormulasPage.FormulaTab.BaseElement.InnerText != "Formulas")
            {
                Assert.Fail(string.Format("Incorrert Tab name displayed in  - {0} when localization changed to Deutsch, Expected - formules", Page.WasherGroupFormulasPage.FormulaTab.BaseElement.InnerText));
            }
        }

        public int RunTimeCalculation(string runTime)
        {
            string[] MinSec = runTime.Split(':');
            return Convert.ToInt32(MinSec[0]) * 60 + Convert.ToInt32(MinSec[1]);
        }

        [TestCategory(TestType.functional, "TC07_VerifyCancelFormula_ConvWasher")]
        [TestCategory(TestType.regression, "TC07_VerifyCancelFormula_ConvWasher")]
        [Test, Description(" Verify Cancel button functionality in Conventional Washer Group Formulas Tab;")]
        public void TC07_VerifyCancelFormula_ConvWasher()
        {
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);
            Page.WasherGroupFormulasPage.AddingFormula(randNumb.ToString(), "101", "0", "0");
            Page.WasherGroupFormulasPage.Cancel.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.SaveNo.Click();
            Thread.Sleep(2000);
           if(!Page.WasherGroupFormulasPage.AddFormula.IsVisible())
            {
                Assert.Fail("Add Formuala button is not displaying after clicking on Cancel button");
            }
            else if(!Page.WasherGroupFormulasPage.IsFormulaTableGridPresent)
            {
                Assert.Fail("Formula grid is not displaying after clicking on Cancel button");
            }                    
        }

        [TestCategory(TestType.functional, "TC08_VerifySaveAndCloseFormula_ConvWasher")]
        [TestCategory(TestType.regression, "TC08_VerifySaveAndCloseFormula_ConvWasher")]
        [Test, Description(" Verify Save and Close button functionality in Conventional Washer Group Formulas Tab;")]
        public void TC08_VerifySaveAndCloseFormula_ConvWasher()
        {
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);
            Page.WasherGroupFormulasPage.AddingFormula(randNumb.ToString(), "101", "0", "0");
            Page.WasherGroupFormulasPage.SaveAndClose.Click();
            Thread.Sleep(3000);
            if (!Page.WasherGroupFormulasPage.AddFormula.IsVisible())
            {
                Assert.Fail("Add Formuala button is not displaying after clicking on Save and Close button");
            }
            else if (!Page.WasherGroupFormulasPage.IsFormulaTableGridPresent)
            {
                Assert.Fail("Formula grid is not displaying after clicking on Save and Close button");
            }
            else if (Page.WasherGroupFormulasPage.FormulasTableGrid.SelectedRows(randNumb.ToString()).Count == 0)
            {
                Assert.Fail("Formula is not added into grid after clicking on Save and Close button");
            }
        }

        [TestCategory(TestType.functional, "TC09_VerifyImportFormula_ConvWasher")]
        [TestCategory(TestType.regression, "TC09_VerifyImportFormula_ConvWasher")]
        [Test, Description(" Verify Import functionality in Conventional Washer Group Formulas Tab;")]
        public void TC09_VerifyImportFormula_ConvWasher()
        {
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.ImportFormula.Click();
            Thread.Sleep(2000);
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);
            Page.WasherGroupFormulasPage.ImportFormulasTableGrid.Rows[0].GetEditables()[0].Click();            
            Page.WasherGroupFormulasPage.ImportFormulasTableGrid.Rows[0].GetEditables()[1].SetText(randNumb.ToString());
            Page.WasherGroupFormulasPage.SaveFormula.Click();
            Thread.Sleep(3000);
            if (Page.WasherGroupFormulasPage.IsFormulaSuccessMessagePresent)
            {
                string message = Page.WasherGroupFormulasPage.FormulaSuccessMessage.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                }
            }
            else
            {
                Assert.Fail("Message is not displayed");
            }
            if (!Page.WasherGroupFormulasPage.IsFormulaTableGridPresent)
            {
                Assert.Fail("Formula grid is not displaying after clicking on Save button");
            }
            else if (Page.WasherGroupFormulasPage.FormulasTableGrid.SelectedRows(randNumb.ToString()).Count == 0)
            {
                Assert.Fail("Formula is not Imported into grid after clicking on Save button");
            }
            else if (!Page.WasherGroupFormulasPage.ImportFormula.IsVisible())
            {
                Assert.Fail("Import Formuala button is not displaying after clicking on Save button");
            }
           
        }
        [TestCategory(TestType.functional, "TC10_VerifyCancelFormula_TunlWasher")]
        [TestCategory(TestType.regression, "TC10_VerifyCancelFormula_TunlWasher")]
        [Test, Description(" Verify Cancel button functionality in Tunnel Washer Group Formulas Tab;")]
        public void TC10_VerifyCancelFormula_TunlWasher()
        {
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialTunlWasherGroupForWshrGrpFrmulas'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);
            Page.WasherGroupFormulasPage.AddingFormulaForTunnelWasher(randNumb.ToString(), "101", "0");
            Page.WasherGroupFormulasPage.Cancel.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.SaveNo.Click();
            Thread.Sleep(2000);
            if(!Page.WasherGroupFormulasPage.AddFormula.IsVisible())
            {
                Assert.Fail("Add Formuala button is not displaying after clicking on Cancel button");
            }
            else if(!Page.WasherGroupFormulasPage.IsFormulaTableGridPresent)
            {
                Assert.Fail("Formula grid is not displaying after clicking on Cancel button");
            }                    
        }

        [TestCategory(TestType.functional, "TC11_VerifySaveAndCloseFormula_TunlWasher")]
        [TestCategory(TestType.regression, "TC11_VerifySaveAndCloseFormula_TunlWasher")]
        [Test, Description(" Verify Save and Close button functionality in Tunnel Washer Group Formulas Tab;")]
        public void TC11_VerifySaveAndCloseFormula_TunlWasher()
        {
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialTunlWasherGroupForWshrGrpFrmulas'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
           
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);
            Page.WasherGroupFormulasPage.AddingFormulaForTunnelWasher(randNumb.ToString(), "101", "0");
            Page.WasherGroupFormulasPage.SaveAndClose.Click();
            Thread.Sleep(3000);
            if (!Page.WasherGroupFormulasPage.AddFormula.IsVisible())
            {
                Assert.Fail("Add Formuala button is not displaying after clicking on Save and Close button");
            }
            else if (!Page.WasherGroupFormulasPage.IsFormulaTableGridPresent)
            {
                Assert.Fail("Formula grid is not displaying after clicking on Save and Close button");
            }
            else if (Page.WasherGroupFormulasPage.FormulasTableGrid.SelectedRows(randNumb.ToString()).Count == 0)
            {
                Assert.Fail("Formula is not added into grid after clicking on Save and Close button");
            }
        }
        [TestCategory(TestType.functional, "TC12_VerifySaveFormula_TunlWasher")]
        [TestCategory(TestType.regression, "TC12_VerifySaveFormula_TunlWasher")]
        [Test, Description("Verify Save button functionality in Tunnel Washer Group Formulas Tab;")]
        //public void TC12_VerifySaveFormula_TunlWasher()
        //{
        //    Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
        //    Thread.Sleep(2000);
        //    int washerGroupNumber = 0;
        //    DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialTunlWasherGroupForWshrGrpFrmulas'");
        //    foreach (DataRow dr in myTable.Rows)
        //    {
        //        washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
        //    }
        //    Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
        //    Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();

        //    Random rand = new Random();
        //    int randNumb = rand.Next(1, 127);
        //    Page.WasherGroupFormulasPage.FormulaTab.Click();
        //    Thread.Sleep(2000);
        //    Page.WasherGroupFormulasPage.AddFormula.Click();
        //    Thread.Sleep(2000);
        //    Page.WasherGroupFormulasPage.AddingFormulaForTunnelWasher(randNumb.ToString(), "100", "0");
        //    Page.WasherGroupFormulasPage.Save.Click();
        //    Thread.Sleep(3000);
        //   if(Page.WasherGroupFormulasPage.IsFormulaCreationSuccessMsgPresent)
        //   {
        //       string message = Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.BaseElement.InnerText;
        //       if (!message.Contains(@"successfully"))
        //       {
        //           Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
        //       }
        //   }            
        //    else
        //    {
        //        Assert.Fail("Message is not displayed");
        //    }
        //    Page.WasherGroupFormulasPage.Cancel.Click();
        //    Thread.Sleep(1000);
        //    if (Page.WasherGroupFormulasPage.FormulasTableGrid.SelectedRows(randNumb.ToString()).Count == 0)
        //    {
        //        Assert.Fail("Formula is not added into grid after clicking on Save button");
        //    }   
        //}       
        public void TC12_VerifySaveFormula_TunlWasher()
        {
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialTunlWasherGroupForWshrGrpFrmulas'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            int formulaCount = Page.WasherGroupFormulasPage.FormulasTableGrid.Rows.Count;
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddingFormulaForTunnelWasher(randNumb.ToString(), "100", "0");
            Page.WasherGroupFormulasPage.Save.Click();
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            if (Page.WasherGroupFormulasPage.FormulasTableGrid.Rows.Count != formulaCount+1)
            {
                Assert.Fail("Formula was not added");
            }
            //Thread.Sleep(3000);
           //if(Page.WasherGroupFormulasPage.IsFormulaCreationSuccessMsgPresent)
           //{
           //    string message = Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.BaseElement.InnerText;
           //    if (!message.Contains(@"successfully"))
           //    {
           //        Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
           //    }
           //}            
           // else
           // {
           //     Assert.Fail("Message is not displayed");
           // }
           // Page.WasherGroupFormulasPage.Cancel.Click();
           // Thread.Sleep(1000);
           // if (Page.WasherGroupFormulasPage.FormulasTableGrid.SelectedRows(randNumb.ToString()).Count == 0)
           // {
           //     Assert.Fail("Formula is not added into grid after clicking on Save button");
           // }   
        }

        [TestCategory(TestType.functional, "TC13_VerifyImportFormula_TunlWasher")]
        [TestCategory(TestType.regression, "TC13_VerifyImportFormula_TunlWasher")]
        [Test, Description(" Verify Import functionality in Tunnel Washer Group Formulas Tab;")]
        public void TC13_VerifyImportFormula_TunlWasher()
        {
            Page.LoginPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialTunlWasherGroupForWshrGrpFrmulas'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();

            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.ImportFormula.Click();
            Thread.Sleep(2000);
            Random rand = new Random();
            int randNumb = rand.Next(1, 127);
            Page.WasherGroupFormulasPage.ImportFormulasTableGrid.Rows[0].GetEditables()[0].Click();
            Page.WasherGroupFormulasPage.ImportFormulasTableGrid.Rows[0].GetEditables()[1].SetText(randNumb.ToString());
            Page.WasherGroupFormulasPage.SaveFormula.Click();
            Thread.Sleep(3000);
            if (Page.WasherGroupFormulasPage.IsFormulaSuccessMessagePresent)
            {
                string message = Page.WasherGroupFormulasPage.FormulaSuccessMessage.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                }
            }
            else
            {
                Assert.Fail("Message is not displayed");
            }
            if (!Page.WasherGroupFormulasPage.IsFormulaTableGridPresent)
            {
                Assert.Fail("Formula grid is not displaying after clicking on Save button");
            }
            else if (Page.WasherGroupFormulasPage.FormulasTableGrid.SelectedRows(randNumb.ToString()).Count == 0)
            {
                Assert.Fail("Formula is not Imported into grid after clicking on Save button");
            }
            else if (!Page.WasherGroupFormulasPage.ImportFormula.IsVisible())
            {
                Assert.Fail("Import Formuala button is not displaying after clicking on Save button");
            }

        }

    }
}
