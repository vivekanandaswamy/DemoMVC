﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class PlantSetupMeterTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            AppState.GetState<MeterState>().DeleteAllMeters();            
        }

        /// <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC01_CreateMeter")]
        [TestCategory(TestType.regression, "TC01_CreateMeter")]
        [Test]
        public void TC01_CreateMeter()
        {
            //AppState.GetState<ControllerState>().CreateUtilityLogger("TrialUtilityLoggerForParentMaterDelete");
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CWGMeter();   
            NavigateToMetersPage();
            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText("Meter 1");
            //string parentMeterName = Page.MetersTabPage.MeterName.Value.TrimEnd();
            Page.MetersTabPage.UtilityType.SelectByText("Gas", Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText("WasherGroupForMeter", Timeout);            
            Page.MetersTabPage.MachineCompartment.SelectByIndex(1, Timeout);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            //Page.MetersTabPage.Controller.SelectByPartialText("MeterDispenser", true);            
            Runner.DoStep("Add a Meter without a parent", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.MeterSuccessMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }
            //Thread.Sleep(1000);
            //Page.LabourCostTabPage.BtnCancel.Click();
            Thread.Sleep(1000);

            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText("Meter 2");
            //string childMeterName = Page.MetersTabPage.MeterName.Value.TrimEnd();
            Page.MetersTabPage.UtilityType.SelectByText("Gas", Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText("WasherGroupForMeter", Timeout);            
            Page.MetersTabPage.MachineCompartment.SelectByIndex(1, Timeout);
            Page.MetersTabPage.Parent.SelectByPartialText("Meter 1", true);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            //Page.MetersTabPage.Controller.SelectByPartialText("MeterDispenser", true);            
            Runner.DoStep("Try adding a Meter with the same Machine / Compartement as above", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the error message while trying to add a Meter with the same Machine / Compartement as any othere's has arrived", () =>
            {
                if (!Page.MetersTabPage.ErrorMessage.BaseElement.InnerText.Contains("Maximum one meter with the same utility can be connected to one Machine / Compartement"))
                {
                    Assert.Fail("Error message when trying to add a meter with the same utility as another didn't show up");
                }
            });
            Page.MetersTabPage.AddMeterCancelButton.Click();

            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText("Meter 3");
            string sample = Page.MetersTabPage.MeterName.Value.TrimEnd();
            Page.MetersTabPage.UtilityType.SelectByText("Gas", Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText("WasherGroupForMeter", Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByIndex(2, Timeout);
            Page.MetersTabPage.Parent.SelectByPartialText("Meter 1", true);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            //Page.MetersTabPage.Controller.SelectByPartialText("MeterDispenser", true);
            Runner.DoStep("Add a Meter with a Parent", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });            
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.MeterSuccessMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }
            //if (!Page.MetersTabPage.SecondMeterAdditionMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            //{
            //    Assert.Fail("Meter not added successfully");
            //}
            //Page.LabourCostTabPage.BtnCancel.Click();                                    
        }

        [TestCategory(TestType.functional, "TC02_SaveAndCancelFunctionality")]
        [TestCategory(TestType.regression, "TC02_SaveAndCancelFunctionality")]
        [Test]
        public void TC02_SaveAndCancelFunctionality()
        {
            NavigateToMetersPage();
            Thread.Sleep(2000);
            int numOfWasherGroups = Page.MetersTabPage.MetersTabGrid.Rows.Count;            
            for (int i = 0; i <= numOfWasherGroups; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Meter 1"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].ScrollToVisible();
                    Thread.Sleep(1000);
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[7].DeskTopMouseClick();
                    //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D6);                                        
                    Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
                    Thread.Sleep(2000);
                    break;
                }
            }
            if (!Page.ChemicalsTabPage.MeterSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Save button functionality failed");
            }
            Thread.Sleep(1000);
            for (int i = 0; i <= numOfWasherGroups; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Meter 1"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].ScrollToVisible();
                    Thread.Sleep(1000);
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[7].DeskTopMouseClick();
                    //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D8);
                    Page.ChemicalsTabPage.CancelChange.DeskTopMouseClick();
                    DialogHandler.NoButton.Click();
                    break;
                }
            }
            Thread.Sleep(2000);
            for (int i = 0; i <= numOfWasherGroups; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Meter 1"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].ScrollToVisible();
                    Thread.Sleep(1000);
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[7].DeskTopMouseClick();
                    //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D8);
                    Page.ChemicalsTabPage.CancelChange.DeskTopMouseClick();
                    DialogHandler.YesButton.Click();
                    break;
                }
            }
            if (!Page.ChemicalsTabPage.MeterSuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Meter not updated successfully");
            }
        }

        [TestCategory(TestType.functional, "TC03_UpdateMeter")]
        [TestCategory(TestType.regression, "TC03_UpdateMeter")]
        [Test]
        public void TC03_UpdateMeter()
        {
            NavigateToMetersPage();
            Thread.Sleep(2000);
            int numOfWasherGroups = Page.MetersTabPage.MetersTabGrid.Rows.Count;
            for (int i = 0; i <= numOfWasherGroups; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Meter 1"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].ScrollToVisible();
                    Thread.Sleep(1000);
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                    break;
                }
            }
            Thread.Sleep(2000);
            //Page.MetersTabPage.MetersTabGrid.SelectedRows("Meter 3")[0].GetButtonControls().LastOrDefault().Click();
            Page.MetersTabPage.MeterNameToEdit.SetText("Meter 1 Edited");
            //Page.MetersTabPage.MeterNameToEdit.Value.TrimEnd();
            //string sampleRenamed = Page.MetersTabPage.MeterNameToEdit.Value.TrimStart();
            Runner.DoStep("Edit a Meter", () =>
            {
                Page.MetersTabPage.EditMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.MeterSuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Meter not updated successfully");
            }
            //Page.MetersTabPage.CancelAfterUpdate.Click();
        }

        [TestCategory(TestType.functional, "TC04_DeleteMeter")]
        [TestCategory(TestType.regression, "TC04_DeleteMeter")]
        [Test]
        public void TC04_DeleteMeter()
        {
            NavigateToMetersPage();            
            //Page.MetersTabPage.MetersTabGrid.SelectedRows("Meter 1")[0].GetButtonControls()[1].Click();
            Page.MetersTabPage.MetersTabGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Runner.DoStep("Try deleting Meter which has a Child mapped to it", () =>
            {
                Page.MetersTabPage.DeleteMeterYes.Click();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the error message that arrives while deleting a meter that has a child is displayed", () =>
            {
                if (!Page.MetersTabPage.SuccessfulMeterAdditionMessage.BaseElement.InnerText.Contains("Unable to delete parent Meter when child Meter exists."))
                {
                    Assert.Fail("Meter is deleted even when mapped to other meter as a parent");
                }
            });

            Thread.Sleep(2000);
            //Page.MetersTabPage.MetersTabGrid.SelectedRows("Meter 3 Edited")[0].GetButtonControls()[1].Click();
            Page.MetersTabPage.MetersTabGrid.Rows.LastOrDefault().GetButtonControls()[0].Click();
            Page.MetersTabPage.DeleteMeterYes.Click();
            Runner.DoStep("Delete the Meter that has a Parent", () =>
            {
                if (!Page.MetersTabPage.SuccessfulMeterAdditionMessage.BaseElement.InnerText.Contains("Meter Deleted Successfully"))
                {
                    Assert.Fail("Meter not deleted successfully");
                }
            });

            //Page.MetersTabPage.MetersTabGrid.SelectedRows("Meter 1")[0].GetButtonControls()[1].Click();
            Page.MetersTabPage.MetersTabGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Page.MetersTabPage.DeleteMeterYes.Click();
            Runner.DoStep("Delete a Meter whose child has been deleted", () =>
            {
                if (!Page.MetersTabPage.SuccessfulMeterAdditionMessage.BaseElement.InnerText.Contains("Meter Deleted Successfully"))
                {
                    Assert.Fail("Meter not deleted successfully");
                }
            });            
        }

        [TestCategory(TestType.functional, "TC05_MeterWithOptionalDispenser")]
        [TestCategory(TestType.regression, "TC05_MeterWithOptionalDispenser")]
        [Test]
        public void TC05_MeterWithOptionalDispenser()
        {
            NavigateToMetersPage();
            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText("Optional Dispenser Meter");
            //string parentMeterName = Page.MetersTabPage.MeterName.Value.TrimEnd();
            Page.MetersTabPage.UtilityType.SelectByIndex(1, Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByIndex(1, Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByIndex(1, Timeout);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            Page.MetersTabPage.AllowManualEntry.Focus();
            Page.MetersTabPage.AllowManualEntry.Click();              
            //Page.MetersTabPage.Controller.SelectByPartialText("TrialUtilityLoggerForParentMaterDelete", true);
            Runner.DoStep("Add a Meter without a parent", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.MeterSuccessMessage.BaseElement.InnerText.ToLower().Contains("meter added successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }
        }
                
        //private void NavigateToMetersPage()
        //{
        //    Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
        //    Thread.Sleep(2000);
        //    Page.PlantSetupPage.UtilityTab.Click();
        //    Thread.Sleep(2000);
        //    Page.PlantSetupPage.MeterTab.Click();
        //    KeyBoardSimulator.KeyPress(Keys.Tab);
        //    Thread.Sleep(2000);
        //}
    }
}
