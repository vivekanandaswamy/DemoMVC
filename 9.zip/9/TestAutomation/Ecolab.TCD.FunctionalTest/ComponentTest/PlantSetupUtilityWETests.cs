﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using Ecolab.Pages.CommonControls;

using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class PlantSetupUtilityWETests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }

        /// <summary>
        ///  TC 24710: Water & Energy Device Details:Verify SAVE functionality while Adding Water & Energy details
        /// </summary>
        [TestCategory(TestType.regression, "TC01_AddWaterEnergyDevice")]
        [Test, Description("TC 24710: Water & Energy Device Details:Verify SAVE functionality while Adding Water & Energy details ;")]
        public void TC01_AddWaterEnergyDevice()
        {
            //DeleteDataIfExisits();

            DateTime date = DateTime.Now.AddDays(+1);
            string inputDate = date.ToString("MM/dd/yyyy").Replace("-", "/");
            string addWE = "AddWE" + DateTime.Now;

            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyTab.DeskTopMouseClick();
            Thread.Sleep(2000);
            //Page.WETabPage.WaterEnergyTabGrid.SelectedRows("Heat Reclaimer")[0].GetButtonControls()[1].DeskTopMouseClick();
            //DialogHandler.ClickonOKButton();
            //Thread.Sleep(3000);
            Page.WETabPage.AddWaterEnergyDetailsButton.Click();
            Page.WETabPage.AddWaterEnergyDetailsButton.ScrollToVisible();
            Page.WETabPage.AddWaterEnergyDevice(addWE, "Hot Water Supply", "AquaHeater Smart", inputDate, "Create");
            Thread.Sleep(2000);
            //Assert.IsTrue(Page.WETabPage.VerifySuccessMsg.BaseElement.InnerText.Contains("Device Added Successfully"), "Success Message not matched");
            if (null != Page.WETabPage.VerifySuccessMsg)
            {
                string message = Page.WETabPage.VerifySuccessMsg.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"device added successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }

            string strFirstName = Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetColumnValues()[1].ToString();
            Page.WETabPage.AddWaterEnergyDetailsButton.Click();
            Page.WETabPage.AddWaterEnergyDetailsButton.ScrollToVisible();
            Page.WETabPage.VerifyFieldValidationMessage("Hot Water Supply", inputDate, "Create");
            Thread.Sleep(2000);
            //Assert.IsTrue(Page.WETabPage.VerifyLastNameFieldValidationMsg.BaseElement.InnerText.Contains("Device Name is required"), "Success Message not matched");

            if (null != Page.WETabPage.VerifyLastNameFieldValidationMsg)
            {
                string message = Page.WETabPage.VerifyLastNameFieldValidationMsg.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"device name is required"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }


            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyCancelButton.Click();

            string strCommand = "Select * from [TCD].[WaterAndEnergy]";
            DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("DeviceNumber =" + strFirstName);
            int count = foundRows.Length;
            if (count >= 1)
            {
                Assert.True(true, strFirstName + " WE Utility added successfully in DB");
            }
            else
            {
                Assert.Fail(strFirstName + " record not saved/ created in DB");
            }
        }

        /// <summary>
        ///  TC 25001: Water & Energy Device Details:Verify SAVE functionality while editing
        /// </summary>
        [TestCategory(TestType.regression, "TC02_UpdateWaterEnergyDevice")]
        [Test, Description("TC 25001: Water & Energy Device Details:Verify SAVE functionality while editing ;")]
        public void TC02_UpdateWaterEnergyDevice()
        {
            CreateBaseData();

            DateTime date = DateTime.Now.AddDays(+1);
            string inputDate = date.ToString("MM/dd/yyyy").Replace("-", "/");
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyTab.Click();
            Thread.Sleep(3000);
            //Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            //Page.WETabPage.VerifyUpdateCancelButton("Updated");
            Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WETabPage.UpdateWaterEnergyDevice("Updated");
            Thread.Sleep(2000);
            //Assert.True(Page.WETabPage.VerifySuccessMsg.BaseElement.InnerText.Contains("Device Updated Successfully"), "Success Message not matched");
            if (null != Page.WETabPage.VerifySuccessMsg)
            {
                string message = Page.WETabPage.VerifySuccessMsg.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"device updated successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
        }

        [TestCategory(TestType.regression, "TC03_SaveAndCancelFunctionality")]
        [Test]
        public void TC03_SaveAndCancelFunctionality()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyTab.Click();
            Thread.Sleep(2000);
            //Page.WETabPage.DeviceName.Click();
            Page.WETabPage.DeviceName.DeskTopMouseClick();
            //Page.WETabPage.WaterEnergyTabGridRoleBased.Rows[0].GetEditables()[0].SetText("as");
            KeyBoardSimulator.KeyDown(Keys.Control);
            KeyBoardSimulator.KeyPress(Keys.A);
            KeyBoardSimulator.KeyUp(Keys.Control);
            KeyBoardSimulator.KeyPress(Keys.Delete);
            KeyBoardSimulator.KeyPress(Keys.A);
            Thread.Sleep(1000);
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Save functionality failed");
            }

            Page.WETabPage.DeviceName.DeskTopMouseClick();
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.B);
            Thread.Sleep(1000);
            Page.LabourCostTabPage.BtnCancel.Click();
            DialogHandler.YesButton.DeskTopMouseClick();
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Cancel functionality failed");
            }
        }

        /// <summary>
        ///  TC 24720: Water & Energy Device Details:Verify Inline editing of a row
        /// </summary>
        //[TestCategory(TestType.regression, "TC04_EditInLineWaterEnergyDevice")]
        [Test, Description("TC 24720: Water & Energy Device Details:Verify Inline editing of a row ;")]
        public void TC04_EditInLineWaterEnergyDevice()
        {
            CreateBaseData();

            DateTime date = DateTime.Now;
            string inputDate = date.ToString("MM/dd/yyyy").Replace("-", "/");
            DateTime nextDate = DateTime.Now.AddDays(+2);
            string inputnextDate = nextDate.ToString("MM/dd/yyyy").Replace("-", "/");
            string inlineEdit = "InLineWE" + DateTime.Now;

            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.WETabPage.WaterEnergyTab.Click();

            Thread.Sleep(3000);
            Page.WETabPage.WaterEnergyTabGrid.SelectedRows("Heat Reclaimer")[0].GetButtonControls()[0].DeskTopMouseClick();
            Page.WETabPage.InlineEditing(inlineEdit, inputnextDate);
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.WETabPage.WaterEnergyTabGrid.SelectedRows("Heat Reclaimer")[0].GetButtonControls()[0].DeskTopMouseClick();
            Thread.Sleep(3000);

            if (null != Page.WETabPage.VerifySuccessMsg)
            {
                string message = Page.WETabPage.VerifySuccessMsg.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"device updated successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
        }

        /// <summary>
        ///  TC 24721: Water & Energy Device Details:Verify UPDATE/CANCEL gets displayed only when user modifies any cell in a row
        /// </summary>
        //[TestCategory(TestType.regression, "TC05_VerifyInlineEditingButtons")]
        [Test, Description("TC 24721: Water & Energy Device Details:Verify UPDATE/CANCEL gets displayed only when user modifies any cell in a row ;")]
        public void TC05_VerifyInlineEditingButtons()
        {
            CreateBaseData();

            DateTime nextDate = DateTime.Now.AddDays(+2);
            string inputnextDate = nextDate.ToString("MM/dd/yyyy").Replace("-", "/");
            string inlineWE = "InLineWE" + DateTime.Now;

            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.WETabPage.WaterEnergyTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Thread.Sleep(2000);
            Page.WETabPage.InlineEditing(inlineWE, inputnextDate);
            Telerik.ActiveBrowser.RefreshDomTree();
            Thread.Sleep(2000);
            Assert.True(Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls()[0].IsEnabled, "InLineEdititng Update button not visible");
            Assert.True(Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls()[1].IsEnabled, "InLineEdititng Cancel button not visible");
            Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls()[1].Click();
        }

        /// <summary>
        ///  TC 24717: Water & Energy Device Details:Verify DELETE button/icon
        /// </summary>
        [TestCategory(TestType.regression, "TC06_DeleteWaterEnergyDevice")]
        [Test, Description("TC 24717: Water & Energy Device Details:Verify DELETE button/icon ;")]
        public void TC06_DeleteWaterEnergyDevice()
        {
            //CreateBaseData();

            //DateTime nextDate = DateTime.Now.AddDays(+2);
            //string inputnextDate = nextDate.ToString("MM/dd/yyyy").Replace("-", "/");
            //Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            //Page.PlantSetupPage.UtilityTab.Click();
            //Page.WETabPage.WaterEnergyTab.Click();
            //Thread.Sleep(3000);
            //string strFirstName = Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetColumnValues()[1].ToString();
            //Page.WETabPage.WaterEnergyTabGrid.SelectedRows(strFirstName).FirstOrDefault().GetButtonControls()[1].Click();
            //DialogHandler.FormulaNoButton.Click();
            ////Page.WETabPage.ClickonCancelPreferencesButton();
            //Assert.True(Page.WETabPage.WaterEnergyTabGrid.GetRow(strFirstName) != null, "User deleted on clicking cancel in delete confirmation popup");
            //Page.WETabPage.WaterEnergyTabGrid.SelectedRows(strFirstName).FirstOrDefault().GetButtonControls()[1].Click();
            //DialogHandler.FormulaYesButton.Click();
            ////Page.WETabPage.ClickonOkPreferencesButton();
            //Thread.Sleep(2000);
            //Assert.True(Page.WETabPage.VerifySuccessMsg.BaseElement.InnerText.Contains("Device Deleted Successfully"), "Success Message not matched");

            //string strCommand = "Select * from [TCD].[WaterAndEnergy] Where [DeviceNumber] = '" + strFirstName + "'" + " AND [Is_Deleted] = 1";
            //DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("DeviceNumber = " + strFirstName);
            //int count = foundRows.Length;
            //if (count >= 1)
            //{
            //    Assert.True(true, strFirstName + " WE Utility deleted successfully in DB");
            //}
            //else
            //{
            //    Assert.Fail(strFirstName + " record not deleted");
            //}
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyTab.Click();
            Thread.Sleep(3000);
            //string name = Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetEditableControls()[1].BaseElement.ChildNodes[0].Attributes[5].Value;
            //Thread.Sleep(2000);
            //int NumnerOfRows = Page.WETabPage.WaterEnergyTabGrid.Rows.Count();
            //for (int i = 1; i < NumnerOfRows; i++)
            //{
            //    if (Page.WETabPage.WaterEnergyTabGrid.Rows[i].GetEditableControls()[0].BaseElement.ChildNodes[0].Attributes[4].Value.Contains("WET Device 1"))
            //    {
            //        Page.WETabPage.WaterEnergyTabGrid.Rows[i].ScrollToVisible();
            //        Thread.Sleep(1000);
            //        Page.WETabPage.WaterEnergyTabGrid.Rows[i].GetButtonControls()[0].Click();
            //    }
            //}
            Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().Click();
            Thread.Sleep(1000);
            DialogHandler.FormulaYesButton.Click();
            Thread.Sleep(2000);
            if (null != Page.ChemicalsTabPage.UpdateSuccessMessage)
            {
                string message = Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"device deleted successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
        }

        /// <summary>
        /// Ts the C06_ user roles_ edit.
        /// </summary>
        //[TestCategory(TestType.regression, "TC07_UserRoles_Edit")]
        [Test, Description("Ts the C06_ user roles_ edit. ;")]
        public void TC07_UserRoles_Edit()
        {
            CreateBaseData();
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]);
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.WaterEnergyTabGrid.Rows.FirstOrDefault().GetButtonControls()[2].Click();
            Page.WETabPage.UpdateWaterEnergyDevice("UserRoleTest");
            Thread.Sleep(2000);
            Assert.True(Page.WETabPage.VerifySuccessMsg.BaseElement.InnerText.ToLower().Contains("device updated successfully"), "Success Message not matched");
        }

        /// <summary>
        /// Ts the C06_ user roles_ edit.
        /// </summary>
        //[TestCategory(TestType.regression, "TC08_UserRoles_View")]
        //[Test, Description("Ts the C06_ user roles_ edit. ;")]
        //public void TC08_UserRoles_View()
        //{
        //    CreateBaseData();
        //    Page.PlantSetupPage.TopMainMenu.LogOut();
        //    Page.LoginPage.VerifyLogin(Users.TMBasicUser[0], Users.TMBasicUser[1]);
        //    Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
        //    Thread.Sleep(2000);
        //    Page.PlantSetupPage.UtilityTab.Click();
        //    Thread.Sleep(2000);
        //    Page.WETabPage.WaterEnergyTab.Click();
        //    Thread.Sleep(2000);
        //    int nActionButtons = Page.WETabPage.WaterEnergyTabGridRoleBased.Rows.FirstOrDefault().GetButtonControls().Count;
        //    if (nActionButtons > 1)
        //    {
        //        Page.PlantSetupPage.TopMainMenu.LogOut();
        //        Assert.Fail("Logged in as User Role 6, but found edit, update and deleted button in Water & Energy table");
        //    }
        //    Thread.Sleep(2000);
        //    HtmlControl CtrlDeviceType;
        //    Page.WETabPage.WaterEnergyTabGridRoleBased.Rows.FirstOrDefault().GetButtonControls()[0].Click();
        //    try
        //    {
        //        CtrlDeviceType = Page.WETabPage.DeviceType;
        //        if (CtrlDeviceType != null)
        //        {
        //            Page.WETabPage.Cancel.Click();
        //            Page.PlantSetupPage.TopMainMenu.LogOut();
        //            Assert.Fail("Logged in as User Role 6, but found Device Type as Editable Field");
        //        }
        //    }
        //    catch
        //    {
        //        Page.WETabPage.Cancel.Click();
        //        Page.PlantSetupPage.TopMainMenu.LogOut();
        //    }
        //}

        [TestCategory(TestType.regression, "TC09_UpdateUtilityAndSaveFunctionality")]
        [Test]
        public void TC09_UpdateUtilityAndSaveFunctionality()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.WETabPage.ColdType.DeskTopMouseClick();
            Thread.Sleep(1000);
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D4);
            Page.WETabPage.HotType.DeskTopMouseClick();
            Thread.Sleep(1000);
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D5);
            Page.ControllerAdvancedSetupPage.Save.Click();
            if (!Page.WETabPage.UpdationSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Save functionality failed");
            }
        }

        [TestCategory(TestType.regression, "TC10_UtilityTabCancelFunctionality")]
        [Test]
        public void TC10_UtilityTabCancelFunctionality()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(1000);
            Page.WETabPage.ColdType.DeskTopMouseClick();
            KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D9);
            Thread.Sleep(1000);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //Page.WETabPage.HotType.DeskTopMouseClick();
            //Thread.Sleep(1000);
            //KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            //KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D9);
            Page.LabourCostTabPage.BtnCancel.DeskTopMouseClick();
            Thread.Sleep(1000);
            DialogHandler.YesButton.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.WETabPage.ColdType.Focus();
            if (Page.WETabPage.ColdType.Value != "9")
            {
                Assert.Fail("Cancel functionality failed");
            }
        }

        [TestCategory(TestType.regression, "TC11_UtilityProperties")]
        [Test]
        public void TC11_UtilityProperties()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.SteamYes.Click();
            Thread.Sleep(4000);
            Page.WETabPage.SteamNo.DeskTopMouseClick();
            Page.WETabPage.BoilerType.Click();
            Thread.Sleep(2000);
            Page.WETabPage.BoilerOption1.Click();
            Thread.Sleep(2000);
            Page.UtilitySetupPage.TxtSteamPercentage.Click();
            Page.UtilitySetupPage.TxtSteamPercentage.TypeText("");
            Page.UtilitySetupPage.TxtBoilerPercentage.Click();
            Page.UtilitySetupPage.TxtBoilerPercentage.TypeText("");
            Page.UtilitySetupPage.TxtStackPercentage.Click();
            Page.UtilitySetupPage.TxtStackPercentage.TypeText("");
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(1000);
            string steamErrorMessage = Page.WETabPage.SteamError.BaseElement.InnerText;
            string boilerErrorMessage = Page.WETabPage.BoilerError.BaseElement.InnerText;
            string stackErrorMessage = Page.WETabPage.StackError.BaseElement.InnerText;
            if (!((steamErrorMessage.Contains("Please enter the Steam Percentage")) && (boilerErrorMessage.Contains("Please enter the Boiler Percentage")) && (stackErrorMessage.Contains("Please enter the Stack Percentage"))))
            {
                Assert.Fail("Incorrect error message found");
            }
            Thread.Sleep(2000);
            Page.UtilitySetupPage.TxtSteamPercentage.Click();   
            Page.UtilitySetupPage.TxtSteamPercentage.TypeText("0");
            Page.UtilitySetupPage.TxtBoilerPercentage.Click();
            Page.UtilitySetupPage.TxtBoilerPercentage.TypeText("0");
            Page.UtilitySetupPage.TxtStackPercentage.Click();   
            Page.UtilitySetupPage.TxtStackPercentage.TypeText("0");
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(1000);
            if (!Page.UtilitySetupPage.SuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Details should have been saved with the default values");
            }
        }

        [TestCategory(TestType.regression, "TC12_VerifyEvaporationFactor")]
        [Test]
        public void TC12_VerifyEvaporationFactor()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.UtilitySetupPage.EvaporationFactor.TypeText("");
            Page.WETabPage.SteamYes.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WETabPage.SteamNo.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.Save.Click();
            if (!Page.UtilitySetupPage.SuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Details should have been saved without any value for 'Evaporation factor'");
            }
            Thread.Sleep(2000);
            Page.UtilitySetupPage.EvaporationFactor.TypeText("0");
            Page.WETabPage.SteamYes.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WETabPage.SteamNo.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.Save.Click();
            if (!Page.UtilitySetupPage.SuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Details should have been saved with 'Evaporation factor' value being zero");
            }
        }

        private void CreateBaseData()
        {
            DateTime date = DateTime.Now.AddDays(+1);
            string inputDate = date.ToString("MM/dd/yyyy").Replace("-", "/");
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.WETabPage.WaterEnergyTab.Click();
            Thread.Sleep(2000);
            List<Pages.CommonControls.EcolabDataGridItems> rows = Page.WETabPage.WaterEnergyTabGrid.SelectedRows("Heat Reclaimer");
            if (null != rows && rows.Count <= 0)
            {
                Page.WETabPage.AddWaterEnergyDetailsButton.Click();
                Page.WETabPage.AddWaterEnergyDetailsButton.ScrollToVisible();
                Page.WETabPage.AddWaterEnergyDevice("AddWE", "Heat Recovery", "Energy Optimizer", inputDate, "Create");
            }

        }

        private void DeleteDataIfExisits()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Page.WETabPage.WaterEnergyTab.Click();
            List<Pages.CommonControls.EcolabDataGridItems> rows = Page.WETabPage.WaterEnergyTabGrid.SelectedRows("AddWE");
            if (null != rows && rows.Count >= 0)
            {
                rows.FirstOrDefault().GetButtonControls()[1].DeskTopMouseClick();
                DialogHandler.FormulaYesButton.Click();
            }

            rows = Page.WETabPage.WaterEnergyTabGrid.SelectedRows("Heat Reclaimer");
            if (null != rows && rows.Count >= 0)
            {
                rows.FirstOrDefault().GetButtonControls()[1].DeskTopMouseClick();
                DialogHandler.FormulaYesButton.Click();
            }
        }
    }
}
