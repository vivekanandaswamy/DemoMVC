﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.TestTemplates;
using Ecolab.CommonUtilityPlugin;
using Ecolab.Pages.CommonControls;
using Ecolab.TelerikPlugin;
using NUnit.Core;
using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.ComponentTest
{
    public class PlantSetupContactsTests : TestBase
    {
        bool verifyAssert = false;
        private static string[] addContactsData = new string[] { "Mr", "Dirk", "Brabanter", "Administrator", "Dirk@ecolab.com", "123456123", "123456789", "123456789" };
        private static string[] updateContactsData = new string[] { "Ms", "Darshini", "Vatsala", "Administrator", "Darsh@ecolab.com", "123456123", "123456123", "123456123" };
        private static string[] cancelContactsData = new string[] { "Mr", "Dirk", "Brabanter", "Administrator", "Dirk@ecolab.com", "789456123", "789456123", "789456123" };
        private static string[] saveData = new string[] { "Ms", "Becky", "Parsons", "Administrator", "becky@ecolab.com", "789456123", "789456123", "789456123" };

        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }

        [TestCategory(TestType.bvt, "TC01_VerifyAddContactFunctionality")]
        [TestCategory(TestType.functional, "TC01_VerifyAddContactFunctionality")]
        [TestCategory(TestType.regression, "TC01_VerifyAddContactFunctionality")]
        [Test, Description("Test case 18693: RG 18041 Plant Setup Contacts Page Verify Add Contact Functionality ;")]
        public void TC01_VerifyAddContactFunctionality()
        {
            Runner.DoStep("Goto PlantSetup page", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
            Runner.DoStep("Click on Contacts tab", () => Page.PlantSetupPage.ContactsTab.Click());
            Assert.True(Page.ContactsTabPage.AddContacts.IsVisible(), "AddContacts button not found");
            Runner.DoStep("Click on 'Add Contact' button", () => Page.ContactsTabPage.AddContacts.Click());
            Telerik.ActiveBrowser.RefreshDomTree();
            Runner.DoStep("Enter necessary contact details", () => Page.ContactsTabPage.AddContactsDetails(addContactsData));
            Thread.Sleep(2000);
            if (null != Page.ContactsTabPage.ErrorMsg)
            {
                if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText.ToLower().Contains("contact added successfully"))
                {
                    string mesg = Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText;
                    Assert.Fail("Incorrect error message is displayed,Expected: Contact added Successfully" + " but Actual:" + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            
            string strCommand = "Select * from TCD.PlantContact where ContactEMail='" + addContactsData[4].Trim() + "' and IS_Deleted =" + '0';
            DataSet ds = DBValidation.GetData(strCommand);
            if (ds.Tables[0].Rows.Count >= 0)
            {
                Assert.True(true, addContactsData[1] + " " + addContactsData[2] + " Contact details added successfully in DB");
            }
            else
            {
                Assert.Fail(addContactsData[1] + " " + addContactsData[2] + " User contact details not found in DB");
            }

            //if (Page.ContactsTabPage.ContactsTabGrid.Rows.Count > 0)
            //{
            //    for (int i = 0; i <= Page.ContactsTabPage.ContactsTabGrid.Rows.Count - 1; i++)
            //    {
            //        if (Page.ContactsTabPage.ContactsTabGrid.Rows[i].GetColumnValues()[4].ToString() == addContactsData[5])
            //        {
            //            verifyAssert = true;
            //            Assert.True(true, "Contacts details not found in the existing grid page");
            //            string strCommand = "Select * from TCD.PlantContact where ContactEMail='" + addContactsData[4].Trim() + "' and IS_Deleted =" + '0';
            //            DataSet ds = DBValidation.GetData(strCommand);
            //            if (ds.Tables[0].Rows.Count >= 0)
            //            {
            //                Assert.True(true, addContactsData[1] + " " + addContactsData[2] + " Contact details added successfully in DB");
            //            }
            //            else
            //            {
            //                Assert.Fail(addContactsData[1] + " " + addContactsData[2] +" User contact details not found in DB");
            //            }
            //            break;
            //        }
            //    }
            //    if (verifyAssert == false)
            //    {
            //        Assert.Fail("Contacts details not found in the existing grid page");
            //    }
            //}
           
            //{
            //    Assert.Fail("Contacts details grid is empty.Expected data in contacts grid");
            //}

        }
      
        //[TestCategory(TestType.bvt, "TC02_VerifyCancelContactFunctionality")]
        //[TestCategory(TestType.regression, "TC02_VerifyCancelContactFunctionality")]
        //[Test, Description("Test case 20432: RG 18041 Plant Setup Contacts Page Verify Cancel button functionality while adding new contact ;")]
        //public void TC02_VerifyCancelContactFunctionality()
        //{
        //    Runner.DoStep("Goto PlantSetup page", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
        //    Runner.DoStep("Click on Contacts tab", () => Page.PlantSetupPage.ContactsTab.Click());
        //    Runner.DoStep("Click on 'Add Contact' button", () => Page.ContactsTabPage.AddContactButton.Click());
        //    Telerik.ActiveBrowser.RefreshDomTree();
        //    Runner.DoStep("Click on Cancel button", ()=> Page.ContactsTabPage.CancelAddContactDetails(cancelContactsData));
        //    Runner.DoStep("Goto PlantSetup page", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
        //    Runner.DoStep("Click on Contacts tab", () => Page.PlantSetupPage.ContactsTab.Click());
        //    if (Page.ContactsTabPage.ContactsTabGrid.Rows.Count > 0)
        //    {
        //        for (int i = 0; i <= Page.ContactsTabPage.ContactsTabGrid.Rows.Count - 1; i++)
        //        {
        //            if (Page.ContactsTabPage.ContactsTabGrid.Rows[i].GetColumnValues()[3].ToString() == cancelContactsData[5])
        //            {
        //                Assert.Fail("Contact added on cancel button click event.");
        //            }
        //        }
        //    }
        //    else
        //    {
        //        Assert.Fail("Contacts details not found in the existing grid table");
        //    }
        //}

        [TestCategory(TestType.bvt, "TC03_VerifyUpdateContactFunctionality")]
        [TestCategory(TestType.regression, "TC03_VerifyUpdateContactFunctionality")]
        [Test, Description("Test case 20434: RG 18041 Plant Setup Contacts Page Verify Edit Conatct functionality ;")]
        public void TC03_VerifyUpdateContactFunctionality()
        {                                 
            //Runner.DoStep("Change the respective values in each field", ()=> 
            //{
                //FindRowAndPerform(updateContactsData[5],2, () => 
                //{                
                //    Page.ContactsTabPage.UpdateContactDetails(updateContactsData);
                //    if (null != Page.ContactsTabPage.ErrorMsg)
                //    {
                //        if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText
                //            .Equals(@"Contact updated Successfully"))
                //        {
                //            Assert.Fail("Incorrect error message is displayed,Expected: Contact updated Successfully"
                //                            + " but Actual:" + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                //        }
                //    }
                //    else
                //    {
                //        Assert.Fail("Error message is not displayed");
                //    }
                //});
            //});     
            Page.ContactsTabPage.ContactsTabGrid.SelectedRows("brabanter, dirk")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.ContactsTabPage.UpdateTitle.SelectByIndex(2, Timeout);
            Page.ContactsTabPage.UpdateTitle.SelectByIndex(1, Timeout);
            Page.ContactsTabPage.UpdateFaxNumber.TypeText("47656670");
            Page.ContactsTabPage.UpdateSave.Click();
            Thread.Sleep(2000);
            if (null != Page.ChemicalsTabPage.UpdateSuccessMessage)
            {
                if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower()
                    .Equals(@"contact updated successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed,Expected: Contact updated Successfully"
                                    + " but Actual:" + Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            //string strCommand = "Select * from TCD.PlantContact where ContactEMail='" + updateContactsData[4].Trim() + "' and IS_Deleted =" + '0';
            //DataSet ds = DBValidation.GetData(strCommand);
            //if (ds.Tables[0].Rows.Count >= 0)
            //{
            //    Assert.True(true, updateContactsData[1] + " " + updateContactsData[2] + " Contact details updated successfully in DB");
            //}
           
            //{
            //    Assert.Fail(updateContactsData[1] + " " + updateContactsData[2] + " User Contact details not updated in DB");
            //}
                

            //if (verifyAssert == false)
            //{
            //    Assert.Fail("Contacts details not found in the existing grid table");
            //}                       
        }

        [TestCategory(TestType.bvt, "TC04_VerifyInlineEditContactFunctionality")]
        //[TestCategory(TestType.regression, "TC04_VerifyInlineEditContactFunctionality")]
        [Test, Description("Test case 25443: RG 18041 Plant Setup Contacts Page Verify Update button while performing inline editing ;")]
        public void TC04_VerifyInlineEditContactFunctionality()
        {            
            Thread.Sleep(2000);
            FindRowAndPerform(addContactsData[5], 0, () =>
            {
                Page.ContactsTabPage.EditUpdateInlineContactDetails(addContactsData);
                //myRow.GetButtonControls()[0].Click();

            }).GetButtonControls()[0].Click();

            if (null != Page.ContactsTabPage.ErrorMsg)
            {
                string message = Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText;
                if (!message.ToLower().Contains(@"Successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed,Expected: Contact updated Successfully"
                                    + " but Actual:" + message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }

            if (verifyAssert == false)
            {
                Assert.Fail("Contacts details not found in the existing grid table");
            }
        }
      
        [TestCategory(TestType.bvt, "TC05_VerifyDeleteContactFunctionality")]
        [TestCategory(TestType.regression, "TC05_VerifyDeleteContactFunctionality")]
        [Test, Description("Test case 20433: RG 18041 Plant Setup Contacts Page Verify Delete Contact functionality ;")]
        public void TC05_VerifyDeleteContactFunctionality()
        {                                  
            Page.ContactsTabPage.ContactsTabGrid.SelectedRows("brabanter, dirk")[0].GetButtonControls()[0].DeskTopMouseClick();
            Thread.Sleep(1000);
            DialogHandler.FormulaYesButton.Click();
            Thread.Sleep(2000);
            if (null != Page.ChemicalsTabPage.UpdateSuccessMessage)
            {
                if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower()
                    .Equals(@"contact deleted successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed,Expected: Contact deleted Successfully"
                                    + " but Actual:" + Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }

        }


        [TestCategory(TestType.regression, "TC06_SavetFunctionality")]
        [Test]
        public void TC06_SavetFunctionality()
        {
            Runner.DoStep("Goto PlantSetup page", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
            Runner.DoStep("Click on Contacts tab", () => Page.PlantSetupPage.ContactsTab.Click());
            Thread.Sleep(1000);
            Assert.True(Page.ContactsTabPage.AddContacts.IsVisible(), "AddContacts button not found");
            Runner.DoStep("Click on 'Add Contact' button", () => Page.ContactsTabPage.AddContacts.Click());
            Telerik.ActiveBrowser.RefreshDomTree();
            //Runner.DoStep("Enter necessary contact details", () => Page.ContactsTabPage.AddContactsDetails(saveData));
            Page.ContactsTabPage.TxtTitleAdd.SelectByText("Ms", Timeout);
            Page.ContactsTabPage.TxtFirstNameAdd.TypeText("Becky");
            Page.ContactsTabPage.TxtLastNameAdd.TypeText("Weasle");
            Page.ContactsTabPage.DdlPositionAdd.SelectByText("Chief Engineer");
            //Page.ContactsTabPage.EmailToAdd.TypeText("becky@ecolab.com");
            Thread.Sleep(2000);
            Page.ContactsTabPage.BtnSaveContactsAdd.Focus();
            Page.ContactsTabPage.BtnSaveContactsAdd.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (null != Page.ContactsTabPage.ErrorMsg)
            {
                if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText.Contains("Contact added Successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed,Expected: Contact added Successfully" + " but Actual:" + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }            
            Thread.Sleep(2000);
            Page.ContactsTabPage.EditPosition.Focus();
            Page.ContactsTabPage.EditPosition.Click();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Down);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Down);
            Page.ContactsTabPage.EditPosition.Click();
            Page.ContactsTabPage.ContactsTabGrid.Rows[0].GetEditables()[2].Focus();
            Page.ContactsTabPage.ContactsTabGrid.Rows[0].GetEditables()[2].DeskTopMouseClick();
            //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D7);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D5);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D1);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D8);
            //Page.ContactsTabPage.ContactsTabGrid.Rows[0].GetEditables()[2].TypeText("543625");
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Save button functionality not achived");
            }
        }

        [TestCategory(TestType.regression, "TC07_CanceltFunctionality")]
        [Test]
        public void TC07_CanceltFunctionality()
        {            
            Thread.Sleep(1000);
            //Page.PlantSetupPage.ContactsTab.Click();
            //Thread.Sleep(2000);
            Page.ContactsTabPage.EditPosition.Focus();
            Page.ContactsTabPage.EditPosition.Click();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Down);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Down);
            Page.ContactsTabPage.EditPosition.Click();
            Page.ContactsTabPage.ContactsTabGrid.Rows[0].GetEditables()[2].Focus();
            Page.ContactsTabPage.ContactsTabGrid.Rows[0].GetEditables()[2].DeskTopMouseClick();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D5);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D1);
            Page.ContactsTabPage.PageCancel.Focus();
            Page.ContactsTabPage.PageCancel.DeskTopMouseClick();
            DialogHandler.NoButton.Click();
        }

        private EcolabDataGridItems FindRowAndPerform(string searchBy, int buttonIndex, Action action)
        {
             verifyAssert = false;
             foreach (HtmlControl page in Page.ContactsTabPage.GetGridPages)
             {
                 if (!verifyAssert)
                 {
                     if (Page.ContactsTabPage.GetGridPages.Count > 1)
                     {
                         page.ScrollToVisible();
                         Telerik.ActiveBrowser.ScrollBy(100, 100);
                         page.DeskTopMouseClick();
                     }                     
                     Thread.Sleep(3000);
                 }

                 List<EcolabDataGridItems> rowList = Page.ContactsTabPage.ContactsTabGrid.SelectedRows(searchBy);
                 if (rowList.Count != 0)
                 {
                     verifyAssert = true;
                     Console.WriteLine("Found");
                     rowList.FirstOrDefault().GetButtonControls()[buttonIndex].Click();
                     action();
                     return rowList.FirstOrDefault();
                 }
             }

             return null;
        }
    }
}
