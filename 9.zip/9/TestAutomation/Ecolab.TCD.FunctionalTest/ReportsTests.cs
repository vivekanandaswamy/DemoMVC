﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest 
{
    public class ReportsTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(3000);
        }

        [TestCategory(TestType.functional, "TC01_ProductionEfficiencyValidation")]
        [TestCategory(TestType.regression, "TC01_ProductionEfficiencyValidation")]       
        [Test]
        public void TC01_ProductionEfficiencyValidation()
        {
            if (!Page.ReportsTabPage.ChartErrorMessage.BaseElement.InnerText.Contains("No data to display the chart"))
            {
                Assert.Fail("Error message not shown");
            }
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.RecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.Fail("Error message not shown");
            }
            Page.ReportsTabPage.ProductionEfficiencyTab.Focus();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
            Thread.Sleep(4000);            
            Page.ReportsTabPage.ProductionDetailsLink.Click();
            Thread.Sleep(3000);
            if (!Page.ReportsTabPage.ChartErrorMessage.BaseElement.InnerText.Contains("No data to display the chart"))
            {
                Assert.Fail("Error message not shown");
            }
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.RecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.Fail("Error message not shown");
            }
            Thread.Sleep(2000);
        }

        [TestCategory(TestType.functional, "TC02_ResourcesUtilizationValidation")]
        [TestCategory(TestType.regression, "TC02_ResourcesUtilizationValidation")]
        [Test]
        public void TC02_ResourcesUtilizationValidation()
        {
            Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.ChartErrorMessage.BaseElement.InnerText.Contains("No data to display the chart"))
            {
                Assert.Fail("Error message not shown");
            }
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.RecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.Fail("Error message not shown");
            }
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.Focus();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Thread.Sleep(4000);
            Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ChemicalConsumptionLink.DeskTopMouseClick();
            Thread.Sleep(3000);
            if (!Page.ReportsTabPage.ChartErrorMessage.BaseElement.InnerText.Contains("No data to display the chart"))
            {
                Assert.Fail("Error message not shown");
            }
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.ResourcesRecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.Fail("Error message not shown");
            }
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.Focus();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Thread.Sleep(4000);
            Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ChemicalInventoryLink.Click();
            Thread.Sleep(3000);
            if (!Page.ReportsTabPage.UserLogTableGrid.IsVisible())
            {
                if (!Page.ReportsTabPage.ResourcesRecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
                {
                    Assert.Fail("Error message not shown");
                }
            }
            Thread.Sleep(2000);
        }

        [TestCategory(TestType.functional, "TC03_EcolabInternalValidation")]
        [TestCategory(TestType.regression, "TC03_EcolabInternalValidation")]
        [Test]
        public void TC03_EcolabInternalValidation()
        {
            Page.ReportsTabPage.EcolabInternalTab.Click();
            Thread.Sleep(3000);
            if (!Page.ReportsTabPage.UserLogTableGrid.IsVisible())
            {
                Assert.Fail("User table unavailable");
            }
        }
    }
}