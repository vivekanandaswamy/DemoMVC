﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest
{
    /// <summary>
    /// Class PlantSetupFormulasTests.
    /// </summary>
    public class PlantSetupFormulasTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(3000);
            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(3000);            
        }

        /// <summary>
        /// Tests the fixture tear down.
        /// </summary>
        //protected override void TestFixtureTearDown()
        //{
        //    Console.WriteLine("Test Fixture Teardown overriden");
        //    base.TestFixtureTearDown();
        //}

        [TestCategory(TestType.functional, "TC01_AddNewFormula")]
        [TestCategory(TestType.regression, "TC01_AddNewFormula")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Formulas Setup Page : Verify Create New Formula Functionality ;")]
        public void TC01_AddNewFormula()
        {
            Page.FormulasTabPage.DeleteIfExistsRecord("AddFormula");
            Page.FormulasTabPage.AddFormula.Click();
            Runner.DoStep("Add a Formula", () =>
            {
                Page.FormulasTabPage.AddingFormula("AddFormula", "Blend", "Saturation2", "Program1", "textilecategory1", "1", "2");
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify the Formula's addition", () =>
            {
                if (null != Page.FormulasTabPage.SuccessMessage)
                {
                    string message = Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText;
                    if (!message.Contains(@"New Formula added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
            string strCommand = "Select * from [TCD].[ProgramMaster] where Name = '" + "AddFormula" + "'";
            DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("Name = " + "'AddFormula'");
            int count = foundRows.Length;
            if (count >= 1)
            {
                Assert.True(true, "AddFormula" + " Formula added successfully in DB");
            }
            else
            {
                Assert.Fail("AddFormula" + " record not saved/ created in DB");
            }
        }

        [TestCategory(TestType.functional, "TC02_EditFormula")]
        [TestCategory(TestType.regression, "TC02_EditFormula")]
        [Test, Description("Test Case 24723:RG Plant Setup -> Formulas Setup Page : Verify the Edit functionality and Cancel the changes ;")]
        public void TC02_EditFormula()
        {
            Page.FormulasTabPage.DeleteIfExistsRecord("EditFormula");
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[4].DeskTopMouseClick();
            Page.FormulasTabPage.EditingFormulaCancelFunctionality("PA", "Blend", "Saturation2", "Program2", "textilecategory1", "1", "2");
            if (!Page.FormulasTabPage.AddFormula.IsVisible())
            {
                Assert.Fail("Page not navigated back to Formulas page on clicking cancel button in EditFormula Popup");
            }
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[4].DeskTopMouseClick();
            Runner.DoStep("Edit a Formula", () =>
            {
                Page.FormulasTabPage.EditingFormula("EditFormula", "Blend", "Saturation2", "Program2", "textilecategory1", "1", "2");
            });
            Runner.DoStep("Verify that Formula has been Edited successfully", () =>
            {
                if (null != Page.ChemicalsTabPage.UpdateSuccessMessage)
                {
                    string message = Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText;
                    if (!message.ToLower().Contains(@"formula updated successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
            string strCommand = "Select * from [TCD].[ProgramMaster] where Name = '" + "EditFormula" + "'";
            DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("Name = " + "'EditFormula'");
            int count = foundRows.Length;
            if (count >= 1)
            {
                Assert.True(true, "EditFormula" + " Formula added successfully in DB");
            }
            else
            {
                Assert.Fail("EditFormula" + " record not saved/ created in DB");
            }
            //DB Validation
        }

        [TestCategory(TestType.functional, "TC03_VerifyInLineEdit")]
        //[TestCategory(TestType.regression, "TC03_VerifyInLineEdit")]
        [Test, Description("Test Case 24761:RG Plant Setup Formulas Setup Page Verify the Inline Edit functionality and Update the changes ;")]
        public void TC03_VerifyInLineEdit()
        {
            string inLineEdit = "InlineEdit" + DateTime.Now;

            Page.FormulasTabPage.DeleteIfExistsRecord(inLineEdit);
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Runner.DoStep("Inline Edit a Formula", () =>
            {
                Page.FormulasTabPage.InLineEditingFormula(inLineEdit);
            });            
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Thread.Sleep(2000);
            Runner.DoStep("Verify the Inline Edition's success message", () =>
            {
                if (null != Page.FormulasTabPage.SuccessMessage)
                {
                    string message = Page.FormulasTabPage.SuccessMessage.BaseElement.InnerText;
                    if (!message.ToLower().Contains(@"formula updated successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
            //string strCommand = "Select * from [TCD].[ProgramMaster] where Name = '" + " InlineEdit" + "'";
            //DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("Name = " + "' InlineEdit'");
            //int count = foundRows.Length;
            //if (count >= 1)
            //{
            //    Assert.True(true, " InlineEdit" + " Formula updated successfully in DB");
            //}
           
            //{
            //    Assert.Fail(" InlineEdit" + " record not saved/ created in DB");
            //}

            Page.FormulasTabPage.DeleteIfExistsRecord("InlineEdit");
        }

        [TestCategory(TestType.functional, "TC04_VerifyInLineEditCancel")]
        //[TestCategory(TestType.regression, "TC04_VerifyInLineEditCancel")]
        [Test, Description("Test Case 24765:RG Plant Setup Formulas Setup Page : Verify the Inline Edit functionality and Cancel the changes ;")]
        public void TC04_VerifyInLineEditCancel()
        {
            Page.FormulasTabPage.DeleteIfExistsRecord("InlineEditCancel");
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Runner.DoStep("Inline Edit a Formula but dont click Save", () =>
            {
                Page.FormulasTabPage.InLineEditingFormula("InlineEditCancel");
            });            
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[1].Click();
            Thread.Sleep(2000);
            if (Page.FormulasTabPage.isRecordExist("CA") == true)
            {
                Assert.Fail("CA" + " formula added on clicking cancel after changing the name in inline Editing");
            }
            string strCommand = "Select * from [TCD].[ProgramMaster] where Name = '" + "InlineEditCancel" + "'";
            DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("Name = " + "'InlineEditCancel'");
            int count = foundRows.Length;
            if (count >= 1)
            {
                Assert.Fail("InlineEditCancel" + " record saved/ created in DB on clicking on edit cancel button");

            }
            else
            {
                Assert.True(true, "InlineEditCancel" + " Formula not updated successfully in DB");
            }
            //DB Validation
        }

        [TestCategory(TestType.functional, "TC05_CopyFormula")]
        [TestCategory(TestType.regression, "TC05_CopyFormula")]
        [Test, Description("Test Case 25022:RG Plant Setup Formulas Setup Page : Verify the Copy functionality")]
        public void TC05_CopyFormula()
        {
            Page.FormulasTabPage.DeleteIfExistsRecord("CopyFormula");
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Copy a Formula", () =>
            {
                Page.FormulasTabPage.CopyingFormula("CopyFormula", "Blend", "Saturation2", "Program1", "textilecategory1", "1", "2");
            });
            Runner.DoStep("Verify Copying the Formula", () =>
            {
                if (null != Page.ChemicalsTabPage.UpdateSuccessMessage)
                {
                    Thread.Sleep(2000);
                    string message = Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText;
                    if (!message.Contains(@"New Formula added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
            string strCommand = "Select * from [TCD].[ProgramMaster] where Name = '" + "CopyFormula" + "'";
            DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("Name = " + "'CopyFormula'");
            int count = foundRows.Length;
            if (count >= 1)
            {
                Assert.True(true, "CopyFormula" + " Formula added successfully in DB");
            }
            else
            {
                Assert.Fail("CopyFormula" + " record not saved/ created in DB");
            }

            Page.FormulasTabPage.DeleteIfExistsRecord("CopyFormula");
        }

        [TestCategory(TestType.functional, "TC07_DeleteFormula")]
        [TestCategory(TestType.regression, "TC07_DeleteFormula")]
        [Test, Description("Test Case 24743:RG:Plant Setup -> Formulas Setup Page : Verify Delete button functionality by selecting Ok ;")]
        public void TC07_DeleteFormula()
        {
            Thread.Sleep(5000);

            string strTest = Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetColumnValues()[1];
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(4000);
            //string dialogmessage = Page.FormulasTabPage.DeleteConfirmationMsg.BaseElement.InnerText;
            Runner.DoStep("Delete a Formula", () =>
            {
                DialogHandler.YesButton.Click();
            });            
            //if (null != dialogmessage)
            //{
            //    if (!dialogmessage.Contains(@"Are you sure you want to delete"))
            //    {
            //        Assert.Fail(string.Format("Incorrect error message is displayed in dialog box : {0}", dialogmessage));
            //    }
            //}
           
            //{
            //    Assert.Fail("Dialog box with confirmation to delete row is not displayed");
            //}
            Runner.DoStep("Verify Formula Deletion success message", () =>
            {
                if (null != Page.ChemicalsTabPage.UpdateSuccessMessage)
                {
                    Thread.Sleep(2000);
                    string message = Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
            //string strCommand = "Select * from [TCD].[ProgramMaster] where Name = '" + strTest + "'" + "And [Is_Deleted] = 1";
            //DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("Name = " + "'" + strTest + "'");
            //int count = foundRows.Length;
            //if (count >= 1)
            //{
            //    Assert.True(true, strTest + " Formula deleted successfully in DB");
            //}
           
            //{
            //    Assert.Fail(strTest + " record not deleted in DB on clicking on Ok button in popup");
            //}
        }

        [TestCategory(TestType.functional, "TC06_DeleteFormulaCancelFunctionality")]
        [TestCategory(TestType.regression, "TC06_DeleteFormulaCancelFunctionality")]
        [Test, Description("Test Case 24759:RG Plant Setup Formulas Setup Page : Verify Delete button functionality by selecting Cancel ;")]
        public void TC06_DeleteFormulaCancelFunctionality()
        {
            //DialogHandler.CancelButton.Click();
            string Text = Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetColumnValues()[1];
            Thread.Sleep(2000);            
            Runner.DoStep("Click on Formula Deletion button of any Formula", () =>
            {
                Page.FormulasTabPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[3].DeskTopMouseClick();
            });
            Thread.Sleep(1000);
            Runner.DoStep("Click on 'No' button in Formula Delete confirmation popup", () =>
            {
                DialogHandler.NoButton.Click();
            });            
            if (Page.FormulasTabPage.isRecordExist(Text) == false)
            {
                Assert.Fail(Text + " formula deleted on clicking cancel in delete confirmation popup");
            }
            //string strCommand = "Select * from [TCD].[ProgramMaster] where Name = '" + Text + "'" + "And [Is_Deleted] = 1";
            //DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("Name = " + "'" + Text + "'");
            //int count = foundRows.Length;
            //if (count >= 1)
            //{
            //    Assert.Fail(Text + " record deleted in DB on clicking on Cancel button in popup");              
            //}
           
            //{
            //    Assert.True(true, Text + " Formula not deleted successfully in DB");
            //}
            //DB Validation Pending
        }

        [TestCategory(TestType.functional, "TC08_ValidateAddingFormulasWithSameNumber")]
        [TestCategory(TestType.regression, "TC08_ValidateAddingFormulasWithSameNumber")]
        [Test]
        public void TC08_ValidateAddingFormulasWithSameNumber()
        {
            creatingDispenserAndWasherGroupForFormulaValidation();
            creatingATunnelWasher();
            validatingFormulasWithSameNumbers();
        }

        [TestCategory(TestType.functional, "TC09_ValidateMaxNominalLoadCapacity")]
        [TestCategory(TestType.regression, "TC09_ValidateMaxNominalLoadCapacity")]
        [Test]
        public void TC09_ValidateMaxNominalLoadCapacity()
        {
            //Validating for a Tunnel washer group
            creatingDispenserAndWasherGroupForFormulaValidationCopy();
            creatingATunnelWasherCopy();
            ValidateMaxNominalLoadCapacityForTunnel();

            //Validating for a Conventional washer group
            creatingDispenserAndWasherGroupForMaxNominalValueValidation();
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABConventionalWasherGroupFormulaNominalValue'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            ValidateMaxNominalLoadCapacityForConventional();
        }

        /// <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC10_ValidatingColumnForMultipleUsers")]
        //[TestCategory(TestType.regression, "TC10_ValidatingColumnForMultipleUsers")]
        [Test]
        public void TC10_ValidatingColumnForMultipleUsers()
        {            
            Runner.DoStep("Logout the user Admin", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });
            Dictionary<string, string> users = new Dictionary<string, string>();
            users.Add(Users.PManagerUser[0], Users.PManagerUser[1]);
            users.Add(Users.PEngineerUser[0], Users.PEngineerUser[1]);
            users.Add(Users.OperatorUser[0], Users.OperatorUser[1]);
            users.Add(Users.TRCustomerUser[0], Users.TRCustomerUser[1]);
            foreach (KeyValuePair<string, string> pair in users)
            {
                Page.LoginPage.VerifyLogin(pair.Key, pair.Value);
                Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
                Thread.Sleep(2000);
                Runner.DoStep("Check if 'Textile Category Ecolab' column is available for the user "+pair.Key+" in formulas table", () =>
                {
                    if (pair.Key != "Operator")
                    {
                        if (Page.FormulasTabPage.FormulasTab.IsEnabled)
                        {
                            Page.FormulasTabPage.FormulasTab.Click();
                            Thread.Sleep(2000);
                            if (pair.Key == "TRCustomer")
                            {
                                if (!Page.FormulasTabPage.ColumnNamesExceptTextileCategoryecolabTRCustomer.ChildNodes.ToString().Contains("Formula Category"))
                                {
                                    Assert.Fail(" 'Textile Category Ecolab' column not available for {0}", pair.Key);
                                }
                            }
                            else
                            {
                                if (!Page.FormulasTabPage.ColumnNamesExceptTextileCategoryecolab.ChildNodes.ToString().Contains("Formula Category"))
                                {
                                    Assert.Fail(" 'Textile Category Ecolab' column not available for {0}", pair.Key);
                                }
                            }
                        }
                    }
                });                  
                Page.PlantSetupPage.TopMainMenu.LogOut();
            }
            Runner.DoStep("Login as user Admin", () =>
            {
                Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            });            
        }

        /// <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC11_ValidateNumberOfCompartmentsForTunnelWG")]
        [TestCategory(TestType.regression, "TC11_ValidateNumberOfCompartmentsForTunnelWG")]
        [Test]
        public void TC11_ValidateNumberOfCompartmentsForTunnelWG()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndATunnelWasherGroup2();
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroupForFormula2'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            Page.WashersPage.DdlModel.Focus();
            Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlController.SelectByPartialText("TrialABUltraxTDIForFormula2", true);
            Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
            Random random = new Random();
            Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
            Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("10");
            Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlPress.Focus();
            Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
            Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
            Runner.DoStep("Create an AB tunnel washer", () =>
            {
                Page.WashersPage.BtnSaveTunnel.Click();
            });            
            Thread.Sleep(8000);
            if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."))
            {
                do
                {
                    Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                    Page.WashersPage.BtnSaveTunnel.Click();
                    Thread.Sleep(8000);
                } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."));
            }
            Thread.Sleep(2000);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
            Runner.DoStep("Click on Washer update button", () =>
            {
                Page.WashersPage.WashersListGridTable.Rows.LastOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            });           
            Thread.Sleep(2000);
            Runner.DoStep("'Number of compartments' field should be enabled. Verify it.", () =>
            {
                if (!Page.WashersPage.NumberOfCompartments.IsEnabled)
                {
                    Assert.Fail(" 'Number of Compartments' field should be enabled");
                }
            });            
            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(2000);
            Page.FormulasTabPage.AddFormulaButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulaNumber.TypeText("1");
            Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.NominalLoadForTunnel.TypeText("156");
            Runner.DoStep("Create a Formula for the present washer group", () =>
            {
                Page.FormulasTabPage.Save.DeskTopMouseClick();
            });            
            Thread.Sleep(2000);
            Page.WashersPage.WashersTab.Click();
            Page.WashersPage.WashersListGridTable.Rows.LastOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Runner.DoStep("After creating a formula, the 'Number of compartments' field should be disabled for the washer. Verify it.", () =>
            {
                if (Page.WashersPage.NumberOfCompartments.IsEnabled)
                {
                    Assert.Fail(" 'Number of Compartments' field should be disabled");
                }
            });            
            Thread.Sleep(2000);
        }

        /// <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC12_ValidateWashsteps")]
        [TestCategory(TestType.regression, "TC12_ValidateWashsteps")]
        [Test]
        public void TC12_ValidateWashsteps()
        {
            int controllerId = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxForWashStepsTime");
            WasherGroup group = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialWasherGroupForWashStepsTime");
            AppState.GetState<WasherState>().CreateConventionalWasher(group.Id, group.Id, "TrialConvWashertestTime", controllerId, 1);

            WasherProgramSetup setup1 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(1, group);

            string time1 = "03:45";
            string time2 = "01:67";
            string time3 = "02:00";

            AppState.GetState<WasherState>().AddWashStep(setup1, 1, RunTimeCalculation(time1));
            AppState.GetState<WasherState>().AddWashStep(setup1, 2, RunTimeCalculation(time2));
            AppState.GetState<WasherState>().AddWashStep(setup1, 3, RunTimeCalculation(time3));

            //int TotalRunTime1 = AppState.GetState<WasherState>().GetWasherSetup(setup1).TotalRunTime;
            int TotalRunTime1 = RunTimeCalculation(time1) + RunTimeCalculation(time2) + RunTimeCalculation(time3);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(1000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialWasherGroupForWashStepsTime'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'Formulas' tab of a washer group", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
            });            
            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulasTableGridAtWasher.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(1000);
            //int TotalRunTimeInUI = Convert.ToInt32(float.Parse(Page.FormulasTabPage.TotalRunTime.Value.Replace(':', '.')));
            //TotalRunTimeInUI = TotalRunTimeInUI * 60;
            int TotalRunTimeInUI = RunTimeCalculation(Page.FormulasTabPage.TotalRunTime.Value);
            Thread.Sleep(1000);
            Runner.DoStep("Verify that the 'Total run time' is displayed correctly ", () =>
            {
                Page.FormulasTabPage.TotalRunTime.Focus();
                if (TotalRunTime1 != TotalRunTimeInUI)
                {
                    Assert.Fail("Total Runtime value is incorrect");
                }
            });                        
        }

        /// <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC13_VerifyTotalQuantity")]
        [TestCategory(TestType.regression, "TC13_VerifyTotalQuantity")]
        [Test]
        public void TC13_VerifyTotalQuantity()
        {
            int controllerId = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxForWashStepsTotalQuantity");
            WasherGroup group = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialWasherGroupForWashStepsTotalQuantity");
            AppState.GetState<WasherState>().CreateConventionalWasher(group.Id, group.Id, "TrialConvWashertestTotalQuantity", controllerId, 1);

            WasherProgramSetup setup1 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(1, group);

            AppState.GetState<WasherState>().AddWashStep(setup1, 1);
            AppState.GetState<WasherState>().AddWashStep(setup1, 2);
            AppState.GetState<WasherState>().AddWashStep(setup1, 3);

            Page.PlantSetupPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            while (Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxForWashStepsTotalQuantity").Count == 0)
            {
                Page.ControllerSetupPage.NextPage.ScrollToVisible();
                Page.ControllerSetupPage.NextPage.Click();
            }

            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxForWashStepsTotalQuantity")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxForWashStepsTotalQuantity")[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(3000);
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.MaxFormulaInjections.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.KendoDown.DeskTopMouseClick();
            Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.DryerTabPage.YesButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.PumpsValvesTab.DeskTopMouseClick();
            Page.PumpsValvesPage.PumpsAndValvesTabGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.PumpsValvesPage.ddlProducts.SelectByIndex(1, Timeout);
            Page.PumpsValvesPage.txtPumpCalibration.TypeText("34");
            Page.PumpsValvesPage.SavePump.DeskTopMouseClick();
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber1 = 0;
            DataTable myTable1 = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialWasherGroupForWashStepsTotalQuantity'");
            foreach (DataRow dr in myTable1.Rows)
            {
                washerGroupNumber1 = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'Formulas' tab of a washer group", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Click on formula update button", () =>
            {
                Page.FormulasTabPage.FormulasTableGridAtWasher.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            });            
            Thread.Sleep(2000);

            string nominalString = Page.FormulasTabPage.NominalLoadForConventional.Value;
            float nominalLoad1 = float.Parse(nominalString);
            Page.FormulasTabPage.ViewInjections.Click();
            Page.FormulasTabPage.SelectProduct.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.AddProduct.Click();
            Page.FormulasTabPage.Quantity.SetText("17");
            string quantityString = Page.FormulasTabPage.Quantity.Value;
            float quantity1 = float.Parse(quantityString);
            Thread.Sleep(1000);
            string totalQuantityString = Page.FormulasTabPage.TotalQuantity.Value;
            double totalQuantity1 = double.Parse(totalQuantityString);

            double totalQuantity1d = (quantity1 * (nominalLoad1 / 100) * 90) / 100;
            totalQuantity1d = Math.Round(totalQuantity1d, 2);

            Runner.DoStep("Verify that the formula 'Total Quantity = (Quantity * (Nominal Load / 100) * 90) / 100' is being satisfied", () =>
            {
                Page.FormulasTabPage.TotalQuantity.Focus();
                if (totalQuantity1 != totalQuantity1d)
                {
                    Thread.Sleep(4000);
                    Assert.Fail("Correct value is not being displayed for the filed 'Total Quantity'");
                }
            });                        

            //Thread.Sleep(1000);
            //Page.FormulasTabPage.Quantity.SetText("17");
            //float quantity2 = float.Parse(Page.FormulasTabPage.Quantity.Value);
            //Thread.Sleep(1000);
            //float totalQuantity2 = float.Parse(Page.FormulasTabPage.TotalQuantity.Value);

            //float TQ2 = (quantity2 * (nominalLoad1 / 100) * 90) / 100;

            //if (totalQuantity2 != ((quantity2 * (nominalLoad1 / 100) * 90) / 100))
            //{
            //    Thread.Sleep(4000);
            //    Assert.Fail("Correct value is not being displayed for the filed 'Total Quantity'");
            //}

            //Page.FormulasTabPage.CancelProduct.Click();            
            Page.FormulasTabPage.CloseInjectionsPopup.Click();
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulasTab.Click();
            //DialogHandler.NoButton.Click();
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulasTableGridAtWasher.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Runner.DoStep("Change the Nominal load value", () =>
            {
                Page.FormulasTabPage.NominalLoadForConventional.TypeText("89");
            });            
            //Page.FormulasTabPage.LoCDSPerMonth.TypeText("26");
            Page.FormulasTabPage.Save.DeskTopMouseClick();
            float nominalLoad2 = float.Parse(Page.FormulasTabPage.NominalLoadForConventional.Value);
            Page.FormulasTabPage.ViewInjections.Click();
            Page.FormulasTabPage.SelectProduct.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.AddProduct.Click();
            Page.FormulasTabPage.Quantity.SetText("17");
            float quantity3 = float.Parse(Page.FormulasTabPage.Quantity.Value);
            Thread.Sleep(1000);
            double totalQuantity3 = double.Parse(Page.FormulasTabPage.TotalQuantity.Value);
            double totalQuantity3d = (quantity3 * (nominalLoad2 / 100) * 90) / 100;
            totalQuantity3d = Math.Round(totalQuantity3d, 2);
            Thread.Sleep(1000);
            Runner.DoStep("Verify that the formula 'Total Quantity = (Quantity * (Nominal Load / 100) * 90) / 100' is being satisfied", () =>
            {
                Page.FormulasTabPage.TotalQuantity.Focus();
                if (totalQuantity3 != totalQuantity3d)
                {
                    Thread.Sleep(4000);
                    Assert.Fail("Correct value is not being displayed for the filed 'Total Quantity'");
                }
            });                 
        }

        /// <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC14_SaveAndCancelFunctionality")]
        [TestCategory(TestType.regression, "TC14_SaveAndCancelFunctionality")]
        [Test]
        public void TC14_SaveAndCancelFunctionality()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(3000);
            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(3000);
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[0].Focus();
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[0].TypeText("Formula 01");
            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[1].Focus();
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[1].Click();
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[1].Click();            
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(2000);
            if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Save functionality failed");
            }

            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[1].Focus();
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[1].Click();
            Page.FormulasTabPage.FormulasTableGrid.Rows[0].GetEditables()[1].Click();                      
            Page.FormulasTabPage.CancelIE.Click();
            bool No = DialogHandler.NoButton.IsVisible();
            if (!No)
            {
                Assert.Fail("Cancel functionality failed");
            }
            DialogHandler.NoButton.Click();
        }

        public void creatingDispenserAndWasherGroupForFormulaValidation()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndATunnelWasherGroup();
        }

        public void creatingDispenserAndWasherGroupForFormulaValidationCopy()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndATunnelWasherGroupCopy();
        }

        public void creatingDispenserAndWasherGroupForMaxNominalValueValidation()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndAConventionalWasherGroupForMaxNominalValueValidation();
        }

        public void creatingATunnelWasher()
        {
            Runner.DoStep("Create an AB tunnel washer", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                Thread.Sleep(2000);
                int washerGroupNumber = 0;
                DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroupForFormula'");
                foreach (DataRow dr in myTable.Rows)
                {
                    washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
                }
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
                Page.WashersPage.DdlModel.Focus();
                Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlController.SelectByPartialText("TrialABUltraxTDIForFormula", true);
                Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
                Random random = new Random();
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("10");
                Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlPress.Focus();
                Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
                Page.WashersPage.BtnSaveTunnel.Click();
                Thread.Sleep(8000);
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        Thread.Sleep(8000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."));
                }
            });            
        }

        public void creatingATunnelWasherCopy()
        {
            Runner.DoStep("Create an AB tunnel washer", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                Thread.Sleep(2000);
                int washerGroupNumber = 0;
                DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroupForFormulaCopy'");
                foreach (DataRow dr in myTable.Rows)
                {
                    washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
                }
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
                Page.WashersPage.DdlModel.Focus();
                Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlController.SelectByPartialText("TrialABUltraxTDIForFormulaCopy", true);
                Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
                Random random = new Random();
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("10");
                Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlPress.Focus();
                Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
                Page.WashersPage.BtnSaveTunnel.Click();
                Thread.Sleep(8000);
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        Thread.Sleep(8000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."));
                }
            });            
        }

        public void validatingFormulasWithSameNumbers()
        {
            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(2000);
            Page.FormulasTabPage.AddFormulaButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulaNumber.TypeText("1");
            Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.NominalLoadForTunnel.TypeText("156");
            Runner.DoStep("Add a Formula for the created washer", () =>
            {
                Page.FormulasTabPage.Save.DeskTopMouseClick();
            });            
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(2000);
            Page.FormulasTabPage.AddFormulaButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulaNumber.TypeText("1");
            Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.NominalLoadForTunnel.TypeText("176");
            Runner.DoStep("Try adding another formula with the same number", () =>
            {
                Page.FormulasTabPage.Save.DeskTopMouseClick();
            });            
            Thread.Sleep(4000);
            Runner.DoStep("Verify that the duplicate fromula addition error message has arrived", () =>
            {
                if (!Page.FormulasTabPage.ErrorMessage.BaseElement.InnerText.Contains("Formula Number already exists"))
                {
                    Assert.Fail("Error message when trying to add a formula with existing formula number isn't displayed");
                }
            });            
        }

        public void ValidateMaxNominalLoadCapacityForTunnel()
        {
            Runner.DoStep("Try creating formula for Tunnel with 'Nominal load' values within and outside the range", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
                Thread.Sleep(2000);
                Page.FormulasTabPage.AddFormulaButton.Click();
                Thread.Sleep(2000);

                Page.FormulasTabPage.NominalLoadForTunnel.TypeText("27");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.NominalLoadErrorMessage.BaseElement.InnerText.Contains("28"))
                {
                    Assert.Fail("Error message not shown");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText("28");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText("165");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText("220");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText("221");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.NominalLoadErrorMessage.BaseElement.InnerText.Contains("220"))
                {
                    Assert.Fail("Error message not shown");
                }
            });            
        }

        public void ValidateMaxNominalLoadCapacityForConventional()
        {
            Runner.DoStep("Try creating formula for Conventional with 'Nominal load' values within and outside the range", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
                Thread.Sleep(2000);
                Page.FormulasTabPage.AddFormulaButton.Click();
                Thread.Sleep(2000);

                Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
                Page.FormulasTabPage.SelectFormulaName.SelectByIndex(0, Timeout);
                Page.FormulasTabPage.NominalLoadForConventional.TypeText("24");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.NominalLoadErrorMessage.BaseElement.InnerText.Contains("25"))
                {
                    Assert.Fail("Error message not shown");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText("25");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText("165");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText("200");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText("201");
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.NominalLoadErrorMessage.BaseElement.InnerText.Contains("200"))
                {
                    Assert.Fail("Error message not shown");
                }
            });            
        }

        public int RunTimeCalculation(string runTime)
        {
            string[] MinSec = runTime.Split(':');
            return Convert.ToInt32(MinSec[0]) * 60 + Convert.ToInt32(MinSec[1]);
        }
    }
}
