﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest
{
    public class PlantSetupDashboardTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Runner.DoStep("Click on 'Dashboard Setup' tab in Plant Setup page", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();
            });            
        }

        /// <summary>
        /// Test case 24716: RG: Adding a Conventional Dashboard
        /// </summary>
        [TestCategory(TestType.functional, "TC01_AddConventionalDashboard")]
        [TestCategory(TestType.regression, "TC01_AddConventionalDashboard")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Dashboard Setup Page : Verify Create New Conventional Dashboard Functionality ;")]
        public void TC01_AddConventionalDashboard()
        {
            Random random = new Random();
            Runner.DoStep("Add a Conventional Dashboard", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();
                Page.DashboardSetupTabPage.AddDashboard.Click();
                Page.DashboardSetupTabPage.DashboardName.TypeText("Conventional Dashboard");
                Page.DashboardSetupTabPage.DashboardType.SelectByIndex(1, Timeout);
                Thread.Sleep(2000);
                Page.DashboardSetupTabPage.MachineName.Click();
                Page.DashboardSetupTabPage.Machine.Click();
                Page.DashboardSetupTabPage.MachineName.Click();
                Page.DashboardSetupTabPage.TimeScaleDuration.TypeText(random.Next(4, 8).ToString());
                Page.DashboardSetupTabPage.SaveDashboard.Click();
                Thread.Sleep(1000);
                if (!Page.DashboardSetupTabPage.SaveSuccessMsg.BaseElement.InnerText.Contains("successfully"))
                {
                    Assert.Fail("Save functionality failed");
                }
            });            
        }

        /// <summary>
        /// Test case 24716: RG: Adding a Tunnel Dashboard
        /// </summary>
        [TestCategory(TestType.functional, "TC02_AddTunnelDashboard")]
        [TestCategory(TestType.regression, "TC02_AddTunnelDashboard")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Dashboard Setup Page : Verify Create New Tunnel Dashboard Functionality ;")]
        public void TC02_AddTunnelDashboard()
        {
            //Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndATunnelForDashboard();
            Runner.DoStep("Add a Tunnel Dashboard", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();
                Page.DashboardSetupTabPage.AddDashboard.Click();
                Page.DashboardSetupTabPage.DashboardName.TypeText("Tunnel Dashboard");
                Page.DashboardSetupTabPage.DashboardType.SelectByIndex(2, Timeout);
                Thread.Sleep(2000);
                Page.DashboardSetupTabPage.MachineName.Click();
                Page.DashboardSetupTabPage.Machine.Click();
                Page.DashboardSetupTabPage.MachineName.Click();
                Page.DashboardSetupTabPage.SaveDashboard.Click();
                Thread.Sleep(1000);
                if (!Page.DashboardSetupTabPage.SaveSuccessMsg.BaseElement.InnerText.Contains("successfully"))
                {
                    Assert.Fail("Save functionality failed");
                }
            });            
        }

        /// <summary>
        /// Test case 24716: RG: Editing a Conventional Dashboard
        /// </summary>
        [TestCategory(TestType.functional, "TC03_EditConventionalDashboard")]
        [TestCategory(TestType.regression, "TC03_EditConventionalDashboard")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Dashboard Setup Page : Verify Editing Conventional Dashboard Functionality ;")]
        public void TC03_EditConventionalDashboard()
        {
            Random random = new Random();
            Runner.DoStep("Edit a Conventional Dashboard", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();

                //Experiment purpose
                //Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[0].GetEditableControls()[1].Focus();
                //Thread.Sleep(1000);
                //Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[0].GetEditableControls()[1].Click();
                //string name = Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[0].GetEditableControls()[1].ChildNodes[0].Attributes[4].Value;

                //Page.DashboardSetupTabPage.DashboardsTableGrid.SelectedRows("Conventional Dashboard").LastOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
                int numberOfRows = Page.DashboardSetupTabPage.DashboardsTableGrid.Rows.Count;
                for (int i = 0; i < numberOfRows; i++)
                {
                    if (Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].ChildNodes[0].Attributes[4].Value.Contains("Conventional Dashboard"))
                    {
                        Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetButtonControls().LastOrDefault().DeskTopMouseClick();                        
                    }
                }                
                Thread.Sleep(2000);
                Page.DashboardSetupTabPage.TimeScaleDuration.TypeText(random.Next(4, 8).ToString());
                Page.DashboardSetupTabPage.SaveDashboard.Click();
            });            
        }

        /// <summary>
        /// Test case 24716: RG: Editing a Tunnel Dashboard
        /// </summary>
        [TestCategory(TestType.functional, "TC04_EditTunnelDashboard")]
        [TestCategory(TestType.regression, "TC04_EditTunnelDashboard")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Dashboard Setup Page : Verify Editing Tunnel Dashboard Functionality ;")]
        public void TC04_EditTunnelDashboard()
        {
            Runner.DoStep("Edit a Tunnel Dashboard", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();
                //Page.DashboardSetupTabPage.DashboardsTableGrid.SelectedRows("Tunnel Dashboard").LastOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
                int numberOfRows = Page.DashboardSetupTabPage.DashboardsTableGrid.Rows.Count;
                for (int i = 0; i < numberOfRows; i++)
                {
                    if (Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].ChildNodes[0].Attributes[4].Value.Contains("Tunnel Dashboard"))
                    {
                        Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetButtonControls().LastOrDefault().Click();
                    }
                }         
                Page.DashboardSetupTabPage.DashboardName.TypeText("Tunnel Dashboard 1");
                Page.DashboardSetupTabPage.SaveDashboard.Click();
            });           
        }

        [TestCategory(TestType.functional, "TC05_SaveAndCancelFunctionality")]
        [TestCategory(TestType.regression, "TC05_SaveAndCancelFunctionality")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Dashboard Setup Page : Verify Editing Conventional Dashboard Functionality ;")]
        public void TC05_SaveAndCancelFunctionality()
        {
            int numberOfRows = Page.DashboardSetupTabPage.DashboardsTableGrid.Rows.Count;
            for (int i = 0; i < numberOfRows; i++)
            {
                if (Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].ChildNodes[0].Attributes[4].Value.Contains("Conventional Dashboard"))
                {
                    Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].DeskTopMouseClick();
                    Thread.Sleep(2000);
                    KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
                    KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.C);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.O);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.N);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.V);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Space);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.B);
                    Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].TypeText("conv db");
                    Page.ControllerAdvancedSetupPage.Save.Click();
                    Thread.Sleep(1000);
                    if (!Page.DashboardSetupTabPage.SaveSuccessMsg.BaseElement.InnerText.Contains("successfully"))
                    {
                        Assert.Fail("Save functionality failed");
                    }
                }
            }

            for (int i = 0; i < numberOfRows; i++)
            {
                if (Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].ChildNodes[0].Attributes[4].Value.Contains("Tunnel Dashboard 1"))
                {
                    Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].DeskTopMouseClick();
                    Thread.Sleep(2000);
                    KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
                    KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.T);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.U);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.N);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.N);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Space);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.B);                    
                    Page.DashboardSetupTabPage.Cancel.Click();
                    Thread.Sleep(1000);
                    DialogHandler.NoButton.Click();
                    Thread.Sleep(1000);
                }
            }        
        }

        /// <summary>
        /// Test case 24716: RG: Deleting a Dashboard of type Coventional
        /// </summary>
        [TestCategory(TestType.functional, "TC06_DeleteCoventionalDashboard")]
        [TestCategory(TestType.regression, "TC06_DeleteCoventionalDashboard")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Dashboard Setup Page : Verify Deleting Coventional Dashboard Functionality ;")]
        public void TC06_DeleteCoventionalDashboard()
        {
            Runner.DoStep("Delete a Conventional Dashboard", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();
                //Page.DashboardSetupTabPage.DashboardsTableGrid.SelectedRows("Conventional Dashboard").LastOrDefault().GetButtonControls()[3].Focus();
                //Page.DashboardSetupTabPage.DashboardsTableGrid.SelectedRows("Conventional Dashboard").LastOrDefault().GetButtonControls()[3].DeskTopMouseClick();
                int numberOfRows = Page.DashboardSetupTabPage.DashboardsTableGrid.Rows.Count;
                for (int i = 0; i < numberOfRows; i++)
                {
                    if (Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].ChildNodes[0].Attributes[4].Value.Contains("conv db"))
                    {
                        Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetButtonControls()[3].Click();
                    }
                }                      
                DialogHandler.YesButton.Click();  
            });                      
        }

        /// <summary>
        /// Test case 24716: RG: Deleting a Dashboard of type Tunnel
        /// </summary>
        [TestCategory(TestType.functional, "TC07_DeleteTunnelDashboard")]
        [TestCategory(TestType.regression, "TC07_DeleteTunnelDashboard")]
        [Test, Description("Test Case 24704:RG Plant Setup -> Dashboard Setup Page : Verify Deleting Tunnel Dashboard Functionality ;")]
        public void TC07_DeleteTunnelDashboard()
        {
            Runner.DoStep("Delete a Tunnel Dashboard", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();
                //Page.DashboardSetupTabPage.DashboardsTableGrid.SelectedRows("Tunnel Dashboard").LastOrDefault().GetButtonControls()[3].Focus();
                //Page.DashboardSetupTabPage.DashboardsTableGrid.SelectedRows("Tunnel Dashboard").LastOrDefault().GetButtonControls()[3].DeskTopMouseClick();
                int numberOfRows = Page.DashboardSetupTabPage.DashboardsTableGrid.Rows.Count;
                for (int i = 0; i < numberOfRows; i++)
                {
                    if (Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetEditableControls()[1].ChildNodes[0].Attributes[4].Value.Contains("Tunnel Dashboard 1"))
                    {
                        Page.DashboardSetupTabPage.DashboardsTableGrid.Rows[i].GetButtonControls()[3].Click();
                    }
                }                         
                DialogHandler.YesButton.Click();
            });            
        }


        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestCategory(TestType.functional, "TC08_Method")]
        public void TC08_Method()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.AddControllerAndWasherGroup();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
        }
    }
}
