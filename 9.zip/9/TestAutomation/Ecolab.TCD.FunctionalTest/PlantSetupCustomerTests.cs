﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest
{
    public class PlantSetupCustomerTests : TestBase
    {
         [TestFixtureSetUp]
         public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            //Precondition();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);            
        }

        //protected override void TestFixtureTearDown()
        //{
        //    Console.WriteLine("Test Fixture Teardown overriden");
        //    base.TestFixtureTearDown();
        //}

        /// <summary>
        ///  TC 18822: Customer Setup page:Verify if the User could navigate to Customer Tab
        /// </summary>
        [TestCategory(TestType.regression, "TC01_VerifyCustomerTab")]
        [TestCategory(TestType.functional, "TC01_VerifyCustomerTab")]
        [Test, Description("TC 18822: Customer Setup page:Verify if the User could navigate to Customer Tab ;")]
        public void TC01_VerifyCustomerTab()
        {
            Runner.DoStep("Goto PlantSetup page", ()=> Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
            Runner.DoStep("Click on Customer tab", ()=> Page.PlantSetupPage.CustomerTab.Click());
            Assert.True(Page.CustomerTabPage.CustomerTabGridTable.IsEnabled, "CustomerTab Tablegrid not found");
        }

        /// <summary>
        /// TC 18823: Chemical: Verify the Customer Page fields displayed are as per the attachment
        /// </summary>
        [TestCategory(TestType.regression, "TC02_Verify_CustomerGridTableHeader")]
        [TestCategory(TestType.functional, "TC02_Verify_CustomerGridTableHeader")]
        [Test, Description("TC 18823: Chemical: Verify the Customer Page fields displayed are as per the attachment ;")]
        public void TC02_Verify_CustomerGridTableHeader()
        {
            Runner.DoStep("Goto PlantSetup page", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
            Runner.DoStep("Click on Customer tab", () => Page.PlantSetupPage.CustomerTab.Click());
            Assert.True(Page.CustomerTabPage.CustomerTabGridTable.IsEnabled, "CustomerTab Tablegrid not found");
            Assert.True(Page.CustomerTabPage.AreColumnsExist("Number", "Name"), "Customer ID column name not found");
        }

        /// <summary>
        ///  TC 18860: Customer Setup page:Verify Add Customer Functionality
        /// </summary>
        [TestCategory(TestType.regression, "TC03_AddCustomer")]
        [TestCategory(TestType.functional, "TC03_AddCustomer")]
        [Test, Description("TC 18860: Customer Setup page:Verify Add Customer Functionality ;")]
        public void TC03_AddCustomer()
        {
			PlantSetupNavigation();
			AddCustomer();            
        }

        /// <summary>
        ///  TC 19047: Customer Setup page:Verify Edit Customer functionality
        /// </summary>
        [TestCategory(TestType.regression, "TC04_UpdateCustomer")]
        [TestCategory(TestType.functional, "TC04_UpdateCustomer")]
        [Test, Description("TC 19047: Customer Setup page:Verify Edit Customer functionality ;")]
        public void TC04_UpdateCustomer()
        {
            string strID = System.DateTime.Now.Millisecond.ToString();
            Runner.DoStep("Goto PlantSetup page", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
            Runner.DoStep("Click on Customer tab", () => Page.PlantSetupPage.CustomerTab.Click());
            Thread.Sleep(5000);
            Runner.DoStep("Select first encountered record with Customer Name as 'sandiego' and click on respective 'Update Record' button", () =>
            {                
                //Page.CustomerTabPage.CustomerTabGrid.SelectedRows("sandiego")[0].GetButtonControls()[1].Click();
                for (int i = 0; i < Page.CustomerTabPage.CustomerTabGrid.Rows.Count; i++)
                {
                    if (Page.CustomerTabPage.CustomerTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("sandiego"))
                    {
                        Page.CustomerTabPage.CustomerTabGrid.Rows[i].GetButtonControls()[1].Click();
                    }
                }                 
            });
            Runner.DoStep("Enter the Customer ID and Customer Name and hit the Save button", () => Page.CustomerTabPage.UpdateCustomer(strID, "Camarillo"));
            Assert.True(Page.CustomerTabPage.VerifySuccessMsg.BaseElement.InnerText.Contains("Customer updated Successfully"), "Success Message not matched");

            string strCommand = "Select * from [TCD].[PlantCustomer] Where CustomerId = '" + strID + "' AND CustomerName = '" + "Camarillo" + "'";
            DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("CustomerId = " + strID);
            int count = foundRows.Length;
            if (count >= 1)
            {
                Assert.True(true, strID + " Customer updated successfully in DB");
            }
            else
            {
                Assert.Fail(strID + " record not updated in DB");
            }
        }

        /// <summary>
        ///  TC 19125: Customer Setup page:Verify Cancel button functionality
        /// </summary>
        [TestCategory(TestType.regression, "TC05_VerifyUpdateCustomerCancelButton")]
        [TestCategory(TestType.functional, "TC05_VerifyUpdateCustomerCancelButton")]
        [Test, Description("TC 19125: Customer Setup page:Verify Cancel button functionality ;")]
        public void TC05_VerifyUpdateCustomerCancelButton()
        {
			//PlantSetupNavigation();
			//AddCustomer();
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.CustomerTab.Click();
            Thread.Sleep(2000);            
            Runner.DoStep("Click on Update button of the first or default record", ()=>  Page.CustomerTabPage.CustomerTabGrid.Rows.FirstOrDefault().GetButtonControls()[1].Click());
            //Runner.DoStep("Click on Update button of the first or default record", () =>
            //{
            //    for (int i = 0; i < Page.CustomerTabPage.CustomerTabGrid.Rows.Count; i++)
            //    {
            //        if (Page.CustomerTabPage.CustomerTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("camarillo"))
            //        {
            //            Page.CustomerTabPage.CustomerTabGrid.Rows[i].GetButtonControls()[1].Click();
            //        }
            //    }
            //});
			Thread.Sleep(2000);
            //ConfirmDialog confirmDialog =
            //   ConfirmDialog.CreateConfirmDialog(Telerik.ActiveBrowser.Manager.ActiveBrowser, DialogButton.YES);
            //Telerik.ActiveBrowser.Manager.DialogMonitor.AddDialog(confirmDialog);
            Runner.DoStep("Enter 'charlotte' as a value to the 'Customer Name' field and then click on 'Cancel' button", ()=> Page.CustomerTabPage.VerifyUpdateCustomerCancelButton("charlotte"));
            //try
            //{
            //    if (Page.CustomerTabPage.lblConduitPortlet.IsEnabled)
            //    {
            //        Assert.True(true, "screen navigated back to home screen on clicking dirty popup cancel button");
            //    }
            //    else
            //    {
            //        Assert.Fail("Pop didn't appear and screen not navigated to home screen on clicking dirty popup cancel button");
            //    }
            //}
            //catch(Exception e)
            //{
            //    Assert.Fail("Pop didn't appear and screen not navigated to home screen on clicking dirty popup cancel button"  + e.Message);
            //}
            //Runner.DoStep("Select first encountered record with Customer Name as 'sandiego' and click on respective 'Delete Record' button", () => Page.CustomerTabPage.CustomerTabGrid.SelectedRows("camarillo").FirstOrDefault().GetButtonControls()[0].Click());
            //Runner.DoStep("Click on YES button", ()=> DialogHandler.FormulaYesButton.Click());
        }

        /// <summary>
        ///  TC 19107: Customer Setup page:Verify Delete Customer functionality
        /// </summary>
        [TestCategory(TestType.regression, "TC06_DeleteCustomer")]
        [TestCategory(TestType.functional, "TC06_DeleteCustomer")]
        [Test, Description("TC 19107: Customer Setup page:Verify Delete Customer functionality ;")]
        public void TC06_DeleteCustomer()
        {
			PlantSetupNavigation();
            DeleteCustomer("camarillo");
        }

        [TestCategory(TestType.regression, "TC07_SaveAndCancelFunctionality")]
        [TestCategory(TestType.functional, "TC07_SaveAndCancelFunctionality")]
        [Test]
        public void TC07_SaveAndCancelFunctionality()
        {
            PlantSetupNavigation();
            AddCustomer();
            Thread.Sleep(2000);
            Page.CustomerTabPage.CustomerNumberEdit.Click();
            Page.CustomerTabPage.CustomerNumberEdit.TypeText("121");
            Page.CustomerTabPage.CustomerNumberEdit.Click();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D1);
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Save functionality failed");
            }

            Thread.Sleep(1000);
            Page.CustomerTabPage.CustomerNumberEdit.Click();
            Page.CustomerTabPage.CustomerNumberEdit.TypeText("234");
            Page.CustomerTabPage.CustomerNumberEdit.Click();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D2);
            Page.ChemicalsTabPage.CancelChange.Click();
            bool No = DialogHandler.NoButton.IsVisible();
            if (!No)
            {
                Assert.Fail("Cancel functionality failed");
            }
            DialogHandler.NoButton.Click();
        }

        private void Precondition()
        {
            if ((short?)DBValidation.DataRows("select top(1) RegionId from tcd.plant")[0].ItemArray[0] == 1)
            {
                DBValidation.UpdateData("update [TCD].[Plant] set RegionId = 2");
            }
        }

		private void AddCustomer()
		{
			string strID = System.DateTime.Now.Millisecond.ToString();
			//Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
			//Page.PlantSetupPage.CustomerTab.Click();
			//Thread.Sleep(5000);
			Runner.DoStep("Click on 'Add Customer' button", ()=> Page.CustomerTabPage.AddCustomerButton.Click());
			Runner.DoStep("Enter the Customer ID and Customer Name and hit the Save button", ()=> Page.CustomerTabPage.AddCustomer(strID, "sandiego"));
            Assert.True(Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.Contains("Customer added Successfully"), "Success Message not matched");

			string strCommand = "Select * from [TCD].[PlantCustomer] Where CustomerId = '" + strID + "' ";
			DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("CustomerId = " + strID);
			int count = foundRows.Length;
			if (count >= 1)
			{
				Assert.True(true, strID + " Customer added successfully in DB");
			}
			else
			{
				Assert.Fail(strID + " record not saved/ created in DB");
			}
		}

		private void DeleteCustomer(string custName)
		{
			//Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
			//Page.PlantSetupPage.CustomerTab.Click();
			//Thread.Sleep(5000);
            //string strID = Page.CustomerTabPage.CustomerTabGrid.SelectedRows(custName).FirstOrDefault().GetColumnValues()[1].ToString();
            //Runner.DoStep("Click on Delete button of the first or default record", () => Page.CustomerTabPage.CustomerTabGrid.SelectedRows(custName).FirstOrDefault().GetButtonControls()[1].Click());
            Runner.DoStep("Click on Delete button of the first or default record", () =>
            {
                //Page.CustomerTabPage.CustomerTabGrid.SelectedRows("sandiego")[0].GetButtonControls()[1].Click();
                for (int i = 0; i < Page.CustomerTabPage.CustomerTabGrid.Rows.Count; i++)
                {
                    if (Page.CustomerTabPage.CustomerTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains(custName))
                    {
                        Page.CustomerTabPage.CustomerTabGrid.Rows[i].GetButtonControls()[0].Click();
                    }
                }
            });
            Runner.DoStep("Click on 'Yes' when asked for confirmation", ()=> DialogHandler.FormulaYesButton.Click());
			//Page.CustomerTabPage.ClickonOkPreferencesButton("camarillo");
			Thread.Sleep(2000);
			Assert.True(Page.CustomerTabPage.VerifySuccessMsg.BaseElement.InnerText.Contains("Successfully"), "Success Message not matched");
			Thread.Sleep(2000);
            Assert.True(Page.CustomerTabPage.CustomerTabGrid.GetRow(custName) == null, "Failed to delete the customer record");

            //string strCommand = "Select * from [TCD].[PlantCustomer] Where Is_Deleted = '1'";
            //DataRow[] foundRows = DBValidation.GetData(strCommand).Tables[0].Select("CustomerId = " + strID);
            //int count = foundRows.Length;
            //if (count >= 1)
            //{
            //    Assert.True(true, strID + " Customer deleted successfully in DB");
            //}
           
            //{
            //    Assert.Fail(strID + " record not deleted in DB");
            //}
		}

		private void PlantSetupNavigation()
		{
            Runner.DoStep("Goto PlantSetup page", () => Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage());
            Runner.DoStep("Click on Customer tab", () => Page.PlantSetupPage.CustomerTab.Click());
			Thread.Sleep(5000);
		}
    }
}
