﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.TelerikPlugin;
using ArtOfTest.WebAii.TestTemplates;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using NUnit.Framework;
using NUnit.Core;
using System.Threading;
using System.IO;
using ArtOfTest.WebAii.ObjectModel;
using Ecolab.Pages.CommonControls;
using System.Collections;
using Ecolab.CommonUtilityPlugin;
using System.Data;
using System.Collections.ObjectModel;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest
{
    public class RedFlagBRValidationTests : TestBase
    {  
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            //AppStateHandler.StateTransformation.RedflagTransform.AssociateRedFlagToMachine();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.RedFlagTab.Click();
        }

        private void CloseBrowser()
        {
            Telerik.Shutdown();
            Telerik.CleanUp();
        }        

        [TestCategory(TestType.regression, "TC12_BRValidation")]
        //[Test]
        public void TC12_BRValidation()
        {
            AppStateHandler.StateTransformation.RedflagTransform.AssociateRedFlagToMachine();
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();          
        }


        [TestCategory(TestType.regression, "TC01_DryerGroupMachineValidation")]
        [TestCategory(TestType.functional, "TC01_DryerGroupMachineValidation")]
        [Test]
        public void TC01_DryerGroupMachineValidation()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.CleanSideTab.Click();
            Page.DryerTabPage.DryerTab.Click();
            Runner.DoStep("Delete all existing Dryer groups", () =>
            {
                Page.DryerTabPage.DeleteAllDryerGroup();
            });
            Runner.DoStep("Add a dryer group", () =>
            {
                Page.DryerTabPage.AddingDryerGroup("RedFlag Dryer Group");
            });
            Runner.DoStep("Verify addition of dryer group", () =>
            {
                MessageVerification("successfully");
            });
            Thread.Sleep(1000);
            Page.DryerTabPage.GetAddDryerButton("RedFlag Dryer Group").Click();
            Runner.DoStep("Add a dryer to the dryer group created", () =>
            {
                Page.DryerTabPage.AddingDryer("1", "RedFlag Dryer", "1");
            });
            Runner.DoStep("Verify dryer is added successfully", () =>
            {
                if (null != Page.DryerTabPage.AddDryerMessage)
                {
                    string message = Page.DryerTabPage.AddDryerMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Dryer added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });      

            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.RedFlagTab.Click();
            Page.PlantSetupPage.RedFlagTab.Click();
            Page.RedFlagTabPage.BtnAddRedFlag.Click();
            Thread.Sleep(2000);
            Page.RedFlagTabPage.CategoryAdd.SelectByPartialText("Production Efficiency", true);
            Page.RedFlagTabPage.DdlRedFlagItemAdd.Focus();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.SelectByText("Drying Efficiency", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.DdlLocationAdd.Focus();
            Page.RedFlagTabPage.DdlLocationAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlLocationAdd.SelectByText("RedFlag Dryer Group", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.CheckingMachineName.Focus();       
            if (!Page.RedFlagTabPage.CheckingMachineName.BaseElement.InnerText.Contains("RedFlag Dryer"))
            {
                Assert.Fail("Respective Dryer not found in the Machine's list");
            }
        }

        //[TestCategory(TestType.regression, "TC02_FinisherGroupMachineValidation")]
        [TestCategory(TestType.functional, "TC02_FinisherGroupMachineValidation")]
        [Test]
        public void TC02_FinisherGroupMachineValidation()
        {
            Page.PlantSetupPage.RedFlagTab.Click();
            Page.RedFlagTabPage.BtnAddRedFlag.Click();
            Thread.Sleep(2000);
            Page.RedFlagTabPage.DdlRedFlagItemAdd.Focus();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.SelectByText("Gas Consumption", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.DdlLocationAdd.Focus();
            Page.RedFlagTabPage.DdlLocationAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlLocationAdd.SelectByText("TestFiniserGrp1", true);
            Page.RedFlagTabPage.BtnMachineAdd.Click();            
            if (!Page.RedFlagTabPage.CheckingMachineName.BaseElement.InnerText.Contains("TestFinisherForGrp1"))
            {
                Assert.Fail("Respective Finisher not found in the Machine's list");
            }
        }

        [TestCategory(TestType.regression, "TC03_MetersAndFinishersDeletion")]
        [TestCategory(TestType.functional, "TC03_MetersAndFinishersDeletion")]
        [Test]
        public void TC03_MetersAndFinishersDeletion()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CWGRedFlag();
            createMeterAndSensor();
            MapRedflags();

            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(1000);
            Page.PlantSetupPage.MeterTab.Click();
            Thread.Sleep(1000);
            int numOfMeters = Page.MetersTabPage.MetersTabGrid.Rows.Count;
            for (int i = 0; i <= numOfMeters; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Redflag Meter"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetButtonControls()[0].Click();
                    Page.MetersTabPage.DeleteMeterYes.Click();
                    if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText
                            .Contains(@"Unable to delete meter when a Red Flag is mapped to Location / Machine"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Unable to delete meter when a Red Flag is mapped to Location / Machine"
                                        + " but Actual: " + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                    break;
                }
            }
            
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(1000);
            int numOfSensors = Page.SensorTabPage.SensorTableGrid.Rows.Count;
            for (int i = 0; i <= numOfSensors; i++)
            {
                if (Page.SensorTabPage.SensorTableGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[3].Value.Contains("Redflag Sensor"))
                {
                    Page.SensorTabPage.SensorTableGrid.Rows[i].GetButtonControls()[0].Click();
                    DialogHandler.FormulaYesButton.Click();
                    if (!Page.SensorTabPage.DeletionErrorMessage.BaseElement.InnerText
                            .Contains(@"Unable to delete sensor when a Red Flag is mapped to Location / Machine"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Unable to delete meter when a Red Flag is mapped to Location / Machine"
                                        + " but Actual: " + Page.SensorTabPage.DeletionErrorMessage.BaseElement.InnerText);
                    }
                    break;
                }
            }

            Page.PlantSetupPage.RedFlagTab.Click();
            Thread.Sleep(1000);
            Page.RedFlagTabPage.RedFlagTabGrid.SelectedRows("Redflag Meter").FirstOrDefault().GetButtonControls()[0].Click();
            DialogHandler.FormulaYesButton.Click();
            if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag deleted successfully"))
            {
                Assert.Fail("Incorrect error message is displayed,Expected: Red flag deleted successfully but Actual-" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
            }

            Thread.Sleep(1000);
            Page.RedFlagTabPage.RedFlagTabGrid.SelectedRows("Redflag Sensor").FirstOrDefault().GetButtonControls()[0].Click();
            DialogHandler.FormulaYesButton.Click();
            if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag deleted successfully"))
            {
                Assert.Fail("Incorrect error message is displayed,Expected: Red flag deleted successfully but Actual-" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
            }

            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(1000);
            Page.PlantSetupPage.MeterTab.Click();
            Thread.Sleep(1000);
            for (int i = 0; i <= numOfMeters; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Redflag Meter"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetButtonControls()[0].Click();
                    Page.MetersTabPage.DeleteMeterYes.Click();
                    Thread.Sleep(1000);
                    if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText
                            .Equals(@"Meter Deleted Successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Meter deleted Successfully"
                                        + " but Actual:" + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                    break;
                }
            }

            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(1000);            
            for (int i = 0; i <= numOfSensors; i++)
            {
                if (Page.SensorTabPage.SensorTableGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[3].Value.Contains("Redflag Sensor"))
                {
                    Page.SensorTabPage.SensorTableGrid.Rows[i].GetButtonControls()[0].Click();
                    DialogHandler.FormulaYesButton.Click();
                    Thread.Sleep(1000);
                    if (!Page.SensorTabPage.DeletionErrorMessage.BaseElement.InnerText
                            .Equals(@"Sensor Deleted Successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Sensor deleted Successfully"
                                        + " but Actual:" + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                    break;
                }
            }            
        }

        private void createMeterAndSensor()
        {
            NavigateToMetersPage();
            Thread.Sleep(2000);
            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText("Redflag Meter");            
            Page.MetersTabPage.UtilityType.SelectByText("Gas", Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText("RedFlagWasherGroup", Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByPartialText("RedFlagWasher", true);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            Page.MetersTabPage.Controller.SelectByPartialText("RedFlagDispenser", true);            
            Page.MetersTabPage.AddMeterSaveButton.Click();            
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }
            Thread.Sleep(2000);
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.AddSensorButton.Click();
            Page.SensorTabPage.AddSensorButton.ScrollToVisible();
            Page.SensorTabPage.SensorName.TypeText("Redflag Sensor");               
            Page.SensorTabPage.SensorType.SelectByIndex(2, Timeout);
            Page.SensorTabPage.SensorLocation.SelectByPartialText("RedFlagWasherGroup", true);
            Thread.Sleep(3000);
            Page.SensorTabPage.MachineName.SelectByPartialText("RedFlagWasher", true);            
            Page.SensorTabPage.OutputType.SelectByIndex(1, Timeout);            
            Page.SensorTabPage.UoM.SelectByIndex(1, Timeout);                        
            Thread.Sleep(2000);
            Runner.DoStep("Add a Sensor", () =>
            {
                Page.SensorTabPage.btnSave.Focus();
                KeyBoardSimulator.KeyPress(Keys.Enter);
            });
            Thread.Sleep(2000);

            if (Page.SensorTabPage.SensorAddedSuccess.BaseElement.InnerText.Contains("Sensor Added Successfully"))
            {
                Assert.True(true, "Sensor added successfully");
            }
            else
            {
                Assert.Fail("Sensor add success messgae not found");
            }
            Thread.Sleep(2000);           
        }

        private void MapRedflags()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();            
            Page.PlantSetupPage.RedFlagTab.Click();
            Page.RedFlagTabPage.BtnAddRedFlag.Click();
            Thread.Sleep(2000);
            Page.RedFlagTabPage.CategoryAdd.SelectByPartialText("Resources", true);
            Page.RedFlagTabPage.DdlRedFlagItemAdd.Focus();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.SelectByPartialText("Gas consumption", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.DdlLocationAdd.Focus();
            Page.RedFlagTabPage.DdlLocationAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlLocationAdd.SelectByText("RedFlagWasherGroup", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.TxtMinimumRangeAdd.TypeText("34");
            Page.RedFlagTabPage.TxtMaximumRangeAdd.TypeText("56");
            Page.RedFlagTabPage.MeterSensor.SelectByText("Redflag Meter", Timeout);
            Page.RedFlagTabPage.SaveRedflag.Focus();
            Page.RedFlagTabPage.SaveRedflag.Click();
            Thread.Sleep(2000);
            Runner.DoStep("Verify the Redflag addition success message", () =>
            {
                if (null != Page.RedFlagTabPage.ErrorMsg)
                {
                    if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Red flag added successfully but Actual:" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
            Thread.Sleep(2000);
            
            Page.PlantSetupPage.RedFlagTab.Click();
            Page.RedFlagTabPage.BtnAddRedFlag.Click();
            Thread.Sleep(2000);
            Page.RedFlagTabPage.CategoryAdd.SelectByPartialText("Process Validation", true);
            Page.RedFlagTabPage.DdlRedFlagItemAdd.Focus();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.SelectByText("pH", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.DdlLocationAdd.Focus();
            Page.RedFlagTabPage.DdlLocationAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlLocationAdd.SelectByText("RedFlagWasherGroup", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.TxtMinimumRangeAdd.TypeText("34");
            Page.RedFlagTabPage.TxtMaximumRangeAdd.TypeText("56");
            Page.RedFlagTabPage.MeterSensor.SelectByText("Redflag Sensor", Timeout);
            Page.RedFlagTabPage.SaveRedflag.Focus();
            Page.RedFlagTabPage.SaveRedflag.Click();
            Thread.Sleep(2000);
            Runner.DoStep("Verify the Redflag addition success message", () =>
            {
                if (null != Page.RedFlagTabPage.ErrorMsg)
                {
                    if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Red flag added successfully but Actual:" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
        }

        private void NavigateToMetersPage()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.PlantSetupPage.MeterTab.Click();
            KeyBoardSimulator.KeyPress(Keys.Tab);
            Thread.Sleep(2000);
        }

        private void MessageVerification(string message)
        {
            if (null != Page.DryerTabPage.AddDryerMessage)
            {
                Thread.Sleep(2000);
                string actualmessage = Page.DryerTabPage.AddDryerMessage.BaseElement.InnerText.ToLower();
                if (!actualmessage.Contains(@message))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual:{0}", actualmessage);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
        }
    }
}
