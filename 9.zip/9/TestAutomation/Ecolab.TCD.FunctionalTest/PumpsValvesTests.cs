﻿using NUnit.Framework;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;

/// <summary>
/// The FunctionalTest namespace.
/// </summary>
namespace Ecolab.FunctionalTest
{
    public class PumpsValvesTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
        }

        [TestCategory(TestType.functional, "TC01_Edit_PumpsValves_AllenBradley")]
        //[TestCategory(TestType.regression, "TC01_Edit_PumpsValves_AllenBradley")]
        [Test, Description("Test Case 32811:RG Verify Add Controller Page Edit Pumps/Valves Functionality Allen Bradley ;")]
        public void TC01_Edit_PumpsValves_AllenBradley()
        {
            Page.PumpsValvesPage.ControllerSetupGridTable.SelectedRows("Allen Bradley")[0].GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (!Page.PumpsValvesPage.ddlSort.BaseElement.InnerText.Contains("All"))
            {
                Assert.Fail("Default option not set to ALL for sort dropdown");
            }
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.AddingPumps("5", "200");
            Thread.Sleep(2000);
            if (null != Page.PumpsValvesPage.ValidationMessage)
            {
                if (!Page.PumpsValvesPage.ValidationMessage.BaseElement.InnerText
                    .Equals(@"Pump details updated successfully"))
                {
                    Page.PumpsValvesPage.BacktoPumps.Click();
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Page.PumpsValvesPage.BacktoPumps.Click();
                Assert.Fail("Error message is not displayed");
            }
            Page.PumpsValvesPage.BacktoPumps.Click();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.BacktoControllers.Click();
            //DB Validation
        }

        [TestCategory(TestType.functional, "TC02_Edit_PumpsValves_Beckhoff")]
        //[TestCategory(TestType.regression, "TC02_Edit_PumpsValves_Beckhoff")]
        [Test, Description("Test Case 32822:RG Verify Add Controller Page -Edit Pumps/Valves Functionality-Beckhoff ;")]
        public void TC02_Edit_PumpsValves_Beckhoff()
        {
            Page.PumpsValvesPage.ControllerSetupGridTable.SelectedRows("Beckhoff")[0].GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (!Page.PumpsValvesPage.ddlSort.BaseElement.InnerText.Contains("All"))
            {
                Assert.Fail("Default option not set to ALL for sort dropdown");
            }
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.AddingPumps("10", "130");
            if (null != Page.PumpsValvesPage.ValidationMessage)
            {
                if (!Page.PumpsValvesPage.ValidationMessage.BaseElement.InnerText
                    .Equals(@"Pump details updated successfully"))
                {
                    Page.PumpsValvesPage.BacktoPumps.Click();
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Page.PumpsValvesPage.BacktoPumps.Click();
                Assert.Fail("Error message is not displayed");
            }
            Page.PumpsValvesPage.BacktoPumps.Click();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.BacktoControllers.Click();
            //DB Validation
        }

        [TestCategory(TestType.functional, "TC03_Verify_UpdatePumps_CancelFunctionality")]
        //[TestCategory(TestType.regression, "TC03_Verify_UpdatePumps_CancelFunctionality")]
        [Test, Description("Test Case 32823:RG Verify Cancel Button Functionality-Update Button ;")]
        public void TC03_Verify_UpdatePumps_CancelFunctionality()
        {
            Page.PumpsValvesPage.ControllerSetupGridTable.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (!Page.PumpsValvesPage.ddlSort.BaseElement.InnerText.Contains("All"))
            {
                Assert.Fail("Default option not set to ALL for sort dropdown");
            }
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.UpdateCancellingPumps("15", "160");
            if (null != Page.PumpsValvesPage.dialogMsg.BaseElement.InnerText)
            {
                if (!Page.PumpsValvesPage.dialogMsg.BaseElement.InnerText
                    .Equals(@"Do you want to save changes?"))
                {
                    Assert.Fail(string.Format("Incorrect error message is displayed in dialog box : {0}", DialogHandler.LastDialogMessage));
                }
            }
            else
            {
                Assert.Fail("Dialog box with confirmation to delete row is not displayed");
            }
            DialogHandler.NoButton.Click();
            Page.PumpsValvesPage.BacktoControllers.Click();
        }

        [TestCategory(TestType.functional, "TC04_Verify_UpdatePumps")]
        // [TestCategory(TestType.regression, "TC04_Verify_UpdatePumps")]
        [Test, Description("Test Case 33630:RG Verify Edit Pump/Valves Functionality-Update Button ;")]
        public void TC04_Verify_UpdatePumps()
        {
            Page.PumpsValvesPage.ControllerSetupGridTable.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (!Page.PumpsValvesPage.ddlSort.BaseElement.InnerText.Contains("All"))
            {
                Assert.Fail("Default option not set to ALL for sort dropdown");
            }
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.UpdatingPumps("20", "120");
            Thread.Sleep(2000);
            if (null != Page.PumpsValvesPage.ValidationMessage)
            {
                if (!Page.PumpsValvesPage.ValidationMessage.BaseElement.InnerText
                    .Equals(@"Pump details updated successfully"))
                {
                    Page.PumpsValvesPage.BacktoPumps.Click();
                    Page.PumpsValvesPage.BacktoControllers.Click();
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Page.PumpsValvesPage.BacktoPumps.Click();
                Assert.Fail("Error message is not displayed");
            }
            Page.PumpsValvesPage.BacktoPumps.Click();
            Page.PumpsValvesPage.BacktoControllers.Click();
        }

        [TestCategory(TestType.functional, "TC05_Verify_InlineEdit_Pumps_Cancel")]
        // [TestCategory(TestType.regression, "TC05_Verify_InlineEdit_Pumps_Cancel")]
        [Test, Description("Test Case 40173:RG Verify Cancel button Functionality-Inline ;")]
        public void TC05_Verify_InlineEdit_Pumps_Cancel()
        {
            Page.PumpsValvesPage.ControllerSetupGridTable.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (!Page.PumpsValvesPage.ddlSort.BaseElement.InnerText.Contains("All"))
            {
                Assert.Fail("Default option not set to ALL for sort dropdown");
            }
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.InlineEditingPumps("0", "190");
            Thread.Sleep(2000);
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[1].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.BacktoControllers.Click();
        }

        [TestCategory(TestType.functional, "TC06_Verify_InlineEdit_Pumps_Update")]
        //[TestCategory(TestType.regression, "TC06_Verify_InlineEdit_Pumps_Update")]
        [Test, Description("Test Case 40107:RG Verify Edit Pump/Valves Functionality-Inline ;")]
        public void TC06_Verify_InlineEdit_Pumps_Update()
        {
            Page.PumpsValvesPage.ControllerSetupGridTable.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (!Page.PumpsValvesPage.ddlSort.BaseElement.InnerText.Contains("All"))
            {
                Assert.Fail("Default option not set to ALL for sort dropdown");
            }
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.InlineEditingPumps("0", "190");
            Thread.Sleep(2000);
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[0].DeskTopMouseClick();
            Thread.Sleep(2000);
            if (null != Page.PumpsValvesPage.ValidationMessage)
            {
                if (!Page.PumpsValvesPage.ValidationMessage.BaseElement.InnerText
                    .Equals(@"Pump details updated successfully"))
                {
                    Page.PumpsValvesPage.BacktoPumps.Click();
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Page.PumpsValvesPage.BacktoPumps.Click();
                Assert.Fail("Error message is not displayed");
            }
            Page.PumpsValvesPage.BacktoControllers.Click();
        }

        [TestCategory(TestType.functional, "TC07_Verify_Pumps_Localization")]
        // [TestCategory(TestType.regression, "TC07_Verify_Pumps_Localization")]
        [Test, Description("Test Case 40190:RG Verify the application localization functionality on Pumps/valves Add and Edit and Grid page ;")]
        public void TC07_Verify_Pumps_Localization()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("Deutsch", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.ControllerSetupGridTable.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (Page.PumpsValvesPage.tabPumpList.BaseElement.InnerText != "Pompen/Valves")
            {
                PostLocalizationStorageTanks();
                Thread.Sleep(2000);
                Assert.Fail(string.Format("Incorrert Tab name displayed in  - {0} when localization changed to Deutsch, Expected - Pompen/Valves", Page.PumpsValvesPage.tabPumpList.BaseElement.InnerText));
            }
            PostLocalizationStorageTanks();
        }

        private void PostLocalizationStorageTanks()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.SensorTabPage.Language.Focus();
            Page.SensorTabPage.Language.SelectByText("English US", true);
            Page.SensorTabPage.Language.ScrollToVisible();
            Page.SensorTabPage.GeneralTabSave.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.ControllerSetupGridTable.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (Page.PumpsValvesPage.tabPumpList.BaseElement.InnerText != "Pumps/Valves")
            {
                Assert.Fail(string.Format("Incorrert Tab name displayed in  - {0} when localization changed to Deutsch, Expected - Pompen/Valves", Page.PumpsValvesPage.tabPumpList.BaseElement.InnerText));
            }
        }

        [TestCategory(TestType.functional, "TC08_Verify_Pumps_UserRole8")]
        //[TestCategory(TestType.regression, "TC08_Verify_Pumps_UserRole8")]
        [Test, Description("Test Case 40908:RG Verify access to Pump & Valve Page depending on UserRoleId - 8 ;")]
        public void TC08_Verify_Pumps_UserRole8()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Thread.Sleep(2000);
            Page.LoginPage.VerifyLogin(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]);
            Thread.Sleep(2000);
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.ControllerSetupGridTable.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.tabPumpList.Click();
            Thread.Sleep(2000);
            if (!Page.PumpsValvesPage.ddlSort.BaseElement.InnerText.Contains("All"))
            {
                Assert.Fail("Default option not set to ALL for sort dropdown");
            }
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[1].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.PumpsValvesPage.UpdatingPumps("0", "150");
            if (null != Page.PumpsValvesPage.ValidationMessage)
            {
                if (!Page.PumpsValvesPage.ValidationMessage.BaseElement.InnerText
                    .Equals(@"Pump details updated successfully"))
                {
                    Page.PumpsValvesPage.BacktoPumps.Click();
                    Assert.Fail("Incorrect error message is displayed");
                }
            }
            else
            {
                Page.PumpsValvesPage.BacktoPumps.Click();
                Assert.Fail("Error message is not displayed");
            }
            Page.PumpsValvesPage.BacktoPumps.Click();
            Page.PumpsValvesPage.BacktoControllers.Click();
            Page.PlantSetupPage.TopMainMenu.LogOut();
        }

        [TestCategory(TestType.functional, "TC09_Verify_Pumps_UserRole6")]
        //[TestCategory(TestType.regression, "TC09_Verify_Pumps_UserRole6")]
        [Test, Description("Test Case 41095:RG: Verify access to Controller Page depending on UserRoleId - 6 ;")]
        public void TC09_Verify_Pumps_UserRole6()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.TMBasicUser[0], Users.TMBasicUser[1]);
            Thread.Sleep(2000);
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            if (Page.PumpsValvesPage.ControllerRoleSetupGridTable.Rows.FirstOrDefault().GetButtonControls().Count > 1)
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
                Assert.Fail("Update/Edit/Delete buttons enabled for User role 6 and expected readonly / viewonly access for controller setup");
            }
            Page.PlantSetupPage.TopMainMenu.LogOut();
        }


        [TestCategory(TestType.functional, "TC10_Verify_Pumps_UserRole4")]
        //[TestCategory(TestType.regression, "TC10_Verify_Pumps_UserRole4")]
        [Test, Description("Test Case 40977:RG Verify access to Pump & Valve Page depending on UserRoleId - 1 to 5 ;")]
        public void TC10_Verify_Pumps_UserRole4()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.PManagerUser[0], Users.PManagerUser[1]);
            Thread.Sleep(2000);
            try
            {
                if (Page.LoginPage.TopMainMenu.NavigateToControlerSetupPageAvailable())
                {
                    Assert.Fail("Controller Setup Menu visible for User Role - 4 i. e Plant Manager");
                }
            }
            finally
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            }
        }

        [TestCategory(TestType.functional, "TC11_VerifyDeletingTunnelCompartmentWithFormula")]
        //[TestCategory(TestType.regression, "TC11_VerifyDeletingTunnelCompartmentWithFormula")]
        [Test]
        public void TC11_VerifyDeletingTunnelCompartmentWithFormula()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateTunnelWasherGroupWithOneTunnelForPumps();
            Random random = new Random();
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            while (Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps").Count == 0)
            {
                Page.ControllerSetupPage.NextPage.ScrollToVisible();
                Page.ControllerSetupPage.NextPage.Click();
            }
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps")[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(2000);
            Page.ControllerGeneralSetupTabPage.SerialNumber.TypeText(random.Next(1, 73683).ToString());
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.Save.Click();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(2000);

            updatePump(0);
            updatePump(1);
            updatePump(2);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            int washerGroupNumber = 0;            
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroupForPumps'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }          
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WashersPage.CompartmentsTab.Click();

            createCompartment(1);
            createCompartment(2);
            createCompartment(3);

            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Page.WasherGroupFormulasPage.FormulaName.SelectByIndex(1, Timeout);
            Page.WasherGroupFormulasPage.Save.Click();
            Thread.Sleep(2000);
            //Page.WasherGroupFormulasPage.Notes.TypeText("Attaching Formula to Compartment 1");
            Page.WasherGroupPage.TxtTemperature.TypeText("56");
            Page.WasherGroupFormulasPage.WaterType.SelectByIndex(1, Timeout);
            Page.WasherGroupFormulasPage.WaterType.SelectByIndex(0, Timeout);
            Page.WasherGroupFormulasPage.WashOperation.SelectByIndex(3, Timeout);    
            Page.WasherGroupFormulasPage.WashOperation.SelectByIndex(1, Timeout);
            Page.WashersPage.NextCompartment.DeskTopMouseClick();            
            Page.WasherGroupFormulasPage.SaveWashStep.Click();
            if (!Page.FormulasTabPage.FormulaWashstepAddedMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Success message not displayed");
            }   
            Page.WashersPage.WashersTab.Click();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WashersPage.CompartmentsTab.Click();
            Thread.Sleep(2000);
            //Page.WashersPage.ButtonControlsArea.Focus();
            if (Page.WashersPage.ButtonControlsArea.ChildNodes.Count > 0)
            {
                Assert.Fail("Deleting a compartment chemical should not be possible when mapped to a formula");
            }
            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Page.WasherGroupFormulasPage.FormulasTableGrid.Rows.FirstOrDefault().GetButtonControls()[3].DeskTopMouseClick();
            DialogHandler.YesButton.Click();
            Page.WashersPage.WashersTab.Click();
            Thread.Sleep(2000);
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(3000);
            Page.WashersPage.CompartmentsTab.Click();
            //Page.WashersPage.ButtonControlsArea.Focus();
            if (Page.WashersPage.ButtonControlsArea.ChildNodes.Count == 0)
            {
                Assert.Fail("Deleting a compartment chemical should be possible when not mapped to a formula");
            }
            Thread.Sleep(2000);
        }

        [TestCategory(TestType.functional, "TC12_VerifyAvailabilityOfPumps")]
        [TestCategory(TestType.regression, "TC12_VerifyAvailabilityOfPumps")]
        [Test]
        public void TC12_VerifyAvailabilityOfPumps()
        {
            try
            {
                Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateTunnelWasherGroupWithOneTunnelForPumps();
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Exception : ", ex);
            }

            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            while (Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps").Count == 0)
            {
                Page.ControllerSetupPage.NextPage.ScrollToVisible();
                Page.ControllerSetupPage.NextPage.Click();
            }
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps")[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(2000);
            Random random = new Random();
            Page.ControllerGeneralSetupTabPage.SerialNumber.TypeText(random.Next(1, 73683).ToString());
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.Save.Click();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(2000);

            updatePump(0);
            updatePump(1);
            updatePump(2);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroupForPumps'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WashersPage.CompartmentsTab.Click();

            createCompartment(1);
            createCompartment(2);
            createCompartment(3);

            Page.ControllerSetupPage.GeneralTab.Click();
            Page.WashersPage.CompartmentsTab.Click();
            Thread.Sleep(1000);
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (Page.WashersPage.Chemical.BaseElement.InnerText.Contains("P/V 1"))
            {
                Assert.Fail("Respective pump should not be available as it is mapped to other Compartment");
            }
            Page.WashersPage.NextCompartment.DeskTopMouseClick();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (Page.WashersPage.Chemical.BaseElement.InnerText.Contains("P/V 1"))
            {
                Assert.Fail("Respective pump should not be available as it is mapped to other Compartment");
            }
            Page.WashersPage.NextCompartment.DeskTopMouseClick();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.CompartmentChemicalsTableGrid.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().DeskTopMouseClick();
            DialogHandler.YesButton.Click();
            Page.WashersPage.SaveCompartment.Click();
            Page.WashersPage.PreviousCompartment.DeskTopMouseClick();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (!Page.WashersPage.Chemical.BaseElement.InnerText.Contains("P/V 1"))
            {
                Assert.Fail("Respective pump should be available as it is not mapped to any Compartment");
            }
            Page.WashersPage.PreviousCompartment.DeskTopMouseClick();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (!Page.WashersPage.Chemical.BaseElement.InnerText.Contains("P/V 1"))
            {
                Assert.Fail("Respective pump should be available as it is not mapped to any Compartment");
            }
        }

        public void updatePump(int rowNumber)
        {
            Page.ControllerSetupPage.PumpsValvesTab.Click();
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[rowNumber].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.PumpsValvesPage.ddlProducts.SelectByIndex(1, Timeout);
            Page.PumpsValvesPage.txtPumpCalibration.TypeText("34");
            Page.PumpsValvesPage.SavePump.ScrollToVisible();
            Page.PumpsValvesPage.SavePump.Click();
        }

        public void createCompartment(int compartmentNumber)
        {
            Page.WashersPage.NextCompartment.DeskTopMouseClick();
            if (compartmentNumber == 1)
            {
                Page.WashersPage.PreviousCompartment.DeskTopMouseClick();
            }
            Page.WashersPage.WaterInlet.SelectByIndex(1, Timeout);
            Page.WashersPage.WashZone.SelectByIndex(1, Timeout);
            Page.WashersPage.WaterFlow.SelectByIndex(1, Timeout);
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.SelectByIndex(1, Timeout);
            Page.WashersPage.AddPump.Click();
            Page.WashersPage.PumpsTableInCompartmentsTab.Rows[0].GetButtonControls().FirstOrDefault().DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.SelectByIndex(1, Timeout);
            Page.WashersPage.AddPump.Click();
            Page.WashersPage.SaveCompartment.Click();
        }
    }
}
