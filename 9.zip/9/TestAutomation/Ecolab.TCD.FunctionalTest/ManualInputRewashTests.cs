﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest
{
    public class ManualInputRewashTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            DBValidation.UpdateData("update tcd.plant set AllowManualRewash = 1");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Thread.Sleep(3000);
            Page.RewashTabPage.RewashTab.Click();
            Thread.Sleep(3000);

        }

        [TestCategory(TestType.functional, "TC01_VerifyNavigationToManualInputPage")]
        [TestCategory(TestType.regression, "TC01_VerifyNavigationToManualInputPage")]
        [Test]
        public void TC01_VerifyNavigationToManualInputPage()
        {
            //Runner.DoStep("Navigate to ManualInput page", ()=> Page.PlantSetupPage.TopMainMenu.IsNavigateToManualInputPage());
            Runner.DoStep("Navigate to ManualInput tab", ()=> Page.PlantSetupPage.TopMainMenu.NavigateToManualInput());
            if(Page.RewashTabPage.RewashTab.IsEnabled)
            {
                Assert.True(true, "Application navigated to Manual Input Page");
            }
            else
            {
                Assert.Fail("Application didnot navigate to Manual Input Page");
            }
            
        }

        [TestCategory(TestType.functional, "TC02_VerifySubMenuItemsOfManualInputPage")]
        [TestCategory(TestType.regression, "TC02_VerifySubMenuItemsOfManualInputPage")]
        [Test]
        public void TC02_VerifySubMenuItemsOfManualInputPage()
        {
            Runner.DoStep("Checking if Uitlity, Production, Rewash and Labour tabs are enabled for ManualInput tab", () =>
                {
            if (Page.RewashTabPage.UtilityTab.IsEnabled)
            {
                Assert.True(true, "Utility Tab visible in Manual Input Page");
            }
            else
            {
                Assert.Fail("Utility Tab not visible in Manual Input Page");
            }
            if (Page.RewashTabPage.ProductionTab.IsEnabled)
            {
                Assert.True(true, "Production Tab visible in Manual Input Page");
            }
            else
            {
                Assert.Fail("Production Tab not visible in Manual Input Page");
            }
            if (Page.RewashTabPage.RewashTab.IsEnabled)
            {
                Assert.True(true, "Rewash Tab visible in Manual Input Page");
            }
            else
            {
                Assert.Fail("Rewash Tab not visible in Manual Input Page");
            }
            if (Page.RewashTabPage.LabourTab.IsEnabled)
            {
                Assert.True(true, "Labour Tab visible in Manual Input Page");
            }
            else
            {
                Assert.Fail("Labour Tab not visible in Manual Input Page");
            }
                });
        }

        [TestCategory(TestType.functional, "TC03_VerifySubmenuItemsInManualInput")]
        [TestCategory(TestType.regression, "TC03_VerifySubmenuItemsInManualInput")]
        [Test]
        public void TC03_VerifySubmenuItemsInManualInput()
        {
            Runner.DoStep("Click on Utility tab in Rewash page", ()=> Page.RewashTabPage.UtilityTab.Click()); 
            Runner.DoStep("Click on production tab in Rewash page", ()=> Page.RewashTabPage.ProductionTab.Click());
            if (Page.RewashTabPage.ProductionData.IsEnabled)
            {
                Assert.True(true, "ProductionData Tab visible in Production Tab Page");
            }
            else
            {
                Assert.Fail("ProductionData Tab not visible in Production Tab Page");
            }

            Runner.DoStep("Click on Rewash tab in Rewash page", ()=> Page.RewashTabPage.RewashTab.Click());
            if (Page.RewashTabPage.WasherGroup.IsEnabled)
            {
                Assert.True(true, "WasherGroup visible in Rewash Tab Page");
            }
            else
            {
                Assert.Fail("WasherGroup not visible in Rewash Tab Page");
            }

            Runner.DoStep("Click on labour tab in Rewash page", ()=> Page.RewashTabPage.LabourTab.Click());
            if (Page.RewashTabPage.Location.IsEnabled)
            {
                Assert.True(true, "Location Tab visible in Labour Tab Page");
            }
            else
            {
                Assert.Fail("Location Tab not visible in Labour Tab Page");
            }
        }

        [TestCategory(TestType.functional, "TC04_VerifyFieldsRewashPage")]
        [TestCategory(TestType.regression, "TC04_VerifyFieldsRewashPage")]
        [Test]
        public void TC04_VerifyFieldsRewashPage()
        {
            Runner.DoStep("Check if every field in Rewash tab are enabled by a click", ()=> Page.RewashTabPage.RewashTab.Click());
            if (Page.RewashTabPage.WasherGroup.IsEnabled)
            {
                Assert.True(true, "WasherGroup drop down visible in Rewash Page");
            }
            else
            {
                Assert.Fail("WasherGroup Tab not visible in Rewash Page");
            }
            if (Page.RewashTabPage.Formula.IsEnabled)
            {
                Assert.True(true, "Formula drop down visible in Rewash Page");
            }
            else
            {
                Assert.Fail("Formula drop down not visible in Rewash Page");
            }
            if (Page.RewashTabPage.RewashReason.IsEnabled)
            {
                Assert.True(true, "RewashReason drop down visible in Rewash Page");
            }
            else
            {
                Assert.Fail("RewashReason drop down not visible in Rewash Page");
            }
        }

        [TestCategory(TestType.functional, "TC05_VerifyValueInWasherGroupField")]
        [TestCategory(TestType.regression, "TC05_VerifyValueInWasherGroupField")]
        [Test]
        public void TC05_VerifyValueInWasherGroupField()
        {
            Page.RewashTabPage.RewashTab.Click();
            string strCommand = "select WasherGroupName from tcd.WasherGroup";
            DataSet ds = DBValidation.GetData(strCommand);
            List<string> lstDB = new List<string>();
            List<string> lstDrp = new List<string>();
            foreach (DataRow d in ds.Tables[0].Rows)
            {
                lstDB.Add(d["WasherGroupName"].ToString());
            }
            ICollection<Element> col = Page.RewashTabPage.WasherGroup.ChildNodes;
            foreach(Element cl in col)
            {
                if (cl.InnerText != "-- Select --")
                lstDrp.Add(cl.InnerText.ToString());
            }
            lstDB.Sort();
            lstDrp.Sort();

            if(lstDB.Count == lstDrp.Count)
            {
                List<string> difference = lstDB.Except(lstDrp).ToList();
            }
            else
            {
                Assert.Fail("Count of DB values and WasherGroupField values didnot match");
            }
        }

        [TestCategory(TestType.functional, "TC06_VerifyValueInFormulasField")]
        [TestCategory(TestType.regression, "TC06_VerifyValueInFormulasField")]
        [Test]
        public void TC06_VerifyValueInFormulasField()
        {
            Page.RewashTabPage.RewashTab.Click();
            string strCommand = "Select [Name] from [TCD].[ProgramMaster] where [Rewash]=1";
            DataSet ds = DBValidation.GetData(strCommand);
            List<string> lstDB = new List<string>();
            List<string> lstDrp = new List<string>();
            foreach (DataRow d in ds.Tables[0].Rows)
            {
                lstDB.Add(d["Name"].ToString());
            }
            ICollection<Element> col = Page.RewashTabPage.Formula.ChildNodes;
            foreach(Element cl in col)
            {
                if (cl.InnerText != "-- Select --")
                lstDrp.Add(cl.InnerText.ToString());
            }
            lstDB.Sort();
            lstDrp.Sort();

            if(lstDB.Count == lstDrp.Count)
            {
                List<string> difference = lstDB.Except(lstDrp).ToList();
            }
            else
            {
                Assert.Fail("Count of DB values and FormulaDropDown values didnot match Expected : " + lstDB.Count + "Actual : " + lstDrp.Count);
            }
        }

        [TestCategory(TestType.functional, "TC07_VerifyValueInRewashReasonField")]
        [TestCategory(TestType.regression, "TC07_VerifyValueInRewashReasonField")]
        [Test]
        public void TC07_VerifyValueInRewashReasonField()
        {
            Runner.DoStep("Click on Rewash tab in Rewash page", () => Page.RewashTabPage.RewashTab.Click());            
            bool bWashing = false;
            bool bFinishing = false;
            ICollection<Element> col = Page.RewashTabPage.RewashReason.ChildNodes;
            foreach (Element cl in col)
            {
                if (cl.InnerText == "Washing")
                {
                    bWashing = true;
                }
                if (cl.InnerText == "Finishing")
                {
                    bFinishing = true;
                }
            }
            if (bWashing != true)
            {
                Assert.Fail("Washing value not appearing in RewashReason drop down");
            }
            if(bFinishing != true)
            {
                Assert.Fail("Finishinh value not appearing in RewashReason drop down");
            }
        }

        [TestCategory(TestType.functional, "TC08_VerifyAllowRewash")]
        [TestCategory(TestType.regression, "TC08_VerifyAllowRewash")]
        [Test]
        public void TC08_VerifyAllowRewash()
        {
            Runner.DoStep("Click on GENERAL tab by navigating to PlantSetup page", () =>
                {
                    Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
                    Page.PlantSetupPage.GeneralTab.Click();
                });
            //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //Page.SensorTabPage.Language.Focus();
            //Page.SensorTabPage.Language.SelectByText("Deutsch", true);
            //Page.SensorTabPage.Language.Focus();
            //Page.SensorTabPage.Language.SelectByText("English US", true);
            Thread.Sleep(3000);
            if (null != Page.RewashTabPage.GetSwitchNameActive())
            {
                Runner.DoStep("Disable the 'AllowWashContainer' by clicking on it and save the changes", () =>
                {
                    if (Page.RewashTabPage.GetSwitchNameActive() == "Yes")
                    {
                        //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);  
                        Page.RewashTabPage.AllowRewashContainer.DeskTopMouseClick();
                        Thread.Sleep(2000);
                        Page.RewashTabPage.ExportPath.Click();
                    }
                    Thread.Sleep(2000);
                    Page.SensorTabPage.GeneralTabSave.Click();
                });
                Telerik.ActiveBrowser.RefreshDomTree();
                Thread.Sleep(2000);
                Runner.DoStep("Navigate to 'ManualInput' page and check for 'Rewash tab'", ()=> Page.PlantSetupPage.TopMainMenu.NavigateToManualInput());
                Thread.Sleep(3000);
                try
                {
                    if(Page.RewashTabPage.RewashTab.IsVisible())
                    {
                        Assert.Fail("Washing value not appearing in RewashReason drop down");
                    }
                }
                catch(Exception e)
                {
                    Assert.True(true, "Rewash tab not found when allow rewash switch set to No" + e.Message);
                    Runner.DoStep("Click on GENERAL tab by navigating to PlantSetup page", () =>
                    {
                        Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
                        Thread.Sleep(2000);
                        Page.PlantSetupPage.GeneralTab.Click();
                        Thread.Sleep(2000);
                        //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                        //Page.SensorTabPage.Language.Focus();
                        //Page.SensorTabPage.Language.SelectByText("Deutsch", true);
                        //Page.SensorTabPage.Language.Focus();
                        //Page.SensorTabPage.Language.SelectByText("English US", true);
                        //Thread.Sleep(2000);
                        //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                        Page.RewashTabPage.AllowRewashContainer.Focus();
                        Page.RewashTabPage.AllowRewashContainer.DeskTopMouseClick();
                        Thread.Sleep(2000);
                        Page.RewashTabPage.ExportPath.Click();
                        Thread.Sleep(2000);
                        Page.SensorTabPage.GeneralTabSave.Click();
                    });
                    Runner.DoStep("Refresh the DOM Tree", () => Telerik.ActiveBrowser.RefreshDomTree());
                    Runner.DoStep("Navigate to 'ManualInput' page and check for 'Rewash tab'", () => Page.PlantSetupPage.TopMainMenu.NavigateToManualInput());
                    if (Page.RewashTabPage.RewashTab.IsVisible())
                    {
                        Assert.True(true, "Rewash tab found when allow rewash switch set to Yes");
                    }
                }       
            }      
        }

        [TestCategory(TestType.functional, "TC09_UserRolemanagement_Rewash")]
        [TestCategory(TestType.regression, "TC09_UserRolemanagement_Rewash")]
        [Test]
        public void TC09_UserRolemanagement_Rewash()
        {
            Runner.DoStep("Admin Logout", () => Page.PlantSetupPage.TopMainMenu.LogOut());
            Runner.DoStep("Log in as TMAdvanced", () => Page.LoginPage.VerifyLogin(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]));
            Runner.DoStep("Navigate to ManualInput page", () => Page.PlantSetupPage.TopMainMenu.NavigateToManualInput());
            if (!Page.RewashTabPage.RewashTab.IsEnabled)
            {
                Assert.Fail("Rewsah Tab not found on logging in with user role Level 7");
            }
            Runner.DoStep("Logout the user 'TMAdvanced' if Rewash tab is enabled", () => Page.PlantSetupPage.TopMainMenu.LogOut());
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }


        [TestCategory(TestType.functional, "TC10_VerifySaveFunctionality")]
        [TestCategory(TestType.regression, "TC10_VerifySaveFunctionality")]
        [Test]
        public void TC10_VerifySaveFunctionality()
        {
            Thread.Sleep(2000);         
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Thread.Sleep(2000);
            Runner.DoStep("Click on Rewash sub-tab in the Manual Input tab", () =>
            {
                Page.RewashTabPage.RewashTab.Click();
            });            
            Thread.Sleep(2000);
            //Page.RewashTabPage.AddingRewash("Tunnel-Washer2", "ecoform1", "Washing", "25", "5");
            //Page.RewashTabPage.AddingRewash("Tunnel Washer1", "Washing", "25", "5");
            Page.RewashTabPage.WasherGroup.SelectByIndex(1, Timeout);
            Page.RewashTabPage.Formula.SelectByIndex(1, Timeout);
            Page.RewashTabPage.RewashReason.SelectByIndex(1, Timeout);
            Page.RewashTabPage.NewValue.TypeText("24");
            Page.RewashTabPage.Save.Focus();
            Runner.DoStep("Enter details and Save them", () =>
            {
                Page.RewashTabPage.Save.Click();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify Rewash details addition", () =>
            {
                if (null != Page.RewashTabPage.SuccessMsg)
                {
                    string message = Page.RewashTabPage.SuccessMsg.BaseElement.InnerText;
                    if (!message.Contains(@"successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed , Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
        }

        [TestCategory(TestType.functional, "TC11_VerifyUpdateFunctionality")]
        [TestCategory(TestType.regression, "TC11_VerifyUpdateFunctionality")]
        [Test]
        public void TC11_VerifyUpdateFunctionality()
        {                             
            Page.RewashTabPage.LastValue.TypeText("25");
            Page.RewashTabPage.Save.Focus();
            Runner.DoStep("Edit a value and Save it", () =>
            {
                Page.RewashTabPage.Save.Click();
            });           
        }

        [TestCategory(TestType.functional, "TC12_VerifyDeleteFunctionality")]
        [TestCategory(TestType.regression, "TC12_VerifyDeleteFunctionality")]
        [Test]
        public void TC12_VerifyDeleteFunctionality()
        {                        
            Page.RewashTabPage.DeleteRewash.DeskTopMouseClick();
            Runner.DoStep("Delete a Rewash record", () =>
            {
                Page.RewashTabPage.RewashDeleteYes.DeskTopMouseClick();
            });
            Runner.DoStep("Verify the deletion", () =>
            {
                if (!Page.RewashTabPage.RewashDeleteMessage.BaseElement.InnerText.Contains("Deleted successfully"))
                {
                    Assert.Fail("Rewash not deleted");
                }
            });            
            Page.RewashTabPage.NewValue.TypeText("24");
            Page.RewashTabPage.Save.Focus();
            Page.RewashTabPage.Save.Click();
        }


        [TestCategory(TestType.functional, "TC13_VerifyRewashFunctionality")]
        [TestCategory(TestType.regression, "TC13_VerifyRewashFunctionality")]
        [Test]
        public void TC13_VerifyRewashFunctionality()
        {
            Runner.DoStep("Click on Rewash tab", () => Page.RewashTabPage.RewashTab.Click());
            Runner.DoStep("Check each individual fields in the Rewash tab", () => Page.RewashTabPage.CheckFields());
            if (!Page.RewashTabPage.IsLastDateEnabled())
            {
                Assert.True(true, "Last Date field disabled");
            }
            else
            {
                Assert.Fail("Last Date field is not readonly field");
            }

            if (Page.RewashTabPage.IsNewDateEnabled())
            {
                Assert.True(true, "New Date field enabled");
            }
            else
            {
                Assert.Fail("New Date field is readonly field");
            }

            if (Page.RewashTabPage.LastValue.IsEnabled)
            {
                Assert.True(true, "Last Value field enabled");
            }
            else
            {
                Assert.Fail("Last Value field is readonly field");
            }

            if (Page.RewashTabPage.NewValue.IsEnabled)
            {
                Assert.True(true, "New Value field enabled");
            }
            else
            {
                Assert.Fail("New Value field is readonly field");
            }
            Page.RewashTabPage.DeleteRewash.DeskTopMouseClick();
            Page.RewashTabPage.RewashDeleteYes.DeskTopMouseClick();
            if (!Page.RewashTabPage.RewashDeleteMessage.BaseElement.InnerText.Contains("Deleted successfully"))
            {
                Assert.Fail("Rewash not deleted");
            }
        }
        
    }
}
