﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Local
{
    public class AlarmDetailsTest : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.ReportsTabPage.ReportsTab.Click();
            Page.ReportsTabPage.WashingProcessValidationTab.Focus();
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.AlarmsDetailsLink.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }

        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");
        public string customStartDate = null;
        public string customEndDate = null;

        [TestCategory(TestType.NA_NonSanityRegression, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.NA_Regression, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.EU_Regression, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_ADCurrentSearchOperations")]
        [Test, Description("Verifying Current options and its results in Alarm Details Report")]
        public void TC01_ADCurrentSearchOperations()
        {
            Runner.DoStep("Select current and day in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                ValidateToday();
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (previousMonth != currentMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select  current and  week in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                ValidateToday();
                DateTime input = DateTime.Today;
                int sunday = DayOfWeek.Sunday - input.DayOfWeek;
                DateTime sundayDate = input.AddDays(sunday);
                string sundayDay = sundayDate.ToString("dd");
                string sundayMonth = sundayDate.ToString("MMM");
                if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep(" Select current and  month in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                ValidateToday();
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select current and quarter in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                ValidateToday();
                if ((Int32.Parse(previousDay) != 01))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
                string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

                if (firstMonthInQuarter != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });
            Runner.DoStep("Select  current and  year in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                ValidateToday();
                if ((previousDay != "01") || (previousMonth != "Jan"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_NonSanityRegression, "TC02_ADPreviousSearchOperations")]
        [TestCategory(TestType.NA_Regression, "TC02_ADPreviousSearchOperations")]
        [TestCategory(TestType.EU_Regression, "TC02_ADPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_ADPreviousSearchOperations")]
        [Test, Description("Verifying Current options and its results in Alarm Details Report")]
        public void TC02_ADPreviousSearchOperations()
        {
            Runner.DoStep("Select previous  and day in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                List<string> list = new List<string>();
                list.Add(currentDay);
                list.Add(currentMonth);
                list.Add(currentYear);
                foreach (string item in list)
                {
                    if (!yesterday.Contains(item))
                    {
                        flag = true;
                        errorBuilder.Append("\n Date Range is not correct");
                        //Assert.Fail("Date Range is not correct");
                    }
                }
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((previousMonth != currentMonth) || (previousDay != currentDay))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select  previous  and week in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
                DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
                string oldDay = fistDayOfWeek.ToString("dd");
                string oldMonth = fistDayOfWeek.ToString("MMM");
                string newDay = lastDayOfWeek.ToString("dd");
                string newMonth = lastDayOfWeek.ToString("MMM");
                string newYear = lastDayOfWeek.ToString("yyyy");

                if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select previous and  month AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                DateTime last = month.AddDays(-1);
                string lastDate = last.ToString("dd");
                string lastMonth = last.ToString("MMM");
                string lastYear = last.ToString("yyyy");
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select previous and quarter in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                int quarterNumber, prevQNumber;
                DateTime firstDayOfQuarter, lastDayOfQuarter;
                quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                if (quarterNumber == 1)
                {
                    prevQNumber = 4;
                    firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
                }
                else
                {
                    prevQNumber = quarterNumber - 1;
                    firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
                }

                if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select previous year in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                string lastYear = DateTime.Now.AddYears(-1).Year.ToString();
                if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_Regression, "TC03_AddColumns")]
        [TestCategory(TestType.NA_Sanity, "TC03_AddColumns")]
        [TestCategory(TestType.EU_Regression, "TC03_AddColumns")]
        [TestCategory(TestType.EU_Sanity, "TC03_AddColumns")]
        [TestCategory(TestType.reports, "TC03_AddColumns")]
        [Test, Description("Verifying Add Columns functionality in Alarm Details Report")]
        public void TC03_AddColumns()
        {
            Page.ReportsTabPage.CurrentView.Click();
            Page.ReportsTabPage.YearView.Click();
            Page.ReportsTabPage.AddColumn.Click();
            string message = Page.ReportsTabPage.ReportsGridTable.GetReportRows()[1].BaseElement.InnerText;
            Runner.DoStep("Verifying  Add column in ChemicalConsumption Reports", () =>
            {
                if (message.ToLower().Contains("no records"))
                {
                    if (!Page.ReportsTabPage.WasherNumber.Attributes[Page.ReportsTabPage.WasherNumber.Attributes.Count - 1].Name.ToLower().Equals("disabled"))
                    {
                        flag = true;
                        errorBuilder.Append("add column is enabled though data doesn't exist");
                    }
                }
                else
                {
                    if (!Page.ReportsTabPage.WasherNumber.Attributes[Page.ReportsTabPage.WasherNumber.Attributes.Count - 1].Name.ToLower().Equals("disabled"))
                    {
                        Page.ReportsTabPage.WasherNumber.Click();
                        Thread.Sleep(500);
                        if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Washer").Count == 0)
                        {
                            flag = true;
                            errorBuilder.Append("\n Washer Column Not Added");
                        }
                    }

                    if (!Page.ReportsTabPage.BatchNumber.Attributes[Page.ReportsTabPage.BatchNumber.Attributes.Count - 1].Name.ToLower().Equals("disabled"))
                    {
                        Page.ReportsTabPage.BatchNumber.Click();
                        Thread.Sleep(500);
                        if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Washer").Count == 0)
                        {
                            flag = true;
                            errorBuilder.Append("\n Washer Column Not Added");

                        }
                    }

                    if (!Page.ReportsTabPage.PumpValveNumber.Attributes[Page.ReportsTabPage.PumpValveNumber.Attributes.Count - 1].Name.ToLower().Equals("disabled"))
                    {
                        Page.ReportsTabPage.PumpValveNumber.Click();
                        Thread.Sleep(500);
                        if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Pump").Count == 0)
                        {
                            flag = true;
                            errorBuilder.Append("\n PumpValve Column Not Added");
                        }
                    }

                    if (!Page.ReportsTabPage.ChemicalName.Attributes[Page.ReportsTabPage.ChemicalName.Attributes.Count - 1].Name.ToLower().Equals("disabled"))
                    {
                        Page.ReportsTabPage.ChemicalName.Click();
                        Thread.Sleep(500);
                        if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Chemical").Count == 0)
                        {
                            flag = true;
                            errorBuilder.Append("\n Chemical Column Not Added");
                        }
                    }

                    if (!Page.ReportsTabPage.InjectionNumber.Attributes[Page.ReportsTabPage.InjectionNumber.Attributes.Count - 1].Name.ToLower().Equals("disabled"))
                    {
                        Page.ReportsTabPage.InjectionNumber.Click();
                        Thread.Sleep(500);
                        if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Injection").Count == 0)
                        {
                            flag = true;
                            errorBuilder.Append("\n Injection Column Not Added");
                        }
                    }

                    if (!Page.ReportsTabPage.FormulaNumber.Attributes[Page.ReportsTabPage.FormulaNumber.Attributes.Count - 1].Name.ToLower().Equals("disabled"))
                    {
                        Page.ReportsTabPage.FormulaNumber.Click();
                        Thread.Sleep(500);
                        if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Formula").Count == 0)
                        {
                            flag = true;
                            errorBuilder.Append("\n Formula Column Not Added");
                        }
                    }

                    Page.ReportsTabPage.YearView.Click();
                    Thread.Sleep(1000);

                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_Regression, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.NA_Sanity, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.EU_Regression, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.EU_Sanity, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_ADCurrentSearchOperations")]
        [Test, Description("Verifying Calender functionality in Alarm Details Report")]
        public void TC04_VerifyCalenderControl()
        {
            Runner.DoStep(" Verifying  calender control  in AlarmDetails Reports", () =>
            {
                Page.ReportsTabPage.Custom.Click();
                Page.ReportsTabPage.CustomStartDate.SetText("02/09/2016");
                Page.ReportsTabPage.CustomEndDate.SetText("05/08/2016");
                Page.ReportsTabPage.Apply.Click();
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_Regression, "TC05_AddFilter")]
        [TestCategory(TestType.NA_Sanity, "TC05_AddFilter")]
        [TestCategory(TestType.EU_Regression, "TC05_AddFilter")]
        [TestCategory(TestType.EU_Sanity, "TC05_AddFilter")]
        [TestCategory(TestType.reports, "TC05_AddFilter")]
        //[Test, Description("Verifying Add Filter functionality in Alarm Details Report")]
        public void TC05_AddFilter()
        {
            Runner.DoStep("Clicking on AlarmDetails Reports and Adding filter", () =>
              {
                  Page.ReportsTabPage.CurrentView.Click();
                  Page.ReportsTabPage.YearView.Click();
                  Page.ReportsTabPage.Filter.Click();
                  Page.ReportsTabPage.AddMoreFilters.Click();
                  Page.ReportsTabPage.InpDispenser.Click();
                  Page.ReportsTabPage.DrpDispenser.Click();
                  Page.ReportsTabPage.Chk3ULTRAX1kyle.Click();
                  Page.ReportsTabPage.ApplyFilter.Click();
                  if (!Page.ReportsTabPage.ReportsGrid.GetColumnValue(6).Contains("3(ULTRAX1kyle)"))
                  {
                      flag = true;
                      errorBuilder.Append("\n ");
                      //Assert.Fail();
                  }
              });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_Regression, "TC06_VerifyHeaders")]
        [TestCategory(TestType.NA_Sanity, "TC06_VerifyHeaders")]
        [TestCategory(TestType.EU_Regression, "TC06_VerifyHeaders")]
        [TestCategory(TestType.EU_Sanity, "TC06_VerifyHeaders")]
        [TestCategory(TestType.reports, "TC06_VerifyHeaders")]
        [Test, Description("Verifying headers in Alarm Details Report")]
        public void TC06_VerifyHeaders()
        {
            Runner.DoStep("Clicking on AlarmDetails Reports and Verify headers", () =>
             {
                 Page.ReportsTabPage.YearView.Click();
                 List<string> headers = new List<string> { "Alarm Code", "Alarm Description", "Start Date & Time", "End Date & Time", "Duration", "Dispenser" };
                 VerifyHeader(headers);
             });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_Regression, "TC07_DefaultFiltersVerification")]
        [TestCategory(TestType.NA_Sanity, "TC07_DefaultFiltersVerification")]
        [TestCategory(TestType.EU_Regression, "TC07_DefaultFiltersVerification")]
        [TestCategory(TestType.EU_Sanity, "TC07_DefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC07_DefaultFiltersVerification")]
        [Test, Description("Verifying default filters in Alarm Details Report")]
        public void TC07_DefaultFiltersVerification()
        {
            Runner.DoStep("Clicking on AlarmDetails Reports and Verifying default filters", () =>
             {
                 Page.ReportsTabPage.Filter.Click();
                 List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula", "Alarm", "Dispenser" };
                 bool isFilterMatch = Page.ReportsTabPage.DefaultFiltersVerification(AvailableFilters);
                 if (!isFilterMatch)
                 {
                     flag = true;
                     errorBuilder.Append("\n Default Filters are not Correct in Alarm Details Report");
                     //Assert.Fail("Default Filters are not Correct in Alarm Details Report");
                 }
             });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;
            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);
            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}