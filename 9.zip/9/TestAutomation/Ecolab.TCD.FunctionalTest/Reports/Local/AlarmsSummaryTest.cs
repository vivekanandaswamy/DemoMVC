﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Local
{
    public class AlarmsSummaryTest : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.ReportsTabPage.ReportsTab.Click();
            Page.ReportsTabPage.WashingProcessValidationTab.Focus();
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.AlarmsSummaryLink.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");
        public string customStartDate = null;
        public string customEndDate = null;

        [TestCategory(TestType.NA_NonSanityRegression, "TC01_ASCurrentSearchOperations")]
        [TestCategory(TestType.NA_Regression, "TC01_ASCurrentSearchOperations")]
        [TestCategory(TestType.EU_Regression, "TC01_ASCurrentSearchOperations")]       
        [TestCategory(TestType.reports, "TC01_ASCurrentSearchOperations")]
        [Test, Description("Verifying Current options and its results in Alarm Summary Report")]
        public void TC01_ASCurrentSearchOperations()
        {
            Runner.DoStep("Select current and  day in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                ValidateToday();
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (previousMonth != currentMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select current and  week in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                ValidateToday();
                DateTime input = DateTime.Today;
                int sunday = DayOfWeek.Sunday - input.DayOfWeek;
                DateTime sundayDate = input.AddDays(sunday);
                string sundayDay = sundayDate.ToString("dd");
                string sundayMonth = sundayDate.ToString("MMM");
                if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select current and month in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                ValidateToday();
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select  Current and  Quarter in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                ValidateToday();
                if ((Int32.Parse(previousDay) != 01))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
                string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

                if (firstMonthInQuarter != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select current and year in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                ValidateToday();
                if ((previousDay != "01") || (previousMonth != "Jan"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_NonSanityRegression, "TC02_ASPreviousSearchOperations")]
        [TestCategory(TestType.NA_Regression, "TC02_ASPreviousSearchOperations")]
        [TestCategory(TestType.EU_Regression, "TC02_ASPreviousSearchOperations")]      
        [TestCategory(TestType.reports, "TC02_ASPreviousSearchOperations")]
        [Test, Description("Verifying Current options and its results in Alarm Summary Report")]
        public void TC02_ASPreviousSearchOperations()
        {
            Runner.DoStep("Select  previous and day  in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                List<string> list = new List<string>();
                list.Add(currentDay);
                list.Add(currentMonth);
                list.Add(currentYear);
                foreach (string item in list)
                {
                    if (!yesterday.Contains(item))
                    {
                        flag = true;
                        errorBuilder.Append("\n Date Range is not correct");
                        //Assert.Fail("Date Range is not correct");
                    }
                }
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((previousMonth != currentMonth) || (previousDay != currentDay))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select  previous and week in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
                DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
                string oldDay = fistDayOfWeek.ToString("dd");
                string oldMonth = fistDayOfWeek.ToString("MMM");
                string newDay = lastDayOfWeek.ToString("dd");
                string newMonth = lastDayOfWeek.ToString("MMM");
                string newYear = lastDayOfWeek.ToString("yyyy");

                if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select  previous and  month in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                DateTime last = month.AddDays(-1);
                string lastDate = last.ToString("dd");
                string lastMonth = last.ToString("MMM");
                string lastYear = last.ToString("yyyy");
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select   previous and quarter  in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                int quarterNumber, prevQNumber;
                DateTime firstDayOfQuarter, lastDayOfQuarter;
                quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                if (quarterNumber == 1)
                {
                    prevQNumber = 4;
                    firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
                }
                else
                {
                    prevQNumber = quarterNumber - 1;
                    firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
                }

                if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select  previous and year in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                string lastYear = DateTime.Now.AddYears(-1).Year.ToString();
                if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        [TestCategory(TestType.NA_Regression, "TC03_VerifyCalenderControl")]
        [TestCategory(TestType.NA_Sanity, "TC03_VerifyCalenderControl")]
        [TestCategory(TestType.EU_Regression, "TC03_VerifyCalenderControl")]
        [TestCategory(TestType.EU_Sanity, "TC03_VerifyCalenderControl")]
        [TestCategory(TestType.reports, "TC03_VerifyCalenderControl")]
        [Test, Description("Verifying Calender Control in Alarm Summary Report")]
        public void TC03_VerifyCalenderControl()
        {
            Runner.DoStep("Verifying  calender control in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.Custom.Click();
                Page.ReportsTabPage.CustomStartDate.SetText("02/09/2016");
                Page.ReportsTabPage.CustomEndDate.SetText("05/08/2016");
                Page.ReportsTabPage.Apply.Click();
            });
            Runner.DoStep("Verifying grid in selected reports", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_Regression, "TC04_VerifyHeaders")]
        [TestCategory(TestType.NA_Sanity, "TC04_VerifyHeaders")]
        [TestCategory(TestType.EU_Regression, "TC04_VerifyHeaders")]
        [TestCategory(TestType.EU_Sanity, "TC04_VerifyHeaders")]
        [TestCategory(TestType.reports, "TC04_VerifyHeaders")]
        [Test, Description("Verifying Headers  in Alarm Summary Report")]
        public void TC04_VerifyHeaders()
        {
            Runner.DoStep("Verifying  headers in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.YearView.Click();
                List<string> headers = new List<string> { "Alarm Code", "Alarm Description",  "No.of Alarms" };
                VerifyHeader(headers);
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.NA_Regression, "TC05_DefaultFiltersVerification")]
        [TestCategory(TestType.NA_Sanity, "TC05_DefaultFiltersVerification")]
        [TestCategory(TestType.EU_Regression, "TC05_DefaultFiltersVerification")]
        [TestCategory(TestType.EU_Sanity, "TC05_DefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC05_DefaultFiltersVerification")]
        [Test, Description("Verifying Default filters  in Alarm Summary Report")]
        public void TC05_DefaultFiltersVerification()
        {
            Runner.DoStep("Verifying  default filters in AlarmsSummary reports", () =>
            {
                Page.ReportsTabPage.Filter.Click();
                List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula", "Alarm", "Dispenser" };
                bool isFilterMatch = Page.ReportsTabPage.DefaultFiltersVerification(AvailableFilters);
                if (!isFilterMatch)
                {
                    flag = true;
                    errorBuilder.Append("\n Default Filters are not Correct in Production Summary Report");
                    //Assert.Fail("Default Filters are not Correct in Production Summary Report");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;
            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);
            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
