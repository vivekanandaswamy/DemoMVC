﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class Rewash : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ProductionEfficiencyTab.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.ReportsTabPage.RewashLink.DeskTopMouseClick();
            Thread.Sleep(1000);
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Sanity, "TC01_RWCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Regression, "TC01_RWCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_RWCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_RWCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_RWCurrentSearchOperations")]
        [Test, Description("Verify the 'Date range' output for the 'Current' search functionality")]
        public void TC01_RWCurrentSearchOperations()
        {
            //current day
            Page.ReportsTabPage.CurrentView.Focus();
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Day options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.DayView.Click();
            });
            GetValues();
            ValidateToday();
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if (previousMonth != currentMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current week
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Week options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.WeekView.Click();
            });
            Page.ReportsTabPage.WeekView.Click();
            GetValues();
            ValidateToday();
            DateTime input = DateTime.Today;
            int sunday = DayOfWeek.Sunday - input.DayOfWeek;
            DateTime sundayDate = input.AddDays(sunday);
            string sundayDay = sundayDate.ToString("dd");
            string sundayMonth = sundayDate.ToString("MMM");
            if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current Month
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Month options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.MonthView.Click();
            });
            GetValues();
            ValidateToday();
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current Quarter
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Quarter options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.QuarterView.Click();
            });
            GetValues();
            ValidateToday();
            if ((Int32.Parse(previousDay) != 01))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
            //Friday, April 01, 2016
            string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

            if (firstMonthInQuarter != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current year
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Quarter options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.YearView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            ValidateToday();
            if ((previousDay != "01") || (previousMonth != "Jan"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current R12
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, R12 options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            //validateToday();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
              //  Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if(flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC02_RWPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Regression, "TC02_RWPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_RWPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_RWPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_RWPreviousSearchOperations")]
        [Test, Description("Verify the 'Date range' output for the 'Previous' search functionality")]
        public void TC02_RWPreviousSearchOperations()
        {
            //previous day
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Day options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.DayView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!yesterday.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");
                  //  Assert.Fail("Date Range is not correct");
                }
            }
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if ((previousMonth != currentMonth) || (previousDay != currentDay))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //previous week
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Week options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();
            DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
            DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
            string oldDay = fistDayOfWeek.ToString("dd");
            string oldMonth = fistDayOfWeek.ToString("MMM");
            string newDay = lastDayOfWeek.ToString("dd");
            string newMonth = lastDayOfWeek.ToString("MMM");
            string newYear = lastDayOfWeek.ToString("yyyy");

            if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //previous month
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Month options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.MonthView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DateTime last = month.AddDays(-1);
            string lastDate = last.ToString("dd");
            string lastMonth = last.ToString("MMM");
            string lastYear = last.ToString("yyyy");
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //previous Quarter
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Quarter options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.QuarterView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            int quarterNumber, prevQNumber;
            DateTime firstDayOfQuarter, lastDayOfQuarter;
            quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            if (quarterNumber == 1)
            {
                prevQNumber = 4;
                firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
            }
            else
            {
                prevQNumber = quarterNumber - 1;
                firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
            }

            if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
              //  Assert.Fail("Date Range is not correct");
            }
            if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //previous year
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Year options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.YearView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            string lastYear1 = DateTime.Now.AddYears(-1).Year.ToString();
            if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear1))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //previous R12
            Page.ReportsTabPage.DayView.Click();
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, R12 options in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
               // Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Sanity, "TC03_RWStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Regression, "TC03_RWStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_RWStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_RWStandardCustomNavigate")]
        //[TestCategory(TestType.reports, "TC03_RWStandardCustomNavigate")]
        [Test, Description("Verify the Standard and Custom navigation functionalities")]
        public void TC03_RWStandardCustomNavigate()
        {
            Runner.DoStep("Click on the Custom navigation link in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
            });
            if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Custom Navigation is not correct");
             //   Assert.Fail("Custom Navigation is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            Runner.DoStep("Click on the Standard navigation link in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
            });
            if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Standard Navigation is not correct");
               // Assert.Fail("Standard Navigation is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC04_RWCustomValidation")]
        //[TestCategory(TestType.NA_Regression, "TC04_RWCustomValidation")]
        //[TestCategory(TestType.EU_Sanity, "TC04_RWCustomValidation")]
        //[TestCategory(TestType.EU_Regression, "TC04_RWCustomValidation")]
        [TestCategory(TestType.reports, "TC04_RWCustomValidation")]
        [Test, Description("Verify the Custom period selection functionality")]
        public void TC04_RWCustomValidation()
        {
            Page.ReportsTabPage.Custom.Focus();
            Page.ReportsTabPage.Custom.Click();
            DateTime customStartDate = DateTime.ParseExact("03/27/2015", "MM/dd/yyyy", CultureInfo.InvariantCulture);
            DateTime customEndDate = DateTime.ParseExact("03/29/2016", "MM/dd/yyyy", CultureInfo.InvariantCulture);
            Page.ReportsTabPage.CustomFromDate.SetText(customStartDate.ToString("MM/dd/yyyy"));
            Page.ReportsTabPage.CustomToDate.SetText(customEndDate.ToString("MM/dd/yyyy"));
            Runner.DoStep("Select two Custom dates in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.Apply.Click();
            });
            string dateRangelbl = null;
            dateRangelbl = customStartDate.ToString("dd MMM yyyy") + " - " + customEndDate.ToString("dd MMM yyyy");
            if (Page.ReportsTabPage.DateRange.BaseElement.InnerText != dateRangelbl)
            {
                flag = true;
                errorBuilder.Append("Date Range is not matched with selected dates");
               // Assert.Fail("Date Range is not matched with selected dates");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC05_RWViewCategoryValidation")]
        //[TestCategory(TestType.NA_Regression, "TC05_RWViewCategoryValidation")]
        //[TestCategory(TestType.EU_Sanity, "TC05_RWViewCategoryValidation")]
        //[TestCategory(TestType.EU_Regression, "TC05_RWViewCategoryValidation")]
        [TestCategory(TestType.reports, "TC05_RWViewCategoryValidation")]
        [Test, Description("Verify different views")]
        public void TC05_RWViewCategoryValidation()
        {
            //Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            //Thread.Sleep(2000);
            Page.ReportsTabPage.PSViewCategoryCentral.Click();
            Runner.DoStep("Click on TIME view in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.PTimeCategoryCentral.Click();
            });
            Thread.Sleep(2000);
            string v = Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText;
            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("Interval"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Time Category");
             //   Assert.Fail("Header column is not matched with selected Time Category ");
            }
            Page.ReportsTabPage.PSViewCategoryCentral.Click();
            Runner.DoStep("Click on LOCATION view in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.PLocationCategoryCentral.Click();
            });
            Thread.Sleep(2000);
            string b = Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText;
            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("Location"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Location Category ");
                //Assert.Fail("Header column is not matched with selected Location Category ");
            }
            Page.ReportsTabPage.PSViewCategoryCentral.Click();
            Runner.DoStep("Click on FORMULA view in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.PFormulaCategoryCentral.Click();
            });
            Thread.Sleep(2000);
            string b1 = Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText;
            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("Formula Segment"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Formula Category");
               // Assert.Fail("Header column is not matched with selected Formula Category ");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC06_RWFilter")]
        //[TestCategory(TestType.NA_Regression, "TC06_RWFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC06_RWFilter")]
        //[TestCategory(TestType.EU_Regression, "TC06_RWFilter")]
        [TestCategory(TestType.reports, "TC06_RWFilter")]
        [Test, Description("Verify the Filter functionality")]
        public void TC06_RWFilter()
        {
            Page.ReportsTabPage.Filter.Click();
            Page.ReportsTabPage.MachineTypeSelection.Click();
            Page.ReportsTabPage.MachineTypeSelectAll.Click();
            Page.ReportsTabPage.MachineTypeOptionSelection.Click();
            Runner.DoStep("Select filters in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.ApplyFilter.Click();
            });
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC07_RWVerifyHeaders")]
        //[TestCategory(TestType.NA_Regression, "TC07_RWVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC07_RWVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC07_RWVerifyHeaders")]
        [TestCategory(TestType.reports, "TC07_RWVerifyHeaders")]
        [Test, Description("Verify the Headers in the page")]
        public void TC07_RWVerifyHeaders()
        {
            Runner.DoStep("Verify columns in 'Rewash' page", () =>
            {
                List<string> headers = new List<string> { "Actual Production ", "Rewash ", "Rewash (%)",
                "Rewash Cost" };
                Page.ReportsTabPage.VerifyHeader(headers);
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC08_RWDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Regression, "TC08_RWDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC08_RWDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC08_RWDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC08_RWDefaultFiltersVerification")]
        [Test, Description("Verify the default filters functionality in the page")]
        public void TC08_RWDefaultFiltersVerification()
        {
            Runner.DoStep("Click on the Filter button in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.Filter.Click();
            });
            List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula Segment", "Formula", "Formula Category", "Plant Customer" };
            bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
            if (!isFilterMatch)
            {
                flag = true;
                errorBuilder.Append("Default Filters are not Correct in Production Summary Report");
             //   Assert.Fail("Default Filters are not Correct in Production Summary Report");

            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC09_RWAddToFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC09_RWAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC09_RWAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC09_RWAddToFavourite")]
        [TestCategory(TestType.reports, "TC09_RWAddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC09_RWAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Rewash AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);

            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC10_RWDownloadReport")]
        //[TestCategory(TestType.NA_Regression, "TC10_RWDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC10_RWDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC10_RWDownloadReport")]
        [TestCategory(TestType.reports, "TC10_RWDownloadReport")]
        [Test, Description("Verify the Excel and PDF functionalities")]
        public void TC10_RWDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.ProductionEfficiencyTab.DeskTopMouseClick();
            Page.ReportsTabPage.RewashLink.DeskTopMouseClick();
            Thread.Sleep(1000);
            Runner.DoStep("Click on the Excel button in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Rewash";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);

            Runner.DoStep("Click on the PDF button in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC11_RWRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC11_RWRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC11_RWRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC11_RWRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC11_RWRemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC11_RWRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Rewash AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");
                  //  Assert.Fail("Date Range is not correct");
                }
            }
        }
        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);
        }

    }
}
