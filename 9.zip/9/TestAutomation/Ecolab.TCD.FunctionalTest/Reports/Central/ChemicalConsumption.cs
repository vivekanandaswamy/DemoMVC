﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class ChemicalConsumption : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Page.ReportsTabPage.ChemicalConsumptionLink.DeskTopMouseClick();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Regression, "TC01_CCCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_CCCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_CCCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_CCCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_CCCurrentSearchOperations")]
        [Test, Description("Verifying Current search options and its results in Alarm Details Report")]
        public void TC01_CCCurrentSearchOperations()
        {
            Runner.DoStep("Select Current and Day options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                ValidateToday();
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (previousMonth != currentMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Week options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                ValidateToday();
                DateTime input = DateTime.Today;
                int sunday = DayOfWeek.Sunday - input.DayOfWeek;
                DateTime sundayDate = input.AddDays(sunday);
                string sundayDay = sundayDate.ToString("dd");
                string sundayMonth = sundayDate.ToString("MMM");
                if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Month options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                ValidateToday();
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Quarter options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                ValidateToday();
                if ((Int32.Parse(previousDay) != 01))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
                //Friday, April 01, 2016
                string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

                if (firstMonthInQuarter != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Year options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                ValidateToday();
                if ((previousDay != "01") || (previousMonth != "Jan"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and R12 options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.R12.Click();
                GetValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC02_CCPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC02_CCPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_CCPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_CCPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_CCPreviousSearchOperations")]
        [Test, Description("Verifying previous search options and its results in Alarm Details Report")]
        public void TC02_CCPreviousSearchOperations()
        {
            Runner.DoStep("Select Previous and Day options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                List<string> list = new List<string>();
                list.Add(currentDay);
                list.Add(currentMonth);
                list.Add(currentYear);
                foreach (string item in list)
                {
                    if (!yesterday.Contains(item))
                    {
                        flag = true;
                        errorBuilder.Append("\n Date Range is not correct");
                        //Assert.Fail("Date Range is not correct");
                    }
                }
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((previousMonth != currentMonth) || (previousDay != currentDay))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Week options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
                DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
                string oldDay = fistDayOfWeek.ToString("dd");
                string oldMonth = fistDayOfWeek.ToString("MMM");
                string newDay = lastDayOfWeek.ToString("dd");
                string newMonth = lastDayOfWeek.ToString("MMM");
                string newYear = lastDayOfWeek.ToString("yyyy");

                if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Month options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                DateTime last = month.AddDays(-1);
                string lastDate = last.ToString("dd");
                string lastMonth = last.ToString("MMM");
                string lastYear = last.ToString("yyyy");
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Quarter options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                int quarterNumber, prevQNumber;
                DateTime firstDayOfQuarter, lastDayOfQuarter;
                quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                if (quarterNumber == 1)
                {
                    prevQNumber = 4;
                    firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
                }
                else
                {
                    prevQNumber = quarterNumber - 1;
                    firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
                }

                if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Year options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                string lastYear = DateTime.Now.AddYears(-1).Year.ToString();
                if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and R12 options in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.DayView.Click();
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.R12.Click();
                GetValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC03_CCStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Sanity, "TC03_CCStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_CCStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_CCStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_CCStandardCustomNavigate")]
        [Test, Description("Verifying Standard and Custom Navigation in Chemical Consumption Report")]
        public void TC03_CCStandardCustomNavigate()
        {
            Runner.DoStep("Select Custom Navigation in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
                if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    flag = true;
                    errorBuilder.Append("\n Custom Navigation is not correct");
                    //Assert.Fail("Custom Navigation is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });
            Runner.DoStep("Select Standard Navigation in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
                if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    flag = true;
                    errorBuilder.Append("\n Standard Navigation is not correct");
                    //Assert.Fail("Standard Navigation is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC04_CCAddColumns")]
        //[TestCategory(TestType.NA_Sanity, "TC04_CCAddColumns")]
        //[TestCategory(TestType.EU_Regression, "TC04_CCAddColumns")]
        //[TestCategory(TestType.EU_Sanity, "TC04_CCAddColumns")]
        [TestCategory(TestType.reports, "TC04_CCAddColumns")]
        [Test, Description("Verifying Add Columns functionality in Chemical Consumption Report")]
        public void TC04_CCAddColumns()
        {
            Page.ReportsTabPage.AddColumn.Click();
            Page.ReportsTabPage.TargetConsumption.Click();
            Page.ReportsTabPage.AverageDailyConsumption.Click();

            Runner.DoStep("Select Columns to Add in the resulting grid in Chemical Consumption Report", () =>
            {

                Page.ReportsTabPage.CostExcess.Click();
            });

            Page.ReportsTabPage.AddColumn.Click();

            Runner.DoStep("Verify added columns in the resulting grid in Chemical Consumption Report", () =>
            {
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Target Consumption").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Column Not Added");
                    //Assert.Fail("Column Not Added");
                }
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Average Daily Consumption").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Column Not Added");
                    //Assert.Fail("Column Not Added");
                }
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Cost Excess ").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Column Not Added");
                    //Assert.Fail("Column Not Added");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC05_CCVerifyCalenderControl")]
        //[TestCategory(TestType.NA_Sanity, "TC05_CCVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Regression, "TC05_CCVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Sanity, "TC05_CCVerifyCalenderControl")]
        [TestCategory(TestType.reports, "TC05_CCVerifyCalenderControl")]
        [Test, Description("Verifying Date selection through custom fields and its results in Chemical Consumption Report")]
        public void TC05_CCVerifyCalenderControl()
        {
            Runner.DoStep("Select Date rang through custom fields in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.Custom.Click();
                Page.ReportsTabPage.CustomStartDate.SetText("02/09/2016");
                Page.ReportsTabPage.CustomEndDate.SetText("05/08/2016");
                Page.ReportsTabPage.Apply.Click();
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC06_CCVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC06_CCVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC06_CCVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC06_CCVerifyHeaders")]
        [TestCategory(TestType.reports, "TC06_CCVerifyHeaders")]
        [Test, Description("Verifying grid headers in Chemical Consumption Report")]
        public void TC06_CCVerifyHeaders()
        {
            List<string> headers = new List<string> { "Chemicals", "Total Consumption", "UoM", "Actual Chemical Usage", "Actual Cost" };
            Runner.DoStep("Verify Grid Headers in Chemical Consumption Report", () =>
            {
                VerifyHeader(headers);
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC07_CCDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Sanity, "TC07_CCDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC07_CCDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC07_CCDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC07_CCDefaultFiltersVerification")]
        [Test, Description("Verifying default filters in Chemical Consumption Report")]
        public void TC07_CCDefaultFiltersVerification()
        {
            Runner.DoStep("Verifying default filters in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.Filter.Click();
                List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula Segment", "Formula Category", "Plant Customer" };

                bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
                if (!isFilterMatch)
                {
                    flag = true;
                    errorBuilder.Append("\n Default Filters are not Correct in Production Summary Report");
                    //Assert.Fail("Default Filters are not Correct in Production Summary Report");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC08_CCFilter")]
        //[TestCategory(TestType.NA_Sanity, "TC08_CCFilter")]
        //[TestCategory(TestType.EU_Regression, "TC08_CCFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC08_CCFilter")]
        [TestCategory(TestType.reports, "TC08_CCFilter")]
        [Test, Description("Verify the Filter functionality")]
        public void TC08_CCFilter()
        {
            Runner.DoStep("Select filters in 'Chemical Consumption' page", () =>
            {
                Page.ReportsTabPage.PSFilterCentral.Click();
                Page.ReportsTabPage.AddMoreFilters.Click();
                Page.ReportsTabPage.WPRBFormulaFormSegFilt.Click();
                Page.ReportsTabPage.WPPVHealthCareFilt.Click();
                Page.ReportsTabPage.ApplyFilter.Click();
            });
            VerifyGrid();

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC09_CCAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC09_CCAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC09_CCAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC09_CCAddToFavourite")]
        [TestCategory(TestType.reports, "TC09_CCAddToFavourite")]
        [Test, Description("Verifying Add to Favourite functionality in Chemical Consumption Report")]
        public void TC09_CCAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Chemical Consumption AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC10_CCDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC10_CCDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC10_CCDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC10_CCDownloadReport")]
        [TestCategory(TestType.reports, "TC10_CCDownloadReport")]
        [Test, Description("Verifying Export to Excel, PDF functionality in Chemical Consumption Report")]
        public void TC10_CCDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Page.ReportsTabPage.ChemicalConsumptionLink.Click();
            Runner.DoStep("Click on Export to Excel icon in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Chemical Consumption";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on Export to PDF icon in Chemical Consumption Report", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC11_CCRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC11_CCRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC11_CCRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC11_CCRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC11_CCRemoveFromFavourite")]
        [Test, Description("Verifying Remove from Favourite functionality in Chemical Consumption Report")]
        public void TC11_CCRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Chemical Consumption AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {

                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }

    }
}
