﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class AccountSummary : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.EcolabInternalTabCentral.DeskTopMouseClick();
            Page.ReportsTabPage.AccountSummary.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        //[TestCategory(TestType.NA_Regression, "TC01_ASVerifyGrid")]
        //[TestCategory(TestType.NA_Sanity, "TC01_ASVerifyGrid")]
        //[TestCategory(TestType.EU_Regression, "TC01_ASVerifyGrid")]
        //[TestCategory(TestType.EU_Sanity, "TC01_ASVerifyGrid")]
        [TestCategory(TestType.reports, "TC01_ASVerifyGrid")]
        [Test, Description("Verifying grid in Account Summary Report")]
        public void TC01_ASVerifyGrid()
        {
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid in Account Summary Report", () =>
            {
                int rowcount = Page.ReportsTabPage.ReportsGridTable.Rows.Count;
                if (Page.ReportsTabPage.ReportsGridTable.Rows.Count > 0)
                {
                    if (!Page.ReportsTabPage.ReportsGridTable.Rows[0].BaseElement.InnerText.Contains("No Records To Display The Table"))
                    {
                        Assert.IsTrue(true);
                    }
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("\n Error occurred without data");
                    //Assert.Fail("Error occurred without data");
                }                    
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC02_ASVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC02_ASVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC02_ASVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC02_ASVerifyHeaders")]
        [TestCategory(TestType.reports, "TC02_ASVerifyHeaders")]
        [Test, Description("Verifying grid headers in Account Summary Report")]
        public void TC02_ASVerifyHeaders()
        {
            Runner.DoStep("Verify Grid Headers in Account Summary Report", () =>
            {
                List<string> headers = new List<string> { "Corporate", "Country", "Plant Name", "Flat Fee" };
                VerifyHeader(headers);
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC03_ASAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC03_ASAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC03_ASAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC03_ASAddToFavourite")]
        [TestCategory(TestType.reports, "TC03_ASAddToFavourite")]
        [Test, Description("Verifying Add to Favourite functionality in Account Summary Report")]
        public void TC03_ASAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);

            string reportName = "Account Summary AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);

            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid in Account Summary Report", () =>
            {
                int rowcount = Page.ReportsTabPage.ReportsGridTable.Rows.Count;
                if (Page.ReportsTabPage.ReportsGridTable.Rows.Count > 0)
                {
                    if (!Page.ReportsTabPage.ReportsGridTable.Rows[0].BaseElement.InnerText.Contains("No Records To Display The Table"))
                    {
                        Assert.IsTrue(true);
                    }
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("\n Error occurred without data");
                    //Assert.Fail("Error occurred without data");
                }                    
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC04_ASDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC04_ASDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC04_ASDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC04_ASDownloadReport")]
        [TestCategory(TestType.reports, "TC04_ASDownloadReport")]
        [Test, Description("Verifying Export to Excel, PDF functionality in Account Summary Report")]
        public void TC04_ASDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.EcolabInternalTabCentral.DeskTopMouseClick();
            Page.ReportsTabPage.AccountSummary.Click();
            Runner.DoStep("Click on Export to Excel icon in Account Summary Report", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Account Summary";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on Export to PDF icon in Account Summary Report", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC05_ASRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC05_ASRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC05_ASRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC05_ASRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC05_ASRemoveFromFavourite")]
        [Test, Description("Verifying Remove from Favourite functionality in Account Summary Report")]
        public void TC05_ASRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Account Summary AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
    }
}
