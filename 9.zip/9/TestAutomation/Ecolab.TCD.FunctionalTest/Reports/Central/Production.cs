﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class Production : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ProductionEfficiencyTab.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.ReportsTabPage.ProductionLink.DeskTopMouseClick();
            Thread.Sleep(1000);
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Regression, "TC01_PCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_PCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_PCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_PCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_PCurrentSearchOperations")]
        [Test, Description("Verifying Current search options and its results in  Production Report")]
        public void TC01_PCurrentSearchOperations()
        {
            Runner.DoStep("Select Current, Day options in 'Production' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
            });
            GetValues();
            ValidateToday();
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (previousMonth != currentMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Week options in 'Production' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
            });

            GetValues();
            ValidateToday();
            DateTime input = DateTime.Today;
            int sunday = DayOfWeek.Sunday - input.DayOfWeek;
            DateTime sundayDate = input.AddDays(sunday);
            string sundayDay = sundayDate.ToString("dd");
            string sundayMonth = sundayDate.ToString("MMM");
            if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Month options in 'Production' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
            });
            GetValues();
            ValidateToday();
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Quarter options in 'Production' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            ValidateToday();
            if ((Int32.Parse(previousDay) != 01))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
            //Friday, April 01, 2016
            string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

            if (firstMonthInQuarter != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Year options in 'Production' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            ValidateToday();
            if ((previousDay != "01") || (previousMonth != "Jan"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, R12 options in 'Production' page", () =>
            {
                Page.ReportsTabPage.DayView.Click();
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            //validateToday();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if(flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC02_PPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC02_PPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_PPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_PPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_PPreviousSearchOperations")]
        [Test, Description("Verifying Previous search options and its results in  Production Report")]
        public void TC02_PPreviousSearchOperations()
        {
            Runner.DoStep("Select Previous, Week options in 'Production' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();
            DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
            DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
            string oldDay = fistDayOfWeek.ToString("dd");
            string oldMonth = fistDayOfWeek.ToString("MMM");
            string newDay = lastDayOfWeek.ToString("dd");
            string newMonth = lastDayOfWeek.ToString("MMM");
            string newYear = lastDayOfWeek.ToString("yyyy");

            if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();


            Runner.DoStep("Select Previous, Week options in 'Production' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();

            if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Previous, Month options in 'Production' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
            });
            GetValues();
            DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DateTime last = month.AddDays(-1);
            string lastDate = last.ToString("dd");
            string lastMonth = last.ToString("MMM");
            string lastYear = last.ToString("yyyy");
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Previous, Quarter options in 'Production' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            int quarterNumber, prevQNumber;
            DateTime firstDayOfQuarter, lastDayOfQuarter;
            quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            if (quarterNumber == 1)
            {
                prevQNumber = 4;
                firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
            }
            else
            {
                prevQNumber = quarterNumber - 1;
                firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
            }

            if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Previous, Year options in 'Production' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            lastYear = DateTime.Now.AddYears(-1).Year.ToString();
            if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Previous, R12 options in 'Production' page", () =>
            {
                Page.ReportsTabPage.DayView.Click();
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC03_PStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Sanity, "TC03_PStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_PStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_PStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_PStandardCustomNavigate")]
        [Test, Description("Verify the Standard and Custom navigation functionalities")]
        public void TC03_PStandardCustomNavigate()
        {
            Runner.DoStep("Click on the Custom navigation link in 'Production' page", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
            });
            if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Custom Navigation is not correct");
                //Assert.Fail("Custom Navigation is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Click on the Standard navigation link in 'Production' page", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
            });
            if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Standard Navigation is not correct");
                //Assert.Fail("Standard Navigation is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC04_PViewCategoryValidation")]
        //[TestCategory(TestType.NA_Sanity, "TC04_PViewCategoryValidation")]
        //[TestCategory(TestType.EU_Regression, "TC04_PViewCategoryValidation")]
        //[TestCategory(TestType.EU_Sanity, "TC04_PViewCategoryValidation")]
        [TestCategory(TestType.reports, "TC04_PViewCategoryValidation")]
        [Test, Description("Verify different views")]
        public void TC04_PViewCategoryValidation()
        {
            Page.ReportsTabPage.ViewCategory.Click();
            Runner.DoStep("Click on TIME view in 'Production' page", () =>
            {
                Page.ReportsTabPage.PTimeCategoryCentral.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.ReportsGrid.GetReportRows()[0].BaseElement.InnerText.Contains("Interval"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Time Category");
                //Assert.Fail("Header column is not matched with selected Time Category ");
            }
            Page.ReportsTabPage.ViewCategory.Click();
            Runner.DoStep("Click on LOCATION view in 'Production' page", () =>
            {
                Page.ReportsTabPage.PLocationCategoryCentral.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.ReportsGrid.GetReportRows()[0].BaseElement.InnerText.Contains("Location"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Location Category");
               // Assert.Fail("Header column is not matched with selected Location Category ");
            }
            Page.ReportsTabPage.ViewCategory.Click();
            Runner.DoStep("Click on FORMULA view in 'Production' page", () =>
            {
                Page.ReportsTabPage.PFormulaCategoryCentral.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("Formula Segment"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Formula Category");
              //  Assert.Fail("Header column is not matched with selected Formula Category ");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC05_PAddColumns")]
        //[TestCategory(TestType.NA_Sanity, "TC05_PAddColumns")]
        //[TestCategory(TestType.EU_Regression, "TC05_PAddColumns")]
        //[TestCategory(TestType.EU_Sanity, "TC05_PAddColumns")]
        [TestCategory(TestType.reports, "TC05_PAddColumns")]
        [Test, Description("Verify ADD COLUMNS functionality")]
        public void TC05_PAddColumns()
        {
            Page.ReportsTabPage.PSAddColumn.Click();
            Runner.DoStep("Add ACTUAL PRODUCTION column in 'Production' page", () =>
            {
                Page.ReportsTabPage.PActualProductionCentral.Click();
            });
            Page.ReportsTabPage.PStandardProductionCentral.Click();
            Runner.DoStep("Add NUMBER OF PIECES column in 'Production' page", () =>
            {
                Page.ReportsTabPage.PNumOfPiecesCentral.Click();
            });
            Page.ReportsTabPage.PStandardProduction.Click();
            Page.ReportsTabPage.ProductionVariance.Click();
            Runner.DoStep("Add REWASH column in 'Production' page", () =>
            {
                Page.ReportsTabPage.AddColumnRewash.Click();
            });
            Page.ReportsTabPage.LoadEfficiency.Click();

            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Actual Production ").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Actual ProductionColumn Not Added");
                //Assert.Fail("Column Not Added Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Standard Production ").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Standard Production Column Not Added");
               // Assert.Fail("Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("No. of Pieces").Count == 0)
            {
                flag = true;
                errorBuilder.Append("No. of Pieces Column Not Added");
                //Assert.Fail("Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Standard Production ").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Standard Production Column Not Added");
               // Assert.Fail("Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Production Variance ").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Production Variance  Column Not Added");
              //  Assert.Fail("Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Rewash (%)").Count == 0)
            {
                flag = true;
                errorBuilder.Append(" Rewash Column Not Added");
               // Assert.Fail("Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Load Efficiency (%)").Count == 0)
            {
                flag = true;
                errorBuilder.Append(" Load Efficiency Column Not Added");
              //  Assert.Fail("Column Not Added");
            }           
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC06_PCustomValidation")]
        //[TestCategory(TestType.NA_Sanity, "TC06_PCustomValidation")]
        //[TestCategory(TestType.EU_Regression, "TC06_PCustomValidation")]
        //[TestCategory(TestType.EU_Sanity, "TC06_PCustomValidation")]
        [TestCategory(TestType.reports, "TC06_PCustomValidation")]
        [Test, Description("Verify the Custom period selection functionality")]
        public void TC06_PCustomValidation()
        {
            Page.ReportsTabPage.Custom.Focus();
            Page.ReportsTabPage.Custom.Click();
            DateTime customStartDate = DateTime.ParseExact("03/27/2015", "MM/dd/yyyy", CultureInfo.InvariantCulture);
            DateTime customEndDate = DateTime.ParseExact("03/29/2016", "MM/dd/yyyy", CultureInfo.InvariantCulture);
            Page.ReportsTabPage.CustomFromDate.SetText(customStartDate.ToString("MM/dd/yyyy"));
            Page.ReportsTabPage.CustomToDate.SetText(customEndDate.ToString("MM/dd/yyyy"));
            Runner.DoStep("Select two Custom dates in 'Production' page", () =>
            {
                Page.ReportsTabPage.Apply.Click();
            });
            Thread.Sleep(2000);
            string dateRangelbl = null;
            dateRangelbl = customStartDate.ToString("dd MMM yyyy") + " - " + customEndDate.ToString("dd MMM yyyy");
            if (Page.ReportsTabPage.DateRange.BaseElement.InnerText != dateRangelbl)
            {
                flag = true;
                errorBuilder.Append("Date Range is not matched with selected dates");
              //  Assert.Fail("Date Range is not matched with selected dates");
            }
            Page.ReportsTabPage.VerifyGrid();
        }

        //[TestCategory(TestType.NA_Regression, "TC07_PVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC07_PVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC07_PVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC07_PVerifyHeaders")]
        [TestCategory(TestType.reports, "TC07_PVerifyHeaders")]
        [Test, Description("Verify the Headers in the page")]
        public void TC07_PVerifyHeaders()
        {
            Runner.DoStep("Verify columns in 'Production' page", () =>
            {
                List<string> headers = new List<string> { "Actual Production ", "Production Mix (%)","Total Chemical Cost ",
            "Chemical Cost Mix (%)","No. of Loads"};
                Page.ReportsTabPage.VerifyHeader(headers);
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC08_PCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Sanity, "TC08_PCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC08_PCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC08_PCentralDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC08_PCentralDefaultFiltersVerification")]
        [Test, Description("Verify the default filters functionality in the page")]
        public void TC08_PCentralDefaultFiltersVerification()
        {
            Runner.DoStep("Click on the Filter button in 'Production' page", () =>
            {
                Page.ReportsTabPage.Filter.Click();
            });
            List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula Segment", "Formula", "Formula Category", "Plant Customer" };
            bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
            if (!isFilterMatch)
            {
                flag = true;
                errorBuilder.Append("Default Filters are not Correct in Production Report");
              //  Assert.Fail("Default Filters are not Correct in Production Report");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC09_PAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC09_PAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC09_PAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC09_PAddToFavourite")]
        [TestCategory(TestType.reports, "TC09_PAddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC09_PAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Production AutoTest";

            Page.ReportsTabPage.AddToFavourites(reportName, result);

            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC10_PDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC10_PDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC10_PDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC10_PDownloadReport")]
        [TestCategory(TestType.reports, "TC10_PDownloadReport")]
        [Test, Description("Verify the Excel and PDF functionalities")]
        public void TC10_PDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.ProductionEfficiencyTab.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.ReportsTabPage.ProductionLink.DeskTopMouseClick();
            Thread.Sleep(1000);
            Runner.DoStep("Click on the Excel button in 'Production' page", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Production Details";
            Thread.Sleep(2000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);

            Runner.DoStep("Click on the PDF button in 'Production' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(2000);

            Page.ReportsTabPage.PDFVerify(partialName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC11_PRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC11_PRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC11_PRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC11_PRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC11_PRemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC11_PRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Production AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC12_PFilter")]
        //[TestCategory(TestType.NA_Sanity, "TC12_PFilter")]
        //[TestCategory(TestType.EU_Regression, "TC12_PFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC12_PFilter")]
        [TestCategory(TestType.reports, "TC12_PFilter")]
        [Test, Description("Verify the Filter functionality")]
        public void TC12_PFilter()
        {
            Runner.DoStep("Select filters in 'Production' page", () =>
            {
                Page.ReportsTabPage.PSFilterCentral.Click();
                Page.ReportsTabPage.AddMoreFilters.Click();
                Page.ReportsTabPage.WPRBFormulaFormSegFilt.Click();
                Page.ReportsTabPage.WPPVHealthCareFilt.Click();
                Page.ReportsTabPage.ApplyFilter.Click();
            });
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }

        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);

            // dayDiff = (Int32.Parse(startDay)) - (Int32.Parse(endDay));
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
