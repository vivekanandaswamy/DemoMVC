﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class ChemicalInventory : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Page.ReportsTabPage.ChemicalInventoryLink.DeskTopMouseClick();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");


        //[TestCategory(TestType.NA_Regression, "TC01_CIAddColumns")]
        //[TestCategory(TestType.NA_Sanity, "TC01_CIAddColumns")]
        //[TestCategory(TestType.EU_Regression, "TC01_CIAddColumns")]
        //[TestCategory(TestType.EU_Sanity, "TC01_CIAddColumns")]
        [TestCategory(TestType.reports, "TC01_CIAddColumns")]
        [Test, Description("Verifying Add Columns functionality in Chemical Inventory Report")]
        public void TC01_CIAddColumns()
        {
            Page.ReportsTabPage.AddColumn.Click();
            Runner.DoStep("Select Columns to Add in the resulting grid in Chemical Inventory Report", () =>
               {
                   Page.ReportsTabPage.AvgDailyNeedsLY.Click();
               });
            int a = Page.ReportsTabPage.ReportsGrid.Rows.Count;
            Page.ReportsTabPage.AddColumn.Click();
            Runner.DoStep("Verify added columns in the resulting grid in Chemical Inventory Report", () =>
            {
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Avg. Daily Needs YTD").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Column Not Added");
                    //Assert.Fail("Column Not Added");
                }
            });

            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC02_CIVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC02_CIVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC02_CIVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC02_CIVerifyHeaders")]
        [TestCategory(TestType.reports, "TC02_CIVerifyHeaders")]
        [Test, Description("Verifying grid headers in Chemical Inventory Report")]
        public void TC02_CIVerifyHeaders()
        {
            Runner.DoStep("Verify Grid Headers in Chemical Inventory Report", () =>
                  {
                      List<string> headers = new List<string> { "Chemical Name", "Date Range", "Units", "Last Inventory", "Inventory Based Consumption", "Dispenser Based Consumption", "Total estimated inventory", "Avg. Daily Needs YTD", "Avg. Daily Needs For Inventory Period" };
                      VerifyHeader(headers);
                  });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC03_CIAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC03_CIAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC03_CIAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC03_CIAddToFavourite")]
        [TestCategory(TestType.reports, "TC03_CIAddToFavourite")]
        [Test, Description("Verifying Add to Favourite functionality in Chemical Inventory Report")]
        public void TC03_CIAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Chemical Inventory AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC04_CIDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC04_CIDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC04_CIDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC04_CIDownloadReport")]
        [TestCategory(TestType.reports, "TC04_CIDownloadReport")]
        [Test, Description("Verifying Export to Excel, PDF functionality in Chemical Inventory Report")]
        public void TC04_CIDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Page.ReportsTabPage.ChemicalInventoryLink.Click();
            Runner.DoStep("Click on Export to Excel icon in Chemical Inventory Report", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });
            string partialName = "Chemical Inventory";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on Export to PDF icon in Chemical Inventory Report", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC05_CIRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC05_CIRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC05_CIRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC05_CIRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC05_CIRemoveFromFavourite")]
        [Test, Description("Verifying Remove from Favourite functionality in Chemical Inventory Report")]
        public void TC05_CIRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Chemical Inventory AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
    }
}
