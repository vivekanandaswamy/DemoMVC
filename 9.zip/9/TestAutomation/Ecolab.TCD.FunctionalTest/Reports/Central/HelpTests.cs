﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class HelpTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.HelpMenu.HelpLink.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        [TestCategory(TestType.reports, "TC01_VerifyCostSummary")]
        [Test, Description("Verify Help for Cost Summary")]
        public void TC01_VerifyCostSummary()
        {
            Runner.DoStep("Verify Cost Summary help link", () =>
            {
                string value = Page.HelpMenu.LnkFinancials.Attributes[0].Value;
                if (!value.ToLower().Contains("active"))
                {
                    Page.HelpMenu.LnkFinancials.DeskTopMouseClick();
                }

                Page.HelpMenu.LnkCostSummary.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Cost"))
                {
                    flag = true;
                    errorBuilder.Append("\n cost summary report name not found");
                    //Assert.Fail("cost summary report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC02_VerifyAccountSummary")]
        [Test, Description("Verify Help  for  Account Summary")]
        public void TC02_VerifyAccountSummary()
        {
            Runner.DoStep("Verify Account Summary help link", () =>
           {
               Page.HelpMenu.LnkAccSummary.Click();
               if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Account"))
               {
                   flag = true;
                   errorBuilder.Append("\n Acconut summary report name not found");
                   //Assert.Fail("Acconut summary report name not found");
               }
           });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC03_VerifyFFevaluation")]
        [Test, Description("Verify Help for  FF evaluation")]
        public void TC03_VerifyFFevaluation()
        {
            Runner.DoStep("Verify FF evaluation help link", () =>
           {
               Page.HelpMenu.LnkFFeval.Click();
               if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("FF Evaluation"))
               {
                   flag = true;
                   errorBuilder.Append("\n FF Evaluation report name not found");
                   //Assert.Fail("FF Evaluation report name not found");
               }
           });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        [TestCategory(TestType.reports, "TC04_VerifyMachineHoldTime")]
        [Test, Description("Verify Help  for Machine Hold Time")]
        public void TC04_VerifyMachineHoldTime()
        {
            Runner.DoStep("Verify Machine hold time help link", () =>
           {
               Page.HelpMenu.LnkMachineHoldTime.Click();
               if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Machine Hold Time"))
               {
                   flag = true;
                   errorBuilder.Append("\n Machine Hold Time report name not found");
                   //Assert.Fail("Machine Hold Time report name not found");
               }
           });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC05_VerifyServicepreparation")]
        [Test, Description("Verify Help  for Service Preparation")]
        public void TC05_VerifyServicepreparation()
        {
            Runner.DoStep("Verify Service preparation help link", () =>
           {
               Page.HelpMenu.LnkServPreparation.Click();
               if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Service Preparation"))
               {
                   flag = true;
                   errorBuilder.Append("\n Service Preparation report name not found");
                   //Assert.Fail("Service Preparation report name not found");
               }
           });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC06_VerifyUserlog")]
        [Test, Description("Verify Help  for User log")]
        public void TC06_VerifyUserlog()
        {
            Runner.DoStep("Verify user log  help link", () =>
           {
               Page.HelpMenu.LnkUserLog.Click();
               if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("User Log"))
               {
                   flag = true;
                   errorBuilder.Append("\n User Log report name not found");
                   //Assert.Fail("User Log report name not found");
               }
           });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC07_VerifyWPDetails")]
        [Test, Description("Verify Help  for Washing Programs Details")]
        public void TC07_VerifyWPDetails()
        {
            Runner.DoStep("Verify Washing Programs Details help link", () =>
           {
               Page.HelpMenu.LnkWPdetails.Click();
               if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Washing Programs Details"))
               {
                   flag = true;
                   errorBuilder.Append("\n Washing Programs Details report name not found");
                   //Assert.Fail("Washing Programs Details report name not found");
               }
           });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC08_VerifyEBMachine")]
        [Test, Description("Verify Help  for Efficiency by Machine")]
        public void TC08_VerifyEBMachine()
        {
            Runner.DoStep("Verify Efficiency by Machine help link", () =>
            {
                ClickProductionEfficiencyTab();
                Page.HelpMenu.LnkEBMachine.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Efficiency by Machine"))
                {
                    flag = true;
                    errorBuilder.Append("\n Efficiency by Machine report name not found");
                    //Assert.Fail("Efficiency by Machine report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC09_VerifyEWEquipment")]
        [Test, Description("Verify Help  for Efficiency Washing Equipment")]
        public void TC09_VerifyEWEquipment()
        {
            Runner.DoStep("Verify Efficiency Washing Equipment help link", () =>
            {
                ClickProductionEfficiencyTab();
                Page.HelpMenu.LnkEBWEquipment.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Efficiency Washing Equipment"))
                {
                    flag = true;
                    errorBuilder.Append("\n Efficiency Washing Equipment report name not found");
                    //Assert.Fail("Efficiency Washing Equipment report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC10_VerifyMyServiceActionList")]
        [Test, Description("Verify Help  for MyService Action List")]
        public void TC10_VerifyMyServiceActionList()
        {
            Runner.DoStep("Verify MyService Action List help link", () =>
            {
                ClickProductionEfficiencyTab();
                Page.HelpMenu.LnkMSActionList.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("MyService Action List"))
                {
                    flag = true;
                    errorBuilder.Append("\n MyService Action List report name not found");
                    //Assert.Fail("MyService Action List report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC11_VerifyPeriodProduction")]
        [Test, Description("Verify Help  for Period Production")]
        public void TC11_VerifyPeriodProduction()
        {
            Runner.DoStep("Verify Period Production help link", () =>
            {
                ClickProductionEfficiencyTab();
                Page.HelpMenu.LnkPProduction.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Period Production"))
                {
                    flag = true;
                    errorBuilder.Append("\n Period Production report name not found");
                    //Assert.Fail("Period Production report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC12_VerifyProductionSummary")]
        [Test, Description("Verify Help  for Production Summary")]
        public void TC12_VerifyProductionSummary()
        {
            Runner.DoStep("Verify Production Summary help link", () =>
            {
                ClickProductionEfficiencyTab();
                Page.HelpMenu.LnkPSummary.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Production Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Production Summary report name not found");
                    //Assert.Fail("Production Summary report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC13_VerifyProduction")]
        [Test, Description("Verify Help  for Production ")]
        public void TC13_VerifyProduction()
        {
            Runner.DoStep("Verify Production  help link", () =>
            {
                ClickProductionEfficiencyTab();
                Page.HelpMenu.LnkProduction.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Production"))
                {
                    flag = true;
                    errorBuilder.Append("\n Production report name not found");
                    //Assert.Fail("Production report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC14_VerifyRewash")]
        [Test, Description("Verify Help  for Rewash ")]
        public void TC14_VerifyRewash()
        {
            Runner.DoStep("Verify Rewash help link", () =>
            {
                ClickProductionEfficiencyTab();
                Page.HelpMenu.LnkRewash.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Rewash"))
                {
                    flag = true;
                    errorBuilder.Append("\n Rewash report name not found");
                    //Assert.Fail("Rewash report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC15_VerifyCConsumption")]
        [Test, Description("Verify Help  for Chemical Consumption ")]
        public void TC15_VerifyCConsumption()
        {
            Runner.DoStep("Verify Chemical Consumption help link", () =>
            {
                ClickResouceUtilizationTab();
                Page.HelpMenu.LnkCConsumption.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Chemical Consumption"))
                {
                    flag = true;
                    errorBuilder.Append("\n Chemical Consumption report name not found");
                    //Assert.Fail("Chemical Consumption report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC16_VerifyCInventory")]
        [Test, Description("Verify Help  for Chemical inventory")]
        public void TC16_VerifyCInventory()
        {
            Runner.DoStep("Verify Chemical inventory help link", () =>
            {
                ClickResouceUtilizationTab();
                Page.HelpMenu.LnkCInventory.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Chemical inventory"))
                {
                    flag = true;
                    errorBuilder.Append("\n Chemical inventory report name not found");
                    //Assert.Fail("Chemical inventory report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC17_VerifyMeters")]
        [Test, Description("Verify Help  for Meters")]
        public void TC17_VerifyMeters()
        {
            Runner.DoStep("Verify Meters help link", () =>
            {
                ClickResouceUtilizationTab();
                Page.HelpMenu.LnkMeters.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Meters"))
                {
                    flag = true;
                    errorBuilder.Append("\n Meters report name not found");
                    //Assert.Fail("Meters report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC18_VerifyOSummary")]
        [Test, Description("Verify Help  for Opearion Summary")]
        public void TC18_VerifyOSummary()
        {
            Runner.DoStep("Verify Resources help link", () =>
            {
                ClickResouceUtilizationTab();
                Page.HelpMenu.LnkOperationSummary.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Resources"))
                {
                    flag = true;
                    errorBuilder.Append("\n Operations Summary report name not found");
                    //Assert.Fail("Operations Summary report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC19_VerifyAlarmDetails")]
        [Test, Description("Verify Help  for Alarm Details")]
        public void TC19_VerifyAlarmDetails()
        {
            Runner.DoStep("Verify Alarm Details help link", () =>
            {
                ClickWashingProcessValidation();
                Page.HelpMenu.LnkAlarmDetails.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Alarm Details"))
                {
                    flag = true;
                    errorBuilder.Append("\n Alarm Details report name not found");
                    //Assert.Fail("Alarm Details report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC20_VerifyAlarmSummary")]
        [Test, Description("Verify Help  for Alarm Summary")]
        public void TC20_VerifyAlarmSummary()
        {
            Runner.DoStep("Verify Alarm Summary help link", () =>
            {
                ClickWashingProcessValidation();
                Page.HelpMenu.LnkAlarmSummary.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Alarm Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Alarm Summary report name not found");
                    //Assert.Fail("Alarm Summary report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC21_VerifyPVDetails")]
        [Test, Description("Verify Help  for Process Validation Details")]
        public void TC21_VerifyPVDetails()
        {
            Runner.DoStep("Verify Process Validation Details help link", () =>
            {
                ClickWashingProcessValidation();
                Page.HelpMenu.LnkProcessValidationDetails.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Process Validation Details"))
                {
                    flag = true;
                    errorBuilder.Append("\n Process Validation Details report name not found");
                    //Assert.Fail("Process Validation Details report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        [TestCategory(TestType.reports, "TC22_VerifyPVSummary")]
        [Test, Description("Verify Help  for Process Validation Summary")]
        public void TC22_VerifyPVSummary()
        {
            Runner.DoStep("Verify Process Validation Summary help link", () =>
            {
                ClickWashingProcessValidation();
                Page.HelpMenu.LnkPVSummary.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Process Validation Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Process Validation Summary report name not found");
                    //Assert.Fail("Process Validation Summary report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC23_VerifyRedFlags")]
        [Test, Description("Verify Help  for Red Flags")]
        public void TC23_VerifyRedFlags()
        {
            Runner.DoStep("Verify Red Flags help link", () =>
            {
                ClickWashingProcessValidation();
                Page.HelpMenu.LnkRedFlags.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Red Flags"))
                {
                    flag = true;
                    errorBuilder.Append("\n Red Flags report name not found");
                    //Assert.Fail("Red Flags report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [TestCategory(TestType.reports, "TC24_VerifyRejectedBatches")]
        [Test, Description("Verify Help  for Rejected Batches")]
        public void TC24_VerifyRejectedBatches()
        {
            Runner.DoStep("Verify Rejected Batches help link", () =>
            {
                ClickWashingProcessValidation();
                Page.HelpMenu.LnkRBatches.Click();
                if (!Page.HelpMenu.ReportName.BaseElement.InnerText.Contains("Rejected Batches"))
                {
                    flag = true;
                    errorBuilder.Append("\n Rejected Batches report name not found");
                    //Assert.Fail("Rejected Batches report name not found");
                }
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void ClickProductionEfficiencyTab()
        {
            string value = Page.HelpMenu.LnkProductionEfficiency.Attributes[0].Value;
            if (!value.ToLower().Contains("active"))
            {
                Page.HelpMenu.LnkProductionEfficiency.DeskTopMouseClick();
            }
        }

        private void ClickResouceUtilizationTab()
        {
            string value = Page.HelpMenu.LnkResourceUtilization.Attributes[0].Value;
            if (!value.ToLower().Contains("active"))
            {
                Page.HelpMenu.LnkResourceUtilization.DeskTopMouseClick();
            }
        }

        private void ClickWashingProcessValidation()
        {
            string value = Page.HelpMenu.LnkWashingProcessValidation.Attributes[0].Value;
            if (!value.ToLower().Contains("active"))
            {
                Page.HelpMenu.LnkWashingProcessValidation.DeskTopMouseClick();
            }
        }
    }
}
