﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class CostSummary : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.FinancialsTab.DeskTopMouseClick();
            Page.ReportsTabPage.CostSummary.DeskTopMouseClick();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }
        
        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Regression, "TC01_CCCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_CCCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_CCCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_CCCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_CCCurrentSearchOperations")]
        [Test, Description("Verifying Current search options and its results in Cost Summary Report")]
        public void TC01_CCCurrentSearchOperations()
        {
            Runner.DoStep("Select Current and Day options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                ValidateToday();
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (previousMonth != currentMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Week options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                ValidateToday();
                DateTime input = DateTime.Today;
                int sunday = DayOfWeek.Sunday - input.DayOfWeek;
                DateTime sundayDate = input.AddDays(sunday);
                string sundayDay = sundayDate.ToString("dd");
                string sundayMonth = sundayDate.ToString("MMM");
                if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Month options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                ValidateToday();
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Quarter options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                ValidateToday();
                if ((Int32.Parse(previousDay) != 01))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
                //Friday, April 01, 2016
                string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

                if (firstMonthInQuarter != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Year options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                ValidateToday();
                if ((previousDay != "01") || (previousMonth != "Jan"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and R12 options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.R12.Click();
                GetValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC02_CCPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC02_CCPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_CCPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_CCPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_CCPreviousSearchOperations")]
        [Test, Description("Verifying Previous search options and its results in Cost Summary Report")]
        public void TC02_CCPreviousSearchOperations()
        {
            Runner.DoStep("Select Previous and Day options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                List<string> list = new List<string>();
                list.Add(currentDay);
                list.Add(currentMonth);
                list.Add(currentYear);
                foreach (string item in list)
                {
                    if (!yesterday.Contains(item))
                    {
                        flag = true;
                        errorBuilder.Append("\n Date Range is not correct");
                        //Assert.Fail("Date Range is not correct");
                    }
                }
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((previousMonth != currentMonth) || (previousDay != currentDay))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Week options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
                DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
                string oldDay = fistDayOfWeek.ToString("dd");
                string oldMonth = fistDayOfWeek.ToString("MMM");
                string newDay = lastDayOfWeek.ToString("dd");
                string newMonth = lastDayOfWeek.ToString("MMM");
                string newYear = lastDayOfWeek.ToString("yyyy");

                if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Month options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                DateTime last = month.AddDays(-1);
                string lastDate = last.ToString("dd");
                string lastMonth = last.ToString("MMM");
                string lastYear = last.ToString("yyyy");
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Quarter options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                int quarterNumber, prevQNumber;
                DateTime firstDayOfQuarter, lastDayOfQuarter;
                quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                if (quarterNumber == 1)
                {
                    prevQNumber = 4;
                    firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
                }
                else
                {
                    prevQNumber = quarterNumber - 1;
                    firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
                }

                if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Year options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                string lastYear = DateTime.Now.AddYears(-1).Year.ToString();
                if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and R12 options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.DayView.Click();
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.R12.Click();
                GetValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }



        //[TestCategory(TestType.NA_Regression, "TC03_CSStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Sanity, "TC03_CSStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_CSStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_CSStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_CSStandardCustomNavigate")]
        [Test, Description("Verifying Standard and Custom Navigation in Cost Summary Report")]
        public void TC03_CSStandardCustomNavigate()
        {
            Page.ReportsTabPage.ReportsNext.Click();
            Runner.DoStep("Select Custom Navigation in Cost Summary Report", () =>
            {
                if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    Assert.Fail("Custom Navigation is not correct");
                }
            });

            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });
            Page.ReportsTabPage.ReportsPrev.Click();

            Runner.DoStep("Select Standard Navigation in Cost Summary Report", () =>
            {

                if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    flag = true;
                    errorBuilder.Append("\n Standard Navigation is not correct");
                    //Assert.Fail("Standard Navigation is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC04_CSViewCategory")]
        //[TestCategory(TestType.NA_Sanity, "TC04_CSViewCategory")]
        //[TestCategory(TestType.EU_Regression, "TC04_CSViewCategory")]
        //[TestCategory(TestType.EU_Sanity, "TC04_CSViewCategory")]
        [TestCategory(TestType.reports, "TC04_CSViewCategory")]
        [Test, Description("Verifying View Category functionality in Cost Summary Report")]
        public void TC04_CSViewCategory()
        {
            Page.ReportsTabPage.ViewCategory.Click();
            Page.ReportsTabPage.TimeCategory.Click();
            Thread.Sleep(3000);

            Runner.DoStep("Select Category and verify its results in Time Category of Cost Summary Report", () =>
            {
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Interval").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Interval column doesnot exist");
                    //Assert.Fail("Interval column doesnot exist");
                }
            });

            Page.ReportsTabPage.ViewCategory.Click();
            Page.ReportsTabPage.LocationCategory.Click();
            Thread.Sleep(3000);
            Runner.DoStep("Select Category and verify its results in Location Category of Cost Summary Report", () =>
            {

                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Location").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Location column doesnot exist");
                    //Assert.Fail("Location column doesnot exist");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC05_CSAddColumn")]
        //[TestCategory(TestType.NA_Sanity, "TC05_CSAddColumn")]
        //[TestCategory(TestType.EU_Regression, "TC05_CSAddColumn")]
        //[TestCategory(TestType.EU_Sanity, "TC05_CSAddColumn")]
        [TestCategory(TestType.reports, "TC05_CSAddColumn")]
        [Test, Description("Verifying Add Columns functionality in Cost Summary Report")]
        public void TC05_CSAddColumn()
        {
            Runner.DoStep("Select Columns to Add in the resulting grid in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.AddColumn.Click();
                Page.ReportsTabPage.NoOfLoads.Click();
                Page.ReportsTabPage.ExcessChemicalCost.Click();
                Page.ReportsTabPage.ExcessTotalCost.Click();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Verify added columns in the resulting grid in Cost Summary Report", () =>
            {
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("No. of Loads").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Column Not Added");
                    //Assert.Fail("Column Not Added");
                }
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Excess Total Cost ").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Column Not Added");
                    //Assert.Fail("Column Not Added");
                }
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Excess Chemical Cost ").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Column Not Added");
                    //Assert.Fail("Column Not Added");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC06_CSAddFilter")]
        //[TestCategory(TestType.NA_Sanity, "TC06_CSAddFilter")]
        //[TestCategory(TestType.EU_Regression, "TC06_CSAddFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC06_CSAddFilter")]
        [TestCategory(TestType.reports, "TC06_CSAddFilter")]
        [Test, Description("Verifying Filter in Cost Summary Report")]
        public void TC06_CSAddFilter()
        {
            Runner.DoStep("select Filter options in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.R12.Click();
                Thread.Sleep(2000);
                Page.ReportsTabPage.ViewCategory.ScrollToVisible();
                Page.ReportsTabPage.ViewCategory.Click();
                Page.ReportsTabPage.FormulaCategory.Click();
                Page.ReportsTabPage.Filter.Click();
                Page.ReportsTabPage.AddMoreFilters.Click();
                Page.ReportsTabPage.FormulaSegment.Click();
                Page.ReportsTabPage.DrpFormulaSegment.Click();
                Page.ReportsTabPage.FormulaSegmentItem.Click();
                Page.ReportsTabPage.ApplyFilter.Click();
                Thread.Sleep(2000);
                if (Page.ReportsTabPage.ReportsGrid.GetColumnValue(1).Contains("Formula Seg 1"))
                {
                    Assert.Pass();
                }
                else if (Page.ReportsTabPage.ReportsGrid.GetReportRows()[1].BaseElement.InnerText.Contains("No Records"))
                {
                    Assert.Pass();
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("\n ");
                    //Assert.Fail();
                }                    
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC07_CSVerifyCalenderControl")]
        //[TestCategory(TestType.NA_Sanity, "TC07_CSVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Regression, "TC07_CSVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Sanity, "TC07_CSVerifyCalenderControl")]
        [TestCategory(TestType.reports, "TC07_CSVerifyCalenderControl")]
        [Test, Description("Verifying Date selection through custom fields and its results in Cost Summary Report")]
        public void TC07_CSVerifyCalenderControl()
        {
            Runner.DoStep("Select Date rang through custom fields in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.Custom.Click();
                Page.ReportsTabPage.CustomStartDate.SetText("02/09/2016");
                Page.ReportsTabPage.CustomEndDate.SetText("05/08/2016");
                Page.ReportsTabPage.Apply.Click();
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC08_CSVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC08_CSVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC08_CSVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC08_CSVerifyHeaders")]
        [TestCategory(TestType.reports, "TC08_CSVerifyHeaders")]
        [Test, Description("Verifying grid headers in Cost Summary Report")]
        public void TC08_CSVerifyHeaders()
        {
            Runner.DoStep("Verify Grid Headers in Cost Summary Report", () =>
            {
                List<string> headers = new List<string> { "Actual Production", "Actual Total Cost", "Total Chemical Cost", "Actual Water Cost", "Actual Energy Cost", "Actual Labor Cost", "Rewash Production", "Actual Rewash Cost" };
                VerifyHeader(headers);
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC09_CSDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Sanity, "TC09_CSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC09_CSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC09_CSDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC09_CSDefaultFiltersVerification")]
        [Test, Description("Verifying default filters in Cost Summary Report")]
        public void TC09_CSDefaultFiltersVerification()
        {
            Runner.DoStep("Verifying default filters in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.Filter.Click();
                List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula Segment", "Formula", "Formula Category", "Plant Customer" };

                bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
                if (!isFilterMatch)
                {
                    flag = true;
                    errorBuilder.Append("\n Default Filters are not Correct in Cost Summary Report");
                    //Assert.Fail("Default Filters are not Correct in Cost Summary Report");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }   
        }

        //[TestCategory(TestType.NA_Regression, "TC10_CSAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC10_CSAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC10_CSAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC10_CSAddToFavourite")]
        [TestCategory(TestType.reports, "TC10_CSAddToFavourite")]
        [Test, Description("Verifying Add to Favourite functionality in Cost Summary Report")]
        public void TC10_CSAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Cost Summary AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC11_CSDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC11_CSDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC11_CSDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC11_CSDownloadReport")]
        [TestCategory(TestType.reports, "TC11_CSDownloadReport")]
        [Test, Description("Verifying Export to Excel, PDF functionality in Cost Summary Report")]
        public void TC11_CSDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.FinancialsTab.DeskTopMouseClick();
            Page.ReportsTabPage.CostSummary.Click();

            Runner.DoStep("Click on Export to Excel icon in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Costs Summary";
            Thread.Sleep(2000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on Export to PDF icon in Cost Summary Report", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(2000);

            Page.ReportsTabPage.PDFVerify(partialName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC12_CSRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC12_CSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC12_CSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC12_CSRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC12_CSRemoveFromFavourite")]
        [Test, Description("Verifying Remove from Favourite functionality in Cost Summary Report")]
        public void TC12_CSRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Cost Summary AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
