﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class AlarmDetails : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();

        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.WashingProcessValidationTab.Focus();
            Page.ReportsTabPage.WashingProcessValidationTab.DeskTopMouseClick();
            Page.ReportsTabPage.AlarmsDetailsLink.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Regression, "TC01_ADCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_ADCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_ADCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_ADCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_ADCurrentSearchOperations")]
        [Test, Description("Verifying Current search options and its results in Alarm Details Report")]
        public void TC01_ADCurrentSearchOperations()
        {
            Runner.DoStep("Select Current and Day options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                ValidateToday();
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (previousMonth != currentMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Week options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                ValidateToday();
                DateTime input = DateTime.Today;
                int sunday = DayOfWeek.Sunday - input.DayOfWeek;
                DateTime sundayDate = input.AddDays(sunday);
                string sundayDay = sundayDate.ToString("dd");
                string sundayMonth = sundayDate.ToString("MMM");
                if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Month options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                ValidateToday();
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Quarter options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                ValidateToday();
                if ((Int32.Parse(previousDay) != 01))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
                string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

                if (firstMonthInQuarter != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Year options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                ValidateToday();
                if ((previousDay != "01") || (previousMonth != "Jan"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and R12 options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.R12.Click();
                GetValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC02_ADPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC02_ADPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_ADPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_ADPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_ADPreviousSearchOperations")]
        [Test, Description("Verifying previous search options and its results in Alarm Details Report")]
        public void TC02_ADPreviousSearchOperations()
        {
            Runner.DoStep("Select Previous and Day options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.DayView.Click();
                GetValues();
                List<string> list = new List<string>();
                list.Add(currentDay);
                list.Add(currentMonth);
                list.Add(currentYear);
                foreach (string item in list)
                {
                    if (!yesterday.Contains(item))
                    {
                        flag = true;
                        errorBuilder.Append("\n Date Range is not correct");
                        //Assert.Fail("Date Range is not correct");
                    }
                }
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((previousMonth != currentMonth) || (previousDay != currentDay))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Week options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
                GetValues();
                DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
                DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
                string oldDay = fistDayOfWeek.ToString("dd");
                string oldMonth = fistDayOfWeek.ToString("MMM");
                string newDay = lastDayOfWeek.ToString("dd");
                string newMonth = lastDayOfWeek.ToString("MMM");
                string newYear = lastDayOfWeek.ToString("yyyy");

                if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Month options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
                GetValues();
                DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                DateTime last = month.AddDays(-1);
                string lastDate = last.ToString("dd");
                string lastMonth = last.ToString("MMM");
                string lastYear = last.ToString("yyyy");
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Quarter options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                GetValues();
                int quarterNumber, prevQNumber;
                DateTime firstDayOfQuarter, lastDayOfQuarter;
                quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                if (quarterNumber == 1)
                {
                    prevQNumber = 4;
                    firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
                }
                else
                {
                    prevQNumber = quarterNumber - 1;
                    firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
                }

                if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Year options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
                GetValues();
                string lastYear = DateTime.Now.AddYears(-1).Year.ToString();
                if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and R12 options in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.DayView.Click();
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.R12.Click();
                GetValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC03_ADStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Sanity, "TC03_ADStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_ADStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_ADStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_ADStandardCustomNavigate")]
        [Test, Description("Verifying Standard and Custom Navigation in Alarm Details Report")]
        public void TC03_ADStandardCustomNavigate()
        {
            Runner.DoStep("Select Custom Navigation in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
                if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    flag = true;
                    errorBuilder.Append("\n Custom Navigation is not correct");
                    //Assert.Fail("Custom Navigation is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });
            Runner.DoStep("Select Standard Navigation in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
                if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    flag = true;
                    errorBuilder.Append("\n Standard Navigation is not correct");
                    //Assert.Fail("Standard Navigation is not correct");
                }
            });

            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        string customStartDate = null;
        string customEndDate = null;

        //[TestCategory(TestType.NA_Regression, "TC04_ADCustomValidation")]
        //[TestCategory(TestType.NA_Sanity, "TC04_ADCustomValidation")]
        //[TestCategory(TestType.EU_Regression, "TC04_ADCustomValidation")]
        //[TestCategory(TestType.EU_Sanity, "TC04_ADCustomValidation")]
        [TestCategory(TestType.reports, "TC04_ADCustomValidation")]
        [Test, Description("Verifying Date selection through custom fields and its results in Alarm Details Report")]
        public void TC04_ADCustomValidation()
        {
            Runner.DoStep("Select Date rang through custom fields in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.Custom.Focus();
                Thread.Sleep(1000);
                Page.ReportsTabPage.Custom.Click();
                Thread.Sleep(1000);
                customStartDate = "03/27/2016";
                customEndDate = "03/29/2016";
                DateTime startDate = DateTime.ParseExact(customStartDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                DateTime endDate = DateTime.ParseExact(customEndDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                Page.ReportsTabPage.CustomStartDate.TypeText(customStartDate);
                Page.ReportsTabPage.CustomEndDate.TypeText(customEndDate);
                Page.ReportsTabPage.Apply.Click();
                string dateRangelbl = null;
                if (startDate.Year == endDate.Year)
                {
                    dateRangelbl = startDate.ToString("dd MMM") + " - " + endDate.ToString("dd MMM yyyy");
                }
                else
                {
                    dateRangelbl = startDate.ToString("dd MMM yyyy") + " - " + endDate.ToString("dd MMM yyyy");
                }

                if (Page.ReportsTabPage.WPADCustDateRangeLbl.BaseElement.InnerText != dateRangelbl)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not matched with selected dates");
                    //Assert.Fail("Date Range is not matched with selected dates");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC05_ADFilter")]
        //[TestCategory(TestType.NA_Sanity, "TC05_ADFilter")]
        //[TestCategory(TestType.EU_Regression, "TC05_ADFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC05_ADFilter")]
        [TestCategory(TestType.reports, "TC05_ADFilter")]
        [Test, Description("Verifying Filter in Alarm Details Report")]
        public void TC05_ADFilter()
        {
            Runner.DoStep("Select Date rang through custom fields in Alarm Details Report", () =>
            {
                //Page.ReportsTabPage.ReportsTab.Click();
                Thread.Sleep(1000);
                Page.ReportsTabPage.Filter.Click();
                Page.ReportsTabPage.AddMoreFilters.Click();
                Page.ReportsTabPage.WPADAddFiltDisp.Click();
                Page.ReportsTabPage.ApplyFilter.Click();
                //if (Page.ReportsTabPage.ReportsGrid.GetColumnValues(1).Contains("Braun 675 lb"))
                //{
                //    Assert.Pass();
                //}
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC06_ADAddColumns")]
        //[TestCategory(TestType.NA_Sanity, "TC06_ADAddColumns")]
        //[TestCategory(TestType.EU_Regression, "TC06_ADAddColumns")]
        //[TestCategory(TestType.EU_Sanity, "TC06_ADAddColumns")]
        [TestCategory(TestType.reports, "TC06_ADAddColumns")]
        [Test, Description("Verifying Add Columns functionality in Alarm Details Report")]
        public void TC06_ADAddColumns()
        {
            Runner.DoStep("Select Columns to Add in the resulting grid in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.AddColumn.Click();
                Page.ReportsTabPage.WPADColWash.Click();
                Page.ReportsTabPage.WPADColDV.Click();
                Page.ReportsTabPage.WPADColForm.Click();
                Page.ReportsTabPage.WPADColStatus.Click();
            });
            Runner.DoStep("Verify added columns in the resulting grid in Alarm Details Report", () =>
            {
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Washer Number").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Washer Number Column Not Added");
                    //Assert.Fail("Washer Number Column Not Added");
                }
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Desired Value").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Desired Value Column Not Added");
                    //Assert.Fail("Desired Value Column Not Added");
                }
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Formula Number").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Formula Number Column Not Added");
                    //Assert.Fail(" Formula Number Column Not Added");
                }
                if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Status").Count == 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Status Column Not Added");
                    //Assert.Fail(" Status Column Not Added");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC07_ADVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC07_ADVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC07_ADVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC07_ADVerifyHeaders")]
        [TestCategory(TestType.reports, "TC07_ADVerifyHeaders")]
        [Test, Description("Verifying grid headers in Alarm Details Report")]
        public void TC07_ADVerifyHeaders()
        {
            Runner.DoStep("Verify Grid Headers in Alarm Details Report", () =>
            {
                List<string> headers = new List<string> { "Alarm Code", "Alarm Description", "Dispenser", "Start Date & Time", "Duration", "End Date & Time" };
                VerifyHeader(headers);
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC08_ADAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC08_ADAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC08_ADAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC08_ADAddToFavourite")]
        [TestCategory(TestType.reports, "TC08_ADAddToFavourite")]
        [Test, Description("Verifying Add to Favourite functionality in Alarm Details Report")]
        public void TC08_ADAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Alarm Details AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC09_ADDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC09_ADDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC09_ADDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC09_ADDownloadReport")]
        [TestCategory(TestType.reports, "TC09_ADDownloadReport")]
        [Test, Description("Verifying Export to Excel, PDF functionality in Alarm Details Report")]
        public void TC09_ADDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.WashingProcessValidationTab.DeskTopMouseClick();
            Page.ReportsTabPage.AlarmsDetailsLink.Click();

            Runner.DoStep("Click on Export to Excel icon in Alarms Details Report", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Alarms Details";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on Export to PDF icon in Alarms Details Report", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC10_RemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC10_RemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC10_RemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC10_RemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC10_RemoveFromFavourite")]
        [Test, Description("Verifying Remove from Favourite functionality in Alarm Details Report")]
        public void TC10_ADRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Alarm Details AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC11_ADCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Sanity, "TC11_ADCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC11_ADCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC11_ADCentralDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC11_ADCentralDefaultFiltersVerification")]
        [Test, Description("Verifying default filters in Alarm Details Report")]
        public void TC11_ADDefaultFiltersVerification()
        {
            Runner.DoStep("Verifying default filters in Alarm Details Report", () =>
            {
                Page.ReportsTabPage.Filter.Click();
                List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula", "Alarm", "Dispenser" };
                bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
                if (!isFilterMatch)
                {
                    flag = true;
                    errorBuilder.Append("\n Default Filters are not Correct in Production Summary Report");
                    //Assert.Fail("Default Filters are not Correct in Production Summary Report");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);

            // dayDiff = (Int32.Parse(startDay)) - (Int32.Parse(endDay));
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
