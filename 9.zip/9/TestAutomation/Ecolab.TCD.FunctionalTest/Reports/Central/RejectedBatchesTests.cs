﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class RejectedBatchesTests : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();

        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.WashingProcessValidationTab.Focus();
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.ProcessValRejectedBatchesLink.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Sanity, "TC01_RBCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Regression, "TC01_RBCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_RBCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_RBCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_RBCurrentSearchOperations")]
        [Test, Description("Verify the 'Date range' output for the 'Current' search functionality")]
        public void TC01_RBCurrentSearchOperations()
        {
            //current day
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Day options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.DayView.Click();
            });
            GetValues();
            ValidateToday();
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if (previousMonth != currentMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current week
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Week options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();
            ValidateToday();
            DateTime input = DateTime.Today;
            int sunday = DayOfWeek.Sunday - input.DayOfWeek;
            DateTime sundayDate = input.AddDays(sunday);
            string sundayDay = sundayDate.ToString("dd");
            string sundayMonth = sundayDate.ToString("MMM");
            if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current month
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Month options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.MonthView.Click();
            });
            GetValues();
            ValidateToday();
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current quarter
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Quarter options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.QuarterView.Click();
            });
            GetValues();
            ValidateToday();
            if ((Int32.Parse(previousDay) != 01))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
            //Friday, April 01, 2016
            string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

            if (firstMonthInQuarter != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });


            //current Year
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, Year options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.YearView.Click();
            });
            GetValues();
            ValidateToday();
            if ((previousDay != "01") || (previousMonth != "Jan"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //current R12
            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, R12 options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.R12.Click();
            });
            GetValuesR12();
            //validateToday();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if(flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC02_RBPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Regression, "TC02_RBPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_RBPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_RBPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_RBPreviousSearchOperations")]
        [Test, Description("Verify the 'Date range' output for the 'Previous' search functionality")]
        public void TC02_RBPreviousSearchOperations()
        {
            //previous day
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Day options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.DayView.Click();
            });
            GetValues();
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!yesterday.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if ((previousMonth != currentMonth) || (previousDay != currentDay))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            //previous week
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Week options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();
            DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
            DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
            string oldDay = fistDayOfWeek.ToString("dd");
            string oldMonth = fistDayOfWeek.ToString("MMM");
            string newDay = lastDayOfWeek.ToString("dd");
            string newMonth = lastDayOfWeek.ToString("MMM");
            string newYear = lastDayOfWeek.ToString("yyyy");

            if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            //previous month
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Month options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.MonthView.Click();
            });
            GetValues();
            DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DateTime last = month.AddDays(-1);
            string lastDate = last.ToString("dd");
            string lastMonth = last.ToString("MMM");
            string lastYear = last.ToString("yyyy");
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            //previous quarter
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Quarter options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.QuarterView.Click();
            });
            GetValues();
            int quarterNumber, prevQNumber;
            DateTime firstDayOfQuarter, lastDayOfQuarter;
            quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            if (quarterNumber == 1)
            {
                prevQNumber = 4;
                firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
            }
            else
            {
                prevQNumber = quarterNumber - 1;
                firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
            }

            if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //previous year
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Year options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.YearView.Click();
            });
            GetValues();
            string lastYear1 = DateTime.Now.AddYears(-1).Year.ToString();
            if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear1))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            //previous R12
            Page.ReportsTabPage.DayView.Click();
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, R12 options in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                //Assert.Fail("Date Range is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC03_RBStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Regression, "TC03_RBStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_RBStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_RBStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_RBStandardCustomNavigate")]
        [Test, Description("Verify the Standard and Custom navigation functionalities")]
        public void TC03_RBStandardCustomNavigate()
        {
            Runner.DoStep("Click on the Custom navigation link in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
            });
            if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Custom Navigation is not correct");                
                //Assert.Fail("Custom Navigation is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });

            Runner.DoStep("Click on the Standard navigation link in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
            });
            if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Standard Navigation is not correct");  
                //Assert.Fail("Standard Navigation is not correct");
            }
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        string customStartDate = null;
        string customEndDate = null;
        //[TestCategory(TestType.NA_Sanity, "TC04_RBCustomValidation")]
        //[TestCategory(TestType.NA_Regression, "TC04_RBCustomValidation")]
        //[TestCategory(TestType.EU_Sanity, "TC04_RBCustomValidation")]
        //[TestCategory(TestType.EU_Regression, "TC04_RBCustomValidation")]
        [TestCategory(TestType.reports, "TC04_RBCustomValidation")]
        [Test, Description("Verify the Custom period selection functionality")]
        public void TC04_RBCustomValidation()
        {
            Page.ReportsTabPage.Custom.Focus();
            Thread.Sleep(1000);
            Page.ReportsTabPage.Custom.Click();
            Thread.Sleep(1000);
            customStartDate = "03/27/2016";
            customEndDate = "03/29/2016";
            DateTime startDate = DateTime.ParseExact(customStartDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            DateTime endDate = DateTime.ParseExact(customEndDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            //StartDateSelection(startDate);


            Page.ReportsTabPage.DateSelection(startDate, Page.ReportsTabPage.WPADCustStartDatDay, Page.ReportsTabPage.WPADCustStartDatMonth, Page.ReportsTabPage.WPADCustStartDatYear, 1);
            Thread.Sleep(1000);
            //EndDateSelection(endDate);
            Page.ReportsTabPage.DateSelection(endDate, Page.ReportsTabPage.WPADCustEndDatDay, Page.ReportsTabPage.WPADCustEndDatMonth, Page.ReportsTabPage.WPADCustEndDatYear, 2);
            //Thread.Sleep(1000);
            //GroupBySelection(startDate, endDate);
            Runner.DoStep("Select two Custom dates in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.Apply.Click();
            });
            string dateRangelbl = null;
            if (startDate.Year == endDate.Year)
            {
                dateRangelbl = startDate.ToString("dd MMM") + " - " + endDate.ToString("dd MMM yyyy");
            }
            else
            {
                dateRangelbl = startDate.ToString("dd MMM yyyy") + " - " + endDate.ToString("dd MMM yyyy");
            }

            if (Page.ReportsTabPage.WPADCustDateRangeLbl.BaseElement.InnerText != dateRangelbl)
            {
                flag = true;
                errorBuilder.Append("Date Range is not matched with selected dates");  
               // Assert.Fail("Date Range is not matched with selected dates");
            }
            Thread.Sleep(1000);
            //Page.ReportsTabPage.ReportsGrid.MainTable.ScrollToVisible();

            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC05_RBFilter")]
        //[TestCategory(TestType.NA_Regression, "TC05_RBFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC05_RBFilter")]
        //[TestCategory(TestType.EU_Regression, "TC05_RBFilter")]
        [TestCategory(TestType.reports, "TC05_RBFilter")]
        [Test, Description("Verify the Filter functionality")]
        public void TC05_RBFilter()
        {
            Thread.Sleep(1000);
            Runner.DoStep("Select filters in 'Rejected Batch' page", () =>
           {
               //Page.ReportsTabPage.ReportsTab.Click();
               Page.ReportsTabPage.Filter.Click();
               Page.ReportsTabPage.AddMoreFilters.Click();
               Page.ReportsTabPage.WPRBFormulaFormSegFilt.Click();
               Page.ReportsTabPage.WPPVHealthCareFilt.Click();
               //Page.ReportsTabPage.WPADAddFiltDisp.Click();
           });
            Page.ReportsTabPage.ApplyFilter.Click();

            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }

        }


        ////Valid for Multiple plants scenario.
        //[TestCategory(TestType.reports, "TC16_RejectedBatchesAddColumns")]
        //[Test]
        //public void TC16_RejectedBatchesAddColumns()
        //{
        //    Page.ReportsTabPage.AddColumn.Click();
        //    Page.ReportsTabPage.WPADColWash.Click();
        //    Page.ReportsTabPage.WPADColDV.Click();
        //    Page.ReportsTabPage.WPADColForm.Click();
        //    Page.ReportsTabPage.WPADColStatus.Click();

        //    if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Washer #").Count == 0)
        //    {
        //        Assert.Fail("Column Not Added");
        //    }
        //    if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Desired Value").Count == 0)
        //    {
        //        Assert.Fail("Column Not Added");
        //    }
        //    if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Formula #").Count == 0)
        //    {
        //        Assert.Fail("Column Not Added");
        //    }
        //    if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Status").Count == 0)
        //    {
        //        Assert.Fail("Column Not Added");
        //    }
        //    Thread.Sleep(1000);
        //}

        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);

            // dayDiff = (Int32.Parse(startDay)) - (Int32.Parse(endDay));
        }

        //[TestCategory(TestType.NA_Sanity, "TC06_RBViewCategory")]
        //[TestCategory(TestType.NA_Regression, "TC06_RBViewCategory")]
        //[TestCategory(TestType.EU_Sanity, "TC06_RBViewCategory")]
        //[TestCategory(TestType.EU_Regression, "TC06_RBViewCategory")]
        [TestCategory(TestType.reports, "TC06_RBViewCategory")]
        [Test, Description("Verify Time Catogery view")]
        public void TC06_RBViewCategory()
        {
            //Page.ReportsTabPage.ReportsTab.Click();
            //Thread.Sleep(2000);
            Page.ReportsTabPage.CRViewCategory.Click();
            Runner.DoStep("Click on TIME view in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.TimeCategory.Click();
            });

            if (!Page.ReportsTabPage.ReportsGridTable.GetReportRows()[0].BaseElement.InnerText.Contains("Interval"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Time Category");  
                //Assert.Fail("Header column is not matched with selected Time Category ");
            }

            Page.ReportsTabPage.CRViewCategory.Click();
            Runner.DoStep("Click on LOCATION view in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.LocationCategory.Click();
            });

            if (!Page.ReportsTabPage.ReportsGridTable.GetReportRows()[0].BaseElement.InnerText.Contains("Location"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Location Category");  
              //  Assert.Fail("Header column is not matched with selected Location Category ");
            }

            Page.ReportsTabPage.CRViewCategory.Click();
            Runner.DoStep("Click on FORMULA view in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.CRFormulaCategory.Click();
            });
            string str = Page.ReportsTabPage.ReportsGridTable.GetReportRows()[0].BaseElement.InnerText;
            if (!Page.ReportsTabPage.ReportsGridTable.GetReportRows()[0].BaseElement.InnerText.Contains("Formula Segment"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Formula Category");  
                //Assert.Fail("Header column is not matched with selected Formula Category ");
            }

            Page.ReportsTabPage.CRViewCategory.Click();
            Runner.DoStep("Click on CUSTOMER view in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.PPlantCustCategoryCentral.Click();
            });
            if (!Page.ReportsTabPage.ReportsGridTable.GetReportRows()[0].BaseElement.InnerText.Contains("Customer Name"))
            {
                flag = true;
                errorBuilder.Append("Header column is not matched with selected Customer Category ");  
               // Assert.Fail("Header column is not matched with selected Customer Category ");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC07_RBVerifyHeaders")]
        //[TestCategory(TestType.NA_Regression, "TC07_RBVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC07_RBVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC07_RBVerifyHeaders")]
        [TestCategory(TestType.reports, "TC07_RBVerifyHeaders")]
        [Test, Description("Verify the Headers in the page")]
        public void TC07_RBVerifyHeaders()
        {
            Runner.DoStep("Verify columns in 'Rejected Batch' page", () =>
            {
                List<string> headers = new List<string> { "No. of Loads", "No. of Rejected Loads", "Rejected Loads " };
                Page.ReportsTabPage.VerifyHeader(headers);
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC08_RBDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Regression, "TC08_RBDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC08_RBDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC08_RBDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC08_RBDefaultFiltersVerification")]
        [Test, Description("Verify the default filters functionality in the page")]
        public void TC08_RBDefaultFiltersVerification()
        {
            Runner.DoStep("Click on the Filter button in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.Filter.Click();
            });
            List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula Segment", "Formula", "Formula Category", "Plant Customer" };

            bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
            if (!isFilterMatch)
            {
                flag = true;
                errorBuilder.Append("Default Filters are not Correct in Rejected Batch Report");  
               // Assert.Fail("Default Filters are not Correct in Rejected Batch Report");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC09_RBAddToFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC09_RBAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC09_RBAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC09_RBAddToFavourite")]
        [TestCategory(TestType.reports, "TC09_RBAddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC09_RBAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Rejected Batches AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);

            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC10_RBDownloadReport")]
        //[TestCategory(TestType.NA_Regression, "TC10_RBDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC10_RBDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC10_RBDownloadReport")]
        [TestCategory(TestType.reports, "TC10_RBDownloadReport")]
        [Test, Description("Verify the Excel and PDF functionalities")]
        public void TC10_RBDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.ProcessValRejectedBatchesLink.Click();
            Runner.DoStep("Click on the Excel button in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Rejected Batches";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on the PDF button in 'Rejected Batch' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);
            Page.ReportsTabPage.PDFVerify(partialName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC11_RBRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC11_RBRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC11_RBRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC11_RBRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC11_RBRemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC11_RBRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Rejected Batches AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }

        }
        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");  
                   // Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
