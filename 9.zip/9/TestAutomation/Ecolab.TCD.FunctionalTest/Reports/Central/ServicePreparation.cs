﻿using ArtOfTest.WebAii.ObjectModel;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class ServicePreparation : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.EcolabInternalTabCentral.MouseHover();
            Page.ReportsTabPage.ServicePreparation.Click();
            Thread.Sleep(6000);
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        List<iAttribute> attlist;
        //[TestCategory(TestType.NA_Sanity, "TC01_ServicePreparationGridView")]
        //[TestCategory(TestType.NA_Regression, "TC01_ServicePreparationGridView")]
        //[TestCategory(TestType.EU_Sanity, "TC01_ServicePreparationGridView")]
        //[TestCategory(TestType.EU_Regression, "TC01_ServicePreparationGridView")]
        [TestCategory(TestType.reports, "TC01_ServicePreparationGridView")]
        [Test, Description("Verify the grid for multiple views")]
        public void TC01_ServicePreparationGridView()
        {
            if (!Page.ReportsTabPage.ReportPanel.IsEnabled)
            {
                flag = true;
                errorBuilder.Append("Report is not displaying correctly: Unable to locate the Report Panel");
               // Assert.Fail("Report is not displaying correctly: Unable to locate the Report Panel");
            }
            SummaryGridView();
            ProductionGridView();
            MachineUtilityGridView();
            ChemicalConsumptionGridView();
            AlarmRedFlagGridView();
            if(flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC02_AddToFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC02_AddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC02_AddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC02_AddToFavourite")]
        [TestCategory(TestType.reports, "TC02_AddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC02_AddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Service Preparation AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC03_DownloadReport")]
        //[TestCategory(TestType.NA_Regression, "TC03_DownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC03_DownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC03_DownloadReport")]
        [TestCategory(TestType.reports, "TC03_DownloadReport")]
        [Test, Description("Verify the PDF functionality")]
        public void TC03_DownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.EcolabInternalTabCentral.MouseHover();
            Page.ReportsTabPage.ServicePreparation.Click();
            Thread.Sleep(1000);
            string partialName = "Service Preparation";
            Runner.DoStep("Click on the PDF button in 'Service Preparation' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);
            Page.ReportsTabPage.PDFVerify(partialName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC04_RemoveFromFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC04_RemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC04_RemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC04_RemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC04_RemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC04_RemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Service Preparation AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        public void SummaryGridView()
        {
            attlist = new List<iAttribute>(Page.ReportsTabPage.SummaryLink.Attributes);
            if (attlist[3].Value.ToString().Contains("collapsed"))
            {
                Page.ReportsTabPage.SummaryLink.Click();
            }
            Runner.DoStep("Verify the grid for SUMMARY view in 'Service Preparation' page", () =>
            {
                int a = Page.ReportsTabPage.SummaryTable1.Rows.Count;
                if (a > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                  //  Assert.Fail("Error occured without data");
                }

                string HeaderRows1 = Page.ReportsTabPage.SummaryTable1.MainTable.AllRows[1].BaseElement.InnerText;
                List<string> headers1 = new List<string> { "Item", "Value", "No Of Red Flags", "Value", "%Change", "Trend" };
                VerifyHeader(headers1, HeaderRows1);

                int b = Page.ReportsTabPage.SummaryTable2.Rows.Count;
                if (b > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                  //  Assert.Fail("Error occured without data");
                }
                string HeaderRows2 = Page.ReportsTabPage.SummaryTable2.MainTable.AllRows[1].BaseElement.InnerText;
                List<string> headers2 = new List<string> { "Item Description", "Who" };
                VerifyHeader(headers2, HeaderRows2);
            });
            Page.ReportsTabPage.SummaryLink.Click();
        }
        public void ProductionGridView()
        {
            attlist = new List<iAttribute>(Page.ReportsTabPage.ProductionLink.Attributes);
            if (attlist[3].Value.ToString().Contains("collapsed"))
            {
                Page.ReportsTabPage.SPProductionLink.Click();
            }
            Runner.DoStep("Verify the grid for PRODUCTION view in 'Service Preparation' page", () =>
            {
                int a = Page.ReportsTabPage.ProductionTable.Rows.Count;
                if (a > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                    //Assert.Fail("Error occured without data");
                }
                string HeaderRows1 = Page.ReportsTabPage.ProductionTable.MainTable.AllRows[1].BaseElement.InnerText;
                List<string> headers1 = new List<string> { "Formulas", "Last 4 Weeks", "Prev 12 Weeks" };
                VerifyHeader(headers1, HeaderRows1);
            });
            Page.ReportsTabPage.SPProductionLink.Click();
        }

        public void MachineUtilityGridView()
        {
            attlist = new List<iAttribute>(Page.ReportsTabPage.MachinesUtilitiesLink.Attributes);
            if (attlist[3].Value.ToString().Contains("collapsed"))
            {
                Page.ReportsTabPage.MachinesUtilitiesLink.Click();
            }
            Runner.DoStep("Verify the grid for MACHINE view in 'Service Preparation' page", () =>
            {

                int a = Page.ReportsTabPage.MachinesUtilitiesTable1.Rows.Count;
                if (a > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                  //  Assert.Fail("Error occured without data");
                }
                string HeaderRows1 = Page.ReportsTabPage.MachinesUtilitiesTable1.MainTable.AllRows[1].BaseElement.InnerText;
                List<string> headers1 = new List<string> { "Machine Name", "Last 4 Weeks", "Prev 12 Weeks" };
                VerifyHeader(headers1, HeaderRows1);

                int b = Page.ReportsTabPage.MachinesUtilitiesTable2.Rows.Count;
                if (b > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                 //   Assert.Fail("Error occured without data");
                }
                string HeaderRows2 = Page.ReportsTabPage.MachinesUtilitiesTable2.MainTable.AllRows[1].BaseElement.InnerText;
                List<string> headers2 = new List<string> { "Last 4 Weeks", "Prev 12 Weeks" };
                VerifyHeader(headers2, HeaderRows2);
            });
            Page.ReportsTabPage.MachinesUtilitiesLink.Click();

        }

        public void ChemicalConsumptionGridView()
        {
            attlist = new List<iAttribute>(Page.ReportsTabPage.ChemicalConsumpLink.Attributes);
            if (attlist[3].Value.ToString().Contains("collapsed"))
            {
                Page.ReportsTabPage.ChemicalConsumpLink.Click();
            }
            Runner.DoStep("Verify the grid for CHEMICAL CONSUMPTION view in 'Service Preparation' page", () =>
            {

                int a = Page.ReportsTabPage.ChemicalConsumptionTable.Rows.Count;
                if (a > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                 //   Assert.Fail("Error occured without data");
                }
                string HeaderRows1 = Page.ReportsTabPage.ChemicalConsumptionTable.MainTable.AllRows[1].BaseElement.InnerText;
                List<string> headers1 = new List<string> { "Chemical Name", "Last 4 Weeks", "Prev 12 Weeks", "UOM", "Stock", "Stock Days", "Last visit C&I deviation" };
                VerifyHeader(headers1, HeaderRows1);
            });
            Page.ReportsTabPage.ChemicalConsumpLink.Click();
        }
        public void AlarmRedFlagGridView()
        {
            attlist = new List<iAttribute>(Page.ReportsTabPage.AlarmRedFlagLink.Attributes);
            if (attlist[3].Value.ToString().Contains("collapsed"))
            {
                Page.ReportsTabPage.AlarmRedFlagLink.Click();
            }
            Runner.DoStep("Verify the grid for ALARM REDFLAG view in 'Service Preparation' page", () =>
            {

                int a = Page.ReportsTabPage.AlarmRedFlagTable1.Rows.Count;
                if (a > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                   // Assert.Fail("Error occured without data");
                }
                string HeaderRows1 = Page.ReportsTabPage.AlarmRedFlagTable1.MainTable.AllRows[0].BaseElement.InnerText;
                List<string> headers1 = new List<string> { "KPI Name", "No. of Red Flags", "UOM", "Min", "Max" };
                VerifyHeader(headers1, HeaderRows1);

                int b = Page.ReportsTabPage.AlarmRedFlagTable2.Rows.Count;
                if (b > 0)
                {
                    Assert.IsTrue(true);
                }
                else
                {
                    flag = true;
                    errorBuilder.Append("Error occured without data");
                   // Assert.Fail("Error occured without data");
                }
                string HeaderRows2 = Page.ReportsTabPage.AlarmRedFlagTable2.MainTable.AllRows[1].BaseElement.InnerText;
                List<string> headers2 = new List<string> { "Formulas", "No of Loads", "No of Rejected Loads", "Rejected Loads", "Cycle", "Injection", "Temp", "ph" };
                VerifyHeader(headers2, HeaderRows2);
            });
            Page.ReportsTabPage.AlarmRedFlagLink.Click();
        }

        public void VerifyHeader(List<string> headers, string HeaderRows)
        {

            foreach (string s in headers)
            {
                if (!HeaderRows.Contains(s))
                {
                    flag = true;
                    errorBuilder.Append(s + "header not found");
                    //Assert.Fail(s + "header not found");
                }
            }
        }

    }
}
