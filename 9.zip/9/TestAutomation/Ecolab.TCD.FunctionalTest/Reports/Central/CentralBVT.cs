﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class CentralBVT : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.EcolabInternalTabCentral.MouseHover();
            Page.ReportsTabPage.AccountSummary.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        [Test]
        public void TC01_VerifyProductionSummaryReportNavigation()
        {
            Runner.DoStep("Verify Production Summary Report Navigation", () =>
            {
                Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
                Page.ReportsTabPage.ProductionSummaryLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Production Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Production Summary Report link is not working");
                    //Assert.Fail("Production Summary Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC02_VerifyProductionDetailsReportNavigation()
        {
            Runner.DoStep("Verify Production Details Report Navigation", () =>
            {
                Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
                Page.ReportsTabPage.ProductionDetailsLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Production Details"))
                {
                    flag = true;
                    errorBuilder.Append("\n Production Details Report link is not working");
                    //Assert.Fail("Production Details Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC03_VerifyPeriodProductionReportNavigation()
        {
            Runner.DoStep("Verify Period Production  Report Navigation", () =>
           {
               Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
               Page.ReportsTabPage.PeriodProductionLink.Click();
               if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Period Production"))
               {
                   flag = true;
                   errorBuilder.Append("\n Period Production Report link is not working");
                   //Assert.Fail("Period Production Report link is not working");
               }
           });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC04_VerifyEfficiencyWashingEquipmentReportNavigation()
        {

            Runner.DoStep("Verify Efficiency Washing Equipment Report Navigation", () =>
            {
                Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
                Page.ReportsTabPage.EfficiencyWashingEquipmentLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Efficiency Washing Equipment"))
                {
                    flag = true;
                    errorBuilder.Append("\n Efficiency Washing Equipment Report link is not working");
                    //Assert.Fail("Efficiency Washing Equipment Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC05_VerifyEfficiencyByMacineReportNavigation()
        {
            Runner.DoStep("Verify Efficiency by Machine Report Navigation", () =>
            {
                Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
                Page.ReportsTabPage.EfficiencyByMachineLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Efficiency by Machine"))
                {
                    flag = true;
                    errorBuilder.Append("\n Efficiency by Machine Report link is not working");
                    //Assert.Fail("Efficiency by Machine Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC06_VerifyRewashReportNavigation()
        {
            Runner.DoStep("Verify Rewash Report Navigation", () =>
            {
                Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
                Page.ReportsTabPage.RewashLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Rewash"))
                {
                    flag = true;
                    errorBuilder.Append("\n Rewash Report link is not working");
                    //Assert.Fail("Rewash Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC07_VerifyWashingProcessValidationReportNavigation()
        {
            Runner.DoStep("Verify Process Validation Details Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
                Page.ReportsTabPage.ProcessValidationDetails.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Process Validation Details"))
                {
                    flag = true;
                    errorBuilder.Append("\n Process Validation Details Report link is not working");
                    //Assert.Fail("Process Validation Details Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC08_VerifyAlarmSummaryReportNavigation()
        {
            Runner.DoStep("Verify Alarms Summary Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
                Page.ReportsTabPage.AlarmsSummaryLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Alarms Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Alarms Summary Report link is not working");
                    //Assert.Fail("Alarms Summary Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC09_VerifyAlarmDetailsReportNavigation()
        {
            Runner.DoStep("Verify Alarms Details Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
                Page.ReportsTabPage.AlarmDetails.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Alarms Details"))
                {
                    flag = true;
                    errorBuilder.Append("\n Alarms Details Report link is not working");
                    //Assert.Fail("Alarms Details Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC10_VerifyRedFlagsReportNavigation()
        {
            Runner.DoStep("Verify Red Flags Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
                Page.ReportsTabPage.ProcessValRedFlagLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Red Flags"))
                {
                    flag = true;
                    errorBuilder.Append("\n Red Flags Report link is not working");
                    //Assert.Fail("Red Flags Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC11_VerifyRejectedBatchesReportNavigation()
        {
            Runner.DoStep("Verify Rejected Batches Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
                Page.ReportsTabPage.ProcessValRejectedBatchesLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Rejected Batches"))
                {
                    flag = true;
                    errorBuilder.Append("\n Rejected Batches Report link is not working");
                    //Assert.Fail("Rejected Batches Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC12_VerifyRejectedBatchesReportNavigation()
        {
            Runner.DoStep("Verify Process Validation Summary Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
                Page.ReportsTabPage.ProcessValSummaryLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Process Validation Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Process Validation Summary Report link is not working");
                    //Assert.Fail(" Process Validation Summary Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC13_VerifyOperationsSummaryReportNavigation()
        {
            Runner.DoStep("Verify Operations Summary  Report Navigation", () =>
            {
                Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
                Page.ReportsTabPage.OperationsSummaryLink.Click();
                Thread.Sleep(1000);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Operations Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Operations Summary Report link is not working");
                    //Assert.Fail("Operations Summary Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC14_VerifyMetersReportNavigation()
        {
            Runner.DoStep("Verify Meters  Report Navigation", () =>
            {
                Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
                Page.ReportsTabPage.Meters.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Meters"))
                {
                    flag = true;
                    errorBuilder.Append("\n Meters Report link is not working");
                    //Assert.Fail("Meters Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC15_VerifyChemicalConsumptionReportNavigation()
        {
            Runner.DoStep("Verify Chemical Consumption Report Navigation", () =>
            {
                Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
                Page.ReportsTabPage.ChemicalConsumptionLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Chemical Consumption"))
                {
                    flag = true;
                    errorBuilder.Append("\n Chemical Consumption Report link is not working");
                    //Assert.Fail("Chemical Consumption Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC16_VerifyChemicalInventoryReportNavigation()
        {
            Runner.DoStep("Verify Chemical Inventory Report Navigation", () =>
            {
                Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
                Page.ReportsTabPage.ChemicalInventoryLink.Click();
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Chemical Inventory"))
                {
                    flag = true;
                    errorBuilder.Append("\n Chemical Inventory Report link is not working");
                    //Assert.Fail("Chemical Inventory Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC17_VerifyCostsSummaryReportNavigation()
        {
            Runner.DoStep("Verify Costs Summary  Report Navigation", () =>
            {
                Page.ReportsTabPage.FinancialsTab.MouseHover();
                Page.ReportsTabPage.CostSummary.Click();
                Thread.Sleep(1000);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Costs Summary"))
                {

                    flag = true;
                    errorBuilder.Append("\n Costs Summary Report link is not working");
                    //Assert.Fail("Costs Summary Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC18_VerifyServicePreparationReportNavigation()
        {
            Runner.DoStep("Verify Service Preparation  Report Navigation", () =>
            {
                Page.ReportsTabPage.EcolabInternalTab.MouseHover();
                Page.ReportsTabPage.ServicePreparation.Click();
                Thread.Sleep(1500);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Service Preparation"))
                {
                    flag = true;
                    errorBuilder.Append("\n Service Preparation Report link is not working");
                    //Assert.Fail("Service Preparation Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC19_VerifyMachineHoldTimeReportNavigation()
        {
            Runner.DoStep("Verify Machine Hold Time  Report Navigation", () =>
            {
                Page.ReportsTabPage.EcolabInternalTab.MouseHover();
                Page.ReportsTabPage.MachineHoldTime.Click();
                Thread.Sleep(1500);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Machine Hold Time"))
                {
                    flag = true;
                    errorBuilder.Append("\n Machine Hold Time Report link is not working");
                    //Assert.Fail("Machine Hold Time Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC20_VerifyWashingProgramsDetailsReportNavigation()
        {
            Runner.DoStep("Verify Washing Programs Details  Report Navigation", () =>
            {
                Page.ReportsTabPage.EcolabInternalTab.MouseHover();
                Page.ReportsTabPage.WashingProgramsDetails.Click();
                Thread.Sleep(1500);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Washing Programs Details"))
                {
                    flag = true;
                    errorBuilder.Append("\n Washing Programs Details Report link is not working");
                    //Assert.Fail("Washing Programs Details Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC21_VerifyAccountSummaryReportNavigation()
        {
            Runner.DoStep("Verify Account Summary  Report Navigation", () =>
            {
                Page.ReportsTabPage.EcolabInternalTab.MouseHover();
                Page.ReportsTabPage.AccountSummary.Click();
                Thread.Sleep(2500);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("Account Summary"))
                {
                    flag = true;
                    errorBuilder.Append("\n Account Summary Report link is not working");
                    //Assert.Fail("Account Summary Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC22_VerifyFFevaluationReportNavigation()
        {
            Runner.DoStep("Verify FF evaluation  Report Navigation", () =>
            {
                Page.ReportsTabPage.EcolabInternalTab.MouseHover();
                Page.ReportsTabPage.FFEvaluation.Click();
                Thread.Sleep(1500);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("FF evaluation"))
                {
                    flag = true;
                    errorBuilder.Append("\n FF evaluation Report link is not working");
                    //Assert.Fail("FF evaluation Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        [Test]
        public void TC23_VerifyUserlogReportNavigation()
        {
            Runner.DoStep("Verify User log  Report Navigation", () =>
            {
                Page.ReportsTabPage.EcolabInternalTab.MouseHover();
                Page.ReportsTabPage.UserLogCentral.Click();
                Thread.Sleep(1500);
                if (!Page.ReportsTabPage.ReportTitle.BaseElement.InnerText.Contains("User log"))
                {
                    flag = true;
                    errorBuilder.Append("\n User log Report link is not working");
                    //Assert.Fail("User log Report link is not working");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
    }
}
