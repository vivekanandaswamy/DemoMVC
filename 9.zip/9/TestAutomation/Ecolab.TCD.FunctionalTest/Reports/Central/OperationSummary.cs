﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class OperationSummary : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            Page.ReportsTabPage.OperationsSummaryLink.DeskTopMouseClick();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Regression, "TC01_OSCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_OSCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_OSCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_OSCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_OSCurrentSearchOperations")]
        [Test, Description("Verifying Current search options and its results in OPeration Summary Report")]
        public void TC01_OSCurrentSearchOperations()
        {
            Runner.DoStep("Select Current, Day options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
            });
            GetValues();
            ValidateToday();
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (previousMonth != currentMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();


            Runner.DoStep("Select Current, Week options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();
            ValidateToday();
            DateTime input = DateTime.Today;
            int sunday = DayOfWeek.Sunday - input.DayOfWeek;
            DateTime sundayDate = input.AddDays(sunday);
            string sundayDay = sundayDate.ToString("dd");
            string sundayMonth = sundayDate.ToString("MMM");
            if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Month options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
            });
            GetValues();
            ValidateToday();
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Quarter options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
            });
            GetValues();
            ValidateToday();
            if ((Int32.Parse(previousDay) != 01))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
            string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");
            if (firstMonthInQuarter != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Year options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
            });
            GetValues();
            ValidateToday();
            if ((previousDay != "01") || (previousMonth != "Jan"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, R12 options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.R12.Click();
            });
            GetValuesR12();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if(flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC02_OSPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC02_OSPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_OSPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_OSPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_OSPreviousSearchOperations")]
        [Test, Description("Verifying Previous search options and its results in Operation Summary evaluation Report")]
        public void TC02_OSPreviousSearchOperations()
        {
            Runner.DoStep("Select Previous, Day options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.DayView.Click();
            });
            GetValues();
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!yesterday.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");
                    // Assert.Fail("Date Range is not correct");
                }
            }
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if ((previousMonth != currentMonth) || (previousDay != currentDay))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Previous, Week options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();
            DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
            DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
            string oldDay = fistDayOfWeek.ToString("dd");
            string oldMonth = fistDayOfWeek.ToString("MMM");
            string newDay = lastDayOfWeek.ToString("dd");
            string newMonth = lastDayOfWeek.ToString("MMM");
            string newYear = lastDayOfWeek.ToString("yyyy");

            if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Previous, Month options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
            });
            GetValues();
            DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DateTime last = month.AddDays(-1);
            string lastDate = last.ToString("dd");
            string lastMonth = last.ToString("MMM");
            string lastYear = last.ToString("yyyy");
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();


            Runner.DoStep("Select Previous, Quarter options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
            });
            GetValues();
            int quarterNumber, prevQNumber;
            DateTime firstDayOfQuarter, lastDayOfQuarter;
            quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            if (quarterNumber == 1)
            {
                prevQNumber = 4;
                firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
            }
            else
            {
                prevQNumber = quarterNumber - 1;
                firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
            }

            if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Previous, Year options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
            });
            GetValues();
            lastYear = DateTime.Now.AddYears(-1).Year.ToString();
            if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();


            Page.ReportsTabPage.DayView.Click();

            Runner.DoStep("Select Previous, R12 options in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
            {
               flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC03_OSStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Sanity, "TC03_OSStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_OSStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_OSStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_OSStandardCustomNavigate")]
        [Test, Description("Verify the Standard and Custom navigation functionalities")]
        public void TC03_OSStandardCustomNavigate()
        {
            Runner.DoStep("Click on the Custom navigation link in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
            });
            if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Custom Navigation is not correct");              
                //Assert.Fail("Custom Navigation is not correct");
            }
            Runner.DoStep("Click on the Standard navigation link in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
            });
            if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
            {
                flag = true;
                errorBuilder.Append("Standard Navigation is not correct"); 
               // Assert.Fail("Standard Navigation is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC04_OSAddFilter")]
        //[TestCategory(TestType.NA_Sanity, "TC04_OSAddFilter")]
        //[TestCategory(TestType.EU_Regression, "TC04_OSAddFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC04_OSAddFilter")]
        [TestCategory(TestType.reports, "TC04_OSAddFilter")]
        [Test, Description("Verify the Filter functionality")]
        public void TC04_OSAddFilter()
        {
            Page.ReportsTabPage.R12.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ViewCategory.ScrollToVisible();
            Page.ReportsTabPage.ViewCategory.Click();
            Page.ReportsTabPage.FormulaCategory.Click();
            Page.ReportsTabPage.Filter.Click();
            Page.ReportsTabPage.AddMoreFilters.Click();
            Page.ReportsTabPage.FormulaSegment.Click();
            Page.ReportsTabPage.DrpFormulaSegment.Click();
            Page.ReportsTabPage.FormulaSegmentItem.Click();
            Runner.DoStep("Select filters in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.ApplyFilter.Click();
            });
            Thread.Sleep(2000);
            Page.ReportsTabPage.Filter.ScrollToVisible();
            if (Page.ReportsTabPage.ReportsGrid.GetColumnValue(1).Contains("Formula Seg 1"))
            {
                Assert.Pass();
            }
            else if (Page.ReportsTabPage.ReportsGrid.GetReportRows()[1].BaseElement.InnerText.Contains("No Records"))
            {
                Assert.Pass();
            }
            else
                Assert.Fail();

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC05_OSViewCategory")]
        //[TestCategory(TestType.NA_Sanity, "TC05_OSViewCategory")]
        //[TestCategory(TestType.EU_Regression, "TC05_OSViewCategory")]
        //[TestCategory(TestType.EU_Sanity, "TC05_OSViewCategory")]
        [TestCategory(TestType.reports, "TC05_OSViewCategory")]
        [Test, Description("Verify different views")]
        public void TC05_OSViewCategory()
        {
            Page.ReportsTabPage.ViewCategory.Click();
            Runner.DoStep("Click on TIME view in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.TimeCategory.Click();
            });
            Thread.Sleep(2000);
            int a = Page.ReportsTabPage.ReportsGrid.GetAllRows().Count;
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Interval").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Interval column doesnot exist"); 
              //  Assert.Fail("Interval column doesnot exist");
            }
            Page.ReportsTabPage.ViewCategory.Click();
            Runner.DoStep("Click on LOCATION view in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.LocationCategory.Click();
            });
            Thread.Sleep(2000);
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Location").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Location column doesnot exist"); 
               // Assert.Fail("Location column doesnot exist");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC06_OSAddColumn")]
        //[TestCategory(TestType.NA_Sanity, "TC06_OSAddColumn")]
        //[TestCategory(TestType.EU_Regression, "TC06_OSAddColumn")]
        //[TestCategory(TestType.EU_Sanity, "TC06_OSAddColumn")]
        [TestCategory(TestType.reports, "TC06_OSAddColumn")]
        [Test, Description("Verify ADD COLUMN functionality")]
        public void TC06_OSAddColumn()
        {
            Page.ReportsTabPage.AddColumn.MouseHover();
            Page.ReportsTabPage.AddColumn.Click();
            Runner.DoStep("Add ACTUAL CHEMICAL column in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.ActualChemicalUsage.Click();
            });
            Runner.DoStep("Add STANDARD WATER USAGE column in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.StandardWaterUsage.Click();
            });
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Actual Chemical Usage ").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Actual Chemical Usage Column Not Added"); 
              //  Assert.Fail("Column Not Added");
            }
            else if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Standard Water Usage").Count == 0)
            {
                flag = true;
                errorBuilder.Append("Standard Water Usage Column Not Added"); 
               // Assert.Fail("Column Not Added");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC07_OSVerifyCalenderControl")]
        //[TestCategory(TestType.NA_Sanity, "TC07_OSVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Regression, "TC07_OSVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Sanity, "TC07_OSVerifyCalenderControl")]
        [TestCategory(TestType.reports, "TC07_OSVerifyCalenderControl")]
        [Test, Description("Verify the Custom period selection functionality")]
        public void TC07_OSVerifyCalenderControl()
        {
            Page.ReportsTabPage.Custom.Click();
            Page.ReportsTabPage.CustomStartDate.SetText("02/09/2016");
            Page.ReportsTabPage.CustomEndDate.SetText("05/08/2016");
            Runner.DoStep("Select two Custom dates in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.Apply.Click();
            });
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC08_OSVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC08_OSVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC08_OSVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC08_OSVerifyHeaders")]
        [TestCategory(TestType.reports, "TC08_OSVerifyHeaders")]
        [Test, Description("Verify the Headers in the page")]
        public void TC08_OSVerifyHeaders()
        {
            Thread.Sleep(1000);
            Runner.DoStep("Verify columns in 'Operation Summary' page", () =>
            {
                List<string> headers = new List<string> { "Actual Production ","No. of Loads","Production Mix (%)",
            "Actual Water Cost","Actual Energy Cost","Total Chemical Cost"};
                Page.ReportsTabPage.VerifyHeader(headers);
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC09_OSDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Sanity, "TC09_OSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC09_OSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC09_OSDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC09_OSDefaultFiltersVerification")]
        [Test, Description("Verify the default filters functionality in the page")]
        public void TC09_OSDefaultFiltersVerification()
        {
            Runner.DoStep("Click on the Filter button in 'Operation Summary' page", () =>
            {
                Page.ReportsTabPage.Filter.Click();
            });
            List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula Segment", "Formula", "Formula Category", "Plant Customer" };

            bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
            if (!isFilterMatch)
            {
                flag = true;
                errorBuilder.Append("Default Filters are not Correct in Production Summary Report"); 
                //Assert.Fail("Default Filters are not Correct in Production Summary Report");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC10_OSAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC10_OSAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC10_OSAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC10_OSAddToFavourite")]
        [TestCategory(TestType.reports, "TC10_OSAddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC10_OSAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Operations Summary AutoTest";
            Runner.DoStep("Add 'Operations Summary' page to favourites", () =>
            {
                Page.ReportsTabPage.AddToFavourites(reportName, result);
            });
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC11_OSDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC11_OSDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC11_OSDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC11_OSDownloadReport")]
        [TestCategory(TestType.reports, "TC11_OSDownloadReport")]
        [Test, Description("Verify the Excel and PDF functionalities")]
        public void TC11_OSDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            Page.ReportsTabPage.OperationsSummaryLink.DeskTopMouseClick();
            Runner.DoStep("Click on the Excel button in 'Operations Summary' page", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Operations Summary";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);

            Runner.DoStep("Click on the PDF button in 'Operations Summary' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC12_OSRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC12_OSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC12_OSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC12_OSRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC12_OSRemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC12_OSRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Operations Summary AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);
        }
        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct"); 
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
