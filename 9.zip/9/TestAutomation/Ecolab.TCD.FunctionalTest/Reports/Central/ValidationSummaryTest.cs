﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class ValidationSummaryTest : TestBase
    {
        #region [Setup / TearDown]
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.WashingProcessValidationTab.Focus();
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.ProcessValSummaryLink.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        #endregion

        //[TestCategory(TestType.NA_Sanity, "TC01_PVSWithData")]
        //[TestCategory(TestType.NA_Regression, "TC01_PVSWithData")]
        //[TestCategory(TestType.EU_Sanity, "TC01_PVSWithData")]
        //[TestCategory(TestType.EU_Regression, "TC01_PVSWithData")]
        [TestCategory(TestType.reports, "TC01_PVSWithData")]
        [Test, Description("Verify the grid with data")]
        public void TC01_PVSWithData()
        {
            Thread.Sleep(1000);
            string strPVDate = "09/25/2015";
            DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            DateSelection(PVDate);
            Runner.DoStep("Verify the grid with data in 'Validation Summary' page", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            //if (Page.ReportsTabPage.tempreportTable.BaseElement.InnerText.Contains("9/25"))
            //{

            //    Assert.Pass("Data is displayed for selected plant and date.");
            //}
            //else if (Page.ReportsTabPage.tempreportTable.BaseElement.InnerText.Contains("No Records"))
            //{
            //    Assert.Pass("Data is not displayed for selected plant and date.");

            //}
            //else
            //    Assert.Fail("Error occured while data is loaded");

            //if(!Page.ReportsTabPage.IsBatchDetailsPresent || ! Page.ReportsTabPage.IsBatchInjectionPresent ||  ! Page.ReportsTabPage.IsBatchWashPresent)
            //{
            //    Assert.Fail("Data is not loaded for Selected Date");
            //}


        }

        //[TestCategory(TestType.NA_Sanity, "TC02_PVSWithOutData")]
        //[TestCategory(TestType.NA_Regression, "TC02_PVSWithOutData")]
        //[TestCategory(TestType.EU_Sanity, "TC02_PVSWithOutData")]
        //[TestCategory(TestType.EU_Regression, "TC02_PVSWithOutData")]
        [TestCategory(TestType.reports, "TC02_PVSWithOutData")]
        [Test, Description("Verify the grid without data")]
        public void TC02_PVSWithOutData()
        {

            Thread.Sleep(1000);
            string strPVDate = "09/25/2016";
            DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            DateSelection(PVDate);
            Runner.DoStep("Verify the grid without data in 'Validation Summary' page", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            // //string st=Page.ReportsTabPage.tempreportTable.BaseElement.InnerText;
            //if (Page.ReportsTabPage.tempreportTable.BaseElement.InnerText.Contains("No Records"))
            // {
            //     Assert.Pass("Data is not displayed for selected plant and date.");

            // }
            //else  if (Page.ReportsTabPage.tempreportTable.BaseElement.InnerText.Contains("9/25"))
            // {

            //     Assert.Pass("Data is displayed for selected plant and date.");
            // }
            // else
            //     Assert.Fail("Error occured while data is loaded");

        }

        //[TestCategory(TestType.NA_Sanity, "TC03_PVSFilter")]
        //[TestCategory(TestType.NA_Regression, "TC03_PVSFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC03_PVSFilter")]
        //[TestCategory(TestType.EU_Regression, "TC03_PVSFilter")]
        [TestCategory(TestType.reports, "TC03_PVSFilter")]
        [Test, Description("Verify the Filter functionality")]
        public void TC03_PVSFilter()
        {
            Thread.Sleep(1000);
            string strPVDate = "09/25/2015";
            DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            DateSelection(PVDate);

            Page.ReportsTabPage.Filter.Click();
            Page.ReportsTabPage.WPPVSFiltMachines.Click();
            Thread.Sleep(1000);
            Page.ReportsTabPage.WPPVSFilSelectAll.Click();
            Page.ReportsTabPage.WPPVFiltMachineType.Click();
            Runner.DoStep("Select filters in 'Rewash' page", () =>
            {
                Page.ReportsTabPage.ApplyFilter.Click();
            });
            if (Page.ReportsTabPage.ReportsGrid.GetColumnValues(1).Contains("Braun 675 lb"))
            {
                Assert.Pass();
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC04_PVSVerifyHeaders")]
        //[TestCategory(TestType.NA_Regression, "TC04_PVSVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC04_PVSVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC04_PVSVerifyHeaders")]
        [TestCategory(TestType.reports, "TC04_PVSVerifyHeaders")]
        [Test, Description("Verify the Headers in the page")]
        public void TC04_PVSVerifyHeaders()
        {
            Runner.DoStep("Select Year view in 'Validation Summary' page", () =>
            {
                List<string> headers = new List<string> { "Batch Start Date", "Machine Name", "Formula Name", "Formula Category","Load Efficiency (%)",
                "Invalid Operation Steps","Invalid Injections"};
                Page.ReportsTabPage.VerifyHeader(headers);
            });
        }

        //[TestCategory(TestType.NA_Sanity, "TC05_PVSDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Regression, "TC05_PVSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC05_PVSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC05_PVSDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC05_PVSDefaultFiltersVerification")]
        [Test, Description("Verify the default filters functionality in the page")]
        public void TC05_PVSDefaultFiltersVerification()
        {
            Runner.DoStep("Click on the Filter button in 'Validation Summary' page", () =>
            {
                Page.ReportsTabPage.Filter.Click();
            });
            List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Plant Customer", "Formula Segment", "Batch Status" };

            bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);

            if (!isFilterMatch)
            {
                flag = true;
                errorBuilder.Append("\n Default Filters are not Correct in Production Summary Report");
                //Assert.Fail("Default Filters are not Correct in Production Summary Report");
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC06_PVSAddToFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC06_PVSAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC06_PVSAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC06_PVSAddToFavourite")]
        [TestCategory(TestType.reports, "TC06_PVSAddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC06_PVSAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Process Validation Summary AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);

            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
        }
        //[TestCategory(TestType.NA_Sanity, "TC07_PVSDownloadReport")]
        //[TestCategory(TestType.NA_Regression, "TC07_PVSDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC07_PVSDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC07_PVSDownloadReport")]
        [TestCategory(TestType.reports, "TC07_PVSDownloadReport")]
        [Test, Description("Verify the PDF functionality")]
        public void TC07_PVSDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.ProcessValSummaryLink.Click();
            Thread.Sleep(1000);
            string strPVDate = "09/25/2015";
            DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            DateSelection(PVDate);
            Thread.Sleep(3000);
            string partialName = "Process Validation Summary";
            Runner.DoStep("Click on the PDF button in 'Validation Summary' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);
            Page.ReportsTabPage.PDFVerify(partialName, result);
        }
        //[TestCategory(TestType.NA_Sanity, "TC08_PVSRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC08_PVSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC08_PVSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC08_PVSRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC08_PVSRemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC08_PVSRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Process Validation Summary AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

        }
        public void DateSelection(DateTime startDate)
        {
            Page.ReportsTabPage.PVSummaryDate.Focus();
            Page.ReportsTabPage.PVSummaryDate.Click();

            Page.ReportsTabPage.ProcValSumDay.SelectButton.Click();
            Page.ReportsTabPage.ProcValSumMonth.SelectButton.Click();
            Page.ReportsTabPage.ProcValSumYear.Selectyear(startDate.ToString("yyyy"));
            Page.ReportsTabPage.ProcValSumMonth.SelectMonth(startDate.ToString("MMM"));
            Page.ReportsTabPage.ProcValSumDay.SelectDay(startDate.ToString("dd"));
            Thread.Sleep(1000);
        }

    }
}
