﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class MyServiceActionList : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ProductionEfficiencyTab.DeskTopMouseClick();
            Page.ReportsTabPage.MyServiceActionListLink.Click();
            DialogHandler.GetMessageAndOKButton();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        //[TestCategory(TestType.NA_Regression, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_MCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_MCurrentSearchOperations")]
        //[Test, Description("Verify the Headers in the page")]
        public void TC01_VerifyHeaders()
        {
            Runner.DoStep("Verify columns in 'My Service Action List' page", () =>
            {
                List<string> headers = new List<string> { "Date", "Description", "Plant Name", "In Charge", "Comments" };
                Page.ReportsTabPage.VerifyHeader(headers);
            });
        }
        //[TestCategory(TestType.NA_Regression, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_MCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_MCurrentSearchOperations")]
        //[Test, Description("Verify the Filter functionality")]
        public void TC02_MSFilter()
        {
            //Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(1000);
            Page.ReportsTabPage.Filter.Click();
            Page.ReportsTabPage.AddMoreFilters.Click();
            Page.ReportsTabPage.WPRBFormulaFormSegFilt.Click();
            Page.ReportsTabPage.WPPVHealthCareFilt.Click();
            Runner.DoStep("Select filters in 'My Service Action List' page", () =>
            {
                Page.ReportsTabPage.ApplyFilter.Click();
            });
            Page.ReportsTabPage.VerifyGrid();
        }
        //[TestCategory(TestType.NA_Regression, "TC03_MSDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Sanity, "TC03_MSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC03_MSDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC03_MSDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC03_MSDefaultFiltersVerification")]
        //[Test, Description("Verify the default filters functionality in the page")]
        public void TC03_MSDefaultFiltersVerification()
        {
            Runner.DoStep("Click on the Filter button in 'My Service Action List' page", () =>
            {
                Page.ReportsTabPage.Filter.Click();
            });
            List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula Segment", "Formula Category", "Plant Customer" };
            bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
            if (!isFilterMatch)
            {
                Assert.Fail("Default Filters are not Correct in 'My Service Action List' Report");

            }
        }

        //[TestCategory(TestType.NA_Regression, "TC04_MSAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC04_MSAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC04_MSAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC04_MSAddToFavourite")]
        [TestCategory(TestType.reports, "TC04_MSAddToFavourite")]
        // [Test, Description("Verifying Add to Favourite functionality in My Service Action List Report")]
        public void TC04_MSAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "My Service Action List AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
        }

        //[TestCategory(TestType.NA_Regression, "TC05_MSDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC05_MSDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC05_MSDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC05_MSDownloadReport")]
        [TestCategory(TestType.reports, "TC05_MSDownloadReport")]
        //[Test, Description("Verifying Export to Excel, PDF functionality in My Service Action List Report")]
        public void TC05_MSDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
            Page.ReportsTabPage.MyServiceActionListLink.Click();

            Runner.DoStep("Click on Export to Excel icon in My Service Action List Report", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "My Service Action List";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on Export to PDF icon in My Service Action List Report", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);
        }

        //[TestCategory(TestType.NA_Regression, "TC06_MSRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC06_MSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC06_MSRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC06_MSRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC06_MSRemoveFromFavourite")]
        // [Test, Description("Verifying Remove from Favourite functionality in My Service Action List Report")]
        public void TC06_MSRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "My Service Action List AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);
        }

    }
}
