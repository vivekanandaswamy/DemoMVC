﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class ValidationDetailsTest : TestBase
    {
        string strPVDate = "09/25/2015";
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.WashingProcessValidationTab.Focus();
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.ProcessValidationDetails.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
            Telerik.ActiveBrowser.Refresh();
        }

        //[TestCategory(TestType.NA_Sanity, "TC01_PVDWithData")]
        //[TestCategory(TestType.NA_Regression, "TC01_PVDWithData")]
        //[TestCategory(TestType.EU_Sanity, "TC01_PVDWithData")]
        //[TestCategory(TestType.EU_Regression, "TC01_PVDWithData")]
        [TestCategory(TestType.reports, "TC01_PVDWithData")]
        [Test, Description("Verify the grid with data")]
        public void TC01_PVDWithData()
        {

            //DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            // DateSelection(PVDate);
            Page.ReportsTabPage.TxtBatchDate.SetText(strPVDate);
            Page.ReportsTabPage.Machine.Click();
            Runner.DoStep("Verify the grid with data in 'Validation details' page", () =>
            {
                Page.ReportsTabPage.WPPVFiltMachineType.Click();
            });
            Thread.Sleep(1000);
            if (Page.ReportsTabPage.Batch.Options.Count > 0)
            {
                Page.ReportsTabPage.Batch.SelectByPartialText("09/25", true);
            }
            Thread.Sleep(3000);
            if (!Page.ReportsTabPage.IsBatchDetailsPresent || !Page.ReportsTabPage.IsBatchInjectionPresent || !Page.ReportsTabPage.IsBatchWashPresent)
            {
                flag = true;
                errorBuilder.Append("Data is not loaded for Selected Date");
                //Assert.Fail("Data is not loaded for Selected Date");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC02_PVDVerifyHeaders")]
        //[TestCategory(TestType.NA_Regression, "TC02_PVDVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC02_PVDVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC02_PVDVerifyHeaders")]
        [TestCategory(TestType.reports, "TC02_PVDVerifyHeaders")]
        [Test, Description("Verify the Headers in the page")]
        public void TC02_PVDVerifyHeaders()
        {
            //string strPVDate = "09/25/2015";
            //DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            //DateSelection(PVDate);
            //Page.ReportsTabPage.TxtBatchDate.SetText(strPVDate);
            //Page.ReportsTabPage.Machine.Click();
            //Page.ReportsTabPage.WPPVFiltMachineType.Click();
            //Thread.Sleep(1000);
            //if (Page.ReportsTabPage.Batch.Options.Count > 0)
            //{
            //    Page.ReportsTabPage.Batch.SelectByPartialText("09/25", true);
            //}
            //Thread.Sleep(3000);
            Runner.DoStep("Verify columns in 'Validation details' page", () =>
            {
                string HeaderRows1 = Page.ReportsTabPage.BatchDetailsTable.MainTable.AllRows[0].BaseElement.InnerText;
                List<string> headers1 = new List<string> { "Formula", "Formula Category", "Customer", "Machine", "Load Number", "Start Date/Time", "Finish Date/Time" };
                VerifyHeader(headers1, HeaderRows1);

                string HeaderRows2 = Page.ReportsTabPage.BatchInjectionTable.MainTable.AllRows[0].BaseElement.InnerText;
                List<string> headers2 = new List<string> { "Step", "Chemical", "Standard", "Injection Value", "Date Time", "Uom", "Status" };
                VerifyHeader(headers2, HeaderRows2);

                string HeaderRows3 = Page.ReportsTabPage.BatchWashTable.MainTable.AllRows[0].BaseElement.InnerText;
                List<string> headers3 = new List<string> { "Step", "Wash Code", "Measure Time", "Target Time" };
                VerifyHeader(headers3, HeaderRows3);
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC03_PVDWithOutData")]
        //[TestCategory(TestType.NA_Regression, "TC03_PVDWithOutData")]
        //[TestCategory(TestType.EU_Sanity, "TC03_PVDWithOutData")]
        //[TestCategory(TestType.EU_Regression, "TC03_PVDWithOutData")]
        [TestCategory(TestType.reports, "TC03_PVDWithOutData")]
        [Test, Description("Verify the grid without data")]
        public void TC03_PVDWithOutData()
        {
            //Thread.Sleep(1000);
            ////string strPVDate = "01/25/2016";
            ////DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", null);
            ////DateSelection(PVDate);
            Page.ReportsTabPage.TxtBatchDate.SetText(strPVDate);
            Page.ReportsTabPage.Machine.Click();
            Runner.DoStep("Verify the grid without data in 'Validation details' page", () =>
            {
                Page.ReportsTabPage.SelectMachine.Click();
            });
            //Thread.Sleep(1000);
            if (Page.ReportsTabPage.IsBatchDetailsPresent || Page.ReportsTabPage.IsBatchInjectionPresent || Page.ReportsTabPage.IsBatchWashPresent)
            {
                flag = true;
                errorBuilder.Append("Data should not be loaded for Selected Date");
                //Assert.Fail("Data should not be loaded for Selected Date");
            }
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC04_PVDAddToFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC04_PVDAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC04_PVDAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC04_PVDAddToFavourite")]
        [TestCategory(TestType.reports, "TC04_PVDAddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC04_PVDAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Process Validation Details AutoTest";
            Runner.DoStep("Add 'Validation details' page to favourites", () =>
            {
                Page.ReportsTabPage.AddToFavourites(reportName, result);
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        //[TestCategory(TestType.NA_Sanity, "TC05_PVDDownloadReport")]
        //[TestCategory(TestType.NA_Regression, "TC05_PVDDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC05_PVDDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC05_PVDDownloadReport")]
        [TestCategory(TestType.reports, "TC05_PVDDownloadReport")]
        [Test, Description("Verify the PDF functionality")]
        public void TC05_PVDDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
            Page.ReportsTabPage.ProcessValidationDetails.Click();
            //string strPVDate = "09/25/2015";
            //DateTime PVDate = DateTime.ParseExact(strPVDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            //DateSelection(PVDate);
            //Page.ReportsTabPage.TxtBatchDate.SetText(strPVDate);
            //Page.ReportsTabPage.Machine.Click();
            //Page.ReportsTabPage.WPPVFiltMachineType.Click();
            //Thread.Sleep(1000);
            //if (Page.ReportsTabPage.Batch.Options.Count > 0)
            //{
            //    Page.ReportsTabPage.Batch.SelectByPartialText("09/25", true);
            //}
            //Thread.Sleep(3000);
            string partialName = "Process Validation Details";

            Runner.DoStep("Click on the PDF button in 'Validation details' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);
            Page.ReportsTabPage.PDFVerify(partialName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Sanity, "TC06_PVDRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Regression, "TC06_PVDRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC06_PVDRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC06_PVDRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC06_PVDRemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC06_PVDRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Process Validation Details AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        public void VerifyHeader(List<string> headers, string HeaderRows)
        {

            foreach (string s in headers)
            {
                if (!HeaderRows.Contains(s))
                {
                    flag = true;
                    errorBuilder.Append(s + "header not found");
                    //Assert.Fail(s + "header not found");
                }
            }
        }

        //public void DateSelection(DateTime startDate)
        //{
        //    Page.ReportsTabPage.PVDetailsDate.Focus();
        //    Page.ReportsTabPage.PVDetailsDate.Click();

        //    Page.ReportsTabPage.PVDDay.SelectButton.Click();
        //    Page.ReportsTabPage.PVDeMonth.SelectButton.Click();
        //    Page.ReportsTabPage.PVDYear.Selectyear(startDate.ToString("yyyy"));
        //    Page.ReportsTabPage.PVDeMonth.SelectMonth(startDate.ToString("MMM"));
        //    Page.ReportsTabPage.PVDDay.SelectDay(startDate.ToString("dd"));
        //    Thread.Sleep(1000);
        //}
    }
}
