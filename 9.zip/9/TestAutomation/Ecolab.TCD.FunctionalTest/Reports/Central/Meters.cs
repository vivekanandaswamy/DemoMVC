﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class Meters : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Page.ReportsTabPage.Meters.Click();
            Page.ReportsTabPage.DdlPlants.SelectByIndex(0, true);
            Page.ReportsTabPage.DdlMeterType.SelectByIndex(1, true);
            Page.ReportsTabPage.DdlMeter.SelectByIndex(2, true);
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Regression, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_MCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_MCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_MCurrentSearchOperations")]
        [Test, Description("Verifying Current search options and its results in Meters Report")]
        public void TC01_MCurrentSearchOperations()
        {
            Runner.DoStep("Select Current, Day options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click(); Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
            });
            GetValues();
            ValidateToday();
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");               
            }
            if (previousMonth != currentMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();


            Runner.DoStep("Select Current, Week options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
            });
            GetValues();
            ValidateToday();
            DateTime input = DateTime.Today;
            int sunday = DayOfWeek.Sunday - input.DayOfWeek;
            DateTime sundayDate = input.AddDays(sunday);
            string sundayDay = sundayDate.ToString("dd");
            string sundayMonth = sundayDate.ToString("MMM");
            if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();


            Runner.DoStep("Select Current, Month options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            ValidateToday();
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();


            Runner.DoStep("Select Current, Quarter options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            ValidateToday();
            if ((Int32.Parse(previousDay) != 01))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);
            //Friday, April 01, 2016
            string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

            if (firstMonthInQuarter != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Runner.DoStep("Select Current, Year options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            ValidateToday();
            if ((previousDay != "01") || (previousMonth != "Jan"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Page.ReportsTabPage.CurrentView.Click();
            Runner.DoStep("Select Current, R12 options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            //validateToday();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if(flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC02_MPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC02_MPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_MPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_MPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_MPreviousSearchOperations")]
        [Test, Description("Verifying Previous search options and its results in Meters Report")]
        public void TC02_MPreviousSearchOperations()
        {
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Day options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.DayView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!yesterday.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");
                    // Assert.Fail("Date Range is not correct");
                }
            }
            if (dayDiff != 0)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if ((previousMonth != currentMonth) || (previousDay != currentDay))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Week options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.WeekView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
            DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
            string oldDay = fistDayOfWeek.ToString("dd");
            string oldMonth = fistDayOfWeek.ToString("MMM");
            string newDay = lastDayOfWeek.ToString("dd");
            string newMonth = lastDayOfWeek.ToString("MMM");
            string newYear = lastDayOfWeek.ToString("yyyy");

            if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Month options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.MonthView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DateTime last = month.AddDays(-1);
            string lastDate = last.ToString("dd");
            string lastMonth = last.ToString("MMM");
            string lastYear = last.ToString("yyyy");
            if (Int32.Parse(previousDay) != 01)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Quarter options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.QuarterView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            int quarterNumber, prevQNumber;
            DateTime firstDayOfQuarter, lastDayOfQuarter;
            quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            if (quarterNumber == 1)
            {
                prevQNumber = 4;
                firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
            }
            else
            {
                prevQNumber = quarterNumber - 1;
                firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
            }

            if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, Year options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.YearView.Click();
            });
            Thread.Sleep(2000);
            GetValues();
            lastYear = DateTime.Now.AddYears(-1).Year.ToString();
            if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();

            Page.ReportsTabPage.DayView.Click();
            Page.ReportsTabPage.PreviousView.Click();
            Runner.DoStep("Select Previous, R12 options in 'Meters' page", () =>
            {
                Page.ReportsTabPage.R12.Click();
            });
            Thread.Sleep(2000);
            GetValuesR12();
            DateTime currentDate = DateTime.Today;
            string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
            if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
            {
                flag = true;
                errorBuilder.Append("Date Range is not correct");
                // Assert.Fail("Date Range is not correct");
            }
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC03_MStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Sanity, "TC03_MStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_MStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_MStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_MStandardCustomNavigate")]
        [Test, Description("Verify the Standard and Custom navigation functionalities")]
        public void TC03_MStandardCustomNavigate()
        {
            Runner.DoStep("Click on the Custom navigation link in 'Meters' page", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
            });
            Page.ReportsTabPage.VerifyGrid();
            Runner.DoStep("Click on the Custom navigation link in 'Meters' page", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
            });
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC04_MVerifyCalenderControl")]
        //[TestCategory(TestType.NA_Sanity, "TC04_MVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Regression, "TC04_MVerifyCalenderControl")]
        //[TestCategory(TestType.EU_Sanity, "TC04_MVerifyCalenderControl")]
        [TestCategory(TestType.reports, "TC04_MVerifyCalenderControl")]
        [Test, Description("Verify the Custom period selection functionality")]
        public void TC04_MVerifyCalenderControl()
        {
            Page.ReportsTabPage.Custom.Click();
            Page.ReportsTabPage.CustomStartDate.SetText("02/09/2016");
            Page.ReportsTabPage.CustomEndDate.SetText("05/08/2016");
            Runner.DoStep("Select two Custom dates in 'Meters' page", () =>
            {
                Page.ReportsTabPage.Apply.Click();
            });
            Page.ReportsTabPage.VerifyGrid();
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC05_MVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC05_MVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC05_MVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC05_MVerifyHeaders")]
        [TestCategory(TestType.reports, "TC05_MVerifyHeaders")]
        [Test, Description("Verify the Headers in the page")]
        public void TC05_MVerifyHeaders()
        {
            Runner.DoStep("Verify columns in 'Meters' page", () =>
            {
                List<string> headers = new List<string> { "Interval", "Recorded Value","Processed Volume ","Cost When Applicable",
                "Actual Value ","Actual Cost"};
                Page.ReportsTabPage.VerifyHeader(headers);
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC06_MAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC01_MetersCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC06_MAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC06_MAddToFavourite")]
        [TestCategory(TestType.reports, "TC06_MAddToFavourite")]
        [Test, Description("Verify the 'Add To Favourites' functionality")]
        public void TC06_MAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Meters AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);

            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                Page.ReportsTabPage.VerifyGrid();
            });
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC07_MDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC07_MDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC07_MDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC07_MDownloadReport")]
        [TestCategory(TestType.reports, "TC07_MDownloadReport")]
        [Test, Description("Verify the Excel and PDF functionalities")]
        public void TC07_MDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
            Page.ReportsTabPage.Meters.Click();
            Page.ReportsTabPage.DdlPlants.SelectByIndex(0, true);
            Page.ReportsTabPage.DdlMeterType.SelectByIndex(1, true);
            Page.ReportsTabPage.DdlMeter.SelectByIndex(2, true);
            Runner.DoStep("Click on the Excel button in 'Meters' page", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Meters";
            Thread.Sleep(1000);

            Page.ReportsTabPage.ExcelVerify(partialName, result);

            Runner.DoStep("Click on the PDF button in 'Meters' page", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC08_MRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC08_MRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC08_MRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC08_MRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC08_MRemoveFromFavourite")]
        [Test, Description("Verify removing page from Favourites functionality")]
        public void TC08_MRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Meters AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);
            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }
        private void GetValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void GetValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);
        }

        private void ValidateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("Date Range is not correct");
                    // Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
