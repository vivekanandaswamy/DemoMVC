﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Reports.Central
{
    public class AlarmsSummaryTest : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();

        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDCentralAppUrl);
            Page.LoginPage.VerifyCentralLogin(Users.ReportsUser[0], Users.ReportsUser[1]);
            Page.ReportsTabPage.ReportsTabCentral.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.WashingProcessValidationTab.Focus();
            Page.ReportsTabPage.WashingProcessValidationTab.DeskTopMouseClick();
            Page.ReportsTabPage.AlarmsSummaryLink.Click();
        }
        [SetUp]
        public void StringBuilderCreation()
        {
            if (errorBuilder == null)
            {
                errorBuilder = new StringBuilder();
            }
        }
        [TearDown]
        public void TearDown()
        {
            flag = false;
            errorBuilder = null;
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear, startDay, startMonth, startYear, endDay, endMonth, endYear;
        int dayDiff;
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        //[TestCategory(TestType.NA_Regression, "TC01_ASCurrentSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC01_ASCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC01_ASCurrentSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC01_ASCurrentSearchOperations")]
        [TestCategory(TestType.reports, "TC01_ASCurrentSearchOperations")]
        [Test, Description("Verifying Current search options and its results in Alarm Summary Report")]
        public void TC01_ASCurrentSearchOperations()
        {
            Runner.DoStep("Select Current and Day options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.DayView.Click();
                getValues();
                validateToday();
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (previousMonth != currentMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Week options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.WeekView.Click();
                getValues();
                validateToday();
                DateTime input = DateTime.Today;
                int sunday = DayOfWeek.Sunday - input.DayOfWeek;
                DateTime sundayDate = input.AddDays(sunday);
                string sundayDay = sundayDate.ToString("dd");
                string sundayMonth = sundayDate.ToString("MMM");
                if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Month options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.MonthView.Click();
                getValues();
                validateToday();
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Quarter options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                getValues();
                validateToday();
                if ((Int32.Parse(previousDay) != 01))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                DateTime firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1);

                string firstMonthInQuarter = firstDayOfQuarter.ToString("MMM");

                if (firstMonthInQuarter != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and Year options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.YearView.Click();
                getValues();
                validateToday();
                if ((previousDay != "01") || (previousMonth != "Jan"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Current and R12 options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.CurrentView.Click();
                Page.ReportsTabPage.R12.Click();
                getValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-1).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC02_ASPreviousSearchOperations")]
        //[TestCategory(TestType.NA_Sanity, "TC02_ASPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Regression, "TC02_ASPreviousSearchOperations")]
        //[TestCategory(TestType.EU_Sanity, "TC02_ASPreviousSearchOperations")]
        [TestCategory(TestType.reports, "TC02_ASPreviousSearchOperations")]
        [Test, Description("Verifying previous search options and its results in Alarm Summary Report")]
        public void TC02_ASPreviousSearchOperations()
        {

            Runner.DoStep("Select Previous and Day options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.DayView.Click();
                getValues();
                List<string> list = new List<string>();
                list.Add(currentDay);
                list.Add(currentMonth);
                list.Add(currentYear);
                foreach (string item in list)
                {
                    if (!yesterday.Contains(item))
                    {
                        flag = true;
                        errorBuilder.Append("\n Date Range is not correct");
                        //Assert.Fail("Date Range is not correct");
                    }
                }
                if (dayDiff != 0)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((previousMonth != currentMonth) || (previousDay != currentDay))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Week options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.WeekView.Click();
                getValues();
                DateTime fistDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7);
                DateTime lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1);
                string oldDay = fistDayOfWeek.ToString("dd");
                string oldMonth = fistDayOfWeek.ToString("MMM");
                string newDay = lastDayOfWeek.ToString("dd");
                string newMonth = lastDayOfWeek.ToString("MMM");
                string newYear = lastDayOfWeek.ToString("yyyy");

                if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Month options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.MonthView.Click();
                getValues();
                DateTime month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                DateTime last = month.AddDays(-1);
                string lastDate = last.ToString("dd");
                string lastMonth = last.ToString("MMM");
                string lastYear = last.ToString("yyyy");
                if (Int32.Parse(previousDay) != 01)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentMonth != previousMonth)
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Quarter options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.QuarterView.Click();
                getValues();
                int quarterNumber, prevQNumber;
                DateTime firstDayOfQuarter, lastDayOfQuarter;
                quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
                if (quarterNumber == 1)
                {
                    prevQNumber = 4;
                    firstDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.AddYears(-1).Year, firstDayOfQuarter.AddMonths(2).Month));
                }
                else
                {
                    prevQNumber = quarterNumber - 1;
                    firstDayOfQuarter = new DateTime(DateTime.Today.Year, (prevQNumber - 1) * 3 + 1, 1);
                    lastDayOfQuarter = new DateTime(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month, DateTime.DaysInMonth(DateTime.Today.Year, firstDayOfQuarter.AddMonths(2).Month));
                }

                if (previousDay != firstDayOfQuarter.ToString("dd") || previousMonth != firstDayOfQuarter.ToString("MMM"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
                if (currentDay != lastDayOfQuarter.ToString("dd") || currentMonth != lastDayOfQuarter.ToString("MMM") || currentYear != lastDayOfQuarter.ToString("yyyy"))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and Year options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.YearView.Click();
                getValues();
                string lastYear = DateTime.Now.AddYears(-1).Year.ToString();
                if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            Runner.DoStep("Select Previous and R12 options in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.DayView.Click();
                Page.ReportsTabPage.PreviousView.Click();
                Page.ReportsTabPage.R12.Click();
                getValuesR12();
                DateTime currentDate = DateTime.Today;
                string lastdate = DateTime.DaysInMonth(currentDate.Year, currentDate.AddMonths(-1).Month).ToString();
                if ((startDay != "01") || (startMonth != currentDate.ToString("MMM")) || (startYear != currentDate.AddYears(-2).ToString("yyyy")) || (endDay != lastdate) || (endMonth != currentDate.AddMonths(-1).ToString("MMM")) || (endYear != currentDate.AddYears(-1).ToString("yyyy")))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC03_ASStandardCustomNavigate")]
        //[TestCategory(TestType.NA_Sanity, "TC03_ASStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Regression, "TC03_ASStandardCustomNavigate")]
        //[TestCategory(TestType.EU_Sanity, "TC03_ASStandardCustomNavigate")]
        [TestCategory(TestType.reports, "TC03_ASStandardCustomNavigate")]
        [Test, Description("Verifying Standard and Custom Navigation in Alarm Summary Report")]
        public void TC03_ASStandardCustomNavigate()
        {

            Runner.DoStep("Select Custom Navigation in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.ReportsNext.Click();
                if (!Page.ReportsTabPage.CustomContainer.IsVisible() || Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    flag = true;
                    errorBuilder.Append("\n Custom Navigation is not correct");
                    //Assert.Fail("Custom Navigation is not correct");
                }
            });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });
            Runner.DoStep("Select Standard Navigation in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.ReportsPrev.Click();
                if (Page.ReportsTabPage.CustomContainer.IsVisible() || !Page.ReportsTabPage.StandardContainer.IsVisible())
                {
                    flag = true;
                    errorBuilder.Append("\n Standard Navigation is not correct");
                    //Assert.Fail("Standard Navigation is not correct");
                }
            });

            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        string customStartDate = null;
        string customEndDate = null;
        //[TestCategory(TestType.NA_Regression, "TC04_ASCustomValidation")]
        //[TestCategory(TestType.NA_Sanity, "TC04_ASCustomValidation")]
        //[TestCategory(TestType.EU_Regression, "TC04_ASCustomValidation")]
        //[TestCategory(TestType.EU_Sanity, "TC04_ASCustomValidation")]
        [TestCategory(TestType.reports, "TC04_ASCustomValidation")]
        [Test, Description("Verifying Date selection through custom fields and its results in Alarm Summary Report")]
        public void TC04_ASCustomValidation()
        {
            Runner.DoStep("Select Date rang through custom fields in Alarm Summary Report", () =>
             {

                 Page.ReportsTabPage.Custom.Focus();
                 Thread.Sleep(1000);
                 Page.ReportsTabPage.Custom.Click();
                 Thread.Sleep(1000);
                 customStartDate = "03/27/2016";
                 customEndDate = "03/29/2016";
                 DateTime startDate = DateTime.ParseExact(customStartDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                 DateTime endDate = DateTime.ParseExact(customEndDate, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                 Page.ReportsTabPage.CustomStartDate.TypeText(customStartDate);
                 Page.ReportsTabPage.CustomEndDate.TypeText(customEndDate);
                 Page.ReportsTabPage.Apply.Click();
                 string dateRangelbl = null;
                 if (startDate.Year == endDate.Year)
                 {
                     dateRangelbl = startDate.ToString("dd MMM") + " - " + endDate.ToString("dd MMM yyyy");
                 }
                 else
                 {
                     dateRangelbl = startDate.ToString("dd MMM yyyy") + " - " + endDate.ToString("dd MMM yyyy");
                 }

                 if (Page.ReportsTabPage.WPADCustDateRangeLbl.BaseElement.InnerText != dateRangelbl)
                 {
                     flag = true;
                     errorBuilder.Append("\n Date Range is not matched with selected dates");
                     //Assert.Fail("Date Range is not matched with selected dates");
                 }
             });
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }


        //[TestCategory(TestType.NA_Regression, "TC05_ASFilter")]
        //[TestCategory(TestType.NA_Sanity, "TC05_ASFilter")]
        //[TestCategory(TestType.EU_Regression, "TC05_ASFilter")]
        //[TestCategory(TestType.EU_Sanity, "TC05_ASFilter")]
        [TestCategory(TestType.reports, "TC05_ASFilter")]
        [Test, Description("Verifying Filter in Alarm Summary Report")]
        public void TC05_ASFilter()
        {
            Runner.DoStep("Select Date rang through custom fields in Alarm Summary Report", () =>
              {

                  //Page.ReportsTabPage.ReportsTab.Click();
                  Thread.Sleep(1000);
                  Page.ReportsTabPage.Filter.Click();
                  Page.ReportsTabPage.AddMoreFilters.Click();
                  Page.ReportsTabPage.WPADAddFiltDisp.Click();

                  Page.ReportsTabPage.ApplyFilter.Click();
                  //if (Page.ReportsTabPage.ReportsGrid.GetColumnValues(1).Contains("Braun 675 lb"))
                  //{
                  //    Assert.Pass();
                  //}
              });


            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC06_ASVerifyHeaders")]
        //[TestCategory(TestType.NA_Sanity, "TC06_ASVerifyHeaders")]
        //[TestCategory(TestType.EU_Regression, "TC06_ASVerifyHeaders")]
        //[TestCategory(TestType.EU_Sanity, "TC06_ASVerifyHeaders")]
        [TestCategory(TestType.reports, "TC06_ASVerifyHeaders")]
        [Test, Description("Verifying grid headers in Alarm Summary Report")]
        public void TC06_ASVerifyHeaders()
        {
            Runner.DoStep("Verify Grid Headers in Alarm Summary Report", () =>
              {
                  List<string> headers = new List<string> { "Alarm Code", "Alarm Description", "Dispenser", "No. of Alarms" };
                  VerifyHeader(headers);
              });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC07_ASCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.NA_Sanity, "TC07_ASCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Regression, "TC07_ASCentralDefaultFiltersVerification")]
        //[TestCategory(TestType.EU_Sanity, "TC07_ASCentralDefaultFiltersVerification")]
        [TestCategory(TestType.reports, "TC07_ASCentralDefaultFiltersVerification")]
        [Test, Description("Verifying default filters in Alarm Summary Report")]
        public void TC07_ASCentralDefaultFiltersVerification()
        {
            Runner.DoStep("Verifying default filters in Alarm Summary Report", () =>
            {
                Page.ReportsTabPage.Filter.Click();
                List<string> AvailableFilters = new List<string> { "Machine Type", "Machine Group", "Machines", "Formula", "Alarm", "Dispenser" };
                bool isFilterMatch = Page.ReportsTabPage.CentralDefaultFiltersVerification(AvailableFilters);
                if (!isFilterMatch)
                {
                    flag = true;
                    errorBuilder.Append("\n Default Filters are not Correct in Production Summary Report");
                    //Assert.Fail("Default Filters are not Correct in Production Summary Report");
                }
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC08_ASAddToFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC08_ASAddToFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC08_ASAddToFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC08_ASAddToFavourite")]
        [TestCategory(TestType.reports, "TC08_ASAddToFavourite")]
        [Test, Description("Verifying Add to Favourite functionality in Alarm Summary Report")]
        public void TC08_ASAddToFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string reportName = "Alarm Summary AutoTest";
            Page.ReportsTabPage.AddToFavourites(reportName, result);
            Thread.Sleep(1000);
            Runner.DoStep("Verify Grid", () =>
            {
                VerifyGrid();
            });

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC09_ASDownloadReport")]
        //[TestCategory(TestType.NA_Sanity, "TC09_ASDownloadReport")]
        //[TestCategory(TestType.EU_Regression, "TC09_ASDownloadReport")]
        //[TestCategory(TestType.EU_Sanity, "TC09_ASDownloadReport")]
        [TestCategory(TestType.reports, "TC09_ASDownloadReport")]
        [Test, Description("Verifying Export to Excel, PDF functionality in Alarm Summary Report")]
        public void TC09_ASDownloadReport()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            Page.ReportsTabPage.WashingProcessValidationTab.DeskTopMouseClick();
            Page.ReportsTabPage.AlarmsSummaryLink.Click();

            Runner.DoStep("Click on Export to Excel icon in Alarms Summary Report", () =>
            {
                Page.ReportsTabPage.DownloadExcel.Click();
            });

            string partialName = "Alarms Summary";
            Thread.Sleep(1000);
            Page.ReportsTabPage.ExcelVerify(partialName, result);
            Runner.DoStep("Click on Export to PDF icon in Alarms Summary Report", () =>
            {
                Page.ReportsTabPage.DownloadPDF.Click();
            });
            Thread.Sleep(1000);

            Page.ReportsTabPage.PDFVerify(partialName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        //[TestCategory(TestType.NA_Regression, "TC10_ASRemoveFromFavourite")]
        //[TestCategory(TestType.NA_Sanity, "TC10_ASRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Regression, "TC10_ASRemoveFromFavourite")]
        //[TestCategory(TestType.EU_Sanity, "TC10_ASRemoveFromFavourite")]
        [TestCategory(TestType.reports, "TC10_ASRemoveFromFavourite")]
        [Test, Description("Verifying Remove from Favourite functionality in Alarm Summary Report")]
        public void TC10_ASRemoveFromFavourite()
        {
            var info = MethodBase.GetCurrentMethod();
            var result = string.Format(
                 "{0}.{1}.{2}",
                 info.ReflectedType.Namespace,
                 info.ReflectedType.Name,
                 info.Name);
            string ReportName = "Alarm Summary AutoTest";
            Page.ReportsTabPage.RemoveFromFavourite(ReportName, result);

            if (flag)
            {
                Assert.Fail(errorBuilder.ToString());
            }
        }

        private void getValues()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));
        }
        private void getValuesR12()
        {
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            startDay = valueOnUI.Substring(0, 2);
            startMonth = valueOnUI.Substring(3, 3);
            startYear = valueOnUI.Substring(7, 4);
            endDay = valueOnUI.Substring(14, 2);
            endMonth = valueOnUI.Substring(17, 3);
            endYear = valueOnUI.Substring(21, 4);

            // dayDiff = (Int32.Parse(startDay)) - (Int32.Parse(endDay));
        }

        //public void VerifyGrid()
        //{

        //    Thread.Sleep(1000);
        //    if (Page.ReportsTabPage.ReportsGridTable.Rows.Count > 1)
        //    {
        //        Assert.IsTrue(true);
        //    }
        //    else if (Page.ReportsTabPage.ReportsGridTable.Rows[0].BaseElement.InnerText.Contains("No Records To Display The Table"))
        //    {

        //        Assert.IsTrue(true, "No Data Displayed for selected dates");
        //    }
        //    else

        //        Assert.Fail("Error occured without data");
        //}



        private void validateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    flag = true;
                    errorBuilder.Append("\n Date Range is not correct");
                    //Assert.Fail("Date Range is not correct");
                }
            }
        }
    }
}
