﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest
{
    public class Reports : TestBase
    {
        List<KeyValuePair<string, int>> months = new List<KeyValuePair<string, int>>();
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {                        
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]); 
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(2000);            
            months.Add(new KeyValuePair<string, int>("Jan", 1));
            months.Add(new KeyValuePair<string, int>("Feb", 2));
            months.Add(new KeyValuePair<string, int>("Mar", 3));
            months.Add(new KeyValuePair<string, int>("Apr", 4));
            months.Add(new KeyValuePair<string, int>("May", 5));
            months.Add(new KeyValuePair<string, int>("Jun", 6));
            months.Add(new KeyValuePair<string, int>("Jul", 7));
            months.Add(new KeyValuePair<string, int>("Aug", 8));
            months.Add(new KeyValuePair<string, int>("Sep", 9));
            months.Add(new KeyValuePair<string, int>("Oct", 10));
            months.Add(new KeyValuePair<string, int>("Nov", 11));
            months.Add(new KeyValuePair<string, int>("Dec", 12));            
        }

        string valueOnUI, previousDay, previousMonth, currentDay, currentMonth, currentYear;        
        int dayDiff;        
        string day = DateTime.Today.ToString("D");
        string yesterday = DateTime.Today.AddDays(-1).ToString("D");

        [TestCategory(TestType.reports, "TC01_CurrentDaySearch")]       
        [Test]
        public void TC01_CurrentDaySearch()
        {                        
            Page.ReportsTabPage.CurrentView.Click();
            Page.ReportsTabPage.DayView.Click();
            getValues();
            validateToday();
            if (dayDiff != 0)
            {
                Assert.Fail("Date Range is not correct");
            }
            if (previousMonth != currentMonth)
            {
                Assert.Fail("Date Range is not correct");
            }          
        }

        [TestCategory(TestType.reports, "TC02_CurrentWeekSearch")]
        [Test]
        public void TC02_CurrentWeekSearch()
        {            
            Page.ReportsTabPage.WeekView.Click();
            getValues();
            validateToday();
            DateTime input = DateTime.Today;
            int sunday = DayOfWeek.Sunday - input.DayOfWeek;
            string sundayDate = input.AddDays(sunday).ToString("D");
            //Sunday, April 10, 2016
            string sundayDay = sundayDate.Substring(14, 2);
            string sundayMonth = sundayDate.Substring(8, 3);
            if ((sundayDay != previousDay) || (sundayMonth != previousMonth))
            {
                Assert.Fail("Date Range is not correct");
            }      
        }

        [TestCategory(TestType.reports, "TC03_CurrentMonthSearch")]
        [Test]
        public void TC03_CurrentMonthSearch()
        {            
            Page.ReportsTabPage.MonthView.Click();
            getValues();
            validateToday();
            if (Int32.Parse(previousDay) != 01)
            {
                Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                Assert.Fail("Date Range is not correct");
            }            
        }

        [TestCategory(TestType.reports, "TC04_CurrentQuarterSearch")]
        [Test]
        public void TC04_CurrentQuarterSearch()
        {            
            Page.ReportsTabPage.QuarterView.Click();
            getValues();
            validateToday();
            if ((Int32.Parse(previousDay) != 01))
            {
                Assert.Fail("Date Range is not correct");
            }
            int quarterNumber = (DateTime.Today.Month - 1) / 3 + 1;
            string firstDayOfQuarter = new DateTime(DateTime.Today.Year, (quarterNumber - 1) * 3 + 1, 1).ToString("D");
            //Friday, April 01, 2016
            string firstMonthInQuarter = firstDayOfQuarter.Substring(8, 3);
            if (firstMonthInQuarter != previousMonth)
            {
                Assert.Fail("Date Range is not correct");
            }           
        }

        [TestCategory(TestType.reports, "TC05_CurrentYearSearch")]
        [Test]
        public void TC05_CurrentYearSearch()
        {            
            Page.ReportsTabPage.YearView.Click();
            getValues();
            validateToday();
            if ((previousDay != "01") || (previousMonth != "Jan"))
            {
                Assert.Fail("Date Range is not correct");
            }  
        }

        [TestCategory(TestType.reports, "TC06_PreviousDaySearch")]
        [Test]
        public void TC06_PreviousDaySearch()
        {
            Page.ReportsTabPage.PreviousView.Click();
            Page.ReportsTabPage.DayView.Click();
            getValues();
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!yesterday.Contains(item))
                {
                    Assert.Fail("Date Range is not correct");
                }
            }
            if (dayDiff != 0)
            {
                Assert.Fail("Date Range is not correct");
            }
            if ((previousMonth != currentMonth) || (previousDay != currentDay))
            {
                Assert.Fail("Date Range is not correct");
            }                       
        }

        [TestCategory(TestType.reports, "TC07_PreviousWeekSearch")]
        [Test]
        public void TC07_PreviousWeekSearch()
        {            
            Page.ReportsTabPage.WeekView.Click();
            getValues();
            string firstDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 7).ToString("D");
            string lastDayOfWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 1).ToString("D");
            string oldDay = firstDayOfWeek.Substring(14, 2);
            string oldMonth = firstDayOfWeek.Substring(8, 3);
            string newDay = lastDayOfWeek.Substring(16, 2);
            string newMonth = lastDayOfWeek.Substring(10, 3);
            string newYear = lastDayOfWeek.Substring(20, 4);

            if ((oldDay != previousDay) || (oldMonth != previousMonth) || (newDay != currentDay) || (newMonth != currentMonth) || (newYear != currentYear))
            {
                Assert.Fail("Date Range is not correct");
            }              
        }

        [TestCategory(TestType.reports, "TC08_PreviousMonthSearch")]
        [Test]
        public void TC08_PreviousMonthSearch()
        {            
            Page.ReportsTabPage.MonthView.Click();
            getValues();
            var today = DateTime.Today;
            var month = new DateTime(today.Year, today.Month, 1);
            string last = month.AddDays(-1).ToString("D");
            string lastDate = last.Substring(16, 2);
            string lastMonth = last.Substring(10, 3);
            string lastYear = last.Substring(20, 4);
            if (Int32.Parse(previousDay) != 01)
            {
                Assert.Fail("Date Range is not correct");
            }
            if (currentMonth != previousMonth)
            {
                Assert.Fail("Date Range is not correct");
            }
            if ((lastDate != currentDay) || (lastMonth != currentMonth) || (lastYear != currentYear))
            {
                Assert.Fail("Date Range is not correct");
            }          
        }

        [TestCategory(TestType.reports, "TC09_PreviousQuarterSearch")]
        [Test]
        public void TC09_PreviousQuarterSearch()
        {            
            Page.ReportsTabPage.QuarterView.Click();
            getValues();

            if ((Int32.Parse(previousDay) != 01))
            {
                Assert.Fail("Date Range is not correct");
            }
            int month1 = 0;
            int month2 = 0;
            foreach (var pair in months)
            {
                if (pair.Key == previousMonth)
                {
                    month1 = pair.Value;
                }
                if (pair.Key == currentMonth)
                {
                    month2 = pair.Value;
                    break;
                }
            }
            int num = month2 - month1;
            if (num != 2)
            {
                Assert.Fail("Date Range is not correct");
            }

            List<KeyValuePair<string, int>> monthsList = new List<KeyValuePair<string, int>>();
            monthsList.Add(new KeyValuePair<string, int>("Jan", 1));
            monthsList.Add(new KeyValuePair<string, int>("Feb", 1));
            monthsList.Add(new KeyValuePair<string, int>("Mar", 1));
            monthsList.Add(new KeyValuePair<string, int>("Apr", 2));
            monthsList.Add(new KeyValuePair<string, int>("May", 2));
            monthsList.Add(new KeyValuePair<string, int>("Jun", 2));
            monthsList.Add(new KeyValuePair<string, int>("Jul", 3));
            monthsList.Add(new KeyValuePair<string, int>("Aug", 3));
            monthsList.Add(new KeyValuePair<string, int>("Sep", 3));
            monthsList.Add(new KeyValuePair<string, int>("Oct", 4));
            monthsList.Add(new KeyValuePair<string, int>("Nov", 4));
            monthsList.Add(new KeyValuePair<string, int>("Dec", 4));

            string previousQuartersYear = DateTime.Today.AddMonths(-3).ToString();
            string presentMonth = DateTime.Now.ToString("MMM");
            int currentQuarterIndex = 0;
            int previousQuartersIndex = 0;
            string monthInQuarter1 = null;
            string monthInQuarter2 = null;
            int i = 0;

            foreach (var pair in monthsList)
            {
                if (pair.Key == presentMonth)
                {
                    currentQuarterIndex = pair.Value;
                    break;
                }
            }
            if (currentQuarterIndex == 1)
            {
                previousQuartersIndex = currentQuarterIndex + 3;
            }
            else
            {
                previousQuartersIndex = currentQuarterIndex - 1;
            }

            foreach (var pair in monthsList)
            {
                if (pair.Value == previousQuartersIndex)
                {
                    if (i == 0)
                    {
                        monthInQuarter1 = pair.Key;
                    }
                    if (i == 2)
                    {
                        monthInQuarter2 = pair.Key;
                        break;
                    }
                    i++;
                }
            }

            if ((monthInQuarter1 != previousMonth) || (monthInQuarter2 != currentMonth))
            {
                Assert.Fail("Date Range is not correct");
            }
            if ((previousQuartersIndex == 1) || (previousQuartersIndex == 4))
            {
                if (currentDay != "31")
                {
                    Assert.Fail("Date Range is not correct");
                }
            }
            else
            {
                if (currentDay != "30")
                {
                    Assert.Fail("Date Range is not correct");
                }
            }
            if (!previousQuartersYear.Contains(currentYear))
            {
                Assert.Fail("Date Range is not correct");
            }         
        }

        [TestCategory(TestType.reports, "TC10_PreviousYearSearch")]
        [Test]
        public void TC10_PreviousYearSearch()
        {            
            Page.ReportsTabPage.YearView.Click();
            getValues();
            string lastYear = DateTime.Now.AddYears(-1).Year.ToString();
            if ((previousDay != "01") || (previousMonth != "Jan") || (currentDay != "31") || (currentMonth != "Dec") || (currentYear != lastYear))
            {
                Assert.Fail("Date Range is not correct");
            }    
        }        

        //[TestCategory(TestType.reports, "TC11_CalenderTest")]
        [Test]
        public void TC11_CalenderTest()
        {
            Page.ReportsTabPage.Custom.Focus();
            Thread.Sleep(1000);
            Page.ReportsTabPage.Custom.Click();
            Thread.Sleep(3000);
            Page.ReportsTabPage.DayDateGrid.SelectButton.Click();
            Page.ReportsTabPage.MonthDateGrid.SelectButton.Click();
            Page.ReportsTabPage.YearDateGrid.Selectyear("2010");
            Page.ReportsTabPage.MonthDateGrid.SelectMonth("Aug");
            Page.ReportsTabPage.DayDateGrid.SelectDay("9");

            Thread.Sleep(15000);
        }

        //[TestCategory(TestType.reports, "TC12_AddColumns")]
        [Test]
        public void TC12_AddColumns()
        {
            //Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            //Thread.Sleep(1000);
            //string b = Page.ReportsTabPage.HeadersGrid.ChildNodes[0].Attributes[5].Value;
            //int columnCount1 = Page.ReportsTabPage.HeadersGrid.ChildNodes.Count;
            //int headers1 = 0;
            //for (int i = 0; i < columnCount1; i++)
            //{
            //    if (Page.ReportsTabPage.HeadersGrid.ChildNodes[i].Attributes[5].Value == "True")
            //    {
            //        headers1++;
            //    }
            //}
            //Page.ReportsTabPage.AddColumn.Click();
            //Page.ReportsTabPage.ActEnergyCostCwt.Click();
            //Thread.Sleep(1000);
            //Telerik.ActiveBrowser.RefreshDomTree();
            //int columnCount2 = Page.ReportsTabPage.HeadersGrid.ChildNodes.Count();
            //int headers2 = 0;
            //for (int i = 0; i < columnCount2; i++)
            //{
            //    if (Page.ReportsTabPage.HeadersGrid.ChildNodes[i].Attributes[5].Value == "True")
            //    {
            //        headers2++;
            //    }
            //}
            //List<string> headers = new List<string>();
            //for (int i = 0; i < headers2; i++)
            //{
            //    headers.Add(Page.ReportsTabPage.HeadersGrid.ChildNodes[i].ChildNodes[0].InnerText);
            //}
            //if (headers1 == headers2)
            //{
            //    Assert.Fail("Column not added succesfully");
            //}
            //if (!headers.Contains("Actual Energy cost ($/Cwt)"))
            //{
            //    Assert.Fail("Column not added succesfully");
            //}  
            
            Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
            Page.ReportsTabPage.AddColumn.Click();
            Page.ReportsTabPage.ActEnergyCostCwt.Click();
            Page.ReportsTabPage.ActualWaterUsage.Click();
            Page.ReportsTabPage.EnergyTargetCWT.Click();
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Actual Energy cost").Count == 0)
            {
                Assert.Fail("Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Actual Water usage").Count == 0)
            {
                Assert.Fail("Column Not Added");
            }
            if (Page.ReportsTabPage.ReportsGrid.SelectedRows("Energy Target").Count == 0)
            {
                Assert.Fail("Column Not Added");
            }
            Thread.Sleep(2000);           
        }
        
        private void getValues()
        {                        
            valueOnUI = Page.ReportsTabPage.DateRange.BaseElement.InnerText;

            previousDay = valueOnUI.Substring(0, 2);
            previousMonth = valueOnUI.Substring(3, 3);
            currentDay = valueOnUI.Substring(9, 2);
            currentMonth = valueOnUI.Substring(12, 3);
            currentYear = valueOnUI.Substring(16, 4);

            dayDiff = (Int32.Parse(currentDay)) - (Int32.Parse(previousDay));            
        }
                
        private void validateToday()
        {
            List<string> list = new List<string>();
            list.Add(currentDay);
            list.Add(currentMonth);
            list.Add(currentYear);
            foreach (string item in list)
            {
                if (!day.Contains(item))
                {
                    Assert.Fail("Date Range is not correct");
                }
            }
        }

        string customStartDate = null;
        string customEndDate = null;

        //[TestCategory(TestType.functional, "TC01_PSCustom_DayValidation")]
        //[TestCategory(TestType.regression, "TC01_PSCustom_DayValidation")]
        [TestCategory(TestType.reports, "TC13_PSCustom_DayValidation")]
        [Test]
        public void TC13_PSCustom_DayValidation()
        {

            Page.ReportsTabPage.Custom.Focus();
            Thread.Sleep(1000);
            Page.ReportsTabPage.Custom.Click();
            Thread.Sleep(1000);
            customStartDate = "03/27/2016";
            customEndDate = "03/29/2016";
            DateTime startDate = DateTime.ParseExact(customStartDate, "MM/dd/yyyy", null);
            DateTime endDate = DateTime.ParseExact(customEndDate, "MM/dd/yyyy", null);
            StartDateSelection(startDate);
            Thread.Sleep(1000);
            EndDateSelection(endDate);
            Thread.Sleep(1000);
            GroupBySelection(startDate, endDate);
            Page.ReportsTabPage.Apply.Click();
            string dateRangelbl = null;
            //if (startDate.ToString("yyyy") == endDate.ToString("yyyy"))
            //    dateRangelbl = startDate.ToString("dd MMM") + " - " + endDate.ToString("dd MMM yyyy");
            //else
                dateRangelbl = startDate.ToString("dd MMM yyyy") + " - " + endDate.ToString("dd MMM yyyy");            
            if (Page.ReportsTabPage.DateRangelabel.BaseElement.InnerText != dateRangelbl)
            {
                Assert.Fail("Date Range is not matched with selected dates");
            }
            Thread.Sleep(1000); 
            if (Page.ReportsTabPage.ReportsGridTable.Rows.Count > 0)
            {
                Assert.IsTrue(true);
            }
            else if (Page.ReportsTabPage.RecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.IsTrue(true, "No Data Displayed for selected dates");
            }                                    
            else
            Assert.Fail("Error occured without data");
        }



        //[TestCategory(TestType.functional, "TC02_PSCustom_WeekValidation")]
        //[TestCategory(TestType.regression, "TC02_PSCustom_WeekValidation")]
        [TestCategory(TestType.reports, "TC14_PSCustom_WeekValidation")]
        [Test]
        public void TC14_PSCustom_WeekValidation()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(2000);    
            Page.ReportsTabPage.Custom.Focus();
            Thread.Sleep(1000);
            Page.ReportsTabPage.Custom.Click();
            Thread.Sleep(1000);
            customStartDate = "03/17/2016";
            customEndDate = "03/29/2016";
            DateTime startDate = DateTime.ParseExact(customStartDate, "MM/dd/yyyy", null);
            DateTime endDate = DateTime.ParseExact(customEndDate, "MM/dd/yyyy", null);
            StartDateSelection(startDate);
            Thread.Sleep(1000);
            EndDateSelection(endDate);
            Thread.Sleep(1000);
            GroupBySelection(startDate, endDate);
            Page.ReportsTabPage.Apply.Click();
            string dateRangelbl = null;
            //if (startDate.ToString("yyyy") == endDate.ToString("yyyy"))
            //    dateRangelbl = startDate.ToString("dd MMM") + " - " + endDate.ToString("dd MMM yyyy");
            //else
                dateRangelbl = startDate.ToString("dd MMM yyyy") + " - " + endDate.ToString("dd MMM yyyy");

            if (Page.ReportsTabPage.DateRangelabel.BaseElement.InnerText != dateRangelbl)
            {
                Assert.Fail("Date Range is not matched with selected dates");
            }
            Thread.Sleep(1000);
            if (Page.ReportsTabPage.ReportsGridTable.Rows.Count > 0)
            {
                Assert.IsTrue(true);
            }
            else if (Page.ReportsTabPage.RecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.IsTrue(true, "No Data Displayed for selected dates");
            }            
            else
                Assert.Fail("Error occured without data");

        }

        //[TestCategory(TestType.functional, "TC03_PSCustom_MonthValidation")]
        //[TestCategory(TestType.regression, "TC03_PSCustom_MonthValidation")]
        [TestCategory(TestType.reports, "TC15_PSCustom_MonthValidation")]
        [Test]
        public void TC15_PSCustom_MonthValidation()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(2000);    
            Page.ReportsTabPage.Custom.Focus();
            Thread.Sleep(1000);
            Page.ReportsTabPage.Custom.Click();
            Thread.Sleep(1000);
            customStartDate = "02/17/2016";
            customEndDate = "03/29/2016";
            DateTime startDate = DateTime.ParseExact(customStartDate, "MM/dd/yyyy", null);
            DateTime endDate = DateTime.ParseExact(customEndDate, "MM/dd/yyyy", null);
            StartDateSelection(startDate);
            Thread.Sleep(1000);
            EndDateSelection(endDate);
            Thread.Sleep(1000);
            GroupBySelection(startDate, endDate);
            Page.ReportsTabPage.Apply.Click();
            string dateRangelbl = null;
            //if (startDate.ToString("yyyy") == endDate.ToString("yyyy"))
            //    dateRangelbl = startDate.ToString("dd MMM") + " - " + endDate.ToString("dd MMM yyyy");
            //else
                dateRangelbl = startDate.ToString("dd MMM yyyy") + " - " + endDate.ToString("dd MMM yyyy");
            if (Page.ReportsTabPage.DateRangelabel.BaseElement.InnerText != dateRangelbl)
            {
                Assert.Fail("Date Range is not matched with selected dates");
            }
            Thread.Sleep(1000);
            if (Page.ReportsTabPage.ReportsGridTable.Rows.Count > 0)
            {
                Assert.IsTrue(true);
            }
            else if (Page.ReportsTabPage.RecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.IsTrue(true, "No Data Displayed for selected dates");
            }           
            else
                Assert.Fail("Error occured without data");
        }

        public void StartDateSelection(DateTime startDate)
        {
            Page.ReportsTabPage.StartDateTimePickr.Click();
            //DateTime startDate = DateTime.ParseExact(sDate, "MM/dd/yyyy", null);        
            Page.ReportsTabPage.CustomStartDateDay.SelectButton.Click();
            Page.ReportsTabPage.CustomStartDateMonth.SelectButton.Click();
            Page.ReportsTabPage.CustomStartDateYear.Selectyear(startDate.ToString("yyyy"));
            Page.ReportsTabPage.CustomStartDateMonth.SelectMonth(startDate.ToString("MMM"));
            Page.ReportsTabPage.CustomStartDateDay.SelectDay(startDate.ToString("dd"));
            Thread.Sleep(1000);
        }

        public void EndDateSelection(DateTime startDate)
        {
            Page.ReportsTabPage.EndDateTimePickr.Click();
            //DateTime startDate = DateTime.ParseExact(eDate, "MM/dd/yyyy", null);
            Page.ReportsTabPage.CustomEndDateDay.SelectButton.Click();
            Page.ReportsTabPage.CustomEndDateMonth.SelectButton.Click();
            Page.ReportsTabPage.CustomEndDateYear.Selectyear(startDate.ToString("yyyy"));
            Page.ReportsTabPage.CustomEndDateMonth.SelectMonth(startDate.ToString("MMM"));
            Page.ReportsTabPage.CustomEndDateDay.SelectDay(startDate.ToString("dd"));
            Thread.Sleep(1000);
        }

        //[TestCategory(TestType.functional, "TC04_PSCustom_QuarterValidation")]
        //[TestCategory(TestType.regression, "TC04_PSCustom_QuarterValidation")]
        [TestCategory(TestType.reports, "TC16_PSCustom_QuarterValidation")]
        [Test]
        public void TC16_PSCustom_QuarterValidation()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(2000);    
            Page.ReportsTabPage.Custom.Focus();
            Thread.Sleep(1000);
            Page.ReportsTabPage.Custom.Click();
            Thread.Sleep(1000);
            customStartDate = "03/17/2015";
            customEndDate = "03/29/2016";
            DateTime startDate = DateTime.ParseExact(customStartDate, "MM/dd/yyyy", null);
            DateTime endDate = DateTime.ParseExact(customEndDate, "MM/dd/yyyy", null);
            StartDateSelection(startDate);
            Thread.Sleep(1000);
            EndDateSelection(endDate);
            Thread.Sleep(1000);
            GroupBySelection(startDate, endDate);
            Page.ReportsTabPage.Apply.Click();
            string dateRangelbl = null;
            //if (startDate.ToString("yyyy") == endDate.ToString("yyyy"))
            //    dateRangelbl = startDate.ToString("dd MMM") + " - " + endDate.ToString("dd MMM yyyy");
            //else
                dateRangelbl = startDate.ToString("dd MMM yyyy") + " - " + endDate.ToString("dd MMM yyyy");

            if (Page.ReportsTabPage.DateRangelabel.BaseElement.InnerText != dateRangelbl)
            {
                Assert.Fail("Date Range is not matched with selected dates");
            }
            Thread.Sleep(1000);
            if (Page.ReportsTabPage.ReportsGridTable.Rows.Count > 0)
            {
                Assert.IsTrue(true);
            }
            else if (Page.ReportsTabPage.RecordsErrorMessage.BaseElement.InnerText.Contains("No Records to display"))
            {
                Assert.IsTrue(true, "No Data Displayed for selected dates");
            }            
            else
                Assert.Fail("Error occured without data");

        }

        //[TestCategory(TestType.functional, "TC05_PSViewCategory_TimeValidation")]
        //[TestCategory(TestType.regression, "TC05_PSViewCategory_TimeValidation")]
        [TestCategory(TestType.reports, "TC17_PSViewCategory_TimeValidation")]
        [Test]
        public void TC17_PSViewCategory_TimeValidation()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(2000);    
            Page.ReportsTabPage.ViewCategory.Click();
            Page.ReportsTabPage.TimeCategory.Click();
            string ws = Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText;

            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("IntervalNo. of LoadsStandard Production (lbs)Actual Production (lbs)Actual Production (lbs/hr)Standard Production (lbs/hr)"))
            {
                Assert.Fail("Header column is not matched with selected Time Category ");
            }
        }

        //[TestCategory(TestType.functional, "TC06_PSViewCategory_LocationValidation")]
        //[TestCategory(TestType.regression, "TC06_PSViewCategory_LocationValidation")]
        [TestCategory(TestType.reports, "TC18_PSViewCategory_LocationValidation")]
        [Test]
        public void TC18_PSViewCategory_LocationValidation()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(1000);              
            Page.ReportsTabPage.ViewCategory.Click();
            Page.ReportsTabPage.LocationCategory.Click();

            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("MachineGroupNo. of LoadsStandard Production (lbs)Actual Production (lbs)Actual Production (lbs/hr)Standard Production (lbs/hr)"))
            {
                Assert.Fail("Header column is not matched with selected Location Category ");
            }
        }

        [TestCategory(TestType.reports, "TC19_FilterProduction")]
        [Test]
        public void TC19_FilterProduction()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(1000);    
            Page.ReportsTabPage.Filter.Click();
            Page.ReportsTabPage.ProdSummaryMachGroup.Click();
            Page.ReportsTabPage.MachineGrpSelectAll.Click();
            Page.ReportsTabPage.Braun675lb.Click();
            Page.ReportsTabPage.ApplyFilter.Click();
            if (Page.ReportsTabPage.ReportsGrid.GetColumnValues(1).Contains("Braun 675 lb"))
            {
                Assert.Pass();
            }
        }

        [TestCategory(TestType.reports, "TC20_StandardCustomNavigate")]
        [Test]
        public void TC20_StandardCustomNavigate()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(1000);
            Page.ReportsTabPage.ReportsNext.Click();
            Page.ReportsTabPage.ReportsPrev.Click();                     
        }        

        public void GroupBySelection(DateTime startDate, DateTime endDate)
        {

            //TimeSpan ts = (DateTime.ParseExact(customEndDate, "MM/dd/yyyy", null) - DateTime.ParseExact(customStartDate, "MM/dd/yyyy", null));
            TimeSpan dateDiff = endDate - startDate;

            if ((dateDiff.TotalDays <= 7 && dateDiff.TotalDays >= 0))
            {
                if (Page.ReportsTabPage.GroupBy.SelectedOption.Text != "Day")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }
            }
            else if ((dateDiff.TotalDays <= 30 && dateDiff.TotalDays >= 8))
            {
                if (Page.ReportsTabPage.GroupBy.SelectedOption.Text != "Week")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }
            }
            else if ((dateDiff.TotalDays <= 90 && dateDiff.TotalDays >= 31))
            {
                if (Page.ReportsTabPage.GroupBy.SelectedOption.Text != "Month")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }
            }
            //else if (ts.TotalDays <= 365 && ts.TotalDays >= 91)
            else if (dateDiff.TotalDays >= 91)
            {
                if (Page.ReportsTabPage.GroupBy.SelectedOption.Text != "Quarter")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }

            }
            //else if (ts.TotalDays > 365)
            //{
            //  if (Page.ReportsTabPage.GroupBy.SelectedOption.Text != "Year")
            //{
            //    Assert.Fail("Wrong Selection in Group By ");
            //}
            //}

        }

        [TestCategory(TestType.reports, "TC21_PDViewCategory_TimeValidation")]
        [Test]
        public void TC21_PDViewCategory_TimeValidation()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ProductionEfficiencyTab.Focus();
            Thread.Sleep(2000);
            Page.ReportsTabPage.ProductionEfficiencyTab.MouseHover();
            Thread.Sleep(4000);
            Page.ReportsTabPage.ProductionDetailsLink.Click();
            Thread.Sleep(3000);
            Page.ReportsTabPage.ViewCategory.Click();
            Page.ReportsTabPage.TimeCategory.Click();
            string ws = Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText;

            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("IntervalNo. of LoadsActual Production (lbs)Standard Production (lbs)Load Efficiency (%)Production Mix (%)Actual Production (lbs/hr)"))
            {
                Assert.Fail("Header column is not matched with selected Time Category ");
            }
        }

        [TestCategory(TestType.reports, "TC22_PDViewCategory_LocationValidation")]
        [Test]
        public void TC22_PDViewCategory_LocationValidation()
        {            
            Thread.Sleep(1000);
            Page.ReportsTabPage.ViewCategory.Click();
            Page.ReportsTabPage.LocationCategory.Click();

            if (!Page.ReportsTabPage.CategoryHeader.BaseElement.InnerText.Contains("LocationNo. of LoadsActual Production (lbs)Standard Production (lbs)Load Efficiency (%)Production Mix (%)Actual Production (lbs/hr)"))
            {
                Assert.Fail("Header column is not matched with selected Location Category ");
            }
        }
    }
}
