﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ecolab.FunctionalTest
{
    public class PlantSetupTargetProductionTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.LoginPage.TopMainMenu.NavigateToTargetProductionPage();
        }
        
        [TestCategory(TestType.regression, "TC01_SaveFunctionality")]
        [Test, Description("Verify Save button functionality in Target Production page")]
        public void TC01_SaveFunctionality()
        {
            Runner.DoStep("Navigate to Shifts tab in Plant Setup page", () =>
            {
                Page.ShiftTabPage.ShiftTab.Click();
            });
            Thread.Sleep(2000);
            Page.ShiftTabPage.DeleteAllShifts();
            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText("Target Production Shift");
            Page.ShiftTabPage.TargetProductionTextBox.TypeText("1234");
            Page.ShiftTabPage.ShiftFromTime.TypeText("10:00");
            Page.ShiftTabPage.ShiftToTime.TypeText("13:00");
            Thread.Sleep(5000);
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.DeskTopMouseClick();
            });

            Thread.Sleep(5000);
            Runner.DoStep("Verify the creation of the Shift", () =>
            {
                if (null != Page.ShiftTabPage.ShiftAddMessage)
                {
                    string message = Page.ShiftTabPage.ShiftAddMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Shift created successfully"))
                    {
                        Assert.Fail("Incorrect message is displayed while adding shift , Expected: Shift created successfully ,Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Shift added message is not displayed");
                }
            });

            Page.LoginPage.TopMainMenu.NavigateToTargetProductionPage();
            Thread.Sleep(2000);
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.Focus();
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.TypeText("");
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.DeskTopMouseClick();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D3);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D4);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D5);
            Page.PlantSetupTargetProductionPage.Save.DeskTopMouseClick();
            if (Page.PlantSetupTargetProductionPage.Message.IsVisible())
            {
                if (!Page.PlantSetupTargetProductionPage.Message.BaseElement.InnerText.Contains("Successfully"))
                {
                    Assert.Fail("Correct success message not displayed");
                }               
            }
            else
            {
                Assert.Fail("Success message not displayed");
            }
        }

        [TestCategory(TestType.regression, "TC02_CancelFunctionality")]
        [Test, Description("Verify Cancel button functionality in Target Production page")]
        public void TC02_CancelFunctionality()
        {
            Page.ShiftTabPage.ShiftTab.Click();
            Thread.Sleep(1000);
            Page.LoginPage.TopMainMenu.NavigateToTargetProductionPage();
            Thread.Sleep(2000);
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.Focus();
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.TypeText("");
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.DeskTopMouseClick();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D3);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D1);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D5);
            Page.PlantSetupTargetProductionPage.Cancel.DeskTopMouseClick();
            DialogHandler.NoButton.Click();
            Page.LoginPage.TopMainMenu.NavigateToTargetProductionPage();
            Thread.Sleep(2000);
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.Focus();
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.TypeText("");
            Page.PlantSetupTargetProductionPage.TargetProductionToEdit.DeskTopMouseClick();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D6);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D7);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.D5);
            Page.PlantSetupTargetProductionPage.Cancel.DeskTopMouseClick();
            DialogHandler.YesButton.Click();
            if (Page.PlantSetupTargetProductionPage.Message.IsVisible())
            {
                if (!Page.PlantSetupTargetProductionPage.Message.BaseElement.InnerText.Contains("Successfully"))
                {
                    Assert.Fail("Correct success message not displayed");
                }
            }
            else
            {
                Assert.Fail("Success message not displayed");
            }
        }
    }
}
