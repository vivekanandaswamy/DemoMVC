﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Data;
using System.Collections.ObjectModel;

using NUnit.Framework;
using Ecolab.Pages.CommonControls;
using ArtOfTest.WebAii.Controls.HtmlControls;
using Telerik.TestingFramework.Controls.KendoUI;
using System.Collections.Generic;

namespace Ecolab.FunctionalTest
{
    public class DispenserPage : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");            
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            //Page.PlantSetupPage.TopMainMenu.NavigateToControlerSetupPage();
            //Page.ControllerSetupPage.DeleteAllControllers();
            //Precondition();           
        }

        private void Precondition()
        {
            Page.ControllerSetupPage.AddControllerButton.Click();
            Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("Ultrax 6/12/16", Timeout);
            Page.ControllerGeneralSetupTabPage.ControllerType.SelectByText("Beckhoff", Timeout);

            Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.DeskTopMouseClick();
            KeyBoardSimulator.SetNumeric("1");
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
            KeyBoardSimulator.SetNumeric("10.225.134.21.1");
            //Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.TypeText("10.225.134.21.1");
            Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.DeskTopMouseClick();

            //Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Page.ControllerSetupPage.Save.DeskTopMouseClick();
        }

        Random random = new Random();

        /// <summary>
        /// Test case 25060: RG: Controller(s) Setup -> List Page : Validate audit of Modified fields
        /// Test case 24683: RG: Verify Add Controller Functionality -Ultrax Beckhoff Model
        /// </summary>
        [TestCategory(TestType.functional, "TC01_VerifyAddEditBeckhoffController")]
        [TestCategory(TestType.regression, "TC01_VerifyAddEditBeckhoffController")]
        [Test(Description = "Test case 25060: RG: Controller(s) Setup -> List Page : Validate audit of Modified fields")]
        public void TC01_VerifyAddEditBeckhoffController()
        {
            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            AddBeckhoffController(random.Next(0, 100000).ToString(), true, "UX16 Beck 1");
            //VerifyAdvanceEditBeckhoff();
        }

        /// <summary>
        /// Test case 24716: RG: Verify Add Controller Functionality -Ultrax AB Model
        /// </summary>
        [TestCategory(TestType.functional, "TC02_VerifyAddEditABController")]
        [TestCategory(TestType.regression, "TC02_VerifyAddEditABController")]
        [Test]
        public void TC02_VerifyAddEditABController()
        {            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            AddAndVerifyABController(random.Next(0, 100000).ToString());
            //VerifyAdvanceEditAllenBradely();
        }

        /// <summary>
        /// Test case 24706: RG: Controller(s)\Edit Page->Verify Add Controller Functionality -MyControl Model
        /// </summary>
        [TestCategory(TestType.functional, "TC03_VerifyAddmyController")]
        [TestCategory(TestType.regression, "TC03_VerifyAddmyController")]
        [Test]
        public void TC03_VerifyAddmyController()
        {
            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            AddAndVerifymyControl(random.Next(0, 100000).ToString(), true);
        }

        /// <summary>
        /// Test case 24756: RG: Verify Controller Model-Europe region
        /// </summary>
        [TestCategory(TestType.functional, "TC04_VerifyControllerList")]
        //[TestCategory(TestType.regression, "TC04_VerifyControllerList")]
        [Test]
        public void TC04_VerifyControllerList()
        {
            try
            {
                Runner.DoStep("Verify Dispensers'list for the region 1", () =>
                {
                    DBValidation.UpdateData("update tcd.Plant set RegionId = 1");
                    //Page.LoginPage.TopMainMenu.LogOut();
                    LoginWithUser(Users.AdminUser[0], Users.AdminUser[1]);

                    List<string> controllerListEU = new List<string>() { "Ultrax 6/12/16", "Ultrax 2000", "Elados Smart", "Softroll", "Utilitty logger", "Tank-controller"
                                                                ,"myControl","E-Control Plus","E-Control","Ecodose","PLC XL","Solumix","Ultrax TDi"};
                    VerifyControllerList(controllerListEU, "Europe");
                });
                Runner.DoStep("Verify Dispensers'list for the region 2", () =>
                {
                    DBValidation.UpdateData("update tcd.Plant set RegionId = 2");
                    //Page.LoginPage.TopMainMenu.LogOut();
                    LoginWithUser(Users.AdminUser[0], Users.AdminUser[1]);
                    List<string> controllerListNA = new List<string>() { "myControl", "E-Control Plus", "E-Control", "Ecodose", "PLC XL", "Utilitty logger", "Tank-controller"
                                                                , "Solumix","Ultrax 6/12/16","Ultrax 2000","Elados Smart","Softroll" };
                    VerifyControllerList(controllerListNA, "North America");
                });                                
            }
            finally
            {
                Runner.DoStep("Set Region ID to 1", () =>
                {
                    DBValidation.UpdateData("update tcd.Plant set RegionId = 1");
                    LoginWithUser(Users.AdminUser[0], Users.AdminUser[1]);
                });               
            }
        }

        /// <summary>
        /// Test case 27083: RG: Controller(s) Setup -> List Page : Verify Delete Controller Functionality
        /// </summary>
        [TestCategory(TestType.functional, "TC05_VerifyDelete")]
        [TestCategory(TestType.regression, "TC05_VerifyDelete")]
        [Test]
        public void TC05_VerifyDelete()
        {
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            int intitialNumberOfRows = Page.ControllerSetupPage.ControllersTabGrid.Rows.Count;
            DataRowCollection initialDatarows = DBValidation.DataRows("select IsDeleted from tcd.ConduitController where IsDeleted='False'");

            DialogHandler.ClickonOKButton();
            Runner.DoStep("Select the first record from dispensers' table and click on delete button", () =>
            {
                Page.ControllerSetupPage.ControllersTabGrid.Rows.FirstOrDefault().GetButtonControls()[1].Click();
            });
            Runner.DoStep("Confirm deletion by clicking 'Yes'", () =>
            {
                DialogHandler.FormulaYesButton.Click();
            });
            Runner.DoStep("Verify deletion using deletion status message", () =>
            {
                Thread.Sleep(3000);
                if (null != Page.ControllerSetupPage.ControllerListMessage)
                {
                    string message = Page.ControllerSetupPage.ControllerListMessage.BaseElement.InnerText;
                    if (!message.Contains("Successfully"))
                    {
                        Assert.Fail("Controller delete message is incorrect Expected: Controller Deleted Successfully , Actual: {0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Controller delete message is not displayed");
                }

                DataRowCollection finalDatarows = DBValidation.DataRows("select IsDeleted from tcd.ConduitController where IsDeleted='False'");
                if (finalDatarows.Count == initialDatarows.Count)
                {
                    Assert.Fail("DB is not updated after controller is deleted");
                }
            });            
        }

        /// <summary>
        /// Test case 40135: RG: Controller(s) Setup -> List Page : Verify Cancel Button Functionality-Inline Edit Button
        /// Test case 40173: RG: Verify Cancel button Functionality-Inline
        /// Test case 25607: RG: Verify Edit Controller Functionality
        /// Test case 41252: RG: Controller(s) Setup -> List Page : Verify edit Button Functionality
        /// Test case 25607: RG: Verify Edit Controller Functionality
        /// </summary>
        [TestCategory(TestType.functional, "TC06_VerifyCancelAndSaveUpdate")]
        [TestCategory(TestType.regression, "TC06_VerifyCancelAndSaveUpdate")]
        [Test]
        public void TC06_VerifyCancelAndSaveUpdate()
        {
            //Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            //string intitilRowData = Page.ControllerSetupPage.ControllersTabGrid.Rows.FirstOrDefault().InnerText;
            //Page.ControllerSetupPage.ControllersTabGrid.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().Click();
            //Page.ControllerSetupPage.ControllersTabGrid.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            //string finalRowData = Page.ControllerSetupPage.ControllersTabGrid.Rows.FirstOrDefault().InnerText;
            //if(!finalRowData.Equals(intitilRowData))
            //{
            //    Assert.Fail("Data is changed after inline edit is cancelled in controller setup page");
            //}            
            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            AddBeckhoffController(random.Next(0, 100000).ToString(), true, "UX16 Beck 2");
            VerifyCancelUpdate();            
            Thread.Sleep(2000);
            VerifySaveUpdate();
        }

        /// <summary>
        /// Test case 25415: RG: Controller(s) Setup -> List Page : Verify access to Controller Page depending on UserRoleId - 1 to 5
        /// Test case 25411: RG: Verify access to Controller Page depending on UserRoleId - 6
        /// </summary>
        [TestCategory(TestType.functional, "TC07_UserRoleValidation")]
        [TestCategory(TestType.regression, "TC07_UserRoleValidation")]
        [Test]
        public void TC07_UserRoleValidation()
        {
            Runner.DoStep("Check whether TMBasic user can add a Dispenser", () =>
            {
                LoginWithUser(Users.TMBasicUser[0], Users.TMBasicUser[1]);
                Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
                if (!Page.ControllerSetupPage.IsAddControllerPresent)
                {
                    Assert.Fail("Add controller button is not present for level 6 user");
                }
            });
            Runner.DoStep("Check whether PEngineer User has access to Dispenser setup page", () =>
            {
                LoginWithUser(Users.PEngineerUser[0], Users.PEngineerUser[1]);
                if (Page.LoginPage.TopMainMenu.MenuItemsList.Contains("Controller Setup"))
                {
                    Assert.Fail("Level 3 user is having access to controller setup page");
                }
            });
            Runner.DoStep("Check whether PManager User has access to Dispenser setup page", () =>
            {
                LoginWithUser(Users.PManagerUser[0], Users.PManagerUser[1]);
                if (Page.LoginPage.TopMainMenu.MenuItemsList.Contains("Controller Setup"))
                {
                    Assert.Fail("Level 4 user is having access to controller setup page");
                }
            });
            Runner.DoStep("Check whether CAManager User has access to Dispenser setup page", () =>
            {
                LoginWithUser(Users.CAManagerUser[0], Users.CAManagerUser[1]);
                if (Page.LoginPage.TopMainMenu.MenuItemsList.Contains("Controller Setup"))
                {
                    Assert.Fail("Level 5 CAM user is having access to controller setup page");
                }
            });
            Runner.DoStep("Check whether BDManager User has access to Dispenser setup page", () =>
            {
                LoginWithUser(Users.BDManagerUser[0], Users.BDManagerUser[1]);
                if (Page.LoginPage.TopMainMenu.MenuItemsList.Contains("Controller Setup"))
                {
                    Assert.Fail("Level 5 (Business development manager) user is having access to controller setup page");
                }
            });
            Runner.DoStep("Login as Enginner", () =>
            {
                LoginWithUser(Users.EngineerUser[0], Users.EngineerUser[1]);
            });                                                       
        }

        /// <summary>
        /// Test case 25600: RG: Controller(s) Setup -> List Page : Verify access to Controller Page depending on UserRoleId - 7 and above
        /// </summary>
        [TestCategory(TestType.functional, "TC08_AddControllerWithLevel7User")]
        [TestCategory(TestType.regression, "TC08_AddControllerWithLevel7User")]
        [Test]
        public void TC08_AddControllerWithLevel7User()
        {
            Runner.DoStep("Check whether TMAdvanced user can add a Dispenser", () =>
            {
                LoginWithUser(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]);
                Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
                if (!Page.ControllerSetupPage.IsAddControllerPresent)
                {
                    Assert.Fail("Add Dispenser button is not present for user role 7");
                }
                //AddAndVerifyBeckhoffController("3",false);
            });
            Runner.DoStep("Login as Engineer", () =>
            {
                LoginWithUser(Users.EngineerUser[0], Users.EngineerUser[1]);
            });                       
        }

        // <summary>
        /// Test case 24716: RG: Verify Save functionality when adding Advanced, Pumps tabs
        /// </summary>
        [TestCategory(TestType.functional, "TC09_VerifyAddSaveInAdvancedAndPumpsTabsBeckhoff")]
        [TestCategory(TestType.regression, "TC09_VerifyAddSaveInAdvancedAndPumpsTabsBeckhoff")]
        [Test]
        public void TC09_VerifyAddSaveInAdvancedAndPumpsTabsBeckhoff()
        {
            LoginWithUser(Users.AdminUser[0], Users.AdminUser[1]); 
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            AddBeckhoffController(random.Next(0, 100000).ToString(), true, "UX16 Beck 3");
            VerifyAdvancedSaveBeckhoff();
            VerifyPumpsAndValvesSaveBeckhoff();
            //VerifyTagManagementTabBeckhoff();
        }

        // <summary>
        /// Test case 24716: RG: Verify Save functionality when updating Advanced, Pumps tabs
        /// </summary>
        [TestCategory(TestType.functional, "TC10_VerifyUpdateSaveInAdvancedAndPumpsTabsBeckhoff")]
        [TestCategory(TestType.regression, "TC10_VerifyUpdateSaveInAdvancedAndPumpsTabsBeckhoff")]
        [Test]
        public void TC10_VerifyUpdateSaveInAdvancedAndPumpsTabsBeckhoff()
        {
            Runner.DoStep("Click on Update button of any Beckhoff dispenser", () =>
            {
                Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
                Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("UX16 Beck 3")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
                Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("UX16 Beck 3")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Thread.Sleep(3000);
            });
            string DispenserName = Page.ControllerGeneralSetupTabPage.DispenserNameBeckhoffUpdate.Value;
            
            Runner.DoStep("Enter details and Save", () =>
            {                
                Page.ControllerGeneralSetupTabPage.DispenserNameBeckhoffUpdate.TypeText("Edit Dispenser Name");
                Page.ControllerGeneralSetupTabPage.Active.DeskTopMouseClick();                
                Page.ControllerGeneralSetupTabPage.SerialNumberUpdateBeckhoff.TypeText(random.Next(1, 50000).ToString());
                Page.ControllerGeneralSetupTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(3000);
            });                        
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Edit Dispenser Name")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Edit Dispenser Name")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ControllerGeneralSetupTabPage.DispenserNameBeckhoffUpdate.TypeText(DispenserName);
            Page.ControllerGeneralSetupTabPage.Active.DeskTopMouseClick();
            Page.ControllerGeneralSetupTabPage.SerialNumberUpdateBeckhoff.TypeText(random.Next(1, 50000).ToString());
            Page.ControllerGeneralSetupTabPage.Save.DeskTopMouseClick();
            Thread.Sleep(1000);
            //VerifyUpdateAdvancedSaveBeckhoff();
            //VerifyPumpsAndValvesSaveBeckhoff();                     
        }

        // <summary>;
        /// Test case 24716: RG: Verify Save functionality when adding Advanced, Pumps tabs
        /// </summary>
        [TestCategory(TestType.functional, "TC11_VerifyAddSaveInAdvancedAndPumpsTabsAB")]
        [TestCategory(TestType.regression, "TC11_VerifyAddSaveInAdvancedAndPumpsTabsAB")]
        [Test]
        public void TC11_VerifyAddSaveInAdvancedAndPumpsTabsAB()
        {
            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            AddABController(random.Next(0, 100000).ToString(), "UX16 AB 1");
            VerifyAdvancedSaveAB();
            VerifyPumpsAndValvesSaveAB();
            //VerifyTagManagementTabAB();
        }

        // <summary>
        /// Test case 24716: RG: Verify Save functionality when updating Advanced, Pumps tabs
        /// </summary>
        [TestCategory(TestType.functional, "TC12_VerifyUpdateSaveInAdvancedAndPumpsTabsAB")]
        [TestCategory(TestType.regression, "TC12_VerifyUpdateSaveInAdvancedAndPumpsTabsAB")]
        [Test]
        public void TC12_VerifyUpdateSaveInAdvancedAndPumpsTabsAB()
        {
            Thread.Sleep(2000);
            Runner.DoStep("Click update button of any AB dispenser in dispensers setup page", () =>
            {
                Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
                Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("UX16 AB 1")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
                Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("UX16 AB 1")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Thread.Sleep(3000);
            });
            string DispenserName = Page.ControllerSetupPage.ABDispenserNameUpdate.Value;
            Runner.DoStep("Change the dispenser detials", () =>
            {
                Page.ControllerSetupPage.ABDispenserNameUpdate.TypeText("Edit AB Dispenser");
                Page.ControllerSetupPage.WebportFtpEnabled.Focus();
                Page.ControllerSetupPage.WebportFtpEnabled.DeskTopMouseClick();
                Page.ControllerSetupPage.WebportFtpEnabled.Focus();
                Page.ControllerSetupPage.WebportFtpEnabled.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.ABSerialNumberUpdate.TypeText(random.Next(1, 50000).ToString());
            });
            Runner.DoStep("Click on Save button", () =>
            {
                Page.ControllerSetupPage.Save.Click();
                Thread.Sleep(2000);
            });
            Thread.Sleep(2000);
            if (!Page.ControllerGeneralSetupTabPage.SuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Dispenser not updated successfully");
            }
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Edit AB Dispenser")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Edit AB Dispenser")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.ABDispenserNameUpdate.TypeText(DispenserName);
            Page.ControllerSetupPage.WebportFtpEnabled.Focus();
            Page.ControllerSetupPage.WebportFtpEnabled.DeskTopMouseClick();
            Page.ControllerSetupPage.WebportFtpEnabled.Focus();
            Page.ControllerSetupPage.WebportFtpEnabled.DeskTopMouseClick();
            Page.ControllerGeneralSetupTabPage.ABSerialNumberUpdate.TypeText(random.Next(1, 50000).ToString());
            Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (!Page.ControllerGeneralSetupTabPage.SuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Dispenser not updated successfully");
            }
            Thread.Sleep(2000);
            //VerifyUpdateAdvancedSaveAB();
            //VerifyPumpsAndValvesSaveAB();
        }

        // <summary>
        /// Test case 24716: RG: Verify Save functionality when updating Advanced, Pumps tabs
        /// </summary>
        [TestCategory(TestType.functional, "TC13_VerifyPumpsInlineEditAB")]
        [Test]
        public void TC13_VerifyPumpsInlineEditAB()
        {
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Allen Bradley")[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(3000);
            VerifyPumpsAndnValvesInlineEdit();
        }

        // <summary>
        /// Test case 24716: RG: Verify Save functionality when updating Advanced, Pumps tabs
        /// </summary>
        [TestCategory(TestType.functional, "TC14_VerifyPumpsInlineEditBeckhoff")]
        [Test]
        public void TC14_VerifyPumpsInlineEditBeckhoff()
        {
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Beckhoff")[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(3000);
            VerifyPumpsAndnValvesInlineEdit();
        }
      
        private void LoginWithUser(string userid, string pwds)
        {
            Page.LoginPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(userid, pwds);
        }

        private void AddBeckhoffController(string controllerNumber, bool enterAMSNetId, string name)
        {
            
            Page.ControllerSetupPage.AddControllerButton.Click();
            Runner.DoStep("Select Dispenser model and type", () =>
            {
                 Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("Ultrax 6/12/16", Timeout);
                 Page.ControllerGeneralSetupTabPage.ControllerType.SelectByText("Beckhoff", Timeout);
            });

            Runner.DoStep("Enter dispenser details", () =>
            {
                Page.ControllerGeneralSetupTabPage.BECDispenserName.TypeText(name);
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.TypeText(controllerNumber);                              
                if (enterAMSNetId)
                {
                    Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBECToAdd.DeskTopMouseClick();
                    Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBECToAdd.Value = "";
                    KeyBoardSimulator.SetNumeric(random.Next(100001, 200000).ToString());
                }

                KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);                
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.DeskTopMouseClick();                
                //KeyBoardSimulator.SetNumeric(controllerNumber);
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.TypeText(controllerNumber);
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.SpinDownClick();
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.SpinUpClick();                
                Page.ControllerGeneralSetupTabPage.BECDispenserSerialNumber.TypeText(DateTime.Now.ToString());
            });
            Runner.DoStep("Save dispenser", () =>
            {
                if (!Page.ControllerSetupPage.IsSaveButtonEnabled())
                {
                    Page.ControllerSetupPage.Save.DeskTopMouseClick();
                }
            });                        
            Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(3000);
        }

        private void AddAndVerifyBeckhoffController(string controllerNumber, bool enterAMSNetId)
        {
            
            Page.ControllerSetupPage.AddControllerButton.Click();
            Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("Ultrax 6/12/16", Timeout);
            Page.ControllerGeneralSetupTabPage.ControllerType.SelectByText("Beckhoff", Timeout);

            if (enterAMSNetId)
            {
                Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBECToAdd.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBECToAdd.Value = "";
                KeyBoardSimulator.SetNumeric(random.Next(100001, 200000).ToString());
            }

            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);

            Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.DeskTopMouseClick();
            //KeyBoardSimulator.SetNumeric(controllerNumber);

            Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.TypeText(controllerNumber);
            Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.SpinDownClick();
            Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxBEC.SpinUpClick();
            Page.ControllerGeneralSetupTabPage.BECDispenserName.TypeText(DateTime.Now.ToString());
            Page.ControllerGeneralSetupTabPage.BECDispenserSerialNumber.TypeText(DateTime.Now.ToString());

            if (!Page.ControllerSetupPage.IsSaveButtonEnabled())
            {
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
            }
            Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(3000);
            ValidateControllerAddition(controllerNumber, "Ultrax 6/12/16Beckhoff");
        }

        private void AddABController(string controllerNumber, string name)
        {
            Runner.DoStep("Select dispenser model and type", () =>
            {
                Page.ControllerSetupPage.AddControllerButton.Click();
                Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("Ultrax 6/12/16", Timeout);
                Page.ControllerGeneralSetupTabPage.ControllerType.SelectByText("Allen Bradley", Timeout);
            });
            Runner.DoStep("Enter necessary details", () =>
            {
                Page.ControllerGeneralSetupTabPage.ABDispenserName.TypeText(name);
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.TypeText(controllerNumber);
                KeyBoardSimulator.SetNumeric("1");
                Page.ControllerGeneralSetupTabPage.OPCServerUltraxAB.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.ABDispenserSerialNumber.TypeText(DateTime.Now.ToString());
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.DeskTopMouseClick();
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.TypeText(controllerNumber);
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.SpinDownClick();
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.SpinUpClick();                                
            });
            Runner.DoStep("Click on Save button", () =>
            {
                if (!Page.ControllerSetupPage.IsSaveButtonEnabled())
                {
                    Page.ControllerSetupPage.Save.DeskTopMouseClick();
                }
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
                Thread.Sleep(3000);
            });                                    
        }

        private void AddAndVerifyABController(string controllerNumber)
        {
            Page.ControllerSetupPage.AddControllerButton.Click();
            Runner.DoStep("Select dispenser model and type", () =>
            {
                Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("Ultrax 6/12/16", Timeout);
                Page.ControllerGeneralSetupTabPage.ControllerType.SelectByText("Allen Bradley", Timeout);
            });
            Runner.DoStep("Enter dispenser details", () =>
            {
                Page.ControllerGeneralSetupTabPage.ABDispenserName.TypeText("test2");
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.TypeText(controllerNumber);
                Page.ControllerGeneralSetupTabPage.OPCServerUltraxAB.DeskTopMouseClick();
                KeyBoardSimulator.SetNumeric("1");
                
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.DeskTopMouseClick();
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.TypeText(controllerNumber);
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.SpinDownClick();
                //Page.ControllerGeneralSetupTabPage.ControllerNumberUltraxAB.SpinUpClick();
                
                Page.ControllerGeneralSetupTabPage.ABDispenserSerialNumber.TypeText(DateTime.Now.ToString());
            });
            Runner.DoStep("Save dispenser", () =>
            {
                if (!Page.ControllerSetupPage.IsSaveButtonEnabled())
                {
                    Page.ControllerSetupPage.Save.DeskTopMouseClick();
                }
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
            });            
            //Page.ControllerGeneralSetupTabPage.OPCObjectUltraxAB.DeskTopMouseClick();
            //KeyBoardSimulator.SetNumeric("1");

            //Page.ControllerGeneralSetupTabPage.IPAddressAB.DeskTopMouseClick();
            //KeyBoardSimulator.SetNumeric("1");

            //Page.ControllerGeneralSetupTabPage.DDEDriverUltraxAB.DeskTopMouseClick();
            //KeyBoardSimulator.SetNumeric("1");

            //Page.ControllerGeneralSetupTabPage.ComPortNumberUltraxAB.DeskTopMouseClick();
            //Page.ControllerGeneralSetupTabPage.ComPortNumberUltraxAB.TypeText("1");
            //Page.ControllerGeneralSetupTabPage.ComPortNumberUltraxAB.SpinDownClick();
            //Page.ControllerGeneralSetupTabPage.ComPortNumberUltraxAB.SpinUpClick();            
            Thread.Sleep(3000);
            ValidateControllerAddition(controllerNumber, "Ultrax 6/12/16AllenBradley");
        }

        private void AddAndVerifymyControl(string controllerNumber, bool enterAMSNetId)
        {
            Page.ControllerSetupPage.AddControllerButton.Click();
            Runner.DoStep("Select dispenser model and type", () =>
            {
                Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("myControl", Timeout);
                Page.ControllerGeneralSetupTabPage.ControllerType.SelectByText("Beckhoff", Timeout);
            });            

            //if (!enterAMSNetId)
            //{
            //    Page.ControllerGeneralSetupTabPage.AMSNetIDmyControlBEC.DeskTopMouseClick();
            //    KeyBoardSimulator.SetNumeric("123456789");
            //}
            Runner.DoStep("Enter dispenser details", () =>
            {
                KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);

                //Page.ControllerGeneralSetupTabPage.ControllerNumbermyControlBEC.DeskTopMouseClick();
                ////KeyBoardSimulator.SetNumeric(controllerNumber);

                //Page.ControllerGeneralSetupTabPage.ControllerNumbermyControlBEC.DeskTopMouseClick();
                //Page.ControllerGeneralSetupTabPage.ControllerNumbermyControlBEC.TypeText(controllerNumber);
                //Page.ControllerGeneralSetupTabPage.ControllerNumbermyControlBEC.SpinDownClick();
                //Page.ControllerGeneralSetupTabPage.ControllerNumbermyControlBEC.SpinUpClick();
                
                Page.ControllerGeneralSetupTabPage.myControlName.TypeText("myControl Dispenser");
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.TypeText(controllerNumber);
                Page.ControllerGeneralSetupTabPage.myControlSerialNumber.TypeText(DateTime.Now.ToString());
                Page.ControllerGeneralSetupTabPage.myControlActive.Click();
                Page.ControllerGeneralSetupTabPage.myControlActive.Click();
            });
            Runner.DoStep("Save dispenser", () =>
            {
                if (!Page.ControllerSetupPage.IsSaveButtonEnabled())
                {
                    Page.ControllerSetupPage.Save.DeskTopMouseClick();
                }
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
            });
            Thread.Sleep(3000);
            ValidateControllerAddition(controllerNumber, "myControlBeckhoff");
        }

        private void ValidateControllerAddition(string controllerNumber, string controllerType)
        {
            Runner.DoStep("Verify addition of dispenser", () =>
            {
                string message = Page.ControllerSetupPage.ControllerAddMessage.BaseElement.InnerText;

                if (null != message)
                {
                    if (!message.Contains("Successfully"))
                    {
                        Assert.Fail("Message incorrect after controller addition. Expected Message : Controller Saved Successfully, Actual Message: {0}", message);
                    }
                }
            });            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();

            //if (Page.ControllerSetupPage.IsControllerGridFirstColumnContains("1" + controllerNumber))
            //{
            //    Assert.Fail("After adding controller, new controller is not displayed in grid");
            //}

            //if (Page.ControllerSetupPage.ControllersTabGrid.SelectedRows(controllerType).Count <= 0)
            //{
            //    Assert.Fail("Controller type is not correctly displayed in UI grid after controller addition");
            //}

            //DataRowCollection dbValues = DBValidation.DataRows("select top 1 IsDeleted from TCD.ConduitController order by InstallDate desc");

            //if (!Convert.ToBoolean(dbValues[0].ItemArray[0]))
            //{
            //    Assert.Fail("Database is not updated after adding controller");
            //}

            //TODO: Looks like audit tables are not getting updated, add audit validation here
            //select * from auditcolumnsdetails where id = (select top 1 ControllerId from ConduitController order by InstallDate desc)
        }

        private void VerifyCancelUpdate()
        {
            
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("UX16 Beck 2").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            //string initialValueCancel = Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.Value;
            Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.DeskTopMouseClick();
            Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.Value = "";
            KeyBoardSimulator.SetNumeric(random.Next(100001, 200000).ToString());
            Page.ControllerGeneralSetupTabPage.BECDispenserSerialNumber.TypeText(DateTime.Now.ToString());
            Page.ControllerSetupPage.WaitforAction(() =>
            {
                Page.ControllerSetupPage.Cancel.DeskTopMouseClick();
                return Page.ControllerSetupPage.IsSaveButtonEnabled();
            }, Timeout);

            Page.ControllerSetupPage.Cancel.DeskTopMouseClick();
            DialogHandler.YesButton.Click();
            Thread.Sleep(2000);
            if (!Page.ControllerGeneralSetupTabPage.SuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
            {
                Assert.Fail("Dispenser not updated");
            }

            Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.DeskTopMouseClick();
            Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.Value = "";
            KeyBoardSimulator.SetNumeric(random.Next(100001, 200000).ToString());

            Page.ControllerSetupPage.WaitforAction(() =>
            {
                Page.ControllerSetupPage.Cancel.DeskTopMouseClick();
                return Page.ControllerSetupPage.IsSaveButtonEnabled();
            }, Timeout);

            Page.ControllerSetupPage.Cancel.DeskTopMouseClick();
            DialogHandler.NoButton.Click();

            //Page.ControllerSetupPage.Cancel.DeskTopMouseClick();
            //DialogHandler.NoButton.Click();
            //Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            //Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Beckhoff").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            //string finalvalueCancel = Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.Value;

            //if (initialValueCancel != finalvalueCancel)
            //{
            //    Assert.Fail("After editing controller, new value is not displayed in controller list page grid");
            //}
        }

        private void VerifySaveUpdate()
        {
            Runner.DoStep("In Dispensers setup page, select a record from the table and click on update button", () =>
            {
                Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
                Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("UX16 Beck 2").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            });
            string initialValueSave = Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.Value;
            Runner.DoStep("Change some of the values", () =>
            {                
                Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.Value = "";
                
                KeyBoardSimulator.SetNumeric(random.Next(100001, 200000).ToString());
                Page.ControllerSetupPage.SerialNumber.TypeText(random.Next(0, 12000).ToString());
                Page.ControllerGeneralSetupTabPage.ActiveUXBeck.Click();
                Page.ControllerGeneralSetupTabPage.ActiveUXBeck.Click();
                Page.ControllerSetupPage.WaitforAction(() =>
                {
                    Page.ControllerSetupPage.Save.DeskTopMouseClick();
                    return Page.ControllerSetupPage.IsSaveButtonEnabled();
                }, Timeout);                                       
                
            });
            Runner.DoStep("Save the details", () =>
            {
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
            });
            Runner.DoStep("Verify whether the value in a particular field has changed", () =>
            {
                Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
                Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("UX16 Beck").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
                string finalvalueSave = Page.ControllerGeneralSetupTabPage.AMSNetIDAddressUltraxBEC.Value;

                if (initialValueSave == finalvalueSave)
                {
                    Assert.Fail("After editing controller, new value is not displayed in controller list page grid");
                }
            });
        }

        private void VerifyAdvanceEditAllenBradely()
        {
            Pages.CommonControls.EcolabDataGridItems row = Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Allen Bradley").FirstOrDefault();
            ReadOnlyCollection<string> rowValus = row.GetColumnValues();
            row.GetButtonControls().LastOrDefault().Click();
            Page.ControllerSetupPage.AdvanceTab.Click();

            if (null != Page.ControllerAdvancedSetupPage.ControllerName)
            {
                string actualMessage = Page.ControllerAdvancedSetupPage.ControllerName.BaseElement.InnerText;
                string expectedMessage = string.Format("{0} ({1} - Allen Bradley)", rowValus.FirstOrDefault(), rowValus[1]);
                if (actualMessage.Equals(expectedMessage))
                {
                    Assert.Fail("Controller name is incorrect , Expected:{0} , Actual{0}", expectedMessage, actualMessage);
                }
            }

            Page.ControllerAdvancedSetupPage.WebPortIPAB.DeskTopMouseClick();
            KeyBoardSimulator.SetNumeric("11");

            Page.ControllerAdvancedSetupPage.WebPortLoginAB.DeskTopMouseClick();
            KeyBoardSimulator.SetNumeric("12");

            Page.ControllerAdvancedSetupPage.WebPortPasswordAB.DeskTopMouseClick();
            KeyBoardSimulator.SetNumeric("1234");

            Page.ControllerSetupPage.WaitforAction(() =>
            {
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
                return Page.ControllerSetupPage.IsSaveButtonEnabled();
            }, Timeout);

            Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Page.ControllerSetupPage.TrySelectBacktoController();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Allen Bradley").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            Page.ControllerSetupPage.AdvanceTab.Click();

            if (!Page.ControllerAdvancedSetupPage.WebPortIPAB.Value.Equals("11"))
            {
                Assert.Fail("Web port ip value is not updated corerctly for Allen Bradely controller");
            }

            if (!Page.ControllerAdvancedSetupPage.WebPortLoginAB.Value.Equals("12"))
            {
                Assert.Fail("Web port login value is not updated corerctly for Allen Bradely controller");
            }

            if (!Page.ControllerAdvancedSetupPage.WebPortPasswordAB.Value.Equals("1234"))
            {
                Assert.Fail("Web port password value is not updated corerctly for Allen Bradely controller");
            }
        }

        private void VerifyAdvanceEditBeckhoff()
        {
            Pages.CommonControls.EcolabDataGridItems row = Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Beckhoff").FirstOrDefault();
            ReadOnlyCollection<string> rowValus = row.GetColumnValues();
            row.GetButtonControls().LastOrDefault().Click();
            Page.ControllerSetupPage.AdvanceTab.Click();

            if (null != Page.ControllerAdvancedSetupPage.ControllerName)
            {
                string actualMessage = Page.ControllerAdvancedSetupPage.ControllerName.BaseElement.InnerText;
                string expectedMessage = string.Format("{0} ({1} - Beckhoff)", rowValus.FirstOrDefault(), rowValus[1]);
                if (actualMessage.Equals(expectedMessage))
                {
                    Assert.Fail("Controller name is incorrect , Expected:{0} , Actual{0}", expectedMessage, actualMessage);
                }
            }

            Page.ControllerAdvancedSetupPage.WebPortIPBEC.DeskTopMouseClick();
            KeyBoardSimulator.SetNumeric("11");

            Page.ControllerAdvancedSetupPage.WebPortLoginBEC.DeskTopMouseClick();
            KeyBoardSimulator.SetNumeric("12");

            Page.ControllerAdvancedSetupPage.WebPortPasswordBEC.DeskTopMouseClick();
            KeyBoardSimulator.SetNumeric("1234");

            Page.ControllerSetupPage.WaitforAction(() =>
            {
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
                return Page.ControllerSetupPage.IsSaveButtonEnabled();
            }, Timeout);

            Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Page.ControllerSetupPage.TrySelectBacktoController();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("Beckhoff").FirstOrDefault().GetButtonControls().LastOrDefault().Click();
            Page.ControllerSetupPage.AdvanceTab.Click();

            if (!Page.ControllerAdvancedSetupPage.WebPortIPBEC.Value.Equals("11"))
            {
                Assert.Fail("Web port ip value is not updated corerctly for Allen Bradely controller");
            }

            if (!Page.ControllerAdvancedSetupPage.WebPortLoginBEC.Value.Equals("12"))
            {
                Assert.Fail("Web port login value is not updated corerctly for Allen Bradely controller");
            }

            if (!Page.ControllerAdvancedSetupPage.WebPortPasswordBEC.Value.Equals("1234"))
            {
                Assert.Fail("Web port password value is not updated corerctly for Allen Bradely controller");
            }
        }

        private void VerifyControllerList(List<string> expectedList, string region)
        {
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Page.ControllerSetupPage.AddControllerButton.Click();
            ReadOnlyCollection<string> actualList = Page.ControllerGeneralSetupTabPage.GetControllerModelList();
            //new List<string>() { "A", "B", "C" }.AsReadOnly();
            foreach (string controller in actualList)
            {
                if (actualList.IndexOf(controller) != expectedList.IndexOf(controller))
                {
                    Assert.Fail("Order of controller {0} for region {1} is different Expected order:{2}, Actual order:{3}", controller, region, expectedList.IndexOf(controller) + 1, actualList.IndexOf(controller) + 1);
                }
            }
        }

        private void VerifyAdvancedSaveBeckhoff()
        {
            Runner.DoStep("Enter any value in 'Advance' tab and click Save", () =>
            {
                Page.ControllerSetupPage.AdvanceTab.Click();
                //Page.ControllerAdvancedSetupPage.LinkIntegrityAddress.DeskTopMouseClick();
                //Page.ControllerAdvancedSetupPage.LinkIntegrityAddress.Value = " ";
                //Page.ControllerAdvancedSetupPage.LinkIntegrityAddress.TypeText("L_LIC");
                //Page.ControllerAdvancedSetupPage.PostFlushTime.DeskTopMouseClick();
                ////Page.ControllerAdvancedSetupPage.PostFlushTime.Value = " ";
                //Page.ControllerAdvancedSetupPage.PostFlushTime.TypeText("L_POSF");
                Page.ControllerAdvancedSetupPage.PostFlushTime.DeskTopMouseClick();
                Page.ControllerAdvancedSetupPage.PostFlushTime.TypeText("37");
                Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
                Thread.Sleep(2000);
            });            
        }

        private void VerifyUpdateAdvancedSaveBeckhoff()
        {
            Page.ControllerSetupPage.AdvanceTab.Click();
            //Page.ControllerAdvancedSetupPage.MaxWashFormulasTag.TypeText("tag a");
            //Page.ControllerAdvancedSetupPage.MaxFormulaInjectionsTag.TypeText("tag b");
            //Page.ControllerAdvancedSetupPage.NumberOfChemicalValvesTag.TypeText("tag c");
            //Page.ControllerAdvancedSetupPage.PreFlushTimeTag.TypeText("tag d");
            Page.ControllerAdvancedSetupPage.PostFlushTimeToUpadte.Click();
            Page.ControllerAdvancedSetupPage.PostFlushTimeToUpadte.TypeText("37");
            //Page.ControllerAdvancedSetupPage.PostFlushTimeTag.TypeText("tag e");
            //Page.ControllerAdvancedSetupPage.LinkIntegrityAddressTag.TypeText("tag f");
            //Page.ControllerAdvancedSetupPage.NameLinkTag.TypeText("tag g");
            //Page.ControllerAdvancedSetupPage.AutomaticWeightEnabledTag.TypeText("tag h");
            //Page.ControllerAdvancedSetupPage.RatioDosingEnabledTag.TypeText("tag i");
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
        }

        private void VerifyPumpsAndValvesSaveBeckhoff()
        {
            Runner.DoStep("In 'Devices' tab, click on update button of any pump", () =>
            {
                Page.ControllerSetupPage.PumpsValvesTab.Focus();
                Page.ControllerSetupPage.PumpsValvesTab.Click();
                Thread.Sleep(2000);
                Page.ControllerPumpValvesPage.PumpsAndValvesTabGrid.Rows[1].GetButtonControls()[3].DeskTopMouseClick();                
            });
            Runner.DoStep("Enter some details and click Save", () =>
            {
                Page.ControllerSetupPage.ProductName.SelectByIndex(1, Timeout);
                Page.ControllerPumpValvesPage.LFSChemicalName.Click();
                Page.ControllerPumpValvesPage.LFSChemicalName.Value = " ";
                Page.ControllerPumpValvesPage.LFSChemicalName.TypeText("LFS");
                Page.PumpsValvesPage.txtPumpCalibration.TypeText("160");
                Thread.Sleep(2000);
                //Page.ControllerPumpValvesPage.FlowDetectorType.SelectByIndex(1, Timeout);
                Page.ControllerPumpValvesPage.SaveButton.DeskTopMouseClick();
                Thread.Sleep(3000);
                if (!Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Device wasn't added successfully");
                }
            });                        
        }

        private void VerifyTagManagementTabBeckhoff()
        {
            Runner.DoStep("Click on 'TagManagement' tab", () =>
            {
                Page.ControllerSetupPage.TagManagementTab.Click();
                Thread.Sleep(3000);
            });            
        }

        public void VerifyAdvancedSaveAB()
        {
            Runner.DoStep("Click on 'Advance' tab", () =>
            {
                Page.ControllerSetupPage.AdvanceTab.Click();
            });
            Runner.DoStep("Enter details and click on Save button", () =>
            {
                Page.ControllerAdvancedSetupPage.PostFlushTimeAB.DeskTopMouseClick();
                Page.ControllerAdvancedSetupPage.PostFlushTimeAB.TypeText("37");
                Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
            });                        
        }

        private void VerifyUpdateAdvancedSaveAB()
        {
            Page.ControllerSetupPage.AdvanceTab.DeskTopMouseClick();
            //Page.ControllerAdvancedSetupPage.MaxWashFormulasTag.TypeText("tag a");
            //Page.ControllerAdvancedSetupPage.MaxFormulaInjectionsTag.TypeText("tag b");
            //Page.ControllerAdvancedSetupPage.NumberOfChemicalValvesTag.TypeText("tag c");
            //Page.ControllerAdvancedSetupPage.PreFlushTimeTag.TypeText("tag d");
            Page.ControllerAdvancedSetupPage.PostFlushTimeToUpadteAB.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.PostFlushTimeToUpadteAB.TypeText("37");
            //Page.ControllerAdvancedSetupPage.PostFlushTimeTag.TypeText("tag e");
            //Page.ControllerAdvancedSetupPage.LinkIntegrityAddressTag.TypeText("tag f");
            //Page.ControllerAdvancedSetupPage.NameLinkTag.TypeText("tag g");
            //Page.ControllerAdvancedSetupPage.AutomaticWeightEnabledTag.TypeText("tag h");
            //Page.ControllerAdvancedSetupPage.RatioDosingEnabledTag.TypeText("tag i");
            Page.ControllerAdvancedSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(2000);
        }

        public void VerifyPumpsAndValvesSaveAB()
        {
            Runner.DoStep("Click on update button of any pump in 'Devices' tab", () =>
            {
                Page.ControllerSetupPage.PumpsValvesTab.DeskTopMouseClick();
                Page.ControllerPumpValvesPage.PumpsAndValvesTabGrid.Rows[1].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Thread.Sleep(2000);
            }); 
            Runner.DoStep("Select the formula and Save", () =>
            {
                Page.ControllerPumpValvesPage.ProductNameAB.SelectByIndex(1, Timeout);
                Page.PumpsValvesPage.txtPumpCalibration.TypeText("160");
                Page.ControllerPumpValvesPage.SaveButton.DeskTopMouseClick();
                Thread.Sleep(2000);
                if (!Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Device wasn't added successfully");
                }
            });                        
        }

        public void VerifyTagManagementTabAB()
        {
            Runner.DoStep("Click on 'TagManagement' tab", () =>
            {
                Page.ControllerSetupPage.TagManagementTab.Click();
                Thread.Sleep(2000);
            });            
        }

        public void VerifyPumpsAndnValvesInlineEdit()
        {
            Page.ControllerSetupPage.PumpsValvesTab.Click();
            Thread.Sleep(2000);
            Page.ControllerPumpValvesPage.PumpsAndValvesTabGrid.Rows.FirstOrDefault().GetButtonControls()[2].DeskTopMouseClick();
            Page.ControllerPumpValvesPage.ProductNameInlineEdit.SelectByIndex(16, Timeout);
            Page.ControllerPumpValvesPage.TimeVolumeCalibrationInlineEdit.Value = "";
            Page.ControllerPumpValvesPage.TimeVolumeCalibrationInlineEdit.TypeText("4.8");
            //KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //KeyBoardSimulator.SetText("5.3");
            //Page.ControllerPumpValvesPage.KFactorInlineEdit.Focus();
            Page.ControllerPumpValvesPage.KFactorInlineEdit.Value = "";
            Page.ControllerPumpValvesPage.KFactorInlineEdit.TypeText("5.3");
            Page.ControllerPumpValvesPage.PumpsAndValvesTabGrid.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
        }
    }
}
