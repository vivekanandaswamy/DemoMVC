﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest
{
    class ManualInputBatchTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Page.ManualInputProductionTabPage.ProductionTab.Click();
            Page.ManualInputBatchTabPage.BatchDataTab.Click();
        }

        /// <summary>
        /// Test case 34217: RG: Verify recording value in Batchdata
        /// </summary>
        //[TestCategory(TestType.ondemand, "TC01_CreateBatchData")]
        [TestCategory(TestType.functional, "TC01_CreateBatchData")]
        [TestCategory(TestType.regression, "TC01_CreateBatchData")]
        [Test, Description("Test case 34217: RG Verify recording value in Batchdata")]
        public void TC01_UpdateBatchData()
        {
            /*
            //Page.ManualInputBatchTabPage.BatchDataTab.Click();
            //Runner.DoStep("Select the date from the Batch page", () =>
            //{
            //    selectDate();
            //});
            Page.ManualInputBatchTabPage.DateButton.Focus();
            Page.ManualInputBatchTabPage.DateButton.Click();
            Page.ManualInputBatchTabPage.BatchDate.Focus();
            Page.ManualInputBatchTabPage.BatchDate.DeskTopMouseClick();            
            //DateTime date = DateTime.Now;
            //string inputDate = date.ToString("MM/dd/yyyy").Replace("-", "/");
            //Page.ManualInputBatchTabPage.SelectDate.TypeText("21/10/2015");
            //Page.ManualInputBatchTabPage.BatchDataDay.DeskTopMouseClick();
            Page.ManualInputBatchTabPage.BatchDataDatePicker.SelectDay("November 2015", "5");            
            selectBatchDate("October", 2015);
            Page.ManualInputBatchTabPage.WasherGroup.SelectByIndex(2, Timeout);
            Page.ManualInputBatchTabPage.Washer.SelectByIndex(1, Timeout);
            Page.ManualInputBatchTabPage.Formula.SelectByIndex(1, Timeout);
            //Page.ManualInputBatchTabPage.BatchDataDropDown.SelectByIndex(1, Timeout);

            //Page.ManualInputBatchTabPage.BatchDataRecordingValue.DeskTopMouseClick();
            //Page.ManualInputBatchTabPage.BatchDataRecordingValue.TypeText("155");
            Runner.DoStep("Enter Batch details and Save them", () =>
            {
                Page.ManualInputBatchTabPage.Save.DeskTopMouseClick();
            });
            Runner.DoStep("Verify whether the Batch data is successfully added", () =>
            {
                HtmlControl successMsg = Page.ManualInputProductionTabPage.Message;
                if (null == successMsg)
                {
                    Assert.Fail("Success message is not displayed after manual input production data is saved");
                }
                else
                {
                    if (!Page.ManualInputProductionTabPage.IsMessage("Saved successfully"))
                    {
                        Assert.Fail("After saving manual input batch data Expected:Saved successfully,Actual:{0}", successMsg.BaseElement.InnerText);
                    }
                }
            });   
             * 
             * */

            Page.ManualInputBatchTabPage.BatchDataTab.Click();





            //Page.ManualInputBatchTabPage.BatchDataDay.DeskTopMouseClick();
            //Page.ManualInputBatchTabPage.BatchDataDatePicker.Click();
            //IReadOnlyCollection<iAttribute> att = Page.ManualInputBatchTabPage.SelectDate.Attributes;

            //foreach (iAttribute dataObject in att)
            //{
            //    string a = dataObject.ToString();
            //    if (dataObject.ToString() == "value")
            //    {
            //        dataObject.Value = "fgd";
            //    }
            //}

            Page.ManualInputBatchTabPage.SelectDate.TypeText("02/01/2016");




            //int a=  Page.ManualInputBatchTabPage.BatchDate.
            //Page.ManualInputBatchTabPage.BatchDataDatePicker.SelectDay("October 2014", "22");
            Page.ManualInputBatchTabPage.WasherGroup.SelectByIndex(1, Timeout);
            Page.ManualInputBatchTabPage.Washer.SelectByIndex(1, Timeout);
            Page.ManualInputBatchTabPage.Formula.SelectByIndex(0, Timeout);
            //Page.ManualInputBatchTabPage.BatchDataDropDown.SelectByIndex(1, Timeout);

            // Page.ManualInputBatchTabPage.BatchDataRecordingValue.DeskTopMouseClick();
            // Page.ManualInputBatchTabPage.BatchDataRecordingValue.TypeText("155");
            //Page.ManualInputBatchTabPage.Save.DeskTopMouseClick();

            Page.ManualInputBatchTabPage.BtnSearch.DeskTopMouseClick();
            Thread.Sleep(2000);            
            if(Page.ManualInputBatchTabPage.IsBatchDataGridPresent)
            { 
                int numOfBatches = Page.ManualInputBatchTabPage.BatchDataGrid.Rows.Count;
                if (numOfBatches > 0)
                {
                    Page.ManualInputBatchTabPage.BatchDataGrid.Rows[0].GetEditableControls()[1].Focus();
                    // string tagname = Page.ManualInputBatchTabPage.BatchDataGrid.Rows[0].GetEditableControls()[5].TagName;
                    Thread.Sleep(1000);
                    Page.ManualInputBatchTabPage.BatchDataGrid.Rows[0].GetEditableControls()[1].Click();
                    Page.ManualInputBatchTabPage.BatchDataGrid.Rows[0].GetEditableControls()[1].TypeText("250");
                    Page.ManualInputBatchTabPage.Save.Click();
                    HtmlControl successMsg = Page.ManualInputProductionTabPage.Message;
                    if (null == successMsg)
                    {
                        Assert.Fail("Success message is not displayed after manual input production data is saved");
                    }
                    else
                    {
                        if (!Page.ManualInputProductionTabPage.IsMessage("Successfully updated."))
                        {
                            Assert.Fail("After saving manual input batch data Expected:Saved successfully,Actual:{0}", successMsg.BaseElement.InnerText);
                        }
                    }
                }
            }
            else
            {
                Assert.IsTrue(true);
            }
            //HtmlControl successMsg = Page.ManualInputProductionTabPage.Message;
            //if (null == successMsg)
            //{
            //    Assert.Fail("Success message is not displayed after manual input production data is saved");
            //}
           
            //{
            //    if (!Page.ManualInputProductionTabPage.IsMessage("Saved successfully"))
            //    {
            //        Assert.Fail("After saving manual input batch data Expected:Saved successfully,Actual:{0}", successMsg.BaseElement.InnerText);
            //    }
            //}

        }

        //[TestCategory(TestType.regression, "TC02_ObtainBatchData")]
        [Test, Description("Test case 34217: RG Verify recording value in Batchdata")]
        public void TC02_ObtainBatchData()
        {
            Page.ManualInputBatchTabPage.BatchDataTab.Click();
            Thread.Sleep(1000);
            selectBatchDate(1, "Jan", "2016");
        }

        public void selectDate()
        {
            Page.ManualInputBatchTabPage.DatePicker.DeskTopMouseClick();
            Page.ManualInputBatchTabPage.PreviousMonth.DeskTopMouseClick();
            Page.ManualInputBatchTabPage.Day33.DeskTopMouseClick();
        }

        public void selectBatchDate(string actualMonth, int actualYear)
        {
            List<string> Months = new List<string>();
            Months.Add("January");
            Months.Add("February");
            Months.Add("March");
            Months.Add("April");
            Months.Add("May");
            Months.Add("June");
            Months.Add("July");
            Months.Add("August");
            Months.Add("September");
            Months.Add("October");
            Months.Add("November");
            Months.Add("December");
            Page.ManualInputBatchTabPage.DatePicker.Click();
            Page.ManualInputBatchTabPage.YearMonthSelector.Click();
            string monthAndYear = Page.ManualInputBatchTabPage.YearMonthSelector.BaseElement.InnerText;
            string month = monthAndYear.Remove(monthAndYear.Length - 5);
            int indexOfPresentMonth = Months.IndexOf(month);
            int indexOfActualMonth = Months.IndexOf(actualMonth);
            monthAndYear = monthAndYear.Substring(monthAndYear.Length - 4, 4);
            int year = int.Parse(monthAndYear);
            if (year == actualYear)
            {
                if (indexOfActualMonth == indexOfPresentMonth)
                {
                    Page.ManualInputBatchTabPage.Day11.Click();
                }
                else if (indexOfActualMonth < indexOfPresentMonth)
                {
                    do
                    {
                        Page.ManualInputBatchTabPage.PreviousMonth.DeskTopMouseClick();
                        monthAndYear = Page.ManualInputBatchTabPage.YearMonthSelector.BaseElement.InnerText;
                        month = monthAndYear.Remove(monthAndYear.Length - 5);
                    } while (actualMonth != month);
                }
                else
                {
                    do
                    {
                        Page.ManualInputBatchTabPage.NextMonth.DeskTopMouseClick();
                        monthAndYear = Page.ManualInputBatchTabPage.YearMonthSelector.BaseElement.InnerText;
                        month = monthAndYear.Remove(monthAndYear.Length - 5);
                    } while (actualMonth != month);
                }
            }
            else if (actualYear < year)
            {
                do
                {
                    Page.ManualInputBatchTabPage.PreviousMonth.DeskTopMouseClick();
                    monthAndYear = Page.ManualInputBatchTabPage.YearMonthSelector.BaseElement.InnerText;
                    monthAndYear = monthAndYear.Substring(monthAndYear.Length - 4, 4);
                    year = int.Parse(monthAndYear);
                } while (actualYear != year);
            }
            else
            {
                do
                {
                    Page.ManualInputBatchTabPage.NextMonth.DeskTopMouseClick();
                    monthAndYear = Page.ManualInputBatchTabPage.YearMonthSelector.BaseElement.InnerText;
                    monthAndYear = monthAndYear.Substring(monthAndYear.Length - 4, 4);
                    year = int.Parse(monthAndYear);
                } while (actualYear != year);
            }
        }

        public void selectBatchDate(int date, string month, string year)
        {
            Page.ManualInputBatchTabPage.DateButton.Focus();
            Page.ManualInputBatchTabPage.DateButton.Click();
            string monthAndYear = Page.ManualInputBatchTabPage.YearMonthSelector.BaseElement.InnerText;
            //while (!monthAndYear.Contains(year))
            //{
            //    Page.ManualInputBatchTabPage.PreviousMonth.DeskTopMouseClick();
            //}
            //while (!monthAndYear.Contains(month))
            //{
            //    Page.ManualInputBatchTabPage.PreviousMonth.DeskTopMouseClick();
            //}
            Page.ManualInputBatchTabPage.PreviousMonth.DeskTopMouseClick();
            finalSelect(date);
        }

        private List<HtmlControl> Dates
        {
            get
            {
                ReadOnlyCollection<HtmlTableRow> dateRows = Page.ManualInputBatchTabPage.DatesTable.BodyRows;
                List<HtmlControl> dates = new List<HtmlControl>();
                foreach (HtmlTableRow dateRow in dateRows)
                {
                    foreach (Element date in dateRow.ChildNodes)
                    {
                        //if (!date.Attributes.ToString().Equals(""))
                        //{
                        //if (date.Attributes.Count >= 2)
                        //{
                        //    if (!date.GetAttribute("class").Value.Contains("k-other-month"))
                        //    {
                        //          dates.Add(new HtmlControl(date));                        
                        //    }
                        //}
                        //}   
                        if (!date.GetAttribute("role").Value.Equals("gridcell"))
                        {
                            dates.Add(new HtmlControl(date));
                        }
                    }
                }
                return dates;
            }
        }

        public string SelectedDate
        {
            get
            {
                return Dates.Where(date => date.BaseElement.GetAttribute("class").Value.Contains("k-state-hover")).FirstOrDefault().BaseElement.InnerText;
            }
        }

        private void finalSelect(int date)
        {
            HtmlControl dateToBeSelected = Dates.Where(selectdate => selectdate.BaseElement.InnerText.Equals(date)).FirstOrDefault();
            dateToBeSelected.DeskTopMouseClick();
        }
    }
}

