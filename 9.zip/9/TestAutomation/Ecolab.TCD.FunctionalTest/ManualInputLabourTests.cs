﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using Ecolab.AppStateHandler;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Ecolab.FunctionalTest
{
    public class ManualInputLabourTests : TestBase
    {
        string msgSaveButton = string.Empty;
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Page.ManualInputLabourTabPage.LabourTab.Click();
        }
        private void CloseBrowser()
        {
            Telerik.Shutdown();
            Telerik.CleanUp();
        }

		
        [TestCategory(TestType.regression, "TC01_VerifyLabourCostCalculatedAutomatically")]
        [Test, Description("Test case 34044: RG: Verify Labor cost is calculated automatilcally once user provides data to all fields in Labor tab ;")]
        public void TC01_VerifyLabourCostCalculatedAutomatically()
        {
            Thread.Sleep(2000);
            Runner.DoStep("Select Location", () =>
            {
                Page.ManualInputLabourTabPage.DdlLocation.SelectByIndex(1, Timeout);
            });            
			//Page.ManualInputLabourTabPage.DdlLocation.SelectByPartialText("Group", true);
			Thread.Sleep(1000);
            Runner.DoStep("Select Man hours type", () =>
            {
                Page.ManualInputLabourTabPage.DdlLabourTypes.SelectByIndex(1, Timeout);
            });            
			//Page.ManualInputLabourTabPage.DdlLabourTypes.SelectByPartialText("Temp", true);
            Thread.Sleep(1000);
            string value = Page.ManualInputLabourTabPage.TxtLabourCost.Text;
            Runner.DoStep("Verify whether the cost is added automatically or not", () =>
            {
                if (Page.ManualInputLabourTabPage.TxtLabourCost.Text == null)
                {
                    Assert.Fail("Labour cost not calculated automatically.Expected-Labour cost to displayed");
                }
                else
                {
                    Assert.Pass("Labour cost calculated automatically");
                }
            });            
        }

		[TestCategory(TestType.regression, "TC02_VerifyLabourCostSaveFunctionality")]
        [TestCategory(TestType.functional, "TC02_VerifyLabourCostSaveFunctionality")]
        [Test, Description("Test case 34045: RG: Verify Save functionality in Labor tab ;")]
        public void TC02_VerifyLabourCostSaveFunctionality()
        {
            Random rand = new Random();            
            int ranHours = rand.Next(1, 9);
            Thread.Sleep(1000);
            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "WasherGroupForMILabor");
            Thread.Sleep(1000);
            Page.ManualInputLabourTabPage.LabourTab.Click();
            Thread.Sleep(1000);

            Runner.DoStep("Enter Labour cost details and save them", () =>
            {
                Page.ManualInputLabourTabPage.AddLabourDetails("WasherGroupForMILabor", "Specialist", ranHours.ToString());
            });            
            Thread.Sleep(1000);
            Runner.DoStep("Verify Labour cost creation", () =>
            {
                if (null != Page.ManualInputLabourTabPage.SuccessMessage)
                {
                    if (Page.ManualInputLabourTabPage.SuccessMessage.BaseElement.InnerText == "")
                    {
                        msgSaveButton = "Labour details not created.";
                    }
                    else
                    {
                        msgSaveButton = Page.ManualInputLabourTabPage.SuccessMessage.BaseElement.InnerText;
                        if (msgSaveButton != "Saved successfully")
                        //if (!Page.ManualInputLabourTabPage.SuccessMessage.BaseElement.InnerText.Equals(@"Saved successfully"))
                        {
                            Assert.Fail("Incorrect error message is displayed,Expected: Labour Data Updated SuccessFully" + " but Actual:" + msgSaveButton);
                        }
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
            //string strCommand = "select Id, LocationId, ManHourTypeId AllocatedManHours " +
            //  " from TCD.ManualLabor where ManHourTypeid = 1  and AllocatedManHours = " + ranHours.ToString() + "  order by id desc";
            //DataSet ds = DBValidation.GetData(strCommand);
            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    Assert.True(true, "Labour records not found in DB.Expected- Allocated Man Hours = " + ranHours.ToString() + " with LocationId = 1");
            //}
           
            //{
            //    Assert.Fail("Labour records not found in DB.Expected- Allocated Man Hours = " + ranHours.ToString() + " with LocationId = 1");
            //}
            ////Validating in History Table for the above newly added record....
            //string strTblHistory = "Select top 1 * from TCD.ManualLaborHistory where AllocatedManHours = " + ranHours.ToString() + " order by operationTimestamp desc";
            //DataSet ds1 = DBValidation.GetData(strTblHistory);
            //if (ds1.Tables[0].Rows.Count > 0)
            //{
            //    Assert.True(true, "Labour records not found in TCD.ManualLaborHistory Table.Expected - data for columns with Allocated Man Hours = " + ranHours.ToString() + " with LocationId = 2");
            //}
           
            //{
            //    Assert.Fail("Labour records not found in TCD.ManualLaborHistory Table.Expected - data for columns withAllocated Man Hours = "+ ranHours.ToString() + " with LocationId = 2");
            //}
            ////Update the Labour records
            //try
            //{               
            //    string strUpdate = "Update TCD.ManualLabor Set AllocatedManHours = 15 where id = " + ds.Tables[0].Rows[0]["id"].ToString();
            //    DBValidation.UpdateData(strUpdate);              		
            //}
            //catch
            //{
            //    Assert.Fail("Failed to update Manual Labor Allocated Man HOurs");
            //}

        }

        [TestCategory(TestType.regression, "TC03_VerifyAccessforUserRoleTwo")]
        [Test, Description("Test case 40732: RG: Verify the access for User Role 2 on Manual Input Labor for ;")]
        public void TC03_VerifyAccessforUserRoleTwo()
        {
            Runner.DoStep("Logout Admin user", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });
            Runner.DoStep("Login as Operator", () =>
            {
                Page.LoginPage.VerifyLogin(Users.OperatorUser[0], Users.OperatorUser[1]);
            });
            Runner.DoStep("Check for Manual Input tab", () =>
            {
                Thread.Sleep(2000);
                List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;
                if (lstMenuList.Contains("Manual Inputs"))
                {
                    Assert.Fail("Login with user roleid = 2 found Labour tab. Expected - Manual Input Labor link should not be available for User Role 2.");
                }
                else
                {
                    Assert.Pass("Labour tab not visible for user roleid = 2.");
                }
            });                        			
        }

        [TestCategory(TestType.regression, "TC04_VerifyAccessforUserRoleFive")]
        [Test, Description("Test case 40754: RG: Verify the access for User Role 5 on Manual Input Labor for ;")]
        public void TC04_VerifyAccessforUserRoleFive()
        {
            Runner.DoStep("Logout user Admin", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });
            Runner.DoStep("Login as BDManager", () =>
            {
                Page.LoginPage.VerifyLogin(Users.BDManagerUser[0], Users.BDManagerUser[1]);
            });                                  
			Thread.Sleep(2000);
            List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;
            Thread.Sleep(2000);
            Runner.DoStep("Check for Manual input tab", () =>
            {
                if (lstMenuList.Contains("Manual Inputs"))
                {
                    Thread.Sleep(2000);
                    Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
                    Page.ManualInputLabourTabPage.LabourTab.Click();
                    Thread.Sleep(2000);
                    if (null == Page.ManualInputLabourTabPage.LabourTabGrid)
                    {
                        Assert.Fail("Login with Level-5 user. Expected - Labour details in gridview.");
                    }
                    Thread.Sleep(2000);
                    Page.ManualInputLabourTabPage.VerifyUserRoleCreateOption();
                    if (Page.ManualInputLabourTabPage.BtnSave.IsEnabled == true)
                    {
                        Assert.Fail("Login with Level - 5 user.Expected - Manual Input Labor link should not be available for User Role 5.");
                    }
                }
                else
                {
                    Assert.Pass("Login with level-5 user. " +
                                   "Expected - Manual Input Labor link not available for User Role 5.");
                }
            });              
        }

        [TestCategory(TestType.regression, "TC05_VerifyAccessRolefor346789")]
        [Test, Description("Test case 40758: RG: Verify the access for User Role 3/4/6/7/8/9 on Manual Input Labor for ;")]
        public void TC05_VerifyAccessRolefor346789()
        {
            Runner.DoStep("Logout Admin user", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });            
            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.PEngineerUser[0], Users.PEngineerUser[1]);
            userAccess.Add(Users.PManagerUser[0], Users.PManagerUser[1]);
            userAccess.Add(Users.TMBasicUser[0], Users.TMBasicUser[1]);
            userAccess.Add(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]);
            userAccess.Add(Users.EngineerUser[0], Users.EngineerUser[1]);
            userAccess.Add(Users.AdminUser[0], Users.AdminUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {                
                Page.LoginPage.VerifyLogin(pair.Key, pair.Value);                				
                List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;
                Thread.Sleep(3000);
                if (lstMenuList.Contains("Manual Inputs"))
                {
					Thread.Sleep(2000);
                    Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
					Thread.Sleep(1000);
                    Page.ManualInputLabourTabPage.LabourTab.Click();
					Thread.Sleep(2000);
                    Runner.DoStep("Verify access for user "+pair.Key+"", () =>
                    {
                        if (!Page.ManualInputLabourTabPage.LabourTab.IsEnabled)
                        {
                            Assert.Fail("Login with user id " + pair.Key + " Expected - User should navigated to Manual Input Labor page once clicks on the Manual Input labor link.");
                        }
                        Page.ManualInputLabourTabPage.VerifyUserRoleCreateOption();
                        Thread.Sleep(2000);
                        if (!Page.ManualInputLabourTabPage.BtnSave.IsEnabled)
                        {
                            Assert.Fail("Login with user id " + pair.Key + " Expected- User should be able to create a new record once navigated to ManualInput Laborpage. But Actual user unable to create the records.");
                        }
                    });                    
                    Page.PlantSetupPage.TopMainMenu.LogOut();
                }
                else
                {
                    Assert.Fail("Login with user id " + pair.Key + " Expected - Manual Input Labor link should be available.Actual - Manual Input Labor link is not available.");
                }                
            }
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }

        [TestCategory(TestType.regression, "TC06_VerifyAuditTableForInsertAndUpdate")]
        //[Test, Description("Test case 40772: RG: Verify the Audit Table for Insert and Update")]
        public void TC06_VerifyAuditTableForInsertAndUpdate()
        {
            Thread.Sleep(2000);
            Page.ManualInputLabourTabPage.AddLabourDetails("Tunnel Washer1", "Normal", "5");
            Thread.Sleep(1000);
            if (Page.ManualInputLabourTabPage.SuccessMessage.BaseElement.InnerText == "")
            {
                msgSaveButton = "Labour details not created.";
            }
            else
            {
                msgSaveButton = Page.ManualInputLabourTabPage.SuccessMessage.BaseElement.InnerText;
            }
            if (null != Page.ManualInputLabourTabPage.SuccessMessage)
            {
                if (!Page.ManualInputLabourTabPage.SuccessMessage.BaseElement.InnerText.Equals(@"Labour Data Updated SuccessFully"))
                {
                    Assert.Fail("Expected: Labour Data Updated SuccessFully" + " but Actual:" + msgSaveButton);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
            string strCommand = "select id, Locationid, ManHourTypeId AllocatedManHours " +
              " from TCD.ManualLabor where LocationId = 2 and ManHourTypeid = 1  and AllocatedManHours = 5  order by id desc";
            DataSet ds = DBValidation.GetData(strCommand);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Assert.True(true, "Labour records not found in DB.Expected- Allocated Man Hours = 5 with LocationId = 1");
            }
            else
            {
                Assert.Fail("Labour records not found in DB.Expected- Allocated Man Hours = 5 with LocationId = 1");
            }
            //Validating in History Table for the above added newly record....
            string strTblHistory = "Select * from TCD.ManualLaborHistory where LocationId = 2 " +
                                "and ManHourTypeId=1 and AllocatedManHours = 5 order by operationTimestamp desc";
            DataSet ds1 = DBValidation.GetData(strTblHistory);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                Assert.True(true, "Labour records not found in TCD.ManualLaborHistory Table.Expected - data for columns with Allocated Man Hours = 5 with LocationId = 2");
            }
            else
            {
                Assert.Fail("Labour records not found in TCD.ManualLaborHistory Table.Expected - data for columns withAllocated Man Hours = 5 with LocationId = 2");
            }
            //Update the Labour records
            try
            {
                string strUpdate = "Update TCD.ManualLabor Set AllocatedManHours = 15 where id = "+ ds.Tables[0].Rows[0]["id"].ToString();
                DBValidation.UpdateData(strUpdate);
            }
            catch
            {
                Assert.Fail("Failed to update Manual Labor Allocated Man HOurs");
            }
        }

        //[TestCategory(TestType.regression, "TC07_VerifyLocalization")]
        [Test, Description("Test case 34209: RG: Verify the Localization criteria ;")]
        public void TC07_VerifyLocalization()
        {
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.RedFlagTabPage.LanguagePreferred.Focus();
            Page.RedFlagTabPage.LanguagePreferred.SelectByText("Deutsch", true);
            Page.RedFlagTabPage.LanguagePreferred.ScrollToVisible();
            Page.RedFlagTabPage.GeneralTabSaveButton.Click();
            Telerik.ActiveBrowser.RefreshDomTree();
            CloseBrowser();
            TestFixtureSetupBase();
            TestFixture();
            string text = Page.ManualInputLabourTabPage.LabourTab.ChildNodes[0].Content;
            if (Page.ManualInputLabourTabPage.LabourTab.ChildNodes[0].Content == "Labour")
            {
                Assert.Fail("Incorrect label displayed when localization changed to Deutsch language.Expected - in Deutsch language, but Actual content found is -"
                                + Page.ManualInputLabourTabPage.LabourTab.ChildNodes[0].Content);
            }
        }
        
        //[TestCategory(TestType.regression, "TC08_PostLocalization")]
        [Test, Description("Test case 34209: RG: Post Localization ;")]
        public void TC08_PostLocalization()
        {
            //Post Condition to revert back the localization
            Page.PlantSetupPage.TopMainMenu.LogOut();
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.GeneralTab.Click();
            Page.ShiftTabPage.LanguagePreferred.Focus();
            Page.ShiftTabPage.LanguagePreferred.SelectByText("English US", true);
            Page.ShiftTabPage.LanguagePreferred.ScrollToVisible();
            Page.ShiftTabPage.GeneralTabSaveButton.Click();
        }

        [TestCategory(TestType.regression, "TC09_UpdateAndDeleteLaboutData")]
        [Test, Description("Test case : RG: Update and Delete Labour data")]
        public void TC09_UpdateAndDeleteLaboutData()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Page.ManualInputLabourTabPage.LabourTab.Click();
            Page.ManualInputLabourTabPage.DdlLocation.SelectByText("WasherGroupForMILabor", Timeout);
            Page.ManualInputLabourTabPage.DdlLabourTypes.SelectByText("Specialist", Timeout);
            int oldManHours = int.Parse(Page.ManualInputLabourTabPage.AllocatedHours.Value);
            int newManHours;
            Random random = new Random();
            do
            {
                newManHours = random.Next(1, 9);
                Page.ManualInputLabourTabPage.AllocatedHours.TypeText(newManHours.ToString());
            } while (oldManHours == newManHours);
            Thread.Sleep(1000);
            Runner.DoStep("Update the man hours and Save them", () =>
            {
                Page.ManualInputLabourTabPage.BtnSave.Focus();
                Page.ManualInputLabourTabPage.BtnSave.DeskTopMouseClick();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify successful updtaion message", () =>
            {
                if (!Page.ManualInputLabourTabPage.HoursSaveMessage.BaseElement.InnerText.Contains("successfully"))
                {
                    Assert.Fail("Man hours not saved successfully");
                }
            });            
            Runner.DoStep("Delete Labour Data", () =>
            {
                Page.ManualInputLabourTabPage.HoursDelete.Click();
                DialogHandler.YesButton.Click();
            });           
            Runner.DoStep("Verify the successful deletion message", () =>
            {
                if (!Page.ManualInputLabourTabPage.HoursSaveMessage.BaseElement.InnerText.Contains("successfully"))
                {
                    Assert.Fail("Man hours not delete successfully");
                }
            });            
        }        
    }
}
