﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.AppStateHandler;
using Ecolab.CommonUtilityPlugin;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest
{
    public class MaxWasherValidationTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.AddControllerAndWasherGroup();            
        }

        // <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC01_ValidatingTunnelWasherGroups")]
        [TestCategory(TestType.regression, "TC01_ValidatingTunnelWasherGroups")]
        [Test]
        public void TC01_ValidatingTunnelWasherGroups()
        {
            AddTunnelDispenserToAB();
            VerifyAndAddTunnelDispenserToBeckhoff();
            VerifyTunnelDispenserForAB();
        }

        // <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC02_ValidatingAbConventionalWasherGroups")]
        [TestCategory(TestType.regression, "TC02_ValidatingAbConventionalWasherGroups")]
        [Test]
        public void TC02_ValidatingAbConventionalWasherGroups()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABConventionalWasherGroup'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'Add Washer' button of a AB Washer group", () =>
            {
                Page.WashersPage.AddWasher.DeskTopMouseClick();
            });            
            Page.WashersPage.DdlModel.SelectByText(AppState.GetState<WasherState>().GetAllWasherModelSize().FirstOrDefault().WasherModelName,Timeout);
            Page.WashersPage.DdlController.SelectByPartialText("TrialABUltrax", true);
            Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());                      
            Page.WashersPage.LFSWasher.SelectByIndex(0, Timeout);
            //Thread.Sleep(2000);
            Page.WashersPage.Size.SelectByIndex(1, Timeout);
            Random random = new Random();
            Page.WashersPage.PlantWasherNumber.TypeText(random.Next(1, 29999).ToString());
            Page.WashersPage.WasherCapacity.TypeText(random.Next(1, 999).ToString());
            Runner.DoStep("Enter washer details and click Save", () =>
            {
                Page.WashersPage.SaveCoventionalWasher.Click();
            });            
            //Thread.Sleep(8000);
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.PlantWasherNumber.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.SaveCoventionalWasher.Click();
                        //Thread.Sleep(8000);
                    }
                    while (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });
            Runner.DoStep("Check whether the LFS washer number already exists for the washer group or not", () =>
            {
                if (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("lfs washer number already exist"))
                {
                    int count = Page.WashersPage.LFSWasher.ChildNodes.Count;
                    for (int currentValue = 1; currentValue < count; currentValue++)
                    {
                        Page.WashersPage.LFSWasher.SelectByIndex(currentValue, Timeout);
                        Page.WashersPage.SaveCoventionalWasher.Click();
                        //Thread.Sleep(8000);
                        if (!Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("lfs washer number already exist"))
                        {
                            Assert.Fail("LFS value should not be available for a washer");
                        }
                    }
                }           
            });            
        }

        // <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC03_ValidatingBeckhoffConventionalWasherGroups")]
        [TestCategory(TestType.regression, "TC03_ValidatingBeckhoffConventionalWasherGroups")]
        [Test]
        public void TC03_ValidatingBeckhoffConventionalWasherGroups()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialBeckConventionalWasherGroup'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a AB Washer group", () =>
            {
                Page.WashersPage.AddWasher.DeskTopMouseClick();
            });              
            Page.WashersPage.DdlModel.SelectByText(AppState.GetState<WasherState>().GetAllWasherModelSize().FirstOrDefault().WasherModelName, Timeout);
            Page.WashersPage.DdlController.SelectByPartialText("TrialBeckhoffUltrax", true);
            Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());             
            Page.WashersPage.LFSWasher.SelectByIndex(0, Timeout);
            //Thread.Sleep(2000);
            Page.WashersPage.Size.SelectByIndex(1, Timeout);
            Random random = new Random();
            Page.WashersPage.PlantWasherNumber.TypeText(random.Next(1, 29999).ToString());
            Page.WashersPage.WasherCapacity.TypeText(random.Next(1, 999).ToString());
            //Thread.Sleep(2000);
            Page.WashersPage.EndOfFormulaNumber.TypeText(random.Next(1, 127).ToString());
            Runner.DoStep("Enter washer details and click Save", () =>
            {
                Page.WashersPage.SaveCoventionalWasher.Click();
            });            
            //Thread.Sleep(8000);
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.PlantWasherNumber.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.SaveCoventionalWasher.Click();
                        //Thread.Sleep(8000);
                    }
                    while (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });
            Runner.DoStep("Check whether the LFS washer number already exists for the washer group or not", () =>
            {
                if (Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("lfs washer number already exist"))
                {
                    int count = Page.WashersPage.LFSWasher.ChildNodes.Count;
                    for (int currentValue = 1; currentValue < count; currentValue++)
                    {
                        Page.WashersPage.LFSWasher.SelectByIndex(currentValue, Timeout);
                        //Thread.Sleep(2000);
                        Page.WashersPage.EndOfFormulaNumber.TypeText(random.Next(1, 127).ToString());
                        Page.WashersPage.SaveCoventionalWasher.Click();
                        //Thread.Sleep(8000);
                        if (!Page.WashersPage.ErrorMessageConventional.BaseElement.InnerText.ToLower().Contains("lfs washer number already exist"))
                        {
                            Assert.Fail("LFS value should not be available for a washer");
                        }

                    }
                }         
            });               
        }

        // <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC04_DeleteWashersAndWasherGroups")]
        //[TestCategory(TestType.regression, "TC04_DeleteWashersAndWasherGroups")]
        //[Test]
        public void TC04_DeleteWashersAndWasherGroups()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckConventionalWasherGroup")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckConventionalWasherGroup")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            if (Page.WashersPage.WashersListGridTable.Rows.Count != 0)
            {
                int count = Page.WashersPage.WashersListGridTable.Rows.Count;
                for (int currentValue = 0; currentValue < count; currentValue++)
                {
                    Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls()[0].DeskTopMouseClick();
                    Page.WashersPage.DeleteWasherYesButton.Click();
                    Thread.Sleep(1000);
                }
            }

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABConventionalWasherGroup")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABConventionalWasherGroup")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            if (Page.WashersPage.WashersListGridTable.Rows.Count != 0)
            {
                int count = Page.WashersPage.WashersListGridTable.Rows.Count;
                for (int currentValue = 0; currentValue < count; currentValue++)
                {
                    Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls()[0].DeskTopMouseClick();
                    Page.WashersPage.DeleteWasherYesButton.Click();
                    Thread.Sleep(1000);
                }
            }

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABTunnelWasherGroup")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABTunnelWasherGroup")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Thread.Sleep(2000);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckTunnelWasherGroup")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckTunnelWasherGroup")[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Thread.Sleep(2000);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();

            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckConventionalWasherGroup")[0].GetButtonControls()[3].ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckConventionalWasherGroup")[0].GetButtonControls()[3].DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Thread.Sleep(1000);

            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABConventionalWasherGroup")[0].GetButtonControls()[3].ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABConventionalWasherGroup")[0].GetButtonControls()[3].DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Thread.Sleep(1000);

            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABTunnelWasherGroup")[0].GetButtonControls()[3].ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialABTunnelWasherGroup")[0].GetButtonControls()[3].DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Thread.Sleep(1000);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckTunnelWasherGroup")[0].GetButtonControls()[3].ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows("TrialBeckTunnelWasherGroup")[0].GetButtonControls()[3].DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Thread.Sleep(1000);           
        }

        // <summary>
        /// 
        /// </summary>
        [TestCategory(TestType.functional, "TC05_ValidateAssigningDispenserToNewTunnel")]
        [TestCategory(TestType.regression, "TC05_ValidateAssigningDispenserToNewTunnel")]
        [Test]
        public void TC05_ValidateAssigningDispenserToNewTunnel()
        {
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndAWasherGroupForTunnelAvailability();            

            Random random = new Random();

            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroup1'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });            
            Page.WashersPage.DdlModel.Focus();
            Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlController.SelectByPartialText("TrialABUltraxTD1", true);
            Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
            Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
            Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("10");
            Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlPress.Focus();
            Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
            Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
            Runner.DoStep("Enter washer details and click Save", () =>
            {
                Page.WashersPage.BtnSaveTunnel.Click();
            });            
            //Thread.Sleep(8000);
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        //Thread.Sleep(8000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });
            Runner.DoStep("Navigate to 'Washers group' page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            });            
            Thread.Sleep(2000);
            int washerGroupNumber1 = 0;
            DataTable myTable1 = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialBeckTunnelWasherGroup1'");
            foreach (DataRow dr in myTable1.Rows)
            {
                washerGroupNumber1 = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a Beckhoff Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });            
            if (Page.WashersPage.DdlController.InnerText.Contains("TrialABUltraxTD1"))
            {
                Assert.Fail(" 'TrialABUltraxTD1' is not supposed to be available");
            }
            else
            {
                Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlController.SelectByPartialText("TrialBeckhoffEladosSmart1", true);
                Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("13");
                Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
                Runner.DoStep("Enter washer details and click Save", () =>
                {
                    Page.WashersPage.BtnSaveTunnel.Click();
                });                
            }
            //Thread.Sleep(8000);
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        //Thread.Sleep(8000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });

            Runner.DoStep("Navigate to 'Washers group' page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            });             
            //Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of an AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });
            Runner.DoStep("Check whether Dispenser added to Beckhoff washer is available", () =>
            {
                if (Page.WashersPage.DdlController.InnerText.Contains("TrialBeckhoffEladosSmart1"))
                {
                    Assert.Fail(" 'TrialBeckhoffEladosSmart1' is not supposed to be available");
                }
            });

            Runner.DoStep("Navigate to previous page", () =>
            {
                KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
            });            
            //Thread.Sleep(2000);
            Runner.DoStep("Delete the Washer", () =>
            {
                Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().DeskTopMouseClick();
                Page.WashersPage.DeleteWasherYesButton.Click();
            });                        

            //Validating whether a Dispenser is available for a washer if another tunnel-washer attached to it is deleted
            Runner.DoStep("Navigate to 'Washers group' page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            });              
            //Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of an AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });            
            //Thread.Sleep(2000);

            Runner.DoStep("Check whether Dispenser added to AB washer is available", () =>
            {
                if (!Page.WashersPage.DdlController.InnerText.Contains("TrialABUltraxTD1"))
                {
                    Assert.Fail(" 'TrialABUltraxTD1' is not available");
                }
            });            
            //Thread.Sleep(2000);

            Runner.DoStep("Navigate to previous page", () =>
            {
                KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
            });
            Runner.DoStep("Delete the Washer", () =>
            {
                Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().DeskTopMouseClick();
                Page.WashersPage.DeleteWasherYesButton.Click();
                //Thread.Sleep(2000);
            });

            Runner.DoStep("Navigate to 'Washer groups' page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            });            
            //Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of an AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });            
            //Thread.Sleep(2000);
            Runner.DoStep("Check whether Dispenser added to Beckhoff washer is available", () =>
            {
                if (!Page.WashersPage.DdlController.InnerText.Contains("TrialBeckhoffEladosSmart1"))
                {
                    Assert.Fail(" 'TrialBeckhoffEladosSmart1' is not available");
                }
            });               
            //Thread.Sleep(2000);
        }

        public void AddTunnelDispenserToAB()
        {
            Random random = new Random();

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroup'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });            
            Page.WashersPage.DdlModel.Focus();
            Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlController.SelectByPartialText("TrialABUltraxTDI", true);
            Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
            Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
            Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("12");
            Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlPress.Focus();
            Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
            Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
            Runner.DoStep("Enter washer details and click Save", () =>
            {
                Page.WashersPage.BtnSaveTunnel.Click();
            });            
            //Thread.Sleep(8000);
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        //Thread.Sleep(8000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });            
        }

        public void VerifyAndAddTunnelDispenserToBeckhoff()
        {
            Random random = new Random();
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            //Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialBeckTunnelWasherGroup'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a Beckhoff Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });            
            if (Page.WashersPage.DdlController.InnerText.Contains("TrialABUltraxTDI"))
            {
                Assert.Fail(" 'TrialABUltraxTDI' is not supposed to be available");
            }
            else
            {
                Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlController.SelectByPartialText("TrialBeckhoffEladosSmart", true);
                Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("11");
                Page.WashersPage.DdlTransferType.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlPress.SelectByIndex(1, Timeout);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
                Runner.DoStep("Enter washer details and click Save", () =>
                {
                    Page.WashersPage.BtnSaveTunnel.Click();
                });                
            }
            //Thread.Sleep(8000);
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        //Thread.Sleep(8000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });            
        }

        public void VerifyTunnelDispenserForAB()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            //Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroup'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });            
            Runner.DoStep("Check whether Dispenser added to Beckhoff washer is available", () =>
            {
                if (Page.WashersPage.DdlController.InnerText.Contains("TrialBeckhoffEladosSmart"))
                {
                    Assert.Fail(" 'TrialBeckhoffEladosSmart' is not supposed to be available");
                }
            });            
        }
    }
}
