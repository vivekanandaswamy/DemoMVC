﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using NUnit.Framework;
using ArtOfTest.WebAii.Win32.Dialogs;
using System.Threading;
using System.Data;

namespace Ecolab.FunctionalTest
{
    public class PlantSetupUserManagementTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()   
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);

            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.UserManagement.UserManagementTab.Click();
            TestDataCleanup();
        }

        [TestCategory(TestType.functional, "TC01_VerifyAddUser")]
        [TestCategory(TestType.regression, "TC01_VerifyAddUser")]
        [Test]
        public void TC01_VerifyAddUser()
        {
            Runner.DoStep("Verify that the popup is appeared when clicked on 'Add User' button", () =>
            {
                Page.UserManagement.AddUser.Click();
                if (!Page.UserManagement.txtFirstName.IsEnabled)
                {
                    Assert.Fail("Add User popup not appeared");
                }
            });
            //Runner.DoStep("Click on Cancel button", () =>
            //{
            //    Page.UserManagement.Cancel.Click();
            //});            
        }

        [TestCategory(TestType.functional, "TC02_AddUser")]
        [TestCategory(TestType.regression, "TC02_AddUser")]
        [Test]
        public void TC02_AddUser()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.UserManagement.UserManagementTab.Click();
            Thread.Sleep(2000);
            Runner.DoStep("Add a User", () =>
            {
                DeleteAndCreate("Added User", "Test12", "Auto1", "auto@ecolab.com", "9069675467", "12345", "Plant Manager");
            });
            //Page.UserManagement.AddingUser("Auto", "Test12", "Auto1", "auto@gmail.com", "9069675467", "12345", "Adminstrator");
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the User has been added successfully", () =>
            {
                if (null != Page.UserManagement.userManagementMsgDiv)
                {
                    if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
                        .Equals(@"User created successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed");
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
        }

        [TestCategory(TestType.functional, "TC03_VerifyUserInGrid")]
        //[TestCategory(TestType.regression, "TC03_VerifyUserInGrid")]
        [Test]
        public void TC03_VerifyUserInGrid()
        {
            Runner.DoStep("Add a User", () =>
            {
                DeleteAndCreate("Auto", "Test", "Auto2", "test@ecolab.com", "9069675467", "1234", "Adminstrator");
            });            
            //Page.UserManagement.AddingUser("Auto", "Test", "Auto2", "test@gmail.com", "9069675467", "1234", "Adminstrator");
            Thread.Sleep(2000);
            Runner.DoStep("Verify the successful User addition message", () =>
            {
                if (null != Page.UserManagement.userManagementMsgDiv)
                {
                    if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
                        .Equals(@"User created successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed");
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
            Runner.DoStep("Verify the new User in the User's list", () =>
            {
                if (!Page.UserManagement.isRecordExist("Auto2"))
                {
                    Assert.Fail("Auto2" + "record not displayed in user management grid");
                }
            });            
        }

        [TestCategory(TestType.functional, "TC04_VerifyUpdateButton")]
        //[TestCategory(TestType.regression, "TC04_VerifyUpdateButton")]
        [Test]
        public void TC04_VerifyUpdateButton()
        {
            //Runner.DoStep("Add a User if not exists", () =>
            //{
            //    CreateUserIfNotExists("Morgan", "Stanley", "StanleyM", "test@ecolab.com", "9069675467", "1234", "Adminstrator");
            //});            

            CreateUserIfNotExists("Morgan", "Stanley", "StanleyM", "test@ecolab.com", "9069675467", "1234", "Adminstrator");

            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            Runner.DoStep("Click on User update button", () =>
            {
                Page.UserManagement.UserManagementTable.SelectedRows("dirkbr")[0].GetButtonControls()[4].ScrollToVisible();
                Page.UserManagement.UserManagementTable.SelectedRows("dirkbr")[0].GetButtonControls()[4].DeskTopMouseClick();
                //Page.UserManagement.UpdateButton.Click();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the popup has appeared when clicked on Update button", () =>
            {
                if (!Page.UserManagement.txtEditFirstName.IsVisible())
                {
                    Assert.Fail("User Management edit popup not displayed on clicking on update in grid");
                }
            });
            Runner.DoStep("Cancel editing User", () =>
            {
                Page.UserManagement.Cancel.Click();
            });            
            Page.UserManagement.AddUser.ScrollToVisible();
        }

        [TestCategory(TestType.functional, "TC05_VerifyDeleteFunctionality")]
        [TestCategory(TestType.regression, "TC05_VerifyDeleteFunctionality")]
        [Test]
        public void TC05_VerifyDeleteFunctionality()
        {
            //Runner.DoStep("Create a User if not exists", () =>
            //{
            //    CreateUserIfNotExists("Auto", "Test", "Auto2", "test@ecolab.com", "9069675467", "1234", "Adminstrator");
            //});            
            
            //string strUserId = Page.UserManagement.UserManagementTable.SelectedRows("Auto2")[0].GetColumnValues()[3];
            //Page.UserManagement.UserManagementTable.SelectedRows("Auto2")[0].GetButtonControls()[3].ScrollToVisible();
            //Page.UserManagement.UserManagementTable.SelectedRows("Auto2")[0].GetButtonControls()[3].DeskTopMouseClick();

            //Thread.Sleep(2000);
            //DialogHandler.NoButton.Click();
            //Thread.Sleep(2000);
            //if (Page.UserManagement.isRecordExist(strUserId) != true)
            //{
            //    Assert.Fail("User deleted on clicking on NO button in delete confirmation popup");
            //}
            //Page.UserManagement.AddUser.ScrollToVisible();
            //Page.UserManagement.UserManagementTable.SelectedRows("Auto2")[0].GetButtonControls()[3].ScrollToVisible();
            //Page.UserManagement.UserManagementTable.SelectedRows("Auto2")[0].GetButtonControls()[3].DeskTopMouseClick();
            //Thread.Sleep(2000);
            //Runner.DoStep("Delete User", () =>
            //{
            //    DialogHandler.YesButton.Click();
            //});            
            //Thread.Sleep(2000);
            //Runner.DoStep("Verify that the User has been deleted", () =>
            //{
            //    if (Page.UserManagement.isRecordExist(strUserId) == true)
            //    {
            //        Assert.Fail("User not deleted on clicking on YES button in delete confirmation popup");
            //    }
            //});            
            //Page.UserManagement.AddUser.ScrollToVisible();
            Thread.Sleep(2000);
            Page.UserManagement.AddingUser("White", "Nickman", "WhiteNickman", "white@ecolab.com", "8748734", "test", "Plant Engineer");
            int NumnerOfRows = Page.UserManagement.UserManagementTable.Rows.Count();
            //Thread.Sleep(1000);
            //string name = Page.UserManagement.UserManagementTable.Rows.LastOrDefault().GetEditableControls()[1].BaseElement.ChildNodes[0].Attributes[3].Value;            
            for (int i = 1; i < NumnerOfRows; i++)
            {
                //Thread.Sleep(1000);
                if (Page.UserManagement.UserManagementTable.Rows[i].GetEditableControls()[1].BaseElement.ChildNodes[0].Attributes[4].Value.Equals("White"))
                {
                    Page.UserManagement.UserManagementTable.Rows[i].ScrollToVisible();
                    Thread.Sleep(1000);
                    Page.UserManagement.UserManagementTable.Rows[i].GetButtonControls()[3].Focus();
                    Page.UserManagement.UserManagementTable.Rows[i].GetButtonControls()[3].DeskTopMouseClick();
                    Thread.Sleep(2000);
                    DialogHandler.YesButton.Click();
                    Thread.Sleep(2000);
                    if (null != Page.UserManagement.userManagementMsgDiv)
                    {
                        if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
                            .Equals(@"User deleted successfully"))
                        {
                            Assert.Fail("Incorrect error message is displayed Expected - User deleted successfully , Actual - " + Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText);
                        }
                    }
                }
            }
        }

        [TestCategory(TestType.functional, "TC06_VerifyInLineEditing")]
        //[TestCategory(TestType.regression, "TC06_VerifyInLineEditing")]
        [Test]
        public void TC06_VerifyInLineEditing()
        {
            CreateUserIfNotExists("Auto", "Test12", "Auto1", "auto@ecolab.com", "9069675467", "12345", "Adminstrator");
            string strFirtName = Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetColumnValues()[1];
            Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetButtonControls()[2].ScrollToVisible();
            Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetButtonControls()[2].DeskTopMouseClick();
            Runner.DoStep("Inline Edit a User", () =>
            {
                Page.UserManagement.InlineEditingUser("Auto1", "InLine");
                Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetButtonControls()[0].DeskTopMouseClick();
            });
            Runner.DoStep("Verify updation by the updation success message", () =>
            {
                if (null != Page.UserManagement.userManagementMsgDiv)
                {
                    if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
                        .Equals(@"User updated successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed");
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
            Runner.DoStep("Verify the updation by checking the updated value in the User row", () =>
            {
                if (Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetColumnValues()[1] != "InLine")
                {
                    Assert.Fail("Updated value not displayed in grid after inline editing");
                }
            });            
            Page.UserManagement.AddUser.ScrollToVisible();

            CreateUserIfNotExists("Auto", "Test12", "Auto1", "auto@ecolab.com", "9069675467", "12345", "Adminstrator");
            Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].ScrollToVisible();
            Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetButtonControls()[4].DeskTopMouseClick();
            Runner.DoStep("Update a User", () =>
            {
                Page.UserManagement.UpdatingUser("Update", "Auto", "Auto1", "auto@ecolab.com", "9069675467", "123456", "Adminstrator");
            });
            Runner.DoStep("Verify user updation successful message", () =>
            {
                if (null != Page.UserManagement.userManagementMsgDiv)
                {
                    if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
                        .Equals(@"User updated successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed Expected - User updated successfully , Actual - " + Page.UserManagement.userErrorMsg.BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
        }

        [TestCategory(TestType.functional, "TC07_UpdateUser")]
        [TestCategory(TestType.regression, "TC07_UpdateUser")]
        [Test]
        public void TC07_UpdateUser()
        {
            //CreateUserIfNotExists("Auto", "Test12", "Auto1", "auto@ecolab.com", "9069675467", "12345", "Adminstrator");
            //Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].ScrollToVisible();
            //Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetButtonControls()[4].DeskTopMouseClick();
            //Page.UserManagement.UpdatingUser("Update", "Auto", "Auto1", "auto@ecolab.com", "9069675467", "123456", "Adminstrator");
            //if (null != Page.UserManagement.userManagementMsgDiv)
            //{
            //    if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
            //        .Equals(@"User updated successfully"))
            //    {
            //        Assert.Fail("Incorrect error message is displayed Expected - User updated successfully , Actual - " + Page.UserManagement.userErrorMsg.BaseElement.InnerText);
            //    }
            //}
            //else
            //{
            //    Assert.Fail("Error message is not displayed");
            //}
            Thread.Sleep(2000);
            Page.UserManagement.UpdateButton.Focus();
            Page.UserManagement.UpdateButton.Click();
            Page.UserManagement.UpdateEmail.TypeText("TREcolab@ecolab.com");
            Page.UserManagement.EditContact.TypeText("6576228");            
            Page.UserManagement.Save.Focus();
            Page.UserManagement.Save.Click();
            if (null != Page.UserManagement.userManagementMsgDiv)
            {
                if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
                    .Contains(@"User updated successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed Expected - User updated successfully , Actual - " + Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText);
                }
            }
        }

        [TestCategory(TestType.functional, "TC08_VerifyDeletedUserLogin")]
        //[TestCategory(TestType.regression, "TC08_VerifyDeletedUserLogin")]
        [Test]
        public void TC08_VerifyDeletedUserLogin()
        {
            DeleteAndCreate("DeleteUser", "Test123", "Delete1", "delete@ecolab.com", "9069675467", "12345", "Adminstrator");
            //Page.UserManagement.AddingUser("DeleteUser", "Test123", "Delete1", "delete@gmail.com", "9069675467", "12345", "Adminstrator");
            Thread.Sleep(2000);
            Runner.DoStep("Delete User", () =>
            {
                Page.UserManagement.UserManagementTable.SelectedRows("DeleteUser")[0].GetButtonControls()[3].ScrollToVisible();
                Page.UserManagement.UserManagementTable.SelectedRows("DeleteUser")[0].GetButtonControls()[3].DeskTopMouseClick();
                Thread.Sleep(2000);
                DialogHandler.YesButton.Click();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify Deletion", () =>
            {
                if (Page.UserManagement.isRecordExist("Delete1") == true)
                {
                    Assert.Fail("User not deleted on clicking on YES button in delete confirmation popup");
                }
            });
            Runner.DoStep("Logout the user ADMIN", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });            
            Thread.Sleep(2000);

            Page.LoginPage.ClickLoginLink();
            Runner.DoStep("In User Login page, enter the credentials of the user deleted and click on 'Login' button", () =>
            {
                Page.LoginPage.EnterLoginCredentials("Delete1", "12345");
                Page.LoginPage.ClickLoginButton();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the 'The username or password is incorrect' message has appeared", () =>
            {
                if (null != Page.UserManagement.Formerror)
                {
                    string message = Page.UserManagement.Formerror.BaseElement.InnerText;
                    if (!message.Equals(@"The username or password is incorrect."))
                    {
                        Assert.Fail("Incorrect error message is displayed, Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.UserManagement.UserManagementTab.Click();
        }

        [TestCategory(TestType.functional, "TC09_VerifyCreatedUserLogin")]
        //[TestCategory(TestType.regression, "TC09_VerifyCreatedUserLogin")]
        [Test]
        public void TC09_VerifyCreatedUserLogin()
        {
            Page.UserManagement.UserManagementTab.Click();
            Runner.DoStep("Add a user 'CreatedUser'", () =>
            {
                DeleteAndCreate("CreatedUser", "Test123", "create", "create@ecolab.com", "9069675467", "12345", "Adminstrator");
            });            
            //Page.UserManagement.AddingUser("CreatedUser", "Test123", "create", "create@gmail.com", "9069675467", "12345", "Adminstrator");
            Runner.DoStep("Logout the user ADMIN", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the user 'CreatedUser' is able to login", () =>
            {
                Page.LoginPage.VerifyLogin("create", "12345");
                Thread.Sleep(2000);
                if (Page.PlantSetupPage.TopMainMenu.IsNavigateToPlantSetupPageAvailable())
                {
                    Assert.Fail("Login failed with created user - " + "create");
                }
            });
            Runner.DoStep("Logout the user 'CreatedUser'", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });
            Runner.DoStep("Login as user ADMIN", () =>
            {
                Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            });            
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.UserManagement.UserManagementTab.Click();
            Thread.Sleep(2000);
            Runner.DoStep("Delete the user 'CreatedUser'", () =>
            {
                Page.UserManagement.UserManagementTable.SelectedRows("CreatedUser")[0].GetButtonControls()[3].ScrollToVisible();
                Page.UserManagement.UserManagementTable.SelectedRows("CreatedUser")[0].GetButtonControls()[3].DeskTopMouseClick();
                Thread.Sleep(2000);
                DialogHandler.YesButton.Click();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify Deletion", () =>
            {
                if (Page.UserManagement.isRecordExist("create") == true)
                {
                    Assert.Fail("User not deleted on clicking on YES button in delete confirmation popup");
                }
            });            
        }

        [TestCategory(TestType.functional, "TC10_AddUser_Duplicate")]
        //[TestCategory(TestType.regression, "TC10_AddUser_Duplicate")]
        [Test]
        public void TC10_AddUser_Duplicate()
        {
            Page.UserManagement.UserManagementTab.Click();
            Runner.DoStep("Add a User", () =>
            {
                CreateUserIfNotExists("Auto", "Test12", "Auto1", "auto@ecolab.com", "9069675467", "12345", "Adminstrator");
            });
            Runner.DoStep("Try adding another user with same details", () =>
            {
                Page.UserManagement.AddingUser("Auto", "Test12", "Auto1", "auto@ecolab.com", "9069675467", "12345", "Adminstrator");
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the DUPLICATE USER ERROR message has appeared", () =>
            {
                if (null != Page.UserManagement.userErrorMsg)
                {
                    if (!Page.UserManagement.userErrorMsg.BaseElement.InnerText
                        .Contains(@"exists"))
                    {
                        Assert.Fail("Incorrect error message is displayed Expected - User already exists. Please use a different User ID , Actual - " + Page.UserManagement.userErrorMsg.BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });            
            Page.UserManagement.Cancel.Click();
            Thread.Sleep(2000);
            Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetButtonControls()[3].ScrollToVisible();
            Page.UserManagement.UserManagementTable.SelectedRows("Auto1")[0].GetButtonControls()[3].DeskTopMouseClick();
            Thread.Sleep(2000);
            DialogHandler.YesButton.Click();
            Thread.Sleep(2000);
            if (Page.UserManagement.isRecordExist("Auto1") == true)
            {
                Assert.Fail("User not deleted on clicking on YES button in delete confirmation popup");
            }
        }

        private static string[] addContactsData = new string[] { "Mr", "Matthew", "Damon", "Administrator", "Matt@ecolab.com", "123456123", "123456789", "123456789" };

        [TestCategory(TestType.functional, "TC11_AddUserUsingImport")]
        [TestCategory(TestType.regression, "TC11_AddUserUsingImport")]
        [Test]
        public void TC11_AddUserUsingImport()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.ContactsTab.Click();
            Page.ContactsTabPage.AddContacts.Click();
            Page.ContactsTabPage.AddContactsDetails(addContactsData);
            Thread.Sleep(2000);
            if (null != Page.ContactsTabPage.ErrorMsg)
            {
                if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed,Expected: Contact added Successfully" + " but Actual:" + Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }

            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.UserManagement.UserManagementTab.Click();
            Thread.Sleep(2000);
            Page.UserManagement.AddUser.Click();
            Page.UserManagement.ImportContactTab.Click();
            Page.UserManagement.ChooseContact.DeskTopMouseClick();
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.M);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.T);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.T);
            Thread.Sleep(3000);            
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            Thread.Sleep(1000);
            Page.UserManagement.txtPassword.Focus();
            Page.UserManagement.txtPassword.Text = "83648273";
            Thread.Sleep(1000);
            Page.UserManagement.UserRoleImport.SelectByIndex(4, Timeout);
            Thread.Sleep(1000);
            Page.UserManagement.Save.Focus();
            Page.UserManagement.Save.Click();
            Thread.Sleep(2000);
            if (!Page.UserManagement.ImportContactSuccessMsg.BaseElement.InnerText.Contains("successfully"))
            {
                Assert.Fail("Importing Contact wasn't successful");
            }
        }

        [TestCategory(TestType.functional, "TC12_SaveAndCancelFunctionality")]
        [TestCategory(TestType.regression, "TC12_SaveAndCancelFunctionality")]
        [Test]
        public void TC12_SaveAndCancelFunctionality()
        {
            int NumnerOfRows = Page.UserManagement.UserManagementTable.Rows.Count();
            for (int i = 1; i < NumnerOfRows; i++)
            {
                if (Page.UserManagement.UserManagementTable.Rows[i].GetEditableControls()[1].BaseElement.ChildNodes[0].Attributes[4].Value.Contains("matthew"))
                {
                    Page.UserManagement.UserManagementTable.Rows[i].ScrollToVisible();
                    Thread.Sleep(1000);
                    Page.UserManagement.UserManagementTable.Rows[i].GetEditableControls()[1].Focus();
                    Thread.Sleep(2000);
                    Page.UserManagement.UserManagementTable.Rows[i].GetEditableControls()[1].DeskTopMouseClick();
                    Thread.Sleep(2000);
                    KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
                    KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.M);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.T);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.T);
                    Page.ControllerAdvancedSetupPage.Save.Click();
                    Thread.Sleep(2000);
                    if (!Page.UserManagement.ImportContactSuccessMsg.BaseElement.InnerText.Contains("successfully"))
                    {
                        Assert.Fail("Save functionality failed");
                    }
                }
            }

            for (int i = 1; i < NumnerOfRows; i++)
            {
                if (Page.UserManagement.UserManagementTable.Rows[i].GetEditableControls()[1].BaseElement.ChildNodes[0].Attributes[4].Value.Contains("matthew"))
                {
                    Page.UserManagement.UserManagementTable.Rows[i].ScrollToVisible();
                    Thread.Sleep(1000);
                    Page.UserManagement.UserManagementTable.Rows[i].GetEditableControls()[1].Focus();
                    Thread.Sleep(2000);
                    Page.UserManagement.UserManagementTable.Rows[i].GetEditableControls()[1].DeskTopMouseClick();
                    Thread.Sleep(2000);
                    KeyBoardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
                    KeyBoardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Delete);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.M);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.A);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.T);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.T);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.E);
                    KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.W);
                    Page.LabourCostTabPage.BtnCancel.Click();
                    Thread.Sleep(2000);
                    DialogHandler.YesButton.Click();
                }
            }         
        }

        private void TestDataCleanup()
        {
            UserCleanup("Auto");
            UserCleanup("Auto1");
            UserCleanup("Auto2");
            UserCleanup("Auto2");
            UserCleanup("DeleteUser");
            UserCleanup("CreatedUser");
        }

        private void UserCleanup(string userName)
        {
            List<Pages.CommonControls.EcolabDataGridItems> rows = Page.UserManagement.UserManagementTable.SelectedRows(userName);
            if (IsUserExists(userName))
            {
                rows.FirstOrDefault().GetButtonControls()[3].ScrollToVisible();
                rows.FirstOrDefault().GetButtonControls()[3].DeskTopMouseClick();
                Thread.Sleep(2000);
                DialogHandler.YesButton.Click();
            }
        }

        private bool IsUserExists(string userName)
        {
            List<Pages.CommonControls.EcolabDataGridItems> rows = Page.UserManagement.UserManagementTable.SelectedRows(userName);

            if (null != rows && rows.Count > 0)
            {
                return true;
            }

            return false;
        }

        private void DeleteAndCreate(string firstName, string lastName, string userId, string emailId, string contactNumber, string password, string userRole)
        {
            UserCleanup(userId);
            Page.UserManagement.AddingUser(firstName, lastName, userId, emailId, contactNumber, password, userRole);
        }

        private void CreateUserIfNotExists(string firstName, string lastName, string userId, string emailId, string contactNumber, string password, string userRole)
        {
            if (!IsUserExists(userId))
            {
                Page.UserManagement.AddingUser(firstName, lastName, userId, emailId, contactNumber, password, userRole);
            }
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the User has been added successfully", () =>
            {
                if (null != Page.UserManagement.userManagementMsgDiv)
                {
                    if (!Page.UserManagement.userManagementMsgDiv.BaseElement.InnerText
                        .Equals(@"User created successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed");
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
        }       
    }
}
