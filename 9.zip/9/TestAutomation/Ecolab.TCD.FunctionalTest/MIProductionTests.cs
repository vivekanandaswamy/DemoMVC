﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest
{
    class MIProductionTests : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Page.ManualInputProductionTabPage.ProductionTab.Click();
            Page.ManualInputProductionTabPage.ProductionDataTab.Click();
        }

        Random random = new Random();

        /// <summary>s
        /// Tests the fixture tear down.
        /// </summary>
        //protected void TestFixtureTearDown()
        //{
        //    Console.WriteLine("Test Fixture Teardown overriden");
        //    base.TestFixtureTearDown();
        //}

        /// <summary>
        /// Test case 32687: RG:Verify whether New Recording and Current recording is displayed only when user selects three(washergroup,washer and formula)
        /// Test case 32693: RG:Verify "Save" button in Production data
        /// Test case 32704: RG:Verify whether user able to delete the "Current" record
        /// Test case 32725: RG:Verify whether Previous record to the deleted "Current record" is displayed as "CurrentRecord"
        /// Test case 32799: RG:Verify whether user able to add new recording
        /// Test case 34204: RG:Select Washer group and verify whether Formula field gets loaded
        /// Test case 32774: RG:Verify whether Current recording changes as soon as user modifies washer/formula
        /// </summary>
        [TestCategory(TestType.functional, "TC01_AddAndDeleteRecord")]
        [TestCategory(TestType.regression, "TC01_AddAndDeleteRecord")]
        [Test, Description("Test case 32687: RG Verify whether New Recording and Current recording is displayed only when user selects three(washergroup,washer and formula) ;" +
            "Test case 32693: RG Verify 'Save' button in Production data ;" +
            "Test case 32704: RG Verify whether user able to delete the 'Current' record ;" +
            "Test case 32725: RG Verify whether Previous record to the deleted 'Current record' is displayed as 'CurrentRecord' ;" +
            "Test case 32799: RG Verify whether user able to add new recording ;" +
            "Test case 34204: RG Select Washer group and verify whether Formula field gets loaded ;" +
            "Test case 32774: RG Verify whether Current recording changes as soon as user modifies washer/formula ;")]        

        public void TC01_AddUpdateDeleteRecord()
        {                        
            AddAndVerifyABController(random.Next(0, 100000).ToString());
            AddAWasherGroup();
            AddAWasher();
            AddAFormula();

            Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
            Page.ManualInputProductionTabPage.ProductionTab.Click();
            Page.ManualInputProductionTabPage.ProductionDataTab.Click();
            //Page.ManualInputProductionTabPage.WasherGroup.SelectByIndex(0, Timeout);        
            //Page.ManualInputProductionTabPage.WasherGroup.SelectByIndex(1, Timeout);            
            //Page.ManualInputProductionTabPage.WasherGroupClick.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.WasherGroupElement1.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.WasherGroupElement2.DeskTopMouseClick();                 

            Page.ManualInputProductionTabPage.Washer.SelectByPartialText("Production Washer", true);
            Page.ManualInputProductionTabPage.Formula.SelectByIndex(1, Timeout);
            Page.ManualInputProductionTabPage.NewValue.Focus();
            Page.ManualInputProductionTabPage.NewValue.Click();
            KeyBoardSimulator.SetNumeric("78");
            //Page.ManualInputProductionTabPage.NewValue.TypeText(random.Next(50,80).ToString());
            Runner.DoStep("Enter Production details and click on Add button", () =>
            {
                Page.ManualInputProductionTabPage.Add.DeskTopMouseClick();
            });
            Thread.Sleep(1000);
            Runner.DoStep("Verify successful addition message", () =>
            {
                if (!Page.ManualInputProductionTabPage.PostDeleteMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Production data not created");
                }
            });
            Page.ManualInputProductionTabPage.ValueInTable.Click();
            Page.ManualInputProductionTabPage.ValueInTable.SetText("91");
            Runner.DoStep("Edit some values and click Save", () =>
            {
                Page.ManualInputProductionTabPage.Save.Click();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Verify successful updation message", () =>
            {
                if (!Page.ManualInputProductionTabPage.PostDeleteMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Value not updated");
                }
            });
            Page.ManualInputBatchTabPage.BatchDataTab.Click();
            Page.ManualInputProductionTabPage.ProductionDataTab.Click();
            //Page.ManualInputProductionTabPage.WasherGroupClick.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.WasherGroupElement1.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.WasherGroupElement2.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.Formula.SelectByIndex(1, Timeout);
            Page.ManualInputProductionTabPage.Washer.SelectByPartialText("Production Washer", true);
            Page.ManualInputProductionTabPage.Formula.SelectByIndex(1, Timeout);
            Page.ManualInputProductionTabPage.Search.Click();
            Page.ManualInputProductionTabPage.ValueInTable.Click();
            Page.ManualInputProductionTabPage.ValueInTable.SetText("65");
            Page.LabourCostTabPage.BtnCancel.Click();
            //if (Page.ManualInputProductionTabPage.ValueInTable)
            //{
            //    Assert.Fail("Table grid is visible even after clicking on Cancel button");
            //}
            Page.ManualInputBatchTabPage.BatchDataTab.Click();
            Page.ManualInputProductionTabPage.ProductionDataTab.Click();
            //Page.ManualInputProductionTabPage.WasherGroup.SelectByIndex(1, Timeout);
            //Page.ManualInputProductionTabPage.Washer.SelectByIndex(1, Timeout);
            //Page.ManualInputProductionTabPage.WasherGroupClick.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.WasherGroupElement1.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.WasherGroupElement2.DeskTopMouseClick();
            //Page.ManualInputProductionTabPage.Formula.SelectByIndex(1, Timeout);
            Page.ManualInputProductionTabPage.Washer.SelectByPartialText("Production Washer", true);
            Page.ManualInputProductionTabPage.Formula.SelectByIndex(1, Timeout);
            Page.ManualInputProductionTabPage.Search.Click();
            Thread.Sleep(2000);
            Runner.DoStep("Delete a record and verify it", () =>
            {
                Page.ManualInputProductionTabPage.ProductionTable.Rows.FirstOrDefault().Focus();
                Page.ManualInputProductionTabPage.ProductionTable.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().DeskTopMouseClick();
                Thread.Sleep(1000);
                if (!Page.ManualInputProductionTabPage.PostDeleteMessage.BaseElement.InnerText.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Production data not deleted");
                }
            });

            //Page.ManualInputProductionTabPage.NewValue.Value = "";
            //Page.ManualInputProductionTabPage.NewValue.TypeText(random.Next(50, 80).ToString());
            //Page.ManualInputProductionTabPage.Save.Click();

            //HtmlControl successMsg = Page.ManualInputProductionTabPage.Message;
            //if (null == successMsg)
            //{
            //    Assert.Fail("Success message is not displayed after manual input production data is saved");
            //}
           
            //{
            //    if (!Page.ManualInputProductionTabPage.IsMessage("Saved successfully"))
            //    {
            //        Assert.Fail("After saving manual input production data Expected:Saved successfully,Actual:{0}", successMsg.BaseElement.InnerText);
            //    }

            //}

            //Page.ManualInputProductionTabPage.NewValue.TypeText("13");
            //Page.ManualInputProductionTabPage.Save.Click();

            //string lastValue = Page.ManualInputProductionTabPage.GetlastValue;
            //if (!Page.ManualInputProductionTabPage.IsLastValue("13"))
            //{
            //    Assert.Fail("Last value is incorrectly displayed Expected:13 , Actual:{0}", lastValue);
            //}

            //DataRowCollection dbValues = DBValidation.DataRows(@"select top 1 * from ManualProduction order by ProductionId desc");

            //if (Convert.ToBoolean(dbValues[0].ItemArray[6]))
            //{
            //    Assert.Fail("Database is not updated after production data is added through manual input");
            //}

            //Page.ManualInputProductionTabPage.DeleteLastValue.DeskTopMouseClick();
            //DialogHandler.YesButton.DeskTopMouseClick();

            //lastValue = Page.ManualInputProductionTabPage.GetlastValue;
            //if (!Page.ManualInputProductionTabPage.IsLastValue("12"))
            //{
            //    Assert.Fail("Last value is incorrectly displayed Expected:12 , Actual:{0}", lastValue);
            //}

            //dbValues = DBValidation.DataRows(@"select top 1 * from ManualProduction order by ProductionId desc");

            //if(!Convert.ToBoolean(dbValues[0].ItemArray[6]))
            //{
            //    Assert.Fail("Database is not updated after production data is deleted through manual input");
            //}

        }

        /// <summary>
        /// Test case 32783: RG: Verify only mentioned users are able to enter the data into ManualInput production data page
        /// Test case 32784
        /// </summary>
        [TestCategory(TestType.bvt, "TC02_VerificationforManualInputTAB")]
        [TestCategory(TestType.regression, "TC02_VerificationforManualInputTAB")]
        [TestCategory(TestType.functional, "TC02_VerificationforManualInputTAB")]
        [Test, Description("Test case 32783: RG: Verify only mentioned users are able to enter the data into ManualInput production data page ;" +
            "Test case 32784 ;")]
        public void TC02_VerificationforManualInputTAB()
        {
            Runner.DoStep("Logout Admin from the Main menu", () => Page.PlantSetupPage.TopMainMenu.LogOut());

            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.CAManagerUser[0], Users.CAManagerUser[1]);
            userAccess.Add(Users.BDManagerUser[0], Users.BDManagerUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {
                Runner.DoStep(pair.Key + " login", () => Page.LoginPage.VerifyLogin(pair.Key, pair.Value));
                List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;
                if (lstMenuList.Contains("Manual Inputs"))
                {
                    /*Runner.DoStep("Navigate "+pair.Key+" to Manual input labor page when clicked on Manual input labor link", ()=>
                    Assert.Fail("Login with user id " + pair.Key + " Expected - User should navigated to Manual Input Labor page once clicks on the Manual Input labor link."));*/
                    Runner.DoStep(pair.Key + " logout", () => Page.PlantSetupPage.TopMainMenu.LogOut());
                }
                else
                {
                    Runner.DoStep(pair.Key + " logout", () => Page.PlantSetupPage.TopMainMenu.LogOut());
                }
            }
        }

        /// <summary>
        /// Test case 32783: RG: Verify only mentioned users are able to enter the data into ManualInput production data page
        /// Test case 34220: RG:Verify only mentioned users are able to enter the data into ManualInput batch data page
        /// </summary>
        [TestCategory(TestType.functional, "TC03_UserRoleVerification")]
        //[TestCategory(TestType.regression, "TC03_UserRoleVerification")]
        [Test, Description("Test case 32783: RG Verify only mentioned users are able to enter the data into ManualInput production data page ;" +
                           "Test case 34220: RG:Verify only mentioned users are able to enter the data into ManualInput batch data page ;")]
        public void TC03_UserRoleVerification()
        {
            Runner.DoStep("Logout Admin from the Main menu", () => Page.PlantSetupPage.TopMainMenu.LogOut());
            Dictionary<string, string> userAccess = new Dictionary<string, string>();
            userAccess.Add(Users.PEngineerUser[0], Users.PEngineerUser[1]);
            userAccess.Add(Users.PManagerUser[0], Users.PManagerUser[1]);
            foreach (KeyValuePair<string, string> pair in userAccess)
            {
                Runner.DoStep(pair.Key + " login", () => Page.LoginPage.VerifyLogin(pair.Key, pair.Value));
                List<string> lstMenuList = Page.PlantSetupPage.TopMainMenu.MenuItemsList;

                if (lstMenuList.Contains("Manual Inputs"))
                {
                    Runner.DoStep("Verifying available tabs for the user -> " + pair.Key, () =>
                   {
                       Page.PlantSetupPage.TopMainMenu.NavigateToManualInput();
                       Page.ManualInputProductionTabPage.ProductionTab.Click();
                       Page.ManualInputProductionTabPage.ProductionDataTab.Click();

                       //Page.ManualInputProductionTabPage.WasherGroup.SelectByText("Tunnel-Washer2", Timeout);
                       //Page.ManualInputProductionTabPage.WasherGroup.SelectByPartialText("Group", true);
                       Page.ManualInputProductionTabPage.WasherGroup.SelectByIndex(1, Timeout);
                       //Page.ManualInputProductionTabPage.Washer.SelectByText(Page.ManualInputProductionTabPage.Washer.Options[1].Text, Timeout);
                       //Page.ManualInputProductionTabPage.Formula.SelectByText(Page.ManualInputProductionTabPage.Formula.Options[1].Text, Timeout);
                   });
                    if (Page.ManualInputProductionTabPage.Save.IsEnabled)
                    {
                        Assert.Fail("Login with user id " + pair.Key + " Expected - 'Save' button is not enabled for the user to save data on 'Production Data' page");
                    }

                    Page.ManualInputBatchTabPage.BatchDataTab.Click();

                    if (Page.ManualInputProductionTabPage.Save.IsEnabled)
                    {
                        Assert.Fail("Login with user id " + pair.Key + " Expected - 'Save' button is not enabled for the user to save data on 'Batch Data' page");
                    }

                    Runner.DoStep(pair.Key + " logout", () => Page.PlantSetupPage.TopMainMenu.LogOut());
                }
                else
                {
                    Assert.Fail("Login with user id " + pair.Key + " Expected - User should navigated to Manual Input Labor page once clicks on the Manual Input labor link.");
                    Runner.DoStep(pair.Key + " logout", () => Page.PlantSetupPage.TopMainMenu.LogOut());
                }
            }
        }

        private void AddAndVerifyABController(string controllerNumber)
        {
            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.AddControllerButton.Click();
            Runner.DoStep("Select dispenser model and type", () =>
            {
                Page.ControllerGeneralSetupTabPage.ControllerModel.SelectByText("Ultrax 6/12/16", Timeout);
                Page.ControllerGeneralSetupTabPage.ControllerType.SelectByText("Allen Bradley", Timeout);
            });
            Runner.DoStep("Enter dispenser details", () =>
            {
                Page.ControllerGeneralSetupTabPage.ABDispenserName.TypeText("Production Dispenser");
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.DeskTopMouseClick();
                Page.ControllerGeneralSetupTabPage.UltraxBeckDispenserNumber.TypeText(controllerNumber);
                Page.ControllerGeneralSetupTabPage.OPCServerUltraxAB.DeskTopMouseClick();
                KeyBoardSimulator.SetNumeric("1");
                
                Page.ControllerGeneralSetupTabPage.ABDispenserSerialNumber.TypeText(DateTime.Now.ToString());
            });
            Runner.DoStep("Save dispenser", () =>
            {
                if (!Page.ControllerSetupPage.IsSaveButtonEnabled())
                {
                    Page.ControllerSetupPage.Save.DeskTopMouseClick();
                }
                Page.ControllerSetupPage.Save.DeskTopMouseClick();
            });            
            Thread.Sleep(2000);
            Runner.DoStep("Verify addition of dispenser", () =>
            {
                string message = Page.ControllerSetupPage.ControllerAddMessage.BaseElement.InnerText;

                if (null != message)
                {
                    if (!message.ToLower().Contains("successfully"))
                    {
                        Assert.Fail("Message incorrect after controller addition. Expected Message : Controller Saved Successfully, Actual Message: {0}", message);
                    }
                }
            });     
        }

        private void AddAWasherGroup()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);            
            string wgNumberSave = random.Next(200).ToString();            
            Page.WasherGroupPage.BtnAddWasherGroup.DeskTopMouseClick();                        
            Page.WasherGroupPage.TxtGroupName.SetText("ProductionWG");
            Page.WasherGroupPage.BtnSaveAdd.Focus();
            Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            Thread.Sleep(2000);
            if (null != Page.WasherGroupPage.ErrorMessage)
            {
                string message = Page.WasherGroupPage.ErrorMessage.BaseElement.InnerText;
                if (!message.ToLower().Contains("successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed,Expected: Washer Group Created successfully."
                                    + " but Actual:" + message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
        }

        private void AddAWasher()
        {
            Runner.DoStep("Click on 'Add Washer' button of a AB Washer group", () =>
            {
                Page.WashersTunnelGeneralPage.AddNewWasher.Click();
            });
            Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlController.SelectByPartialText("Production Dispenser", true);
            Page.WashersPage.TxtName.TypeText("Production Washer");
            Page.WashersPage.LFSWasher.SelectByIndex(0, Timeout);
            //Thread.Sleep(2000);
            Page.WashersPage.Size.SelectByIndex(1, Timeout);
            Random random = new Random();
            Page.WashersPage.PlantWasherNumber.TypeText(random.Next(1, 29999).ToString());
            Page.WashersPage.WasherCapacity.TypeText(random.Next(1, 999).ToString());
            Runner.DoStep("Enter washer details and click Save", () =>
            {
                Page.WashersPage.SaveCoventionalWasher.Click();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Verify addition of washer", () =>
            {
                string message = Page.WashersPage.AddWasherMsg.BaseElement.InnerText.ToLower();

                if (null != message)
                {
                    if (!message.ToLower().Contains("successfully"))
                    {
                        Assert.Fail("Message incorrect after controller addition. Expected Message : Controller Saved Successfully, Actual Message: {0}", message);
                    }
                }
            });    
        }

        private void AddAFormula()
        {
            Thread.Sleep(2000);
            int randNumb = random.Next(1, 127);
            Page.WasherGroupFormulasPage.FormulaTab.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Thread.Sleep(2000);
            Page.WasherGroupFormulasPage.AddingFormula(randNumb.ToString(), "100", "0", "0");
            Thread.Sleep(3000);
            Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.Focus();
            if (null != Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg)
            {
                string message = Page.WasherGroupFormulasPage.FormulaCreationSuccessMsg.BaseElement.InnerText;
                if (!message.Contains(@"successfully"))
                {
                    Assert.Fail("Incorrect error message is displayed, Actual: {0}", message);
                }
            }
            else
            {
                Assert.Fail("Error message is not displayed");
            }
        }
    }
}
