﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.Pages.CommonControls;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.FunctionalTest.BVT
{
    public class BVTTests : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }


       
        [TestCategory(TestType.bvt, "TC01_VerifyPlantSetupGeneralTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to General tab. ;")]
        public void TC01_VerifyPlantSetupGeneralTabNavigation()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Runner.DoStep("Verify the 'General' Tab after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.GeneralTab.Click();
            });

            if (Page.ChemicalsTabPage.GeneralTabActiveStatus.ChildNodes[0].InnerText == "General")
            {
                Assert.True(Page.ChemicalsTabPage.GeneralTabActiveStatus.ChildNodes[0].InnerText == "General", "Verified General tab details selected by default");
            }
            else
            {
                Assert.Fail("Verification Failed, General Tab details not selected by default");
            }

        }

      
        [TestCategory(TestType.bvt, "TC02_VerifyPlantSetupChemicalsTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Chemicals Tab Page. ;")]
        public void TC02_VerifyPlantSetupChemicalsTabNavigation()
        {
            Runner.DoStep("Verify 'Chemicals' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.ChemicalsTab.Click();
            });

            if (Page.ChemicalsTabPage.BtnAddChemical.IsVisible())
            {
                Assert.True(true, "Chemicals' Tab is displayed");
            }
            else
            {
                Assert.Fail("Chemicals' Tab is NOT displayed");
            }

        }

       
        [TestCategory(TestType.bvt, "TC03_VerifyPlantSetupFormulaListTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to FormulaList Tab Page. ;")]
        public void TC03_VerifyPlantSetupFormulaListTabNavigation()
        {
            Runner.DoStep("Verify 'FormulaList' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
            });

            if (Page.FormulasTabPage.AddFormula.IsVisible())
            {
                Assert.True(true, "FormulaList' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'FormulaList' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC04_VerifyPlantSetupCustomerTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Plant Customer Tab Page. ;")]
        public void TC04_VerifyPlantSetupCustomerTabNavigation()
        {

            Runner.DoStep("Verify 'Plant Customer' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.CustomerTab.Click();
            });

            if (Page.CustomerTabPage.AddCustomerButton.IsVisible())
            {
                Assert.True(true, " 'Plant Customer' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Plant Customer' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC05_VerifyPlantSetupRedFlagTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to RedFlag Tab Page. ;")]
        public void TC05_VerifyPlantSetupRedFlagTabNavigation()
        {

            Runner.DoStep("Verify 'Red Flag' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.RedFlagTab.Click();
            });

            if (Page.RedFlagTabPage.BtnAddRedFlag.IsVisible())
            {
                Assert.True(true, " 'Red Flag' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Red Flag' Tab is NOT displayed");
            }
        }

        
        [TestCategory(TestType.bvt, "TC06_VerifyPlantSetupUtilityFactorsTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Utility Factors Tab Page. ;")]
        public void TC06_VerifyPlantSetupUtilityFactorsTabNavigation()
        {

            Runner.DoStep("Verify 'Utility Factors' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.UtilityTab.Click();
            });

            if (Page.UtilitySetupPage.TxtColdTemp.IsVisible())
            {
                Assert.True(true, " 'Utility Factors' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Utility Factors' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC07_VerifyPlantSetupCleanSideTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Clean Side Tab Page. ;")]
        public void TC07_VerifyPlantSetupCleanSideTabNavigation()
        {

            Runner.DoStep("Verify 'Clean Side' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.CleanSideTab.Click();
            });

            if (Page.DryerTabPage.AddDryerGroup.IsVisible())
            {
                Assert.True(true, " 'Clean Side' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Clean Side' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC08_VerifyPlantSetupUserManagementTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to User Management Tab Page. ;")]
        public void TC08_VerifyPlantSetupUserManagementTabNavigation()
        {

            Runner.DoStep("Verify 'User Management' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.UserManagement.UserManagementTab.Click();
            });

            if (Page.UserManagement.AddUser.IsVisible())
            {
                Assert.True(true, " 'User Management' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'User Management' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC09_VerifyPlantSetupDashboardSetupTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Dashboard Setup Tab Page. ;")]
        public void TC09_VerifyPlantSetupDashboardSetupTabNavigation()
        {

            Runner.DoStep("Verify 'Dashboard Setup' Tab is displayed after clicking the PlantSetUp SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.DashboardSetupTab.Click();
            });

            if (Page.DashboardSetupTabPage.AddDashboard.IsVisible())
            {
                Assert.True(true, " 'Dashboard Setup' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Dashboard Setup' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC10_VerifyDispenserSetupTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Dispenser Setup Tab Page. ;")]
        public void TC10_VerifyDispenserSetupTabNavigation()
        {
            Runner.DoStep("Verify 'Dispenser Setup' Tab is displayed after clicking the Dispenser Setup SubMenu from SetUp tab", () =>
            {
                Page.LoginPage.TopMainMenu.NavigateToDispenserSetupPage();
            });

            if (Page.ControllerSetupPage.IsAddControllerPresent)
            {
                Assert.True(true, " 'Dispenser Setup' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Dispenser Setup' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC11_VerifyWasherGroupsTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Washer Groups Tab Page. ;")]
        public void TC11_VerifyWasherGroupsTabNavigation()
        {

            Runner.DoStep("Verify 'Washer Groups' Tab is displayed after clicking the Washer Groups SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            });

            if (Page.WasherGroupPage.BtnAddWasherGroup.IsVisible())
            {
                Assert.True(true, " 'Washer Groups' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Washer Groups' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC12_VerifyWashersTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Washers Tab Page. ;")]
        public void TC12_VerifyWashersTabNavigation()
        {

            Runner.DoStep("Verify 'Washers' Tab is displayed after clicking the Washers SubMenu from SetUp tab", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWashersPage();
            });

            if (Page.WashersPage.tabWasher.IsVisible())
            {
                Assert.True(true, " 'Washers' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Washers' Tab is NOT displayed");
            }
        }

        
        [TestCategory(TestType.bvt, "TC13_VerifyStorageTanksTabNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Storage Tanks Tab Page. ;")]
        public void TC13_VerifyStorageTanksTabNavigation()
        {
            Runner.DoStep("Verify 'Storage Tanks' Tab is displayed after clicking the Storage Tanks SubMenu from SetUp tab", () =>
            {
                Page.LoginPage.TopMainMenu.NavigateToStorageTanksPage();
            });

            if (Page.StorageTanksTabPage.AddStorageTanks.IsVisible())
            {
                Assert.True(true, " 'Storage Tanks' Tab is displayed");
            }
            else
            {
                Assert.Fail(" 'Storage Tanks' Tab is NOT displayed");
            }
        }

       
        [TestCategory(TestType.bvt, "TC14_VerifyProductionSummaryReportNavigation")]
        [Test, Description("Test case: Reports -> Verify that the User is navigated to Production Summary Page. ;")]
        public void TC14_VerifyProductionSummaryReportNavigation()
        {
            Page.ReportsTabPage.ReportsTab.Click();
            Runner.DoStep("Verify Production Summary Report Navigation", () =>
            {
                if (!Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower().Contains("production summary"))
                {
                    Assert.Fail("Production Summary link is not working");
                }
            });
        }

       
        [TestCategory(TestType.bvt, "TC15_VerifyProductionDetailsReportNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Production Details Tab Page. ;")]
        public void TC15_VerifyProductionDetailsReportNavigation()
        {
            Runner.DoStep("Verify Production Details Report Navigation", () =>
            {
                Page.ReportsTabPage.ProductEfficiencyTab.MouseHover();
                Page.ReportsTabPage.ProductionDetailsLink.Click();
                Thread.Sleep(2000);
                if (Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower() != "production")
                {
                    Assert.Fail("production details link is not working");
                }
            });
        }
       
        [TestCategory(TestType.bvt, "TC16_VerifyAlarmSummaryReportNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Alarm Summary Page. ;")]
        public void TC16_VerifyAlarmSummaryReportNavigation()
        {
            Runner.DoStep("Verify Alarm Summary Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.DeskTopMouseClick();
                Thread.Sleep(3000);
                if (!Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower().Contains("alarms summary"))
                {
                    Assert.Fail("alarms summary link is not working");
                }
            });
        }

       
        [TestCategory(TestType.bvt, "TC17_VerifyAlarmDetailsReportNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Alarm details Tab Page. ;")]
        public void TC17_VerifyAlarmDetailsReportNavigation()
        {
            Runner.DoStep("Verify Alarm details Report Navigation", () =>
            {
                Page.ReportsTabPage.WashingProcessValidationTab.MouseHover();
                Page.ReportsTabPage.AlarmDetails.Click();
                if (!Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower().Contains("alarms details"))
                {
                    Assert.Fail("alarms details link is not working");
                }
            });
        }

       
        [TestCategory(TestType.bvt, "TC18_VerifyChemicalConsumptionReportNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Chemical Consumption Page. ;")]
        public void TC18_VerifyChemicalConsumptionReportNavigation()
        {
            Runner.DoStep("Verify Chemical Consumption Report Navigation", () =>
            {
                Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
                Page.ReportsTabPage.ChemicalConsumptionLink.Click();
                if (!Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower().Contains("chemical consumption"))
                {
                    Assert.Fail("chemical consumption link is not working");
                }
            });
        }

       
        [TestCategory(TestType.bvt, "TC19_VerifyChemicalInventoryReportNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Chemical Inventory Page. ;")]
        public void TC19_VerifyChemicalInventoryReportNavigation()
        {
            Runner.DoStep("Verify Chemical Inventory Report Navigation", () =>
            {
                Page.ReportsTabPage.ResourcesUtilizationTab.MouseHover();
                Page.ReportsTabPage.ChemicalInventoryLink.Click();
                if (!Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower().Contains("chemical inventory"))
                {
                    Assert.Fail("chemical inventory link is not working");
                }
            });
        }

      
        [TestCategory(TestType.bvt, "TC20_VerifyOpeartionSummaryReportNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to Opeartion Summary Page. ;")]
        public void TC20_VerifyOpeartionSummaryReportNavigation()
        {
            Runner.DoStep("Verify Operation Summary Report Navigation", () =>
            {
                Page.ReportsTabPage.ResourcesUtilizationTab.DeskTopMouseClick();
                Thread.Sleep(3000);
                if (!Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower().Contains("operations summary"))
                {
                    Assert.Fail("Operations Summary link is not working");
                }
            });
        }

       
        [TestCategory(TestType.bvt, "TC21_VerifyUserLogReportNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify that the User is navigated to User Log Page. ;")]
        public void TC21_VerifyUserLogReportNavigation()
        {
            Runner.DoStep("Verify User Log  Report Navigation", () =>
            {
                Page.ReportsTabPage.EcolabInternalTab.DeskTopMouseClick();
                Thread.Sleep(3000);
                if (!Page.ReportsTabPage.ReportNameBreadCrumb.BaseElement.InnerText.ToLower().Contains("user log"))
                {
                    Assert.Fail("User Log link is not working");
                }
            });
        }

       
        [TestCategory(TestType.bvt, "TC22_VerifyHomepageNavigation")]
        [Test, Description("Test case: Plant Setup -> Verify Homepage Navigation when click on Ecolab Envision. ;")]
        public void TC22_VerifyHomepageNavigation()
        {
            Runner.DoStep("Verify Homepage Navigation when click on Ecolab Envision", () =>
            {

                Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
                Page.DashboardSetupTabPage.HomePageVerification.DeskTopMouseClick();
                Thread.Sleep(1000);
                string ss = Page.DashboardSetupTabPage.HomePageOverview.BaseElement.InnerText.ToLower();
                if (!Page.DashboardSetupTabPage.HomePageOverview.BaseElement.InnerText.ToLower().Contains("overview"))
                {
                    Assert.Fail("Home Page is not Loaded Correctly When clicked on Ecolab Envision");
                }
            });
        }

    }
}
