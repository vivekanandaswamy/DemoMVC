﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.FunctionalTest.Config
{
    public class Users : BaseSetings
    {
        private static Users defaultInstance = new Users();
        private static string settingsFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Config");
        private static string settingsFile;

        public static Users Default
        {
            get
            {
                settingsFile = Path.Combine(settingsFilePath, "Users.xml");
                return defaultInstance;
            }

        }

        List<string> adminUser = new List<string>();
        public ReadOnlyCollection<string> AdminUser
        {
            get
            {
                adminUser.Add("Admin");
                adminUser.Add("test");
                List<string> value = GetUser(settingsFile, "ADM").ToList();
                if (null != value)
                {
                    adminUser = value;

                }
                return adminUser.AsReadOnly();
            }
        }

        List<string> trEcolabUser = new List<string>();
        public ReadOnlyCollection<string> TREcolabUser
        {
            get
            {
                trEcolabUser.Add("TREcolab");
                trEcolabUser.Add("test");
                List<string> value = GetUser(settingsFile, "TRE").ToList();
                if (null != value)
                {
                    trEcolabUser = value;

                }
                return trEcolabUser.AsReadOnly();
            }
        }

        List<string> engineerUser = new List<string>();
        public ReadOnlyCollection<string> EngineerUser
        {
            get
            {
                engineerUser.Add("Engineer");
                engineerUser.Add("test");
                List<string> value = GetUser(settingsFile, "ENG").ToList();
                if (null != value)
                {
                    engineerUser = value;

                }
                return engineerUser.AsReadOnly();
            }
        }

        List<string> tempEcolabUser = new List<string>();
        public ReadOnlyCollection<string> TempEcolabUser
        {
            get
            {
                tempEcolabUser.Add("TempEcolab");
                tempEcolabUser.Add("test");
                List<string> value = GetUser(settingsFile, "TRE").ToList();
                if (null != value)
                {
                    engineerUser = value;

                }
                return engineerUser.AsReadOnly();
            }
        }

        List<string> trCustomerUser = new List<string>();
        public ReadOnlyCollection<string> TRCustomerUser
        {
            get
            {
                trCustomerUser.Add("TRCustomer");
                trCustomerUser.Add("test");
                List<string> value = GetUser(settingsFile, "TRC").ToList();
                if (null != value)
                {
                    trCustomerUser = value;

                }
                return trCustomerUser.AsReadOnly();
            }
        }

        List<string> tmAdvancedUser = new List<string>();
        public ReadOnlyCollection<string> TMAdvancedUser
        {
            get
            {
                tmAdvancedUser.Add("TMAdvanced");
                tmAdvancedUser.Add("test");
                List<string> value = GetUser(settingsFile, "TMA").ToList();
                if (null != value)
                {
                    tmAdvancedUser = value;

                }
                return tmAdvancedUser.AsReadOnly();
            }
        }

        List<string> tmBasicUser = new List<string>();
        public ReadOnlyCollection<string> TMBasicUser
        {
            get
            {
                tmBasicUser.Add("TMBasic");
                tmBasicUser.Add("test");
                List<string> value = GetUser(settingsFile, "TMB").ToList();
                if (null != value)
                {
                    tmBasicUser = value;

                }
                return tmBasicUser.AsReadOnly();
            }
        }

        List<string> bdManagerUser = new List<string>();
        public ReadOnlyCollection<string> BDManagerUser
        {
            get
            {
                bdManagerUser.Add("BDManager");
                bdManagerUser.Add("test");
                List<string> value = GetUser(settingsFile, "BDM").ToList();
                if (null != value)
                {
                    bdManagerUser = value;

                }
                return bdManagerUser.AsReadOnly();
            }
        }

        List<string> caManagerUser = new List<string>();
        public ReadOnlyCollection<string> CAManagerUser
        {
            get
            {
                caManagerUser.Add("CAManager");
                caManagerUser.Add("test");
                List<string> value = GetUser(settingsFile, "CAM").ToList();
                if (null != value)
                {
                    caManagerUser = value;

                }
                return caManagerUser.AsReadOnly();
            }
        }

        List<string> pmanagerUser = new List<string>();
        public ReadOnlyCollection<string> PManagerUser
        {
            get
            {
                pmanagerUser.Add("PManager");
                pmanagerUser.Add("test");
                List<string> value = GetUser(settingsFile, "PM").ToList();
                if (null != value)
                {
                    pmanagerUser = value;

                }
                return pmanagerUser.AsReadOnly();
            }
        }

        List<string> pEngineerUser = new List<string>();
        public ReadOnlyCollection<string> PEngineerUser
        {
            get
            {
                pEngineerUser.Add("PEngineer");
                pEngineerUser.Add("test");
                List<string> value = GetUser(settingsFile, "PE").ToList();
                if (null != value)
                {
                    pEngineerUser = value;

                }
                return pEngineerUser.AsReadOnly();
            }
        }

        List<string> operatorUser = new List<string>();
        public ReadOnlyCollection<string> OperatorUser
        {
            get
            {
                operatorUser.Add("Operator");
                operatorUser.Add("test");
                List<string> value = GetUser(settingsFile, "OPE").ToList();
                if (null != value)
                {
                    operatorUser = value;

                }
                return operatorUser.AsReadOnly();
            }
        }

        List<string> reportsUser = new List<string>();
        public ReadOnlyCollection<string> ReportsUser
        {
            get
            {
                reportsUser.Add("Operator");
                reportsUser.Add("test");
                //reportsUser.Add("jason.krcma@ecolab.com");
                //reportsUser.Add("Envision123@");
                List<string> value = GetUser(settingsFile, "Reports").ToList();
                if (null != value)
                {
                    reportsUser = value;

                }
                return reportsUser.AsReadOnly();
            }
        }
    }
}
