﻿using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Validators;
using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AppStateTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string connstring = @"Data Source=Hyd-VCHEMBETI\SQLEXPRESS;Initial Catalog=ConduitLocal;User ID=tcddev;Password=Agstcd@1";
            //string connstring = @"Data Source=HYD-ECOLABDB\SQLExpress;Initial Catalog=ConduitLocalQAAutomation;User ID=tcddev;Password=Agstcd@1";
            //string connstring = @"Data Source=HYD-ECOLABTEXTI\SQLExpress;Initial Catalog=ConduitLocal_Ncover;User ID=tcddev;Password=Agstcd@1";

            AppState.ConnectionString = connstring;

            //WasherGroup test = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TestTestTest");

            //Ecolab.AppStateHandler.StateTransformation.ControllerTransform.AddControllerAndStorageTanks();
            //int controllerId = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxForWashSteps");
            //WasherGroup group = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialWasherGroupForWashSteps");
            //AppState.GetState<WasherState>().CreateConventionalWasher(group.Id, "TrialConvWashertest", controllerId, 1);

            //WasherProgramSetup setup1 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(1, group);
            //WasherProgramSetup setup2 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(2, group);
            //WasherProgramSetup setup3 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(3, group);

            //AppState.GetState<WasherState>().AddWashStep(setup1, 1);
            //AppState.GetState<WasherState>().AddWashStep(setup1, 2);
            //AppState.GetState<WasherState>().AddWashStep(setup1, 3);

            //int TotalRunTime1 = AppState.GetState<WasherState>().GetWasherSetup(setup1).TotalRunTime;

            //AppState.GetState<WasherState>().AddWashStep(setup2, 1);
            //AppState.GetState<WasherState>().AddWashStep(setup2, 2);
            //AppState.GetState<WasherState>().AddWashStep(setup2, 3);
            //AppState.GetState<WasherState>().AddWashStep(setup2, 4);

            //int TotalRunTime2 = AppState.GetState<WasherState>().GetWasherSetup(setup2).TotalRunTime;

            //AppState.GetState<WasherState>().AddWashStep(setup3, 1);
            //AppState.GetState<WasherState>().AddWashStep(setup3, 2);
            //AppState.GetState<WasherState>().AddWashStep(setup3, 3);
            //AppState.GetState<WasherState>().AddWashStep(setup3, 4);
            //AppState.GetState<WasherState>().AddWashStep(setup3, 5);
            //Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndAWasherGroupForTunnelAvailability();

            //int TotalRunTime3 = AppState.GetState<WasherState>().GetWasherSetup(setup3).TotalRunTime;

            //for(int i = 1; i <=16 ; i++)
            //{
            //    Console.WriteLine("TrialConvWashertest" + i);
            //    AppState.GetState<WasherState>().CreateConventionalWasher(157, "TrialConvWashertest" + i, 22, i);
            //    Thread.Sleep(2000);
            //}

            //Console.Read();

            //AppState.GetState<ControllerState>().CreateUtilityLogger("TrialUtilityLogger");
            //AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltrax");
            //AppState.GetState<ControllerState>().CreateBeckhoffUltrax("TrialBeckhoffUltrax", 18);
            //AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTDI", 19);
            //AppState.GetState<ControllerState>().CreateBeckhoffUltraxTDI("TrialBeckhoffEladosSmart", 22);
            //AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialABConventionalWasherGroup");
            //AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroup");
            //AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialBeckConventionalWasherGroup");
            //AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialBeckTunnelWasherGroup");

            //DryerGroup dryergrp = AppState.GetState<DryerState>().CreateDryerGroup("CreatedFromDB2");
            //AppState.GetState<DryerState>().DeleteAllDryers();
            //AppState.GetState<FinisherState>().DeleteAllFinishers();
            //AppState.GetState<MeterState>().DeleteAllMeters();
            //AppState.GetState<SensorState>().DeleteAllSensor();

            //MachineGroup dryerGroup = AppState.GetState<DryerState>().CreateDryerGroup("TestDryerGrp1");
            //MachineGroup finisherGroup = AppState.GetState<FinisherState>().CreateFinisherGroup("TestFiniserGrp1");

            //Dryer dryer = AppState.GetState<DryerState>().CreateDryer("DryerType 01", dryerGroup.Id, "TestDryerForGrp1");
            //Finisher finisher = AppState.GetState<FinisherState>().CreateFinisher("FinisherType 01", finisherGroup.Id, "TestFinisherForGrp1");
            //AppState.GetState<RedFlagState>().CreateRedFlag("Energy consumption", dryerGroup.Id, dryer.DryerNo);
            //AppState.GetState<RedFlagState>().CreateRedFlag("Energy consumption", finisherGroup.Id, finisher.FinnisherNo);

            //AppState.GetState<MeterState>().CreateMeter("Gas", "TestUtilityLogger2", "TestDryerMeter2", dryerGroup.Id, dryer.Id);
            //AppState.GetState<MeterState>().CreateMeter("Gas", "TestUtilityLogger2", "TestFinisherMeter2", finisherGroup.Id, finisher.Id);
            //AppState.GetState<SensorState>().CreateSensor("TestUtilityLogger2", "TestDryerSensor2", "Temperature", dryerGroup.Id, dryer.Id, "0-20mA", "Celsius");
            //AppState.GetState<SensorState>().CreateSensor("TestUtilityLogger2", "TestFinisherSensor2", "Temperature", finisherGroup.Id, finisher.Id, "0-20mA", "Celsius");

            // Test AppState code -----------------------------------------------------------------------------------------------------------------

            //List<Controller> controllers = AppState.GetState<ControllerState>().GetControllersWashersFormulas;
            //List<Meter> meters1 = AppState.GetState<MeterState>().GetAllMeters();

            //AppState.PreserveState<ControllerState, Controller>();
            ////AppState.PreserveState<MeterState, Meter>();
            ////AppState.PreserveState<PlantContactState, PlantContact>();
            ////AppState.PreserveState<ShiftState, ShiftData>();

            //controllers = null;



            //controllers = AppState.RetrieveState<ControllerState,Controller>();

            //List<Meter> meters2 = AppState.RetrieveState<MeterState,Meter>();

            ////List<Meter> addedMeter = MetersValidator.AddedMeters(meters2, meters1);
            ////List<Meter> delMeter = MetersValidator.DeletedMeter(meters2, meters1);

            //List<Meter> addedMeter = MetersValidator.AddedMeters();
            //List<Meter> delMeter = MetersValidator.DeletedMeters();

            //List<PlantContact> addedContact = PlantContactValidator.AddedContacts();
            //List<PlantContact> deletedContact = PlantContactValidator.DeletedContacts();
            //List<PlantContact> editedContact = PlantContactValidator.GetEditedContacts();

            //List<ShiftData> addedShift = ShiftValidator.AddedShifts();
            //List<ShiftData> deletedShift = ShiftValidator.DeletedShifts();
            //List<ShiftData> editedShift = ShiftValidator.GetEditedShifts();

            //////Open the file written above and read values from it.        

            ////---------------------------------------------------------------------------------------------------------------
            //// DB Trace

            //AppState.PreserveState<SPCallState, DBObject>();
            //List<DBObject> spCalls;

            //while (true)
            //{
            //    spCalls = SPCallValidator.AddedSPCalls();
            //    //spCalls = AppState.GetState<SPCallState>().GetAllSPCalls;
            //    CreateDirectory();
            //    if (spCalls.Count > 0)
            //    {
            //        AppState.PreserveState<SPCallState, DBObject>();
            //        foreach (DBObject sp in spCalls)
            //        {
            //            Console.WriteLine("SP called:{0} , timestamp:{1}", sp.ProcName, sp.LastExecutionTime);
            //            LogQuery(sp);
            //        }
            //    }

            //    //Console.ReadKey();
            //}

            ////---------------------------------------------------------------------------------------------------------------

            //---------------------------------------------------------------------------------------------------------------

            ////Data conditioning code

            //////User creation
            //AppState.GetState<UserState>().DeleteAllUserExceptAdmin();
            //AppState.GetState<UserState>().CreateUser("TREcolab", "test", "TRE");
            //AppState.GetState<UserState>().CreateUser("Engineer", "test", "ENG");
            //AppState.GetState<UserState>().CreateUser("TRCustomer", "test", "TRC");
            //AppState.GetState<UserState>().CreateUser("TMAdvanced", "test", "TMA");
            //AppState.GetState<UserState>().CreateUser("TMBasic", "test", "TMB");
            //AppState.GetState<UserState>().CreateUser("BDManager", "test", "BDM");
            //AppState.GetState<UserState>().CreateUser("CAManager", "test", "CAM");
            //AppState.GetState<UserState>().CreateUser("PManager", "test", "PM");
            //AppState.GetState<UserState>().CreateUser("PEngineer", "test", "PE");
            //AppState.GetState<UserState>().CreateUser("Operator", "test", "OPE");

            //////Allow formulas for rewash
            //AppState.GetState<ProgramState>().AllowAllFormulaForManualRewash();


            //////Delete all shifts
            //AppState.GetState<ShiftState>().DeleteAllShift();

            //////Delete all contacts
            //AppState.GetState<PlantContactState>().DeleteAllPlantContacts();

            //////Refresh Labour cost
            //AppState.GetState<LabourCostState>().ResetLabourCost(15, 15, 15, 15);

            ////////Delete all storage tanks
            ////AppState.GetState<StorageTankState>().DeleteAllStorageTanks();

            ////////Get all Finishers
            //AppState.GetState<FinisherState>().GetAllFinishers();

            //---------------------------------------------------------------------------------------------------------------

            ////Settings st = new Settings();
            //Type t = Type.GetType("AppStateTest.Settings");
            //Settings st = Activator.CreateInstance(t) as Settings;
            //var test = st.GetUsers();

        }

        static void LogQuery(DBObject spCall)
        {
            string path = @".\SPCalls\" + spCall.ProcName + ".sql";

            if (!File.Exists(path))
            {
                File.Create(path).Close();
            }

            if (!IsQueryLogged(path, spCall.SQLStatement))
            {
                File.AppendAllText(path, spCall.SQLStatement);
                File.AppendAllText(path, Environment.NewLine);
                File.AppendAllText(path, "--==============================================================================================================================");
                File.AppendAllText(path, Environment.NewLine);
            }
        }

        static bool IsQueryLogged(string path, string query)
        {
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    string line = sr.ReadToEnd();
                    if (line.Contains(query))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
                return false;
            }
        }

        static void CreateDirectory()
        {
            if (!Directory.Exists(@".\SPCalls"))
            {
                Directory.CreateDirectory(@".\SPCalls");
            }
        }

    }

    //public class Settings : Ecolab.BaseSetings
    //{
    //    public List<List<string>> GetUsers()
    //    {
    //        return GetAllUsers("../../../bin/Config/Users.xml").ToList();
    //    }
    //}
}
