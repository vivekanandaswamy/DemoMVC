﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class StorageTankState : BaseState
    {
        public StorageTankState(string connString)
            :base(connString)
        { }

        public void DeleteAllStorageTanks()
        {
            DBAccess.QueryString = SQL.Resource.DeleteAllStorageTanks;
            DBAccess.ExecuteCommand();
        }

        public void CreateStorageTank(string tankName, int controllerId)
        {
            DBAccess.QueryString = SQL.Resource.CreateStorageTank;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("TankName", tankName);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerId", controllerId);
            });
        }
    }
}
