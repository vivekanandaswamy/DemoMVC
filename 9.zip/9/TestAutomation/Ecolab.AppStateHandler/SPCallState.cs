﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class SPCallState : BaseState , IStateManagement
    {
        public SPCallState(string connString)
            : base(connString)
        { }

        public List<Entities.DBObject> GetAllSPCalls 
        { 
            get
            {
                DBAccess.QueryString = SQL.Resource.ConduitSPCallTrace;
                return DBAccess.GetData<Entities.DBObject>();
            }
        }

        public List<T> GetFullState<T>() where T : Entities.BaseEntity
        {
            return GetAllSPCalls.Cast<T>().ToList();
        }

        public string StateName
        {
            get 
            {
                return "SPCallState.osl";
            }
        }
    }
}
