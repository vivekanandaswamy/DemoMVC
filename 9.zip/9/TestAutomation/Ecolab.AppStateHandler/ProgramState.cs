﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class ProgramState : BaseState
    {
        public ProgramState(string connString)
            :base(connString)
        { }

        public void AllowAllFormulaForManualRewash()
        {
            DBAccess.QueryString = SQL.Resource.AllowAllFormulaForRewash;
            DBAccess.ExecuteCommand();
        }
    }
}
