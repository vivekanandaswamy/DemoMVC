﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class ShiftState : BaseState , IStateManagement
    {
        public ShiftState(string connString)
            :base(connString)
        { }

        public void DeleteAllShift()
        {
            DBAccess.QueryString = SQL.Resource.DeleteAllShifts;
            DBAccess.ExecuteCommand();
        }

        public List<Entities.ShiftData> GetShifts 
        { 
            get
            {
                DBAccess.QueryString = SQL.Resource.GetShifts;
                return DBAccess.GetData<Entities.ShiftData>();
            }
        }

        public List<T> GetFullState<T>() where T : Entities.BaseEntity
        {
            return GetShifts.Cast<T>().ToList();
        }

        public string StateName
        {
            get 
            {
                return "ShiftData.osl";
            }
        }
    }
}
