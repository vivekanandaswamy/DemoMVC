﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class SensorState : BaseState        
    {
        public SensorState(string connString)
            :base(connString)
        { }

        public void DeleteAllSensor()
        {
            AppState.GetState<RedFlagState>().DeleteAllRedFlags();
            DBAccess.QueryString = SQL.Resource.DeleteAllSensors;
            DBAccess.ExecuteCommand();
        }

        public void CreateSensor(string topicName, string sensorName, string sensorTypeName, int machineGroupId, int machineId, string outputType, string uom)
        {
            DBAccess.QueryString = SQL.Resource.CreateSensor;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("Topic",topicName);
                ((SqlCommand)command).Parameters.AddWithValue("SensorName", sensorName);
                ((SqlCommand)command).Parameters.AddWithValue("SensorTypeName", sensorTypeName);
                ((SqlCommand)command).Parameters.AddWithValue("MachineGroupId", machineGroupId);
                ((SqlCommand)command).Parameters.AddWithValue("MachineId", machineId);
                ((SqlCommand)command).Parameters.AddWithValue("OutputType", outputType);
                ((SqlCommand)command).Parameters.AddWithValue("UOM", uom);
            });
        }
    }
}
