﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    internal interface IStateManagement
    {
        List<T> GetFullState<T>() where T : Entities.BaseEntity;
        string StateName { get;}
    }
}
