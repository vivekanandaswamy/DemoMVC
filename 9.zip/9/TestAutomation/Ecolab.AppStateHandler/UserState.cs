﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class UserState : BaseState
    {
        public UserState(string connString)
            :base(connString)
        { }

        public void CreateUser(string loginName, string password, string roleCode)
        {
            DBAccess.QueryString = SQL.Resource.CreateUser;
            DBAccess.ExecuteCommand((command) => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("FirstName", loginName);
                ((SqlCommand)command).Parameters.AddWithValue("LastName", loginName);
                ((SqlCommand)command).Parameters.AddWithValue("LoginName", loginName);
                ((SqlCommand)command).Parameters.AddWithValue("Password", password);
                ((SqlCommand)command).Parameters.AddWithValue("UserRoleCode", roleCode);

            });
        }

        public void DeleteAllUserExceptAdmin()
        {
            DBAccess.QueryString = SQL.Resource.DeleteAllUserExceptAdmin;
            DBAccess.ExecuteCommand();
        }
    }
}
