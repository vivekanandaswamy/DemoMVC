﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class AppState
    {
        public static string ConnectionString { get; set; }

        public static T GetState<T>() where T : BaseState
        {
            return (T)Activator.CreateInstance(typeof(T), ConnectionString);           
        }

        public static void PreserveState<T,TEntity>() where T : BaseState where TEntity : Entities.BaseEntity
        {
            Stream stream = File.Open(AppStatePath(((IStateManagement)GetState<T>()).StateName), FileMode.Create);
            BinaryFormatter bformatter = new BinaryFormatter();
            //Console.WriteLine("Writing Employee Information");
            bformatter.Serialize(stream, ((IStateManagement)GetState<T>()).GetFullState<TEntity>());
            stream.Close();
        }

        public static List<TEntity> RetrieveState<T, TEntity>() where T : BaseState where TEntity : Entities.BaseEntity
        {
            Stream stream = File.Open(AppStatePath(((IStateManagement)GetState<T>()).StateName), FileMode.Open);
            BinaryFormatter bformatter = new BinaryFormatter();
            List<TEntity> returnStream;
            //Console.WriteLine("Reading Employee Information");
            returnStream = (List<TEntity>)bformatter.Deserialize(stream);
            stream.Close();
            return returnStream;
        }

        private static string AppStatePath(string stateName)
        {
            if(!Directory.Exists(@".\AppStates"))
            {
                Directory.CreateDirectory(@".\AppStates");
            }

            return string.Format(@".\AppStates\{0}",stateName);
        }

    }
}
