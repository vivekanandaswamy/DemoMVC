﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class PlantContactState : BaseState , IStateManagement
    {
        public PlantContactState(string connString)
            :base(connString)
        { }

        public void DeleteAllPlantContacts()
        {
            DBAccess.QueryString = SQL.Resource.DeleteAllPlantContacts;
            DBAccess.ExecuteCommand();
        }

        public List<Entities.PlantContact> GetContacts 
        { 
            get
            {
                DBAccess.QueryString = SQL.Resource.GetContacts;
                return DBAccess.GetData<Entities.PlantContact>();
            }
        }   



        public List<T> GetFullState<T>() where T : Entities.BaseEntity
        {
            return GetContacts.Cast<T>().ToList();
        }

        public string StateName
        {
            get 
            {
                return "PlantContact.osl";
            }
        }
    }
}
