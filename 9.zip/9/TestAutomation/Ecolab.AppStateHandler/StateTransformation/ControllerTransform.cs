﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.StateTransformation
{
    public class ControllerTransform
    {
        public static void TunnelDispenserAndWasherGroup()
        {
            AppState.GetState<ControllerState>().CreateABUltraxTDI("ABUltraxTDI");            
            AppState.GetState<ControllerState>().CreateBeckhoffUltraxTDI("BeckhoffEladosSmart");

            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "ABTunnelWasherGroup");
            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "BeckTunnelWasherGroup");
        }

        public static void ConvControllerAndWasherGroupBeckhoff()
        {
            int beckhoffUltraxId = AppState.GetState<ControllerState>().CreateBeckhoffUltrax("TrialBeckhoffUltrax");
            Entities.WasherGroup beckhoffConventionalWasherGroup = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialBeckConventionalWasherGroup");
            for (int i = 1; i <= 16; i++)
            {
                Console.WriteLine("TrialConvWashertestBeckhoff " + i);
                AppState.GetState<WasherState>().CreateConventionalWasher(beckhoffConventionalWasherGroup.Id, beckhoffConventionalWasherGroup.Id, "TrialConvWashertestBeckhoff  " + i.ToString(), beckhoffUltraxId, i);
                Thread.Sleep(200);
            }
        }

        public static void ConvControllerAndWasherGroupAB()
        {        
            //Controllers
            int abUltraxId = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltrax");          
            
            //Washer Groups
            Entities.WasherGroup abConventionalWasherGroup = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialABConventionalWasherGroup");
                        
            //Washers
            for (int i = 1; i <= 16; i++)
            {
                Console.WriteLine("TrialConvWashertestAb " + i);
                AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroup.Id, abConventionalWasherGroup.Id, "TrialConvWashertestAb  " + i.ToString(), abUltraxId, i);
                Thread.Sleep(200);
            }            
        }

        public static void AddControllerAndStorageTanks()
        {
            int abBUltraxtId = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxForStorageTanks");
            
            for(int i = 1; i <= 8; i++)
            {
                AppState.GetState<StorageTankState>().CreateStorageTank("StroageTank " + i, abBUltraxtId);
            }            
        }

        public static void AddControllerAndStorageTanks(string dispenser, string StroageTank)
        {
            int abBUltraxtId = AppState.GetState<ControllerState>().CreateABUltrax(dispenser);

            for (int i = 1; i <= 8; i++)
            {
                AppState.GetState<StorageTankState>().CreateStorageTank(StroageTank + i, abBUltraxtId);
            }
        }

        public static void CreateDispenserAndATunnelWasherGroup()
        {
            AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTDIForFormula");
            //Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroupForFormula");
        }

        public static void CreateDispenserAndATunnelWasherGroupCopy()
        {
            AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTDIForFormulaCopy");
            //Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroupForFormulaCopy");
        }

        public static void CreateDispenserAndATunnelWasherGroup2()
        {
            AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTDIForFormula2");
            //Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroupForFormula2");
        }

        public static void CreateDispenserAndAWasherGroupForTunnelAvailability()
        {
            AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTD1");
            //Thread.Sleep(2000);
            AppState.GetState<ControllerState>().CreateBeckhoffUltraxTDI("TrialBeckhoffEladosSmart1");
            //Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroup1");
            AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialBeckTunnelWasherGroup1");
            //Thread.Sleep(2000);
        }

        public static void CreateDispenserAndAConventionalWasherGroupForMaxNominalValueValidation()
        {
            int abUltraxIdFormulaNominalValue = AppState.GetState<ControllerState>().CreateABUltrax("TrialABUltraxFormulaNominalValue");
            //Thread.Sleep(2000);
            Entities.WasherGroup abConventionalWasherGroupFormulaNominalValue = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "TrialABConventionalWasherGroupFormulaNominalValue");
            Console.WriteLine("TrialConvWashertestAbFormulaNominalValue");
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupFormulaNominalValue.Id, abConventionalWasherGroupFormulaNominalValue.Id, "TrialConvWashertestAbFormulaNominalValue", abUltraxIdFormulaNominalValue, 1);
            //Thread.Sleep(2000);                
        }

        public static void MIProduction()
        {
            int abUltraxIdForMIProduction = AppState.GetState<ControllerState>().CreateABUltrax("MIProductionDispenser");
            //Thread.Sleep(2000);
            Entities.WasherGroup abConventionalWasherGroupForMIProduction = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "MIProductionWasherGroup");
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForMIProduction.Id, abConventionalWasherGroupForMIProduction.Id, "MIProductionWasher", abUltraxIdForMIProduction, 1);
            //Thread.Sleep(2000);
        }

        public static void CreateTunnelWasherGroupWithOneTunnelForPumps()
        {
            int controllerId = AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTDIForPumps");
            //Thread.Sleep(2000);
            Entities.WasherGroup washerGroup = AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroupForPumps");
            //Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateTunnelWasher(washerGroup.Id, "TrialTunnelForPumps", controllerId);
        }

        public static void CreateDispenserAndATunnelForDashboard()
        {
            int controllerId = AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTDIForDashboard");
            //Thread.Sleep(2000);
            Entities.WasherGroup washerGroup = AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroupForDashboard");
            AppState.GetState<WasherState>().CreateTunnelWasher(washerGroup.Id, "TrialTunnelForDashboard", controllerId);
        }

        public static void CWGMeter()
        {
            int abUltraxIdForMeter = AppState.GetState<ControllerState>().CreateABUltrax("DispenserForMeter");
            //Thread.Sleep(2000);
            Entities.WasherGroup abConventionalWasherGroupForMeter = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "WasherGroupForMeter");
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForMeter.Id, abConventionalWasherGroupForMeter.Id, "MeterWasher 1", abUltraxIdForMeter, 1);
            //Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForMeter.Id, abConventionalWasherGroupForMeter.Id, "MeterWasher 2", abUltraxIdForMeter, 2);
            //Thread.Sleep(2000);
        }

        public static void MIUtility()
        {
            int abUltraxIdForMeter = AppState.GetState<ControllerState>().CreateABUltrax("DispenserForMIMeter");
            //Thread.Sleep(2000);
            Entities.WasherGroup abConventionalWasherGroupForMeter = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "WasherGroupForMIMeter");
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForMeter.Id, abConventionalWasherGroupForMeter.Id, "MIMeterWasher", abUltraxIdForMeter, 1);
            //Thread.Sleep(2000);            
        }     

        public static void CWGSensor()
        {
            int abUltraxIdForSensor = AppState.GetState<ControllerState>().CreateABUltrax("SensorDispenser");
            //Thread.Sleep(2000);
            Entities.WasherGroup abConventionalWasherGroupForSensor = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "SensorWasherGroup");
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForSensor.Id, abConventionalWasherGroupForSensor.Id, "SensorWasher 1", abUltraxIdForSensor, 1);
            //Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForSensor.Id, abConventionalWasherGroupForSensor.Id, "SensorWasher 2", abUltraxIdForSensor, 2);
            //Thread.Sleep(2000);
        }

        public static void WasherTest()
        {
            int controllerId = AppState.GetState<ControllerState>().CreateABUltraxTDI("WasherTestDispenser");
            //Thread.Sleep(2000);
            Entities.WasherGroup washerGroup = AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "WasherTestWasherGroup");
            AppState.GetState<WasherState>().CreateTunnelWasher(washerGroup.Id, "WasherTestTunnel", controllerId);
        }

        public static void CWGRedFlag()
        {
            int abUltraxIdForRedFlag = AppState.GetState<ControllerState>().CreateABUltrax("RedFlagDispenser");
            //Thread.Sleep(2000);
            Entities.WasherGroup abConventionalWasherGroupForRedFlag = AppState.GetState<WasherState>().CreateWasherGroup("Conventional", "RedFlagWasherGroup");
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForRedFlag.Id, abConventionalWasherGroupForRedFlag.Id, "RedFlagWasher", abUltraxIdForRedFlag, 1);
            //Thread.Sleep(2000);            
        }

        public static void CWGRedFlag(string dispenser, string washerGroup, string wgType, string washer)
        {
            int abUltraxIdForRedFlag = AppState.GetState<ControllerState>().CreateABUltrax(dispenser);
            //Thread.Sleep(2000);
            Entities.WasherGroup abConventionalWasherGroupForRedFlag = AppState.GetState<WasherState>().CreateWasherGroup(wgType, washerGroup);
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForRedFlag.Id, abConventionalWasherGroupForRedFlag.Id, washer, abUltraxIdForRedFlag, 1);
            //Thread.Sleep(2000);
        }

        public static void CreateTunnelWasherGroupWithOneTunnelForPumps(string dispenser, string washerGroupType, string washerGroupName, string tunnelWasherName)
        {
            int controllerId = AppState.GetState<ControllerState>().CreateABUltraxTDI(dispenser);
            Thread.Sleep(2000);
            Entities.WasherGroup washerGroup = AppState.GetState<WasherState>().CreateWasherGroup(washerGroupType, washerGroupName);
            Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateTunnelWasher(washerGroup.Id, tunnelWasherName, controllerId);
        }
        public static void CreateDispenserAndATunnelWasherGroup2(string dispenser, string washerGroupType, string washerGroupName)
        {
            AppState.GetState<ControllerState>().CreateABUltraxTDI(dispenser);
            Thread.Sleep(2000);
            AppState.GetState<WasherState>().CreateWasherGroup(washerGroupType, washerGroupName);
        }                
    }
}
