﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.StateTransformation
{
    public class RedflagTransform
    {
        public static void AssociateRedFlagToMachine()
        {
            AppState.GetState<RedFlagState>().DeleteAllRedFlags();
            AppState.GetState<DryerState>().DeleteAllDryers();
            AppState.GetState<FinisherState>().DeleteAllFinishers();
            AppState.GetState<MeterState>().DeleteAllMeters();
            AppState.GetState<SensorState>().DeleteAllSensor();
            AppState.GetState<ControllerState>().CreateUtilityLogger("TestUtilityLogger2");

            MachineGroup dryerGroup = AppState.GetState<DryerState>().CreateDryerGroup("TestDryerGrp1");
            MachineGroup finisherGroup = AppState.GetState<FinisherState>().CreateFinisherGroup("TestFiniserGrp1");

            Dryer dryer = AppState.GetState<DryerState>().CreateDryer("DryerType 01", dryerGroup.Id, "TestDryerForGrp1");
            Finisher finisher = AppState.GetState<FinisherState>().CreateFinisher("FinisherType 01", finisherGroup.Id, "TestFinisherForGrp1");
            AppState.GetState<RedFlagState>().CreateRedFlag("Energy consumption", dryerGroup.Id, dryer.Id);
            AppState.GetState<RedFlagState>().CreateRedFlag("Energy consumption", finisherGroup.Id, finisher.Id);

            AppState.GetState<MeterState>().CreateMeter("Gas", "TestUtilityLogger2", "TestDryerMeter2", dryerGroup.Id, dryer.Id);
            AppState.GetState<MeterState>().CreateMeter("Gas", "TestUtilityLogger2", "TestFinisherMeter2", finisherGroup.Id, finisher.Id);
            AppState.GetState<SensorState>().CreateSensor("TestUtilityLogger2", "TestDryerSensor2", "Temperature", dryerGroup.Id, dryer.Id, "0-20mA", "Celsius");
            AppState.GetState<SensorState>().CreateSensor("TestUtilityLogger2", "TestFinisherSensor2", "Temperature", finisherGroup.Id, finisher.Id, "0-20mA", "Celsius");
        }
    }
}
