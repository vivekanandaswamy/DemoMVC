﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class LabourCostState : BaseState
    {
        public LabourCostState(string connString)
            :base(connString)
        { }

        public void ResetLabourCost(int costForType1, int costForType2, int costForType3, int costForType4)
        {
            DBAccess.QueryString = SQL.Resource.TruncateAndSaveLabourCost;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("CostForType1", costForType1);
                ((SqlCommand)command).Parameters.AddWithValue("CostForType2", costForType2);
                ((SqlCommand)command).Parameters.AddWithValue("CostForType3", costForType3);
                ((SqlCommand)command).Parameters.AddWithValue("CostForType4", costForType4);
            });
        }
    }
}
