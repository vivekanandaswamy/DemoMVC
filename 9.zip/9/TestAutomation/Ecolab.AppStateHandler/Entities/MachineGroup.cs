﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class MachineGroup : BaseEntity
    {
        public MachineGroup(int id, string groupDescription, int groupTypeId)
        {
            Id = id;
            GroupDescription = groupDescription;
            GroupTypeId = groupTypeId;
        }

        public string GroupDescription { get; set; }

        public int GroupTypeId { get; set; }
    }
}
