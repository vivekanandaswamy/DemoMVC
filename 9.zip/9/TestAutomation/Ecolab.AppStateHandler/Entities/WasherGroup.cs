﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class WasherGroup : BaseEntity
    {
        public WasherGroup(int washerGroupId, byte washerGroupTypeId, string washerGroupName, string washerGroupNumber)
        {
            Id = washerGroupId;
            WasherGroupTypeId = washerGroupTypeId;
            WasherGroupName = washerGroupName;
            WasherGroupNumber = Convert.ToInt32(washerGroupNumber);
        }

        public byte WasherGroupTypeId { get; set; }

        public string WasherGroupName { get; set; }

        public int WasherGroupNumber { get; set; }
    }
}
