﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class WasherProgramSetup : BaseEntity
    {
        public WasherProgramSetup(int washerProgramSetupId, int washerGroupId, short programNumber, int programId, int totalRunTime, int totalSteps)
        {
            Id = washerProgramSetupId;
            WasherGroupId = washerGroupId;
            ProgramNumber = programNumber;
            ProgramId = programId;
            TotalRunTime = totalRunTime;
            TotalSteps = totalSteps;
        }

        public int WasherGroupId { get; set; }

        public short ProgramNumber { get; set; }

        public int ProgramId { get; set; }

        public int TotalRunTime { get; set; }

        public int TotalSteps { get; set; }
    }
}
