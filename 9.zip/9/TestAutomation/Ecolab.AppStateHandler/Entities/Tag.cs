﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class Tag : BaseEntity, ISerializable
    {
        public Tag(string tagType, string tagAddress)
        {
            TagType = tagType;
            TagAddress = tagAddress;
        }

        public Tag(SerializationInfo info, StreamingContext ctxt)
        {
            TagType = (string)info.GetValue("TagType", typeof(string));
            TagAddress = (string)info.GetValue("TagAddress", typeof(string));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("TagType", TagType);
            info.AddValue("TagAddress", TagAddress);
        }
        
        public string TagType { get; set; }

        public string TagAddress { get; set; }        
    }
}
