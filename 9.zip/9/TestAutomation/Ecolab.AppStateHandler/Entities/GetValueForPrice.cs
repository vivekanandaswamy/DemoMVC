﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class GetValueForPrice : BaseEntity
    {
        public GetValueForPrice(int productId, decimal valueBasedUOMID) //string packageSizeWeightUOMCode, int unitWeightVolumeUOMId, float t_C, float cost, double per_Oz_Cost, 
        {
           // Source contains fields of type (Int32, String, Int32, Decimal, Double, Double, Double).

            ProductId = productId;
            ValueBasedUOMID = valueBasedUOMID;
            //PackageSizeWeightUOMCode = packageSizeWeightUOMCode;
            
            //UnitWeightVolumeUOMId = unitWeightVolumeUOMId;
            //T_C = t_C;
            //Cost = cost;
            //Per_Oz_Cost = per_Oz_Cost;
        }
        public int ProductId { get; set; }
        public decimal ValueBasedUOMID { get; set; }
        //public string PackageSizeWeightUOMCode { get; set; }
        //public int UnitWeightVolumeUOMId { get; set; }
        //public float T_C { get; set; }
        //public float Cost { get; set; }
        //public double Per_Oz_Cost { get; set; }
      
    }
}
