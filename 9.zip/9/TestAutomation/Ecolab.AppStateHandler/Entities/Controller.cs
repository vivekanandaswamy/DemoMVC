﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class Controller : BaseEntity, ISerializable
    {
        public Controller(string topicName, string description, string controllerName, int  controllerId, string controllerType)
        {
            TopicName = topicName;
            Description = description;
            ControllerName = controllerName;
            ControllerId = controllerId;
            ControllerType = controllerType;
        }

        public Controller(SerializationInfo info, StreamingContext ctxt)
		{
			//Get the values from info and assign them to the appropriate properties
            TopicName = (string)info.GetValue("TopicName", typeof(string));
            Description = (string)info.GetValue("Description", typeof(string));
            Washers = (List<Washer>)info.GetValue("Washers", typeof(List<Washer>));
            ControllerName = (string)info.GetValue("ControllerName", typeof(string));
            ControllerId = (int)info.GetValue("ControllerId", typeof(int));
            ControllerType = (string)info.GetValue("ControllerType", typeof(string));
		}
		
		//Serialization function.
		public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
		{
			//You can use any custom name for your name-value pair. But make sure you
			// read the values with the same name. For ex:- If you write EmpId as "EmployeeId"
			// then you should read the same with "EmployeeId"
            info.AddValue("TopicName", TopicName);
            info.AddValue("Description", Description);
            info.AddValue("Washers", Washers);
            info.AddValue("ControllerName", ControllerName);
            info.AddValue("ControllerId", ControllerId);
            info.AddValue("ControllerType", ControllerType);
		}

        public string TopicName { get; set; }

        public string Description { get; set; }

        public string ControllerName { get; set; }

        public int ControllerId { get; set; }

        public string ControllerType { get; set; }

        public List<Washer> Washers { get; set; }
    }
}
