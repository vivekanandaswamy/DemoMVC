﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class PlantContact : BaseEntity , ISerializable
    {
        public PlantContact(int contactId, string contactFirstName, string contactLastName, string contactTitle, string contactEmail, string contactofficePhone, string contactMobile )
        {
            Id = contactId;
            ContactFirstName = contactFirstName;
            ContactLastName = contactLastName;
            ContactTitle = contactTitle;
            ContactOfficePhone = contactofficePhone;
            ContactMobilePhone = contactMobile;
            ContactEmail = contactEmail;
        }

        public PlantContact(SerializationInfo info, StreamingContext context)
        {
            Id = (int)info.GetValue("Id", typeof(int));
            ContactFirstName = (string)info.GetValue("ContactFirstName", typeof(string));
            ContactLastName = (string)info.GetValue("ContactLastName", typeof(string));
            ContactTitle = (string)info.GetValue("ContactTitle", typeof(string));
            ContactEmail = (string)info.GetValue("ContactEmail", typeof(string));
            ContactOfficePhone = (string)info.GetValue("ContactOfficePhone", typeof(string));
            ContactMobilePhone = (string)info.GetValue("ContactMobilePhone", typeof(string));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Id", Id);
            info.AddValue("ContactFirstName", ContactFirstName);
            info.AddValue("ContactLastName", ContactLastName);
            info.AddValue("ContactTitle", ContactTitle);
            info.AddValue("ContactEmail", ContactEmail);
            info.AddValue("ContactOfficePhone", ContactOfficePhone);
            info.AddValue("ContactMobilePhone", ContactMobilePhone);
        }

        public string ContactFirstName { get; set; }

        public string ContactLastName { get; set; }

        public string ContactTitle { get; set; }

        public string ContactEmail { get; set; }

        public string ContactOfficePhone { get; set; }

        public string ContactMobilePhone { get; set; }       
    }
}
