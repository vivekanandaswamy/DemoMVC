﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class Batch
    {
        public Batch(int batchId)
        {
            BatchId = batchId;
        }

        public int BatchId { get; set; }

        public int FormulaNumber { get; set; }

        public string FormulaTag { get; set; }

        public string InjCounter { get; set; }

        public string OPCounter { get; set; }

        public string AWEA { get; set; }

        public int NumberOfInjections { get; set; }

        public int ControllerId { get; set; }

        public string TopicName { get; set; }

        public string WasherNumber { get; set; }

        public int WasherValue { get; set; }

        public int TurnTime { get; set; }

        public int EOF { get; set; }

        public string AlarmErrorTag { get; set; }

        public int AlarmErrorCode { get; set; }

        public string AlarmFormulaTag { get; set; }

        public string ControllerType { get; set; }

        public bool IsTunnel { get; set; }
    }
}
