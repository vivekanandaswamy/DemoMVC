﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class ShiftData : BaseEntity , ISerializable
    {
        public ShiftData(int shiftId, string shiftName, int dayId, TimeSpan startTime, TimeSpan endTime, decimal targetProduction)
        {
            Id = shiftId;
            ShiftName = shiftName;
            DayId = dayId;
            StartTime = startTime;
            EndTime = endTime;
            TargetProduction = targetProduction;
        }

        public ShiftData(SerializationInfo info, StreamingContext context)
        {
            Id = (int)info.GetValue("Id", typeof(int));
            ShiftName = (string)info.GetValue("ShiftName", typeof(string));
            DayId = (int)info.GetValue("DayId", typeof(int));
            StartTime = (TimeSpan)info.GetValue("StartTime", typeof(TimeSpan));
            EndTime = (TimeSpan)info.GetValue("EndTime", typeof(TimeSpan));
            TargetProduction = (decimal)info.GetValue("TargetProduction", typeof(decimal));
        }
        
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Id", Id);
            info.AddValue("ShiftName", ShiftName);
            info.AddValue("DayId", DayId);
            info.AddValue("StartTime", StartTime);
            info.AddValue("EndTime", EndTime);
            info.AddValue("TargetProduction", TargetProduction);
        }

        public string ShiftName { get; set; }

        public int DayId { get; set; }

        public TimeSpan StartTime { get; set; }

        public TimeSpan EndTime { get; set; }

        public decimal TargetProduction { get; set; }

    }
}
