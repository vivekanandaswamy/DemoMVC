﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class Formula : BaseEntity, ISerializable
    {
        public Formula(short programNumber, int totalRunTime, string category, short nominalLoad, int standardWeight, string formulaName)
        {
            ProgramNumber = (int)programNumber;
            TotalRunTime = totalRunTime;
            Category = category;
            NominalLoad = (int)nominalLoad;
            StandardWeight = standardWeight;
            FormulaName = formulaName;           
        }

        public Formula(SerializationInfo info, StreamingContext ctxt)
        {
            ProgramNumber = (int)info.GetValue("ProgramNumber", typeof(int));
            TotalRunTime = (int)info.GetValue("TotalRunTime", typeof(int));
            Category = (string)info.GetValue("Category", typeof(string));
            NominalLoad = (int)info.GetValue("NominalLoad", typeof(int));
            StandardWeight = (int)info.GetValue("NominalLoad", typeof(int));
            FormulaName = (string)info.GetValue("FormulaName", typeof(string));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("ProgramNumber", ProgramNumber);
            info.AddValue("TotalRunTime", TotalRunTime);
            info.AddValue("Category", Category);
            info.AddValue("NominalLoad", NominalLoad);
            info.AddValue("StandardWeight", StandardWeight);
            info.AddValue("FormulaName", FormulaName);
        }

        public int ProgramNumber { get; set; }

        public int TotalRunTime { get; set; }

        public string Category { get; set; }

        public int NominalLoad { get; set; }

        public int StandardWeight { get; set; }

        public string FormulaName { get; set; }
        
    }
}
