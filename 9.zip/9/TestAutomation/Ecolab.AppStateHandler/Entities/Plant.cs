﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class Plant : BaseEntity
    {
        public Plant(int plantId, string ecolabAccountNumber, string name, string exportPath, short regionId, string currencyCode)
        {
            Id = plantId;
            EcolabAccountNumber = ecolabAccountNumber;
            Name = name;
            ExportPath = exportPath;
            RegionId = regionId;
            CurrencyCode = currencyCode;
        }

        public string EcolabAccountNumber { get; set; }

        public string  Name { get; set; }

        public string ExportPath { get; set; }

        public short RegionId { get; set; }

        public string CurrencyCode { get; set; }
    }
}
