﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class WasherModelSize : BaseEntity
    {
        public WasherModelSize(short washerModelid, string washerModelName, string washerSize)
        {
            Id = washerModelid;
            WasherModelName = washerModelName;
            WasherSize = washerSize;
        }

        public string WasherModelName { get; set; }

        public string WasherSize { get; set; }
    }
}
