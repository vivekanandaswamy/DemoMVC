﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class DBObject : BaseEntity, ISerializable
    {
        public DBObject(int objectId, string procName, int executionCount, string sqlStatement, DateTime lastExecutionTime)
        {
            Id = objectId;
            ProcName = procName;
            ExecutionCount = executionCount;
            SQLStatement = sqlStatement;
            LastExecutionTime = lastExecutionTime;
        }

        public DBObject(SerializationInfo info, StreamingContext cntx)
        {
            Id = (int)info.GetValue("Id", typeof(int));
            ProcName = (string)info.GetValue("ProcName", typeof(string));
            ExecutionCount = (int)info.GetValue("ExecutionCount",typeof(int));
            SQLStatement = (string)info.GetValue("SQLStatement", typeof(string));
            LastExecutionTime = (DateTime)info.GetValue("LastExecutionTime", typeof(DateTime));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Id", Id);
            info.AddValue("ProcName", ProcName);
            info.AddValue("ExecutionCount", ExecutionCount);
            info.AddValue("SQLStatement", SQLStatement);
            info.AddValue("LastExecutionTime", LastExecutionTime);
        }

        public string ProcName { get; set; }

        public int ExecutionCount { get; set; }

        public string SQLStatement { get; set; }

        public DateTime LastExecutionTime { get; set; }       
    }
}
