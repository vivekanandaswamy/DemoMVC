﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class Dryer : BaseEntity
    {
        public Dryer(int id, int dryerGroupId, int dryerNo, string description)
        {
            Id = id;
            DryerGroupId = dryerGroupId;
            DryerNo = dryerNo;
            Description = description;
        }

        public int DryerGroupId { get; set; }

        public int DryerNo { get; set; }

        public string Description { get; set; }
    }
}
