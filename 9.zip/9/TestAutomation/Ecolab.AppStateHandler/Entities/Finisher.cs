﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    public class Finisher : BaseEntity
    {
        public Finisher(int finnisherId, int finnisherNo, int finisherGroupId, string name, int finnisherTypeId)
        {
            Id = finnisherId;
            FinnisherNo = finnisherNo;
            Name = name;
            FinnisherTypeId = finnisherTypeId;
            FinisherGroupId = finisherGroupId;
        }

        public int FinnisherId { get; set; }

        public int FinnisherNo { get; set; }

        public string Name { get; set; }

        public int FinnisherTypeId { get; set; }

        public int FinisherGroupId { get; set; }
    }
}
