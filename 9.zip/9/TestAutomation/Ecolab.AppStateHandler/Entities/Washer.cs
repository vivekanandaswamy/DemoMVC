﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class Washer : BaseEntity, ISerializable
    {
        public Washer(int machineInternalId, int washerId, int groupId, string machineName, bool isTunnel, int turnArroundTime 
            , short targetTurnTime, short pantWasherNUmber, int eof)
        {
            MachineInternalId = machineInternalId;
            WasherId = washerId;
            GroupId = groupId;
            MachineName = machineName;
            IsTunnel = isTunnel;
            TurnArroundTime = turnArroundTime;
            TargetTurnTime = targetTurnTime;
            PlantWasherNumber = pantWasherNUmber;
            EOF = eof;
        }

        //Deserialization constructor.
        public Washer(SerializationInfo info, StreamingContext ctxt)
		{
			//Get the values from info and assign them to the appropriate properties
            MachineInternalId = (int)info.GetValue("MachineInternalId", typeof(int));
            WasherId = (int)info.GetValue("WasherId", typeof(int));
            GroupId = (int)info.GetValue("GroupId", typeof(int));
            MachineName = (string)info.GetValue("MachineName", typeof(string));
            IsTunnel = (bool)info.GetValue("IsTunnel", typeof(bool));
            TargetTurnTime = (short)info.GetValue("TargetTurnTime", typeof(short));
            WasherTags = (List<Tag>)info.GetValue("WasherTags", typeof(List<Tag>));
            Formulas = (List<Formula>)info.GetValue("Formulas", typeof(List<Formula>));
            TurnArroundTime = (int)info.GetValue("TurnArroundTime", typeof(int));
            PlantWasherNumber = (short)info.GetValue("PlantWasherNumber", typeof(short));
            //Batches = (List<Batch>)info.GetValue("Batches", typeof(List<Batch>));
            EOF = (int)info.GetValue("EOF", typeof(int));
		}
		
		//Serialization function.
		public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
		{
			//You can use any custom name for your name-value pair. But make sure you
			// read the values with the same name. For ex:- If you write EmpId as "EmployeeId"
			// then you should read the same with "EmployeeId"
            info.AddValue("MachineInternalId", MachineInternalId);
            info.AddValue("WasherId", WasherId);
            info.AddValue("GroupId", GroupId);
            info.AddValue("MachineName", MachineName);
            info.AddValue("IsTunnel", IsTunnel);
            info.AddValue("TargetTurnTime", TargetTurnTime);
            info.AddValue("WasherTags", WasherTags);
            info.AddValue("Formulas", Formulas);
            info.AddValue("TurnArroundTime", TurnArroundTime);
            info.AddValue("PlantWasherNumber", PlantWasherNumber);
            //info.AddValue("Batches", Batches);
            info.AddValue("EOF", EOF);
		}

        public int MachineInternalId { get; set; }

        public int WasherId { get; set; }

        public int GroupId { get; set; }

        public string MachineName { get; set; }

        public bool IsTunnel { get; set; }

        public short TargetTurnTime { get; set; }

        public List<Tag> WasherTags { get; set; }

        public List<Formula> Formulas { get; set; }

        public int TurnArroundTime { get; set; }

        public short PlantWasherNumber { get; set; }

        public List<Batch> Batches { get; set; }

        public int EOF { get; set; }
    }
}
