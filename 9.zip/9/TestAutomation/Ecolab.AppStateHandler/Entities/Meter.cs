﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Entities
{
    [Serializable()]
    public class Meter : BaseEntity, ISerializable
    {
        public Meter(int meterId, int controllerId, string topicName, string name, string utilityType, string description)
        {
            Id = meterId;
            ControllerID = controllerId;
            TopicName = topicName;
            Name = name;
            UtilityType = utilityType;
            Description = description;
        }

        public Meter(SerializationInfo info, StreamingContext ctxt)
        {
            Id = (int)info.GetValue("MeterId", typeof(int));
            ControllerID = (int)info.GetValue("ControllerID", typeof(int));
            TopicName = (string)info.GetValue("TopicName", typeof(string));
            Name = (string)info.GetValue("Name", typeof(string));
            UtilityType = (string)info.GetValue("UtilityType", typeof(string));
            Description = (string)info.GetValue("Description", typeof(string));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("MeterId", Id);
            info.AddValue("ControllerID", ControllerID);
            info.AddValue("TopicName", TopicName);
            info.AddValue("Name", Name);
            info.AddValue("UtilityType", UtilityType);
            info.AddValue("Description", Description);
        }

        public int MeterId { get; set; }

        public int ControllerID { get; set; }

        public string TopicName { get; set; }

        public string Name { get; set; }

        public string UtilityType { get; set; }

        public string Description { get; set; }
              
    }
}
