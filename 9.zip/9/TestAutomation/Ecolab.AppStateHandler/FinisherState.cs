﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class FinisherState : BaseState , IStateManagement
    {
        public FinisherState(string connstring)
            :base(connstring)
        { }

        public List<Entities.Finisher> GetAllFinishers()
        {
            DBAccess.QueryString = SQL.Resource.GetFinishers;
            return DBAccess.GetData<Entities.Finisher>();
        }

        public void DeleteAllFinishers()
        {
            DBAccess.QueryString = SQL.Resource.DeleteAllFinnishers;
            DBAccess.ExecuteCommand();          
        }

        public MachineGroup CreateFinisherGroup(string finisherGroupName)
        {
            DBAccess.QueryString = SQL.Resource.CreateFinisherGroup;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("FinisherGroupName", finisherGroupName);
            });

            DBAccess.QueryString = SQL.Resource.GetLastCreatedMachineGroup;
            return DBAccess.GetData<MachineGroup>(command =>
            {
                ((SqlCommand)command).Parameters.AddWithValue("GroupType", "Finnisher Group");
            }).FirstOrDefault();

        }

        public Finisher CreateFinisher(string finisherTypeName, int finisherGroupId, string finisherName)
        {
            DBAccess.QueryString = SQL.Resource.CreateFinisher;
            DBAccess.ExecuteCommand(command =>
            {
                ((SqlCommand)command).Parameters.AddWithValue("FinisherTypeName", finisherTypeName);
                ((SqlCommand)command).Parameters.AddWithValue("FinisherGroupId", finisherGroupId);
                ((SqlCommand)command).Parameters.AddWithValue("FinisherName", finisherName);
            });

            DBAccess.QueryString = SQL.Resource.GetLastCreatedFinisher;
            return DBAccess.GetData<Finisher>().FirstOrDefault();
        }

        public List<T> GetFullState<T>() where T : Entities.BaseEntity
        {
            return GetAllFinishers().Cast<T>().ToList();
        }


        public string StateName
        {
            get 
            {
                return "Finishers.osl";
            }
        }
    }
}
