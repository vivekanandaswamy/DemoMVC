﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Validators
{
    public class PlantContactValidator : BaseValidator
    {
        public static List<PlantContact> AddedContacts()
        {
            return AddedEntities<PlantContact>(AppState.RetrieveState<PlantContactState, PlantContact>(), AppState.GetState<PlantContactState>().GetContacts);
        }

        public static List<PlantContact> DeletedContacts()
        {
            return DeletedEntities<PlantContact>(AppState.RetrieveState<PlantContactState, PlantContact>(), AppState.GetState<PlantContactState>().GetContacts);
        } 

        public static List<PlantContact> GetEditedContacts()
        {
            List<PlantContact> previousContactState = AppState.RetrieveState<PlantContactState, PlantContact>();
            List<PlantContact> currentContactState = AppState.GetState<PlantContactState>().GetContacts;
            List<PlantContact> editedContacts = new List<PlantContact>();
            List<PlantContact> sameContact;

            foreach (PlantContact previousContact in previousContactState)
            {
                sameContact = currentContactState.Where(currContact => currContact.Id == previousContact.Id).ToList();
                if (sameContact.Count > 0 && IsEdited(sameContact.FirstOrDefault(), previousContactState))
                {
                    editedContacts.Add(sameContact.FirstOrDefault());
                }                
            }

            return editedContacts;
        }

        private static bool IsEdited(PlantContact contact, List<PlantContact> currentContacts)
        {
            PlantContact currentContactfromState = currentContacts.Where(currentContact => contact.Id == currentContact.Id).FirstOrDefault();

            if(!currentContactfromState.ContactEmail.Equals(contact.ContactEmail))
            {
                return true;
            }

            if (!currentContactfromState.ContactFirstName.Equals(contact.ContactFirstName))
            {
                return true;
            }

            if (!currentContactfromState.ContactLastName.Equals(contact.ContactLastName))
            {
                return true;
            }
            
            if (!currentContactfromState.ContactMobilePhone.Equals(contact.ContactMobilePhone))
            {
                return true;
            }

            if (!currentContactfromState.ContactOfficePhone.Equals(contact.ContactOfficePhone))
            {
                return true;
            }

            if (!currentContactfromState.ContactTitle.Equals(contact.ContactTitle))
            {
                return true;
            }

            return false;
        }
    }
}
