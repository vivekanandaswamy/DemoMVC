﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Validators
{
    public class SPCallValidator : BaseValidator
    {
        public static List<DBObject> AddedSPCalls()
        {
            return AddedEntities<DBObject>(AppState.RetrieveState<SPCallState, DBObject>(), AppState.GetState<SPCallState>().GetAllSPCalls);
        }
    }
}
