﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Validators
{
    public class ShiftValidator : BaseValidator
    {
        public static List<ShiftData> AddedShifts()
        {
            return AddedEntities<ShiftData>(AppState.RetrieveState<ShiftState, ShiftData>(), AppState.GetState<ShiftState>().GetShifts);
        }

        public static List<ShiftData> DeletedShifts()
        {
            return DeletedEntities<ShiftData>(AppState.RetrieveState<ShiftState, ShiftData>(), AppState.GetState<ShiftState>().GetShifts);
        }

        public static List<ShiftData> GetEditedShifts()
        {
            List<ShiftData> previousShiftState = AppState.RetrieveState<ShiftState, ShiftData>();
            List<ShiftData> currentShiftState = AppState.GetState<ShiftState>().GetShifts;
            List<ShiftData> editedShifts = new List<ShiftData>();
            List<ShiftData> sameShift;

            foreach (ShiftData previousContact in previousShiftState)
            {
                sameShift = currentShiftState.Where(currContact => currContact.Id == previousContact.Id).ToList();
                if (sameShift.Count > 0 && IsEdited(sameShift.FirstOrDefault(), previousShiftState))
                {
                    editedShifts.Add(sameShift.FirstOrDefault());
                }
            }

            return editedShifts;
        }

        private static bool IsEdited(ShiftData shift, List<ShiftData> currentShifts)
        {
            ShiftData currentShiftfromState = currentShifts.Where(currentShift => shift.Id == currentShift.Id).FirstOrDefault();

            if (!currentShiftfromState.ShiftName.Equals(shift.ShiftName))
            {
                return true;
            }

            if (!currentShiftfromState.StartTime.Equals(shift.StartTime))
            {
                return true;
            }

            if (!currentShiftfromState.EndTime.Equals(shift.EndTime))
            {
                return true;
            }

            if (!currentShiftfromState.DayId.Equals(shift.DayId))
            {
                return true;
            }

            if (!currentShiftfromState.TargetProduction.Equals(shift.TargetProduction))
            {
                return true;
            }
            return false;
        }
    }
}
