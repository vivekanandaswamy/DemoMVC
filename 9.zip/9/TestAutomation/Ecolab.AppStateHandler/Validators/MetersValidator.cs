﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Validators
{
    public class MetersValidator : BaseValidator
    {
        public static List<Meter> AddedMeters()
        {
            return AddedEntities<Meter>(AppState.RetrieveState<MeterState, Meter>(), AppState.GetState<MeterState>().GetAllMeters());            
        }

        public static List<Meter> DeletedMeters()
        {
            return DeletedEntities<Meter>(AppState.RetrieveState<MeterState, Meter>(), AppState.GetState<MeterState>().GetAllMeters());            
        }        
    }
}
