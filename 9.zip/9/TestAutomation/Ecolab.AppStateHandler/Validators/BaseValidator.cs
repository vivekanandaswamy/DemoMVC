﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Validators
{
    public class BaseValidator
    {
        protected static List<T> AddedEntities<T>(List<T> entitiesList1, List<T> entitiesList2) where T : BaseEntity
        {
            List<T> diffMeters = new List<T>();
            foreach (T entity2 in entitiesList2)
            {
                if (entitiesList1.Where(entity1 => entity1.Id == entity2.Id).ToList().Count <= 0)
                {
                    diffMeters.Add(entity2);
                }
            }
            return diffMeters;
        }

        protected static List<T> DeletedEntities<T>(List<T> entitiesList1, List<T> entitiesList2) where T : BaseEntity
        {
            List<T> diffMeters = new List<T>();
            foreach (T entity1 in entitiesList1)
            {
                if (entitiesList2.Where(entity2 => entity2.Id == entity1.Id).ToList().Count <= 0)
                {
                    diffMeters.Add(entity1);
                }
            }
            return diffMeters;
        }
    }
}
