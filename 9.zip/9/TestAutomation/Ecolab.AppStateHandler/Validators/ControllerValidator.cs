﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler.Validators
{
    public class ControllerValidator
    {
        private string connectionString;
        private ControllerState controllerState;

        public ControllerValidator(string dbconnString)
        {
            connectionString = dbconnString;            
        }

        private void Initialize()
        {
            controllerState = new ControllerState(connectionString);
            controllerState.Initialize();
        }

        public bool IsControllerPresent(string controllerName)
        {
            return controllerState.GetControllers.Execute.Where(controller => controller.ControllerName.Equals(controllerName)).ToList().Count >= 0;
        }

        public bool IsWasherPresent(string washerName)
        {
            return controllerState.GetControllersAndWashers.Where(controller => controller.Washers
                                                                                    .Any(washer => washer.MachineName.Equals(washerName))).ToList().Count >= 0;
        }
                                                                                
    }
}
