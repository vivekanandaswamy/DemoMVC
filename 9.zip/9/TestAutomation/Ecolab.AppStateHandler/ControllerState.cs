﻿using Ecolab.AppStateHandler.Entities;
using Ecolab.CommonUtilityPlugin;
using Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class ControllerState : BaseState, IStateManagement
    {
        private List<Entities.Controller> controllers;

        public ControllerState(string dbConnectionString)
            :base(dbConnectionString)
        { }

        public void Initialize()
        {
            controllers = GetControllersAndWashers;
        }

        public ControllerState GetControllers
        {
            get
            {
                DBAccess.QueryString = SQL.Resource.GetControllers;
                controllers = DBAccess.GetData<Entities.Controller>();
                return this;    
            }       
        }

        private ControllerState GetWashers
        {
            get
            {
                
                foreach (Entities.Controller controller in controllers)
                {
                    DBAccess.QueryString = SQL.Resource.GetWashers;
                    controller.Washers = DBAccess.GetData<Entities.Washer>((command) =>
                    {
                        ((SqlCommand)command).Parameters.AddWithValue("ControllerId", controller.ControllerId);
                    }).ToList();
                }
                return this;
            }
            
        }

        private ControllerState GetTagsAndFormulas
        {
            get
            {
                foreach (Entities.Controller controller in controllers)
                {
                    foreach (Entities.Washer washer in controller.Washers)
                    {
                        DBAccess.QueryString = SQL.Resource.GetTags;
                        washer.WasherTags = DBAccess.GetData<Entities.Tag>((command) =>
                        {
                            ((SqlCommand)command).Parameters.AddWithValue("WasherId", washer.WasherId);
                        }).ToList();

                        DBAccess.QueryString = SQL.Resource.GetFormula;
                        washer.Formulas = DBAccess.GetData<Entities.Formula>((command) =>
                        {
                            ((SqlCommand)command).Parameters.AddWithValue("IsTunnel", washer.IsTunnel);
                            ((SqlCommand)command).Parameters.AddWithValue("WasherGroupId", washer.GroupId);
                        }).ToList();
                    }
                }
                return this;
            }
        }

        public List<Entities.Controller> GetControllersAndWashers 
        { 
            get
            {
                return  GetControllers
                       .GetWashers
                       .Execute;
            }
        }

        public List<Entities.Controller> GetControllersWashersFormulas
        {
            get
            {
                return GetControllers
                       .GetWashers
                       .GetTagsAndFormulas
                       .Execute;
            }
        }

        public List<Entities.Controller> Execute
        {
            get
            {
                return controllers;
            }
        }

        public int CreateUtilityLogger(string topicName)
        {
            int controllerId = 0;
            SqlParameter param = new SqlParameter { ParameterName = "ControllerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            string utilityLogger = Data.Resource1.UtilityLogger;
            Plant plant = AppState.GetState<PlantState>().GetPlantDetails();
            int controllerNumber = (int)DBAccess.DataRows(SQL.Resource.GetRandomControllerNumber)[0].ItemArray[0];
            utilityLogger = utilityLogger.Replace("EcolabAccountNumber=\"\"", string.Format("EcolabAccountNumber=\"{0}\"", plant.EcolabAccountNumber));
            utilityLogger = utilityLogger.Replace("TopicName=\"\"", string.Format("TopicName=\"{0}\"", topicName));
            utilityLogger = utilityLogger.Replace("ControllerNumber=\"\"", string.Format("ControllerNumber=\"{0}\"", controllerNumber));

            //DBAccess.QueryString = SQL.Resource.GetRandomControllerNumber;
            

            DBAccess.QueryString = "[TCD].SaveControllerSetupData";
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).CommandType = CommandType.StoredProcedure;
                ((SqlCommand)command).Parameters.AddWithValue("UserId", 1);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerSetupData", utilityLogger);
                ((SqlCommand)command).Parameters.Add(param);
                ((SqlCommand)command).Parameters.Add(paramLastModifiedTimeStamp);
            });
            controllerId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);
            return controllerId;
        }

        public int CreateABUltrax(string topicName)
        {
            int controllerId = 0;
            SqlParameter param = new SqlParameter { ParameterName = "ControllerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            string utilityLogger = Data.Resource1.UltraxAB;
            Plant plant = AppState.GetState<PlantState>().GetPlantDetails();
            int controllerNumber = (int)DBAccess.DataRows(SQL.Resource.GetRandomControllerNumber)[0].ItemArray[0];
            utilityLogger = utilityLogger.Replace("EcolabAccountNumber=\"\"", string.Format("EcolabAccountNumber=\"{0}\"", plant.EcolabAccountNumber));
            utilityLogger = utilityLogger.Replace("TopicName=\"\"", string.Format("TopicName=\"{0}\"", topicName));
            utilityLogger = utilityLogger.Replace("ControllerNumber=\"\"", string.Format("ControllerNumber=\"{0}\"", controllerNumber));


            DBAccess.QueryString = "[TCD].SaveControllerSetupData";
            DBAccess.ExecuteCommand(command =>
            {
                ((SqlCommand)command).CommandType = CommandType.StoredProcedure;
                ((SqlCommand)command).Parameters.AddWithValue("UserId", 1);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerSetupData", utilityLogger);
                ((SqlCommand)command).Parameters.Add(param);
                ((SqlCommand)command).Parameters.Add(paramLastModifiedTimeStamp);
            });
            controllerId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);
            return controllerId;
        }

        public int CreateBeckhoffUltrax(string topicName)
        {
            int controllerId = 0;
            SqlParameter param = new SqlParameter { ParameterName = "ControllerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            string utilityLogger = Data.Resource1.UltraxBeckhoff;
            Plant plant = AppState.GetState<PlantState>().GetPlantDetails();
            int controllerNumber = (int)DBAccess.DataRows(SQL.Resource.GetRandomControllerNumber)[0].ItemArray[0];
            utilityLogger = utilityLogger.Replace("EcolabAccountNumber=\"\"", string.Format("EcolabAccountNumber=\"{0}\"", plant.EcolabAccountNumber));
            utilityLogger = utilityLogger.Replace("TopicName=\"\"", string.Format("TopicName=\"{0}\"", topicName));
            utilityLogger = utilityLogger.Replace("ControllerNumber=\"\"", string.Format("ControllerNumber=\"{0}\"", controllerNumber));


            DBAccess.QueryString = "[TCD].SaveControllerSetupData";
            DBAccess.ExecuteCommand(command =>
            {
                ((SqlCommand)command).CommandType = CommandType.StoredProcedure;
                ((SqlCommand)command).Parameters.AddWithValue("UserId", 1);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerSetupData", utilityLogger);
                ((SqlCommand)command).Parameters.Add(param);
                ((SqlCommand)command).Parameters.Add(paramLastModifiedTimeStamp);
            });
            controllerId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);
            return controllerId;
        }

        public int CreateABUltraxTDI(string topicName)
        {
            int controllerId = 0;
            SqlParameter param = new SqlParameter { ParameterName = "ControllerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            string utilityLogger = Data.Resource1.UltraxTDIAB;
            Plant plant = AppState.GetState<PlantState>().GetPlantDetails();
            int controllerNumber = (int)DBAccess.DataRows(SQL.Resource.GetRandomControllerNumber)[0].ItemArray[0];
            utilityLogger = utilityLogger.Replace("EcolabAccountNumber=\"\"", string.Format("EcolabAccountNumber=\"{0}\"", plant.EcolabAccountNumber));
            utilityLogger = utilityLogger.Replace("TopicName=\"\"", string.Format("TopicName=\"{0}\"", topicName));
            utilityLogger = utilityLogger.Replace("ControllerNumber=\"\"", string.Format("ControllerNumber=\"{0}\"", controllerNumber));


            DBAccess.QueryString = "[TCD].SaveControllerSetupData";
            DBAccess.ExecuteCommand(command =>
            {
                ((SqlCommand)command).CommandType = CommandType.StoredProcedure;
                ((SqlCommand)command).Parameters.AddWithValue("UserId", 1);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerSetupData", utilityLogger);
                ((SqlCommand)command).Parameters.Add(param);
                ((SqlCommand)command).Parameters.Add(paramLastModifiedTimeStamp);
            });
            controllerId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);
            return controllerId;
        }

        public int CreateBeckhoffUltraxTDI(string topicName)
        {
            int controllerId = 0;
            SqlParameter param = new SqlParameter { ParameterName = "ControllerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            string utilityLogger = Data.Resource1.UltraxTDIBeckhoff;
            Plant plant = AppState.GetState<PlantState>().GetPlantDetails();
            int controllerNumber = (int)DBAccess.DataRows(SQL.Resource.GetRandomControllerNumber)[0].ItemArray[0];
            utilityLogger = utilityLogger.Replace("EcolabAccountNumber=\"\"", string.Format("EcolabAccountNumber=\"{0}\"", plant.EcolabAccountNumber));
            utilityLogger = utilityLogger.Replace("TopicName=\"\"", string.Format("TopicName=\"{0}\"", topicName));
            utilityLogger = utilityLogger.Replace("ControllerNumber=\"\"", string.Format("ControllerNumber=\"{0}\"", controllerNumber));


            DBAccess.QueryString = "[TCD].SaveControllerSetupData";
            DBAccess.ExecuteCommand(command =>
            {
                ((SqlCommand)command).CommandType = CommandType.StoredProcedure;
                ((SqlCommand)command).Parameters.AddWithValue("UserId", 1);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerSetupData", utilityLogger);
                ((SqlCommand)command).Parameters.Add(param);
                ((SqlCommand)command).Parameters.Add(paramLastModifiedTimeStamp);
            });
            controllerId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);
            return controllerId;
        }

        public List<T> GetFullState<T>() where T : Entities.BaseEntity
        {
            return GetControllersWashersFormulas.Cast<T>().ToList();
        }


        public string StateName
        {
            get 
            {
                return "Controller.osl";
            }
        }
    }
}
