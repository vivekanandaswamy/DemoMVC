﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class DryerState : BaseState
    {
        public DryerState(string connString)
            : base(connString)
        { }

        public MachineGroup CreateDryerGroup(string dryerGroupName)
        {
            DBAccess.QueryString = SQL.Resource.CreateDryerGroup;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("DryerGroupName", dryerGroupName);                
            });

            DBAccess.QueryString = SQL.Resource.GetLastCreatedMachineGroup;
            return DBAccess.GetData<MachineGroup>(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("GroupType", "Dryer Group");
            }).FirstOrDefault();            
        }

        public Dryer CreateDryer(string dryerTypeName, int dryerGroupId, string dryerName)
        {
            DBAccess.QueryString = SQL.Resource.CreateDryer;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("DryerTypeName", dryerTypeName);
                ((SqlCommand)command).Parameters.AddWithValue("DryerGroupId", dryerGroupId);
                ((SqlCommand)command).Parameters.AddWithValue("DryerName", dryerName);
            });

            DBAccess.QueryString = SQL.Resource.GetLastCreatedDryer;
            return DBAccess.GetData<Dryer>().FirstOrDefault();
        }

        public void DeleteAllDryers()
        {
            DBAccess.QueryString = SQL.Resource.DeleteAllDryers;
            DBAccess.ExecuteCommand();
        }
    }
}
