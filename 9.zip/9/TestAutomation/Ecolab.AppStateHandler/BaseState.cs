﻿using Ecolab.CommonUtilityPlugin;
using Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class BaseState
    {
        private static ContainerAccess container = new ContainerAccess();
        private string connectionString;

        public BaseState(string connection)
        {
            connectionString = connection;
        }

        private static DataAccess dataAccess;
        protected DataAccess DBAccess
        {
            get
            {
                if(null == dataAccess)
                {
                    dataAccess = CreatePlugin<DataAccess>();
                    dataAccess.ConectionString = connectionString;
                    dataAccess.DataCategory = DataCategory.SQLDB;
                }                
                return dataAccess;
            }

        }

        private static T CreatePlugin<T>() where T : IContainerPlugin
        {
            return container.GetPlugin<T>();
        }
    }
}
