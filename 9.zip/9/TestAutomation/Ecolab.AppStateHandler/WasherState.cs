﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class WasherState : BaseState
    {
        public WasherState(string connString)
            :base(connString)
        { }

        public WasherGroup CreateWasherGroup(string washerGroupTypeName, string washerGroupName)
        {
            DBAccess.QueryString = SQL.Resource.CreateWasherGroup;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("WasherGroupTypeName", washerGroupTypeName);
                ((SqlCommand)command).Parameters.AddWithValue("MyServiceWasherGroupGuid", new Guid());
                ((SqlCommand)command).Parameters.AddWithValue("WasherGroupName", washerGroupName);
            });

            return GetLastCreatedWasherGroup();
        }

        public void CreateConventionalWasher(int washerGroupId, int newWasherGroupId, string washerName, int controllerId, int lfsControllerNumber)
        {
            DBAccess.QueryString = SQL.Resource.CreateConventionalWasher;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("WasherGroupId", washerGroupId);
                ((SqlCommand)command).Parameters.AddWithValue("NewWasherGroupId", newWasherGroupId);  
                ((SqlCommand)command).Parameters.AddWithValue("WasherName", washerName);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerId", controllerId);
                ((SqlCommand)command).Parameters.AddWithValue("@LFSWasherNumber", lfsControllerNumber);
                ((SqlCommand)command).Parameters.AddWithValue("ConventionalWasherGuid", new Guid());
            });
        }

        //public void CreateConventionalWasherEU(int washerGroupId, int newWasherGroupId, string washerName, int controllerId, int lfsControllerNumber)
        //{
        //    DBAccess.QueryString = SQL.Resource.CreateConventionalWasher;
        //    DBAccess.ExecuteCommand(command =>
        //    {
        //        ((SqlCommand)command).Parameters.AddWithValue("WasherGroupId", washerGroupId);
        //        ((SqlCommand)command).Parameters.AddWithValue("NewWasherGroupId", newWasherGroupId);
        //        ((SqlCommand)command).Parameters.AddWithValue("WasherName", washerName);
        //        ((SqlCommand)command).Parameters.AddWithValue("ControllerId", controllerId);
        //        ((SqlCommand)command).Parameters.AddWithValue("@LFSWasherNumber", lfsControllerNumber);
        //        ((SqlCommand)command).Parameters.AddWithValue("ConventionalWasherGuid", new Guid());
        //    });
        //}

        public void CreateTunnelWasher(int washerGroupId, string tunnelName, int controllerId)
        {
            DBAccess.QueryString = SQL.Resource.CreateTunnelWasher;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("WasherGroupId", washerGroupId);
                ((SqlCommand)command).Parameters.AddWithValue("TunnelName", tunnelName);
                ((SqlCommand)command).Parameters.AddWithValue("ControllerId", controllerId);
            });
        }

        public List<WasherModelSize> GetAllWasherModelSize()
        {
            DBAccess.QueryString = SQL.Resource.GetWasherModelSize;
            return DBAccess.GetData<WasherModelSize>();
        }

        public WasherGroup GetLastCreatedWasherGroup()
        {
            DBAccess.QueryString = SQL.Resource.GetLastCreatedWasherGroup;
            return DBAccess.GetData<WasherGroup>().FirstOrDefault();
        }

        public WasherProgramSetup AddFormulatoWasherGroup(int programNumber, WasherGroup washerGroup)
        {
            DBAccess.QueryString = SQL.Resource.AddWasherGroupFormula;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("ProgramNumber",programNumber);
                ((SqlCommand)command).Parameters.AddWithValue("WasherGroupId", washerGroup.Id);                
            });

            DBAccess.QueryString = SQL.Resource.GetLastCreatedWasherProgramSetup;
            return DBAccess.GetData<WasherProgramSetup>().FirstOrDefault();            
        }

        public void AddWashStep(WasherProgramSetup programSetup, int stepNumber)
        {
            DBAccess.QueryString = SQL.Resource.AddWashSteps;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("WasherProgramStepId",programSetup.Id);
                ((SqlCommand)command).Parameters.AddWithValue("StepNumber", stepNumber);
            });
        }

        public WasherProgramSetup GetWasherSetup(WasherProgramSetup washerProgramSetup)
        {
            DBAccess.QueryString = SQL.Resource.GetWasherProgramSetup;
            return DBAccess.GetData<WasherProgramSetup>(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("WasherProgramStepId", washerProgramSetup.Id);
            }).FirstOrDefault();
        }

        public void AddWashStep(WasherProgramSetup programSetup, int stepNumber, int StepRunTime)
        {
            DBAccess.QueryString = SQL.Resource.AddWashSteps;
            DBAccess.ExecuteCommand(command =>
            {
                ((SqlCommand)command).Parameters.AddWithValue("WasherProgramStepId", programSetup.Id);
                ((SqlCommand)command).Parameters.AddWithValue("StepNumber", stepNumber);
                ((SqlCommand)command).Parameters.AddWithValue("StepRunTime", StepRunTime);
            });
        }
    }
}
