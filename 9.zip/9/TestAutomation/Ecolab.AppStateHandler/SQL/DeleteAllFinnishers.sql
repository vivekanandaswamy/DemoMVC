UPDATE TCD.MachineGroup
SET Is_Deleted = 1
WHERE GroupTypeId IN (SELECT Id FROM TCD.MachineGroupType WHERE GroupType='Finnisher Group')

Update TCD.Finnishers
SET Is_deleted = 1