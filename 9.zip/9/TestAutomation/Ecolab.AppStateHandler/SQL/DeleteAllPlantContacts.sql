UPDATE	TCD.PlantContact
SET Is_Deleted = 1	