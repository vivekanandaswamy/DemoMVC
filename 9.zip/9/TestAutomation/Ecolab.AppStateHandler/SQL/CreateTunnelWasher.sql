-- Create Tunnel Washer

DECLARE @EcolabAcntNbr NVARCHAR(100) = (SELECT EcolabAccountNumber FROM TCD.Plant)
DECLARE @WasherModelName NVARCHAR(50) = (
											SELECT top(1) WasherModelName FROM tcd.WasherModelSize 
											WHERE WasherSize Is Not NULL
											AND ModelTypeId = 2
											AND Is_Deleted = 'FALSE'	
										)
DECLARE @RegionId SMALLINT = (SELECT RegionId FROM TCD.Plant)
DECLARE @WasherModeId TINYINT = (SELECT TOP(1) WasherModeId FROM tcd.WasherMode WHERE WasherModeName = 'Binary')
DECLARE @TransferTypeId TINYINT = (SELECT top (1) TunnelTransferTypeId FROM TCD.TunnelTransferType Where Name = 'Top' order by RegionId)
DECLARE @PressExtractor TINYINT = (
									SELECT TOP(1) TunnelPressExtractorId FROM TCD.TunnelPressExtractor
									WHERE RegionId = (SELECT RegionId FROM TCD.Plant)
									AND Is_Deleted = 0
									)
DECLARE @MyServiceWasherId UniqueIdentifier = '00000000-0000-0000-0000-000000000000' 
DECLARE @OutputTunnelId	INT


DECLARE @Random	INT
DECLARE @Lower	INT = 1 ---- The lowest random number
DECLARE @Upper	INT = (SELECT (CAST(
				(SELECT Top(1) PlantWasherNumber from TCD.Washer ORDER BY PlantWasherNumber DESC) AS INT
			 ) + 1000))
			  ---- The highest random number
DECLARE @IsPresent BIT

SET @Random = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)
--SELECT @Random

SET @IsPresent = (SELECT 1 FROM TCD.WasherGroup WHERE WasherGroupNumber = @Random)
--SELECT @Random , @IsPresent

WHILE (@IsPresent = 1)
BEGIN
	SET @Random = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)
	SET @IsPresent = (SELECT 1 FROM TCD.WasherGroup WHERE WasherGroupNumber = @Random)
	--SELECT @Random, @IsPresent
	CONTINUE
END
SELECT @Random AS PlantWasherNumber


EXEC [TCD].[AddTunnel]		@MyServiceWasherId
						,	@EcolabAcntNbr
						,	@WasherGroupId
						,	@TunnelName
						,	@WasherModelName
						,	@RegionId
						,	@ControllerId
						,	1
						,	@Random
						,	@WasherModeId
						,	300
						,	'FALSE'
						,	10
						,	12
						,	@TransferTypeId
						,	@PressExtractor
						,	100
						,	127
						,	'Test dummy tunnel Created For Testing Purpose'
						,	1
						,	@OutputTunnelId