DECLARE @Random	INT
DECLARE @Lower	INT = 1 ---- The lowest random number
DECLARE @Upper	INT = (SELECT (CAST(
				(SELECT Top(1) ControllerNumber from TCD.ConduitController ORDER BY ControllerNumber DESC) AS INT
			 ) + 10000))
			  ---- The highest random number
DECLARE @IsPresent BIT

SET @Random = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)
--SELECT @Random

SET @IsPresent = (SELECT 1 FROM TCD.WasherGroup WHERE WasherGroupNumber = @Random)
--SELECT @Random , @IsPresent

WHILE (@IsPresent = 1)
BEGIN
	SET @Random = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)
	SET @IsPresent = (SELECT 1 FROM TCD.WasherGroup WHERE WasherGroupNumber = @Random)
	--SELECT @Random, @IsPresent
	CONTINUE
END
SELECT @Random