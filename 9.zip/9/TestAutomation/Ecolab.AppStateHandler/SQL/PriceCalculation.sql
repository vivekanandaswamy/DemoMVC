﻿Select distinct x.ProductID,

(case y.UnitWeightVolumeUOMId when 1 then 35.274

when 2 then 0.035274

WHEN  5 THEN 1

WHEN  6 THEN 16

WHEN  8 THEN 33.814

WHEN  10 THEN 0.033814

WHEN  12 THEN 128

WHEN  13 THEN 32 END) as ValueBasedUOMID

from TCD.ProductDataMapping x join (Select a.ProductID,b.PackageSizeWeightUOMCode,b.UnitWeightVolumeUOMId,(b.UnitPerPackage * b.UnitWeightVolume)AS T_C

from TCD.ProductMaster a join TCD.PackageSize b on a.PackageSizeId=b.PackageSizeID) y on x.ProductID=y.ProductId 
and  x.ProductID in (select Top(1) ProductId from tcd.ProductMaster where Name like @Name)