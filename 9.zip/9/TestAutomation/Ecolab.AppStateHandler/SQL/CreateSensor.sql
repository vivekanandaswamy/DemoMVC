--Create Sensor
DECLARE @Scope VARCHAR(100)
DECLARE @SensorId INT =  (SELECT (CAST(
							(SELECT top(1) SensorId FROM TCD.Sensor ORDER By SensorId DESC) AS INT
						) + 1))
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)
DECLARE @ControllerId INT = (SELECT ControllerId FROM tcd.ConduitController WHERE TopicName = @Topic)
DECLARE @SensorTypeId INT = (SELECT ResourceId FROM TCD.SensorTypeMaster WHERE Name = @SensorTypeName)


EXEC TCD.SavePlantSensorDetails		 @SensorId
									,@EcolabAcntNumbr
									,@ControllerId
									,@SensorName
									,@SensorTypeId
									,@MachineGroupId
									,@MachineId
									,@OutputType
									,null
									,@UOM
									,null
									,0
									,null
									,null
									,null
									,null
									,null
									,@Scope				