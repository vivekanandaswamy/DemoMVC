UPDATE TCD.TankSetup
SET Is_Deleted = 1