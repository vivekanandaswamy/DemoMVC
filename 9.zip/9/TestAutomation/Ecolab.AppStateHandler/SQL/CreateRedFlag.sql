--Create Red Flag

DECLARE @Scope varchar(100)
DECLARE @ItemId INT = (SELECT Id FROM tcd.RedFlagItemList WHERE ItemName = @RedFlagTypeName)
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)

EXEC [TCD].[SaveRedFlagDetails]		  1
									, @ItemId
									, 2
									, 10
									, @MachineGroupId
									, @MachineId
									, @EcolabAcntNumbr
									, 0
									, @Scope