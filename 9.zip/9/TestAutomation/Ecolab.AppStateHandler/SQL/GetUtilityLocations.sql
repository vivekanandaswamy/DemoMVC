SELECT DISTINCT 
				GT.Id,	
				GT.GroupDescription,
				GT.GroupTypeId,
				GT.Id,
				MS.IsTunnel
FROM			[TCD].MachineGroup GT 
INNER JOIN [TCD].MachineSetup MS 
ON				GT.Id = MS.GroupId  
WHERE			GroupTypeId in (1,2) 
AND				GT.Is_Deleted = 0
AND				MS.IsDeleted = 0
