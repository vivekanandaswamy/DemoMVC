--create conventional washer --

DECLARE @Random	INT
DECLARE @Lower	INT = 1 ---- The lowest random number
DECLARE @Upper	INT = (SELECT (CAST(
				(SELECT Top(1) PlantWasherNumber from TCD.Washer ORDER BY PlantWasherNumber DESC) AS INT
			 ) + 1000))
			  ---- The highest random number
DECLARE @IsPresent BIT

SET @Random = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)
--SELECT @Random

SET @IsPresent = (SELECT 1 FROM TCD.WasherGroup WHERE WasherGroupNumber = @Random)
--SELECT @Random , @IsPresent

WHILE (@IsPresent = 1)
BEGIN
	SET @Random = ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0)
	SET @IsPresent = (SELECT 1 FROM TCD.WasherGroup WHERE WasherGroupNumber = @Random)
	--SELECT @Random, @IsPresent
	CONTINUE
END
SELECT @Random AS PlantWasherNumber

DECLARE @ConventionalWasherId INT
DECLARE @OutputLastModifiedTimestampAtLocal DATETIME
DECLARE @ModelId INT = (SELECT top(1) WasherModelId FROM tcd.WasherModelSize WHERE WasherSize Is Not NULL)
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)

EXEC [TCD].[AddConventional]		@EcolabAcntNumbr
								,	@WasherGroupId
								,	@NewWasherGroupId
								,	@WasherName
								,	@ModelId
								,	@ControllerId
								,	@LFSWasherNumber
								,	@Random
								,	1
								,	90
								,	'FALSE'
								,	'FALSE'
								,	1
								,	10
								,	40
								,	99
								,	null
								,	1
								,	@ConventionalWasherGuid
								,	@ConventionalWasherId
								,	null
								,	@OutputLastModifiedTimestampAtLocal