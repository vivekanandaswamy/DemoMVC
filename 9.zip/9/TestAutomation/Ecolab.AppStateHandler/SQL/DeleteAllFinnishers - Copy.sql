Update TCD.Finnishers
SET Is_deleted = 1