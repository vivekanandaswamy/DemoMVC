-- Create Storage Tank

DECLARE @EcolabAccntNumbr NVARCHAR(50) = (SELECT EcolabAccountNumber FROM TCD.Plant)
CREATE TABLE #Temp 
(
		ProductName NVARCHAR(100)
	,	ProductId INT
)
INSERT INTO #Temp
EXEC TCD.GetProductsForControllerEquipment @EcolabAccntNumbr
DECLARE @ProductId INT = (SELECT TOP(1) ProductId FROM #Temp)
DROP TABLE #Temp

--SELECT @ProductId

EXEC [TCD].[SaveTankDetails]		@TankName
								,	@EcolabAccntNumbr
								,	1
								,	4
								,	10
								,	@ControllerId
								,	0
								,	5
								,	'0-20mA'
								,	@ProductId
								,	1
								,	null
								,	null
								,	null
								,	null