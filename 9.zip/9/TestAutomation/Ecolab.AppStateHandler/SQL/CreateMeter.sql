--Create Meter Associated with dryer

DECLARE @Scope VARCHAR(100)
DECLARE @UtilityType INT
DECLARE @ControllerId INT
DECLARE @ControllerModelId INT
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)
DECLARE @Topic VARCHAR(100) = @TopicName
DECLARE @MeterId INT =  (SELECT (CAST(
							(SELECT top(1) MeterID FROM TCD.Meter ORDER By MeterId DESC) AS INT
						) + 1))

SET @UtilityType = (select ResourceId from tcd.UtilityMaster Where Name = @UtilityName)
SET @ControllerId = (select ControllerId from tcd.ConduitController where TopicName = @Topic)
SET @ControllerModelId = (select ControllerModelId from tcd.ConduitController where TopicName = @Topic)
EXEC [TCD].[SavePlantMeterDetails]    @MeterId
									, @EcolabAcntNumbr 
									, @MeterName
									, @UtilityType 
									, @MachineGroupId
									, @MachineId 
									, null
									, null
									, null
									, null
									, @ControllerId
									, @ControllerModelId
									, null
									, null
									, null
									, 0
									, @Scope