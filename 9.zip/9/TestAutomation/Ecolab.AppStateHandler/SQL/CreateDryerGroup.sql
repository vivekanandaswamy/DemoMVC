--create dryer group --

DECLARE @Scope	VARCHAR(100)
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber 
FROM TCD.Plant)

EXEC [TCD].[SaveDryerGroups]	  @DryerGroupName
								, @EcolabAcntNumbr
								, 0 
								, @Scope
