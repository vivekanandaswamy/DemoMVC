SELECT	--*
		 PlantId
		,EcolabAccountNumber
		,Name
		,ExportPath
		,RegionId
		,CurrencyCode
FROM	TCD.Plant