SELECT	top(1) 
		MCHNGRP.Id
	   ,GroupDescription
	   ,GroupTypeId	   				
FROM tcd.MachineGroup MCHNGRP
INNER JOIN TCD.MachineGroupType MCHGRPTYP
ON	MCHNGRP.GroupTypeId = MCHGRPTYP.Id
WHERE MCHGRPTYP.GroupType = @GroupType
ORDER BY LastModifiedTime DESC