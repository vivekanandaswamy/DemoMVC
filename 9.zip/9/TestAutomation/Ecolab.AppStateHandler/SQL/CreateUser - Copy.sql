Declare @RoleId INT , @EcolabAccountNumber NVARCHAR(1000)
Declare	@Scope VARCHAR(100)
Declare @Emailid nvarchar(20)

Set @RoleId = (Select RoleId from TCD.UserRoles Where code = @UserRoleCode)
Set @EcolabAccountNumber = (Select EcolabAccountNumber from TCD.Plant)
Set @EmailId = (Select (Concat(@LoginName,'@xxx.com')))


Exec [TCD].[SaveUserDetails]		NULL
								,	@FirstName
								,	@LastName
								,	@LoginName
								,	@Password
								,	@EmailId
								,	'1111111'
								,	@RoleId
								,	0
								,	@EcolabAccountNumber
								,	NULL
								,	1
								,	@Scope