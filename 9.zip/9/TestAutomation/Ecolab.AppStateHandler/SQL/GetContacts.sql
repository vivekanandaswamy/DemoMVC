SELECT	ID,
		ContactFirstName,
		ContactLastName,
		ContactTitle,
		ContactEMail,
		ContactOfficePhone,
		ContactMobilePhone
FROM	TCD.PlantContact
WHERE	Is_Deleted = 0