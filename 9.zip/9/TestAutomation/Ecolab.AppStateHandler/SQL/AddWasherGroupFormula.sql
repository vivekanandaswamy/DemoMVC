--Add Washer Group Formula

DECLARE @ProgramId	INT = 1
--DECLARE @ProgramNumber	INT  = 3
--DECLARE @WasherGroupId	INT  = 155
DECLARE @ProgramSetupId SMALLINT
DeCLARE @UserId INT
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)

CREATE TABLE #TEMP
(
		ProgramId INT
	,	Name NVARCHAR(100)
	,	Pieces INT
	,	TextileId INT
	,	CategoryName NVARCHAR(100)
	,	EcolabSaturationId INT
	,	EcolabSaturationName NVARCHAR(100)
	,	PlantProgramId INT
	,	PlantProgramName NVARCHAR(100)
	,	ChainTextileId INT
	,	ChainTextileCategory NVARCHAR(100)
	,	Rewash INT
	,	Weight INT
	,	TotalCount INT
	,	CustomerId INT
	,	LastModifiedTime DateTime
	,	EcolabAccountNumber NVARCHAR(100)
	,	Is_Deleted BIT
	,	Weight_Display	INT	
)
--INSERT INTO #TEMP
--EXEC [TCD].[GetPrograms] @EcolabAcntNumbr
----SET @ProgramId = (SELECT TOP(1) ProgramId FROM #TEMP)
--SET @ProgramId = 45
----SELECT TOP(1) ProgramId FROM #TEMP
--DROP TABLE #TEMP
SET @UserId = (select UserId from TCD.UserMaster where LoginName like 'Admin' and UserId = 1)

EXEC [TCD].[AddWasherGroupFormula] 		@EcolabAcntNumbr
									,	@WasherGroupId									
									,	@ProgramNumber
									,	@ProgramId
									,	25
									,	10
									,	30
									,	1
									,   @UserId
									,	@ProgramSetupId