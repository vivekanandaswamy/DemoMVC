SELECT			--*
				MTR.MeterId,
				MTR.ControllerID,
				CNTLR.TopicName,
				CNTLR.Name,
				MTR.UtilityType,
				MTR.Description				
FROM			TCD.Meter MTR
INNER JOIN		TCD.ConduitController CNTLR
ON				MTR.ControllerID = CNTLR.ControllerId
WHERE			MTR.Is_deleted = 0
AND				CNTLR.IsDeleted = 0