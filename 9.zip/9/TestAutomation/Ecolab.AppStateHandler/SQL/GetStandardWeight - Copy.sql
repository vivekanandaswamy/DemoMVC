SELECT		CAST((CAST(WSHPRGSETUP.NominalLoad AS INT) * CAST(WSHR.MaxLoad AS INT))/CONVERT(decimal(10,2), 100) AS INT) AS StandardWeight,
			TargetTurnTime
FROM		TCD.Washer	WSHR
INNER JOIN	TCD.MachineSetup	MCHNSETUP
ON			WSHR.WasherId	=	MCHNSETUP.WasherId
INNER JOIN	TCD.WasherProgramSetup		WSHPRGSETUP
ON			MCHNSETUP.GroupId	=	WSHPRGSETUP.WasherGroupId
WHERE		WSHR.WasherId		=		@WasherId