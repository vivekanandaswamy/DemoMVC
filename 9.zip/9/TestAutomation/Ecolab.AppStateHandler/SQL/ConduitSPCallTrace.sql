CREATE TABLE #TEMP (objectid INT, ProcName NVARCHAR(MAX),execution_count INT,sql_statement NVARCHAR(MAX),last_execution_time DATETIME)

INSERT INTO #TEMP(objectid, ProcName,execution_count,sql_statement,last_execution_time )
SELECT DISTINCT TOP(20) objectid, ProcName,execution_count,sql_statement,last_execution_time   
FROM (SELECT COALESCE((OBJECT_NAME(s2.objectid)),'Ad-Hoc') AS ProcName,
execution_count,
s2.objectid,
(SELECT TOP 1 SUBSTRING(s2.TEXT,statement_start_offset / 2+1 ,
( (CASE WHEN statement_end_offset = -1
THEN (LEN(CONVERT(NVARCHAR(MAX),s2.TEXT)) * 2)
ELSE statement_end_offset END)- statement_start_offset) / 2+1)) AS sql_statement,
last_execution_time
FROM sys.dm_exec_query_stats AS s1


CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS s2 ) x
WHERE sql_statement NOT like 'SELECT TOP(20) FROM(SELECT %'
--and OBJECTPROPERTYEX(x.objectid,'IsProcedure') = 1
ORDER BY last_execution_time DESC

select * from #TEMP 


--SELECT  *
--FROM    (SELECT UniqueID, ProcName, objectid,execution_count,sql_statement,last_execution_time,
--                ROW_NUMBER() OVER (PARTITION BY objectid ORDER BY ProcName) AS RowNumber
--         FROM   #temp
--         ) AS a
--WHERE   a.RowNumber = 1

DROP TABLE #TEMP 
