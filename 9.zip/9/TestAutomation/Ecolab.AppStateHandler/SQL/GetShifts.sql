SELECT	ShiftId,
		ShiftName,
		DayId,
		StartTime,
		EndTime,
		TargetProduction		
FROM	TCD.ShiftData
WHERE	Is_Deleted = 0