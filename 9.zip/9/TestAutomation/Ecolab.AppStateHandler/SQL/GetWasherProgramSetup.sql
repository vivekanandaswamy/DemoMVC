SELECT		WasherProgramSetupId
		,	WasherGroupId
		,	ProgramNumber
		,	ProgramId
		,	TotalRunTime
		,	TotalSteps
FROM	TCD.WasherProgramSetup
WHERE	WasherProgramSetupId = @WasherProgramStepId