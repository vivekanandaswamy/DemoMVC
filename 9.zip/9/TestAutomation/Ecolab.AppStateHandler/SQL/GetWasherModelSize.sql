DECLARE @RegionID int
SELECT @RegionID = p.RegionId FROM TCD.Plant p
SELECT wms.WasherModelId, 
wms.WasherModelName, 
WasherSize 
FROM TCD.WasherModelSize wms 
WHERE wms.WasherSize IS NOT NULL
AND wms.RegionId = @RegionID
AND wms.ModelTypeId = 1 -- only conventional model