--create dryer --

DECLARE @Scope VARCHAR(100)
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)
DECLARE @DryerTypeId INT = (SELECT DryerTypeId from tcd.DryerType WHERE Name = @DryerTypeName)

EXEC [TCD].[SaveDryer]	  @DryerGroupId
						, 1
						, @DryerName 
						, 10 
						, @DryerTypeId
						, @EcolabAcntNumbr 
						, 0 
						, 2
						, @Scope