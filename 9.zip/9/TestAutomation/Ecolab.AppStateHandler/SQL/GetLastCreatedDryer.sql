SELECT	top(1) 
		Id
	   ,DryerGroupId
	   ,DryerNo
	   ,Description	   				
FROM tcd.Dryers
ORDER BY LastModifiedTime DESC