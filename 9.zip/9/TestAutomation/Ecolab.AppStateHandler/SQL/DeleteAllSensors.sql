UPDATE			TCD.Sensor
SET				Is_deleted = 1