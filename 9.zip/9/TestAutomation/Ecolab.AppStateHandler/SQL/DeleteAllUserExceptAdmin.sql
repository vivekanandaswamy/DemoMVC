UPDATE TCD.UserMaster
SET IsActive = 0
WHERE LoginName <> 'Admin'