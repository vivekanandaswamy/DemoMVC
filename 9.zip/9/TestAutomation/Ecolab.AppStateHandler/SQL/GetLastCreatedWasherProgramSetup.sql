--Get WasherProgramSetupId of last added formula to washer group

SELECT	TOP(1)
			WasherProgramSetupId
		,	WasherGroupId
		,	ProgramNumber
		,	ProgramId
		,	TotalRunTime
		,	TotalSteps
FROM	TCD.WasherProgramSetup
ORDER BY LastModifiedTime DESC