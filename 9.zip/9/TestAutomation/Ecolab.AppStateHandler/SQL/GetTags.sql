SELECT			WSHTAGS.TagType,
				WSHTAGS.TagAddress
FROM			TCD.WasherTags		WSHTAGS
WHERE			WSHTAGS.WasherId				=				@WasherId
AND				WSHTAGS.Active					=				1