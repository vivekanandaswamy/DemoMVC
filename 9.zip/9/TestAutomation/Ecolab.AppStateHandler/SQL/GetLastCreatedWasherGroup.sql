SELECT top(1)	WasherGroupId
			,	WasherGroupTypeId
			,	WasherGroupName
			,	WasherGroupNumber 
FROM TCD.WasherGroup
ORDER BY WasherGroupId DESC