UPDATE			TCD.Meter
SET				Is_deleted = 1