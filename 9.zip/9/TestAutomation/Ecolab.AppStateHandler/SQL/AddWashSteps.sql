-- Add wash steps to formula

DECLARE @RegionId INT = (SELECT RegionId FROM TCD.Plant)
DECLARE @StepTypeId INT
DECLARE @WaterTypeId INT
DECLARE @DrainDestinationId INT
--DECLARE @StepNumber INT  = 1
--DECLARE @WasherProgramStepId INT  = 195
DECLARE @DosingSetupId INT
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)

--DECLARE @RegionId INT = (SELECT RegionId FROM TCD.Plant)
--DECLARE @StepTypeId INT
CREATE TABLE #Temp1
(
		StepId INT
	,	StepName NVARCHAR(100)
)
INSERT INTO #Temp1
EXEC [TCD].[GetWashOperations] 
									@RegionId
								,	0
SET @StepTypeId = (SELECT TOP(1) StepId FROM #Temp1)
DROP TABLE #Temp1
SELECT @StepTypeId

--DECLARE @WaterTypeId INT
CREATE TABLE #Temp2
(
		Id INT
	,	Name NVARCHAR(100)
	,	RegionID INT
	,	MySerViceUtilTypeCode NVARCHAR(10)
)
INSERT INTO #Temp2	
							
EXEC [TCD].[GetWaterTypes] @RegionId
SET @WaterTypeId = (SELECT TOP(1) Id FROM #Temp2)
DROP TABLE #Temp2
SELECT @WaterTypeId

--DECLARE @DrainDestinationId INT
CREATE TABLE #Temp3
(
		DrainDestinationId INT
	,	DrainDestinationName NVARCHAR(100)	
)
INSERT INTO #Temp3								
EXEC [TCD].[GetDrainDestination]
SET @DrainDestinationId = (SELECT TOP(1) DrainDestinationId FROM #Temp3)
DROP TABLE #Temp3
SELECT @DrainDestinationId

EXEC [TCD].[AddWasherGroupWashStepFormula]		@EcolabAcntNumbr
											,	@StepNumber
											,	@StepTypeId
											,	120
											,	10
											,	@WaterTypeId
											,	1
											,	@DrainDestinationId
											,	1
											,	'Test Test Test'
											,	@WasherProgramStepId
											,	1
											,	1
											,	'FALSE'
											,	@DosingSetupId