UPDATE	TCD.ShiftData
SET Is_Deleted = 1	