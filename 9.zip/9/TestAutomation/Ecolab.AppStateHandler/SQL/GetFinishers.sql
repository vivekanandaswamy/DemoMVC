SELECT			--*
				FNRS.FinnisherId,				
				FNRS.FinnisherNo,
				FNRS.FinnisherGroupId,
				FNRS.Name,				
				FNRS.FinnisherTypeId		
FROM			TCD.Finnishers FNRS
WHERE			FNRS.Is_deleted = 0