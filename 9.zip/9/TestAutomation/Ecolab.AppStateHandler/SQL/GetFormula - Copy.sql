IF	@IsTunnel = 0

	BEGIN
			SELECT DISTINCT		
						WSHPRGSETUP.ProgramNumber,
						WSHPRGSETUP.TotalRunTime,
						WSHPRGSETUP.Category,
						WSHPRGSETUP.NominalLoad,
						CAST((CAST(WSHPRGSETUP.NominalLoad AS INT) * CAST(WSHR.MaxLoad AS INT))/CONVERT(decimal(10,2), 100) AS INT) AS StandardWeight,
						PRGMMSTR.Name						
			FROM		TCD.WasherProgramSetup		WSHPRGSETUP
			INNER JOIN	TCD.MachineSetup	MCHNSETUP
			ON			WSHPRGSETUP.WasherGroupId	=	MCHNSETUP.GroupId
			INNER JOIN	TCD.Washer WSHR
			ON			WSHR.WasherId	=	MCHNSETUP.WasherId
			INNER JOIN  TCD.ProgramMaster PRGMMSTR
			ON			WSHPRGSETUP.ProgramId			=			PRGMMSTR.ProgramId
			WHERE		WSHPRGSETUP.WasherGroupId		=			@WasherGroupId
			AND			WSHPRGSETUP.Is_Deleted			=			0
			ORDER BY 	WSHPRGSETUP.ProgramNumber
	END
ELSE
	BEGIN
			SELECT DISTINCT		
						TUNPRGSETUP.ProgramNumber,
						TUNPRGSETUP.TotalRunTime,
						TUNPRGSETUP.Category,
						TUNPRGSETUP.NominalLoad,
						CAST((CAST(TUNPRGSETUP.NominalLoad AS INT) * CAST(WSHR.MaxLoad AS INT))/CONVERT(decimal(10,2), 100) AS INT) AS StandardWeight,
						PRGMMSTR.Name						
			FROM		TCD.TunnelProgramSetup		TUNPRGSETUP
			INNER JOIN	TCD.MachineSetup	MCHNSETUP
			ON			TUNPRGSETUP.WasherGroupId	=	MCHNSETUP.GroupId
			INNER JOIN	TCD.Washer WSHR
			ON			WSHR.WasherId	=	MCHNSETUP.WasherId
			INNER JOIN  TCD.ProgramMaster PRGMMSTR
			ON			TUNPRGSETUP.ProgramId			=			PRGMMSTR.ProgramId
			WHERE		TUNPRGSETUP.WasherGroupId		=			@WasherGroupId
			AND			TUNPRGSETUP.Is_Deleted			=			0
			ORDER BY 	TUNPRGSETUP.ProgramNumber
	END


