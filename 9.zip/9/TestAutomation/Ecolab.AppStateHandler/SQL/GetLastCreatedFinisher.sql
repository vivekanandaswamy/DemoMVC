SELECT	  top(1) 
		  FinnisherId
		, FinnisherNo
		, FinnisherGroupId
		, Name
		, FinnisherTypeId
FROM	tcd.Finnishers
ORDER BY LastModifiedTime DESC