UPDATE TCD.MachineGroup
SET Is_Deleted = 1
WHERE GroupTypeId IN (SELECT Id FROM TCD.MachineGroupType WHERE GroupType='Dryer Group')

UPDATE TCD.Dryers
SET Is_deleted = 1