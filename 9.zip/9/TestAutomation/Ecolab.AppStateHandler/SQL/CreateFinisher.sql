--create finisher --

DECLARE @Scope VARCHAR(100)
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber FROM TCD.Plant)
DECLARE @FinisherTypeId INT = (SELECT FinnisherTypeId FROM tcd.FinnisherType WHERE Name = @FinisherTypeName)

EXEC [TCD].[SaveFinnisher]    @FinisherGroupId
							, @FinisherName 
							, @FinisherTypeId 
							, @EcolabAcntNumbr
							, 0 
							, 12 
							, @Scope