--create finsher group --

DECLARE @Scope VARCHAR(100)
DECLARE @EcolabAcntNumbr VARCHAR(1000) = (SELECT EcolabAccountNumber 
FROM TCD.Plant)

EXEC [TCD].[SaveFinnisherGroups]	  @FinisherGroupName
									, @EcolabAcntNumbr
									, 0 
									, @Scope