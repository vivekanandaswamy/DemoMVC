SELECT DISTINCT			
				MCHNSETUP.MachineInternalId,
				MCHNSETUP.WasherId,
				MCHNSETUP.GroupId,
				MCHNSETUP.MachineName,
				MCHNSETUP.IsTunnel,
				MCHNSETUP.TurnAroundTime,
				WSHR.TargetTurnTime,
				WSHR.PlantWasherNumber,
				CAST(WSHR.EndOfFormula AS INT) AS EndOfFormula
FROM			TCD.MachineSetup , TCD.Washer	WSHR
INNER JOIN		TCD.MachineSetup MCHNSETUP
ON				WSHR.WasherId	=	MCHNSETUP.WasherId
WHERE			MCHNSETUP.IsDeleted				=				0
AND				MCHNSETUP.ControllerId			=				@ControllerId