SELECT		CONDCONT.TopicName,
			CONDCONT.Description,
			CONDCONT.Name			AS		ControllerName,
			CONDCONT.ControllerId,
			CONDTYP.Name			AS		ControllerType
FROM		TCD.ConduitController CondCont 
INNER JOIN	TCD.ControllerType CONDTYP
ON			CONDTYP.Id				=				CONDCONT.ControllerTypeId				
WHERE		CONDCONT.Active					=				1
AND			CONDCONT.IsDeleted				=				0