TRUNCATE TABLE TCD.LaborCost
DECLARE @Scope NVARCHAR(100)
DECLARE @EcolabAcntNbr NVARCHAR(100)

SET @EcolabAcntNbr = (SELECT EcolabAccountNumber FROM TCD.Plant)
EXEC [TCD].[SaveLabourCost] NULL,1,@CostForType1,@EcolabAcntNbr,0,@Scope
EXEC [TCD].[SaveLabourCost] NULL,2,@CostForType2,@EcolabAcntNbr,0,@Scope
EXEC [TCD].[SaveLabourCost] NULL,3,@CostForType3,@EcolabAcntNbr,0,@Scope
EXEC [TCD].[SaveLabourCost] NULL,4,@CostForType4,@EcolabAcntNbr,0,@Scope