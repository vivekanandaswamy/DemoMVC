UPDATE	TCD.ProgramMaster
SET	Rewash = 1