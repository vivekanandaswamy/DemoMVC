UPDATE TCD.RedFlag
SET Is_Deleted = 1

UPDATE	TCD.RedFlagMappingData
SET Is_Deleted = 1