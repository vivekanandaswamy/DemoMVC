﻿using Ecolab.AppStateHandler.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class PlantState : BaseState
    {
        public PlantState(string connString)
            : base(connString)
        { }

        public Plant GetPlantDetails()
        {
            DBAccess.QueryString = SQL.Resource.GetPlantDetails;
            return DBAccess.GetData<Plant>().FirstOrDefault();
        }

        public GetValueForPrice GetValueForPriceCalculation(string Name)
        {
            DBAccess.QueryString = SQL.Resource.PriceCalculation;          
            return DBAccess.GetData<GetValueForPrice>(command =>
            {
                ((SqlCommand)command).Parameters.AddWithValue("Name", Name);
            }).FirstOrDefault();
        }
        //public GetValueForPrice GetValueForPriceCalculation(string sku)
        //{
        //    DBAccess.QueryString = SQL.Resource.PriceCalculation;
        //    DBAccess.ExecuteCommand(command =>
        //    {
        //        ((SqlCommand)command).Parameters.AddWithValue("sku", sku);

        //    });

        //    DBAccess.QueryString = SQL.Resource.PriceCalculation;
        //    return DBAccess.GetData<GetValueForPrice>().FirstOrDefault();
        //}

    }
}
