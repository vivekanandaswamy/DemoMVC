﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class RedFlagState : BaseState
    {
        public RedFlagState(string connString)
            : base(connString)
        { }

        public void CreateRedFlag(string redFlagTypeName, int machineGroupId, int machineId)
        {
            DBAccess.QueryString = SQL.Resource.CreateRedFlag;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("RedFlagTypeName", redFlagTypeName);
                ((SqlCommand)command).Parameters.AddWithValue("MachineGroupId", machineGroupId);
                ((SqlCommand)command).Parameters.AddWithValue("MachineId", machineId);
            });
        }

        public void DeleteAllRedFlags()
        {
            DBAccess.QueryString = SQL.Resource.DeleteAllRedFlags;
            DBAccess.ExecuteCommand();
        }
    }
}
