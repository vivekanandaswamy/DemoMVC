﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.AppStateHandler
{
    public class MeterState : BaseState, IStateManagement
    {
        public MeterState(string connstring)
            :base(connstring)
        { }

        public List<Entities.Meter> GetAllMeters()
        {
            DBAccess.QueryString = SQL.Resource.GetMeters;
            return DBAccess.GetData<Entities.Meter>();
        }

        public void DeleteAllMeters()
        {
            AppState.GetState<RedFlagState>().DeleteAllRedFlags();
            DBAccess.QueryString = SQL.Resource.DeleteAllMeters;
            DBAccess.ExecuteCommand();          
        }

        public void CreateMeter(string utilityName, string topicName, string meterName, int machineGroupId, int machineId)
        {
            DBAccess.QueryString = SQL.Resource.CreateMeter;
            DBAccess.ExecuteCommand(command => 
            {
                ((SqlCommand)command).Parameters.AddWithValue("TopicName", topicName);                
                ((SqlCommand)command).Parameters.AddWithValue("UtilityName", utilityName);                
                ((SqlCommand)command).Parameters.AddWithValue("MeterName", meterName);
                ((SqlCommand)command).Parameters.AddWithValue("MachineGroupId", machineGroupId);
                ((SqlCommand)command).Parameters.AddWithValue("MachineId", machineId    );
            });
        }

        public List<T> GetFullState<T>() where T : Entities.BaseEntity
        {
            return GetAllMeters().Cast<T>().ToList();
        }


        public string StateName
        {
            get 
            {
                return "Meters.osl";
            }
        }
    }
}
