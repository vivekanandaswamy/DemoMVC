﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Telerik.TestingFramework.Controls.KendoUI;

namespace Ecolab.Pages
{
    public class ControllerAdvancedSetupPage : PageBase
    {
        private string guiMap;

        public ControllerAdvancedSetupPage(List<object> utilsList)
            : base(utilsList, "ControllerAdvancedSetupPage.xml")
        {
            guiMap = string.Concat(GuiMapPath, "ControllerAdvancedSetupPage.xml");
        }

        public KendoExtendedInput FactorsMultiplierAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtFactorsMultiplierAB");
            }
        }

        public KendoExtendedInput InjectionQuantityMultiplierAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtInjectionQuantityMultiplierAB");
            }
        }

        public KendoExtendedInput MaxFormulaInjections
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("MaxFormulaInjections");
            }
        }

        public KendoExtendedInput OZSecondMultiplierAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtOZSecondMultiplierAB");
            }
        }

        public KendoExtendedInput NumberOfChemicalValvesAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtNumberOfChemicalValvesAB");
            }
        }

        public HtmlInputText WebPortPasswordAB
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWebPortPasswordAB");
            }
        }

        public HtmlInputText WebPortIPAB
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWebPortIPAB");
            }
        }

        public HtmlInputText WebPortLoginAB
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWebPortLoginAB");
            }
        }

        public HtmlControl ControllerName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lblControllerName");
            }
        }

        public KendoExtendedInput MaxWashFormulasBEC
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtMaxWashFormulasBEC");
            }
        }

        public KendoExtendedInput MaxFormulaInjectionBEC
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtMaxFormulaInjectionBEC");
            }
        }

        public KendoExtendedInput NumberOfChemicalValvesBEC
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtNumberOfChemicalValvesBEC");
            }
        }

        public HtmlInputText WebPortPasswordBEC
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWebPortPasswordBEC");
            }
        }

        public HtmlInputText WebPortIPBEC
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWebPortIPBEC");
            }
        }

        public HtmlInputText WebPortLoginBEC
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWebPortLoginBEC");
            }
        }

        public HtmlInputText MaxWashFormulasTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMaxWashFormulasTag");
            }
        }

        public HtmlInputText MaxFormulaInjectionsTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMaxFormulaInjectionsTag");
            }
        }

        public HtmlInputText NumberOfChemicalValvesTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNumberOfChemicalValvesTag");
            }
        }

        public HtmlInputText PreFlushTimeTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtPreflushTimeTag");
            }
        }

        public HtmlControl KendoDown
        {
            get
            {
                return GetHtmlControl<HtmlControl>("KendoDown");
            }
        }

        public HtmlInputText PostFlushTimeTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtPostFlushTimeTag");
            }
        }

        public HtmlInputText LinkIntegrityAddressTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtLinkIntegrityAddressTag");
            }
        }

        public HtmlInputText NameLinkTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNameLinkTag");
            }
        }

        public HtmlInputText AutomaticWeightEnabledTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtAutomaticWeightEnabledTag");
            }
        }

        public HtmlInputText RatioDosingEnabledTag
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtRatioDosingEnabledTag");
            }
        }

        public HtmlButton Save
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSave");
            }
        }
        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }

        public bool IsSaveUtilityDetailsPresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnSave");
            }
        }

        public HtmlControl SetPLCTime
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SetPLCTime");
            }
        }
        public HtmlControl USetPLCTime
        {
            get
            {
                return GetHtmlControl<HtmlControl>("USetPLCTime");
            }
        }
        public HtmlControl UBSetPLCTime
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UBSetPLCTime");
            }
        }
        public HtmlControl ESSetPLCTime
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ESSetPLCTime");
            }
        }

        public HtmlControl EnableConnexx
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EnableConnexx");
            }
        }

        public KendoExtendedInput PostFlushTime
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPostFlushTime");
            }
        }

        public KendoExtendedInput PostFlushTimeAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPostFlushTimeAB");
            }
        }

        public KendoExtendedInput PostFlushTimeToUpadte
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPostFlushTimeToUpadte");
            }
        }

        public KendoExtendedInput PostFlushTimeToUpadteAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPostFlushTimeToUpadteAB");
            }
        }

        public KendoExtendedInput LFSInjection
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("LFSInjection");
            }
        }
        public HtmlControl LFSInjectionYesButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("LFSInjectionYesButton");
            }
        }
        public HtmlInputControl txtLFSInjection
        {
            get
            {
                return GetHtmlControl<HtmlInputControl>("txtLFSInjection");
            }
        }

        public HtmlControl TxtMaxWashFormulas
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtMaxWashFormulas");
            }
        }
        public HtmlControl TxtMaxFormulaInjections
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtMaxFormulaInjections");
            }
        }
        public HtmlControl TxtNoOfChemicalValves
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtNoOfChemicalValves");
            }
        }

        public HtmlControl TxtLFSInjectionClasses
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtLFSInjectionClasses");
            }
        }
        public HtmlInputText HysteresisonConnexx1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("HysteresisonConnexx1");
            }
        }
        public HtmlInputText HysteresisonConnexxPlcXl
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("HysteresisonConnexxPlcXl");
            }
        }
        public HtmlInputText ConnexxAlarmdelay1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("ConnexxAlarmdelay1");
            }
        }
        public HtmlInputText ConnexxAlarmdelayPlcXl
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("ConnexxAlarmdelayPlcXl");
            }
        }


        public HtmlInputText TxtEnvisionTimeout
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtEnvisionTimeout");
            }
        }
        public HtmlInputText TxtStopTimeDubix
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtStopTimeDubix");
            }
        }
        public HtmlInputText TxtAlarmReset
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtAlarmReset");
            }
        }
        public HtmlInputText TxtExtraFlushMe1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtExtraFlushMe1");
            }
        }
        public HtmlInputText TxtExtraFlushMe2
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtExtraFlushMe2");
            }
        }

        public HtmlInputText TxtMaxFormulas
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMaxFormulas");
            }
        }
        public HtmlInputText TxtMaxInjections
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMaxInjections");
            }
        }
        public HtmlInputText TxtChemicalvalves
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtChemicalvalves");
            }
        }
        public HtmlInputText TxtpreflushTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtpreflushTime");
            }
        }
        public HtmlInputText TxtpostflushTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtpostflushTime");
            }
        }
        public HtmlInputText TxtInjectionClasses
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtInjectionClasses");
            }
        }

        public bool IsHysteresisonConnexx1MsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("HysteresisonConnexx1Msg");
            }
        }
        public bool IsConnexxAlarmdelay1MsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ConnexxAlarmdelay1Msg");
            }
        }

        public bool IsEnvisionTimeoutMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ConnexxAlarmdelay1Msg");
            }
        }
        public bool IsStopTimeMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("StopTimeMsg");
            }
        }
        public bool IsAlarmResetMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("AlarmResetMsg");
            }
        }
        public bool Isextraflush1MsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("extraflush1Msg");
            }
        }
        public bool Isextraflush2MsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("extraflush2Msg");
            }
        }


     
    }
}
