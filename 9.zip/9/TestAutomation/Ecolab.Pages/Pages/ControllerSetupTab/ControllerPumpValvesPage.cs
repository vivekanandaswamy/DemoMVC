﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Pages
{
    public class ControllerPumpValvesPage : PageBase
    {
        private string guiMap;

        public ControllerPumpValvesPage(List<object> utilsList)
            : base(utilsList, "Pumps.xml")
        {
            guiMap = string.Concat(GuiMapPath, "Pumps.xml");
        }

        public HtmlButton SaveButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("SavePump");
            }
        }

        public HtmlButton CancelSaveButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("CancelPump");
            }
        }

        public CommonControls.EcolabDataGrid PumpsAndValvesTabGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "PumpsAndValvesTabGridTable");
            }
        }

        public HtmlInputText LFSChemicalName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtLFSChemicalName");
            }
        }

        public HtmlSelect FlowDetectorType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlFlowDetectorType");
            }
        }

        public HtmlSelect ProductNameAB
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlProductNameAB");
            }
        }

        public HtmlSelect PumpType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlPumpType");
            }
        }

        public HtmlSelect ProductNameInlineEdit
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlProductNameInlineEdit");
            }
        }

        public HtmlInputText TimeVolumeCalibrationInlineEdit
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTimeVolumeCalibrationInlineEdit");
            }
        }

        public HtmlInputText KFactorInlineEdit
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtKFactorInlineEdit");
            }
        }

        public HtmlButton InlineEdit
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnInlineEdit");
            }
        }
    }
}
