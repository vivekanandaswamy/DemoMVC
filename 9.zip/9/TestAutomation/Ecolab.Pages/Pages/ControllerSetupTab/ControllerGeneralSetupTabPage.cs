﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using Telerik.TestingFramework.Controls.KendoUI;
using System.Collections.ObjectModel;

namespace Ecolab.Pages
{
    public class ControllerGeneralSetupTabPage : PageBase
    {
        private string guiMap;

        public ControllerGeneralSetupTabPage(List<object> utilsList)
            : base(utilsList, "ControllerGeneralSetupPage.xml")
        {
            guiMap = string.Concat(GuiMapPath, "ControllerGeneralSetupPage.xml");
        }

        public HtmlSelect ControllerModel
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlControllerModel");
            }
        }

        public HtmlSelect ControllerType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlControllerType");
            }
        }

        public HtmlInputText OPCServerUltraxAB
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtOPCServerUltraxAB");
            }
        }

        public HtmlInputText OPCObjectUltraxAB
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtOPCObjectUltraxAB");
            }
        }

        public KendoExtendedInput ControllerNumberUltraxAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtControllerNumberUltraxAB");
            }
        }

        public HtmlInputText IPAddressAB
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtIPAddressAB");
            }
        }

        public HtmlControl GeneralActiveCheckBox
        {
            get
            {
                return GetHtmlControl<HtmlControl>("GeneralActiveCheckBox");
            }
        }
        public HtmlControl DispVersion
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtDispVersion");
            }
        }

        public HtmlInputText DispenserNameBeckhoffUpdate
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDispenserNameBeckhoffUpdate");
            }
        }

        public HtmlInputText SerialNumberUpdateBeckhoff
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtSerialNumberUpdateBeckhoff");
            }
        }

        public HtmlSelect ControllerVersionUltraxAB
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("txtControllerVersionUltraxAB");
            }
        }

        public HtmlButton Save
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSave");
            }
        }

        public HtmlButton SaveAndClose
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveAndClose");
            }
        }   

        public HtmlControl Active
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Active");
            }
        }

        public KendoExtendedInput ComPortNumberUltraxAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtComPortNumberUltraxAB");
            }
        }

        public KendoExtendedInput PreflushTimeUltraxAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPreflushTimeUltraxAB");
            }
        }

        public KendoExtendedInput PostflushUltraxAB
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPostflushUltraxAB");
            }
        }

        public HtmlInputText DDEDriverUltraxAB
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDDEDriverUltraxAB");
            }
        }

        public HtmlInputText AMSNetIDAddressUltraxBEC
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtAMSNetIDAddressUltraxBEC");
            }
        }

        public HtmlInputText AMSNetIDAddressUltraxBECToAdd
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtAMSNetIDAddressUltraxBECToAdd");
            }
        }

        public KendoExtendedInput ControllerNumberUltraxBEC
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtControllerNumberUltraxBEC");
            }
        }

        public HtmlInputText UltraxBeckDispenserNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtUltraxBeckDispenserNumber");
            }
        }

        public KendoExtendedInput PreflushTimeUltraxBEC
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPreflushTimeUltraxBEC");
            }
        }

        public KendoExtendedInput PostflushTimeUltraxBEC
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtPostflushTimeUltraxBEC");
            }
        }

        public HtmlInputText AMSNetIDmyControlBEC
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtAMSNetIDmyControlBEC");
            }
        }

        public HtmlInputText myControlName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtmyControlName");
            }
        }
        public HtmlInputText DispenserName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDispenserName");
            }
        }
        public HtmlInputText ControllerName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtControllerName");
            }
        }


        public HtmlInputText DispenserNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDispenserNumber");
            }
        }       
        public HtmlControl ChkActive
        {
            get
            {
                return GetHtmlControl<HtmlControl>("chkActive");
            }
        }

        public HtmlInputText myControlSerialNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtmyControlSerialNumber");
            }
        }

        public HtmlControl SuccessMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SuccessMessage");
            }
        }

        public HtmlInputText ABSerialNumberUpdate
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtABSerialNumberUpdate");
            }
        }

        public HtmlInputCheckBox myControlActive
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("myControlActive");
            }
        }

        public KendoExtendedInput ControllerNumbermyControlBEC
        {
            get
            {
                return GetHtmlControl<KendoExtendedInput>("txtControllerNumbermyControlBEC");
            }
        }

        public string GetUltraxABControllerNumber
        {
            get
            {
                return ControllerNumberUltraxAB.BaseElement.GetAttribute("value").Value;
            }
        }

        public string GetUltraxBECControllerNumber
        {
            get
            {
                return ControllerNumberUltraxBEC.BaseElement.GetAttribute("value").Value;
            }
        }

        public string GetUltraxBECPreflushTime
        {
            get
            {
                return PreflushTimeUltraxBEC.BaseElement.GetAttribute("value").Value;
            }
        }

        public string GetUltraxBECPostflushTime
        {
            get
            {
                return PostflushTimeUltraxBEC.BaseElement.GetAttribute("value").Value;
            }
        }

        public HtmlInputText BECDispenserName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtBECDispenserName");
            }
        }

        public HtmlInputText ABDispenserName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtABDispenserName");
            }
        }

        public HtmlInputText BECDispenserSerialNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtBECDispenserSerialNumber");
            }
        }

        public HtmlInputText ABDispenserSerialNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtABDispenserSerialNumber");
            }
        }

        public HtmlInputCheckBox ActiveUXBeck
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("ActiveUXBeck");
            }
        }
        public HtmlInputText SerialNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtSerialNumberForPumps");
            }
        }
        public HtmlInputText ESDispenserName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtESDispenserName");
            }
        }
        public HtmlInputText ESDispenserNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtESDispenserNumber");
            }
        }
        public HtmlInputCheckBox ESActive
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("checkESActive");
            }
        }

        public HtmlInputText ESSerialNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtESSerialNumber");
            }
        }

        public HtmlControl ActiveCheckBox
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActiveCheckBox");
            }
        }

        public HtmlControl TxtIpAddress
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtIpAddress");
            }
        }

        public HtmlInputText AMSNetIdAddress
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtAMSNetIdAddress");
            }
        }

        public HtmlInputText TxtFactorMultiplier
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtFactorMultiplier");
            }
        }
        public HtmlInputText TxtOzmultiplier
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtOzmultiplier");
            }
        }
        public HtmlInputText Txtinjectionqualitymultiplier
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtinjectionqualitymultiplier");
            }
        }

        public bool IsErrordispMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrordispMsg"); 
            }
        }
        public bool IsErrordispMsgForPlcXlPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrordispMsgForPlcxl");
            }
        }
        public bool IsErrordispMsgForUltraxPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrordispMsgForUltrax");
            }
        }
        public bool IsErrordispVersionMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorDispVersionMsg");
            }
        }
        public bool IsErrorIpAddMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorIpMsg");
            }
        }
        public bool IsErrordispnumbMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrordispnumbMsg"); 
            }
        }
        public bool IsErrorAmsIdMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorAmsIdMsg"); 
            }
        }
        public bool IsErrorSeriNoMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorSeriNoMsg"); 
             }
        }
        public bool IsErrorOpcServerMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorOpcServerMsg");
            }
        }
        public bool IsErrorFactormultiplierMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorFactormultiplierMsg");
            }
        }
        public bool IsErrorozmultiplierrMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorozmultiplierrMsg");
            }
        }
        public bool IsErrorinjqtymultiplierMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ErrorinjqtymultiplierMsg");
            }
        }
      
        public ReadOnlyCollection<string> GetControllerModelList()
        {
            ReadOnlyCollection<HtmlOption> options = ControllerModel.Options;
            List<HtmlOption> controllers = options.Where(option => options.IndexOf(option) > 0).ToList();
            List<string> listOfControllers = new List<string>();

            foreach (HtmlOption controller in controllers)
            {
                listOfControllers.Add(controller.Text);
            }

            return listOfControllers.AsReadOnly();
        }

    }
}
