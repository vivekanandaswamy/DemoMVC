﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Threading;

namespace Ecolab.Pages
{
    public class BatchTabPage : PageBase
    {
        private string guiMap;

        public BatchTabPage(List<object> utilsList)
            : base(utilsList, "ManualInputBatchTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "ManualInputBatchTab.xml");
        }

        public CommonControls.EcolabDataGrid BatchDataGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "BatchDataGrid");
            }
        }

        public HtmlControl BatchDataTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabBatchData");
            }
        }

        public HtmlControl BatchDataDay
        {
            get
            {
                return GetHtmlControl<HtmlControl>("batchDay");
            }
        }

        public HtmlControl DateButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DateButton");
            }
        }

        public CommonControls.EcolabDateTimePicker BatchDataDatePicker
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "batchDatePicker");
            }
        }

        public CommonControls.EcolabDateTimePicker BatchDate
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "BatchDate");
            }
        }

        public HtmlSelect WasherGroup
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherGroup");
            }
        }

        public HtmlSelect Washer
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasher");
            }
        }

        public HtmlSelect Formula
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlFormula");
            }
        }

        public HtmlSelect BatchDataDropDown
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlBatch");
            }
        }

        public HtmlInputText BatchDataRecordingValue
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("recordingValue");
            }
        }

        public HtmlButton Save
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSave");
            }
        }

        public HtmlControl DatePicker
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DatePicker");
            }
        }

        public HtmlControl SelectDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SelectDate");
            }
        }

        public HtmlControl YearMonthSelector
        {
            get
            {
                return GetHtmlControl<HtmlControl>("YearMonthSelector");
            }
        }

        public HtmlControl PreviousMonth
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PreviousMonth");
            }
        }

        public HtmlControl NextMonth
        {
            get
            {
                return GetHtmlControl<HtmlControl>("NextMonth");
            }
        }

        public HtmlTable DatesTable
        {
            get
            {
                return GetHtmlControl<HtmlTable>("DatesTable");
            }
        }

        public HtmlControl Day1
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day1");
            }
        }

        public HtmlControl Day2
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day2");
            }
        }

        public HtmlControl Day3
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day3");
            }
        }

        public HtmlControl Day4
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day4");
            }
        }

        public HtmlControl Day5
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day5");
            }
        }

        public HtmlControl Day6
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day6");
            }
        }

        public HtmlControl Day7
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day7");
            }
        }

        public HtmlControl Day8
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day8");
            }
        }

        public HtmlControl Day9
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day9");
            }
        }

        public HtmlControl Day10
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day10");
            }
        }

        public HtmlControl Day11
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day11");
            }
        }

        public HtmlControl Day12
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day12");
            }
        }

        public HtmlControl Day13
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day13");
            }
        }

        public HtmlControl Day14
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day14");
            }
        }

        public HtmlControl Day15
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day15");
            }
        }

        public HtmlControl Day16
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day16");
            }
        }

        public HtmlControl Day17
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day17");
            }
        }

        public HtmlControl Day18
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day18");
            }
        }

        public HtmlControl Day19
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day19");
            }
        }

        public HtmlControl Day20
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day20");
            }
        }

        public HtmlControl Day21
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day21");
            }
        }

        public HtmlControl Day22
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day22");
            }
        }

        public HtmlControl Day23
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day23");
            }
        }

        public HtmlControl Day24
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day24");
            }
        }

        public HtmlControl Day25
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day25");
            }
        }

        public HtmlControl Day26
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day26");
            }
        }

        public HtmlControl Day27
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day27");
            }
        }

        public HtmlControl Day28
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day28");
            }
        }

        public HtmlControl Day29
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day29");
            }
        }

        public HtmlControl Day30
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day30");
            }
        }

        public HtmlControl Day31
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day31");
            }
        }

        public HtmlControl Day32
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day32");
            }
        }

        public HtmlControl Day33
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day33");
            }
        }

        public HtmlControl Day34
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day34");
            }
        }

        public HtmlControl Day35
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day35");
            }
        }

        public HtmlControl Day36
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day36");
            }
        }

        public HtmlControl Day37
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day37");
            }
        }

        public HtmlControl Day38
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day38");
            }
        }

        public HtmlControl Day39
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day39");
            }
        }

        public HtmlControl Day40
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day40");
            }
        }

        public HtmlControl Day41
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day41");
            }
        }

        public HtmlControl Day42
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Day42");
            }
        }

        public HtmlControl BtnSearch
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Search");
            }
        }
        public bool IsBatchDataGridPresent
        {
            get
            {
                return IsPresent<HtmlControl>("BatchDataGrid");
            }
        }
    }
}
