﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Threading;


namespace Ecolab.Pages
{
    public class ProductionTabPage : PageBase
    {
        private string guiMap;

        public ProductionTabPage(List<object> utilsList)
            : base(utilsList, "ManualInputProductionTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "ManualInputProductionTab.xml");
        }

        public CommonControls.EcolabDataGrid ProductionTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ProductionTable");
            }
        }

        public HtmlControl ProductionTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabProduction");
            }
        }

        public HtmlControl WasherGroupDropdown
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WasherGroupDropdown");
            }
        }

        public HtmlControl ProductionDataTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabProductionData");
            }
        }        

        public HtmlSelect WasherGroup

        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherGroup");
            }
        }

        public HtmlControl WasherGroupClick
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WasherGroupClick");
            }
        }

        public HtmlControl WasherGroupElement1
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WasherGroupElement1");
            }
        }

        public HtmlControl WasherGroupElement2
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WasherGroupElement2");
            }
        }

        public HtmlSelect Washer
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasher");
            }
        }

        public HtmlSelect Formula
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlFormula");
            }
        }

        public HtmlControl NewValueUOM
        {
            get
            {
                Telerik.ActiveBrowser.RefreshDomTree();
                return GetHtmlControl<HtmlControl>("newValueUOM");
            }
        }

        public HtmlControl LastValueUOM
        {
            get
            {
                Telerik.ActiveBrowser.RefreshDomTree();
                return GetHtmlControl<HtmlControl>("lastValueUOM");
            }
        }

        public HtmlInputText NewValue
        {
            get
            {
                Telerik.ActiveBrowser.RefreshDomTree();
                return GetHtmlControl<HtmlInputText>("txtNewValue");
            }
        }

        public HtmlInputText LastValue
        {
            get
            {
                Telerik.ActiveBrowser.RefreshDomTree();
                return GetHtmlControl<HtmlInputText>("txtLastValue");
            }
        }

        public HtmlControl Save
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnSave");
            }
        }

        public HtmlControl Add
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnAdd");
            }
        }

        public HtmlControl Search
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Search");
            }
        }

        public HtmlControl PostDeleteMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtPostDeleteMessage");
            }
        }

        public HtmlInputText ValueInTable
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("ValueInTable");
            }
        }

        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }

        public HtmlControl DeleteLastValue
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btndeleteLastValue");
            }
        }

        public HtmlControl Message
        {
            get
            {
                return GetHtmlControl<HtmlControl>("divErrorMsg");
            }
        }                

        public HtmlInputText BatchDataStartDate
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("startDate");
            }
        }

        public HtmlInputText BatchDataStartTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("startTime");
            }
        }        

        public HtmlControl BatchDataUOM
        {
            get
            {
                return GetHtmlControl<HtmlControl>("batchUOM");
            }
        }        

        public string GetlastValue 
        { 
            get
            {
                return LastValue.BaseElement.GetAttribute("Value").Value;
            }        
        }

        public bool IsLastValue(string value)
        {
            return WaitforAction(() =>
            {
                return GetlastValue.Equals(value);
            }, Config.PageClassSettings.Default.MaxTimeoutValue);
        }
        
        public bool IsMessage(string value)
        {
            return WaitforAction(() =>
            {
                return Message.BaseElement.InnerText.Equals(value);
            }, Config.PageClassSettings.Default.MaxTimeoutValue);
        }

        public bool IsSaveButtonPresent 
        { 
            get
            {
                return IsPresent<HtmlButton>("btnSave");
            }
        }
    }
}
