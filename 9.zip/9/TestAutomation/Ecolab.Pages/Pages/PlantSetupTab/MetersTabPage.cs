﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using Telerik.TestingFramework.Controls.KendoUI;
using ArtOfTest.WebAii.Core;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;

namespace Ecolab.Pages
{
    public class MetersTabPage : PageBase
    {
        private string guiMap;

        public MetersTabPage(Ecolab.TelerikPlugin.TelerikFramework TelerikPlugin)
            : base(TelerikPlugin, "MetersTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "MetersTab.xml");
        }

        public MetersTabPage(List<object> utilsList)
            : base(utilsList, "MetersTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "MetersTab.xml");
        }

        public HtmlControl AddMeterButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnAddMeter");                
            }
        }
        public bool IsAddMeterPresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnAddMeter");
            }
        }


        public HtmlButton AddMeterSaveButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveMeter");                
            }
        }

        public HtmlButton EditMeterSaveButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnEditSave");
            }
        }
        public HtmlSelect MeterWaterType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMeterWaterTypeAdd");
            }

        }

        public HtmlSelect WaterTypeUpdate
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWaterTypeUpdate");
            }

        }

        public HtmlControl WaterTypeFromFormulaSetup
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WaterTypeFromFormulaSetup");
            }

        }

        public HtmlControl SecondMeterSuccessMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SecondMeterSuccessMsg");
            }
        }

        public HtmlControl SecondMeterAdditionMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SecondMeterAdditionMessage");
            }
        }

        public HtmlControl MeterUpdateMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MeterUpdateMsg");
            }
        }

        public HtmlSelect CounterAdd
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("CounterAdd");
            }
        }

        public bool IsCounterAddPresent()
        {
            return IsPresent<HtmlSelect>("CounterAdd");
        }

        public HtmlButton AddMeterCancelButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");                
            }
        }

        public HtmlButton CancelAfterUpdate
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancelAfterUpdate");
            }
        }

        public HtmlButton EditMeterCancelButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnEditCancel");
            }
        }

        public HtmlButton DeleteMeterYes
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnDeleteMeterYes");
            }
        }

        public HtmlControl EditMetersLabel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MetersEditLabel");
            }
        }
        public HtmlControl ViewMetersLabel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MetersViewLabel");
            }
        }
        public HtmlInputText MeterName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMeterName");                
            }

        }

        public HtmlControl SuccessfulMeterAdditionMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtSuccessfulMeterAdditionMessage");
            }
        }

        public HtmlInputText MeterNameToEdit
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMeterNameToEdit");
            }
        }

        public HtmlControl MeterDeleteMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MeterDeleteMsg");
            }

        }

        public HtmlSelect UtilityType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlUtilityType");                
            }

        }

        public HtmlSelect UtilityTypeUpdate
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlUtilityTypeUpdate");
            }
        }
       
        public HtmlSelect UtilityLocation
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlUtilityLocation");                
            }

        }

        public HtmlSelect MachineCompartment
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMachineCompartment");                
            }

        }

        public HtmlSelect Parent
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlParent");                
            }

        }

        public HtmlInputText Calibration
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtCalibration");                
            }

        }

        public HtmlInputText EditCalibration
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("edittxtCalibration");
            }

        }

        public HtmlSelect UOM
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlUOM");                
            }

        }       

        public HtmlSelect Controller
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlController");                
            }

        }

        public HtmlSelect ControllerUpdate
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlControllerUpdate");
            }

        }

        public HtmlControl Controllerlabel 
        { 
            get
            {
                return GetHtmlControl<HtmlControl>("ddlControllerLabel");
            }
        }

        public HtmlInputCheckBox ManualEntryEdit
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("ddlAllowManualEntryEdit");                
            }

        }

        public HtmlInputText MaxRollOverPoint
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMaxValueLimit");                
            }

        }

        public CommonControls.EcolabDataGrid MetersTabGrid
        {
            get
            {
               return new CommonControls.EcolabDataGrid(Telerik, guiMap, "MetersTabGridTable");
            }
        }
        public CommonControls.EcolabDataGrid UsersRolesMetersTabGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "UserRolesMetersTabGridTable");
            }
        }

        public HtmlControl MeterAddedSuccess
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lblMeterAddedSuccess");                
            }

        }

        public HtmlControl ErrorMessage    
        {
            get
            {
                HtmlControl errorMessage = GetHtmlControl<HtmlControl>("lblErrorMessage");
                //errorMessage.ScrollToVisible();
                return errorMessage;
            }
        }

        public HtmlControl FailureMessage
        {
            get
            {
                HtmlControl errorMessage = GetHtmlControl<HtmlControl>("lblFailureMessage");
                //errorMessage.ScrollToVisible();
                return errorMessage;
            }
        }

        public bool AddMeterAndVerify()
        {
            
            AddMeterSaveButton.Focus();
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(Keys.Enter);

            //SaveButton.ExtendedMouseClick();
            if(null == MeterAddedSuccess)
            {
                return false;
            }

            return true;
        }

        public bool IsMachineCompartmentPresent()
        {
            return IsPresent<HtmlSelect>("ddlMachineCompartment");
        }

        public HtmlSpan YesNoButton
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("YesNoSwitch");
            }
        }

        public HtmlInputCheckBox AllowManualEntry
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("ddlAllowManualEntryAdd");
            }
        }


        public HtmlControl EditsaveMeter
        {
            get
            {
                return GetHtmlControl<HtmlControl>("editsaveMeter");
            }
        }

    }
}
