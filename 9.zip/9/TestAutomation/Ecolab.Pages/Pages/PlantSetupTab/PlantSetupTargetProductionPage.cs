﻿using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.TestAttributes;
using ArtOfTest.WebAii.TestTemplates;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.CommonUtilityPlugin;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.Pages
{
    public class PlantSetupTargetProductionPage : PageBase
    {
        private string guiMap;
        /// <summary>
        /// reading guimap OR objects
        /// </summary>
        /// <param name="TelerikPlugin"></param>
        public PlantSetupTargetProductionPage(Ecolab.TelerikPlugin.TelerikFramework telerikPlugin)
            : base(telerikPlugin)
        {
            guiMap = string.Concat(GuiMapPath, "PlantSetupTargetProduction.xml");
        }
        public PlantSetupTargetProductionPage(List<object> utilsList)
            : base(utilsList, "PlantSetupTargetProduction.xml")
        {
            guiMap = string.Concat(GuiMapPath, "PlantSetupTargetProduction.xml");
        }

        public HtmlInputText TargetProductionToEdit
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTargetProductionToEdit");
            }
        }

        public CommonControls.EcolabDataGrid StandardProdGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "StandardProdGrid");
            }
        }
        public HtmlControl Save
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnSave");
            }
        }

        public bool IsSavePresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnSave");
            }
        }

        public HtmlControl Message
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Message");
            }
        }

        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }
    }
}
