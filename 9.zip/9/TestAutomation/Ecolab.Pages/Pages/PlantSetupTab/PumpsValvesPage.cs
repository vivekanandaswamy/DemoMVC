﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Collections.ObjectModel;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Windows.Forms;
using ArtOfTest.WebAii.Core;

namespace Ecolab.Pages.Pages
{
    public class PumpsValvesPage : PageBase
    {
        private string guiMap;

        public PumpsValvesPage(List<object> utilsList)
            : base(utilsList, "Pumps.xml")
        {
            guiMap = string.Concat(GuiMapPath, "Pumps.xml");
        }

        public CommonControls.EcolabDataGrid ControllerSetupGridTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ControllerSetupGridTable");
            }
        }

        public CommonControls.EcolabDataGrid ControllerRoleSetupGridTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ControllerRoleSetupGridTable");
            }
        }

        public CommonControls.EcolabDataGrid PumpsAndValvesTabGridTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "PumpsAndValvesTabGridTable");
            }
        }

        public CommonControls.EcolabDataGrid PumpsListTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "PumpsListTableGrid");
            }
        }

        public HtmlAnchor tabPumpList
        {
            get
            {
                return GetHtmlControl<HtmlAnchor>("tabPumpList");
            }
        }

        public HtmlSelect ddlSort
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlSort");
            }
        }

        public HtmlSelect LineNumber
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlLineNumber");
            }
        }

        public HtmlSelect CompartmentForDPT1
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlCompartmentForDPT1");
            }
        }

        public HtmlSelect CompartmentForDPT2
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlCompartmentForDPT2");
            }
        }

        public HtmlSpan BacktoControllers
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("BacktoControllers");
            }
        }

        public HtmlSelect ddlProducts
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlProducts");
            }
        }

        public HtmlSelect ddlPumpType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlPumpType");
            }
        }
        public HtmlSelect ddlLineNumber
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlLineNumber");
            }
        }
        public bool IsddlFlushValveNumberPresent
        {
            get
            {
               return IsPresent<HtmlSelect>("ddlFlushValveNumber");
            }
        }

        public HtmlSelect ddlFlushValveNumber
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlFlushValveNumber");
            }
        }

        public HtmlSelect DeviceValve1
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve1");
            }
        }

        public HtmlSelect DeviceValve2
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve2");
            }
        }

        public HtmlSelect DeviceValve3
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve3");
            }
        }

        public HtmlSelect DeviceValve4
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve4");
            }
        }

        public HtmlSelect DeviceValve5
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve5");
            }
        }

        public HtmlSelect DeviceValve6
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve6");
            }
        }

        public HtmlSelect DeviceValve7
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve7");
            }
        }

        public HtmlSelect DeviceValve8
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDeviceValve8");
            }
        }

        public HtmlSelect MCDeviceValve1
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve1");
            }
        }

        public HtmlSelect MCDeviceValve2
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve2");
            }
        }

        public HtmlSelect MCDeviceValve3
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve3");
            }
        }

        public HtmlSelect MCDeviceValve4
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve4");
            }
        }

        public HtmlSelect MCDeviceValve5
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve5");
            }
        }

        public HtmlSelect MCDeviceValve6
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve6");
            }
        }

        public HtmlSelect MCDeviceValve7
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve7");
            }
        }

        public HtmlSelect MCDeviceValve8
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMCDeviceValve8");
            }
        }

        public HtmlSelect ddlCompartmentNumberForDirectDosing
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlCompartmentNumberForDirectDosing");
            }
        }
        public HtmlSelect ddlTunnelNumberForDirectDosing
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlTunnelNumberForDirectDosing");
            }
        }
        
        public HtmlInputCheckBox cbConventionalWgConnection
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("cbConventionalWgConnection");
            }
        }
        public HtmlInputCheckBox cbPumpInDirectDosingMode
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("cbPumpInDirectDosingMode");
            }
        }
        public HtmlInputText txtPumpCalibration
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtPumpCalibration");
            }
        }

        public HtmlInputText txtMaxDosingTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMaxDosingTime");
            }
        }

        public HtmlButton SavePump
        {
            get
            {
                return GetHtmlControl<HtmlButton>("SavePump");
            }
        }

        public HtmlButton CancelPump
        {
            get
            {
                return GetHtmlControl<HtmlButton>("CancelPump");
            }
        }
        public HtmlButton CancelEdit
        {
            get
            {
                return GetHtmlControl<HtmlButton>("CancelEdit");
            }
        }
        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("Cancel");
            }
        }
                
        public HtmlSpan BacktoPumps
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("BacktoPumps");
            }
        }

        public HtmlSelect InLineddlProducts
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("InLineddlProducts");
            }
        }

        public HtmlInputText InLinetxtPumpCalibration
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("InLinetxtPumpCalibration");
            }
        }

        public HtmlInputText InLinetxtMaxDosingTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("InLinetxtMaxDosingTime");
            }
        }

        public HtmlDiv ValidationMessage
        {
            get
            {
                return GetHtmlControl<HtmlDiv>("ValidationMessage");
            }
        }
        public HtmlControl PumpValidationMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PumpValidationMessage");
            }
        }

        public HtmlControl ValvesArea
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ValvesArea");
            }
        }

        public HtmlSpan dialogMsg
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("dialogMsg");
            }
        }

     
        public void AddingPumps(string pumpCalibration, string maxDosingTime)
        {
            ddlProducts.SelectByIndex(1);
            txtPumpCalibration.TypeText(pumpCalibration);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtMaxDosingTime.TypeText(maxDosingTime);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtPumpCalibration.SetText(pumpCalibration);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtMaxDosingTime.MouseClick();
            txtMaxDosingTime.TypeText(maxDosingTime);
            txtPumpCalibration.TypeText(pumpCalibration);
            SavePump.Focus();
            SavePump.Click();
        }

        public void UpdateCancellingPumps(string pumpCalibration, string maxDosingTime)
        {
            ddlProducts.SelectByIndex(1);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtPumpCalibration.TypeText("0");
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtMaxDosingTime.TypeText("0");
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtPumpCalibration.MouseClick();
            txtPumpCalibration.SetText(pumpCalibration);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtMaxDosingTime.MouseClick();
            txtMaxDosingTime.TypeText(maxDosingTime);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            CancelPump.Focus();
            CancelPump.Click();
        }

        public void UpdatingPumps(string pumpCalibration, string maxDosingTime) 
        {
            ddlProducts.SelectByIndex(1);
            txtPumpCalibration.TypeText(pumpCalibration);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtMaxDosingTime.TypeText(maxDosingTime);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtPumpCalibration.SetText(pumpCalibration);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            txtMaxDosingTime.MouseClick();
            txtMaxDosingTime.TypeText(maxDosingTime);
            txtPumpCalibration.TypeText(pumpCalibration);
            SavePump.Focus();
            SavePump.Click();
        }

        public void InlineEditingPumps(string pumpCalibration, string maxDosingTime)
        {
            InLineddlProducts.SelectByIndex(1);
            InLinetxtPumpCalibration.TypeText(pumpCalibration);
            InLinetxtMaxDosingTime.TypeText(maxDosingTime);
        }
    }
}
