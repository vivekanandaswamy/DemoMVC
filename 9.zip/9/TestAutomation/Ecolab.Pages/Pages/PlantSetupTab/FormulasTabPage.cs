﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Collections.ObjectModel;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Windows.Forms;
using ArtOfTest.WebAii.Core;

namespace Ecolab.Pages.Pages.PlantSetupTab
{
    public class FormulasTabPage : PageBase
    {
        private string guiMap;

        public FormulasTabPage(List<object> utilsList)
            : base(utilsList, "FormulasTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "FormulasTab.xml");
        }
       
        public HtmlControl FormulasTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabFormulas");
            }
        }

        public HtmlControl AddFormula
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnAddFormulas");
            }
        }
        public bool IsAddFormulaPresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnAddFormulas");
            }
        }

        public HtmlButton CancelIE
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancelIE");
            }
        }

        public CommonControls.EcolabDataGrid WashStepProductsTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "WashStepProductsTable");
            }
        }

        public CommonControls.EcolabDataGrid tblWashStepProducts
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "tblWashStepProducts");
            }
        }

        public HtmlControl AddFormulaButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AddFormulaButton");
            }
        }
        public HtmlControl InjectionView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("InjectionView");
            }
        }
        public HtmlControl UomFormula
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UomFormula");
            }
        }
        public HtmlControl ViewChange
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ViewChange");
            }
        }
        public HtmlControl GridView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("GridView");
            }
        }
        public HtmlControl FormView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormView");
            }
        }
       
        public HtmlControl FormulaWashstepAddedMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulaWashstepAddedMessage");
            }
        }

        public HtmlButton AddProduct
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnAddProduct");
            }
        }

        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }

        public HtmlButton SaveProducts
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveProducts");
            }
        }

        public HtmlButton CancelInPopup
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancelInPopup");
            }
        }

        public HtmlInputText EUQuantity
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtQuantityEU");
            }
        }
        public HtmlInputText Quantity
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtQuantity");
            }
        }
        public HtmlInputText IVQuantity
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("IVQuantity");
            }
        }
        public HtmlInputText IVTotalQuantity
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("IVTotalQuantity");
            }
        }
        public HtmlInputText IVPrice
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("IVPrice");
            }
        }
        public HtmlInputText QuantityForPLC
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtQuantityForPLC");
            }
        }

        public HtmlInputText TotalQuantity
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTotalQuantity");
            }
        }
        public HtmlInputText TotalQuantityEU
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTotalQuantityEU");
            }
        }
        public HtmlControl GetPrice
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtPrice");
            }
        }
        public HtmlControl GetPriceEU
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtPriceEU");
            }
        }
        public HtmlControl ViewInjections
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnViewInjections");
            }
        }

        public HtmlControl ViewInjectionsForPLC
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ViewInjectionsForPLC");
            }
        }
        
        public CommonControls.EcolabDataGrid FormulasTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "FormulasTableGrid");
            }
        }

        public bool IsFormulaTableGridPresent
        {
            get
            {
                return IsPresent<HtmlControl>("FormulasTableGrid");
            }
        }


        public CommonControls.EcolabDataGrid FormulasTableGridAtWasher
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "FormulasTableGridAtWasher");
            }
        }

        public HtmlControl ColumnNamesExceptTextileCategoryecolab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ColumnNamesExceptTextileCategoryecolab");
            }
        }

        public HtmlControl ColumnNamesExceptTextileCategoryecolabTRCustomer
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ColumnNamesExceptTextileCategoryecolabTRCustomer");
            }
        }

        public HtmlControl FormulaTable
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulasTableGrid");
            }
        }

        public HtmlSelect SelectProduct
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlSelectProduct");
            }
        }
        public HtmlSelect WasherNameFormula
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherNameFormula");
            }
        }

        public HtmlSelect WashersDropdown
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWashersDropdown");
            }
        }

        public HtmlInputText FormulaName
        {
             get
            {
                return GetHtmlControl<HtmlInputText>("txtFormulaNameAdd");
            }
            
        }

        public HtmlButton FormulaFrameSave
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnFormulaFrameSave");
            }

        }

        public HtmlInputText TotalRunTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTotalRunTime");
            }

        }

        public HtmlInputText FormulaNameEdit
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtFormulaName");
            }

        }

        public HtmlSelect AddChainFormulaName
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlAddChainFormulaName");
            }

        }

        public bool IsAddChainFormulanamePresent
        {
            get
            {
                return IsPresent<HtmlSelect>("ddlAddChainFormulaName");
            }
          
        }



        public HtmlInputText CopyFormulaName
        {
             get
            {
                return GetHtmlControl<HtmlInputText>("txtcopyFormulaName");
            }
            
        }

        public HtmlInputText NominalLoadForTunnel
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNominalLoadForTunnel");
            }

        }

        public HtmlInputText NominalLoadForConventional
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNominalLoadForConventional");
            }
        }
        
        public HtmlControl TextileCategoryEcolab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlEcolabTextileCategoryAdd_listbox");
            }

        }

        public HtmlSelect SelectFormulaName
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlSelectFormulaName");
            }

        }

        public HtmlControl TextileSaturation
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlEcolabSaturationAdd_listbox");
            }

        }

        public HtmlControl ChainFormulaName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlChainFormulaAdd_listbox");
            }

        }

        public HtmlControl TextileCategoryInternal
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlChainTextileCategoryAdd_listbox");
            }

        }

        public HtmlControl EditTextileCategoryEcolab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlEcolabTextileCategoryEdit_listbox");
            }

        }

        public HtmlControl EditTextileSaturation
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlEcolabSaturationEdit_listbox");
            }

        }

        public HtmlControl EditChainFormulaName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlChainFormulaEdit_listbox");
            }

        }

        public HtmlControl EditTextileCategoryInternal
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlChainTextileCategoryEdit_listbox");
            }

        }

        public HtmlInputText NumberofweightedPieces
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtaddNumberofweightedPieces");
            }

        }

        public HtmlInputText AddWeight
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtaddWeight");
            }
        }

        public HtmlInputText LoadsPerMonth
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtLoadsPerMonth");
            }
        }

        public HtmlInputText FormulaNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtFormulaNumber");
            }
        }

        public HtmlInputText PieceWeight
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtPieceWeight");
            }

        }

        public HtmlInputText EditPieceWeight
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNumberofweightedPieces");
            }

        }

        public HtmlInputText EditWeight
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWeight");
            }

        }

        public HtmlButton Save
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSave");
            }
        }

        public HtmlButton AddFormulaPopupSave
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnAddFormulaPopupSave");
            }
        }

        public HtmlControl EditSave
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnEditSave");
            }
        }

        public HtmlControl TabsForOperator
        {
            get
            {
                return GetHtmlControl<HtmlControl>("TabsForOperator");
            }
        }

        public HtmlControl NominalLoadErrorMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("NominalLoadErrorMessage");
            }
        }

        public HtmlControl ConvNominalLoadErrorMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ConvNominalLoadErrorMessage");
            }
        }

        public HtmlButton CopySave
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnUpdatecopy");
            }

        }

        public HtmlInputCheckBox RewashCheckBox
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("RewashCheckBox");
            }

        }

        public HtmlButton SaveFinisher
        {
            get
            {
                return GetHtmlControl<HtmlButton>("SaveFinisher");
            }

        }

        public HtmlButton CancelProduct
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancelProduct");
            }

        }

        public HtmlControl CloseInjectionsPopup
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CloseInjectionsPopup");
            }

        }

        public HtmlSelect FormulaCategory
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlFormulaCategory");
            }
        }

        public HtmlSelect TextileSaturationNew
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlTextileSaturationNew");
            }
        }

        public HtmlSelect FormulaSegment
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlFormulaSegment");
            }
        }

        public HtmlControl DeleteConfirmationMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DeleteConfirmationMsg");
            }

        }

        public HtmlControl SuccessMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SuccessMsg");
            }
        }

        public HtmlControl ErrorMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ErrorMessage");
            }
        }

        public HtmlInputText InLineFormulaName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("FormulaNameInLine");
            }
        }

        public List<string> GetAllColumnsNames 
        { 
            get
            {
                List<string> columnNames = new List<string>();
                ReadOnlyCollection<HtmlControl> headerColumns = WaitforAction<ReadOnlyCollection<HtmlControl>>(() =>
                {                    
                    return Telerik.Find.AllByXPath<HtmlControl>(".//*[@id='gridFormula']/div[1]/div/table/thead/tr/th/a/span");
                }, Config.PageClassSettings.Default.MaxTimeoutValue);  
              
                foreach(HtmlControl column in headerColumns)
                {
                    columnNames.Add(column.BaseElement.InnerText);
                }
                return columnNames;
            }
        }        

        public void AddingFormula(string strFormulaName, string strEcolabTextileCategory, string strSaturation, string strChainFormulaName,
            string strTextileCategoryInternal, string strNumberofweightedPieces, string strAddWeight)
        {
            DeleteIfExistsRecord(strFormulaName);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //AddChainFormulaName.SelectByIndex(1, true, true);
            FormulaName.Focus();
            FormulaName.TypeText(strFormulaName);
            //ListItemClick(TextileCategoryEcolab, strEcolabTextileCategory);
            //ListItemClick(TextileSaturation, strSaturation);
            //ListItemClick(ChainFormulaName, strChainFormulaName);
            //ListItemClick(TextileCategoryInternal, strTextileCategoryInternal);
            FormulaCategory.SelectByIndex(1, true);
            TextileSaturationNew.SelectByIndex(1, true);
            FormulaSegment.SelectByIndex(1, true);
            NumberofweightedPieces.Focus();
            NumberofweightedPieces.TypeText(strNumberofweightedPieces);
            AddWeight.Focus();
            AddWeight.TypeText(strAddWeight);
            AddFormulaPopupSave.Focus();
            AddFormulaPopupSave.DeskTopMouseClick();            
        }

        public void AddingFormula(string strFormulaName, string strNumberofweightedPieces, string strAddWeight)
        {
            //DeleteIfExistsRecord(strFormulaName);
            if (IsAddChainFormulanamePresent)
            {
                AddChainFormulaName.SelectByIndex(1, true);
            }
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            FormulaName.TypeText(strFormulaName);
            FormulaCategory.SelectByIndex(1, true);
            TextileSaturationNew.SelectByIndex(1, true);
            FormulaSegment.SelectByIndex(1, true);
            NumberofweightedPieces.Focus();
            NumberofweightedPieces.TypeText(strNumberofweightedPieces);
            AddWeight.Focus();
            AddWeight.TypeText(strAddWeight);
            AddFormulaPopupSave.Focus();
            AddFormulaPopupSave.DeskTopMouseClick();
        }

        public void AddingFormulaEU(string chainFormula, string strFormulaName, string strNumberofweightedPieces, string strAddWeight)
        {
            //DeleteIfExistsRecord(strFormulaName);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            if (IsAddChainFormulanamePresent)
            {
                AddChainFormulaName.SelectByIndex(1, true);
            }
            FormulaName.Focus();
            FormulaName.Click();
            FormulaName.TypeText(strFormulaName);
            //KeyBoardSimulator.KeyDown(Keys.Control);
            //KeyBoardSimulator.KeyPress(Keys.A);
            //KeyBoardSimulator.KeyUp(Keys.Control);
            //KeyBoardSimulator.SetText(strFormulaName);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyDown(System.Windows.Forms.Keys.Control);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyUp(System.Windows.Forms.Keys.Control);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.F);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.O);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.R);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.M);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.U);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.L);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.A);
            NumberofweightedPieces.Focus();
            NumberofweightedPieces.TypeText(strNumberofweightedPieces);
            AddWeight.Focus();
            AddWeight.TypeText(strAddWeight);
            AddFormulaPopupSave.Focus();
            AddFormulaPopupSave.DeskTopMouseClick();
        }


        public void EditingFormula(string strFormulaName, string strEcolabTextileCategory, string strSaturation, string strChainFormulaName,
            string strTextileCategoryInternal, string strNumberofweightedPieces, string strAddWeight)
        {
            DeleteIfExistsRecord(strFormulaName);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            FormulaName.TypeText(strFormulaName);
            //EditListItemClick(EditTextileCategoryEcolab, strEcolabTextileCategory);
            //EditListItemClick(EditTextileSaturation, strSaturation);
            //EditListItemClick(EditChainFormulaName, strChainFormulaName);
            //EditListItemClick(EditTextileCategoryInternal, strTextileCategoryInternal);
            RewashCheckBox.Click();
            RewashCheckBox.Click();
            EditPieceWeight.Focus();
            EditPieceWeight.TypeText(strNumberofweightedPieces);
            EditWeight.Focus();
            EditWeight.TypeText(strAddWeight);
            AddFormulaPopupSave.Focus();
            AddFormulaPopupSave.DeskTopMouseClick();

        }

        public void EditingFormula(string strFormulaName, string strNumberofweightedPieces, string strAddWeight)
        {
            DeleteIfExistsRecord(strFormulaName);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            FormulaName.TypeText(strFormulaName);
            FormulaCategory.SelectByIndex(1, true);
            TextileSaturationNew.SelectByIndex(1, true);
            FormulaSegment.SelectByIndex(1, true);
            NumberofweightedPieces.Focus();
            NumberofweightedPieces.TypeText(strNumberofweightedPieces);
            AddWeight.Focus();
            AddWeight.TypeText(strAddWeight);
            AddFormulaPopupSave.Focus();
            AddFormulaPopupSave.DeskTopMouseClick();
        }

        public void EditingFormulaCancelFunctionality(string strFormulaName, string strEcolabTextileCategory, string strSaturation, string strChainFormulaName,
            string strTextileCategoryInternal, string strNumberofweightedPieces, string strAddWeight)

        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            FormulaName.TypeText(strFormulaName);
            //EditListItemClick(EditTextileCategoryEcolab, strEcolabTextileCategory);
            //EditListItemClick(EditTextileSaturation, strSaturation);
            //EditListItemClick(EditChainFormulaName, strChainFormulaName);
            //EditListItemClick(EditTextileCategoryInternal, strTextileCategoryInternal);
            RewashCheckBox.Click();
            RewashCheckBox.Click();
            EditPieceWeight.Focus();
            EditPieceWeight.TypeText(strNumberofweightedPieces);
            EditWeight.Focus();
            EditWeight.TypeText(strAddWeight);
            CancelInPopup.Focus();
            CancelInPopup.DeskTopMouseClick();

        }

        public void CopyingFormula(string strFormulaName, string strEcolabTextileCategory, string strSaturation, string strChainFormulaName,
            string strTextileCategoryInternal, string strNumberofweightedPieces, string strAddWeight)
        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            FormulaName.TypeText(strFormulaName);
            //EditListItemClick(EditTextileCategoryEcolab, strEcolabTextileCategory);
            //EditListItemClick(EditTextileSaturation, strSaturation);
            //EditListItemClick(EditChainFormulaName, strChainFormulaName);
            //EditListItemClick(EditTextileCategoryInternal, strTextileCategoryInternal);
            RewashCheckBox.Click();
            RewashCheckBox.Click();
            EditPieceWeight.Focus();
            EditPieceWeight.TypeText(strNumberofweightedPieces);
            EditWeight.Focus();
            EditWeight.TypeText(strAddWeight);
            AddFormulaPopupSave.Focus();
            AddFormulaPopupSave.DeskTopMouseClick();
        }

        public void ListItemClick(HtmlControl control, string strText)
        {
            Thread.Sleep(3000);
            control.Focus();
            ICollection<Element> ele = control.ChildNodes;
            bool flag = false;
            foreach(Element e in ele)
            {
                if(e.InnerText == strText)
                {
                    (new HtmlControl(e)).Click();
                    flag = true;
                    MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
                    break;
                }
            }

            if(!flag)
            {
                ListItemClickByIndex(control, 1);
            }
        }

        public void ListItemClickByIndex(HtmlControl control, int index)
        {           
            Thread.Sleep(3000);
            control.Focus();
            ReadOnlyCollection<Element> ele = control.ChildNodes;
            if(ele.Count >= 2)
            {
                (new HtmlControl(ele[index])).Click();
            }
            else
            {
                (new HtmlControl(ele.FirstOrDefault())).Click();
            }
            
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);                                
        }

        public void EditListItemClick(HtmlControl control, string strText)
        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //Thread.Sleep(3000);
            //control.Focus();
            //ICollection<Element> ele = control.ChildNodes;
            //foreach (Element e in ele)
            //{
            //    if (e.InnerText == strText)
            //    {
            //        (new HtmlControl(e)).Click();
            //        MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //        break;
            //    }
            //}
            ListItemClick(control, strText);
        }

        public bool isRecordExist(string strFormulaName)
        {
            ICollection<Element> eChild = FormulaTable.Find.AllByXPath(@"//tbody/tr");
            foreach (Element e in eChild)
            {
                if(e.ChildNodes[1].InnerText == strFormulaName)
                {
                    return true;
                }
            }
            return false;  
        }

        public void InLineEditingFormula(string strFormulaName)
        {
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.SetText(strFormulaName);            
            KeyBoardSimulator.SetNumeric(strFormulaName);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.KeyPress(Keys.Down);

            //InLineFormulaName.Focus();
            //InLineFormulaName.SetText(strFormulaName);
            
        }

        public void DeleteIfExistsRecord(string name)
        {
            if (isRecordExist(name))
            {
                Thread.Sleep(4000);
                FormulasTableGrid.SelectedRows(name).FirstOrDefault().GetButtonControls()[1].Click();
                DialogHandler.FormulaYesButton.Click();                
            }            
        }        
    }
}
