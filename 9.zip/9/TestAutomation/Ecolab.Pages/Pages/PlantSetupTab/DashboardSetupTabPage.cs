﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Collections.ObjectModel;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Windows.Forms;
using ArtOfTest.WebAii.Core;

namespace Ecolab.Pages.Pages.PlantSetupTab
{
    public class DashboardSetupTabPage : PageBase
    {
        /// <summary>
        /// The GUI map
        /// </summary>
        private string guiMap;
        
        public DashboardSetupTabPage(List<object> utilsList)
            : base(utilsList, "DashboardSetupTabPage.xml")
        {
            guiMap = string.Concat(GuiMapPath, "DashboardSetupTabPage.xml");
        }
                
        public HtmlButton AddDashboard
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnAddDashboard");
            }
        }
        public HtmlControl HomePageVerification
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HomePageVerification");
            }
        }
        public HtmlControl HomePageOverview
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HomePageOverview");
            }
        }
        public bool IsDashboardSetupTabPresent
        {
            get
            {
                return IsPresent<HtmlControl>("tabDashboardSetup");
            }
        }

        public HtmlControl DashboardSetupTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabDashboardSetup");
            }
        }


        public bool IsAddDashboardPresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnAddDashboard");
            }
        }

        public HtmlButton OuterSave
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnOuterSave");
            }
        }

        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }

        public HtmlButton SaveDashboard
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveDashboard");
            }
        }
        public HtmlButton Save
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSave");
            }
        }        

        public HtmlInputText DashboardName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDashboardName");
            }
        }

        public HtmlSelect DashboardType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlDashboardType");
            }
        }

        public bool IsDashboardPresent
        {
            get
            {
                return IsPresent<HtmlControl>("itemDashboards");
            }
        }

        public HtmlControl MachineName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ddlMachineName");
            }
        }

        public HtmlControl SaveSuccessMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SaveSuccessMsg");
            }
        }

        public HtmlControl Machine
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Machine");
            }
        }

        public HtmlControl DashboardsMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DashboardsMessage");
            }
        }

        public HtmlControl BreadCrumb
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DashboardsBreadCrumb");
            }
        }
        
        public HtmlSelect MonitorName
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMonitorName");
            }
        }

        public HtmlInputText TimeScaleDuration
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTimeScaleDuration");
            }
        }

        public CommonControls.EcolabDataGrid DashboardsTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "DashboardsTableGrid");
            }
        }      
    }
}
