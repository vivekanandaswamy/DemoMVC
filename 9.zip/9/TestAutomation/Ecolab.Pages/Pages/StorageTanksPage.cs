﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Collections.ObjectModel;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Windows.Forms;
using ArtOfTest.WebAii.Core;

namespace Ecolab.Pages.Pages
{
    public class StorageTanksPage : PageBase
    {
        private string guiMap;

        public StorageTanksPage(List<object> utilsList)
            : base(utilsList, "StorageTanksTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "StorageTanksTab.xml");
        }

        public CommonControls.EcolabDataGrid StorageTanksTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "StorageTankTableGrid");
            }
        }

        public HtmlAnchor StorageTanksTab
        {
            get
            {
                return GetHtmlControl<HtmlAnchor>("tabStorageTanks");
            }
        }

        public HtmlAnchor AddStorageTanks
        {
            get
            {
                return GetHtmlControl<HtmlAnchor>("btnAddStorageTanks");
            }
        }

        public bool IsAddStorageTanksPrsent
        {
            get
            {
                return IsPresent<HtmlControl>("btnAddStorageTanks");
            }
        }
        
        public HtmlSpan BackToStorageTanks
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("btnBackToStorageTanks");
            }
        }

        public HtmlInputText TankName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTankName");
            }
        }

        public HtmlSelect ProductName
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlProductName");
            }
        }

        public HtmlInputText LowLevel
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtLowLevel");
            }
        }

        public HtmlInputText Size
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtSize");
            }
        }

        public HtmlSelect ControllerName
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlControllerName");
            }
        }

        public HtmlInputText EmptyLevel
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtEmptyLevel");
            }
        }

        public HtmlInputText LevelDeviation
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtLevelDeviation");
            }
        }

        public HtmlInputText CallibrationLevel
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtCallibrationLevel");
            }
        }

        public HtmlSelect InputType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlInputType");
            }
        }

        public HtmlSpan Save
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("btnSave");
            }
        }

        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }

        public HtmlControl Errordiv
        {
            get
            {
                return GetHtmlControl<HtmlControl>("errordiv");
            }
        }

        public HtmlControl InlineEditSuccessMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("InlineEditSuccessMsg");
            }
        }

        public HtmlControl MaxTanksReachedError
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MaxTanksReachedError");
            }
        }

        public bool IsSuccessMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("InlineEditSuccessMsg");
            }
        }

        public HtmlControl LowAndCalibrationLevelsError
        {
            get
            {
                return GetHtmlControl<HtmlControl>("LowAndCalibrationLevelsError");
            }
        }

        public HtmlControl EmptyAndLowLevelsError
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EmptyAndLowLevelsError");
            }
        }

        public HtmlSpan dialogMsg
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("dialogMsg");
            }
        }

        public void AddingStorageTankWithNonAdmin(string tankName, string lowLevel, string size, string calibrationlevel, string emptyLevel, string levelDeviation)
        {
            AddStorageTankCommonSteps(tankName, lowLevel, size, calibrationlevel, emptyLevel, levelDeviation);
            Save.Focus();
            Save.Click();
        }        

        public void AddingStorageTank(string tankName, string lowLevel, string size, string calibrationlevel, string emptyLevel, string levelDeviation)
        {
            AddStorageTankCommonSteps(tankName, lowLevel, size, calibrationlevel, emptyLevel, levelDeviation);
            InputType.SelectByIndex(1,Config.PageClassSettings.Default.MaxTimeoutValue);
            Save.Focus();
            Save.Click();
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //Thread.Sleep(2000);
        }

        public void UpdatingStorageTank(string tankName, string lowLevel, string size, string calibrationlevel, string emptyLevel)
        {
            TankName.TypeText(tankName);
            ProductName.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            LowLevel.TypeText(lowLevel);
            //EmptyLevel.TypeText(emptyLevel);
            ControllerName.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            //LevelDeviation.TypeText(levelDeviation);
            Size.SetText(size);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            EmptyLevel.Focus();
            EmptyLevel.MouseClick();
            EmptyLevel.TypeText(emptyLevel);
            CallibrationLevel.DeskTopMouseClick();
            CallibrationLevel.TypeText(calibrationlevel);
            Save.Focus();
            Save.Click();
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //Thread.Sleep(2000);


        }

        public void InLineEditingStorageTank(string tankName, string lowLevel, string size, string emptyLevel,
            string calibrationlevel)
        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            TankName.Focus();
            //TankName.DeskTopMouseClick();
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.SetText(tankName);
            //TankName.TypeText(tankName);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.KeyPress(Keys.Down);
            //ControllerName.SelectByIndex(1);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.KeyPress(Keys.Down);
            //ProductName.SelectByIndex(1);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.SetNumeric(emptyLevel);
            //EmptyLevel.TypeText(emptyLevel);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.SetNumeric(lowLevel);
            //LowLevel.TypeText(lowLevel);
            KeyBoardSimulator.KeyPress(Keys.Tab);
            KeyBoardSimulator.SetNumeric(calibrationlevel);
            //LevelDeviation.TypeText(levelDeviation);
            //Size.TypeText(size);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //Thread.Sleep(2000);


        }

        public bool isRecordExist(string tankName)
        {
            ICollection<Element> eChild = StorageTanksTableGrid.Find.AllByXPath(@"//tbody/tr");
            foreach (Element e in eChild)
            {
                if (e.ChildNodes[3].InnerText == tankName)
                {
                    return true;
                }
            }
            return false;
        }

        private void AddStorageTankCommonSteps(string tankName, string lowLevel, string size, string calibrationlevel, string emptyLevel, string levelDeviation)
        {
            AddStorageTanks.Click();
            Thread.Sleep(2000);
            TankName.TypeText(tankName);
            ProductName.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            LowLevel.TypeText(lowLevel);
            EmptyLevel.TypeText(emptyLevel);
            ControllerName.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            LevelDeviation.TypeText(levelDeviation);
            Size.SetText(size);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            EmptyLevel.Focus();
            EmptyLevel.DeskTopMouseClick();
            EmptyLevel.TypeText("0");
            CallibrationLevel.DeskTopMouseClick();
            CallibrationLevel.TypeText(calibrationlevel);
        }

    }
}
