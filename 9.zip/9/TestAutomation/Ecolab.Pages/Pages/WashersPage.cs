﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Win32.Dialogs;
using Ecolab.CommonUtilityPlugin;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telerik.TestingFramework.Controls.KendoUI;

namespace Ecolab.Pages
{
    public class WashersPage : PageBase
    {
        private string guiMap;
        /// <summary>
        /// reading guimap OR objects
        /// </summary>
        /// <param name="TelerikPlugin"></param>
        public WashersPage(Ecolab.TelerikPlugin.TelerikFramework TelerikPlugin)
            : base(TelerikPlugin)
        {
            guiMap = string.Concat(GuiMapPath, "WashersTab.xml");
        }

        public WashersPage(List<object> utilsList)
            : base(utilsList, "WashersTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "WashersTab.xml");
        }

        /// <summary>
        ///
        /// </summary>
        public CommonControls.EcolabDataGrid WashersListGridTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "WashersListGridTable");
            }
        }

        public CommonControls.EcolabDataGrid ConnectionsTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ConnectionsTable");
            }
        }

        /// <summary>
        ///
        /// </summary>
        public CommonControls.EcolabDataGrid CompartmentChemicalsTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "CompartmentChemicalsTableGrid");
            }
        }

        public CommonControls.EcolabDataGrid PumpsTableInCompartmentsTab
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "PumpsTableInCompartmentsTab");
            }
        }


        /// <summary>
        ///Gets Washer tab controls
        /// </summary>
        public HtmlControl WashersTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabWashers");
            }
        }
        public HtmlControl ConnectionsTabHeader
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ConnectionsTabHeader");
            }
        }
        public HtmlControl FlushTimeTabHeader
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FlushTimeTabHeader");
            }
        }
        public HtmlControl AnalogDosingTabHeader
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AnalogDosingTabHeader");
            }
        }
        public HtmlControl BatchEjectTabHeader
        {
            get
            {
                return GetHtmlControl<HtmlControl>("BatchEjectTabHeader");
            }
        }
        public HtmlControl ProductDeviationTabHeader
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProductDeviationTabHeader");
            }
        }
        public HtmlControl SetupWasherTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabSetupWasher");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlControl Compartment1
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Compartment1");
            }
        }

        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlControl tabWasher
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabWasher");
            }
        }

        public bool IsTabWasherPresent
        {
            get
            {
                return IsPresent<HtmlControl>("tabWasher");
            }
        }

        public HtmlControl ConnectionsTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabConnections");
            }
        }

        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlControl Compartment2
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Compartment2");
            }
        }
       
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlControl Compartment3
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Compartment3");
            }
        }
        /// <summary>
        ///Gets Compartments tab controls
        /// </summary>
        public HtmlControl CompartmentsTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabCompartments");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlControl AddWasherMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AddWasherMsg");
            }
        }

        public HtmlControl washerUom
        {
            get
            {
                return GetHtmlControl<HtmlControl>("washerUom");
            }
        }

        public HtmlInputCheckBox cbIsPony
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("cbIsPony");
            }
        }
        public HtmlControl washerCapacityUOM
        {
            get
            {
                return GetHtmlControl<HtmlControl>("washerCapacityUOM");
            }
        }
        /// <summary>
        ///
        /// </summary>
        public HtmlControl WasherUpdationMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WasherUpdationMsg");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlSelect Compartment
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlCompartment");
            }
        }
        public HtmlSelect MoveCompartment
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMoveCompartment");
            }
        }
        /// <summary>
        ///Gets Compartments tab controls
        /// </summary>
        public HtmlControl NextCompartment
        {
            get
            {
                return GetHtmlControl<HtmlControl>("NextCompartment");
            }
        }

        public HtmlControl SaveMovePump
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SaveMovePump");
            }
        }
        /// <summary>
        ///Gets Compartments tab controls
        /// </summary>
        public HtmlControl PreviousCompartment
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PreviousCompartment");
            }
        }
        public HtmlControl WaterLevel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WaterLevel");
            }
        }
        /// <summary>
        ///Gets Compartments tab controls
        /// </summary>
        public HtmlControl ButtonControlsArea
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ButtonControlsArea");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlSelect WaterInlet
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWaterInlet");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlSelect WashZone
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWashZone");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlSelect WaterFlow
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWaterFlow");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlSelect Chemical
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlChemical");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlButton AddPump
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnAddPump");
            }
        }
        /// <summary>
        ///Gets controls
        /// </summary>
        public HtmlButton SaveCompartment
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveCompartment");
            }
        }
        /// <summary>
        /// Gets language preferred control from general tab
        /// </summary>
        public HtmlSelect LanguagePreferred
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("SelectPreferredLanguage");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public HtmlSelect LFSWasher
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("LFSWasher");
            }
        }

        public HtmlInputText MinimumMachineLoad
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMinimumMachineLoad");
            }
        }

        public HtmlInputText ME1Valve1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME1Valve1");
            }
        }

        public HtmlInputText ME1Valve2
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME1Valve2");
            }
        }

        public HtmlInputText ME1Valve3
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME1Valve3");
            }
        }

        public HtmlInputText ME1Valve4
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME1Valve4");
            }
        }

        public HtmlInputText ME1Valve5
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME1Valve5");
            }
        }

        public HtmlInputText ME1Valve6
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME1Valve6");
            }
        }

        public HtmlInputText ME2Valve1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME2Valve1");
            }
        }

        public HtmlInputText ME2Valve2
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME2Valve2");
            }
        }

        public HtmlInputText ME2Valve3
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME2Valve3");
            }
        }

        public HtmlInputText ME2Valve4
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME2Valve4");
            }
        }

        public HtmlInputText ME2Valve5
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME2Valve5");
            }
        }

        public HtmlInputText ME2Valve6
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtME2Valve6");
            }
        }

        public HtmlInputText DosingPump1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump1");
            }
        }

        public HtmlInputText DosingPump2
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump2");
            }
        }

        public HtmlInputText DosingPump3
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump3");
            }
        }

        public HtmlInputText DosingPump4
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump4");
            }
        }

        public HtmlInputText DosingPump5
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump5");
            }
        }

        public HtmlInputText DosingPump6
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump6");
            }
        }

        public HtmlInputText DosingPump7
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump7");
            }
        }

        public HtmlInputText DosingPump8
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtDosingPump8");
            }
        }

        public HtmlInputText MCCnctDosngPoint1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint1");
            }
        }

        public HtmlInputText MCCnctDosngPoint2
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint2");
            }
        }

        public HtmlInputText MCCnctDosngPoint3
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint3");
            }
        }

        public HtmlInputText MCCnctDosngPoint4
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint4");
            }
        }

        public HtmlInputText MCCnctDosngPoint5
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint5");
            }
        }

        public HtmlInputText MCCnctDosngPoint6
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint6");
            }
        }

        public HtmlInputText MCCnctDosngPoint7
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint7");
            }
        }

        public HtmlInputText MCCnctDosngPoint8
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint8");
            }
        }

        public HtmlInputText MCCnctDosngPoint9
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint9");
            }
        }

        public HtmlInputText MCCnctDosngPoint10
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint10");
            }
        }

        public HtmlInputText MCCnctDosngPoint11
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint11");
            }
        }

        public HtmlInputText MCCnctDosngPoint12
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCnctDosngPoint12");
            }
        }

        public HtmlInputText MCCompsFrValves1
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves1");
            }
        }

        public HtmlInputText MCCompsFrValves2
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves2");
            }
        }

        public HtmlInputText MCCompsFrValves3
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves3");
            }
        }

        public HtmlInputText MCCompsFrValves4
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves4");
            }
        }

        public HtmlInputText MCCompsFrValves9
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves9");
            }
        }

        public HtmlInputText MCCompsFrValves10
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves10");
            }
        }

        public HtmlInputText MCCompsFrValves11
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves11");
            }
        }

        public HtmlInputText MCCompsFrValves12
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMCCompsFrValves12");
            }
        }


        /// <summary>
        /// 
        /// </summary>
        public HtmlSelect Size
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("Size");
            }
        }
        /// <summary>
        /// Gets save button control
        /// </summary>
        public HtmlButton GeneralTabSaveButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnUpload");
            }
        }
        /// <summary>
        /// Gets save button control
        /// </summary>
        public bool IsAddWasherPresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnAddWasher");
            }
        }

        public HtmlButton AddWasher
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnAddWasher");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public HtmlButton SaveCoventionalWasher
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveCoventionalWasher");
            }
        }
        /// <summary>
        /// Gets the control of success MSG.
        /// </summary>
        /// <returns></returns>
        public HtmlControl SuccessMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SuccessValidationMessage");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public HtmlControl ErrorMessageTunnel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ErrorMessageTunnel");
            }
        }

        public HtmlControl ResultMessageTunnel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ResultMessageTunnel");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public HtmlControl ErrorMessageConventional
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ErrorMessageConventional");
            }
        }
        /// <summary>
        /// Gets Back To Washers Link Button
        /// </summary>
        /// <returns></returns>
        public HtmlSpan BtnBacktoWashersLink
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("btnBacktoWashersLink");
            }
        }
        /// <summary>
        /// Gets DropDown Control of Model
        /// </summary>
        /// <returns></returns>
        public HtmlSelect DdlModel
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlModel");
            }
        }
        /// <summary>
        /// Gets DropDown Control of Model
        /// </summary>
        /// <returns></returns>
        public HtmlInputText TxtName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtName");
            }
        }
        /// <summary>
        /// Gets DropDown Control of Controller
        /// </summary>
        /// <returns></returns>
        public HtmlSelect DdlController
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlController");
            }
        }
        /// <summary>
        /// Gets Drop down Control of Washer Mode
        /// </summary>
        /// <returns></returns>
        public HtmlSelect DdlWasherMode
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherMode");
            }
        }

        public HtmlSelect DdlTransferType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlTransferType");
            }
        }
        public HtmlSelect DdlWasherGroups
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherGroups");
            }
        }

        public HtmlSelect DdlPress
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlPress");
            }
        }
        /// <summary>
        /// Gets TextBox control
        /// </summary>
        /// <returns></returns>
        public HtmlInputText TxtPlantWasher
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtPlantWasher");
            }
        }
        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        public HtmlInputText NumberOfCompartments
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNumberOfCompartments");
            }
        }
        /// <summary>
        /// Gets TextBox control for Program Number
        /// </summary>
        /// <returns></returns>
        public HtmlInputText TxtProgramNo
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtProgramNo");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public HtmlInputText EndOfFormulaNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtEndOfFormulaNumber");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public HtmlInputText PlantWasherNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtPlantWasherNumber");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public HtmlInputText WasherCapacity
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWasherCapacity");
            }
        }
        /// <summary>
        /// Gets the save button control
        /// </summary>
        /// <returns></returns>
        public HtmlButton BtnSaveTunnel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveTunnel");
            }
        }
        /// <summary>
        /// Gets the Cancel Button Control
        /// </summary>
        /// <returns></returns>
        public HtmlButton BtnCancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }
        /// <summary>
        /// Gets the Target Runtime
        /// </summary>
        /// <returns></returns>
        public HtmlInputText TargetTurntime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtTargetTurntime");
            }
        }
        /// <summary>
        /// Gets the Washer Idle Time
        /// </summary>
        /// <returns></returns>
        public HtmlInputText WasherIdleTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtWasherIdleTime");
            }
        }
        /// <summary>
        /// Gets popup ok button control for deleting
        /// </summary>
        /// <returns></returns>
        public HtmlButton BtnOkDelete
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnOkDelete");
            }
        }
        /// <summary>
        /// Gets popup Cancel button control for deleting
        /// </summary>
        /// <returns></returns>
        public HtmlButton BtnCancelDelete
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancelDelete");
            }
        }
        /// <summary>
        /// Gets popup Yes Prompt button control for Navigation
        /// </summary>
        /// <returns></returns>
        public HtmlButton BtnYesPopUp
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnYesPopUp");
            }
        }
        /// <summary>
        /// Gets popup No Prompt button control for Navigation
        /// </summary>
        /// <returns></returns>
        public HtmlButton BtnNoPopUp
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnNoPopUp");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public HtmlButton DeleteWasherYesButton
        {
            get
            {
                return GetHtmlControl<HtmlButton>("DeleteWasherYesButton");
            }
        }

        /// <summary>		
        ///Gets controls		
        /// </summary>		
        public HtmlInputCheckBox chkAWE
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("chkAWE");
            }
        }
        /// <summary>		
        ///Gets controls		
        /// </summary>		
        public HtmlInputCheckBox chkRatioDosingActive
        {
            get
            {
                return GetHtmlControl<HtmlInputCheckBox>("chkRatioDosingActive");
            }
        }

        public HtmlInputText txtEndOfFormula
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtEndOfFormula");
            }
        }

        public HtmlButton btnSaveAndCloseConventionalGeneral
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveAndCloseConventionalGeneral");
            }
        }

        /// <summary>		
        /// 		
        /// </summary>		
        /// <returns></returns>		
        public HtmlButton btnWasherPopUpCancelNo
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnWasherPopUpCancelNo");
            }
        }
        /// <summary>		
        /// 		
        /// </summary>		
        /// <returns></returns>		
        public HtmlButton btnCancelWasher
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancelWasher");
            }
        }
        /// <summary>		
        /// 		
        /// </summary>		
        /// <returns></returns>		
        public HtmlControl lnkBackToWasherGroup
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkBackToWasherGroup");
            }
        }

        public HtmlControl WashergroupTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("TabWashergroup");
            }
        }
        /// <summary>		
        /// 		
        /// </summary>		
        /// <returns></returns>		
        public bool IsWashergroupPresent
        {
            get
            {
                //HtmlControl controllerTab = ControllersTab;		
                return IsPresent<HtmlControl>("TabWashergroup");
            }
        }

        /// <summary>
        /// Gets the Target Runtime
        ///</summary>
        /// <returns></returns>
        //public HtmlInputText TargetTurntime
        //{
        //    get
        //    {
        //        return GetHtmlControl<HtmlInputText>("txtTargetTurntime");
        //    }

        //}
        //  /// <summary>
        //      /// Gets the Washer Idle Time
        //      ///</summary>
        //  /// <returns></returns>
        //public HtmlInputText WasherIdleTime
        //{
        //    get
        //    {
        //        return GetHtmlControl<HtmlInputText>("txtWasherIdleTime");
        //    }
        //}
        /// <summary>
        /// Deleting Washer Details
        /// </summary>
        /// <param name="DeleteWasherGroup">The Washer details.</param>
        public void DeleteWasherFromGridList(string text)
        {
            ConfirmDialog confirmDialog =
                          ConfirmDialog.CreateConfirmDialog(Telerik.ActiveBrowser.Manager.ActiveBrowser, DialogButton.OK);
            Telerik.ActiveBrowser.Manager.DialogMonitor.AddDialog(confirmDialog);
            Thread.Sleep(2000);
            WashersListGridTable.SelectedRows(text)[0].GetButtonControls()[0].DeskTopMouseClick();
        }

        public bool UpdateWasherDetails(string[] SetValues)
        {
            MouseKeyBoardSimulator objSimulator = new MouseKeyBoardSimulator();
            Thread.Sleep(3000);
            if (DdlController.ChildNodes.Count > 1)
            {
                DdlModel.Focus();
                DdlModel.SelectByIndex(1);
                DdlModel.MouseClick();
                KeyBoardSimulator.KeyDown(Keys.Select);
                KeyBoardSimulator.KeyPress(Keys.Enter);
            }
            else
            {
                return false;
            }
            if (DdlController.ChildNodes.Count > 1)
            {
                DdlController.Focus();
                DdlController.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
                DdlWasherMode.Focus();
                KeyBoardSimulator.KeyDown(Keys.Select);
                KeyBoardSimulator.KeyPress(Keys.Enter);
            }
            else
            {
                return false;
            }
            TxtName.Focus();
            TxtName.Text = string.Empty;
            //objSimulator.SetText(SetValues[0]);
            TxtName.TypeText(SetValues[0]);
            //TxtPlantWasher.Focus();
            //TxtPlantWasher.Text = string.Empty;
            //TxtPlantWasher.TypeText(SetValues[1]);
            //TxtProgramNo.Focus();
            //TxtProgramNo.Text = string.Empty;
            //objSimulator.SetNumeric(SetValues[2]);
            DdlTransferType.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            DdlPress.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            Thread.Sleep(2000);
            BtnSaveTunnel.Focus();
            BtnSaveTunnel.DeskTopMouseClick();
            return true;
        }

    }
}
