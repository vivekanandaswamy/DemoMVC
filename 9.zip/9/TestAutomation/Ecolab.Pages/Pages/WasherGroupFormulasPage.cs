﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Collections.ObjectModel;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Windows.Forms;
using ArtOfTest.WebAii.Core;
using Ecolab.CommonUtilityPlugin;

namespace Ecolab.Pages.Pages
{
    public class WasherGroupFormulasPage : PageBase
    {

        private string guiMap;

        public WasherGroupFormulasPage(List<object> utilsList)
            : base(utilsList, "WasherGroupFormulasTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "WasherGroupFormulasTab.xml");
        }

        public CommonControls.EcolabDataGrid FormulasTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "FormulasTableGrid");
            }
        }
        public CommonControls.EcolabDataGrid ImportFormulasTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ImportFormulasGrid");
            }
        }

        public CommonControls.EcolabDataGrid WasherGroupsTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "WasherGroupsTableGrid");
            }
        }
        public CommonControls.EcolabDataGrid tblAddWashstepProducts
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "tblAddWashstepProducts");
            }
        }

        
        public HtmlAnchor WashergroupTab
        {
            get
            {
                return GetHtmlControl<HtmlAnchor>("tabWashergroup");
            }
        }

        public HtmlSpan AddWasherGroup
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("AddWasherGroup");
            }
        }

        public HtmlAnchor WashersSetupTab
        {
            get
            {
                return GetHtmlControl<HtmlAnchor>("tabWashersSetup");
            }
        }

        public HtmlControl FormulaTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabFormula");
            }
        }

        public HtmlInputText GroupNumber
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtGroupNumber");
            }
        }

        public HtmlInputText GroupName
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtGroupName");
            }
        }

        public HtmlSelect WasherGroupType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherGroupType");
            }
        }

        public HtmlButton Save
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSave");
            }
        }
        public HtmlButton SaveFormula
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveFormula");
            }
        }
        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }
        public HtmlButton SaveAndClose
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveAndClose");
            }
        }

        public HtmlControl ButtonContainer
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnContainer");
            }
        }
        public HtmlControl SaveYes
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnSaveYes");
            }
        }
        public HtmlControl SaveNo
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnSaveNo");
            }
        }
      
         public HtmlControl ImportFormula
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnImportFormula");
            }
        }
        
        public HtmlButton SaveWashStep
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveWashStep");
            }
        }

        public HtmlButton WasherGroupSaveSave
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnWasherGroupSaveSave");
            }
        }

        public HtmlControl divMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("divMessage");
            }
        }

        public HtmlControl MaxFormulaNumberError
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MaxFormulaNumberError");
            }
        }

        public HtmlControl MaxFormulaNumberErrorEU
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MaxFormulaNumberErrorEU");
            }
        }

        public HtmlControl TxtWaterLevel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtWaterLevel");
            }
        }

        public HtmlControl FormulaCreationSuccessMsg
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulaCreationSuccessMsg");
            }
        }

        public HtmlSelect WaterType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWaterType");
            }
        }

        public HtmlSelect WashOperation
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWashOperation");
            }
        }
        public HtmlSelect TunnelStep
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlTunnelStep");
            }
        }
        public HtmlInputText Notes
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNotes");
            }
        }

        public HtmlControl divMessageCreate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("divMessageCreate");
            }
        }

        public HtmlControl FormulaSuccessMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulaSuccessMessage");
            }
        }

        public HtmlControl AddFormula
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AddFormula");
            }
        }

        public HtmlControl AddFormulaText
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AddFormulaText");
            }
        }

        public bool IsBtnAddFormulaPresent
        {
            get
            {
                return IsPresent<HtmlControl>("AddFormula");
            }
        }

        public HtmlControl CancelInjection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CancelInjection");
            }
        }

        public HtmlSpan BacktoWasherGroups
        {
            get
            {
                return GetHtmlControl<HtmlSpan>("btnBacktoWasherGroups");
            }
        }

        public HtmlInputText Number
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNumber");
            }
        }

        public HtmlSelect FormulaName
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlFormulaName");
            }
        }

        public HtmlInputText NominalLoadForConventional
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNominalLoadForConventional");
            }
        }
        public HtmlInputText NominalLoadForTunnel
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNominalLoadForTunnel");
            }
        }

        public HtmlInputText NominalLoad
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNominalLoad");
            }
        }

        public HtmlInputText NominalLoadInlineEdit
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNominalLoadInlineEdit");
            }
        }

        public HtmlInputText LoadsPerMonth
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtLoadsPerMonth");
            }
        }

        public HtmlInputText ExtraTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtExtraTime");
            }
        }

        public HtmlInputText ExtraTimeEu
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtExtraTimeeu");
            }
        }
         public HtmlInputText StandardRunTime
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtStandardRunTime");
            }
        }

        
        public ReadOnlyCollection<HtmlSelect> GetWashStepOperations 
        { 
            get
            {
                return WaitforAction<ReadOnlyCollection<HtmlSelect>>(() =>
                {
                    return Telerik.Find.AllByXPath<HtmlSelect>(".//*[@id='tblWashSteps']/tbody/tr/td[3]/span[1]/select");
                },Config.PageClassSettings.Default.MaxTimeoutValue);
            }
        }

        public bool IsButtonContainerPresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnContainer");
            }
        }
        public bool IsFormulaTableGridPresent
        {
            get
            {
                return IsPresent<HtmlControl>("FormulasTableGrid");
            }
        }

        public bool IsFormulaCreationSuccessMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("FormulaCreationSuccessMsg");
            }
        }
        public bool IsFormulaSuccessMessagePresent
        {
            get
            {
                return IsPresent<HtmlControl>("FormulaSuccessMessage");
            }
        }
     
        public void AddingWasherGroup(string groupNumber, string groupName)
        {
            GroupNumber.TypeText(groupNumber);
            GroupName.TypeText(groupName);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            GroupName.SetText(groupName);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            GroupNumber.MouseClick();
            GroupNumber.TypeText(groupNumber);
            GroupName.TypeText(groupName);
            WasherGroupSaveSave.Focus();
            WasherGroupSaveSave.Click();
        }

        public void AddingFormula(string number, string nominalLoad, string loadsPerMonth, string extraTime)
        {
            Number.TypeText(number);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            FormulaName.SelectByIndex(1,Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NominalLoadForConventional.TypeText(nominalLoad);
            //LoadsPerMonth.TypeText(loadsPerMonth);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            ExtraTime.TypeText(extraTime);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //NominalLoad.MouseClick();
            //NominalLoad.SetText("0");
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            ExtraTime.MouseClick();
            //NominalLoadForConventional.TypeText(nominalLoad);
        }
        public void AddingFormula(string nominalLoad)
        {           
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            FormulaName.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NominalLoadForConventional.TypeText(nominalLoad);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            ExtraTime.MouseClick();
        }

        public void AddingFormula(string formulaName, string nominalLoad, string extraTime, int regionId, string model)
        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            //try
            //{
                FormulaName.SelectByPartialText(formulaName, true);
            //}
            //catch (Exception)
            //{
            //    FormulaName.SelectByIndex(1, 2000);
            //}
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NominalLoadForConventional.TypeText(nominalLoad);
            //LoadsPerMonth.TypeText(loadsPerMonth);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            if (regionId == 1 && model != "myControl")
            {
                ExtraTime.TypeText(extraTime);
                MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            }
            else 
            {
                ExtraTimeEu.TypeText(extraTime);
                MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            }
          
        }
        public void AddingFormula(string formulaName, string nominalLoad)
        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            //try
            //{
                FormulaName.SelectByPartialText(formulaName, true);
            //}
            //catch (Exception)
            //{
            //    FormulaName.SelectByIndex(1, 2000);
            //}
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NominalLoadForConventional.TypeText(nominalLoad);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
        }



        public void AddingFormulaForTunnelWasher(string formulaName, string nominalLoad)
        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();
            //try
            //{
                FormulaName.SelectByPartialText(formulaName, true);
            //}
            //catch(Exception)
            //{
            //    FormulaName.SelectByIndex(1, 2000);
            //}
            
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
           
            NominalLoadForTunnel.TypeText(nominalLoad);
            //LoadsPerMonth.TypeText(loadsPerMonth);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            //StandardRunTime.MouseClick();

        }

        public void AddingFormulaForTunnelWasher(string formulaName, string nominalLoad, string runTime)
        {
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            FormulaName.Focus();            
            FormulaName.SelectByPartialText(formulaName, true); 
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NominalLoadForTunnel.TypeText(nominalLoad);
            //LoadsPerMonth.TypeText(loadsPerMonth);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            StandardRunTime.TypeText(runTime);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);  

        }
        //public void AddingFormulaForTunnelWasher(string number, string nominalLoad, string runTime)
        //{
        //    Number.TypeText(number);
        //    MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
        //    FormulaName.Focus();
        //    FormulaName.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
        //    MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
        //    NominalLoadForTunnel.TypeText(nominalLoad);
        //    //LoadsPerMonth.TypeText(loadsPerMonth);
        //    MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
        //    StandardRunTime.TypeText(runTime);
        //    MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);          

        //}

        public void UpdatingFormula(string nominalLoad, string loadsPerMonth, string extraTime)
        {
            NominalLoadForConventional.Focus();
            NominalLoadForConventional.TypeText(nominalLoad);
            //LoadsPerMonth.TypeText(loadsPerMonth);
            //NominalLoad.SetText("0");
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            ExtraTime.MouseClick();
            ExtraTime.TypeText(extraTime);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NominalLoadForConventional.TypeText(nominalLoad);
            SelectAllWashStepOperations();
            Save.ScrollToVisible();
            Save.Focus();
            //Save.Click();
            Save.DeskTopMouseClick();
            //Save.DeskTopMouseClick();
        }

        public void InLineEditingFormula(string nominalLoad, string loadsPerMonth, string extraTime)
        {
            MouseKeyBoardSimulator objKeyPress = new MouseKeyBoardSimulator();
            objKeyPress.KeyPress(System.Windows.Forms.Keys.Tab);
            objKeyPress.KeyPress(System.Windows.Forms.Keys.Tab);
            objKeyPress.KeyPress(System.Windows.Forms.Keys.Tab);
            //NominalLoadInlineEdit.DeskTopMouseClick();
            //NominalLoadInlineEdit.Focus();
            //NominalLoadInlineEdit.TypeText(nominalLoad);
            objKeyPress.SetNumeric(nominalLoad);
            objKeyPress.KeyPress(System.Windows.Forms.Keys.Tab);
            objKeyPress.KeyPress(System.Windows.Forms.Keys.Tab);
            objKeyPress.SetNumeric(loadsPerMonth);
            //LoadsPerMonth.TypeText(loadsPerMonth);
            //ExtraTime.TypeText(extraTime);
        }

        public void SelectAllWashStepOperations()
        {
            ReadOnlyCollection<HtmlSelect> washStepOperationList = GetWashStepOperations;
            if (null != washStepOperationList && washStepOperationList.Count > 0)
            {
                foreach (HtmlSelect washStepOperation in washStepOperationList)
                {
                    //washStepOperation.DeskTopMouseClick();
                    washStepOperation.ScrollToVisible();
                    washStepOperation.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
                }
            }
        }        
    }
}
