﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Pages.Pages
{
    public class HelpMenu : PageBase
    {
        private string guiMap;

        public HelpMenu(List<object> utilsList)
            : base(utilsList, "HelpMenu.xml")
        {
            guiMap = string.Concat(GuiMapPath, "HelpMenu.xml");
        }

        public HtmlControl HelpLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("helpLink");
            }
        }

        public HtmlControl LnkFinancials
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkFinancials");
            }
        }

        public HtmlControl LnkInternal
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkInternal");
            }
        }

        public HtmlControl LnkProductionEfficiency
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkProductionEfficiency");
            }
        }
        public HtmlControl LnkResourceUtilization
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkResourceUtilization");
            }
        }
        public HtmlControl LnkWashingProcessValidation
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkWashingProcessValidation");
            }
        }


        public HtmlControl LnkCostSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkCostSummary");
            }
        }
        public HtmlControl LnkAccSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkAccSummary");
            }
        }
        public HtmlControl LnkFFeval
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkFFeval");
            }
        }
        public HtmlControl LnkMachineHoldTime
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkMachineHoldTime");
            }
        }
        public HtmlControl LnkServPreparation
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkServPreparation");
            }
        }
        public HtmlControl LnkUserLog
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkUserLog");
            }
        }
        public HtmlControl LnkWPdetails
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkWPdetails");
            }
        }

        public HtmlControl LnkEBMachine
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkEBMachine");
            }
        }
        public HtmlControl LnkEBWEquipment
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkEBWEquipment");
            }
        }
        public HtmlControl LnkMSActionList
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkMSActionList");
            }
        }
        public HtmlControl LnkPProduction
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkPProduction");
            }
        }
        public HtmlControl LnkPSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkPSummary");
            }
        }
        public HtmlControl LnkProduction
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkProduction");
            }
        }
        public HtmlControl LnkRewash
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkRewash");
            }
        }
        public HtmlControl LnkCConsumption
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkCConsumption");
            }
        }
        public HtmlControl LnkCInventory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkCInventory");
            }
        }
        public HtmlControl LnkMeters
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkMeters");
            }
        }

         public HtmlControl LnkOperationSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("lnkOperationSummary");
            }        
        }

         public HtmlControl LnkAlarmDetails
         {
             get
             {
                 return GetHtmlControl<HtmlControl>("lnkAlarmDetails");
             }
         }
         public HtmlControl LnkAlarmSummary
         {
             get
             {
                 return GetHtmlControl<HtmlControl>("lnkAlarmSummary");
             }
         }
         public HtmlControl LnkProcessValidationDetails
         {
             get
             {
                 return GetHtmlControl<HtmlControl>("lnkProcessValidationDetails");
             }
         }
         public HtmlControl LnkPVSummary
         {
             get
             {
                 return GetHtmlControl<HtmlControl>("lnkPVSummary");
             }
         }
         public HtmlControl LnkRedFlags
         {
             get
             {
                 return GetHtmlControl<HtmlControl>("lnkRedFlags");
             }
         }
         public HtmlControl LnkRBatches
         {
             get
             {
                 return GetHtmlControl<HtmlControl>("lnkRBatches");
             }
         }
        public HtmlControl ReportName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("reportname");
            }
        }

        public HtmlControl LocalHelpMenu
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Help");
            }
        }

        public HtmlControl HelpMenuHome
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpHome");
            }
        }
        public HtmlControl HelpMenuDashboard
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpMenuDashboard");
            }
        }


        public HtmlControl HomeContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HomeContent");
            }
        }



        public HtmlControl HelpReportsSideNav
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpReportsSideNav");
            }
        }

        public HtmlControl HelpRptProductionSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptProductionSummary");
            }
        }
        public HtmlControl HelpRptProductionSummaryContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptProductionSummaryContent");
            }
        }
        public HtmlControl HelpRptProductionDetails
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptProductionDetails");
            }
        }
        public HtmlControl HelpRptProductionDetailsContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptProductionDetailsContent");
            }
        }
        public HtmlControl HelpRptAlaramSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptAlaramSummary");
            }
        }
        public HtmlControl HelpRptAlaramSummaryContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptAlaramSummaryContent");
            }
        }

        public HtmlControl HelpRptAlaramDetails
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptAlaramDetails");
            }
        }
        public HtmlControl HelpRptAlaramDetailsContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptAlaramDetailsContent");
            }
        }



        public HtmlControl HelpMenuContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpMenuContent");
            }
        }

        public HtmlControl HelpRptChemicalConsumption
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptChemicalConsumption");
            }
        }
        public HtmlControl HelpRptChemicalInventory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptChemicalInventory");
            }
        }

        public HtmlControl HelpRptOperationSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptOperationSummary");
            }
        }
        public HtmlControl HelpRptUseLog
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpRptUseLog");
            }
        }    

    }
}
