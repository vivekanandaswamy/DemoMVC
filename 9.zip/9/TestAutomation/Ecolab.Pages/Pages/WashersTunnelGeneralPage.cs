﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Collections.ObjectModel;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Windows.Forms;
using ArtOfTest.WebAii.Core;

namespace Ecolab.Pages.Pages
{
    public class WashersTunnelGeneralPage : PageBase
    {
        private string guiMap;

        public WashersTunnelGeneralPage(List<object> utilsList)
            : base(utilsList, "WashersTunnelGeneralTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "WashersTunnelGeneralTab.xml");
        }

        public CommonControls.EcolabDataGrid WashersTableGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "WashersTableGrid");
            }
        }
        public bool IsWashertableGridPresent
        {
            get
            {
                return IsPresent<HtmlTable>("WashersTableGrid");
            }
        }

        public HtmlControl WasherGroups
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnWasherGroups");
            }
        }

        public HtmlControl WasherGroupsSubType
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnWasherGroupsSubType");
            }
        }

        public HtmlButton AddNewWasher
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnAddNewWasher");
            }
        }

        public HtmlButton AddWasher
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnAddWasher");
            }
        }

        public HtmlInputText Name
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtName");
            }
        }

        public HtmlSelect Controller
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlController");
            }
        }

        public HtmlSelect WasherCapacity
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherCapacity");
            }
        }
     
        public HtmlSelect WasherMode
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlWasherMode");
            }
        }

        public HtmlInputText NoOfCompartments
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNoOfCompartments");
            }
        }

        public HtmlSelect Press
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlPress");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public HtmlInputText MCTunnelWasherCapacity
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("MCTunnelWasherCapacity");
            }
        }

        public HtmlInputText PlantWasher
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtPlantWasher");
            }
        }

        public HtmlSelect Model
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlModel");
            }
        }

        public HtmlAnchor BackToWasher
        {
            get
            {
                return GetHtmlControl<HtmlAnchor>("bckWasherbutton");
            }
        }

        public HtmlInputText MaxLoad
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtMaxLoad");
            }
        }

        //public HtmlInputText MCTunnelWasherCapacity
        //{
        //    get
        //    {
        //        return GetHtmlControl<HtmlInputText>("MCTunnelWasherCapacity");
        //    }
        //} 
        public HtmlInputText NoOfTanks
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtNoOfTanks");
            }
        }

        public HtmlSelect TransferType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlTransferType");
            }
        }

        public HtmlSelect PressOrExtractor
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlPressOrExtractor");
            }
        }
       
        public HtmlInputText ProgramNo
        {
            get
            {
                return GetHtmlControl<HtmlInputText>("txtProgramNo");
            }
        }

        public HtmlButton SaveTunnel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnSaveTunnel");
            }
        }

        public HtmlButton Cancel
        {
            get
            {
                return GetHtmlControl<HtmlButton>("btnCancel");
            }
        }

        public HtmlTextArea Description
        {
            get
            {
                return GetHtmlControl<HtmlTextArea>("txtDescription");
            }
        }

        public HtmlControl divMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("divMessage");
            }
        }
        public HtmlControl PlantWasherMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PlantWasherMessage");
            }
        }

        public HtmlControl Message
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Message");
            }
        }

        public HtmlControl WasherDeleteMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WasherDeleteMessage");
            }
        }
        public bool IsTunnelWasherPresent
        {
            get
            {
                return IsPresent<HtmlControl>("WashersTableGrid");
            }
        }

        public bool IsProgNoMandotoryMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("ProgNoMandotoryMsg");
            }
        }
        public bool IsWasherMandatorymsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("WasherMandatorymsg");
            }
        }
        public bool IsWashermodelMandatorymsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("WashermodelMandatorymsg");
            }
        }
        public bool IsWashermodeMandatorymsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("WashermodeMandatorymsg");
            }
        }
        public bool IsPlantWasherMandatorymsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("PlantWasherMandatorymsg");
            }
        }
        public bool IsNoOfTanksMandotoryMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("NoOfTanksMandotoryMsg");
            }
        }
        public bool IsNoOfCompMandatoryMsgPresent
        {
            get
            {
                return IsPresent<HtmlControl>("NoOfCompMandatoryMsg");
            }
        }






        public void AddingWahser(string WahserName, string PWasher, string PNumber)
        {
            AddWasher.Click();
            Thread.Sleep(2000);
            Name.Focus();
            Name.TypeText(WahserName);
            Thread.Sleep(2000);
            Model.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            Controller.SelectByPartialText("BSTuDisp1", true);
            WasherCapacity.SetText("101");
            PlantWasher.TypeText(PWasher);
            NoOfTanks.TypeText("0");
            NoOfCompartments.Focus();
            NoOfCompartments.TypeText("0");
            TransferType.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            PressOrExtractor.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            ProgramNo.TypeText(PNumber);
            WasherMode.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);            
            Description.TypeText("Test Washer Creation");
            SaveTunnel.Focus();
            SaveTunnel.Click();
        }
        public void AddingTunnelWahser(string WahserName, string PWasher, string PNumber)
        {
            //AddWasher.Click();
            Thread.Sleep(2000);
            Name.Focus();
            Name.TypeText(WahserName);
            Thread.Sleep(2000);
            Model.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            Controller.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            WasherCapacity.SetText("101");
            PlantWasher.TypeText(PWasher);
            NoOfTanks.TypeText("0");
            NoOfCompartments.Focus();
            NoOfCompartments.TypeText("0");
            TransferType.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            PressOrExtractor.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            ProgramNo.TypeText(PNumber);
            WasherMode.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            Description.TypeText("Test Washer Creation");
            SaveTunnel.Focus();
            SaveTunnel.Click();
        }
        public void UpdatingWasher(string WahserName, string PWasher, string PNumber)
        {
            Name.Focus();
            Name.TypeText(WahserName);
            Thread.Sleep(2000);
            Controller.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            Thread.Sleep(2000);
            //WasherMode.SelectByIndex(1);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NoOfCompartments.Focus();
            NoOfCompartments.TypeText("0");
            Press.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            Model.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            PlantWasher.TypeText(PWasher);
            MaxLoad.TypeText("0");
            NoOfTanks.TypeText("0");
            TransferType.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            ProgramNo.TypeText(PNumber);
            Description.TypeText("Test Washer Creation");
            SaveTunnel.Focus();
            SaveTunnel.Click();
        }

        public void CancellingAddWahser(string WahserName, string PWasher, string PNumber)
        {
            AddNewWasher.Click();
            Thread.Sleep(2000);
            Name.Focus();
            Name.TypeText(WahserName);
            Thread.Sleep(2000);
            Controller.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            Thread.Sleep(2000);
            //WasherMode.SelectByIndex(1);
            //MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            NoOfCompartments.Focus();
            NoOfCompartments.TypeText("0");
            Press.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            Model.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            PlantWasher.TypeText(PWasher);
            MaxLoad.TypeText("0");
            NoOfTanks.TypeText("0");
            TransferType.SelectByIndex(1, Config.PageClassSettings.Default.MaxTimeoutValue);
            MouseKeyboardLibrary.KeyboardSimulator.KeyPress(System.Windows.Forms.Keys.Tab);
            ProgramNo.TypeText(PNumber);
            Description.TypeText("Test Washer Creation");
            SaveTunnel.Focus();
            SaveTunnel.Click();
        }

    }
}
