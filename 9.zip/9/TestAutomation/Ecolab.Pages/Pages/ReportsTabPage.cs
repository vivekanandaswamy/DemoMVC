﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using ArtOfTest.WebAii.Controls.HtmlControls;
using System.Collections.ObjectModel;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Windows.Forms;
using ArtOfTest.WebAii.Core;
using Ecolab.Pages.CommonControls;
using System.Runtime.InteropServices;
using System.IO;
using System.Reflection;

namespace Ecolab.Pages.Pages
{
    public class ReportsTabPage : PageBase
    {
        private string guiMap;

        public ReportsTabPage(List<object> utilsList)
            : base(utilsList, "ReportsTab.xml")
        {
            guiMap = string.Concat(GuiMapPath, "ReportsTab.xml");
        }

        public HtmlControl ReportsTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabReports");
            }
        }

        public bool IsReportTabPresent
        {
            get
            {
                return IsPresent<HtmlControl>("tabReports");
            }
        }

        public HtmlControl ProductionEfficiencyTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabProductionEfficiency");
            }
        }

        public bool IsGroupByPresent
        {
            get
            {
                return IsPresent<HtmlSelect>("GroupBy");
            }
        }

        public HtmlControl ProductionDetailsLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProductionDetailsLink");
            }
        }

        public HtmlControl ChartErrorMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ChartErrorMessage");
            }
        }

        public HtmlControl RecordsErrorMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("RecordsErrorMessage");
            }
        }

        public HtmlControl ResourcesUtilizationTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabResourcesUtilization");
            }
        }

        public HtmlControl WashingProcessValidationTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabWashingProcessValidation");
            }
        }

        public HtmlControl ChemicalConsumptionLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ChemicalConsumptionLink");
            }
        }

        public HtmlControl ChemicalInventoryLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ChemicalInventoryLink");
            }
        }

        public HtmlControl OperationsSummaryLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("OperationsSummaryLink");
            }
        }

        public HtmlControl AlarmsSummaryLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AlarmsSummaryLink");
            }
        }

        public HtmlControl AlarmsDetailsLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AlarmsDetailsLink");
            }
        }

        public HtmlControl ResourcesRecordsErrorMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ResourcesRecordsErrorMessage");
            }
        }

        public HtmlControl EcolabInternalTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabEcolabInternal");
            }
        }

        public HtmlControl UserLogTableGrid
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UserLogTableGrid");
            }
        }

        public HtmlControl CurrentView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CurrentView");
            }
        }

        public HtmlControl PreviousView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PreviousView");
            }
        }

        public HtmlControl DayView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DayView");
            }
        }

        public HtmlControl WeekView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WeekView");
            }
        }

        public HtmlControl MonthView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MonthView");
            }
        }

        public HtmlControl QuarterView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("QuarterView");
            }
        }

        public HtmlControl YearView
        {
            get
            {
                return GetHtmlControl<HtmlControl>("YearView");
            }
        }
        public HtmlControl UserOptionSelection1
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UserOptionSelection1");
            }
        }
        public HtmlControl PPlantCustCategoryCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PPlantCustCategoryCentral");
            }
        }

        public HtmlControl SelectAll
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SelectAll");
            }
        }
        public HtmlControl InpDispenser
        {
            get
            {
                return GetHtmlControl<HtmlControl>("inpDispenser");
            }
        }
        public HtmlControl DrpDispenser
        {
            get
            {
                return GetHtmlControl<HtmlControl>("drpDispenser");
            }
        }
        public HtmlControl Chk3ULTRAX1kyle
        {
            get
            {
                return GetHtmlControl<HtmlControl>("chk3ULTRAX1kyle");
            }
        }

        public HtmlControl WPRBFormulaFormSegFilt
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPRBFormulaFormSegFilt");
            }
        }

        public HtmlControl WPPVHealthCareFilt
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPPVHealthCareFilt");
            }
        }


        public HtmlControl DateRange
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DateRange");
            }
        }

        public HtmlControl Standard
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Standard");
            }
        }

        public HtmlControl ProductionSummaryLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProductionSummaryLink");
            }
        }

        public HtmlControl Custom
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Custom");
            }
        }

        public HtmlControl CustomStartDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CustomStartDate");
            }
        }

        public HtmlControl NoDataErrorMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("NoDataErrorMessage");
            }
        }

        public HtmlControl PlantFilter
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PlantFilter");
            }
        }

        public HtmlControl CustomEndDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CustomEndDate");
            }
        }

        public HtmlControl PlantSelectAll
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PlantSelectAll");
            }
        }

        public HtmlSelect GroupBy
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("GroupBy");
            }
        }

        /// <summary>		
        /// Labour Cost Table Grid		
        /// </summary>		
        public CommonControls.EcolabDataGrid ReportsGridTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ReportsGrid");
            }
        }

        public CommonControls.EcolabDataGrid ReportsGrid
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ReportsTable");
            }
        }

        public HtmlControl DateRangelabel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DateRangelabel");
            }
        }

        public HtmlControl ProductionLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProductionLink");
            }
        }
        public HtmlControl SPProductionLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SPProductionLink");
            }
        }

        public HtmlControl PeriodProductionLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PeriodProductionLink");
            }
        }

        public HtmlControl EfficiencyWashingEquipmentLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EfficiencyWashingEquipmentLink");
            }
        }

        public HtmlControl RewashLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("RewashLink");
            }
        }

        public HtmlControl PSViewCategoryCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PSViewCategoryCentral");
            }
        }

        public CommonControls.EcolabDateTimePicker DayDateGrid
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "StartDateDay");
            }
        }
        public CommonControls.EcolabDateTimePicker MonthDateGrid
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "StartDateMonth");
            }
        }

        public CommonControls.EcolabDateTimePicker YearDateGrid
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "StartDateYear");
            }
        }

        public HtmlControl DateTimePickr
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DateTimePickr");

            }
        }

        public HtmlControl ReportsNext
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ReportsNext");
            }
        }

        public HtmlControl DateButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DateButton");
            }
        }


        public HtmlControl AddColumn
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnAddColumn");
            }
        }

        public HtmlControl ActEnergyCostCwt
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActEnergyCostCwt");
            }
        }

        public HtmlControl ActualWaterUsage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActualWaterUsage");
            }
        }
        public HtmlControl StandardWaterUsage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("StandardWaterUsage");
            }
        }
        public HtmlControl EnergyTargetCWT
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EnergyTargetCWT");
            }
        }

        public HtmlControl ReportNameBreadCrumb
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ReportNameBreadCrumb");
            }
        }

        public HtmlControl ViewCategory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ViewCategory");
            }
        }

        public HtmlControl TimeCategory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("TimeCategory");
            }
        }

        public HtmlControl PTimeCategoryCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PTimeCategoryCentral");
            }
        }

        public HtmlControl PLocationCategoryCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PLocationCategoryCentral");
            }
        }

        public HtmlControl FormulaSegment
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulaSegment");
            }
        }
        public HtmlControl RdoFormulaSegment
        {
            get
            {
                return GetHtmlControl<HtmlControl>("rdoFormulaSegment");
            }
        }

        public HtmlControl FormulaCategoryCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulaCategoryCentral");
            }
        }

        public HtmlControl RuntimeEfficiencyCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("RuntimeEfficiencyCentral");
            }
        }

        public HtmlControl ActualChemicalUsage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActualChemicalUsage");
            }
        }

        public HtmlSelect Plants
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlPlants");
            }
        }

        public HtmlSelect MachineGroup
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMachineGroup");
            }
        }

        public HtmlSelect Machine
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMachine");
            }
        }

        public HtmlControl EfficiencyByMachineLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EfficiencyByMachineLink");
            }
        }

        public HtmlControl MyServiceActionListLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MyServiceActionListLink");
            }
        }

        public HtmlControl ExcessRuntime
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ExcessRuntime");
            }
        }

        public HtmlControl PFormulaCategoryCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PFormulaCategoryCentral");
            }
        }

        public HtmlControl LocationCategory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("LocationCategory");
            }
        }


        public HtmlControl CategoryHeader
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CategoryHeader");
            }
        }

        public HtmlControl PSChartTypeCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PSChartTypeCentral");
            }
        }

        public HtmlControl Apply
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Apply");
            }
        }

        public HtmlControl PActualProductionCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PActualProductionCentral");
            }
        }

        public HtmlControl PStandardProductionCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PStandardProductionCentral");
            }
        }

        public HtmlControl PNumOfPiecesCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PNumOfPiecesCentral");
            }
        }

        public HtmlControl PStandardProduction
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PStandardProduction");
            }
        }

        public HtmlControl ProductionVariance
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProductionVariance");
            }
        }

        public HtmlControl AddColumnRewash
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AddColumnRewash");
            }
        }

        public HtmlControl LoadEfficiency
        {
            get
            {
                return GetHtmlControl<HtmlControl>("LoadEfficiency");
            }
        }



        public HtmlControl StartDateTimePickr
        {
            get
            {
                return GetHtmlControl<HtmlControl>("StartDateTimePickr");
            }
        }

        public HtmlControl EndDateTimePickr
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EndDateTimePickr");
            }
        }
        public HtmlControl ProductEfficiencyTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProductEfficiencyTab");
            }
        }

        public HtmlControl ReportsPrev
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ReportsPrevious");
            }
        }

        public HtmlControl Message1
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ReportsMessage");
            }
        }

        public HtmlControl NoRecords
        {
            get
            {
                return GetHtmlControl<HtmlControl>("NorecordsText");
            }
        }

        public HtmlControl Filter
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Filter");
            }
        }

        public HtmlControl ProdSummaryMachGroup
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProdSummaryMachGroup");
            }
        }

        public HtmlControl MachineGrpSelectAll
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MachineGrpSelectAll");
            }
        }

        public HtmlControl Braun675lb
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Braun675lb");
            }
        }

        public HtmlControl ApplyFilter
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ApplyFilter");
            }
        }

        public HtmlControl EffByMechFormCatCol
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EffByMechFormCatCol");
            }
        }
        public HtmlControl EffByMechAddCol
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EffByMechAddCol");
            }
        }
        public HtmlControl EffByMechFormCat
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EffByMechFormCat");
            }
        }
        public HtmlControl EffByMechFormCatFilt
        {
            get
            {
                return GetHtmlControl<HtmlControl>("EffByMechFormCatFilt");
            }
        }


        public HtmlControl CustomerCategory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Customercategory");
            }
        }

        public HtmlControl FormulaCategory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Formulacategory");
            }
        }

        public HtmlControl WashingprocessValidation
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WashingProcessValidation");
            }
        }
        public HtmlControl AlarmDetails
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AlarmDetails");
            }
        }
        public HtmlControl WasherNumber
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WasherNumber");
            }
        }
        public HtmlControl BatchNumber
        {
            get
            {
                return GetHtmlControl<HtmlControl>("BatchNumber");
            }
        }
        public HtmlControl PumpValveNumber
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PumpValveNumber");
            }
        }
        public HtmlControl ChemicalName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ChemicalName");
            }
        }
        public HtmlControl InjectionNumber
        {
            get
            {
                return GetHtmlControl<HtmlControl>("InjectionNumber");
            }
        }
        public HtmlControl FormulaNumber
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulaNumber");
            }
        }

        public HtmlControl AvgDailyNeedsLY
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AvgDailyNeedsLY");
            }
        }
        public HtmlControl AvgDailyNeedsforIP
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AvgDailyNeedsforIP");
            }
        }
        public HtmlControl AvgDailyCostYTD
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AvgDailyCostYTD");
            }
        }
        public HtmlControl AvgDailyCostloadYTD
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AvgDailyCostloadYTD");
            }
        }
        public HtmlControl Daybeforeoutofstock
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Daybeforeoutofstock");
            }
        }

        public HtmlControl TargetConsumption
        {
            get
            {
                return GetHtmlControl<HtmlControl>("TargetConsumption");
            }
        }

        public HtmlControl AverageConsumption
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AverageConsumption");
            }
        }
        public HtmlControl AverageDailyConsumption
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AverageDailyConsumption");
            }
        }

        public HtmlControl CostExcess
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CostExcess");
            }
        }
        public HtmlControl RunTimeEfficiency
        {
            get
            {
                return GetHtmlControl<HtmlControl>("RunTimeEfficiency");
            }
        }
        public HtmlControl StandardLoad
        {
            get
            {
                return GetHtmlControl<HtmlControl>("StandardLoad");
            }
        }

        public HtmlControl ActualProductionColumnAdd1
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActualProductionColumnAdd1");
            }
        }
        public HtmlControl DuplicateReportName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DuplicateReportName");
            }
        }
        public HtmlControl CancelButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CancelButton");
            }
        }

        public HtmlControl ActualProductionColumnAdd2
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActualProductionColumnAdd2");
            }
        }

        public HtmlControl PSFilterCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PSFilterCentral");
            }
        }
        public HtmlControl PSAddColumn
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PSAddColumn");
            }
        }
        public HtmlControl PSFilterMachineType
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PSFilterMachineType");
            }
        }

        public HtmlControl FinancialsTab
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FinancialsTab");
            }
        }

        public HtmlControl CostSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CostSummary");
            }
        }

        public HtmlControl R12
        {
            get
            {
                return GetHtmlControl<HtmlControl>("R12");
            }
        }

        public HtmlControl CustomContainer
        {
            get
            {
                return GetHtmlControl<HtmlControl>("customContainer");
            }
        }

        public HtmlControl StandardContainer
        {
            get
            {
                return GetHtmlControl<HtmlControl>("standardContainer");
            }
        }

        public HtmlControl AddMoreFilters
        {
            get
            {
                return GetHtmlControl<HtmlControl>("btnAddMoreFilters");
            }
        }

        public HtmlControl DrpFormulaSegment
        {
            get
            {
                return GetHtmlControl<HtmlControl>("drpFormulaSegment");
            }
        }

        public HtmlControl FormulaSegmentItem
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FormulaSegmentItem");
            }
        }

        public HtmlControl NoOfLoads
        {
            get
            {
                return GetHtmlControl<HtmlControl>("inpNoOfLoads");
            }
        }

        public HtmlControl ExcessChemicalCost
        {
            get
            {
                return GetHtmlControl<HtmlControl>("inpExcessChemicalCost");
            }
        }

        public HtmlControl ExcessTotalCost
        {
            get
            {
                return GetHtmlControl<HtmlControl>("inpExcessTotalCost");
            }
        }

        public HtmlControl StandardConsumption
        {
            get
            {
                return GetHtmlControl<HtmlControl>("StandardConsumption");
            }
        }

        public HtmlControl Meters
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Meters");
            }
        }

        public HtmlSelect DdlPlants
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlPlants");
            }
        }

        public HtmlSelect DdlMeterType
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMeterType");
            }
        }

        public HtmlSelect DdlMeter
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("ddlMeter");
            }
        }

        public HtmlControl WPADCustDateRangeLbl
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPADCustDateRangeLbl");
            }
        }

        public HtmlControl WPADAddFiltDisp
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPADAddFiltDisp");
            }
        }

        public HtmlControl WPADColWash
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPADColWash");
            }
        }

        public HtmlControl WPADColDV
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPADColDV");
            }
        }

        public HtmlControl WPADColForm
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPADColForm");
            }
        }

        public HtmlControl WPADColStatus
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPADColStatus");
            }
        }

        public HtmlControl CRViewCategory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CRTimeCategory");
            }
        }

        public HtmlControl BreadCrumb
        {
            get
            {
                return GetHtmlControl<HtmlControl>("breadCrumb");
            }
        }

        public CommonControls.EcolabDateTimePicker WPADCustStartDatDay
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "WPADCustStartDatDay");
            }
        }

        public CommonControls.EcolabDateTimePicker WPADCustStartDatMonth
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "WPADCustStartDatMonth");
            }
        }

        public CommonControls.EcolabDateTimePicker WPADCustStartDatYear
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "WPADCustStartDatYear");
            }
        }

        public CommonControls.EcolabDateTimePicker WPADCustEndDatDay
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "WPADCustEndDatDay");
            }
        }

        public CommonControls.EcolabDateTimePicker WPADCustEndDatMonth
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "WPADCustEndDatMonth");
            }
        }

        public CommonControls.EcolabDateTimePicker WPADCustEndDatYear
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "WPADCustEndDatYear");
            }
        }

        public HtmlControl ProcessValRedFlagLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProcessValRedFlagLink");
            }
        }

        public HtmlControl PVRejectedBatchesReportsGrid
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PVRejectedBatchesReportsGrid");
            }
        }

        public HtmlControl CRFormulaCategory
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CRFormulaCategory");
            }
        }

        public HtmlControl ProcessValRejectedBatchesLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProcessValRejectedBatchesLink");
            }
        }

        public HtmlControl ProcessValidationDetails
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabProcessValidationDetails");
            }
        }

        public HtmlControl WPPVFiltMachineType
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPPVFiltMachineType");
            }
        }

        public HtmlSelect Batch
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("cboBatch");
            }
        }

        public bool IsBatchDetailsPresent
        {
            get
            {
                return IsPresent<HtmlControl>("BatchDetailsTable");
            }
        }

        public bool IsBatchInjectionPresent
        {
            get
            {
                return IsPresent<HtmlControl>("BatchInjectionTable");
            }
        }

        public bool IsBatchWashPresent
        {
            get
            {
                return IsPresent<HtmlControl>("BatchWashTable");
            }
        }

        public HtmlControl SelectMachine
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SelectMachine");
            }
        }

        public HtmlControl PVDetailsDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PVDetailsDate");
            }
        }

        public CommonControls.EcolabDateTimePicker PVDDay
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "PVDDay");
            }
        }

        public CommonControls.EcolabDateTimePicker PVDeMonth
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "PVDeMonth");
            }
        }

        public CommonControls.EcolabDateTimePicker PVDYear
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "PVDYear");
            }
        }

        public HtmlControl ProcessValSummaryLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ProcessValSummaryLink");
            }
        }

        public HtmlControl WPPVSFiltMachines
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPPVSFiltMachines");
            }
        }

        public HtmlControl WPPVSFilSelectAll
        {
            get
            {
                return GetHtmlControl<HtmlControl>("WPPVSFilSelectAll");
            }
        }

        public HtmlControl PVSummaryDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PVSummaryDate");
            }
        }

        public CommonControls.EcolabDateTimePicker ProcValSumDay
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "ProcValSumDay");
            }
        }

        public CommonControls.EcolabDateTimePicker ProcValSumMonth
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "ProcValSumMonth");
            }
        }

        public CommonControls.EcolabDateTimePicker ProcValSumYear
        {
            get
            {
                return new CommonControls.EcolabDateTimePicker(Telerik, guiMap, "ProcValSumYear");
            }
        }

        public HtmlControl ReportsTabCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabReportsCentral");
            }
        }

        public HtmlControl EcolabInternalTabCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("tabEcolabInternalCentral");
            }
        }

        public HtmlControl AccountSummary
        {
            get
            {
                return GetHtmlControl<HtmlControl>("accountSummary");
            }
        }

        public HtmlControl AddToFavourite
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AddToFavourite");
            }
        }

        public HtmlControl SaveReportAsFavorite
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SaveReportAsFavorite");
            }
        }

        public HtmlControl ReportName
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ReportName");
            }
        }

        public HtmlSelect AutoMaticallyGenerated
        {
            get
            {
                return GetHtmlControl<HtmlSelect>("AutoMaticallyGenerated");
            }
        }

        public HtmlControl SaveButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SaveButton");
            }
        }

        public HtmlControl Favourite
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Favourite");
            }
        }

        public HtmlControl FavouriteMenu
        {
            get
            {
                return GetHtmlControl<HtmlControl>("FavouriteMenu");
            }
        }

        public HtmlControl DownloadExcel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DownloadExcel");
            }
        }

        public HtmlControl DownloadPDF
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DownloadPDF");
            }
        }

        public HtmlControl YesButton
        {
            get
            {
                return GetHtmlControl<HtmlControl>("YesButton");
            }
        }

        public HtmlControl FFEvaluation
        {
            get
            {
                return GetHtmlControl<HtmlControl>("fFEvaluation");
            }
        }

        public HtmlControl CustomFromDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CustomFromDate");
            }
        }

        public HtmlControl CustomToDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CustomToDate");
            }
        }

        public HtmlControl PlantSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PlantSelection");
            }
        }

        public HtmlControl PlantOptionSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("PlantOptionSelection");
            }
        }

        public HtmlControl ActualChemicalCost
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActualChemicalCost");
            }
        }

        public HtmlControl StandardChemicalCost
        {
            get
            {
                return GetHtmlControl<HtmlControl>("StandardChemicalCost");
            }
        }

        public HtmlControl ExcessCost
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ExcessCost");
            }
        }

        public HtmlControl ActualUsage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActualUsage");
            }
        }

        public HtmlControl StandardUsage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("StandardUsage");
            }
        }

        public HtmlControl MachineTypeSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MachineTypeSelection");
            }
        }

        public HtmlControl MachineTypeSelectAll
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MachineTypeSelectAll");
            }
        }

        public HtmlControl MachineTypeOptionSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MachineTypeOptionSelection");
            }
        }

        public HtmlControl MachineHoldTime
        {
            get
            {
                return GetHtmlControl<HtmlControl>("machineHoldTime");
            }
        }

        public HtmlControl ServicePreparation
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ServicePreparation");
            }
        }

        public HtmlControl ReportPanel
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ReportPanel");
            }
        }

        public HtmlControl SummaryLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("SummaryLink");
            }
        }

        public CommonControls.EcolabDataGrid SummaryTable1
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "SummaryTable1");
            }
        }

        public CommonControls.EcolabDataGrid SummaryTable2
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "SummaryTable2");
            }
        }

        public CommonControls.EcolabDataGrid ProductionTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ProductionTable");
            }
        }

        public HtmlControl MachinesUtilitiesLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("MachinesUtilitiesLink");
            }
        }

        public CommonControls.EcolabDataGrid MachinesUtilitiesTable1
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "MachinesUtilitiesTable1");
            }
        }

        public CommonControls.EcolabDataGrid MachinesUtilitiesTable2
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "MachinesUtilitiesTable2");
            }
        }

        public HtmlControl ChemicalConsumpLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ChemicalConsumpLink");
            }
        }

        public CommonControls.EcolabDataGrid ChemicalConsumptionTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "ChemicalConsumptionTable");
            }
        }

        public HtmlControl AlarmRedFlagLink
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AlarmRedFlagLink");
            }
        }

        public CommonControls.EcolabDataGrid AlarmRedFlagTable1
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "AlarmRedFlagTable1");
            }
        }

        public CommonControls.EcolabDataGrid AlarmRedFlagTable2
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "AlarmRedFlagTable2");
            }
        }

        public HtmlControl UserSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UserSelection");
            }
        }

        public HtmlControl UserSelectAll
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UserSelectAll");
            }
        }
        public HtmlControl UserList
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UserList");
            }
        }

        public HtmlControl UserOptionSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("UserOptionSelection");
            }
        }

        public HtmlControl ActionSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActionSelection");
            }
        }

        public HtmlControl ActionSelectAll
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActionSelectAll");
            }
        }

        public HtmlControl CentralActionOptionSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("CentralActionOptionSelection");
            }
        }
        public HtmlControl ActionOptionSelection
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ActionOptionSelection");
            }
        }
        public HtmlControl UserLogCentral
        {
            get
            {
                return GetHtmlControl<HtmlControl>("userLogCentral");
            }
        }

        public HtmlControl WashingProgramsDetails
        {
            get
            {
                return GetHtmlControl<HtmlControl>("washingProgramsDetails");
            }
        }

        public void DateSelection(DateTime startDate, object day, object month, object year, int DateTimePicker)
        {
            if (DateTimePicker == 1)
            {
                StartDateTimePickr.Click();
            }
            else
            {
                EndDateTimePickr.Click();
            }
            ((EcolabDateTimePicker)day).SelectButton.Click();
            ((EcolabDateTimePicker)month).SelectButton.Click();
            ((EcolabDateTimePicker)year).Selectyear(startDate.ToString("yyyy"));
            ((EcolabDateTimePicker)month).SelectMonth(startDate.ToString("MMM"));
            ((EcolabDateTimePicker)day).SelectDay(startDate.ToString("dd"));
        }

        public void GroupBySelection(DateTime startDate, DateTime endDate)
        {
            TimeSpan dateDiff = endDate - startDate;

            if ((dateDiff.TotalDays <= 7 && dateDiff.TotalDays >= 0))
            {
                if (GroupBy.SelectedOption.Text != "Day")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }
            }
            else if ((dateDiff.TotalDays <= 30 && dateDiff.TotalDays >= 8))
            {
                if (GroupBy.SelectedOption.Text != "Week")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }
            }
            else if ((dateDiff.TotalDays <= 90 && dateDiff.TotalDays >= 31))
            {
                if (GroupBy.SelectedOption.Text != "Month")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }
            }
            else if (dateDiff.TotalDays >= 91)
            {
                if (GroupBy.SelectedOption.Text != "Quarter")
                {
                    Assert.Fail("Wrong Selection in Group By ");
                }
            }
        }

        public CommonControls.EcolabDataGrid BatchDetailsTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "BatchDetailsTable");
            }
        }
        public CommonControls.EcolabDataGrid BatchWashTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "BatchWashTable");
            }
        }

        public CommonControls.EcolabDataGrid BatchInjectionTable
        {
            get
            {
                return new CommonControls.EcolabDataGrid(Telerik, guiMap, "BatchInjectionTable");
            }
        }
        public HtmlControl DefaultFilters
        {
            get
            {
                return GetHtmlControl<HtmlControl>("DefaultFilters");
            }
        }
        public HtmlControl AddMoreFilterOptions
        {
            get
            {
                return GetHtmlControl<HtmlControl>("AddMoreFilterOptions");
            }
        }

        public bool IsAddMoreFilterPresent
        {
            get
            {
                return IsPresent<HtmlControl>("btnAddMoreFilters");
            }
        }

        public bool IsLoadMessagePresent
        {
            get
            {
                return IsPresent<HtmlControl>("LoadingMessage");
            }
        }


        public HtmlControl HelpMenu
        {
            get
            {
                return GetHtmlControl<HtmlControl>("Help");
            }
        }
        public HtmlControl HelpMenuHome
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpHome");
            }
        }
        public HtmlControl HelpMenuDashboard
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpMenuDashboard");
            }
        }
        public HtmlControl HelpMenuDashbordContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HelpMenuDashbordContent");
            }
        }
        public HtmlControl HomeContent
        {
            get
            {
                return GetHtmlControl<HtmlControl>("HomeContent");
            }
        }
        public HtmlControl ReportTitle
        {
            get
            {
                return GetHtmlControl<HtmlControl>("ReportTitle");
            }
        }

        public HtmlControl TxtBatchDate
        {
            get
            {
                return GetHtmlControl<HtmlControl>("txtBatchDate");
            }
        }

        public HtmlControl LoadingMessage
        {
            get
            {
                return GetHtmlControl<HtmlControl>("LoadingMessage");
            }
        }

        public bool DefaultFiltersVerification(List<string> psFilters)
        {
            List<string> lsPSFilters = new List<string>();
            ReadOnlyCollection<Element> defaultFilt = DefaultFilters.ChildNodes;
            ReadOnlyCollection<Element> moreFilters = AddMoreFilterOptions.ChildNodes;
            foreach (Element i in defaultFilt)
            {
                lsPSFilters.Add(i.ChildNodes[0].ChildNodes[0].ChildNodes[0].Content);
            }
            AddMoreFilters.Click();
            foreach (Element i in moreFilters)
            {
                lsPSFilters.Add(i.ChildNodes[0].ChildNodes[0].Attributes[2].Value);
            }
            bool b = new HashSet<string>(lsPSFilters).SetEquals(psFilters);
            return new HashSet<string>(lsPSFilters).SetEquals(psFilters); ;
        }
        public bool CentralDefaultFiltersVerification(List<string> psFilters)
        {
            List<string> lsPSFilters = new List<string>();
            ReadOnlyCollection<Element> defaultFilt = DefaultFilters.ChildNodes;
            foreach (Element i in defaultFilt)
            {
                lsPSFilters.Add(i.ChildNodes[0].ChildNodes[0].ChildNodes[0].Content);
            }
            if (IsAddMoreFilterPresent)
            {
                ReadOnlyCollection<Element> moreFilters = AddMoreFilterOptions.ChildNodes;
                AddMoreFilters.Click();
                foreach (Element i in moreFilters)
                {
                    lsPSFilters.Add(i.ChildNodes[0].Attributes[2].Value);
                }
            }
            return new HashSet<string>(lsPSFilters).SetEquals(psFilters); ;
        }

        public void VerifyGrid()
        {
            string message = ReportsGridTable.GetReportRows()[1].BaseElement.InnerText;
            if (ReportsGridTable.GetReportRows().Count >= 2 && !message.ToLower().Contains("No Records"))
            {
                Assert.IsTrue(true);
            }
            else if (message.ToLower().Contains("no records"))
            {
                Assert.IsTrue(true, "No Data Displayed for selected dates");
            }
            else
                Assert.Fail("Error occurred without data");
        }



        public void VerifyHeader(List<string> headers)
        {
            string HeaderRows = ReportsGridTable.MainTable.AllRows[0].BaseElement.InnerText;
            foreach (string s in headers)
            {
                if (!HeaderRows.Contains(s))
                {
                    Assert.Fail(s + " header not found");
                }
            }
        }

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        static extern int SHGetKnownFolderPath([MarshalAs(UnmanagedType.LPStruct)] Guid rfid, uint dwFlags, IntPtr hToken, out string pszPath);
        public static class KnownFolder
        {
            public static readonly Guid Downloads = new Guid("374DE290-123F-4565-9164-39C4925E467B");
        }

        public void AddToFavourites(string reportName, string methodName)
        {
            Runner.DoStep("Click on Add to Favourite icon", methodName, () =>
            {
                AddToFavourite.Click();
                if (!SaveReportAsFavorite.IsEnabled)
                {
                    Assert.Fail(reportName + "Save Report pop up is not opened");
                }
            });
            Runner.DoStep("Enter details and Click on Save button to Add to Favourites", methodName, () =>
            {
                ReportName.SetText(reportName);
                AutoMaticallyGenerated.SelectByText("Daily");
                SaveButton.Click();
            });
            if (DuplicateReportName.GetStyleValue("display") != "none")
            {
                CancelButton.Click();
                Assert.Pass(reportName + "Report Name is already exist");
            }


            Favourite.ScrollToVisible();
            Favourite.DeskTopMouseClick();
            Utility utility = new Utility();
            List<HtmlControl> list = utility.GetHtmlControls(FavouriteMenu, reportName);
            Runner.DoStep("Verifying the added report in Favourites tab", methodName, () =>
            {
                if (list.Count == 0)
                {
                    Assert.Fail(reportName + "Report is not added to Favourite List");
                }
            });
            list[0].Click();
            if (AddToFavourite.IsVisible())
            {
                Assert.Fail("Add to Favourite icon is displaying for Saved Report");
            }

        }
        public void RemoveFromFavourite(string ReportName, string methodName)
        {
            Runner.DoStep("Verifying Remove From Favourite functionality", methodName, () =>
            {
                Favourite.DeskTopMouseClick();

                Utility utility = new Utility();
                List<HtmlControl> list = utility.GetHtmlControls(FavouriteMenu, ReportName);

                if (list.Count > 1)
                {
                    Runner.DoStep("Click on Delete icon for the report in Favourites list", methodName, () =>
                 {
                     // list[1].ScrollToVisible();
                     list[1].Click();
                 });
                    Thread.Sleep(1000);

                    Runner.DoStep("Click on Delete icon for the report in Favourites list", methodName, () =>
                    {
                        YesButton.Click();
                    });

                    Thread.Sleep(1000);
                    Favourite.DeskTopMouseClick();
                    List<HtmlControl> list1 = utility.GetHtmlControls(FavouriteMenu, ReportName);
                    Runner.DoStep("Verifying whether the report is deleted or not from Favourite list", methodName, () =>
                     {
                         if (list1.Count != 0)
                         {
                             Assert.Fail(ReportName + "Report is not deleted");
                         }
                     });
                }
                else
                {
                    Assert.IsTrue(true, ReportName + "Report is not exist in the Favourite List");
                }

            });
        }
        public void ExcelVerify(string fileName, string methodName)
        {
            Runner.DoStep("Verifying Export to excel functionality", methodName, () =>
            {
                string downloads;
                SHGetKnownFolderPath(KnownFolder.Downloads, 0, IntPtr.Zero, out downloads);
                string filepath = downloads + "\\";

                if (File.Exists(filepath + fileName + ".xlsx"))
                {
                    Assert.IsTrue(true, "File downloaded successfully");
                }
                else
                {
                    Assert.Fail("Unable to Export the file to Excel");
                }
            });
        }
        public void PDFVerify(string fileName, string methodName)
        {
            Runner.DoStep("Verifying Export to PDF functionality", methodName, () =>
            {
                string downloads;
                SHGetKnownFolderPath(KnownFolder.Downloads, 0, IntPtr.Zero, out downloads);
                string filepath = downloads + "\\";

                if (File.Exists(filepath + fileName + ".pdf"))
                {
                    Assert.IsTrue(true, "File downloaded successfully");
                }
                else
                {
                    Assert.Fail("Unable to Export the file to PDF");
                }
            });
        }
    }
}
