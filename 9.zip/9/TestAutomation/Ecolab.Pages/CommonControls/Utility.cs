﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ecolab.Pages.CommonControls
{
    public class Utility : HtmlControl
    {
        public List<HtmlControl> GetHtmlControls(HtmlControl ctrl, string desc)
        {
            List<Element> childnodes = ctrl.ChildNodes.ToList();
            List<HtmlControl> htmlControls = new List<HtmlControl>();
            foreach (Element item in childnodes)
            {
                string reportName = item.ChildNodes[0].TextContent;
                if (reportName == desc)
                {
                    htmlControls.Add(new HtmlControl(item.ChildNodes[0]));
                    htmlControls.Add(new HtmlControl(item.ChildNodes[1]));
                }
            }
            return htmlControls;
        }
    }
}
