﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.ObjectModel;
using System.Threading;
using System.Text.RegularExpressions;


namespace Ecolab.Pages.CommonControls
{
    public class EcolabDateTimePicker : HtmlTable
    {
        private Ecolab.TelerikPlugin.TelerikFramework telerikFramework;

        private string strLogicalName = string.Empty;

        private string myguiMap;

        public EcolabDateTimePicker(HtmlTable gridelement)
            : base(gridelement.BaseElement) { }

        /// <summary>
        /// EcolabDataGrid
        /// </summary>
        /// <param name="telerik"></param>
        /// <param name="guiMapPath"></param>
        public EcolabDateTimePicker(Ecolab.TelerikPlugin.TelerikFramework telerik, string guiMapPath)
        {
            telerikFramework = telerik;
            myguiMap = guiMapPath;
        }

        public EcolabDateTimePicker(Ecolab.TelerikPlugin.TelerikFramework telerik, string guiMapPath, string logicalName)
            : this(telerik, guiMapPath)
        {
            telerikFramework = telerik;
            strLogicalName = logicalName;
            myguiMap = string.Concat(guiMapPath);
        }

        /// MainTable
        /// </summary>
        private HtmlTable BaseTable
        {
            get
            {
                return telerikFramework.WaitForControl<HtmlTable>(myguiMap, strLogicalName, Config.PageClassSettings.Default.MaxTimeoutValue);
            }
        }

        private ReadOnlyCollection<Element> HeaderControls
        {
            get
            {
                return BaseTable.HeadRows.FirstOrDefault().ChildNodes;
            }
        }

        private List<HtmlControl> Years
        {
            get
            {
                List<HtmlControl> years = new List<HtmlControl>();
                ReadOnlyCollection<Element> yearRows = BaseTable.ChildNodes[1].ChildNodes[0].ChildNodes;

                foreach (Element yearRow in yearRows)
                {
                    foreach (Element year in yearRow.ChildNodes)
                    {
                        if (year.GetAttribute("class").Value.Equals("year") || year.GetAttribute("class").Value.Equals("year active"))
                        {
                            years.Add(new HtmlControl(year));
                        }
                    }
                }
                return years;
            }
        }


        private List<HtmlControl> Dates
        {
            get
            {
                ReadOnlyCollection<HtmlTableRow> dateRows = BaseTable.BodyRows;
                List<HtmlControl> dates = new List<HtmlControl>();
                foreach (HtmlTableRow dateRow in dateRows)
                {
                    foreach (Element date in dateRow.ChildNodes)
                    {
                        if (date.GetAttribute("class").Value.Equals("day") || date.GetAttribute("class").Value.Equals("day active"))
                        {
                            dates.Add(new HtmlControl(date));
                        }
                    }
                }
                return dates;
            }
        }
        private List<HtmlControl> Months
        {
            get
            {
                List<HtmlControl> months = new List<HtmlControl>();
                ReadOnlyCollection<Element> monthRows = BaseTable.ChildNodes[1].ChildNodes[0].ChildNodes;
                foreach (Element monthRow in monthRows)
                {
                    foreach (Element month in monthRow.ChildNodes)
                    {
                        if (month.GetAttribute("class").Value.Equals("month") || month.GetAttribute("class").Value.Equals("month active"))
                        {
                            months.Add(new HtmlControl(month));
                        }
                    }
                }
                return months;
            }
        }


        public HtmlControl PrevMonthButton
        {
            get
            {
                return new HtmlControl(HeaderControls.FirstOrDefault());
            }
        }

        public HtmlControl NextMonthButton
        {
            get
            {
                return new HtmlControl(HeaderControls.LastOrDefault());
            }
        }

        public HtmlControl SelectButton
        {
            get
            {
                return new HtmlControl(HeaderControls[1]);
            }
        }

        public string MonthAndYear
        {
            get
            {
                var test = HeaderControls[1].InnerText;
                return HeaderControls[1].InnerText;
            }
        }

        public string TodayDate
        {
            get
            {
                return Dates.Where(date => date.BaseElement.GetAttribute("class").Value.Contains("today")).FirstOrDefault().BaseElement.InnerText;
            }
        }

        public string SelectedDate
        {
            get
            {
                return Dates.Where(date => date.BaseElement.GetAttribute("class").Value.Contains("active")).FirstOrDefault().BaseElement.InnerText;
            }
        }

        public void SelectDay(string date)
        {
            //string a = MonthAndYear;
            //while (!MonthAndYear.Equals(monthYearText) && !MonthAndYear.ToLower().Contains("december"))
            //{
            //    Thread.Sleep(2000);
            //    NextMonthButton.DeskTopMouseClick();
            //}

            //while (!MonthAndYear.Equals(monthYearText) && !MonthAndYear.ToLower().Contains("january"))
            //{
            //    Thread.Sleep(2000);
            //    PrevMonthButton.DeskTopMouseClick();
            //}

            HtmlControl dateToBeSelected = Dates.Where(selectdate => selectdate.BaseElement.InnerText.Equals(date)).FirstOrDefault();

            dateToBeSelected.DeskTopMouseClick();
        }        

        public void SelectDay(string monthYearText, string date, HtmlControl NextMonthButton1, HtmlControl PrePrevMonthButton1, string MonthAndyear1)
        {
            //string year = MonthAndYear.Substring(Math.Max(0, MonthAndYear.Length - 4));

            while (!MonthAndyear1.Equals(monthYearText) && !MonthAndyear1.ToLower().Contains("january"))
            {
                Thread.Sleep(2000);
                //PrevMonthButton.DeskTopMouseClick();
                PrePrevMonthButton1.DeskTopMouseClick();
            }

            while (!MonthAndyear1.Equals(monthYearText) && !MonthAndyear1.ToLower().Contains("december"))
            {
                Thread.Sleep(2000);
                //NextMonthButton.DeskTopMouseClick();               
                NextMonthButton1.DeskTopMouseClick();
            }

            HtmlControl dateToBeSelected = Dates.Where(selectdate => selectdate.BaseElement.InnerText.Equals(date)).FirstOrDefault();
            dateToBeSelected.MouseClick();
        }

        public void Selectyear(string year)
        {
            if (Convert.ToInt32(year) < 2009)
            {
                PrevMonthButton.Click();

            }
            else if (Convert.ToInt32(year) > 2020)
            {

                NextMonthButton.Click();
            }
            HtmlControl yearToBeSelected = Years.Where(selectdate => selectdate.BaseElement.InnerText.Equals(year)).FirstOrDefault();
            yearToBeSelected.Click();

        }


        public void SelectMonth(string month)
        {
            HtmlControl monthToBeSelected = Months.Where(selectdate => selectdate.BaseElement.InnerText.Equals(month)).FirstOrDefault();
            monthToBeSelected.Click();
        }
    }
}