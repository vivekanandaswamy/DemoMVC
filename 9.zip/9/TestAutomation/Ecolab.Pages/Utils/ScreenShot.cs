﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AuScGen.TestExecutionUtil;
using System.Diagnostics;
using System.Reflection;
using System.IO;
using Ecolab.TelerikPlugin;
using System.Drawing;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.Xml;

namespace Ecolab.Pages.Utils
{
    public class ScreenShot : IScreenPrint
    {
        private TelerikPlugin.TelerikFramework telerik;
        private string folderPath;
        private string declaringType;
        private string methodName;
        private MethodBase MethodBase
        {
            get
            {
                StackTrace stackTrace = new StackTrace();
                return stackTrace.GetFrame(5).GetMethod();
            }
        }

        public string LogFolder
        {
            get
            {
                declaringType = MethodBase.DeclaringType.ToString();
                methodName = MethodBase.Name;
                string screenShotFolder = string.Format(@"{0}\{1}.{2}", folderPath, declaringType, methodName);
                CreateDirectory(screenShotFolder);
                Console.WriteLine(MethodBase.Name); // e.g.
                return screenShotFolder;
            }
        }

        public ScreenShot(TelerikPlugin.TelerikFramework telerikFw, string folder)
        {
            telerik = telerikFw;
            folderPath = folder;
        }

        public void ScreenPrint()
        {
            //telerik.ActiveBrowser.Capture().Save(string.Format(@"{0}\{1}_{2}.png", LogFolder, methodName, index.ToString()));
            //telerik.ActiveBrowser.Capture().Save(string.Format(@"{0}\{1}_{2}.png", LogFolder, methodName, Guid.NewGuid()));
            GetScreenPrint();
        }

        public void ScreenPrint(string message)
        {
            GetScreenPrint();
            SaveStepMessage(GetStepMessage(message));
        }


        public void ScreenPrint(string message, string method)
        {
            GetScreenPrint(method);
            SaveStepMessage(GetStepMessage(message),method);
        }

        private void CreateDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        private void GetScreenPrint()
        {
            using (Bitmap bmpScreenCapture = new Bitmap(Screen.PrimaryScreen.Bounds.Width,
                                            Screen.PrimaryScreen.Bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bmpScreenCapture))
                {
                    g.CopyFromScreen(Screen.PrimaryScreen.Bounds.X,
                                     Screen.PrimaryScreen.Bounds.Y,
                                     0, 0,
                                     bmpScreenCapture.Size,
                                     CopyPixelOperation.SourceCopy);
                }

                bmpScreenCapture.Save(string.Format(@"{0}\{1}_{2}.png", LogFolder, methodName, Guid.NewGuid()));
            }
        }

        private void GetScreenPrint(string method)
        {
            using (Bitmap bmpScreenCapture = new Bitmap(Screen.PrimaryScreen.Bounds.Width,
                                            Screen.PrimaryScreen.Bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bmpScreenCapture))
                {
                    g.CopyFromScreen(Screen.PrimaryScreen.Bounds.X,
                                     Screen.PrimaryScreen.Bounds.Y,
                                     0, 0,
                                     bmpScreenCapture.Size,
                                     CopyPixelOperation.SourceCopy);
                }
              
                //declaringType = method.Substring(0, method.Length - 2);
                string screenShotFolder = string.Format(@"{0}\{1}", folderPath, method);
                CreateDirectory(screenShotFolder);
                string[] array=  method.Split('.');
                 string methodName = array[array.Length - 1];
               // string split = methodName.Split('.');

                string location = string.Format(@"{0}\{1}_{2}.png", screenShotFolder, methodName, Guid.NewGuid());

                bmpScreenCapture.Save(location); 
            }
        }

        private void SaveStepMessage(StepMessage message)
        {
            //XmlSerializer ser = new XmlSerializer(typeof(StepMessage));
            //bool bAppend = true ;

            //TextWriter writer = new StreamWriter(string.Format(@"{0}\message.xml",LogFolder), bAppend);

            //ser.Serialize(writer, message);

            //writer.Close();   
            //string sb = string.Format("{1}", message.Message);
            if (!File.Exists(string.Format(@"{0}\message.csv", LogFolder)))
            {
                StreamWriter w = File.CreateText(string.Format(@"{0}\message.csv", LogFolder));
                w.WriteLine(message.Message);
                w.Close();
            }
            else
            {
                StreamWriter w = File.AppendText(string.Format(@"{0}\message.csv", LogFolder));
                w.WriteLine(message.Message);
                w.Close();
            }
        }

        private void SaveStepMessage(StepMessage message ,string method)
        {
            //XmlSerializer ser = new XmlSerializer(typeof(StepMessage));
            //bool bAppend = true ;

            //TextWriter writer = new StreamWriter(string.Format(@"{0}\message.xml",LogFolder), bAppend);

            //ser.Serialize(writer, message);

            //writer.Close();   
            //string sb = string.Format("{1}", message.Message);

         //   declaringType = method.Substring(0, method.Length - 2);
            string Folder = string.Format(@"{0}\{1}", folderPath, method);


            if (!File.Exists(string.Format(@"{0}\message.csv", Folder)))
            {
                StreamWriter w = File.CreateText(string.Format(@"{0}\message.csv", Folder));
                w.WriteLine(message.Message);
                w.Close();
            }
            else
            {
                StreamWriter w = File.AppendText(string.Format(@"{0}\message.csv", Folder));
                w.WriteLine(message.Message);
                w.Close();
            }
        }

        private StepMessage GetStepMessage(string messagetext)
        {
            StepMessage message = new StepMessage();
            message.StepNumber = 1;
            message.StepName = string.Format("Step:{0}", message.StepNumber);
            message.Message = messagetext;
            return message;
        }
    }
}