﻿using ArtOfTest.WebAii.Controls.HtmlControls;
using Ecolab.TelerikPlugin;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ecolab.Pages.Utils
{
    public class Actions
    {
        TelerikFramework telerikFw;
        PageBase controlPage;
        
        
        public Actions(TelerikFramework telerik, PageBase page)
        {
            telerikFw = telerik;
            controlPage = page;
        }

        public void PerformClickOnAllControls(string queryString, Action inBetweenAction)
        {
            telerikFw.ActiveBrowser.RefreshDomTree();
            ReadOnlyCollection<HtmlControl> allDeleteButtons;
            allDeleteButtons =  controlPage.WaitforAction<ReadOnlyCollection<HtmlControl>>(() =>
            {
                return telerikFw.Find.AllByXPath<HtmlControl>(queryString);
            }, Config.PageClassSettings.Default.MaxTimeoutValue);

            while (null != allDeleteButtons && allDeleteButtons.Count > 0)
            {
                allDeleteButtons.FirstOrDefault().Click();
                inBetweenAction();

                allDeleteButtons = controlPage.WaitforAction<ReadOnlyCollection<HtmlControl>>(() =>
                {
                    return telerikFw.Find.AllByXPath<HtmlControl>(queryString);
                }, Config.PageClassSettings.Default.MaxTimeoutValue); 
            }    
        }
    }
}
