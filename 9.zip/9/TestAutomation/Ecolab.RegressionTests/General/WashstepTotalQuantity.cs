﻿using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class WashstepTotalQuantity : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);            
        }

        static string testData = TestDataPath + Excel.ExcelName;
        
        [TestCategory(TestType.regression, "TC01_VerifyTotalQuantity")]
        [Test]
        public void TC01_VerifyTotalQuantity()
        {
            string dispenser = null;
            string washerGroup = null;
            string washer = null;
            string wGType = null;
            int formulaNumber = 0;
            int stepNumber1 = 0;
            int stepNumber2 = 0;
            int stepNumber3 = 0;
            int dispenserNumber = 0;
            int calibration = 0;
            int productNumber = 0;
            int quantity = 0;

            DataTable dt = Excel.DataRead(testData, "WashstepTotalQuantity");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == MethodBase.GetCurrentMethod().Name)
                {
                    dispenser = row["Dispenser"].ToString();
                    washerGroup = row["Washer Group"].ToString();
                    washer = row["Washer"].ToString();
                    wGType = row["WG Type"].ToString();
                    formulaNumber = Convert.ToInt32(row["Formula Number"].ToString());
                    stepNumber1 = Convert.ToInt32(row["Step Number 1"].ToString());
                    stepNumber2 = Convert.ToInt32(row["Step Number 2"].ToString());
                    stepNumber3 = Convert.ToInt32(row["Step Number 3"].ToString());
                    dispenserNumber = Convert.ToInt32(row["Dispenser Number"].ToString());
                    calibration = Convert.ToInt32(row["Calibration"].ToString());
                    productNumber = Convert.ToInt32(row["Product number"].ToString());
                    quantity = Convert.ToInt32(row["Quantity"].ToString());                    
                    break;
                }
            }

            int controllerId = AppState.GetState<ControllerState>().CreateABUltrax(dispenser);  
            WasherGroup group = AppState.GetState<WasherState>().CreateWasherGroup(wGType, washerGroup);
            AppState.GetState<WasherState>().CreateConventionalWasher(group.Id, group.Id, washer, controllerId, dispenserNumber);

            WasherProgramSetup setup1 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(formulaNumber, group);

            AppState.GetState<WasherState>().AddWashStep(setup1, stepNumber1);
            AppState.GetState<WasherState>().AddWashStep(setup1, stepNumber2);
            AppState.GetState<WasherState>().AddWashStep(setup1, stepNumber3);

            Page.PlantSetupPage.TopMainMenu.NavigateToControlerSetupPage();
            Thread.Sleep(2000);
            while (Page.ControllerSetupPage.ControllersTabGrid.SelectedRows(dispenser).Count == 0)
            {
                Page.ControllerSetupPage.NextPage.ScrollToVisible();
                Page.ControllerSetupPage.NextPage.Click();
            }

            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows(dispenser)[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows(dispenser)[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(3000);
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.MaxFormulaInjections.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.KendoDown.DeskTopMouseClick();
            Page.ControllerSetupPage.Save.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.DryerTabPage.YesButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.PumpsValvesTab.DeskTopMouseClick();
            Page.PumpsValvesPage.PumpsAndValvesTabGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.PumpsValvesPage.ddlProducts.SelectByIndex(productNumber, Timeout);
            Page.PumpsValvesPage.txtPumpCalibration.TypeText("" + calibration + "");
            Page.PumpsValvesPage.SavePump.DeskTopMouseClick();
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber1 = 0;
            DataTable myTable1 = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = '" + washerGroup + "'");
            foreach (DataRow dr in myTable1.Rows)
            {
                washerGroupNumber1 = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'Formulas' tab of a washer group", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Click on formula update button", () =>
            {
                Page.FormulasTabPage.FormulasTableGridAtWasher.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            });
            Thread.Sleep(2000);

            string nominalString = Page.FormulasTabPage.NominalLoadForConventional.Value;
            float nominalLoad1 = float.Parse(nominalString);
            Page.FormulasTabPage.ViewInjections.Click();
            Page.FormulasTabPage.SelectProduct.SelectByIndex(productNumber, Timeout);
            Page.FormulasTabPage.AddProduct.Click();
            Page.FormulasTabPage.Quantity.SetText(""+ quantity +"");
            string quantityString = Page.FormulasTabPage.Quantity.Value;
            float quantity1 = float.Parse(quantityString);
            Thread.Sleep(1000);
            string totalQuantityString = Page.FormulasTabPage.TotalQuantity.Value;
            double totalQuantity1 = double.Parse(totalQuantityString);

            double totalQuantity1d = (quantity1 * (nominalLoad1 / 100) * 90) / 100;
            totalQuantity1d = Math.Round(totalQuantity1d, 2);

            Runner.DoStep("Verify that the formula 'Total Quantity = (Quantity * (Nominal Load / 100) * 90) / 100' is being satisfied", () =>
            {
                Page.FormulasTabPage.TotalQuantity.Focus();
                if (totalQuantity1 != totalQuantity1d)
                {
                    Thread.Sleep(4000);
                    Assert.Fail("Correct value is not being displayed for the filed 'Total Quantity'");
                }
            });                        
        }
    }
}
