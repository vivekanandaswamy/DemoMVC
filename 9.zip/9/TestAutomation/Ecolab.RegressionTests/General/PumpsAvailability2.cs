﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class PumpsAvailability2 : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);                        
        }

        static string testData = TestDataPath + Excel.ExcelName;
        
        string testCaseId = null;
        string dispenser = null;
        string washerGrouptype = null;
        string washerGroupName = null;
        string tunnelWasherName = null;
        string pumpCalibration = null;
        string pump = null;

        [TestCategory(TestType.regression, "TC01_VerifyAvailabilityOfPumpsToAdd")]
        [Test]
        public void TC01_VerifyAvailabilityOfPumpsToAdd()
        {
            DataTable dt = Excel.DataRead(testData, "Pumps");
            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == MethodBase.GetCurrentMethod().Name)
                {
                    testCaseId = row["TestCaseId"].ToString();
                    dispenser = row["Dispenser"].ToString();
                    washerGrouptype = row["WasherGroupType"].ToString();
                    washerGroupName = row["WasherGroupName"].ToString();
                    tunnelWasherName = row["TunnelWasherName"].ToString();
                    pumpCalibration = row["PumpCalibration"].ToString();
                    pump = row["Pump"].ToString();
                    break;
                }
            }
            try
            {
                Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateTunnelWasherGroupWithOneTunnelForPumps(dispenser, washerGrouptype, washerGroupName, tunnelWasherName);
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Exception : ", ex);
            }

            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            while (Page.ControllerSetupPage.ControllersTabGrid.SelectedRows(dispenser).Count == 0)
            {
                Page.ControllerSetupPage.NextPage.ScrollToVisible();
                Page.ControllerSetupPage.NextPage.Click();
            }
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows(dispenser)[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows(dispenser)[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(1000);
            Random random = new Random();
            Page.ControllerGeneralSetupTabPage.SerialNumber.TypeText(random.Next(1, 73683).ToString());
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.Save.Click();
            Thread.Sleep(1000);
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(1000);

            updatePump(0, pumpCalibration);
            updatePump(1, pumpCalibration);
            updatePump(2, pumpCalibration);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable(string.Format("select * from tcd.WasherGroup where WasherGroupName = '{0}'", washerGroupName));
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.WashersPage.CompartmentsTab.Click();

            createCompartment("1");
            createCompartment("2");
            createCompartment("3");

            // Verify the pumps/valve added in one compartment should not be displayed in other compartment chemicals drop down
            Page.ControllerSetupPage.GeneralTab.Click();
            Page.WashersPage.CompartmentsTab.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (Page.WashersPage.Chemical.BaseElement.InnerText.Contains(pump))
            {
                Assert.Fail("Respective pump should not be available as it is mapped to other Compartment");
            }
            Page.WashersPage.NextCompartment.DeskTopMouseClick();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (Page.WashersPage.Chemical.BaseElement.InnerText.Contains(pump))
            {
                Assert.Fail("Respective pump should not be available as it is mapped to other Compartment");
            }
        }

        [TestCategory(TestType.regression, "TC02_PumpsDeletionMultipleScenarios")]
        [Test]
        public void TC02_PumpsDeletionMultipleScenarios()
        {
            DataTable dt = Excel.DataRead(testData, "Pumps");
            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == MethodBase.GetCurrentMethod().Name)
                {                    
                    pump = row["Pump"].ToString();
                    break;
                }
            }

            Page.ControllerSetupPage.GeneralTab.Click();
            Page.WashersPage.CompartmentsTab.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.CompartmentChemicalsTableGrid.Rows.FirstOrDefault().GetButtonControls().FirstOrDefault().Click();
            DialogHandler.YesButton.Click();
            Page.WashersPage.SaveCompartment.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.Click();
            Thread.Sleep(1000);
            if (!Page.WashersPage.Chemical.BaseElement.InnerText.Contains(pump))
            {
                Assert.Fail("Respective pump should be available as it is not mapped to any Compartment");
            }
            Page.WashersPage.NextCompartment.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (!Page.WashersPage.Chemical.BaseElement.InnerText.Contains(pump))
            {
                Assert.Fail("Respective pump should be available as it is not mapped to any Compartment");
            }
        }
        
        public void updatePump(int rowNumber, string pumpCalibration)
        {
            Page.ControllerSetupPage.PumpsValvesTab.Click();
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[rowNumber].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.PumpsValvesPage.ddlProducts.SelectByIndex(1, Timeout);
            Page.PumpsValvesPage.txtPumpCalibration.TypeText(pumpCalibration);
            Page.PumpsValvesPage.SavePump.ScrollToVisible();
            Page.PumpsValvesPage.SavePump.Click();
        }

        public void createCompartment(string compartmentNumber)
        {
            Page.WashersPage.Compartment.SelectByText(compartmentNumber, true);
            Page.WashersPage.WaterInlet.SelectByIndex(1, Timeout);
            Page.WashersPage.WashZone.SelectByIndex(1, Timeout);
            Page.WashersPage.WaterFlow.SelectByIndex(1, Timeout);
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.SelectByIndex(1, Timeout);
            Page.WashersPage.AddPump.Click();
            Page.WashersPage.SaveCompartment.Click();
        }
    }
}
