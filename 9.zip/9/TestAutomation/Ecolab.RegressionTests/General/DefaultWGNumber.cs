﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class DefaultWGNumber : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {                    
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }
        
        [TestCategory(TestType.regression, "TC01_WasherGroupNumber")]
        [Test]
        public void TC01_WasherGroupNumber()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            //Page.WasherGroupPage.WasherGroupTableGrid.Rows.LastOrDefault().ScrollToVisible();
            //Page.WasherGroupPage.WasherGroupTableGrid.Rows.LastOrDefault().Focus();
            //string washerGroupNumber = Page.WasherGroupPage.WasherGroupTableGrid.Rows.LastOrDefault().GetColumnValues()[1];
            Page.WasherGroupPage.GroupNumberColumn.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.WasherGroupPage.GroupNumberColumn.DeskTopMouseClick();
            Thread.Sleep(1000);
            int washerGroupNumber = Convert.ToInt32(Page.WasherGroupPage.WasherGroupTableGrid.Rows.FirstOrDefault().GetColumnValues()[1]);
            //int washerGroupNumber = 0;
            //DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupNumber = (select max(CAST(washergroupnumber as int)) from tcd.WasherGroup)");
            //foreach (DataRow dr in myTable.Rows)
            //{
            //    washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"]);
            //}                
            //Page.WasherGroupPage.BtnAddWasherGroup.ScrollToVisible();
            Page.WasherGroupPage.BtnAddWasherGroup.Focus();
            Page.WasherGroupPage.BtnAddWasherGroup.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WasherGroupPage.TxtGroupNumber.Focus();
            int newWasherGroupNumber = Convert.ToInt32(Page.WasherGroupPage.TxtGroupNumber.Value);
            if (newWasherGroupNumber != (washerGroupNumber + 1))
            {
                Assert.Fail("New washer group number created wrongly");
            }
        } 
    }
}
