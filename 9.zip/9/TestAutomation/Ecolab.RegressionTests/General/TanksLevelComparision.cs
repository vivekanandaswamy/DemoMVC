﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class TanksLevelComparision : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);                        
        }

        static string testData = TestDataPath + Excel.ExcelName;

        /// <summary>
        ///
        /// </summary>        
        [TestCategory(TestType.regression, "TC01_LevelsComparision")]
        [Test]
        public void TC01_LevelsComparision()
        {
            string storageTankName = null;
            int product = 0;
            string lowLevel = null;
            string emptyLevel = null;
            string calibrationLevel = null;
            string tankDispenser = null;

            DataTable dt = Excel.DataRead(testData, "TanksLevelComparision");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {                    
                    storageTankName = row["Storage tank name"].ToString();
                    product = Convert.ToInt32(row["Product"].ToString());
                    lowLevel = row["Low level"].ToString();
                    emptyLevel = row["Empty level"].ToString();
                    calibrationLevel = row["Calibration level"].ToString();
                    tankDispenser = row["Tank Dispenser"].ToString();                                        
                    break;
                }
            }

            int abBUltraxtId = AppState.GetState<ControllerState>().CreateABUltrax(tankDispenser);

            Page.LoginPage.TopMainMenu.NavigateToStorageTanksPage();
            Runner.DoStep("Enter Storage tank details and click Save", () =>
            {
                Page.StorageTanksTabPage.AddStorageTanks.Click();
                Page.StorageTanksTabPage.TankName.TypeText(storageTankName);
                Page.StorageTanksTabPage.ProductName.SelectByIndex(product, Timeout);

                Page.StorageTanksTabPage.LowLevel.TypeText(lowLevel);
                Page.StorageTanksTabPage.EmptyLevel.TypeText(emptyLevel);
                Page.StorageTanksTabPage.CallibrationLevel.TypeText(calibrationLevel);

                Page.StorageTanksTabPage.InputType.SelectByIndex(product, Timeout);
                Page.StorageTanksTabPage.ControllerName.SelectByPartialText(tankDispenser, true);
                Page.StorageTanksTabPage.Save.DeskTopMouseClick();
            });

            Runner.DoStep("Verify whether Low-Calibration values error has occured or not", () =>
            {
                if (!Page.StorageTanksTabPage.LowAndCalibrationLevelsError.BaseElement.InnerText.Contains("Low Level should be less than Calibration Level"))
                {
                    Assert.Fail("Expected error message after comparing Low and Calibration levels' values not visble", true);
                }
            });

            Runner.DoStep("Verify whether Empty-Low values error has occured or not", () =>
            {
                if (!Page.StorageTanksTabPage.EmptyAndLowLevelsError.BaseElement.InnerText.Contains("Empty level should be less than Low Level"))
                {
                    Assert.Fail("Expected error message after comparing Empty and Low levels' values not visble", true);
                }
            });
            Thread.Sleep(2000);
        }        
    }
}
