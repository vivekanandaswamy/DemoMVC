﻿using Ecolab.AppStateHandler;
using Ecolab.AppStateHandler.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class WashStepsRunTime : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
        }

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC1_ValidateWashsteps")]
        [Test]
        public void TC1_ValidateWashsteps()
        {
            DataTable dt = Excel.DataRead(testData, "WasherSteps");         
            string dispenser = null;
            string washerGrouptype = null;
            string washerGroupName = null;
            string washerName = null;
            string stepRunTime1 = null;
            string stepRunTime2 = null;
            string stepRunTime3 = null;

            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == MethodBase.GetCurrentMethod().Name)
                {                    
                    dispenser = row["Dispenser"].ToString();
                    washerGrouptype = row["WasherGroupType"].ToString();
                    washerGroupName = row["WasherGroupName"].ToString();
                    washerName = row["WasherName"].ToString();
                    stepRunTime1 = row["StepRunTime1"].ToString();
                    stepRunTime2 = row["StepRunTime2"].ToString();
                    stepRunTime3 = row["StepRunTime3"].ToString();
                    break;
                }
            }
            int controllerId = AppState.GetState<ControllerState>().CreateABUltrax(dispenser);
            WasherGroup group = AppState.GetState<WasherState>().CreateWasherGroup(washerGrouptype, washerGroupName);
            AppState.GetState<WasherState>().CreateConventionalWasher(group.Id, group.Id, washerName, controllerId, 1);

            WasherProgramSetup setup1 = AppState.GetState<WasherState>().AddFormulatoWasherGroup(1, group);

            AppState.GetState<WasherState>().AddWashStep(setup1, 1, RunTimeCalculation(stepRunTime1));
            AppState.GetState<WasherState>().AddWashStep(setup1, 2, RunTimeCalculation(stepRunTime2));
            AppState.GetState<WasherState>().AddWashStep(setup1, 3, RunTimeCalculation(stepRunTime3));

            // int TotalRunTime1 = AppState.GetState<WasherState>().GetWasherSetup(setup1).TotalRunTime;
            int TotalRunTime1 = RunTimeCalculation(stepRunTime1) + RunTimeCalculation(stepRunTime2) + RunTimeCalculation(stepRunTime3);
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(1000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable(string.Format("select * from tcd.WasherGroup where WasherGroupName = '{0}'", washerGroupName));
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'Formulas' tab of a washer group", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
            });
            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulasTableGridAtWasher.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(1000);

            int TotalRunTimeInUI = RunTimeCalculation(Page.FormulasTabPage.TotalRunTime.Value);

            Runner.DoStep("Verify that the 'Total run time' is displayed correctly ", () =>
            {
                Page.FormulasTabPage.TotalRunTime.Focus();
                if (TotalRunTime1 != TotalRunTimeInUI)
                {
                    Assert.Fail("Total Runtime value is incorrect");
                }
            });
        }

        public int RunTimeCalculation(string runTime)
        {
            string[] MinSec = runTime.Split(':');
            return Convert.ToInt32(MinSec[0]) * 60 + Convert.ToInt32(MinSec[1]);
        }
    }
}
