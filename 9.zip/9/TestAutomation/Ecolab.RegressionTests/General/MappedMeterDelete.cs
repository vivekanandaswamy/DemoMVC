﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.RegressionTests.General
{
    public class MappedMeterDelete : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            AppState.GetState<MeterState>().DeleteAllMeters();
        }

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC01_MeterDelete")]
        [Test]
        public void TC01_MeterDelete()
        {
            string meterName1 = null;
            string meterName2 = null;
            string utilityType = null;
            string location = null;
            string machine1 = null;
            string machine2 = null;
            int UOM = 0;
            string meterDispenser = null;
            string wGType = null;

            DataTable dt = Excel.DataRead(testData, "MappedMeterDelete");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {
                    meterName1 = row["Meter Name 1"].ToString();
                    meterName2 = row["Meter Name 2"].ToString();
                    utilityType = row["Utility type"].ToString();                    
                    location = row["Location"].ToString();                   
                    machine1 = row["Machine 1"].ToString();                    
                    machine2 = row["Machine 2"].ToString();
                    UOM = Convert.ToInt32(row["UOM"].ToString());
                    meterDispenser = row["Meter Dispenser"].ToString();
                    wGType = row["WG Type"].ToString();
                    break;
                }
            } 
            
            int abUltraxIdForMeter = AppState.GetState<ControllerState>().CreateABUltrax(meterDispenser);
            Ecolab.AppStateHandler.Entities.WasherGroup abConventionalWasherGroupForMeter = AppState.GetState<WasherState>().CreateWasherGroup(wGType, location);
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForMeter.Id, abConventionalWasherGroupForMeter.Id, machine1, abUltraxIdForMeter, 1);
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupForMeter.Id, abConventionalWasherGroupForMeter.Id, machine2, abUltraxIdForMeter, 2);            
            NavigateToMetersPage();
            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText(meterName1);
            //string parentMeterName = Page.MetersTabPage.MeterName.Value.TrimEnd();
            Page.MetersTabPage.UtilityType.SelectByText(utilityType, Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText(location, Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByPartialText(machine1, true);
            Page.MetersTabPage.UOM.SelectByIndex(UOM, Timeout);
            //Page.MetersTabPage.Controller.SelectByPartialText("MeterDispenser", true);
            Runner.DoStep("Add a Meter without a parent", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }

            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText(meterName2);
            string sample = Page.MetersTabPage.MeterName.Value.TrimEnd();
            Page.MetersTabPage.UtilityType.SelectByText(utilityType, Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText(location, Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByPartialText(machine2, true);
            Page.MetersTabPage.Parent.SelectByPartialText(meterName1, true);
            Page.MetersTabPage.UOM.SelectByIndex(UOM, Timeout);
            //Page.MetersTabPage.Controller.SelectByPartialText("MeterDispenser", true);
            Runner.DoStep("Add a Meter with a Parent", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }
                                  
            Page.MetersTabPage.MetersTabGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Runner.DoStep("Try deleting Meter which has a Child mapped to it", () =>
            {
                Page.MetersTabPage.DeleteMeterYes.Click();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the error message that arrives while deleting a meter that has a child is displayed", () =>
            {
                if (!Page.MetersTabPage.SuccessfulMeterAdditionMessage.BaseElement.InnerText.Contains("Unable to delete parent Meter when child Meter exists."))
                {
                    Assert.Fail("Meter is deleted even when mapped to other meter as a parent");
                }
            });

            Thread.Sleep(2000);
            //Page.MetersTabPage.MetersTabGrid.SelectedRows("Meter 3 Edited")[0].GetButtonControls()[1].Click();
            Page.MetersTabPage.MetersTabGrid.Rows.LastOrDefault().GetButtonControls()[0].Click();
            Page.MetersTabPage.DeleteMeterYes.Click();
            Runner.DoStep("Delete the Meter that has a Parent", () =>
            {
                if (!Page.MetersTabPage.SuccessfulMeterAdditionMessage.BaseElement.InnerText.Contains("Meter Deleted Successfully"))
                {
                    Assert.Fail("Meter not deleted successfully");
                }
            });

            //Page.MetersTabPage.MetersTabGrid.SelectedRows("Meter 1")[0].GetButtonControls()[1].Click();
            Page.MetersTabPage.MetersTabGrid.Rows.FirstOrDefault().GetButtonControls()[0].Click();
            Page.MetersTabPage.DeleteMeterYes.Click();
            Runner.DoStep("Delete a Meter whose child has been deleted", () =>
            {
                if (!Page.MetersTabPage.SuccessfulMeterAdditionMessage.BaseElement.InnerText.Contains("Meter Deleted Successfully"))
                {
                    Assert.Fail("Meter not deleted successfully");
                }
            });            
        }

        private void NavigateToMetersPage()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(1000);
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(1000);
            Page.PlantSetupPage.MeterTab.Click();
            KeyBoardSimulator.KeyPress(Keys.Tab);
            Thread.Sleep(1000);
        }
    }
}
