﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class NominalLoadCheck : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }

        static string testData = TestDataPath + Excel.ExcelName;

        string numberOfTanks = null;
        string transferType = null;
        string press = null;
        string nLT1 = null;
        string nLT2 = null;
        string nLT3 = null;
        string nLT4 = null;
        string nLT5 = null;
        string nLC1 = null;
        string nLC2 = null;
        string nLC3 = null;
        string nLC4 = null;
        string nLC5 = null;
        int ddlModelNumber = 0;
        string dispenser1 = null;
        string dispenser2 = null;
        string wG1 = null;
        string wG2 = null;
        string convWasher = null;
        string wGType1 = null;
        string wGType2 = null;

        [TestCategory(TestType.regression, "TC01_ValidateMaxNominalLoadCapacity")]
        [Test]
        public void TC01_ValidateMaxNominalLoadCapacity()
        {
            DataTable dt = Excel.DataRead(testData, "NominalLoadCheck");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {
                    //testCaseId = row["Test case ID"].ToString();
                    numberOfTanks = row["Number of tanks"].ToString();
                    transferType = row["Transfer type"].ToString();
                    press = row["Press"].ToString();
                    nLT1 = row["NLT1"].ToString();
                    nLT2 = row["NLT2"].ToString();
                    nLT3 = row["NLT3"].ToString();
                    nLT4 = row["NLT4"].ToString();
                    nLT5 = row["NLT5"].ToString();
                    nLC1 = row["NLC1"].ToString();
                    nLC2 = row["NLC2"].ToString();
                    nLC3 = row["NLC3"].ToString();
                    nLC4 = row["NLC4"].ToString();
                    nLC5 = row["NLC5"].ToString();
                    ddlModelNumber = Convert.ToInt32(row["DdlModelNumber"]);
                    dispenser1 = row["Dispenser 1"].ToString();
                    dispenser2 = row["Dispenser 2"].ToString();
                    wG1 = row["WG 1"].ToString();
                    wG2 = row["WG 2"].ToString();
                    convWasher = row["Conv Washer"].ToString();
                    wGType1 = row["WG type 1"].ToString();
                    wGType2 = row["WG type 2"].ToString();
                    break;
                }
            }

            //Validating for a Tunnel washer group

            AppState.GetState<ControllerState>().CreateABUltraxTDI(dispenser1);
            AppState.GetState<WasherState>().CreateWasherGroup(wGType1, wG1);

            creatingATunnelWasherCopy();
            ValidateMaxNominalLoadCapacityForTunnel();

            //Validating for a Conventional washer group

            int abUltraxIdFormulaNominalValue = AppState.GetState<ControllerState>().CreateABUltrax(dispenser2);
            Ecolab.AppStateHandler.Entities.WasherGroup abConventionalWasherGroupFormulaNominalValue = AppState.GetState<WasherState>().CreateWasherGroup(wGType2, wG2);
            //Console.WriteLine("TrialConvWashertestAbFormulaNominalValue");
            AppState.GetState<WasherState>().CreateConventionalWasher(abConventionalWasherGroupFormulaNominalValue.Id, abConventionalWasherGroupFormulaNominalValue.Id, convWasher, abUltraxIdFormulaNominalValue, 1);

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(2000);
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = '" + wG2 + "'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            ValidateMaxNominalLoadCapacityForConventional();
        }

        public void creatingATunnelWasherCopy()
        {
            Runner.DoStep("Create an AB tunnel washer", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                Thread.Sleep(2000);
                int washerGroupNumber = 0;
                DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = '" + wG1 + "'");
                foreach (DataRow dr in myTable.Rows)
                {
                    washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
                }
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
                Page.WashersPage.DdlModel.Focus();
                Page.WashersPage.DdlModel.SelectByIndex(ddlModelNumber, Timeout);
                Page.WashersPage.DdlController.SelectByPartialText(dispenser1, true);
                Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
                Random random = new Random();
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText(numberOfTanks);
                Page.WashersPage.DdlTransferType.SelectByPartialText(transferType, true);
                Page.WashersPage.DdlPress.Focus();
                Page.WashersPage.DdlPress.SelectByPartialText(press, true);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 99).ToString());
                Page.WashersPage.BtnSaveTunnel.Click();
                Thread.Sleep(8000);
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        Thread.Sleep(8000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."));
                }
            });
        }

        public void ValidateMaxNominalLoadCapacityForTunnel()
        {
            Runner.DoStep("Try creating formula for Tunnel with 'Nominal load' values within and outside the range", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
                Thread.Sleep(2000);
                Page.FormulasTabPage.AddFormulaButton.Click();
                Thread.Sleep(2000);

                Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nLT1);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.NominalLoadErrorMessage.BaseElement.InnerText.Contains(nLT2))
                {
                    Assert.Fail("Error message not shown");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nLT2);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nLT3);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nLT4);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.NominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nLT5);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.NominalLoadErrorMessage.BaseElement.InnerText.Contains(nLT4))
                {
                    Assert.Fail("Error message not shown");
                }
            });
        }

        public void ValidateMaxNominalLoadCapacityForConventional()
        {
            Runner.DoStep("Try creating formula for Conventional with 'Nominal load' values within and outside the range", () =>
            {
                Page.FormulasTabPage.FormulasTab.Click();
                Thread.Sleep(2000);
                Page.FormulasTabPage.AddFormulaButton.Click();
                Thread.Sleep(2000);

                Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
                Page.FormulasTabPage.SelectFormulaName.SelectByIndex(0, Timeout);
                Page.FormulasTabPage.NominalLoadForConventional.TypeText(nLC1);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.ConvNominalLoadErrorMessage.BaseElement.InnerText.Contains(nLC2))
                {
                    Assert.Fail("Error message not shown");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText(nLC2);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.ConvNominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText(nLC3);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (Page.FormulasTabPage.ConvNominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText(nLC4);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(8000);
                if (Page.FormulasTabPage.ConvNominalLoadErrorMessage.IsVisible())
                {
                    Assert.Fail("Error message shown inspite of entering correct value");
                }
                Page.FormulasTabPage.NominalLoadForConventional.TypeText(nLC5);
                Page.FormulasTabPage.Save.DeskTopMouseClick();
                Thread.Sleep(5000);
                if (!Page.FormulasTabPage.ConvNominalLoadErrorMessage.BaseElement.InnerText.Contains(nLC4))
                {
                    Assert.Fail("Error message not shown");
                }
            });
        }
    }
}
