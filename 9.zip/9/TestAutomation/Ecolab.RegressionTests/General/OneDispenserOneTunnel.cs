﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class OneDispenserOneTunnel : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);                        
        }

        Random random = new Random();
        static string testData = TestDataPath + Excel.ExcelName;
        
        [TestCategory(TestType.regression, "TC01_AssignDispenserToTunnel")]
        [Test]
        public void TC01_AssignDispenserToTunnel()
        {
            string dispenser1 = null;
            string dispenser2 = null;
            string wG1 = null;
            string wG2 = null;
            int dDLModel = 0;
            string tunnel1 = null;
            string tunnel2 = null;
            int numberOfTanks = 0;
            string transferType = null;
            string press = null;
            string wGType = null;

            DataTable dt = Excel.DataRead(testData, "OneDispenserOneTunnel");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == MethodBase.GetCurrentMethod().Name)
                {
                    dispenser1 = row["Dispenser 1"].ToString();
                    dispenser2 = row["Dispenser 2"].ToString();
                    wG1 = row["WG 1"].ToString();
                    wG2 = row["WG 2"].ToString();
                    dDLModel = Convert.ToInt32(row["DDL Model"].ToString());
                    tunnel1 = row["Tunnel 1"].ToString();
                    tunnel2 = row["Tunnel 2"].ToString();
                    numberOfTanks = Convert.ToInt32(row["Number of Tanks"].ToString());
                    transferType = row["Transfer type"].ToString();
                    press = row["Press"].ToString();
                    wGType = row["WG type"].ToString();
                    break;
                }
            }

            AppState.GetState<ControllerState>().CreateABUltraxTDI(dispenser1);
            AppState.GetState<ControllerState>().CreateBeckhoffUltraxTDI(dispenser2);
            AppState.GetState<WasherState>().CreateWasherGroup(wGType, wG1);
            AppState.GetState<WasherState>().CreateWasherGroup(wGType, wG2);

            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = '" + wG1 + "'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });
            Page.WashersPage.DdlModel.Focus();
            Page.WashersPage.DdlModel.SelectByIndex(dDLModel, Timeout);
            Page.WashersPage.DdlController.SelectByPartialText(dispenser1, true);
            Page.WashersPage.TxtName.TypeText(tunnel1);
            Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
            Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("" + numberOfTanks + "");
            Page.WashersPage.DdlTransferType.SelectByPartialText(transferType, true);
            Page.WashersPage.DdlPress.Focus();
            Page.WashersPage.DdlPress.SelectByPartialText(press, true);
            Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
            Runner.DoStep("Enter washer details and click Save", () =>
            {
                Page.WashersPage.BtnSaveTunnel.Click();
            });            
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();                        
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });
            Runner.DoStep("Navigate to 'Washers group' page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            });
            Thread.Sleep(2000);
            int washerGroupNumber1 = 0;
            DataTable myTable1 = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = '" + wG2 + "'");
            foreach (DataRow dr in myTable1.Rows)
            {
                washerGroupNumber1 = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Thread.Sleep(2000);
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber1.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of a Beckhoff Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });
            if (Page.WashersPage.DdlController.InnerText.Contains(dispenser1))
            {
                Assert.Fail(" '" + dispenser1 + "' is not supposed to be available");
            }
            else
            {
                Page.WashersPage.DdlModel.SelectByIndex(dDLModel, Timeout);
                Page.WashersPage.DdlController.SelectByPartialText(dispenser2, true);
                Page.WashersPage.TxtName.TypeText(tunnel2);
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText("" + numberOfTanks + "");
                Page.WashersPage.DdlTransferType.SelectByPartialText(transferType, true);
                Page.WashersPage.DdlPress.SelectByPartialText(press, true);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 127).ToString());
                Runner.DoStep("Enter washer details and click Save", () =>
                {
                    Page.WashersPage.BtnSaveTunnel.Click();
                });
            }            
            Runner.DoStep("Check whether the washer number is a unique one and generate a new one if not", () =>
            {
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();                        
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.ToLower().Contains("specified plant washer number or name already exists"));
                }
            });

            Runner.DoStep("Navigate to 'Washers group' page", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            });            
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Runner.DoStep("Click on 'SAVE' button of an AB Washer group", () =>
            {
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            });
            Runner.DoStep("Check whether Dispenser added to Beckhoff washer is available", () =>
            {
                if (Page.WashersPage.DdlController.InnerText.Contains(dispenser2))
                {
                    Assert.Fail(" '" + dispenser2 + "' is not supposed to be available");
                }
            });
        }
    }
}
