﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class FormulaMappedPumpsDeletion : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }

        static string testData = TestDataPath + Excel.ExcelName;
        Random random = new Random();

        [TestCategory(TestType.regression, "TC01_FormulasMappedPumpsDelete")]
        [Test]
        public void TC01_FormulasMappedPumpsDelete()
        {
            try
            {
                int controllerId = AppState.GetState<ControllerState>().CreateABUltraxTDI("TrialABUltraxTDIForPumps");
                //Thread.Sleep(2000);
                Ecolab.AppStateHandler.Entities.WasherGroup washerGroup = AppState.GetState<WasherState>().CreateWasherGroup("Tunnel", "TrialABTunnelWasherGroupForPumps");
                //Thread.Sleep(2000);
                AppState.GetState<WasherState>().CreateTunnelWasher(washerGroup.Id, "TrialTunnelForPumps", controllerId);
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Exception : ", ex);
            }

            Page.LoginPage.TopMainMenu.NavigateToControlerSetupPage();
            while (Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps").Count == 0)
            {
                Page.ControllerSetupPage.NextPage.ScrollToVisible();
                Page.ControllerSetupPage.NextPage.Click();
            }
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps")[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.ControllerSetupPage.ControllersTabGrid.SelectedRows("TrialABUltraxTDIForPumps")[0].GetButtonControls().LastOrDefault().Click();
            Thread.Sleep(2000);
            Page.ControllerGeneralSetupTabPage.SerialNumber.TypeText(random.Next(1, 73683).ToString());
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.ActiveCheckBox.Click();
            Page.ControllerGeneralSetupTabPage.Save.Click();
            Thread.Sleep(2000);
            Page.ControllerSetupPage.AdvanceTab.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.SetPLCTime.Click();
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(2000);

            updatePump(0);            

            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            int washerGroupNumber = 0;
            DataTable myTable = DBValidation.GetDataTable("select * from tcd.WasherGroup where WasherGroupName = 'TrialABTunnelWasherGroupForPumps'");
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WashersPage.CompartmentsTab.Click();

            createCompartment(1);           

            Page.WasherGroupFormulasPage.FormulaTab.Click();
            Page.WasherGroupFormulasPage.AddFormula.Click();
            Page.WasherGroupFormulasPage.FormulaName.SelectByIndex(1, Timeout);
            Page.WasherGroupFormulasPage.Save.Click();
            Thread.Sleep(2000);            
            Page.WasherGroupPage.TxtTemperature.TypeText("56");
            Page.WasherGroupFormulasPage.WaterType.SelectByIndex(1, Timeout);
            Page.WasherGroupFormulasPage.WaterType.SelectByIndex(0, Timeout);
            Page.WasherGroupFormulasPage.WashOperation.SelectByIndex(3, Timeout);
            Page.WasherGroupFormulasPage.WashOperation.SelectByIndex(1, Timeout);            
            Page.WasherGroupFormulasPage.SaveWashStep.Click();
            if (!Page.FormulasTabPage.FormulaWashstepAddedMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Success message not displayed");
            }

            Page.WashersPage.WashersTab.Click();
            Page.WashersPage.WashersListGridTable.Rows.FirstOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WashersPage.CompartmentsTab.Click();
            Thread.Sleep(2000);            
            Page.WashersPage.PumpsTableInCompartmentsTab.Rows.FirstOrDefault().GetButtonControls()[0].Click();            
            DialogHandler.YesButton.Click();
            Page.WashersPage.SaveCompartment.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.Click();
            Thread.Sleep(1000);
            if (!Page.WashersPage.Chemical.BaseElement.InnerText.Contains("P/V 1"))
            {
                Assert.Fail("Respective pump should be available as it is not mapped to any Compartment");
            }
            Page.WashersPage.NextCompartment.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.DeskTopMouseClick();
            Thread.Sleep(1000);
            if (!Page.WashersPage.Chemical.BaseElement.InnerText.Contains("P/V 1"))
            {
                Assert.Fail("Respective pump should be available as it is not mapped to any Compartment");
            }
        }

        public void updatePump(int rowNumber)
        {
            Page.ControllerSetupPage.PumpsValvesTab.Click();
            Page.PumpsValvesPage.PumpsListTableGrid.Rows[rowNumber].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.PumpsValvesPage.ddlProducts.SelectByIndex(1, Timeout);
            Page.PumpsValvesPage.txtPumpCalibration.TypeText("34");
            Page.PumpsValvesPage.SavePump.ScrollToVisible();
            Page.PumpsValvesPage.SavePump.Click();
        }

        public void createCompartment(int compartmentNumber)
        {
            Page.WashersPage.NextCompartment.DeskTopMouseClick();
            if (compartmentNumber == 1)
            {
                Page.WashersPage.PreviousCompartment.DeskTopMouseClick();
            }
            Page.WashersPage.WaterInlet.SelectByIndex(1, Timeout);
            Page.WashersPage.WashZone.SelectByIndex(1, Timeout);
            Page.WashersPage.WaterFlow.SelectByIndex(1, Timeout);
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.SelectByIndex(1, Timeout);
            Page.WashersPage.AddPump.Click();
            Page.WashersPage.PumpsTableInCompartmentsTab.Rows[0].GetButtonControls().FirstOrDefault().DeskTopMouseClick();
            Page.WashersPage.DeleteWasherYesButton.Click();
            Page.WashersPage.Chemical.ScrollToVisible();
            Page.WashersPage.Chemical.SelectByIndex(1, Timeout);
            Page.WashersPage.AddPump.Click();
            Page.WashersPage.SaveCompartment.Click();
        }
    }
}
