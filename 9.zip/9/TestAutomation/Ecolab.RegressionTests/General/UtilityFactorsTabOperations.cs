﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.RegressionTests.General
{
    public class UtilityFactorsTabOperations : TestBase
    {                
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
        }

        static string testData = TestDataPath + Excel.ExcelName;
        DataTable dt = Excel.DataRead(testData, "UtilityFactor");

        [TestCategory(TestType.regression, "TC01_UtilityMandatoryProperties")]
        [Test]
        public void TC01_UtilityMandatoryProperties()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.SteamYes.Click();
            Thread.Sleep(4000);
            Page.WETabPage.SteamNo.DeskTopMouseClick();
            Page.WETabPage.BoilerType.Click();
            Thread.Sleep(2000);
            Page.WETabPage.BoilerOption1.Click();
            Thread.Sleep(2000);
            Page.UtilitySetupPage.TxtSteamPercentage.Click();
            Page.UtilitySetupPage.TxtSteamPercentage.TypeText("");
            Page.UtilitySetupPage.TxtBoilerPercentage.Click();
            Page.UtilitySetupPage.TxtBoilerPercentage.TypeText("");
            Page.UtilitySetupPage.TxtStackPercentage.Click();
            Page.UtilitySetupPage.TxtStackPercentage.TypeText("");
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(1000);
            string steamErrorMessage = Page.WETabPage.SteamError.BaseElement.InnerText;
            string boilerErrorMessage = Page.WETabPage.BoilerError.BaseElement.InnerText;
            string stackErrorMessage = Page.WETabPage.StackError.BaseElement.InnerText;
            if (!((steamErrorMessage.Contains("Please enter the Steam Percentage")) && (boilerErrorMessage.Contains("Please enter the Boiler Percentage")) && (stackErrorMessage.Contains("Please enter the Stack Percentage"))))
            {
                Assert.Fail("Incorrect error message found");
            }
        }

        [TestCategory(TestType.regression, "TC02_MeterWithOptionalDispenser")]
        [Test]
        public void TC02_MeterWithOptionalDispenser()
        {
            string meterName = null;
            //dt = Excel.DataRead(testData, "UtilityFactor");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == MethodBase.GetCurrentMethod().Name)
                {
                    meterName = row["Meter Name"].ToString();
                    break;
                }
            }
            NavigateToMetersPage();
            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText(meterName);

            Page.MetersTabPage.UtilityType.SelectByIndex(1, Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByIndex(1, Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByIndex(1, Timeout);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            Page.MetersTabPage.AllowManualEntry.Focus();
            Page.MetersTabPage.AllowManualEntry.Click();
            Runner.DoStep("Add a Meter without a parent", () =>
            {
                Page.MetersTabPage.AddMeterSaveButton.Click();
            });
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.ToLower().Contains("meter added successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }
        }

        [TestCategory(TestType.regression, "TC03_EnterMandatoryUtilityProperties")]
        [Test]
        public void TC03_EnterMandatoryUtilityProperties()
        {
            string steamPercentage = null;
            string boilerPercentage = null;
            string stackPercentage = null;

            //dt = Excel.DataRead(testData, "UtilityFactor");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == MethodBase.GetCurrentMethod().Name)
                {
                    steamPercentage = row["Steam %"].ToString();
                    boilerPercentage = row["Boiler %"].ToString();
                    stackPercentage = row["Stack %"].ToString();
                    break;
                }
            }

            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.WETabPage.SteamYes.Click();
            Thread.Sleep(4000);
            Page.WETabPage.SteamNo.DeskTopMouseClick();
            Page.WETabPage.BoilerType.Click();
            Thread.Sleep(2000);
            Page.WETabPage.BoilerOption1.Click();
            Thread.Sleep(2000);
            Page.UtilitySetupPage.TxtSteamPercentage.Click();
            Page.UtilitySetupPage.TxtSteamPercentage.TypeText("");
            Page.UtilitySetupPage.TxtBoilerPercentage.Click();
            Page.UtilitySetupPage.TxtBoilerPercentage.TypeText("");
            Page.UtilitySetupPage.TxtStackPercentage.Click();
            Page.UtilitySetupPage.TxtStackPercentage.TypeText("");
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(1000);
            string steamErrorMessage = Page.WETabPage.SteamError.BaseElement.InnerText;
            string boilerErrorMessage = Page.WETabPage.BoilerError.BaseElement.InnerText;
            string stackErrorMessage = Page.WETabPage.StackError.BaseElement.InnerText;
            if (!((steamErrorMessage.Contains("Please enter the Steam Percentage")) && (boilerErrorMessage.Contains("Please enter the Boiler Percentage")) && (stackErrorMessage.Contains("Please enter the Stack Percentage"))))
            {
                Assert.Fail("Incorrect error message found");
            }
            Thread.Sleep(2000);
            Page.UtilitySetupPage.TxtSteamPercentage.Click();
            Page.UtilitySetupPage.TxtSteamPercentage.TypeText(steamPercentage);
            Page.UtilitySetupPage.TxtBoilerPercentage.Click();
            Page.UtilitySetupPage.TxtBoilerPercentage.TypeText(boilerPercentage);
            Page.UtilitySetupPage.TxtStackPercentage.Click();
            Page.UtilitySetupPage.TxtStackPercentage.TypeText(stackPercentage);
            Page.ControllerAdvancedSetupPage.Save.Click();
            Thread.Sleep(1000);
            if (!Page.UtilitySetupPage.SuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Details should have been saved with the default values");
            }
        }

        [TestCategory(TestType.regression, "TC04_VerifyEvaporationFactor")]
        [Test]
        public void TC04_VerifyEvaporationFactor()
        {
            //dt = Excel.DataRead(testData, "UtilityFactor");
            string evaporationFactor = null;

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == MethodBase.GetCurrentMethod().Name)
                {
                    evaporationFactor = row["Evaporation Factor"].ToString();
                    break;
                }
            }
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.UtilitySetupPage.EvaporationFactor.TypeText("");
            Page.WETabPage.SteamYes.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WETabPage.SteamNo.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.Save.Click();
            if (!Page.UtilitySetupPage.SuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Details should have been saved without any value for 'Evaporation factor'");
            }
            Thread.Sleep(2000);
            Page.UtilitySetupPage.EvaporationFactor.TypeText(evaporationFactor);
            Page.WETabPage.SteamYes.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.WETabPage.SteamNo.DeskTopMouseClick();
            Page.ControllerAdvancedSetupPage.Save.Click();
            if (!Page.UtilitySetupPage.SuccessMessage.BaseElement.InnerText.Contains("Successfully"))
            {
                Assert.Fail("Details should have been saved with 'Evaporation factor' value being zero");
            }

        }
        private void NavigateToMetersPage()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.PlantSetupPage.MeterTab.Click();
            KeyBoardSimulator.KeyPress(Keys.Tab);
            Thread.Sleep(2000);
        }
    }
}
