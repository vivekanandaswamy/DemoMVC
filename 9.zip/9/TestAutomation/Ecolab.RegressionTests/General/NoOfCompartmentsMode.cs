﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class NoOfCompartmentsMode : TestBase
    {        
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulasTab.Click();
            //Thread.Sleep(3000);        
        }

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC1_ValidateNumberOfCompartmentsForTunnelWG")]
        [Test]
        public void TC1_ValidateNumberOfCompartmentsForTunnelWG()
        {
            DataTable dt = Excel.DataRead(testData, "TunnelWG");
            string testCaseId = null;
            string noOfTanks = null;
            string formulaNumber = null;
            string nominalLoadForTunnel = null;
            string dispenser = null;
            string transferType = null;
            string press = null;
            string washerGrouptype = null;
            string washerGroupName = null;
            int washerGroupNumber = 0;
            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {
                    testCaseId = row["TestCaseId"].ToString();
                    dispenser = row["Dispenser"].ToString();
                    washerGrouptype = row["WasherGroupType"].ToString();
                    washerGroupName = row["WasherGroupName"].ToString();
                    transferType = row["TransferType"].ToString();
                    press = row["Press"].ToString();
                    noOfTanks = row["NoOfTanks"].ToString();
                    formulaNumber = row["FormulaNumber"].ToString();
                    nominalLoadForTunnel = row["NominalLoadForTunnel"].ToString();

                    break;
                }

            }
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndATunnelWasherGroup2(dispenser, washerGrouptype, washerGroupName);
            Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
            Thread.Sleep(1000);

            DataTable myTable = DBValidation.GetDataTable(string.Format("select * from tcd.WasherGroup where WasherGroupName = '{0}'", washerGroupName));
            foreach (DataRow dr in myTable.Rows)
            {
                washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
            }
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
            Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
            Page.WashersPage.DdlModel.Focus();
            Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
            Page.WashersPage.DdlController.SelectByPartialText(dispenser, true);
            Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
            Random random = new Random();
            Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
            Page.WashersTunnelGeneralPage.NoOfTanks.TypeText(noOfTanks);
            Page.WashersPage.DdlTransferType.SelectByText(transferType, true);
            Page.WashersPage.DdlPress.Focus();
            Page.WashersPage.DdlPress.SelectByText(press, true);
            Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 99).ToString());
            Runner.DoStep("Create an AB tunnel washer", () =>
            {
                Page.WashersPage.BtnSaveTunnel.Click();
            });
            Thread.Sleep(4000);
            if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."))
            {
                do
                {
                    Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                    Page.WashersPage.BtnSaveTunnel.Click();
                    Thread.Sleep(4000);
                } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."));
            }
            Thread.Sleep(2000);
            KeyBoardSimulator.KeyPress(System.Windows.Forms.Keys.Back);
            Runner.DoStep("Click on Washer update button", () =>
            {
                Page.WashersPage.WashersListGridTable.Rows.LastOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            });
            Thread.Sleep(2000);
            Runner.DoStep("'Number of compartments' field should be enabled. Verify it.", () =>
            {
                if (!Page.WashersPage.NumberOfCompartments.IsEnabled)
                {
                    Assert.Fail(" 'Number of Compartments' field should be enabled");
                }
            });
            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(2000);
            Page.FormulasTabPage.AddFormulaButton.DeskTopMouseClick();
            Thread.Sleep(2000);
            Page.FormulasTabPage.FormulaNumber.TypeText(formulaNumber);
            Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nominalLoadForTunnel);
            Runner.DoStep("Create a Formula for the present washer group", () =>
            {
                Page.FormulasTabPage.Save.DeskTopMouseClick();
            });
            Thread.Sleep(2000);
            Page.WashersPage.WashersTab.Click();
            Page.WashersPage.WashersListGridTable.Rows.LastOrDefault().GetButtonControls().LastOrDefault().DeskTopMouseClick();
            Thread.Sleep(2000);
            Runner.DoStep("After creating a formula, the 'Number of compartments' field should be disabled for the washer. Verify it.", () =>
            {
                if (Page.WashersPage.NumberOfCompartments.IsEnabled)
                {
                    Assert.Fail(" 'Number of Compartments' field should be disabled");
                }
            });
            Thread.Sleep(2000);
        }
    }
}
