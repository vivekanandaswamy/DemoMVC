﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.RegressionTests.General
{
    public class MapMeterSensorToRedFlags : TestBase
    {

        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            AppState.GetState<MeterState>().DeleteAllMeters();
        }

        string testCaseId = null;
        string meterName = null;
        string utilityType = null;

        string washerGroup = null;
        string washerType = null;
        string washer = null;

        string utilityLocation = null;
        string machineCompartment = null;
        string controller = null;
        string sensorName = null;
        string sensorLocation = null;
        string sensorMachine = null;

        string redFlagCategory1 = null;
        string redFlagItem1 = null;
        string redFlagLocation1 = null;
        string redFlagMin1 = null;
        string redFlagMax1 = null;

        string redFlagCategory2 = null;
        string redFlagItem2 = null;
        string redFlagLocation2 = null;
        string redFlagMin2 = null;
        string redFlagMax2 = null;

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC01_MetersAndSensorsDeletion")]
        [Test]
        public void TC01_MetersAndSensorsDeletion()
        {                        
            DataTable dt = Excel.DataRead(testData, "MeterSensor");

            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == MethodBase.GetCurrentMethod().Name)
                {
                    testCaseId = row["TestCaseId"].ToString();
                    washerGroup = row["WasherGroup"].ToString();
                    washerType = row["WasherType"].ToString();
                    washer = row["Washer"].ToString();

                    meterName = row["MeterName"].ToString();
                    utilityType = row["UtilityType"].ToString();
                    utilityLocation = row["UtilityLocation"].ToString();
                    machineCompartment = row["MachineCompartment"].ToString();
                    controller = row["Controller"].ToString();
                    sensorName = row["SensorName"].ToString();
                    sensorLocation = row["SensorLocation"].ToString();
                    sensorMachine = row["SensorMachine"].ToString();

                    redFlagCategory1 = row["RedFlagCategory1"].ToString();
                    redFlagItem1 = row["RedFlagItem1"].ToString();
                    redFlagLocation1 = row["RedFlagLocation1"].ToString();
                    redFlagMin1 = row["RedFalgMin1"].ToString();
                    redFlagMax1 = row["RedFalgMax1"].ToString();

                    redFlagCategory2 = row["RedFlagCategory2"].ToString();
                    redFlagItem2 = row["RedFlagItem2"].ToString();
                    redFlagLocation2 = row["RedFlagLocation2"].ToString();
                    redFlagMin2 = row["RedFalgMin2"].ToString();
                    redFlagMax2 = row["RedFalgMax2"].ToString();

                    break;
                }
            }

            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CWGRedFlag(controller, washerGroup, washerType, washer);
            createMeterAndSensor();
            MapRedflags();

            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(1000);
            Page.PlantSetupPage.MeterTab.Click();
            Thread.Sleep(1000);
            int numOfMeters = Page.MetersTabPage.MetersTabGrid.Rows.Count;
            for (int i = 0; i <= numOfMeters; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Redflag Meter"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetButtonControls()[0].Click();
                    Page.MetersTabPage.DeleteMeterYes.Click();
                    if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText
                            .Contains(@"Unable to delete meter when a Red Flag is mapped to Location / Machine"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Unable to delete meter when a Red Flag is mapped to Location / Machine"
                                        + " but Actual: " + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                    break;
                }
            }

            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(1000);
            int numOfSensors = Page.SensorTabPage.SensorTableGrid.Rows.Count;
            for (int i = 0; i <= numOfSensors; i++)
            {
                if (Page.SensorTabPage.SensorTableGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[3].Value.Contains("Redflag Sensor"))
                {
                    Page.SensorTabPage.SensorTableGrid.Rows[i].GetButtonControls()[0].Click();
                    DialogHandler.FormulaYesButton.Click();
                    if (!Page.SensorTabPage.DeletionErrorMessage.BaseElement.InnerText
                            .Contains(@"Unable to delete sensor when a Red Flag is mapped to Location / Machine"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Unable to delete meter when a Red Flag is mapped to Location / Machine"
                                        + " but Actual: " + Page.SensorTabPage.DeletionErrorMessage.BaseElement.InnerText);
                    }
                    break;
                }
            }

            Page.PlantSetupPage.RedFlagTab.Click();
            Thread.Sleep(1000);
            Page.RedFlagTabPage.RedFlagTabGrid.SelectedRows("Redflag Meter").FirstOrDefault().GetButtonControls()[0].Click();
            DialogHandler.FormulaYesButton.Click();
            if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag deleted successfully"))
            {
                Assert.Fail("Incorrect error message is displayed,Expected: Red flag deleted successfully but Actual-" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
            }

            Thread.Sleep(1000);
            Page.RedFlagTabPage.RedFlagTabGrid.SelectedRows("Redflag Sensor").FirstOrDefault().GetButtonControls()[0].Click();
            DialogHandler.FormulaYesButton.Click();
            if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag deleted successfully"))
            {
                Assert.Fail("Incorrect error message is displayed,Expected: Red flag deleted successfully but Actual-" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
            }

            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(1000);
            Page.PlantSetupPage.MeterTab.Click();
            Thread.Sleep(1000);
            for (int i = 0; i <= numOfMeters; i++)
            {
                if (Page.MetersTabPage.MetersTabGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[5].Value.Contains("Redflag Meter"))
                {
                    Page.MetersTabPage.MetersTabGrid.Rows[i].GetButtonControls()[0].Click();
                    Page.MetersTabPage.DeleteMeterYes.Click();
                    Thread.Sleep(1000);
                    if (!Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText
                            .Equals(@"Meter Deleted Successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Meter deleted Successfully"
                                        + " but Actual:" + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                    break;
                }
            }

            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(1000);
            for (int i = 0; i <= numOfSensors; i++)
            {
                if (Page.SensorTabPage.SensorTableGrid.Rows[i].GetEditableControls()[2].BaseElement.ChildNodes[0].Attributes[3].Value.Contains("Redflag Sensor"))
                {
                    Page.SensorTabPage.SensorTableGrid.Rows[i].GetButtonControls()[0].Click();
                    DialogHandler.FormulaYesButton.Click();
                    Thread.Sleep(1000);
                    if (!Page.SensorTabPage.DeletionErrorMessage.BaseElement.InnerText
                            .Equals(@"Sensor Deleted Successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Sensor deleted Successfully"
                                        + " but Actual:" + Page.ContactsTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                    break;
                }
            }
        }

        private void MapRedflags()
        {
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.RedFlagTab.Click();
            Page.RedFlagTabPage.BtnAddRedFlag.Click();
            Thread.Sleep(2000);
            Page.RedFlagTabPage.CategoryAdd.SelectByPartialText("Resources", true);
            Page.RedFlagTabPage.DdlRedFlagItemAdd.Focus();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.SelectByPartialText("Gas consumption", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.DdlLocationAdd.Focus();
            Page.RedFlagTabPage.DdlLocationAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlLocationAdd.SelectByText("RedFlagWasherGroup", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.TxtMinimumRangeAdd.TypeText("34");
            Page.RedFlagTabPage.TxtMaximumRangeAdd.TypeText("56");
            Page.RedFlagTabPage.MeterSensor.SelectByText("Redflag Meter", Timeout);
            Page.RedFlagTabPage.SaveRedflag.Focus();
            Page.RedFlagTabPage.SaveRedflag.Click();
            Thread.Sleep(2000);
            Runner.DoStep("Verify the Redflag addition success message", () =>
            {
                if (null != Page.RedFlagTabPage.ErrorMsg)
                {
                    if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Red flag added successfully but Actual:" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
            Thread.Sleep(2000);

            Page.PlantSetupPage.RedFlagTab.Click();
            Page.RedFlagTabPage.BtnAddRedFlag.Click();
            Thread.Sleep(2000);
            Page.RedFlagTabPage.CategoryAdd.SelectByPartialText("Process Validation", true);
            Page.RedFlagTabPage.DdlRedFlagItemAdd.Focus();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlRedFlagItemAdd.SelectByText("pH", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.DdlLocationAdd.Focus();
            Page.RedFlagTabPage.DdlLocationAdd.ExtendedMouseClick();
            Page.RedFlagTabPage.DdlLocationAdd.SelectByText("RedFlagWasherGroup", true);
            Thread.Sleep(2000);
            Page.RedFlagTabPage.TxtMinimumRangeAdd.TypeText("34");
            Page.RedFlagTabPage.TxtMaximumRangeAdd.TypeText("56");
            Page.RedFlagTabPage.MeterSensor.SelectByText("Redflag Sensor", Timeout);
            Page.RedFlagTabPage.SaveRedflag.Focus();
            Page.RedFlagTabPage.SaveRedflag.Click();
            Thread.Sleep(2000);
            Runner.DoStep("Verify the Redflag addition success message", () =>
            {
                if (null != Page.RedFlagTabPage.ErrorMsg)
                {
                    if (!Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText
                        .Equals(@"Red flag added successfully"))
                    {
                        Assert.Fail("Incorrect error message is displayed,Expected: Red flag added successfully but Actual:" + Page.RedFlagTabPage.ErrorMsg.BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("Error message is not displayed");
                }
            });
        }

        private void createMeterAndSensor()
        {
            NavigateToMetersPage();
            Thread.Sleep(2000);
            Page.MetersTabPage.AddMeterButton.Click();
            Page.MetersTabPage.MeterName.SetText("Redflag Meter");
            Page.MetersTabPage.UtilityType.SelectByText("Gas", Timeout);
            Page.MetersTabPage.UtilityLocation.SelectByText("RedFlagWasherGroup", Timeout);
            Page.MetersTabPage.MachineCompartment.SelectByPartialText("RedFlagWasher", true);
            Page.MetersTabPage.UOM.SelectByIndex(1, Timeout);
            Page.MetersTabPage.Controller.SelectByPartialText("RedFlagDispenser", true);
            Page.MetersTabPage.AddMeterSaveButton.Click();
            Thread.Sleep(2000);
            if (!Page.ChemicalsTabPage.UpdateSuccessMessage.BaseElement.InnerText.Contains("Meter Added Successfully"))
            {
                Assert.Fail("Meter not added successfully");
            }
            Thread.Sleep(2000);
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.SensorTab.Click();
            Thread.Sleep(2000);
            Page.SensorTabPage.AddSensorButton.Click();
            Page.SensorTabPage.AddSensorButton.ScrollToVisible();
            Page.SensorTabPage.SensorName.TypeText("Redflag Sensor");
            Page.SensorTabPage.SensorType.SelectByIndex(2, Timeout);
            Page.SensorTabPage.SensorLocation.SelectByPartialText("RedFlagWasherGroup", true);
            Thread.Sleep(3000);
            Page.SensorTabPage.MachineName.SelectByPartialText("RedFlagWasher", true);
            Page.SensorTabPage.OutputType.SelectByIndex(1, Timeout);
            Page.SensorTabPage.UoM.SelectByIndex(1, Timeout);
            Thread.Sleep(2000);
            Runner.DoStep("Add a Sensor", () =>
            {
                Page.SensorTabPage.btnSave.Focus();
                KeyBoardSimulator.KeyPress(Keys.Enter);
            });
            Thread.Sleep(2000);

            if (Page.SensorTabPage.SensorAddedSuccess.BaseElement.InnerText.Contains("Sensor Added Successfully"))
            {
                Assert.True(true, "Sensor added successfully");
            }
            else
            {
                Assert.Fail("Sensor add success messgae not found");
            }
            Thread.Sleep(2000);
        }

        private void NavigateToMetersPage()
        {
            Page.LoginPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(2000);
            Page.PlantSetupPage.UtilityTab.Click();
            Thread.Sleep(2000);
            Page.PlantSetupPage.MeterTab.Click();
            KeyBoardSimulator.KeyPress(Keys.Tab);
            Thread.Sleep(2000);
        }
    }
}
