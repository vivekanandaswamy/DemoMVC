﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class FCColumnAvailability : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Thread.Sleep(1000);
        }

        [TestCategory(TestType.regression, "TC01_ValidatingColumnForMultipleUsers")]
        [Test]
        public void TC01_ValidatingColumnForMultipleUsers()
        {
            Runner.DoStep("Logout the user Admin", () =>
            {
                Page.PlantSetupPage.TopMainMenu.LogOut();
            });
            Dictionary<string, string> users = new Dictionary<string, string>();
            users.Add(Users.PManagerUser[0], Users.PManagerUser[1]);
            users.Add(Users.PEngineerUser[0], Users.PEngineerUser[1]);
            //users.Add(Users.OperatorUser[0], Users.OperatorUser[1]);
            users.Add(Users.CAManagerUser[0], Users.CAManagerUser[1]);
            users.Add(Users.BDManagerUser[0], Users.BDManagerUser[1]);
            users.Add(Users.TREcolabUser[0], Users.TREcolabUser[1]);
            users.Add(Users.TRCustomerUser[0], Users.TRCustomerUser[1]);
            users.Add(Users.EngineerUser[0], Users.EngineerUser[1]);
            users.Add(Users.TMAdvancedUser[0], Users.TMAdvancedUser[1]);
            users.Add(Users.TMBasicUser[0], Users.TMBasicUser[1]);
            users.Add(Users.AdminUser[0], Users.AdminUser[1]);
            foreach (KeyValuePair<string, string> pair in users)
            {
                Page.LoginPage.VerifyLogin(pair.Key, pair.Value);
                Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
                Thread.Sleep(2000);
                Runner.DoStep("Check if 'Formula Category' column is available for the user " + pair.Key + " in formulas table", () =>
                {
                    //if (pair.Key != "Operator")
                    //{
                    //    int numberofTabs = Page.FormulasTabPage.TabsForOperator.ChildNodes.Count;
                    //    if (numberofTabs > 1)
                    //    {
                    //        Assert.Fail("'Formula List' tab should not be available for Operator");
                    //    }
                    //    Page.PlantSetupPage.TopMainMenu.LogOut();
                    //}                    
                    //else 
                    //{
                    if (Page.FormulasTabPage.FormulasTab.IsEnabled)
                    {
                        Page.FormulasTabPage.FormulasTab.Click();
                        Thread.Sleep(2000);
                        if (!Page.FormulasTabPage.FormulasTableGrid.MainTable.HeadRows[0].BaseElement.InnerText.Contains("Formula Category"))
                        {
                            Assert.Fail(" 'Formula Category' column not available for {0}", pair.Key);
                        }
                        if (pair.Key != "Admin")
                        {
                            Page.PlantSetupPage.TopMainMenu.LogOut();
                        }
                    }
                    //}                    
                });
            }
        }
    }
}
