﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class ShiftsBreakTime : TestBase
    {
        /// <summary>
        /// Tests the fixture.
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Runner.DoStep("Navigate to Shifts tab in Plant Setup page", () =>
            {
                Page.ShiftTabPage.ShiftTab.Click();
            });
        }

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC01_AddShiftWith15mntsBreakTime")]
        [Test]
        public void TC01_AddShiftWith15mntsBreakTime()
        {
            //string testCaseId = null;
            string shiftName = null;
            string targetProduction = null;
            string shiftStartTime = null;
            string shiftEndTime = null;
            string breakStartTime = null;
            string breaktEndTime = null;
            string dayInWeek = null;

            DataTable dt = Excel.DataRead(testData, "ShiftsBreakTime");

            foreach (DataRow row in dt.Rows)
            {
                if (row["Test case ID"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {
                    //testCaseId = row["Test case ID"].ToString();
                    shiftName = row["Shift name"].ToString();
                    targetProduction = row["Target production"].ToString();
                    shiftStartTime = row["Shift start time"].ToString();
                    shiftStartTime = shiftStartTime.Substring(1, 5);
                    shiftEndTime = row["Shift end time"].ToString();
                    shiftEndTime = shiftEndTime.Substring(1, 5);
                    breakStartTime = row["Break start time"].ToString();
                    breakStartTime = breakStartTime.Substring(1, 5);
                    breaktEndTime = row["Break end time"].ToString();
                    breaktEndTime = breaktEndTime.Substring(1, 5);
                    dayInWeek = row["Day in week"].ToString();
                    break;
                }
            }

            Page.ShiftTabPage.DeleteAllShifts();

            Page.ShiftTabPage.AddShift.Click();

            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Thursday, DayOfWeek.Friday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText(shiftName);
            Page.ShiftTabPage.TargetProductionTextBox.TypeText(targetProduction);
            Page.ShiftTabPage.ShiftFromTime.TypeText(shiftStartTime);
            Page.ShiftTabPage.ShiftToTime.TypeText(shiftEndTime);
            Runner.DoStep("Add a Shift with no break(s)", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });
            Runner.DoStep("Verify that the NO BREAKS FOUND message has arrived", () =>
            {
                if (null != Page.ShiftTabPage.NoBreakMessage(dayInWeek, shiftName))
                {
                    if (!Page.ShiftTabPage.NoBreakMessage(dayInWeek, shiftName).BaseElement.InnerText
                        .Equals("No Breaks Found"))
                    {
                        Assert.Fail("No breaks found message is incorrect: Actual:{0}", Page.ShiftTabPage.NoBreakMessage(dayInWeek, shiftName).BaseElement.InnerText);
                    }
                }
                else
                {
                    Assert.Fail("No breaks found message is not displayed");
                }
            });

            Page.ShiftTabPage.ShiftEditButton(dayInWeek, shiftName).Click();
            Page.ShiftTabPage.AddBreak.Click();
            Page.ShiftTabPage.BreakFromTime.FirstOrDefault().TypeText(breakStartTime);
            Page.ShiftTabPage.BreakToTime.FirstOrDefault().TypeText(breaktEndTime);
            Runner.DoStep("Add a 15 minutes break to the above shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.TypeEnterKey();
            });
            Runner.DoStep("Verify that the break has been added", () =>
            {
                if (null != Page.ShiftTabPage.ShiftTexts(dayInWeek, shiftName))
                {
                    if (!Page.ShiftTabPage.ShiftTexts(dayInWeek, shiftName).Contains(breakStartTime + " to " + breaktEndTime))
                    {
                        Assert.Fail("Shift text for " + dayInWeek + " is not correct , Actual:{0}", Page.ShiftTabPage.ShiftTexts(dayInWeek, shiftName).FirstOrDefault());
                    }
                }
                else
                {
                    Assert.Fail("Shift message is not displayed in shift page");
                }
            });
        }

    }
}
