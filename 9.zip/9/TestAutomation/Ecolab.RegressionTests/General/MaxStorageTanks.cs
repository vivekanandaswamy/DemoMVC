﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class MaxStorageTanks : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);            
        }

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC01_ValidateMaxStorageTanks")]
        [Test]
        public void TC01_ValidateMaxStorageTanks()
        {
            //int iii = Page.StorageTanksTabPage.StorageTanksCount.BaseElement.ChildNodes.Count;            
            DataTable dt = Excel.DataRead(testData, "Storage Tank");
            string testCaseId = null;
            string stroageTank = null;
            string dispenser = null;
            string lowLevel = null;
            string emptyLevel = null;
            string callibrationLevel = null;

            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {
                    testCaseId = row["TestCaseId"].ToString();
                    dispenser = row["Dispenser"].ToString();
                    stroageTank = row["StroageTank"].ToString();
                    lowLevel = row["LowLevel"].ToString();
                    emptyLevel = row["EmptyLevel"].ToString();
                    callibrationLevel = row["CallibrationLevel"].ToString();
                    break;
                }

            }

            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.AddControllerAndStorageTanks(dispenser, stroageTank);

            Page.LoginPage.TopMainMenu.NavigateToStorageTanksPage();
            Runner.DoStep("Enter Storage tank details and click Save", () =>
            {
                Page.StorageTanksTabPage.AddStorageTanks.Click();
                Page.StorageTanksTabPage.TankName.TypeText(stroageTank);
                Page.StorageTanksTabPage.ProductName.SelectByIndex(1, Timeout);

                Page.StorageTanksTabPage.LowLevel.TypeText(lowLevel);
                Page.StorageTanksTabPage.EmptyLevel.TypeText(emptyLevel);
                Page.StorageTanksTabPage.CallibrationLevel.TypeText(callibrationLevel);

                Page.StorageTanksTabPage.InputType.SelectByIndex(1, Timeout);
                Page.StorageTanksTabPage.ControllerName.SelectByPartialText(dispenser, true);
                Page.StorageTanksTabPage.Save.DeskTopMouseClick();
            });


            Runner.DoStep("Edit the Low, Calibration and Empty level values and click Save", () =>
            {
                Page.StorageTanksTabPage.Save.DeskTopMouseClick();
            });

            //Thread.Sleep(4000);
            Runner.DoStep("Verify the expected MAX STORAGE TANKS LIMIT message appeared or not", () =>
            {
                if (!Page.StorageTanksTabPage.MaxTanksReachedError.BaseElement.InnerText.Contains("Dispenser cannot have more than 8 Tanks"))
                {
                    Assert.Fail("Max Storage tanks for a Dispenser limit reached but the error message is not shown", true);
                }
            });
            Thread.Sleep(2000);
        }        
    }
}
