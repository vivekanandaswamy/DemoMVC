﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class DuplicateFormulaNumber : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            //base.TestFixture();
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);            
        }

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC1_ValidateAddingFormulasWithSameNumber")]
        [Test]
        public void TC1_ValidateAddingFormulasWithSameNumber()
        {
            DataTable dt = Excel.DataRead(testData, "FormulaNumber");
            string testCaseId = null;
            string noOfTanks = null;
            string formulaNumber = null;
            string nominalLoadForTunnel1 = null;
            string nominalLoadForTunnel2 = null;
            string dispenser = null;
            string transferType = null;
            string press = null;
            string washerGrouptype = null;
            string washerGroupName = null;

            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {
                    testCaseId = row["TestCaseId"].ToString();
                    dispenser = row["Dispenser"].ToString();
                    washerGrouptype = row["WasherGroupType"].ToString();
                    washerGroupName = row["WasherGroupName"].ToString();
                    transferType = row["TransferType"].ToString();
                    press = row["Press"].ToString();
                    noOfTanks = row["NoOfTanks"].ToString();
                    formulaNumber = row["FormulaNumber"].ToString();
                    nominalLoadForTunnel1 = row["NominalLoadForTunnel1"].ToString();
                    nominalLoadForTunnel2 = row["NominalLoadForTunnel2"].ToString();
                    break;
                }
            }
            Ecolab.AppStateHandler.StateTransformation.ControllerTransform.CreateDispenserAndATunnelWasherGroup2(dispenser, washerGrouptype, washerGroupName);

            Runner.DoStep("Create an AB tunnel washer", () =>
            {
                Page.PlantSetupPage.TopMainMenu.NavigateToWasherGroupsPage();
                Thread.Sleep(1000);
                int washerGroupNumber = 0;
                DataTable myTable = DBValidation.GetDataTable(string.Format("select * from tcd.WasherGroup where WasherGroupName = '{0}'", washerGroupName));
                foreach (DataRow dr in myTable.Rows)
                {
                    washerGroupNumber = Convert.ToInt32(dr["WasherGroupNumber"].ToString());
                }
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().ScrollToVisible();
                Page.WasherGroupPage.WasherGroupTableGrid.SelectedRows(washerGroupNumber.ToString())[0].GetButtonControls().LastOrDefault().DeskTopMouseClick();
                Page.WasherGroupPage.BtnSaveAdd.DeskTopMouseClick();
                Page.WashersPage.DdlModel.Focus();
                Page.WashersPage.DdlModel.SelectByIndex(1, Timeout);
                Page.WashersPage.DdlController.SelectByPartialText(dispenser, true);
                Page.WashersPage.TxtName.TypeText(DateTime.Now.ToString());
                Random random = new Random();
                Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                Page.WashersTunnelGeneralPage.NoOfTanks.TypeText(noOfTanks);
                Page.WashersPage.DdlTransferType.SelectByText(transferType, true);
                Page.WashersPage.DdlPress.Focus();
                Page.WashersPage.DdlPress.SelectByText(press, true);
                Page.WashersPage.TxtProgramNo.TypeText(random.Next(0, 99).ToString());
                Page.WashersPage.BtnSaveTunnel.Click();
                Thread.Sleep(3000);
                if (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."))
                {
                    do
                    {
                        Page.WashersPage.TxtPlantWasher.TypeText(random.Next(1, 29999).ToString());
                        Page.WashersPage.BtnSaveTunnel.Click();
                        Thread.Sleep(3000);
                    } while (Page.WashersPage.ErrorMessageTunnel.BaseElement.InnerText.Contains("Specified Plant Washer Number or Name already exists."));
                }
            });

            // validating Formulas With Same Numbers

            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(1000);
            Page.FormulasTabPage.AddFormulaButton.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulaNumber.TypeText(formulaNumber);
            Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nominalLoadForTunnel1);
            Runner.DoStep("Add a Formula for the created washer", () =>
            {
                Page.FormulasTabPage.Save.DeskTopMouseClick();
            });
            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulasTab.Click();
            Thread.Sleep(1000);
            Page.FormulasTabPage.AddFormulaButton.DeskTopMouseClick();
            Thread.Sleep(1000);
            Page.FormulasTabPage.FormulaNumber.TypeText(formulaNumber);
            Page.FormulasTabPage.SelectFormulaName.SelectByIndex(1, Timeout);
            Page.FormulasTabPage.NominalLoadForTunnel.TypeText(nominalLoadForTunnel2);
            Runner.DoStep("Try adding another formula with the same number", () =>
            {
                Page.FormulasTabPage.Save.DeskTopMouseClick();
            });
            Thread.Sleep(2000);
            Runner.DoStep("Verify that the duplicate fromula addition error message has arrived", () =>
            {
                if (!Page.FormulasTabPage.ErrorMessage.BaseElement.InnerText.Contains("Formula Number already exists"))
                {
                    Assert.Fail("Error message when trying to add a formula with existing formula number isn't displayed");
                }
            });
        }      
    }
}
