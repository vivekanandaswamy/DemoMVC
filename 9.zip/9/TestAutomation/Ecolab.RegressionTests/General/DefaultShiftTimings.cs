﻿using Ecolab.AppStateHandler;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests.General
{
    public class DefaultShiftTimings : TestBase
    {
        [TestFixtureSetUp]
        public void TestFixture()
        {
            Console.WriteLine("Test Fixture overridden");
            Telerik.ActiveBrowser.NavigateTo(TCDAppUrl);
            Page.LoginPage.VerifyLogin(Users.AdminUser[0], Users.AdminUser[1]);
            Page.PlantSetupPage.TopMainMenu.NavigateToPlantSetupPage();
            Runner.DoStep("Navigate to Shifts tab in Plant Setup page", () =>
            {
                Page.ShiftTabPage.ShiftTab.Click();
            });
        }

        static string testData = TestDataPath + Excel.ExcelName;

        [TestCategory(TestType.regression, "TC1_DefaultStartTimesOfSecondAndThirdShits")]
        [Test]
        public void TC1_DefaultStartTimesOfSecondAndThirdShits()
        {

            string str = testDataFile.Tables["ShiftDetails"].Rows[0].ItemArray[3].ToString();

            DataTable dt = Excel.DataRead(testData, "ShiftDetails");
            string testCaseId = null;
            string shiftName1 = null;
            string targetProduction1 = null;
            string shiftFromTime1 = null;
            string shiftToTime1 = null;
            string shiftName2 = null;
            string targetProduction2 = null;
            string shiftToTime2 = null;

            foreach (DataRow row in dt.Rows)
            {
                if (row["TestCaseId"].ToString() == System.Reflection.MethodBase.GetCurrentMethod().Name)
                {
                    testCaseId = row["TestCaseId"].ToString();
                    shiftName1 = row["ShiftName1"].ToString();
                    targetProduction1 = row["TargetProduction1"].ToString();
                    shiftFromTime1 = row["ShiftFrom1"].ToString();
                    shiftToTime1 = row["ShiftTo1"].ToString();
                    shiftName2 = row["ShiftName2"].ToString();
                    targetProduction2 = row["TargetProduction2"].ToString();
                    shiftToTime2 = row["ShiftTo2"].ToString();
                    break;
                }
            }

            Page.ShiftTabPage.DeleteAllShifts("Monday");

            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Sunday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText(shiftName1);
            Page.ShiftTabPage.TargetProductionTextBox.TypeText(targetProduction1);
            Page.ShiftTabPage.ShiftFromTime.TypeText(shiftFromTime1);
            Page.ShiftTabPage.ShiftToTime.TypeText(shiftToTime1);
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.DeskTopMouseClick();
            });

            Thread.Sleep(1000);
            Runner.DoStep("Verify the creation of the Shift", () =>
            {
                if (null != Page.ShiftTabPage.ShiftAddMessage)
                {
                    string message = Page.ShiftTabPage.ShiftAddMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Shift created successfully"))
                    {
                        Assert.Fail("Incorrect message is displayed while adding shift , Expected: Shift created successfully ,Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Shift added message is not displayed");
                }
            });

            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });
            Thread.Sleep(1000);
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Sunday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday });
            Page.ShiftTabPage.ShiftNameTextBox.TypeText(shiftName2);
            Page.ShiftTabPage.TargetProductionTextBox.TypeText(targetProduction2);
            Page.ShiftTabPage.ShiftFromTime.Focus();
            if (!Page.ShiftTabPage.ShiftFromTime.Value.Contains(shiftToTime1))
            {
                Assert.Fail("Start time not aligned with end time of previous shift");
            }
            Page.ShiftTabPage.ShiftToTime.TypeText(shiftToTime2);
            Runner.DoStep("Add a Shift", () =>
            {
                Page.ShiftTabPage.SaveShiftButton.DeskTopMouseClick();
            });
            Thread.Sleep(1000);
            Runner.DoStep("Verify the creation of the Shift", () =>
            {
                if (null != Page.ShiftTabPage.ShiftAddMessage)
                {
                    string message = Page.ShiftTabPage.ShiftAddMessage.BaseElement.InnerText;
                    if (!message.Contains(@"Shift created successfully"))
                    {
                        Assert.Fail("Incorrect message is displayed while adding shift , Expected: Shift created successfully ,Actual:{0}", message);
                    }
                }
                else
                {
                    Assert.Fail("Shift added message is not displayed");
                }
            });
            Runner.DoStep("Click on 'Add Shift' button", () =>
            {
                Page.ShiftTabPage.AddShift.Click();
            });
            Thread.Sleep(1000);
            Page.ShiftTabPage.UnSelectDay(new List<DayOfWeek> { DayOfWeek.Sunday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday });
            Page.ShiftTabPage.ShiftFromTime.Focus();

            if (!Page.ShiftTabPage.ShiftFromTime.Value.Contains(shiftToTime2))
            {
                Assert.Fail("Start time not aligned with end time of previous shift");
            }
        } 
    }
}
