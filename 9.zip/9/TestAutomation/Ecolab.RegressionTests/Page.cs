﻿using Ecolab.Pages;
using Ecolab.Pages.Pages;
using Ecolab.Pages.Pages.PlantSetupTab;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.RegressionTests
{
    public class Page
    {
        private List<object> utilsList = new List<object>();

        public Page(TestBase testBase)
        {
            //Telerik = testBase.Telerik;

            utilsList.Add(testBase.Telerik);
            utilsList.Add(testBase.KeyBoardSimulator);
            utilsList.Add(testBase.DialogHandler);
            utilsList.Add(testBase.DBValidation);
        }

        private LoginPage loginPage;
        public LoginPage LoginPage
        {
            get
            {
                if (null == loginPage)
                {
                    loginPage = new LoginPage(utilsList);
                }
                return loginPage;
            }
        }

        private PlantSetupPage plantSetupPage;
        public PlantSetupPage PlantSetupPage
        {
            get
            {
                if (null == plantSetupPage)
                {
                    plantSetupPage = new PlantSetupPage(utilsList);
                }
                return plantSetupPage;
            }
        }

        private MetersTabPage metersTabPage;
        public MetersTabPage MetersTabPage
        {
            get
            {
                if (null == metersTabPage)
                {
                    metersTabPage = new MetersTabPage(utilsList);
                }
                return metersTabPage;
            }
        }

        private ContactsTabPage contactsTabPage;
        public ContactsTabPage ContactsTabPage
        {
            get
            {
                if (null == contactsTabPage)
                {
                    contactsTabPage = new ContactsTabPage(utilsList);
                }
                return contactsTabPage;
            }
        }

        private CustomerTabPage customerTabPage;
        public CustomerTabPage CustomerTabPage
        {
            get
            {
                if (null == customerTabPage)
                {
                    customerTabPage = new CustomerTabPage(utilsList);
                }
                return customerTabPage;
            }
        }

        private SensorsTabPage sensorTabPage;
        public SensorsTabPage SensorTabPage
        {
            get
            {
                if (null == sensorTabPage)
                {
                    sensorTabPage = new SensorsTabPage(utilsList);
                }
                return sensorTabPage;
            }
        }

        private GeneralTabPage generalTabPage;
        public GeneralTabPage GeneralTabPage
        {
            get
            {
                if (null == generalTabPage)
                {
                    generalTabPage = new GeneralTabPage(utilsList);
                }
                return generalTabPage;
            }
        }

        private WETabPage wETabPage;
        public WETabPage WETabPage
        {
            get
            {
                if (null == wETabPage)
                {
                    wETabPage = new WETabPage(utilsList);
                }
                return wETabPage;
            }
        }

        private ProductionChart productionChart;
        public ProductionChart ProductionChart
        {
            get
            {
                if (null == productionChart)
                {
                    productionChart = new ProductionChart(utilsList);
                }
                return productionChart;
            }
        }

        private DryerTabPage dryerTabPage;
        public DryerTabPage DryerTabPage
        {
            get
            {
                if (null == dryerTabPage)
                {
                    dryerTabPage = new DryerTabPage(utilsList);
                }
                return dryerTabPage;
            }
        }

        private FinishersTabPage finishersTabPage;
        public FinishersTabPage FinishersTabPage
        {
            get
            {
                if (null == finishersTabPage)
                {
                    finishersTabPage = new FinishersTabPage(utilsList);
                }
                return finishersTabPage;
            }
        }

		private WasherGroupPage washerGroupPage;
		public WasherGroupPage WasherGroupPage
		{
			get
			{
				if (null == washerGroupPage)
				{
					washerGroupPage = new WasherGroupPage(utilsList);
				}
				return washerGroupPage;
			}
		}

        private WashersTunnelGeneralPage washersTunnelGeneralPage;
        public WashersTunnelGeneralPage WashersTunnelGeneralPage
        {
            get
            {
                if (null == washersTunnelGeneralPage)
                {
                    washersTunnelGeneralPage = new WashersTunnelGeneralPage(utilsList);
                }
                return washersTunnelGeneralPage;
            }
        }


        private ShiftTabPage shiftTabPage;
        public ShiftTabPage ShiftTabPage
        {
            get
            {
                if (null == shiftTabPage)
                {
                    shiftTabPage = new ShiftTabPage(utilsList);
                }
                return shiftTabPage;
            }
        }

        private PlantSetupTargetProductionPage plantSetupTargetProductionPage;
        public PlantSetupTargetProductionPage PlantSetupTargetProductionPage
        {
           get
            {
                if (null == plantSetupTargetProductionPage)
                {
                    plantSetupTargetProductionPage = new PlantSetupTargetProductionPage(utilsList);
                }
                return plantSetupTargetProductionPage;
            }
        }
       
        private ChemicalsTabPage chemicalsTabPage;
        public ChemicalsTabPage ChemicalsTabPage
        {
            get
            {
                if (null == chemicalsTabPage)
                {
                    chemicalsTabPage = new ChemicalsTabPage(utilsList);
                }
                return chemicalsTabPage;
            }
        }

        private FormulasTabPage formulasTabPage;
        public FormulasTabPage FormulasTabPage
        {
            get
            {
                if (null == formulasTabPage)
                {
                    formulasTabPage = new FormulasTabPage(utilsList);
                }
                return formulasTabPage;
            }
        }

        private ReportsTabPage reportsTabPage;
        public ReportsTabPage ReportsTabPage
        {
            get
            {
                if (null == reportsTabPage)
                {
                    reportsTabPage = new ReportsTabPage(utilsList);
                }
                return reportsTabPage;
            }
        }

        private DashboardSetupTabPage dashboardSetupTabPage;
        public DashboardSetupTabPage DashboardSetupTabPage
        {
            get
            {
                if (null == dashboardSetupTabPage)
                {
                    dashboardSetupTabPage = new DashboardSetupTabPage(utilsList);
                }
                return dashboardSetupTabPage;
            }
        }

        private RewashTabPage rewashTabPage;
        public RewashTabPage RewashTabPage
        {
            get
            {
                if (null == rewashTabPage)
                {
                    rewashTabPage = new RewashTabPage(utilsList);
                }
                return rewashTabPage;
            }
        }

		private UtilitySetupPage utilitySetupPage;
		public UtilitySetupPage UtilitySetupPage
		{
			get
			{
				if (null == utilitySetupPage)
				{
					utilitySetupPage = new UtilitySetupPage(utilsList);
				}
				return utilitySetupPage;
			}
		}

        private StorageTanksPage storageTanksTabPage;
        public StorageTanksPage StorageTanksTabPage
        {
            get
            {
                if (null == storageTanksTabPage)
                {
                    storageTanksTabPage = new StorageTanksPage(utilsList);
                }
                return storageTanksTabPage;
            }
        }

        private WasherGroupFormulasPage washerGroupFormulasPage;
        public WasherGroupFormulasPage WasherGroupFormulasPage
        {
            get
            {
                if (null == washerGroupFormulasPage)
                {
                    washerGroupFormulasPage = new WasherGroupFormulasPage(utilsList);
                }
                return washerGroupFormulasPage;
            }
        }

        private UserManagementTabPage userManagementTabPage;
        public UserManagementTabPage UserManagement
        {
            get
            {
                if (null == userManagementTabPage)
                {
                    userManagementTabPage = new UserManagementTabPage(utilsList);
                }
                return userManagementTabPage;
            }
        }

        private UtilityTabPage  manualInputUtilityTabPage;
        public UtilityTabPage ManualInputUtilityTabPage
        {
            get
            {
                if (null == manualInputUtilityTabPage)
                {
                    manualInputUtilityTabPage = new UtilityTabPage(utilsList);
                }
                return manualInputUtilityTabPage;
            }
        }

        private ProductionTabPage manualInputProductionTabPage;
        public  ProductionTabPage ManualInputProductionTabPage
        {
            get
            {
                if (null == manualInputProductionTabPage)
                {
                    manualInputProductionTabPage = new ProductionTabPage(utilsList);
                }
                return manualInputProductionTabPage;
            }
        }

        private BatchTabPage manualInputBatchTabPage;
        public  BatchTabPage ManualInputBatchTabPage
        {
            get
            {
                if (null == manualInputBatchTabPage)
                {
                    manualInputBatchTabPage = new BatchTabPage(utilsList);
                }
                return manualInputBatchTabPage;
            }
        }

        private RedFlagTabPage redFlagTabPage;
        public RedFlagTabPage RedFlagTabPage
        {
            get
            {
                if (null == redFlagTabPage)
                {
                    redFlagTabPage = new RedFlagTabPage(utilsList);
                }
                return redFlagTabPage;
            }
        }
        private  LabourTabPage manualInputLabourTabPage;
        public LabourTabPage ManualInputLabourTabPage
        {
            get
            {
                if (null == manualInputLabourTabPage)
                {
                    manualInputLabourTabPage = new LabourTabPage(utilsList);
                }
                return manualInputLabourTabPage;
            }
        }


        private ControllerSetupPage controllerSetupPage;
        public ControllerSetupPage ControllerSetupPage
        {
            get
            {
                if (null == redFlagTabPage)
                {
                    controllerSetupPage = new ControllerSetupPage(utilsList);
                }
                return controllerSetupPage;
            }
        }

        private ControllerGeneralSetupTabPage controllerGeneralSetupTabPage;
        public ControllerGeneralSetupTabPage ControllerGeneralSetupTabPage
        {
            get
            {
                if (null == redFlagTabPage)
                {
                    controllerGeneralSetupTabPage = new ControllerGeneralSetupTabPage(utilsList);
                }
                return controllerGeneralSetupTabPage;
            }
        }

        private ControllerAdvancedSetupPage controllerAdvancedSetupPage;
        public ControllerAdvancedSetupPage ControllerAdvancedSetupPage
        {
            get
            {
                if (null == redFlagTabPage)
                {
                    controllerAdvancedSetupPage = new ControllerAdvancedSetupPage(utilsList);
                }
                return controllerAdvancedSetupPage;
            }
        }

        private ControllerPumpValvesPage controllerPumpValvesPage;
        public ControllerPumpValvesPage ControllerPumpValvesPage
        {
            get
            {
                if (null == controllerPumpValvesPage)
                {
                    controllerPumpValvesPage = new ControllerPumpValvesPage(utilsList);
                }
                return controllerPumpValvesPage;
            }
        }


        private AlarmPage alarmPage;
        public AlarmPage AlarmPage
        {
            get
            {
                if (null == alarmPage)
                {
                    alarmPage = new AlarmPage(utilsList);
                }
                return alarmPage;
            }
        }        

        private MonitorSetupPage monitorSetupPage;
        public MonitorSetupPage MonitorSetupPage
        {
            get
            {
                if (null == monitorSetupPage)
                {
                    monitorSetupPage = new MonitorSetupPage(utilsList);
                }
                return monitorSetupPage;
            }
        }

        private PumpsValvesPage pumpsValvesPage;
        public PumpsValvesPage PumpsValvesPage
        {
            get
            {
                if (null == pumpsValvesPage)
                {
                    pumpsValvesPage = new PumpsValvesPage(utilsList);
                }
                return pumpsValvesPage;
            }
        }        

		private UserProfile userProfilePage;
		public UserProfile UserProfilePage
		{
			get
			{
				if (null == userProfilePage)
				{
					userProfilePage = new UserProfile(utilsList);
				}
				return userProfilePage;
			}
		}       

        private WashersPage washersPage;
        public WashersPage WashersPage
        {
            get
            {
                if (null == washersPage)
                {
                    washersPage = new WashersPage(utilsList);
                }
                return washersPage;
            }
        }

        private LabourCostTabPage labourCostTabPage;
        public LabourCostTabPage LabourCostTabPage
        {
            get
            {
                if (null == labourCostTabPage)
                {
                    labourCostTabPage = new LabourCostTabPage(utilsList);
                }
                return labourCostTabPage;
            }
        }
    }
}
