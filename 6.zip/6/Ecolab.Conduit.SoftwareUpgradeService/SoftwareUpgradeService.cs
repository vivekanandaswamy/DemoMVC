﻿// -----------------------------------------------------------------------
// <copyright file="SoftwareUpgradeService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>SoftwareUpgradeService </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Timers;
using Ecolab.Conduit.SoftwareUpgradeService.Properties;
using log4net;

namespace Ecolab.Conduit.SoftwareUpgradeService
{
    public partial class SoftwareUpgradeService : ServiceBase
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(SoftwareUpgradeService));

        Timer batchTimer;

        public SoftwareUpgradeService()
        {
            InitializeComponent();
        }

        internal void Start()
        {
            OnStart(null);
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                if (!Debugger.IsAttached)
                {
                    batchTimer = new Timer()
                    {
                        AutoReset = bool.Parse(Settings.Default.TimerAutoReset)
                    };

                    batchTimer.Start();
                    batchTimer.Elapsed += new System.Timers.ElapsedEventHandler(ReCallProcess);

                    Log.Info("SoftwareUpgradeService : Timer property set successfully. ");
                }
                else
                    ProcessIntegration();
            }
            catch (Exception ex)
            {
                Log.Error("OnStart", ex);
            }
        }

        private void ReCallProcess(object sender, ElapsedEventArgs e)
        {
			batchTimer.Stop();
            ProcessIntegration();
			batchTimer.Enabled = bool.Parse(Settings.Default.TimerEnabled);
			batchTimer.Interval = double.Parse(Settings.Default.TimerInterval);
			batchTimer.Start();
        }

        protected override void OnStop()
        {
            if (!Debugger.IsAttached)
                batchTimer.Stop();
            Log.Info("Service stopped.");
        }

        private static void ProcessIntegration()
        {
            try
            {
                Log.Info("SoftwareUpgradeService process started....");
                ProcessSoftwareUpgrade processSoftwareUpgrade = new ProcessSoftwareUpgrade();
                processSoftwareUpgrade.ProcessSoftwareUpgradation();
                System.Threading.Thread.Sleep(60);
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While process queue :" + socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured while process queue :" + ex);
            }
        }
    }
}
