﻿// -----------------------------------------------------------------------
// <copyright file="DbHelper.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>DbHelper </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SoftwareUpgradeService.DB
{
    using Nalco.Data.Common;

    /// <summary>
    /// Class for DbHelper
    /// </summary>
    class DbHelper
    {
        /// <summary>
        /// Initializes the connection.
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        public static void InitializeConnection(string connectionString)
        {
            DbContext.AddConnectionString(connectionString);
        }

        public static void InitializeConnection(string area, string connectionString)
        {
            DbContext.AddConnectionString(area, connectionString);
        }
    }
}
