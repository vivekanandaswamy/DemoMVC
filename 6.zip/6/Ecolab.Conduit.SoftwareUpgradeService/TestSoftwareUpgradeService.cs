﻿// -----------------------------------------------------------------------
// <copyright file="TestSoftwareUpgradeService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>TestSoftwareUpgradeService </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.Conduit.SoftwareUpgradeService
{
    public partial class TestSoftwareUpgradeService : Form
    {
        SoftwareUpgradeService objSoftwareUpgradeService = new SoftwareUpgradeService();
        public TestSoftwareUpgradeService()
        {
            InitializeComponent();
            Trace.Listeners.Add(new TestSoftwareUpgradeTraceListener(this.LogOutput));
        }

        private void btnStartService_Click(object sender, EventArgs e)
        {
            objSoftwareUpgradeService.Start();
        }

        private void btnStopService_Click(object sender, EventArgs e)
        {
            if (objSoftwareUpgradeService.CanStop)
            {
                objSoftwareUpgradeService.Stop();
            }
        }

        private void TestSoftwareUpgrade_Load(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
        }
    }

    internal class TestSoftwareUpgradeTraceListener : TraceListener
    {
        TextBox LogTextBox;
        public TestSoftwareUpgradeTraceListener(TextBox logTextBox)
        {
            LogTextBox = logTextBox;
        }

        public override void Write(string message)
        {
            if (LogTextBox.InvokeRequired)
            {
                LogTextBox.Invoke((MethodInvoker)delegate
                {
                    Write(message);
                });
                return;
            }

            LogTextBox.AppendText(message);
        }

        public override void WriteLine(string message)
        {
            Write(message);
            Write(Environment.NewLine);
        }
    }
}
