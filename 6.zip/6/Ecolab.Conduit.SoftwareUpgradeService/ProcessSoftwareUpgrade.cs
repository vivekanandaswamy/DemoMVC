﻿// -----------------------------------------------------------------------
// <copyright file="ProcessSoftwareUpgrade.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Process Software Upgrade </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SoftwareUpgradeService
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.PushHandler;
    using Ecolab.Models;
    using Ecolab.Models.SyncMessages;
    using Ecolab.Services;
    using Library.Helpers;
    using log4net;
    using Newtonsoft.Json;

    /// <summary>
    /// Process Software Upgrade Handler class
    /// </summary>
    public class ProcessSoftwareUpgrade
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog log = LogManager.GetLogger(typeof(ProcessSoftwareUpgrade));

        /// <summary>
        /// plantService
        /// </summary>
        private PlantService plantService = null;

        /// <summary>
        /// Plant Details
        /// </summary>
        private Plant plant = null;

        /// <summary>
        /// mlocalDirectory
        /// </summary>
        private string localDir = Path.GetTempPath();

        /// <summary>
        /// Process the software update
        /// </summary>
        public bool ProcessSoftwareUpgradation()
        {
            int errorCode;
            bool isDownloadSuccess;
            plantService = new PlantService();
            TimeSpan now = DateTime.Now.TimeOfDay;
            DayOfWeek day = DateTime.Now.DayOfWeek;
            DayOfWeek setDay = new DayOfWeek();
            plant = plantService.GetPlantDetails();
            setDay = (DayOfWeek)plant.DayId - 1;
            if (setDay != day)
            {
                return false;
            }
            else if (setDay == day)
            {
                if ((now < plant.StartTime) || (now > plant.EndTime))
                {
                    return false;
                }
            }
            string currentVersion = GetCurrentVersion();
            log.Info("Current version of conduit : " + currentVersion);

            List<SoftwareVersion> softwareVersion = GetRemoteVersion();
            log.Info("Version Available to Update: " + JsonConvert.SerializeObject(softwareVersion));

            if (softwareVersion != null && softwareVersion.Count > 0)
            {
                foreach (SoftwareVersion versionDetails in softwareVersion)
                {
                    if (currentVersion != versionDetails.VersionNumber.ToString())
                    {
                        isDownloadSuccess = this.BeginDownloadFromFtp(versionDetails.FolderPath);
                        if (isDownloadSuccess)
                        {
                            this.UnZipFiles(versionDetails.FolderPath);
                            errorCode = this.InstallUpdates(versionDetails.FolderPath, versionDetails.VersionNumber.ToString());
                            if (errorCode > 0)
                            {
                                this.DeleteDir(versionDetails.FolderPath);
                                this.GenerateAlarm(plant.EcoalabAccountNumber);
                                this.SaveSoftwareUpdateDetails(versionDetails.VersionNumber.ToString(), false);
                                return false;
                            }
                            else
                            {
                                this.DeleteDir(versionDetails.FolderPath);
                                this.SaveSoftwareUpdateDetails(versionDetails.VersionNumber.ToString(), true);
                            }
                        }
                        else
                        {
                            log.Info("File not Downloaded. Please try again later");
                            this.DeleteDir(versionDetails.FolderPath);
                            this.SaveSoftwareUpdateDetails(versionDetails.VersionNumber.ToString(), false);
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// SaveSoftwareUpdateDetails
        /// </summary>
        /// <param name="versionNumber">versionNumber</param>
        /// <param name="isSuccess">is success</param>
        private void SaveSoftwareUpdateDetails(string versionNumber, bool isSuccess)
        {
            try
            {
                plantService.SaveSoftwareUpdateDetails(versionNumber, isSuccess);
                log.Info("SaveSoftwareUpdateDetails:: software update version saved successfully.");
            }
            catch (SqlException ex)
            {
                log.Error("Error occured in updating software histroy Table" + ex.Message);
            }
        }

        /// <summary>
        /// ecoalabAccountNumber
        /// </summary>
        /// <param name="ecoalabAccountNumber">ecoalabAccountNumber</param>
        private void GenerateAlarm(string ecoalabAccountNumber)
        {
            try
            {
                this.plantService.GenerateAlarm(ecoalabAccountNumber);
                log.Info("Alarms generated.");
            }
            catch (SqlException ex)
            {
                log.Error("Alarm Generation Failed" + ex.Message);
            }
        }

        /// <summary>
        /// UnZipFiles
        /// </summary>
        /// <param name="localDir">the localDir</param>
        private void UnZipFiles(string localDir)
        {
            //string path = this.localDir + @"\" + localDir;
            string zipPath = string.Empty;
            string extractPath = this.localDir + @"\" + localDir;
            string[] files = Directory.GetFiles(this.localDir + @"\" + localDir);
            foreach (string file in files)
            {
                if (file.Contains(".zip"))
                {
                    zipPath = file;
                    System.IO.Compression.ZipFile.ExtractToDirectory(zipPath, extractPath);
                }
            }
            log.Info("UnZip successfull.");
        }

        /// <summary>
        /// InstallUpdates
        /// </summary>
        /// <param name="localDir">the local dir</param>        
        /// <param name="newVersion">The new version.</param>
        /// <returns>
        /// integer error code of running msi
        /// </returns>
        private int InstallUpdates(string localDir, string newVersion)
        {
            string path = this.localDir + @"\" + localDir;
            int errorCode = 0;
            if (File.Exists(path))
            {
                // This path is a file
                errorCode = ProcessFile(path, newVersion);
            }
            else if (Directory.Exists(path))
            {
                // This path is a directory
                errorCode = ProcessDirectory(path, newVersion);
            }
            else
            {
                log.Info(path + " is not a valid file or directory.");
            }
            log.Info("InstallUpdates:: errorCode: " + errorCode.ToString());
            return errorCode;
        }

        /// <summary>
        /// ProcessDirectory
        /// </summary>
        /// <param name="targetDirectory">targetDirectory</param>        
        /// <param name="newVersion">The new version.</param>
        /// <returns>
        /// returns eeror code
        /// </returns>
        private int ProcessDirectory(string targetDirectory, string newVersion)
        {
            int errorCode = 0;
            // Process the list of files found in the directory. 
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
            {
                errorCode = ProcessFile(fileName, newVersion);
                if (errorCode > 0)
                {
                    return errorCode;
                }
            }
            // Recurse into subdirectories of this directory. 
            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
            {
                ProcessDirectory(subdirectory, newVersion);
            }
            return errorCode;
        }

        /// <summary>
        /// ProcessFile
        /// </summary>
        /// <param name="path">ftp path.</param>        
        /// <param name="newVersion">The new version.</param>
        /// <returns>
        /// error code.
        /// </returns>
        private int ProcessFile(string path, string newVersion)
        {
            int errorCode = 0;
            try
            {
                Process myProcess = new Process();
                bool isPathContainsExtension = this.CheckExtension(path);
                if (isPathContainsExtension)
                {
                    myProcess.StartInfo.FileName = "msiexec.exe";
                    myProcess.EnableRaisingEvents = true;
                    myProcess.StartInfo.Arguments = string.Format(@"/i " + path + " /q");
                    myProcess.Start();
                    myProcess.WaitForExit();
                    Thread.Sleep(300);
                    log.Info(string.Format("Process exited with exit code {0}", myProcess.ExitCode));
                    errorCode = myProcess.ExitCode;
                    if (myProcess.ExitCode == 0)
                    {
                        this.UpdateVersionInConduit(newVersion);
                    }
                }
                else
                {
                    return errorCode = 1;
                }

                return errorCode;
            }
            catch (Exception ex)
            {
                log.Error("Upgrade not successfull: Error Occured:" + ex);
                return errorCode;
            }
        }

        /// <summary>
        /// UpdateVersionInConduit
        /// </summary>
        /// <param name="remoteVersion">remoteVersion</param>
        private void UpdateVersionInConduit(string remoteVersion)
        {
            PlantSettings plantSettings = new PlantSettings();
            plantSettings.PlantVersion = remoteVersion;
            plantSettings.EcolabAccountNumber = plant.EcoalabAccountNumber;
            plantService.UpdateVersionInConduit(plantSettings);
            byte[] resultBuffer = SerializeHelper.Serialize(plantSettings);
            Push.PushToCentral(resultBuffer, 0, (int)TcdAdminMessageTypes.TcdUpdatePlantVersion);
        }

        /// <summary>
        /// Get update remote version of the application from central db
        /// </summary>
        /// <returns>upated version of the app</returns>
        private List<SoftwareVersion> GetRemoteVersion()
        {
            List<SoftwareVersion> softwareVersion = new List<SoftwareVersion>();
            if (plant != null && !string.IsNullOrEmpty(plant.EcoalabAccountNumber))
            {
                string response = Push.FetchenVisionVersion(plant.EcoalabAccountNumber, (int)TcdAdminMessageTypes.TcdGetConduitVersion);
                softwareVersion = JsonConvert.DeserializeObject<List<SoftwareVersion>>(response);
                return softwareVersion;
            }
            else
            {
                log.Info("No conduit application available to update software.");
                return softwareVersion;
            }
        }

        /// <summary>
        /// Get the current version of the application from local db
        /// </summary>
        /// <returns>current version of the app</returns>
        private string GetCurrentVersion()
        {
            if (plant != null && !string.IsNullOrEmpty(plant.EcoalabAccountNumber))
            {
                PlantSettings plantSettings = plantService.GetPlantSettings(plant.EcoalabAccountNumber);
                log.Info("Plant Settings : " + JsonConvert.SerializeObject(plantSettings));
                return plantSettings.PlantVersion;
            }
            else
            {
                log.Info("No Local conduit application available to update software.");
                return string.Empty;
            }
        }

        /// <summary>
        /// BeginDownloadFromFtp
        /// </summary>
        /// <param name="folderPath">folderPath</param>
        private bool BeginDownloadFromFtp(string folderPath)
        {
            bool isDownloadComplete;
            string localDir = CheckAndCreateDir(folderPath);
            Dictionary<string, string> dicSyncConfigSettings = new Dictionary<string, string>();
            dicSyncConfigSettings = Push.GetConfigSettings("SoftWareUpdate");
            log.Info("Config Settings to push to central : " + JsonConvert.SerializeObject(dicSyncConfigSettings));
            FTPClient ftpClient = new FTPClient(dicSyncConfigSettings["FTPUrl"], dicSyncConfigSettings["FTPUserId"], dicSyncConfigSettings["FTPPassword"]);
            string[] filesDetails = ftpClient.GetFileList(folderPath);
            if (filesDetails != null)
            {
                foreach (string file in filesDetails)
                {
                    if (!(String.IsNullOrEmpty(file)))
                    {
                        string fileName = file.Split(' ').Last();
                        log.Info("Files download details: File Name " + fileName + " ,Folder path " + folderPath);
                        if (file.StartsWith("d", StringComparison.InvariantCultureIgnoreCase))
                        {
                            this.BeginDownloadFromFtp(folderPath + "/" + fileName);
                        }
                        else
                        {
                            isDownloadComplete = ftpClient.Download(fileName, folderPath, localDir);
                            if (!isDownloadComplete)
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// CheckAndCreateDir
        /// </summary>
        /// <param name="remoteDir">remoteDir</param>
        /// <returns>path</returns>
        private string CheckAndCreateDir(string remoteDir)
        {
            string path = localDir + @"\" + remoteDir;
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            return path;
        }

        /// <summary>
        /// Delete local directory after success of update
        /// </summary>
        /// <param name="remoteDir">remoteDir</param>
        /// <returns></returns>
        private string DeleteDir(string remoteDir)
        {
            string path = localDir + remoteDir;
            string[] directoryList = Directory.GetDirectories(localDir);
            string[] directory = Array.FindAll(directoryList, s => s.Equals(path));
            if (directory != null && directory.Length > 0)
            {
                foreach (string dir in directory)
                {
                    string[] fileList = Directory.GetFiles(dir);
                    if (fileList != null && fileList.Length > 0)
                    {
                        foreach (string files in fileList)
                        {
                            File.Delete(files);
                        }
                        Directory.Delete(dir);
                    }
                    else
                    {
                        Directory.Delete(dir);
                    }
                }
            }
            log.Info("DeleteDir:: directory delete successfully.");
            return path;
        }

        /// <summary>
        /// Checks the extension.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns></returns>
        private bool CheckExtension(string path)
        {
            string extensions = ConfigurationManager.AppSettings["FileType"];
            string[] extensionArray = extensions.Split(',');
            if (extensionArray != null)
            {
                foreach (string extension in extensionArray)
                {
                    if (!(String.IsNullOrEmpty(extension.TrimEnd())))
                    {
                        if (path.Contains(extension))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
    }

}