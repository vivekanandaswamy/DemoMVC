﻿// -----------------------------------------------------------------------
// <copyright file="FTPClient.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FTP Client </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SoftwareUpgradeService
{
    using System;
    using System.IO;
    using System.Net;
    using System.Text;
    using log4net;

    public class FTPClient
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ProcessSoftwareUpgrade));
        private string host = null;
        private string loginUser = null;
        private string password = null;
        private FtpWebRequest ftpRequest = null;
        private FtpWebResponse ftpResponse = null;
        private Stream ftpStream = null;
        private int bufferSize = 2048;        

        /// <summary>
        /// parametrzed constructor
        /// </summary>
        /// <param name="hostIP">Host url</param>
        /// <param name="userName">userName</param>
        /// <param name="password">Password</param>
        public FTPClient(string hostIP, string userName, string password)
        {
            host = hostIP;
            loginUser = userName;
            this.password = password;
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public FTPClient()
        {
            // TODO: Complete member initialization
        }

        /// <summary>
        /// Download
        /// </summary>
        /// <param name="fileName">the file Name</param>
        /// <param name="remoteDirectory">the remote dir.</param>
        /// <param name="localDirectory">the local dir</param>
        public bool Download(string fileName, string remoteDirectory, string localDirectory)
        {
            bool returnValue = true;
            try
            {
                /* Create an FTP Request */
                ftpRequest = (FtpWebRequest)FtpWebRequest.Create("ftp://" + host + "/" + remoteDirectory + "/" + fileName);
                /* Log in to the FTP Server with the User Name and Password Provided */
                ftpRequest.Credentials = new NetworkCredential(loginUser, password);
                /* When in doubt, use these options */
                ftpRequest.UseBinary = true;
                ftpRequest.UsePassive = true;
                ftpRequest.KeepAlive = true;
                ftpRequest.Timeout = -1;
                /* Specify the Type of FTP Request */
                ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                /* Establish Return Communication with the FTP Server */
                ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                /* Get the FTP Server's Response Stream */
                ftpStream = ftpResponse.GetResponseStream();
                /* Open a File Stream to Write the Downloaded File */
                FileStream localFileStream = new FileStream(localDirectory + "\\" + fileName, FileMode.Create);
                /* Buffer for the Downloaded Data */
                byte[] byteBuffer = new byte[bufferSize];
                int bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                /* Download the File by Writing the Buffered Data Until the Transfer is Complete */
                try
                {
                    while (bytesRead > 0)
                    {
                        localFileStream.Write(byteBuffer, 0, bytesRead);
                        bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error Occured while reading file: " + ex.ToString());
                    returnValue = false;
                }
                /* Resource Cleanup */
                localFileStream.Close();
                ftpStream.Close();
                ftpResponse.Close();
                ftpRequest = null;
            }
            catch (Exception ex)
            {
                Log.Error("Error Occured while downloading file: " + ex.ToString());
                returnValue = false;
            }
            return returnValue;
        }

        /// <summary>
        /// GetFileList
        /// </summary>
        /// <param name="remoteDir">remoteDir</param>
        /// <returns>list of files in string format</returns>
        public string[] GetFileList(string remoteDir)
        {
            string[] downloadFiles;
            StringBuilder result = new StringBuilder();
            WebResponse response = null;
            StreamReader reader = null;
            try
            {
                FtpWebRequest reqFTP;
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + host + "/" + remoteDir + "/"));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(loginUser, password);
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectoryDetails;
                reqFTP.Proxy = null;
                reqFTP.KeepAlive = false;
                reqFTP.UsePassive = false;
                response = reqFTP.GetResponse();
                reader = new StreamReader(response.GetResponseStream());
                string line = reader.ReadLine();
                while (line != null)
                {
                    result.Append(line);
                    result.Append("\n");
                    line = reader.ReadLine();
                }
                result.Remove(result.ToString().LastIndexOf('\n'), 1);
                return result.ToString().Split('\n');
            }
            catch (Exception ex)
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (response != null)
                {
                    response.Close();
                }
                Log.Error("Error Occured while fetching the list of files:" + ex.ToString());
                downloadFiles = null;
                return downloadFiles;
            }
        }
    }
}
