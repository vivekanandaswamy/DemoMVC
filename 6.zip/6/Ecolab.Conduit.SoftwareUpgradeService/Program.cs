﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Main </summary>
// -----------------------------------------------------------------------

using System.Configuration;
using System.Diagnostics;
using System.ServiceProcess;
using System.Windows.Forms;

namespace Ecolab.Conduit.SoftwareUpgradeService
{
    using DB;
    using PushHandler;
    using Services.Infra;

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            log4net.Config.XmlConfigurator.Configure();
            Push.LoggerName = "SoftwareUpgradeService";
            DbHelper.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            AutoMapper.Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
            if (Debugger.IsAttached)
            {
                using (TestSoftwareUpgradeService form = new TestSoftwareUpgradeService())
                {
                    Application.Run(form);
                }
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] 
            { 
                new SoftwareUpgradeService() 
            };
                log4net.Config.XmlConfigurator.Configure();
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}
