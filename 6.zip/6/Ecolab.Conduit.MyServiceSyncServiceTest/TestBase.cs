﻿// -----------------------------------------------------------------------
// <copyright file="TestBase.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Base class for Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncServiceTest
{
    using System;
    using Ecolab.Data.Access;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess.DB;
    using System.Configuration;
    using Ecolab.Services.Infra;

    /// <summary>
    /// Test Base Class
    /// </summary>
    [TestClass]
    public class TestBase
    {
        [TestInitialize]
        public void Init()
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            DbHelper.InitializeConnection(ConfigurationManager.ConnectionStrings["MyServiceConnection"].ToString());
            AutoMapper.Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
        }
    }
}
