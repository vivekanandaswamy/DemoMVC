﻿// -----------------------------------------------------------------------
// <copyright file="PackageSizeTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PackageSize Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class PackageSizeTest : TestBase
    {
        [TestCategory("MyService Integration")]
        [Description("UT to test Package Size Processor")]
        [TestMethod]
        public void PackageSizeMyServiceIntegrationTest()
        {
            var packageSizeProcessor = new PackageSizeProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });
            packageSizeProcessor.Save(plants);
        }
    }
}