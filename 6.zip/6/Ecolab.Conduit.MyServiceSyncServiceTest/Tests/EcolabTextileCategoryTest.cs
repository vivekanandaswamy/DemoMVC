﻿// -----------------------------------------------------------------------
// <copyright file="EcolabTextileCategoryTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The EcolabTextileCategory Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System;
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Common;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class EcolabTextileCategoryTest : TestBase
    {
        [TestMethod]
        public void EcolabTextileCategoryMyServiceIntegrationTest()
        {
            var ecolabTextileCategoryProcessor = new EcolabTextileCategoryProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            ecolabTextileCategoryProcessor.Save(plants);
        }

        [TestMethod]
        public void ProcessMyServiceEcolabTextileCategoryObjectTest()
        {
            var ecolabTextileCategoryProcessor = new EcolabTextileCategoryProcessor();

            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            var ecolabTextileCategorys = new List<EcolabTextileCategory>
            {
                new EcolabTextileCategory
                {
                    TextileId = 0,
                    CategoryName = "abc",
                    IsDeleted = true,
                    MyServiceMstrLnnTypId = 51,
                    MyServiceLastSynchTime = DateTime.Now
                },
                new EcolabTextileCategory
                {
                    TextileId = 0,
                    CategoryName = "def",
                    IsDeleted = false,
                    MyServiceMstrLnnTypId = 52,
                    MyServiceLastSynchTime = DateTime.Now
                },
                new EcolabTextileCategory
                {
                    TextileId = 0,
                    CategoryName = "ghi",
                    IsDeleted = true,
                    MyServiceMstrLnnTypId = 53,
                    MyServiceLastSynchTime = DateTime.Now
                }
            };

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "EcolabTextileCategory");

            ecolabTextileCategoryProcessor.ProcessMyServiceObject(plants, log, ecolabTextileCategorys);
        }
    }
}