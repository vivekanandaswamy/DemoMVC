﻿// -----------------------------------------------------------------------
// <copyright file="ProductCategoryTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ProductCategory Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System;
    using System.Collections.Generic;
    using Entities;
    using Entities.PlantSetup.Chemical;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Common;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class ProductCategoryTest : TestBase
    {

        [TestMethod]
        public void ProductCategoryMyServiceIntegrationTest()
        {
            var productCategoryProcessor = new ProductCategoryProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            productCategoryProcessor.Save(plants);
        }

        [TestMethod]
        public void ProcessMyServiceObjectTest()
        {
            var productCategoryProcessor = new ProductCategoryProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });
            var myServiceTestData = new List<ProductMaster>
            {
                new ProductMaster
                {
                    ProductcategoryName = "aaa",
                    IsDelete = false,
                    MyServiceProdCatId = 1000
                },
                new ProductMaster
                {
                    ProductcategoryName = "bbb",
                    IsDelete = false,
                    MyServiceProdCatId = 1002
                },
                new ProductMaster
                {
                    ProductcategoryName = "ccc",
                    IsDelete = false,
                    MyServiceProdCatId = 1003
                },
                new ProductMaster
                {
                    ProductcategoryName = "ddd",
                    IsDelete = false,
                    MyServiceProdCatId = 1004
                }
            };
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(string.Empty, "ProductCategory");
            productCategoryProcessor.ProcessMyServiceObject(plants, log, myServiceTestData);
        }

        [TestMethod]
        public void InsertOrUpdateProductCategoryDetailsTest()
        {
            var productCategoryProcessor = new ProductCategoryProcessor();

            var productMaster = new ProductMaster
            {
                ProductcategoryName = "eee",
                IsDelete = false,
                MyServiceProdCatId = 1005
            };

            productCategoryProcessor.InsertOrUpdateProductCategoryDetails(productMaster);
        }

        [TestMethod]
        public List<ProductMaster> GetMyServiceProductCategoryDetailsTest()
        {
            var productCategoryProcessor = new ProductCategoryProcessor();
            List<ProductMaster> productMaster = new List<ProductMaster>();
            productMaster = productCategoryProcessor.GetMyServiceProductCategoryDetails(DateTime.Now.AddYears(-100));
            return productMaster;
        }
    }
}
