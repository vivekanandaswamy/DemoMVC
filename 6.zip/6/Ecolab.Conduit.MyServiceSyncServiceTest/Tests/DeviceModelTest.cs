﻿// -----------------------------------------------------------------------
// <copyright file="DeviceModelTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The DeviceModel Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Entities;
    using Entities.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Common;
    using MyServiceSyncService.Processor;    

    [TestClass]
    public class DeviceModelTest : TestBase
    {
        [TestMethod]
        public void DeviceModelMyServiceIntegrationTest()
        {
            var deviceModelProcessor = new DeviceModelProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            deviceModelProcessor.Save(plants);
        }

        [TestMethod]
        public void ProcessMyServiceDeviceModelObjectTest()
        {
            var deviceModelProcessor = new DeviceModelProcessor();

            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            var deviceModels = new List<DeviceModel>
            {
                new DeviceModel
                {
                    DeviceModelId = 0,
                    Description = "abc",
                    DeviceTypeId = 1,
                    IsDeleted = true,
                    MyServiceWtrEnrgDvcId = 71,
                    RegionCode = "NA",
                    MyServiceLastSynchTime = DateTime.Now
                },
                new DeviceModel
                {
                    DeviceModelId = 0,
                    Description = "def",
                    DeviceTypeId = 2,
                    IsDeleted = false,
                    MyServiceWtrEnrgDvcId = 72,
                    RegionCode = "EMEA",
                    MyServiceLastSynchTime = DateTime.Now
                },
                new DeviceModel
                {
                    DeviceModelId = 0,
                    Description = "lmn",
                    DeviceTypeId = 3,
                    IsDeleted = true,
                    MyServiceWtrEnrgDvcId = 73,
                    RegionCode = "APLA",
                    MyServiceLastSynchTime = DateTime.Now
                }
            };

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), "DeviceModel");

            deviceModelProcessor.ProcessMyServiceObject(plants, log, deviceModels);
        }

        [TestMethod]
        public void InsertOrUpdateDeviceModelTest()
        {
            var deviceModelProcessor = new DeviceModelProcessor();

            var deviceModel = new DeviceModel
            {
                DeviceModelId = 0,
                Description = "xyz",
                DeviceTypeId = 4,
                IsDeleted = false,
                MyServiceWtrEnrgDvcId = 74,
                RegionCode = "NA",
                MyServiceLastSynchTime = DateTime.Now
            };

            int deviceModelId = deviceModelProcessor.InsertOrUpdateDeviceModelDetails(deviceModel);

            Assert.AreEqual(deviceModel.DeviceModelId, deviceModelId);
        }

        [TestMethod]
        public void GetMyServiceDeviceModelsTest()
        {
            var deviceModelProcessor = new DeviceModelProcessor();

            deviceModelProcessor.GetMyServiceDeviceModelDetails(DateTime.Now.AddYears(-100));
        }
    }
}