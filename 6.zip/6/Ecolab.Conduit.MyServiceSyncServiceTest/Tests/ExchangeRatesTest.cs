﻿// -----------------------------------------------------------------------
// <copyright file="ExchangeRatesTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ExchangeRates Test  class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;
    using System.Collections.Generic;

    [TestClass]
    public class ExchangeRatesTest : TestBase
    {
        [TestMethod]
        public void ExchangeRatesMyServiceIntegrationTest()
        {
            var exchangeRatesProcessor = new ExchangeRatesProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            exchangeRatesProcessor.Save(plants);
        }
    }
}
