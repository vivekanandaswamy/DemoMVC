﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSizeTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The WasherModelSize Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class WasherModelSizeTest : TestBase
    {
        [TestMethod]
        public void TestWasherModelSize()
        {
            var washerModelSizeProcessor = new WasherModelSizeProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });
            washerModelSizeProcessor.Save(plants);
        }
    }
}