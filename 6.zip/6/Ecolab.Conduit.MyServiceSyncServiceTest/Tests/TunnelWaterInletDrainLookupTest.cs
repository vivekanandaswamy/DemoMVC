﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWaterInletDrainLookupTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelWaterInletDrainLookup Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System;
    using System.Collections.Generic;
    using Entities;
    using Entities.Washers.Tunnel;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Common;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class TunnelWaterInletDrainLookupTest : TestBase
    {
        [TestMethod]
        public void TestTunnelWaterInletDrainLookup()
        {
            var tunnelWaterInletDrainLookupProcessor = new TunnelWaterInletDrainLookupProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });
            tunnelWaterInletDrainLookupProcessor.Save(plants);
        }

        [TestMethod]
        public void TestProcessMyServiceData()
        {
            var tunnelWaterInletDrainLookupProcessor = new TunnelWaterInletDrainLookupProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });
            var myServiceTestData = new List<PressExtractor>
            {
                new PressExtractor
                {
                    Name = "aaa",
                    EcolabAccountNumber = "0500232537",
                    Id = 0,
                    IsDeleted = false,
                    MyServiceModDtTm = DateTime.Now,
                    MyServicePropId = 1,
                    RegionCode = "NA"
                },
                new PressExtractor
                {
                    Name = "bbb",
                    EcolabAccountNumber = "0500232537",
                    Id = 0,
                    IsDeleted = true,
                    MyServiceModDtTm = DateTime.Now,
                    MyServicePropId = 2,
                    RegionCode = "EMEA"
                },
                new PressExtractor
                {
                    Name = "ccc",
                    EcolabAccountNumber = "0500232537",
                    Id = 0,
                    IsDeleted = false,
                    MyServiceModDtTm = DateTime.Now,
                    MyServicePropId = 3,
                    RegionCode = "EMEA"
                },
                new PressExtractor
                {
                    Name = "ddd",
                    EcolabAccountNumber = "0500232537",
                    Id = 0,
                    IsDeleted = true,
                    MyServiceModDtTm = DateTime.Now,
                    MyServicePropId = 4,
                    RegionCode = "NA"
                }
            };
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails("1", "TunnelWaterInletDrainLookup");
            tunnelWaterInletDrainLookupProcessor.ProcessMyServiceData(plants, log, myServiceTestData);
        }

        [TestMethod]
        public void TestGetMyServiceTunnelWaterInletDrainLookupDetails()
        {
            var tunnelWaterInletDrainLookupProcessor = new TunnelWaterInletDrainLookupProcessor();
            tunnelWaterInletDrainLookupProcessor.GetMyServiceTunnelWaterInletDrainLookupDetails(
                DateTime.Now.AddYears(-100));
        }

        [TestMethod]
        public void TestInsertorUpdateTunnewlWaterInlet()
        {
            var tunnelWaterInletDrainLookupProcessor = new TunnelWaterInletDrainLookupProcessor();

            var gasOilTypes = new PressExtractor
            {
                Name = "aaa",
                EcolabAccountNumber = "0500232537",
                Id = 0,
                IsDeleted = false,
                MyServiceModDtTm = DateTime.Now,
                MyServicePropId = 1,
                RegionCode = "NA"
            };

            tunnelWaterInletDrainLookupProcessor.InsertOrUpdateTunnelWaterInletDrainLookupDetails(gasOilTypes);
        }
    }
}