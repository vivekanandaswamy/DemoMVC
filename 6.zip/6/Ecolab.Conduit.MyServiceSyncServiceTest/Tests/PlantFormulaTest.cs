﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PlantFormula Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Common;
    using MyServiceSyncService.Processor;

    /// <summary>
    /// Plant Formula test
    /// </summary>
    [TestClass]
    public class PlantFormulaTest : TestBase
    {
        /// <summary>
        /// Test Method for testing Save Method in PlantFormula Processor
        /// </summary>
        [TestMethod]
        public void TestSave()
        {
            PlantFormulaProcessor plantFormulaProcessor = new PlantFormulaProcessor();
            plantFormulaProcessor.Save("040000163");
        }

        /// <summary>
        /// Test Method for Testing SaveInConduitForFirstTimeSynch Method in PlantFormula Processor
        /// </summary>
        [TestMethod]
        public void TestSaveInConduitForFirstTimeSynch()
        {
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails("040000163", "PlantFormula");
            PlantFormulaProcessor plantFormulaProcessor = new PlantFormulaProcessor();
            DateTime myServiceDateTime = DateTime.Now.AddYears(-100);
            plantFormulaProcessor.SaveInConduitForFirstTimeSynch(myServiceDateTime,"040000163");
        }
    }
}
