﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The DrainDestination Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class DrainDestinationTest : TestBase
    {
        [TestMethod]
        public void DrainDestinationMyServiceIntegrationTest()
        {
            var drainDestinationProcessor = new DrainDestinationProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            drainDestinationProcessor.Save(plants);
        }
    }
}