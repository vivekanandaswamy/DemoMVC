﻿// -----------------------------------------------------------------------
// <copyright file="ProductMasterTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ProductMaster Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class ProductMasterTest : TestBase
    {
        [TestMethod]
        public void ProductMasterMyServiceIntegrationTest()
        {
            var productMasterProcessor = new ProductMasterProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            productMasterProcessor.Save(plants);
        }
    }
}