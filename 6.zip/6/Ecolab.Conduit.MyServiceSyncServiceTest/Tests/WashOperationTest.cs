﻿// -----------------------------------------------------------------------
// <copyright file="WashOperationTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The WashOperation Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System;
    using System.Collections.Generic;
    using Entities;
    using Entities.WasherGroup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Common;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class WashOperationTest : TestBase
    {
        [TestMethod]
        public void WashOperationMyServiceIntegrationTest()
        {
            var washOperationProcessor = new WashOperationProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            washOperationProcessor.Save(plants);
        }

        [TestMethod]
        public void ProcessMyServiceWashOperationObjectTest()
        {
            var washOperationProcessor = new WashOperationProcessor();

            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            var washOperations = new List<WashStep>
            {
                new WashStep
                {
                    StepId = 0,
                    StepName = "abc",
                    RegionCode = "NA",
                    IsActive = false,
                    IsTunnel = true,
                    MyServiceWshOpTypCd = "N",
                    MyServiceWshOpId = 301,
                    MyServiceLastSynchTime = DateTime.Now
                },
                new WashStep
                {
                    StepId = 0,
                    StepName = "def",
                    RegionCode = "EMEA",
                    IsActive = true,
                    IsTunnel = false,
                    MyServiceWshOpTypCd = "D",
                    MyServiceWshOpId = 302,
                    MyServiceLastSynchTime = DateTime.Now
                },
                new WashStep
                {
                    StepId = 0,
                    StepName = "jkl",
                    RegionCode = "APLA",
                    IsActive = false,
                    IsTunnel = true,
                    MyServiceWshOpTypCd = "N",
                    MyServiceWshOpId = 303,
                    MyServiceLastSynchTime = DateTime.Now
                }
            };

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "WashStep");

            washOperationProcessor.ProcessMyServiceObject(plants, log, washOperations);
        }

        [TestMethod]
        public void InsertOrUpdateWashOperationTest()
        {
            var washOperationProcessor = new WashOperationProcessor();

            var washOperation = new WashStep
            {
                StepId = 0,
                StepName = "xyz",
                RegionCode = "APLA",
                IsActive = true,
                IsTunnel = false,
                MyServiceWshOpTypCd = "D",
                MyServiceWshOpId = 304,
                MyServiceLastSynchTime = DateTime.Now
            };

            int washOperationId = washOperationProcessor.InsertOrUpdateWashOperationDetails(washOperation);

            Assert.AreEqual(washOperation.StepId, washOperationId);
        }

        [TestMethod]
        public void GetMyServiceWashOperationsTest()
        {
            var washOperationProcessor = new WashOperationProcessor();

            washOperationProcessor.GetMyServiceWashOperationDetails(DateTime.Now.AddYears(-100));
        }
    }
}