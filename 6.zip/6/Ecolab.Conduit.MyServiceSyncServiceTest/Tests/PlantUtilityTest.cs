﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PlantUtility Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class PlantUtilityTest : TestBase
    {
        [TestCategory("MyService Integration")]
        [Description("UT to test Package Size Processor")]
        [TestMethod]
        public void SyncDataWithInMyService()
        {
            var plantUtility = new PlantUtilityProcessor();
            plantUtility.Save("040259798");
        }
    }
}