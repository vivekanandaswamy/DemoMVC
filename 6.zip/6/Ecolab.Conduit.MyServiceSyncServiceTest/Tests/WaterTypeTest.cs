﻿// -----------------------------------------------------------------------
// <copyright file="WaterTypeTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The WaterType Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System;
    using System.Collections.Generic;
    using Entities;
    using Entities.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Common;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class WaterTypeTest : TestBase
    {
        [TestMethod]
        public void WaterTypeMyServiceIntegrationTest()
        {
            var waterTypeProcessor = new WaterTypeProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            waterTypeProcessor.Save(plants);
        }

        [TestMethod]
        public void ProcessMyServiceWaterTypeObjectTest()
        {
            var waterTypeProcessor = new WaterTypeProcessor();

            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            var waterTypes = new List<PlantUtilityWaterTypeMaster>
            {
                new PlantUtilityWaterTypeMaster
                {
                    WaterTypeId = 0,
                    WaterTypeName = "abc",
                    RegionCode = "NA",
                    IsDeleted = true,
                    MyServiceUtilId = 100,
                    MyServiceLastSynchTime = DateTime.Now
                },
                new PlantUtilityWaterTypeMaster
                {
                    WaterTypeId = 0,
                    WaterTypeName = "def",
                    RegionCode = "APLA",
                    IsDeleted = false,
                    MyServiceUtilId = 101,
                    MyServiceLastSynchTime = DateTime.Now
                },
                new PlantUtilityWaterTypeMaster
                {
                    WaterTypeId = 0,
                    WaterTypeName = "ghi",
                    RegionCode = "EMEA",
                    IsDeleted = true,
                    MyServiceUtilId = 102,
                    MyServiceLastSynchTime = DateTime.Now
                }
            };

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "WaterType");

            waterTypeProcessor.ProcessMyServiceObject(plants, log, waterTypes);
        }

        [TestMethod]
        public void InsertOrUpdateWaterTypeTest()
        {
            var waterTypeProcessor = new WaterTypeProcessor();

            var waterType = new PlantUtilityWaterTypeMaster
            {
                WaterTypeId = 0,
                WaterTypeName = "xyz",
                RegionCode = "NA",
                IsDeleted = true,
                MyServiceUtilId = 103,
                MyServiceLastSynchTime = DateTime.Now
            };

            int waterTypeId = waterTypeProcessor.InsertOrUpdateWaterTypeDetails(waterType);

            Assert.AreEqual(waterType.WaterTypeId, waterTypeId);
        }

        [TestMethod]
        public void GetMyServiceWaterTypesTest()
        {
            var waterTypeProcessor = new WaterTypeProcessor();

            waterTypeProcessor.GetMyServiceWaterTypeDetails(DateTime.Now.AddYears(-100));
        }
    }
}