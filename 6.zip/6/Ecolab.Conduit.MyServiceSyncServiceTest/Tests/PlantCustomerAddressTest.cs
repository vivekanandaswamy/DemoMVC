﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerAddressTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PlantCustomerAddress Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class PlantCustomerAddressTest : TestBase
    {
        [TestMethod]
        public void TestPlantCustomerAddress()
        {
            var plantCustomerAddressProcessor = new PlantCustomerAddressProcessor();
        }
    }
}