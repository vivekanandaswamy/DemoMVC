﻿// -----------------------------------------------------------------------
// <copyright file="ChainTextileCategoryTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ChainTextileCategory Test  class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using System.Configuration;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;    

    [TestClass]
    public class ChainTextileCategoryTest : TestBase
    {
        [TestMethod]
        public void ChainTextileCategoryMyServiceIntegrationTest()
        {
            var chainTextileCategoryProcessor = new ChainTextileCategoryProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber")
            });

            chainTextileCategoryProcessor.Save(plants);
        }
    }
}
