﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWaterFlowTypeTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelWaterFlowType Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class TunnelWaterFlowTypeTest : TestBase
    {
        [TestMethod]
        public void TunnelWaterFlowTypeMyServiceIntegrationTest()
        {
            var tunnelWaterFlowTypeProcessor = new TunnelWaterFlowTypeProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            tunnelWaterFlowTypeProcessor.Save(plants);
        }
    }
}