﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PlantChain Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class PlantChainTest : TestBase
    {
        [TestMethod]
        public void TestPlantChain()
        {
            var plantChainProcessor = new PlantChainProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });
            plantChainProcessor.Save(plants);
        }
    }
}