﻿// -----------------------------------------------------------------------
// <copyright file="EcolabSaturationTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The EcolabSaturation Test  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class EcolabSaturationTest : TestBase
    {
        [TestMethod]
        public void EcolabSaturationMyServiceIntegrationTest()
        {
            var ecolabSaturationProcessor = new EcolabSaturationProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });

            ecolabSaturationProcessor.Save(plants);
        }
    }
}