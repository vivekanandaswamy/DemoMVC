﻿// -----------------------------------------------------------------------
// <copyright file="GasOilTypesTest.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The GasOilTypes Test  class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using System.Collections.Generic;
    using Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    /// <summary>
    ///     Gas oil type test class
    /// </summary>
    [TestClass]
    public class GasOilTypesTest : TestBase
    {
        /// <summary>
        ///     Test Method to test Save Method
        /// </summary>
        [TestMethod]
        public void TestGasOilTypes()
        {
            var gasOilTypeProcessor = new GasOilTypesProcessor();
            var plants = new List<Plant>();
            plants.Add(new Plant
            {
                EcoalabAccountNumber = "0500232537"
            });
            gasOilTypeProcessor.Save(plants);
        }
    }
}