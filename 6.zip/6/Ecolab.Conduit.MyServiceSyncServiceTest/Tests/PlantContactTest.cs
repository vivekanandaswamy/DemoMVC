﻿namespace Ecolab.Conduit.MyServiceSyncServiceTest.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MyServiceSyncService.Processor;

    [TestClass]
    public class PlantContactTest : TestBase
    {
        [TestMethod]
        public void PlantContactIntegrationTestForDisconnectedMode()
        {
            var plantContactProcessor = new PlantContactProcessor();
            plantContactProcessor.Save("0500669005");
        }

        [TestMethod]
        public void PlantContactIntegrationTestForConnectedMode()
        {
            var plantContactProcessor = new PlantContactProcessor();
            plantContactProcessor.Save("0500232537");
        }

        [TestMethod]
        public void PlantContactIntegrationTestForInsertInMyService()
        {
            var plantContactProcessor = new PlantContactProcessor();
            plantContactProcessor.Save("0500232537");
        }
    }
}