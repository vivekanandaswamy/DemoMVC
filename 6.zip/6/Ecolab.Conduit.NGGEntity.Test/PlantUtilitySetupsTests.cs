﻿namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup;
    using TcdRequestHandler.Tcd.Entities.PlantUtilitySetups; 

    [TestClass]
    public class PlantUtilityContainer : TestBase
    {
        /// <summary>
        /// Test method for PlantUtilityContainer
        /// </summary>
        [TestMethod]
        public void PlantUtilityContainer_Test()
        {
            Model.PlantUtilityContainer plantUtilityContainer = new Model.PlantUtilityContainer();
            PlantUtilityContainer nggPlantUtilityContainer = new PlantUtilityContainer();
            string result = Compare(plantUtilityContainer, nggPlantUtilityContainer);

            if (result != null)
            {
                Console.WriteLine("PlantUtilityContainer : \r\n" + result);
                Assert.AreEqual(plantUtilityContainer, nggPlantUtilityContainer);
            }
            else
            {
                Console.WriteLine("Both the PlantUtilityContainer properties are equal.");
            }
        }

        /// <summary>
        /// Test method for PlantUtilityFactorTypes
        /// </summary>
        [TestMethod]
        public void PlantUtilityFactorTypes_Test()
        {
            Model.PlantUtilityFactorTypes plantUtilityFactorTypes = new Model.PlantUtilityFactorTypes();
            PlantUtilityFactorTypes nggPlantUtilityFactorTypes = new PlantUtilityFactorTypes();
            string result = Compare(plantUtilityFactorTypes, nggPlantUtilityFactorTypes);

            if (result != null)
            {
                Console.WriteLine("PlantUtilityFactorTypes : \r\n" + result);
                Assert.AreEqual(plantUtilityFactorTypes, nggPlantUtilityFactorTypes);
            }
            else
            {
                Console.WriteLine("Both the PlantUtilityFactorTypes properties are equal.");
            }
        }

        /// <summary>
        /// Test method for PlantUtilitySetup
        /// </summary>
        [TestMethod]
        public void PlantUtilitySetup_Test()
        {
            Model.PlantUtilitySetup plantUtilitySetup = new Model.PlantUtilitySetup();
            PlantUtilitySetup nggPlantUtilitySetup = new PlantUtilitySetup();
            string result = Compare(plantUtilitySetup, nggPlantUtilitySetup);           

            if (result != null)
            {
                Console.WriteLine("PlantUtilitySetup : \r\n" + result);
                Assert.AreEqual(plantUtilitySetup, nggPlantUtilitySetup);
            }
            else
            {
                Console.WriteLine("Both the PlantUtilitySetup properties are equal.");
            }
        }
    }
}
