﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.Washers.Tunnel;
    using TcdRequestHandler.Tcd.Entities.Washers.Tunnel;
    using System.Reflection;

    [TestClass]
    public class TunnelTests : TestBase
    {
        /// <summary>
        /// Test method for PumpAssociation
        /// </summary>
        [TestMethod]
        public void PumpAssociation_Test()
        {
            Model.PumpAssociation pumpAssociation = new Model.PumpAssociation();
            PumpAssociation nggPumpAssociation = new PumpAssociation();
            string result = Compare(pumpAssociation, nggPumpAssociation);

            if (result != null)
            {
                Console.WriteLine("PumpAssociation : \r\n" + result);
            }
            else
            {
                Console.WriteLine("Both the PumpAssociation properties are equal.");
            }
        }

        /// <summary>
        /// Test method for TunnelCompartment
        /// </summary>
        [TestMethod]
        public void TunnelCompartment_Test()
        {
            Model.TunnelCompartment tunnelCompartment = new Model.TunnelCompartment();
            TunnelCompartment nggTunnelCompartment = new TunnelCompartment();
            string result = Compare(tunnelCompartment, nggTunnelCompartment);
           
            if (result != null)
            {
                Console.WriteLine("TunnelCompartment : \r\n" + result);
            }
            else
            {
                Console.WriteLine("Both the TunnelCompartment properties are equal.");
            }
        }

        /// <summary>
        /// Test method for TunnelContainer
        /// </summary>
        [TestMethod]
        public void TunnelContainer_Test()
        {          
            Model.TunnelContainer tunnelContainer = new Model.TunnelContainer();
            TunnelContainer nggTunnelContainer = new TunnelContainer();           
            string result = Compare(tunnelContainer, nggTunnelContainer);

            if (result != null)
            {
                Console.WriteLine("TunnelContainer : \r\n" + result);
            }
            else
            {
                Console.WriteLine("Both the TunnelContainer properties are equal.");
            }
        }

        /// <summary>
        /// Test method for TunnelGeneral
        /// </summary>
        [TestMethod]
        public void TunnelGeneral_Test()
        {          
            Model.TunnelGeneral tunnelGeneral = new Model.TunnelGeneral();
            TunnelGeneral nggTunnelGeneral = new TunnelGeneral();            
            string result = Compare(tunnelGeneral, nggTunnelGeneral);

            if (result != null)
            {
                Console.WriteLine("TunnelGeneral : \r\n" + result);
            }
            else
            {
                Console.WriteLine("Both the TunnelGeneral properties are equal.");
            }
        }

        /// <summary>
        /// Test method for TunnelTags
        /// </summary>
        [TestMethod]
        public void TunnelTags_Test()
        {            
            Model.TunnelTags tunnelTags = new Model.TunnelTags();
            TunnelTags nggTunnelTags = new TunnelTags();            
            string result = Compare(tunnelTags, nggTunnelTags);           

            if (result != null)
            {
                Console.WriteLine("TunnelTags : \r\n" + result);
            }
            else
            {
                Console.WriteLine("Both the TunnelTags properties are equal.");
            }
        }
    }
}
