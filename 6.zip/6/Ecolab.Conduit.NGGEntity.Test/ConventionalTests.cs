﻿namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;    
    using Model = Ecolab.Models.Washers.Conventional;
    using TcdRequestHandler.Tcd.Entities.Washers.Conventional;
    using System.Reflection;

    [TestClass]
    public class ConventionalTests : TestBase
    {
        /// <summary>
        /// Test method for ConventionalGeneral
        /// </summary>
        [TestMethod]
        public void ConventionalGeneral_Test()
        {        
           
            Dictionary<string, string> lstProperties = new Dictionary<string, string>();

            Model.ConventionalGeneral conventionalGeneral = new Model.ConventionalGeneral();
            ConventionalGeneral nggConventionalGeneral = new ConventionalGeneral(); 
            string result = Compare(conventionalGeneral, nggConventionalGeneral);

            if(result != null )
            {
                Console.WriteLine("ConventionalGeneral : \r\n" + result);
                Assert.AreEqual(conventionalGeneral, nggConventionalGeneral);
            }
            else
            {
                Console.WriteLine("Both the ConventionalGeneral properties are equal."); 
            } 
        }

        /// <summary>
        /// Test method for ConventionalTags
        /// </summary>
        [TestMethod]
        public void ConventionalTags_Test()
        {
            Model.ConventionalTags conventionalTags = new Model.ConventionalTags();
            ConventionalTags nggConventionalTags = new ConventionalTags();
            string result = Compare(conventionalTags, nggConventionalTags);

            if (result != null)
            {
                Console.WriteLine("ConventionalTags : \r\n" + result);
                Assert.AreEqual(conventionalTags, nggConventionalTags);
            }
            else
            {
                Console.WriteLine("Both the ConventionalTags properties are equal.");
            }
        }       
    }
}
