﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models;
    using TcdRequestHandler.Tcd.Entities.Formulas;      

    [TestClass]
    public class FormulasTests : TestBase
    {
        /// <summary>
        /// Test method for Formula
        /// </summary>
        [TestMethod]
        public void Formula_Test()
        {
            Model.Formula formula = new Model.Formula();
            Formula nggFormula = new Formula();
            string result = Compare(formula, nggFormula);

            if (result != null)
            {
                Console.WriteLine("Formula : \r\n" + result);
                Assert.AreEqual(formula, nggFormula);
            }
            else
            {
                Console.WriteLine("Both the Formula properties are equal.");
            }           
        }        
    }
}
