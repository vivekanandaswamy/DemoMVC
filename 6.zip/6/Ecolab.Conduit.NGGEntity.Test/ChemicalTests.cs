﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup.Chemical;
    using TcdRequestHandler.Tcd.Entities.Chemicals;
   
    [TestClass]
    public class ChemicalTests : TestBase
    {
        /// <summary>
        /// Test method for Chemicals
        /// </summary>
        [TestMethod]
        public void Chemicals_Test()
        {
            Model.Chemicals chemicals = new Model.Chemicals();
            Chemicals nggChemicals = new Chemicals();
            string result = Compare(chemicals, nggChemicals);

            if (result != null)
            {
                Console.WriteLine("Chemicals : \r\n" + result);
                Assert.AreEqual(chemicals, nggChemicals);
            }
            else
            {
                Console.WriteLine("Both the Chemicals properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ProductMaster
        /// </summary>
        [TestMethod]
        public void ProductMaster_Test()
        {
            Model.ProductMaster productMaster = new Model.ProductMaster();
            ProductMaster nggProductMaster = new ProductMaster();
            string result = Compare(productMaster, nggProductMaster);

            if (result != null)
            {
                Console.WriteLine("ProductMaster : \r\n" + result);
                Assert.AreEqual(productMaster, nggProductMaster);
            }
            else
            {
                Console.WriteLine("Both the ProductMaster properties are equal.");
            }
        }
    }
}
