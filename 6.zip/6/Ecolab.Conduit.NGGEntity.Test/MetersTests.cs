﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup;
    using TcdRequestHandler.Tcd.Entities.Meters; 

    [TestClass]
    public class MetersTests : TestBase
    {
        /// <summary>
        /// Test method for Meter
        /// </summary>
        [TestMethod]
        public void Meter_Test()
        {
            Model.Meter meter = new Model.Meter();
            Meter nggMeter = new Meter();
            string result = Compare(meter, nggMeter);

            if (result != null)
            {
                Console.WriteLine("Meter : \r\n" + result);
                Assert.AreEqual(meter, nggMeter);
            }
            else
            {
                Console.WriteLine("Both the Meter properties are equal.");
            }
        }

        /// <summary>
        /// Test method for MeterModel
        /// </summary>
        [TestMethod]
        public void MeterModel_Test()
        {
            Model.MeterModel meterModel = new Model.MeterModel();
            MeterModel nggMeterModel = new MeterModel();
            string result = Compare(meterModel, nggMeterModel);
            
            if (result != null)
            {
                Console.WriteLine("MeterModel : \r\n" + result);
                Assert.AreEqual(meterModel, nggMeterModel);
            }
            else
            {
                Console.WriteLine("Both the MeterModel properties are equal.");
            }
        }
    }
}
