﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Conduit.NGGEntity.Test
{
    public class TestBase
    {
        public string Compare<T1, T2>(T1 source, T2 compare)
        {
            StringBuilder str = new StringBuilder();
            string result = string.Empty;

            var query = from sourceFile in source.GetType().GetProperties()
                        where !compare.GetType().GetProperties().Any(compareFile => compareFile.Name == sourceFile.Name)
                        select new { sourceFile.Name, sourceFile.PropertyType };
            if (query.Any())
            {
                foreach (var item in query)
                {
                    str.Append("\r\n" + item.Name + " : " + item.PropertyType.FullName);
                }
                return str.ToString();
            }
            else
            {
               return  result = null;
            }
        }
    }
}
