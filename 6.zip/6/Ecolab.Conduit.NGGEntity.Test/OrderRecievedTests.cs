﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models;
    using TcdRequestHandler.Tcd.Entities.OrderRecieved; 

    [TestClass]
    public class OrderRecievedTests : TestBase
    {
        /// <summary>
        /// Test method for OrderRecieved
        /// </summary>
        [TestMethod]
        public void OrderRecieved_Test()
        {
            Model.OrderRecieved orderRecieved = new Model.OrderRecieved();
            OrderRecieved nggOrderRecieved = new OrderRecieved();
            string result = Compare(orderRecieved, nggOrderRecieved);

            if (result != null)
            {
                Console.WriteLine("OrderRecieved : \r\n" + result);
                Assert.AreEqual(orderRecieved, nggOrderRecieved);
            }
            else
            {
                Console.WriteLine("Both the OrderRecieved properties are equal.");
            }     
        }
    }
}
