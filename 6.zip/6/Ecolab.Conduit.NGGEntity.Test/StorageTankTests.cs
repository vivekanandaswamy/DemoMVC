﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;    
    using Model = Ecolab.Models.StorageTanks;
    using TcdRequestHandler.Tcd.Entities.StorageTanks; 

    [TestClass]
    public class StorageTankTests : TestBase
    {
        /// <summary>
        /// Test method for Tanks
        /// </summary>
        [TestMethod]
        public void Tanks_Test()
        {
            Model.Tanks tanks = new Model.Tanks();
            Tanks nggTanks = new Tanks();
            string result = Compare(tanks, nggTanks);

            if (result != null)
            {
                Console.WriteLine("Tanks : \r\n" + result);
                Assert.AreEqual(tanks, nggTanks);
            }
            else
            {
                Console.WriteLine("Both the Tanks properties are equal.");
            }
        }
    }
}
