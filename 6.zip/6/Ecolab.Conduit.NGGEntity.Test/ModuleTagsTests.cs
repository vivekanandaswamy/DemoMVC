﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.Common;
    using TcdRequestHandler.Tcd.Entities.ModuleTags; 

    [TestClass]
    public class ModuleTagsTests : TestBase
    {
        /// <summary>
        /// Test method for ModuleTagsModel
        /// </summary>
        [TestMethod]
        public void ModuleTagsModel_Test()
        {
            Model.ModuleTagsModel moduleTagsModel = new Model.ModuleTagsModel();
            ModuleTagsModel nggModuleTagsModel = new ModuleTagsModel();
            string result = Compare(moduleTagsModel, nggModuleTagsModel);

            if (result != null)
            {
                Console.WriteLine("ModuleTagsModel : \r\n" + result);
                Assert.AreEqual(moduleTagsModel, nggModuleTagsModel);
            }
            else
            {
                Console.WriteLine("Both the ModuleTagsModel properties are equal.");
            }            
        }
    }
}
