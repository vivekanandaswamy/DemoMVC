﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup.Finnisher;
    using TcdRequestHandler.Tcd.Entities.Finnishers;      

    [TestClass]
    public class FinnishersTests : TestBase
    {
        /// <summary>
        /// Test method for Finnisher
        /// </summary>
        [TestMethod]
        public void Finnisher_Test()
        {
            Model.Finnisher finnisher = new Model.Finnisher();
            Finnisher nggFinnisher = new Finnisher();
            string result = Compare(finnisher, nggFinnisher);

            if (result != null)
            {
                Console.WriteLine("Finnisher : \r\n" + result);
                Assert.AreEqual(finnisher, nggFinnisher);
            }
            else
            {
                Console.WriteLine("Both the Finnisher properties are equal.");
            }
        }

        /// <summary>
        /// Test method for FinnisherGroup
        /// </summary>
        [TestMethod]
        public void FinnisherGroup_Test()
        {
            Model.FinnisherGroup finnisherGroup = new Model.FinnisherGroup();
            FinnisherGroup nggFinnisherGroup = new FinnisherGroup();
            string result = Compare(finnisherGroup, nggFinnisherGroup);

            if (result != null)
            {
                Console.WriteLine("FinnisherGroup : \r\n" + result);
                Assert.AreEqual(finnisherGroup, nggFinnisherGroup);
            }
            else
            {
                Console.WriteLine("Both the FinnisherGroup properties are equal.");
            }
        }

        /// <summary>
        /// Test method for FinnisherType
        /// </summary>
        [TestMethod]
        public void FinnisherType_Test()
        {
            Model.FinnisherType finnisherType = new Model.FinnisherType();
            FinnisherType nggFinnisherType = new FinnisherType();
            string result = Compare(finnisherType, nggFinnisherType);

            if (result != null)
            {
                Console.WriteLine("FinnisherType : \r\n" + result);
                Assert.AreEqual(finnisherType, nggFinnisherType);
            }
            else
            {
                Console.WriteLine("Both the FinnisherType properties are equal.");
            }            
        }
    }
}
