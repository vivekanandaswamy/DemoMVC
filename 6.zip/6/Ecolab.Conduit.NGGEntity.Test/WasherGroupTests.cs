﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.WasherGroup;
    using TcdRequestHandler.Tcd.Entities.WasherGroup; 

    [TestClass]
    public class WasherGroupTests : TestBase
    {
        /// <summary>
        /// Test method for TunnelFormula
        /// </summary>
        [TestMethod]
        public void TunnelFormula_Test()
        {
            Model.TunnelFormulaModel tunnelFormulaModel = new Model.TunnelFormulaModel();
            TunnelFormula nggTunnelFormula = new TunnelFormula();
            string result = Compare(tunnelFormulaModel, nggTunnelFormula);

            if (result != null)
            {
                Console.WriteLine("TunnelFormula : \r\n" + result);
                Assert.AreEqual(tunnelFormulaModel, nggTunnelFormula);
            }
            else
            {
                Console.WriteLine("Both the TunnelFormula properties are equal.");                
            }           
        }

        /// <summary>
        /// Test method for TunnelWashStep
        /// </summary>
        [TestMethod]
        public void TunnelWashStep_Test()
        {
            Model.TunnelWashStep tunnelWashStep = new Model.TunnelWashStep();
            TunnelWashStep nggTunnelWashStep = new TunnelWashStep();
            string result = Compare(tunnelWashStep, nggTunnelWashStep);

            if (result != null)
            {
                Console.WriteLine("TunnelWashStep : \r\n" + result);
                Assert.AreEqual(tunnelWashStep, nggTunnelWashStep);
            }
            else
            {
                Console.WriteLine("Both the TunnelWashStep properties are equal.");                
            }
        }

        /// <summary>
        /// Test method for TunnelWashStepProducts
        /// </summary>
        [TestMethod]
        public void TunnelWashStepProducts_Test()
        {
            Model.TunnelWashStepProducts tunnelWashStepProducts = new Model.TunnelWashStepProducts();
            TunnelWashStepProducts nggTunnelWashStepProducts = new TunnelWashStepProducts();
            string result = Compare(tunnelWashStepProducts, nggTunnelWashStepProducts);

            if (result != null)
            {
                Console.WriteLine("TunnelWashStepProducts : \r\n" + result);
                Assert.AreEqual(tunnelWashStepProducts, nggTunnelWashStepProducts);
            }
            else
            {
                Console.WriteLine("Both the TunnelWashStepProducts properties are equal.");
            }
        }

        /// <summary>
        /// Test method for WasherDosingProduct
        /// </summary>
        [TestMethod]
        public void WasherDosingProduct_Test()
        {
            Model.WasherDosingProduct washerDosingProduct = new Model.WasherDosingProduct();
            WasherDosingProduct nggWasherDosingProduct = new WasherDosingProduct();
            string result = Compare(washerDosingProduct, nggWasherDosingProduct);

            if (result != null)
            {
                Console.WriteLine("WasherDosingProduct : \r\n" + result);
                Assert.AreEqual(washerDosingProduct, nggWasherDosingProduct);
            }
            else
            {
                Console.WriteLine("Both the WasherDosingProduct properties are equal.");
            }             
        }

        /// <summary>
        /// Test method for WasherFormula
        /// </summary>
        [TestMethod]
        public void WasherFormula_Test()
        {
            Model.WasherFormulaModel washerFormulaModel = new Model.WasherFormulaModel();
            WasherFormula nggWasherFormula = new WasherFormula();
            string result = Compare(washerFormulaModel, nggWasherFormula);

            if (result != null)
            {
                Console.WriteLine("WasherFormula : \r\n" + result);
                Assert.AreEqual(washerFormulaModel, nggWasherFormula);
            }
            else
            {
                Console.WriteLine("Both the WasherFormula properties are equal.");
            }
        }

        /// <summary>
        /// Test method for WasherFormulaWashStep
        /// </summary>
        [TestMethod]
        public void WasherFormulaWashStep_Test()
        {
            Model.WasherFormulaWashStep washerFormulaWashStep = new Model.WasherFormulaWashStep();
            WasherFormulaWashStep nggWasherFormulaWashStep = new WasherFormulaWashStep();
            string result = Compare(washerFormulaWashStep, nggWasherFormulaWashStep);

            if (result != null)
            {
                Console.WriteLine("WasherFormulaWashStep : \r\n" + result);
                Assert.AreEqual(washerFormulaWashStep, nggWasherFormulaWashStep);
            }
            else
            {
                Console.WriteLine("Both the WasherFormulaWashStep properties are equal.");
            }
        }

        /// <summary>
        /// Test method for WasherGroup
        /// </summary>
        [TestMethod]
        public void WasherGroup_Test()
        {
            Model.WasherGroup washerGroup = new Model.WasherGroup();
            WasherGroup nggWasherGroup = new WasherGroup();
            string result = Compare(washerGroup, nggWasherGroup);

            if (result != null)
            {
                Console.WriteLine("WasherGroup : \r\n" + result);
                Assert.AreEqual(washerGroup, nggWasherGroup);
            }
            else
            {
                Console.WriteLine("Both the WasherGroup properties are equal.");
            }             
        }

        /// <summary>
        /// Test method for WasherGroupFormula
        /// </summary>
        [TestMethod]
        public void WasherGroupFormula_Test()
        {
            Model.WasherGroupFormula washerGroupFormula = new Model.WasherGroupFormula();
            WasherGroupFormula nggWasherGroupFormula = new WasherGroupFormula();
            string result = Compare(washerGroupFormula, nggWasherGroupFormula);

            if (result != null)
            {
                Console.WriteLine("WasherGroupFormula : \r\n" + result);
                Assert.AreEqual(washerGroupFormula, nggWasherGroupFormula);
            }
            else
            {
                Console.WriteLine("Both the WasherGroupFormula properties are equal.");
            }           
        }
    }
}
