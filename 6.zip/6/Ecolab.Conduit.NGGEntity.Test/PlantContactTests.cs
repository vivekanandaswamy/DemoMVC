﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models;
    using TcdRequestHandler.Tcd.Entities.PlantContact; 

    [TestClass]
    public class PlantContactTests : TestBase
    {
        /// <summary>
        /// Test method for PlantContact
        /// </summary>
        [TestMethod]
        public void PlantContact_Test()
        {
            Model.PlantContact plantContact = new Model.PlantContact();
            PlantContact nggPlantContact = new PlantContact();
            string result = Compare(plantContact, nggPlantContact);

            if (result != null)
            {
                Console.WriteLine("PlantContact : \r\n" + result);
                Assert.AreEqual(plantContact, nggPlantContact);
            }
            else
            {
                Console.WriteLine("Both the PlantContact properties are equal.");
            }
        }
    }
}
