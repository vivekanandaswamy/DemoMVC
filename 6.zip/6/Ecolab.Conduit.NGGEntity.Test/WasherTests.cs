﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.Washers;
    using TcdRequestHandler.Tcd.Entities.Washers;

    [TestClass]
    public class WasherTests : TestBase
    {
        /// <summary>
        /// Test method for Alarms
        /// </summary>
        [TestMethod]
        public void Alarms_Test()
        {
            Model.Alarms alarms = new Model.Alarms();
            Alarms nggAlarms = new Alarms();
            string result = Compare(alarms, nggAlarms);

            if (result != null)
            {
                Console.WriteLine("Alarms : \r\n" + result);
                Assert.AreEqual(alarms, nggAlarms);
            }
            else
            {
                Console.WriteLine("Both the Alarms properties are equal.");
            }            
        }

        /// <summary>
        /// Test method for Washers
        /// </summary>
        [TestMethod]
        public void Washers_Test()
        {
            Model.Washers washers = new Model.Washers();
            Washers nggWashers = new Washers();
            string result = Compare(washers, nggWashers);

            if (result != null)
            {
                Console.WriteLine("Washers : \r\n" + result);
                Assert.AreEqual(washers, nggWashers);
            }
            else
            {
                Console.WriteLine("Both the Washers properties are equal.");
            }
        }
    }
}
