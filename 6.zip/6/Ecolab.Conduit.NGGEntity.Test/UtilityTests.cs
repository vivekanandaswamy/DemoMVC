﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup;
    using TcdRequestHandler.Tcd.Entities.Utility; 

    [TestClass]
    public class UtilityTests : TestBase
    {
        /// <summary>
        /// Test method for Utility
        /// </summary>
        [TestMethod]
        public void Utility_Test()
        {
            Model.Utility utility = new Model.Utility();
            Utility nggUtility = new Utility();
            string result = Compare(utility, nggUtility);

            if (result != null)
            {
                Console.WriteLine("Utility : \r\n" + result);
                Assert.AreEqual(utility, nggUtility);
            }
            else
            {
                Console.WriteLine("Both the Utility properties are equal.");
            }
        }
    }
}
