﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.ManualInput;
    using TcdRequestHandler.Tcd.Entities.ManualInput; 

    [TestClass]
    public class ManualInputTests : TestBase
    {
        /// <summary>
        /// Test method for ManualBatch
        /// </summary>
        [TestMethod]
        public void ManualBatch_Test()
        {
            Model.ManualBatchData manualBatchData = new Model.ManualBatchData();
            ManualBatch nggManualBatch = new ManualBatch();
            string result = Compare(manualBatchData, nggManualBatch);
            
            if (result != null)
            {
                Console.WriteLine("ManualBatch : \r\n" + result);
                Assert.AreEqual(manualBatchData, nggManualBatch);
            }
            else
            {
                Console.WriteLine("Both the ManualBatch properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ManualLabor
        /// </summary>
        [TestMethod]
        public void ManualLabor_Test()
        {
            Model.ManualLabor.ManualLabor manualLabor = new Model.ManualLabor.ManualLabor();
            ManualLabor nggManualLabor = new ManualLabor();
            string result = Compare(manualLabor, nggManualLabor);

            if (result != null)
            {
                Console.WriteLine("ManualLabor : \r\n" + result);
                Assert.AreEqual(manualLabor, nggManualLabor);
            }
            else
            {
                Console.WriteLine("Both the ManualLabor properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ManualProduction
        /// </summary>
        [TestMethod]
        public void ManualProduction_Test()
        {
            Model.Production.ManualProduction manualProduction = new Model.Production.ManualProduction();
            ManualProduction nggManualProduction = new ManualProduction();
            string result = Compare(manualProduction, nggManualProduction);

            if (result != null)
            {
                Console.WriteLine("ManualProduction : \r\n" + result);
                Assert.AreEqual(manualProduction, nggManualProduction);
            }
            else
            {
                Console.WriteLine("Both the ManualProduction properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ManualRewash
        /// </summary>
        [TestMethod]
        public void ManualRewash_Test()
        {
            Model.Rewash.ManualRewash manualRewash = new Model.Rewash.ManualRewash();
            ManualRewash nggManualRewash = new ManualRewash();
            string result = Compare(manualRewash, nggManualRewash);

            if (result != null)
            {
                Console.WriteLine("ManualRewash : \r\n" + result);
                Assert.AreEqual(manualRewash, nggManualRewash);
            }
            else
            {
                Console.WriteLine("Both the ManualRewash properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ManualRewashContainer
        /// </summary>
        [TestMethod]
        public void ManualRewashContainer_Test()
        {
            Model.Rewash.ManualRewashContainer manualRewashContainer = new Model.Rewash.ManualRewashContainer();
            ManualRewashContainer nggManualRewashContainer = new ManualRewashContainer();
            string result = Compare(manualRewashContainer, nggManualRewashContainer);

            if (result != null)
            {
                Console.WriteLine("ManualRewashContainer : \r\n" + result);
                Assert.AreEqual(manualRewashContainer, nggManualRewashContainer);
            }
            else
            {
                Console.WriteLine("Both the ManualRewashContainer properties are equal.");
            }
        }

        /// <summary>
        /// Test method for RewashProduct
        /// </summary>
        [TestMethod]
        public void RewashProduct_Test()
        {
            Model.Rewash.RewashProduct rewashProduct = new Model.Rewash.RewashProduct();
            RewashProduct nggRewashProduct = new RewashProduct();
            string result = Compare(rewashProduct, nggRewashProduct);

            if (result != null)
            {
                Console.WriteLine("RewashProduct : \r\n" + result);
                Assert.AreEqual(rewashProduct, nggRewashProduct);
            }
            else
            {
                Console.WriteLine("Both the RewashProduct properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ManualUtility
        /// </summary>
        [TestMethod]
        public void ManualUtility_Test()
        {
            Model.ManualUtility manualUtility = new Model.ManualUtility();
            ManualUtility nggManualUtility = new ManualUtility();
            string result = Compare(manualUtility, nggManualUtility);

            if (result != null)
            {
                Console.WriteLine("ManualUtility : \r\n" + result);
                Assert.AreEqual(manualUtility, nggManualUtility);
            }
            else
            {
                Console.WriteLine("Both the ManualUtility properties are equal.");
            }            
        }        
    }
}
