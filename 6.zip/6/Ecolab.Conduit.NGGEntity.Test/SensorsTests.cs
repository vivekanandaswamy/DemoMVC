﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup;
    using TcdRequestHandler.Tcd.Entities.Sensors; 

    [TestClass]
    public class SensorsTests : TestBase
    {
        /// <summary>
        /// Test method for Sensor
        /// </summary>
        [TestMethod]
        public void Sensor_Test()
        {
            Model.Sensor sensor = new Model.Sensor();
            Sensor nggSensor = new Sensor();
            string result = Compare(sensor, nggSensor);
            

            if (result != null)
            {
                Console.WriteLine("Sensor : \r\n" + result);
                Assert.AreEqual(sensor, nggSensor);
            }
            else
            {
                Console.WriteLine("Both the Sensor properties are equal.");
            }
        }

        /// <summary>
        /// Test method for SensorModel
        /// </summary>
        [TestMethod]
        public void SensorModel_Test()
        {
            Model.SensorModel sensorModel = new Model.SensorModel();
            SensorModel nggSensorModel = new SensorModel();
            string result = Compare(sensorModel, nggSensorModel);

            if (result != null)
            {
                Console.WriteLine("SensorModel : \r\n" + result);
                Assert.AreEqual(sensorModel, nggSensorModel);
            }
            else
            {
                Console.WriteLine("Both the SensorModel properties are equal.");                
            }
        }       
    }
}
