﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup.RedFlag;
    using TcdRequestHandler.Tcd.Entities.RedFlags; 

    [TestClass]
    public class RedFlagTests : TestBase
    {
        /// <summary>
        /// Test method for RedFlag
        /// </summary>
        [TestMethod]
        public void RedFlag_Test()
        {
            Model.RedFlag redFlag = new Model.RedFlag();
            RedFlag nggRedFlag = new RedFlag();
            string result = Compare(redFlag, nggRedFlag);

            if (result != null)
            {
                Console.WriteLine("RedFlag : \r\n" + result);
                Assert.AreEqual(redFlag, nggRedFlag);
            }
            else
            {
                Console.WriteLine("Both the RedFlag properties are equal.");
            }
        }       
    }
}
