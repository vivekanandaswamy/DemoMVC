﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models;
    using TcdRequestHandler.Tcd.Entities.PlantCustomer; 

    [TestClass]
    public class PlantCustomerTests : TestBase
    {
        /// <summary>
        /// Test method for PlantCustomer
        /// </summary>
        [TestMethod]
        public void PlantCustomer_Test()
        {
            Model.PlantCustomer plantCustomer = new Model.PlantCustomer();
            PlantCustomer nggPlantCustomer = new PlantCustomer();
            string result = Compare(plantCustomer, nggPlantCustomer);

            if (result != null)
            {
                Console.WriteLine("PlantCustomer : \r\n" + result);
                Assert.AreEqual(plantCustomer, nggPlantCustomer);
            }
            else
            {
                Console.WriteLine("Both the PlantCustomer properties are equal.");
            }
        }
    }
}
