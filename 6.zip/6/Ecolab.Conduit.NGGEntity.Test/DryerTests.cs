﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;       
    using Model = Ecolab.Models.PlantSetup.Dryer;
    using TcdRequestHandler.Tcd.Entities.Dryers;      

    [TestClass]
    public class DryerTests : TestBase
    {
        /// <summary>
        /// Test method for Dryer
        /// </summary>
        [TestMethod]
        public void Dryer_Test()
        {            
            Model.Dryer dryer = new Model.Dryer();
            Dryer nggDryer = new Dryer();
            string result = Compare(dryer, nggDryer);
            
            if (result != null)
            {
                Console.WriteLine("Dryer : \r\n" + result);
                Assert.AreEqual(dryer, nggDryer);
            }
            else
            {
                Console.WriteLine("Both the Dryer properties are equal.");
            }
        }

        /// <summary>
        /// Test method for DryerGroup
        /// </summary>
        [TestMethod]
        public void DryerGroup_Test()
        {
            Model.DryerGroup dryerGroup = new Model.DryerGroup();
            DryerGroup nggDryerGroup = new DryerGroup();
            string result = Compare(dryerGroup, nggDryerGroup);

            if (result != null)
            {
                Console.WriteLine("DryerGroup : \r\n" + result);
                Assert.AreEqual(dryerGroup, nggDryerGroup);
            }
            else
            {
                Console.WriteLine("Both the DryerGroup properties are equal.");
            }
        }

        /// <summary>
        /// Test method for DryerType
        /// </summary>
        [TestMethod]
        public void DryerType_Test()
        {
            Model.DryerType dryerType = new Model.DryerType();
            DryerType nggDryerType = new DryerType();
            string result = Compare(dryerType, nggDryerType);

            if (result != null)
            {
                Console.WriteLine("DryerType : \r\n" + result);
                Assert.AreEqual(dryerType, nggDryerType);
            }
            else
            {
                Console.WriteLine("Both the DryerType properties are equal.");
            }            
        }
    }
}
