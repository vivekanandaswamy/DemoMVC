﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.Common;
    using TcdRequestHandler.Tcd.Entities;   
  
    [TestClass]
    public class GroupTypeTests : TestBase
    {
        /// <summary>
        /// Test method for GroupType
        /// </summary>
        [TestMethod]
        public void GroupType_Test()
        {
            Model.GroupType groupType = new Model.GroupType();
            GroupType nggGroupType = new GroupType();
            string result = Compare(groupType, nggGroupType);

            if (result != null)
            {
                Console.WriteLine("GroupType : \r\n" + result);
                Assert.AreEqual(groupType, nggGroupType);
            }
            else
            {
                Console.WriteLine("Both the GroupType properties are equal.");
            }           
        }
    }
}
