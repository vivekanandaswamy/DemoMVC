﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using ModelCommon = Ecolab.Models.Common;
    using Model = Ecolab.Models.PlantSetup.ShiftLabor;
    using TcdRequestHandler.Tcd.Entities.Shifts; 

    [TestClass]
    public class ShiftTests : TestBase
    {
        /// <summary>
        /// Test method for LaborType
        /// </summary>
        [TestMethod]
        public void LaborType_Test()
        {
            ModelCommon.LaborType laborType = new ModelCommon.LaborType();
            LaborType nggLaborType = new LaborType();
            string result = Compare(laborType, nggLaborType);            

            if (result != null)
            {
                Console.WriteLine("LaborType : \r\n" + result);
                Assert.AreEqual(laborType, nggLaborType);
            }
            else
            {
                Console.WriteLine("Both the LaborType properties are equal.");
            }
        }

        /// <summary>
        /// Test method for LaborTypeCost
        /// </summary>
        [TestMethod]
        public void LaborTypeCost_Test()
        {
            Model.LaborTypeCost laborTypeCost = new Model.LaborTypeCost();
            LaborTypeCost nggLaborTypeCost = new LaborTypeCost();
            string result = Compare(laborTypeCost, nggLaborTypeCost);

            if (result != null)
            {
                Console.WriteLine("LaborTypeCost : \r\n" + result);
                Assert.AreEqual(laborTypeCost, nggLaborTypeCost);
            }
            else
            {
                Console.WriteLine("Both the LaborTypeCost properties are equal.");
            }
        }

        /// <summary>
        /// Test method for Shift
        /// </summary>
        [TestMethod]
        public void Shift_Test()
        {
            Model.Shift shift = new Model.Shift();
            Shift nggShift = new Shift();
            string result = Compare(shift, nggShift);

            if (result != null)
            {
                Console.WriteLine("Shift : \r\n" + result);
                Assert.AreEqual(shift, nggShift);
            }
            else
            {
                Console.WriteLine("Both the Shift properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ShiftBreak
        /// </summary>
        [TestMethod]
        public void ShiftBreak_Test()
        {
            Model.ShiftBreak shiftBreak = new Model.ShiftBreak();
            ShiftBreak nggShiftBreak = new ShiftBreak();
            string result = Compare(shiftBreak, nggShiftBreak);

            if (result != null)
            {
                Console.WriteLine("ShiftBreak : \r\n" + result);
                Assert.AreEqual(shiftBreak, nggShiftBreak);
            }
            else
            {
                Console.WriteLine("Both the ShiftBreak properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ShiftLabor
        /// </summary>
        [TestMethod]
        public void ShiftLabor_Test()
        {
            Model.ShiftLabor shiftLabor = new Model.ShiftLabor();
            ShiftLabor nggShiftLabor = new ShiftLabor();
            string result = Compare(shiftLabor, nggShiftLabor);

            if (result != null)
            {
                Console.WriteLine("ShiftLabor : \r\n" + result);
                Assert.AreEqual(shiftLabor, nggShiftLabor);
            }
            else
            {
                Console.WriteLine("Both the ShiftLabor properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ShiftSyncContainer
        /// </summary>
        [TestMethod]
        public void ShiftSyncContainer_Test()
        {
            Model.ShiftSyncContainer shiftSyncContainer = new Model.ShiftSyncContainer();
            ShiftSyncContainer nggShiftSyncContainer = new ShiftSyncContainer();
            string result = Compare(shiftSyncContainer, nggShiftSyncContainer);

            if (result != null)
            {
                Console.WriteLine("ShiftSyncContainer : \r\n" + result);
                Assert.AreEqual(shiftSyncContainer, nggShiftSyncContainer);
            }
            else
            {
                Console.WriteLine("Both the ShiftSyncContainer properties are equal.");
            }
        }

        /// <summary>
        /// Test method for TargetProduction
        /// </summary>
        [TestMethod]
        public void TargetProduction_Test()
        {
            Model.TargetProduction targetProduction = new Model.TargetProduction();
            TargetProduction nggTargetProduction = new TargetProduction();
            string result = Compare(targetProduction, nggTargetProduction);

            if (result != null)
            {
                Console.WriteLine("TargetProduction : \r\n" + result);
                Assert.AreEqual(targetProduction, nggTargetProduction);
            }
            else
            {
                Console.WriteLine("Both the TargetProduction properties are equal.");
            }
        }

        /// <summary>
        /// Test method for TargetProductionContainer
        /// </summary>
        [TestMethod]
        public void TargetProductionContainer_Test()
        {
            Model.TargetProductionContainer targetProductionContainer = new Model.TargetProductionContainer();
            TargetProductionContainer nggTargetProductionContainer = new TargetProductionContainer();
            string result = Compare(targetProductionContainer, nggTargetProductionContainer);

            if (result != null)
            {
                Console.WriteLine("TargetProductionContainer : \r\n" + result);
                Assert.AreEqual(targetProductionContainer, nggTargetProductionContainer);
            }
            else
            {
                Console.WriteLine("Both the TargetProductionContainer properties are equal.");
            }
        }
    }
}
