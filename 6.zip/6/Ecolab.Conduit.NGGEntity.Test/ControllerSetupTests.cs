﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Collections.Generic;   
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.ControllerSetup;
    using TcdRequestHandler.Tcd.Entities.ControllerSetup;
    using TcdRequestHandler.Tcd.Entities.ControllerSetup.Pumps;    

    [TestClass]
    public class ControllerSetupTests : TestBase
    {
        /// <summary>
        /// Test method for Controller
        /// </summary>
        [TestMethod]
        public void Controller_Test()
        {
            Model.Controller controller = new Model.Controller();
            Controller nggController = new Controller();
            string result = Compare(controller, nggController);

            if (result != null)
            {
                Console.WriteLine("Controller : \r\n" + result);
                Assert.AreEqual(controller, nggController);
            }
            else
            {
                Console.WriteLine("Both the Controller properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ControllerSetupData
        /// </summary>
        [TestMethod]
        public void ControllerSetupData_Test()
        {
            Model.ControllerSetupData controllerSetupData = new Model.ControllerSetupData();
            ControllerSetupData nggControllerSetupData = new ControllerSetupData();
            string result = Compare(controllerSetupData, nggControllerSetupData);
           
            if (result != null)
            {
                Console.WriteLine("ControllerSetupData : \r\n" + result);
                Assert.AreEqual(controllerSetupData, nggControllerSetupData);
            }
            else
            {
                Console.WriteLine("Both the ControllerSetupData properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ControllerSetupDataDetails
        /// </summary>
        [TestMethod]
        public void ControllerSetupDataDetails_Test()
        {
            Model.ControllerSetupDataDetails controllerSetupDataDetails = new Model.ControllerSetupDataDetails();
            ControllerSetupDataDetails nggControllerSetupDataDetails = new ControllerSetupDataDetails();
            string result = Compare(controllerSetupDataDetails, nggControllerSetupDataDetails);
           
            if (result != null)
            {
                Console.WriteLine("ControllerSetupDataDetails : \r\n" + result);
                Assert.AreEqual(controllerSetupDataDetails, nggControllerSetupDataDetails);
            }
            else
            {
                Console.WriteLine("Both the ControllerSetupDataDetails properties are equal.");
            }
        }

        /// <summary>
        /// Test method for ControllerSetupMetaData, here we donot have a zero argument constructor
        /// </summary>
        //[TestMethod]
        //public void ControllerSetupMetaData_Test()
        //{
        //    
        //    Model.ControllerSetupMetaData controllerSetupMetaData = new Model.ControllerSetupMetaData();
        //    ControllerSetupMetaData nggControllerSetupMetaData = new ControllerSetupMetaData();
        //    string result = Compare(controllerSetupMetaData, nggControllerSetupMetaData);
           
        //    if (result != null)
        //    {
        //        Console.WriteLine("ControllerSetupMetaData : \r\n" + result);
        //       Assert.AreEqual(controllerSetupMetaData, nggControllerSetupMetaData);
        //    }
        //    else
        //    {
        //        Console.WriteLine("Both the ControllerSetupMetaData properties are equal.");
        //    }
        //}

        /// <summary>
        /// Test method for Pumps
        /// </summary>
        [TestMethod]
        public void Pumps_Test()
        {            
            Model.Pumps.PumpsModel pumpsModel = new Model.Pumps.PumpsModel();
            Pumps nggPumps = new Pumps();
            string result = Compare(pumpsModel, nggPumps);
            
            if (result != null)
            {
                Console.WriteLine("PumpsModel : \r\n" + result);
                Assert.AreEqual(pumpsModel, nggPumps);
            }
            else
            {
                Console.WriteLine("Both the Pumps properties are equal.");
            }
        }
    }
}
