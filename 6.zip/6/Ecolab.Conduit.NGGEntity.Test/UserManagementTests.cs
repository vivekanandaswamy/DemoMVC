﻿
namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup.UserManagement;
    using TcdRequestHandler.Tcd.Entities.UserManagements; 

    [TestClass]
    public class UserManagementTests : TestBase
    {
        /// <summary>
        /// Test method for UserManagement
        /// </summary>
        [TestMethod]
        public void UserManagement_Test()
        {
            Model.UserManagement userManagement = new Model.UserManagement();
            UserManagement nggUserManagement = new UserManagement();
            string result = Compare(userManagement, nggUserManagement);

            if (result != null)
            {
                Console.WriteLine("UserManagement : \r\n" + result);
                Assert.AreEqual(userManagement, nggUserManagement);
            }
            else
            {
                Console.WriteLine("Both the UserManagement properties are equal.");
            }            
        }
    }
}
