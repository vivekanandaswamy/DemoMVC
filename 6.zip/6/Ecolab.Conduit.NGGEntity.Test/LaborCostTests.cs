﻿

namespace Ecolab.Conduit.NGGEntity.Test
{
    using System;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Model = Ecolab.Models.PlantSetup.ShiftLabor;
    using TcdRequestHandler.Tcd.Entities;
    using TcdRequestHandler.Tcd.Entities.LaborCosts; 

    [TestClass]
    public class LaborCostTests : TestBase
    {
        /// <summary>
        /// Test method for LaborCost
        /// </summary>
        [TestMethod]
        public void LaborCost_Test()
        {
            Model.LaborCost laborCost = new Model.LaborCost();
            LaborCost nggLaborCost = new LaborCost();
            string result = Compare(laborCost, nggLaborCost);

            if (result != null)
            {
                Console.WriteLine("LaborCost : \r\n" + result);
                Assert.AreEqual(laborCost, nggLaborCost);
            }
            else
            {
                Console.WriteLine("Both the LaborCost properties are equal.");
            }
        }

        /// <summary>
        /// Test method for LaborCostContainer
        /// </summary>
        [TestMethod]
        public void LaborCostContainer_Test()
        {
            Model.LaborCostContainer laborCostContainer = new Model.LaborCostContainer();
            LaborCostContainer nggLaborCostContainer = new LaborCostContainer();
            string result = Compare(laborCostContainer, nggLaborCostContainer);

            if (result != null)
            {
                Console.WriteLine("LaborCostContainer : \r\n" + result);
                Assert.AreEqual(laborCostContainer, nggLaborCostContainer);
            }
            else
            {
                Console.WriteLine("Both the LaborCostContainer properties are equal.");
            }
        }
    }
}
