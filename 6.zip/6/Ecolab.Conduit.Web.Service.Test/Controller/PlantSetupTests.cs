﻿using WebModel = Ecolab.ConduitLocal.Web.Mapper;

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using ConduitLocal.Web.Controllers;
    using ConduitLocal.Web.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Moq;
    using Services.Interfaces;

    [TestClass]
    public sealed class PlantSetupTests : TestBase, IDisposable
    {
        private readonly List<CurrencyMaster> currMaster = new List<CurrencyMaster>();
        private readonly List<LanguageMaster> langMaster = new List<LanguageMaster>();
        private readonly Plant plant = new Plant();
        private readonly List<DimensionalUnitSystems> unitSystem = new List<DimensionalUnitSystems>();
        private Mock<IUserService> _userService;
        private PlantModel plantModel;
        private PlantSetupController plantSetupController;

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        public PlantSetupTests()
        {
            plant = new Plant { EcoalabAccountNumber = "econumber", Name = "test2", TmName = "Test TM Name", TmPhoneNumner = "0", DmName = "Test TM Name", DmPhoneNumner = "0", Chain = "test chain", ChainUnitNumber = "123456", ChainRegions = "123", CensusPriceKg = 20, Remarks = "Remarks", LanguageId = 1, CurrencyCode = "1", Rate = 60, ExportPath = null, DataLiveTime = 2, BudgetCustomer = true, UomId = 2, Logo = null };

            currMaster.Add(new CurrencyMaster { CurrencyCode = "DZD", CurrencyName = "Algeria (Dinar)" });

            langMaster.Add(new LanguageMaster { LanguageId = 1, Name = "en-EN" });

            unitSystem.Add(new DimensionalUnitSystems { UnitSystemId = 1, UnitSystem = "US Default" });

            plantModel = new PlantModel { EcoalabAccountNumber = "EcoNumber", LanguageId = 1, CurrencyCode = "2", Rate = 80, ExportPath = "\abc\test", DataLiveTime = 23, BudgetCustomer = true, UOMId = 1 };
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            plantSetupController.Dispose();
        }

        [TestInitialize]
        public void TestInitialize()
        {
            _userService = new Mock<IUserService>();

            //Mock the Plant Service using Moq
            var _plantService = new Mock<IPlantService>();
            _plantService.Setup(pS => pS.GetPlantDetails(UserId, "1")).Returns(plant);
            _plantService.Setup(pS => pS.GetCurrencyDetails()).Returns(currMaster);
            _plantService.Setup(pS => pS.GetLanguageDetails()).Returns(langMaster);
            _plantService.Setup(pS => pS.GetDimensionalUnitSystems()).Returns(unitSystem);
            this._plantService = _plantService.Object;

            plantSetupController = new PlantSetupController(_userService.Object, this._plantService);
        }

        //[TestMethod]
        //public void IndexTest()
        //{
        //    ViewResult result = plantSetupController.Index() as ViewResult;
        //    Assert.IsNotNull(result, "fetched plant data.");
        //}

        //[TestMethod]
        //public void SaveTest()
        //{
        //    plantSetupController.Save(plantModel);
        //}

        /// <summary>
        ///     Grabbages the collect.
        /// </summary>
        [TestCleanup]
        public void GrabbageCollect()
        {
            plantSetupController = null;
            _plantService = null;
        }
    }
}