﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Controllers;
    using System.Web.Http.Hosting;
    using System.Web.Http.Routing;

    public static class SetupControllerForTests
    {
        public static void SetupControllerForContlTests(ApiController controller, string url, string contlName)
        {
            HttpConfiguration config = new HttpConfiguration();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, url);
            IHttpRoute route = config.Routes.MapHttpRoute("DefaultApi", "api/{controller}/{id}");
            HttpRouteData routeData = new HttpRouteData(route, new HttpRouteValueDictionary { { "controller", contlName } });

            controller.ControllerContext = new HttpControllerContext(config, routeData, request);
            controller.Request = request;
            controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }
    }
}