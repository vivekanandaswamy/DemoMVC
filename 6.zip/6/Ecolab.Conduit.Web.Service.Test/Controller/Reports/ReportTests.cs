﻿namespace Ecolab.Conduit.Web.Service.Test.Controller.Reports
{
    using System;
    using System.Collections.Generic;
    using System.Security.Principal;
    using System.Web;
    using System.Web.Mvc;
    using ConduitLocal.Web.Controllers;
    using ConduitLocal.Web.Models.Reports;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports;
    using Models.Reports.ProductionEfficiency;
    using Models.Reports.ResourcesUtilization;
    using Models.Reports.WashingProcessValidation;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.Reports;

    /// <summary>
    ///     Test class for ReportTests
    /// </summary>
    [TestClass]
    public class ReportTests : TestBase
    {
        /// <summary>
        ///     AlarmDetails mock
        /// </summary>
        private readonly List<AlarmDetails> mockAlarmDetails = new List<AlarmDetails>();

        /// <summary>
        ///     AlarmSummary mock
        /// </summary>
        private readonly List<AlarmSummary> mockAlarmSummary = new List<AlarmSummary>();

        /// <summary>
        ///     ChemicalConsumption mock
        /// </summary>
        private readonly List<ChemicalConsumption> mockChemicalConsumption = new List<ChemicalConsumption>();

        /// <summary>
        ///     ChemicalInventory mock
        /// </summary>
        private readonly List<ChemicalInventory> mockChemicalInventoryLists = new List<ChemicalInventory>();

        /// <summary>
        ///     OperationsSummary mock
        /// </summary>
        private readonly List<OperationsSummary> mockOperationsSummary = new List<OperationsSummary>();

        /// <summary>
        ///     ProductionMix mock
        /// </summary>
        private readonly List<ProductionMix> mockProductionMix = new List<ProductionMix>();

        /// <summary>
        ///     ProductionSummary mock
        /// </summary>
        private readonly List<ProductionSummary> mockProductionSummary = new List<ProductionSummary>();

        /// <summary>
        ///     Report mock
        /// </summary>
        private readonly List<Report> mockReport = new List<Report>();

        /// <summary>
        ///     ReportAllColumns mock
        /// </summary>
        private readonly List<ReportAllColumns> mockReportAllColumns = new List<ReportAllColumns>();

        /// <summary>
        ///     ReportFilter mock
        /// </summary>
        private readonly List<ReportFilter> mockReportFilter = new List<ReportFilter>();

        /// <summary>
        ///     ReportFilterList mock
        /// </summary>
        private readonly List<ReportFilterList> mockReportFilterList = new List<ReportFilterList>();

        /// <summary>
        ///     ReportModel model
        /// </summary>
        private readonly ReportModel mockReportModel;

        /// <summary>
        ///     ReportRibbonOptions mock
        /// </summary>
        private readonly List<ReportRibbonOptions> mockReportRibbonOptions = new List<ReportRibbonOptions>();

        /// <summary>
        ///     ReportSettings mock
        /// </summary>
        private readonly ReportSettings mockReportSettings;

        /// <summary>
        ///     ReportSettingsModel mock
        /// </summary>
        private readonly List<ReportSettingsModel> mockReportSettingsModel = new List<ReportSettingsModel>();

        /// <summary>
        ///     ReportSwitchMode mock
        /// </summary>
        private readonly List<ReportSwitchMode> mockReportSwitchMode = new List<ReportSwitchMode>();

        /// <summary>
        ///     RibbonOption mock
        /// </summary>
        private readonly List<RibbonOption> mockRibbonOption = new List<RibbonOption>();

        /// <summary>
        ///     ControllerContext
        /// </summary>
        private ControllerContext controllerContext;

        /// <summary>
        ///     IAlarmReportService mock
        /// </summary>
        private Mock<IAlarmReportService> mockAlarmReportService;

        /// <summary>
        ///     IAlarmSummaryReportService mock
        /// </summary>
        private Mock<IAlarmSummaryReportService> mockAlarmSummaryReportService;

        /// <summary>
        ///     IChemicalConsumptionService mock
        /// </summary>
        private Mock<IChemicalConsumptionService> mockChemicalConsumptionService;

        /// <summary>
        ///     IChemicalInventoryReportService mock
        /// </summary>
        private Mock<IChemicalInventoryReportService> mockChemicalInventoryReportService;

        /// <summary>
        ///     mock context base
        /// </summary>
        private Mock<HttpContextBase> mockContextBase;

        /// <summary>
        ///     IOperationsSummaryService mock
        /// </summary>
        private Mock<IOperationsSummaryService> mockOperationsSummaryService;

        /// <summary>
        ///     ProductionMixReportService
        /// </summary>
        private Mock<IProductionMixReportService> mockproductionMixReportService;

        /// <summary>
        ///     Interface for Production Summary
        /// </summary>
        private Mock<IProductionSummaryReportService> mockProductionSummaryReportService;

        /// <summary>
        ///     ReportSettings list mock
        /// </summary>
        private List<ReportSettings> mockreport = new List<ReportSettings>();

        /// <summary>
        ///     IReportService mock
        /// </summary>
        private Mock<IReportCategoryService> mockReportCategoryService;

        /// <summary>
        ///     ReportLayOutModel mock
        /// </summary>
        private List<ReportLayoutModel> mockReportLayoutModel = new List<ReportLayoutModel>();

        /// <summary>
        ///     web model ReportModel
        /// </summary>
        private List<ConduitLocal.Web.Models.Reports.ReportModel> mockReportModelWeb;

        /// <summary>
        ///     IReportService mock
        /// </summary>
        private Mock<IReportService> mockReportService;

        /// <summary>
        ///     mock request base
        /// </summary>
        private Mock<HttpRequestBase> mockRequestBase;

        /// <summary>
        ///     IRibbonOptionService mock
        /// </summary>
        private Mock<IRibbonOptionService> mockRibbonOptionService;

        /// <summary>
        ///     IUserService mock
        /// </summary>
        private Mock<IUserService> mockUserService;

        private Mock<IReportSubView> mockReportSubView;

        /// <summary>
        ///     ReportController
        /// </summary>
        private ReportController reportController;

        /// <summary>
        ///     constructor
        /// </summary>
        public ReportTests()
        {
            mockReportModel = new ReportModel();
            mockReportModelWeb = new List<ConduitLocal.Web.Models.Reports.ReportModel>();
            mockReport.Add(new Report { ReportCategoryId = 1, ReportCategoryName = "", SubCategoryId = 1, SubCategoryName = "", ReportId = 1, ReportName = "", DisplayTopRecordsCount = 10, ShowOthers = false, ShowTotal = false });

            mockReportSettings = new ReportSettings { ReportId = 1 };
            mockReportSettingsModel.Add(new ReportSettingsModel { ReportId = 1 });

            mockReportAllColumns.Add(new ReportAllColumns { ColumnName = "1", DisplayOrder = 1, IsSortable = true, ViewModeId = 1, SwitchModeId = 1, IsVisible = true, IsChartDisplay = true });

            mockReportFilter.Add(new ReportFilter { FilterName = "1" });

            mockRibbonOption.Add(new RibbonOption { Name = "1" });

            mockReportSwitchMode.Add(new ReportSwitchMode { SwitchName = "1" });

            mockReportRibbonOptions.Add(new ReportRibbonOptions { IsChartDisplay = true, SwitchModeId = 1, SwitchName = "1", ColumnId = 1, ColumnName = "1", ReportFilterId = 1, FilterName = "1", DisplayOrder = 1, ViewModeId = 1, ViewModeName = "1", IsVisible = true });

            mockReportLayoutModel.Add(new ReportLayoutModel() { ReportCategoryId = 1, ReportCategoryName = "1", SubCategoryId = 1, SubCategoryName = "1", ReportId = 1, ReportName = "1", DisplayTopRecordsCount = 1, ShowOthers = true, ShowTotal = true, ChartType = "1" });

            //mockProductionMix.Add(new ProductionMix { FormulaName = "1", TotalLoad = 1, TargetLoad = 1, ProductionDiff = 1, LoadEfficiency = 1, ProductionMixValue = 1, ActualProductionperhour = 1, TargetProductionperhour = 1, NumberOfLoads = 1, NumberOfPieces = 1, Rewash = 1, TextileCategoryEcolab = "1", TextileCategoryCustomer = "1", ChainFormula = "1" });

            mockProductionSummary.Add(new ProductionSummary { Period = "1", ActualProduction = 1, TargetProduction = 1, NoOfLoads = 1, Actualproductionhour = 1, Targetproductionhour = 1, MachineGroup = "1", Machine = "1" });

            mockChemicalInventoryLists.Add(new ChemicalInventory
            {
                // ProductId = 1, 
                ChemicalName = "Test",
                LastInventory = 11,
                InventoryBasedConsumption = 12,
                DispencerBasedConsumption = 13,
                TodayEstimateInventory = 232,
                AvgDailyNeeds = 23,
                AvgDailyCost = 45,
                AvgDailyCostPerLoad = 12,
                AvgDailyNeedsLY = 25,
                DayBeforeOutOfStock = 3
            });

            mockOperationsSummary.Add(new OperationsSummary { Formula = "Formula1", ActualProduction = 3444, ProductionMixValue = 444, NoOfLoads = 454, ActualWaterUsage = 66, ActualWaterUsagePerLoad = 77, TargetWaterUsagePerLoad = 7, ActualEnergy = 78, ActualEnergyperload = 89, EnergyTargetperload = 90, ActualChemicalLoadPerLoad = 7, TargetChemicalLoadPerLoad = 8, SwitchMode = "Formula wise" });
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            mockContextBase = new Mock<HttpContextBase>();
            mockRequestBase = new Mock<HttpRequestBase>();
            controllerContext = new ControllerContext { HttpContext = GetMockedHttpContext() };

            mockUserService = new Mock<IUserService>();
            mockReportSubView=new Mock<IReportSubView>();
            mockReportCategoryService = new Mock<IReportCategoryService>();
            mockRibbonOptionService = new Mock<IRibbonOptionService>();
            mockReportService = new Mock<IReportService>();
            mockproductionMixReportService = new Mock<IProductionMixReportService>();
            mockAlarmReportService = new Mock<IAlarmReportService>();
            mockChemicalConsumptionService = new Mock<IChemicalConsumptionService>();
            mockProductionSummaryReportService = new Mock<IProductionSummaryReportService>();
            mockAlarmSummaryReportService = new Mock<IAlarmSummaryReportService>();
            mockChemicalInventoryReportService = new Mock<IChemicalInventoryReportService>();
            mockOperationsSummaryService = new Mock<IOperationsSummaryService>();

            mockReportCategoryService.Setup(Ut => Ut.FetchReports(It.IsAny<int>(), It.IsAny<int>())).Returns(mockReport);
           // mockReportService.Setup(RS => RS.GenerateReport(mockReportSettings, "1")).Returns(mockReportModel);

            mockRibbonOptionService.Setup(RO => RO.FetchReportAllColumns(mockReportSettings)).Returns(mockReportAllColumns);
            mockRibbonOptionService.Setup(RO => RO.FetchReportchartDisplay(It.IsAny<int>(), It.IsAny<string>())).Returns(mockReportAllColumns);
            mockRibbonOptionService.Setup(RO => RO.FetchReportFilters(It.IsAny<int>(), It.IsAny<string>())).Returns(mockReportFilter);
            mockRibbonOptionService.Setup(RO => RO.FetchReportFiltersDataByFilterId(It.IsAny<int>(), It.IsAny<string>())).Returns(mockReportFilterList);
            mockRibbonOptionService.Setup(RO => RO.FetchRibbonOption(It.IsAny<int>())).Returns(mockRibbonOption);
            mockRibbonOptionService.Setup(RO => RO.FetchRibbonOptionDataForReport(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(mockReportRibbonOptions);
            mockRibbonOptionService.Setup(RO => RO.FetchSwitchCategories(It.IsAny<int>(), It.IsAny<string>())).Returns(mockReportSwitchMode);
            mockChemicalConsumptionService.Setup(CC => CC.FetchChemicalCunsumptionData(mockReportSettings)).Returns(mockChemicalConsumption);
            mockproductionMixReportService.Setup(PM => PM.FetchProductionMixReportDetails(mockReportSettings)).Returns(mockProductionMix);
            mockProductionSummaryReportService.Setup(PS => PS.FetchProductionSummaryReportDetails(mockReportSettings)).Returns(mockProductionSummary);
            mockAlarmReportService.Setup(AS => AS.FetchAlarmDetails(mockReportSettings)).Returns(mockAlarmDetails);
            mockAlarmSummaryReportService.Setup(AR => AR.FetchAlarmSummaryReport(mockReportSettings)).Returns(mockAlarmSummary);
            mockChemicalInventoryReportService.Setup(CHI => CHI.FetchChemicalInventoryReportData(this.mockReportSettings)).Returns(mockChemicalInventoryLists);
            mockOperationsSummaryService.Setup(OS => OS.FetchOperationsSummaryData(mockReportSettings)).Returns(mockOperationsSummary);
            reportController = new ReportController(mockUserService.Object, _plantService.Object, mockRibbonOptionService.Object, mockReportCategoryService.Object, mockproductionMixReportService.Object, mockReportSubView.Object) { ControllerContext = controllerContext };
        }

        #endregion

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            mockReportLayoutModel = null;
            reportController.Dispose();
        }

        [TestMethod]
        public void Report_Test()
        {
            ViewResult result = reportController.Index() as ViewResult;
            Assert.IsNotNull(result, "fetched the report data.");
        }

        //[TestMethod]
        //public void GetDataForReport_Test()
        //{
        //    LocalReports res = reportController.GetDataForReport(mockReportLayoutModel);
        //    Assert.IsNotNull(res);
        //}

        [TestMethod]
        public void GetReportDetails_Test()
        {
            try
            {
                var result = reportController.GetReport(2);

                Assert.IsNotNull(result, "Fetched Successfully");
            }
            catch (Exception e)
            {
               Console.WriteLine(e.Message);
            }
        }

        [TestMethod]
        public void GetReportChart_Test()
        {
            try
            {
                var result = reportController.GetReport(2);
                Assert.IsNotNull(result, "Fetched Successfully");
            }
            catch (Exception e)
            {
               Console.WriteLine(e.Message);
            }
        }

        /// <summary>
        ///     Returns the Http Context with user identity
        /// </summary>
        /// <returns>HttpContextBase</returns>
        private HttpContextBase GetMockedHttpContext()
        {
            var context = new Mock<HttpContextBase>();
            var request = new Mock<HttpRequestBase>();
            var response = new Mock<HttpResponseBase>();
            var session = new Mock<HttpSessionStateBase>();
            var server = new Mock<HttpServerUtilityBase>();
            var user = new Mock<IPrincipal>();
            var identity = new Mock<IIdentity>();

            context.Setup(ctx => ctx.Request).Returns(request.Object);
            context.Setup(ctx => ctx.Response).Returns(response.Object);
            context.Setup(ctx => ctx.Session).Returns(session.Object);
            context.Setup(ctx => ctx.Server).Returns(server.Object);
            context.Setup(ctx => ctx.User).Returns(user.Object);
            user.Setup(x => x.Identity).Returns(identity.Object);
            identity.Setup(id => id.IsAuthenticated).Returns(true);
            identity.Setup(id => id.Name).Returns("test");
            context.Setup(x => x.User.IsInRole("Admin")).Returns(true);

            return context.Object;
        }
    }
}