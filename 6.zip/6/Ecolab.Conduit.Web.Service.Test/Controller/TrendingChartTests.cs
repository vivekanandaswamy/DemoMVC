﻿// -----------------------------------------------------------------------
// <copyright file="TrendingChartTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The TrendingChartTests object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Moq;
    using Services.Interfaces;
    using Ecolab.Services;

    [TestClass]
    public sealed class TrendingChartTests : TestBase, IDisposable
    {
        #region "Properties"

        /// <summary>
        ///     MachineSetupTunnel
        /// </summary>
        private readonly List<MachineSetupTunnel> mockMachTunnels = new List<MachineSetupTunnel>();

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     ConduitChartParameterMapping
        /// </summary>
        private List<ConduitChartParameterMapping> mockParameters = new List<ConduitChartParameterMapping>();

        /// <summary>
        ///     interface IMeterService
        /// </summary>
        private Mock<ITrendingChartService> trendingChartService;

        /// <summary>
        ///     Api controller MeterController
        /// </summary>
        private TrendingChartController trendingChartController;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        ///     ConduitChartParameterMapping
        /// </summary>
        private readonly List<ConduitChartParameterMapping> mockConduitChartParMaps = new List<ConduitChartParameterMapping>();

        /// <summary>
        ///     ConduitChartParameterMapping
        /// </summary>
        private readonly List<TunnelReading> mockTunnelReadings = new List<TunnelReading>();

        #endregion       

        public TrendingChartTests()
        {
            mockMachTunnels.Add(new MachineSetupTunnel
            {
                GroupId = 1,
                MachineInternalId = 2,
                MachineName = "test",
                NumberOfcompartmentals = 10,
                MachineType = "testmach"
            });

            mockConduitChartParMaps.Add(new ConduitChartParameterMapping
            {
                ParameterID = 1,
                ParameterName = "Name",
                WasherId = 1,
                MappedCompartment = 1,
                GroupId = 1
            });

            mockTunnelReadings.Add(new TunnelReading
            {
                Actual = "11",
                CompartmentId = 2,
                Desired = "12",
                GroupId = 2,
                ParamterName = "Name",
                TimeStamp = DateTime.Now
            });
           
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            trendingChartController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserName = "test";
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "Admin";
            HttpContext.Current.User = custPrinciple;

            userService = new Mock<IUserService>();
            _plantService = new Mock<IPlantService>();

            ecolabAccountNumber = "1";
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);

            trendingChartService = new Mock<ITrendingChartService>();
            trendingChartService.Setup(Ut => Ut.GetTunnelDetails()).Returns(mockMachTunnels);
            trendingChartService.Setup(Ut => Ut.GetChemicalChartParametersByTunnelId(It.IsAny<int>())).Returns(mockConduitChartParMaps);
            trendingChartService.Setup(Ut => Ut.GetTrendingdataDetails(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<int>(), It.IsAny<string>())).Returns(mockTunnelReadings);
           
            HttpConfiguration config = new HttpConfiguration();
            trendingChartController = new TrendingChartController(userService.Object, _plantService.Object, trendingChartService.Object) { Request = new HttpRequestMessage() };
            trendingChartController.Request = new HttpRequestMessage();
            trendingChartController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        /// <summary>
        ///     Get the tunnel details
        /// </summary>
        [TestMethod]
        public void FetchTunnelDetails_Test()
        {
            List<MachineSetupTunnel> result = trendingChartController.GetTunnelDetails();
            Assert.IsNotNull(result, "Tunnel data");
        }

        /// <summary>
        ///     Get the Parameters By TunnelId 
        /// </summary>
        [TestMethod]
        public void GetParametersByTunnelId_Test()
        {
            int id = 1;
            int chartId = 2;
            List<ConduitChartParameterMapping> result = trendingChartController.GetParametersByTunnelId(id, chartId);
            Assert.IsNotNull(result, "Tunnel data");
        }
        /// <summary>
        ///     Get By Filters 
        /// </summary>
        [TestMethod]
        public void GetByFilters_Test()
        {
           int chartId = 2;
           int washerId =1;
           int compId = 1;
           int parameterId = 1;
           DateTime? startDate = DateTime.Now;
           DateTime? endDate = DateTime.Now;
           IEnumerable<Dictionary<string, object>> result = trendingChartController.GetByFilters(chartId, washerId, compId, parameterId, startDate, endDate);
           Assert.IsNotNull(result, "Tunnel data");
        }       
    }
}