﻿// -----------------------------------------------------------------------
// <copyright file="TestBase.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Base class for Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Web;
    using Data.Access;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Moq;
    using Services;
    using Services.Interfaces;

    /// <summary>
    ///     TestBase
    /// </summary>
    [TestClass]
    public class TestBase
    {
        /// <summary>
        ///     Model Plant
        /// </summary>
        protected readonly Plant plant;

        /// <summary>
        ///     plant Service
        /// </summary>
        protected Mock<IPlantService> _plantService;

        /// <summary>
        ///     EcolabAccountNumber
        /// </summary>
        public string ecolabAccountNumber;

        /// <summary>
        /// Currency List
        /// </summary>
        protected readonly List<CurrencyMaster> currencyList = new List<CurrencyMaster>();

        /// <summary>
        /// Dimensional unit List
        /// </summary>
        protected readonly List<DimensionalUnitSystems> dimensionalList = new List<DimensionalUnitSystems>();

        protected readonly List<LanguageMaster> languages = new List<LanguageMaster>();

        /// <summary>
        ///     User Id
        /// </summary>
        public TestBase()
        {
            languages.Add(new LanguageMaster { Name = "English US", LanguageId = 1, Locale = "en-US" });
            plant = new Plant
            {
                EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Name = "test",
                TmName = "test",
                TmPhoneNumner = "11",
                DmName = "test",
                DmPhoneNumner = "test",
                Chain = "test",
                ChainUnitNumber = "12345",
                ChainRegions = "222",
                CensusPriceKg = 20,
                Remarks = "444",
                LanguageId = 1,
                CurrencyCode = "fff",
                Rate = 123,
                ExportPath = "/fdgf/",
                DataLiveTime = 1,
                BudgetCustomer = true,
                UomId = 1,
                Logo = string.Empty,
                //RegionID = 1,
                RegionName = "gfhgf",
                LanguageName = "fdgf",
                CurrencyName = "ggd",
                UnitSystem = "fgfg",
                AllowManualRewash = false,
                PlantCustAddr = new PlantCustAddress { BillingAddr1 = "", BillingAddr2 = "", City = "", Country = "", Zip = "" },
                ShippingAddr = new ShippingAddress { ShippingAddr1 = "", ShippingAddr2 = "", Shippingcity = "", Shippingcountry = "", Shippingzip = "" },
                LastModifiedTimeStamp = DateTime.Now
            };

            currencyList.Add(new CurrencyMaster { CurrencyCode = "USD", CurrencyName = "US Dollars" });
            dimensionalList.Add(new DimensionalUnitSystems { UnitSystemId = 1, UnitSystem = "US Default" });
        }

        /// <summary>
        ///     Gets User Id
        /// </summary>
        public int userId { get; private set; }

        /// <summary>
        ///     Gets UOMId
        /// </summary>
        public int uomId { get; private set; }

        [TestInitialize]
        public void Init()
        {
            HttpContext.Current = new HttpContext(new HttpRequest("", "http://conduitlocal.com", ""), new HttpResponse(new StringWriter()));
            CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1, UserRoleIds = "1,9", UserRoles = "Admin,Sales" };
            ((CustomPrincipal)custPrinciple).EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            HttpContext.Current.User = custPrinciple;
            userId = custPrinciple.UserId;
            uomId = plant.UomId;
            _plantService = new Mock<IPlantService>();
            _plantService.Setup(_ => _.GetPlantDetails(1, string.Empty)).Returns(plant);
            _plantService.Setup(x => x.GetCurrencyDetails()).Returns(currencyList);
            _plantService.Setup(x => x.GetDimensionalUnitSystems()).Returns(dimensionalList);
            _plantService.Setup(x => x.GetLanguageDetails()).Returns(languages);
            ecolabAccountNumber = plant.EcoalabAccountNumber;

            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            Database.ApplicationMode = Entities.ApplicationMode.Local;


        }

        /// <summary>
        ///     Gets Plant Details
        /// </summary>
        /// <returns>PlantModel</returns>
        protected Plant GetPlantDetails()
        {
            return plant; //plantService.GetPlantDetails(UserId);
        }
    }
}