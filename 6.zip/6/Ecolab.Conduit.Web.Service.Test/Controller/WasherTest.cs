﻿
namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using Ecolab.ConduitLocal.Web.Api.Washers;
    using Ecolab.ConduitLocal.Web.Models.Washers;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers;
    using Ecolab.Services.Interfaces.WasherGroup;
    using Ecolab.Services.Interfaces.Washers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Services;
    using Services.Interfaces;    

    [TestClass]
    public class WasherTest : TestBase
    {
        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private Mock<IWasherGroupService> washerGroupService;

        /// <summary>
        ///     Interface object for Washer Services.
        /// </summary>
        private Mock<IWasherServices> washerServices;

        /// <summary>
        ///     Interface object for Washer Services.
        /// </summary>
        private Mock<IInjectionService> injectiionServices;

        /// <summary>
        ///     Interface object for User Services.
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        ///  Interface object for Plant Services.
        /// </summary>
        private Mock<IPlantService> plantService;

        /// <summary>
        /// WasherController
        /// </summary>
        private WasherController washerController;

        /// <summary>
        /// Washers
        /// </summary>
        IEnumerable<Washers> washers;

        /// <summary>
        /// Washers
        /// </summary>
        List<Washers> washersList = new List<Washers>();

        /// <summary>
        /// Alarms
        /// </summary>
        IEnumerable<Alarms> alarms;

        /// <summary>
        /// Alarms
        /// </summary>
        List<Alarms> alarmsList = new List<Alarms>();

        /// <summary>
        /// WasherGroup
        /// </summary>
        IEnumerable<WasherGroup> washerGroup;

        /// <summary>
        /// WasherGroup
        /// </summary>
        List<WasherGroup> washerGroupsList = new List<WasherGroup>();

        /// <summary>
        /// AlarmsModel
        /// </summary>
        AlarmsModel alarmsModel;

        /// <summary>
        /// Alarms
        /// </summary>
        Alarms alarmsData;

        public WasherTest()
        {
            washersList.Add(new Washers
            {
                ControllerName = "Name",
                EcolabAccountNumber = "1",
                Id = 1,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                Maxload = 8,
                MaxNumberOfRecords = 10,
                MyServiceCustMchGrpGuid = Guid.NewGuid(),
                MyServiceCustMchGuid = Guid.NewGuid(),
                Size = "Small",
                WasherControllerId = 3,
                WasherGroupId = 7,
                WasherGroupName = "GroupName",
                WasherModel = "WasherModel",
                WasherName = "WasherName",
                WasherNumber = 9,
                WasherType = "Type",
                WasherTypeFlag = true
            });

            washers = washersList;

            alarmsList.Add(new Alarms
            {
                Active = true,
                AlarmMachineMappingId = 7,
                AlarmMachineMappingIds = new List<int>() { 1, 2, 3 },
                ControllerModelId = 6,
                ControllerTypelId = 3,
                Description = "Description",
                DisplayOrder = 4,
                EcolabAccountNumber = "1",
                Id = 1,
                IsDefault = true,
                IsDeleted = false,
                MachineNumber = 2,
                MaxNumberOfRecords = 10,
                ResourceKey = "ResourceKey"
            });

            alarms = alarmsList;

            washerGroupsList.Add(new WasherGroup
            {
                EcolabAccountNumber = "1",
                Id = 1,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                WasherGroupId = 7,
                WasherGroupName = "GroupName"
            });

            washerGroup = washerGroupsList;

            alarmsModel = new AlarmsModel()
            {
                Active = true,
                AlarmMachineMappingId = 7,
                AlarmMachineMappingIds = new List<int>() { 1, 2, 3 },
                ControllerModelId = 6,
                ControllerTypelId = 3,
                Description = "Description",
                DisplayOrder = 4,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Id = 1,
                IsDefault = true,
                MachineNumber = 2,
                MaxNumberOfRecords = 10,
                ResourceKey = "ResourceKey"
            };

            alarmsData = new Alarms
            {
                Active = true,
                AlarmMachineMappingId = 7,
                AlarmMachineMappingIds = new List<int>() { 1, 2, 3 },
                ControllerModelId = 6,
                ControllerTypelId = 3,
                Description = "Description",
                DisplayOrder = 4,
                EcolabAccountNumber = "1",
                Id = 1,
                IsDefault = true,
                IsDeleted = false,
                MachineNumber = 2,
                MaxNumberOfRecords = 10,
                ResourceKey = "ResourceKey"
            };
        }

        [TestInitialize]
        public void MockSetUp()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserName = "test";
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "Admin";
            custPrinciple.EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            HttpContext.Current.User = custPrinciple;

            userService = new Mock<IUserService>();

            plantService = new Mock<IPlantService>();
            ecolabAccountNumber = "1";
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);

            washerGroupService = new Mock<IWasherGroupService>();
            washerServices = new Mock<IWasherServices>();
            injectiionServices = new Mock<IInjectionService>();
            DateTime lastModifiedTimeStamp;

            washerServices.Setup(ws => ws.GetWashersDetails(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Boolean>())).Returns(washers);
            washerServices.Setup(ws => ws.DeleteWasher(It.IsAny<bool>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(true);
            washerServices.Setup(ws => ws.DeleteConventional(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(true);
            washerServices.Setup(ws => ws.GetAlarmSetupDetails(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(alarms);
            washerGroupService.Setup(ws => ws.GetWasherGroupDetails(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(washerGroupsList);
            washerServices.Setup(ws => ws.SaveAlarmStatus(alarmsData, It.IsAny<int>(), It.IsAny<string>())).Returns(1);
            washerServices.Setup(ws=>ws.GetAlarmStatusDataForWasher(It.IsAny<string>(),It.IsAny<int>(),It.IsAny<int>())).Returns(alarmsList);

            HttpConfiguration config = new HttpConfiguration();
            washerController = new WasherController(washerServices.Object, washerGroupService.Object, injectiionServices.Object);
            washerController.Request = new HttpRequestMessage();
            washerController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        /// <summary>
        /// Unit test for GetWashersDetails
        /// </summary>
        [TestMethod]
        public void GetWashersDetails_Test()
        {
            string ecolabAccountNumber = "1";
            

            IEnumerable<WashersModel> washersModel = washerController.GetWashersDetails(ecolabAccountNumber);
            List<WashersModel> washersModels = new List<WashersModel>();
            Assert.IsNotNull(washersModels.Count > 0, "Get the washers details.");
        }

        /// <summary>
        /// Unit test for Tunnel Washers Delete
        /// </summary>
        [TestMethod]
        public void WasherDelete_Tunnel_Test()
        {
            string ecolabAccountNumber = "1";
            int washerId = 1;
            bool isTunnel = true;
            int washergroupId = 1;

            bool isDelete = washerController.WasherDelete(washerId, isTunnel, ecolabAccountNumber, washergroupId);

            Assert.IsTrue(isDelete, "Tunnel Washers are deleted.");
        }

        /// <summary>
        /// Unit test for Conventional Washers Delete
        /// </summary>
        [TestMethod]
        public void WasherDelete_Conventional_Test()
        {
            string ecolabAccountNumber = "1";
            int washerId = 1;
            bool isTunnel = false;
            int washergroupId = 1;

            bool isDelete = washerController.WasherDelete(washerId, isTunnel, ecolabAccountNumber, washergroupId);

            Assert.IsTrue(isDelete, "Conventional Washers have been deleted.");
        }

        /// <summary>
        /// Unit test forGetAlarmSetupDetails
        /// </summary>
        [TestMethod]
        public void GetAlarmSetupDetails_Test()
        {
            int controllerModelId = 1;
            int controllerTypeId = 2;
            int machineNumber = 7;
            int washerGroupId = 8;
            string ecoLabAccountNumber = "1";
            int WasherGroupTypeId = 2;
            int tunnelId = 1;
            AlarmsData alarmsData = washerController.GetAlarmSetupDetails(controllerModelId, controllerTypeId, machineNumber, washerGroupId, ecoLabAccountNumber, WasherGroupTypeId, tunnelId, false);

            Assert.IsNotNull(alarmsData, "Get the Alarm Setup Details.");
        }

        ///// <summary>
        ///// Unit test for SaveAlarmStatus
        ///// </summary>
        //[TestMethod]
        //public void SaveAlarmStatus_Test()
        //{
        //    HttpResponseMessage result = washerController.SaveAlarmStatus(alarmsModel);
        //   Assert.IsNotNull(result, "Alarm Status is saved.");
        //}
    }
}
