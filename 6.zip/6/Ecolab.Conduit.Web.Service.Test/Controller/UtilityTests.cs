﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Services.Interfaces.PlantSetup;
    using Moq;
    using Ecolab.ConduitLocal.Web.Api;
    using System.Collections.Generic;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Services.Interfaces;
    using System.Web.Http;
    using System.Net.Http;
    using System.Web.Http.Hosting;
using Ecolab.Models.Common;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup;
    using Ecolab.Services;
    using System.Web;
    using System.Configuration;

    [TestClass]
    public class UtilityTests : TestBase
    {

        /// <summary>
        ///     Utility Service
        /// </summary>
        private Mock<IUtilityService> mockUtilityService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> mockUserService;

        /// <summary>
        /// Api controller 
        /// </summary>
        private UtilityController utilityController;

        /// <summary>
        /// Service model
        /// </summary>
        List<Utility> mockUtilities = new List<Utility>();

        /// <summary>
        /// Service model
        /// </summary>
        List<DeviceType> mockDeviceTypes = new List<DeviceType>();

        /// <summary>
        /// Service model
        /// </summary>
        List<DeviceModel> mockDeviceModels = new List<DeviceModel>();

        /// <summary>
        /// Web model
        /// </summary>
        UtilityModel mockUtilityModel;

        /// <summary>
        /// Web model
        /// </summary>
        UtilityModel mockUtilityModelUpdate;

		/// <summary>
		/// Web model List
		/// </summary>
		List<UtilityModel> mockUtilityModelList;

		#region "Test Initialization"

		/// <summary>
		///     Mock Setup
		/// </summary>
		[TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            HttpContext.Current.User = custPrinciple;

            mockUserService = new Mock<IUserService>();
            mockUtilityService = new Mock<IUtilityService>();
            DateTime lastModifiedTimeStamp;
            int id = 101;
            mockUtilities.Add(new Utility
            {
                Comment = "Comments",
                DeviceModelDesc = "DeviceModelDesc",
                DeviceModelId = 1,
                DeviceName = "DeviceName",
                DeviceNoteDesc = "DeviceNoteDesc",
                DeviceNumber = 1,
                DeviceTypeDesc = "DeviceTypeDesc",
                DeviceTypeId = 1,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                GroupId = 1,
                Id = 1,
                InstallDate = DateTime.Now,
                IsDeleted = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                MyServiceCustWtrEnrgDvcGUID = Guid.NewGuid()
            });

            mockUtilityService.Setup(us => us.GetUtilityDetails(It.IsAny<string>(), It.IsAny<Boolean?>())).Returns(mockUtilities);
            mockUtilityService.Setup(us => us.GetDeviceTypeDetails()).Returns(mockDeviceTypes);
            mockUtilityService.Setup(us => us.GetDeviceModelDetails(It.IsAny<int>(), this.ecolabAccountNumber)).Returns(mockDeviceModels);
            mockUtilityService.Setup(us => us.SaveUtilityDetails(It.IsAny<Utility>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            mockUtilityService.Setup(us => us.DeleteUtilityDetails(It.IsAny<int>(), It.IsAny<int>(),It.IsAny<string>(), out lastModifiedTimeStamp)).Returns(id);

            HttpConfiguration config = new HttpConfiguration();
            utilityController = new UtilityController(mockUserService.Object, mockUtilityService.Object, _plantService.Object) { Request = new HttpRequestMessage() };
            utilityController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            UtilityController.Utilities = mockUtilities;
        }

        #endregion

        /// <summary>
        /// Test method for GeUtilityDetails
        /// </summary>
        [TestMethod]
        public void GetUtilityTest()
        {
            IEnumerable<UtilityModel> utilityModel = utilityController.GetUtility();
            Assert.IsNotNull(utilityModel, "Get the utility details");
        }

        /// <summary>
        /// Test method for GetDeviceTypeDetails
        /// </summary>
        [TestMethod]
        public void GetDeviceTypeTest()
        {
            int id = 1;
            Dictionary<string, object> result = utilityController.GetUtilityOnEdit(id);
            Assert.IsNotNull(result, "Get the utility details");
        }

        /// <summary>
        /// Test method for GetDeviceModelDetails
        /// </summary>
        [TestMethod]
        public void GetDeviceModelTest()
        {
            int id = 1;
            IEnumerable<DevicemodelModel> result = utilityController.GetDeviceModelDetails(id);
            Assert.IsNotNull(result, "Get the utility details");
        }


        /// <summary>
        /// Test method for Create utility details
        /// </summary>
        [TestMethod]
        public void CreateUtilityTest()
        {
			mockUtilityModelList = new List<UtilityModel>();
			mockUtilityModelList.Add(mockUtilityModel);
			HttpResponseMessage result = utilityController.CreateUtility(mockUtilityModelList);
            Assert.IsNotNull(result, "Created the utility details");
        }

        /// <summary>
        /// Test method for update utility details
        /// </summary>
        //[TestMethod]
        //public void PutTest()
        //{
        //    HttpResponseMessage result = utilityController.Put(mockUtilityModelUpdate);
        //    Assert.IsNotNull(result, "Updated the utility details");
        //}

        /// <summary>
        /// Test method for delete utility details
        /// </summary>
        [TestMethod]
        public void DeleteUtilityTest()
        {
			mockUtilityModelList = new List<UtilityModel>();
			mockUtilityModelList.Add(mockUtilityModelUpdate);
			HttpResponseMessage result = utilityController.DeleteUtility(mockUtilityModelList);
            Assert.IsNotNull(result, "Deleted the utility details");
        }

        public UtilityTests()
        {
            mockUtilities.Add(new Utility
            { 
                Comment = "Comments", 
                DeviceModelDesc = "DeviceModelDesc", 
                DeviceModelId = 1, 
                DeviceName = "DeviceName", 
                DeviceNoteDesc = "DeviceNoteDesc",
                DeviceNumber =1,
                DeviceTypeDesc = "DeviceTypeDesc",
                DeviceTypeId = 1,
                EcolabAccountNumber = "040242802",
                GroupId =1,
                Id =1,
                InstallDate = DateTime.Now,
                IsDeleted = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                MyServiceCustWtrEnrgDvcGUID = Guid.NewGuid()
            });

            mockDeviceTypes.Add(new DeviceType
            {
                Description = "Description",
                DeviceTypeId =1,
                IsDeleted= false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                MyServiceDeviceTypeId =1 ,
                MyServiceModDtTm = DateTime.Now,
                RegionCode = 2                
            });

            mockDeviceModels.Add(new DeviceModel
            {
                Description = "Description",
                DeviceModelId = 1,
                DeviceTypeId = 1,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                MyServiceLastSynchTime = DateTime.Now,
                MyServiceWtrEnrgDvcId = 1,
                RegionCode = "2"       
            });

            mockUtilityModel = new UtilityModel()
            {
                Comment = "Comments",
                DeviceModelDesc = "DeviceModelDesc",
                DeviceModelId = 1,
                DeviceName = "DeviceName",
                DeviceNoteDesc = "DeviceNoteDesc",
                DeviceNumber = 1,
                DeviceTypeDesc = "DeviceTypeDesc",
                DeviceTypeId = 1,
                EcolabAccountNumber = "040242802",                          
                InstallDate = "5/20/2015",
                IsDeleted = false,                
                LastModifiedTimestampAtCentral = DateTime.Now,                
                MyServiceCustWtrEnrgDvcGUID = Guid.NewGuid()
            };

            mockUtilityModelUpdate= new UtilityModel()
            {
                Comment = "Comments",
                DeviceModelDesc = "DeviceModelDesc",
                DeviceModelId = 1,
                DeviceName = "DeviceName",
                DeviceNoteDesc = "DeviceNoteDesc",
                DeviceNumber = 1,
                Id = 1,
                DeviceTypeDesc = "DeviceTypeDesc",
                DeviceTypeId = 1,
                EcolabAccountNumber = "040242802",                          
                InstallDate = "5/20/2015",
                IsDeleted = false,                
                LastModifiedTimestampAtCentral = DateTime.Now,                
                MyServiceCustWtrEnrgDvcGUID = Guid.NewGuid()
            };
        }
    }
}
