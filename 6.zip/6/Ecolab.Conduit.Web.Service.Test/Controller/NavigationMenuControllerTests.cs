﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuControllerTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Navigation Menu Controller object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.NavigationMenu;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.NavigationMenu;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.NavigationMenu;

    [TestClass]
    public sealed class NavigationMenuControllerTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public NavigationMenuControllerTests()
        {
            _mockNavigationMenu.Add(new NavigationMenu { Id = 1, Name = "1", ParentId = 1, TypeId = 1, TypeName = "1", ControllerTypeId = 1, ControllerModelId = 1, WasherGroupId = 1, WasherTypeFlag = true, WasherGroupTypeId = 1 });
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            _userService = null;
            _navigationMenuService = null;
            _plantService = null;
            _mockNavigationMenu = null;
            navigationMenuController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            _navigationMenuService = new Mock<INavigationMenuService>();
            _navigationMenuService.Setup(Alr => Alr.FetchNavigationMenuDetails(It.IsAny<string>(), It.IsAny<string>())).Returns(_mockNavigationMenu);

            HttpConfiguration config = new HttpConfiguration();
            navigationMenuController = new NavigationMenuController(_userService.Object, _plantService.Object, _navigationMenuService.Object) { Request = new HttpRequestMessage() };
            navigationMenuController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        [TestMethod]
        public void FetchNavigationMenuItems()
        {
            NavigationMenuDataViewModel result = navigationMenuController.FetchNavigationMenuItems();
            Assert.IsNotNull(result, "Alarm data");
        }

        #region "Properties"

        /// <summary>
        ///     interface IAlarmService
        /// </summary>
        private Mock<INavigationMenuService> _navigationMenuService;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     Alarm class
        /// </summary>
        private List<NavigationMenu> _mockNavigationMenu = new List<NavigationMenu>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller AlarmController
        /// </summary>
        private NavigationMenuController navigationMenuController;

        #endregion
    }
}