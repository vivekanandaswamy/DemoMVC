﻿using WebModel = Ecolab.ConduitLocal.Web.Models;
using Model = Ecolab.Models;

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.StorageTanks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.StorageTanks;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.Plc;
    using Services.Interfaces.StorageTanks;
    using Ecolab.Services;
    using System.Web;
    using Ecolab.Models;
    using System.Configuration;

    [TestClass]
    public sealed class StorageTanksTests : TestBase, IDisposable
    {
        #region "Setup data"

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        public StorageTanksTests()
        {
            _mockStorageTanks = new List<Tanks> { new Tanks { TankId = 991, TankName = "TestTankModel", ControllerName = "TestontrollerModel", EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") } };

            _mockTank = new Tanks { TankId = 991, TankName = "TestTankModel", ControllerName = "TestontrollerModel", EcolabAccountNumber = "1" };

            _storageTankModel = new TanksModel { TankId = 990, TankName = "TestTankWebModel", ControllerName = "TestontrollerWebModel", EcolabAccountNumber = "1" };

           // _storageTankModelList = new List<TanksModel> { new TanksModel { TankId = 990, TankName = "TestTankWebModel", ControllerName = "TestontrollerWebModel", EcolabAccountNumber = "1" } };

            mockuomSubUnits.Add(new UOMSubUnit 
            {
                SubUnit_Source = "lbs",
                SubUnit_Target = "kgs",
                Unit = "kgs",
                UnitSystemId = 1,
                UsageKey = ""            
            });
        }

        #endregion

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            storageTankController.Dispose();
        }

        #region "Test Initialization"

        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserName = "test";
            custPrinciple.UserRoleIds = "1,9";
            custPrinciple.UserRoles = "Admin,Sales";
            HttpContext.Current.User = custPrinciple;

            _userService = new Mock<IUserService>();
            _storageTankService = new Mock<IStorageTanksService>();
            _controllerSetupService = new Mock<IControllerSetupService>();
            _pumpServices = new Mock<IPumpsService>();
            _plcService = new Mock<IPlcService>();

            DateTime lastModifiedTimeStamp;
            _storageTankService.Setup(Pc => Pc.SaveStorageTank(_mockTank, It.IsAny<int>(), out lastModifiedTimeStamp));
            _storageTankService.Setup(Pc => Pc.UpdateStorageTank(_mockTank, It.IsAny<int>(), out lastModifiedTimeStamp));
            _storageTankService.Setup(Pc => Pc.DeleteStorageTanks(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), out lastModifiedTimeStamp)).Returns(true);
            _storageTankService.Setup(st => st.GetTanksDetails(It.IsAny<string>(), It.IsAny<int>())).Returns(_mockStorageTanks);
            _plantService.Setup(ps => ps.GetPlantUOMSubUnits(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(mockuomSubUnits);

            HttpConfiguration config = new HttpConfiguration();
            storageTankController = new StorageTanksController(_userService.Object, _storageTankService.Object, _controllerSetupService.Object, _pumpServices.Object, _plcService.Object, _plantService.Object) { Request = new HttpRequestMessage() }; 
            storageTankController.Request = new HttpRequestMessage();
            storageTankController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        #region "Properties"
        /// <summary>
        /// Tanks
        /// </summary>
        private readonly Tanks _mockTank;

        /// <summary>
        /// TanksModel
        /// </summary>
        private readonly TanksModel _storageTankModel;

        

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface IControllerSetupService
        /// </summary>
        private Mock<IControllerSetupService> _controllerSetupService;

        private List<Tanks> _mockStorageTanks;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IPlcService> _plcService;

        /// <summary>
        ///     interface IPumpsService
        /// </summary>
        private Mock<IPumpsService> _pumpServices;

        /// <summary>
        ///     interface IStorageTanksService
        /// </summary>
        private Mock<IStorageTanksService> _storageTankService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller
        /// </summary>
        private StorageTanksController storageTankController;

        /// <summary>
        /// UOMSubUnits
        /// </summary>
        private List<UOMSubUnit> mockuomSubUnits = new List<UOMSubUnit>();

        #endregion

        #region "Test Methods"

        [TestMethod]
        public void GetTankDetailsOnControllerTest()
        {
            string ecolabAccountNumber = "040242802";
            int controllerId = 1;
            IEnumerable<TanksModel> result = storageTankController.GetTankDetailsOnController(ecolabAccountNumber, controllerId);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetTanksDetailsTest()
        {
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
             IEnumerable<TanksModel> result = storageTankController.GetTanksDetails(ecolabAccountNumber);
        }

        //[TestMethod]
        //public void DeleteStorageTanksTest()
        //{
        //    bool result = storageTankController.DeleteStorageTanks(_storageTankModel);
        //    Assert.IsNotNull(result);
        //}


        // There we have unit convertions so it is not executing

        [TestMethod]
        public void CreateStorageTankTest()
        {
            HttpResponseMessage result = storageTankController.CreateStorageTank(_storageTankModel);
            Assert.IsNotNull(result);
        }

        //[TestMethod]
        //public void UpdateStorageTankTest()
        //{
        //    HttpResponseMessage result = storageTankController.UpdateStorageTank(_storageTankModel);
        //    Assert.IsNotNull(result);
        //}

        #endregion
    }
}