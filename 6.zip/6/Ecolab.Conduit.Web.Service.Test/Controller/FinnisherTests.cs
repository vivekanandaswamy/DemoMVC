﻿

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Models.PlantSetup.Finnisher;
    using Moq;
    using Services.PlantSetup.Finnisher;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.Finnisher;
    using Ecolab.Services;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup.Finnisher;

    [TestClass]
    public class FinnisherTests : TestBase
    {
        /// <summary>
        ///     FinnisherGroup Service
        /// </summary>
        private Mock<IFinnisherGroupService> finnisherGroupService;

        /// <summary>       
        ///     Finnisher Service
        /// </summary>
        private Mock<IFinnisherService> finnisherService;

        /// <summary>
        /// Api FinnisherController
        /// </summary>
        private FinnisherController finnisherController;

        /// <summary>
        /// UserService service
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        /// service model FinnisherGroup
        /// </summary>
        List<FinnisherGroup> mockFinnisherGroups = new List<FinnisherGroup>();

        /// <summary>
        /// Web model FinnisherGroupModel
        /// </summary>
        FinnisherGroupModel mockCreateFinnisherGroupModel;

        /// <summary>
        /// Web model FinnisherGroupModel
        /// </summary>
        FinnisherGroupModel mockFinnisherGroupModel;

        /// <summary>
        /// Service model FinnisherType
        /// </summary>
        List<FinnisherType> mockFinnisherTypes = new List<FinnisherType>();

        /// <summary>
        /// Web model FinnisherModel
        /// </summary>
        FinnisherModel mockCreateFinnisherModel;

        /// <summary>
        /// Web model FinnisherModel
        /// </summary>
        FinnisherModel mockFinnisherModel;

        public FinnisherTests()
        {
            mockFinnisherGroups.Add(new FinnisherGroup
            {
                EcolabAccountNumber = "040242802",
                Finnisher = new Finnisher
                {
                    EcolabAccountNumber = "040242802",
                    FinisherId = 1,
                    FinnisherType = new FinnisherType { Id = 1, Name = "FinnisherTypeTest" },
                    GroupId = 1,
                    GroupName = "GroupNameTest",
                    IsDelete = false,
                    IsDeleted = false,
                    LastModifiedTimestampAtCentral = DateTime.Now,
                    LastModifiedTimeStampFinnisher = DateTime.Now,
                    LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                    LastSyncTime = DateTime.Now,
                    MaxNumberOfRecords = 10,
                    Name = "FinnisherTest",
                    Number = 1
                },
                Id = 1,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampFinnisher = DateTime.Now,
                LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "FinnisherGroupTest"
            });

            mockCreateFinnisherGroupModel = new FinnisherGroupModel()
            {
                EcolabAccountNumber = "040242802",
                Finnisher = new FinnisherModel
                {
                    EcolabAccountNumber = "040242802",
                    FinisherId = 1,
                    FinnisherType = new FinnisherTypeModel { Id = 1, Name = "FinnisherTypeTest" },
                    GroupId = 1,
                    GroupName = "GroupNameTest",
                    IsDelete = false,
                    IsDeleted = false,
                    LastModifiedTimestampAtCentral = DateTime.Now,
                    LastModifiedTimeStampFinnisher = DateTime.Now,
                    LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                    LastSyncTime = DateTime.Now,
                    MaxNumberOfRecords = 10,
                    Name = "FinnisherTest",
                    Number = 1
                },
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampFinnisher = DateTime.Now,
                LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "FinnisherGroupTest"
            };

            mockFinnisherGroupModel = new FinnisherGroupModel()
            {
                EcolabAccountNumber = "040242802",
                Finnisher = new FinnisherModel
                {
                    EcolabAccountNumber = "040242802",
                    FinisherId = 1,
                    FinnisherType = new FinnisherTypeModel { Id = 1, Name = "FinnisherTypeTest" },
                    GroupId = 1,
                    GroupName = "GroupNameTest",
                    IsDelete = false,
                    IsDeleted = false,
                    LastModifiedTimestampAtCentral = DateTime.Now,
                    LastModifiedTimeStampFinnisher = DateTime.Now,
                    LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                    LastSyncTime = DateTime.Now,
                    MaxNumberOfRecords = 10,
                    Name = "FinnisherTest",
                    Number = 1
                },
                Id = 1,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampFinnisher = DateTime.Now,
                LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "FinnisherGroupTest"
            };

            mockFinnisherTypes.Add(new FinnisherType
            {
                Id = 1,
                Name = "FinnisherTypeTest"
            });

            mockCreateFinnisherModel = new FinnisherModel()
            {
                EcolabAccountNumber = "040242802",
                FinnisherType = new FinnisherTypeModel { Id = 1, Name = "FinnisherTypeTest" },
                GroupId = 1,
                GroupName = "GroupNameTest",
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampFinnisher = DateTime.Now,
                LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "FinnisherTest",
                Number = 1
            };

            mockFinnisherModel = new FinnisherModel()
            {
                EcolabAccountNumber = "040242802",
                FinisherId = 1,
                FinnisherType = new FinnisherTypeModel { Id = 1, Name = "FinnisherTypeTest" },
                GroupId = 1,
                GroupName = "GroupNameTest",
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampFinnisher = DateTime.Now,
                LastModifiedTimeStampFinnisherGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "FinnisherTest",
                Number = 1
            };
        }

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            HttpContext.Current.User = custPrinciple;

            finnisherGroupService = new Mock<IFinnisherGroupService>();
            finnisherService = new Mock<IFinnisherService>();
            userService = new Mock<IUserService>();
            DateTime lastModifiedTimeStamp;
            int id = 1;

            finnisherGroupService.Setup(fg => fg.FetchFinnisherGroupDetails(It.IsAny<string>())).Returns(mockFinnisherGroups);
            finnisherGroupService.Setup(fg => fg.InsertFinnisherGroup(It.IsAny<FinnisherGroup>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            finnisherGroupService.Setup(fg => fg.UpdateFinnisherGroup(It.IsAny<FinnisherGroup>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            finnisherGroupService.Setup(fg => fg.DeleteFinnisherGroup(It.IsAny<FinnisherGroup>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), out lastModifiedTimeStamp)).Returns(id);
            finnisherService.Setup(fs => fs.FetchFinnisherTypes(It.IsAny<string>())).Returns(mockFinnisherTypes);
            finnisherService.Setup(fs => fs.InsertFinnisher(It.IsAny<Finnisher>(), It.IsAny<int>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            finnisherService.Setup(fs => fs.UpdateFinnisher(It.IsAny<Finnisher>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            finnisherService.Setup(fs => fs.DeleteFinnisher(It.IsAny<Finnisher>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), out lastModifiedTimeStamp)).Returns(id);

            HttpConfiguration config = new HttpConfiguration();
            finnisherController = new FinnisherController(userService.Object, finnisherGroupService.Object, finnisherService.Object, _plantService.Object) { Request = new HttpRequestMessage() };
            finnisherController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        /// <summary>
        /// Get the finisher groups details
        /// </summary>
        [TestMethod]
        public void GetTest()
        {
            List<FinnisherGroupModel> finnisherGroupModels = finnisherController.Get();
            Assert.IsNotNull(finnisherGroupModels, "Finnishers group details are available."); 
        }


        /// <summary>
        /// Insert finisher groups details
        /// </summary>
        [TestMethod]
        public void CreateFinnisherGroupTest()
        {
            HttpResponseMessage result = finnisherController.CreateFinnisherGroup(mockCreateFinnisherGroupModel);
            Assert.IsNotNull(result, "Inserted Finnishers group details.");
        }

        /// <summary>
        /// Update finisher groups details
        /// </summary>
        [TestMethod]
        public void UpdateFinnisherGroupTest()
        {
            HttpResponseMessage result = finnisherController.UpdateFinnisherGroup(mockFinnisherGroupModel);
            Assert.IsNotNull(result, "Updated Finnishers group details.");
        }

        /// <summary>
        /// Delete finisher groups details
        /// </summary>
        [TestMethod]
        public void DeleteFinnisherGroupTest()
        {
            HttpResponseMessage result = finnisherController.DeleteFinnisherGroup(mockFinnisherGroupModel);
            Assert.IsNotNull(result, "Deleted Finnishers group details.");
        }

        /// <summary>
        /// Get the finisher type details
        /// </summary>
        [TestMethod]
        public void FetchFinnisherTypesTest()
        {
            IEnumerable<FinnisherTypeModel> finnisherTypeModels = finnisherController.FetchFinnisherTypes();
            Assert.IsNotNull(finnisherTypeModels, "Finnisher type details are available.");
        }

        /// <summary>
        /// Insert finisher details
        /// </summary>
        [TestMethod]
        public void CreateFinnisherTest()
        {
            HttpResponseMessage result = finnisherController.CreateFinnisher(mockCreateFinnisherModel);
            Assert.IsNotNull(result, "Inserted Finnishers details.");
        }

        /// <summary>
        /// Update finisher details
        /// </summary>
        [TestMethod]
        public void UpdateFinnisherTest()
        {
            HttpResponseMessage result = finnisherController.UpdateFinnisher(mockFinnisherModel);
            Assert.IsNotNull(result, "Updated Finnisher details.");
        }

        /// <summary>
        /// Delete finisher groups details
        /// </summary>
        [TestMethod]
        public void DeleteFinnisherTest()
        {
            HttpResponseMessage result = finnisherController.DeleteFinnisher(mockFinnisherModel);
            Assert.IsNotNull(result, "Deleted Finnishers details.");
        }
       
    }
}
