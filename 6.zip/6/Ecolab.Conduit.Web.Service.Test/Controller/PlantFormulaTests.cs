﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaTests.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Plant Customer Tests  </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Services;
    using Services.Interfaces;
    using Model = Models;
    using WebModel = ConduitLocal.Web.Models;
    using System.Web;
    using System.Configuration;

    [TestClass]
    public sealed class PlantFormulaTests : TestBase, IDisposable
    {
        #region "Setup data"

        /// <summary>
        ///     Plant Formula Tests
        /// </summary>
        public PlantFormulaTests()
        {
            mockFormulaMetaData = new List<Model.Formula> { new Model.Formula { ProgramId = 8, Name = "Fender Covers", Pieces = 5, EcolabTextileId = 5, EcolabTextileCategoryName = "textilecategory5", EcolabSaturationId = 5, EcolabSaturationName = "saturation5", PlantProgramId = 5, PlantProgramName = "Test5", ChainTextileId = 1, ChainTextileCategory = "testing", Rewash = true, Weight = 5, PieceWeight = 1, UserId = 1, TotalCount = 10 } };

            mockFormula = new Model.Formula { ProgramId = 1, Name = "Fender Covers", Pieces = 5 };

            mockFormulaModel = new WebModel.FormulaModel { ProgramId = 1, Name = "Fender Covers", Pieces = 5 };

            mockChainTextileCategory = new List<Model.ChainTextileCategory> { new Model.ChainTextileCategory { TextileId = 1, Name = "Textile1" } };

            mockEcolabTextileCategory = new List<Model.EcolabTextileCategory> { new Model.EcolabTextileCategory { TextileId = 1, CategoryName = "Category name" } };

            mockEcolabSaturation = new List<Model.EcolabSaturation> { new Model.EcolabSaturation { EcolabSaturationId = 1, EcolabSaturationName = "Saturation name" } };

            mockPlantChainProgram = new List<Model.PlantChainProgram> { new Model.PlantChainProgram { PlantProgramId = 1, PlantProgramName = "program name " } };
        }

        #endregion

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            plantFormulaController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Mock Setup
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            //CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1 };
            //custPrinciple.UserId = 1;
            //((CustomPrincipal)custPrinciple).EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            //HttpContext.Current.User = custPrinciple;

            _userService = new Mock<IUserService>();
            _customerService = new Mock<PlantCustomerService>();

            _programMasterService = new Mock<IProgramMasterService>();
            _programMasterService.Setup(pc => pc.GetFormulaDetails(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(mockFormulaMetaData);
            _programMasterService.Setup(pc => pc.GetChainTextileCategory(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"))).Returns(mockChainTextileCategory);
            _programMasterService.Setup(pc => pc.GetEcolabSaturation(0)).Returns(mockEcolabSaturation);
            _programMasterService.Setup(pc => pc.GetPlantChainProgram()).Returns(mockPlantChainProgram);
            _programMasterService.Setup(pc => pc.GetEcolabTextileCategory(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"))).Returns(mockEcolabTextileCategory);
            _programMasterService.Setup(pc => pc.GetPlantFormulasForSync(1, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"))).Returns(mockFormulaMetaData);
            //_programMasterService.Setup(pc => pc.SaveFormulaDetails(mockFormula,1,);
            //_programMasterService.Setup(pc => pc.DeleteFormulaDetails(819,"1", 1));

            HttpConfiguration config = new HttpConfiguration();

            plantFormulaController = new PlantFormulaController(_userService.Object, _plantService.Object, _programMasterService.Object, _customerService.Object) { Request = new HttpRequestMessage() };
            plantFormulaController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     ChainTextileCategory
        /// </summary>
        private readonly List<Model.ChainTextileCategory> mockChainTextileCategory;

        /// <summary>
        ///     EcolabSaturation
        /// </summary>
        private readonly List<Model.EcolabSaturation> mockEcolabSaturation;

        /// <summary>
        ///     EcolabTextileCategory
        /// </summary>
        private readonly List<Model.EcolabTextileCategory> mockEcolabTextileCategory;

        /// <summary>
        ///     Formula
        /// </summary>
        private readonly Model.Formula mockFormula;

        /// <summary>
        ///     Formula List
        /// </summary>
        private readonly List<Model.Formula> mockFormulaMetaData;

        /// <summary>
        ///     Formula Model
        /// </summary>
        private readonly WebModel.FormulaModel mockFormulaModel;

        /// <summary>
        ///     PlantChainProgram
        /// </summary>
        private readonly List<Model.PlantChainProgram> mockPlantChainProgram;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext ControllerContext;

        /// <summary>
        ///     interface IProgramMasterService
        /// </summary>
        private Mock<PlantCustomerService> _customerService;

        /// <summary>
        ///     interface IProgramMasterService
        /// </summary>
        private Mock<IProgramMasterService> _programMasterService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller
        /// </summary>
        private PlantFormulaController plantFormulaController;

		/// <summary>
		///     Formula Model List
		/// </summary>
		private List<WebModel.FormulaModel> mockFormulaModelList;

		#endregion

		#region "Test Methods"

		/// <summary>
		///     Get Formulas
		/// </summary>
		[TestMethod]
        public void GetFormulaDetailsTest()
        {
            HttpResponseMessage result = plantFormulaController.GetFormula(1);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetFormulaForAddTest()
        {
            FormulaViewModel result = plantFormulaController.GetFormulaForDropDown(1);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void SaveFormulaDetailsTest()
        {
			mockFormulaModelList = new List<ConduitLocal.Web.Models.FormulaModel>();
			mockFormulaModelList.Add(mockFormulaModel);
			HttpResponseMessage result = plantFormulaController.Put(mockFormulaModelList);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void CreateFormulaDetailsTest()
        {
            HttpResponseMessage result = plantFormulaController.CreateFormula(mockFormulaModel);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void DeleteFormulaDetailsTest()
        {
			mockFormulaModelList = new List<ConduitLocal.Web.Models.FormulaModel>();
			mockFormulaModelList.Add(mockFormulaModel);
			HttpResponseMessage result = plantFormulaController.DeleteFormula(mockFormulaModelList[0].ProgramId, mockFormulaModelList[0].LastModifiedTimeStamp);
            Assert.IsNotNull(result);
        }

        #endregion
    }
}