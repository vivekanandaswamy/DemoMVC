﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;

    [TestClass]
    public sealed class DeviceTests : TestBase, IDisposable
    {
        private string searchURL = ( new AppSettingsReader() ).GetValue("WebApiController.URL", typeof (string)) + "Utility";

        private string ecolabNumber = string.Empty;

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public DeviceTests()
        {
            ecolabNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            _mockUtility.Add(new Utility
            {
                DeviceNumber = 69,
                DeviceTypeId = 11,
                DeviceTypeDesc = "DeviceType",
                DeviceModelId = 1,
                DeviceModelDesc = "DeviceModel",
                DeviceNoteDesc = "DeviceType/DeviceModel",
                EcolabAccountNumber = ecolabNumber,
                Comment = "Test Mock",
                InstallDate = DateTime.Now
            });

            _mockutilityModel = new UtilityModel
            {
                Id = 120,
                DeviceNumber = 1,
                DeviceTypeId = 11,
                DeviceTypeDesc = "DeviceType",
                DeviceModelId = 1,
                DeviceModelDesc = "DeviceModel",
                DeviceNoteDesc = "DeviceType/DeviceModel",
                EcolabAccountNumber = ecolabNumber,
                Comment = "Test Mock",
                InstallDate = Convert.ToString(DateTime.Now)
            };
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            utilityController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            _utilityService = new Mock<IUtilityService>();
            _utilityService.Setup(Ut => Ut.GetUtilityDetails(ecolabNumber, true)).Returns(_mockUtility);

            _plantService = new Mock<IPlantService>();
            ecolabAccountNumber = ecolabNumber;
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);

            HttpConfiguration config = new HttpConfiguration();

            utilityController = new UtilityController(_userService.Object, _utilityService.Object, _plantService.Object);
            utilityController.Request = new HttpRequestMessage();
            utilityController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            UtilityController.Utilities = _mockUtility;
        }

        #endregion

        /// <summary>
        ///     Fetch the device details
        /// </summary>
        [TestMethod]
        public void FetchDeviceDetails()
        {
            IEnumerable<UtilityModel> result = utilityController.GetUtility();
            Assert.IsNotNull(result);
        }

        /// <summary>
        ///     Insert test for device data
        /// </summary>
        [TestMethod]
        public void CreateTest()
        {
			_mockUtilityModelList = new List<UtilityModel>();
			_mockUtilityModelList.Add(_mockutilityModel);
			HttpResponseMessage result = utilityController.CreateUtility(_mockUtilityModelList);

            if (result != null)
            {
                Assert.IsNotNull(result, "Inserted device data.");
            }
            else
            {
                Assert.IsNotNull(result, "Device data has not been inserted.");
            }
        }

        /// <summary>
        ///     update test for device
        /// </summary>
        [TestMethod]
        public void PutTest()
        {
			//UtilityModel utilityModel = new UtilityModel
			//{
			//    Id = 1,
			//    DeviceNumber = 11,
			//    DeviceTypeId = 1,
			//    DeviceTypeDesc = "DeviceType",
			//    DeviceModelId = 1,
			//    DeviceModelDesc = "DeviceModel",
			//    DeviceNoteDesc = "DeviceType/DeviceModel",
			//    EcolabAccountNumber = "1",
			//    Comment = "Test Mock",
			//    InstallDate = "23/08/2014"
			//};

			_mockUtilityModelList = new List<UtilityModel>();
			_mockUtilityModelList.Add(_mockutilityModel);
			HttpResponseMessage result = utilityController.Put(_mockUtilityModelList);
             Assert.AreEqual(result.IsSuccessStatusCode, true);
        }

        /// <summary>
        ///     delete test for utility
        /// </summary>
        [TestMethod]
        public void DeleteUtility_Test()
        {
            UtilityModel utilityModel = new UtilityModel
            {
                DeviceNumber = 1,
                EcolabAccountNumber = ecolabNumber,
                InstallDate = "08/23/2014",
                //LastModifiedTimeStamp = System.DateTime.Now,
                IsDeleted = true };

			_mockUtilityModelList = new List<UtilityModel>();
			_mockUtilityModelList.Add(utilityModel);
			HttpResponseMessage result = utilityController.DeleteUtility(_mockUtilityModelList);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        #region "Properties"

        /// <summary>
        ///     Utility class
        /// </summary>
        private readonly List<Utility> _mockUtility = new List<Utility>();

        /// <summary>
        ///     Model Utility
        /// </summary>
        private readonly UtilityModel _mockutilityModel;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     interface IUtilityService
        /// </summary>
        private Mock<IUtilityService> _utilityService;

        /// <summary>
        ///     Api controller CustomerController
        /// </summary>
        private UtilityController utilityController;

		/// <summary>
		/// List of model
		/// </summary>
		private List<UtilityModel> _mockUtilityModelList;

        #endregion
    }
}