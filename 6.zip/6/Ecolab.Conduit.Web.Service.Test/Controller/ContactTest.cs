﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using Ecolab.ConduitLocal.Web.Models;
    using Ecolab.Models;
    using Ecolab.Services;
    using Ecolab.Services.Interfaces;
    using ConduitLocal.Web.Api.Washers.Conventional;
    using ConduitLocal.Web.Models.Washers.Conventional;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Washers.Conventional;
    using Moq;
    using Ecolab.ConduitLocal.Web.Api;
    using Ecolab.Models.Common;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup;
    using System.Configuration;

    [TestClass]
    public class ContactTest : TestBase
    {
        /// <summary>
        ///     Plant Contact Service
        /// </summary>
        private Mock<IPlantContactService> plantContService;

        /// <summary>
        ///     Interface object for User Services.
        /// </summary>
        private Mock<IUserService> userService;       

        /// <summary>
        /// ContactController
        /// </summary>
        private ContactController contactController;

        /// <summary>
        /// PlantContact
        /// </summary>
        List<PlantContact> plantContacts = new List<PlantContact>();

        /// <summary>
        /// PlantContact
        /// </summary>
        IEnumerable<PlantContact> plantContact;

        /// <summary>
        /// PlantContactPosition
        /// </summary>
        List<PlantContactPosition> plantContPositions = new List<PlantContactPosition>();

        /// <summary>
        /// PlantContactModel
        /// </summary>
        PlantContactModel plantContactModel;

        /// <summary>
        /// PlantContactModel
        /// </summary>
        PlantContactModel plantContactModelUpdate;

		/// <summary>
		/// List of plant contact models
		/// </summary>
		List<PlantContactModel> plantContactModelList;

        public ContactTest()
        {
			plantContactModelList = new List<PlantContactModel>();

            plantContacts.Add(new PlantContact
            {                
                ContactEmailAdresss = "test@Ecolabtcd.com",
                ContactFaxNumber = "1233454567",
                ContactFirstName = "FirstName",
                ContactLastName = "LastName",
                ContactMobilePhone = "3456783412",
                ContactOfficePhone = "4556783489",
                ContactPositionId = 1,
                ContactPositionName = "Manager",
                ContactTitle = "Manager",
                EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Id = 1,
                IsDelete = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral= DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 20                
            });

            plantContact = plantContacts;

            plantContPositions.Add(new PlantContactPosition
            {
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Id = 1,
                IsDeleted = false,
                MyServiceCntctPosnId = 1,
                MyServiceModDtTm = DateTime.Now,
                PositionName = "PositionName"                
            });

            plantContactModel = new PlantContactModel()
            {
                ContactEmailAdresss = "test@Ecolabtcd.com",
                ContactFaxNumber = "1233454567",
                ContactFirstName = "FirstName",
                ContactLastName = "LastName",
                ContactMobilePhone = "3456783412",
                ContactOfficePhone = "4556783489",
                ContactPositionId = 1,
                ContactPositionName = "Manager",
                ContactTitle = "Manager",
                EcoalabAccountNumber = "1",                
                IsDelete = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 20     
            };

            plantContactModelUpdate = new PlantContactModel()
            {
                Id = 1,
                ContactEmailAdresss = "test@Ecolabtcd.com",
                ContactFaxNumber = "1233454567",
                ContactFirstName = "FirstName",
                ContactLastName = "LastName",
                ContactMobilePhone = "3456783412",
                ContactOfficePhone = "4556783489",
                ContactPositionId = 1,
                ContactPositionName = "Manager",
                ContactTitle = "Manager",
                EcoalabAccountNumber = "1",
                IsDelete = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 20
            };
        }

        [TestInitialize]
        public void TestInitialize()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1 };
            HttpContext.Current.User = custPrinciple;

            userService = new Mock<IUserService>();           
            plantContService = new Mock<IPlantContactService>();         
          
            DateTime lastModifiedTimeStamp;

            plantContService.Setup(pc => pc.GetPlantContactDetails(It.IsAny<string>())).Returns(plantContacts);
            plantContService.Setup(pc => pc.FetchPlantContactPosition()).Returns(plantContPositions);
            plantContService.Setup(pc => pc.GetContactList(It.IsAny<string>(), It.IsAny<string>())).Returns(plantContact);
            plantContService.Setup(pc => pc.SavePlantContactDetails(It.IsAny<PlantContact>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(1);
            plantContService.Setup(pc => pc.DeletePlantContactDetails(It.IsAny<PlantContact>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(1);
            plantContService.Setup(pc => pc.GetContactList(It.IsAny<string>(), It.IsAny<string>())).Returns(plantContact);

            HttpConfiguration config = new HttpConfiguration();
            contactController = new ContactController(userService.Object, _plantService.Object, plantContService.Object) { Request = new HttpRequestMessage() };
            contactController.Request = new HttpRequestMessage();
            contactController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        /// <summary>
        /// MS test for GetContact
        /// </summary>
        [TestMethod]
        public void GetContact_Test()
        {
            IEnumerable<PlantContactModel> plantContactModel = contactController.GetContact();

            Assert.IsNotNull(plantContactModel, "Get the contact details");            
        }

        /// <summary>
        /// MS test for FetchPlantContactPosition
        /// </summary>
        [TestMethod]
        public void FetchPlantContactPosition_Test()
        {
            IEnumerable<PlantContactPositionModel> result = contactController.FetchPlantContactPosition();

            Assert.IsNotNull(result, "Get the contact details");
        }

        /// <summary>
        /// MS test for CreateContact
        /// </summary>
        [TestMethod]
        public void CreateContact_Test()
        {
			plantContactModelList = new List<PlantContactModel>();
			plantContactModelList.Add(plantContactModel);
            HttpResponseMessage result = contactController.CreateContact(plantContactModelList);

            Assert.IsNotNull(result, "Saved the plant contact details");
        }

        /// <summary>
        /// MS test for Put
        /// </summary>
        [TestMethod]
        public void Put_Test()
        {
			plantContactModelList = new List<PlantContactModel>();
			plantContactModelList.Add(plantContactModelUpdate);
			HttpResponseMessage result = contactController.Put(plantContactModelList);

            Assert.IsNotNull(result, "Updated the plant contact details");
        }

        /// <summary>
        /// MS test for DeleteContact
        /// </summary>
        [TestMethod]
        public void DeleteContact_Test()
        {
			plantContactModelList = new List<PlantContactModel>();
			plantContactModelList.Add(plantContactModelUpdate);
			HttpResponseMessage result = contactController.DeleteContact(plantContactModelList);

            Assert.IsNotNull(result, "Updated the plant contact details");
        }

        /// <summary>
        /// MS test for GetContactList
        /// </summary>
        [TestMethod]
        public void GetContactList_Test()
        {
            string term = "term";
            IEnumerable<PlantContactModel> plantContactModel = contactController.GetContactList(term);

            Assert.IsNotNull(plantContactModel, "Updated the plant contact details");
        }   
    }
}
