﻿using Ecolab.Services.Interfaces.Plc;
using WebModel = Ecolab.ConduitLocal.Web.Models;
using Model = Ecolab.Models;

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup.Chemical;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.Chemical;
    using Models.WasherGroup;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Ecolab.Services.Interfaces.ControllerSetup;

    [TestClass]
    public sealed class WasherGroupFormulaTests : TestBase, IDisposable
    {
        #region "Setup data"

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public WasherGroupFormulaTests()
        {
            _washerFormulaWashStepData = new List<WasherFormulaWashStep> { new WasherFormulaWashStep { DrainDestination = "Test", EcolabAccountNumber = "1", Id = 1, ProgramSetupId = 1 } };

            _chemicals = new List<Chemicals> { new Chemicals { Name = "test", ProductId = 1, Cost = 10 } };

            //_washerGroupFormula = new List<WasherGroupFormula> { new WasherGroupFormula { Id = 1, EcolabAccountNumber = "1", LoadsPerMonth = 10 } };

            _washerDosingProductData = new List<WasherDosingProduct> { new WasherDosingProduct { Id = 1, InjectionNumber = 1, ProductId = 1, ProductName = "Prod Name1", Quantity = 10, WasherDosingSetupId = 1, EcolabAccountNumber = "1" }, new WasherDosingProduct { Id = 2, InjectionNumber = 2, ProductId = 2, ProductName = "Prod Name2", Quantity = 11, WasherDosingSetupId = 1, EcolabAccountNumber = "1" } };
        }

        #endregion

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            washerGroupFormulaController.Dispose();
        }

        #region "Test Initialization"

        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            _washerGroupFormulaService = new Mock<IWasherGroupFormulaService>();

            _washerGroupService = new Mock<IWasherGroupService>();

            _programMasterService = new Mock<IProgramMasterService>();

            _plantUtilityService = new Mock<IPlantUtilityService>();

            _productMasterService = new Mock<IProductMasterService>();

            _controllerService = new Mock<IControllerSetupService>();

            userService = new Mock<IUserService>();

            washerServices = new Mock<IWasherServices>();

            _injectionService = new Mock<IInjectionService>();
            _iplcService = new Mock<IPlcService>();

            _iplcService = new Mock<IPlcService>();

            _productMasterService.Setup(pc => pc.FetchUsedChemicalList("test", "1", 1)).Returns(_chemicals);

            _washerGroupFormulaService.Setup(pc => pc.GetWasherGroupFormulaWashSteps("1", 1, 1, 1)).Returns(_washerFormulaWashStepData);
            _washerGroupFormulaService.Setup(pc => pc.GetWasherDosingProduct("1", 1, true)).Returns(_washerDosingProductData);

            HttpConfiguration config = new HttpConfiguration();
            washerGroupFormulaController = new WasherGroupFormulaController(_washerGroupService.Object, _programMasterService.Object, _washerGroupFormulaService.Object, _plantUtilityService.Object, _productMasterService.Object, _plantService.Object, userService.Object, washerServices.Object, _injectionService.Object, _iplcService.Object, _controllerService.Object);
            washerGroupFormulaController.Request = new HttpRequestMessage();
            washerGroupFormulaController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        #region "Test Methods"

        [TestMethod]
        public void GetChemicalListTest()
        {
            IEnumerable<ChemicalsModel> result = washerGroupFormulaController.GetChemicalList("test");
            Assert.IsNotNull(result);
        }

        #endregion

        #region "Properties"

        private readonly List<Chemicals> _chemicals;
        private readonly List<WasherDosingProduct> _washerDosingProductData;
        private readonly List<WasherFormulaWashStep> _washerFormulaWashStepData;
        

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        private Mock<IPlantUtilityService> _plantUtilityService;

        private Mock<IProductMasterService> _productMasterService;

        private Mock<IProgramMasterService> _programMasterService;

        private Mock<IControllerSetupService> _controllerService;

        private Mock<IUserService> _userService;

        private Mock<IWasherGroupFormulaService> _washerGroupFormulaService;

        private Mock<IWasherGroupService> _washerGroupService;

        private Mock<IUserService> userService;

        private Mock<IInjectionService> _injectionService;

        private Mock<IPlcService> _iplcService;

        /// <summary>
        ///     Api controller
        /// </summary>
        private WasherGroupFormulaController washerGroupFormulaController;

        private Mock<IWasherServices> washerServices;

        #endregion
    }
}