﻿

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Services.Interfaces;
    using Ecolab.Services.Interfaces.PlantSetup;   
    using Ecolab.Services;
    using System.Web;
    using Ecolab.ConduitLocal.Web.Api;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup.RedFlag;
    using Ecolab.Models.PlantSetup.RedFlag;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup;
    using Ecolab.Models.PlantSetup;

    [TestClass]
    public class RedFlagTests : TestBase
    {
        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        ///     RedFlag Service
        /// </summary>
        private  Mock<IRedFlagService> redFlagService;

        /// <summary>
        /// Api controller RedFlagController
        /// </summary>
        private RedFlagController redFlagController;

        /// <summary>
        /// RedFlag
        /// </summary>
        List<RedFlag> redFlags = new List<RedFlag>();

        /// <summary>
        /// RedFlagItem
        /// </summary>
        List<RedFlagItem> redFlagItems = new List<RedFlagItem>();

        /// <summary>
        /// MachineSetup
        /// </summary>
        List<MachineSetup> machineSetups = new List<MachineSetup>();

        /// <summary>
        /// RedFlagLocation
        /// </summary>
        List<RedFlagLocation> redFlagLocations = new List<RedFlagLocation>();

        public RedFlagTests()
        {
            redFlags.Add(new RedFlag 
            {
                 Id = 1,
                ItemId = 1,
                ItemName = "",
                MinimumRange = 10.4M,
                MaximumRange = 25.8M,               
                LocationId = 1,
                LocationName = "",
                EcolabAccountNumber = "1",                             
                LastModifiedTimeStamp = DateTime.Now
            });

            redFlagItems.Add(new RedFlagItem 
            { 
                ItemId = 12,
                ItemName = "TestRedFlag"
            });           

            machineSetups.Add(new MachineSetup 
            {
                MachineId = 1,
                MachineName = "TestMachine"
            });

            redFlagLocations.Add(new RedFlagLocation
            {
                GroupDescription = "TestDesc",
                GroupMainType = 1,
                GroupTypeId = 1
            });
        }

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void Testinilialize()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1 };
            HttpContext.Current.User = custPrinciple;

            userService = new Mock<IUserService>();
            redFlagService = new Mock<IRedFlagService>();
            redFlagService.Setup(rf => rf.FetchRedFlagDetails(It.IsAny<int?>(), It.IsAny<string>())).Returns(redFlags);
            redFlagService.Setup(rf => rf.FetchRedFlagItemDetails(It.IsAny<int?>(), It.IsAny<string>())).Returns(redFlagItems);
			redFlagService.Setup(rf => rf.GetRedFlagMachineDetails(It.IsAny<int>(), It.IsAny<string>())).Returns(machineSetups);
            redFlagService.Setup(rf => rf.FetchRedFlagLocationDetails(It.IsAny<int>(), It.IsAny<string>())).Returns(redFlagLocations);

            HttpConfiguration config = new HttpConfiguration();
            redFlagController = new RedFlagController(userService.Object, _plantService.Object, redFlagService.Object) { Request = new HttpRequestMessage() };
            redFlagController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;   
        }

        /// <summary>
        /// MS Test for Get the red flag details
        /// </summary>
        [TestMethod]
        public void Get_Test()
        {
            List<RedFlagModel> redFlagModels = redFlagController.Get();

            if(redFlagModels.Count > 0)
            {
                Assert.IsNotNull(redFlagModels, "Get the red flag details.");
            }            
        }

        /// <summary>
        /// MS Test for Item Data
        /// </summary>
        [TestMethod]
        public void GetItemData_Test()
        {
            List<ItemModel> itemModels = redFlagController.GetItemData();

            if (itemModels.Count > 0)
            {
                Assert.IsNotNull(itemModels, "Get the red flag item details.");
            }
        }

        /// <summary>
        /// MS Test for Get OnItem Change
        /// </summary>
        [TestMethod]
        public void GetOnItemChange_Test()
        {
            int? id = 1;
            int itemId = 1;
            List<RedFlagLocationModel> redFlagLocationModels = redFlagController.GetOnItemChange(id, itemId);

            if (redFlagLocationModels.Count > 0)
            {
                Assert.IsNotNull(redFlagLocationModels, "Get the red flag details.");
            }
        }

        /// <summary>
        /// MS Test for Get OnLocation Change
        /// </summary>
        [TestMethod]
        public void GetOnLocationChange_Test()
        {
            int? id = 1;
            int itemId = 1;
            int locationId = 1;
            List<MachineSetupModel> machineSetupModel = redFlagController.GetOnLocationChange(id, itemId, locationId);

            if (machineSetupModel.Count > 0)
            {
                Assert.IsNotNull(machineSetupModel, "Get the red flag details.");
            }
        }

        /// <summary>
        /// MS Test for Get OnEdit clicked 
        /// </summary>
        [TestMethod]
        public void GetOnEditClicked_Test()
        {
            int id = 1;           
            Dictionary<string, object> result = redFlagController.GetOnEditClicked(id);

            if (result.Count > 0)
            {
                Assert.IsNotNull(result, "Get the red flag details.");
            }
        }
    }
}
