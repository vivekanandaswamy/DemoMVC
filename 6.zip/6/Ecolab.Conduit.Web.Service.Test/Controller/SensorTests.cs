﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Models.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using SensorController = ConduitLocal.Web.Api.SensorController;
    using Ecolab.Services;
    using System.Web;
    using Services.Interfaces.ControllerSetup;

    using Ecolab.Models.Common;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;

    [TestClass]
    public sealed class SensorTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public SensorTests()
        {
            mockSensor.Add(new Sensor
            {
                SensorNumber = 1,
                SensorName = "test",
                SensorType = 3,
                SensorTypeName = "test",
                EcolabAccountNumber = "1",
                ControllerId = 1,
                ControllerName = "test Controller",
                SensorLocationId = 1,
                SensorLocation = "test",
                MachineId = 1,
                MachineName = "test",
                OutputType = "test",               
                AnalogueImputNumber = "test",
                ChemicalforChartId = 1,
                ChemicalforChart = "test",
                Uom = "test",
                UomName = "test",
                DashboardActualValue = true
            });

            mockSensorModel = new SensorWebModel
            {
                SensorNumber = 1,
                SensorName = "test",
                SensorType = 3,
                SensorTypeName = "test",
                EcolabAccountNumber = "1",
                ControllerId = 1,
                ControllerName = "test Controller",
                SensorLocationId = 1,
                SensorLocation = "test",
                MachineId = 1,
                MachineName = "test",
                OutputType = "test",
                //Calibration = 12.752M,
                AnalogueImputNumber = "test",
                ChemicalforChartId = 1,
                ChemicalforChart = "test",
                UOM = "test",
                UOMName = "test",
                DashboardActualValue = true
            };

            sensorModel = new SensorWebModel
            {
                SensorNumber = 1,
                SensorName = "test",
                SensorType = 3,
                SensorTypeName = "test",
                EcolabAccountNumber = "1",
                ControllerId = 1,
                ControllerName = "test Controller",
                SensorLocationId = 1,
                SensorLocation = "test",
                MachineId = 1,
                MachineName = "test",
                OutputType = "test",
                //Calibration = 12.752M,
                AnalogueImputNumber = "test",
                ChemicalforChartId = 1,
                ChemicalforChart = "test",
                UOM = "test",
                UOMName = "test",
                DashboardActualValue = true
            };

            mockMachineSetups.Add(new MachineSetup
            {
                ControllerId = 1,
                MachineId = 2,
                MachineName = "Name"
            });

            conduitControllers.Add(new ConduitController 
            { 
                ControllerId = 1,
                ControllerModelId = 2,
                ControllerModelName = "Test",
                ControllerType = "Type",
                ControllerTypeId = 1,
                Name = "TestName",
                RegionId = 1
            });
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            sensorController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserName = "test";
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "Admin";
            HttpContext.Current.User = custPrinciple;

            _userService = new Mock<IUserService>();

            _plantService = new Mock<IPlantService>();
            _washerGroupService = new Mock<IWasherGroupService>();
            ecolabAccountNumber = "1";
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);
           
            _sensorService = new Mock<ISensorService>();
            _sensorService.Setup(ut => ut.GetPlantSensorDetails(It.IsAny<int?>(), It.IsAny<string>())).Returns(mockSensor);
            _sensorService.Setup(ut => ut.GetPlantMachineDetails(It.IsAny<int?>(), It.IsAny<string>(), It.IsAny<int>())).Returns(mockMachineSetups);
            _sensorService.Setup(ut => ut.GetConduitControllerDetails(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>())).Returns(conduitControllers); 

            _plantService = new Mock<IPlantService>();
            ecolabAccountNumber = "1";
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);

            plcService = new Mock<IPlcService>();
            controllerSetupService = new Mock<IControllerSetupService>();
            _washerService = new Mock<IWasherServices>();

            HttpConfiguration config = new HttpConfiguration();
            sensorController = new SensorController(_userService.Object, _sensorService.Object, _plantService.Object, plcService.Object, controllerSetupService.Object, _washerGroupService.Object,_washerService.Object) { Request = new HttpRequestMessage() };
            sensorController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        /// <summary>
        ///     Fetch the sensor details
        /// </summary>
        [TestMethod]
        public void FetchSensorTest()
        {
            IEnumerable<SensorWebModel> result = sensorController.GetSensor();
            Assert.IsNotNull(result, "Sensor data");
        }

        /// <summary>
        ///     Create the sensor details
        /// </summary>
        [TestMethod]
        public void CreateSensorTest()
        {
			mockSensorModelList = new List<SensorWebModel>();
			mockSensorModelList.Add(mockSensorModel);
			HttpResponseMessage result = sensorController.CreateSensor(mockSensorModelList);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     save the sensor details
        /// </summary>
        [TestMethod]
        public void PutSensorTest()
        {
            const int sensorId = 10;
            HttpResponseMessage result = sensorController.Put(sensorId, mockSensorModel);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     Get Defaults
        /// </summary>
        [TestMethod]
        public void FetchDefaultsTest()
        {
            const int sensorId = 1;
            Dictionary<string, object> result = sensorController.GetDefaults(sensorId);
            Assert.IsNotNull(result.Count > 0, "fetched default data");
        }

        /// <summary>
        ///     Fetch Compartment data
        /// </summary>
        [TestMethod]
        public void FetchMachineOrCompartmentTest()
        {
            const int groupTypeId = 2;
            IEnumerable<MachineSetupModel> result = sensorController.GetMachineOrCompartment(groupTypeId);
            Assert.IsNotNull(result, "fetched Compartment data");
        }

        /// <summary>
        ///     Fetch UOM sensor details
        /// </summary>
        [TestMethod]
        public void FetchUomSensorDetailsTest()
        {
            const int sensorTypeId = 5;
            IEnumerable<UOMSensorModel> result = sensorController.GetUomSensorDetails(sensorTypeId);
            Assert.IsNotNull(result, "fetched UOM sensor details");
        }

        /// <summary>
        ///     fetched machine Or CompartmentList data
        /// </summary>
        [TestMethod]
        public void FetchChemicalForChartTest()
        {
            const int locationId = 2;
            const int machineId = 2;
            Dictionary<string, object> result = sensorController.GetOnMachineCompartmentChange(locationId, machineId);
            Assert.IsNotNull(result, "fetched machine Or CompartmentList data ");
        }

        /// <summary>
        ///     fetch machine Or CompartmentList data based on location
        /// </summary>
        [TestMethod]
        public void FetchOnLocationChangeTest()
        {
            const int groupTypeId = 2;
            const int sensorTypeId = 1;
            Dictionary<string, object> result = sensorController.GeOnLocationChange(groupTypeId, sensorTypeId);
            Assert.IsNotNull(result.Count > 0, "fetched machine Or CompartmentList data");
        }

        /// <summary>
        ///     fetch uomData data based on sensor Type
        /// </summary>
        [TestMethod]
        public void FetchOnSensorTypeChangeTest()
        {
            const int sensorTypeId = 4;
            Dictionary<string, object> result = sensorController.GeOnSensorTypeChange(sensorTypeId);
            Assert.IsNotNull(result.Count > 0, "fetched uomData");
        }

        /// <summary>
        ///     delete test for Sensor
        /// </summary>
        [TestMethod]
        public void DeleteSensorTest()
        {
			mockSensorModelList = new List<SensorWebModel>();
			mockSensorModelList.Add(mockSensorModel);
			HttpResponseMessage result = sensorController.DeleteSensor(mockSensorModelList);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     delete test for Sensor
        /// </summary>
        [TestMethod]
        public void DeleteSensorByIdTest()
        {
            const int sensorId = 10;
            HttpResponseMessage result = sensorController.DeleteSensor(sensorId, sensorModel);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     Negative delete test for Sensor
        /// </summary>
        [TestMethod]
        public void DeleteSensorByIdFailTest()
        {
            const int id = -1;
            HttpResponseMessage result = sensorController.DeleteSensor(id, sensorModel);
            Assert.AreEqual(HttpStatusCode.BadRequest, result.StatusCode);
        }

        #region "Properties"

        /// <summary>
        ///     Meter class
        /// </summary>
        private readonly List<Sensor> mockSensor = new List<Sensor>();

        /// <summary>
        ///     Model Meter
        /// </summary>
        private readonly SensorWebModel mockSensorModel;

        /// <summary>
        ///     Model  Meter
        /// </summary>
        private readonly SensorWebModel sensorModel;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext ControllerContext;

        /// <summary>
        ///     interface IMeterService
        /// </summary>
        private Mock<ISensorService> _sensorService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller MeterController
        /// </summary>
        private SensorController sensorController;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IPlcService> plcService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IControllerSetupService> controllerSetupService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        List<MachineSetup> mockMachineSetups = new List<MachineSetup>();

        /// <summary>
        /// ConduitController
        /// </summary>
        List<ConduitController> conduitControllers = new List<ConduitController>();

		/// <summary>
		///     Model Meter list
		/// </summary>
		private List<SensorWebModel> mockSensorModelList;

        /// <summary>
        /// interface Washer Group Service
        /// </summary>
        private Mock<IWasherGroupService> _washerGroupService;

        private Mock<IWasherServices> _washerService;
        #endregion
    }
}