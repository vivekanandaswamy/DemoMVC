﻿// -----------------------------------------------------------------------
// <copyright file="TagManagementTest.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The TagManagement Setup Tests is for test cases for unit testing .</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http.Controllers;
    using ConduitLocal.Web.Controllers;
    using ConduitLocal.Web.Models.PlantSetup;
    using Ecolab.Dcs.Entities;
    using Ecolab.Services.Interfaces.ControllerSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup;
    using Moq;
    using Services.Interfaces;
    using TagManagementModel = Models.TagManagement;
    using System.Web.Mvc;
    using Services;
    using Services.Plc;
    using Services.ControllerSetup;
    using ConduitLocal.Web.Models.Common;

    /// <summary>
    /// Unit test cases classes for Tag Magnagement.
    /// </summary>
    [TestClass]
    public class TagManagementTest : TestBase
    {
        public TagManagementTest()
        {
            mockTagManagementModel.Add(new OpcTag
            {
                Topic = "",
                Address = "N7=83",
                ServerHandle = 0,
                Quality = null,
                TimeStamp = DateTime.MinValue,
                Value = "0",
                IsModified = false
            });
            mockTagManagementModel.Add(new OpcTag
            {
                Topic = "",
                Address = "N7=84",
                ServerHandle = 0,
                Quality = null,
                TimeStamp = DateTime.MinValue,
                Value = "0",
                IsModified = false
            });
            mockPlcDiscrepancyModel.Add(new PLCDiscrepancyModel
            {
                Entity = 0,
                ParentEntity = 0,
                ParentEntityId = 0,
                EntityId = 0,
                UserId = 0,
                ControllerId = 0
            });
            mockPlcDiscrepancyModel.Add(new PLCDiscrepancyModel
            {
                Entity = -1,
                ParentEntity = -1,
                ParentEntityId = -1,
                EntityId = -1,
                UserId = -1,
                ControllerId = -1
            });
            mockPlcDiscrepancyModel.Add(new PLCDiscrepancyModel
            {
                Entity = 1,
                ParentEntity = 2,
                ParentEntityId = 1,
                EntityId = 1,
                UserId = 1,
                ControllerId = 1
            });
            mockPlcDiscrepancyModel = null;
        }

        /// <summary>
        ///  Test initialization for TagManagementTests
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            HttpControllerContext httpControllerContext = new HttpControllerContext();
            httpControllerContext.Request = new HttpRequestMessage(HttpMethod.Post, string.Empty);
            HttpActionContext httpActionContext = new HttpActionContext();
            httpActionContext.ControllerContext = httpControllerContext;
            tagManagementService = new Mock<ITagManagementService>();
            tagManagementController = new TagManagementController(new UserService(), new PlantService(), new TagManagementService(), new PlcService(), new ControllerSetupService());
        }

        /// <summary>
        ///     Controller for tag Management Controller.
        /// </summary>
        private TagManagementController tagManagementController;


        /// <summary>
        ///     List object for dimensions types
        /// </summary>
        private readonly List<OpcTag> mockTagManagementModel = new List<OpcTag>();

        /// <summary>
        ///     List object for Plc Discrepancy data
        /// </summary>
        private readonly List<PLCDiscrepancyModel> mockPlcDiscrepancyModel = new List<PLCDiscrepancyModel>();

        /// <summary>
        ///     interface IPlantUtilityService
        /// </summary>
        private Mock<ITagManagementService> tagManagementService;

        /// <summary>
        ///     To get the Tag Management details
        /// </summary>
        public void GetSettings()
        {
            ActionResult tagManagementModel = tagManagementController.Index(1, mockPlcDiscrepancyModel);
            Assert.IsNotNull(tagManagementModel, "Passed this test case");
        }

        /// <summary>
        ///     Test case for writing the values to PLC
        /// </summary>
        public void SendSettings()
        {
            tagManagementController.SendSettingstoPLC(mockTagManagementModel, 1, mockPlcDiscrepancyModel);
        }
    }
}
