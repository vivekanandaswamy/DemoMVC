﻿// -----------------------------------------------------------------------
// <copyright file="AlarmTest.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The AlarmTest object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Moq;
    using Services.Interfaces;

    /// <summary>
    ///     Alarm Test Class
    /// </summary>
    [TestClass]
    public sealed class AlarmTest : TestBase, IDisposable
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public AlarmTest()
        {
            mockAlarm.Add(new Alarm { StartDate = DateTime.Now, MachineName = "ABC", AlarmDescription = "TEST" });
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            userService = null;
            alarmService = null;
            _plantService = null;
            mockAlarm = null;
            alarmController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            userService = new Mock<IUserService>();

            alarmService = new Mock<IAlarmService>();
            alarmService.Setup(_ => _.FetchAlarmDetails(It.IsAny<string>())).Returns(mockAlarm);

            /* _plantService = new Mock<IPlantService>();
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);
*/
            HttpConfiguration config = new HttpConfiguration();
            alarmController = new AlarmController(userService.Object, _plantService.Object, alarmService.Object) { Request = new HttpRequestMessage() };
            alarmController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        [TestMethod]
        public void FetchAlarmDetails()
        {
            IEnumerable<AlarmModel> result = alarmController.FetchAlarmDetails();
            Assert.IsNotNull(result, "Alarm data");
        }

        #region "Properties"

        /// <summary>
        ///     interface IAlarmService
        /// </summary>
        private Mock<IAlarmService> alarmService;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext ControllerContext;

        /// <summary>
        ///     Alarm class
        /// </summary>
        private List<Alarm> mockAlarm = new List<Alarm>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        ///     Api controller AlarmController
        /// </summary>
        private AlarmController alarmController;

        #endregion
    }
}