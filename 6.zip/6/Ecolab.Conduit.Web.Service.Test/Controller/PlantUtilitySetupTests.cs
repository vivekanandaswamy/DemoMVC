﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilitySetupTests.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The PlantUtility Setup Tests is for test cases for unit testing .</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http.Controllers;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;
    using PlantUtilityFactorTypes = Models.PlantSetup.PlantUtilityFactorTypes;

    /// <summary>
    ///     Unit test cases classes for plant utility setup.
    /// </summary>
    [TestClass]
    public class PlantUtilitySetupTests : TestBase
    {
        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtilitySetupTests" /> class.
        /// </summary>
        public PlantUtilitySetupTests()
        {
            // Dimension Types
            mockPlantUtilityDimensionTypes.Add(new PlantUtilityDimensionTypes { Temperature = "F", Price = "$", ElectricPrice = "$/Unit", GasPrice = "$/Lbs", EnergyContent = "Kwh/m3" });

            //// Gas Oil Types
            mockPlantUtilityGasoilTypes.Add(new PlantUtilityGasoilTypes { GasoilTypeId = 1, GasoilTypeName = "Propane" });

            ////Factor Types
            mockPlantUtilityFactorTypes.Add(new PlantUtilityFactorTypes { UtilityId = 1, UtilityType = 2, FactorType = "Cold", Temperature = 3, EnergyContent = 3, Price = 3, Location = "1", BoilerSteam = true, BoilerType = 1, SteamPercentage = 1, BoilerPercentage = 1, StackPercentage = 1, RewashFactor = 1, FreeType = 1, SubUnit = "kwh/m3" });

            // Plant Utility Setup Model
            //mockPlantUtilitySetupModel = new PlantUtilityFactorTypes { UtilityType = 2, FactorType = "Cold", Temperature = 3, EnergyContent = 3, Price = 3, Location = "1", BoilerSteam = true, BoilerType = 1, SteamPercentage = 1, BoilerPercentage = 1, StackPercentage = 1, RewashFactor = 1, FreeType = 1, SubUnit = "kwh/m3" }};
        }

        #endregion

        #region TestIntialize

        /// <summary>
        ///     Test initialization for PlantUtilitySetupTests
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            HttpControllerContext httpControllerContext = new HttpControllerContext();
            httpControllerContext.Request = new HttpRequestMessage(HttpMethod.Post, string.Empty);
            HttpActionContext httpActionContext = new HttpActionContext();
            httpActionContext.ControllerContext = httpControllerContext;
            plantUtilityService = new Mock<IPlantUtilityService>();
            plantUtilityService.Setup(Ut => Ut.GetPlantUtilityDetails("1")).Returns(mockPlantUtilityFactorTypes);
            plantUtilityService.Setup(Ut => Ut.GetFreeWaterDetails(1)).Returns(mockPlantUtilityWaterTypeMaster);
            plantUtilityService.Setup(Ut => Ut.GetGasoilTypes("1")).Returns(mockPlantUtilityGasoilTypes);
            plantUtilityService.Setup(Ut => Ut.GetDimensionTypes("1")).Returns(mockPlantUtilityDimensionTypes);
            plantUtilityService.Setup(Ut => Ut.GetPlantUtilityDetailsList(1)).Returns(mockPlantUtilityFactorTypes);
            plantUtilitySetupController = new PlantUtilitySetupController(userService.Object, _plantService.Object, plantUtilityService.Object) { ControllerContext = httpControllerContext };
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     List object for dimensions types
        /// </summary>
        private readonly List<PlantUtilityDimensionTypes> mockPlantUtilityDimensionTypes = new List<PlantUtilityDimensionTypes>();

        /// <summary>
        ///     List object for factor types of plant utility
        /// </summary>
        private readonly List<PlantUtilityFactorTypes> mockPlantUtilityFactorTypes = new List<PlantUtilityFactorTypes>();

        /// <summary>
        ///     List object for plant utility gasoil types.
        /// </summary>
        private readonly List<PlantUtilityGasoilTypes> mockPlantUtilityGasoilTypes = new List<PlantUtilityGasoilTypes>();

        /// <summary>
        ///     List object for plant utility water types.
        /// </summary>
        private readonly List<PlantUtilityWaterTypeMaster> mockPlantUtilityWaterTypeMaster = new List<PlantUtilityWaterTypeMaster>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private readonly Mock<IUserService> userService = new Mock<IUserService>();

        /// <summary>
        ///     interface IPlantUtilityService
        /// </summary>
        private Mock<IPlantUtilityService> plantUtilityService;

        /// <summary>
        ///     Controller for plant utility setup.
        /// </summary>
        private PlantUtilitySetupController plantUtilitySetupController;

        #endregion

        #region Constructor

      
        #endregion

        

        #region Test Methods

        /// <summary>
        ///     To get the plant utility details
        /// </summary>
        public void Get()
        {
            PlantUtilityListModel utility = plantUtilitySetupController.Get();
            Assert.IsNotNull(utility, "Passed this test case");
        }

        /// <summary>
        ///     Test case for saving the plant utility setup.
        /// </summary>
        public void Save()
        {
            List<PlantUtilityFactorTypes> mockPlantUtilitySetupModel = new List<PlantUtilityFactorTypes>();
            plantUtilitySetupController.Save(mockPlantUtilitySetupModel);
        }

        #endregion
    }
}