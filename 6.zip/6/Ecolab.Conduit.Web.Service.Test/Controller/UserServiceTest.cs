﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Services;
    using Services.Interfaces;

    [TestClass]
    public class UserServiceTest
    {
        /// <summary>
        ///     User Service
        /// </summary>
        private IUserService userService;

        #region Test Initialize

        [TestInitialize]
        public void TestInitialize()
        {
            userService = new UserService();
        }

        #endregion

        [TestMethod]
        public void LoginTest()
        {
            string userName = "tcd";
            string password = "tcd";
            string returnUrl = string.Empty;
            User result = userService.Login(userName, password, out returnUrl);
            Assert.AreEqual("tcd", userName);
            Assert.AreEqual("tcd", password);
        }
    }
}