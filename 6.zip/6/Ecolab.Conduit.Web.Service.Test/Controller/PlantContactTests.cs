﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Net.Http;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Moq;
    using Services.Interfaces;

    [TestClass]
    public sealed class PlantContactTests : TestBase, IDisposable
    {
        private readonly string contlName = "Contact";
        private readonly string searchURL = ( new AppSettingsReader() ).GetValue("WebApiController.URL", typeof (string)) + "Contact";

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            userService = null;
            _plantService = null;
            plantContService = null;
            contController.Dispose();
        }

        /// <summary>
        ///     Mock Setup method
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            userService = new Mock<IUserService>();

            plantContService = new Mock<IPlantContactService>();
            plantContService.Setup(pc => pc.GetPlantContactDetails("1")).Returns(MockPlantContact);

            contController = new ContactController(userService.Object, _plantService.Object, plantContService.Object);
        }

        [TestMethod]
        public void GetContactDetails_Test()
        {
            //IEnumerable<PlantContactModel> result = contController.GetContact();
            //Assert.IsNotNull(result);
        }

        [TestMethod]
        public void CreateContactDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(contController, searchURL, contlName);
            PlantContactModel objPlantContact = new PlantContactModel { ContactFirstName = "TestFirst", ContactLastName = "TestLast", ContactFaxNumber = "abcdef", ContactMobilePhone = "46546464", ContactEmailAdresss = "Test@email.com", ContactOfficePhone = "464564dfsdf564", ContactPositionId = 3, ContactTitle = "TMtitle" };
            //var result = contController.CreateContact(objPlantContact);
            //if (result != null)
            //{
            //    Assert.IsNotNull(result, "Saved");
            //}
            //else
            //{
            //    Assert.IsNull(result, "Not Saved");
            //}
        }

        [TestMethod]
        public void UpdateContactDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(contController, searchURL, contlName);
            PlantContactModel objPlantContact = new PlantContactModel { Id = 51, EcoalabAccountNumber = "123", ContactFirstName = "SDF", ContactLastName = "SFS", ContactFaxNumber = "3424242423", ContactMobilePhone = "2423423424", ContactEmailAdresss = "FSDF@SGFS.COM", ContactOfficePhone = "2342342423", ContactPositionId = 1, ContactTitle = "TMtitle" };
			List<PlantContactModel> list = new List<PlantContactModel>();
			list.Add(objPlantContact);
			HttpResponseMessage result = contController.Put(list);
            if (result != null)
            {
                Assert.IsNotNull(result, "Updated");
            }
            else
            {
                Assert.IsNull(result, "Not Updated");
            }
        }

        [TestMethod]
        public void DeleteContactDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(contController, searchURL, contlName);
            PlantContactModel objPlantContact = new PlantContactModel { Id = 53, EcoalabAccountNumber = "1", ContactFirstName = "SDF", ContactLastName = "SFS", ContactFaxNumber = "3424242423", ContactMobilePhone = "2423423424", ContactEmailAdresss = "FSDF@SGFS.COM", ContactOfficePhone = "2342342423", ContactPositionId = 2, ContactTitle = "TMtitle" };
			List<PlantContactModel> list = new List<PlantContactModel>();
			list.Add(objPlantContact);
			HttpResponseMessage result = contController.DeleteContact(list);
            if (result != null)
            {
                Assert.IsNotNull(result, "Deleted");
            }
            else
            {
                Assert.IsNull(result, "Not Deleted");
            }
        }

        #region "Methods"

        private List<PlantContact> MockPlantContact()
        {
            _mockPlantContact = new List<PlantContact>();
            _mockPlantContact.Add(new PlantContact { EcoalabAccountNumber = "123", ContactFirstName = "TestFirst", ContactLastName = "TestLast", ContactFaxNumber = "abcdef", ContactMobilePhone = "46546464", ContactEmailAdresss = "Test@email.com", ContactOfficePhone = "464564dfsdf564", ContactPositionId = 2, ContactTitle = "TMtitle" });

            return _mockPlantContact;
        }

        #endregion

        #region "Properties"      

        /// <summary>
        ///     mock PlantContact
        /// </summary>
        private List<PlantContact> _mockPlantContact;

        /// <summary>
        ///     Api controller ContactController
        /// </summary>
        private ContactController contController;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext controllerContext;

        /// <summary>
        ///     interface IPlantContactService
        /// </summary>
        private Mock<IPlantContactService> plantContService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> userService;

        #endregion
    }
}