﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models;  
    using Infra;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Models.PlantSetup.Dryer;
    using Moq;
    using Services.PlantSetup.Dryer;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.Dryer;
    using Ecolab.Services;
    using Ecolab.ConduitLocal.Web.Models.PlantSetup.Dryer;

    [TestClass]
    public class DryerTests : TestBase
    {
        /// <summary>
        ///     DryerGroup Service
        /// </summary>
        private Mock<IDryerGroupService> dryerGroupService;

        /// <summary>
        ///     DryerGroup Service
        /// </summary>
        private Mock<IDryerService> dryerService;

        /// <summary>
        /// UserService service
        /// </summary>
        private  Mock<IUserService> userService;

        /// <summary>
        /// Api DryerController 
        /// </summary>
        private DryerController dryerController;

        /// <summary>
        /// DryerGroup service model
        /// </summary>
        List<DryerGroup> mockdryerGroups = new List<DryerGroup>();

        /// <summary>
        /// DryerGroup service model
        /// </summary>
        DryerGroupModel mockdryerGroupModel;

        /// <summary>
        /// DryerType service model
        /// </summary>
        List<DryerType> mockDryerTypes = new List<DryerType>();

        /// <summary>
        /// Dryer service model
        /// </summary>
        Dryer mockDryer;

        /// <summary>
        /// Web Model DryerModel 
        /// </summary>
        DryerModel mockDryerModel; 

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            //CustomPrincipal custPrinciple = new CustomPrincipal("1");
            //custPrinciple.UserId = 1;
            //HttpContext.Current.User = custPrinciple;

            dryerGroupService = new Mock<IDryerGroupService>();
            dryerService = new Mock<IDryerService>();
            userService = new Mock<IUserService>();
            DateTime lastModifiedTimeStamp;
            int id = 1; 

            dryerGroupService.Setup(dg => dg.FetchDryerGroupDetails(It.IsAny<string>())).Returns(mockdryerGroups);
            dryerGroupService.Setup(dg => dg.InsertDryerGroup(It.IsAny<DryerGroup>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            dryerGroupService.Setup(dg => dg.UpdateDryerGroup(It.IsAny<DryerGroup>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            dryerGroupService.Setup(dg => dg.DeleteDryerGroup(It.IsAny<DryerGroup>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), out lastModifiedTimeStamp)).Returns(id);
            dryerService.Setup(ds => ds.FetchDryerTypes(It.IsAny<string>())).Returns(mockDryerTypes);
            dryerService.Setup(ds => ds.InsertDryer(It.IsAny<Dryer>(), It.IsAny<int>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            dryerService.Setup(ds => ds.UpdateDryer(It.IsAny<Dryer>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(id);
            dryerService.Setup(ds => ds.DeleteDryer(It.IsAny<Dryer>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), out lastModifiedTimeStamp)).Returns(id);
            
            HttpConfiguration config = new HttpConfiguration();
            dryerController = new DryerController(userService.Object, _plantService.Object, dryerGroupService.Object, dryerService.Object) { Request = new HttpRequestMessage() };
            dryerController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        /// <summary>
        /// Get the dryer group details
        /// </summary>
        [TestMethod]
        public void GetTest()
        {
            List<DryerGroupModel> result = dryerController.Get();
            Assert.IsNotNull(result, "Get the dryer group details");
        }

        /// <summary>
        /// Create DryerGroup
        /// </summary>
        [TestMethod]
        public void CreateDryerGroupTest()
        {
            HttpResponseMessage result = dryerController.CreateDryerGroup(mockdryerGroupModel);
            Assert.IsNotNull(result, "Created dryer group details");
        }

        /// <summary>
        /// Update Dryer Group
        /// </summary>
        [TestMethod]
        public void UpdateDryerGroupTest()
        {
            HttpResponseMessage result = dryerController.UpdateDryerGroup(mockdryerGroupModel);
            Assert.IsNotNull(result, "Updated dryer group details");
        }

        /// <summary>
        /// Delete Dryer Group
        /// </summary>
        [TestMethod]
        public void DeleteDryerGroupTest()
        {
            HttpResponseMessage result = dryerController.DeleteDryerGroup(mockdryerGroupModel);
            Assert.IsNotNull(result, "delete dryer group details");
        }

        /// <summary>
        /// Get Dryer Types details
        /// </summary>
        [TestMethod]
        public void FetchDryerTypesTest()
        {
            List<DryerTypeModel> result = dryerController.FetchDryerTypes();
            Assert.IsNotNull(result, "Get the dryer types details");
        }

        ///// <summary>
        ///// Create Dryer, commented it because of here we have conversions 
        ///// </summary>
        //[TestMethod]
        //public void CreateDryerTest()
        //{
        //    HttpResponseMessage result = dryerController.CreateDryer(mockDryerModel);
        //    Assert.IsNotNull(result, "Created dryer details");
        //}

        ///// <summary>
        ///// Update Dryer
        ///// </summary>
        //[TestMethod]
        //public void UpdateDryerTest()
        //{
        //    HttpResponseMessage result = dryerController.UpdateDryer(mockDryerModel);
        //    Assert.IsNotNull(result, "Updated dryer details");
        //}

        ///// <summary>
        ///// Delete Dryer
        ///// </summary>
        //[TestMethod]
        //public void DeleteDryerTest()
        //{
        //    HttpResponseMessage result = dryerController.DeleteDryer(mockDryerModel);
        //    Assert.IsNotNull(result, "delete dryer details");
        //}


        public DryerTests()
        {
            mockdryerGroups.Add(new DryerGroup
            {
                DesiredUnits = "kgs",
                Dryer= new Dryer()
                {
                    ActualUnits= "lbs",
                    ConvertedNominalload = 10.7M,
                    DesiredUnits ="kgs",                    
                    EcolabAccountNumber = "040242802",
                    GroupId = 2,
                    GroupName = "TestGroup",
                    Id =1,
                    IsDelete = false,
                    IsDeleted = false,
                    LastModifiedTimestampAtCentral = DateTime.Now,
                    LastModifiedTimeStampDryer = DateTime.Now,
                    LastModifiedTimeStampDryerGroup  = DateTime.Now,
                    LastSyncTime = DateTime.Now,
                    MaxNumberOfRecords = 10,
                    Name = "TestDryer",
                    Nominalload = 10.8M                    
                },
                EcolabAccountNumber = "040242802",
                Id= 1,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampDryer = DateTime.Now,
                LastModifiedTimeStampDryerGroup  = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "TestDryerGroup"
            });

            mockdryerGroupModel = new DryerGroupModel()
            {
                DesiredUnits = "kgs",
                Dryer = new DryerModel()
                {
                    ActualUnits = "lbs",
                    ConvertedNominalload = 10.7M,
                    DesiredUnits = "kgs",
                    EcolabAccountNumber = "040242802",
                    GroupId = 2,
                    Id = 1,
                    GroupName = "TestGroup",
                    IsDeleted = false,
                    LastModifiedTimestampAtCentral = DateTime.Now,
                    LastModifiedTimeStampDryer = DateTime.Now,
                    LastModifiedTimeStampDryerGroup = DateTime.Now,
                    LastSyncTime = DateTime.Now,
                    MaxNumberOfRecords = 10,
                    Name = "TestDryer",
                    Nominalload = 10.8M
                },
                EcolabAccountNumber = "040242802",                
                IsDelete = false,
                IsDeleted = false,
                Id = 1,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampDryer = DateTime.Now,
                LastModifiedTimeStampDryerGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "TestDryerGroup"
            };

            mockDryerTypes.Add(new DryerType 
            { 
                Id = 1,
                Name = "TestDryerType"
            });

            mockDryer = new Dryer()
            {
                ActualUnits = "lbs",
                ConvertedNominalload = 10.7M,
                DesiredUnits = "kgs",
                EcolabAccountNumber = "040242802",
                GroupId = 2,
                GroupName = "TestGroup",
                Id = 1,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampDryer = DateTime.Now,
                LastModifiedTimeStampDryerGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "TestDryer",
                Nominalload = 10.8M      
            };

            mockDryerModel = new DryerModel()
            {
                ActualUnits = "lbs",
                ConvertedNominalload = 10.7M,
                DesiredUnits = "kgs",
                EcolabAccountNumber = "040242802",
                GroupId = 2,
                GroupName = "TestGroup",
                Id = 1,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastModifiedTimeStampDryer = DateTime.Now,
                LastModifiedTimeStampDryerGroup = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                Name = "TestDryer",
                Nominalload = 10.8M      
            };
        }
    }
}
