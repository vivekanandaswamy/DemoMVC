﻿

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api.Washers.Conventional;
    using ConduitLocal.Web.Models.Washers.Conventional;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Washers.Conventional;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers.Conventional;
    using Ecolab.Services.Interfaces.Washers.Tunnel;
    using Ecolab.ConduitLocal.Web.Api.Washers.Tunnel;
    using Ecolab.Services;
    using System.Web;
    using Ecolab.ConduitLocal.Web.Models.Washers.Tunnel;
    using Ecolab.Models.Washers.Tunnel;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Dcs.Entities;
    using System.Configuration;
    using ConduitLocal.Web.Api;

    [TestClass]
    public class TunnelTests : TestBase
    {
        /// <summary>
        ///     Interface object for User Services.
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        ///  Interface object for Plant Services.
        /// </summary>
        private Mock<IPlantService> plantService;

        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private Mock<IControllerSetupService> controllerSetupService;

        /// <summary>
        ///     The ITunnelCompartment services
        /// </summary>
        private Mock<ITunnelCompartmentServices> tunnelCompartmentServices;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private Mock<ITunnelGeneralServices> tunnelGeneralServices;

        /// <summary>
        ///     The _tunnel Connection services
        /// </summary>
        private Mock<ITunnelConnectionServices> tunnelConnectionServices;

        /// <summary>
        ///     The _washer group formula service
        /// </summary>
        private Mock<IWasherGroupFormulaService> washerGroupFormulaService;

        /// <summary>
        ///     The _washer Group Service
        /// </summary>
        private Mock<IWasherGroupService> washerGroupService;

        /// <summary>
        /// Web api tunnel controller 
        /// </summary>
        private TunnelController tunnelController;

        /// <summary>
        /// 
        /// </summary>
        private IEnumerable<WashersList> washersList;

        /// <summary>
        /// WashersList
        /// </summary>
        private List<WashersList> washersLists = new List<WashersList>();

        /// <summary>
        /// PressExtractor
        /// </summary>
        IEnumerable<PressExtractor> pressExtractor;

        /// <summary>
        /// PressExtractor
        /// </summary>
        List<PressExtractor> pressExtractors = new List<PressExtractor>();

        /// <summary>
        /// WasherGroup
        /// </summary>
        List<WasherGroup> washerGroups = new List<WasherGroup>();

        /// <summary>
        /// WasherModelSizeModel
        /// </summary>
        IEnumerable<Ecolab.Models.Washers.Tunnel.WasherModelSize> washerModelSize;

        /// <summary>
        /// WasherModelSizeModel
        /// </summary>
        List<Ecolab.Models.Washers.Tunnel.WasherModelSize> washerModelSizes = new List<Ecolab.Models.Washers.Tunnel.WasherModelSize>();

        /// <summary>
        /// TunnelGeneralModel
        /// </summary>
        TunnelGeneralModel tunnelGeneralModel;

        /// <summary>
        /// TunnelGeneral
        /// </summary>
        TunnelGeneral tunnelGeneral = new TunnelGeneral();

        /// <summary>
        /// TunnelTags
        /// </summary>
        List<TunnelTags> tunnelTags = new List<TunnelTags>();

        /// <summary>
        /// TunnelCompartmentModel
        /// </summary>
        TunnelCompartmentModel tunnelCompartmentModel = new TunnelCompartmentModel();

        /// <summary>
        /// TunnelCompartmentModel
        /// </summary>
        TunnelCompartment tunnelCompartment;

        /// <summary>
        /// WashStep
        /// </summary>
        IEnumerable<WashStep> washStep;

        /// <summary>
        /// WashStep
        /// </summary>
        List<WashStep> washSteps = new List<WashStep>();

        /// <summary>
        /// PumpAssociation
        /// </summary>
        IEnumerable<PumpAssociation> pumpAssociation;

        /// <summary>
        /// PumpAssociation
        /// </summary>
        List<PumpAssociation> pumpAssociations = new List<PumpAssociation>();

        /// <summary>
        /// WasherGroup
        /// </summary>
        IEnumerable<WasherGroup> washerGroup;

        List<PressExtractor> extractorList = new List<PressExtractor>();


        public TunnelTests()
        {
            washersLists.Add(new WashersList
            {
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Id = 2,
                IsDeleted = false,
                WasherModelId = 1,
                WasherModelName = "ModelName"
            });

            washersList = washersLists;

            pressExtractors.Add(new PressExtractor
            {
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Id = 1,
                IsDeleted = false,
                MyServiceModDtTm = DateTime.Now,
                MyServicePropId = 1,
                Name = "Name",
                RegionCode = "en-EN"
            });

            pressExtractor = pressExtractors;

            washerGroups.Add(new WasherGroup
            {
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Id = 2,
                IsDelete = false,
                IsDeleted = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                MyServiceLastModifiedTime = DateTime.Now,
                WasherGroupId = 7,
                WasherGroupName = "GroupName",
                MyServiceWasherGroupGuid = Guid.NewGuid(),
                MyServiceWasherGroupNumber = 1,
                WasherGroupDescription = "Description",
                WasherGroupNumber = "9",
                WasherGroupTypeId = 7,
                WasherGroupTypeName = "TypeName"
            });

            washerModelSizes.Add(new Ecolab.Models.Washers.Tunnel.WasherModelSize
            {
                WasherSize = "large"
            });

            washerModelSize = washerModelSizes;

            tunnelGeneralModel = new TunnelGeneralModel()
            {
                AweActive = true,
                ControllerId = 1,
                ControllerName = "Tunnel",
                Description = "Test Desc",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                FormulaCount = 2,
                IsDelete = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxLoad = 20,
                MaxNumberOfRecords = 10,
                ModelId = 4,
                MyServiceMaxLoad = 7,
                MyServiceMCHId = 1,
                MyServiceModelId = 2,
                MyServiceWasherGroupGuid = Guid.NewGuid(),
                MyServiceWashersGuid = Guid.NewGuid(),
                Name = "Test Name",
                NoofCompartments = 12,
                NoofTanks = 1,
                PlantWasherNumber = 12,
                PressExtractor = 1,
                PressExtractorName = "",
                ProgramNumber = 1,
                RegionCode = "em-EN",
                RegionId = 1,
                Role = 4,
                Size = "23",
                WasherGroupId = 7,
                WasherGroupName = "GroupName",
                WasherType = "Type",
                WasherTypeFlag = true,
                WasherMode = 2,
                WasherModelName = "WasherModelName"
            };

            tunnelTags.Add(new TunnelTags
            {
                AutoWeightEntryActiveTag = "",
                AutoWeightEntryFormulaTag = "",
                CurrentFormulaTag = "",
                CurrentInjectionTag = "",
                CurrentOperationCounterTag = "",
                EndOfFormulaTag = "",
                HoldDelayTag = "",
                HoldSignalTag = "",
                InjectionClassTag = "",
                InjectionRatioTag = "",
                RatioDosingActiveTag = "",
                RatioDosingPercentageTag = "",
                TagAddress = "",
                TagDescription = "",
                WasherModeTag = "",
                WasherNumberTag = "1",
                WaterFlushTimeTag = ""
            });

            tunnelCompartmentModel = new TunnelCompartmentModel
            {
                CompartmentNumber = 1,
                DosagePoint = true,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                IsDelete = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                MyServiceDrainLookUpId = 6,
                MyServiceTunnelWaterFlowTypeId = 1,
                MyServiceWasherId = Guid.NewGuid(),
                RecycledWaterInlet = true,
                SplitCompartment = true,
                Steam = true,
                TemperatureControlByPMR = true,
                tunnelCompartmentId = 1,
                WasherGroupId = 7,
                WashStepId = 3,
                WaterFlowId = 5,
                WaterinletDrainId = 8,
                WaterLevel = 18
            };

            tunnelGeneral = new TunnelGeneral
            {
                Id = 1,
                AweActive = true,
                ControllerId = 1,
                ControllerName = "Tunnel",
                Description = "Test Desc",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                FormulaCount = 2,
                IsDelete = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxLoad = 20,
                MaxNumberOfRecords = 10,
                ModelId = 4,
                MyServiceMaxLoad = 7,
                MyServiceMCHId = 1,
                MyServiceModelId = 2,
                MyServiceWasherGroupGuid = Guid.NewGuid(),
                MyServiceWashersGuid = Guid.NewGuid(),
                Name = "Test Name",
                NoofCompartments = 12,
                NoofTanks = 1,
                PlantWasherNumber = 12,
                PressExtractor = 1,
                PressExtractorName = "",
                ProgramNumber = 1,
                RegionCode = "em-EN",
                RegionId = 1,
                Role = 4,
                Size = "23",
                WasherGroupId = 7,
                WasherGroupName = "GroupName",
                WasherType = "Type",
                WasherTypeFlag = true,
                WasherMode = 2,
                WasherModelName = "WasherModelName"
            };

            tunnelCompartment = new TunnelCompartment
            {
                Id = 1,
                CompartmentNumber = 1,
                DosagePoint = true,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                IsDelete = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                MyServiceDrainLookUpId = 6,
                MyServiceTunnelWaterFlowTypeId = 1,
                MyServiceWasherId = Guid.NewGuid(),
                RecycledWaterInlet = true,
                SplitCompartment = true,
                Steam = true,
                TemperatureControlByPMR = true,
                WasherGroupId = 7,
                WashStepId = 3,
                WaterFlowId = 5,
                WaterinletDrainId = 8,
                WaterLevel = 18
            };

            washSteps.Add(new WashStep
            {
                StepId = 1,
                StepName = "StepName"
            });

            washStep = washSteps;

            pumpAssociations.Add(new PumpAssociation
            {
                FormulaAssociated = 8,
                ProductName = "Name"
            });

            pumpAssociation = pumpAssociations;

            washerGroup = washerGroups;

            extractorList.Add(new PressExtractor { Id = 1, Name = "Press" });
            extractorList.Add(new PressExtractor { Id = 2, Name = "Extractor" });
            extractorList.Add(new PressExtractor { Id = 3, Name = "Jet Press" });
            extractorList.Add(new PressExtractor { Id = 4, Name = "Jet Extractor" });

        }

        [TestInitialize]
        public void TestInitialize()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1 };
            HttpContext.Current.User = custPrinciple;

            userService = new Mock<IUserService>();
            plantService = new Mock<IPlantService>();
            controllerSetupService = new Mock<IControllerSetupService>();
            tunnelCompartmentServices = new Mock<ITunnelCompartmentServices>();
            tunnelGeneralServices = new Mock<ITunnelGeneralServices>();
            washerGroupFormulaService = new Mock<IWasherGroupFormulaService>();
            washerGroupService = new Mock<IWasherGroupService>();
            tunnelConnectionServices = new Mock<ITunnelConnectionServices>();
            DateTime lastModifiedTimeStamp;
            var p = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            tunnelGeneralServices.Setup(tg => tg.GetWashersList(It.IsAny<string>(), It.IsAny<int>())).Returns(washersList);
            tunnelGeneralServices.Setup(tg => tg.GetPressExtractorList(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"))).Returns(pressExtractor);
            tunnelGeneralServices.Setup(tg => tg.GetTransferTypeList(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"))).Returns(pressExtractor);
            washerGroupService.Setup(wg => wg.GetWasherGroupDetails(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(washerGroups);
            tunnelGeneralServices.Setup(tg => tg.GetWashersModelSizeList(It.IsAny<int>())).Returns(washerModelSize);
            tunnelGeneralServices.Setup(tg => tg.SaveTunnelData(tunnelGeneral, It.IsAny<int>(), out lastModifiedTimeStamp)).Returns("101");
            tunnelGeneralServices.Setup(tg => tg.GetTunnelWasherTagsByWasherId(It.IsAny<int>(), It.IsAny<string>())).Returns(tunnelTags);
            tunnelCompartmentServices.Setup(tg => tg.SavetunnelCompartmentData(tunnelCompartment, It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(101);
            tunnelGeneralServices.Setup(tg => tg.GetTunnelData(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(tunnelGeneral);
            tunnelCompartmentServices.Setup(tg => tg.GetCompartmentData(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), Convert.ToByte(It.IsAny<byte>()), true)).Returns(tunnelCompartment);
            tunnelGeneralServices.Setup(tg => tg.UpdateTunnelData(tunnelGeneral, It.IsAny<int>(), out lastModifiedTimeStamp, It.IsAny<DateTime?>())).Returns("201");
            tunnelCompartmentServices.Setup(tg => tg.GetWaterInletDrainList(ecolabAccountNumber)).Returns(pressExtractor);
            tunnelCompartmentServices.Setup(tg => tg.GetWaterFlowList(It.IsAny<int>())).Returns(pressExtractor);
            washerGroupFormulaService.Setup(wg => wg.GetWashOperations(It.IsAny<int>(), It.IsAny<bool>())).Returns(washStep);
            tunnelCompartmentServices.Setup(tg => tg.PumpsProductsList(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(pumpAssociation);
            washerGroupService.Setup(wg => wg.GetWasherGroupDetails(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(washerGroups);
            tunnelGeneralServices.Setup(tg => tg.GetPressExtractorList(It.IsAny<string>())).Returns(extractorList);

            HttpConfiguration config = new HttpConfiguration();
            tunnelController = new TunnelController(tunnelGeneralServices.Object, controllerSetupService.Object, washerGroupFormulaService.Object, tunnelCompartmentServices.Object, washerGroupService.Object, userService.Object, plantService.Object, tunnelConnectionServices.Object);
            tunnelController.Request = new HttpRequestMessage();
            tunnelController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;            
        }

        // commented as ecolabaccount number is not accessable in the controller
        /// <summary>
        /// MS Test for GetDropDownData
        /// </summary>
        [TestMethod]
        public void GetDropDownData_Test()
        {
            string ecoLabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int regionId = 1;
            string washerType = "Tunnel";
            int washerGroupId = 1;
            //TunnelGeneralDropdownsModel tunnelGenDropdownsModel = tunnelController.GetDropDownData(ecoLabAccountNumber, regionId, washerType, washerGroupId);
            //if (tunnelGenDropdownsModel != null)
            //{
            //    Assert.IsNotNull(tunnelGenDropdownsModel, "Get the drop downs data.");
            //}
        }

        /// <summary>
        /// MS Test for GetDropDownData
        /// </summary>
        [TestMethod]
        public void GetSizeList_Test()
        {
            int washerModelId = 1;

            IEnumerable<Ecolab.ConduitLocal.Web.Models.Washers.Tunnel.WasherModelSizeModel> washerModelSizeModel = tunnelController.GetSizeList(washerModelId);
            if (washerModelSizeModel != null)
            {
                Assert.IsNotNull(washerModelSizeModel, "Get the drop downs data.");
            }
        }

        /// <summary>
        /// MS Test for SaveTunnelData
        /// </summary>
        [TestMethod]
        public void SaveTunnelData_Test()
        {
            HttpResponseMessage result = tunnelController.SaveTunnelData(tunnelGeneralModel);

            if (result != null)
            {
                Assert.IsNotNull(result, "Get the drop downs data.");
            }
        }

        /// <summary>
        /// MS Test for SaveTunnelCompartmentData
        /// </summary>
        [TestMethod]
        public void SaveTunnelCompartmentData_Test()
        {
            HttpResponseMessage result = tunnelController.SaveTunnelCompartmentData(tunnelCompartmentModel);

            if (result != null)
            {
                Assert.IsNotNull(result, "Get the drop downs data.");
            }
        }

        /// <summary>
        /// MS Test for UpdateTunnelData
        /// </summary>
        [TestMethod]
        public void UpdateTunnelData_Test()
        {
            HttpResponseMessage result = tunnelController.UpdateTunnelData(tunnelGeneralModel);

            if (result != null)
            {
                Assert.IsNotNull(result, "Get the drop downs data.");
            }
        }

        /// <summary>
        /// MS Test for GetTunnelData
        /// </summary>
        [TestMethod]
        public void GetTunnelData_Test()
        {
            int id = 1;
            int washerGroupId = 2;
            string ecoLabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");

            TunnelGeneralModel result = tunnelController.GetTunnelData(id, washerGroupId, ecoLabAccountNumber);

            if (result != null)
            {
                Assert.IsNotNull(result, "Get the tunnel data.");
            }
        }

        /// <summary>
        /// MS Test for GetCompartmentData
        /// </summary>
        [TestMethod]
        public void GetCompartmentData_Test()
        {
            int id = 1111;
            int washerGroupId = 2113;
            string ecoLabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            byte compartmentNumber = 1;
            int regionId = 1;
            int controllerId = 2077;

            TunnelCompartmentModel result = tunnelController.GetCompartmentData(id, washerGroupId, ecoLabAccountNumber, compartmentNumber, regionId, controllerId);

            if (result != null)
            {
                Assert.IsNotNull(result, "Get the compartment data.");
            }
        }

        /// <summary>
        /// MS Test for GetCompartmentDropDownData
        /// </summary>
        [TestMethod]
        public void GetCompartmentDropDownData_Test()
        {
            string ecoLabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int regionId = 1;
            int controllerId = 1;
            int tunnelId = 1;
            int washerGroupId = 1;

            TunnelConventionalDropDownModel result = tunnelController.GetCompartmentDropDownData(ecoLabAccountNumber, regionId, controllerId, tunnelId, washerGroupId);

            if (result != null)
            {
                Assert.IsNotNull(result, "Get the compartment data.");
            }
        }
    }
}
