﻿// -----------------------------------------------------------------------
// <copyright file="DefaultControllerTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Default Controller Tests object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.Default;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.Default;
    using System.Configuration;

    [TestClass]
    public sealed class DefaultControllerTests : TestBase, IDisposable
    {
        /// <summary>
        ///     PortletModel List
        /// </summary>
        private readonly List<PortletModel> mPortletModelList = new List<PortletModel>();

        /// <summary>
        ///     ShiftSummary
        /// </summary>
        private readonly ShiftSummary mShiftSummary;

        /// <summary>
        ///     Api controller DefaultController
        /// </summary>
        private DefaultController mDefaultController;

        /// <summary>
        ///     interface IDefaultService
        /// </summary>
        private Mock<IDefaultService> mDefaultService;

        /// <summary>
        ///     portlet List
        /// </summary>
        private List<Portlet> mPortletList = new List<Portlet>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> mUserService;

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public DefaultControllerTests()
        {
            mPortletList.Add(new Portlet { PortletId = 1, DisplayOrder = 1, IsEnabled = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });
            mPortletList.Add(new Portlet { PortletId = 2, DisplayOrder = 2, IsEnabled = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });
            mPortletList.Add(new Portlet { PortletId = 3, DisplayOrder = 3, IsEnabled = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });
            mPortletList.Add(new Portlet { PortletId = 4, DisplayOrder = 4, IsEnabled = false, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });

            mShiftSummary = new ShiftSummary { Efficiency = 90, LostLoad = 100, TotalLoad = 9000 };

            mPortletModelList.Add(new PortletModel { PortletId = 1, DisplayOrder = 1, IsEnabled = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });
            mPortletModelList.Add(new PortletModel { PortletId = 2, DisplayOrder = 2, IsEnabled = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });
            mPortletModelList.Add(new PortletModel { PortletId = 3, DisplayOrder = 3, IsEnabled = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });
            mPortletModelList.Add(new PortletModel { PortletId = 4, DisplayOrder = 4, IsEnabled = false, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") });
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            mUserService = null;
            mDefaultService = null;
            mPortletList = null;
            mDefaultController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            mUserService = new Mock<IUserService>();

            mDefaultService = new Mock<IDefaultService>();
            mDefaultService.Setup(_ => _.FetchPortletsByUser(1, "1")).Returns(mPortletList);
            mDefaultService.Setup(_ => _.GetShiftSummaryDetails("1")).Returns(mShiftSummary);
            mDefaultService.Setup(_ => _.CreateUserPortletData(It.IsAny<List<Portlet>>(), It.IsAny<int>(), It.IsAny<string>())).Returns("101");
            HttpConfiguration config = new HttpConfiguration();
            mDefaultController = new DefaultController(mUserService.Object, _plantService.Object, mDefaultService.Object) { Request = new HttpRequestMessage() };
            mDefaultController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        /// <summary>
        ///     Save UserPortletData
        /// </summary>
        /// <returns>Save User PortletData</returns>
        [TestMethod]
        public void CreateUserPortletData()
        {
            string result = mDefaultController.CreateUserPortletData(mPortletModelList);
            Assert.AreEqual(result, "101");
        }
    }
}