﻿// -----------------------------------------------------------------------
// <copyright file="MonitorSetupTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The MonitorSetupTests object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller.Visualization
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api.Visualization.Monitor;
    using ConduitLocal.Web.Models.Visualization.Monitor;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Visualization.Monitor;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.Visualization.Monitor;
    using MachinesForWasherGroupType = Models.Visualization.Monitor.MachinesForWasherGroupType;
    using MonitorDetails = Models.Visualization.Monitor.MonitorDetails;
    using WasherGroupType = Models.Visualization.Monitor.WasherGroupType;

    [TestClass]
    public sealed class MonitorSetupTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public MonitorSetupTests()
        {
            _monitorSetUp = new MonitorSetUp { DashboardId = 1, DashboardName = "TEST", WasherId = 2, WasherGroupTypeId = 3, WasherGroupTypeName = "1", MachineName = "ABC", MonitorId = "2", IsEnableParameter = true, IsEdit = true, IsDeleteMapping = true, Customer = true, Formula = true, Load = true };

            _mockMachinesForWasherGroupType.Add(new MachinesForWasherGroupType { MachineId = 1, MachineName = "1" });

            _mockWasherGroupType.Add(new WasherGroupType { WasherGroupTypeId = 1, WasherGroupTypeName = "1" });

            _mockMonitorDetails.Add(new MonitorDetails { MonitorId = "1" });

            _mockMonitorSetup.Add(new MonitorSetUp { DashboardId = 1, DashboardName = "1", WasherId = 2, WasherGroupTypeId = 2, WasherGroupTypeName = "1", MachineName = "1", MonitorId = "1", IsEnableParameter = true, IsEdit = true, IsDeleteMapping = true, Customer = true, Formula = true, Load = true });
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            _userService = null;
            _monitorSetupService = null;
            _plantService = null;
            _mockMonitorSetup = null;
            _mockWasherGroupType = null;
            _mockMachinesForWasherGroupType = null;
            _mockMonitorDetails = null;
            _monitorSetupController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.GetWasherGroupTypes()).Returns(_mockWasherGroupType);

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.GetMachinesForWasherGroupType(It.IsAny<string>(), It.IsAny<int>())).Returns(_mockMachinesForWasherGroupType);

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.FetchMonitorSetUpDetails(It.IsAny<string>())).Returns(_mockMonitorSetup);

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.FetchMonitorSetUpDetailsById(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockMonitorSetup);

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.InsertMonitorSetUp(_monitorSetUp, It.IsAny<int>())).Returns(It.IsAny<int>());

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.UpdateMonitorSetUp(It.IsAny<MonitorSetUp>(), It.IsAny<int>())).Returns(It.IsAny<int>());

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.DeleteMonitorSetUp(_monitorSetUp, It.IsAny<int>())).Returns(It.IsAny<string>());

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.DeleteDashboardMonitorSetUpMapping(_monitorSetUp, It.IsAny<int>()));

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.FetchMonitorDetails(It.IsAny<string>())).Returns(_mockMonitorDetails);

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.SaveMonitorDetails(_mockMonitorDetails)).Returns(It.IsAny<int>());

            _monitorSetupService = new Mock<IMonitorSetupService>();
            _monitorSetupService.Setup(alr => alr.FetchMonitorSetUpDetailsById(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockMonitorSetup);

            HttpConfiguration config = new HttpConfiguration();
            _monitorSetupController = new MonitorSetupController(_userService.Object, _plantService.Object, _monitorSetupService.Object) { Request = new HttpRequestMessage() };
            _monitorSetupController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        /// <summary>
        ///     GetWasherGroupTypes
        /// </summary>
        [TestMethod]
        public void GetWasherGroupTypes_Test()
        {
            List<ConduitLocal.Web.Models.Visualization.Monitor.WasherGroupType> result = _monitorSetupController.FetchWasherGroupTypes();
            Assert.IsNotNull(result, "Washer Group Type Data");
        }

        /// <summary>
        ///     GetMachinesForWasherGroupType
        /// </summary>
        [TestMethod]
        public void GetMachinesForWasherGroupType_Test()
        {
            List<ConduitLocal.Web.Models.Visualization.Monitor.MachinesForWasherGroupType> result = _monitorSetupController.FetchMachinesForWasherGroupType(1);
            Assert.IsNotNull(result, "Machines For Washer Group Type Data");
        }

        /// <summary>
        ///     FetchMonitorSetUpDetails
        /// </summary>
        [TestMethod]
        public void FetchMonitorSetUpDetails_Test()
        {
            List<MonitorSetupModel> result = _monitorSetupController.FetchMonitorSetUpDetails();
            Assert.IsNotNull(result, "Monitor SetUp Details Data");
        }

        /// <summary>
        ///     Fetch Monitor Details
        /// </summary>
        [TestMethod]
        public void FetchMonitorDetails_Test()
        {
            List<ConduitLocal.Web.Models.Visualization.Monitor.MonitorDetails> result = _monitorSetupController.FetchMonitors();
            Assert.IsNotNull(result, "Monitor Details Data");
        }

        [TestMethod]
        public void UpdateMonitorSetUp()
        {
            int id = 1;
            MonitorSetupModel result = _monitorSetupController.FetchMonitorDetailsToEdit(id);
            if (result == null)
            {
                Assert.IsNull(result, "run");
            }
            else
            {
                Assert.IsNotNull(result, "run fast");
            }
        }

        [TestMethod]
        public void DeleteMonitorSetUp()
        {
            int id = 1;
            string result = _monitorSetupController.DeleteMonitorSetup(id);
            if (result == null)
            {
                Assert.IsNull(result, "deleted successfully");
            }
            else
            {
                Assert.IsNotNull(result, "delete failed");
            }
        }

        [TestMethod]
        public void InsertMonitorSetUp()
        {
            MonitorSetupModel result = _monitorSetupController.FetchMonitorSetUpForAdd();
            Assert.IsNotNull(result);
        }

        #region "Properties"

        /// <summary>
        ///     Model Monitor Setup
        /// </summary>
        private readonly MonitorSetUp _monitorSetUp;

        /// <summary>
        ///     interface IMonitorSetupService
        /// </summary>
        private Mock<IMonitorSetupService> _monitorSetupService;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     Monitor Setup class
        /// </summary>
        private List<MonitorSetUp> _mockMonitorSetup = new List<MonitorSetUp>();

        /// <summary>
        ///     Machines For Washer Group Type
        /// </summary>
        private List<MachinesForWasherGroupType> _mockMachinesForWasherGroupType = new List<MachinesForWasherGroupType>();

        /// <summary>
        ///     Washer Group Type
        /// </summary>
        private List<WasherGroupType> _mockWasherGroupType = new List<WasherGroupType>();

        /// <summary>
        ///     MonitorDetails
        /// </summary>
        private List<MonitorDetails> _mockMonitorDetails = new List<MonitorDetails>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller AlarmController
        /// </summary>
        private MonitorSetupController _monitorSetupController;

        #endregion
    }
}