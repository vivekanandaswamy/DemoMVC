﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup;
    using ConduitLocal.Web.Models.Visualization.ConventionalWasher;
    using Infra;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Visualization.ConventionalWasher;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.Visualization;
    using Services.Interfaces.Visualization.ConventionalWasher;

    [TestClass]
    public sealed class ConventionalWasherDashboardTests : TestBase, IDisposable
    {
        /// <summary>
        ///     BatchDetails List
        /// </summary>
        private readonly List<BatchDetailsModel> _mockBatchDetailsModel = new List<BatchDetailsModel>();

        /// <summary>
        ///     BreakAndTimeline List
        /// </summary>
        private readonly List<BreakAndTimelineModel> _mockBreakAndTimelineModel = new List<BreakAndTimelineModel>();

        /// <summary>
        ///     Conventional Washer List
        /// </summary>
        private readonly List<ConventionalWasherModel> _mockConventionalWasherModel = new List<ConventionalWasherModel>();

        /// <summary>
        ///     List Conventional Washer
        /// </summary>
        private readonly List<ConventionalWasherModel> _mockConventionalWasherWebModel = new List<ConventionalWasherModel>();

        /// <summary>
        ///     GroupType WebModel
        /// </summary>
        private readonly List<GroupTypeModel> _mockGroupTypeWebModels = new List<GroupTypeModel>();

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     ConventionalWasherViewModel
        /// </summary>
        private ConventionalWasherViewModel _conventionalWasherViewModel;

        /// <summary>
        ///     Api controller
        /// </summary>
        private VisualizationController _convWasherController;

        /// <summary>
        ///     interface for Conventional Washer Dashboard Service
        /// </summary>
        private Mock<IConventionalWasherDashboardService> _convWasherService;

        /// <summary>
        ///     interface IDashboardService
        /// </summary>
        private Mock<IDashboardService> _dashboardService;

        /// <summary>
        ///     List Batch Details
        /// </summary>
        private List<BatchDetails> _mockBatchDetails = new List<BatchDetails>();

        /// <summary>
        ///     List Break And Timeline Details
        /// </summary>
        private List<BreakAndTimeline> _mockBreakAndTimeline = new List<BreakAndTimeline>();

        /// <summary>
        ///     List Conventional Washer
        /// </summary>
        private List<ConventionalWasher> _mockConventionalWasher = new List<ConventionalWasher>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        public ConventionalWasherDashboardTests()
        {
            TestSetup.Init(TestContext);
            _mockGroupTypeWebModels.Add(new GroupTypeModel { GroupTypeId = 1, GroupDescription = "ABC", GroupMainType = 1, IsTunnel = true });

            _mockConventionalWasherModel.Add(new ConventionalWasherModel { GroupId = 1, WasherId = 2, WasherName = "ABC", NominalLoad = 5.5, ActualLoad = 8.7, LoadEfficiency = 18.6, TimeEfficiency = 100, LostLoad = 9.8, Alarm = true, startTime = 3 });

            _mockConventionalWasher.Add(new ConventionalWasher { GroupId = 1, WasherId = 1, WasherName = "ABC", NominalLoad = 1, ActualLoad = 1, LoadEfficiency = 18.6, TimeEfficiency = 100, LostLoad = 1, Alarm = true, Status = "1" });

            _conventionalWasherViewModel = new ConventionalWasherViewModel { ActualLoad = 8.7.ToString("#,0.##"), Efficiency = 18.6, LostLoad = 9.8.ToString("#,0.##"), PlantLogo = "1", WeightColor = "2", WeightLevel = "3", EfficiencyColor = "4", EfficiencyLevel = "5", Pixel = 5, HoursToDisplay = 5, CurrentTimeInSeconds = 60 };

            _mockBatchDetails.Add(new BatchDetails { GroupId = 1, MachineId = 2, BatchId = 3, ProgramId = 4, ProgramName = "ABC", BatchStartTimeInSeconds = 60, BatchStandardEndTimeInSeconds = 60, BatchActualEndTimeInSeconds = 60, StandardTurnTimeInSeconds = 60, ActualTurnTimeInSeconds = 60, RunningStatus = true });

            _mockBreakAndTimelineModel.Add(new BreakAndTimelineModel { Type = "ABC", FromTimeInSeconds = 60, ToTimeInSeconds = 40 });
            
            _mockBreakAndTimeline.Add(new BreakAndTimeline { Type = "TimeLine", FromTimeInSeconds = 10, ToTimeInSeconds = 20 });
        }

        public TestContext TestContext { get; set; }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            _convWasherController.Dispose();
            _userService = null;
            _convWasherService = null;
            _mockConventionalWasher = null;
            _mockBreakAndTimeline = null;
            _mockBatchDetails = null;
            _dashboardService = null;
            _convWasherController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            _dashboardService = new Mock<IDashboardService>();

            _convWasherService = new Mock<IConventionalWasherDashboardService>();
            _convWasherService.Setup(conv => conv.FetchBatchData(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<int>())).Returns(_mockBatchDetails);

           // _convWasherService = new Mock<IConventionalWasherDashboardService>();
            _convWasherService.Setup(conv => conv.FetchWasherData(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockConventionalWasher);

           // _convWasherService = new Mock<IConventionalWasherDashboardService>();
            _convWasherService.Setup(conv => conv.FetchTimeLineAndBreakData(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockBreakAndTimeline);

            HttpConfiguration config = new HttpConfiguration();
            _convWasherController = new VisualizationController(_userService.Object, _plantService.Object, _dashboardService.Object, _convWasherService.Object);
            _convWasherController.Request = new HttpRequestMessage();
            _convWasherController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        // Fetchspeciftedlanguagedata  is commented in user access which is dependent on this test, hence commented this test
        ///// <summary>
        /////     GetWasherGroupTypes
        ///// </summary>
        //[TestMethod]
        //public void Fetch()
        //{
        //    Ecolab.ConduitLocal.Web.Controllers.LocaleController LocaleController = new Ecolab.ConduitLocal.Web.Controllers.LocaleController(_userService.Object, _plantService.Object);
        //    var P = LocaleController.LocalizationData;            
        //    ConventionalWasherViewModel result = _convWasherController.GetConventionalWasherVisualizationData(2);
        //    Assert.IsNotNull(result, "Data");
        //}
    }
}