﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.Chemical;
    using Moq;
    using Services.Interfaces;

    [TestClass]
    public sealed class PlantChemicalTests : TestBase, IDisposable
    {
        private readonly string contlName = "PlantChemical";
        private readonly string searchURL = ( new AppSettingsReader() ).GetValue("WebApiController.URL", typeof (string)) + "PlantChemical";

        #region "Methods"

        /// <summary>
        ///     Plant Chemical Tests
        /// </summary>
        public PlantChemicalTests()
        {
            _mockPlantChemical.Add(new ProductMaster { ProductId = 69, SKU = "WATER_HUUU", Name = "Water, Hot Reuse111111", Cost = 80, DensityFactor = 9, AcceptedDeviation = 0, ProductCategoryId = 0, Type = null, Supplier = "Supplier", IncludeinCI = true, PackagingSize = "Package", Weight = 25, Volume = 25, ProductcategoryName = null, IsSelected = true });

            objPlantChem = new ProductMasterModel { ProductId = 1, Cost = 9, IsSelected = true, EcolabAccountNumber = "1" };

            objPlantChemList = new List<ProductMasterModel> { new ProductMasterModel { ProductId = 1, Cost = 9, IsSelected = true, EcolabAccountNumber = "1" } };
        }

        #endregion

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            chemController.Dispose();
        }

        #region "Test Initialization"

        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            var _plantChem = new Mock<IProductMasterService>();
            _plantChem.Setup(Pc => Pc.FetchPlantChemicalList(It.IsAny<string>())).Returns(_mockPlantChemical);

            HttpConfiguration config = new HttpConfiguration();
            chemController = new PlantChemicalController(_userService.Object, _plantChem.Object, _plantService.Object, null);
            chemController.Request = new HttpRequestMessage();
            chemController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     ProductMaster
        /// </summary>
        private readonly List<ProductMaster> _mockPlantChemical = new List<ProductMaster>();

        /// <summary>
        ///     ProductMasterModel
        /// </summary>
        private readonly ProductMasterModel objPlantChem;

        /// <summary>
        ///     ProductMasterModel
        /// </summary>
        private readonly List<ProductMasterModel> objPlantChemList;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller ChemicalController
        /// </summary>
        private PlantChemicalController chemController;

        #endregion

        #region "TestMethods"

        [TestMethod]
        public void GetChemicalDetails_Test()
        {
            IEnumerable<ProductMasterModel> result = chemController.GetPlantChemical();
            Assert.IsNotNull(result, "Get chemical details.");
        }

        [TestMethod]
        public void CreateChemicalDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(chemController, searchURL, contlName);
            HttpResponseMessage result = chemController.CreateChemical(objPlantChemList);
            Assert.IsNotNull(result != null, "Chemical has been saved");
        }

        [TestMethod]
        public void SaveChemicalDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(chemController, searchURL, contlName);
            HttpResponseMessage result = chemController.Put(objPlantChemList);
            Assert.IsNotNull(result != null, "Chemical has been saved");
        }

        [TestMethod]
        public void DeleteChemicalDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(chemController, searchURL, contlName);
            HttpResponseMessage result = chemController.DeleteChemical(objPlantChemList);
            Assert.IsNotNull(result != null, "Chemical has been saved");
        }

        #endregion
    }
}