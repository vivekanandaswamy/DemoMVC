﻿// -----------------------------------------------------------------------
// <copyright file="MeterTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The MeterTests object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.Plc;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;

    [TestClass]
    public sealed class MeterTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public MeterTests()
        {
            control = new Ecolab.Models.ControllerSetup.Controller();
            control.ControllerId = 2464;
            control.ControllerModelId = 11;
            control.ControllerModelName = "PLC XL";
            control.ControllerName = "366 (PLCXL1T5WsExmple)";
            control.ControllerNumber = 366;
            control.ControllerType = "13";
            control.ControllerType = "1 Tunnel 5 Washers";
            control.EcolabAccountNumber = "P03810003";

            mockMeter.Add(new Meter { MeterId = 1, Description = "Test", MeterType = "test", MeterTypeName = "test", EcolabAccountNumber = "1", MaxValueLimit = 1, MeterTickUnit = "test", UsageFactor = 1, MachineId = 1, MachinecompartmentName = "test", ControllerId = 1, ControllerName = "test", ParentId = 1, ParentName = "testParent", Calibration = 1, DigitalInputNumber = "", AllowManualEntry = true, UtilityId = 1, UtilityLocation = "Test" });

            mockMeterModel = new MeterWebModel { MeterId = 9, EcolabAccountNumber = "1", Description = "test", MeterType = "3", GroupId = 1, MachineId = 1, MaxValueLimit = 1000, MeterTickUnit = "1", UsageFactor = Convert.ToDecimal(5), ParentId = 1, Calibration = Convert.ToDecimal(2), DigitalInputNumber = "", AllowManualEntry = true };

            meterModel = new MeterWebModel { MeterId = 9, EcolabAccountNumber = "1", Description = "test", MeterType = "3", GroupId = 1, MachineId = 1, MaxValueLimit = 1000, MeterTickUnit = "1", UsageFactor = Convert.ToDecimal(0), ControllerId = 1, ParentId = 1, Calibration = Convert.ToDecimal(2), DigitalInputNumber = "", AllowManualEntry = true };

            metermodels = new MeterModel { MeterId = 1051, Description = "Meter 1", MeterType = "2", GroupId = 2573, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), MaxValueLimit = 10000, MeterTickUnit = "gallon", UsageFactor = 1, ControllerId = 2305, ParentId = 0, Calibration = 45, DigitalInputNumber = 0, WaterType = 13 };
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            userService = null;
            meterService = null;
            _plantService = null;
            mockMeter = null;
            meterController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            userService = new Mock<IUserService>();

            meterService = new Mock<IMeterService>();
            washerGroupService = new Mock<IWasherGroupService>();
            meterService.Setup(ut => ut.GetPlantMeterDetails(It.IsAny<int?>(), It.IsAny<string>())).Returns(mockMeter);
            meterService.Setup(x => x.GetPlantMeterDetailsByMeterId(It.IsAny<int>(), It.IsAny<string>())).Returns(metermodels); ;
            ecolabAccountNumber = "1";
            _plantService.Setup(ps => ps.GetPlantDetails(1, string.Empty)).Returns(plant);

            plcService = new Mock<IPlcService>();
            plantUtilityService = new Mock<IPlantUtilityService>();
            controllerSetupService = new Mock<IControllerSetupService>();
            washerService = new Mock<IWasherServices>();

            controllerSetupService.Setup(ut=>ut.GetControllerDetailById(It.IsAny<int>(),It.IsAny<string>())).Returns(control);
            HttpConfiguration config = new HttpConfiguration();
            meterController = new MeterController(userService.Object, meterService.Object, _plantService.Object, plcService.Object, plantUtilityService.Object, controllerSetupService.Object, washerGroupService.Object, washerService.Object)
            {
                Request = new HttpRequestMessage()
            };
            meterController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        /// <summary>
        ///     Fetch the meter details
        /// </summary>
        [TestMethod]
        public void FetchMeteDetails()
        {
            IEnumerable<MeterWebModel> result = meterController.GetMeter();
            Assert.IsNotNull(result, "Meter data");
        }

        /// <summary>
        ///     Insert test for meter
        /// </summary>
        [TestMethod]
        public void CreateTest()
        {
            mockMeterModelList = new List<MeterWebModel>();
            mockMeterModelList.Add(mockMeterModel);
            HttpResponseMessage result = meterController.CreateMeter(mockMeterModelList);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     update test for meter
        /// </summary>
        [TestMethod]
        public void MeterUpdateTest()
        {
            mockMeterModelList = new List<MeterWebModel>();
            mockMeterModelList.Add(meterModel);
            HttpResponseMessage result = meterController.Put(mockMeterModelList);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     delete test for meter
        /// </summary>
        [TestMethod]
        public void DeleteTest()
        {
            mockMeterModelList = new List<MeterWebModel>();
            mockMeterModelList.Add(meterModel);
            HttpResponseMessage result = meterController.DeleteMeter(mockMeterModelList);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        #region "Properties"

        private readonly MeterModel metermodels;

        /// <summary>
        ///     Model  Meter
        /// </summary>
        private readonly MeterWebModel meterModel;

        /// <summary>
        ///     Model Meter
        /// </summary>
        private readonly MeterWebModel mockMeterModel;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext ControllerContext;

        /// <summary>
        ///     interface IMeterService
        /// </summary>
        private Mock<IMeterService> meterService;

        /// <summary>
        ///     Meter class
        /// </summary>
        private List<Meter> mockMeter = new List<Meter>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        ///     Api controller MeterController
        /// </summary>
        private MeterController meterController;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IPlcService> plcService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IPlantUtilityService> plantUtilityService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IControllerSetupService> controllerSetupService;

        /// <summary>
        ///     Model Meter List
        /// </summary>
        private List<MeterWebModel> mockMeterModelList;

        /// <summary>
        /// Interface Washer Group Service
        /// </summary>
        private Mock<IWasherGroupService> washerGroupService;
        private Mock<IWasherServices> washerService;

        Ecolab.Models.ControllerSetup.Controller control;

        #endregion
    }
}