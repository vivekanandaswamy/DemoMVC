﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The ControllerSetupTests object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.ControllerSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ControllerSetup;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Controller = Models.ControllerSetup.Controller;
    using ControllerModel = ConduitLocal.Web.Models.ControllerSetup.ControllerModel;
    using WebModel = ConduitLocal.Web.Models;
    using Model = Models;
    using Ecolab.Services;
    using Ecolab.Models;
    using System.Configuration;


    /// <summary>
    ///     Controller Setup Test class
    /// </summary>
    [TestClass]
    public sealed class ControllerSetupTests : TestBase, IDisposable
    {
        #region "Properties"

        /// <summary>
        /// ControllerModel
        /// </summary>
        private readonly ControllerModel _controller;

        /// <summary>
        /// List of ControllerSetupDataModel
        /// </summary>
        private readonly List<ControllerSetupDataModel> _controllerSetupDataModel;

        /// <summary>
        /// Controller
        /// </summary>
        private readonly Controller _mockController;

        /// <summary>
        /// List of Controllers
        /// </summary>
        private readonly List<Controller> _mockControllerListData;

        /// <summary>
        /// List of MetaData
        /// </summary>
        private readonly List<MetaData> _mockControllerMetaData;

        /// <summary>
        /// List of ControllerType
        /// </summary>
        private readonly List<ControllerType> _mockControllerType;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext ControllerContext;

        /// <summary>
        ///     interface IControllerSetupService
        /// </summary>
        private Mock<IControllerSetupService> _controllerSetupService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> userService;

        /// <summary>
        ///     Api controller
        /// </summary>
        private ControllerSetupController controllerSetupController;

        private Plant mockPlant;

        #endregion

        #region "Setup data"

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        public ControllerSetupTests()
        {
            _mockControllerMetaData = new List<MetaData> { new MetaData { FieldGroupId = 1, FieldGroupType = "TABLE", FieldGroupInfo = new List<ControllerSetupMetaData> { new ControllerSetupMetaData { ControllerModelId = 1, DataSourceId = 2, ControllerTypeId = 1 } } } };

            _mockControllerListData = new List<Controller>
            { new Controller
                {
                    ControllerId = 3,
                    ControllerModelId = 12,
                    ControllerModelName = "ABC",
                    ControllerName = "ControllerName",
                    ControllerNumber = 1,
                    ControllerType = "ControllerType",
                    ControllerTypeId = 1,
                    ControllerVersion = "ControllerVersion",
                    EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                    InstallDate = DateTime.Now,
                    InstallDateAsString = DateTime.Now.ToString(),
                    IsDelete = false,
                    LastModifiedTimeStamp =  DateTime.Now,
                    LastModifiedTimestampAtCentral =  DateTime.Now,
                    LastSyncTime =  DateTime.Now,
                    MaxNumberOfRecords = 12
                }
            };

            _mockControllerType = new List<ControllerType> { new ControllerType { Name = "ABC" } };
            _mockController = new Controller { ControllerName = "ABC", ControllerModelName = "DEF", ControllerId = 2279, ControllerModelId = 11, IsDelete = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };

            _controller = new ControllerModel { ControllerName = "ABC", ControllerModelName = "DEF" };

            _controllerSetupDataModel = new List<ControllerSetupDataModel> { new ControllerSetupDataModel { ControllerId = 1, ControllerModelId = 1, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 1, Value = "Test" } };

            mockPlant = new Plant()
            {
                EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Name = "test2",
                TmName = "Test TM Name",
                TmPhoneNumner = "0",
                DmName = "Test TM Name",
                DmPhoneNumner = "0",
                Chain = "test chain",
                ChainUnitNumber = "123456",
                ChainRegions = "123",
                CensusPriceKg = 20,
                Remarks = "Remarks",
                LanguageId = 1,
                CurrencyCode = "1",
                Rate = 60,
                ExportPath = null,
                DataLiveTime = 2,
                BudgetCustomer = true,
                UomId = 2,
                Logo = null
            };
        }

        #endregion

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            controllerSetupController.Dispose();
        }

        #region "Test Initialization"

        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1 };
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "1";
            HttpContext.Current.User = custPrinciple;

            DateTime lastModifiedTimeStamp;

            userService = new Mock<IUserService>();
            _controllerSetupService = new Mock<IControllerSetupService>();

            _controllerSetupService.Setup(Pc => Pc.GetControllerSetupMetadata(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>())).Returns(_mockControllerMetaData);
            _controllerSetupService.Setup(Pc => Pc.GetControllerSetupMetadataWithValues(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>())).Returns(_mockControllerMetaData);
            _controllerSetupService.Setup(Pc => Pc.GetControllerDetails(mockPlant.EcoalabAccountNumber, It.IsAny<bool?>(), It.IsAny<bool?>())).Returns(_mockControllerListData);
            _controllerSetupService.Setup(Pc => Pc.UpdateControllerListData(_mockController, It.IsAny<int>(), It.IsAny<string>(), out lastModifiedTimeStamp, It.IsAny<DateTime>()));
            _controllerSetupService.Setup(Pc => Pc.DeleteControllerListData(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>(), out lastModifiedTimeStamp, null));
            _controllerSetupService.Setup(Pc => Pc.GetControllerTypesDetails(It.IsAny<int>())).Returns(_mockControllerType);
            _controllerSetupService.Setup(Pc => Pc.GetControllerDetailById(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockController);

            HttpConfiguration config = new HttpConfiguration();
            controllerSetupController = new ControllerSetupController(userService.Object, _plantService.Object, _controllerSetupService.Object) { Request = new HttpRequestMessage() };
            controllerSetupController.Request = new HttpRequestMessage();
            controllerSetupController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        #region "Test Methods"

        [TestMethod]
        public void GetControllerSetupMetaDataTest()
        {
            int tabId = 1;
            int controllerModelId = 1;
            int controllerTypeId = 1;
            List<MetaDataModel> result = controllerSetupController.GetControllerSetupMetaData(tabId, controllerModelId, controllerTypeId);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetControllerSetupMetaDataWithValuesTest()
        {
            List<MetaDataModel> result = controllerSetupController.GetControllerSetupMetaDataWithValues(24, 1);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetControllerDetailsTest()
        {
            IEnumerable<ControllerModel> result = controllerSetupController.GetControllerDetails();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetControllerTypesDetailsTest()
        {
            int controllerModelId = 1;
            IEnumerable<ControllerTypeModel> result = controllerSetupController.GetControllerTypesDetails(controllerModelId);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void SaveControllerDetailsTest()
        {
            HttpResponseMessage result = controllerSetupController.UpdateControllerDetails(_controller);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void SaveControllerSetupDataTest()
        {
            HttpResponseMessage result = controllerSetupController.SaveControllerSetupData(_controllerSetupDataModel);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        [TestMethod]
        public void UpdateControllerSetupDataTest()
        {
            HttpResponseMessage result = controllerSetupController.UpdateControllerSetupData(_controllerSetupDataModel);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        [TestMethod]
        public void DeleteControllerTest()
        {
            HttpResponseMessage result = controllerSetupController.DeleteController(1);
            Assert.IsNotNull(result);
        }

        #endregion
    }
}