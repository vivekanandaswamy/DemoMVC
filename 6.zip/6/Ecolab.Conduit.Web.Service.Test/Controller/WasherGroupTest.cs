﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class WasherGroupTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
