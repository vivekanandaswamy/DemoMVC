﻿namespace Ecolab.Conduit.Web.Service.Test.Controller.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api.ManualInput;
    using ConduitLocal.Web.Models.ManualInput;
    using ConduitLocal.Web.Models.ManualInput.Production;
    using ConduitLocal.Web.Models.PlantSetup;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Models.ManualInput.Production;
    using Models.PlantSetup;
    using Moq;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.ManualInput;
    using Model = Models;

    [TestClass]
    public sealed class ManualProductionDataEntryTests : TestBase, IDisposable
    {
        /// <summary>
        ///     GroupType
        /// </summary>
        private readonly List<GroupType> _mockGroupTypes = new List<GroupType>();

        /// <summary>
        ///     GroupType WebModel
        /// </summary>
        private readonly List<GroupTypeModel> _mockGroupTypeWebModels = new List<GroupTypeModel>();

        /// <summary>
        ///     MachineSetup
        /// </summary>
        private readonly List<MachineSetup> _mockMachineSetup = new List<MachineSetup>();

        /// <summary>
        ///     MachineSetupModel
        /// </summary>
        private readonly List<MachineSetupModel> _mockMachineSetupModel = new List<MachineSetupModel>();

        /// <summary>
        ///     ManualProductionModel
        /// </summary>
        private readonly ManualProductionModel _mockManualProdModel;

        /// <summary>
        ///     ManualProduction
        /// </summary>
        private readonly ManualProduction _mockManualProduction = new ManualProduction();

        /// <summary>
        ///     ManualProductionModel List
        /// </summary>
        private readonly List<ManualProductionModel> _mockManualProdWebModel = new List<ManualProductionModel>();

        /// <summary>
        ///     WashProgramSetup
        /// </summary>
        private readonly List<WashProgramSetup> _mockWashProgramSetups = new List<WashProgramSetup>();

        /// <summary>
        ///     WashProgramSetup List
        /// </summary>
        private readonly List<WashProgramSetupModel> _mockWashProgramSetupsWebModel = new List<WashProgramSetupModel>();

        /// <summary>
        ///     ManualUtilityViewModel
        /// </summary>
        private readonly ManualProductionViewModel manualProdViewModel;

        /// <summary>
        ///     interface IControllerSetupService
        /// </summary>
        private Mock<IManualProductionDataEntryService> _manualProdService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext controllerContext;

        /// <summary>
        ///     Api controller
        /// </summary>
        private ManualProductionDataEntryController manualProdController;

        public ManualProductionDataEntryTests()
        {
            _mockManualProduction = new ManualProduction { Id = 1, RecordedDate = DateTime.Now, Value = 200 };

            _mockWashProgramSetups.Add(new WashProgramSetup { ProgramNumber = 1, Description = "Food" });

            _mockGroupTypes.Add(new GroupType { GroupTypeId = 2, GroupDescription = "WasherType" });

            _mockMachineSetup.Add(new MachineSetup { MachineId = 1, MachineName = "Washer" });

            _mockManualProdModel = new ManualProductionModel { Id = 1, WasherGroupId = 1, WasherId = 1, FormulaId = 1, RecordedDate = "01/02/2015", Value = 1 };

            _mockManualProdWebModel.Add(new ManualProductionModel { Id = 2, WasherGroupId = 2, WasherId = 2, FormulaId = 2, RecordedDate = "01/02/2015", Value = 2 });

            _mockManualProdWebModel.Add(new ManualProductionModel { Id = 1, WasherGroupId = 1, WasherId = 1, FormulaId = 1, RecordedDate = "01/02/2015", Value = 1 });

            manualProdViewModel = new ManualProductionViewModel { WasherGroups = _mockGroupTypeWebModels, Washers = _mockMachineSetupModel, Formulas = _mockWashProgramSetupsWebModel, ProductionData = _mockManualProdWebModel, Result = "TEST" };
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            manualProdController.Dispose();
        }

        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1 };
            HttpContext.Current.User = custPrinciple;

            _userService = new Mock<IUserService>();           
            _manualProdService = new Mock<IManualProductionDataEntryService>();

            //_manualProdService.Setup(mp => mp.FetchManualProductionData(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(_mockManualProduction);
            _manualProdService.Setup(mp => mp.FetchFormulasByGroupId(It.IsAny<string>(), It.IsAny<string>())).Returns(_mockWashProgramSetups);
            _manualProdService.Setup(mp => mp.FetchWasherGroups(It.IsAny<string>())).Returns(_mockGroupTypes);
            _manualProdService.Setup(mp => mp.FetchWashersByGroupId(It.IsAny<string>(), It.IsAny<string>())).Returns(_mockMachineSetup);
            int productionId = 0;
            _manualProdService.Setup(mp => mp.SaveManualProduction(It.IsAny<ManualProduction>(), It.IsAny<string>(), It.IsAny<int>(), out productionId)).Returns("result");
            _manualProdService.Setup(mp => mp.UpdateManualProduction(It.IsAny<ManualProduction>(), It.IsAny<string>(), It.IsAny<int>()));
            _manualProdService.Setup(mp => mp.DeleteManualProduction(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>()));
            _manualProdService.Setup(mp => mp.FetchUnits("1")).Returns("Kgs");
           
            HttpConfiguration config = new HttpConfiguration();
            manualProdController = new ManualProductionDataEntryController(_userService.Object, _plantService.Object, _manualProdService.Object) { Request = new HttpRequestMessage() };
            manualProdController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        [TestMethod]
        public void FetchMIWasherGroups_Test()
        {
            ManualProductionViewModel result = manualProdController.FetchMiWasherGroups();
            if (result.WasherGroups != null)
            {
                Assert.IsTrue(true, "Data is avaialable");
            }
            else
            {
                Assert.IsFalse(true, "Data is not avaialable");
            }
        }

        [TestMethod]
        public void FetchWasherGroups_Test()
        {
            List<GroupTypeModel> result = manualProdController.FetchWasherGroups();
            if (result.Count > 0)
            {
                Assert.IsTrue(true, "Data is avaialable");
            }
            else
            {
                Assert.IsFalse(true, "Data is not avaialable");
            }
        }

        [TestMethod]
        public void FetchMIWasherDetails_Test()
        {
            string groupId = "1";
            List<MachineSetupModel> result = manualProdController.FetchMiWasherDetails(groupId);
            if (result.Count > 0)
            {
                Assert.IsTrue(true, "Data is avaialable");
            }
            else
            {
                Assert.IsFalse(true, "Data is not avaialable");
            }
        }

        [TestMethod]
        public void FetchMIFormulaDetails_Test()
        {
            string groupId = "1";
            List<WashProgramSetupModel> result = manualProdController.FetchMiFormulaDetails(groupId);
            if (result.Count > 0)
            {
                Assert.IsTrue(true, "Data is avaialable");
            }
            else
            {
                Assert.IsFalse(true, "Data is not avaialable");
            }
        }

        [TestMethod]
        public void FetchWasherFormulaByWasherGroup_Test()
        {
            string groupId = "1";
            ManualProductionViewModel result = manualProdController.FetchWasherFormulaByWasherGroup(groupId);
            if (result.Formulas != null)
            {
                Assert.IsTrue(true, "Data is avaialable");
            }
            else
            {
                Assert.IsFalse(true, "Data is not avaialable");
            }
        }
    }
}