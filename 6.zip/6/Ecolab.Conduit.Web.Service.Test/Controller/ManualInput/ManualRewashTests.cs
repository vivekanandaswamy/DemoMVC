﻿using MIWebModel = Ecolab.ConduitLocal.Web.Models.ManualInput;

namespace Ecolab.Conduit.Web.Service.Test.Controller.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api.ManualInput;
    using ConduitLocal.Web.Models.ManualInput.Rewash;
    using ConduitLocal.Web.Models.PlantSetup;
    using Infra;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Moq;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.ManualInput;
    using ManualRewash = Models.ManualInput.Rewash.ManualRewash;
    using RewashReason = Models.ManualInput.Rewash.RewashReason;

    [TestClass]
    public sealed class ManualRewashTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Service Model  for Manual Rewash
        /// </summary>
        private readonly List<ManualRewash> _manualRewashModel;

        /// <summary>
        ///     ManualRewashViewModel
        /// </summary>
        private readonly ManualRewashViewModel _manualRewashViewModel;

        /// <summary>
        ///     Web Model  for Manual Rewash
        /// </summary>
        private readonly ConduitLocal.Web.Models.ManualInput.Rewash.ManualRewash _manulRewashWebModel;

        /// <summary>
        ///     GroupType Model
        /// </summary>
        private readonly List<GroupType> _mockGroupTypes = new List<GroupType>();

        /// <summary>
        ///     GroupType WebModel
        /// </summary>
        private readonly List<GroupTypeModel> _mockGroupTypeWebModels = new List<GroupTypeModel>();

        /// <summary>
        ///     Manul Rewash List
        /// </summary>
        private readonly List<ManualRewash> _mockManualRewash = new List<ManualRewash>();

        /// <summary>
        ///     Manul Rewash List
        /// </summary>
        private readonly List<ConduitLocal.Web.Models.ManualInput.Rewash.ManualRewash> _mockManualRewashWebModel = new List<ConduitLocal.Web.Models.ManualInput.Rewash.ManualRewash>();

        /// <summary>
        ///     RewashReason List
        /// </summary>
        private readonly List<RewashReason> _mockRewashReasons = new List<RewashReason>();

        /// <summary>
        ///     RewashReason List
        /// </summary>
        private readonly List<ConduitLocal.Web.Models.ManualInput.Rewash.RewashReason> _mockRewashReasonWebModel = new List<ConduitLocal.Web.Models.ManualInput.Rewash.RewashReason>();

        /// <summary>
        ///     WashProgramSetup List
        /// </summary>
        private readonly List<WashProgramSetup> _mockWashProgramSetups = new List<WashProgramSetup>();

        /// <summary>
        ///     WashProgramSetup List
        /// </summary>
        private readonly List<MIWebModel.WashProgramSetupModel> _mockWashProgramSetupsWebModel = new List<MIWebModel.WashProgramSetupModel>();

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface for Manual ProductionDataEntryService
        /// </summary>
        private Mock<IManualProductionDataEntryService> _manualProdService;

        /// <summary>
        ///     Api controller
        /// </summary>
        private ManualRewashController _manualRewashController;

        /// <summary>
        ///     interface IManual Rewash Service
        /// </summary>
        private Mock<IManualRewashService> _manualRewashService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        public ManualRewashTests()
        {
            TestSetup.Init(TestContext);
            _mockWashProgramSetups.Add(new WashProgramSetup { ProgramNumber = 1, Description = "Test" });
            _mockWashProgramSetupsWebModel.Add(new MIWebModel.WashProgramSetupModel { ProgramNumber = 1, Description = "Test" });

            _mockGroupTypeWebModels.Add(new GroupTypeModel { GroupDescription = "test", GroupMainType = 1, GroupTypeId = 1, IsTunnel = true });

            _manulRewashWebModel = new ConduitLocal.Web.Models.ManualInput.Rewash.ManualRewash { WasherGroupId = 1, FormulaId = 1, RewashReasonId = 1, RecordedDate = "10/08/2014", Value = 10.23, DesiredUnits = "lbs", Result = "result" };

            _mockManualRewashWebModel.Add(new ConduitLocal.Web.Models.ManualInput.Rewash.ManualRewash { WasherGroupId = 2, FormulaId = 2, RewashReasonId = 2, RecordedDate = "10/08/2014", Value = 10.23, DesiredUnits = "lbs", Result = "result" });

            _mockManualRewashWebModel.Add(new ConduitLocal.Web.Models.ManualInput.Rewash.ManualRewash { WasherGroupId = 1, FormulaId = 1, RewashReasonId = 1, RecordedDate = "10/08/2014", Value = 10.23, DesiredUnits = "lbs", Result = "result" });

            _mockManualRewash.Add(new ManualRewash { WasherGroupId = 1, FormulaId = 1, RewashReasonId = 1, RecordedDate = DateTime.Now, Value = 1 });

            _manualRewashModel = new List<Models.ManualInput.Rewash.ManualRewash>() { new ManualRewash { WasherGroupId = 1, FormulaId = 1, RewashReasonId = 1, RecordedDate = DateTime.Now, Value = 10.23 } };

            _mockGroupTypes.Add(new GroupType { GroupTypeId = 2, GroupDescription = "WasherType" });
            _mockRewashReasonWebModel.Add(new ConduitLocal.Web.Models.ManualInput.Rewash.RewashReason { Description = "test", RewashReasonId = 1 });

            _mockManualRewashWebModel.Add(_manulRewashWebModel);
            _manualRewashViewModel = new ManualRewashViewModel { WasherGroups = _mockGroupTypeWebModels, Formulas = _mockWashProgramSetupsWebModel, RewashReason = _mockRewashReasonWebModel, Rewash = _mockManualRewashWebModel, Result = "test" };
        }

        public TestContext TestContext { get; set; }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            _manualRewashController.Dispose();
        }

        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            HttpContext.Current.User = custPrinciple;

            _manualRewashService = new Mock<IManualRewashService>();
            _manualProdService = new Mock<IManualProductionDataEntryService>();
            _userService = new Mock<IUserService>();

            _manualRewashService.Setup(MR => MR.FetchFormulasByGroupId(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>())).Returns(_mockWashProgramSetups);
            _manualRewashService.Setup(MR => MR.FetchManualRewash(It.IsAny<int>(), It.IsAny<string>())).Returns(_manualRewashModel);
            _manualRewashService.Setup(MR => MR.FetchRewashReason()).Returns(_mockRewashReasons);
            _manualProdService.Setup(MP => MP.FetchWasherGroups(It.IsAny<string>())).Returns(_mockGroupTypes);
            int manualrewashId = 0;
            _manualRewashService.Setup(MR => MR.SaveManualRewash(_manualRewashModel[0], It.IsAny<string>(), It.IsAny<int>(), out manualrewashId)).Returns(It.IsAny<string>());
            _manualRewashService.Setup(MR => MR.UpdateManualRewash(_manualRewashModel[0], It.IsAny<string>(), It.IsAny<int>())).Returns(It.IsAny<string>());
            _manualRewashService.Setup(MR => MR.DeleteManualRewash(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>())).Returns("result");
            _plantService.Setup(PS => PS.GetPlantDetails("1")).Returns(plant);

            HttpConfiguration config = new HttpConfiguration();
            _manualRewashController = new ManualRewashController(_userService.Object, _plantService.Object, _manualRewashService.Object, _manualProdService.Object);
            _manualRewashController.Request = new HttpRequestMessage();
            _manualRewashController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        /// <summary>
        ///     FetchFormulasByGroupId
        /// </summary>
        //[TestMethod]
        //public void FetchFormulasByGroupId_Test()
        //{
        //    int groupId = 1;
        //    List<MIWebModel.WashProgramSetupModel> result = _manualRewashController.FetchMiFormulaDetails(groupId);
        //    Assert.IsNotNull(result);
        //}

        /// <summary>
        ///     FetchManualRewash
        /// </summary>
        [TestMethod]
        public void FetchManualRewash_Test()
        {
            ManualRewashViewModel result = _manualRewashController.FetchManualRewash(_manulRewashWebModel);
            Assert.IsNotNull(result);
        }

        /// <summary>
        ///     FetchRewashReason
        /// </summary>
        [TestMethod]
        public void FetchRewashReason_Test()
        {
            ManualRewashViewModel result = _manualRewashController.Fetch();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void DeleteManualRewash_Test()
        {
            ManualRewashViewModel result = _manualRewashController.DeleteManualRewash(_manualRewashViewModel);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void SaveManualProduction_Test()
        {
            ManualRewashViewModel result = _manualRewashController.SaveManualProduction(_manualRewashViewModel);
            Assert.IsNotNull(result);
        }
    }
}