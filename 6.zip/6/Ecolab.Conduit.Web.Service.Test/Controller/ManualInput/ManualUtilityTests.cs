﻿namespace Ecolab.Conduit.Web.Service.Test.Controller.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api.ManualInput;
    using ConduitLocal.Web.Models.ManualInput;
    using ConduitLocal.Web.Models.ManualInput.Utility;
    using ConduitLocal.Web.Models.PlantSetup;
    using Infra;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Models.PlantSetup;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.ManualInput;

    [TestClass]
    public sealed class ManualUtilityTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Service Model  for Manual Rewash
        /// </summary>
        private readonly ManualUtility _manualUtilityModel;

        /// <summary>
        ///     ManualUtilityViewModel
        /// </summary>
        private readonly ManualUtilityViewModel _manualUtilityViewModel;

        /// <summary>
        ///     Web Model  for Manual Utility
        /// </summary>
        private readonly ManualUtilityModel _manulUtilityWebModel;

        /// <summary>
        ///     GroupType Model
        /// </summary>
        private readonly List<GroupType> _mockGroupTypes = new List<GroupType>();

        /// <summary>
        ///     GroupType WebModel
        /// </summary>
        private readonly List<GroupTypeModel> _mockGroupTypeWebModels = new List<GroupTypeModel>();

        /// <summary>
        ///     MachineSetup List
        /// </summary>
        private readonly List<MachineSetup> _mockMachineSetup = new List<MachineSetup>();

        /// <summary>
        ///     MachineSetupModel List
        /// </summary>
        private readonly List<MachineSetupModel> _mockMachineSetupWebModel = new List<MachineSetupModel>();

        /// <summary>
        ///     ManulUtilityData List
        /// </summary>
        private readonly List<ManualUtility> _mockManualUtility = new List<ManualUtility>();

        /// <summary>
        ///     Manul Utility List
        /// </summary>
        private readonly List<ManualUtilityModel> _mockManulUtilityWebModel = new List<ManualUtilityModel>();

        /// <summary>
        ///     WashProgramSetup List
        /// </summary>
        private readonly List<WashProgramSetup> _mockWashProgramSetups = new List<WashProgramSetup>();

        /// <summary>
        ///     WashProgramSetup List
        /// </summary>
        private readonly List<WashProgramSetupModel> _mockWashProgramSetupsWebModel = new List<WashProgramSetupModel>();

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface for Manual ProductionDataEntryService
        /// </summary>
        private Mock<IManualProductionDataEntryService> _manualProdService;

        /// <summary>
        ///     Api controller
        /// </summary>
        private ManualUtilityController _manualUtilityController;

        /// <summary>
        ///     interface IManualUtilityData Service
        /// </summary>
        private Mock<IManualUtilityService> _manualUtilityService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        public ManualUtilityTests()
        {
            TestSetup.Init(TestContext);
            _mockWashProgramSetups.Add(new WashProgramSetup { ProgramNumber = 1, Description = "Test" });
            _mockWashProgramSetupsWebModel.Add(new WashProgramSetupModel { ProgramNumber = 1, Description = "Test" });

            _mockGroupTypeWebModels.Add(new GroupTypeModel { GroupDescription = "test", GroupMainType = 1, GroupTypeId = 1, IsTunnel = true });

            _manulUtilityWebModel = new ManualUtilityModel { RecordedDate = "11/24/2014", Value = 1, Usage = 2 };

            _manualUtilityModel = new ManualUtility { MeterId = 1, Description = "1", MeterTickUnit = "2", UtilityTypeId = "3", GroupId = 2, UtilityTypeName = "4", LocationName = "5", RecordedDate = DateTime.Now, Value = 3, Usage = 4, MaxValueLimit = 5 };
            _mockGroupTypes.Add(new GroupType { GroupTypeId = 2, GroupDescription = "WasherType" });

            _mockManulUtilityWebModel.Add(_manulUtilityWebModel);
            _manualUtilityViewModel = new ManualUtilityViewModel { MeterId = 1, Description = "1", MeterTickUnit = "2", UtilityTypeId = "3", GroupId = 4, UtilityTypeName = "4", LocationName = "5", Utility = _mockManulUtilityWebModel, Result = "Test", MaxValueLimit = 5 };

            _mockManulUtilityWebModel.Add(new ManualUtilityModel { RecordedDate = "11/24/2014", Value = 0, Usage = 0 });

            _mockManulUtilityWebModel.Add(new ManualUtilityModel { RecordedDate = "11/24/2014", Value = 1, Usage = 1 });
        }

        public TestContext TestContext { get; set; }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            _manualUtilityController.Dispose();
        }

        [TestInitialize]
        public void MockSetup()
        {
            _manualUtilityService = new Mock<IManualUtilityService>();
            _manualProdService = new Mock<IManualProductionDataEntryService>();
            _userService = new Mock<IUserService>();

            _manualUtilityService.Setup(mu => mu.FetchManualUtility(It.IsAny<string>())).Returns(_mockManualUtility);
            int laborId = 0;
            _manualUtilityService.Setup(mu => mu.SaveManualUtility(It.IsAny<ManualUtility>(), It.IsAny<string>(), It.IsAny<int>(), out laborId)).Returns("result");
            _manualUtilityService.Setup(mu => mu.UpdateManualUtility(It.IsAny<ManualUtility>(), It.IsAny<string>(), It.IsAny<int>())).Returns("result");
            _manualUtilityService.Setup(mu => mu.DeleteManualUtility(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<int>())).Returns("true");
            _manualProdService.Setup(mp => mp.FetchWasherGroups(It.IsAny<string>())).Returns(_mockGroupTypes);

            HttpConfiguration config = new HttpConfiguration();
            _manualUtilityController = new ManualUtilityController(_userService.Object, _plantService.Object, _manualUtilityService.Object) { Request = new HttpRequestMessage() };
            _manualUtilityController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        /// <summary>
        ///     FetchManualUtility
        /// </summary>
        [TestMethod]
        public void FetchManualUtility_Test()
        {
            const int meterId = 1;
            ManualUtilityViewModel result = _manualUtilityController.FetchManualUtility(meterId);
            Assert.IsNotNull(result, "Data Is Available");
        }

        /// <summary>
        ///     SaveManualUtility
        /// </summary>
        [TestMethod]
        public void SaveManualUtility_Test()
        {
            //    int Id = 1;
            List<ManualUtilityViewModel> result = _manualUtilityController.SaveManualUtility(_manualUtilityViewModel);
            if (result != null)
            {
                Assert.IsTrue(true, "Data is avaialable");
            }
            else
            {
                Assert.IsFalse(true, "Data is not avaialable");
            }
        }

        /// <summary>
        ///     DeleteManualUtility
        /// </summary>
        [TestMethod]
        public void DeleteManualUtility_Test()
        {
            ManualUtilityViewModel result = new ManualUtilityViewModel();//_manualUtilityController.DeleteManualUtility(_manualUtilityViewModel);
            Assert.IsNotNull(result);
        }
    }
}