﻿namespace Ecolab.Conduit.Web.Service.Test.Controller.ManualInput
{
	using System;
	using System.Collections.Generic;
	using System.Net.Http;
	using System.Web;
	using System.Web.Http;
	using System.Web.Http.Hosting;
	using System.Web.Mvc;
	using ConduitLocal.Web.Api.ManualInput;
	using ConduitLocal.Web.Models.ManualInput;
	using ConduitLocal.Web.Models.ManualInput.Batch;
	using ConduitLocal.Web.Models.PlantSetup;
	using Infra;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Models.ManualInput;
	using Models.PlantSetup;
	using Moq;
	using Services;
	using Services.Interfaces;
	using Services.Interfaces.ManualInput;

	[TestClass]
	public sealed class ManualBatchDataTests : TestBase, IDisposable
	{
		/// <summary>
		///     Service Model  for Manual Rewash
		/// </summary>
		private readonly ManualBatchData _manualBatchDataModel;

		/// <summary>
		///     Service Model  for Manual Rewash
		/// </summary>
		
		/// <summary>
		///     Web Model  for Manual Batch
		/// </summary>
		private readonly ManualBatch _manulBatchWebModel;

		/// <summary>
		///     GroupType Model
		/// </summary>
		private readonly List<GroupType> _mockGroupTypes = new List<GroupType>();

		/// <summary>
		///     GroupType WebModel
		/// </summary>
		private readonly List<GroupTypeModel> _mockGroupTypeWebModels = new List<GroupTypeModel>();

		/// <summary>
		///     MachineSetup List
		/// </summary>
		private readonly List<MachineSetup> _mockMachineSetup = new List<MachineSetup>();

		/// <summary>
		///     MachineSetupModel List
		/// </summary>
		private readonly List<MachineSetupModel> _mockMachineSetupWebModel = new List<MachineSetupModel>();

		/// <summary>
		///     ManulBatchData List
		/// </summary>
		private readonly List<ManualBatchData> _mockManualBatchData = new List<ManualBatchData>();

		/// <summary>
		///     ManualBatchDataModel List
		/// </summary>
		private readonly List<ManualBatchDataModel> _mockManualBatchDataWebModel = new List<ManualBatchDataModel>();

		/// <summary>
		///     Manul Batch List
		/// </summary>
		private readonly List<ManualBatch> _mockManulBatchWebModel = new List<ManualBatch>();

		/// <summary>
		///     WashProgramSetup List
		/// </summary>
		private readonly List<WashProgramSetup> _mockWashProgramSetups = new List<WashProgramSetup>();

		/// <summary>
		///     WashProgramSetup List
		/// </summary>
		private readonly List<WashProgramSetupModel> _mockWashProgramSetupsWebModel = new List<WashProgramSetupModel>();

		/// <summary>
		///     ControllerContext
		/// </summary>
		public ControllerContext _controllerContext;

		/// <summary>
		///     Api controller
		/// </summary>
		private ManualBatchController _manualBatchController;

		/// <summary>
		///     interface IManualBatchData Service
		/// </summary>
		private Mock<IManualBatchDataService> _manualBatchDataService;

		/// <summary>
		///     ManualBatchViewModel
		/// </summary>
		private ManualBatchViewModel _manualBatchViewModel;

		/// <summary>
		///     interface for Manual ProductionDataEntryService
		/// </summary>
		private Mock<IManualProductionDataEntryService> _manualProdService;

		/// <summary>
		///     interface IUserService
		/// </summary>
		private Mock<IUserService> _userService;

		public ManualBatchDataTests()
		{
			TestSetup.Init(TestContext);
			_mockWashProgramSetups.Add(new WashProgramSetup { ProgramNumber = 1, Description = "Test" });
			_mockWashProgramSetupsWebModel.Add(new WashProgramSetupModel { ProgramNumber = 1, Description = "Test" });

			_mockGroupTypeWebModels.Add(new GroupTypeModel { GroupDescription = "test", GroupMainType = 1, GroupTypeId = 1, IsTunnel = true });

			_manulBatchWebModel = new ManualBatch { WasherGroupId = 1, WasherId = 1, FormulaId = 1, StartDate = DateTime.Now, StartTime = TimeSpan.Zero, RecordingValue = 1, DesiredUnits = "lbs", Result = "true" };

			_manualBatchDataModel = new ManualBatchData { StartDate = DateTime.Now, StartTime = TimeSpan.Zero, RecordingValue = 1 };

			_mockGroupTypes.Add(new GroupType { GroupTypeId = 2, GroupDescription = "WasherType" });
			_mockManualBatchDataWebModel.Add(new ManualBatchDataModel { StartDate = new DateTime(), StartTime = "11:00", RecordingValue = 1, DesiredUnits = "1" });

			_mockManulBatchWebModel.Add(_manulBatchWebModel);
			_manualBatchViewModel = new ManualBatchViewModel { WasherGroups = _mockGroupTypeWebModels, Formulas = _mockWashProgramSetupsWebModel, Washers = _mockMachineSetupWebModel, Batch = _manulBatchWebModel, Result = "test" };
		}

		public TestContext TestContext { get; set; }

		/// <summary>
		///     Dispose
		/// </summary>
		public void Dispose()
		{
			_manualBatchController.Dispose();
		}

		[TestInitialize]
		public void MockSetup()
		{
			CustomPrincipal custPrinciple = new CustomPrincipal("1");
			custPrinciple.UserId = 1;
			HttpContext.Current.User = custPrinciple;

			_manualBatchDataService = new Mock<IManualBatchDataService>();
			_manualProdService = new Mock<IManualProductionDataEntryService>();
			_userService = new Mock<IUserService>();

			_manualBatchDataService.Setup(mb => mb.FetchBatchWasherGroupBySelectedDate(It.IsAny<DateTime>(), It.IsAny<string>())).Returns(_mockGroupTypes);
			_manualBatchDataService.Setup(mb => mb.FetchBatchWashersByGroupId(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockMachineSetup);
			_manualBatchDataService.Setup(mb => mb.FetchBatchFormulasByGroupId(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockWashProgramSetups);
			_manualBatchDataService.Setup(mb => mb.FetchBatchByGroupId(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<DateTime>(), It.IsAny<string>())).Returns(_mockManualBatchData);
			_manualBatchDataService.Setup(mb => mb.FetchBatchDetailsByBatchId(It.IsAny<int>(), It.IsAny<string>())).Returns(_manualBatchDataModel);
			_manualProdService.Setup(mp => mp.FetchWasherGroups(It.IsAny<string>())).Returns(_mockGroupTypes);
            List<ManualBatchData> _manualBatchDataModelList = new List<ManualBatchData>();
            _manualBatchDataService.Setup(mb => mb.UpdateManualBatch(_manualBatchDataModelList, It.IsAny<string>(), It.IsAny<int>())).Returns("result");
			_plantService.Setup(ps => ps.GetPlantDetails("1")).Returns(plant);

			HttpConfiguration config = new HttpConfiguration();
			_manualBatchController = new ManualBatchController(_userService.Object, _plantService.Object, _manualBatchDataService.Object, _manualProdService.Object) { Request = new HttpRequestMessage() };
			_manualBatchController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
		}

		/// <summary>
		///     FetchBatchByGroupId
		/// </summary>
		[TestMethod]
		public void FetchBatchByGroupId_Test()
		{
			List<ManualBatchData> result = _manualBatchController.FetchBatchByGroupId(_manulBatchWebModel);
			Assert.IsNotNull(result);
		}

		/// <summary>
		///     FetchBatchDetailsByBatchId
		/// </summary>
		[TestMethod]
		public void FetchBatchDetailsByBatchId_Test()
		{
			ManualBatchDataModel result = _manualBatchController.FetchBatchDetailsByBatchId(_manulBatchWebModel);
			Assert.IsNotNull(result);
		}

		/// <summary>
		///     UpdateBatchData
		/// </summary>
		[TestMethod]
		public void UpdateManualBatch_Test()
		{
			string result = _manualBatchController.UpdateManualBatch(_manulBatchWebModel);
			if (result != null)
			{
				Assert.IsNotNull(result, "Updated Successfully");
			}
			else
			{
				Assert.IsNull(result, "Update Failed");
			}
		}
	}
}