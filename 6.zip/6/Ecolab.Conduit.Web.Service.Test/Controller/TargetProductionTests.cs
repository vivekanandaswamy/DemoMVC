﻿// -----------------------------------------------------------------------
// <copyright file="TargetProductionTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>TargetProductionTests class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.ShiftLabor;
    using Moq;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using WebModel = ConduitLocal.Web.Models.PlantSetup.TargetProduction;
    using System.Configuration;
    using System.Linq;
    using System.Security.Principal;

    /// <summary>
    ///     TargetProduction class
    /// </summary>
    [TestClass]
    public class TargetProductionTests : TestBase
    {
        /// <summary>
        ///     TargetProductionModel class
        /// </summary>
        private IEnumerable<WebModel.TargetProduction> _mockTargetProductions = null;

        /// <summary>
        ///     TargetProductionModel class
        /// </summary>
        private readonly List<TargetProduction> mockTargetProduction = new List<TargetProduction>();


        List<Shift> runningShifts = new List<Shift>();
        /// <summary>
        ///     interface IMeterService
        /// </summary>
        private Mock<IShiftBreakService> _shiftBreakService;

        /// <summary>
        ///     Api controller MeterController
        /// </summary>
        private TargetProductionController _targetProductionController;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext ControllerContext;

        public TargetProductionTests()
        {
            mockTargetProduction.Add(new TargetProduction
            {
                DayId = 2,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                ShiftId = 18,
                TargetProd = 55,
                ShiftName = "TestShift",
                DayName = "Monday"
            });

            runningShifts.Add(new Shift
            {
                ShiftId = 18,
                ShiftName = "TestShift",
                DayId = 2,
                DayName = "Monday",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                TargetProduction = 55
            });
        }

        [TestInitialize]
        public void MockSetup()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserName = "test";
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "Admin";
            HttpContext.Current.User = custPrinciple;

            DateTime lastModifiedTime = DateTime.UtcNow;
            HttpConfiguration config = new HttpConfiguration();
            _userService = new Mock<IUserService>();
            _plantService = new Mock<IPlantService>();
            _shiftBreakService = new Mock<IShiftBreakService>();

            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);
            _shiftBreakService.Setup(sb => sb.FetchTargetProductionDetails(ecolabAccountNumber)).Returns(mockTargetProduction);
            _shiftBreakService.Setup(lc => lc.SaveTargetProduction(It.IsAny<List<TargetProduction>>(), ecolabAccountNumber, It.IsAny<int>(), out lastModifiedTime)).Returns("Result");
            _shiftBreakService.Setup(sb => sb.FetchRunningShiftDetails()).Returns(runningShifts);

            _targetProductionController = new TargetProductionController(_userService.Object, _plantService.Object, _shiftBreakService.Object) { Request = new HttpRequestMessage() };
            _targetProductionController.Request = new HttpRequestMessage();
            _targetProductionController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        [TestMethod]
        public void FetchTargetProductionDetails_Test()
        {
            WebModel.TargetProdDetails result = _targetProductionController.FetchTargetProductionDetails();
            if (result != null)
            {
                Assert.IsNotNull(result, "Target Production data is avilable");
            }
            else
            {
                Assert.IsNull(result, "Target Production data is not avilable");
            }
        }

        /// <summary>
        ///     Test method for SaveTargetProduction
        /// </summary>
        [TestMethod]
        public void SaveTargetProduction_Test()
        {
            IList<WebModel.TargetProduction> mockTargetProduction1 = new List<WebModel.TargetProduction>();
            mockTargetProduction1.Add(new WebModel.TargetProduction());
            _mockTargetProductions = from n in mockTargetProduction1 select n;

            HttpResponseMessage result = _targetProductionController.Put(_mockTargetProductions);
            if (result != null)
            {
                Assert.IsNotNull(result, "Target Production saved successfully");
            }
            else
            {
                Assert.IsNull(result, "Target Production not saved");
            }
        }
    }
}