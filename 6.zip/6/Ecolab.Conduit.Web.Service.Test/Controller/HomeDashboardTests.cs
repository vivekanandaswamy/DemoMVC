﻿// -----------------------------------------------------------------------
// <copyright file="HomeDashboardTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Home Dashboard object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.Visualization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.Visualization;

    [TestClass]
    public sealed class HomeDashboardTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        public HomeDashboardTests()
        {
            _mockDashboardsForHome.Add(new Models.Visualization.DashboardsForHome { DashboardId = 1, TypeId = 1 });

            _mockDashboardsForHomeWeb.Add(new DashboardsForHome { DashboardId = 1, TypeId = 1 });
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            _userService = null;
            _homeDashboardService = null;
            _plantService = null;
            _mockDashboardsForHome = null;
            homeController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for Home Dashboard
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            _homeDashboardService = new Mock<IDashboardService>();
            _homeDashboardService.Setup(Hdb => Hdb.FetchDashboardsForHome()).Returns(_mockDashboardsForHome);

            _plantService = new Mock<IPlantService>();
            _plantService.Setup(Ut => Ut.GetPlantDetails("1")).Returns(plant);

            HttpConfiguration config = new HttpConfiguration();
            homeController = new HomeController(_userService.Object, _plantService.Object, _homeDashboardService.Object);
            homeController.Request = new HttpRequestMessage();
            homeController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        [TestMethod]
        public void FetchHomeDashboardDetails()
        {
            List<DashboardsForHome> result = homeController.FetchDashboardsForHome();
            Assert.IsNotNull(result, "Alarm data");
        }

        #region "Properties"

        /// <summary>
        ///     interface IDashboardService
        /// </summary>
        private Mock<IDashboardService> _homeDashboardService;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     Home Dashboard Web class
        /// </summary>
        private readonly List<DashboardsForHome> _mockDashboardsForHomeWeb = new List<DashboardsForHome>();

        /// <summary>
        ///     Home Dashboard class
        /// </summary>
        private List<Models.Visualization.DashboardsForHome> _mockDashboardsForHome = new List<Models.Visualization.DashboardsForHome>();

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller Home Controller
        /// </summary>
        private HomeController homeController;

        #endregion
    }
}