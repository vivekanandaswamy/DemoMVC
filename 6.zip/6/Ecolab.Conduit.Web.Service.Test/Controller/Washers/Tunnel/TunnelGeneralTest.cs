﻿
// -----------------------------------------------------------------------
// <copyright file="TunnelGeneralTest.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The TunnelGeneralTest object</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Web.Service.Test.Controller.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    public class TunnelGeneralTest
    {

    }
}
