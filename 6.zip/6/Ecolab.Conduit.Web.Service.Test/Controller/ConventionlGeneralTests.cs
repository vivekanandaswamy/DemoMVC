﻿using Model = Ecolab.Models;
using WebModel = Ecolab.ConduitLocal.Web.Models;

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api.Washers.Conventional;
    using ConduitLocal.Web.Models.Washers.Conventional;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Washers.Conventional;
    using Moq;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers.Conventional;
    using Services.Interfaces.Washers;

    [TestClass]
    public sealed class ConventionlGeneralTests : TestBase, IDisposable
    {
        #region "Setup data"

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        public ConventionlGeneralTests()
        {
            _mockConventionalGeneralList = new List<ConventionalGeneral> { new ConventionalGeneral { Name = "ABC", ControllerName = "DEF" } };

            _mockWasherModelSize = new List<WasherModelSize> { new WasherModelSize { WasherModelId = 191, WasherModelName = "TestModel1" } };
            _mockConventionalGeneral = new ConventionalGeneral();
            _mockLfsWasherNumber = new LfsWasherNumber { LfsWasherMaxNumber = 99 };

            _mockWasherModeList = new List<WasherModeList> { new WasherModeList { Id = 191, Name = "TestMode1" } };

            _mockWasherModelList = new List<WasherModelList> { new WasherModelList { WasherModelName = "TestModelData" } };

            _mockConventionalGeneral = new ConventionalGeneral { Name = "ABC", ControllerName = "DEF" };

            _conventionalGeneral = new ConventionalGeneralModel { Name = "ABC", ControllerName = "DEF" };
        }

        #endregion "Setup data"

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            conventionalController.Dispose();
        }

        #region "Test Initialization"

        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();
            _plantService = new Mock<IPlantService>();
            _conventionalGeneralServices = new Mock<IConventionalGeneralServices>();
            _controllerSetupService = new Mock<IControllerSetupService>();
            _washerGroupService = new Mock<IWasherGroupService>();
            _injectionService = new Mock<IInjectionService>();
            _washerServices = new Mock<IWasherServices>();
            _conventionalGeneralServices.Setup(Pc => Pc.GetWasherModeList("1", 1)).Returns(_mockWasherModeList);
            _conventionalGeneralServices.Setup(Pc => Pc.GetWashersModelList("Conventional", 1)).Returns(_mockWasherModelList);
            _conventionalGeneralServices.Setup(Pc => Pc.GetWashersModelSizeList("ABC", 1, "Conventional")).Returns(_mockWasherModelSize);
            _conventionalGeneralServices.Setup(Pc => Pc.GetLfsWasherList(12, "1")).Returns(_mockLfsWasherNumber);

            DateTime lastModifiedTimeStamp;
            _conventionalGeneralServices.Setup(Pc => Pc.SaveConventionalData(_mockConventionalGeneral, 1, 0, out lastModifiedTimeStamp));
            _conventionalGeneralServices.Setup(Pc => Pc.UpdateConventionalData(_mockConventionalGeneral, 1, 0, out lastModifiedTimeStamp, null));

            HttpConfiguration config = new HttpConfiguration();
            conventionalController = new ConventionalController(_conventionalGeneralServices.Object, _controllerSetupService.Object, _washerGroupService.Object, _userService.Object, _plantService.Object, _injectionService.Object, _washerServices.Object);
            conventionalController.Request = new HttpRequestMessage();
            conventionalController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion "Test Initialization"

        #region "Properties"

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     interface IControllerSetupService
        /// </summary>
        private Mock<IConventionalGeneralServices> _conventionalGeneralServices;

        /// <summary>
        ///     interface IControllerSetupService
        /// </summary>
        private Mock<IControllerSetupService> _controllerSetupService;

        /// <summary>
        ///     interface IWasherGroupService
        /// </summary>
        private Mock<IWasherGroupService> _washerGroupService;


        private Mock<IInjectionService> _injectionService;
         
        private Mock<IWasherServices> _washerServices;
        /// <summary>
        ///     Api controller
        /// </summary>
        private ConventionalController conventionalController;

        private List<ConventionalGeneral> _mockConventionalGeneralList;

        private readonly ConventionalGeneral _mockConventionalGeneral;

        private readonly List<WasherModelSize> _mockWasherModelSize;

        private readonly LfsWasherNumber _mockLfsWasherNumber;

        private readonly List<WasherModeList> _mockWasherModeList;

        private readonly List<WasherModelList> _mockWasherModelList;

        private readonly ConventionalGeneralModel _conventionalGeneral;

        #endregion "Properties"

        #region "Test Methods"

        [TestMethod]
        public void GetWasherModeListTest()
        {
            IEnumerable<WasherModeListModel> result = conventionalController.GetWasherModeList(1, "1");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetLfsWasherListTest()
        {
            LfsWasherNumberModel result = conventionalController.GetLfsWasherList(1, "1");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetWashersModelSizeListTest()
        {
            IEnumerable<WasherModelSizeModel> result = conventionalController.GetSizeList("ABC", 1, "Conventional");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void SaveConventionalDataTest()
        {
            HttpResponseMessage result = conventionalController.SaveConventionalData(_conventionalGeneral);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        [TestMethod]
        public void UpdateConventionalDataTest()
        {
            HttpResponseMessage result = conventionalController.UpdateConventionalData(_conventionalGeneral);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        #endregion "Test Methods"
    }
}