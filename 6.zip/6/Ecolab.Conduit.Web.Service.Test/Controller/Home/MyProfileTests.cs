﻿// -----------------------------------------------------------------------
// <copyright file="MyProfileTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The MyProfileTests object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Linq;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api.MyProfile;
    using ConduitLocal.Web.Models.PlantSetup.UserManagement;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.UserManagement;
    using Moq;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.Home;
    using Model = Models;
    using WebModel = ConduitLocal.Web.Models.PlantSetup;
    using System.Configuration;

    /// <summary>
    ///     Tests class for My Profile
    /// </summary>
    [TestClass]
    public sealed class MyProfileTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Constructor
        /// </summary>
        public MyProfileTests()
        {
            _mockUserManagement = new UserManagement
            {
                UserNumber = 3,
                FirstName = "Test",
                LastName = "Test",
                LoginName = RandomString,
                LanguageId = 1,
                LanguageName = "English US",
                Password = "baloce",
                Email = "test@test.com",
                ContactNo = "9999999",
                LevelId = 9,
                Fax = "99999",
                Mobile = "9999999",
                Title = "Mr.",
                RoleName = "Administrator",
                Locale = "en-us",                
            };
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            myProfileController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for My Profile
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            //CustomPrincipal custPrinciple = new CustomPrincipal("1") { UserId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            //HttpContext.Current.User = custPrinciple;

            _myProfileService = new Mock<IMyProfileService>();
            _myProfileService.Setup(ut => ut.FetchMyProfileDetails(It.IsAny<int>(), It.IsAny<string>())).Returns(_mockUserManagement);
            _myProfileService.Setup(ut => ut.UpdateMyProfile(It.IsAny<UserManagement>(), It.IsAny<string>())).Returns("201");
            _myProfileService.Setup(ut => ut.UpdateUserPassword(It.IsAny<UserManagement>(), It.IsAny<string>())).Returns("201");

            HttpConfiguration config = new HttpConfiguration();
            myProfileController = new MyProfileController(_userService.Object, _plantService.Object, _myProfileService.Object) { Request = new HttpRequestMessage() };
            myProfileController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        /// <summary>
        ///     Fetch My Profile Details
        /// </summary>
        [TestMethod]
        public void FetchMyProfileDetails()
        {
            UserProfileViewModel result = myProfileController.FetchMyProfileDetails();
            Assert.IsNotNull(result, result != null ? "User Management data" : "User Management data is not available");
        }

        /// <summary>
        ///     update test for My Profile
        /// </summary>
        [TestMethod]
        public void SaveProfileTest()
        {
            string result = myProfileController.SaveUserProfile(_mockUserManagement);
            Assert.IsNotNull(result, result == "201" ? "saved successfully" : "saved failed");
        }

        /// <summary>
        ///     update test for My Profile Password
        /// </summary>
        [TestMethod]
        public void SavePasswordTest()
        {
            UserProfileViewModel result = myProfileController.SavePassword(_mockUserManagement);
            Assert.IsNotNull(result, result != null ? "Password updated successfully" : "Password updation failed");
        }

        #region Common methods

        /// <summary>
        ///     Method to generate random string for insetring a new record into DB
        /// </summary>
        /// <returns>Random String</returns>
        public string GenerateRandomString()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, 8).Select(s => s[random.Next(s.Length)]).ToArray());
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     UserManagement class
        /// </summary>
        private readonly UserManagement _mockUserManagement = new UserManagement();

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface IMyProfileService
        /// </summary>
        private Mock<IMyProfileService> _myProfileService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller MyProfileController
        /// </summary>
        private MyProfileController myProfileController;

        /// <summary>
        ///     Returns a random string
        /// </summary>
        private string RandomString
        {
            get { return GenerateRandomString(); }
        }

        #endregion
    }
}