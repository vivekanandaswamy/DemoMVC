﻿namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup.ShiftLabor;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.ShiftLabor;
    using Moq;
    using Services;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Model = Models;
    using WebModel = ConduitLocal.Web.Models;
    using Ecolab.ConduitLocal.Web.Models;
    using System.Configuration;

    [TestClass]
    public sealed class ShiftLaborTests : TestBase, IDisposable
    {
        /// <summary>
        ///     ShiftLabor
        /// </summary>
        private readonly ShiftLabor _mockLabor;

        /// <summary>
        ///     ShiftLaborModel
        /// </summary>
        private readonly ShiftLaborModel _mockLaborModel;

        /// <summary>
        ///     Shift class
        /// </summary>
        private readonly List<Shift> _mockShift = new List<Shift>();

        /// <summary>
        ///     ShiftLabor
        /// </summary>
        private readonly List<ShiftLabor> _mockShiftLabor = new List<ShiftLabor>();

        /// <summary>
        ///     ShiftModel
        /// </summary>
        private readonly ShiftModel _mockShiftModel;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface IShiftBreakService
        /// </summary>
        private Mock<ILaborService> _laborService;

        /// <summary>
        ///     interface IShiftBreakService
        /// </summary>
        private Mock<IShiftBreakService> _shiftBreakService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     PlantCustAddress
        /// </summary>
        public Model.PlantCustAddress plantCustAddr;

        /// <summary>
        ///     Api controller ShiftLaborController
        /// </summary>
        private ShiftLaborController shiftLaborController;

        /// <summary>
        ///     ShippingAddress
        /// </summary>
        public Model.ShippingAddress shippingAddr;

        private readonly List<Model.UOMSubUnit> mockUOMSubUnits;

        public ShiftLaborTests()
        {
            _mockShift.Add(new Shift { ShiftId = 1, ShiftName = "SecondShift356", DayId = 1, StartTime = new TimeSpan(10, 30, 0), EndTime = new TimeSpan(18, 30, 0), TargetProduction = 12, ShiftBreak = new ShiftBreak { StartTime = new TimeSpan(12, 30, 0), EndTime = new TimeSpan(13, 00, 0) }, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), Count = 0 });

            _mockShiftModel = new ShiftModel
            {
                Id = 1,
                ShiftId = 0,
                ShiftName = "SecondShift356",
                DayId = 1,
                DayName = "Sunday",
                StartTime = "10:30",
                EndTime = "08:30",
                TargetProduction = 12.8M,
                ShiftBreaks = new List<ShiftBreakModel> { new ShiftBreakModel { BreakId = 1, ShiftId = 1, DayId = 1, StartTime = "12:30", EndTime = "01:00", EcolabAccountNumber = "1", IsDeleted = false, DesiredUnits = "lbs" } },
                EcolabAccountNumber = "1",
                IsSunday = true,
                Count = 1,
                DesiredUnits = "lbs"
            };


            _mockShiftLabor.Add(
                new ShiftLabor
                {
                    LaborId = 1,
                    ShiftId = 1,
                    DayId = 1,
                    LaborTypeId = 2,
                    LaborTypeName = "Temporary",
                    LocationId = 1,
                    LoactionName = "Washer-Extractor",
                    LaborCount = 1,
                    LaborHours = 3,
                    PricePerHr = 10
                });

            _mockLaborModel = new ShiftLaborModel
            {
                ShiftId = 1,
                DayId = 1,
                LaborTypeId = 2,
                LaborTypeName = "Temporary",
                LocationId = 1,
                LoactionName = "Washer-Extractor (Automated)",
                LaborHours = 3,
                PricePerHr = 10,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber")

            };
            

            _mockLabor = new ShiftLabor
            {
                LaborId = 1,
                ShiftId = 1,
                DayId = 1,
                LaborTypeId = 2,
                LaborTypeName = "Temporary",
                LocationId = 1,
                LoactionName = "Washer-Extractor (Automated)",
                LaborHours = 3,
                PricePerHr = 10
            };

            mockUOMSubUnits = new List<Model.UOMSubUnit>()
            {
                new Model.UOMSubUnit
                {
                    UnitSystemId = 1,
                    UsageKey = "UsageKey",
                    Unit = "lbs",
                    SubUnit_Source = "lbs",
                    SubUnit_Target = "kgs"
                }
            };
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            shiftLaborController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            HttpContext.Current = new HttpContext(new HttpRequest("", "http://conduitlocal.com", ""), new HttpResponse(new StringWriter()));

            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserName = "test";
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "Admin";
            HttpContext.Current.User = custPrinciple;

            _userService = new Mock<IUserService>();

            _plantService = new Mock<IPlantService>();
            ecolabAccountNumber = "1";
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);

            _shiftBreakService = new Mock<IShiftBreakService>();
            _laborService = new Mock<ILaborService>();
            int result = 0;
            _shiftBreakService.Setup(SL => SL.FetchShiftDetails(It.IsAny<int?>(), It.IsAny<int?>(), It.IsAny<string>())).Returns(_mockShift);
            DateTime lastModifiedTimeStamp;
            _shiftBreakService.Setup(SL => SL.InsertShiftAndBreak(It.IsAny<List<Shift>>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns("result");
            _shiftBreakService.Setup(SL => SL.UpdateShiftAndBreak(It.IsAny<List<Shift>>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns("result");
            _shiftBreakService.Setup(SL => SL.DeleteShiftAndBreak(It.IsAny<Shift>(), It.IsAny<int>(), out lastModifiedTimeStamp));
            _laborService.Setup(SL => SL.FetchShiftLaborDetails(ecolabAccountNumber)).Returns(_mockShiftLabor);
            _laborService.Setup(SL => SL.InsertShiftLabor(It.IsAny<ShiftLabor>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(result);
            _laborService.Setup(SL => SL.UpdateShiftLabor(It.IsAny<ShiftLabor>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(result);
            _laborService.Setup(SL => SL.DeleteShiftLabor(It.IsAny<ShiftLabor>(), It.IsAny<int>(), out lastModifiedTimeStamp)).Returns(result);

            _plantService.Setup(_ => _.GetPlantUOMSubUnits(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).Returns(mockUOMSubUnits);
            HttpConfiguration config = new HttpConfiguration();
            shiftLaborController = new ShiftLaborController(_userService.Object, _shiftBreakService.Object, _laborService.Object, _plantService.Object);
            shiftLaborController.Request = new HttpRequestMessage();
            shiftLaborController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        [TestMethod]
        public void FetchShiftLaborDetails_Test()
        {
            int? dayId = 1;
            int? shiftId = 1;
            Dictionary<string, List<ShiftModel>> result = shiftLaborController.GetShiftData(dayId, shiftId);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void CreateShift_Test()
        {
            HttpResponseMessage result = shiftLaborController.CreateShift(_mockShiftModel);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void UpdateShift_Test()
        {
            string result = shiftLaborController.UpdateShift(_mockShiftModel);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void DeleteShift_Test()
        {
            shiftLaborController.DeleteShift(1, 1);
        }

        [TestMethod]
        public void DeleteBreak_Test()
        {
            shiftLaborController.DeleteBreak(1, 1, 1);
        }

        [TestMethod]
        public void CreateLabor_Test()
        {
            HttpResponseMessage result = shiftLaborController.CreateLabor(_mockLaborModel);
            Assert.IsNotNull(result, "Labot Insert successfully");
        }

        [TestMethod]
        public void UpdateLabor_Test()
        {
            ShiftLabor _mockLabor = new ShiftLabor { LaborId = 1, ShiftId = 1, DayId = 1, LaborTypeId = 2, LaborTypeName = "Temporary", LocationId = 1, LoactionName = "Washer-Extractor (Automated)", LaborHours = 3, PricePerHr = 10 };
            string result = shiftLaborController.Updatelabor(_mockLabor);
            Assert.IsNotNull(result, "Labot Updated successfully");
        }

        [TestMethod]
        public void DeleteLabor_Test()
        {
            int id = 1;
            HttpResponseMessage result = shiftLaborController.DeleteLabor(id);
            Assert.IsNotNull(result, "Labot Deleted successfully");
        }
    }
}