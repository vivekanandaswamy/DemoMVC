﻿// -----------------------------------------------------------------------
// <copyright file="LaborCostTests.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Labor Cost Tests</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Web;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup.ShiftLabor;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.ShiftLabor;
    using Moq;
    using Ecolab.Services;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup.ShiftLabor;

    /// <summary>
    ///     Test class for LaborCostTests
    /// </summary>
    [TestClass]
    public sealed class LaborCostTests : TestBase, IDisposable
    {
        /// <summary>
        ///     LaborCostModel class
        /// </summary>
        private readonly IEnumerable<LaborCost> mockLaborCost;
        private readonly List<LaborCost> mockListLaborCost;

        /// <summary>
        ///     LaborCostModel class
        /// </summary>
        private readonly IEnumerable<LaborCostModel> mockLaborCostModel = null;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext ControllerContext;

        /// <summary>
        ///     Api controller MeterController
        /// </summary>
        private LaborCostController laborCostController;

        /// <summary>
        ///     interface IMeterService
        /// </summary>
        private Mock<ILaborCostService> laborService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> userService;

        public LaborCostTests()
        {
            mockListLaborCost = new List<LaborCost>()
            {
                new LaborCost 
                {
                    LaborTypeId = 1,                   
                    Cost = 12,
                    EcolabAccountNumber = "1"
                    
                }};
            mockLaborCost = mockListLaborCost;
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            laborCostController.Dispose();
        }

        [TestInitialize]
        public void MockSetUp()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserName = "test";
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "Admin";
            HttpContext.Current.User = custPrinciple;

            DateTime lastModifiedBy;
            int errorCode;
            userService = new Mock<IUserService>();
            laborService = new Mock<ILaborCostService>();
            laborService.Setup(lc => lc.FetchLaborTypeCostDetails(It.IsAny<string>())).Returns(mockListLaborCost);
            laborService.Setup(lc => lc.SaveLaborCost(It.IsAny<IEnumerable<LaborCost>>(), It.IsAny<string>(), It.IsAny<int>(), out lastModifiedBy, out errorCode))
            .Returns(mockLaborCost);
            _plantService.Setup(ut => ut.GetPlantDetails("1")).Returns(plant);

            HttpConfiguration config = new HttpConfiguration();
            laborCostController = new LaborCostController(userService.Object, _plantService.Object, laborService.Object) { Request = new HttpRequestMessage() };
            laborCostController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        /// <summary>
        ///     Test method for FetchLaborTypeCostDetails
        /// </summary>
        [TestMethod]
        public void FetchLaborTypeCostDetails_Test()
        {
            List<LaborCostModel> result = laborCostController.Fetch();
            if (result != null)
            {
                Assert.IsNotNull(result, "Labor cost data is avilable");
            }
            else
            {
                Assert.IsNull(result, "Labor cost data is not avilable");
            }
        }

        /// <summary>
        ///     Test method for save SaveLaborCost
        /// </summary>
        [TestMethod]
        public void SaveLaborCost_Test()
        {
            HttpResponseMessage result = laborCostController.Put(mockLaborCostModel);
            if (result != null)
            {
                Assert.IsNotNull(result, "Labor cost data saved successfully");
            }
            else
            {
                Assert.IsNull(result, "Labor cost data not saved");
            }
        }
    }
}