﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementTests.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The MeterTests object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models.PlantSetup.UserManagement;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.UserManagement;
    using Moq;
    using Services.Interfaces;

    /// <summary>
    ///     Tests class for UserManagement
    /// </summary>
    [TestClass]
    public sealed class UserManagementTests : TestBase, IDisposable
    {
        /// <summary>
        ///     Constructor
        /// </summary>
        public UserManagementTests()
        {
            _mockUserManagement.Add(new UserManagement { UserNumber = 3, FirstName = "Test", LastName = "Test", LoginName = RandomString, Password = "test", Email = "test@test.com", ContactNo = "9999999", LevelId = 9, EcolabAccountNumber = EcoalabAccountNumber });

            _mockUserManagementModel = new UserManagementModel { UserNumber = 3, FirstName = "Test", LastName = "Test", LoginName = RandomString, Password = "test", Email = "test@test.com", ContactNo = "9999999", LevelId = 9, EcolabAccountNumber = EcoalabAccountNumber };

            _userManagementModel = new UserManagementModel { UserNumber = 3, FirstName = "Test", LastName = "Test", LoginName = RandomString, Password = "test", Email = "test@test.com", ContactNo = "9999999", LevelId = 9, EcolabAccountNumber = EcoalabAccountNumber };
        }

        /// <summary>
        ///     Dispose
        /// </summary>
        public void Dispose()
        {
            userManagementController.Dispose();
        }

        #region "Test Initialization"

        /// <summary>
        ///     Test initialization for User Management
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();

            _userManagementService = new Mock<IUserManagementService>();
            _userManagementService.Setup(Ut => Ut.FetchUserManagementDetails(null, EcoalabAccountNumber)).Returns(_mockUserManagement);

            _plantService.Setup(Ut => Ut.GetPlantDetails(userId, "1")).Returns(plant);

            HttpConfiguration config = new HttpConfiguration();
            userManagementController = new UserManagementController(_userService.Object, _plantService.Object, _userManagementService.Object);
            userManagementController.Request = new HttpRequestMessage();
            userManagementController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #endregion

        /// <summary>
        ///     Fetch User Management Details
        /// </summary>
        [TestMethod]
        public void FetchUserManagementDetails()
        {
            UserManagementViewModel result = userManagementController.Fetch();
            Assert.IsNotNull(result, "User Management data");
        }

        /// <summary>
        ///     Insert test for User Management
        /// </summary>
        [TestMethod]
        public void CreateTest()
        {
            HttpResponseMessage result = userManagementController.Create(_mockUserManagementModel);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     update test for User Management
        /// </summary>
        [TestMethod]
        public void PutTest()
        {
            HttpResponseMessage result = userManagementController.Put(0, _userManagementModel);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        /// <summary>
        ///     delete test for User Management
        /// </summary>
        [TestMethod]
        public void DeleteTest()
        {
            HttpResponseMessage result = userManagementController.Delete(_userManagementModel);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
        }

        #region Common methods

        /// <summary>
        ///     Method to generate random string for insetring a new record into DB
        /// </summary>
        /// <returns>Random String</returns>
        public string GenerateRandomString()
        {
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, 8).Select(s => s[random.Next(s.Length)]).ToArray());
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     UserManagement class
        /// </summary>
        private readonly List<UserManagement> _mockUserManagement = new List<UserManagement>();

        /// <summary>
        ///     Model UserManagement
        /// </summary>
        private readonly UserManagementModel _mockUserManagementModel;

        /// <summary>
        ///     Model  UserManagement
        /// </summary>
        private readonly UserManagementModel _userManagementModel;

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        /// <summary>
        ///     interface IUserManagementService
        /// </summary>
        private Mock<IUserManagementService> _userManagementService;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller UserManagementController
        /// </summary>
        private UserManagementController userManagementController;

        /// <summary>
        ///     Returns EcolabAccountNumber from PlantDetails
        /// </summary>
        private string EcoalabAccountNumber
        {
            get { return "1"; }
        }

        /// <summary>
        ///     Returns a random string
        /// </summary>
        private string RandomString
        {
            get { return GenerateRandomString(); }
        }

        #endregion
    }
}