﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerTests.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Customer Tests class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Controller
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Net.Http;
    using System.Web.Http;
    using System.Web.Http.Hosting;
    using System.Web.Mvc;
    using ConduitLocal.Web.Api;
    using ConduitLocal.Web.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Moq;
    using Services.Interfaces;

    /// <summary>
    /// </summary>
    [TestClass]
    public sealed class PlantCustomerTests : TestBase, IDisposable
    {
        private readonly string contlName = "Customer";
        private readonly string searchURL = ( new AppSettingsReader() ).GetValue("WebApiController.URL", typeof (string)) + "Customer";

        /// <summary>
        ///     ControllerContext
        /// </summary>
        public ControllerContext _controllerContext;

        private PlantCustomerModel _mockPlantCustModel;

        private List<PlantCustomer> _mockPlantCustomer;

        /// <summary>
        ///     interface IUserService
        /// </summary>
        private Mock<IUserService> _userService;

        /// <summary>
        ///     Api controller CustomerController
        /// </summary>
        private CustomerController customerController;

		private List<PlantCustomerModel> _mockPlantCustModelList;

		/// <summary>
		///     Dispose
		/// </summary>
		public void Dispose()
        {
            customerController.Dispose();
        }

        #region "Methods"

        private List<PlantCustomer> MockPlantCust()
        {
            _mockPlantCustomer = new List<PlantCustomer> { new PlantCustomer { Id = 34, CustomerId = 1, CustomerName = "tcd45698", IsDeleted = true } };
            return _mockPlantCustomer;
        }

        #endregion

        /// <summary>
        ///     Mock setup method
        /// </summary>
        [TestInitialize]
        public void MockSetup()
        {
            _userService = new Mock<IUserService>();
            var plantCust = new Mock<IPlantCustomerService>();
            plantCust.Setup(pc => pc.GetPlantCustomer(It.IsAny<string>())).Returns(MockPlantCust);
            ecolabAccountNumber = "1";
            _plantService.Setup(PS => PS.GetPlantDetails(1, string.Empty)).Returns(plant);

            HttpConfiguration config = new HttpConfiguration();
            customerController = new CustomerController(_userService.Object, plantCust.Object, _plantService.Object) { Request = new HttpRequestMessage() };
            customerController.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
        }

        #region "Test Methods"

        [TestMethod]
        public void GetPlantCustomerDetailsTest()
        {
            IEnumerable<PlantCustomerModel> result = customerController.GetCustomer();
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void SaveCustomerDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(customerController, searchURL, contlName);
            _mockPlantCustModel = new PlantCustomerModel { CustomerId = 3, CustomerName = "TestFromDev2" };
			_mockPlantCustModelList = new List<PlantCustomerModel>();
			_mockPlantCustModelList.Add(_mockPlantCustModel);
			HttpResponseMessage result = customerController.Put(_mockPlantCustModelList);
            if (result != null)
            {
                Assert.IsNotNull(result, "Saved");
            }
            else
            {
                Assert.IsNull(result, "Not Saved");
            }
        }

        [TestMethod]
        public void DeleteCustomerDetails_Test()
        {
            SetupControllerForTests.SetupControllerForContlTests(customerController, searchURL, contlName);
            _mockPlantCustModel = new PlantCustomerModel { Id = 1, IsDeleted = true, CustomerId = 4, CustomerName = "TestFromDev2", EcoalabAccountNumber = "1", LastModifiedTimeStamp = DateTime.Now, MaxNumberOfRecords = 10 };
			_mockPlantCustModelList = new List<PlantCustomerModel>();
			_mockPlantCustModelList.Add(_mockPlantCustModel);
			HttpResponseMessage result = customerController.DeleteCustomer(_mockPlantCustModelList);
            if (result != null)
            {
                Assert.IsNotNull(result, "Deleted");
            }
            else
            {
                Assert.IsNull(result, "Not Deleted");
            }
        }

        #endregion
    }
}