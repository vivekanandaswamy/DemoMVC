﻿// -----------------------------------------------------------------------
// <copyright file="TestSetup.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Test Setup class for Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Infra
{
    using ConduitLocal.Web.Infra;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    ///     TestSetup
    /// </summary>
    [TestClass]
    public static class TestSetup
    {
        [AssemblyInitialize]
        public static void Init(TestContext TestContext)
        {
            AutoMapperConfiguration.Configure();
        }
    }
}