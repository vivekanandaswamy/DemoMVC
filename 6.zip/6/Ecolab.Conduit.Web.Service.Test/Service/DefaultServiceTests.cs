﻿// -----------------------------------------------------------------------
// <copyright file="DefaultServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DefaultServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.Default;
    using Services.Default;
    using Services.Interfaces.Default;

    /// <summary>
    ///     DefaultServiceTests class
    /// </summary>
    [TestClass]
    public class DefaultServiceTests : TestBase
    {
        /// <summary>
        ///     interface IDefaultService
        /// </summary>
        private IDefaultService mDefaultService;

        [TestInitialize]
        public void TestInitialize()
        {
            mDefaultService = new DefaultService();
        }

        /// <summary>
        ///     Fetch Portlets ByUser
        /// </summary>
        [TestMethod]
        public void FetchPortletsByUser_Test()
        {
            string ecolabaccountnumber = "1";
            int userId = 1;
            List<Portlet> result = mDefaultService.FetchPortletsByUser(userId, ecolabaccountnumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetch ShiftSummaryDetails
        /// </summary>
        [TestMethod]
        public void GetShiftSummaryDetails_Test()
        {
            string ecolabaccountnumber = "1";
            ShiftSummary result = mDefaultService.GetShiftSummaryDetails(ecolabaccountnumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Create User PortletData
        /// </summary>
        [TestMethod]
        public void CreateUserPortletData_Test()
        {
            string ecolabaccountnumber = "1";
            int userId = 1;

            var portletList = new List<Portlet>();
            Portlet objFirstPortlet = new Portlet { PortletId = 1, DisplayOrder = 1, IsEnabled = true, EcolabAccountNumber = ecolabaccountnumber };
            Portlet objSecondPortlet = new Portlet { PortletId = 2, DisplayOrder = 2, IsEnabled = true, EcolabAccountNumber = ecolabaccountnumber };
            Portlet objThirdPortlet = new Portlet { PortletId = 3, DisplayOrder = 3, IsEnabled = false, EcolabAccountNumber = ecolabaccountnumber };
            Portlet objFourthPortlet = new Portlet { PortletId = 4, DisplayOrder = 4, IsEnabled = false, EcolabAccountNumber = ecolabaccountnumber };

            portletList.Add(objFirstPortlet);
            portletList.Add(objSecondPortlet);
            portletList.Add(objThirdPortlet);
            portletList.Add(objFourthPortlet);

            string result = mDefaultService.CreateUserPortletData(portletList, userId, ecolabaccountnumber);
            if (result == "101")
            {
                Assert.IsTrue(true, "Record Inserted Successfully");
            }
            else
            {
                Assert.IsFalse(true, "Record Insertion Failed");
            }
        }
    }
}