﻿

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Services;
    using Ecolab.Models;

    [TestClass]
    public class LogServiceTests : TestBase
    {
        /// <summary>
        /// interface IPlantService
        /// </summary>
        LogService logService;

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            logService = new LogService();
        }

        ///// <summary>
        ///// MS Test for GetLogsData
        ///// </summary>
        //[TestMethod]
        //public void GetLogsData_Test()
        //{
        //    List<Logs> logs = logService.GetLogsData();

        //    if(logs.Count > 0)
        //    {
        //        Assert.IsTrue(true, "Log details are available");
        //    }
        //    else
        //    {
        //        Assert.IsTrue(true, "Log details are not available");
        //    }
        //}
    }
}
