﻿// -----------------------------------------------------------------------
// <copyright file="TrendingChartServiceTests.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Meter Service Tests  </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Services;
    using Services.Interfaces;
    using WebModel = ConduitLocal.Web.Mapper;

    [TestClass]
    public class TrendingChartServiceTests : TestBase
    {
        /// <summary>
        ///     interface IPlantService
        /// </summary>
        private ITrendingChartService trendingChartService;

        //public TrendingChartServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            trendingChartService = new TrendingChartService();
        }

        /// <summary>
        ///     Get tunnel details.
        /// </summary>
        [TestMethod]
        public void FetchTunnelDetailsTests()
        {
            List<MachineSetupTunnel> result = trendingChartService.GetTunnelDetails();
            if (result.Count > 0)
            {
                Assert.IsNotNull(result.Count > 0, "Trending data");
            }
            else
            {
                Assert.IsNull(result, "Trending data is not avialable");
            }
        }

        /// <summary>
        ///     Get parameter details by tunnel id.
        /// </summary>
        [TestMethod]
        public void FetchParametersByTunnelIdTests()
        {
            int groupId = 1;
            List<ConduitChartParameterMapping> result = trendingChartService.GetParametersByTunnelId(groupId);
            if (result.Count > 0)
            {
                Assert.IsNotNull(result.Count > 0, "Parameters data");
            }
            else
            {
                Assert.IsNotNull(result.Count, "Parameters data is not avialable");
            }
        }
    }
}