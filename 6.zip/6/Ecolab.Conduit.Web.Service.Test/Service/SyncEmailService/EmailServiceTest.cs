﻿// -----------------------------------------------------------------------
// <copyright file="EmailServiceTest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Email Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.SyncEmailService
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Models;
    using Ecolab.Services.Interfaces;
    using Ecolab.Services;
    using Moq;
    using System.Configuration;

    [TestClass]
    public class EmailServiceTest : TestBase
    {
        private IPlantService plantService;

        [TestInitialize]
        public void TestInitialize()
        {
            plantService = new PlantService();
        }
      

        [TestMethod]
        public void FetchPlantDetails_Test()
        {
            List<Entities.PlantSynch> plant = new List<Entities.PlantSynch>();
            plant = plantService.GetPlants();
            if (plant != null)
            {
                Assert.IsTrue(true, "Plant details are available");
            }
            else
            {
                Assert.IsTrue(true, "Plant details are not available");
            }
        }

        [TestMethod] 
        public void CheckPlantSyncOrNot_Test()
        {
            Ecolab.Data.Access.Database.ApplicationMode = Entities.ApplicationMode.Central;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");   
            List<Entities.PlantSynch> plant = new List<Entities.PlantSynch>();
            plant = plantService.GetPlants();
            int plantid = 0;
            foreach (var item in plant)
            {
                plantid = item.PlantId;
            }
            int synclapsetime = 25;
            int result = 0;
            result = plantService.CheckPlantSynch(plantid, synclapsetime);
            if (result == 0)
            {
                Assert.IsTrue(true, "Plant is in sync");
            }
            else
            {
                Assert.IsTrue(true, "Plant is not in sync");
            }
        }

        [TestMethod]
        public void FetchTMUsers_Test()
        {           
            List<Entities.PlantSynch> plant = new List<Entities.PlantSynch>();
            plant = plantService.GetPlants();
            int plantid = 0;
            foreach (var item in plant)
            {
                plantid = item.PlantId;
            }

            List<string> TMUsers = plantService.GetTMUsers(plantid);
            
            if (TMUsers.Count > 0)
            {
                Assert.IsTrue(true, "TM Users are available");
            }
            else
            {
                Assert.IsTrue(true, "TM Users are not available");
            }
        }
    }
}
