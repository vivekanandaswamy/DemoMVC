﻿
namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Models;   
    using Ecolab.Services.Interfaces;
    using Ecolab.Services;

    [TestClass]
    public class PlantServiceTests : TestBase
    {
        /// <summary>
        /// interface IPlantService
        /// </summary>
        IPlantService plantService;

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            plantService = new PlantService();
        }

        /// <summary>
        /// MS test for GetPlantDetails
        /// </summary>
        [TestMethod]
        public void GetPlantDetails_Test()
        {
            int userId = 1;
            string ecolabAccountNumber = string.Empty;

            Plant plant =  plantService.GetPlantDetails(userId, ecolabAccountNumber);

            if(plant != null)
            {
                 Assert.IsTrue(true, "Plant details are available");
            }
            else
            {
                 Assert.IsTrue(true, "Plant details are not available");
            }
        }

        /// <summary>
        /// MS test for GetPlantDetails with out user
        /// </summary>
        [TestMethod]
        public void GetPlantDetailsWithoutUser_Test()
        {            
            string ecolabAccountNumber = string.Empty;

            Plant plant = plantService.GetPlantDetails(ecolabAccountNumber);

            if (plant != null)
            {
                Assert.IsTrue(true, "Plant details are available");
            }
            else
            {
                Assert.IsTrue(true, "Plant details are not available");
            }
        }

        /// <summary>
        /// MS test for SavePlantDetails
        /// </summary>
        //[TestMethod]
        //public void SavePlantDetails_Test()
        //{
        //    Plant plant = new Plant() 
        //    {
        //        EcoalabAccountNumber ="1",
        //        LanguageId = 1,
        //        CurrencyCode = "US",
        //        Rate = 100,
        //        ExportPath = "D://img.jpeg",
        //        DataLiveTime = 30,
        //        BudgetCustomer = true,
        //        UomId = 1,
        //        Logo = "1,1",
        //        AllowManualRewash = false
        //    };

        //    int userId =1;
        //    DateTime lastModifiedTimeStamp;

        //    string result = plantService.SavePlantDetails(plant, userId, out lastModifiedTimeStamp);

        //    if (plant != null)
        //    {
        //        Assert.IsTrue(true, "Plant details are available");
        //    }
        //    else
        //    {
        //        Assert.IsTrue(true, "Plant details are not available");
        //    }
        //}
    }
}
