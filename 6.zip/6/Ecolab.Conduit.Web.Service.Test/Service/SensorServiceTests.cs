﻿namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Common;
    using Models.PlantSetup;
    using Services.Interfaces.PlantSetup;
    using Services.PlantSetup;
    using System.Configuration;

    [TestClass]
    public class SensorServiceTests : TestBase
    {
        /// <summary>
        ///     interface ISensorService
        /// </summary>
        private ISensorService sensorService;

        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            sensorService = new SensorService();
        }

        /// <summary>
        ///     Positive Fetch test for sensors
        /// </summary>
        [TestMethod]
        public void FetchSensorDetailsTest()
        {
            List<Sensor> result = sensorService.GetPlantSensorDetails(1, EcolabAccountNumber);
            Assert.IsNotNull(result.Count > 0, "fetched sensor details.");
        }

        /// <summary>
        ///     Positive Fetch test for sesnsors
        /// </summary>
        [TestMethod]
        public void FetchSensorDetailsForNullTest()
        {
            List<Sensor> result = sensorService.GetPlantSensorDetails(null, EcolabAccountNumber);
            Assert.IsNotNull(result.Count > 0, "fetched sensor details.");
        }

        /// <summary>
        ///     Test method for Save Sensor
        /// </summary>
        [TestMethod]
        public void SaveSensorTest()
        {
            const int userId = 1;
            Sensor objSensor = new Sensor
            {
                SensorNumber = 1,
                SensorName = "test",
                SensorType = 3,
                SensorTypeName = "test",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                ControllerId = 1,
                ControllerName = "test Controller",
                SensorLocationId = 1,
                SensorLocation = "test",
                MachineId = 1,
                MachineName = "test",
                OutputType = "test",
                //Calibration = 12.752M,
                AnalogueImputNumber = "1", ChemicalforChartId = 1, ChemicalforChart = "test", Uom = "test", UomName = "test", DashboardActualValue = true };
            DateTime lastModifiedTime;
            string errorCode;
            int? result = Convert.ToInt16(sensorService.SavePlantSensorDetails(objSensor, userId, out errorCode, out lastModifiedTime));
            Assert.IsNotNull(result > 0, "Sensor data has been inserted");
        }

        /// <summary>
        ///     Test method for Save Sensor
        /// </summary>
        [TestMethod]
        public void SaveSensorFailTest()
        {
            const int userId = 1;
            Sensor objSensor = new Sensor
            {
                SensorNumber = 1,
                SensorName = "test",
                SensorType = 3,
                SensorTypeName = "test",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                ControllerId = 1,
                ControllerName = "test Controller",
                SensorLocationId = 1,
                SensorLocation = "test",
                MachineId = 1,
                MachineName = "test",
                OutputType = "test",
                //Calibration = 12.752M,
                AnalogueImputNumber = "1", ChemicalforChartId = 1, ChemicalforChart = "test", Uom = "test", UomName = "test", DashboardActualValue = true };
            DateTime lastModifiedTime;
            string errorCode;
            int? result = Convert.ToInt16(sensorService.SavePlantSensorDetails(objSensor, userId, out errorCode, out lastModifiedTime));
            Assert.IsNotNull(result == null, "Error while inserting sensor data");
        }

        /// <summary>
        ///     Test to Delete sensor
        /// </summary>
        [TestMethod]
        public void DeletesensorsTest()
        {
            Sensor objSensor = new Sensor { SensorNumber = 14, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            const int userId = 1;
            DateTime lastModifiedTimeStamp;
            int error;
            int isDeleted = sensorService.DeletePlantSensorDetails(objSensor, userId, out error, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted != 0, "Sensor details has been deleted");
        }

        /// <summary>
        ///     Get the sensor Type details.
        /// </summary>
        [TestMethod]
        public void FetchSensorTypeDetailsTest()
        {
            List<SensorType> result = sensorService.GetSensorTypeDetails();
            Assert.IsNotNull(result.Count > 0, "Fetched the sensor type details.");
        }

        /// <summary>
        ///     Get the Group Type details.
        /// </summary>
        [TestMethod]
        public void FetchGroupTypeDetailsTest()
        {
            string ecolabAccountNumber = "1";
            List<GroupType> result = sensorService.GetGroupTypeDetails(ecolabAccountNumber);
            Assert.IsNotNull(result.Count > 0, "Fetched the sensor type details.");
        }

        /// <summary>
        ///     Get the plant machine details.
        /// </summary>
        [TestMethod]
        public void FetchPlantMachineDetailsTest()
        {
            const int groupTypeId = 1;
            List<MachineSetup> result = sensorService.GetPlantMachineDetails(groupTypeId, "1");
            Assert.IsNotNull(result.Count > 0, "Fetched the plant machine details.");
        }

        /// <summary>
        ///     Get the Conduit details.
        /// </summary>
        [TestMethod]
        public void FetchConduitControllerDetailsTest()
        {
            List<ConduitController> result = sensorService.GetConduitControllerDetails(null, null, EcolabAccountNumber);
            Assert.IsNotNull(result.Count > 0, "Fetched the Conduit details.");
        }

        /// <summary>
        ///     Get the sensor Type details.
        /// </summary>
        [TestMethod]
        public void FetchUomSensorDetailsTest()
        {
            const int id = 1;
            List<UOMSensor> result = sensorService.GetUomSensorDetails(id);
            Assert.IsNotNull(result.Count > 0, "Fetched the UOM sensor details.");
        }

        /// <summary>
        ///     Get the sensor Type details.
        /// </summary>
        [TestMethod]
        public void FetchSensorChemicalChartDetailsTest()
        {
            const int groupId = 1;
            const int machineId = 1;
            const int controllerId = 1;
            List<SensorChemicalChart> result = sensorService.GetSensorChemicalChartDetails(groupId, machineId, controllerId, EcolabAccountNumber);
            Assert.IsNotNull(result.Count > 0, "Fetched the sensor checmical chart details.");
        }
    }
}