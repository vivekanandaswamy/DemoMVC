﻿// -----------------------------------------------------------------------
// <copyright file="HomeDashboardsServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ScreenDashboardMappingServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Visualization
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Visualization;
    using Services.Interfaces.Visualization;
    using Services.Visualization;

    /// <summary>
    ///     Summary description for HomeDashboardsServiceTests
    /// </summary>
    [TestClass]
    public class HomeDashboardsServiceTests : TestBase
    {
        /// <summary>
        ///     interface IDashboardService
        /// </summary>
        private IDashboardService homeDashboardService;

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            homeDashboardService = new DashboardService();
        }

        /// <summary>
        ///     Get the Tunnel data
        /// </summary>
        [TestMethod]
        public void FetchHomeDashboardData_Test()
        {
            List<DashboardsForHome> result = homeDashboardService.FetchDashboardsForHome();
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}