﻿namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup;
    using Models.PlantSetup.Dryer;
    using Services;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.PlantSetup.Dryer;
    using Services.PlantSetup;
    using Services.PlantSetup.Dryer;
    using System.Configuration;

    [TestClass]
    public class DryerServiceTests : TestBase
    {
        /// <summary>
        ///     interface I
        /// </summary>
        private IDryerGroupService _dryerGroupService;

        private IDryerService _dryerService;
        private IMeterService _meterService;

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _dryerGroupService = new DryerGroupService();
            _dryerService = new DryerService();
            _plantService = new PlantService();
            _meterService = new MeterService();
        }

        /// <summary>
        ///     Test method to Insert a new dryer group
        /// </summary>
        [TestMethod]
        public void ValidInsertDryerGroup_Test()
        {
            DryerGroup objDryerGroup = new DryerGroup { Name = GenerateRandomString(), EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            DateTime lastModifiedTimeStamp;
            int result = _dryerGroupService.InsertDryerGroup(objDryerGroup, UserId, out lastModifiedTimeStamp);
            if (result == 101)
            {
                Assert.AreEqual(result, 101);
            }
            else
            {
                Assert.AreNotEqual(result, 101);
            }
        }

        /// <summary>
        ///     Test method to Insert a duplicate  dryer group Name which should not save the record and return 301
        /// </summary>
        [TestMethod]
        public void DuplicateInsertDryerGroup_Test()
        {
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            string existingName = dryergroups.Where(_ => _.IsDeleted != true).Select(_ => _.Name).FirstOrDefault();
            DryerGroup objDryerGroup = new DryerGroup { Name = existingName, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            DateTime lastModifiedTimeStamp;
            int result = _dryerGroupService.InsertDryerGroup(objDryerGroup, UserId, out lastModifiedTimeStamp);
            Assert.AreEqual(result, 301);
        }

        /// <summary>
        ///     Test method to update an existing record
        /// </summary>
        [TestMethod]
        public void UpdateDryerGroup_Test()
        {
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails("1");
            int existingId = dryergroups.Where(_ => _.IsDeleted != true).Select(_ => _.Id).FirstOrDefault();
            DryerGroup objDryerGroup = new DryerGroup { Id = existingId, Name = GenerateRandomString() };
            DateTime lastModifiedTimeStamp;
            int result = _dryerGroupService.UpdateDryerGroup(objDryerGroup, UserId, out lastModifiedTimeStamp);
            if (result == 102)
            {
                Assert.AreEqual(result, 102);
            }
            else
            {
                Assert.AreNotEqual(result, 102);
            }
        }

        /// <summary>
        ///     Test method to update a duplicate  dryer group Name which should not save the record and return 301
        /// </summary>
        [TestMethod]
        public void DuplicateUpdateDryerGroup_Test()
        {
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails("1");
            string existingName = dryergroups.Where(_ => _.IsDeleted != true).Select(_ => _.Name).FirstOrDefault();
            int existingId = dryergroups.Where(_ => _.IsDeleted != true && _.Name != existingName).Select(_ => _.Id).FirstOrDefault();
            DryerGroup objDryerGroup = new DryerGroup { Id = existingId, Name = existingName, EcolabAccountNumber = "1" };
            if (existingId > 0)
            {
                DateTime lastModifiedTimeStamp;
                int result = _dryerGroupService.UpdateDryerGroup(objDryerGroup, UserId, out lastModifiedTimeStamp);
                Assert.AreEqual(result, 301);
            }
        }

        /// <summary>
        ///     Test method to update a duplicate  dryer group Name which should not save the record and return 301
        /// </summary>
        [TestMethod]
        public void InvalidUpdateDryerGroup_Test()
        {
            DryerGroup objDryerGroup = new DryerGroup { Id = 0, Name = GenerateRandomString(), EcolabAccountNumber = "1" };
            DateTime lastModifiedTimeStamp;
            int result = _dryerGroupService.UpdateDryerGroup(objDryerGroup, UserId, out lastModifiedTimeStamp);
            Assert.IsNotNull(result, "Updated");
        }

        /// <summary>
        ///     Test method to delete a dryer group with dependency meters
        /// </summary>
        [TestMethod]
        public void DeleteDryerGroupDependency_Test()
        {
            List<Meter> meters = _meterService.GetPlantMeterDetails(null, "1");
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails("1");

            int existingId = (from groups in dryergroups join objmeters in meters on groups.Id equals objmeters.GroupId where objmeters.IsDeleted != true select groups.Id).FirstOrDefault();

            DryerGroup objDryerGroup = new DryerGroup { Id = existingId };
            if (existingId > 0)
            {
                DateTime lastModifiedTimeStamp;
                int result = _dryerGroupService.DeleteDryerGroup(objDryerGroup, objDryerGroup.Id, UserId, "1", out lastModifiedTimeStamp);
                Assert.IsNotNull(result, "Deleted");
            }
        }

        /// <summary>
        ///     Method to generate random string for insetring a new record into DB
        /// </summary>
        /// <returns>Random String</returns>
        public string GenerateRandomString()
        {
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, 8).Select(s => s[random.Next(s.Length)]).ToArray());
        }

        #region Dryers

        /// <summary>
        ///     Test method to insert a dryer record into DB.
        /// </summary>
        [TestMethod]
        public void ValidInsertDryer_Test()
        {
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails("1");
            int existingGroupId = dryergroups.Where(_ => _.IsDeleted != true).Select(_ => _.Id).FirstOrDefault();

            List<DryerType> dryerTypes = _dryerService.FetchDryerTypes("1");
            int dryerTypeId = dryerTypes.Select(_ => _.Id).FirstOrDefault();

            Dryer objDryer = new Dryer { Name = GenerateRandomString(), Nominalload = 100, EcolabAccountNumber = "1", DryerType = new DryerType { Id = dryerTypeId } };
            DateTime lastModifiedTimeStamp;
            int result = _dryerService.InsertDryer(objDryer, existingGroupId, UserId, out lastModifiedTimeStamp);
            Assert.IsNotNull(result, "Inserted");
        }

        /// <summary>
        ///     Test method to insert a dryer record into DB.
        /// </summary>
        [TestMethod]
        public void DuplicateInsertDryer_Test()
        {
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Dryer existingRecord = dryergroups.Where(_ => _.IsDeleted != true).Select(_ => _.Dryer).FirstOrDefault();

            List<DryerType> dryerTypes = _dryerService.FetchDryerTypes("1");
            int dryerTypeId = dryerTypes.Select(_ => _.Id).FirstOrDefault();

            Dryer objDryer = new Dryer { Name = existingRecord.Name, Nominalload = 100, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), DryerType = new DryerType { Id = dryerTypeId } };
            DateTime lastModifiedTimeStamp;
            int result = _dryerService.InsertDryer(objDryer, existingRecord.GroupId, UserId, out lastModifiedTimeStamp);
            Assert.IsNotNull(result, "Inserted");
        }

        /// <summary>
        ///     Test method to update an existing dryer record.
        /// </summary>
        [TestMethod]
        public void UpdateDryer_Test()
        {
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Dryer existingDryer = dryergroups.Where(_ => _.IsDeleted != true).Select(_ => _.Dryer).FirstOrDefault();

            List<DryerType> dryerTypes = _dryerService.FetchDryerTypes("1");
            int dryerTypeId = dryerTypes.OrderByDescending(_ => _.Id).Select(_ => _.Id).FirstOrDefault();

            existingDryer.Number = existingDryer.Number;
            existingDryer.Name = GenerateRandomString();
            existingDryer.DryerType.Id = dryerTypeId;
            DateTime lastModifiedTimeStamp;
            int result = _dryerService.UpdateDryer(existingDryer, UserId, out lastModifiedTimeStamp);
            Assert.IsNotNull(result, "Updated");
        }

        /// <summary>
        ///     Test method to soft delete dryer record in DB
        /// </summary>
        [TestMethod]
        public void DeleteDryer_Test()
        {
            List<Meter> meters = _meterService.GetPlantMeterDetails(null, "1");
            List<DryerGroup> dryergroups = _dryerGroupService.FetchDryerGroupDetails("1");

            int existingId = dryergroups.Where(_ => !meters.Select(x => x.MachineId).Contains(_.Dryer.Number)).Select(_ => _.Dryer.Number).FirstOrDefault();

            DryerGroup objDryerGroup = new DryerGroup { Id = existingId };
            Dryer objDryer = new Dryer();

            if (existingId > 0)
            {
                DateTime lastModifiedTimeStamp;
                int result = _dryerService.DeleteDryer(objDryer, existingId, UserId, "1", out lastModifiedTimeStamp);
                if (result != 0)
                {
                    Assert.IsTrue(true, "Dryer has been deleted");
                }
                else
                {
                    Assert.IsFalse(false, "Dryer has not been deleted");
                }
            }
        }

        #endregion
    }
}