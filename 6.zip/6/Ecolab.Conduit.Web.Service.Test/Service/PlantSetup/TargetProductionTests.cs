﻿// -----------------------------------------------------------------------
// <copyright file="TargetProductionTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TargetProductionTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.ShiftLabor;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Services.PlantSetup.ShiftLabor;

    [TestClass]
    public class TargetProductionTests : TestBase
    {
        /// <summary>
        ///     interface IShiftBreakService
        /// </summary>
        private IShiftBreakService shiftBreakService;

        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            shiftBreakService = new ShiftBreakService();
        }

        /// <summary>
        ///     Test for get the TargetProduction details
        /// </summary>
        [TestMethod]
        public void FetchTargetProductionDetails_Test()
        {
            List<TargetProduction> result = shiftBreakService.FetchTargetProductionDetails("1");
            if (result != null)
            {
                Assert.IsNotNull(result, "Got the TargetProduction details.");
            }
            else
            {
                Assert.IsNull(result, "TargetProduction details are not available.");
            }
        }

        /// <summary>
        ///     Test for update the TargetProduction details
        /// </summary>
        [TestMethod]
        public void SaveTargetProduction()
        {
            var targetProduction = new List<TargetProduction> { new TargetProduction { DayId = 2, TargetProd = 33, ShiftId = 18, ShiftName = "Shift1", RecordedDate = DateTime.Now, TargetProdDisplay = 2 } };
            DateTime lastModifiedTime = DateTime.UtcNow; 
            string result = shiftBreakService.SaveTargetProduction(targetProduction, "1", 1, out lastModifiedTime);
            if (result == "201")
            {
                Assert.AreEqual(result, "201");
            }
            else
            {
                Assert.AreNotEqual(result, "201");
            }
        }
    }
}