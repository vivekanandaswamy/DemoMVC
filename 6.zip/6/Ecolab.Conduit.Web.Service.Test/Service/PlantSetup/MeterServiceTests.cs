﻿// -----------------------------------------------------------------------
// <copyright file="MeterServiceTests.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Meter Service Tests  </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Common;
    using Models.PlantSetup;
    using Services.Interfaces.PlantSetup;
    using Services.PlantSetup;
    using WebModel = ConduitLocal.Web.Mapper;
    using System.Configuration;

    [TestClass]
    public class MeterServiceTests : TestBase
    {
        /// <summary>
        ///     interface IPlantService
        /// </summary>
        private IMeterService meterService;

        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            meterService = new MeterService();
        }

        /// <summary>
        ///     Fetch test for meters
        /// </summary>
        [TestMethod]
        public void FetchMetersTest()
        {
            List<Meter> result = meterService.GetPlantMeterDetails(null, "1");
            Assert.IsNotNull(result.Count > 0, "fetched meter data.");
        }

        /// <summary>
        ///     Test method for SaveMeters
        /// </summary>
        [TestMethod]
        public void SaveMetersTest()
        {
            Meter objMeter;
            int userId = 1;
            objMeter = new Meter { EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), Description = "test", MeterType = "3", GroupId = 1, MachineId = 1, MaxValueLimit = 1000, MeterTickUnit = "1", UsageFactor = Convert.ToDecimal(0), ControllerId = 1, ParentId = 1, Calibration = Convert.ToDecimal(2), DigitalInputNumber = "1", AllowManualEntry = true };

            DateTime lastModifiedTimeStamp;
            string errorCode;
            int id = meterService.SavePlantMeterDetails(objMeter, userId, out errorCode, out lastModifiedTimeStamp);
            if (id > 0)
            {
                Assert.IsTrue(true, "Saved Plant Customer details.");
            }
            else
            {
                Assert.IsTrue(true, "Not Saved Plant Customer details.");
            }
            
        }

        /// <summary>
        ///     Test method for DeleteMeters
        /// </summary>
        [TestMethod]
        public void DeleteMeterTest()
        {
            int userId = 1;
            DateTime lastModifiedTimeStamp;
            Meter objMeter = new Meter { MeterId = 9, EcolabAccountNumber = "1", Description = "test", MeterType = "3", GroupId = 1, MachineId = 1, MaxValueLimit = 1000, MeterTickUnit = "1", UsageFactor = Convert.ToDecimal(0), ControllerId = 1, ParentId = 1, Calibration = Convert.ToDecimal(2), DigitalInputNumber = "1", AllowManualEntry = true };
            int error;
            int isDeleted = meterService.DeletePlantMeterDetails(objMeter, userId, out error, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted > 0, "Meter details has been deleted");
        }

        /// <summary>
        ///     Get group type details
        /// </summary>
        [TestMethod]
        public void FetchGroupTypeDetailsTest()
        {
            List<GroupType> result = meterService.GetGroupTypeDetails();
            Assert.IsNotNull(result.Count > 0, "fetched the group type data.");
        }

        /// <summary>
        ///     Get parent meter details
        /// </summary>
        [TestMethod]
        public void FetchParentMeterDetailsTest()
        {
            int meterId = 1;
            List<ParentMeter> result = meterService.GetParentMeterDetails(1, meterId, "1");
            Assert.IsNotNull(result.Count > 0, "fetched the group type details.");
        }

        /// <summary>
        ///     Get plant machine details
        /// </summary>
        [TestMethod]
        public void FetchPlantMachineDetailsTest()
        {
            int groupTypeId = 1;
            List<MachineSetup> result = meterService.GetPlantMachineDetails(groupTypeId, "1");
            Assert.IsNotNull(result.Count > 0, "fetched the plant machine details.");
        }

        /// <summary>
        ///     Get the meter controller details.
        /// </summary>
        [TestMethod]
        public void FetchPlantMeterControllerDetailsTest()
        {
            List<ConduitController> result = meterService.GetPlantMeterControllerDetails(null, null, EcolabAccountNumber);
            Assert.IsNotNull(result.Count > 0, "fetched the controller details.");
        }

        /// <summary>
        ///     Get the utility details.
        /// </summary>
        [TestMethod]
        public void FetchUtilitySetupDetails()
        {
            List<ResourceMaster> result = meterService.GetUtilitySetupDetails();
            Assert.IsNotNull(result.Count > 0, "fetched the utility details.");
        }

        /// <summary>
        ///     Get UOM Meter Details
        /// </summary>
        [TestMethod]
        public void FetchUOMMeterDetails()
        {
            int utilityTypeId = 1;
            List<UOMMeter> result = meterService.GetUomMeterDetails(utilityTypeId);
            Assert.IsNotNull(result.Count > 0, "fetched the utility details.");
        }
    }
}