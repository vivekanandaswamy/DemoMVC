﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftLaborServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Data.Access;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.ShiftLabor;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Services.PlantSetup.ShiftLabor;

    [TestClass]
    public class ShiftLaborServiceTests  :TestBase
    {
        /// <summary>
        ///     interface ILaborService
        /// </summary>
        private ILaborService _laborService;

        /// <summary>
        ///     interface IShiftBreakService
        /// </summary>
        private IShiftBreakService _shiftBreakService;       

        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _shiftBreakService = new ShiftBreakService();
            _laborService = new LaborService();           
        }

        /// <summary>
        ///     Get the shift break details
        /// </summary>
        [TestMethod]
        public void FetchShiftBreakDetails_Test()
        {
            List<Shift> shifts = _shiftBreakService.FetchShiftDetails(null, null, "1");
            if (shifts.Count > 0)
            {
                Assert.IsTrue(true, "Get the list of shift break details");
            }
            else
            {
                Assert.IsTrue(true, "Shift break details are not available");
            }           
        }

        /// <summary>
        ///     insert the shift break details
        /// </summary>
        [TestMethod]
        public void InsertShiftBreak_Test()
        {
            var shifts = new List<Shift>();
            shifts.Add(new Shift { //ShiftId =,
            ShiftName = "SecondShift356", DayId = 1, StartTime = new TimeSpan(10, 30, 0), EndTime = new TimeSpan(18, 30, 0), TargetProduction = 12, ShiftBreak = new ShiftBreak { StartTime = new TimeSpan(12, 30, 0), EndTime = new TimeSpan(13, 00, 0) }, EcolabAccountNumber = "1", Count = 0 });
            DateTime lastModifiedTimeStamp;
            string result = _shiftBreakService.InsertShiftAndBreak(shifts, 1, out lastModifiedTimeStamp);

            if (result == "101")
            {
                Assert.IsTrue(true, "shift break details are saved");
            }
            else
            {
                Assert.IsTrue(true, "Shift break details are not saved");
            }            
        }

        /// <summary>
        ///     update the shift break details
        /// </summary>
        [TestMethod]
        public void UpdateShiftBreak_Test()
        {
            var shifts = new List<Shift>();
            shifts.Add(new Shift { Id = 2, ShiftId = 188, ShiftName = "FirstShiftUpdate", DayId = 1, StartTime = new TimeSpan(11, 30, 0), EndTime = new TimeSpan(18, 30, 0), TargetProduction = 12, ShiftBreak = new ShiftBreak { BreakId = 152, StartTime = new TimeSpan(12, 30, 0), EndTime = new TimeSpan(13, 00, 0) }, EcolabAccountNumber = "1" });
            DateTime lastModifiedTimeStamp;
            string result = _shiftBreakService.UpdateShiftAndBreak(shifts, 1, out lastModifiedTimeStamp);

            if (result == "201")
            {
                Assert.IsTrue(true, "Update the shift break details");
            }
            else
            {
                Assert.IsTrue(true, "Shift break details are not updated");
            }
        }

        /// <summary>
        ///     delete the shift break details
        /// </summary>
        [TestMethod]
        public void DeleteShiftBreak_Test()
        {
            Shift shift = new Shift { ShiftId = 150, DayId = 1, EcolabAccountNumber = "1" };
            DateTime lastModifiedTimeStamp;
            int result = _shiftBreakService.DeleteShiftAndBreak(shift, 1, out lastModifiedTimeStamp);

            if (result == 201)
            {
                Assert.IsTrue(true, "Deleted the shift break details");
            }
            else
            {
                Assert.IsTrue(true, "Shift break details are not deleted");
            }
        }

        /// <summary>
        ///     delete the break details
        /// </summary>
        [TestMethod]
        public void DeleteBreak_Test()
        {
            Shift shift = new Shift { ShiftId = 149, DayId = 2, ShiftBreak = new ShiftBreak { BreakId = 151 }, EcolabAccountNumber = "1" };
            DateTime lastModifiedTimeStamp;
            int result = _shiftBreakService.DeleteBreak(shift, 1, out lastModifiedTimeStamp);
            Assert.IsNotNull(result, "Delete the list of shift break details");
        }

        [TestMethod]
        public void FetchShiftLaborDetails_Test()
        {
            List<ShiftLabor> result = _laborService.FetchShiftLaborDetails("1");
            if (result != null)
            {
                Assert.IsNotNull(result, "Get the data for shift labor");
            }
            else
            {
                Assert.IsNull(result, "No data get for shift labor");
            }
        }

        /// <summary>
        ///     insert the shiftlabor details
        /// </summary>
        [TestMethod]
        public void InsertLabor_Test()
        {
            ShiftLabor labor = FetchNewLabor();
            DateTime lastModifiedTimeStamp;
            int result = _laborService.InsertShiftLabor(labor, 1, out lastModifiedTimeStamp);
            Assert.IsNotNull(result != 0, "Insert the list of shift break details");
        }

        /// <summary>
        ///     update the labor details
        /// </summary>
        [TestMethod]
        public void UpdateLabor_Test()
        {
            ShiftLabor labor = FetchUpdateLabor();
            DateTime lastModifiedTimeStamp;
            int result = _laborService.UpdateShiftLabor(labor, 1, out lastModifiedTimeStamp);
            if(result !=0)
            {
                Assert.IsTrue(true, "Update the list of shift break details");
            }
            else
            {
                Assert.IsTrue(true, "Not updated the list of shift break details");
            }
            
        }

        /// <summary>
        ///     delete the labor details
        /// </summary>
        [TestMethod]
        public void DeleteLabor_Test()
        {
            int userId = 1;
            List<ShiftLabor> labors = _laborService.FetchShiftLaborDetails("1");

            if (labors.Any())
            {
                DateTime lastModifiedTimeStamp;
                ShiftLabor labor = labors.First();
                int? deletedLaborId = labor.LaborId;
                string ecolabAccNum = "1";
                labor.EcolabAccountNumber = ecolabAccNum;
                int isDeleted = _laborService.DeleteShiftLabor(labor, userId, out lastModifiedTimeStamp);
                List<ShiftLabor> laborsAfter = _laborService.FetchShiftLaborDetails("1");
                IEnumerable<ShiftLabor> deletedLaborAvailable = laborsAfter.Where(pfrm => pfrm.LaborId == deletedLaborId);
                Assert.IsTrue(!deletedLaborAvailable.Any(), "Labor Is Deleted");
            }
        }
      
        public void FetCostByLaborTypeId()
        {
            LaborTypeCost result = _laborService.FetchCostByLabourType(1, "1");
        }

        private ShiftLabor FetchNewLabor()
        {
            ShiftLabor shiftLabor = new ShiftLabor { ShiftId = 1, DayId = 1, LaborTypeId = 1, LocationId = 1, LaborHours = 40, PricePerHr = 10, LaborCount = 8, EcolabAccountNumber = "1" };
            return shiftLabor;
        }

        private ShiftLabor FetchUpdateLabor()
        {
            ShiftLabor shiftLabor = new ShiftLabor { LaborId = 6, ShiftId = 1, DayId = 1, LaborTypeId = 1, LocationId = 1, LaborHours = 80, PricePerHr = 10, LaborCount = 8, EcolabAccountNumber = "1" };
            return shiftLabor;
        }
    }
}