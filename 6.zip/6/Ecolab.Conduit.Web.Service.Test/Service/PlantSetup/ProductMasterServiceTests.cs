﻿// -----------------------------------------------------------------------
// <copyright file="ProductMasterServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductMasterServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.PlantSetup.Chemical;
    using Services;
    using Services.Interfaces;
    using System.Configuration;

    /// <summary>
    ///     Tests for Product Master
    /// </summary>
    [TestClass]
    public class ProductMasterServiceTests : TestBase
    {
        /// <summary>
        ///     interface IProductMasterService
        /// </summary>
        private IProductMasterService _prodMastService;

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        //public ProductMasterServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        [TestInitialize]
        public void TestInitialize()
        {
            _prodMastService = new ProductMasterService();
        }

        /// <summary>
        ///     Get plant chemical details test
        /// </summary>
        [TestMethod]
        public void FetchPlantChemicalDetails()
        {
            List<ProductMaster> plantChemicals = _prodMastService.FetchPlantChemicalList("1");
            Assert.IsNotNull(plantChemicals != null, "Received Plant chemicals.");
        }

        /// <summary>
        ///     Create plant chemical details test
        /// </summary>
        [TestMethod]
        public void SaveChemicalDetails()
        {
            ProductMaster platChem = FetchNewPlatChemicalCreateNew();
            int userId = 1;
            DateTime lastModifiedTimeStamp = DateTime.Now;
            int result = _prodMastService.SavePlantChemicalDetails(platChem, userId, out lastModifiedTimeStamp);
            Assert.IsNotNull(platChem != null, "Save the chemical data.");
        }

        /// <summary>
        ///     Update plant chemical details test
        /// </summary>
        [TestMethod]
        public void UpdateChemicalDetails()
        {
            int userId = 1;
            DateTime lastModifiedTimeStamp = DateTime.Now;
            ProductMaster prodMaster = new ProductMaster { Id = 4, Cost = 12, IncludeinCI = true, EcolabAccountNumber = "1" };
            _prodMastService.UpdateChemicalDetails(prodMaster, userId, out lastModifiedTimeStamp);
            Assert.IsNotNull(prodMaster != null, "Save the chemical data.");
        }

        /// <summary>
        ///     Delete plant chemical details test
        /// </summary>
        [TestMethod]
        public void DeleteChemicalDetails()
        {
            int userId = 1;
            List<ProductMaster> plantChemicals = _prodMastService.FetchPlantChemicalList("1");
            List<PlantUtilityUnitTypes> units = _prodMastService.GetPlantUtilityEnergyPriceUnits("1", 1);

            if (plantChemicals.Any())
            {
                ProductMaster platChem = plantChemicals.First();
                int deletedPlatChemIdId = platChem.ProductId;
                platChem.Id = deletedPlatChemIdId;
                DateTime lastModifiedTimeStamp = DateTime.Now;
                _prodMastService.DeleteChemicalDetails(platChem, userId, out lastModifiedTimeStamp);

                List<ProductMaster> plantChemicalsAfter = _prodMastService.FetchPlantChemicalList("1");
                IEnumerable<ProductMaster> deletedPlantChemicalAvailable = plantChemicalsAfter.Where(pfrm => pfrm.ProductId == deletedPlatChemIdId);

                Assert.IsTrue(!deletedPlantChemicalAvailable.Any(), "PlatChem Is Deleted");
            }
        }

        private ProductMaster FetchNewPlatChemicalCreateNew()
        {
            List<Chemicals> plantChemicals = _prodMastService.FetchChemicalList("Chem", ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            int productId = plantChemicals.Any() ? plantChemicals.First().ProductId : 1;
            ProductMaster prodMast = new ProductMaster { ProductId = productId, Cost = 10.00, IncludeinCI = true, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            return prodMast;
        }

        private ProductMaster FetchNewPlatChemicalCreate()
        {
            List<Chemicals> plantChemicals = _prodMastService.FetchChemicalList("Chem", "1");
            int productId = plantChemicals.Any() ? plantChemicals.First().ProductId : 1;
            ProductMaster prodMast = new ProductMaster { ProductId = productId, Cost = 10.00, IncludeinCI = true, EcolabAccountNumber = "1" };
            return prodMast;
        }
    }
}