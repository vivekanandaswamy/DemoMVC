﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlagServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using System;
    using System.Collections.Generic;
     using System.Configuration;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.UserManagement;
    using Services;
    using Services.Interfaces;
    using ServiceModel = Models.PlantSetup.UserManagement;

    /// <summary>
    ///     Test class UserManagement
    /// </summary>
    [TestClass]
    public class UserManagementTests : TestBase
    {
        /// <summary>
        ///     interface User Management
        /// </summary>
        private IUserManagementService _userManagementService;

        /// <summary>
        ///     Returns a random string
        /// </summary>
        private string RandomString
        {
            get { return GenerateRandomString(); }
        }

        //public UserManagementTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _userManagementService = new UserManagementService();
        }

        /// <summary>
        ///     Test method to fetch all UserManagement details
        /// </summary>
        [TestMethod]
        public void FetchUserManagementDetails_Test()
        {
            List<UserManagement> userManagement = _userManagementService.FetchUserManagementDetails(1, "1").ToList();
            if (userManagement.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }           
        }

        /// <summary>
        ///     Test method to fetch selected UserManagement details
        /// </summary>
        [TestMethod]
        public void FetchUserManagementItem_Test()
        {
            List<UserManagement> userManagement = _userManagementService.FetchUserManagementDetails(1, "1").ToList();
            if (userManagement.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }     
        }

        /// <summary>
        ///     Test method to insert user management details
        /// </summary>
        [TestMethod]
        public void ValidInsertUserManagement_Test()
        {
            int userId = 1;
            DateTime lastModifiedTimestamp;
            int userMasterId;
            UserManagement userManagement = new UserManagement { FirstName = "Krishna", LastName = "Thota", LoginName = RandomString, Password = "test", LevelId = 6, Email = "kthota@ags.com", ContactNo = "9948843888", EcolabAccountNumber = "1" };
            string result = _userManagementService.InsertUserManagement(userManagement, userId, out lastModifiedTimestamp, out userMasterId);

            if (result != null)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }   
        }

        /// <summary>
        ///     Test method that validates a invalid entry by returning 301 error message
        /// </summary>
        [TestMethod]
        public void InvalidInsertUserManagement_Test()
        {
            //var existingLoginName = _userManagementService.FetchUserManagementDetails(null, "1").Select(_ => _.LoginName).FirstOrDefault();
            DateTime lastModifiedTimestamp;
            int userMasterId;
            UserManagement userManagement = new UserManagement { FirstName = "test", LastName = "Thota", LoginName = "test", Password = "test", LevelId = 6, Email = "kthota@ags.com", ContactNo = "9948843888", EcolabAccountNumber = "1" };
            string result = _userManagementService.InsertUserManagement(userManagement, UserId, out lastModifiedTimestamp, out userMasterId);

            if (result != null)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }   
        }

        /// <summary>
        ///     Test method to update user in user management
        /// </summary>
        [TestMethod]
        public void ValidUpdateUserManagement_Test()
        {
            DateTime lastModifiedTimestamp;
            int userMasterId;
            UserManagement userManagement = new UserManagement { UserNumber = 8, FirstName = "Krishna", LastName = "Thota", LoginName = RandomString, Password = "test", LevelId = 8, Email = "kthota@ags.com", ContactNo = "9948843888", EcolabAccountNumber = "1" };
            string result = _userManagementService.UpdateUserManagement(userManagement, UserId, out lastModifiedTimestamp, out userMasterId);
            if (result == "301")
            {
                Assert.IsTrue(true, "Data is updated");
            }
            else
            {
                Assert.IsTrue(true, "Data is not updated");
            }
        }

        /// <summary>
        ///     Test method that validates a invalid entry by returning 301 error message
        /// </summary>
        [TestMethod]
        public void InvalidUpdateUserManagement_Test()
        {
            DateTime lastModifiedTimestamp;
            int userMasterId;
            // var existingLoginName = _userManagementService.FetchUserManagementDetails(null, "1").Select(_ => _.LoginName).FirstOrDefault();
            UserManagement userManagement = new UserManagement { UserNumber = 8, FirstName = "Krishna", LastName = "Thota", LoginName = "test", Password = "test", LevelId = 8, Email = "kthota@ags.com", ContactNo = "9948843888", EcolabAccountNumber = "1" };
            string result = _userManagementService.UpdateUserManagement(userManagement, UserId, out lastModifiedTimestamp, out userMasterId);

            if (result == "301")
            {
                Assert.IsTrue(true, "Data is updated");
            }
            else
            {
                Assert.IsTrue(true, "Data is not updated");
            }
        }

        /// <summary>
        ///     Test method to delete user in user management
        /// </summary>
        [TestMethod]
        public void DeleteUserManagement_Test()
        {
            DateTime lastModifiedTimestamp;
            UserManagement userManagement = new UserManagement { UserNumber = 8, FirstName = "Krishna", LastName = "Thota", LoginName = RandomString, Password = "test", LevelId = 8, Email = "kthota@ags.com", ContactNo = "9948843888", EcolabAccountNumber = "1" };
            bool result = _userManagementService.DeleteUserManagement(userManagement, 1, out lastModifiedTimestamp);
            if (result == true)
            {
                Assert.IsTrue(true, "Data is deleted");
            }
            else
            {
                Assert.IsTrue(true, "Data is not deleted");
            }
           
        }

        /// <summary>
        /// test method to get maximum number of records
        /// </summary>
        [TestMethod]
        public void GetMaxNumberOfRecords_Test()
        {
            Ecolab.Data.Access.Database.ApplicationMode = Entities.ApplicationMode.Central;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int result = _userManagementService.GetMaxNumberOfRecords(ecolabAccNumber);
            if (result > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// test method to validate and save user details in usermanagement 
        /// </summary>
        [TestMethod]
        public void ValidateAndSaveUserManagementDetails_Test()
        {
            DateTime dt;
            int errorcode = -1;
            int userid = 1;
            UserManagement userManagement = new UserManagement { UserNumber = 9, FirstName = "Krishna", LastName = "Thota", LoginName = RandomString, Password = "test", LevelId = 8, Email = "kthota@aags.com", ContactNo = "9888843888", EcolabAccountNumber = "1" };
            UserManagementService ums = new UserManagementService();

            int result = ums.ValidateAndSaveUserManagementDetails(userManagement, userid, Library.Enums.TcdAdminMessageTypes.TcdAddUserManagement, out errorcode, out dt);

            if (result == 51030)
            {
                Assert.IsTrue(true, "Records not in sync");
            }
            else if (result == 60000)
            {
                Assert.IsTrue(true, "timestamp");
            }
            else if (result == 0)
            {
                Assert.IsTrue(true, "success");
            }
        }

        /// <summary>
        ///  test method to SaveUserManagementForFirstTimeSync
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public void SaveUserManagementForFirstTimeSync_Test()
        {
            UserManagement userManagement = new UserManagement { FirstName = "Krishna", LastName = "Thota", LoginName = RandomString, Password = "test", LevelId = 6, Email = "kthota@ags.com", ContactNo = "9948843888", EcolabAccountNumber = "1",LastModifiedTime=DateTime.Now };
            int userid = 1;
            UserManagementService userMgmService = new UserManagementService();
            try
            {
                userMgmService.SaveUserManagementForFirstTimeSync(userManagement, userid);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }
        /// <summary>
        ///     Method to generate random string for insetring a new record into DB
        /// </summary>
        /// <returns>Random String</returns>
        public string GenerateRandomString()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, 8).Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}