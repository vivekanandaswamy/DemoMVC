﻿using Ecolab.Services.Interfaces.PlantSetup.Finnisher;
using Ecolab.Services.PlantSetup.Finnisher;
using Entities.PlantSetup.Finnisher;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup.FinisherTest
{
    [TestClass]
    public class FinisherGroupServiceTest : TestBase
    {
        /// <summary>
        ///     interface I
        /// </summary>
        private IFinnisherGroupService _finisherGroupService;

        [TestInitialize]
        public void TestInitialize()
        {
            _finisherGroupService = new FinnisherGroupService();
        }

        /// <summary>
        ///     Test to Get Finnisher Group Details Types
        /// </summary>
        [TestMethod]
        public void FetchFinnisherGroupDetails_Test()
        {
            try {
                string plantId = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                List<Models.PlantSetup.Finnisher.FinnisherGroup> FinnisherGroup = _finisherGroupService.FetchFinnisherGroupDetails(plantId);
                if (FinnisherGroup.Count > 0)
                {
                    Assert.IsTrue(true, "Data fetched successfully");                    
                }
                else
                {
                    Assert.IsTrue(true, "Data Not fetched successfully");

                }
            }
            catch
            {
                Assert.Fail();
            }
        }

        /// <summary>
        ///    Test to Insert Finnisher Group Details Types
        /// </summary>
        [TestMethod]
        public void InsertFinnisherGroup_Test()
        {
            try {
                Models.PlantSetup.Finnisher.FinnisherGroup finnisherGroup = new Models.PlantSetup.Finnisher.FinnisherGroup();
                finnisherGroup.Id = 1;
                finnisherGroup.Name = "FinisherGroup1";
                int userId = 1;
                DateTime lastModifiedTimeStamp;
                finnisherGroup.EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                int result = _finisherGroupService.InsertFinnisherGroup(finnisherGroup, userId, out lastModifiedTimeStamp);
                if (result > 0)
                {
                    Assert.IsTrue(true, "Data inserted successfully");
                }
                else
                {
                    Assert.IsTrue(true, "Data Not inserted successfully");
                }
            }
            catch
            {
                Assert.Fail();
            }

        }

        /// <summary>
        ///     Test to Update Finnisher Group  Types
        /// </summary>
        [TestMethod]
        public void UpdateFinnisherGroup_Test()
        {
            try {
                Models.PlantSetup.Finnisher.FinnisherGroup finnisherGroup = new Models.PlantSetup.Finnisher.FinnisherGroup();
                finnisherGroup.Id = 1;
                finnisherGroup.Name = "FinisherGroup1";
                int userId = 1;
                DateTime lastModifiedTimeStamp;
                finnisherGroup.EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                int result = _finisherGroupService.InsertFinnisherGroup(finnisherGroup, userId, out lastModifiedTimeStamp);
                finnisherGroup.Name = "FinisherGroup2";
                int update = _finisherGroupService.UpdateFinnisherGroup(finnisherGroup, userId, out lastModifiedTimeStamp);
                List<Models.PlantSetup.Finnisher.FinnisherGroup> FinnisherGroup = _finisherGroupService.FetchFinnisherGroupDetails(finnisherGroup.EcolabAccountNumber);
                if (FinnisherGroup[0].Name == "FinisherGroup2")
                {
                    Assert.IsTrue(true, "Data updated successfully");
                }
                else
                {
                    Assert.IsTrue(true, "Data Not updated successfully");
                }
            }
            catch
            {
                Assert.Fail();
            }
        }

        /// <summary>
        ///     Test to Delete Finnisher Group Types
        /// </summary>
        [TestMethod]
        public void DeleteFinnisherGroup_Test()
        {
            try {
                Models.PlantSetup.Finnisher.FinnisherGroup finnisherGroup = new Models.PlantSetup.Finnisher.FinnisherGroup();
                finnisherGroup.Id = 1;
                finnisherGroup.Name = "FinisherGroup1";
                int finnisherGroupId = 1;
                int userId = 1;
                string plantId = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                DateTime lastModifiedTimeStamp;
                int result = _finisherGroupService.InsertFinnisherGroup(finnisherGroup, userId, out lastModifiedTimeStamp);
                _finisherGroupService.DeleteFinnisherGroup(finnisherGroup, finnisherGroupId, userId, plantId, out lastModifiedTimeStamp);
                List<Models.PlantSetup.Finnisher.FinnisherGroup> FinnisherGroup = _finisherGroupService.FetchFinnisherGroupDetails(finnisherGroup.EcolabAccountNumber);
                if (FinnisherGroup.Count > 0)
                {
                    Assert.IsTrue(true, "Data deleted successfully");
                }
                else
                {
                    Assert.IsTrue(true, "Data Not deleted successfully");
                }
            }
            catch
            {
                Assert.Fail();
            }
        }
    }
}

