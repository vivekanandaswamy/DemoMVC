﻿using Ecolab.Services.Interfaces.PlantSetup.Finnisher;
using Ecolab.Services.PlantSetup.Finnisher;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup.FinisherTest
{
    [TestClass]
    public class FinnisherServiceTest : TestBase
    {
        private IFinnisherService _finnisherService;
        [TestInitialize]
        public void TestInitialize()
        {
            _finnisherService = new FinnisherService();
        }

        [TestMethod]
        /// <summary>
        ///     Test to Fetch Finnisher Types
        /// </summary>
        public void FetchFinnisherTypes_Test()
        {
            try {
                string plantId = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                List<Models.PlantSetup.Finnisher.FinnisherType> finnisher = _finnisherService.FetchFinnisherTypes(plantId);
                if (finnisher.Count > 0)
                {
                    Assert.IsTrue(true, "Data Fetched Successfully");
                }
                else
                {
                    Assert.IsTrue(true, "Data not Fetched Successfully");
                }
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        /// <summary>
        ///     Test to Insert Finnisher Types
        /// </summary>
        public void InsertFinnisher_Test()
        {
            try {
                Models.PlantSetup.Finnisher.Finnisher finisher = new Models.PlantSetup.Finnisher.Finnisher();
                finisher.FinnisherType = new Models.PlantSetup.Finnisher.FinnisherType();
                finisher.Name = "FinisherGroup1";
                finisher.FinnisherType.Id = 1;
                finisher.EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                finisher.Number = 12;
                int userId = 1;
                int finnisherGroupId = 1;
                DateTime lastModifiedTimestamp;
                int result = _finnisherService.InsertFinnisher(finisher, finnisherGroupId, userId, out lastModifiedTimestamp);
                if (result > 0)
                {
                    Assert.IsTrue(true, "Data Inserted Successfully");
                }
                else
                {
                    Assert.IsTrue(true, "Data not inserted Successfully");
                }
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        /// <summary>
        ///     Test to Update Finnisher Types
        /// </summary>
        public void UpdateFinnisher_Test()
        {
            try {
                Models.PlantSetup.Finnisher.Finnisher finisher = new Models.PlantSetup.Finnisher.Finnisher();
                finisher.FinnisherType = new Models.PlantSetup.Finnisher.FinnisherType();
                finisher.Name = "FinisherGroup1";
                finisher.FinisherId = 1;
                finisher.FinnisherType.Id = 1;
                finisher.EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                finisher.Number = 12;
                int userId = 1;
                int finnisherGroupId = 1;
                DateTime lastModifiedTimestamp;
                int insert = _finnisherService.InsertFinnisher(finisher, finnisherGroupId, userId, out lastModifiedTimestamp);
                finisher.Name = "Finisher_Group1";
                int updateResult = _finnisherService.UpdateFinnisher(finisher, userId, out lastModifiedTimestamp);
                List<Models.PlantSetup.Finnisher.FinnisherType> result = _finnisherService.FetchFinnisherTypes(EcolabAccountNumber);
                if (result[0].Name == "Finisher_Group1")
                {
                    Assert.IsTrue(true, "Data updated successfully");
                }
                else
                {
                    Assert.IsTrue(true, "Data Not updated successfully");
                }
            }
            catch
            {
                Assert.Fail();
            }
        }
        
        [TestMethod]
        /// <summary>
        ///     Test to Delete Finnisher Types
        /// </summary>
        public void DeleteFinnisher_Test()
        {
            try {
                Models.PlantSetup.Finnisher.Finnisher finisher = new Models.PlantSetup.Finnisher.Finnisher();
                finisher.FinnisherType = new Models.PlantSetup.Finnisher.FinnisherType();
                finisher.Name = "FinisherGroup1";
                finisher.FinisherId = 1;
                finisher.FinnisherType.Id = 1;
                string plantId = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
                finisher.Number = 12;
                int userId = 1;
                int finnisherNumber = 1;
                int finnisherGroupId = 1;
                DateTime lastModifiedTimestamp;
                int insert = _finnisherService.InsertFinnisher(finisher, finnisherGroupId, userId, out lastModifiedTimestamp);
                _finnisherService.DeleteFinnisher(finisher, finnisherNumber, userId, plantId, out lastModifiedTimestamp);
                List<Models.PlantSetup.Finnisher.FinnisherType> result = _finnisherService.FetchFinnisherTypes(plantId);
                if (result.Count > 0)
                {
                    Assert.IsTrue(true, "Data deleted Successfully");
                }
                else
                {
                    Assert.IsTrue(true, "Data not deleted Successfully");
                }
            }
            catch
            {
                Assert.Fail();
            }
        }

    }
}
