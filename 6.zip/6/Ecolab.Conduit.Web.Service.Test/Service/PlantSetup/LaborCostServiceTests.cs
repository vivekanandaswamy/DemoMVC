﻿// -----------------------------------------------------------------------
// <copyright file="LaborCostServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LaborCostServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.ShiftLabor;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Services.PlantSetup.ShiftLabor;

    [TestClass]
    public class LaborCostServiceTests : TestBase
    {
        /// <summary>
        ///     interface ILaborCostService
        /// </summary>
        private ILaborCostService laborCostService;

        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            laborCostService = new LaborCostService();
        }

        /// <summary>
        ///     Test for get the labor cost details
        /// </summary>
        [TestMethod]
        public void FetchLaborTypeCostDetails_Test()
        {
            List<LaborCost> result = laborCostService.FetchLaborTypeCostDetails("1");
            if (result != null)
            {
                Assert.IsTrue(true, "Get the lobor cost details.");
            }
            else
            {
                Assert.IsFalse(true, "Lobor cost details are not available.");
            }
        }

        /// <summary>
        ///     Test for update the labor cost details
        /// </summary>
        [TestMethod]
        public void SaveLaborCost()
        {
            var laborCost = new List<LaborCost> { new LaborCost { LaborTypeId = 1, Cost = 125, EcolabAccountNumber = "1" } };
            DateTime lastModifiedTimeStamp;
            int errorCode = 0;
            IEnumerable<LaborCost> result = laborCostService.SaveLaborCost(laborCost, "1", 1, out lastModifiedTimeStamp, out errorCode);
            Assert.IsTrue(result != null);
        }
    }
}