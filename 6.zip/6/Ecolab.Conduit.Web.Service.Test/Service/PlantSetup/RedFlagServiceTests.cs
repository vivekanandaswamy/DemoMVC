﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlagServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.RedFlag;
    using Services.Interfaces.PlantSetup;
    using Services.PlantSetup;
    using System.Configuration;
    using Models.PlantSetup;

    [TestClass]
    public class RedFlagServiceTests : TestBase
    {
        /// <summary>
        ///     interface I
        /// </summary>
        private IRedFlagService _redFlagService;

        //public RedFlagServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _redFlagService = new RedFlagService();
        }

        [TestMethod]
        public void FetchRedFlag_Test()
        {
            List<RedFlag> redFlag = _redFlagService.FetchRedFlagDetails(null, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(redFlag.Count > 0, "Received list of red flag details");
        }

        [TestMethod]
        public void FetchRedFlagItem_Test()
        {
            List<RedFlagItem> redFlagItem = _redFlagService.FetchRedFlagItemDetails(1, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(redFlagItem.Count > 0, "Received list of red flag item details");
        }

        [TestMethod]
        public void FetchRedFlagLocation_Test()
        {
            List<RedFlagLocation> redFlagLoc = _redFlagService.FetchRedFlagLocationDetails(1, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(redFlagLoc.Count > 0, "Received list of red flag item details");
        }

        /// <summary>
        ///     InsertRedFlag
        /// </summary>
        /// <param name="RedFlagList">the RedFlagList</param>
        /// <param name="Userid">the Userid</param>
        /// <param name="lastModifiedTimestamp">lastModifiedTimestamp</param>
        /// <returns>List of InsertRedFlag</returns>
        [TestMethod]
        public void InsertRedFlag_Test()
        {
            int userId = 1;
            DateTime lastModifiedTimestamp;
            RedFlag redFlag1 = new RedFlag { ItemId = 35, MinimumRange = 1, MaximumRange = 23, UOM = "uom", LocationId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), CategoryId = 2, PlantId = 15 };
            RedFlag redFlag2 = new RedFlag { ItemId = 4, MinimumRange = 1, MaximumRange = 23, UOM = "uom", LocationId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), CategoryId = 2, PlantId = 15 };
            List<RedFlag> redFlagsList=new List<RedFlag>();
            redFlagsList.Add(redFlag1);
            redFlagsList.Add(redFlag2);

            int? result =  _redFlagService.InsertRedFlag(redFlagsList, userId, out lastModifiedTimestamp);
            if (result != null)
            {
                Assert.IsTrue(true, "Red flag inserted successfully");
            }
            else
            {
                Assert.IsFalse(true, "Red flag insertion failed");
            }
        }

        /// <summary>
        ///    UpdateRedFlag_Test
        /// </summary>
        /// <param name="RedFlag">the RedFlag</param>
        /// <param name="Userid">the Userid</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of UpdateRedFlag</returns>
        [TestMethod]
        public void UpdateRedFlag_Test()
        {
            RedFlag redFlag1 = new RedFlag { ItemId = 35, MinimumRange = 1, MaximumRange = 23, UOM = "uom", LocationId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), CategoryId = 2, PlantId = 15 };
            RedFlag redFlag2 = new RedFlag { ItemId = 4, MinimumRange = 1, MaximumRange = 23, UOM = "uom", LocationId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), CategoryId = 2, PlantId = 15 };
            List<RedFlag> redFlagsList = new List<RedFlag>();
            DateTime lastModifiedTimestamp;
            int? result = _redFlagService.UpdateRedFlag(redFlagsList, 1, out lastModifiedTimestamp);
            if (result != null)
            {
                Assert.IsTrue(true, "Red flag updated successfully");
            }
            else
            {
                Assert.IsFalse(true, "Red flag update failed");
            }
        }

        /// <summary>
        ///    DeleteRedFlag_Test
        /// </summary>
        /// <param name="RedFlag">the RedFlag</param>
        /// <param name="Userid">the Userid</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>DeleteRedFlag</returns>
        [TestMethod]
        public void DeleteRedFlag_Test()
        {
            RedFlag redFlag = new RedFlag { ItemId = 35, MinimumRange = 1, MaximumRange = 23, UOM = "uom", LocationId = 1, EcolabAccountNumber = "040242802", CategoryId = 2, PlantId = 15, Id=11 };
            DateTime lastModifiedtimeStamp = DateTime.Now;
            int result = _redFlagService.DeleteRedFlag(redFlag, 1, out lastModifiedtimeStamp);
            Assert.IsNotNull(result, "Red flag deleted successfully");
        }

        /// <summary>
        ///    FetchFormulaCategoryOnLocationChange
        /// </summary>
        /// <param name="locationId">the location id</param>
        /// <param name="Id">the Id</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of FetchFormulaCategoryOnLocationChange</returns>
        [TestMethod]
        public void FetchFormulaCategoryOnLocationChange()
        {
            string EcolabAccountNumber= "";
            List<Models.Formula> redFlagLoc = _redFlagService.FetchFormulabyFormulaCategory(1,1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(redFlagLoc.Count > 0, "Received list of red flag item details");
        }

        /// <summary>
        ///     GetProductsOnFormulaChange
        /// </summary>
        /// <param name="locationId">the location id</param>
        /// <param name="formulaId">the formula Id</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of ProductsOnFormulaChange</returns>
        [TestMethod]
        public void GetProductsOnFormulaChange()
        {
            List<Models.PlantSetup.Chemical.ProductMaster> redFlagLoc = _redFlagService.FetchProductsByFormulaId(1, 1, "040242802");
            Assert.IsNotNull(redFlagLoc.Count > 0, "Received list of red flag item details");
        }

        /// <summary>
        ///     GetRedFlagMachineDetails_Test
        /// </summary>
        /// <param name="groupTypeId">the groupTypeId</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of RedFlagMachineDetails</returns>
        [TestMethod]
        public void GetRedFlagMachineDetails_Test()
        {
            int? groupTypeId = 1;
            string ecolabAccountNumber= ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<MachineSetup> result = _redFlagService.GetRedFlagMachineDetails(groupTypeId, ecolabAccountNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Gets list of Meters for the location
        /// </summary>
        /// <param name="locationId">the location id</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of Meters for the location passed</returns>
        [TestMethod]
        public void GetRedFlagMetersByLocation_Test()
        {
            int locationId = 1;
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int itemId = 1;
            List<Meter> parentMeters = _redFlagService.GetRedFlagMetersByLocation(locationId, ecolabAccountNumber, itemId);
            if (parentMeters.Count > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Gets list of Sensors for the location
        /// </summary>
        /// <param name="locationId">the location id</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of Sensors for the location passed</returns>
        [TestMethod]
        public void GetRedFlagSensorsByLocation_Test()
        {
            int locationId = 1;
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<Sensor> parentMeters = _redFlagService.GetRedFlagSensorsByLocation(locationId, ecolabAccountNumber);
            if (parentMeters.Count > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        // Removed the below test as GetMaxNumberOfRecords does not exists
        ///// <summary>
        /////     Get Max Number Of Records.
        ///// </summary>
        ///// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        ///// <returns>The integers.</returns>
        //[TestMethod]
        //public void GetMaxNumberOfRecords_Test()
        //{
        //    string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
        //    int maxNumberOfRecords = _redFlagService.GetMaxNumberOfRecords(ecolabAccountNumber);
        //    if (maxNumberOfRecords > 0)
        //    {
        //        Assert.IsTrue(true, "Data is available");
        //    }
        //    else
        //    {
        //        Assert.IsTrue(true, "Data is not available");
        //    }
        //}

        /// <summary>
        ///     Get the Formula Category.
        /// </summary>
        /// <param name="locationId">the locationId value</param>
        /// <param name="ecolabAccountNumber">Ecolab account number.</param>
        /// <returns>List FormulaCategory.</returns>
        [TestMethod]
        public void FetchFormulaCategorybyLocationId_Test()
        {
            int? locationId = 1;
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<Models.Formula> formulaCategory = _redFlagService.FetchFormulaCategorybyLocationId(locationId, ecolabAccountNumber);
            if (formulaCategory.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Get the red flag details for reSync.
        /// </summary>
        /// <param name="id">the red flag id.</param>
        /// <param name="ecolabAccNum">Ecolab account number.</param>
        /// <returns>List RedFlag values.</returns>
        [TestMethod]
        public void FetchRedFlagDetailsForReSync_Test()
        {
            int? id = 1;
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<RedFlag> redFlag = _redFlagService.FetchRedFlagDetailsForReSync(id, ecolabAccountNumber);
            if (redFlag.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Get the RedFlagCategory details.
        /// </summary>
        /// <returns>List RedFlagCategory.</returns>
        [TestMethod]
        public void FetchRedFlagCategoryData_Test()
        {
            List<RedFlagCategory> redFlagCategory = _redFlagService.FetchRedFlagCategoryData();
            if (redFlagCategory.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Get the RedFlagItemList details.
        /// </summary>
        /// <param name="categoryId">the categoryId value</param>
       /// <param name="ecolabAccNum">Ecolab account number.</param>
        /// <returns>RedFlagItemList.</returns>
        [TestMethod]
        public void GetRedFlagItemListByCategory_Test()
        {
            int categoryId = 1;
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<RedFlagItem> redFlagCategory = _redFlagService.GetRedFlagItemListByCategory(categoryId, ecolabAccountNumber);
            if (redFlagCategory.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchRedFlagDetailsForSync_Test()
        {
            int noOfRecordsToBeProcessed = 1;
            RedFlagService redFlagService = new RedFlagService();
            List<RedFlagData> redFlags = redFlagService.FetchRedFlagDetailsForSync(noOfRecordsToBeProcessed);
            if (redFlags.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }


    }
}