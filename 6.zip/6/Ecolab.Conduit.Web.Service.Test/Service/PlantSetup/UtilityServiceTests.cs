﻿// -----------------------------------------------------------------------
// <copyright file="UtilityServicetTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The UtilityServicetTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.PlantSetup
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Ecolab.Services.PlantSetup;
    using Services.Interfaces.PlantSetup;
    using Models.PlantSetup;
    using Models.Common;

    [TestClass]
    public class UtilityServiceTests : TestBase
    {
        private IUtilityService _utilityService;
        /// <summary>
        ///  Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _utilityService = new UtilityService();
        }
        /// <summary>
        /// Get Utility details
        /// </summary>
        [TestMethod]
        public void FetchUtilityDetails_test()
        {
            string accountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<Utility> utilityservice = _utilityService.GetUtilityDetails(accountNumber, null);
            Assert.IsNotNull(utilityservice.Count > 0, "Received list of utility details");
        }

        // commented below test as the procedure is adding a record with is deleted = false and making the test failed
        /// <summary>
        /// Save utility details
        /// </summary>
        [TestMethod]
        public void SaveUtilityDetails_Test()
        {
            Utility utility = new Utility
            {
                Comment = "Comments",
                DeviceModelDesc = "DeviceModelDesc",
                DeviceModelId = 1,
                DeviceName = "DeviceName",
                DeviceNoteDesc = "DeviceNoteDesc",
                DeviceNumber = 1,
                DeviceTypeDesc = "DeviceTypeDesc",
                DeviceTypeId = 1,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                GroupId = 1,
                Id = 1,
                InstallDate = DateTime.Now,
                IsDeleted = false,
                LastModifiedTimeStamp = DateTime.Now,
                LastModifiedTimestampAtCentral = DateTime.Now,
                LastSyncTime = DateTime.Now,
                MaxNumberOfRecords = 10,
                MyServiceCustWtrEnrgDvcGUID = new Guid("00000000-0000-0000-0000-000000000000")

            };

            int id = 1;
            DateTime lastModifiedtimeStamp = DateTime.Now;
            //int saveUtilityDet = _utilityService.SaveUtilityDetails(utility, id, out lastModifiedtimeStamp);
            //if (saveUtilityDet > 0)
            //{
            //    Assert.IsTrue(true, " utility details saved successfully");
            //}
            //else
            //{
            //    Assert.IsFalse(true, "utility details not saved");
            //}
        }
        /// <summary>
        /// Get device type details
        /// </summary>
        [TestMethod]
        public void FetchDeviceTypeDetails_Test()
        {
            List<DeviceType> devicetype = _utilityService.GetDeviceTypeDetails();
            Assert.IsNotNull(devicetype.Count > 0, "Received list of device type details");
        }
        /// <summary>
        /// Get Device type model details
        /// </summary>
        [TestMethod]
        public void FetchDeviceTypeModelDetails_Test()
        {
            int deviceId = 1;
            string ecolabAccountNumber = "040298214";
            List<DeviceModel> devicetypemodel = _utilityService.GetDeviceModelDetails(deviceId, ecolabAccountNumber);
            try
            {
                Assert.IsNotNull(devicetypemodel.Count > 0, "Received device type model details");
            }
            catch
            {
                Assert.IsNull("No data received on device type model");
            }
        }
        /// <summary>
        /// Get maximum number of records
        /// </summary>
        [TestMethod]
        public void FetchMaximumNoOfRecords_Test()
        {
            Ecolab.Data.Access.Database.ApplicationMode = Entities.ApplicationMode.Central;
            int records = _utilityService.GetMaxNumberOfRecords(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            if (records > 0)
            {
                Assert.IsTrue(true, "Records found");
            }
            else
            {
                Assert.IsFalse(true, "Records not found");
            }
        }
        /// <summary>
        /// Delete utility details
        /// </summary>
        [TestMethod]
        public void DeleteUtilityDetails_Test()
        {
            int deviceNumber = 999;
            int userId = 1;
            DateTime lastModifiedTimeStamp = DateTime.Now;
            int deleteUtilityDetails = _utilityService.DeleteUtilityDetails(deviceNumber, userId, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), out lastModifiedTimeStamp);
            if (deleteUtilityDetails > 0)
            {
                Assert.IsTrue(true, "Deleted Utility successfully");
            }
            else
            {
                Assert.IsFalse(true, "Deletion failed");

            }
        }
    }
}
