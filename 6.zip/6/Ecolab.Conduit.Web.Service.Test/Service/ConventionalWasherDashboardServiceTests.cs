﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionalWasherDashboardServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Visualization.ConventionalWasher;
    using Services.Interfaces.Visualization.ConventionalWasher;
    using Services.Visualization.ConventionalWasher;

    /// <summary>
    ///     Service Test ConventionalDashboard
    /// </summary>
    [TestClass]
    public class ConventionalWasherDashboardServiceTests : TestBase
    {
        /// <summary>
        ///     interface IConventionalWasherDashboardService
        /// </summary>
        private IConventionalWasherDashboardService convWasherDashboardService;

        [TestInitialize]
        public void TestInitialize()
        {
            convWasherDashboardService = new ConventionalWasherDashboardService();
        }

        /// <summary>
        ///     Fetchs the Washer Details.
        /// </summary>
        [TestMethod]
        public void FetchWasherData_Test()
        {
            int dashboardId = 1;
            List<ConventionalWasher> result = convWasherDashboardService.FetchWasherData(dashboardId, "2");
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetchs the Batch Details.
        /// </summary>
        [TestMethod]
        public void FetchBatchData_Test()
        {
            int dashboardId = 1;
            DateTime startDateTime = DateTime.Now;
            TimeSpan startTime = new TimeSpan(2, 0, 0);
            startDateTime = startDateTime.Date + startTime;
            startDateTime = TimeZoneInfo.ConvertTimeToUtc(startDateTime);

            DateTime endDateTime = DateTime.Now;
            TimeSpan endTime = new TimeSpan(3, 0, 0);
            endDateTime = endDateTime.Date + endTime;
            endDateTime = TimeZoneInfo.ConvertTimeToUtc(endDateTime);

            List<BatchDetails> result = convWasherDashboardService.FetchBatchData(dashboardId, "2", startDateTime, endDateTime, 10);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetchs the Break and timeline Details.
        /// </summary>
        [TestMethod]
        public void FetchTimeLineAndBreakData_Test()
        {
            string plantId = "2";
            int dashboardId = 1;
            List<BreakAndTimeline> result = convWasherDashboardService.FetchTimeLineAndBreakData(dashboardId,plantId);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}