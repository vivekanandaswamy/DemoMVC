﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.NavigationMenu
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.NavigationMenu;
    using Ecolab.Services.NavigationMenu;
    using Ecolab.Services.Interfaces.NavigationMenu;

    [TestClass]
    public class NavigationMenuServiceTest : TestBase
    {
        INavigationMenuService navigationMenuService;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            navigationMenuService = new NavigationMenuService();
        }

        /// <summary>
        /// MS Test case for FetchNavigationMenuDetails
        /// </summary>
        [TestMethod]
        public void FetchNavigationMenuDetails_Test()
        {
            string ecolabAccountNumber = "1";
            List<NavigationMenu> NavigationMenu = navigationMenuService.FetchNavigationMenuDetails(ecolabAccountNumber,string.Empty);

            if (NavigationMenu.Count > 0)
            {
                Assert.IsTrue(true, "Data is avialable");
            }
            else
            {
                Assert.IsTrue(true, "Data is not avialable");
            }
        }
    }
}
