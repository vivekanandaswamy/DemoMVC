﻿// -----------------------------------------------------------------------
// <copyright file="ManualRewashTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Manual Input Rewash Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Models.ManualInput.Rewash;
    using Services.Interfaces.ManualInput;
    using Services.ManualInput;
    using AutoMapper;

    /// <summary>
    ///     Service Test Manual Rewash
    /// </summary>
    [TestClass]
    public class ManualRewashTests : TestBase
    {
        /// <summary>
        ///     interface IManualRewashService
        /// </summary>
        private IManualRewashService manualRewashService;

        /// <summary>
        ///     class ManualRewashService
        /// </summary>
        ManualRewashService manualRewashServiceClass;
        
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            manualRewashService = new ManualRewashService();
            manualRewashServiceClass = new ManualRewashService();
        }

        [TestMethod]
        public void FetchManualRewash_Test()
        {
            int groupId = 1;
            int rewashReasonId = 1;
            int formulaId = 1;
            string date = "03/04/2015";
            List<ManualRewash> result = manualRewashService.FetchManualRewash(groupId, "1");
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchFormulasByGroupId_Test()
        {
            int groupId = 1;
            string date = "03/04/2015";
            IEnumerable<WashProgramSetup> result = manualRewashService.FetchFormulasByGroupId(groupId, "1", date);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchRewashReason_Test()
        {
            IEnumerable<RewashReason> result = manualRewashService.FetchRewashReason();
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        [TestMethod]
        public void SaveManualRewash_Test()
        {
            ManualRewash manualRewash = new ManualRewash { Value = 20, FormulaId = 1, WasherGroupId = 1, RewashReasonId = 1, RecordedDate = DateTime.Now, IsDeleted = false };
            int manualrewashId = 0;
            string result = manualRewashService.SaveManualRewash(manualRewash, "1", 1, out manualrewashId);

            if (result == "101")
            {
                Assert.AreEqual(result, "101");
            }
            else
            {
                Assert.AreEqual(result, "201");
            }
            
        }

        [TestMethod]
        public void UpdateManualRewash_Test()
        {
            ManualRewash manualRewash = new ManualRewash { Id = 1, Value = 40, FormulaId = 1, WasherGroupId = 2, RewashReasonId = 2, RecordedDate = DateTime.Now, IsDeleted = false };
            string result = manualRewashService.UpdateManualRewash(manualRewash, "1", 1);
            if (result == "401")
            {
                Assert.AreEqual(result, "401");
            }
            else
            {
                Assert.AreEqual(result, "401");
            }
        }

        [TestMethod]
        public void DeleteManualRewash_Test()
        {
            int rewashId = 1;
            string result = manualRewashService.DeleteManualRewash(rewashId, "1", 1);
            if (result == "401")
            {
                Assert.AreEqual(result, "401");
            }
            else
            {
                Assert.AreNotEqual(result, "401");
            }
        }

        [TestMethod]
        public void FetchManualRewashProductData_Test()
        {
            int rewashId = 1;
            string ecolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            IEnumerable<RewashProduct> result = manualRewashService.FetchManualRewashProductData(rewashId, ecolabAccNum);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        [TestMethod]
        public void SaveRewashReason_Test()
        {
            RewashReason rewashReason1 = new RewashReason
            {
                RewashReasonId = 1,
                Description = "test",
                LastModified = DateTime.Now
            };
            RewashReason rewashReason2 = new RewashReason
            {
                RewashReasonId = 2,
                Description = "test1",
                LastModified = DateTime.Now
            };
            List<RewashReason> rewashReasonColl = new List<RewashReason>();
            rewashReasonColl.Add(rewashReason1);
            rewashReasonColl.Add(rewashReason2);
            string ecolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            string result = manualRewashServiceClass.SaveRewashReason(rewashReasonColl);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}