﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatchDataTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualBatchData Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.ManualInput
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Models.PlantSetup;
    using Services.Interfaces.ManualInput;
    using Services.ManualInput;
    using System;
    using System.Configuration;

    /// <summary>
    ///     Test class for ManualBatchDataTests
    /// </summary>
    [TestClass]
    public class ManualBatchDataTests : TestBase
    {
        /// <summary>
        ///     interface IManualBatchDataService
        /// </summary>
        private IManualBatchDataService manualBatchDataService;

        //public ManualBatchDataTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            manualBatchDataService = new ManualBatchDataService();
        }

        
        [TestMethod]
        public void FetchBatchWasherGroupBySelectedDate_Test()
        {
            DateTime selectedDate = DateTime.Now;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<GroupType> result = manualBatchDataService.FetchBatchWasherGroupBySelectedDate(selectedDate, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchBatchByGroupId__Test()
        {
            int groupTypeId = 1;
            int washerId = 1;
            int programId = 1;
            DateTime startDate = DateTime.Now;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<ManualBatchData> result = manualBatchDataService.FetchBatchByGroupId(groupTypeId, washerId, programId, startDate, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void GetManualBatchDate_Test()
        {
            // ecolab account number shoud be a number 
            string ecolabAccNumber = "1";
            ManualBatchData result = manualBatchDataService.GetManualBatchDate(ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchBatchWasherGroups_Test()
        {
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<Models.WasherGroup.WasherGroup> result = manualBatchDataService.FetchBatchWasherGroups(ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchFormulasByGroupId_Test()
        {
            string groupTypeId = "1";
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<WashProgramSetup> result = manualBatchDataService.FetchFormulasByGroupId(groupTypeId, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchWashersByGroupId_Test()
        {
            string groupIds = "1";
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<MachineSetup> result = manualBatchDataService.FetchWashersByGroupId(groupIds, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchWasherGroupByDate_Test()
        {
            int batchId = 1;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            ManualBatchData result = manualBatchDataService.FetchBatchDetailsByBatchId(batchId, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchBatchByGroupId_Test()
        {
            string groupId = "2";
            int washerId = 1;
            int programId = 1;
            DateTime startDate = DateTime.Now;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<ManualBatchData> result = manualBatchDataService.FetchBatchData(groupId, washerId, programId,startDate, ecolabAccNumber,1,1);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchBatchWashersByGroupId_Test()
        {
            int groupId = 2;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<MachineSetup> result = manualBatchDataService.FetchBatchWashersByGroupId(groupId, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchBatchFormulasByGroupId_Test()
        {
            int groupId = 2;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<WashProgramSetup> result = manualBatchDataService.FetchBatchFormulasByGroupId(groupId, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchBatchDetailsByBatchId_Test()
        {
            int batchId = 1;
            string ecolabAccNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            ManualBatchData result = manualBatchDataService.FetchBatchDetailsByBatchId(batchId, ecolabAccNumber);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void UpdateManualBatch_Test()
        {
            List<ManualBatchData> manualBatchData = new List<ManualBatchData> { new ManualBatchData (){
				Id = 1,
				RecordingValue = 25
			}};
            string result = manualBatchDataService.UpdateManualBatch(manualBatchData, "1", 1);
            if (result == "201")
            {
                Assert.AreEqual(result, "201");
            }
            else
            {
                Assert.IsTrue(true, "Data is not updated");
            }
        }
    }
}