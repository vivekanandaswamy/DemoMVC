﻿// -----------------------------------------------------------------------
// <copyright file="MnaualLaborTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualBatchData Tests </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Web.Service.Test.Service.ManualInput
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput.ManualLabor;
    using Models.PlantSetup;
    using Services.Interfaces.ManualInput;
    using Services.ManualInput;
    using System;
    using System.Configuration;
    using Services.Interfaces.ManualInputs;
    using Services.ManualInputs;
    using System.Linq;

    [TestClass]
    public class MnaualLaborTests : TestBase
    {

        private IManualLaborService manualLaborService;


        [TestInitialize]
        public void TestInitialize()
        {
            manualLaborService = new ManualLaborService();
        }

        /// <summary>
        ///     Get Manual Labor Details
        /// </summary>
        /// <param name="LocationId">LocationId</param>
        /// <param name="type">type</param>
        [TestMethod]
        public void GetLaborCost_Test()
        {
            int locationId = 1;
            int type = 1;
            int result = manualLaborService.GetLaborCost(locationId, type);
            if (result > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Get Manual Labor Details
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        /// <param name="manualLabor">ManualLabor Object</param>
        /// <param name="LocationId">LocationId</param>
        [TestMethod]
        public void GetManualLaborDetails_Test()
        {
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int manHourTypeId = 1;
            int locationId = 1;
            IEnumerable<ManualLabor> manualLaborList = manualLaborService.GetManualLaborDetails(ecolabAccountNumber, manHourTypeId, locationId);
            int count = 0;
            foreach (var manualLaborListData in manualLaborList)
            {
                count++;
            }
            if (count > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }

        }

        /// <summary>
        ///     Save Manual Labor Details
        /// </summary>
        /// <param name="manualLabor">ManualLabor Object</param>
        /// <param name="userId">User Id</param>
        [TestMethod]
        public void SaveManualLaborDetails_Test()
        {
            ManualLabor manualLabor = new ManualLabor();
            manualLabor.LocationId = 2725;
            manualLabor.ManHourTypeId = 1;
            manualLabor.StartDate = DateTime.Now;
            manualLabor.EndDate = DateTime.Now;
            manualLabor.LaborCost = 5;
            manualLabor.AllocatedManHours = 2;
            int userId = 1;
            manualLabor.EcolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int result = manualLaborService.SaveManualLaborDetails(manualLabor, userId);
            if (result > 0)
            {
                Assert.IsTrue(true, "Data has been inserted");
            }
            else
            {
                Assert.IsTrue(true, "Data has not been inserted");
            }
        }

        /// <summary>
        ///     Delete Manual Labor Details
        /// </summary>
        /// <param name="manualLaborId">ManualLabor Id</param>
        /// <param name="userId">User Id</param>
        [TestMethod]
        public void DeleteManualLabor()
        {
            ManualLabor manualLabor = new ManualLabor();
            manualLabor.LocationId = 2725;
            manualLabor.ManHourTypeId = 1;
            manualLabor.StartDate = DateTime.Now;
            manualLabor.EndDate = DateTime.Now;
            manualLabor.LaborCost = 5;
            manualLabor.AllocatedManHours = 2;
            int userId = 1;
            int count = 0;
            manualLabor.EcolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int id = manualLaborService.SaveManualLaborDetails(manualLabor, userId);
            manualLaborService.DeleteManualLabor(id, userId);
            IEnumerable<ManualLabor> manualLaborList = manualLaborService.GetManualLaborDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), manualLabor.ManHourTypeId, manualLabor.LocationId);
            foreach (var manualLaborListData in manualLaborList)
            {
                count++;
            }
            if (count > 0)
            {
                Assert.IsTrue(true, "Data is not deleted");
            }
            else
            {
                Assert.IsTrue(true, "Data is deleted");
            }           
        }

        /// <summary>
        ///     Updates Manual Labor Details
        /// </summary>
        /// <param name="manualLabor">ManualLabor Object</param>
        /// <param name="userId">User Id</param>
        [TestMethod]
        public void UpdateManualLaborDetails()
        {
            ManualLabor manualLabor = new ManualLabor();
            manualLabor.LocationId = 2725;
            manualLabor.ManHourTypeId = 1;
            manualLabor.StartDate = DateTime.Now;
            manualLabor.EndDate = DateTime.Now;
            manualLabor.LaborCost = 5;
            manualLabor.AllocatedManHours = 2;
            int userId = 1;
            manualLabor.EcolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int id = manualLaborService.SaveManualLaborDetails(manualLabor, userId);
            manualLabor.AllocatedManHours = 2;
            manualLaborService.UpdateManualLaborDetails(manualLabor, userId);           
            List<ManualLabor> manualLaborList = manualLaborService.GetManualLaborDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), manualLabor.ManHourTypeId, manualLabor.LocationId).ToList();
            
            if (manualLaborList[0].AllocatedManHours == 2)
            {
                Assert.IsTrue(true, "Data has  been updated");
            }
            else
            {
                Assert.IsTrue(true, "Data has not been updated");
            }
        }
    }
}
