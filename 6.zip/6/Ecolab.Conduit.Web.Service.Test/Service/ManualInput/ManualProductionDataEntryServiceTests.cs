﻿// -----------------------------------------------------------------------
// <copyright file="ManualProductionDataEntryServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualProductionDataEntryService Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.ManualInput
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Models.ManualInput.Production;
    using Models.PlantSetup;
    using Services.Interfaces.ManualInput;
    using Services.ManualInput;
    using System.Configuration;

    /// <summary>
    /// </summary>
    [TestClass]
    public class ManualProductionDataEntryServiceTests : TestBase
    {
        /// <summary>
        ///     interface IManualProductionDataEntryService
        /// </summary>
        private IManualProductionDataEntryService manualProductionService;

        //public ManualProductionDataEntryServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            manualProductionService = new ManualProductionDataEntryService();
        }

        [TestMethod]
        public void UpdateManualProductionData_Test()
        {
            string groupId = "3";
            int washerId = 1;
            int fomulaId = 1;
            int userId = 1;
            string ecolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<ManualProduction> manualProduction = manualProductionService.FetchProductionData(groupId, washerId, fomulaId, Convert.ToDateTime("2015 - 11 - 19 18:30:00.000"), ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1, 10);
            string result = manualProductionService.UpdateManualProductionData(manualProduction, ecolabAccNum, userId);
            
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchUnits_Test()
        {
            string ecolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            string result = manualProductionService.FetchUnits(ecolabAccNum);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchManualBatchData_Test()
        {
            string groupId = "3";
            int washerId = 1;
            int fomulaId = 1;
            List<ManualProduction> result = manualProductionService.FetchProductionData(groupId, washerId, fomulaId,Convert.ToDateTime("2015 - 11 - 19 18:30:00.000"),ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1, 10);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchWasherGroups_Test()
        {
            List<GroupType> result = manualProductionService.FetchWasherGroups("1");
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchWashersByGroupId_Test()
        {
            List<MachineSetup> result = manualProductionService.FetchWashersByGroupId("1", "1");
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void FetchFormulasByGroupId_Test()
        {
            List<WashProgramSetup> result = manualProductionService.FetchFormulasByGroupId("1", "1");
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        [TestMethod]
        public void SaveManualProduction_Test()
        {
            ManualProduction manualProduction;
            manualProduction = new ManualProduction { WasherGroupId = 1, WasherId = 1, FormulaId = 1, RecordedDate = DateTime.Now, Value = 12 };
            int productionId = 0;
            string result = manualProductionService.SaveManualProduction(manualProduction, "1", 1, out productionId);
            if (result == "101")
            {
                Assert.IsTrue(true, "Saved successfully");
            }
            else
            {
                Assert.IsTrue(true, "Saved Failed");
            }
        }

        [TestMethod]
        public void UpdateManualProduction_Test()
        {
            ManualProduction manualProduction;
            manualProduction = new ManualProduction { Id = 1, WasherGroupId = 1, WasherId = 1, FormulaId = 1, RecordedDate = DateTime.Now, Value = 15 };
            string result = manualProductionService.UpdateManualProduction(manualProduction, "1", 1);
            if (result == "201")
            {
                Assert.IsTrue(true, "Update successfully");
            }
            else
            {
                Assert.IsTrue(true, "Update Failed");
            }
        }

        [TestMethod]
        public void DeleteManualProduction_Test()
        {
            string result = manualProductionService.DeleteManualProduction(2, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1);
            if (result == "301")
            {
                Assert.IsTrue(true, "Delete successfully");
            }
            else
            {
                Assert.IsTrue(true, "Delete Failed");
            }
        }
    }
}