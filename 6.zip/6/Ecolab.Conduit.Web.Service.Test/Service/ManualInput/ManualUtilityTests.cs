﻿namespace Ecolab.Conduit.Web.Service.Test.Service.ManualInput
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ManualInput;
    using Services.Interfaces.ManualInput;
    using Services.ManualInput;

    [TestClass]
    public class ManualUtilityTests : TestBase
    {
        #region "Properties"

        /// <summary>
        ///     interface IManualRewashService
        /// </summary>
        private IManualUtilityService _manualUtilityService;

        #endregion

        //public ManualUtilityTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _manualUtilityService = new ManualUtilityService();
        }

        [TestMethod]
        public void FetchManualUtility_Tests()
        {
            List<ManualUtility> result = _manualUtilityService.FetchManualUtility("1");
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        [TestMethod]
        public void SaveManualUtility_Tests()
        {
            ManualUtility manualUtility = new ManualUtility { MeterId = 1, RecordedDate = DateTime.Now, Value = 20, Usage = 20 };
            int laborId = 0;
            string result = _manualUtilityService.SaveManualUtility(manualUtility, "1", 1, out laborId);
            Assert.AreEqual(result, "101");
        }

        [TestMethod]
        public void UpdateManualUtility_Tests()
        {
            ManualUtility manualUtility = new ManualUtility { Id = 1, RecordedDate = DateTime.Now, Value = 40, Usage = 40 };
            string result = string.Empty;//_manualUtilityService.UpdateManualUtility(manualUtility, "1", 1);
            if (result == "201")
            {
                Assert.IsTrue(true, "Update successfully");
            }
            else
            {
                Assert.IsTrue(true, "Update Failed");
            }
        }

        [TestMethod]
        public void DeleteManualUtility_Tests()
        {
            int Id = 1;
            string result = _manualUtilityService.DeleteManualUtility(Id, "1", 1);
            if (result == "301")
            {
                Assert.IsTrue(true, "Delete successfully");
            }
            else
            {
                Assert.IsTrue(true, "Delete Failed");
            }
        }
    }
}