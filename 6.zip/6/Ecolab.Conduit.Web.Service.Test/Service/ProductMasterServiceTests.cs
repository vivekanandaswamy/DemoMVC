﻿// -----------------------------------------------------------------------
// <copyright file="ProductMasterServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Master Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Services.Interfaces;
    using Ecolab.Services;
    using Ecolab.Models.PlantSetup.Chemical;
    using Ecolab.Conduit.Library.Enums;
    using Models;
    using System.Configuration;

    [TestClass]
    public class ProductMasterServiceTests : TestBase
    {
        IProductMasterService productMasterService;

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            productMasterService = new ProductMasterService();
        }

        /// <summary>
        /// MS unit test for FetchPlantChemicalList
        /// </summary>
        [TestMethod]
        public void FetchPlantChemicalList_Test()
        {
            string ecolabAccNum = "1";
            List<ProductMaster> productMaster = productMasterService.FetchPlantChemicalList(ecolabAccNum);

            if (productMaster.Count > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for SavePlantChemicalDetails
        /// </summary>
        [TestMethod]
        public void SavePlantChemicalDetails_Test()
        {
            ProductMaster prodMaster = new ProductMaster()
            {
                ProductId = 1,
                Cost = 10,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                IncludeinCI = true,
                InventoryExpense = "1"
            };

            int userId = 1;
            DateTime lastModifiedTimeStamp;
            int result = productMasterService.SavePlantChemicalDetails(prodMaster, userId, out lastModifiedTimeStamp);

            if (result > 0)
            {
                Assert.IsTrue(true, "Data is saved");
            }
            else
            {
                Assert.IsTrue(true, "Data is not saved");
            }
        }

        /// <summary>
        /// MS unit test for FetchChemicalList
        /// </summary>
        [TestMethod]
        public void FetchChemicalList_Test()
        {
            string searchTerm = "nam";
            string ecolabAccNum = "1";

            List<Chemicals> chemicals = productMasterService.FetchChemicalList(searchTerm, ecolabAccNum);

            if (chemicals.Count > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for FetchUsedChemicalList
        /// </summary>
        [TestMethod]
        public void FetchUsedChemicalList_Test()
        {
            string searchTerm = "nam";
            string ecolabAccNum = "1";

            List<Chemicals> chemicals = productMasterService.FetchUsedChemicalList(searchTerm, ecolabAccNum, 0);

            if (chemicals.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for UpdateChemicalDetails
        /// </summary>
        [TestMethod]
        public void UpdateChemicalDetails_Test()
        {
            ProductMaster prodMaster = new ProductMaster()
            {
                Id = 1,
                ProductId = 1,
                Cost = 15,
                EcolabAccountNumber = "1",
                IncludeinCI = true,
                InventoryExpense = "1"
            };

            int userId = 1;
            DateTime lastModifiedTimeStamp;
            int result = productMasterService.UpdateChemicalDetails(prodMaster, userId, out lastModifiedTimeStamp);

            if (result > 0)
            {
                Assert.IsTrue(true, "Data is updated");
            }
            else
            {
                Assert.IsTrue(true, "Data is not updated");
            }
        }

        /// <summary>
        /// MS unit test for DeleteChemicalDetails
        /// </summary>
        [TestMethod]
        public void DeleteChemicalDetails_Test()
        {
            ProductMaster prodMaster = new ProductMaster()
            {
                Id = 1,
                EcolabAccountNumber = "1"
            };

            int userId = 1;
            DateTime lastModifiedTimeStamp;
            int result = productMasterService.DeleteChemicalDetails(prodMaster, userId, out lastModifiedTimeStamp);

            if (result > 0)
            {
                Assert.IsTrue(true, "Data is updated");
            }
            else
            {
                Assert.IsTrue(true, "Data is not updated");
            }
        }

        /// <summary>
        /// MS unit test for GetPlantUtilityEnergyPriceUnits
        /// </summary>
        [TestMethod]
        public void GetPlantUtilityEnergyPriceUnits_Test()
        {
            List<PlantUtilityUnitTypes> list = productMasterService.GetPlantUtilityEnergyPriceUnits("1", 1);

            if (list.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for GetDimensionTypes
        /// </summary>
        [TestMethod]
        public void GetDimensionTypes_Test()
        {
            String result = productMasterService.GetDimensionTypes("1");

            if (result != null)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for GetMaxNumberOfRecords
        /// </summary>
        [TestMethod]
        public void GetMaxNumberOfRecords_Test()
        {
            Ecolab.Data.Access.Database.ApplicationMode = Entities.ApplicationMode.Central;
            int result = productMasterService.GetMaxNumberOfRecords("1");

            if (result > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for ValidateAndSavePlantChemicalDetails
        /// </summary>
        [TestMethod]
        public void ValidateAndSavePlantChemicalDetails_Test()
        {
            //Ecolab.Data.Access.Database.ApplicationMode = Entities.ApplicationMode.Central;
            ProductMaster prodMaster = new ProductMaster()
            {
                Id = 1,
                ProductId = 1,
                Cost = 15,
                EcolabAccountNumber = "1",
                IncludeinCI = true,
                InventoryExpense = "1"
            };
            DateTime dt;
            int errorcode = -1;
            int result = productMasterService.ValidateAndSavePlantChemicalDetails(prodMaster, 1, TcdAdminMessageTypes.TcdAddPlantChemical, out errorcode, out dt);

            if (result == 51030)
            {
                Assert.IsTrue(true, "Records not in sync");
            }
            else if (result == 60000)
            {
                Assert.IsTrue(true, "timestamp");
            }
            else if (result == 0)
            {
                Assert.IsTrue(true, "success");
            }
        }

        /// <summary>
        /// MS unit test for GetUnUsedPlantChemicalList
        /// </summary>
        [TestMethod]
        public void GetUnUsedPlantChemicalList_Test()
        {
            string EcolabAccountNumber = "1";
            int washerGroupId = 1;
            List<Chemicals> list = productMasterService.GetUnUsedPlantChemicalList(EcolabAccountNumber, washerGroupId);

            if (list.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for CheckWasherGroupForProduct
        /// </summary>
        [TestMethod]
        public void CheckWasherGroupForProduct_Test()
        {
            string EcolabAccountNumber = "1";
            int washerGroupId = 1;
            List<int> list = productMasterService.CheckWasherGroupForProduct(washerGroupId, EcolabAccountNumber);

            if (list.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for FetchWasherDosingProductList
        /// </summary>
        [TestMethod]
        public void FetchWasherDosingProductList_Test()
        {
            string EcolabAccountNumber = "1";
            int washerGroupId = 1;
            IEnumerable<Chemicals> prodlist = productMasterService.FetchWasherDosingProductList(EcolabAccountNumber, washerGroupId);
            int count = 0;
            foreach (var item in prodlist)
            {
                count++;
            }
            if (count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for SaveSubstitueChemical
        /// </summary>
        [TestMethod]
        public void SaveSubstitueChemical_Test()
        {

            SubstituteChemical sbusChemcial = new SubstituteChemical() { WasherGroupId = 1, OldProductId = 1, NewProductId = 1, EcolabAccountNumber = "1", ScalarAmountPercent = 2, ScalarOption = 1, PlantId = 1, WasherGroupIds = new List<int>() { 1 }, Id = 1 };
            int userid = 1;
            int result = productMasterService.SaveSubstitueChemical(sbusChemcial, userid);
            if (result > 0)
            {
                Assert.IsTrue(true, "Data is saved");
            }
            else
            {
                Assert.IsTrue(true, "Data is not saved");
            }
        }

        /// <summary>
        ///MS unit test for FetchPlantProductStandardPriceForReSync 
        /// </summary>
        [TestMethod]
        public void FetchPlantProductStandardPriceForReSync_Test()
        {
            string ecolabAccNum = "1";
            bool isDeleted = false;
            ProductMasterService pms = new ProductMasterService();
            List<ProductStandardPrice> list = pms.FetchPlantProductStandardPriceForReSync(ecolabAccNum);
            if (list.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for FetchPlantChemicalListForResync
        /// </summary>
        [TestMethod]
        public void FetchPlantChemicalListForResync_Test()
        {
            string ecolabAccNum = "1";
            bool isDeleted = false;
            ProductMasterService pms = new ProductMasterService();

            List<ProductMaster> list = pms.FetchPlantChemicalListForResync(ecolabAccNum);
            if (list.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS unit test for SavePlantChemicalDetailsForFirstTimeSync
        /// </summary>
        [TestMethod]
        public void SavePlantChemicalDetailsForFirstTimeSync_Test()
        {
            ProductMaster prodMaster = new ProductMaster() { AcceptedDeviation = 0.0M, Cost = 10, DensityFactor = 0.0M, DensityFactorUOMId = 0, EcolabAccountNumber = "040242802", Id = 1, IsDelete = false, IsSelected = false, LastModifiedTimeStamp = DateTime.Now, MaxNumberOfRecords = 0, MyServiceProdCatId = 0, MyServiceProdId = 7248, Name = "1 % BLEACH", ProductId = 7216, SKU = "G6012202", Volume = 0 };

            int userid = 0;
            try
            {
                ProductMasterService pms = new ProductMasterService();
                pms.SavePlantChemicalDetailsForFirstTimeSync(prodMaster, userid);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }

        }

        /// <summary>
        /// MS unit test for SaveProductStandardPriceForFirstTimeSync
        /// </summary>
        [TestMethod]
        public void SaveProductStandardPriceForFirstTimeSync_Test()
        {
            ProductStandardPrice productStandardPrice = new ProductStandardPrice() { Id = 1, EcolabAccountNumber = "040242802", ProductId = 123, ListPrice = 52.12, ContractPrice = 10, CountryPrice = 12, LastModifiedTimeStamp = DateTime.Now };

            int userid = 0;
            try
            {
                ProductMasterService pms = new ProductMasterService();
                pms.SaveProductStandardPriceForFirstTimeSync(productStandardPrice, userid);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }

        }

        /// <summary>
        /// MS unit test for SaveMyServiceProductStandardPrice
        /// </summary>
        [TestMethod]
        public void SaveMyServiceProductStandardPrice_Test()
        {
            ProductStandardPrice productStandardPrice = new ProductStandardPrice() { Id = 1, EcolabAccountNumber = "040242802", ProductId = 123, ListPrice = 52.12, ContractPrice = 10, CountryPrice = 12, LastModifiedTimeStamp = DateTime.Now };
            DateTime lastModifiedTimeStamp = DateTime.Now;
            ProductMasterService pms = new ProductMasterService();
            int result = pms.SaveMyServiceProductStandardPrice(productStandardPrice, out lastModifiedTimeStamp);
            if (result > 0)
            {
                Assert.IsTrue(true, "Data is saved");
            }
            else
            {
                Assert.IsTrue(true, "Data is not saved");
            }

        }


        [TestMethod]
        public void SaveProductCategoryDetails_Test()
        {
            ProductMaster prodMaster = new ProductMaster()
            {
                ProductId = 1,
                Cost = 10,
                EcolabAccountNumber = "040242802",
                IncludeinCI = true,
                InventoryExpense = "1",
                MyServiceProdId = 7248,
                ProductCategoryId = 1,
                ProductcategoryName = "Test Category"

            };

            List<ProductMaster> myServiceProductCategoryList = new List<ProductMaster>();
            myServiceProductCategoryList.Add(prodMaster);
            try
            {
                ProductMasterService pms = new ProductMasterService();
                pms.SaveProductCategoryDetails(myServiceProductCategoryList);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }


        }

        /// <summary>
        ///MS unit test for SaveMyServiceProductMasterDetails
        /// </summary>
        [TestMethod]
        public void SaveMyServiceProductMasterDetails_Test()
        {
            ProductMaster prodMaster = new ProductMaster()
            {
                ProductId = 5494547,
                Cost = 10,
                EcolabAccountNumber = "040242802",
                IncludeinCI = true,
                InventoryExpense = "1",
                MyServiceProdId = 7298,
                Name = "therm",
                sp_SP = "therm",
                nl_BE = "therm",
                nr_NR = "therm"

            };

            List<ProductMaster> products = new List<ProductMaster>();
            products.Add(prodMaster);
            try
            {
                ProductMasterService pms = new ProductMasterService();
                pms.SaveMyServiceProductMasterDetails(products);
            }
            catch (Exception e)
            {
                Assert.Fail();
            }
        }


    }
}
