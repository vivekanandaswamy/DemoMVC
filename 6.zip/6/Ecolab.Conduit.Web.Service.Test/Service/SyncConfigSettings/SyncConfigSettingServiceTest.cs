﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.SyncConfigSettings
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Services.SyncConfigSettingService;
    using Ecolab.Services.Interfaces.SyncConfigSettings;    

    [TestClass]
    public class SyncConfigSettingServiceTest : TestBase
    {
        ISyncConfigSettingService syncConfigSettingService;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            syncConfigSettingService = new SyncConfigSettingService();
        }

        /// <summary>
        /// Test Case for GetAppConfigKeyValueDetails
        /// </summary>
        [TestMethod]
        public void GetAppConfigKeyValueDetails_Test()
        {
            string typeOfService = "SyncQueuedata";
            Dictionary<string, string> dicConfigSettings = new Dictionary<string, string>();
            dicConfigSettings = syncConfigSettingService.GetAppConfigKeyValueDetails(typeOfService);

            if (dicConfigSettings.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for UpdateConfiguration
        /// </summary>
        [TestMethod]
        public void UpdateConfiguration_Test()
        {
            string serviceName = "SyncLogFile";
            string keyName = "PortNumber";
            string value = "40";
            int status;
            status = syncConfigSettingService.UpdateConfiguration(serviceName, keyName, value);

            if (status > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }        
    }
}
