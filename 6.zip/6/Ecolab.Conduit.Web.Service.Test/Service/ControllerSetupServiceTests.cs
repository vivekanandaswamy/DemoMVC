﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Services.ControllerSetup;
    using Services.Interfaces.ControllerSetup;
    using ControllerModel = Models.ControllerSetup;
    using System.Configuration;

    /// <summary>
    ///     ControllerSetupServiceTests
    /// </summary>
    [TestClass]
    public class ControllerSetupServiceTests : TestBase
    {
        /// <summary>
        ///     interface IControllerSetupService
        /// </summary>
        private IControllerSetupService controllerSetupService;

        //public ControllerSetupServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     get test for controller details
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            controllerSetupService = new ControllerSetupService();
        }

        /// <summary>
        ///     Get Controller MetaData
        /// </summary>
        [TestMethod]
        public void GetControllerSetupMetaDataTest()
        {
            List<ControllerModel.MetaData> controllerSetupMetaData = controllerSetupService.GetControllerSetupMetadata(1, 1, 2, 9);
            Assert.IsNotNull(controllerSetupMetaData.Count >= 0, "Received Controller Meta Data Detail.");
        }

        /// <summary>
        ///     Get Controller Advance MetaData
        /// </summary>
        [TestMethod]
        public void GetControllerSetupAdvanceMetaDataTest()
        {
            List<ControllerModel.MetaData> controllerSetupMetaData = controllerSetupService.GetControllerSetupAdvanceMetadata(3, 48, "1");
            Assert.IsNotNull(controllerSetupMetaData.Count >= 0, "Received Controller Advance Meta Data Detail.");
        }

        /// <summary>
        ///     Get Controller Advance MetaData
        /// </summary>
        [TestMethod]
        public void GetControllerSetupAdvanceMetaDataWithValuesTest()
        {
            List<ControllerModel.MetaData> controllerSetupMetaData = controllerSetupService.GetControllerSetupAdvanceMetadataWithValues(3, 47, "1");
            Assert.IsNotNull(controllerSetupMetaData.Count >= 0, "Received Controller Advance Meta Data Detail.");
        }

        /// <summary>
        ///     Get Controller MetaData with Values
        /// </summary>
        [TestMethod]
        public void GetControllerSetupModelDataWithValuesTest()
        {
            List<ControllerModel.MetaData> controllerSetupMetaData = controllerSetupService.GetControllerSetupMetadataWithValues(3, 48, "1", 9);
            Assert.IsNotNull(controllerSetupMetaData.Count >= 0, "Received Controller Meta Data with Values.");
        }

        /// <summary>
        ///     Get Controller MetaData with Values
        /// </summary>
        [TestMethod]
        public void IsSetupAdvanceDataExistTest()
        {
            bool IsExist = controllerSetupService.IsSetupAdvanceDataExist(3, 48, "1");
            Assert.IsTrue((IsExist || IsExist == false));
        }

        /// <summary>
        ///     Get Controller Details
        /// </summary>
        [TestMethod]
        public void GetControllerDetailsTest()
        {
            List<ControllerModel.Controller> controller = controllerSetupService.GetControllerDetails("1");
            Assert.IsNotNull(controller.Count >= 0, "Received Controller Details.");
        }

        /// <summary>
        ///     Get Controller Details When CanControlTunnel is passed
        /// </summary>
        [TestMethod]
        public void GetControllerDetails_When_CanControlTunnel_Passed_Test()
        {
            List<ControllerModel.Controller> controller = controllerSetupService.GetControllerDetails("1", true);
            Assert.IsNotNull(controller.Count >= 0, "Received Controller Details.");
        }

        /// <summary>
        ///     Get Controller Details By Id
        /// </summary>
        [TestMethod]
        public void GetControllerDetailsByIdTest()
        {
            ControllerModel.Controller controller = controllerSetupService.GetControllerDetailById(2279, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(controller, "Received Controller Details.");
        }

        [TestMethod]
        public void GetControllerTypesDetailsTest()
        {
            List<ControllerModel.ControllerType> controllerType = controllerSetupService.GetControllerTypesDetails(1);
            Assert.IsNotNull(controllerType.Count >= 0, "Received Controller Type Details.");
        }

        /// <summary>
        ///     Get Controller Models Detail
        /// </summary>
        [TestMethod]
        public void GetControllerModelDetailsTest()
        {
            List<ControllerModel.ControllerModel> controllerTypes = controllerSetupService.GetControllerModelsDetails(1);
            Assert.IsNotNull(controllerTypes.Count >= 0, "Received Controller Model Detail.");
        }

        /// <summary>
        ///     Save Controller Setup Details
        /// </summary>
        [TestMethod]
        public void SaveControllerSetupDataTest()
        {
            var controllerSetupData = new List<ControllerModel.ControllerSetupData> { new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 1, FieldName = "ControllerNumber", Value = "1123" }, new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 2, Value = "ControllerSupplierTest" }, new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 4, FieldName = "ControllerVersion", Value = "Ver1" }, new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 5, FieldName = "InstallDate", Value = "8/28/2014 10:33 PM" }, new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 6, Value = "Test1" }, new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 7, Value = "Test2" }, new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 8, Value = "Test3" }, new ControllerModel.ControllerSetupData { EcolabAccountNumber = "1", ControllerModelId = 100, ControllerTypeId = 1, FieldGroupId = 1, FieldId = 9, Value = "Test4" } };
            DateTime lastModifiedTimeStamp;
            int controllerId = controllerSetupService.SaveControllerSetupData(controllerSetupData, 1, out lastModifiedTimeStamp);
        }

        ///// <summary>
        /////     Save Controller List Details
        ///// </summary>
        //[TestMethod]
        //public void SaveControllerListDataTest()
        //{
        //    DateTime date = DateTime.Now.AddDays(-30);

        //    ControllerModel.Controller ControllerListData = new ControllerModel.Controller { ControllerVersion = "ABC", InstallDateAsString = "Mon Sep 15 2014 00:00:00 GMT+0530 (India Standard Time)", InstallDate = date };

        //    DateTime lastModifiedTimeStamp;
        //    controllerSetupService.UpdateControllerListData(ControllerListData, 1, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), out lastModifiedTimeStamp);
        //}

        /// <summary>
        ///     Update Controller Setup Details
        /// </summary>
        [TestMethod]
        public void UpdateControllerSetupDataTest()
        {
            var controllerSetupData = new List<ControllerModel.ControllerSetupData> { new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 28, FieldName = "ControllerNumber", Value = "5" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 26, FieldName = "ControllerSupplier", Value = "ControllerSupplierTest" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 34, FieldName = "InstallDate", Value = "8/28/2014 10:33 PM" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 21, Value = "Test1" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 22, Value = "Test2" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 23, Value = "Test3" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 27, Value = "Test4" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 30, Value = "Test5" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 33, Value = "Test6" }, new ControllerModel.ControllerSetupData { ControllerId = 44, ControllerModelId = 22, FieldGroupId = 7, FieldId = 35, Value = "Test7" } };
            DateTime lastModifiedTimeStamp;
            controllerSetupService.UpdateControllerSetupData(controllerSetupData, 1, out lastModifiedTimeStamp);
        }

        /// <summary>
        ///     Delete Controller List Details
        /// </summary>
        [TestMethod]
        public void DeleteControllerListDataTest()
        {
            int controllerId = 9;
            int userId = 1;
            DateTime lastModifiedTimeStamp;
            controllerSetupService.DeleteControllerListData(controllerId, userId, "1", out lastModifiedTimeStamp);
        }
    }
}