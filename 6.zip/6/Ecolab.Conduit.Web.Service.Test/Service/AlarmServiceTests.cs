﻿// -----------------------------------------------------------------------
// <copyright file="AlarmServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Alarm Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Services;
    using Services.Interfaces;

    [TestClass]
    public class AlarmServiceTests : TestBase
    {
        /// <summary>
        ///     interface IAlarmService
        /// </summary>
        private IAlarmService alarmService;

        //public AlarmServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     get test for controller details
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            alarmService = new AlarmService();
        }

        /// <summary>
        ///     Test to Get the alarm details
        /// </summary>
        [TestMethod]
        public void FetchAlarmDetails_Test()
        {
            List<Alarm> result = alarmService.FetchAlarmDetails("1");

            if (result != null)
            {
                Assert.IsNotNull(result, "Alarm details are available");
            }
            else
            {
                Assert.IsNull(result, "Alarm details are not available");
            }
        }

        [TestMethod]
        public void FetAlarmDetailsSync_Test()
        {
            int recordCount = 10;
            List<Alarm> result = alarmService.FetchAlarmDetailsForSync(recordCount);
            if (result != null)
            {
                Assert.IsNotNull(result, "Alarm details are available");
            }
            else
            {
                Assert.IsNull(result, "Alarm details are not available");
            }
        }
    }
}