﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Services;
    using Ecolab.Services.Interfaces;    

    [TestClass]
    public class SyncServiceTest : TestBase
    {
        ISyncService syncService;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            syncService = new SyncService();
        }

        /// <summary>
        /// Test Case for GetLatestLastModifiedTime
        /// </summary>
        [TestMethod]
        public void GetLatestLastModifiedTime_Test()
        {
            string tableName = "ConduitController";
            string ecolabAccountNumber = "1";
            Dictionary<string, string> dicConfigSettings = new Dictionary<string, string>();
            DateTime latestDate = syncService.GetLatestLastModifiedTime(tableName, ecolabAccountNumber, "WasherGroup");

            if (latestDate != null)
            {
                Assert.IsTrue(true, "Date is available");
            }
            else
            {
                Assert.IsTrue(true, "Date is not available");
            }
        }
    }
}
