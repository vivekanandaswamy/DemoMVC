﻿using WebModel = Ecolab.ConduitLocal.Web.Mapper;

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Services;

    [TestClass]
    public class PlantTest : TestBase
    {
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _plantService = new PlantService();
        }

        /// <summary>
        ///     Get the plant details
        /// </summary>
        [TestMethod]
        public void GetPlantDetail()
        {
            Plant result = _plantService.GetPlantDetails();
            Assert.IsNotNull(result, "fetched plant data.");
        }

        /// <summary>
        ///     save test for plant details
        /// </summary>
        [TestMethod]
        public void SavePlantCustomerTest()
        {
            Plant plant;
            int userId = 1;
            plant = new Plant { EcoalabAccountNumber = "EcoNumber", LanguageId = 1, CurrencyCode = "2", Rate = 80, ExportPath = "\abc\test", DataLiveTime = 23, BudgetCustomer = true, UomId = 1 };
            DateTime lastModifiedTimeStamp;
            _plantService.SavePlantDetails(plant, userId, out lastModifiedTimeStamp);
            //Assert.IsNotNull(id > 0, "Saved Plant details.");
        }
    }
}