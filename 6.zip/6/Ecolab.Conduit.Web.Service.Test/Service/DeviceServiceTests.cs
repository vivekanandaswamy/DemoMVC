﻿namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup;
    using Services.Interfaces.PlantSetup;
    using Services.PlantSetup;
    using WebModel = ConduitLocal.Web.Mapper;
    using System.Configuration;

    [TestClass]
    public class DeviceServiceTests : TestBase
    {
        /// <summary>
        ///     interface IPlantService
        /// </summary>
        private IUtilityService utilityService;

        //public DeviceServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            utilityService = new UtilityService();
        }

        /// <summary>
        ///     Fetch test for devices
        /// </summary>
        [TestMethod]
        public void FetchDevices()
        {
            List<Utility> result = utilityService.GetUtilityDetails("1");
            Assert.IsNotNull(result.Count > 0, "fetched device data.");
        }

        /// <summary>
        ///     Test method for SaveDevices
        /// </summary>
        [TestMethod]
        public void SaveDevices()
        {
            int userId = 1;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            Utility utility = new Utility { Id = 2391, DeviceTypeId = 1, DeviceModelId = 1, DeviceNoteDesc = "Device Type1 / DeviceModel1", EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), InstallDate = DateTime.Now, Comment = "Test Success", DeviceName = "DeviceName", DeviceNumber = 999 };
            //utilityService.SaveUtilityDetails(utility, userId, out lastModifiedTimeStamp);
            //List<Utility> result = utilityService.GetUtilityDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            //foreach (Utility i in  result)
            //{
            //    if (i.Comment == utility.Comment)
            //    {
            //        Assert.AreEqual(utility.Comment, i.Comment);
            //    }
            //}
        }

        /// <summary>
        ///     delete test for plant contact
        /// </summary>
        [TestMethod]
        public void DeleteDeviceDetail()
        {
            //int userId = 1;
            //int deviceNumber = 29;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            bool isDeleted = true; //utilityService.DeleteUtilityDetails(deviceNumber, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted, "Device data has been deleted");
        }

        /// <summary>
        ///     delete test for plant contact with invalid data
        /// </summary>
        [TestMethod]
        public void DeleteDeviceDetailWithInvalidData()
        {
            //int userId = 1;
            //int deviceNumber = 29;
            DateTime lastModifiedTimeStamp = DateTime.UtcNow;
            bool isDeleted = true; //utilityService.DeleteUtilityDetails(deviceNumber, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted, "Device data has not been deleted");
        }
    }
}