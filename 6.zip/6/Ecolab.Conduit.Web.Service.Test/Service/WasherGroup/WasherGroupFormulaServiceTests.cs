﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupFormulaServiceTests.cs" company="Ecolab">
// Unit test cases for WasherGroupFormulaService.
// </copyright>
// <summary> Washer Group Formula tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.WasherGroup;
    using Services.Interfaces.WasherGroup;
    using Services.WasherGroup;
    using System.Configuration;

    /// <summary>
    ///     WasherGroupFormulaServiceTests
    /// </summary>
    [TestClass]
    public class WasherGroupFormulaServiceTests : TestBase
    {
        /// <summary>
        ///     interface IWasherGroupFormulaService
        /// </summary>
        private IWasherGroupFormulaService _washerGroupFormulaService;

        //public WasherGroupFormulaServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     get test for Washer Group Formula
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _washerGroupFormulaService = new WasherGroupFormulaService();
        }

        /// <summary>
        ///     Get GetWasherGroupFormula
        /// </summary>
        [TestMethod]
        public void GetWasherGroupFormulaTest()
        {
            IEnumerable<WasherGroupFormula> washerGroupFormula = _washerGroupFormulaService.GetWasherGroupFormula(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1, 1);
            Assert.IsNotNull(washerGroupFormula, "Received washerGroupFormula Detail.");
        }

        /// <summary>
        ///     Get GetWasherGroupFormula
        /// </summary>
        [TestMethod]
        public void GetWasherDosingProductTest()
        {
            IEnumerable<WasherDosingProduct> washerDosingProduct = _washerGroupFormulaService.GetWasherDosingProduct("1", 1, true);
            Assert.IsNotNull(washerDosingProduct, "Received washerDosingProduct Detail.");
        }

        //[TestMethod]
        //public void GetTunnelProductListForFormulaWithInjectionCountTest()
        //{
        //    var products = _washerGroupFormulaService.GetTunnelProductListForFormulaWithInjectionCount("1", 417);
        //    Assert.IsNotNull(products, "Received products Detail.");
        //}
        /// <summary>
        ///     Get GetTunnelProductListForFormulaWithInjectionCount
        /// </summary>
        /// <summary>
        ///     Get GetWashOperations Test
        /// </summary>
        [TestMethod]
        public void GetWashOperationsTest()
        {
            IEnumerable<WashStep> washeSteps = _washerGroupFormulaService.GetWashOperations(1,false);
            Assert.IsNotNull(washeSteps, "Received washerGroupFormula Detail.");
        }

        /// <summary>
        ///     Get GetWasherGroupFormulaWashStepsTest Test
        /// </summary>
        [TestMethod]
        public void GetWasherGroupFormulaWashStepsTest()
        {
            IEnumerable<WasherFormulaWashStep> washeSteps = _washerGroupFormulaService.GetWasherGroupFormulaWashSteps("1", 12, 96, 0);
            Assert.IsNotNull(washeSteps, "Received washerGroupFormula Detail.");
        }

        /// <summary>
        ///     Add WasherGroupFormula
        /// </summary>
        [TestMethod]
        public void AddWasherGroupFormulaTest()
        {
            DateTime lastModifiedTimeStamp;
            int userId = 1;
            WasherGroupFormula washerGroupFromula = new WasherGroupFormula()
            {
              
                WasherGroupNumber = "1",
                WasherGroupName = "test1",
                WasherGroupTypeName="conventional",
                ProgramNumber = 1,
              
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                WasherGroupId = 3,
                
                ProgramId = 3,
                NominalLoad = 25,
                ExtraTime = 40              
            };
            try {
                int returnValue = _washerGroupFormulaService.AddWasherGroupFormula(washerGroupFromula, userId, out lastModifiedTimeStamp);

                if (returnValue > 0)
                {
                    Assert.IsTrue(true, "Received washerGroupFormula Detail.");
                }
            }
            catch {

                Assert.IsFalse(false, "Not received washerGroupFormula Detail.");
               
                
            }
            
        }

        /// <summary>
        ///     Get Tunnel Product List
        /// </summary>
        [TestMethod]
        public void GetTunnelProductListTest()
        {
            List<TunnelWashStepProducts> result = _washerGroupFormulaService.GetTunnelProductList(2, "1", 2,1);
            Assert.IsNotNull(result, "Received tunnel products Detail.");
        }

        /// <summary>
        ///     Add WasherGroupFormulaWashSteps
        /// </summary>
        [TestMethod]
        public void AddWasherGroupFormulaWashStepsTest()
        {
            var ecolabnum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            DateTime lastModifiedTimeStamp;
            var productsList = new List<WasherDosingProduct> { new WasherDosingProduct { Id = 1, InjectionNumber = 1, ProductId = 1, ProductName = "Prod Name1", Quantity = 10, EcolabAccountNumber = ecolabnum }, new WasherDosingProduct { Id = 2, InjectionNumber = 2, ProductId = 2, ProductName = "Prod Name2", Quantity = 11, EcolabAccountNumber = ecolabnum } };

            WasherFormulaWashStep WashstepData = new WasherFormulaWashStep { DrainDestinationId = 1, EcolabAccountNumber = ecolabnum, StepNumber = 21, RunTime = 90, Temperature = 50, WaterLevel = 89, ProgramSetupId = 2098, WashOperationId = 1, WasherDosingProducts = productsList };

            int returnValue = _washerGroupFormulaService.AddWasherGroupFormulaWashSteps(WashstepData, 1, 1, out lastModifiedTimeStamp);
            Assert.IsNotNull(returnValue, "Added washerGroupFormula Detail.");
        }

        /// <summary>
        ///     Add WasherGroupFormulaWashSteps
        /// </summary>
        [TestMethod]
        public void UpdateWasherGroupFormulaWashStepsTest()
        {
            DateTime lastModifiedTimeStamp;
            var productsList = new List<WasherDosingProduct> { new WasherDosingProduct { Id = 1, InjectionNumber = 1, ProductId = 1, ProductName = "Updated Prod Name1", Quantity = 11, EcolabAccountNumber = "1", WasherDosingSetupId = 8 }, new WasherDosingProduct { Id = 2, InjectionNumber = 2, ProductId = 2, ProductName = "Updated Prod Name2", Quantity = 12, EcolabAccountNumber = "1", WasherDosingSetupId = 8 } };

            WasherFormulaWashStep WashstepData = new WasherFormulaWashStep { Id = 8, DrainDestinationId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), StepNumber = 11, RunTime = 99, Temperature = 50, WaterLevel = 89, ProgramSetupId = 1, WashOperationId = 1, WasherDosingProducts = productsList };

            int returnValue = _washerGroupFormulaService.UpdateWasherGroupWashStepFormula(WashstepData, 1, out lastModifiedTimeStamp);
            Assert.IsNotNull(returnValue, "Updated washerGroupFormula Detail.");
        }

        [TestMethod]
        public void UpdateConventionalWashStepInjectionsTest()
        {
            DateTime lastModifiedTimeStamp;
            var productsList = new List<WasherDosingProduct> { new WasherDosingProduct { Id = 1, InjectionNumber = 1, ProductId = 1, ProductName = "Updated Prod Name1", Quantity = 11, EcolabAccountNumber = "1", WasherDosingSetupId = 8 }, new WasherDosingProduct { Id = 2, InjectionNumber = 2, ProductId = 2, ProductName = "Updated Prod Name2", Quantity = 12, EcolabAccountNumber = "1", WasherDosingSetupId = 8 } };
            WasherFormulaWashStep WashstepData = new WasherFormulaWashStep { Id = 8, DrainDestinationId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), StepNumber = 11, RunTime = 99, Temperature = 50, WaterLevel = 89, ProgramSetupId = 1, WashOperationId = 1, WasherDosingProducts = productsList };

            bool retVal = _washerGroupFormulaService.UpdateConventionalWashStepInjections(WashstepData, 1, out lastModifiedTimeStamp);
            Assert.IsNotNull(retVal, "Updated washerGroupFormula injections Details.");

        }

        [TestMethod]
        public void SaveConventionalWashStepGridViewTest()
        {
                DateTime lastModifiedTimeStamp;
                WasherFormulaWashStep[] WashstepData= new WasherFormulaWashStep[3];
                var productsList = new List<WasherDosingProduct> { new WasherDosingProduct { Id = 1, InjectionNumber = 1, ProductId = 1, ProductName = "Updated Prod Name1", Quantity = 11, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), WasherDosingSetupId = 8 } };
                var productsList2 = new List<WasherDosingProduct> { new WasherDosingProduct() };
                var productsList3 = new List<WasherDosingProduct> { new WasherDosingProduct { Id = 1, InjectionNumber = 1, ProductId = 1, ProductName = "Updated Prod Name1", Quantity = 11, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), WasherDosingSetupId = 8 }, new WasherDosingProduct { Id = 2, InjectionNumber = 2, ProductId = 2, ProductName = "Updated Prod Name2", Quantity = 12, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), WasherDosingSetupId = 8 } };
                WashstepData[0] = new WasherFormulaWashStep { Id = 8, DrainDestinationId = 15, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), StepNumber = 11, RunTime = 99, Temperature = 50, WaterLevel = 89, ProgramSetupId = 1, WashOperationId = 1, WasherDosingProducts = productsList };
                WashstepData[1] = new WasherFormulaWashStep { Id = 9, DrainDestinationId = 4, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), StepNumber = 11, RunTime = 99, Temperature = 50, WaterLevel = 89, ProgramSetupId = 1, WashOperationId = 46, WasherDosingProducts = productsList2 };
                WashstepData[2] = new WasherFormulaWashStep { Id = 28, DrainDestinationId = 15, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), StepNumber = 11, RunTime = 99, Temperature = 50, WaterLevel = 89, ProgramSetupId = 1, WashOperationId = 1, WasherDosingProducts = productsList3 };
                for (int i = 0; i < 3; i++)
                {
                    int returnValue = _washerGroupFormulaService.UpdateWasherGroupWashStepFormula(WashstepData[i], 1, out lastModifiedTimeStamp);
                    Assert.IsNotNull(returnValue, "Updated washerGroupFormula Detail.");
                }
        }
    }
}