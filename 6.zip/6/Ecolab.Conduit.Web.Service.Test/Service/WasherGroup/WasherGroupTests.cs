﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupTests.cs" company="Ecolab">
// Unit test cases for washer groups.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.WasherGroup
{
    public class WasherGroupTests : TestBase
    {
    }
}