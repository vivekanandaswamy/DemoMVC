﻿// -----------------------------------------------------------------------
// <copyright file="InjectionServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Injection Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Models.WasherGroup;
    using Access.WasherGroup;
    using Ecolab.Services.Interfaces.WasherGroup;
    using Ecolab.Services.WasherGroup;
    using System.Configuration;

    [TestClass]
    public class InjectionServiceTests : TestBase
    {
        /// <summary>
        /// interface IInjectionService
        /// </summary>
        IInjectionService injectionService;

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            injectionService = new InjectionService();
        }

        /// <summary>
        /// MS Test for SaveInjectionDetails
        /// </summary>
        [TestMethod]
        public void SaveInjectionDetails_Test()
        {
			string ecolabAccountNumber = "1";
            int washerGroupId =1;
            int controllerId =2;
            int washerId = 3;

			injectionService.SaveInjectionDetails(washerGroupId, controllerId, washerId, ecolabAccountNumber);
        }

        /// <summary>
        /// MS Test for GetInjectionDetails
        /// </summary>
        [TestMethod]
        public void GetInjectionDetails_Test()
        {
            int washerGroupId = 1;            

            List<InjectionData> InjectionDatas  = injectionService.GetInjectionDetails(washerGroupId);

            if (InjectionDatas.Count > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS Test for GetWasherGroupInjectionDetails
        /// </summary>
        [TestMethod]
        public void GetWasherGroupInjectionDetails_Test()
        {
            string ecolabAccountNumber = "1";
            int washerGroupId = 1;
            int controllerId = 1;

            List<InjectionDetails> InjectionDetails = injectionService.GetWasherGroupInjectionDetails(ecolabAccountNumber, washerGroupId, controllerId);

            if (InjectionDetails.Count > 0)
            {
                Assert.IsTrue(true, "Washer Group Injection Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Washer Group Injection Data is not available");
            }
        }

        /// <summary>
        /// MS Test for GetWasherStepInjectionDetails
        /// </summary>
        [TestMethod]
        public void GetWasherStepInjectionDetails_Test()
        {
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");            
            int washerDosingSetupId =1;
            int programSetupId = 1;
            int injectionNumber = 1;

            List<InjectionDetails> InjectionDetails = injectionService.GetWasherStepInjectionDetails(ecolabAccountNumber, washerDosingSetupId, programSetupId, injectionNumber);

            if (InjectionDetails.Count > 0)
            {
                Assert.IsTrue(true, "Washer Group Injection Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Washer Group Injection Data is not available");
            }
        }
    }
}
