﻿// -----------------------------------------------------------------------
// <copyright file="MyProfileServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyProfileServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Home
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.PlantSetup.UserManagement;
    using Services.Home;
    using Services.Interfaces.Home;
    using System.Configuration;

    /// <summary>
    ///     Test class for MyProfileServiceTests
    /// </summary>
    [TestClass]
    public class MyProfileServiceTests : TestBase
    {
        /// <summary>
        ///     interface IMyProfileService
        /// </summary>
        private IMyProfileService myProfileService;

        //public MyProfileServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            myProfileService = new MyProfileService();
        }

        /// <summary>
        ///     Get the my profile details
        /// </summary>
        [TestMethod]
        public void FetchMyProfileDetails_Test()
        {
            int? id = 1;
            UserManagement userManagement = myProfileService.FetchMyProfileDetails(id, "1");
            Assert.IsNotNull(userManagement != null, "Get the my profile details");
        }

        /// <summary>
        ///     Update the my p[rofile details
        /// </summary>
        [TestMethod]
        public void UpdateMyProfile_Test()
        {            
            UserManagement userManagement = new UserManagement
            {
                UserNumber = 1,
                Title = "Mr",
                FirstName = "Temporary Role for Customer 1",
                LastName = "Test1",
                Email = "TRCustomer@colab.com",
                LanguageId = 1,
                ContactNo = "",
                Mobile = "7323456789",
                Fax = "7323456788",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                CurrencyCode = "1",
                UOMId = 1
            };
            string result = myProfileService.UpdateMyProfile(userManagement, userManagement.EcolabAccountNumber);
            if (result == "201")
            {
                Assert.IsTrue(true, "My profile details are updated.");
            }
            else
            {
                Assert.IsFalse(true, "My profile details are not updated.");
            }
        }

        /// <summary>
        ///     Update(Change) the user password
        /// </summary>
        [TestMethod]
        public void UpdateUserPassword_Test()
        {
            UserManagement userManagement = new UserManagement { UserNumber = 1, Password = "baloce1", EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };

            string result = myProfileService.UpdateUserPassword(userManagement, userManagement.EcolabAccountNumber);
            if (result == "201")
            {
                Assert.IsTrue(true, "User password is updated.");
            }
            else
            {
                Assert.IsFalse(true, "Password is not updated.");
            }
        }
    }
}