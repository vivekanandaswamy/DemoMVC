﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Services;
    using Services.Interfaces;
    using System.Configuration;

    /// <summary>
    ///     Plant Formula Service Tests
    /// </summary>
    [TestClass]
    public class PlantFormulaServiceTests : TestBase
    {
        /// <summary>
        ///     interface IProgramMasterService
        /// </summary>
        private IProgramMasterService _ProgramMasterService;

        //public PlantFormulaServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     get test for Program Master Service
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _ProgramMasterService = new ProgramMasterService();
        }

        /// <summary>
        ///     Get Formula Details
        /// </summary>
        [TestMethod]
        public void GetFormulaDetailsWithPagingTest()
        {
            List<Formula> Formulas = _ProgramMasterService.GetFormulaDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1, 12, 0);
            Assert.IsNotNull(Formulas.Count >= 0, "Received Formula Details.");
        }

        /// <summary>
        ///     Get Formula Details
        /// </summary>
        [TestMethod]
        public void GetFormulaDetailsWithoutPagingTest()
        {
            List<Formula> Formulas = _ProgramMasterService.GetFormulaDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 0, 0, 0);
            Assert.IsNotNull(Formulas.Count >= 0, "Received Formula Details.");
        }

        /// <summary>
        ///     Get Ecolab Textile Category
        /// </summary>
        [TestMethod]
        public void GetEcolabTextileCategoryTest()
        {
            List<EcolabTextileCategory> EcolabTextileCategory = _ProgramMasterService.GetEcolabTextileCategory(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(EcolabTextileCategory.Count >= 0, "Received Controller Types Detail.");
        }

        /// <summary>
        ///     Get Ecolab Saturation
        /// </summary>
        [TestMethod]
        public void GetEcolabSaturationTest()
        {
            List<EcolabSaturation> EcolabSaturation = _ProgramMasterService.GetEcolabSaturation(1);
            Assert.IsNotNull(EcolabSaturation.Count >= 0, "Received Controller Types Detail.");
        }

        /// <summary>
        ///     Get Plant Chain Program
        /// </summary>
        [TestMethod]
        public void GetPlantChainProgramTest()
        {
            List<PlantChainProgram> PlantChainProgram = _ProgramMasterService.GetPlantChainProgram();
            Assert.IsNotNull(PlantChainProgram.Count >= 0, "Received Controller Meta Data with Values.");
        }

        /// <summary>
        ///     Get Chain Textile Category
        /// </summary>
        [TestMethod]
        public void GetChainTextileCategoryTest()
        {
            List<ChainTextileCategory> ChainTextileCategory = _ProgramMasterService.GetChainTextileCategory("1");
            Assert.IsNotNull(ChainTextileCategory.Count >= 0, "Received Field Source for Controller Column.");
        }

        /// <summary>
        ///     Save Formula Details Test
        /// </summary>
        [TestMethod]
        public void SaveFormulaDetailsTest()
        {
            Formula formula = new Formula { ProgramId = 8, Name = "Fender Covers", Pieces = 5, EcolabTextileId = 5, EcolabTextileCategoryName = "textilecategory5", EcolabSaturationId = 5, EcolabSaturationName = "saturation5", PlantProgramId = 5, PlantProgramName = "Test5", ChainTextileId = 1, ChainTextileCategory = "testing", Rewash = true, Weight = 5, PieceWeight = 1, UserId = 1, TotalCount = 10 };
            //_ProgramMasterService.SaveFormulaDetails(formula, 1);
        }

        /// <summary>
        ///     Delete Formula Details
        /// </summary>
        [TestMethod]
        public void DeleteFormulaDetailsTest()
        {
            DateTime lastModifiedTimeStamp;
            Formula objFormula = new Formula { ProgramId = 6, UserId = 1 };
            //int isDeleted = _ProgramMasterService.DeleteFormulaDetails(1, DateTime.UtcNow, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1, out lastModifiedTimeStamp);
            //Assert.IsNotNull(isDeleted, "Formula service data has been deleted");
        }
    }
}