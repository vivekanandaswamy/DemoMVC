﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Library.Enums;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.Common;
    using Services;
    using Services.Interfaces;
    using System.Configuration;

    /// <summary>
    ///     PlantContactServiceTests
    /// </summary>
    [TestClass]
    public class PlantContactServiceTests : TestBase
    {
        /// <summary>
        ///     interface IPlantContactService
        /// </summary>
        private IPlantContactService plantContactService;

        /// <summary>
        ///     get test for plant contact details
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            plantContactService = new PlantContactService();
        }

        [TestMethod]
        public void GetPlantContactDetailsTest()
        {
            List<PlantContact> plantContacts = plantContactService.GetPlantContactDetails();
            Assert.IsNotNull(plantContacts.Count >= 0, "Received Plant Contacts.");
        }

        /// <summary>
        ///     save test for plant contact
        /// </summary>
        [TestMethod]
        public void SavePlantContactDetails()
        {
            int userId = 1;
            DateTime lastModifiedTimeStamp = DateTime.Now;
            PlantContact objPlantContact = new PlantContact { EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), ContactFirstName = "TestFirst", ContactLastName = "TestLast", ContactFaxNumber = "abcdef", ContactMobilePhone = "46546464", ContactEmailAdresss = string.Empty, ContactOfficePhone = "464564dfsdf564", ContactPositionId = 2, ContactTitle = "TMtitle" };
            int id = plantContactService.SavePlantContactDetails(objPlantContact, userId, out lastModifiedTimeStamp);
            if (id > 0)
            {
                Assert.IsNotNull(id > 0, "Saved plant contact details successfully.");
            }
            else
            {
                Assert.AreEqual(id = 0, 0);
            }
        }

        /// <summary>
        ///     save test for plant contact
        /// </summary>
        [TestMethod]
        public void ValidateAndSavePlantContactDetails()
        {
            int userId = 1;
            int error;
            DateTime lastModifiedTimeStamp = DateTime.Now;
            PlantContact objPlantContact = new PlantContact { EcoalabAccountNumber = "1", ContactFirstName = "TestFirst", ContactLastName = "TestLast", ContactFaxNumber = "abcdef", ContactMobilePhone = "46546464", ContactEmailAdresss = "Test@email.com", ContactOfficePhone = "464564dfsdf564", ContactPositionId = 2, ContactTitle = "TMtitle", MaxNumberOfRecords = 10 };
            int id = plantContactService.ValidateAndSavePlantContactDetails(objPlantContact, userId, TcdAdminMessageTypes.TcdAddPlantContact, out error, out lastModifiedTimeStamp);
            if (id > 0)
            {
                Assert.IsNotNull(id > 0, "Saved plant contact details successfully.");
            }
            else
            {
                Assert.AreEqual(id = 0, 0);
            }
        }

        /// <summary>
        ///     save test for plant contact with invalid data
        /// </summary>
        [TestMethod]
        public void SavePlantContactWithNullDetails()
        {
            PlantContact objPlantContact = new PlantContact { EcoalabAccountNumber = "-1", ContactFirstName = null, ContactLastName = null, ContactFaxNumber = null, ContactMobilePhone = null, ContactEmailAdresss = null, ContactOfficePhone = null, ContactPositionId = 0, ContactTitle = null };
            // int id = plantContactService.SavePlantContactDetails(objPlantContact, userId);
            // Assert.IsTrue(id > 0, "Saved plant contact details successfully.");
        }

        /// <summary>
        ///     delete test for plant contact
        /// </summary>
        [TestMethod]
        public void DeletePlantContactDetail()
        {
            int userId = 1;
            //int EcolabAccountNumber = 1;
            PlantContact objPlantContact = new PlantContact { Id = 10, EcoalabAccountNumber = "1" };
            DateTime lastModifiedTimeStamp;
            int isDeleted = plantContactService.DeletePlantContactDetails(objPlantContact, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted == 0, "Customer service data has been deleted");
        }

        /// <summary>
        ///     delete test for plant contact with invalid data
        /// </summary>
        [TestMethod]
        public void DeleteWithInvalidData_PlantContactDetail()
        {
            int userId = 1;
            PlantContact objPlantContact = new PlantContact { Id = 0, EcoalabAccountNumber = "1" };
            DateTime lastModifiedTimeStamp;
            int isDeleted = plantContactService.DeletePlantContactDetails(objPlantContact, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted >= 0, "Customer service data could not be deleted");
        }

        [TestMethod]
        public void FetchPlantContactPositionTest()
        {
            List<PlantContactPosition> plantContacts = plantContactService.FetchPlantContactPosition();
            Assert.IsNotNull(plantContacts.Count >= 0, "Received Plant Contact positions.");
        }
    }
}