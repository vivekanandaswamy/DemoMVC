﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationMenuTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Navigation
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.NavigationMenu;
    using Services.Interfaces.NavigationMenu;
    using Services.NavigationMenu;

    /// <summary>
    ///     Service Test Equipment
    /// </summary>
    [TestClass]
    public class NavigationMenuTests : TestBase
    {
        /// <summary>
        ///     interface INavigationMenuService
        /// </summary>
        private INavigationMenuService navigationMenuService;

        [TestInitialize]
        public void TestInitialize()
        {
            navigationMenuService = new NavigationMenuService();
        }

        /// <summary>
        ///     Fetch Equipment For Navigation Menu
        /// </summary>
        [TestMethod]
        public void FetchNavigationDetails_Test()
        {
            string ecolabaccountnumber = "1";
            string role = "BDM";
            List<NavigationMenu> result = navigationMenuService.FetchNavigationMenuDetails(ecolabaccountnumber, role);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}