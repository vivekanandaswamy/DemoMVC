﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.Default
{
    using System.Collections.Generic;
    using System.Configuration;
    using Ecolab.Models;
    using Ecolab.Models.Default;
    using Ecolab.Services.Default;
    using Ecolab.Services.Interfaces.Default;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;

    [TestClass]
    public class DefaultServiceTest : TestBase
    {
        IDefaultService defaultService;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            defaultService = new DefaultService();
        }

        /// <summary>
        /// Test Case for CreateUserPortletData
        /// </summary>
        [TestMethod]
        public void CreateUserPortletData_Test()
        {
            List<Portlet> portlets = new List<Portlet>()
            {
                new Portlet()
                {
                    DisplayOrder = 1,
                    EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                    IsEnabled = true,
                    Name = "Name",
                    PortletId = 1,
                    ReportId = 1
                }
            };

            int userId = 1;
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            string result;

            result = defaultService.CreateUserPortletData(portlets, userId, ecolabAccountNumber);

            if(result == "101")
            {
                Assert.IsTrue(true, "Date has been inserted");
            }
            else
            {
                Assert.IsTrue(true, "Date has not been inserted");
            }
        }

        /// <summary>
        /// Test Case for FetchPortletsByUser
        /// </summary>
        [TestMethod]
        public void FetchPortletsByUser_Test()
        {            
            int userId = 12;
            string ecolabAccountNumber = "040242802";           

            List<Portlet> portlets = defaultService.FetchPortletsByUser(userId, ecolabAccountNumber);

            if (portlets.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for GetShiftSummaryDetails
        /// </summary>
        [TestMethod]
        public void GetShiftSummaryDetails_Test()
        {
            string ecolabAccountNumber = "040242802";

            ShiftSummary shiftSummary = defaultService.GetShiftSummaryDetails(ecolabAccountNumber);

            if (shiftSummary != null)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }
    }
}
