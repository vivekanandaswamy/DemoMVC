﻿// -----------------------------------------------------------------------
// <copyright file="StorageTanksServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Storage Tanks Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Services.Interfaces.StorageTanks;
    using Services.StorageTanks;
    using storageModel = Models.StorageTanks;
    using System.Configuration;

    /// <summary>
    ///     StorageTanksServiceTests
    /// </summary>
    [TestClass]
    public class StorageTanksServiceTests :TestBase
    {
        /// <summary>
        ///     interface IStorageTanksService
        /// </summary>
        private IStorageTanksService storageTanksService;

        //public StorageTanksServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     get test for storage details
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            storageTanksService = new StorageTanksService();
        }

        /// <summary>
        ///     Get storage details
        /// </summary>
        [TestMethod]
        public void GetTanksDetailsTest()
        {
            List<storageModel.Tanks> storageTankDetails = storageTanksService.GetTanksDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 1);
            Assert.IsNotNull(storageTankDetails.Count >= 0, "Received storage tank data Detail.");
        }

        /// <summary>
        ///     delete storage details
        /// </summary>
        [TestMethod]
        public void DeleteStorageTanksTest()
        {
            DateTime lastModifiedTimeStamp;
            storageTanksService.DeleteStorageTanks(2160, 1, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), out lastModifiedTimeStamp);
        }

        /// <summary>
        ///     Save storage tank Details
        /// </summary>
        [TestMethod]
        public void SaveStorageTankTest()
        {
            storageModel.Tanks tanksData = new storageModel.Tanks { TankId = 990, TankName = "Unit Test Tank", EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            DateTime lastModifiedTimeStamp;
            storageTanksService.SaveStorageTank(tanksData, 1, out lastModifiedTimeStamp);
        }

        /// <summary>
        ///     update storage tank Details
        /// </summary>
        [TestMethod]
        public void UpdateStorageTankTest()
        {
            storageModel.Tanks tanksData = new storageModel.Tanks { TankId = 990, TankName = "Unit Test Tank modeified", EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            DateTime lastModifiedTimeStamp;
            storageTanksService.UpdateStorageTank(tanksData, 1, out lastModifiedTimeStamp);
        }
    }
}