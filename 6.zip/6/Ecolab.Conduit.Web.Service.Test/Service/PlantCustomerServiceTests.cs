﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Services;
    using Services.Interfaces;

    /// <summary>
    ///     tests for plant customer service
    /// </summary>
    [TestClass]
    public class PlantCustomerServiceTests : TestBase
    {
        /// <summary>
        ///     interface IPlantCustomerService
        /// </summary>
        private IPlantCustomerService plantCustomerService;

        //public PlantCustomerServiceTests(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            plantCustomerService = new PlantCustomerService();
        }

        /// <summary>
        ///     get test for plant customer details
        /// </summary>
        [TestMethod]
        public void GetPlantCustomersTest()
        {
            List<PlantCustomer> plantCustomers = plantCustomerService.GetPlantCustomer(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(plantCustomers.Count >= 0, "Received Plant Customers.");
        }

        /// <summary>
        ///     save test for plant customer
        /// </summary>
        [TestMethod]
        public void SavePlantCustomerTest()
        {
            PlantCustomer plantCust;
            int userId = 1;
            plantCust = new PlantCustomer { CustomerId = 3, CustomerName = "TestFromDev2", EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };

            DateTime lastModifiedTimeStamp;
            int id = plantCustomerService.SavePlantCustomer(plantCust, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(id > 0, "Saved Plant Customer details.");
        }

        ///// <summary>
        /////     not save test for plant customer
        ///// </summary>
        //[TestMethod]
        //public void SaveWithInvalidData_PlantCustomerTest()
        //{
        //    PlantCustomer plantCust;
        //    int userId = 1;
        //    plantCust = new PlantCustomer { CustomerId = 0, CustomerName = "TestFromDev2", EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
        //    DateTime lastModifiedTimeStamp;
        //    int id = plantCustomerService.SavePlantCustomer(plantCust, userId, out lastModifiedTimeStamp);
        //    Assert.IsTrue(id > 0, "Saved Plant Customer details.");
        //}

        /// <summary>
        ///     delete test for plant customer
        /// </summary>
        [TestMethod]
        public void DeletePlantCustomerTest()
        {
            int userId = 1;
            DateTime lastModifiedTimeStamp;
            PlantCustomer objplantCust = new PlantCustomer { Id = 5, CustomerId = 3, EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            int plantCustomerId = plantCustomerService.DeletePlantCustomer(objplantCust, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(plantCustomerId > 0, "Customer service data has been deleted");
        }

        /// <summary>
        ///     delete test for plant customer
        /// </summary>
        [TestMethod]
        public void DeleteWithInvalid_PlantCustomerTest()
        {
            int userId = 1;
            PlantCustomer objplantCust = new PlantCustomer { Id = 0, CustomerId = 0, EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            DateTime lastModifiedTimeStamp;
            int isDeleted = plantCustomerService.DeletePlantCustomer(objplantCust, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted <= 0, "Customer service data could not be deleted");
        }

        /// <summary>
        ///     delete test for plant customer
        /// </summary>
        [TestMethod]
        public void DeleteWithInvalidData_PlantCustomerTest()
        {
            int userId = 1;
            DateTime lastModifiedTimeStamp;
            PlantCustomer objplantCust = new PlantCustomer { Id = -41, CustomerId = -1, EcoalabAccountNumber = "1" };
            int isDeleted = plantCustomerService.DeletePlantCustomer(objplantCust, userId, out lastModifiedTimeStamp);
            Assert.IsTrue(isDeleted < 0, "Customer service data has been deleted");
        }
    }
}