﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.Reports
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ecolab.Services.Interfaces.Reports;
    using Ecolab.Models.Reports;
    using Ecolab.Services.Reports;
using System.Collections.Generic;

    [TestClass]
    public class ReportSubViewServiceTests
    {
        /// <summary>
        /// interface IReportSubView
        /// </summary>
        IReportSubView reportSubView;

        /// <summary>
        /// test initialize
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            reportSubView = new ReportSubViewService();
        }

        /// <summary>
        /// MS Test for FetchSubViewsForView
        /// </summary>
        [TestMethod]
        public void FetchSubViewsForView_Test()
        {
            int viewModeId = 1;
            int languageId = 1;

            List<ReportSubView> reportSubViews = reportSubView.FetchSubViewsForView(viewModeId, languageId);

            if(reportSubViews.Count > 0)
            {
                Assert.IsTrue(true, "Sub Views are available");
            }
            else
            {
                Assert.IsTrue(true, "Sub Views are not available");
            }
        }
    }
}
