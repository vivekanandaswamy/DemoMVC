﻿// -----------------------------------------------------------------------
// <copyright file="ReportCategoryServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Category Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using reportCategory = Models.Reports;

    /// <summary>
    ///     Service Test Of Report Category.
    /// </summary>
    [TestClass]
    public class ReportCategoryServiceTests : TestBase
    {
        /// <summary>
        ///     Interface for Report Category.
        /// </summary>
        private IReportCategoryService reportCategoryService;

        [TestInitialize]
        public void TestInitialize()
        {
            reportCategoryService = new ReportCategoryService();
        }

        /// <summary>
        ///     Fetches Report Details.
        /// </summary>
        [TestMethod]
        public void FetchReports_Test()
        {
            int roleId = 9;
            int languageId = 1;
            List<reportCategory.Report> result = reportCategoryService.FetchReports(roleId, languageId);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}