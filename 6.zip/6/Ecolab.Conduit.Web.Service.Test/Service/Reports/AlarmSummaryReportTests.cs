﻿// -----------------------------------------------------------------------
// <copyright file="AlarmSummaryReportTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm Summary Report Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Reports
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports;
    using Models.Reports.WashingProcessValidation;
    using Services.Interfaces.Reports;
    using Services.Reports;

    [TestClass]
    public class AlarmSummaryReportTests : TestBase
    {
        /// <summary>
        ///     interface ChemicalInventoryReportService
        /// </summary>
        private IAlarmSummaryReportService alarmSummaryReportService;

        /// <summary>
        /// interface IReportService
        /// </summary>
        private IReportService reportService;

        /// <summary>
        ///     Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            alarmSummaryReportService = new AlarmSummaryReportService();
            reportService = new AlarmSummaryReportService();
        }

        /// <summary>
        /// MS Test for FetchAlarmSummaryReport
        /// </summary>
        [TestMethod]
        public void FetchAlarmSummaryReport_Test()
        {
            ReportSettings reportSettings = new ReportSettings { Corporate = string.Empty, Country = string.Empty, Region = string.Empty, EcolabAccountNumber = "1", Controller = string.Empty, Machine = string.Empty, MachineGroup = string.Empty, Formula = string.Empty, MachineType = string.Empty, Alarm = string.Empty, FromDate = DateTime.Now, ToDate = DateTime.Now, GroupId = string.Empty, MachineInternalId = string.Empty, SortColumnId = 0, SortDirection = string.Empty, UserId = 1, ToDateUTC = DateTime.Now, FromDateUTC = DateTime.Now };

            List<AlarmSummary> alarmSummaryLists = alarmSummaryReportService.FetchAlarmSummaryReport(reportSettings);
            if (alarmSummaryLists != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        /// MS Test for GenerateReport
        /// </summary>
        [TestMethod]
        public void GenerateReport_Test()
        {
            ReportSettings reportSettings = new ReportSettings { Corporate = string.Empty, Country = string.Empty, Region = string.Empty, EcolabAccountNumber = "1", Controller = string.Empty, Machine = string.Empty, MachineGroup = string.Empty, Formula = string.Empty, MachineType = string.Empty, Alarm = string.Empty, FromDate = DateTime.Now, ToDate = DateTime.Now, GroupId = string.Empty, MachineInternalId = string.Empty, SortColumnId = 0, SortDirection = string.Empty, UserId = 1, ToDateUTC = DateTime.Now, FromDateUTC = DateTime.Now };
            string ecolabAccountNumber = "1";

            ReportTableAndChart reportTableAndChart = reportService.GenerateReport(reportSettings, ecolabAccountNumber);
            if (reportTableAndChart != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}