﻿// -----------------------------------------------------------------------
// <copyright file="ProductionMixReportServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Production Mix Report Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports.ProductionEfficiency;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using prodMixReport = Models.Reports;

    /// <summary>
    ///     Service Test Of  Production Mix Report
    /// </summary>
    [TestClass]
    public class ProductionMixReportServiceTests : TestBase
    {
        /// <summary>
        ///     Interface for Production Mix Report
        /// </summary>
        private IProductionMixReportService prodMixReportService;

        [TestInitialize]
        public void TestInitialize()
        {
            prodMixReportService = new ProductionMixReportService();
        }

        /// <summary>
        ///     Fetches Production Mix Report Details.
        /// </summary>
        [TestMethod]
        public void FetchProductionMixReport_Test()
        {
            prodMixReport.ReportSettings productionMix = new prodMixReport.ReportSettings { FromDate = DateTime.Now, ToDate = DateTime.Now, FromDateUTC = DateTime.Now, ToDateUTC = DateTime.Now };
            List<ProductionMix> result = prodMixReportService.FetchProductionMixReportDetails(productionMix);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}