﻿// -----------------------------------------------------------------------
// <copyright file="OperationSummaryTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Operation Summary Report Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Reports
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports.ResourcesUtilization;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using prodMixReport = Models.Reports;

    /// <summary>
    ///     Test class for OperationSummaryTests
    /// </summary>
    [TestClass]
    public class OperationSummaryTests : TestBase
    {
        /// <summary>
        ///     Interface for Production Mix Report
        /// </summary>
        private IOperationsSummaryService operationSummaryService;

        [TestInitialize]
        public void TestInitialize()
        {
            operationSummaryService = new OperationsSummaryService();
        }

        [TestMethod]
        public void OperationSummaryReport_Test()
        {
            prodMixReport.ReportSettings operationSummary = new prodMixReport.ReportSettings { FromDate = DateTime.Now, ToDate = DateTime.Now, ToDateUTC = DateTime.Now, FromDateUTC = DateTime.Now };
            List<OperationsSummary> result = operationSummaryService.FetchOperationsSummaryData(operationSummary);

            if (result.Count > 0)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(false, "Data is not available");
            }
        }
    }
}