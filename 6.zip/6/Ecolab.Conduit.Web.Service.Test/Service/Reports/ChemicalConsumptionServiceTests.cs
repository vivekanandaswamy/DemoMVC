﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalConsumptionServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemical Consumption Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Reports
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports;
    using Models.Reports.ResourcesUtilization;
    using Services.Interfaces.Reports;
    using Services.Reports;

    /// <summary>
    ///     Service Test Of  Chemical Consumption
    /// </summary>
    [TestClass]
    public class ChemicalConsumptionServiceTests : TestBase
    {
        /// <summary>
        ///     Interface for Chemical Consumption Service
        /// </summary>
        private IChemicalConsumptionService chemicalConsumptionService;

        /// <summary>
        /// interface IReportService
        /// </summary>
        private IReportService reportService;

        [TestInitialize]
        public void TestInitialize()
        {
            chemicalConsumptionService = new ChemicalConsumptionService();
            reportService = new ChemicalConsumptionService();
        }

        /// <summary>
        ///     Fetches Chemical Consumption Details.
        /// </summary>
        [TestMethod]
        public void FetchChemicalConsumption_Test()
        {
            ReportSettings chemical = new ReportSettings { FromDate = DateTime.Now, ToDate = DateTime.Now, FromDateUTC = DateTime.Now, ToDateUTC = DateTime.Now };
            IEnumerable<ChemicalConsumption> result = chemicalConsumptionService.FetchChemicalCunsumptionData(chemical);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}