﻿// -----------------------------------------------------------------------
// <copyright file="ReportLocalizationServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Localization Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Reports
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Services.Interfaces.Reports;
    using Ecolab.Services.Reports;
using Ecolab.Models.Reports;

    [TestClass]
    public class ReportLocalizationServiceTests : TestBase
    {
        /// <summary>
        /// interface IReportLocalizationService
        /// </summary>
        IReportLocalizationService reportLocalizationService;

        /// <summary>
        /// Test initialize
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            reportLocalizationService = new ReportLocalizationService();
        }
       
        /// <summary>
        /// MS Test for FetchReportLocalizationDetails
        /// </summary>
        [TestMethod]
        public void FetchReportLocalizationDetails_Tests()
        {
            int reportId = 1;
            int languageId = 2;

            List<ReportLocalization> reportLocalizations = reportLocalizationService.FetchReportLocalizationDetails(reportId, languageId);
            if(reportLocalizations.Count > 0)
            {
                Assert.IsTrue(true, "Localization details are available");
            }
            else
            {
                Assert.IsTrue(true, "Data are not available");
            }
        }
    }
}
