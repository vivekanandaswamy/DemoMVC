﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalInventoryReportServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemical Inventory Report Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Reports
{
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports;
    using Models.Reports.ResourcesUtilization;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using System.Configuration;

    [TestClass]
    public class ChemicalInventoryReportServiceTests : TestBase
    {
        /// <summary>
        ///     interface ChemicalInventoryReportService
        /// </summary>
        private IChemicalInventoryReportService chemicalInventoryReportService;

        /// <summary>
        ///     Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            chemicalInventoryReportService = new ChemicalInventoryReportService();
        }

        [TestMethod]
        public void FetchChemicalInventoryReportData_Test()
        {
            ReportSettings reportSettings = new ReportSettings { Corporate = string.Empty, Country = string.Empty, Region = string.Empty, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), SortColumnId = 0, SortDirection = string.Empty, UserId = 1, ReportId = 6 };

            List<ChemicalInventory> chemicalInventories = chemicalInventoryReportService.FetchChemicalInventoryReportData(reportSettings).ToList();
            if (chemicalInventories != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}