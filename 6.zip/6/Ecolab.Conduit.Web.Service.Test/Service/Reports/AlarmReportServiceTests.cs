﻿// -----------------------------------------------------------------------
// <copyright file="AlarmReportServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm Report Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports.WashingProcessValidation;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using alarmReport = Models.Reports;

    /// <summary>
    ///     Service Test Of  Alarm Report
    /// </summary>
    [TestClass]
    public class AlarmReportServiceTests : TestBase
    {
        /// <summary>
        ///     Interface for Alarm Report
        /// </summary>
        private IAlarmReportService alarmReportService;

        /// <summary>
        ///     Interface for Alarm Report
        /// </summary>
        private IAlarmSummaryReportService alarmSummaryReportService;

        [TestInitialize]
        public void TestInitialize()
        {
            alarmReportService = new AlarmReportService();
            alarmSummaryReportService = new AlarmSummaryReportService();
        }

        /// <summary>
        ///     Fetches Alarm Report Details.
        /// </summary>
        [TestMethod]
        public void FetchAlarmReport_Test()
        {
            alarmReport.ReportSettings alarm = new alarmReport.ReportSettings { FromDate = DateTime.Now, ToDate = DateTime.Now, FromDateUTC = DateTime.Now, ToDateUTC = DateTime.Now };
            IEnumerable<AlarmDetails> result = alarmReportService.FetchAlarmDetails(alarm);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetches Alarm Summary Details.
        /// </summary>
        [TestMethod]
        public void FetchAlarmSummaryReport_Test()
        {
            alarmReport.ReportSettings alarm = new alarmReport.ReportSettings { FromDate = DateTime.Now, ToDate = DateTime.Now, ToDateUTC = DateTime.Now, FromDateUTC = DateTime.Now };
            IEnumerable<AlarmSummary> result = alarmSummaryReportService.FetchAlarmSummaryReport(alarm);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}