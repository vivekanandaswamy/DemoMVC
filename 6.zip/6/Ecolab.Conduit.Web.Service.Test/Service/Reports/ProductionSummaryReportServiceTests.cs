﻿// -----------------------------------------------------------------------
// <copyright file="ProductionSummaryReportServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Production Summary Report Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports.ProductionEfficiency;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using prodSummaryReport = Models.Reports;

    /// <summary>
    ///     Service Test Of  Production Summary Report
    /// </summary>
    [TestClass]
    public class ProductionSummaryReportServiceTests : TestBase
    {
        /// <summary>
        ///     Interface for Production Summary Report
        /// </summary>
        private IProductionSummaryReportService prodSummaryReportService;

        [TestInitialize]
        public void TestInitialize()
        {
            prodSummaryReportService = new ProductionSummaryReportService();
        }

        /// <summary>
        ///     Fetches Production Summary Report Details.
        /// </summary>
        [TestMethod]
        public void FetchProductionSummaryReport_Test()
        {
            prodSummaryReport.ReportSettings productionSummary = new prodSummaryReport.ReportSettings { FromDate = DateTime.Now, ToDate = DateTime.Now };
            List<ProductionSummary> result = prodSummaryReportService.FetchProductionSummaryReportDetails(productionSummary);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}