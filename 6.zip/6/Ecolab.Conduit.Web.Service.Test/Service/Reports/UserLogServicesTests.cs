﻿// -----------------------------------------------------------------------
// <copyright file="UserLogServicesTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Log Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports.EcolabInternal;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using userLog = Models.Reports;

    /// <summary>
    ///     Service Test Of User Log.
    /// </summary>
    [TestClass]
    public class UserLogServicesTests : TestBase
    {
        /// <summary>
        ///     Interface for User Log.
        /// </summary>
        private IUserLogService userLogService;

        [TestInitialize]
        public void TestInitialize()
        {
            userLogService = new UserLogService();
        }

        /// <summary>
        ///     Gets User Log Details.
        /// </summary>
        [TestMethod]
        public void FetchReports_Test()
        {
            userLog.ReportSettings userlog = new userLog.ReportSettings { FromDate = DateTime.Now, ToDate = DateTime.Now, ToDateUTC = DateTime.Now, FromDateUTC = DateTime.Now };
            IEnumerable<UserLog> result = userLogService.GetUserLogData(userlog);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}