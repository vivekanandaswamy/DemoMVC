﻿// -----------------------------------------------------------------------
// <copyright file="RibbonServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Ribbon Service Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Reports;
    using Services.Interfaces.Reports;
    using Services.Reports;
    using System.Configuration;

    /// <summary>
    ///     Service Test Of  Ribbon
    /// </summary>
    [TestClass]
    public class RibbonServiceTest : TestBase
    {
        /// <summary>
        ///     interface IRibbonOptionService
        /// </summary>
        private IRibbonOptionService ribbonService;

        [TestInitialize]
        public void TestInitialize()
        {
            ribbonService = new RibbonOptionService();
        }

        /// <summary>
        ///     Fetches Ribbon Option.
        /// </summary>
        [TestMethod]
        public void FetchRibbonOption_Test()
        {
            int reportId = 1;
            List<RibbonOption> result = ribbonService.FetchRibbonOption(reportId);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetches Switch Categories.
        /// </summary>
        [TestMethod]
        public void FetchSwitchCategories_Test()
        {
            int reportId = 10;
            string ecolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<ReportSwitchMode> result = ribbonService.FetchSwitchCategories(reportId, ecolabAccNum);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetches Report Filters
        /// </summary>
        [TestMethod]
        public void FetchReportFilters_Test()
        {
            int reportId = 10;
            string ecolabAccNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            List<ReportFilter> result = ribbonService.FetchReportFilters(reportId, ecolabAccNum);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetches Report All Coloumns.
        /// </summary>
        [TestMethod]
        public void FetchReportAllColumns_Test()
        {
            ReportSettings settings = new ReportSettings { RoleId = 9, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), SwitchModeId = 1, ViewModeId = 0, ReportId = 1 };

            List<ReportAllColumns> result = ribbonService.FetchReportAllColumns(settings);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetches Report Filters By FilterId.
        /// </summary>
        [TestMethod]
        public void FetchReportFiltersByFilterId_Test()
        {
            int filterId = 1;
            string ecolabAccNum = "ABC";
            List<ReportFilterList> result = ribbonService.FetchReportFiltersDataByFilterId(filterId, ecolabAccNum);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }

        /// <summary>
        ///     Fetches Ribbon Option Data For Report.
        /// </summary>
        [TestMethod]
        public void FetchRibbonOptionDataForReport_Test()
        {
            int reportId = 1;
            int roleId  = 9;
            int languageId = 1;
            List<ReportRibbonOptions> result = ribbonService.FetchRibbonOptionDataForReport(reportId, 0, roleId,languageId);
            if (result != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsFalse(true, "Data is not available");
            }
        }
    }
}