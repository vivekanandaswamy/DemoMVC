﻿// -----------------------------------------------------------------------
// <copyright file="BatchServiceTest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchServiceTest </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Web.Service.Test.Service.Batch
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Entities.Batch;
    using Ecolab.Services.Interfaces.Batch;    
    using Ecolab.Services.Batch;
    using ServiceModel = Models.Batch;
    using System.Linq;

    [TestClass]
    public class BatchServiceTest  :TestBase
    {
        IBatchService batchService; 

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            batchService = new BatchService();
        }

        /// <summary>
        /// Test case for GetBatchCollectionDetails
        /// </summary>
        [TestMethod]
        public void GetBatchCollectionDetails_Test()
        {
            List<ServiceModel.BatchData> batchData = batchService.GetBatchCollectionDetails(10);

            if (batchData != null)
            {
                Assert.IsTrue(true, "Data available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

         /// <summary>
        /// Test case for GetBatchCustomerData
        /// </summary>
        //[TestMethod]
        //public void GetBatchCustomerData_Test()
        //{
        //   var batchData = batchService.GetBatchCollectionDetails();
        //   int batchId = Convert.ToInt32(batchData.Select(x => x.BatchId));
        //   List<ServiceModel.BatchCustomerData> batchCustomerData = batchService.GetBatchCustomerData(batchId);
        //}
    }
}
