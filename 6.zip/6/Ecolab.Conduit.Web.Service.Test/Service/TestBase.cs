﻿// -----------------------------------------------------------------------
// <copyright file="TestBase.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> Base class for Tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System.Configuration;
    using System.Globalization;
    using System.Threading;
    using Data.Access;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Services;
    using Services.Interfaces;    

    /// <summary>
    ///     TestBase
    /// </summary>
    [TestClass]
    public class TestBase
    {
        /// <summary>
        ///     User Id
        /// </summary>
        private const int userId = 1;

        /// <summary>
        ///     EcolabAccountNumber
        /// </summary>
        private string _ecolabAccountNumber;

        /// <summary>
        ///     plant Service
        /// </summary>
        protected IPlantService _plantService;

        /// <summary>
        ///     Gets User Id
        /// </summary>
        protected int UserId
        {
            get { return userId; }
        }

        /// <summary>
        ///     Gets Ecolab Account Number
        /// </summary>
        protected string EcolabAccountNumber
        {
            get { return _ecolabAccountNumber ?? ( _ecolabAccountNumber = GetPlantDetails().EcoalabAccountNumber ); }
        }

        /// <summary>
        ///     Test Initialization
        /// </summary>
        [TestInitialize]
        public void Init()
        {
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            Database.ApplicationMode = Entities.ApplicationMode.Local;
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture("en-US");
            _plantService = new PlantService();
        }

        /// <summary>
        ///     Gets Plant Details
        /// </summary>
        /// <returns>PlantModel</returns>
        protected Plant GetPlantDetails()
        {
            return _plantService.GetPlantDetails(UserId);
        }
    }
}