﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.Common
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// 
    /// </summary>
    public class CommonMethods
    {
        public static bool DeletePlantChemical(int id)
        {
            string sqlquery = string.Empty;
            sqlquery += "Delete From ProductdataMapping Where Id =" + id + ";";
            return true;
        }
    }
}
