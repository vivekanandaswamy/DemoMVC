﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ScreenDashboardMappingServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Visualization
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Visualization;
    using Services.Interfaces.Visualization;
    using Services.Visualization;

    /// <summary>
    ///     Summary description for DashboardServiceTest
    /// </summary>
    [TestClass]
    public class DashboardServiceTest : TestBase
    {
        /// <summary>
        ///     interface IDashboardService
        /// </summary>
        private IDashboardService dashboardService;

        //public DashboardServiceTest(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            dashboardService = new DashboardService();
        }

        /// <summary>
        ///     Get the Tunnel data
        /// </summary>
        [TestMethod]
        public void FetchTunnelData_Test()
        {
            int dashboardId = 1;
            string plantId = "2";
            List<Tunnel> tunnels = dashboardService.FetchTunnelData(dashboardId, plantId);

            if (tunnels.Count > 0)
            {
                Assert.IsTrue(true, "Get the list of Tunnel details");
            }
            else
            {
                Assert.IsTrue(true, "Tunnel details are not available");
            }           
        }

        /// <summary>
        ///     Get the Compartment data
        /// </summary>
        [TestMethod]
        public void FetchCompartmentData_Test()
        {
            string plantId = "1";
            int dashboardId = 1;
            List<Compartment> compartments = dashboardService.FetchCompartmentData(dashboardId, plantId);

            if (compartments.Count>0)
            {
                Assert.IsTrue(true, "Get the list of compartment details");
            }
            else
            {
                Assert.IsTrue(true, "Compartment details are not available");
            }            
        }

        /// <summary>
        ///     Get the DashboardsForHome data
        /// </summary>
        [TestMethod]
        public void FetchDashboardsForHome_Test()
        {
            List<DashboardsForHome> dashboardsForHome = dashboardService.FetchDashboardsForHome();

            if (dashboardsForHome.Count > 0)
            {
                Assert.IsTrue(true, "Get the list of Dashboards For Home ");
            }
            else
            {
                Assert.IsTrue(true, "Dashboards For Home details are not available");
            }
        }
    }
}