﻿// -----------------------------------------------------------------------
// <copyright file="ExternalDisplayServiceTest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ScreenDashboardMappingServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Visualization
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Visualization.Monitor;
    using Services.Interfaces.Visualization.Monitor;
    using Services.Visualization.Monitor;
    using System.Configuration;

    /// <summary>
    ///     Summary description for ScreenDashboardMappingServiceTest
    /// </summary>
    [TestClass]
    public class ExternalDisplayServiceTest : TestBase
    {
        /// <summary>
        ///     interface IShiftBreakService
        /// </summary>
        private IExternalDisplayService _visualizationService;

        //public ExternalDisplayServiceTest(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _visualizationService = new ExternalDisplayService();
        }

        /// <summary>
        ///     Get the Dashboard Vs Screen details
        /// </summary>
        [TestMethod]
        public void FetchMappingDetails_Test()
        {
            List<ExternalDisplay> details = _visualizationService.FetchMappingDetails();
            Assert.IsNotNull(details.Count > 0, "Get the list of Dashboard Vs Screen details");
        }

        /// <summary>
        ///     FetchDisplaySettings
        /// </summary>
        //[TestMethod]
        //public void FetchDisplaySettings_Test()
        //{
        //    string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
        //    ExternalDisplaySettings externalDisplaySettings = _visualizationService.FetchDisplaySettings(ecolabAccountNumber);

        //    if (externalDisplaySettings != null)
        //    {
        //        Assert.IsTrue(true, "Get the DisplaySettings");
        //    }
        //    else
        //    {
        //        Assert.IsTrue(true, "DisplaySettings are not available");
        //    }           
        //}
    }
}