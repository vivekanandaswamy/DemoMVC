﻿// -----------------------------------------------------------------------
// <copyright file="MonitorSetUpServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MonitorSetUpServiceTests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Visualization
{
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Visualization.Monitor;
    using Services.Interfaces.Visualization.Monitor;
    using Services.Visualization.Monitor;
    using System.Configuration;

    /// <summary>
    ///     Test class for MonitorSetUpServiceTests
    /// </summary>
    [TestClass]
    public class MonitorSetUpServiceTests : TestBase
    {
        /// <summary>
        ///     interface IMonitorSetupService
        /// </summary>
        private IMonitorSetupService monitorSetupService;

        /// <summary>
        ///     initialization of test
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            monitorSetupService = new MonitorSetupService();
        }

        /// <summary>
        ///     Test method for get monitor setup
        /// </summary>
        [TestMethod]
        public void FetchMonitorSetUpDetails_Test()
        {
            List<MonitorSetUp> result = monitorSetupService.FetchMonitorSetUpDetails("1");
            Assert.IsNotNull(result, "Monitor setup details are available.");
        }

        /// <summary>
        ///     Test method for get monitor setup
        /// </summary>
        [TestMethod]
        public void FetchMonitorSetUpDetailsById_Test()
        {
            List<MonitorSetUp> result = monitorSetupService.FetchMonitorSetUpDetailsById(4, "1");
        }

        /// <summary>
        ///     Test method for insert monitor setup
        /// </summary>
        [TestMethod]
        public void InsertMonitorSetUp_Test()
        {
            MonitorSetUp monitorSetUps = new MonitorSetUp()
            { 
                DashboardId = 1,
                DashboardName = "test", 
                WasherGroupTypeId = 1,
                WasherId = 1,
                MonitorId = "M-01",                 
                IsEnableParameter = true,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                IsEdit = true,
                Customer = true, 
                Formula = true, 
                Load = true,
                DisplayOnLogin= true,
                TimelineHours = 2,
                FormulaDisplayType= 2
            };

            int userId = 1;

            int result = monitorSetupService.InsertMonitorSetUp(monitorSetUps, userId);

            if (result > 0)
            {
                Assert.IsTrue(true, "Data has been inserted.");
            }
            else
            {
                Assert.IsTrue(true, "Data has not been inserted.");
            }
        }

        /// <summary>
        ///     Test method for update monitor setup
        /// </summary>
        [TestMethod]
        public void UpdateMonitorSetUp_Test()
        {
            MonitorSetUp monitorSetUps = new MonitorSetUp
            {
                
                DashboardId = 1,
                DashboardName = "test",
                WasherId = 1,
                WasherGroupTypeId = 1,
                WasherGroupTypeName="",
                MachineName="",
                MonitorId = "M-01",
                IsEnableParameter = true,
                IsEdit=true,
                IsDeleteMapping=true,
                Customer=true,
                Formula=true,
                Load=true,
                DisplayOnLogin=true,
                TimelineHours=2,
                FormulaDisplayType=1,
                FormulaDisplayTypeName="",
                SlideDuration=2,
                EfficiencyCalcType=2,
                EfficiencyCalcTypeName=null,
                MachineNameDispalyType=2
                //Id = 1,
                //EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                
            };

            int result = monitorSetupService.InsertMonitorSetUp(monitorSetUps, 1);
        }

        /// <summary>
        ///     Test method for delete monitor setup
        /// </summary>
        [TestMethod]
        public void DeleteMonitorSetUp_Test()
        {
            MonitorSetUp monitorSetUps = new MonitorSetUp { Id = 1, DashboardId = 1, EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };

            string result = monitorSetupService.DeleteMonitorSetUp(monitorSetUps, 1);
        }
    }
}