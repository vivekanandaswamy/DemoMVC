﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.ControllerSetup
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Conduit.Library.Enums;
    using Ecolab.Services.Interfaces.ControllerSetup;
    using Models.ControllerSetup;
    using Ecolab.Services.ControllerSetup;
    [TestClass]
    public class ControllerSetupServiceTest : TestBase
    {
        IControllerSetupService controllerSetupService;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            controllerSetupService = new ControllerSetupService();
        }

        /// <summary>
        /// Test Case for GetControllerSetupMetadata
        /// </summary>
        [TestMethod]
        public void GetControllerSetupMetadata_Test()
        {
            int tabId = 1;
            int controllerModelId = 1;
            int controllerTypeId = 9;
            List<MetaData> metaDatas = controllerSetupService.GetControllerSetupMetadata(tabId, controllerModelId, controllerTypeId,9);

            if(metaDatas.Count>0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for GetControllerSetupMetadataWithValues
        /// </summary>
        [TestMethod]
        public void GetControllerSetupMetadataWithValues_Test()
        {
            int tabId = 1;
            int controllerModelId = 1;
            string ecolabAccountNumber = "1";
            List<MetaData> metaDatas = controllerSetupService.GetControllerSetupMetadataWithValues(tabId, controllerModelId, ecolabAccountNumber,9);

            if (metaDatas.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for GetControllerSetupAdvanceMetadata
        /// </summary>
        [TestMethod]
        public void GetControllerSetupAdvanceMetadata_Test()
        {
            int tabId = 1;
            int controllerModelId = 1;
            string ecolabAccountNumber = "1";
            List<MetaData> metaDatas = controllerSetupService.GetControllerSetupAdvanceMetadata(tabId, controllerModelId, ecolabAccountNumber);

            if (metaDatas.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for GetControllerSetupAdvanceMetadataWithValues
        /// </summary>
        [TestMethod]
        public void GetControllerSetupAdvanceMetadataWithValues_Test()
        {
            int tabId = 1;
            int controllerModelId = 1;
            string ecolabAccountNumber = "1";
            List<MetaData> metaDatas = controllerSetupService.GetControllerSetupAdvanceMetadataWithValues(tabId, controllerModelId, ecolabAccountNumber);

            if (metaDatas.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for GetControllerDetails
        /// </summary>
        [TestMethod]
        public void GetControllerDetails_Test()
        {            
            string ecolabAccountNumber = "1";
            bool? canControlTunnel = null;
            List<Controller> Controllers = controllerSetupService.GetControllerDetails(ecolabAccountNumber, canControlTunnel);

            if (Controllers.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for GetControllerDetailById
        /// </summary>
        [TestMethod]
        public void GetControllerDetailById_Test()
        {
           int controllerId = 1;
           string ecolabAccountNumber = "1";

           Controller Controller = controllerSetupService.GetControllerDetailById(controllerId, ecolabAccountNumber);

           if (Controller != null)
           {
               Assert.IsTrue(true, "Data is available");
           }
           else
           {
               Assert.IsTrue(true, "Data is not available");
           }
        }

        /// <summary>
        /// Test Case for GetControllerModelsDetails
        /// </summary>
        [TestMethod]
        public void GetControllerModelsDetails_Test()
        {
            int regionId = 1;

            List<ControllerModel> ControllerModels = controllerSetupService.GetControllerModelsDetails(regionId);

            if (ControllerModels.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for GetControllerTypesDetails
        /// </summary>
        [TestMethod]
        public void GetControllerTypesDetails_Test()
        {
            int regionId = 1;

            List<ControllerType> ControllerTypes = controllerSetupService.GetControllerTypesDetails(regionId);

            if (ControllerTypes.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test Case for UpdateControllerListData
        /// </summary>
        [TestMethod]
        public void UpdateControllerListData_Test()
        {
            DateTime installedDate = DateTime.Now;
            Controller controller = new Controller()
            {
                ControllerId = 1,
                InstallDate = installedDate.AddMonths(-1),
                InstallDateAsString = DateTime.Now.ToString()
            };
            int userId = 1;
            string ecolabAccountNumber ="1";
            DateTime lastModifiedTimeStamp =  new DateTime();
            DateTime? lastModifiedTimestampAtCentral = DateTime.Now;

            controllerSetupService.UpdateControllerListData(controller,userId,ecolabAccountNumber,out lastModifiedTimeStamp,lastModifiedTimestampAtCentral);           
        }

        /// <summary>
        /// Test Case for DeleteControllerListData
        /// </summary>
        [TestMethod]
        public void DeleteControllerListData_Test()
        {
            int controllerId = 1;
            int userId = 1;
            string ecolabAccountNumber = "1";
            DateTime lastModifiedTimeStamp;
            DateTime? lastModifiedTimestampAtCentral = null;
            bool isDeleted = false;

            isDeleted = controllerSetupService.DeleteControllerListData(controllerId, userId, ecolabAccountNumber, out lastModifiedTimeStamp, lastModifiedTimestampAtCentral);

            if (isDeleted == true)
            {
                Assert.IsTrue(true, "Data is deleted");
            }
            else
            {
                Assert.IsTrue(true, "Data is not deleted");
            }
        }

        /// <summary>
        /// Test Case for SaveControllerSetupData
        /// </summary>
        [TestMethod]
        public void SaveControllerSetupData_Test()
        {

            List<ControllerSetupData> controllerSetupDatas = new List<ControllerSetupData>()
            {
                new ControllerSetupData()
                {
                    Active = true,
                    ControllerId = 1,
                    ControllerModelId = 1,
                    ControllerTypeId = 1,
                    EcolabAccountNumber = "1",
                    FieldGroupId = 1,
                    FieldId = 9,
                    FieldName = "FeildName",
                    FieldTagAddress = "Address",
                    FieldTagValue = "TagValue",
                    TabId = 1,
                    TopicName = "Name",
                    Value = "value"
                }
            };
               
            int userId = 1;
            DateTime lastModifiedTimeStamp;
            int id;

            id = controllerSetupService.SaveControllerSetupData(controllerSetupDatas, userId, out lastModifiedTimeStamp);

            if (id > 0)
            {
                Assert.IsTrue(true, "Data is saved");
            }
            else
            {
                Assert.IsTrue(true, "Data is not saved");
            }
        }
    }
}
