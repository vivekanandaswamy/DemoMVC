﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.ControllerSetup.Pumps
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Entities.ControllerSetup.Pumps;
    using Ecolab.Services.Interfaces.ControllerSetup.Pumps;
    using Models.Common;
    using ServiceModel = Models.ControllerSetup.Pumps;
    using Ecolab.Services.ControllerSetup.Pumps;
    using System.Configuration;

    [TestClass]
    public class PumpsServicesTest  :TestBase
    {
        IPumpsService pumpsService;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            pumpsService = new PumpsServices();
        }

        /// <summary>
        /// Test case for GetPumps
        /// </summary>
        [TestMethod]
        public void GetPumps_Test()
        {
            string ecolabAccountNum = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            int controlNum = 2279;
            string showOption = "";
            List<ServiceModel.PumpsModel> pumpsModels = pumpsService.GetPumps(ecolabAccountNum, controlNum,showOption);

            if(pumpsModels.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        /// <summary>
        /// Test case for GetProductList
        /// </summary>
        [TestMethod]
        public void GetProductList_Test()
        {
            string ecolabAccountNum = "040242802";
            List<ServiceModel.ProductModel> productModels = pumpsService.GetProductList(ecolabAccountNum);

            if (productModels.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }

        // commented the code in below test case "Record not in-synch between plant and central."
        // above error will display until the sync had happened
        /// <summary>
        /// Test case for UpdatePump
        /// </summary>
        [TestMethod]
        public void UpdatePump_Test()
        {
            ServiceModel.PumpsModel PumpsModel = new ServiceModel.PumpsModel()
            {
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                ControllerId = 2077,
                ControllerEquipmentId = 1,
                ControllerEquipmentTypeId = 1,
                ProductId = 7364,
                PumpCalibration = 12.4M,
                LfsChemicalName = "Test",
                KFactor = 12.5M,
                TunnelHold = false,
                FlowDetectorType =1,
                FlowSwitchAlarm = true,
                FlowMeterAlarm = true,
                FlowMeterType = 2,
                FlowAlarmDelay = 5,
                FlowMeterPumpDelay = 25,
                FlowMeterAlarmDelay = 50,
                LfsChemicalNameTag = "Test",
                KfactorTag = "FactorTag",
                CalibrationTag = "CalibrationTag"
            };
            int userId = 1;
            DateTime lastModifiedTimeStamp;
            DateTime? lastModifiedDateTimeAtCentral = DateTime.Now;

            //int id = pumpsService.UpdatePump(PumpsModel, userId, out lastModifiedTimeStamp, lastModifiedDateTimeAtCentral);

            //if (id > 0)
            //{
            //    Assert.IsTrue(true, "Data is updated");
            //}
            //else
            //{
            //    Assert.IsTrue(true, "Data is not updated");
            //}
        }

        /// <summary>
        /// Test case for GetModuleTagsDetails
        /// </summary>
        [TestMethod]
        public void GetModuleTagsDetails_Test()
        {
            int moduleId = 1;
            int moduleTypeId = 1;
            string ecolabAccountNum = "040242802";
            List<ModuleTagsModel> moduleTagsModel = pumpsService.GetModuleTagsDetails(moduleId, moduleTypeId, ecolabAccountNum);

            if (moduleTagsModel.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }
        }
    }
}
