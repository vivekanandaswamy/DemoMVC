﻿// -----------------------------------------------------------------------
// <copyright file="WasherServiceTest.cs" company="Ecolab">
// Unit test cases for WasherServiceTest.
// </copyright>
// <summary> Washer Service Test </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Washers
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Washers;
    using Services.Interfaces.Washers;
    using Services.Washers;
    using System.Configuration;

    /// <summary>
    ///     WasherServiceTest
    /// </summary>
    [TestClass]
    public class WasherServiceTest : TestBase
    {
        /// <summary>
        ///     interface IWasherServices
        /// </summary>
        private IWasherServices _washerServices;

        //public WasherServiceTest(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     get test for Washer Alarms
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _washerServices = new WasherServices();
        }

        /// <summary>
        ///     Get Washer Alarms
        /// </summary>
        [TestMethod]
        public void GetAlarmSetupDetailsTest()
        {
            IEnumerable<Alarms> washerAlarms = _washerServices.GetAlarmSetupDetails(1, 1, 1, "1",1,1);
            Assert.IsNotNull(washerAlarms, "Received washerAlarm Detail.");
        }

        /// <summary>
        ///     Get Washer Alarms
        /// </summary>
        [TestMethod]
        public void GetAlarmSetupDetails_When_MachineNumber_Not_Passed_Test()
        {
            IEnumerable<Alarms> washerAlarms = _washerServices.GetAlarmSetupDetails(1, 1, 0, "1",1,1);
            Assert.IsNotNull(washerAlarms, "Received washerAlarm Detail.");
        }

        /// <summary>
        ///     Get Washer Alarms
        /// </summary>
        [TestMethod]
        public void GetAlarmSetupDetails_When_No_Matching_Passed_Parameter_Test()
        {
            IEnumerable<Alarms> washerAlarms = _washerServices.GetAlarmSetupDetails(111, 111, 0, "1",1,1);
            Assert.IsNotNull(washerAlarms, "Received washerAlarm Detail.");
        }

        /// <summary>
        ///     Save Washer Alarm Status
        /// </summary>
        [TestMethod]
        public void SaveAlarmStatusTest()
        {
            Alarms alarm = new Alarms { ControllerModelId = 1, MachineNumber = 1, ControllerTypelId = 1, Active = true, AlarmMachineMappingIds = new List<int> { 1, 2 } };
            int result = _washerServices.SaveAlarmStatus(alarm, 1, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsTrue(result >= 0);
        }

        /// <summary>
        ///     Gets the washers details.
        /// </summary>
        [TestMethod]
        public void GetWashersDetails()
        {
            IEnumerable<Washers> washersDetails = _washerServices.GetWashersDetails(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 2);
            Assert.IsNotNull(washersDetails, "Received Washers Details.");
        }

        /// <summary>
        ///     Deletes the washer.
        /// </summary>
        [TestMethod]
        public void DeleteWasher()
        {
            DateTime lastModifiedTimeStamp;
            bool isDeleted;
            try {
                 isDeleted = _washerServices.DeleteWasher(true, 7, "040242802", 1, out lastModifiedTimeStamp);
                Assert.IsTrue(isDeleted, "Washer Deleted");
            }
            catch
            {
                
                Assert.IsFalse(false, "Washer does not exists");
            }
               
        }
    }
}