﻿// -----------------------------------------------------------------------
// <copyright file="TunnelServiceTest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Washers.Tunnel;
    using Services.ControllerSetup;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.Washers.Tunnel;
    using Services.Washers.Tunnel;
    using System.Configuration;

    /// <summary>
    ///     Tunnel Service Test
    /// </summary>
    [TestClass]
    public class TunnelServiceTest : TestBase
    {
        /// <summary>
        ///     The _controller setup service
        /// </summary>
        private IControllerSetupService controllerSetupService;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private ITunnelGeneralServices tunnelGeneralServices;

        [TestInitialize]
        public void TestInitialize()
        {
            tunnelGeneralServices = new TunnelGeneralServices();
            controllerSetupService = new ControllerSetupService();
        }

        /// <summary>
        ///     Gets the washers list test.
        /// </summary>
        [TestMethod]
        public void GetWashersListTest()
        {
            IEnumerable<WashersList> washersList = tunnelGeneralServices.GetWashersList("1", 1);
            Assert.IsNotNull(washersList, "Received Washers List.");
        }

        /// <summary>
        ///     Gets the press extractor list test.
        /// </summary>
        [TestMethod]
        public void GetPressExtractorListTest()
        {
            IEnumerable<PressExtractor> pressExtractor = tunnelGeneralServices.GetPressExtractorList(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(pressExtractor, "Received PressExtractor List.");
        }

        /// <summary>
        ///     Gets the transfer type list test.
        /// </summary>
        [TestMethod]
        public void GetTransferTypeListTest()
        {
            IEnumerable<PressExtractor> transferTypeList = tunnelGeneralServices.GetTransferTypeList(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            Assert.IsNotNull(transferTypeList, "Received TransferType List.");
        }


        // Commented as GetWasherModeList is not being called any where
        /// <summary>
        ///     Gets the washer mode list test.
        /// </summary>
        //[TestMethod]
        //public void GetWasherModeListTest()
        //{
        //    IEnumerable<PressExtractor> washerModeList = tunnelGeneralServices.GetWasherModeList(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 2279);
        //    Assert.IsNotNull(washerModeList, "Received Mode List.");
        //}

        /// <summary>
        ///     Saves the tunnel data test.
        /// </summary>
        [TestMethod]
        public void SaveTunnelDataTest()
        {
            short programNumber = 59 + 1;
            TunnelGeneral tunnelGenaral = new TunnelGeneral()
            {
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                WasherGroupId = 2538,
                Name = "UniqName",
                WasherModelName = "Arista",
                ControllerId = 2279,
                PlantWasherNumber = 543,
                WasherMode = 10,
                MaxLoad = 2,
                AweActive = true,
                NoofTanks = 1,
                NoofCompartments = 1,
                TransferType = 1,
                PressExtractor = 1,
                ProgramNumber = programNumber,
                Description = "Some Description",
                RegionId = 2,
                ETechWasherNumber = 12
            };

            int userId = 1;
            int role = 4;
            DateTime lastModifiedTimeStamp;
            // commented below line as creating a new tunnel with existing configuration is throwing DB exception
            //  tunnelGeneralServices.SaveTunnelData(tunnelGenaral, userId, out lastModifiedTimeStamp);
        }

        /// <summary>
        ///     Gets the tunnel data test.
        /// </summary>
        [TestMethod]
        public void GetTunnelDataTest()
        {
            TunnelGeneral tunnelData = tunnelGeneralServices.GetTunnelData(1, 2, "1");
            if (tunnelData != null)
            {
                Assert.IsNotNull(tunnelData, "Received Tunnel Data");
            }
            else
            {
                Assert.IsNull(tunnelData, "No data received for tunnel");
            }
        }

        /// <summary>
        ///     Updates the tunnel data.
        /// </summary>
        [TestMethod]
        public void UpdateTunnelData()
        {
            TunnelGeneral tunnelGenaral = new TunnelGeneral
            {
                Name = "UniqName",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                WasherGroupId = 2561,
                WasherModelName = "Arista",
                ControllerId = 2410,
                PlantWasherNumber = 1,
                WasherMode = 6,
                MaxLoad = 2,
                AweActive = true,
                NoofTanks = 1,
                NoofCompartments = 1,
                TransferType = 1,
                PressExtractor = 1,
                ProgramNumber = 2,
                Description = "Some Description",
                RegionId = 2,
                Id = 2284
            };
            DateTime lastModifiedTimeStamp;
            tunnelGeneralServices.SaveTunnelData(tunnelGenaral, 1, out lastModifiedTimeStamp);
        }
    }
}