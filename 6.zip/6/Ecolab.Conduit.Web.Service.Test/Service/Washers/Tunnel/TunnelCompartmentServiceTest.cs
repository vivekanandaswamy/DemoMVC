﻿// -----------------------------------------------------------------------
// <copyright file="TunnelCompartmentServiceTest.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel General  Service </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.Web.Service.Test.Service.Washers.Tunnel
{
    using Ecolab.Models.Washers.Tunnel;
    using Ecolab.Services.Interfaces.Washers.Tunnel;
    using Ecolab.Services.Washers.Tunnel;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Collections.Generic;

    /// <summary>
    /// Tunnel Compartment Service Test
    /// </summary>
    public class TunnelCompartmentServiceTest
    {
        /// <summary>
        /// The tunnel compartment services
        /// </summary>
        private ITunnelCompartmentServices tunnelCompartmentServices;

        /// <summary>
        /// Test Initialize
        /// </summary>
        /// <returns></returns>
        [TestInitialize]
        public void TestInitialize()
        {
            tunnelCompartmentServices = new TunnelCompartmentServices();
        }

        /// <summary>
        /// Get Water Inlet Drain List Test
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public void GetWaterInletDrainListTest()
        {
            IEnumerable<PressExtractor> objList = tunnelCompartmentServices.GetWaterInletDrainList();
            Assert.IsNotNull(objList, "Received Washers List.");
        }

        /// <summary>
        /// Get Water Flow List Test
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public void GetWaterFlowListTest()
        {
            IEnumerable<PressExtractor> objList = tunnelCompartmentServices.GetWaterFlowList(2);
            Assert.IsNotNull(objList, "Received Washers List.");
        }

        /// <summary>
        /// Pumps Products List Test
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public void PumpsProductsListTest()
        {
            IEnumerable<PumpAssociation> objList = tunnelCompartmentServices.PumpsProductsList("1", 164, 43);
            Assert.IsNotNull(objList, "Received Washers List.");
        }

        /// <summary>
        /// Savetunnel Compartment Data Test
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public void SavetunnelCompartmentDataTest()
        {
            var pumpAssociationList = new List<PumpAssociation>();

            var pumpAssociation = new PumpAssociation
            {
                ControllerEquipmentId = 1,
                ControllerEquipmentSetupId = 100,
                IsDeleted = true
            };
            pumpAssociationList.Add(pumpAssociation);
            pumpAssociation = new PumpAssociation
            {
                ControllerEquipmentId = 2,
                ControllerEquipmentSetupId = 101,
                IsDeleted = false
            };
            pumpAssociationList.Add(pumpAssociation);

            var tunnelCompartment = new TunnelCompartment
            {
                CompartmentNumber = 1,
                EcolabAccountNumber = "1",
                Id = 43,
                RecycledWaterInlet = true,
                SplitCompartment = true,
                Steam = true,
                TemperatureControlByPMR = true,
                UsePressExtractWater = true,
                WashStepId = 1,
                WaterFlowId = 1,
                WaterinletDrainId = 1,
                WaterLevel = 1,
                PumpAssociationList = pumpAssociationList,
            };
            tunnelCompartmentServices.SavetunnelCompartmentData(tunnelCompartment, 1);
        }
        /// <summary>
        /// Get Compartment Data
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public void GetCompartmentData()
        {
            TunnelCompartment objList = tunnelCompartmentServices.GetCompartmentData(43, 2, "1", 1);
            Assert.IsNotNull(objList, "Received Washers List.");
        }
    }
}