﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactServiceTests.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service.Washers.Conventional
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.Washers.Conventional;
    using Services.Interfaces.Washers.Conventional;
    using Services.Washers.conventional;
    using System.Data.SqlClient;
    using System.Configuration;

    /// <summary>
    ///     ControllerSetupServiceTests
    /// </summary>
    [TestClass]
    public class ConventionalServiceTests : TestBase
    {
        /// <summary>
        ///     interface IConventionalGeneralServices
        /// </summary>
        private IConventionalGeneralServices conventionalService;

        [TestInitialize]
        public void TestInitialize()
        {
            conventionalService = new ConventionalGeneralServices();
        }

        /// <summary>
        ///     Get Washers Model List
        /// </summary>
        [TestMethod]
        public void GetWashersModelListTest()
        {
            IEnumerable<WasherModelList> washerModelListData = conventionalService.GetWashersModelList("Conventional", 1);
            Assert.IsNotNull(washerModelListData, "Received Washer Model List Detail.");
        }

        /// <summary>
        ///     Get Washers Mode List
        /// </summary>
        [TestMethod]
        public void GetWasherModeListTest()
        {
            IEnumerable<WasherModeList> washerModeListData = conventionalService.GetWasherModeList("1", 165);
            Assert.IsNotNull(washerModeListData, "Received Washer Mode List Detail.");
        }

        /// <summary>
        ///     Get Washers Model Size List
        /// </summary>
        [TestMethod]
        public void GetWashersModelSizeListTest()
        {
            IEnumerable<WasherModelSize> washerModelSizeData = conventionalService.GetWashersModelSizeList("AMERICAN 200", 1, "Conventional");
            Assert.IsNotNull(washerModelSizeData, "Received Washer Size List Detail.");
        }

        /// <summary>
        ///     Get Lfs Washer List
        /// </summary>
        [TestMethod]
        public void GetLfsWasherListTest()
        {
            LfsWasherNumber lfsWasherListData = conventionalService.GetLfsWasherList(165, "1");
            if (lfsWasherListData != null)
            {
                Assert.IsNotNull(lfsWasherListData, "Received Lfs Washer List Detail.");
            }
            else
            {
                Assert.IsNull(lfsWasherListData, "No data received for Lfs Washer List Detail.");
            }
        }

        /// <summary>
        ///     Save Conventional Data
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(SqlException))]
        public void SaveConventionalDataTest()
        {            
            ConventionalGeneral conventionalGenaral = new ConventionalGeneral()
            {
                EcolabAccountNumber = "40242802",
                WasherGroupId = 2,                
                Name = "Test",
                ControllerId = 6,
                PlantWasherNumber = 2,
                WasherModeId = 1,
                MaxLoad = 10,
                AweActive = true,
                WasherModelId = 1,
                LfsWasher = 1,
                HoldDelay = 20,
                HoldSignal= true,
                EndOfFormula = 60,
                TargetTurnTime = 60,
                WaterFlushTime = 40,
                Description = "Description"                          
            };

            int userId = 1;
            int roleId = 4;
            DateTime lastModifiedTimeStamp;

            string result = conventionalService.SaveConventionalData(conventionalGenaral, userId, roleId, out lastModifiedTimeStamp);
           
            if(result != null)
            {
                Assert.IsTrue(true, "Data has been saved");
            }
            else
            {
                Assert.IsTrue(true, "Data has not been saved");
            }
        }

        /// <summary>
        ///     Update Conventional Data
        /// </summary>
        [TestMethod]
        public void UpdateConventionalDataTest()
        {
            ConventionalGeneral conventionalGenaral = new ConventionalGeneral()
            {
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                Id = 2277,
                WasherGroupId = 2537,
                Name = "ABC",
                ControllerId = 2287,
                PlantWasherNumber = 2,
                WasherModeId = 1,
                MaxLoad = 10,
                AweActive = true,
                WasherModelId = 1,
                LfsWasher = 3,
                HoldDelay = 20,
                HoldSignal = true,
                EndOfFormula = 65,
                TargetTurnTime = 60,
                WaterFlushTime = 40,
                Description = "Description"
            };
            DateTime lastModifiedTimeStamp;
            string result = conventionalService.UpdateConventionalData(conventionalGenaral, 1, 4, out lastModifiedTimeStamp);

            if (result != null)
            {
                Assert.IsTrue(true, "Data has been updated");
            }
            else
            {
                Assert.IsTrue(true, "Data has not been updated");
            }
        }
    }
}