﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ecolab.Services.Interfaces.Washers;
using Ecolab.Services.Washers;
using Ecolab.Models.Washers;
using System.Collections.Generic;

namespace Ecolab.Conduit.Web.Service.Test.Service.Washers
{
    /// <summary>
    ///     The Product Deviation tests
    /// </summary>
    [TestClass]
    public class ProductDeviationTests
    {

        /// <summary>
        ///     interface IProductDeviationService
        /// </summary>
        private IProductDeviationService productDeviationService;

        [TestInitialize]
        public void TestInitialize()
        {
            productDeviationService = new ProductDeviationService();
        }

        /// <summary>
        ///     Method to Save Deviation
        /// </summary>
        //[TestMethod]
        //public void SaveWasherDeviation()
        //{
        //    string EcolabAccountNumber = "040242802";
        //    List<ProductDeviation> productDeviationList = new List<ProductDeviation>();
        //    ProductDeviation objProductDeviation = new ProductDeviation
        //    {
        //        Id = 0,
        //        WasherId = 5,
        //        ControllerEquipmentSetupID = 100,
        //        ProductDeviationValue = 100
        //    };
        //    productDeviationList.Add(objProductDeviation);
        //    ProductDeviation objProductDeviation1 = new ProductDeviation
        //    {
        //        Id = 0,
        //        WasherId = 5,
        //        ControllerEquipmentSetupID = 101,
        //        ProductDeviationValue = 100
        //    };
        //    productDeviationList.Add(objProductDeviation1);
        //    ProductDeviation objProductDeviation2 = new ProductDeviation
        //    {
        //        Id = 0,
        //        WasherId = 5,
        //        ControllerEquipmentSetupID = 102,
        //        ProductDeviationValue = 100
        //    };
        //    productDeviationList.Add(objProductDeviation2);

        //    int result = productDeviationService.SaveProductDeviationData(productDeviationList, EcolabAccountNumber);
        //    if (result >= 0)
        //    {
        //        Assert.IsTrue(true, "Data has been saved");
        //    }
        //    else
        //    {
        //        Assert.IsTrue(true, "Data has not been saved");
        //    }
        //}
    }
}
