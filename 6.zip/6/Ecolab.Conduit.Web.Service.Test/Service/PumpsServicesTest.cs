﻿// -----------------------------------------------------------------------
// <copyright file="PumpsServicesTest.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary> plant contact tests </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models.ControllerSetup.Pumps;
    using Services.ControllerSetup.Pumps;
    using Services.Interfaces.ControllerSetup.Pumps;
    using System.Configuration;
    using Services;
    using System.Web;

    /// <summary>
    ///     Class PumpsServicesTest.
    /// </summary>
    [TestClass]
    public class PumpsServicesTest : TestBase
    {
        /// <summary>
        ///     The pumps service
        /// </summary>
        private IPumpsService pumpsService;

        //public PumpsServicesTest(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Initializes a new instance of the <see cref="PumpsServicesTest" /> class.
        /// </summary>
        /// <param name="plantService">The plant service.</param>
        /// <summary>
        ///     Tests the initialize.
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            CustomPrincipal custPrinciple = new CustomPrincipal("1");
            custPrinciple.UserId = 1;
            custPrinciple.UserRoleIds = "1";
            custPrinciple.UserRoles = "1";
            pumpsService = new PumpsServices();
        }

        /// <summary>
        ///     Gets the pumps test.
        /// </summary>
        [TestMethod]
        public void GetPumpsTest()
        {
            List<PumpsModel> pumpsList = pumpsService.GetPumps(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 2279, "true");
            Assert.IsNotNull(pumpsList, "Received Pumps List.");
        }

        /// <summary>
        ///     Gets the product list test.
        /// </summary>
        [TestMethod]
        public void GetProductListTest()
        {
            List<ProductModel> productList = pumpsService.GetProductList("1");
            Assert.IsNotNull(productList, "Received Product List.");
        }

        /// <summary>
        ///     Updates the pump.
        /// </summary>
        [TestMethod]
        public void UpdatePump()
        {
            DateTime lastSyncTime;
            var pumpsModel = new PumpsModel
            {
                ControllerEquipmentId = 1,
                ControllerEquipmentTypeId = 1,
                ControllerEquipmentSetupId = 1,
                ControllerId = 2291,
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
               // FlowMeterCalibration = 2,
                FlowMeterSwitchFlag = true,
                FlowSwitchTimeOut = 2,
                MaximumDosingTime = 200,
                ProductId = 183,
                PumpCalibration = 2.3M,
                CalibrationTag = "L_OZ1",
                ControllerTopicName = "UNIT3",
                KFactor = 6,
                KfactorTag = "L_KF1",
                LfsChemicalName = "Chemical1"
            };
            int productList = pumpsService.UpdatePump(pumpsModel, 1, out lastSyncTime, null);
            Assert.IsNotNull(productList, "Updated Pump Data");
        }
    }
}