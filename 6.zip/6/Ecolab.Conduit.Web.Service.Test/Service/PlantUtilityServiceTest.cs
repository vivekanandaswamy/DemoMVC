﻿namespace Ecolab.Conduit.Web.Service.Test.Service
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Services.Interfaces.PlantSetup;
    using Services.PlantSetup;
    using plantutilityModel = Models.PlantSetup;
    using System.Configuration;

    [TestClass]
    public class PlantUtilityServiceTest : TestBase
    {
        /// <summary>
        ///     interface IPlantUtilityService
        /// </summary>
        private IPlantUtilityService _plantUtilityService;

        /// <summary>
        ///     list for adding utility factors
        /// </summary>
        public static List<plantutilityModel.PlantUtilitySetup> lstPLantUtility { get; set; }

        //public PlantUtilityServiceTest(IPlantService plantService)
        //    : base(plantService)
        //{
        //}
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="plantService">Plant Service</param>
        /// <summary>
        ///     get test for controller details
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            _plantUtilityService = new PlantUtilityService();
        }

        /// <summary>
        ///     gets the plant utility details and checking there is utility or not
        /// </summary>
        [TestMethod]
        public void GetPlantUtilityDetailsTest()
        {
            //gets the utility details and assigning to a variable
            List<plantutilityModel.PlantUtilityFactorTypes> plantUtiltyDetails =
                _plantUtilityService.GetPlantUtilityDetails("1");
            //Testing the data and displaying the message 
            Assert.IsNotNull(plantUtiltyDetails, "Got Utility Details.");
        }

        /// <summary>
        ///     This method is for getting the free water types and checking the count.
        /// </summary>
        [TestMethod]
        public void GetFreeWaterDetailsTest()
        {
            // gets free water types for plant utility setup
            List<plantutilityModel.PlantUtilityWaterTypeMaster> utilityFreeWaterTypes = _plantUtilityService.GetFreeWaterDetails(1);
            // Checking free water types count is greater than zero then we are passing the test case.
            Assert.IsTrue(utilityFreeWaterTypes.Count > 0, "Got the Free Water types.");
        }

        /// <summary>
        ///     This method is for getting the gas oil types and checking the count.
        /// </summary>
        [TestMethod]
        public void GetGasoilTypesTest()
        {
            //gets the gas oil types for plant utility setup
            List<plantutilityModel.PlantUtilityGasoilTypes> utilityGasOilTypes = _plantUtilityService.GetGasoilTypes(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"));
            // Checking gas oil types count is greater than zero then we are passing the test case.
            Assert.IsTrue(utilityGasOilTypes.Count > 0, "Getting gas oil types.");
        }

        /// <summary>
        ///     This test method gets the dimensional units for plant-utility based on the region.
        /// </summary>
        [TestMethod]
        public void GetDimensionTypesTest()
        {
            //gets the required dimensions for the plant utility setup factors based on the region
            List<plantutilityModel.PlantUtilityDimensionTypes> utilityDimensionUnits = _plantUtilityService.GetDimensionTypes("1");
            //Checking the dimensional units are not null 
            Assert.IsNotNull(utilityDimensionUnits, "Got the utility dimensions based on the region.");
        }

        /// <summary>
        ///     This test method gets the default values for all the factor types for plant-utility.
        /// </summary>
        [TestMethod]
        public void GetPlantUtilityDetailsListTest()
        {
            //gets the defaults values for all the factors types. 
            List<plantutilityModel.PlantUtilityFactorTypes> utilityDetailsDefault = _plantUtilityService.GetPlantUtilityDetailsList(1);
            //checking the default utility details is not null
            Assert.IsNotNull(utilityDetailsDefault, "Got the default values for plant utility.");
        }

        /// <summary>
        ///     This test method is for saving the plant utility data into the database.
        /// </summary>
        [TestMethod]
        public void SavePlantUtilityDetailsTest()
        {
            int userId = 1;
            plantutilityModel.PlantUtilitySetup objPlantUtility = new plantutilityModel.PlantUtilitySetup { UtilityType = 2, FactorType = "", ColdTemp = 3, ColdPrice = 3, HotTemp = 3, HotPrice = 3, TemperedTemp = 3, TemperedPrice = 3, WasteWaterPrice = 3, Free1Temp = 3, Free1Price = 3, Free2Temp = 3, Free2Price = 3, Free3Temp = 3, Free3Price = 3, Energy = 3, ElectricityTarrif = 3, Location = "1", BoilerSteam = true, SteamPercentage = 3, BoilerPercentage = 3, StackPercentage = 3, RewashFactor = 3, ColdSoftTemp = 3, ColdSoftPrice = 3, HotHardTemp = 3, HotHardPrice = 3, ColdHardTemp = 3, ColdHardPrice = 3, HotSoftTemp = 3, HotSoftPrice = 3, Free1FactorType = "2", Free2FactorType = "2", Free3FactorType = "2", GasOilType = "3", EcoalabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber") };
            DateTime lastModifiedTimeStamp;
            //int id = _plantUtilityService.SavePlantUtilityDetails(objPlantUtility, userId, out lastModifiedTimeStamp);
            //Assert.IsTrue(id > 0, "Saved Plant Utility details.");
        }
    }
}