﻿using System;
using System.Collections.Generic;
using Ecolab.Models;
using Ecolab.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Configuration;

namespace Ecolab.Conduit.Web.Service.Test.Service
{
    [TestClass]
    public class WaterAndEnergyUsageCalculationTest : TestBase
    {
        /// <summary>
        /// Calculates the water and energy usage test.
        /// </summary>
        [TestMethod]
        public void CalculateWaterAndEnergyUsageTest()
        {
            List<WashStepWaterAndEnergyUsageModel> list = WaterAndEnergyUsageCalculation.GetWaterAndEnergyUsageForConventional(ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), 2537, 2277, 2);

            decimal coldWaterUsage = list.Where(x => x.WashStepNumber == 1).FirstOrDefault().ColdWaterUsage;

            Assert.IsTrue(Convert.ToDouble(coldWaterUsage) == 0);

        }
    }
}
