﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.SyncQueue
{
    using System;
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Ecolab.Services.Interfaces.SyncQueue;
    using Models.SyncConfigSettings;
    using Ecolab.Services.SyncQueue;
    using ServiceModel = Ecolab.Models.TcpMessageQueue;
    using Ecolab.Models.TcpMessageQueue;
    using Entities.TcpMessageQueue;

    [TestClass]
    public class SyncQueueServicesTest : TestBase
    {
        ISyncQueueServices syncQueueServices;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            syncQueueServices = new SyncQueueServices();
        }

        /// <summary>
        /// MS Unit test case for SaveTcpMessageQueueData
        /// </summary>
        [TestMethod]
        public void SaveTcpMessageQueueData_Test()
        {
            TcpMessageQueue objSyncQueueData = new TcpMessageQueue()
            {
                RequestMessage = "RequestMessage",
                EntityType = "EntityType",
                CreatedDate = DateTime.Now,
                UserId = 1,
                MessageId = 2,
                ActionType = 5,
                EcolabAccountNumber = "1"
            };

            int id = syncQueueServices.SaveTcpMessageQueueData(objSyncQueueData);

            if(id == 0)
            {
                Assert.IsTrue(true, "Data is saved");
            }
            else
            {
                Assert.IsTrue(true, "Data is not saved");
            }
        }

        /// <summary>
        /// MS Unit test case for GetQueueRequest
        /// </summary>
        [TestMethod]
        public void GetQueueRequest_Test()
        {
            List<TcpMessageQueueEntity> tcpMessageQueueEntity = syncQueueServices.GetQueueRequest();

            if (tcpMessageQueueEntity.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is not available");
            }           
        }
    }
}
