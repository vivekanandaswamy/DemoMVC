﻿

namespace Ecolab.Conduit.Web.Service.Test.Service.StorageTanks
{
    using System;   
    using System.Collections.Generic;
    using Microsoft.VisualStudio.TestTools.UnitTesting;   
    using Ecolab.Services.Interfaces.StorageTanks;
    using Ecolab.Services.StorageTanks;
    using Ecolab.Models.StorageTanks;
    using Ecolab.Conduit.Library.Enums;
    using System.Configuration;
    

    [TestClass]
    public class StorageTanksServiceTest : TestBase
    {
        IStorageTanksService storageTanksService;
        Tanks tanks;

        /// <summary>
        /// Test initialization
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            storageTanksService = new StorageTanksService();
            tanks = new Tanks()
            {
                TankName = "TankName",
                EcolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber"),
                LowLevel = 1,
                ControllerId = 1,
                EmptyLevel = 12,
                CallibrationLevel = 4,
                LevelDeviation = 2,
                Size = 10,
                InputType = "InputType",
                ProductId = 183,
                CurrentLevel = 1,
                SizeTag = "SizeTag",
                LevelDeviationTag = "LevelDeviationTag",
                CurrentLevelTag = "CurrentLevelTag",
                LowLevelDisplay = 3,
                EmptyLevelDisplay = 3,
                CalibrationLevelDisplay = 8,
                CurrentLevelDisplay = 5,
                LevelDeviationDisplay = 0,
                SizeDisplay = 1
            };
        }

        /// <summary>
        /// Test Case for GetTanksDetails
        /// </summary>
        [TestMethod]
        public void GetTanksDetails_Test()
        {
            string ecolabAccountNumber = "1";
            int id = 0;
            List<Tanks> tanks = storageTanksService.GetTanksDetails(ecolabAccountNumber, id);
            
            if (tanks.Count > 0)
            {
                Assert.IsTrue(true, "Data is available");
            }
            else
            {
                Assert.IsTrue(true, "Data is available");
            }
        }

        /// <summary>
        /// Test Case for DeleteStorageTanks
        /// </summary>
        [TestMethod]
        public void DeleteStorageTanks_Test()
        {
            int tankId = 2160;
            int userId = 1;
            string ecolabAccountNumber = ConfigurationManager.AppSettings.Get("EcolabAccountNumber");
            DateTime lastModifiedTimeStamp;

            bool isDeleted = storageTanksService.DeleteStorageTanks(tankId, userId, ecolabAccountNumber, out lastModifiedTimeStamp);

            if (isDeleted == true)
            {
                Assert.IsTrue(true, "Data is deleted");
            }
            else
            {
                Assert.IsTrue(true, "Data is not deleted");
            }
        }

        //Commented below test as procedure corresponding to this test is creating 2 storage tanks
        ///// <summary>
        ///// Test Case for SaveStorageTank
        ///// </summary>
        //[TestMethod]
        //public void SaveStorageTank_Test()
        //{
        //    int userId =1;
        //    tanks.TankName = DateTime.Now.ToString();
        //    DateTime lastModifiedTimeStamp;

        //    int id = storageTanksService.SaveStorageTank(tanks, userId, out lastModifiedTimeStamp);

        //    if (id == 0)
        //    {                
        //        Assert.IsTrue(true, "Data is saved");
        //    }
        //    else
        //    {
        //        bool isDeleted = storageTanksService.DeleteStorageTanks(id, userId, ConfigurationManager.AppSettings.Get("EcolabAccountNumber"), out lastModifiedTimeStamp);
        //        Assert.IsTrue(true, "Data is not saved");
        //    }
        //}

        /// <summary>
        /// Test Case for UpdateStorageTank
        /// </summary>
        [TestMethod]
        public void UpdateStorageTank_Test()
        {
            tanks.TankId = 2160;
            tanks.TankName = "UpdateTank";
            int userId = 1;
            DateTime lastModifiedTimeStamp;

            int id = storageTanksService.UpdateStorageTank(tanks, userId, out lastModifiedTimeStamp);

            if (id > 0)
            {
                Assert.IsTrue(true, "Data is updated");
            }
            else
            {
                Assert.IsTrue(true, "Data is not updated");
            }
        }

        /// <summary>
        /// Test Case for ValidateAndSaveStorageTanksDetails
        /// </summary>
        [TestMethod]
        public void ValidateAndSaveStorageTanksDetails_Test()
        {          
            int userId =1;
            TcdAdminMessageTypes tcdAdminMessageTypes = new TcdAdminMessageTypes();
            int errorCode;
            DateTime lastModifiedTimeStamp;
          
            var moduleTagsModel = storageTanksService.ValidateAndSaveStorageTanksDetails(tanks, userId, tcdAdminMessageTypes, out errorCode, out lastModifiedTimeStamp);

            if (moduleTagsModel > 0)
            {
                Assert.IsTrue(true, "Data is deleted");
            }
            else
            {
                Assert.IsTrue(true, "Data is not deleted");
            }
        }

        /// <summary>
        /// Test Case for GetModuleTagsDetails
        /// </summary>
        [TestMethod]
        public void GetModuleTagsDetails_Test()
        {
            int tankId =1;
            int moduleTypeId =2;
            string ecolabAccountNumber = "1";

            var moduleTagsModel = storageTanksService.GetModuleTagsDetails(tankId, moduleTypeId, ecolabAccountNumber);

            if (moduleTagsModel != null)
            {
                Assert.IsTrue(true, "Data is deleted");
            }
            else
            {
                Assert.IsTrue(true, "Data is not deleted");
            }
        }
    }
}
