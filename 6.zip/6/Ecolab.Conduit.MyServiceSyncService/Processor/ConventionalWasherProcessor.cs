﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasherProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Conventional Washer processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access.ControllerSetup;
    using Access.WasherGroup;
    using Access.Washers;
    using Access.Washers.Conventional;
    using AutoMapper;
    using Common;
    using Ecolab.Services.Washers.conventional;
    using Entities;
    using Entities.ControllerSetup;
    using Entities.WasherGroup;
    using Entities.Washers;
    using Entities.Washers.Conventional;
    using log4net;
    using MyServiceAccess;

    public class ConventionalWasherProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int controllerId = Convert.ToInt32(ConfigurationManager.AppSettings["ControllerConventionId"]);

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int userId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Save Method for MyService
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync Conventional Washers for Plant :" + ecolabAccountNumber);
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "ConventionalWasher");
            DateTime myServiceTime = DateTime.Now.AddYears(-100);

            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                Log.Info("Conventional Washers: Since there are records in central so washers will be saved in MyService");
                SaveConventionalWasherListInMyService(log, ecolabAccountNumber);
            }
            else
            {
                Log.Info("First Time Synch Start for plant " + ecolabAccountNumber);
                SaveInConduitForFirstTimeSynch(myServiceTime, ecolabAccountNumber, log);
            }
        }

        /// <summary>
        /// Saving MyService data in Conduit for First Time Synch.
        /// </summary>
        /// <param name="myServiceTime">myServiceTime</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="log">MyService Sync log</param>
        public void SaveInConduitForFirstTimeSynch(DateTime myServiceTime, string ecolabAccountNumber, MyServiceSyncLog log)
        {
            Log.Info("Conventional Washers: Getting Conventional WasherGroups. " + ecolabAccountNumber);
            List<Entities.WasherGroup.WasherGroup> washerGroupList = GetMyServiceWasherGroupDetails(myServiceTime, ecolabAccountNumber);

            if (washerGroupList != null && washerGroupList.Count > 0)
            {
                foreach (var washerGroup in washerGroupList)
                {
                    Log.Info("Conventional Washers: Getting list of Conventional Washer from My Service of washer group " + washerGroup.WasherGroupName);
                    List<ConventionalGeneral> myserviceConventionalGeneralList = GetMyServiceConventionalDetails(myServiceTime, ecolabAccountNumber, washerGroup);

                    int washerGroupId = GetWasherGroupId(washerGroup, ecolabAccountNumber);
                    foreach (var item in myserviceConventionalGeneralList)
                    {
                        item.WasherGroupId = washerGroupId;
                    }
                    Log.Info("Convention Washers :: " + MyServiceCommon.SerializeToJsonFromEntity<List<ConventionalGeneral>>(myserviceConventionalGeneralList));
                    SaveConventionalData(myserviceConventionalGeneralList, ecolabAccountNumber);
                }
            }
            else
            {
                Log.Info("Conventional Washers: No Washer Group Present in Myservice for Syncing Conventional Washer. " + ecolabAccountNumber);
            }

            if (responseFlag)
            {
                Log.Info("Syncing Success for ConventionalWasher  " + ecolabAccountNumber);
                if (log != null)
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ConventionalWasher", "Yes");
                }
            }
            else
            {
                Log.Info("Syncing Fail for ConventionalWasher" + ecolabAccountNumber);
                if (log != null)
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ConventionalWasher", "Fail");
                }
            }
        }

        /// <summary>
        /// Get MyService Conventional Details
        /// </summary>
        /// <param name="myServiceTime">The myservice Time</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="washerGroup">The washer group details</param>
        /// <returns>List of conventional general details</returns>
        private List<ConventionalGeneral> GetMyServiceConventionalDetails(DateTime myServiceTime, string ecolabAccountNumber, WasherGroup washerGroup)
        {
            try
            {
                List<ConventionalGeneral> myserviceConventionalGeneralList =
                        ConventionalWasherAccess.GetConventionalDetails(washerGroup.MyServiceWasherGroupGuid,ecolabAccountNumber, myServiceTime);
                return myserviceConventionalGeneralList;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ConventionalWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Get MyService Washer Group Details
        /// </summary>
        /// <param name="myServiceTime">The Myservice Time</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>List of washer group details</returns>
        private List<WasherGroup> GetMyServiceWasherGroupDetails(DateTime myServiceTime, string ecolabAccountNumber)
        {
            try
            {
                List<Entities.WasherGroup.WasherGroup> washerGroupList = WasherGroupsAccess.GetWasherGroupsDetails(ecolabAccountNumber, myServiceTime).Where(t => t.WasherGroupTypeId == 1).ToList();
                return washerGroupList;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ConventionalWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saving Conventional General Data in conduit.
        /// </summary>
        /// <param name="myserviceConventionalGeneralList">myserviceConventionalGeneralList</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        public void SaveConventionalData(List<ConventionalGeneral> myserviceConventionalGeneralList, string ecolabAccountNumber)
        {
            ConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();

            int response = 0;
            foreach (var conventionalGeneral in myserviceConventionalGeneralList)
            {
                //Default Values
                Controller conduitController = ControllerSetupAccess.GetControllerDetailById(0, ecolabAccountNumber);
                if (conduitController == null)
                {
                    ConventionalWasherAccess.CreateVirtualController(ecolabAccountNumber);
                }
                conventionalGeneral.ControllerId = controllerId;
                conventionalGeneral.WasherModeId = 0;
                conventionalGeneral.AweActive = false;
                conventionalGeneral.EndOfFormula = 99;
                conventionalGeneral.LfsWasher = null;
                conventionalGeneral.EcolabAccountNumber = ecolabAccountNumber;
                if (conventionalGeneral.Name != null)
                {
                    conventionalGeneral.Name = conventionalGeneral.Name.TrimEnd();
                }
                DateTime lastModifiedTime = DateTime.UtcNow;
                IEnumerable<WasherModelSize> washerModelSize =
                    ConventionalGeneralAccess.GetWasherModeSizeList(conventionalGeneral.ModelName, conventionalGeneral.RegionId, "Conventional", true).Where(t => t.MyServiceMCHId == conventionalGeneral.MyServiceMCHId).ToList();
                foreach (var item in washerModelSize)
                {
                    conventionalGeneral.WasherModelId = item.WasherModelId;
                }
                Log.Info("Conventional Washers: SaveMyServiceConventionalData: " + conventionalGeneral);

                Ecolab.Models.Washers.Conventional.ConventionalGeneral objData = Mapper.Map<ConventionalGeneral, Ecolab.Models.Washers.Conventional.ConventionalGeneral>(conventionalGeneral);

                SaveConventionalDataInConduit(conventionalGeneralServices, ref response, ref lastModifiedTime, objData);
            }
            if (response < 0)
            {
                responseFlag = false;
                Log.Info("Conventional Washers: Sync fail. " + ecolabAccountNumber);
            }
        }

        /// <summary>
        /// Save Conventional Data In Conduit
        /// </summary>
        /// <param name="conventionalGeneralServices">conventional General Services</param>
        /// <param name="response">Parameter Responce</param>
        /// <param name="lastModifiedTime">last Modified Time</param>
        /// <param name="objData">Conventional data</param>
        private void SaveConventionalDataInConduit(ConventionalGeneralServices conventionalGeneralServices, ref int response, ref DateTime lastModifiedTime, Ecolab.Models.Washers.Conventional.ConventionalGeneral objData)
        {
            try
            {
                List<Ecolab.Models.Washers.Conventional.ConventionalGeneral> washerList = conventionalGeneralServices.GetConventionalDataForResync(null, null, objData.EcolabAccountNumber, true);
                bool saveInEnvision = Convert.ToBoolean(ConfigurationManager.AppSettings["SaveInEnvision"]);

                if (washerList != null && washerList.Count > 0 && washerList.Where(t => t.MyServiceCustMchGuid == objData.MyServiceCustMchGuid && t.MyServiceCustMchGrpGuid == objData.MyServiceCustMchGrpGuid && t.EcolabAccountNumber == objData.EcolabAccountNumber).ToList().Count > 0)
                {
                    var washer = washerList.Where(t => t.MyServiceCustMchGuid == objData.MyServiceCustMchGuid && t.MyServiceCustMchGrpGuid == objData.MyServiceCustMchGrpGuid && t.EcolabAccountNumber == objData.EcolabAccountNumber).FirstOrDefault();

                    if (saveInEnvision)
                    {
                        conventionalGeneralServices.SaveControllerSystemInEnvisionFromMyService(washer);
                    }
                }
                else
                {
                    response = conventionalGeneralServices.SaveMyServiceConventionalData(objData, userId, out lastModifiedTime, DateTime.UtcNow);
                    objData.Id = response;
                    if (saveInEnvision)
                    {
                        conventionalGeneralServices.SaveControllerSystemInEnvisionFromMyService(objData);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error in ConventionalWasherProcessor : " + ex.ToString());
                Log.Error("Conventional washer : " + MyServiceCommon.SerializeToJsonFromEntity<Ecolab.Models.Washers.Conventional.ConventionalGeneral>(objData));
                responseFlag = false;
            }
        }

        /// <summary>
        /// Get Washer Group Id
        /// </summary>
        /// <param name="washerGroup">washer Group Details </param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <returns>washer group id</returns>
        private int GetWasherGroupId(WasherGroup washerGroup, string ecolabAccountNumber)
        {
            List<WasherGroup> washerGroups = WasherGroupAccess.GetWasherGroupDetails(-1, ecolabAccountNumber);

            if (washerGroups.Where(t => t.MyServiceWasherGroupGuid == washerGroup.MyServiceWasherGroupGuid).ToList().Count > 0)
            {
                washerGroup.WasherGroupId = washerGroups.Where(t => t.MyServiceWasherGroupGuid == washerGroup.MyServiceWasherGroupGuid).FirstOrDefault().WasherGroupId;
            }

            return washerGroup.WasherGroupId;
        }

        /// <summary>
        ///     Save Washer List In MyService
        /// </summary>
        /// <param name="log">Myservice sync log object.</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        public void SaveConventionalWasherListInMyService(MyServiceSyncLog log, string ecolabAccountNumber)
        {
            Log.Info("Conventional Washers: Getting Washer Groups for washers to sync in myService. " + ecolabAccountNumber);
            List<WasherGroup> conduitWasherGroupDetails = GetConduitWasherGroupDetails(ecolabAccountNumber);
            Log.Info("Conventional Washers: List of washer Groups in conduit: " + MyServiceCommon.SerializeToJsonFromEntity<List<WasherGroup>>(conduitWasherGroupDetails));
            List<ConventionalGeneral> washers = new List<ConventionalGeneral>();
            if (conduitWasherGroupDetails != null && conduitWasherGroupDetails.Count > 0)
            {
                foreach (WasherGroup conduitWasherGroup in conduitWasherGroupDetails)
                {
                    if (conduitWasherGroup.WasherGroupTypeId == 1)
                    {
                        washers = GetConduitConventionalWasherList(ecolabAccountNumber, washers, conduitWasherGroup);
                        washers = washers.Where(t => t.LastModifiedTimestamp > log.MyServiceLastSynchTime).ToList();
                        Log.Info("Conventional Washers: List of Washer to be save in Myservice: " + MyServiceCommon.SerializeToJsonFromEntity<List<ConventionalGeneral>>(washers));
                        this.SaveWasherListInMyService(washers, conduitWasherGroup);
                    }
                    else
                    {
                        Log.Info("Conventional Washers: No Conventional Washer present for Plant : " + ecolabAccountNumber);
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for ConventionalWasher  " + ecolabAccountNumber);
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ConventionalWasher", "Yes");
                    }
                }
                else
                {
                    Log.Info("Syncing Fail for ConventionalWasher" + ecolabAccountNumber);
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ConventionalWasher", "Fail");
                    }
                }
            }
        }

        /// <summary>
        /// Get Conduit Conventional Washer List
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <param name="washers">Conventional general details</param>
        /// <param name="conduitWasherGroup">conduit Washer Group</param>
        /// <returns>List of ConventionalGeneral</returns>
        private List<ConventionalGeneral> GetConduitConventionalWasherList(string ecolabAccountNumber, List<ConventionalGeneral> washers, WasherGroup conduitWasherGroup)
        {
            try
            {
                washers = ConventionalGeneralAccess.GetConventionalWasherList(conduitWasherGroup.WasherGroupId,
                        ecolabAccountNumber, true);
                return washers;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ConventionalWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Get Conduit Washer GroupDetails
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <returns>conduit Washer Group Details</returns>
        private List<WasherGroup> GetConduitWasherGroupDetails(string ecolabAccountNumber)
        {
            try
            {
                List<WasherGroup> conduitWasherGroupDetails = WasherGroupAccess.GetWasherGroupDetails(-1, ecolabAccountNumber, true);
                return conduitWasherGroupDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ConventionalWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Save Washer List In MyService
        /// </summary>
        /// <param name="washerList">List of Washer for a particular Group</param>
        /// <param name="conduitWasherGroup">conduit Washer Group</param>
        public void SaveWasherListInMyService(List<ConventionalGeneral> washerList, WasherGroup conduitWasherGroup)
        {
            int response = 0;
            int serviceItemResponse = 0;
            foreach (ConventionalGeneral washer in washerList)
            {
                Log.Info("Conventional Washers: Washer to be save in MyService: " + MyServiceCommon.SerializeToJsonFromEntity<ConventionalGeneral>(washer));
                try
                {
                    response = ConventionalWasherAccess.SaveConventionalGeneralInMyService(washer);
                    serviceItemResponse = ConventionalWasherAccess.SaveConventionalGeneralInServiceItem(washer);
                    if (response > 0 || serviceItemResponse > 0)
                    {
                        responseFlag = false;
                    }
                    else
                    {
                        responseFlag = true;
                    }
                    if (response == 0)
                    {
                        List<WasherGroupFormula> washerGroupFormulas = ConventionalWasherFormulaAccess.GetWasherGroupFormula(conduitWasherGroup.EcolabAccountNumber, DateTime.Now.AddYears(-100), conduitWasherGroup.MyServiceWasherGroupGuid);
                        if (washerGroupFormulas != null && washerGroupFormulas.Count > 0)
                        {
                            foreach (WasherGroupFormula washerGroupFormula in washerGroupFormulas)
                            {
                                ConventionalWasherFormulaAccess.SaveFormulaMachineRefrenceInMyService(washerGroupFormula, conduitWasherGroup, washer);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in ConventionalWasherProcessor for plant : " + ex);
                    Log.Error("Data :: " + MyServiceCommon.SerializeToJsonFromEntity<ConventionalGeneral>(washer));
                    responseFlag = false;
                }
                if (response != 0)
                {
                    responseFlag = false;
                }
            }
        }

        /// <summary>
        /// Get Washers List To Save In MyService
        /// </summary>
        /// <param name="conduitWasherGroup">conduit Washer Group</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>list of washers</returns>
        public List<Washers> GetWashersListToSaveInMyService(WasherGroup conduitWasherGroup, string ecolabAccountNumber)
        {
            List<Washers> washers = new List<Washers>();
            Log.Info("Getting list of Washer for EcolabAccountNumber : " + ecolabAccountNumber);
            washers = WashersAccess.GetWashersDetails(ecolabAccountNumber, conduitWasherGroup.WasherGroupId);
            return washers;
        }

        /// <summary>
        /// Save Not implemented
        /// </summary>
        /// <param name="plants">List of plant details</param>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }
    }
}