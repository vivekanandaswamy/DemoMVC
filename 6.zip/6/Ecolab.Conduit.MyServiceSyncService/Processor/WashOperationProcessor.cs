﻿// -----------------------------------------------------------------------
// <copyright file="WashOperationProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The wash operation processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.WasherGroup;
    using log4net;

    /// <summary>
    /// WashOperationProcessor class
    /// </summary>
    public class WashOperationProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Wash Operation details from myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            Log.Info("Started sync For WashOperation");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "WashStep");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<WashStep> myserviceWashOperationDetails = GetMyServiceWashOperationDetails(myServiceTime);

            ProcessMyServiceObject(plants, log, myserviceWashOperationDetails);
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myserviceWashOperationDetails">MyService Object</param>
        public void ProcessMyServiceObject(List<Plant> plants, MyServiceSyncLog log, List<WashStep> myserviceWashOperationDetails)
        {
            if (myserviceWashOperationDetails != null && myserviceWashOperationDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Insert Or Update WashOperation data into Central");
                Log.Info("Total WashOperation :: " + myserviceWashOperationDetails.Count);
                foreach (WashStep item in myserviceWashOperationDetails)
                {
                    Log.Info("WashOperation Detail : " + MyServiceCommon.SerializeToJsonFromEntity<WashStep>(item));
                    InsertOrUpdateWashOperationDetails(item);
                }

                Log.Info("Insert Or Update WashOperation data into Local Plants");
                foreach (var plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Ecolab.Models.WasherGroup.WashStep> washOperations = Mapper.Map<List<WashStep>, List<Models.WasherGroup.WashStep>>(myserviceWashOperationDetails);
                        response = Push.PushMasterData<List<Ecolab.Models.WasherGroup.WashStep>>(washOperations, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceWashOperation);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "WashOperation");
                            responseFlag = false;
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for WashOperation");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "WashStep", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for WashOperation");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "WashStep", "Fail");
                }
            }
        }

        /// <summary>
        /// Insert or Update Wash Operation in Central
        /// </summary>
        /// <param name="myserviceWashOperation">Wash Operation from MyService</param>
        public int InsertOrUpdateWashOperationDetails(WashStep myserviceWashOperation)
        {
            try
            {
                myserviceWashOperation.StepId = Access.WasherGroup.WasherGroupFormulaAccess.SaveMyServiceWashOperationDetails(myserviceWashOperation);
                Access.WasherGroup.WasherGroupFormulaAccess.SaveMyServiceWashOperationLocaleDetails(myserviceWashOperation);
                return myserviceWashOperation.StepId;
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in ProductMasterProcessor :: " + ex.ToString());
                Log.Error("WashOperation Detail : " + MyServiceCommon.SerializeToJsonFromEntity<WashStep>(myserviceWashOperation));
                return 0;
            }
        }

        /// <summary>
        /// Get MyService Wash Operation Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">Last Sync Time</param>
        /// <returns>List of Wash Operation</returns>
        public List<WashStep> GetMyServiceWashOperationDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<WashStep> myserviceWashOperationDetails = WashOperationAccess.GetWashOperationDetails(lastSyncTimeInCentral);
                return myserviceWashOperationDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ProductMasterProcessor :: " + ex.ToString());
                return null;
            }
        }
    }
}
