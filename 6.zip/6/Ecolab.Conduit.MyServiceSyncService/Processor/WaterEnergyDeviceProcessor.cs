﻿// -----------------------------------------------------------------------
// <copyright file="WaterEnergyDeviceProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The WaterEnergyDevice processor class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access.PlantSetup;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Entities;
    using Entities.PlantSetup;
    using log4net;
    using Newtonsoft.Json;

    /// <summary>
    /// WaterEnergyDeviceProcessor Class
    /// </summary>
    public class WaterEnergyDeviceProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(WaterEnergyDeviceProcessor));

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save WaterEnergyDevice from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync WaterEnergyDevice for Plant :" + ecolabAccountNumber);

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "WaterAndEnergy");

            DateTime myServiceTime = DateTime.UtcNow.AddYears(-100);
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = log.MyServiceLastSynchTime;
                ProcessWaterEnergyDeviceToSaveInMyService(ecolabAccountNumber, myServiceTime, log);
            }
            else
            {
                ProcessWaterEnergyDeviceToSaveInConduit(ecolabAccountNumber, myServiceTime, log);
            }
        }

        /// <summary>
        /// Get water energy data to save in MyService
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        /// <param name="myServiceTime"></param>
        /// <param name="log"></param>
        private void ProcessWaterEnergyDeviceToSaveInMyService(string ecolabAccountNumber, DateTime myServiceTime, MyServiceSyncLog log)
        {
            List<Utility> waterEnergyDevices = UtilityAccess.GetUtilityyDetails(ecolabAccountNumber, true).Where(t => t.LastModifiedTimestamp > myServiceTime).ToList();

            foreach (var item in waterEnergyDevices)
            {
                item.DeviceModelId = UtilityAccess.GetMyServiceWtrEnrgDvcIdFromConduit(item.DeviceModelId);
            }

            if (waterEnergyDevices != null && waterEnergyDevices.Count > 0)
            {
                Log.Info("Total no of WaterEnergyDevices :" + waterEnergyDevices.Count);
                Log.Info("Water And Energy Details to save in myService:: " + MyServiceCommon.SerializeToJsonFromEntity<List<Utility>>(waterEnergyDevices));
                foreach (Utility waterEnergyDevice in waterEnergyDevices)
                {
                    try
                    {
                        SavewaterEnergyDeviceInMyService(waterEnergyDevice);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in WaterEnergyDeviceProcessor : " + ex.ToString());
                        responseFlag = false;
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing success for WaterEnergyDevice of plant : " + ecolabAccountNumber);

                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WaterAndEnergy", "Yes");
                }
                else
                {
                    Log.Info("Syncing fail for WaterEnergyDevice of plant : " + ecolabAccountNumber);

                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WaterAndEnergy", "Fail");
                }
            }
        }

        /// <summary>
        /// Get water energy data to save in conduit
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        /// <param name="myServiceTime"></param>
        /// <param name="log"></param>
        private void ProcessWaterEnergyDeviceToSaveInConduit(string ecolabAccountNumber, DateTime myServiceTime, MyServiceSyncLog log)
        {
            List<Utility> waterEnergyDevices = WaterEnergyDeviceAccess.GetWaterEnergyDevice(ecolabAccountNumber, myServiceTime);
            Log.Info("Water And Energy Details :: " + MyServiceCommon.SerializeToJsonFromEntity<List<Utility>>(waterEnergyDevices));

            foreach (var item in waterEnergyDevices)
            {
                item.DeviceModelId = UtilityAccess.GetConduitDeviceModelId(item.DeviceModelId);
                item.DeviceTypeId = UtilityAccess.GetConduitDeviceTypeId(item.DeviceTypeId);
                item.DeviceName = "WaterAndEnergy";
            }

            if (waterEnergyDevices != null && waterEnergyDevices.Count > 0)
            {
                Log.Info("Total no of WaterEnergyDevices :" + waterEnergyDevices.Count);
                foreach (Utility waterEnergyDevice in waterEnergyDevices)
                {
                    try
                    {
                        SavewaterEnergyDeviceInConduit(waterEnergyDevice);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in WaterEnergyDeviceProcessor : " + ex.ToString());
                        Log.Error("WaterAndEnergy Details :: " + JsonConvert.SerializeObject(waterEnergyDevice));
                        responseFlag = false;
                    }
                }                
            }
            if (responseFlag)
            {
                Log.Info("Syncing success for WaterEnergyDevice of plant : " + ecolabAccountNumber);

                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WaterAndEnergy", "Yes");
            }
            else
            {
                Log.Info("Syncing fail for WaterEnergyDevice of plant : " + ecolabAccountNumber);

                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WaterAndEnergy", "Fail");
            }
        }

        /// <summary>
        /// Save water energy data in MyService
        /// </summary>
        /// <param name="waterEnergyDevice"></param>
        /// <returns></returns>
        private int SavewaterEnergyDeviceInMyService(Utility waterEnergyDevice)
        {
            int response = 0;
            int serviceItemResponse = 0;
            if (waterEnergyDevice != null)
            {
                try
                {
                    response = WaterEnergyDeviceAccess.SaveWaterEnergyDevice(waterEnergyDevice);
                    serviceItemResponse = WaterEnergyDeviceAccess.SaveWEDataInServiceItem(waterEnergyDevice);
                    if (response > 0 || serviceItemResponse > 0)
                    {
                        responseFlag = false;
                    }
                    else
                    {
                        responseFlag = true;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in WaterEnergyDeviceProcessor : " + ex.ToString());
                    Log.Error("WaterAndEnergy Details to save in myService:: " + JsonConvert.SerializeObject(waterEnergyDevice));
                    responseFlag = false;
                }
            }
            return response;
        }

        /// <summary>
        /// Save water enrgy data in Conduit
        /// </summary>
        /// <param name="waterEnergyDevice"></param>
        /// <returns></returns>
        private int SavewaterEnergyDeviceInConduit(Utility waterEnergyDevice)
        {
            int response = 0;
            if (waterEnergyDevice != null)
            {
                DateTime lastModifiedTimeStamp = DateTime.Now;

                try
                {
                    if (!WaterEnergyDeviceAccess.IsWaterAndEnergyDeviceExist(waterEnergyDevice.EcolabAccountNumber, waterEnergyDevice.MyServiceCustWtrEnrgDvcGUID))
                    {
                        response = Access.PlantSetup.UtilityAccess.SaveUtilityDetails(waterEnergyDevice, SystemUserId, out lastModifiedTimeStamp, DateTime.UtcNow);
                        responseFlag = response < 1 ? false : true;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in WaterEnergyDeviceProcessor : " + ex.ToString());
                    responseFlag = false;
                }
            }
            return response;
        }
    }
}