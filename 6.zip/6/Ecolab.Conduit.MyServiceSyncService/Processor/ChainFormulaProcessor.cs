﻿// -----------------------------------------------------------------------
// <copyright file="ChainFormulaProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ChainFormula processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    /// <summary>
    /// ChainFormulaProcessor class
    /// </summary>
    public class ChainFormulaProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

		/// <summary>
		/// response flag
		/// </summary>
		private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Chain Formula details from central
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
			Log.Info("Started sync For ChainFormula");

			MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "ChainFormula");

			DateTime myServiceTime;
			if (log != null)
			{
				Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                //Since we are syncing Central admin to local, no need to convert UTC time to MyService DB timezone.
                myServiceTime = log.MyServiceLastSynchTime; //MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
			else
			{
				myServiceTime = DateTime.Now.AddYears(-100);
			}

			this.ProcessChainFormula(plants, log, myServiceTime);
        }

        /// <summary>
        /// Process Chain Formula
        /// </summary>
        /// <param name="plants">plants</param>
        /// <param name="log">log</param>
        /// <param name="myServiceDateTime">myServiceDateTime</param>
        public void ProcessChainFormula(List<Entities.Plant> plants, MyServiceSyncLog log, DateTime myServiceDateTime)
	    {
			int response = 0;
			Log.Info("Getting PlantChain Details from Central Conduit");

			List<PlantChain> plantChains = Access.PlantChainAccess.GetPlantChainDetails();

			Log.Info("Fetched PlantChain Details from central Conduit" + plantChains);

			foreach (PlantChain pc in plantChains)
			{
				List<ChainFormula> chainFormula = Access.ChainFormulaAccess.GetChainFormulaByPlantChainId(pc.PlantChainId, myServiceDateTime);
				//List<Plant> plantsForChain = plants.Where(p => p.PlantChainId == pc.PlantChainId).ToList();

				Log.Info("Plants to be synced for chain Formula:" + MyServiceCommon.SerializeToJsonFromEntity<List<Plant>>(plants));
				if (chainFormula != null && chainFormula.Count > 0)
				{
					foreach (var plant in plants)
					{
						Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
						bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
						if (!isDisconnected)
						{
							Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
							List<Ecolab.Models.ChainFormula> chainFormulas = Mapper.Map<List<ChainFormula>, List<Ecolab.Models.ChainFormula>>(chainFormula);

							Log.Info("Chain Formula send to Push To Master for Plant : " + plant.EcoalabAccountNumber);
							response = Push.PushMasterData<List<Ecolab.Models.ChainFormula>>(chainFormulas, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateChainFormula);
							if (response != 0)
							{
								Log.Info("Chain Formula: Push To local: Failed for Plant " + plant.EcoalabAccountNumber);
								responseFlag = false;
							}
							else
							{
								Log.Info("Chain Formula: Push To local: Success for Plant " + plant.EcoalabAccountNumber);
							}
						}
						else
						{
							Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
						}
					}
				}
                else
                {
                    Log.Info("Chain Formula: Plant Chain is not match from Central to local, Plant Chain Id:" + pc.PlantChainId);
                }

            }
			if (responseFlag)
			{
				Log.Info("Syncing Success for Chain Formula");
				if (log != null)
				{
					MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
				}
				else
				{
					MyServiceCommon.UpdateMyServiceSyncLog(null, "ChainFormula", "Yes");
				}

			}
			else
			{
				Log.Info("Syncing Fail for ChainFormula");
				if (log != null)
					MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
				else
					MyServiceCommon.UpdateMyServiceSyncLog(null, "ChainFormula", "Fail");
			}
	    }
    }
}
