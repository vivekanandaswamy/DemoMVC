﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasherFormulaProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Conventional Washer Formula processor class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access.WasherGroup;
    using AutoMapper;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Entities;
    using Entities.WasherGroup;
    using Entities.Washers.Conventional;
    using Library.Enums;
    using log4net;
    using PushHandler;
    using Services.WasherGroup;

    /// <summary>
    /// ConventionalWasherFormulaProcessor Class
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.MyServiceSyncService.Processor.IProcessor" />
    public class ConventionalWasherFormulaProcessor : IProcessor
	{
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

		/// <summary>
		/// mResponse Flag
		/// </summary>
		private bool responseFlag = true;

		/// <summary>
		/// injection number
		/// </summary>
		private short conventionalInjectionNumber = 0;

        /// <summary>
        /// Is Plant Disconnected
        /// </summary>
        bool isDisconnected = false;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Save ConventionalWasherFormula from Myservice
		/// </summary>
		/// <param name="ecolabAccountNumber">Ecolab Account Number</param>
		public void Save(string ecolabAccountNumber)
		{
			Log.Info("Started sync conventional Formula - WasherProgramSetup for Plant :" + ecolabAccountNumber);

			MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "WasherProgramSetup");
            isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);

            Log.Info("Getting list of Conventional Washer Groups from conduit for this plant : " + ecolabAccountNumber);
			List<WasherGroup> conventionalWasherGroups = GetConduitConventionalWasherGroups(ecolabAccountNumber);

			DateTime myServiceTime = DateTime.Now.AddYears(-100);
			if (log != null)
			{
				Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

				myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime, ecolabAccountNumber);
			}

			Log.Info("Process started for getting conventional formula and saving in COnduit");
			ProcessWasherGroupFormulaToSaveInConduit(ecolabAccountNumber, conventionalWasherGroups, myServiceTime);

			if (log != null)
			{
				Log.Info("Process started for getting conventional formula and saving back to My Service");
				ProcessWasherGroupFormulaToSaveInMyService(ecolabAccountNumber, conventionalWasherGroups, log.MyServiceLastSynchTime);
			}

			if (responseFlag)
			{
				Log.Info("Syncing success in MyService for WasherGroupFormula of plant : " + ecolabAccountNumber);

				if (log != null)
				{
					MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, "WasherProgramSetup", "Yes");
				}
				else
				{
					MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WasherProgramSetup", "Yes");
				}
			}
			else
			{
				Log.Info("Syncing fail in MyService for WasherGroupFormula of plant : " + ecolabAccountNumber);

				if (log != null)
				{
					MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, "WasherProgramSetup", "Fail");
				}
				else
				{
					MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WasherProgramSetup", "Fail");
				}
			}
		}

		/// <summary>
		/// Gets the conduit conventional washer groups.
		/// </summary>
		/// <param name="ecolabAccountNumber">The ecolab account number.</param>
		/// <returns>List of conventional washer groups</returns>
		private List<WasherGroup> GetConduitConventionalWasherGroups(string ecolabAccountNumber)
		{
			try
			{
				List<WasherGroup> conventionalWasherGroups = WasherGroupAccess.GetWasherGroupDetails(-1, ecolabAccountNumber, false).Where(t => t.WasherGroupTypeName == "Conventional").ToList();
				return conventionalWasherGroups;
			}
			catch (Exception ex)
			{
				Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
				responseFlag = false;
				return null;
			}
		}

        /// <summary>
        /// Processes the washer group formula to save in conduit.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="conventionalWasherGroups">The conventional washer groups.</param>
        /// <param name="myServiceTime">My service time.</param>
        private void ProcessWasherGroupFormulaToSaveInConduit(string ecolabAccountNumber, List<WasherGroup> conventionalWasherGroups, DateTime myServiceTime)
        {
            int response = 0;
            if (conventionalWasherGroups != null && conventionalWasherGroups.Count > 0)
            {
                foreach (var item in conventionalWasherGroups)
                {
                    Log.Info("Getting Conventional formula for washer group :" + item.WasherGroupName + " and plant" + ecolabAccountNumber);
                    List<WasherGroupFormula> washerGroupFormulas = GetMyServiceConventionalFormula(ecolabAccountNumber, myServiceTime, item);
                    if (washerGroupFormulas != null && washerGroupFormulas.Count > 0)
                    {
                        Log.Info("Total no of connventional formulas from my service:" + washerGroupFormulas.Count + "for washer group :" + item.WasherGroupName);
                        Log.Info("Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<List<WasherGroupFormula>>(washerGroupFormulas));
                        foreach (WasherGroupFormula washerGroupFormula in washerGroupFormulas)
                        {
                            try
                            {
                                washerGroupFormula.ProgramId = WasherGroupFormulaAccess.FetchProgramIdForFormulaName(ecolabAccountNumber, washerGroupFormula.ProductName);
                                response = SaveWasherGroupFormulaInConduit(washerGroupFormula, conventionalWasherGroups);
                            }
                            catch (Exception ex)
                            {
                                Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
                                Log.Error("Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(washerGroupFormula));
                                responseFlag = false;
                            }

                            if (response != 0 && response != 51000)
                            {
                                responseFlag = false;
                            }
                            else
                            {
                                if (washerGroupFormula.FormulaTypeCode == "P")
                                {
                                    Log.Info("Saving proposed formula back to my service");
                                    Log.Info("Purposed Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(washerGroupFormula));
                                    try
                                    {
                                        ConventionalWasherFormulaAccess.UpdateProposedToCurrentFormula(washerGroupFormula);
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.Error("Error in ConventionalWasherFormulaProcessor to save proposed formula in myService : " + ex.ToString());
                                        Log.Error("Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(washerGroupFormula));
                                        responseFlag = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

		/// <summary>
		/// Gets my service conventional formula.
		/// </summary>
		/// <param name="ecolabAccountNumber">The ecolab account number.</param>
		/// <param name="myServiceTime">My service time.</param>
		/// <param name="item">The item.</param>
		/// <returns>List of washer group fromula</returns>
		private List<WasherGroupFormula> GetMyServiceConventionalFormula(string ecolabAccountNumber, DateTime myServiceTime, WasherGroup item)
		{
			try
			{
				List<WasherGroupFormula> washerGroupFormulas = ConventionalWasherFormulaAccess.GetWasherGroupFormula(ecolabAccountNumber, myServiceTime, item.MyServiceWasherGroupGuid);
				return washerGroupFormulas;
			}
			catch (Exception ex)
			{
				Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
				responseFlag = false;
				return null;
			}
		}

		/// <summary>
		/// Saves the washer group formula in conduit.
		/// </summary>
		/// <param name="washerGroupFormula">The washer group formula.</param>
		/// <param name="conventionalWasherGroups">The conventional washer groups.</param>
		/// <returns>Response which is an int value</returns>
		private int SaveWasherGroupFormulaInConduit(WasherGroupFormula washerGroupFormula, List<WasherGroup> conventionalWasherGroups)
		{
			int response = 0;
			conventionalInjectionNumber = 0;

			if (washerGroupFormula != null && conventionalWasherGroups.Where(t => t.MyServiceWasherGroupGuid == washerGroupFormula.MyServiceMchGrpGuid).ToList().Count > 0)
			{
                List<WasherFormulaWashStep> washerFormulaWashSteps = GetMyServiceWasherGroupFormulaWashSteps(washerGroupFormula);

                washerGroupFormula.WasherGroupId = conventionalWasherGroups.Where(t => t.MyServiceWasherGroupGuid == washerGroupFormula.MyServiceMchGrpGuid).FirstOrDefault().WasherGroupId;
				
                if (isDisconnected)
                {
                    response = WasherGroupFormulaAccess.SaveMyServiceWasherGroupFormula(washerGroupFormula, SystemUserId);

                    if (response != 0)
                    {
                        Log.Info("Formula save fail in conduit for plant : " + washerGroupFormula.EcolabAccountNumber + "and Washer Group :" + washerGroupFormula.WasherGroupId);
                        Log.Info("Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(washerGroupFormula));
                    }
                    else
                    {
                        Log.Info("Getting Wash Steps for this saved Conventional Formula from My Service " + " for formula " + washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);

                        if (washerFormulaWashSteps != null && washerFormulaWashSteps.Count > 0)
                        {
                            Log.Info("Total no of wash steps :" + washerFormulaWashSteps.Count);
                            Log.Info("Wash Steps Details : " + MyServiceCommon.SerializeToJsonFromEntity<List<WasherFormulaWashStep>>(washerFormulaWashSteps));
                            foreach (WasherFormulaWashStep washerFormulaWashStep in washerFormulaWashSteps)
                            {
                                try
                                {
                                    conventionalInjectionNumber = Convert.ToInt16(conventionalInjectionNumber + 1);
                                    response = SaveWasherFormulaWashStepInConduit(washerFormulaWashStep, washerGroupFormula);
                                }
                                catch (Exception ex)
                                {
                                    Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
                                    Log.Error("WashStep Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherFormulaWashStep>(washerFormulaWashStep));
                                    responseFlag = false;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (washerGroupFormula.FormulaTypeCode == "P")
                    {
                        Log.Info("Formula is proposed. Create or Update Plant Formula Details.");
                        Services.WasherGroup.WasherGroupFormulaService objwasherGroupFormulaService = new Services.WasherGroup.WasherGroupFormulaService();
                        Log.Info("Plant " + washerGroupFormula.EcolabAccountNumber + " is " + "Connected");

                        Ecolab.Models.WasherGroup.WasherGroupFormula washerFormulaDetails = Mapper.Map<WasherGroupFormula, Ecolab.Models.WasherGroup.WasherGroupFormula>(washerGroupFormula);

                        try
                        {
                            washerFormulaDetails.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(washerGroupFormula.EcolabAccountNumber);
                            Ecolab.Models.WasherGroup.WasherFormulaModel washerFormulaModel = new Ecolab.Models.WasherGroup.WasherFormulaModel();
                            washerFormulaModel.washerFormula = washerFormulaDetails;

                            response = Push.PushToLocal<Ecolab.Models.WasherGroup.WasherFormulaModel>(washerFormulaModel, washerFormulaDetails.EcolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdAddWasherFormula);

                            if (response == 0)
                            {
                                washerFormulaModel.washerFormulaWashStep = new List<Models.WasherGroup.WasherFormulaWashStep>();
                                washerFormulaDetails.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForWasherProgram(washerGroupFormula.EcolabAccountNumber);
                                foreach (WasherFormulaWashStep washerformWashStep in washerFormulaWashSteps)
                                {
                                    washerformWashStep.WashOperationId = WasherGroupFormulaAccess.FetchWashOperationIdForMyServiceWashOpId(washerformWashStep.MyServiceWshOpId);
                                    washerformWashStep.ProgramSetupId = WasherGroupFormulaAccess.FetchProgramSetupIdForGUId(washerGroupFormula.EcolabAccountNumber, washerFormulaModel.washerFormula.MyServiceCustFrmulaMchGrpGUID.GetValueOrDefault());
                                    washerformWashStep.EcolabAccountNumber = washerGroupFormula.EcolabAccountNumber;
                                    List<WasherDosingProduct> WasherDosingProducts = ConventionalWasherFormulaAccess.GetWasherDosingProducts(washerformWashStep.MyServiceCusrFrmulaStpGuid);
                                    WasherDosingProducts.ForEach(a => a.ProductId = WasherGroupFormulaAccess.FetchProductIdForMyserviceProdId(a.MyServiceProductId));
                                    washerformWashStep.WasherDosingProducts = WasherDosingProducts;
                                    washerFormulaModel.washerFormulaWashStep.Add(Mapper.Map<WasherFormulaWashStep, Models.WasherGroup.WasherFormulaWashStep>(washerformWashStep));
                                }
                                response = Push.PushToLocal<Ecolab.Models.WasherGroup.WasherFormulaModel>(washerFormulaModel, washerFormulaDetails.EcolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdAddWasherFormulaWashStep);
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
                            Log.Error("WashStep Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(washerGroupFormula));
                            responseFlag = false;
                        }
                    }
                }
			}
			return response;
		}

		/// <summary>
		/// Gets my service washer group formula wash steps.
		/// </summary>
		/// <param name="washerGroupFormula">The washer group formula.</param>
		/// <returns>List of washer formula wash steps</returns>
		private List<WasherFormulaWashStep> GetMyServiceWasherGroupFormulaWashSteps(WasherGroupFormula washerGroupFormula)
		{
			try
			{
				List<WasherFormulaWashStep> washerFormulaWashSteps = ConventionalWasherFormulaAccess.GetWasherGroupFormulaWashSteps(washerGroupFormula.MyServiceCustFrmulaMchGrpGUID.Value);
				return washerFormulaWashSteps;
			}
			catch (Exception ex)
			{
				Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
				responseFlag = false;
				return null;
			}
		}

        /// <summary>
        /// Saves the washer formula wash step in conduit.
        /// </summary>
        /// <param name="washerFormulaWashStep">The washer formula wash step.</param>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <returns>Returns Response</returns>
        private int SaveWasherFormulaWashStepInConduit(WasherFormulaWashStep washerFormulaWashStep, WasherGroupFormula washerGroupFormula)
        {
            int response = 0;
            if (washerFormulaWashStep != null)
            {
                response = WasherGroupFormulaAccess.SaveMyServiceWasherFormulaWashStep(washerFormulaWashStep, washerGroupFormula, SystemUserId);
                if (response != 0)
                {
                    Log.Info("Washstep save fail in conduit :: WashStep Details ::" + MyServiceCommon.SerializeToJsonFromEntity<WasherFormulaWashStep>(washerFormulaWashStep));
                    if (response == 51000)
                    {
                        Log.Info("Specified WasherStep already exists for the plant.");
                    }
                }
                else
                {
                    Log.Info("Getting Products for this saved Conventional Formula Wash Steps from My Service" + " for wash step " + washerFormulaWashStep.MyServiceCusrFrmulaStpGuid);
                    List<WasherDosingProduct> WasherDosingProducts = ConventionalWasherFormulaAccess.GetWasherDosingProducts(washerFormulaWashStep.MyServiceCusrFrmulaStpGuid);

                    if (WasherDosingProducts != null && WasherDosingProducts.Count > 0)
                    {
                        Log.Info("Total no of products :" + WasherDosingProducts.Count);
                        Log.Info("Dosing Products Details : " + MyServiceCommon.SerializeToJsonFromEntity<List<WasherDosingProduct>>(WasherDosingProducts));
                        foreach (WasherDosingProduct washerDosingProduct in WasherDosingProducts)
                        {
                            try
                            {
                                response = SaveWasherDosingProductsInConduit(washerDosingProduct, washerFormulaWashStep, washerGroupFormula, conventionalInjectionNumber);
                            }
                            catch (Exception ex)
                            {
                                Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
                                Log.Error("Dosing Product Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherDosingProduct>(washerDosingProduct));
                                responseFlag = false;
                            }
                        }
                    }
                    else
                    {
                        conventionalInjectionNumber = Convert.ToInt16(conventionalInjectionNumber - 1);
                    }
                }
            }

            return response;
        }

        /// <summary>
        /// Saves the washer dosing products in conduit.
        /// </summary>
        /// <param name="washerDosingProduct">The washer dosing product.</param>
        /// <param name="washerFormulaWashStep">The washer formula wash step.</param>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <returns>Returns Response</returns>
        private int SaveWasherDosingProductsInConduit(WasherDosingProduct washerDosingProduct, WasherFormulaWashStep washerFormulaWashStep, WasherGroupFormula washerGroupFormula, short injectionNumber)
        {
            int response = 0;

            if (washerDosingProduct != null)
            {
                Log.Info("DosingProduct saving in conduit is processed.");
                washerDosingProduct.InjectionNumber = injectionNumber;
                response = WasherGroupFormulaAccess.SaveMyServiceWasherDosingProduct(washerDosingProduct, washerFormulaWashStep, washerGroupFormula, SystemUserId);

                if (response != 0)
                {
                    Log.Info("DosingProduct save fail in conduit.");
                }
                else
                {
                    Log.Info("DosingProduct save success in conduit.");
                }
            }

            return response;
        }

		/// <summary>
		/// Processes the washer group formula to save in my service.
		/// </summary>
		/// <param name="ecolabAccountNumber">The ecolab account number.</param>
		/// <param name="conventionalWasherGroups">The conventional washer groups.</param>
		/// <param name="myServiceTime">My service time.</param>
		private void ProcessWasherGroupFormulaToSaveInMyService(string ecolabAccountNumber, List<WasherGroup> conventionalWasherGroups, DateTime myServiceTime)
		{
			int response = 0;
			if (conventionalWasherGroups != null && conventionalWasherGroups.Count > 0)
			{
				Log.Info("Looping each Conventional Washer Groups to get formulas and save in My Service");
				foreach (WasherGroup washerGroup in conventionalWasherGroups)
				{
					Log.Info("Getting Conventional formula for washer group :" + washerGroup.WasherGroupName + " and plant" + ecolabAccountNumber);
					List<WasherGroupFormula> washerGroupFormulas = GetConduitWasherGroupFormula(ecolabAccountNumber, myServiceTime, washerGroup);

					if (washerGroupFormulas != null && washerGroupFormulas.Count > 0)
					{
						Log.Info("Total no of formulas :" + washerGroupFormulas.Count);
						Log.Info("Looping each Conventional formulas to save in My Service for Washer Group :" + washerGroup.WasherGroupName);
						foreach (WasherGroupFormula washerGroupFormula in washerGroupFormulas)
						{
							Log.Info("Saving Formula started back in my service ");
							response = SaveWasherGroupFormulaInMyService(washerGroupFormula, washerGroup);

							if (response != 0)
							{
								responseFlag = false;
                                if (response == 50124)
                                {
                                    Log.Error("ConventionalFormula : Washer group is not present in myService for which we are trying to save formula." + MyServiceCommon.SerializeToJsonFromEntity<WasherGroup>(washerGroup));
                                    continue;
                                }
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// Gets the conduit washer group formula.
		/// </summary>
		/// <param name="ecolabAccountNumber">The ecolab account number.</param>
		/// <param name="myServiceTime">My service time.</param>
		/// <param name="washerGroup">The washer group.</param>
		/// <returns>List of washer group formulas</returns>
		private List<WasherGroupFormula> GetConduitWasherGroupFormula(string ecolabAccountNumber, DateTime myServiceTime, WasherGroup washerGroup)
		{
			try
			{
				List<WasherGroupFormula> washerGroupFormulas = WasherGroupFormulaAccess.GetWasherGroupFormula(ecolabAccountNumber, washerGroup.WasherGroupId, 0, true).Where(t => t.LastModifiedTime > myServiceTime).ToList();
				return washerGroupFormulas;
			}
			catch (Exception ex)
			{
				Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
				responseFlag = false;
				return null;
			}
		}

		/// <summary>
		/// Saves the washer group formula in my service.
		/// </summary>
		/// <param name="washerGroupFormula">The washer group formula.</param>
		/// <param name="washerGroup">The washer group.</param>
		/// <returns>Returns Response</returns>
		private int SaveWasherGroupFormulaInMyService(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
		{
			int response = 0;
			if (washerGroup != null && washerGroupFormula != null)
			{
				Log.Info("Formula saving in myservice is processed.");
				try
				{
					response = ConventionalWasherFormulaAccess.SaveWasherGroupFormula(washerGroupFormula, washerGroup);
					if (response == 0)
					{
						List<ConventionalGeneral> myserviceConventionalGeneralList = ConventionalWasherAccess.GetConventionalDetails(washerGroup.MyServiceWasherGroupGuid, washerGroup.EcolabAccountNumber, DateTime.Now.AddYears(-100));
						if (myserviceConventionalGeneralList != null && myserviceConventionalGeneralList.Count > 0)
						{
							foreach (ConventionalGeneral item in myserviceConventionalGeneralList)
							{
								ConventionalWasherFormulaAccess.SaveFormulaMachineRefrenceInMyService(washerGroupFormula, washerGroup, item);
							}
						}
					}
				}
				catch (Exception ex)
				{
					Log.Error("Error in ConventionalWasherFormulaProcessor for Plant " + washerGroup.EcolabAccountNumber + " with error : " + ex.ToString());
					responseFlag = false;
					return 0;
				}

				if (response == 0)
				{
					Log.Info("Formula save success in myservice.");
					Log.Info("Getting Wash Steps for this saved Conventional Formula from Conduit");
					List<WasherFormulaWashStep> washerFormulaWashSteps = GetConduitWasherFormulaWashSteps(washerGroupFormula, washerGroup);

					if (washerFormulaWashSteps != null && washerFormulaWashSteps.Count > 0)
					{
						Log.Info("Total no of wash steps :" + washerFormulaWashSteps.Count);
						Log.Info("Looping each Conventional formulas Wash Steps to save in My Service");
						foreach (WasherFormulaWashStep washerFormulaWashStep in washerFormulaWashSteps)
						{
							try
							{
								response = SaveWasherFormulaWashStepInMyService(washerFormulaWashStep, washerGroupFormula, washerGroup);
							}
							catch (Exception ex)
							{
								Log.Error("Error in ConventionalWasherFormulaProcessor for Plant " + washerGroup.EcolabAccountNumber + " with error : " + ex.ToString());
								responseFlag = false;
								return 0;
							}
						}
					}
				}
				else
				{
					Log.Info("Convention Formula save fail in myservice for plant :" + washerGroup.EcolabAccountNumber + "And washer group : " + washerGroup.WasherGroupName);
					Log.Info("Formula save fail in myservice.");
				}
			}

			return response;
		}

		/// <summary>
		/// Gets the conduit washer formula wash steps.
		/// </summary>
		/// <param name="washerGroupFormula">The washer group formula.</param>
		/// <param name="washerGroup">The washer group.</param>
		/// <returns>List of washer group formula wash steps</returns>
		private List<WasherFormulaWashStep> GetConduitWasherFormulaWashSteps(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
		{
			try
			{
				List<WasherFormulaWashStep> washerFormulaWashSteps = WasherGroupFormulaAccess.GetWasherGroupFormulaWashSteps(washerGroup.EcolabAccountNumber, washerGroup.WasherGroupId, washerGroupFormula.Id, 0, true);
				return washerFormulaWashSteps;
			}
			catch (Exception ex)
			{
				Log.Error("Error in ConventionalWasherFormulaProcessor : " + ex.ToString());
				responseFlag = false;
				return null;
			}
		}

		/// <summary>
		/// Saves the washer formula wash step in my service.
		/// </summary>
		/// <param name="washerFormulaWashStep">The washer formula wash step.</param>
		/// <param name="washerGroupFormula">The washer group formula.</param>
		/// <param name="washerGroup">The washer group.</param>
		/// <returns>Returns Response</returns>
		private int SaveWasherFormulaWashStepInMyService(WasherFormulaWashStep washerFormulaWashStep, WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
		{
			int response = 0;

			if (washerFormulaWashStep != null)
			{
				Log.Info("WashStep saving in myservice is processed.");
				response = ConventionalWasherFormulaAccess.SaveWasherFormulaWashStep(washerFormulaWashStep, washerGroupFormula, washerGroup);

				if (response == 0)
				{
					Log.Info("WashStep save success in myservice.");
					Log.Info("Getting Products for this saved Conventional Formula Wash Steps from Conduit");
					List<WasherDosingProduct> washerDosingProducts = WasherGroupFormulaAccess.GetWasherDosingProduct(washerGroup.EcolabAccountNumber, washerFormulaWashStep.Id, true).ToList();

					if (washerDosingProducts != null && washerDosingProducts.Count > 0)
					{
						Log.Info("Total no of dosing products :" + washerDosingProducts.Count);
						Log.Info("Looping each Conventional Products to save in My Service");
						foreach (WasherDosingProduct washerDosingProduct in washerDosingProducts)
						{
							response = SaveWasherDosingProductInMyService(washerDosingProduct, washerFormulaWashStep, washerGroupFormula, washerGroup);
						}
					}
				}
				else
				{
					Log.Info("WashStep save fail in myservice for plant :" + washerGroup.EcolabAccountNumber + "And washer group Formula : " + washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
				}
			}

			return response;
		}

		/// <summary>
		/// Saves the washer dosing product in my service.
		/// </summary>
		/// <param name="washerDosingProduct">The washer dosing product.</param>
		/// <param name="washerFormulaWashStep">The washer formula wash step.</param>
		/// <param name="washerGroupFormula">The washer group formula.</param>
		/// <param name="washerGroup">The washer group.</param>
		/// <returns>Returns Response</returns>
		private int SaveWasherDosingProductInMyService(WasherDosingProduct washerDosingProduct, WasherFormulaWashStep washerFormulaWashStep, WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
		{
			int response = 0;
            try
            {
                if (washerDosingProduct != null)
                {
                    Log.Info("DosingProduct saving in myservice is processed.");
                    int MyServiceProdId = ConventionalWasherFormulaAccess.GetMyServiceProductId(washerDosingProduct.ProductId);
                    Log.InfoFormat("MyServiceProdID {0} for Plant {1} is",MyServiceProdId, washerGroup.EcolabAccountNumber);
                    if (MyServiceProdId > 0)
                    {
                        response = ConventionalWasherFormulaAccess.SaveWasherDosingProduct(washerDosingProduct, washerFormulaWashStep, washerGroupFormula, washerGroup, MyServiceProdId);

                        if (response != 0)
                            Log.Info("WashStep save fail in myservice for plant :" + washerGroup.EcolabAccountNumber + "And washer group Formula : " + washerGroupFormula.MyServiceCustFrmulaMchGrpGUID +

                                "And its wash step : " + washerFormulaWashStep.MyServiceCusrFrmulaStpGuid);
                        else
                            Log.Info("DosingProduct save success in myservice.");
                    }
                }
            }
            catch (Exception ex) {
                Log.Error("Error in Saving WashingDosing Product in MyService for Plant :" + washerGroup.EcolabAccountNumber + "with error :" + ex.ToString());
                Log.Error("WasherDosingProductData :" + MyServiceCommon.SerializeToJsonFromEntity<WasherDosingProduct>(washerDosingProduct));
            }

			return response;
		}
	}
}