﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSizeProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Washer Model Size processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access.Washers.Conventional;
    using AutoMapper;
    using Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.Washers.Conventional;
    using log4net;

    /// <summary>
    /// WasherModelSizeProcessor class
    /// </summary>
    public class WasherModelSizeProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Save Washer Model Size details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///  Save Washer Model Size details from Myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("Started sync For WasherModelSize");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "WasherModelSize");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<WasherModelSize> myserviceWasherSizeDetails = GetMyServiceWasherModelSizeDetails(myServiceTime);

            ProcessMyServiceData(plants, log, myserviceWasherSizeDetails);
        }

        /// <summary>
        /// To save the myService data to central as well as in local.
        /// </summary>
        /// <param name="plants">List of plants</param>
        /// <param name="log">loggint the information</param>
        /// <param name="myserviceWasherSizeDetails">list of washer model size.</param>
        public void ProcessMyServiceData(List<Plant> plants, MyServiceSyncLog log, List<WasherModelSize> myserviceWasherSizeDetails)
        {

            if (myserviceWasherSizeDetails != null && myserviceWasherSizeDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Insert Or Update Washer model Size data into Central");
                Log.Info("Total Washer model :: " + myserviceWasherSizeDetails.Count);
                foreach (var washerModelSize in myserviceWasherSizeDetails)
                {
                    Log.Info("WasherModelSize Detail : " + MyServiceCommon.SerializeToJsonFromEntity<WasherModelSize>(washerModelSize));
                    Int16 washerModelSizeId = InsertOrUpdateWasherModelSizeDetails(washerModelSize);
                    washerModelSize.WasherModelId = washerModelSizeId;
                }

                Log.Info("Insert Or Update Washer model Size data into Local Plants");

                foreach (var plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");

                        List<Models.Washers.Conventional.WasherModelSize> washerModelSizeDetails =
                            Mapper.Map<List<WasherModelSize>, List<Models.Washers.Conventional.WasherModelSize>>(myserviceWasherSizeDetails);
                        response = Push.PushMasterData<List<Models.Washers.Conventional.WasherModelSize>>(washerModelSizeDetails, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceWasherModelSize);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "WasherModelSize");
                            responseFlag = false;
                        }
                        else
                        {
                            Log.Info("Syncing Success in Local Plant: " + plant.EcoalabAccountNumber + "for WasherModelSize");
                        }
                    }
                }
                if (responseFlag)
                {
                    Log.Info("Syncing Success for Washer model Size");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "WasherModelSize", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for Washer model Size");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "WasherModelSize", "Fail");
                }
            }
        }
        /// <summary>
        /// Get MyService Washer Model Size Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">lastSyncTimeInCentral</param>
        /// <returns>List of WasherModelSize</returns>
        private List<WasherModelSize> GetMyServiceWasherModelSizeDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<WasherModelSize> myserviceWasherModelSizeDetails = WasherModelSizeAccess.GetWasherModelSizeDetails(lastSyncTimeInCentral);
                return myserviceWasherModelSizeDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in WasherModelSizeProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Insert or Update Washer Model Size in Central
        /// </summary>
        /// <param name="washerModelSize">Washer Model Size from MyService</param>
        private Int16 InsertOrUpdateWasherModelSizeDetails(WasherModelSize washerModelSize)
        {
            try
            {
                return ConventionalGeneralAccess.SaveMyServiceWasherModelSizeDetails(washerModelSize);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in WasherModelSizeProcessor :: " + ex.ToString());
                Log.Error("WasherModelSize Detail : " + MyServiceCommon.SerializeToJsonFromEntity<WasherModelSize>(washerModelSize));
                return 0;
            }
        }
    }
}
