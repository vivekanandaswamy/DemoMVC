﻿// -----------------------------------------------------------------------
// <copyright file="ChainTextileCategoryProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ChainTextileCategory processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.PlantSetup.Chemical;
    using log4net;

    /// <summary>
    /// ChainTextileCategoryProcessor class
    /// </summary>
    public class ChainTextileCategoryProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

		/// <summary>
		/// response flag
		/// </summary>
		private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Chain TextileCategory details from central
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
			Log.Info("Started sync For ChainTextileCategory");

			MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "ChainTextileCategory");

			DateTime myServiceTime;
			if (log != null)
			{
				Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                //Since we are syncing Central admin to local, no need to convert UTC time to MyService DB timezone.
                myServiceTime = log.MyServiceLastSynchTime; 
			}
			else
			{
				myServiceTime = DateTime.Now.AddYears(-100);
			}

			this.ProcessChainTextileCategory(plants, log, myServiceTime);
        }

		/// <summary>
		/// Process Chain textile category
		/// </summary>
		/// <param name="plants">plants</param>
		/// <param name="log">log</param>
		/// <param name="myServiceDateTime">myServiceDateTime</param>
		public void ProcessChainTextileCategory(List<Entities.Plant> plants, MyServiceSyncLog log, DateTime myServiceDateTime)
	    {
            try
            {
			int response = 0;
			Log.Info("Getting PlantChain Details from Central Conduit");

			List<PlantChain> plantChains = Access.PlantChainAccess.GetPlantChainDetails();

                Log.Info("Fetched PlantChain Details from central Conduit" + MyServiceCommon.SerializeToJsonFromEntity<List<PlantChain>>(plantChains));

			foreach (PlantChain pc in plantChains)
			{
				List<ChainTextileCategory> chainTextileCategories = Access.ChainTextileCategoryAccess.GetChainTextileCategoryByPlantChainId(pc.PlantChainId, myServiceDateTime);
				List<Plant> plantsForChain = plants.Where(p => p.PlantChainId == pc.PlantChainId).ToList();

				Log.Info("Plants to be synced for chain Textile Category:" + MyServiceCommon.SerializeToJsonFromEntity<List<Plant>>(plantsForChain));
				if (chainTextileCategories != null && chainTextileCategories.Count > 0)
				{
					foreach (var plant in plantsForChain)
					{
						Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
						bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
						if (!isDisconnected)
						{
							Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
							List<Ecolab.Models.ChainTextileCategory> chainTextileCategorys = Mapper.Map<List<ChainTextileCategory>, List<Ecolab.Models.ChainTextileCategory>>(chainTextileCategories);

							Log.Info("Chain textile send to Push To Master for Plant : " + plant.EcoalabAccountNumber);
							response = Push.PushMasterData<List<Ecolab.Models.ChainTextileCategory>>(chainTextileCategorys, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateChainTextileCategory);
							if (response != 0)
							{
								Log.Info("Chain Textile Category: Push To local: Failed for Plant " + plant.EcoalabAccountNumber);
								responseFlag = false;
							}
							else
							{
								Log.Info("Chain Textile Category: Push To local: Success for Plant " + plant.EcoalabAccountNumber);
							}
						}
						else
						{
							Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
						}
					}
				}

			}
            }
            catch (Exception ex)
            {
                Log.Error("Error in ChainTextileCategoryProcessor : " + ex);
                responseFlag = false;
            }
			if (responseFlag)
			{
				Log.Info("Syncing Success for Chain Textile Category");
				if (log != null)
				{
					MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
				}
				else
				{
					MyServiceCommon.UpdateMyServiceSyncLog(null, "ChainTextileCategory", "Yes");
				}

			}
			else
			{
				Log.Info("Syncing Fail for ChainTextileCategory");
				if (log != null)
					MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
				else
					MyServiceCommon.UpdateMyServiceSyncLog(null, "ChainTextileCategory", "Fail");
			}
	    }
    }
}
