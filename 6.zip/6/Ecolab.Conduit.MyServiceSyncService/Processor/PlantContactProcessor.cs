﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The plant contact processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Common;
    using Entities;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;

    /// <summary>
    /// PlantContactProcessor class
    /// </summary>
    public class PlantContactProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(PlantContactProcessor));

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Save Plant Setup details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync Plant Contacts for Plant :" + ecolabAccountNumber);

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "PlantContact");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<PlantContact> myservicePlantContactDetails = GetMyServicePlantContactDetails(ecolabAccountNumber, myServiceTime);
            List<PlantContact> conduitPlantContactDetails = GetConduitPlantContactDetails(ecolabAccountNumber);

            List<PlantContact> plantContacts = GetPlantContactListForConduit(myservicePlantContactDetails, conduitPlantContactDetails);

            SavePlantContactDetailsInConduit(ecolabAccountNumber, plantContacts);

            plantContacts = null;
            if (log != null)
                plantContacts = GetPlantContactListForMyService(conduitPlantContactDetails, log.MyServiceLastSynchTime);

            SavePlantContactDetailsInMyService(plantContacts);

            if (responseFlag)
            {
                Log.Info("Syncing success for PlantContact." + ecolabAccountNumber);
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantContact", "Yes");
            }
            else
            {
                Log.Info("Syncing Fail for PlantContact." + ecolabAccountNumber);
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantContact", "Fail");
            }
        }

        /// <summary>
        /// Get plant contact list from conduit 
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account NUmber</param>
        /// <returns>List of contacts</returns>
        private List<PlantContact> GetConduitPlantContactDetails(string ecolabAccountNumber)
        {
            try
            {
                List<PlantContact> conduitPlantContactDetails = Access.PlantContactAccess.GetPlantContactDetails(ecolabAccountNumber);
                return conduitPlantContactDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantContactProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Get plant contact list from myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account NUmber</param>
        /// <param name="myServiceTime">last sync time</param>
        /// <returns>List of contacts</returns>
        private List<PlantContact> GetMyServicePlantContactDetails(string ecolabAccountNumber, DateTime myServiceTime)
        {
            try
            {
                List<PlantContact> myservicePlantContactDetails = PlantContactAccess.GetPlantContactDetails(ecolabAccountNumber, myServiceTime);
                return myservicePlantContactDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantContactProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get the list of contacts which need to save in myservice
        /// </summary>
        /// <param name="conduitPlantContactDetails">Plant Contacts from Conduit</param>
        /// <param name="lastSyncTime">last sync time</param>
        /// <returns>List of contacts</returns>
        private List<PlantContact> GetPlantContactListForMyService(List<PlantContact> conduitPlantContactDetails, DateTime lastSyncTime)
        {
            List<PlantContact> plantContacts = new List<PlantContact>();

            if (conduitPlantContactDetails != null)
                plantContacts = conduitPlantContactDetails.Where(t => t.LastModifiedTimestamp > lastSyncTime).ToList();

            return plantContacts;
        }

        /// <summary>
        /// Get the list of contacts which need to save in conduit
        /// </summary>
        /// <param name="myservicePlantContactDetails">Plant Contacts from MyService</param>
        /// <param name="conduitPlantContactDetails">Plant Contacts from Conduit</param>
        /// <returns>List of contacs</returns>
        private List<PlantContact> GetPlantContactListForConduit(List<PlantContact> myservicePlantContactDetails, List<PlantContact> conduitPlantContactDetails)
        {
            List<PlantContact> plantContacts = new List<PlantContact>();

            foreach (PlantContact item in myservicePlantContactDetails)
            {
                PlantContact contact = conduitPlantContactDetails.Where(t => t.MyServiceCntctGuid == item.MyServiceCntctGuid).FirstOrDefault();

                if (contact != null)
                {
                    if (MyServiceCommon.ConvertMyServiceTimeToUTCTime(item.MyServiceLastSynchTime) > contact.LastModifiedTimestamp)
                    {
                        MergeMyserviceWithConduit(contact, item);
                        plantContacts.Add(contact);
                    }
                }
                else
                {
                    plantContacts.Add(item);
                }
            }

            return plantContacts;
        }

        /// <summary>
        /// Merge object
        /// </summary>
        /// <param name="conduitContact">Conduit Contact</param>
        /// <param name="myserviceContact">Myservice Contact</param>
        private void MergeMyserviceWithConduit(PlantContact conduitContact, PlantContact myserviceContact)
        {
            if (conduitContact != null && myserviceContact != null)
            {
                conduitContact.ContactFirstName = myserviceContact.ContactFirstName;
                conduitContact.ContactLastName = myserviceContact.ContactLastName;
                conduitContact.ContactTitle = myserviceContact.ContactTitle;
                conduitContact.MyServiceContactPositionId = myserviceContact.MyServiceContactPositionId;
                conduitContact.ContactEmailAdresss = myserviceContact.ContactEmailAdresss;
                conduitContact.ContactOfficePhone = myserviceContact.ContactOfficePhone;
                conduitContact.ContactMobilePhone = myserviceContact.ContactMobilePhone;
                conduitContact.ContactFaxNumber = myserviceContact.ContactFaxNumber;
                conduitContact.IsDelete = myserviceContact.IsDelete;
            }
        }

        /// <summary>
        /// Save Plant Contact into conduit
        /// </summary>
        /// <param name="ecolabAccountNumber">Plant Number</param>        
        /// <param name="myservicePlantContactDetails">Plant Contacts from MyService</param>
        private void SavePlantContactDetailsInConduit(string ecolabAccountNumber, List<PlantContact> myservicePlantContactDetails)
        {
            bool isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
            int response = 0;

            if (myservicePlantContactDetails != null && myservicePlantContactDetails.Count > 0)
            {
                foreach (var item in myservicePlantContactDetails)
                {
                    try
                    {
                        Log.Info("Plant Contact Detail :: " + MyServiceCommon.SerializeToJsonFromEntity<PlantContact>(item));

                        if (isDisconnected)
                        {
                            Log.Info("Plant " + ecolabAccountNumber + " is " + "DisConnected");
                            DateTime lastModifiedDateTime = DateTime.UtcNow;
                            Access.PlantContactAccess.SaveMyServicePlantContactDetails(item, SystemUserId, out lastModifiedDateTime);
                        }
                        else
                        {
                            Log.Info("Plant " + ecolabAccountNumber + " is " + "Connected");
                            Ecolab.Models.PlantContact plantDetails = Mapper.Map<PlantContact, Ecolab.Models.PlantContact>(item);
                            response = Push.PushToLocal<Ecolab.Models.PlantContact>(plantDetails, plantDetails.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServicePlantContact);
                            if (response == 0)
                            {
                                responseFlag = true;
                            }
                            else
                            {
                                responseFlag = false;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in PlantContactProcessor : " + ex.ToString());
                        responseFlag = false;
                        Log.Error("Plant Contact Detail :: " + MyServiceCommon.SerializeToJsonFromEntity<PlantContact>(item));
                    }
                }
            }
        }

        /// <summary>
        /// Save Plant Contact into Myservice
        /// </summary>
        /// <param name="conduitPlantContactDetails">Plant Contacts from Conduit</param>
        private void SavePlantContactDetailsInMyService(List<PlantContact> conduitPlantContactDetails)
        {
            if (conduitPlantContactDetails != null && conduitPlantContactDetails.Count > 0)
            {
                foreach (var plantContact in conduitPlantContactDetails)
                {
                    try
                    {
                        Log.Info("Plant Contact Details to Save in myService :: " + MyServiceCommon.SerializeToJsonFromEntity<PlantContact>(plantContact));
                        PlantContactAccess.SavePlantContactDetails(plantContact);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in PlantContactProcessor : " + ex.ToString());
                        Log.Error("Plant Contact Detail to save in myService :: " + MyServiceCommon.SerializeToJsonFromEntity<PlantContact>(plantContact));
                        responseFlag = false;
                    }
                }
            }
        }
    }
}