﻿// -----------------------------------------------------------------------
// <copyright file="FormulaWashfloorProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Wash Floor Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Access;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.Model;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Entities;
    using log4net;

    /// <summary>
    /// FormulaWashfloorProcessor class
    /// </summary>
    public class FormulaWashfloorProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Save wash floor details to Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "FormulaWashFloor");           
            DateTime lastSyncTime = log == null ? DateTime.Now : log.MyServiceLastSynchTime;
            this.ProcessFrmWashFloorMyServiceSync(lastSyncTime);
            this.ProcessCustFrmWashFloorMyServiceSync(lastSyncTime);
            this.ProcessEfficiencyWashFloorMyServiceSync(lastSyncTime);

            if (responseFlag)
            {
                Log.Info("Syncing Success for WashFloor data. " + ecolabAccountNumber);
                MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "FormulaWashFloor", "Yes");
            }
            else
            {
                Log.Info("Syncing Fail for WashFloor data." + ecolabAccountNumber);
                MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "FormulaWashFloor", "Fail");
            }
        }

        /// <summary>
        /// Process formula washfloor data
        /// </summary>
        /// <param name="lastSyncTime">Last sync time</param>
        private void ProcessFrmWashFloorMyServiceSync(DateTime lastSyncTime)
        {
            List<WashFloorFormula> washFloorFormula = CubeAccess.FetchFormulaWashfloorData(lastSyncTime);
            MyServiceWashFloor myServiceWashFloorGuids = null;
            foreach (WashFloorFormula item in washFloorFormula)
            {
                try
                {
                    myServiceWashFloorGuids = MyServiceWashFloorDataAccess.GetMyServiceDetails(Convert.ToInt32(item.WasherId), Convert.ToInt32(item.ProgramNumber), item.EcolabAccountNumber);
                    if (myServiceWashFloorGuids != null)
                    {
                        MyServiceWashFloorAccess.SaveMyServiceWashFloorFormula(myServiceWashFloorGuids, item.Loads);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in Formula washfloor data sync : " + ex.ToString());
                    Log.Error("Formula wash floor data EcolabAccountNumber :: " + item.EcolabAccountNumber + ", Data ::" + MyServiceCommon.SerializeToJsonFromEntity<WashFloorFormula>(item));
                    responseFlag = false;
                }
            }
        }

        /// <summary>
        /// Process customer washfloor data
        /// </summary>
        /// <param name="lastSyncTime">Last sync time</param>
        private void ProcessCustFrmWashFloorMyServiceSync(DateTime lastSyncTime)
        {
            List<CustLoadsWashFloor> washFloorFormula = CubeAccess.FetchCustomerFormulaWashfloorData(lastSyncTime);
            foreach (CustLoadsWashFloor item in washFloorFormula)
            {
                try
                {
                    MyServiceWashFloorAccess.SaveMyServiceCustWashFloorFormula(item.EcolabAccountNumber, item.Loads, item.SoilWeight, item.WashFloorDate);
                }
                catch (Exception ex)
                {
                    Log.Error("Error in Customer washfloor data sync : " + ex.ToString());
                    Log.Error("Customer wash floor data EcolabAccountNumber :: " + item.EcolabAccountNumber + ", Data ::" + MyServiceCommon.SerializeToJsonFromEntity<CustLoadsWashFloor>(item));
                    responseFlag = false;
                }
            }
        }

        /// <summary>
        /// Process efficiency washfloor data
        /// </summary>
        /// <param name="lastSyncTime">Last sync time</param>
        private void ProcessEfficiencyWashFloorMyServiceSync(DateTime lastSyncTime)
        {
            List<CustEfficiencyWashFloor> washFloorFormula = CubeAccess.FetchEfficiencyWashfloorData(lastSyncTime);
            foreach (CustEfficiencyWashFloor item in washFloorFormula)
            {
                try
                {
                    MyServiceWashFloorAccess.SaveMyServiceEffWashFloor(item.EcolabAccountNumber, item.TotalEfficiency, item.LoadEfficiency, item.TurnTime, item.TransferTime, lastSyncTime);
                }
                catch (Exception ex)
                {
                    Log.Error("Error in Efficiency washfloor data sync : " + ex.ToString());
                    Log.Error("Efficiency wash floor data EcolabAccountNumber :: " + item.EcolabAccountNumber + ", Data ::" + MyServiceCommon.SerializeToJsonFromEntity<CustEfficiencyWashFloor>(item));
                    responseFlag = false;
                }
            }
        }

        public void Save(List<Entities.Plant> plants)
        {
            throw new NotImplementedException();
        }
    }
}
