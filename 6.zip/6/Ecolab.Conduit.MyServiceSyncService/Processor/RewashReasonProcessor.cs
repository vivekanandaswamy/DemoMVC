﻿// -----------------------------------------------------------------------
// <copyright file="RewashReasonProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ChainTextileCategory processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.ManualInput.Rewash;
    using log4net;

    /// <summary>
    /// RewashReasonProcessor Class
    /// </summary>
    public class RewashReasonProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

		/// <summary>
		/// response flag
		/// </summary>
		private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Rewash Reason details from central to Local Plant(s).
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("Started Central sync for master data Rewash Reason(s)");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "RewashReason");

            DateTime lastSyncTime;
            if (log != null)
            {
                Log.Info("Message fetched from Central Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                lastSyncTime = log.MyServiceLastSynchTime;
            }
            else
            {
                lastSyncTime = DateTime.Now.AddYears(-100);
            }

            List<Ecolab.Models.ManualInput.Rewash.RewashReason> listOfRewashReasons = this.GetAllCentralRewashReasons(lastSyncTime);

            this.ProcessMyServiceObject(plants, log, listOfRewashReasons);
        }

	    /// <summary>
	    ///     Get Central Rewash Reasons
	    /// </summary>
	    /// <param name="lastSyncTime">Last Sync Time</param>
	    /// <returns>List of Rewash Reasons object</returns>
	    private List<Ecolab.Models.ManualInput.Rewash.RewashReason> GetAllCentralRewashReasons(DateTime lastSyncTime)
	    {
		    try
		    {
			    Log.Info("Getting list of Rewash Reasons from Central Conduit");
			    var rewashReasons = RewashReasonAccess.FetchRewashReasonForSync(lastSyncTime);
			    List<Ecolab.Models.ManualInput.Rewash.RewashReason> listOfRewashReasons =
				    Mapper.Map<List<RewashReason>, List<Ecolab.Models.ManualInput.Rewash.RewashReason>>(rewashReasons);
			    foreach (Models.ManualInput.Rewash.RewashReason rewashReason in listOfRewashReasons)
			    {
				    rewashReason.LastModified = DateTime.SpecifyKind(rewashReason.LastModified, DateTimeKind.Utc);
				    if (rewashReason.LastSync != null)
				    {
					    rewashReason.LastSync = DateTime.SpecifyKind(rewashReason.LastSync.Value, DateTimeKind.Utc);
				    }
			    }
			    return listOfRewashReasons;
		    }
		    catch (Exception ex)
		    {
			    Log.Error("Error in Fectching RewashReason from Central DB :: " + ex.ToString());
			    return null;
		    }
	    }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details</param>
        /// <param name="listOfRewashReasons">The list of rewash reasons.</param>
        public void ProcessMyServiceObject(List<Plant> plants, MyServiceSyncLog log, List<Ecolab.Models.ManualInput.Rewash.RewashReason> listOfRewashReasons)
        {
            if (listOfRewashReasons != null && listOfRewashReasons.Count > 0)
            {
                int response = 0;
                Log.Info("Plants to be synced for Rewash Reasons:" + MyServiceCommon.SerializeToJsonFromEntity<List<Ecolab.Models.ManualInput.Rewash.RewashReason>>(listOfRewashReasons));

                foreach (Entities.Plant plant in plants)
                {
                    Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        Log.Info("Rewash reasons send to Push To Master for Plant : " + plant.EcoalabAccountNumber);

                        response = Push.PushMasterData<List<Ecolab.Models.ManualInput.Rewash.RewashReason>>(listOfRewashReasons, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateRewashReasons);

                        if (response != 0)
                        {
                            Log.Info("Rewash Reason Master Data: Push To local: Failed for Plant " + plant.EcoalabAccountNumber);
							responseFlag = false;
                        }
                        else
                        {
                            Log.Info("Rewash Reason Master Data: Push To local: Success for Plant " + plant.EcoalabAccountNumber);
                        }
                    }
                    else
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
                    }
                }
				if (responseFlag)
				{
					Log.Info("Syncing Success for RewashReason");
					if (log != null)
						MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
					else
						MyServiceCommon.UpdateMyServiceSyncLog(null, "RewashReason", "Yes");
				}
				else
				{
					Log.Info("Syncing Fail for RewashReason");
					if (log != null)
						MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
					else
						MyServiceCommon.UpdateMyServiceSyncLog(null, "RewashReason", "Fail");
				}
            }
        }
    }
}
