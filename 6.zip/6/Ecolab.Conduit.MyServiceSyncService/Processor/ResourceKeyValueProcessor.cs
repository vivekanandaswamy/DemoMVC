﻿// -----------------------------------------------------------------------
// <copyright file="ResourceKeyValueProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Resource Key Value Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    /// <summary>
    /// Class for ResourceKeyValueProcessor
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.MyServiceSyncService.Processor.IProcessor" />
    public class ResourceKeyValueProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///  Save ResourceKeyValues details from Myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("ResourceKeyValues: Sync Started");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "ResourceKeyValue");

            DateTime lastSynchTime;
            if (log == null)
            {
                lastSynchTime = DateTime.Now.AddYears(-100);
            }
            else
            {
                lastSynchTime = log.MyServiceLastSynchTime;
            }

            List<ResourceKeyValue> resourceKeyValueDetails = GetResourceKeyValueDetails(lastSynchTime);

            if (resourceKeyValueDetails != null && resourceKeyValueDetails.Count > 0)
            {
                foreach (var item in resourceKeyValueDetails)
                {
                    foreach (var resValue in item.lstResourceValue)
                    {
                        resValue.LastModifiedTime = DateTime.SpecifyKind(resValue.LastModifiedTime, DateTimeKind.Utc);
                    }
                }

                ProcessCentralObject(plants, log, resourceKeyValueDetails);
            }

            if (responseFlag)
            {
                Log.Info("Syncing Success for ResourceKeyValue");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "ResourceKeyValue", "Yes");
            }
            else
            {
                Log.Info("Syncing Fail for ResourceKeyValue");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "ResourceKeyValue", "Fail");
            }
        }

        /// <summary>
        /// Get alarm master list from central
        /// </summary>
        /// <param name="lastSynchTime">last Synch Time from Central to Local</param>
        /// <returns></returns>
        private List<ResourceKeyValue> GetResourceKeyValueDetails(DateTime lastSynchTime)
        {
            try
            {
                List<ResourceKeyValue> resourceKeyValueDetails = new List<ResourceKeyValue>();
                resourceKeyValueDetails = ResourceKeyValueAccess.GetResourceKeysDetails(lastSynchTime);

                foreach (var item in resourceKeyValueDetails)
                {
                    List<ResourceValues> resValues = new List<ResourceValues>();
                    resValues = ResourceKeyValueAccess.GetResourceValues(item.ResourceId);
                    item.lstResourceValue = resValues;

                    List<ResourceKeyPageMapping> resPageMapping = new List<ResourceKeyPageMapping>();
                    resPageMapping = ResourceKeyValueAccess.GetResourceKeyMapping(item.ResourceId);
                    item.lstResourcePageMapping = resPageMapping;
                }

                return resourceKeyValueDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ResourceKeyValueProcessor :: " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Processing of central ResourceKeyValue list
        /// </summary>
        /// <param name="plants">plants from central</param>
        /// <param name="log">log</param>
        /// <param name="resourceKeyValueDetails">The resource key value details.</param>
        private void ProcessCentralObject(List<Plant> plants, MyServiceSyncLog log, List<ResourceKeyValue> resourceKeyValueDetails)
        {
            try
            {
                Log.Info("Insert Or Update ResourceKeyValue data into Local Plants");

                foreach (Plant plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                    if (!isDisconnected)
                    {
                        int response = 0;
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.ResourceKeyValue> resourceKeyValueData = Mapper.Map<List<ResourceKeyValue>, List<Models.ResourceKeyValue>>(resourceKeyValueDetails);

                        response = Push.PushMasterData(resourceKeyValueData, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateResourceKeyValue);
                        if (response != 0)
                        {
                            Log.Info("ResourceKeyValue: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Failed");
                            responseFlag = false;
                        }
                        else
                        {
                            Log.Info("ResourceKeyValue: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Success");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error in ResourceKeyValueProcessor : " + ex);
                responseFlag = false;
            }
        }

        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }
    }
}