﻿// -----------------------------------------------------------------------
// <copyright file="ProcessEntities.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>Processes Entities to save from Myservice </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
	using System;
	using System.Collections.Generic;
	using System.IO;
	using System.Linq;
	using System.Xml.Linq;
	using Access;
	using Ecolab.Conduit.MyServiceSyncService.Model;
	using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
	using Entities;
	using log4net;

	/// <summary>
	/// ProcessEntities class
	/// </summary>
	public static class ProcessEntities
	{
		/// <summary>
		/// logger instance
		/// </summary>
		private static readonly ILog Log = LogManager.GetLogger(typeof(ProcessEntities));

		/// <summary>
		/// Start the sync from Myservice
		/// </summary>
		public static void StartIntegrationProcess()
		{
			List<MyServicePlant> myServicePlants = GetPlants();

			if (myServicePlants != null && myServicePlants.Count > 0)
			{
				foreach (MyServicePlant item in myServicePlants)
				{
					if (item.SyncDateTime == null)
					{
						ProcessPlantCreation(item.EcolabAccountNumber);
					}
				}
			}
			Log.Info("Getting All Plant Details...");
			List<Plant> plants = GetPlantDetails();
			Log.Info("Total Plants : " + plants != null ? plants.Count : 0);

			if (plants != null && plants.Count > 0)
			{
				string myServiceOrder = GetMyserviceXml();

				ProcessMyServiceMasterDataSync(myServiceOrder, plants);

				ProcessEnvisionMasterDataSync(myServiceOrder, plants); 

				foreach (Plant item in plants)
				{
					if (myServicePlants != null && myServicePlants.Count > 0)
					{
						var first = myServicePlants.FirstOrDefault(t => t.EcolabAccountNumber == item.EcoalabAccountNumber);
						if (first != null && first.Active)
						{
							ProcessUIDataSync(myServiceOrder, item.EcoalabAccountNumber);
						}
					}
					else
					{
						ProcessUIDataSync(myServiceOrder, item.EcoalabAccountNumber);
					}
				}
			}
		}

		/// <summary>
		/// Process Plant Creation process
		/// </summary>
		private static void ProcessPlantCreation(string ecolabAccountNumber)
		{
			bool response = true;
			Log.Info("Process of Plant Creation Processed......");
			response = PlantSetupProcessor.ProcessPlantCreation(ecolabAccountNumber);
			if (response)
			{
				Log.Info("Plant Creation Processed successful. :: " + ecolabAccountNumber);
				PlantSetupAccess.UpdatePlantSyncTime(ecolabAccountNumber);
			}
			else
			{
				Log.Info("Plant Creation Processed failed. :: " + ecolabAccountNumber);
			}
		}

		/// <summary>
		/// Get Plant which need to be created
		/// </summary>
		/// <returns>List of plants</returns>
		private static List<MyServicePlant> GetPlants()
		{
			try
			{
				return PlantSetupAccess.GetPlants();
			}
			catch (Exception ex)
			{
				Log.Error("Error in GetPlants from SycnPlant table. " + ex);
			}

			return null;
		}

		/// <summary>
		/// Get Plant Details
		/// </summary>
		/// <returns>List of plants</returns>
		private static List<Plant> GetPlantDetails()
		{
			try
			{
				return PlantAccess.GetPlantDetails();
			}
			catch (Exception ex)
			{
				Log.Error("Error in GetPlants from SycnPlant table. " + ex);
			}

			return null;
		}

		/// <summary>
		/// Get the sync configuration xml
		/// </summary>
		/// <returns>string</returns>
		private static string GetMyserviceXml()
		{
			var basePath = AppDomain.CurrentDomain.RelativeSearchPath ?? AppDomain.CurrentDomain.BaseDirectory;
			XDocument xdoc = null;
			try
			{
				xdoc = XDocument.Load(Path.Combine(basePath, @"MyServiceSyncOrder.xml"));
			}
			catch (FileNotFoundException ex)
			{
				Log.Error(ex.Message + "GetMyserviceXml Method");
			}
			catch (Exception e)
			{
				Log.Error(e.Message + "GetMyserviceXml Method");
				throw;
			}
			if (xdoc != null) return xdoc.ToString();
			return string.Empty;
		}

		/// <summary>
		/// process myservice master data sync objects
		/// </summary>
		/// <param name="myServiceXml">configuration xml</param>
		/// <param name="plants">List of plants</param>
		private static void ProcessMyServiceMasterDataSync(string myServiceXml, List<Plant> plants)
		{
			Log.Info("Started to Sync MyService Master Data....");
			XDocument xdoc = XDocument.Parse(myServiceXml);
			foreach (XElement ele in xdoc.Root.Element("MyServiceMasterData").Elements("Processor"))
			{
				if (ele.Element("Enabled").Value == "true")
				{
					IProcessor processor = ModelFactory.GetProcessorObject(ele.Element("Name").Value);
					processor.Save(plants);
				}
			}
		}

		/// <summary>
		/// process sync objects
		/// </summary>
		/// <param name="myServiceXml">configuration xml</param>
		/// <param name="ecolabAccNum">EcolabAccountNumber</param>
		private static void ProcessUIDataSync(string myServiceXml, string ecolabAccNum)
		{
			Log.Info("Started to Sync UI Data....");
			XDocument xdoc = XDocument.Parse(myServiceXml);

			foreach (XElement ele in xdoc.Root.Element("UIData").Elements("Processor"))
			{
				if (ele.Element("Enabled").Value == "true")
				{
					IProcessor processor = ModelFactory.GetProcessorObject(ele.Element("Name").Value);
					processor.Save(ecolabAccNum);
				}
			}
		}

		/// <summary>
		/// process envision master data sync objects
		/// </summary>
		/// <param name="myServiceXml">configuration xml</param>
		/// <param name="plants">List of plants</param>
		private static void ProcessEnvisionMasterDataSync(string myServiceXml, List<Plant> plants)
		{
			Log.Info("Started to Sync Envision Master Data....");
			XDocument xdoc = XDocument.Parse(myServiceXml);
			foreach (XElement ele in xdoc.Root.Element("EnvisionMasterData").Elements("Processor"))
			{
				if (ele.Element("Enabled").Value == "true")
				{
					IProcessor processor = ModelFactory.GetProcessorObject(ele.Element("Name").Value);
					processor.Save(plants);
				}
			}
		}

		/// <summary>
		/// Syncs Washfloor data to MyService
		/// </summary>
		public static void StartWashFloorDataSync()
		{
			List<Plant> plants = GetPlantDetails();

			if (plants != null && plants.Count > 0)
			{
				IProcessor processor = ModelFactory.GetProcessorObject("FormulaWashfloor");
				processor.Save(string.Empty);
			}
		}
	}
}