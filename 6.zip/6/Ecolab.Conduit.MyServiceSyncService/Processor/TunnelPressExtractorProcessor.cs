﻿// -----------------------------------------------------------------------
// <copyright file="TunnelPressExtractorProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelPressExtractor Processor  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access.Washers.Tunnel;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.Washers.Tunnel;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;

    /// <summary>
    /// TunnelPressExtractorProcessor
    /// </summary>
    public class TunnelPressExtractorProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///     Save Tunnel PressExtractor details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///     Save
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            this._log.Info("Started sync For TunnelPressExtractor");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "TunnelPressExtractor");

            DateTime myServiceTime;
            if (log != null)
            {
                this._log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<PressExtractor> myserviceTunnelPressExtractorDetails =
                this.GetMyServiceTunnelPressExtractorDetails(myServiceTime);

            this.ProcessMyServiceData(plants, log, myserviceTunnelPressExtractorDetails);
        }

        /// <summary>
        ///     To save data in Local as well as in central
        /// </summary>
        /// <param name="plants">list of plants.</param>
        /// <param name="log">log</param>
        /// <param name="myserviceTunnelPressExtractorDetails">list of myservice data to be save in central and local</param>
        public void ProcessMyServiceData(List<Plant> plants, MyServiceSyncLog log,
            List<PressExtractor> myserviceTunnelPressExtractorDetails)
        {
            if (myserviceTunnelPressExtractorDetails != null && myserviceTunnelPressExtractorDetails.Count > 0)
            {
                int response = 0;
                this._log.Info("Insert Or Update TunnelPressExtractor data into Central");
                _log.Info("Total TunnelPressExtractor :: " + myserviceTunnelPressExtractorDetails.Count);
                foreach (PressExtractor tunnelPressExtractorDetails in myserviceTunnelPressExtractorDetails)
                {
                    _log.Info("TunnelPressExtractor Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PressExtractor>(tunnelPressExtractorDetails));
                    this.InsertOrUpdateTunnelPressExtractorDetails(tunnelPressExtractorDetails);
                }
                this._log.Info("Insert Or Update TunnelPressExtractor data into Local Plants");
                foreach (Plant plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        _log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.Washers.Tunnel.PressExtractor> objPressExtractor =
                            Mapper.Map<List<PressExtractor>, List<Models.Washers.Tunnel.PressExtractor>>(
                                myserviceTunnelPressExtractorDetails);
                        response = Push.PushMasterData(objPressExtractor, plant.EcoalabAccountNumber, this.SystemUserId,
                            (int)TcdAdminMessageTypes.TcdUpdateMyServiceTunnelPressExtractor);

                        if (response != 0)
                        {
                            _log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "TunnelPressExtractor");
                            responseFlag = false;
                        }
                    }
                }
                if (responseFlag)
                {
                    this._log.Info("Syncing Success for TunnelPressExtractor");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "TunnelPressExtractor", "Yes");
                }
                else
                {
                    this._log.Info("Syncing Fail for TunnelPressExtractor");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "TunnelPressExtractor", "Fail");
                }
            }
            else
            {
                _log.Info("No data fetched from MyService");
            }
        }

        /// <summary>
        ///     Get MyService Tunnel Press Extractor Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">Last sync time in central</param>
        /// <returns>List of Tunnel Press Extractor</returns>
        public List<PressExtractor> GetMyServiceTunnelPressExtractorDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<PressExtractor> myserviceTunnelPressExtractorDetails =
                    TunnelPressExtractorAccess.GetTunnelPressExtractorDetails(lastSyncTimeInCentral);
                return myserviceTunnelPressExtractorDetails;
            }
            catch (Exception ex)
            {
                _log.Error("Error in TunnelPressExtractorProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        ///     Insert or Update Tunnel Press Extractor in Central
        /// </summary>
        /// <param name="tunnelPressExtractorDetails">Tunnel Press Extractor from MyService</param>
        public void InsertOrUpdateTunnelPressExtractorDetails(PressExtractor tunnelPressExtractorDetails)
        {
            try
            {
                tunnelPressExtractorDetails.Id =
                    TunnelGeneralAccess.SaveMyServiceTunnelPressExtractorDetails(tunnelPressExtractorDetails);
                TunnelGeneralAccess.SaveMyServiceTunnelPressExtractorLocaleDetails(tunnelPressExtractorDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                _log.Error("Error in TunnelPressExtractorProcessor :: " + ex.ToString());
                _log.Error("TunnelPressExtractor Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PressExtractor>(tunnelPressExtractorDetails));
            }
        }
    }
}