﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactPositionProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant contact processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.Common;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;

    /// <summary>
    /// PlantContactPositionProcessor class
    /// </summary>
    class PlantContactPositionProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Plant Contact Positions details from myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            Log.Info("Started sync For PlantContactPosition");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "PlantContactPosition");
            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }
            List<PlantContactPosition> myservicePlantContactPositionDetails = GetMyServicePlantContactPositionDetails(myServiceTime);
            ProcessMyServiceObject(plants, log, myservicePlantContactPositionDetails);
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myservicePlantContactPositionDetails">MyService Object</param>
        private void ProcessMyServiceObject(List<Plant> plants, MyServiceSyncLog log, List<PlantContactPosition> myservicePlantContactPositionDetails)
        {
            if (myservicePlantContactPositionDetails != null && myservicePlantContactPositionDetails.Count > 0)
            {
                Log.Info("PlantContactPosition: Insert Or Update data into Central");
                Log.Info("Total PlantContactPosition :: " + myservicePlantContactPositionDetails.Count);
                foreach (PlantContactPosition item in myservicePlantContactPositionDetails)
                {
                    Log.Info("PlantContactPosition Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PlantContactPosition>(item));
                    InsertOrUpdatePlantContactPositionDetails(item);
                }
                Log.Info("PlantContactPosition: Sync to central: Success");
                Log.Info("PlantContactPosition: Insert Or Update PlantContactPosition data into Local Plants");
                foreach (var plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                    if (!isDisconnected)
                    {
                        int response = 0;
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.Common.PlantContactPosition> plantContactPositionDetails = Mapper.Map<List<PlantContactPosition>, List<Models.Common.PlantContactPosition>>(myservicePlantContactPositionDetails);
                        response = Push.PushMasterData(plantContactPositionDetails, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceContactPosition);
                        if (response != 0)
                        {
                            Log.Info("PlantContactPosition: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Failed");
                            responseFlag = false;
                        }
                        else
                        {
                            Log.Info("PlantContactPosition: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Success");
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for PlantContactPosition");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantContactPosition", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for PlantContactPosition");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantContactPosition", "Fail");
                }
            }
        }

        /// <summary>
        /// Insert or Update Plant Address in Central
        /// </summary>
        /// <param name="myservicePlantContactPosition">myservicePlantContactPosition</param>
        private void InsertOrUpdatePlantContactPositionDetails(PlantContactPosition myservicePlantContactPosition)
        {
            try
            {
                myservicePlantContactPosition.Id = Access.Common.PlantContactPositionAccess.SaveMyServicePlantContactPositionDetails(myservicePlantContactPosition);
                Access.Common.PlantContactPositionAccess.SaveMyServicePlantContactPositionLocaleDetails(myservicePlantContactPosition);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in PlantContactPositionProcessor :: " + ex.ToString());
                Log.Error("PlantContactPosition Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PlantContactPosition>(myservicePlantContactPosition));
            }
        }

        /// <summary>
        /// Get MyService Plant Contact Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">lastSyncTimeInCentral</param>
        /// <returns>List of Plant Contact</returns>
        private List<PlantContactPosition> GetMyServicePlantContactPositionDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<PlantContactPosition> myservicePlantChainDetails = PlantContactPositionAccess.GetPlantContactPositionDetails(lastSyncTimeInCentral);
                return myservicePlantChainDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantContactPositionProcessor :: " + ex.ToString());
                return null;
            }
        }
    }
}
