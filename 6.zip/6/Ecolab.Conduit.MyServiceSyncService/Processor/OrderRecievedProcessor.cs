﻿// -----------------------------------------------------------------------
// <copyright file="OrderRecievedProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Order Recieved Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Common;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;
    using Newtonsoft.Json;

    /// <summary>
    /// Class for OrderRecievedProcessor
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.MyServiceSyncService.Processor.IProcessor" />
    public class OrderRecievedProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog logManager = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///  Save Order Recieved details from Myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
        }

        /// <summary>
        ///  Save Order Recieved details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountnUmber</param>
        public void Save(string ecolabAccountNumber)
        {
            logManager.Info("Started sync For OrderRecieved");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "OrderRecieved");

			DateTime myServiceTime;
            if (log != null)
            {
				logManager.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

				myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
			}
			else
			{
				myServiceTime = DateTime.Now.AddYears(-100);
            }
            
			List<OrderRecieved> myserviceOrderRecievedDetails = GetMyServiceOrderRecievedDetails(ecolabAccountNumber, myServiceTime);

            ProcessMyServiceData(ecolabAccountNumber, log, myserviceOrderRecievedDetails);
        }

        /// <summary>
        /// Gets my service order recieved details.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="myServiceTime">My service time.</param>
        /// <returns>List of OrderRecieved</returns>
        private List<OrderRecieved> GetMyServiceOrderRecievedDetails(string ecolabAccountNumber, DateTime myServiceTime)
        {
            try
            {
                List<OrderRecieved> myserviceOrderRecievedDetails = OrderRecievedAccess.GetOrderRecievedDetails(ecolabAccountNumber, myServiceTime);
                return myserviceOrderRecievedDetails;
            }
            catch (Exception ex)
            {
                logManager.Error("Error in OrderRecievedProcessor : " + ex);
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Processes my service data.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="log">The MyServiceSyncLog.</param>
        /// <param name="myserviceOrderRecievedDetails">The myservice order recieved details.</param>
        private void ProcessMyServiceData(string ecolabAccountNumber, MyServiceSyncLog log, List<OrderRecieved> myserviceOrderRecievedDetails)
        {
            if (myserviceOrderRecievedDetails != null && myserviceOrderRecievedDetails.Count > 0)
            {
                int response = 0;
                bool isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
                if (!isDisconnected)
                {
                    logManager.Info("Plant " + ecolabAccountNumber + " is " + "Connected");

                    List<Ecolab.Models.OrderRecieved> orderRecievedDetails = Mapper.Map<List<OrderRecieved>, List<Ecolab.Models.OrderRecieved>>(myserviceOrderRecievedDetails);
                    foreach (var orderRecieved in orderRecievedDetails)
                    {
                        response = Push.PushToLocal<Ecolab.Models.OrderRecieved>(orderRecieved, ecolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateOrderRecieved);
                    }

                    if (response != 0)
                    {
                        logManager.Info("Syncing Fail in Local Plant: " + ecolabAccountNumber + "for " + "OrderRecieved");
                        responseFlag = false;
                    }
                    else
                    {
                        logManager.Info("Syncing Success in Local Plant: " + ecolabAccountNumber + "for OrderRecieved");
                    }
                }
                else
                {
                    logManager.Info("Insert Or Update Oder recieved data for EcolabAccountNumber: " + ecolabAccountNumber);

                    foreach (var orderRecieved in myserviceOrderRecievedDetails)
                    {
                        int orderRecievedId = InsertOrUpdateOrderRecievedDetails(orderRecieved);
                        orderRecieved.Id = orderRecievedId;
                    }
                }
            }
            else
            {
                logManager.Info("OrderRecievedProcessor: No Order Recieved data available to sync to enVision for EcolabAccountNumber: " + ecolabAccountNumber);
            }
            if (responseFlag)
            {
                logManager.Info("Syncing Success for OrderRecieved: " + ecolabAccountNumber);
                if (log != null)
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "OrderRecieved", "Yes");
                }
            }
            else
            {
                logManager.Info("Syncing Fail for OrderRecieved: " + ecolabAccountNumber);
                if (log != null)
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "OrderRecieved", "Fail");
                }
            }
        }

        /// <summary>
        /// Inserts the or update order recieved details.
        /// </summary>
        /// <param name="orderRecieved">The order recieved.</param>
        /// <returns>Returns the integer value.</returns>
        private int InsertOrUpdateOrderRecievedDetails(OrderRecieved orderRecieved)
        {
            try
            {
                return Access.OrderRecievedAccess.SaveOrderRecievedDetaisl(orderRecieved);
            }
            catch (Exception ex)
            {
                logManager.Error("Error in OrderRecievedProcessor : " + ex);
                logManager.Error("Order Received Details :: " + JsonConvert.SerializeObject(orderRecieved));
                responseFlag = false;
                return 0;
            }
        }
    }
}