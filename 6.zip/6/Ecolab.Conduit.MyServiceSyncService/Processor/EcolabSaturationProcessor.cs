﻿// -----------------------------------------------------------------------
// <copyright file="EcolabSaturationProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The EcolabSaturation processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    /// <summary>
    /// EcolabSaturationProcessor class
    /// </summary>
    public class EcolabSaturationProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Ecolab Saturation details from myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("Started sync For EcolabSaturation");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "EcolabSaturation");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            Log.Info("Getting list of My Service EcolabSaturation Details from My Service");
            List<EcolabSaturation> myserviceEcolabSaturationDetails = GetMyServiceEcolabSaturationDetails(myServiceTime);

            Log.Info("Process started for saving EcolabSaturation in COnduit");
            ProcessMyServiceObject(plants, log, myserviceEcolabSaturationDetails);
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myserviceEcolabSaturationDetails">MyService Object</param>
        public void ProcessMyServiceObject(List<Entities.Plant> plants, MyServiceSyncLog log, List<EcolabSaturation> myserviceEcolabSaturationDetails)
        {
            if (myserviceEcolabSaturationDetails != null && myserviceEcolabSaturationDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Looping each EcolabSaturation to save in Central Conduit");
                Log.Info("Total EcolabSaturation :: " + myserviceEcolabSaturationDetails.Count);
                foreach (EcolabSaturation item in myserviceEcolabSaturationDetails)
                {
                    Log.Info("EcolabSaturation Detail : " + MyServiceCommon.SerializeToJsonFromEntity<EcolabSaturation>(item));
                    InsertOrUpdateEcolabSaturationDetails(item);
                }

                Log.Info("Saving EcolabSaturation data into Local Plants");
                foreach (var plant in plants)
                {
                    Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Ecolab.Models.EcolabSaturation> ecolabSaturations = Mapper.Map<List<EcolabSaturation>, List<Ecolab.Models.EcolabSaturation>>(myserviceEcolabSaturationDetails);

                        Log.Info("EcolabSaturation send to Push To Master for Plant : " + plant.EcoalabAccountNumber);
                        response = Push.PushMasterData<List<Ecolab.Models.EcolabSaturation>>(ecolabSaturations, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceEcolabSaturation);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "EcolabSaturation");
                            responseFlag = false;
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for EcolabSaturation");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "EcolabSaturation", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for EcolabSaturation");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "EcolabSaturation", "Fail");
                }
            }
        }

        /// <summary>
        /// Insert or Update EcolabSaturation Details in Central
        /// </summary>
        /// <param name="myserviceEcolabSaturationDetails">EcolabSaturation from MyService</param>
        private void InsertOrUpdateEcolabSaturationDetails(EcolabSaturation myserviceEcolabSaturationDetails)
        {
            try
            {
                Log.Info("Saving EcolabSaturation into Central Conduit");
                myserviceEcolabSaturationDetails.EcolabSaturationId = Access.PlantSaturationAccess.SaveMyServiceEcolabSaturationDetails(myserviceEcolabSaturationDetails);
                Access.PlantSaturationAccess.SaveMyServiceEcolabSaturationLocaleDetails(myserviceEcolabSaturationDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in EcolabSaturationProcessor :: " + ex.ToString());
                Log.Error("EcolabSaturation Detail : " + MyServiceCommon.SerializeToJsonFromEntity<EcolabSaturation>(myserviceEcolabSaturationDetails));
            }
        }

        /// <summary>
        /// Get MyService EcolabSaturation
        /// </summary>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <returns>List of EcolabSaturation object</returns>
        private List<EcolabSaturation> GetMyServiceEcolabSaturationDetails(DateTime lastSyncTime)
        {
            try
            {
                List<EcolabSaturation> myserviceEcolabSaturationDetails = EcolabSaturationAccess.GetEcolabSaturationDetails(lastSyncTime);
                return myserviceEcolabSaturationDetails; ;
            }
            catch (Exception ex)
            {
                Log.Error("Error in EcolabSaturationProcessor :: " + ex.ToString());
                return null;
            }
        }
    }
}