﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWasherProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Tunnel Washer Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access.WasherGroup;
    using Access.Washers.Tunnel;
    using AutoMapper;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Entities;
    using Entities.WasherGroup;
    using Entities.Washers.Tunnel;
    using log4net;

    /// <summary>
    /// TunnelWasherProcessor class
    /// </summary>
    public class TunnelWasherProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Saves the specified ecolab account number.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync For Tunnel Washer");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "TunnelWasher");
            int washerCount = TunnelGeneralAccess.GetMaxNumberOfRecords(ecolabAccountNumber);
            DateTime myServiceTime = DateTime.Now.AddYears(-100);
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                SaveTunnelWasherListInMyService(log, log.MyServiceLastSynchTime, ecolabAccountNumber);
                if (responseFlag)
                {
                    Log.Info("Syncing Success for TunnelWasher  " + ecolabAccountNumber);
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for TunnelWasher" + ecolabAccountNumber);
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                }
            }
            else
            {
                if (washerCount > 0)
                {
                    Log.Info("First Time Synch Start for plant " + ecolabAccountNumber);
                    SaveInConduitForFirstTimeSynch(myServiceTime, ecolabAccountNumber);
                    if (responseFlag)
                    {
                        Log.Info("Syncing Success for TunnelWasher  " + ecolabAccountNumber);
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "TunnelWasher", "Yes");
                    }
                    else
                    {
                        Log.Info("Syncing Fail for TunnelWasher" + ecolabAccountNumber);
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "TunnelWasher", "Fail");
                    }
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "TunnelWasher", "Yes");
                    Log.Info("There is no tunnel washer present in conduit. first TM need to create a Tunnel Washer with the same name as in myService to proceed Tunnel Washer Creation for ecolab account number :: " + ecolabAccountNumber);
                }
            }
        }

        /// <summary>
        /// Saving MyService data in Conduit for First Time Synch.
        /// </summary>
        /// <param name="myServiceTime">My service time.</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>        
        private void SaveInConduitForFirstTimeSynch(DateTime myServiceTime, string ecolabAccountNumber)
        {
            try
            {
                responseFlag = true;
                Log.Info("Getting Tunnel WasherGroups");
                List<Entities.WasherGroup.WasherGroup> washerGroupList = GetMyServiceWasherGroups(myServiceTime, ecolabAccountNumber);
                Log.Info("Tunnel Washer Group data ::" + MyServiceCommon.SerializeToJsonFromEntity<List<Entities.WasherGroup.WasherGroup>>(washerGroupList));
                Log.Info("Getting list of Tunnel Washer from My Service");
                foreach (var washerGroup in washerGroupList)
                {
                    Entities.Washers.Tunnel.TunnelGeneral myserviceTunnelGeneralDetails = GetMyServiceTunnelWashers(myServiceTime, ecolabAccountNumber, washerGroup);
                    if (myserviceTunnelGeneralDetails != null)
                    {
                        myserviceTunnelGeneralDetails.WasherGroupId = GetWasherGroupId(washerGroup, ecolabAccountNumber);
                        Log.Info("Tunnel Washer data ::" + MyServiceCommon.SerializeToJsonFromEntity<Entities.Washers.Tunnel.TunnelGeneral>(myserviceTunnelGeneralDetails));
                        SaveTunnelGeneralData(myserviceTunnelGeneralDetails, ecolabAccountNumber, myServiceTime);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
            }
        }

        /// <summary>
        /// Get MyService Tunnel Washers
        /// </summary>
        /// <param name="myServiceTime">myService Time</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="washerGroup">Washer Group Details</param>
        /// <returns>myservice Tunnel General Details</returns>
        private TunnelGeneral GetMyServiceTunnelWashers(DateTime myServiceTime, string ecolabAccountNumber, WasherGroup washerGroup)
        {
            try
            {
                Entities.Washers.Tunnel.TunnelGeneral myserviceTunnelGeneralDetails = TunnelWasherAccess.GetTunnelGeneralDetails(washerGroup.MyServiceWasherGroupGuid, ecolabAccountNumber, myServiceTime);
                return myserviceTunnelGeneralDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Get MyService Washer Groups
        /// </summary>
        /// <param name="myServiceTime">myService Time</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Washer group List</returns>
        private List<WasherGroup> GetMyServiceWasherGroups(DateTime myServiceTime, string ecolabAccountNumber)
        {
            try
            {
                List<Entities.WasherGroup.WasherGroup> washerGroupList = WasherGroupsAccess.GetWasherGroupsDetails(ecolabAccountNumber, myServiceTime).Where(t => t.WasherGroupTypeId == 2).ToList();
                return washerGroupList;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// To fetch WasherGroup Id
        /// </summary>
        /// <param name="washerGroup">The washerGroup details</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Returns washer group ID</returns>
        private int GetWasherGroupId(WasherGroup washerGroup, String ecolabAccountNumber)
        {
            try
            {
                List<WasherGroup> washerGroups = WasherGroupAccess.GetWasherGroupDetails(-1, ecolabAccountNumber);

                washerGroup.WasherGroupId = washerGroups.Where(t => t.MyServiceWasherGroupGuid == washerGroup.MyServiceWasherGroupGuid).FirstOrDefault().WasherGroupId;
                return washerGroup.WasherGroupId;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return 0;
            }
        }

        /// <summary>
        /// Saving Tunnel General Data in conduit.
        /// </summary>
        /// <param name="tunnelGeneral">tunnelGeneral</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="myServiceTime">My service time.</param>
        public void SaveTunnelGeneralData(TunnelGeneral tunnelGeneral, string ecolabAccountNumber, DateTime myServiceTime)
        {
            int response = 0;

            Log.Info("Saving tunnel genral in Conduit--Central");
            tunnelGeneral.ModelId = Convert.ToInt16(tunnelGeneral.MyServiceModelId);
            tunnelGeneral.MaxLoad = Convert.ToInt16(tunnelGeneral.MyServiceMaxLoad);
            tunnelGeneral.RegionId = MyServiceCommon.GetRegionId(tunnelGeneral.RegionCode);
            tunnelGeneral.EcolabAccountNumber = ecolabAccountNumber;

            try
            {
                response = Access.Washers.Tunnel.TunnelGeneralAccess.SaveMyServiceTunnelData(tunnelGeneral, SystemUserId);
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                Log.Error("Tunnel Washer data ::" + MyServiceCommon.SerializeToJsonFromEntity<Entities.Washers.Tunnel.TunnelGeneral>(tunnelGeneral));
                responseFlag = false;
            }

            Log.Info("Getting List of compatment for the tunnel" + tunnelGeneral.MyServiceWashersGuid);
            List<Entities.Washers.Tunnel.TunnelCompartment> TunnelCompartmentList = GetMyServiceTunnelCompartment(tunnelGeneral, ecolabAccountNumber, myServiceTime);
            Log.Info("Tunnel Washer Compartment data ::" + MyServiceCommon.SerializeToJsonFromEntity<List<Entities.Washers.Tunnel.TunnelCompartment>>(TunnelCompartmentList));
            TunnelGeneral tunnelData = TunnelGeneralAccess.GetTunnelData(null, tunnelGeneral.WasherGroupId, ecolabAccountNumber);
            if (tunnelData != null)
            {
                int washerId = tunnelData.Id;
                foreach (var item in TunnelCompartmentList)
                {
                    item.Id = washerId;
                }
                response = SaveCompartmentListInConduit(TunnelCompartmentList, ecolabAccountNumber, tunnelGeneral.MyServiceWashersGuid, tunnelGeneral.MyServiceWasherGroupGuid);
            }

            if (response < 0)
            {
                responseFlag = false;
            }
        }

        /// <summary>
        /// Get MyService Tunnel Compartment
        /// </summary>
        /// <param name="tunnelGeneral">tunnel General details</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="myServiceTime">the myService Time</param>
        /// <returns> MyService Tunnel Compartment LIst</returns>
        private List<TunnelCompartment> GetMyServiceTunnelCompartment(TunnelGeneral tunnelGeneral, string ecolabAccountNumber, DateTime myServiceTime)
        {
            try
            {
                List<Entities.Washers.Tunnel.TunnelCompartment> TunnelCompartmentList = TunnelWasherAccess.GetTunnelCompartmentList(tunnelGeneral.MyServiceWashersGuid, ecolabAccountNumber, myServiceTime);
                return TunnelCompartmentList;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saving MyService Tunnel Compartment in Conduit.
        /// </summary>
        /// <param name="TunnelCompartmentList">TunnelCompartmentList</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="myServiceWasherId">My service washer identifier.</param>
        /// <param name="myServiceWasherGroupGuid">My service washer group unique identifier.</param>
        /// <returns>Returns response</returns>
        public int SaveCompartmentListInConduit(List<TunnelCompartment> TunnelCompartmentList, String ecolabAccountNumber, Guid myServiceWasherId, Guid myServiceWasherGroupGuid)
        {
            int response = 0;
            Log.Info("Saving compartments in conduit --Central");
            foreach (var tunnelCompartment in TunnelCompartmentList)
            {
                try
                {
                    DateTime LastModifiedTime = DateTime.UtcNow;
                    tunnelCompartment.EcolabAccountNumber = ecolabAccountNumber;
                    tunnelCompartment.WaterinletDrainId = TunnelWasherAccess.GetConduitWaterInletDrainId(tunnelCompartment.WaterinletDrainId);
                    tunnelCompartment.WaterFlowId = TunnelWasherAccess.GetConduitWaterFlowId(tunnelCompartment.WaterFlowId);
                    tunnelCompartment.WashStepId = TunnelWasherAccess.GetConduitWashStepId(tunnelCompartment.WashStepId);

                    Access.Washers.Tunnel.TunnelCompartmentAccess.SaveTunnelDataForMyService(tunnelCompartment, SystemUserId, out LastModifiedTime);
                    tunnelCompartment.MyServiceWasherId = myServiceWasherId;
                    tunnelCompartment.PumpAssociationList = GetPumpAssociationList(tunnelCompartment, myServiceWasherGroupGuid);

                    if (tunnelCompartment.PumpAssociationList != null && tunnelCompartment.PumpAssociationList.Count > 0)
                    {
                        Log.Info("Tunnel Washer Pump data :: " + MyServiceCommon.SerializeToJsonFromEntity<List<PumpAssociation>>(tunnelCompartment.PumpAssociationList));
                        foreach (var pump in tunnelCompartment.PumpAssociationList)
                        {
                            try
                            {
                                pump.EcolabAccountNumber = ecolabAccountNumber;
                                response = SavePumpAssocialtionListForMyService(pump);
                            }
                            catch (Exception ex)
                            {
                                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                                Log.Error("Tunnel Washer Pump data ::" + MyServiceCommon.SerializeToJsonFromEntity<PumpAssociation>(pump));
                                responseFlag = false;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                    Log.Error("Tunnel Washer Compartment data ::" + MyServiceCommon.SerializeToJsonFromEntity<Entities.Washers.Tunnel.TunnelCompartment>(tunnelCompartment));
                    responseFlag = false;
                }
            }

            return response;
        }

        /// <summary>
        /// Saving MyService Pumps in Conduit.
        /// </summary>
        /// <param name="pump">The pump details</param>
        /// <returns>Returns a int value</returns>
        private int SavePumpAssocialtionListForMyService(PumpAssociation pump)
        {
            return Access.Washers.Tunnel.TunnelCompartmentAccess.SaveTunnelCompartmentPumpAssociationDataForMyService(pump);
        }

        /// <summary>
        /// Getting MyServicePumpAssocitionList
        /// </summary>
        /// <param name="tunnelCompartment">tunnel Compartment details</param>
        /// <param name="myServiceWasherGroupGuid">myServiceWasherGroupGuid</param>
        /// <returns>Returns list of pumps</returns>
        private List<PumpAssociation> GetPumpAssociationList(TunnelCompartment tunnelCompartment, Guid myServiceWasherGroupGuid)
        {
            return TunnelWasherAccess.GetPumpAssociationList(tunnelCompartment, myServiceWasherGroupGuid);
        }

        /// <summary>
        /// Saving Conduit data in MyService.
        /// </summary>
        /// <param name="log">The MyServiceSync Log</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        private void SaveTunnelWasherListInMyService(MyServiceSyncLog log, DateTime myServiceLastSynchTime, string ecolabAccountNumber)
        {
            try
            {
                Log.Info("Saving in My Service for tunnel started ." + ecolabAccountNumber);
                List<TunnelGeneral> conduitTunnelGeneralDetails = new List<TunnelGeneral>();

                Log.Info("Getting List For all washer Groups for " + ecolabAccountNumber);
                List<WasherGroup> conduitWasherGroupDetails = GetConduitWasherGroupDetails(ecolabAccountNumber);

                TunnelGeneral tunnelDetails = new TunnelGeneral();
                Log.Info("Getting List of all Tunnel Washers");
                foreach (var item in conduitWasherGroupDetails)
                {
                    if (item.WasherGroupTypeId == 2)
                    {
                        tunnelDetails = GetConduitTunnelWashers(ecolabAccountNumber, tunnelDetails, item);
                        if (tunnelDetails != null)
                        {
                            conduitTunnelGeneralDetails.Add(tunnelDetails);
                        }
                    }
                }

                List<TunnelGeneral> tunnelGeneralList = new List<TunnelGeneral>();
                Log.Info("Getting List For all Tunnel Washers to save in myservice");

                if (log != null)
                {
                    tunnelGeneralList = GetTunnelGeneralListToSaveInMyService(conduitTunnelGeneralDetails, log.MyServiceLastSynchTime);
                }
                else
                {
                    tunnelGeneralList = GetTunnelGeneralListToSaveInMyService(conduitTunnelGeneralDetails, myServiceLastSynchTime);
                }

                Log.Info("Getting List Of tunnels with Compartmnets for these tunnels");
                List<Ecolab.Models.Washers.Tunnel.TunnelContainer> tunnels = GetCompartmentList(tunnelGeneralList);

                Log.Info("Saving tunnels in myService");
                SaveTunnelListInMyService(tunnels);

            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
            }
        }

        /// <summary>
        /// Get Conduit Tunnel Washers
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="tunnelDetails">tunnel general Details</param>
        /// <param name="item">washer group item</param>
        /// <returns>Returns tunnel general details</returns>
        private TunnelGeneral GetConduitTunnelWashers(string ecolabAccountNumber, TunnelGeneral tunnelDetails, WasherGroup item)
        {
            try
            {
                tunnelDetails = Access.Washers.Tunnel.TunnelGeneralAccess.GetTunnelListData(item.WasherGroupId, ecolabAccountNumber, true);
                return tunnelDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Get Conduit Washer Group Details
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <returns>conduit Washer Group Details</returns>
        private List<WasherGroup> GetConduitWasherGroupDetails(string ecolabAccountNumber)
        {
            try
            {
                List<WasherGroup> conduitWasherGroupDetails = Access.WasherGroup.WasherGroupAccess.GetWasherGroupDetails(-1, ecolabAccountNumber);
                return conduitWasherGroupDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Getting CentralTunnelWasher with compartments to be insert in MyService.
        /// </summary>
        /// <param name="tunnelGeneralList">tunnelGeneralList</param>
        /// <returns>Returns tunnel list</returns>
        private List<Models.Washers.Tunnel.TunnelContainer> GetCompartmentList(List<TunnelGeneral> tunnelGeneralList)
        {
            //TunnelCompartmentAccess tunnelCompartmentServices = new TunnelCompartmentServices();
            List<Ecolab.Models.Washers.Tunnel.TunnelContainer> tunnels = new List<Ecolab.Models.Washers.Tunnel.TunnelContainer>();

            List<Ecolab.Models.Washers.Tunnel.TunnelGeneral> tunnelData =
                        Mapper.Map<List<Entities.Washers.Tunnel.TunnelGeneral>, List<Ecolab.Models.Washers.Tunnel.TunnelGeneral>>(tunnelGeneralList);

            tunnelData = tunnelData.Where(item => item.WasherTypeName == "Tunnel").ToList();
            foreach (var item in tunnelData)
            {
                Ecolab.Models.Washers.Tunnel.TunnelContainer container = new Ecolab.Models.Washers.Tunnel.TunnelContainer();
                container.TunnelCompartments = new List<Ecolab.Models.Washers.Tunnel.TunnelCompartment>();
                container.TunnelGeneral = item;

                for (int compartmentNumber = 1; compartmentNumber <= item.NoofCompartments; compartmentNumber++)
                {
                    TunnelCompartment compartment = GetConduitCompartmentData(item, compartmentNumber);

                    Ecolab.Models.Washers.Tunnel.TunnelCompartment tunnelCompartment =
                            Mapper.Map<TunnelCompartment, Ecolab.Models.Washers.Tunnel.TunnelCompartment>(compartment);

                    if (compartment.TunnelCompartmentId > 0)
                        container.TunnelCompartments.Add(tunnelCompartment);
                }

                tunnels.Add(container);
            }

            return tunnels;
        }

        /// <summary>
        /// Get Conduit Compartment Data
        /// </summary>
        /// <param name="item">Tunnel General item</param>
        /// <param name="compartmentNumber">The compartment Number</param>
        /// <returns>Tunnel Compartment</returns>
        private TunnelCompartment GetConduitCompartmentData(Models.Washers.Tunnel.TunnelGeneral item, int compartmentNumber)
        {
            try
            {
                TunnelCompartment compartment =
                            TunnelCompartmentAccess.GetCompartmentData(item.Id, item.WasherGroupId, item.EcolabAccountNumber, Convert.ToByte(compartmentNumber), false);
                return compartment;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Getting CentralTunnelWasher to be insert in MyService.
        /// </summary>
        /// <param name="conduitTunnelGeneralDetails">conduitTunnelGeneralDetails</param>
        /// <param name="myServiceLastSynchTime">myServiceLastSynchTime</param>
        /// <returns>tunnel General List</returns>
        private List<TunnelGeneral> GetTunnelGeneralListToSaveInMyService(List<TunnelGeneral> conduitTunnelGeneralDetails, DateTime myServiceLastSynchTime)
        {
            List<TunnelGeneral> tunnelGeneralList = new List<TunnelGeneral>();

            foreach (var conduitTunnelGeneral in conduitTunnelGeneralDetails)
            {
                if (conduitTunnelGeneral.LastModifiedTimestamp > myServiceLastSynchTime)
                {
                    TunnelGeneral tunnelGeneral = conduitTunnelGeneral;
                    tunnelGeneralList.Add(tunnelGeneral);
                }
            }

            return tunnelGeneralList;
        }

        /// <summary>
        /// Save Tunnels details to My Service from Conduit
        /// </summary>
        /// <param name="tunnels">The tunnels list.</param>
        public void SaveTunnelListInMyService(List<Ecolab.Models.Washers.Tunnel.TunnelContainer> tunnels)
        {
            int response = 0;
            int serviceItemResponse = 0;
            int result = 0;
            int pumpresult = 0;

            foreach (var tunnel in tunnels)
            {
                Ecolab.Models.Washers.Tunnel.TunnelGeneral tunnelObj = tunnel.TunnelGeneral;
                TunnelGeneral tunnelGeneral = Mapper.Map<Ecolab.Models.Washers.Tunnel.TunnelGeneral, TunnelGeneral>(tunnelObj);

                Guid myServiceWasherGroupId = tunnelGeneral.MyServiceWasherGroupGuid;
                Guid myServiceWasherId = tunnelGeneral.MyServiceWashersGuid;

                Log.Info("Save Tunnel General in My Service");
                try
                {
                    response = TunnelWasherAccess.SaveTunnelGeneralInMyService(tunnelGeneral);
                    serviceItemResponse = TunnelWasherAccess.SaveTunnelGeneralInServiceItem(tunnelGeneral);
                    if (response > 0 || serviceItemResponse > 0)
                    {
                        responseFlag = false;
                    }
                    else
                    {
                        responseFlag = true;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                    responseFlag = false;
                }

                List<Ecolab.Models.Washers.Tunnel.TunnelCompartment> tunnelCompartmentList = tunnel.TunnelCompartments;
                List<TunnelCompartment> tunnelCompartments = Mapper.Map<List<Ecolab.Models.Washers.Tunnel.TunnelCompartment>, List<TunnelCompartment>>(tunnelCompartmentList);

                Log.Info("Save Tunnel Compartment in My Service");
                foreach (var tunnelComp in tunnelCompartments)
                {
                    try
                    {
                        tunnelComp.WashStepId = TunnelWasherAccess.GetMyServiceWashOperationId(tunnelComp.WashStepId, tunnelComp.EcolabAccountNumber);
                        result = TunnelWasherAccess.SaveTunnelCompartment(tunnelComp);
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                        responseFlag = false;
                    }

                    if (tunnelComp.PumpAssociationList.Count > 0)
                    {
                        foreach (var pump in tunnelComp.PumpAssociationList)
                        {
                            pump.MyServiceProdId = TunnelWasherAccess.GetMyServiceProdId(pump.ControllerEquipmentSetupId, tunnelComp.EcolabAccountNumber);
                            pump.MyServiceWasherGuid = myServiceWasherId;
                            pump.EcolabAccountNumber = tunnelComp.EcolabAccountNumber;
                            try
                            {
                                pumpresult = TunnelWasherAccess.SaveTunnelDosingInMyservice(pump, myServiceWasherGroupId, tunnelComp.CompartmentNumber);
                            }
                            catch (Exception ex)
                            {
                                Log.Error("Error in TunnelWasherProcessor : " + ex.ToString());
                                responseFlag = false;
                            }
                        }
                    }
                }

                if (response != 0 || result != 0 || pumpresult != 0)
                {
                    responseFlag = false;
                }
            }
        }

        /// <summary>
        /// to save plant details
        /// </summary>
        /// <param name="plants">The plant details</param>
        public void Save(List<Entities.Plant> plants)
        {
            throw new NotImplementedException();
        }
    }
}
