﻿// -----------------------------------------------------------------------
// <copyright file="ExchangeRatesProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ExchangeRates processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.PlantSetup.Chemical;
    using log4net;

    /// <summary>
    /// ExchangeRatesProcessor class
    /// </summary>
    public class ExchangeRatesProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private int _mUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Exchange Rates details from central
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("Started sync For ExchangeRates");

            Log.Info("Getting ExchangeRates Details from central");

            List<ExchangeRate> exchangeRates = Access.ExchangeRateAccess.GetExchangeRates();

            Log.Info("Fetched ExchangeRates Details from central");

            if (exchangeRates != null && exchangeRates.Count != 0)
            {
                foreach (var plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Ecolab.Models.ExchangeRate> exchangeRateDetails = Mapper.Map<List<ExchangeRate>, List<Ecolab.Models.ExchangeRate>>(exchangeRates);
                        Push.PushMasterData<List<Ecolab.Models.ExchangeRate>>(exchangeRateDetails, plant.EcoalabAccountNumber, _mUserId, (int)TcdAdminMessageTypes.TcdUpdateExchangeRate);
                    }
                    else
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
                    }
                }
            }
        }
    }
}
