﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWasherFormulaProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Tunnel Washer Formula processor class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access.WasherGroup;
    using Access.Washers;
    using Access.Washers.Tunnel;
    using AutoMapper;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Entities;
    using Entities.WasherGroup;
    using Entities.Washers;
    using log4net;
    using Library.Enums;
    using PushHandler;

    using Services.WasherGroup;
    /// <summary>
    /// TunnelWasherFormulaProcessor Class
    /// </summary>
    public class TunnelWasherFormulaProcessor : IProcessor
    {

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;
        /// <summary>
        /// Gets or Sets whether the plant is Disconnected
        /// </summary>
        public bool IsDisconnected { get; set; }

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save ConventionalWasherFormula from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync TunnelProgramSetup for Plant :" + ecolabAccountNumber);
            IsDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "TunnelProgramSetup");
            int washerCount = TunnelGeneralAccess.GetMaxNumberOfRecords(ecolabAccountNumber);
            List<WasherGroup> tunnelWasherGroups = GetConduitTunnelWasherGroups(ecolabAccountNumber);
            DateTime myServiceTime = DateTime.Now.AddYears(-100);
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
            }

            ProcessTunnelFormulaToSaveInConduit(ecolabAccountNumber, tunnelWasherGroups, myServiceTime);

            if (log != null)
                ProcessTunnelFormulaToSaveInMyService(ecolabAccountNumber, tunnelWasherGroups, myServiceTime);

            if (washerCount > 0)
            {
                if (responseFlag)
                {
                    Log.Info("Syncing success in MyService for TunnelWasherGroupFormula of plant : " + ecolabAccountNumber);

                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "TunnelProgramSetup", "Yes");
                    }
                }
                else
                {
                    Log.Info("Syncing fail in MyService for TunnelWasherGroupFormula of plant : " + ecolabAccountNumber);

                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "TunnelProgramSetup", "Fail");
                    }
                }
            }
            else
            {
                MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "TunnelProgramSetup", "Yes");
            }
        }

        /// <summary>
        /// Get Conduit Tunnel WasherGroups
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>List of tunnel washer groups</returns>
        private List<WasherGroup> GetConduitTunnelWasherGroups(string ecolabAccountNumber)
        {
            try
            {
                List<WasherGroup> tunnelWasherGroups = WasherGroupAccess.GetWasherGroupDetails(-1, ecolabAccountNumber, false).Where(t => t.WasherGroupTypeName == "Tunnel").ToList();
                return tunnelWasherGroups;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Processes the tunnel formula to save in conduit.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="tunnelWasherGroups">The tunnel washer groups.</param>
        /// <param name="myServiceTime">My service time.</param>
        private void ProcessTunnelFormulaToSaveInConduit(string ecolabAccountNumber, List<WasherGroup> tunnelWasherGroups, DateTime myServiceTime)
        {
            try
            {
                int response = 0;
                if (tunnelWasherGroups != null && tunnelWasherGroups.Count > 0)
                {
                    foreach (var item in tunnelWasherGroups)
                    {
                        List<Washers> washers = GetConduitWasherDetails(ecolabAccountNumber, item);

                        if (washers.Count > 0)
                        {
                            Log.Info("Getting tunnel formula for washer group :" + item.WasherGroupName + " and plant" + ecolabAccountNumber);
                            List<WasherGroupFormula> tunnelFormulas = GetMyServiceTunnelFormula(ecolabAccountNumber, myServiceTime, item);

                            if (tunnelFormulas != null && tunnelFormulas.Count > 0)
                            {
                                Log.Info("Total no of tunnel formulas from my service:" + tunnelFormulas.Count + "for washer group :" + item.WasherGroupName);
                                Log.Info("Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<List<WasherGroupFormula>>(tunnelFormulas));
                                foreach (WasherGroupFormula tunnelFormula in tunnelFormulas)
                                {
                                    response = SaveTunnelFormulaInConduit(tunnelFormula, tunnelWasherGroups);

                                    if (response != 0)
                                    {
                                        responseFlag = false;
                                    }
                                    else
                                    {
                                        if (tunnelFormula.FormulaTypeCode == "P")
                                        {
                                            Log.Info("Saving proposed formula back to my service");
                                            Log.Info("Purposed Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(tunnelFormula));
                                            TunnelWasherFormulaAccess.UpdateProposedToCurrentFormula(tunnelFormula);
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            Log.Info("Washer is not present with this WasherGroup having ecolabaccountnumber : " + ecolabAccountNumber);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
            }
        }

        /// <summary>
        /// Gets my service tunnel formula.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="myServiceTime">My service time.</param>
        /// <param name="item">The washer group item.</param>
        /// <returns>List&lt;WasherGroupFormula&gt;.</returns>
        private List<WasherGroupFormula> GetMyServiceTunnelFormula(string ecolabAccountNumber, DateTime myServiceTime, WasherGroup item)
        {
            try
            {
                List<WasherGroupFormula> tunnelFormulas = TunnelWasherFormulaAccess.GetWasherGroupFormula(ecolabAccountNumber, myServiceTime, item.MyServiceWasherGroupGuid);
                return tunnelFormulas;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Gets the conduit washer details.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="item">The washer group item.</param>
        /// <returns>List&lt;Washers&gt;.</returns>
        private List<Washers> GetConduitWasherDetails(string ecolabAccountNumber, WasherGroup item)
        {
            try
            {
                List<Washers> washers = WashersAccess.GetWashersDetails(ecolabAccountNumber, item.WasherGroupId);
                return washers;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saves the tunnel formula in conduit.
        /// </summary>
        /// <param name="tunnelFormula">The tunnel formula.</param>
        /// <param name="tunnelWasherGroups">The tunnel washer groups.</param>
        /// <returns>System.Int32. &response</returns>
        private int SaveTunnelFormulaInConduit(WasherGroupFormula tunnelFormula, List<WasherGroup> tunnelWasherGroups)
        {
            int response = 0;            
            if (tunnelFormula != null && tunnelWasherGroups.Where(t => t.MyServiceWasherGroupGuid == tunnelFormula.MyServiceMchGrpGuid).ToList().Count > 0)
            {
                List<TunnelWashStep> tunnelWashSteps = GetMyServiceTunnelWashSteps(tunnelFormula);
                tunnelFormula.WasherGroupId = tunnelWasherGroups.Where(t => t.MyServiceWasherGroupGuid == tunnelFormula.MyServiceMchGrpGuid).FirstOrDefault().WasherGroupId;
                try
                {
                    if (IsDisconnected)
                    {
                        response = WasherGroupFormulaAccess.SaveMyServiceTunnelFormula(tunnelFormula, SystemUserId);
                        if (response != 0)
                        {
                            Log.Info("Formula save fail in conduit for plant : " + tunnelFormula.EcolabAccountNumber + "and Washer Group :" + tunnelFormula.WasherGroupId);
                            Log.Info("Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(tunnelFormula));
                        }
                        else
                        {
                            Log.Info("Getting Wash Steps for this saved Conventional Formula from My Service " + " for formula " + tunnelFormula.MyServiceCustFrmulaMchGrpGUID);
                            if (tunnelWashSteps != null && tunnelWashSteps.Count > 0 && IsDisconnected)
                            {
                                Log.Info("Total no of wash steps :" + tunnelWashSteps.Count);
                                Log.Info("Wash Steps Details : " + MyServiceCommon.SerializeToJsonFromEntity<List<TunnelWashStep>>(tunnelWashSteps));
                                foreach (TunnelWashStep tunnelWashStep in tunnelWashSteps)
                                {
                                    response = SaveTunnelWashStepInConduit(tunnelWashStep, tunnelFormula);
                                }
                            }
                        }
                    }
                    else
                    {
                        if (tunnelFormula.FormulaTypeCode == "P")
                        {
                            Log.Info("Formula is proposed. Create or Update Plant Formula Details.");
                            Services.WasherGroup.WasherGroupFormulaService objwasherGroupFormulaService = new Services.WasherGroup.WasherGroupFormulaService();
                            Log.Info("Plant " + tunnelFormula.EcolabAccountNumber + " is " + "Connected");

                            //Creating TunnelFormula object for sync
                            Ecolab.Models.WasherGroup.TunnelFormulaModel tunnelFormulaModel = new Models.WasherGroup.TunnelFormulaModel();
                            tunnelFormulaModel.tunnelFormula = Mapper.Map<WasherGroupFormula, Ecolab.Models.WasherGroup.WasherGroupFormula>(tunnelFormula);
                            tunnelFormulaModel.tunnelFormula.MaxNumberOfRecords = objwasherGroupFormulaService.GetMaxNumberOfRecordsForTunnelProgram(tunnelFormula.EcolabAccountNumber);
                            tunnelFormulaModel.tunnelFormula.WasherGroupTypeName = "Tunnel";
                            tunnelFormulaModel.tunnelFormula.LastModifiedTime = DateTime.SpecifyKind(tunnelFormulaModel.tunnelFormula.LastModifiedTime, DateTimeKind.Utc);                            
                                                                                    
                            //Getting Products for each tunnel wash step
                            tunnelFormulaModel.tunnelWashStep = new List<Models.WasherGroup.TunnelWashStep>();
                            if (tunnelWashSteps != null && tunnelWashSteps.Count > 0)
                            {
                                foreach (TunnelWashStep tunnelWashStep in tunnelWashSteps)
                                {
                                    tunnelWashStep.ProductsList = GetMyServiceTunnelWashStepProducts(tunnelWashStep);
                                    tunnelFormulaModel.tunnelWashStep.Add(Mapper.Map<TunnelWashStep, Models.WasherGroup.TunnelWashStep>(tunnelWashStep));
                                }
                            }
                            response = Push.PushToLocal<Ecolab.Models.WasherGroup.TunnelFormulaModel>(tunnelFormulaModel, tunnelFormulaModel.tunnelFormula.EcolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdAddTunnelFormulaFromMyService);                                                            
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                    Log.Error("Formulas Details : " + MyServiceCommon.SerializeToJsonFromEntity<WasherGroupFormula>(tunnelFormula));
                    responseFlag = false;
                    return 0;
                }                
            }

            return response;
        }

        /// <summary>
        /// Gets my service tunnel wash steps.
        /// </summary>
        /// <param name="tunnelFormula">The tunnel formula.</param>
        /// <returns>List&lt;TunnelWashStep&gt;.</returns>
        private List<TunnelWashStep> GetMyServiceTunnelWashSteps(WasherGroupFormula tunnelFormula)
        {
            try
            {
                List<TunnelWashStep> tunnelWashSteps = TunnelWasherFormulaAccess.GetTunnelWashSteps(tunnelFormula.MyServiceCustFrmulaMchGrpGUID.Value);
                return tunnelWashSteps;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saves the tunnel wash step in conduit.
        /// </summary>
        /// <param name="tunnelWashStep">The tunnel wash step.</param>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <returns>System.Int32. Response</returns>
        private int SaveTunnelWashStepInConduit(TunnelWashStep tunnelWashStep, WasherGroupFormula washerGroupFormula)
        {
            int response = 0;
            if (tunnelWashStep != null)
            {
                try
                {
                    response = WasherGroupFormulaAccess.SaveMyServiceTunnelWashStep(tunnelWashStep, washerGroupFormula, SystemUserId);
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                    Log.Error("WashStep Details : " + MyServiceCommon.SerializeToJsonFromEntity<TunnelWashStep>(tunnelWashStep));
                    responseFlag = false;
                    return 0;
                }
                if (response != 0)
                {
                    Log.Info("Washstep save fail in conduit.");
                    Log.Info("WashStep Details : " + MyServiceCommon.SerializeToJsonFromEntity<TunnelWashStep>(tunnelWashStep));
                }
                else
                {
                    Log.Info("Getting Products for this saved tunnel Formula Wash Steps from My Service" + " for wash step " + tunnelWashStep.MyServiceCusrFrmulaStpGuid);
                    List<TunnelWashStepProducts> tunnelWashStepProducts = GetMyServiceTunnelWashStepProducts(tunnelWashStep);

                    if (tunnelWashStepProducts != null && tunnelWashStepProducts.Count > 0)
                    {
                        Log.Info("Total no of products :" + tunnelWashStepProducts.Count);
                        Log.Info("Dosing Products Details : " + MyServiceCommon.SerializeToJsonFromEntity<List<TunnelWashStepProducts>>(tunnelWashStepProducts));
                        foreach (TunnelWashStepProducts tunnelWashStepProduct in tunnelWashStepProducts)
                        {
                            response = SaveTunnelWashStepProductsInConduit(tunnelWashStepProduct, tunnelWashStep, washerGroupFormula);
                        }
                    }
                }
            }

            return response;
        }

        /// <summary>
        /// Get MyService Tunnel WashStep Products
        /// </summary>
        /// <param name="tunnelWashStep">The tunnel wash step</param>
        /// <returns>List of tunnel wash step products</returns>
        private List<TunnelWashStepProducts> GetMyServiceTunnelWashStepProducts(TunnelWashStep tunnelWashStep)
        {
            try
            {
                List<TunnelWashStepProducts> tunnelWashStepProducts = TunnelWasherFormulaAccess.GetTunnelWashStepProducts(tunnelWashStep.MyServiceCusrFrmulaStpGuid.Value);
                return tunnelWashStepProducts;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saves the tunnel wash step products in conduit.
        /// </summary>
        /// <param name="tunnelWashStepProduct">The tunnel wash step product.</param>
        /// <param name="tunnelWashStep">The tunnel wash step.</param>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <returns>System.Int32. Response</returns>
        private int SaveTunnelWashStepProductsInConduit(TunnelWashStepProducts tunnelWashStepProduct, TunnelWashStep tunnelWashStep, WasherGroupFormula washerGroupFormula)
        {
            int response = 0;

            if (tunnelWashStepProduct != null)
            {
                try
                {
                    response = WasherGroupFormulaAccess.SaveMyServiceTunnelWashStepProduct(tunnelWashStepProduct, tunnelWashStep, washerGroupFormula, SystemUserId);
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                    Log.Error("Dosing Product Details : " + MyServiceCommon.SerializeToJsonFromEntity<TunnelWashStepProducts>(tunnelWashStepProduct));
                    responseFlag = false;
                    return 0;
                }

                if (response != 0)
                {
                    Log.Info("DosingProduct save fail in conduit.");
                    Log.Info("Dosing Product Details : " + MyServiceCommon.SerializeToJsonFromEntity<TunnelWashStepProducts>(tunnelWashStepProduct));
                }
            }

            return response;
        }

        /// <summary>
        /// Processes the tunnel formula to save in my service.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="tunnelWasherGroups">The tunnel washer groups.</param>
        /// <param name="myServiceTime">My service time.</param>
        private void ProcessTunnelFormulaToSaveInMyService(string ecolabAccountNumber, List<WasherGroup> tunnelWasherGroups, DateTime myServiceTime)
        {
            try
            {
                int response = 0;
                if (tunnelWasherGroups != null && tunnelWasherGroups.Count > 0)
                {
                    foreach (WasherGroup washerGroup in tunnelWasherGroups)
                    {
                        List<WasherGroupFormula> washerGroupFormulas = GetConduitTunnelFormulas(ecolabAccountNumber, myServiceTime, washerGroup);

                        if (washerGroupFormulas != null && washerGroupFormulas.Count > 0)
                        {
                            Log.Info("Total no of formulas :" + washerGroupFormulas.Count);
                            foreach (WasherGroupFormula washerGroupFormula in washerGroupFormulas)
                            {
                                response = SaveWasherGroupFormulaInMyService(washerGroupFormula, washerGroup);

                                if (response != 0)
                                {
                                    responseFlag = false;
                                    if (response == 50124)
                                    {
                                        Log.Error("TunnelFormula : Washer group is not present in myService for which we are trying to save formula." + MyServiceCommon.SerializeToJsonFromEntity<WasherGroup>(washerGroup));
                                        continue;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
            }
        }

        /// <summary>
        /// Gets the conduit tunnel formulas.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="myServiceTime">My service time.</param>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns>List&lt;WasherGroupFormula&gt;.</returns>
        private List<WasherGroupFormula> GetConduitTunnelFormulas(string ecolabAccountNumber, DateTime myServiceTime, WasherGroup washerGroup)
        {
            try
            {
                List<WasherGroupFormula> washerGroupFormulas = WasherGroupFormulaAccess.GetWasherGroupFormula(ecolabAccountNumber, washerGroup.WasherGroupId, 0, true).Where(t => t.LastModifiedTime > myServiceTime).ToList();
                return washerGroupFormulas;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saves the washer group formula in my service.
        /// </summary>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns>System.Int32.</returns>
        private int SaveWasherGroupFormulaInMyService(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
        {
            int response = 0;
            if (washerGroup != null && washerGroupFormula != null)
            {
                Log.Info("TunnelFormula saving in myservice is processed.");
                try
                {
                    response = TunnelWasherFormulaAccess.SaveWasherGroupFormula(washerGroupFormula, washerGroup);
                    if (response == 0)
                    {
                        Entities.Washers.Tunnel.TunnelGeneral myserviceTunnelGeneralDetails = TunnelWasherAccess.GetTunnelGeneralDetails(washerGroup.MyServiceWasherGroupGuid, washerGroup.EcolabAccountNumber, DateTime.Now.AddYears(-100));
                        if (myserviceTunnelGeneralDetails != null)
                        {
                            TunnelWasherFormulaAccess.SaveFormulaMachineRefrenceInMyService(washerGroupFormula, washerGroup, myserviceTunnelGeneralDetails);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                    responseFlag = false;
                    return 0;
                }

                if (response == 0)
                {
                    Log.Info("TunnelFormula save success in myservice.");
                    List<TunnelWashStep> tunnelWashSteps = GetConduitTunnelWashSteps(washerGroupFormula, washerGroup);

                    if (tunnelWashSteps != null && tunnelWashSteps.Count > 0)
                    {
                        Log.Info("Total no of tunnel wash steps :" + tunnelWashSteps.Count);
                        foreach (TunnelWashStep tunnelWashStep in tunnelWashSteps)
                        {
                            response = SaveTunnelFormulaWashStepInMyService(tunnelWashStep, washerGroupFormula, washerGroup);
                        }
                    }
                }
                else
                {
                    Log.Info("TunnelFormula save fail in myservice.");
                }
            }

            return response;
        }

        /// <summary>
        /// Gets the conduit tunnel wash steps.
        /// </summary>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns>List&lt;TunnelWashStep&gt;.</returns>
        private List<TunnelWashStep> GetConduitTunnelWashSteps(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
        {
            try
            {
                List<TunnelWashStep> tunnelWashSteps = WasherGroupFormulaAccess.GetTunnelWashSteps(washerGroupFormula.Id, washerGroup.EcolabAccountNumber, 0, true);
                return tunnelWashSteps;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saves the tunnel formula wash step in my service.
        /// </summary>
        /// <param name="tunnelWashStep">The tunnel wash step.</param>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns>System.Int32.</returns>
        private int SaveTunnelFormulaWashStepInMyService(TunnelWashStep tunnelWashStep, WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
        {
            int response = 0;

            if (tunnelWashStep != null)
            {
                Log.Info("TunnelWashStep saving in myservice is processed.");
                try
                {
                    if (tunnelWashStep.StepTypeId > 0)
                    {
                        response = TunnelWasherFormulaAccess.SaveTunnelFormulaWashStep(tunnelWashStep, washerGroupFormula, washerGroup);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                    responseFlag = false;
                    return 0;
                }

                if (response == 0)
                {
                    Log.Info("TunnelWashStep save success in myservice.");
                    List<TunnelWashStepProducts> tunnelWashStepProducts = GetConduitTunnelProducts(tunnelWashStep, washerGroup);

                    if (tunnelWashStepProducts != null && tunnelWashStepProducts.Count > 0)
                    {
                        Log.Info("Total no of tunnel washstep products :" + tunnelWashStepProducts.Count);
                        Log.Info("TODO: Clarity needed for saving products in myservices");

                        foreach (TunnelWashStepProducts tunnelWashStepProduct in tunnelWashStepProducts)
                        {
                            tunnelWashStepProduct.MyServiceCmpmtDsgDvcguid = TunnelWasherFormulaAccess.GetTunnelCompartmentDosingDeviceGuid(tunnelWashStepProduct.ControllerEquipmentSetupId, tunnelWashStepProduct.EcolabAccountNumber);
                            Log.Info("Dosing Product Details : " + MyServiceCommon.SerializeToJsonFromEntity<TunnelWashStepProducts>(tunnelWashStepProduct));
                            response = SaveTunnelWashStepProductInMyService(tunnelWashStepProduct, tunnelWashStep, washerGroupFormula);
                        }
                    }
                }
                else
                {
                    Log.Info("TunnelWashStep save fail in myservice.");
                }
            }

            return response;
        }

        /// <summary>
        /// Gets the conduit tunnel products.
        /// </summary>
        /// <param name="tunnelWashStep">The tunnel wash step.</param>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns>List&lt;TunnelWashStepProducts&gt;.</returns>
        private List<TunnelWashStepProducts> GetConduitTunnelProducts(TunnelWashStep tunnelWashStep, WasherGroup washerGroup)
        {
            try
            {
                List<TunnelWashStepProducts> tunnelWashStepProducts = WasherGroupFormulaAccess.GetTunnelProductList(tunnelWashStep.CompartmentNumber, washerGroup.EcolabAccountNumber, tunnelWashStep.GroupId, tunnelWashStep.TunnelDosingSetupId).ToList();
                return tunnelWashStepProducts;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Saves the tunnel wash step product in my service.
        /// </summary>
        /// <param name="tunnelWashStepProduct">The tunnel wash step product.</param>
        /// <param name="tunnelWashStep">The tunnel wash step.</param>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <returns>System.Int32. Response</returns>
        private int SaveTunnelWashStepProductInMyService(TunnelWashStepProducts tunnelWashStepProduct, TunnelWashStep tunnelWashStep, WasherGroupFormula washerGroupFormula)
        {
            int response = 0;

            if (tunnelWashStepProduct != null && tunnelWashStepProduct.MyServiceFrmulaStpDsgDvcGUID != null)
            {
                Log.Info("TunnelWashStepProduct saving in myservice is processed.");
                try
                {
                    response = TunnelWasherFormulaAccess.SaveTunnelWashStepProduct(tunnelWashStepProduct, tunnelWashStep, washerGroupFormula);
                }
                catch (Exception ex)
                {
                    Log.Error("Error in TunnelWasherFormulaProcessor : " + ex.ToString());
                    responseFlag = false;
                    return 0;
                }

                if (response != 0)
                {
                    Log.Info("TunnelWashStepProduct save fail in myservice.");
                }
                else
                {
                    Log.Info("TunnelWashStepProduct save success in myservice.");
                }
            }

            return response;
        }
    }
}