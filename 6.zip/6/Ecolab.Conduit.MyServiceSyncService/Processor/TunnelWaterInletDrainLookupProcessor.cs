﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWaterInletDrainLookupProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelWaterInletDrainLookup Processor  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access.Washers.Tunnel;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.Washers.Tunnel;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;

    /// <summary>
    /// TunnelWaterInletDrainLookupProcessor
    /// </summary>
    public class TunnelWaterInletDrainLookupProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///     Save Washer Model Size details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///     Save
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            this.Log.Info("Started sync For TunnelWaterInletDrainLookup");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "TunnelWaterInletDrainLookup");

            DateTime myServiceTime;
            if (log != null)
            {
                this.Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<PressExtractor> myserviceTunnelWaterInletDrainLookupDetails =
                this.GetMyServiceTunnelWaterInletDrainLookupDetails(myServiceTime);

            this.ProcessMyServiceData(plants, log, myserviceTunnelWaterInletDrainLookupDetails);
        }

        /// <summary>
        ///     To save data in Local as well as in central
        /// </summary>
        /// <param name="plants">list of plants.</param>
        /// <param name="log">log</param>
        /// <param name="myserviceTunnelWaterInletDrainLookupDetails">list of myservice data to be save in central and local</param>
        public void ProcessMyServiceData(List<Plant> plants, MyServiceSyncLog log,
            List<PressExtractor> myserviceTunnelWaterInletDrainLookupDetails)
        {
            if (myserviceTunnelWaterInletDrainLookupDetails != null && myserviceTunnelWaterInletDrainLookupDetails.Count > 0)
            {
                int response = 0;
                this.Log.Info("Insert Or Update TunnelWaterInletDrainLookup data into Central");
                Log.Info("Total TunnelWaterInletDrainLookup :: " + myserviceTunnelWaterInletDrainLookupDetails.Count);
                foreach (PressExtractor tunnelWaterInletDrainDetails in myserviceTunnelWaterInletDrainLookupDetails)
                {
                    Log.Info("TunnelWaterInletDrainLookup Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PressExtractor>(tunnelWaterInletDrainDetails));
                    this.InsertOrUpdateTunnelWaterInletDrainLookupDetails(tunnelWaterInletDrainDetails);
                }
                this.Log.Info("Insert Or Update TunnelWaterInletDrainLookup data into Local Plants");
                foreach (Plant plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.Washers.Tunnel.PressExtractor> objPressExtractor =
                            Mapper.Map<List<PressExtractor>, List<Models.Washers.Tunnel.PressExtractor>>(
                                myserviceTunnelWaterInletDrainLookupDetails);
                        response = Push.PushMasterData(objPressExtractor, plant.EcoalabAccountNumber, this.SystemUserId,
                            (int)TcdAdminMessageTypes.TcdUpdateMyServiceTunnelWaterInletDrainLookup);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "TunnelWaterInletDrainLookup");
                            responseFlag = false;
                        }
                    }
                }
                if (responseFlag)
                {
                    this.Log.Info("Syncing Success for TunnelWaterInletDrainLookup");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "TunnelWaterInletDrainLookup", "Yes");
                }
                else
                {
                    this.Log.Info("Syncing Fail for TunnelWaterInletDrainLookup");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "TunnelWaterInletDrainLookup", "Fail");
                }
            }
            else
            {
                Log.Info("No data fetched from MyService");
            }
        }

        /// <summary>
        ///     Get MyService Tunnel Water Inlet Drain Lookup Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">Last sync time in central</param>
        /// <returns>List of Plant Contact</returns>
        public List<PressExtractor> GetMyServiceTunnelWaterInletDrainLookupDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<PressExtractor> myserviceTunnelWaterInletDrainLookupDetails =
                    TunnelWaterInletDrainLookupAccess.GetTunnelWaterInletDrainLookupDetails(lastSyncTimeInCentral);
                return myserviceTunnelWaterInletDrainLookupDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWaterInletDrainLookupProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        ///     Insert or Update Washer Model Size in Central
        /// </summary>
        /// <param name="tunnelWaterInletDrainDetails">Washer Model Size from MyService</param>
        public void InsertOrUpdateTunnelWaterInletDrainLookupDetails(PressExtractor tunnelWaterInletDrainDetails)
        {
            try
            {
                tunnelWaterInletDrainDetails.Id =
                    TunnelGeneralAccess.SaveMyServiceTunnelWaterInletDrainLookupDetails(tunnelWaterInletDrainDetails);
                TunnelGeneralAccess.SaveMyServicemyServiceTunnelWaterInletDrainLookupLocaleDetails(tunnelWaterInletDrainDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in TunnelWaterInletDrainLookupProcessor :: " + ex.ToString());
                Log.Error("TunnelWaterInletDrainLookup Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PressExtractor>(tunnelWaterInletDrainDetails));
            }
        }
    }
}