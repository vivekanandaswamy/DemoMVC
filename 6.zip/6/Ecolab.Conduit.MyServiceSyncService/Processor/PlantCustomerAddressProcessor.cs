﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerAddressProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant setup processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    /// <summary>
    /// PlantSetupProcessor class
    /// </summary>
    public class PlantCustomerAddressProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private static readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// Save Plant Setup details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync Plant Customer Address for Plant :" + ecolabAccountNumber);

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "PlantCustomerAddress");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + log.Id + "," + log.EcolabAccountNumber +
                         "," + log.Entity + "," + log.Active + "," + log.Status + "," + log.MyServiceLastSynchTime);
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime, ecolabAccountNumber);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            PlantCustomerAddress myservicePlantAddress = GetMyServicePlantCustAddress(ecolabAccountNumber, myServiceTime);

            Log.Info("Myservice PlantCustomerAddress Data : " + MyServiceCommon.SerializeToJsonFromEntity<PlantCustomerAddress>(myservicePlantAddress));

            ProcessMyServiceObject(ecolabAccountNumber, myservicePlantAddress, log);
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="ecolabAccountNumber">Plant Number</param>
        /// <param name="myservicePlantAddress">MyService Object</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        public void ProcessMyServiceObject(string ecolabAccountNumber, PlantCustomerAddress myservicePlantAddress, MyServiceSyncLog log)
        {
            int response = 0;
            if (myservicePlantAddress != null)
            {
                bool isDisconnected = Common.MyServiceCommon.IsPlantConnected(ecolabAccountNumber);

                try
                {
                    if (isDisconnected)
                    {
                        Log.Info("Insert Or Update PlantCustomerAddress data into Central");
                        Log.Info("Plant " + ecolabAccountNumber + " is " + "DisConnected");
                        InsertOrUpdatePlantAddress(myservicePlantAddress);
                    }
                    else
                    {
                        Log.Info("Insert Or Update PlantCustomerAddress data into local and central");
                        Log.Info("Plant " + ecolabAccountNumber + " is " + "Connected");
                        Ecolab.Models.PlantCustomerAddress plantDetails = Mapper.Map<PlantCustomerAddress, Ecolab.Models.PlantCustomerAddress>(myservicePlantAddress);
                        response = Push.PushToLocal<Ecolab.Models.PlantCustomerAddress>(plantDetails, ecolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServicePlantAddress);
                    }

                    if (response == 0)
                    {
                        Log.Info("Syncing Success for PlantCustomerAddress");
                        if (log != null)
                            MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                        else
                            MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantCustomerAddress", "Yes");
                    }
                    else
                    {
                        Log.Info("Syncing Fail for PlantCustomerAddress");
                        if (log != null)
                            MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                        else
                            MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantCustomerAddress", "Fail");
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in PlantCustomerAddressProcessor :" + ex.ToString());
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantCustomerAddress", "Fail");
                }
            }
        }

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Insert or Update Plant Address in Central
        /// </summary>
        /// <param name="myservicePlantAddress">Plant Address from MyService</param>
        private void InsertOrUpdatePlantAddress(PlantCustomerAddress myservicePlantAddress)
        {
            PlantAccess.SaveMyServicePlantAddress(myservicePlantAddress);
        }

        /// <summary>
        /// Get MyService Plant Address Details
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <returns>Plant Address details object</returns>
        private PlantCustomerAddress GetMyServicePlantCustAddress(string ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            PlantCustomerAddress myservicePlantAddress = PlantCustomerAddressAccess.GetPlantCustomerAddress(ecolabAccountNumber, lastSyncTimeInCentral);
            return myservicePlantAddress;
        }
    }
}
