﻿// -----------------------------------------------------------------------
// <copyright file="ProductCategoryProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The product category processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.PlantSetup.Chemical;
    using log4net;

    /// <summary>
    /// ProductCategoryProcessor class
    /// </summary>    
    public class ProductCategoryProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save product category details from CentralDB
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("ProductCategory: Sync Started");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "ProductCategory");

            DateTime lastSynchTime;
            if (log == null)
            {
                lastSynchTime = DateTime.Now.AddYears(-100);
            }
            else
            {
                lastSynchTime = log.MyServiceLastSynchTime;
            }

            List<ProductMaster> ProductCategoryDetails = GetProductCategoryDetails(lastSynchTime);
            ProductCategoryDetails.Each(t => t.MyServiceLastSynchTime = DateTime.SpecifyKind(t.MyServiceLastSynchTime, DateTimeKind.Utc));

            ProcessMyServiceObject(plants, log, ProductCategoryDetails);
        }

        /// <summary>
        /// Get product category details from CentralDB
        /// </summary>
        /// <param name="lastSynchTime"></param>
        /// <returns></returns>
        private List<ProductMaster> GetProductCategoryDetails(DateTime lastSynchTime)
        {
            try
            {
                List<ProductMaster> productMasterDetails = ProductCategoryAccess.GetProductCategoryDetails(lastSynchTime); ;
                return productMasterDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ProductCategoryProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myserviceProductCategoryDetails">MyService Object</param>
        public void ProcessMyServiceObject(List<Entities.Plant> plants, MyServiceSyncLog log, List<ProductMaster> myserviceProductCategoryDetails)
        {
            if (myserviceProductCategoryDetails != null && myserviceProductCategoryDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Insert Or Update ProductCategory data into Local Plants");
                foreach (var plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Ecolab.Models.PlantSetup.Chemical.ProductMaster> productCategorys = Mapper.Map<List<ProductMaster>, List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>>(myserviceProductCategoryDetails);
                        response = Push.PushMasterData<List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>>(productCategorys, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceProductCategory);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "ProductCategory");
                            responseFlag = false;
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for ProductCategory");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "ProductCategory", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for ProductCategory");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "ProductCategory", "Fail");
                }
            }
        }

        /// <summary>
        /// Insert or Update Product Category in Central
        /// </summary>
        /// <param name="myserviceProductCategory">Product Category from MyService</param>
        public void InsertOrUpdateProductCategoryDetails(ProductMaster myserviceProductCategory)
        {
            try
            {
                myserviceProductCategory.ProductCategoryId = Access.PlantSetup.Chemical.ProductMasterAccess.SaveMyServiceProductCategoryDetails(myserviceProductCategory);
                Access.PlantSetup.Chemical.ProductMasterAccess.SaveMyServiceProductCategoryLocaleDetails(myserviceProductCategory);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in ProductCategoryProcessor :: " + ex.ToString());
                Log.Error("ProductCategory Detail : " + MyServiceCommon.SerializeToJsonFromEntity<ProductMaster>(myserviceProductCategory));
            }
        }

        /// <summary>
        /// Get MyService Product Category Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">Last Sync Time</param>
        /// <returns>List of Product Categories</returns>
        public List<ProductMaster> GetMyServiceProductCategoryDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<ProductMaster> myserviceProductCategoryDetails = ProductCategoryAccess.GetProductCategoryDetails(lastSyncTimeInCentral);
                return myserviceProductCategoryDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ProductCategoryProcessor :: " + ex.ToString());
                return null;
            }
        }

    }
}
