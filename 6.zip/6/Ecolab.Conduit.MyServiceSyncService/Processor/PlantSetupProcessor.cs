﻿// -----------------------------------------------------------------------
// <copyright file="PlantSetupProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The plant setup processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;       
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.Common;
    using Access;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;
    using Nalco.Data.Common;

    /// <summary>
    /// PlantSetupProcessor class
    /// </summary>
    public class PlantSetupProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private static int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(PlantSetupProcessor));

        /// <summary>
        /// Process Plant Creation
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab account number</param>
        /// <returns>Returns response</returns>
        public static bool ProcessPlantCreation(string ecolabAccountNumber)
        {
            bool response = true;
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["PlantCreationInEnvision"]) || Convert.ToBoolean(ConfigurationManager.AppSettings["PlantCreationInConduit"]))
            {
                Log.Info("Getting plant details from myService :: " + ecolabAccountNumber);
                MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "Plant");

                DateTime myServiceTime = DateTime.Now.AddYears(-100);
                if (log != null)
                {
                    Log.Info("Myservice Sync Data : " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                    myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
                }

                List<Plant> plants = PlantSetupAccess.GetPlantList(myServiceTime, ecolabAccountNumber);

                if (plants != null && plants.Count > 0)
                {
                    response = ProcessPlants(plants);

                    if (response)
                    {
                        if (log != null)
                        {
                            MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                        }
                        else
                        {
                            MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "Plant", "Yes");
                        }
                    }
                    else
                    {
                        if (log != null)
                        {
                            MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                        }
                        else
                        {
                            MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "Plant", "Fail");
                        }
                    }
                }
                else
                {
                    Log.Info("Plant is already synced :: " + ecolabAccountNumber);
                }
            }
            else
            {
                Log.Info("Plant Creation is disable for ecolabAccountNumber :: " + ecolabAccountNumber);
            }

            return response;
        }

        /// <summary>
        /// Save plant details in central
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        public void Save(string ecolabAccountNumber)
        {
            try
            {
                if (!Convert.ToBoolean(ConfigurationManager.AppSettings["PlantCreationInConduit"]))
                {
                    Log.Info("Process plant :: " + ecolabAccountNumber);

                    Plant plant = PlantSetupAccess.GetPlantSetupDetails(ecolabAccountNumber, null);
                    bool isPlantExists = PlantSetupAccess.IsPlantExists(plant.EcoalabAccountNumber, false);
                    Log.Info("Getting plant address for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                    PlantCustomerAddress myservicePlantAddress = PlantCustomerAddressAccess.GetPlantCustomerAddress(plant.EcoalabAccountNumber, null);

                    if (plant.PlantChainId > 0)
                    {
                        PlantChain myServicePlantChain = new PlantChain();
                        Log.Info("Getting plant chain for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                        myServicePlantChain = MyServiceAccess.PlantChainAccess.GetPlantChainDetails(plant.PlantChainId);

                        if (myServicePlantChain != null)
                        {
                            Log.Info("Saving plant chain for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                            plant.PlantChainId = Access.PlantChainAccess.SaveMyServicePlantChainDetails(myServicePlantChain);
                        }
                    }

                    if (myservicePlantAddress != null && isPlantExists)
                    {
                        UpdatePlantInCentral(plant);
                        Log.Info("Saving plant address for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                        PlantAccess.SaveMyServicePlantAddress(myservicePlantAddress);
                        Log.Info("Plant updated succesfuly." + plant.EcoalabAccountNumber);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Plant " + ecolabAccountNumber + "is having error to update in PlantSetupProcessor. " + ex.ToString());
            }
        }

        /// <summary>
        /// Process the plants
        /// </summary>
        /// <param name="plants">List of plants</param>
        /// <returns>Success Status or failure</returns>
        private static bool ProcessPlants(List<Plant> plants)
        {
            bool transactionStatus = true;

            foreach (Plant plant in plants)
            {
                GetLanguageIdFromCode(plant);
                Log.Info("myService Plant data : " + MyServiceCommon.SerializeToJsonFromEntity<Plant>(plant));

                Log.Info("Checking " + plant.EcoalabAccountNumber + " plant is exist in conduit or not....");
                bool isPlantExists = PlantSetupAccess.IsPlantExists(plant.EcoalabAccountNumber, false);

                if (Convert.ToBoolean(ConfigurationManager.AppSettings["PlantCreationInEnvision"]))
                {
                    transactionStatus = ProcessPlantCreationInEnvision(transactionStatus, plant, isPlantExists);
                }
                else
                {
                    transactionStatus = ProcessPlantCreationInCentral(transactionStatus, plant, isPlantExists);
                }
            }

            return transactionStatus;
        }

        /// <summary>
        /// Get Language id from conduit
        /// </summary>
        /// <param name="plant">plant object</param>
        private static void GetLanguageIdFromCode(Plant plant)
        {
            plant.LanguageId = PlantSetupAccess.GetLanguageIdFromCode(plant.MyServiceLanguageCode);
        }

        /// <summary>
        /// Process the plant creation in Conduit Central
        /// </summary>
        /// <param name="transactionStatus">transaction Status</param>
        /// <param name="plant">Plant Object</param>
        /// <param name="isPlantExists">Plant is exist or not</param>
        /// <returns>Returns response</returns>
        private static bool ProcessPlantCreationInCentral(bool transactionStatus, Plant plant, bool isPlantExists)
        {
            try
            {
                Log.Info("Getting plant address for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                PlantCustomerAddress myservicePlantAddress = PlantCustomerAddressAccess.GetPlantCustomerAddress(plant.EcoalabAccountNumber, DateTime.Today.AddYears(-100));
              
                plant.DataLiveTime = Convert.ToInt32(ConfigurationManager.AppSettings["DataLiveTime"]);
                plant.ExportPath = ConfigurationManager.AppSettings["ExportPath"];

                if (plant.PlantChainId > 0)
                {
                    PlantChain myServicePlantChain = new PlantChain();
                    Log.Info("Getting plant chain for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                    myServicePlantChain = MyServiceAccess.PlantChainAccess.GetPlantChainDetails(plant.PlantChainId);

                    if (myServicePlantChain != null)
                    {
                        Log.Info("Saving plant chain for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                        plant.PlantChainId = Access.PlantChainAccess.SaveMyServicePlantChainDetails(myServicePlantChain);
                    }
                }

                if (myservicePlantAddress != null)
                {
                    if (isPlantExists)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + "is already exsist in coduit. So update the plant details.");

                        transactionStatus = UpdatePlantInCentral(plant);
                        if (transactionStatus && myservicePlantAddress != null)
                        {
                            Log.Info("Saving plant address for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                            PlantAccess.SaveMyServicePlantAddress(myservicePlantAddress);
                        }
                    }
                    else
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + "is not exsist in coduit. So start the process of plant creation in conduit.");
                        transactionStatus = SavePlantInConduitCentral(plant);
                        if (transactionStatus && myservicePlantAddress != null)
                        {
                            Log.Info("Saving plant address for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                            PlantAccess.SaveMyServicePlantAddress(myservicePlantAddress);
                        }
                    }

                    if (transactionStatus)
                    {
                        Log.Info("Syncing Success for Plant :: " + plant.EcoalabAccountNumber);
                    }
                    else
                    {
                        Log.Info("Syncing Fail for Plant :: " + plant.EcoalabAccountNumber);
                    }
                }
                else
                {
                    Log.Info("Plant Customer Address is not present for plant : " + plant.EcoalabAccountNumber);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Plant " + plant.EcoalabAccountNumber + "is having error to Save in PlantSetupProcessor. " + ex.ToString());

                transactionStatus = false;
            }

            return transactionStatus;
        }

        /// <summary>
        /// save Plant in central
        /// </summary>
        /// <param name="plant">Plant object</param>
        /// <returns>Returns response</returns>
        private static bool SavePlantInConduitCentral(Plant plant)
        {
            try
            {
                int errorCode = 0;
                errorCode = PlantAccess.SaveMyServicePlantDetails(plant, SystemUserId);

                if (errorCode > 0)
                {
                    Log.Info("Error Code : " + errorCode);
                }

                return errorCode > 0 ? false : true;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantSetupProcessor :: " + ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// update Plant Setup details from Myservice
        /// </summary>
        /// <param name="plant">Plant object</param>
        /// <returns>Returns response</returns>
        private static bool UpdatePlantInCentral(Plant plant)
        {
            Log.Info("Getting Plant details from conduit central." + plant.EcoalabAccountNumber);
            Plant conduitPlantDetails = GetConduitPlantDetails(plant.EcoalabAccountNumber);
            Log.Info("conduit Plant data : " + MyServiceCommon.SerializeToJsonFromEntity<Plant>(conduitPlantDetails));
            Log.Info("Merge myService plant data with conduit plant data." + plant.EcoalabAccountNumber);

            if (conduitPlantDetails != null)
            {
                MergeConduitPlantDetailsWithMyService(plant, conduitPlantDetails);
                Log.Info("After merge myService plant data with conduit plant data : " + MyServiceCommon.SerializeToJsonFromEntity<Plant>(conduitPlantDetails));
                Log.Info("Checking plant : " + plant.EcoalabAccountNumber + " is connected or not");
                bool isDisconnected = Common.MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                if (isDisconnected)
                {
                    Log.Info("Plant : " + plant.EcoalabAccountNumber + " is disconnected");
                    return SavePlantInConduitCentral(conduitPlantDetails);
                }
                else
                {
                    Log.Info("Plant : " + plant.EcoalabAccountNumber + " is connected");
                    Ecolab.Models.Plant plantDetails = Mapper.Map<Plant, Ecolab.Models.Plant>(conduitPlantDetails);
                    plantDetails.MaxNumberOfRecords = 1;
                    int errorCode = Push.PushToLocal<Ecolab.Models.Plant>(plantDetails, plantDetails.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServicePlantDetails);

                    if (errorCode > 0)
                    {
                        Log.Info("Error Code : " + errorCode);
                    }

                    return errorCode > 0 ? false : true;
                }
            }

            return false;
        }

        /// <summary>
        /// Process plant creation in envision
        /// </summary>
        /// <param name="transactionStatus">transation status</param>
        /// <param name="plant">The Plant Details </param>
        /// <param name="isPlantExists">plant is exist or not</param>
        /// <returns>Returns response</returns>
        private static bool ProcessPlantCreationInEnvision(bool transactionStatus, Plant plant, bool isPlantExists)
        {
            try
            {
                transactionStatus = DbClient.ExecuteTransaction(delegate(DbTransaction trans, DbContext context)
                {
                    Log.Info("Start process to insert/update plant in enVision." + plant.EcoalabAccountNumber);
                    transactionStatus = SavePlantInEnvision(plant, trans, context);

                    if (transactionStatus)
                    {
                        Log.Info("Savinf Success for Plant :: " + plant.EcoalabAccountNumber + " in Envision");
                    }
                    else
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + "is having error to Save in enVision. ");
                    }

                    return transactionStatus;
                });

                transactionStatus = ProcessPlantCreationInCentral(transactionStatus, plant, isPlantExists);

                if (transactionStatus)
                {
                    Log.Info("Syncing Success for Plant :: " + plant.EcoalabAccountNumber);
                }
                else
                {
                    Log.Info("Syncing Fail for Plant :: " + plant.EcoalabAccountNumber);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Plant " + plant.EcoalabAccountNumber + "is having error to Save in PlantSetupProcessor. " + ex.ToString());
                transactionStatus = false;
            }

            return transactionStatus;
        }

        /// <summary>
        /// Save plant in Envision system
        /// </summary>
        /// <param name="plant">Plant object</param>
        /// <param name="trans">Transaction</param>
        /// <param name="context">Context</param>
        /// <returns>Returns response</returns>
        private static bool SavePlantInEnvision(Plant plant, DbTransaction trans, DbContext context)
        {
            try
            {
                Log.Info("Getting plant address for : " + plant.EcoalabAccountNumber + " from myServiceDB");
                PlantCustomerAddress myservicePlantAddress = PlantCustomerAddressAccess.GetPlantCustomerAddress(plant.EcoalabAccountNumber, DateTime.Today.AddYears(-100));
                int errorCode = 0;
                if (myservicePlantAddress != null)
                {
                    Log.Info("Plant Address data : " + MyServiceCommon.SerializeToJsonFromEntity<PlantCustomerAddress>(myservicePlantAddress));

                    Log.Info("Checking " + plant.EcoalabAccountNumber + " plant is exsist in enVision or not....");
                    bool isPlantExistsInEnvision = PlantSetupAccess.IsPlantExists(plant.EcoalabAccountNumber, true);

                    if (isPlantExistsInEnvision)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + "is already exsist in enVision. So update the plant details.");
                        errorCode = PlantSetupAccess.UpdatePlantInEnvision(plant, myservicePlantAddress, trans, context);
                    }
                    else
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + "is not exsist in enVision. So insert the plant details.");
                        errorCode = PlantSetupAccess.SavePlantInEnvision(plant, myservicePlantAddress, trans, context);
                    }
                }
                else
                {
                    Log.Info("No plant address is found in myService for plant :" + plant.EcoalabAccountNumber + "so we can not insert or update plant in enVision.");
                    errorCode = 1;
                }

                if (errorCode > 0)
                {
                    Log.Info("Error Code : " + errorCode);
                }

                return errorCode > 0 ? false : true;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantSetupProcessor :: " + ex.ToString());
                return false;
            }
        }

        /// <summary>
        /// Merge the conduit plant details with the updated or newly inserted plant details from my servise.
        /// </summary>
        /// <param name="myservicePlantDetails">Plant Details Object from MyService</param>
        /// <param name="conduitPlantDetails">Plant Details Object from Conduit</param>
        private static void MergeConduitPlantDetailsWithMyService(Plant myservicePlantDetails, Plant conduitPlantDetails)
        {
            conduitPlantDetails.EcoalabAccountNumber = myservicePlantDetails.EcoalabAccountNumber;
            conduitPlantDetails.Name = myservicePlantDetails.Name;
            conduitPlantDetails.TmName = myservicePlantDetails.TmName;
            conduitPlantDetails.TmPhoneNumner = myservicePlantDetails.TmPhoneNumner;
            conduitPlantDetails.DmName = myservicePlantDetails.DmName;
            conduitPlantDetails.DmPhoneNumner = myservicePlantDetails.DmPhoneNumner;
            conduitPlantDetails.ChainUnitNumber = myservicePlantDetails.ChainUnitNumber;
            conduitPlantDetails.CensusPriceKg = myservicePlantDetails.CensusPriceKg;
            conduitPlantDetails.Remarks = myservicePlantDetails.Remarks;
            conduitPlantDetails.LanguageId = myservicePlantDetails.LanguageId;
            conduitPlantDetails.CurrencyCode = myservicePlantDetails.CurrencyCode;
            conduitPlantDetails.RegionCode = myservicePlantDetails.RegionCode;
            conduitPlantDetails.UOMDesc = myservicePlantDetails.UOMDesc;
            conduitPlantDetails.PlantChainId = myservicePlantDetails.PlantChainId;
            conduitPlantDetails.IsDelete = myservicePlantDetails.IsDelete;
            conduitPlantDetails.MyServiceCustGuid = myservicePlantDetails.MyServiceCustGuid;
            conduitPlantDetails.PlantContractNumber = myservicePlantDetails.PlantContractNumber;
			conduitPlantDetails.LastServiceVisitDate = myservicePlantDetails.LastServiceVisitDate;
			conduitPlantDetails.NextServiceVisitDate = myservicePlantDetails.NextServiceVisitDate;
            conduitPlantDetails.SourceSystemCode = myservicePlantDetails.SourceSystemCode;
        }

        /// <summary>
        /// Get Conduit Plant Details
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Plant details object</returns>
        private static Plant GetConduitPlantDetails(string ecolabAccountNumber)
        {
            try
            {
                Plant plantDetails = PlantAccess.GetPlantDetails(ecolabAccountNumber);
                return plantDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantSetupProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Save Not implemented
        /// </summary>
        /// <param name="plants">List of plants</param>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }
    }
}