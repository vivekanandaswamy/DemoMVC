﻿// -----------------------------------------------------------------------
// <copyright file="FormulaSegmentsProcessor.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FormulaSegmentsProcessor </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    public class FormulaSegmentsProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        public void Save(List<Plant> plants)
        {
            Log.Info("Started sync For FormulaSegments");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "FormulaSegments");

            DateTime lastSyncTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                //Since we are syncing Central admin to local, no need to convert UTC time to MyService DB timezone.
                lastSyncTime = log.MyServiceLastSynchTime;
            }
            else
            {
                lastSyncTime = DateTime.Now.AddYears(-100);
            }

            List<Ecolab.Models.FormulaSegment> listOfFormulaSegments = this.GetAllFormulaSegments(lastSyncTime);
            this.ProcessFormulaSegemnts(plants, log, listOfFormulaSegments);
        }

        /// <summary>
        ///     Get Central FormulaSegments
        /// </summary>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <returns>List of FormulaSegments object</returns>
        private List<Ecolab.Models.FormulaSegment> GetAllFormulaSegments(DateTime lastSyncTime)
        {
            try
            {
                Log.Info("Getting list of Formula Segment from Central Conduit");
                var formulaSegments = FormulaSegmentAccess.FetchFormulaSegments(lastSyncTime);
                List<Ecolab.Models.FormulaSegment> listOfFormulaSegments =
                    Mapper.Map<List<FormulaSegment>, List<Ecolab.Models.FormulaSegment>>(formulaSegments);
                foreach (Models.FormulaSegment segment in listOfFormulaSegments)
                {
                    segment.LastModified = DateTime.SpecifyKind(segment.LastModified, DateTimeKind.Utc);
                    if (segment.LastSync != null)
                    {
                        segment.LastSync = DateTime.SpecifyKind(segment.LastSync.Value, DateTimeKind.Utc);
                    }
                }
                return listOfFormulaSegments;
            }
            catch (Exception ex)
            {
                Log.Error("Error in Fectching Formula Segment from Central DB :: " + ex.ToString());
                return null;
            }
        }

        public void ProcessFormulaSegemnts(List<Plant> plants, MyServiceSyncLog log, List<Ecolab.Models.FormulaSegment> listOfFormulaSegments)
        {
            if (listOfFormulaSegments != null && listOfFormulaSegments.Count > 0)
            {
                int response = 0;
                Log.Info("Plants to be synced for FormulaSegments:" + MyServiceCommon.SerializeToJsonFromEntity<List<Ecolab.Models.FormulaSegment>>(listOfFormulaSegments));

                foreach (Entities.Plant plant in plants)
                {
                    Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        Log.Info("FormulaSegments send to Push To Master for Plant : " + plant.EcoalabAccountNumber);

                        response = Push.PushMasterData<List<Ecolab.Models.FormulaSegment>>(listOfFormulaSegments, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdFormulaSegment);

                        if (response != 0)
                        {
                            Log.Info("FormulaSegments Master Data: Push To local: Failed for Plant " + plant.EcoalabAccountNumber);
                            responseFlag = false;
                        }
                        else
                        {
                            Log.Info("FormulaSegments Master Data: Push To local: Success for Plant " + plant.EcoalabAccountNumber);
                        }
                    }
                    else
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
                    }
                }
                if (responseFlag)
                {
                    Log.Info("Syncing Success for FormulaSegments");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "FormulaSegments", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for FormulaSegments");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "FormulaSegments", "Fail");
                }
            }
        }
    }
}
