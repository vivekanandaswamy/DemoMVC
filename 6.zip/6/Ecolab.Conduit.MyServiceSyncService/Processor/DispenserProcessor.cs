﻿// -----------------------------------------------------------------------
// <copyright file="DispenserProcessor.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Dispenser Processor </summary>
// ----------------------------------------------------------------------- 

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Entities;
    using log4net;
    using Newtonsoft.Json;
   public class DispenserProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(DispenserProcessor));

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;
        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Dispenser from Central
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync Dispenser for Plant :" + ecolabAccountNumber);

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "Dispensers");
            DateTime myServiceTime = DateTime.UtcNow.AddYears(-100);
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = log.MyServiceLastSynchTime;
            }
            ProcessDispenserToSaveInMyService(ecolabAccountNumber, myServiceTime, log);
        }


        /// <summary>
        /// Processes the dispenser to save in my service.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="myServiceTime">My service time.</param>
        /// <param name="log">The log.</param>
        private void ProcessDispenserToSaveInMyService(string ecolabAccountNumber, DateTime myServiceTime, MyServiceSyncLog log)
        {
            try
            {
                List<Model.Controller> dispensers = DispenserAccess.GetControllerDetails(ecolabAccountNumber, true).Where(t => t.LastModifiedTimeStamp > myServiceTime).ToList();
                if (dispensers != null && dispensers.Count > 0)
                {
                    Log.Info("Total no of Dispensers :" + dispensers.Count);
                    Log.Info("Dispensers Details to save in myService:: " + MyServiceCommon.SerializeToJsonFromEntity<List<Model.Controller>>(dispensers));
                    foreach (Model.Controller dispenserData in dispensers)
                    {
                        SaveDispenserInMyService(dispenserData);
                    }
                }
                else
                {
                    Log.Info("Dispenser Processor: No Controller available to sync to myService for EcolabAccountNumber: " + ecolabAccountNumber);
                }
                if (responseFlag)
                {
                    Log.Info("Syncing success for Dispenser of plant : " + ecolabAccountNumber);

                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "Dispenser", "Yes");
                }
                else
                {
                    Log.Info("Syncing fail for Dispenser of plant : " + ecolabAccountNumber);

                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "Dispenser", "Fail");
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error in DispenserProcessor : " + ex);
            }
        }

        /// <summary>
        /// Save Dispenser Data in MyService
        /// </summary>
        /// <param name="dispenserData"></param>
        /// <returns>return int value</returns>
        private int SaveDispenserInMyService(Model.Controller dispenserData)
        {
            int response = 0;
            int serviceItemResponse = 0;
            if (dispenserData != null)
            {
                try
                {
                    response = DispenserAccess.SaveDispenserData(dispenserData);
                    serviceItemResponse = DispenserAccess.SaveDispenserDataInServiceItem(dispenserData);
                    if (response > 0 || serviceItemResponse > 0)
                    {
                        responseFlag = false;
                    }
                    else
                    {
                        responseFlag = true;
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error in DispenserProcessor : " + ex);
                    Log.Error("Dispenser Details to save in myService:: " + JsonConvert.SerializeObject(dispenserData));
                    responseFlag = false;
                }
            }
            return response;
        }
    }
}
