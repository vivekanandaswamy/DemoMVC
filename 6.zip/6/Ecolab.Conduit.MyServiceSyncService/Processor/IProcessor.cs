﻿// -----------------------------------------------------------------------
// <copyright file="IProcessor.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The IProcessor </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    /// <summary>
    /// Interface IProcessor
    /// </summary>
    public interface IProcessor
    {
        void Save(string ecolabAccountNumber);
       
        void Save(List<Plant> plants);
    }
}
