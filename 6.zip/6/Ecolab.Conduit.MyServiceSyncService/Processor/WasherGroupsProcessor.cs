﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupsProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Washer Groups Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access.WasherGroup;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.WasherGroup;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;

    /// <summary>
    /// WasherGroupsProcessor class
    /// </summary>
    public class WasherGroupsProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Save Washer Groups details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync Washer Groups for Plant :" + ecolabAccountNumber);

            Log.Info("First Insert Plant and Water Energy Device Group for ::" + ecolabAccountNumber + " if not exists.");
            int responce = WasherGroupsAccess.InsertDefaultMachineGroup(ecolabAccountNumber);
            if (responce != 0)
            {
                Log.Info("Plant and Water Energy Device Group for ::" + ecolabAccountNumber + " is exists.");
            }
            else
            {
                Log.Info("Plant and Water Energy Device Group for ::" + ecolabAccountNumber + " inserted.");
            }

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "WasherGroups");

            Log.Info("Getting List For all washer Groups from Central");
            List<WasherGroup> conduitWasherGroupDetails = GetConduitWasherGroupDetails(ecolabAccountNumber);

            DateTime myServiceTime = DateTime.Now.AddYears(-100);

            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = log.MyServiceLastSynchTime;

                Log.Info("Getting List For all washer Groups from Central to be saved in myService");
                List<WasherGroup> washerGroups = GetWasherGroupListToSaveInMyService(conduitWasherGroupDetails, myServiceTime);

                if (washerGroups != null && washerGroups.Count > 0)
                {
                    Log.Info("Washer Group Details ::" + MyServiceCommon.SerializeToJsonFromEntity<List<WasherGroup>>(washerGroups));
                    SaveWasherGroupListInMyService(washerGroups);
                }
            }
            else
            {
                Log.Info("First Time Synch Start");
                SaveInConduitForFirstTimeSynch(myServiceTime, ecolabAccountNumber, conduitWasherGroupDetails);
            }

            if (responseFlag)
            {
                Log.Info("Syncing Success for WasherGroups." + ecolabAccountNumber);
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WasherGroups", "Yes");
            }
            else
            {
                Log.Info("Syncing Fail for WasherGroups." + ecolabAccountNumber);
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "WasherGroups", "Fail");
            }
        }

        private List<WasherGroup> GetConduitWasherGroupDetails(string ecolabAccountNumber)
        {
            try
            {
                List<WasherGroup> conduitWasherGroupDetails = Access.WasherGroup.WasherGroupAccess.GetWasherGroupDetails(-1, ecolabAccountNumber, true);
                return conduitWasherGroupDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in WasherGroupProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Save Washer Groups details to Myservice from Conduit.
        /// </summary>
        /// <param name="washerGroups">washer Group</param>        
        private void SaveWasherGroupListInMyService(List<WasherGroup> washerGroups)
        {
            foreach (var washerGroup in washerGroups)
            {
                try
                {
                    WasherGroupsAccess.SaveWasherGroupInMyService(washerGroup);
                }
                catch (Exception ex)
                {
                    Log.Error("Error in WasherGroupProcessor : " + ex.ToString());
                    Log.Error("Washer Group Details to save in myService ::" + MyServiceCommon.SerializeToJsonFromEntity<WasherGroup>(washerGroup));
                    responseFlag = false;
                }
            }
        }

        /// <summary>
        /// Getting MyServiceWasherGroups to be insert in MyService.
        /// </summary>
        /// <param name="conduitWasherGroupDetails">conduitWasherGroupDetails</param>
        /// <param name="myServiceLastSynchTime">myServiceLastSynchTime</param>
        private List<WasherGroup> GetWasherGroupListToSaveInMyService(List<WasherGroup> conduitWasherGroupDetails, DateTime myServiceLastSynchTime)
        {
            try
            {
                List<WasherGroup> washerGroups = new List<WasherGroup>();

                foreach (var conduitWasherGroup in conduitWasherGroupDetails)
                {
                    if (conduitWasherGroup.LastModifiedTimestamp > myServiceLastSynchTime)
                    {
                        WasherGroup washerGroup = conduitWasherGroup;
                        washerGroups.Add(washerGroup);
                    }
                }

                return washerGroups;
            }
            catch (Exception ex)
            {
                Log.Error("Error in WasherGroupProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Save Washer Groups details from Myservice in Conduit For First Time Synch
        /// </summary>
        /// <param name="myServiceTime">myServiceTime</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        private void SaveInConduitForFirstTimeSynch(DateTime myServiceTime, string ecolabAccountNumber, List<WasherGroup> conduitWasherGroupDetails)
        {
            int response = 0;
            Log.Info("Last Syncing time from myservice in central : " + myServiceTime);

            Log.Info("Getting list of Washer Groups from My Service");
            List<WasherGroup> myserviceWasherGroupDetails = GetMyServiceWasherGroupDetails(myServiceTime, ecolabAccountNumber);

            if (myserviceWasherGroupDetails != null && myserviceWasherGroupDetails.Count > 0)
            {
                Log.Info("Washer Group Details ::" + MyServiceCommon.SerializeToJsonFromEntity<List<WasherGroup>>(myserviceWasherGroupDetails));
                foreach (var item in myserviceWasherGroupDetails)
                {
                    item.WasherGroupNumber = item.MyServiceWasherGroupNumber.ToString();
                }

                List<Ecolab.Models.WasherGroup.WasherGroup> washerGroupList = Mapper.Map<List<Entities.WasherGroup.WasherGroup>, List<Ecolab.Models.WasherGroup.WasherGroup>>(myserviceWasherGroupDetails);

                bool isDisconnected = Common.MyServiceCommon.IsPlantConnected(ecolabAccountNumber);

                foreach (var washerGroup in washerGroupList)
                {
                    if (conduitWasherGroupDetails != null && conduitWasherGroupDetails.Where(t => t.MyServiceWasherGroupGuid == washerGroup.MyServiceWasherGroupGuid).ToList().Count > 0)
                    {
                        washerGroup.WasherGroupId = conduitWasherGroupDetails.Where(t => t.MyServiceWasherGroupGuid == washerGroup.MyServiceWasherGroupGuid).FirstOrDefault().WasherGroupId;
                    }

                    if (isDisconnected)
                    {
                        Log.Info("Insert Or Update Washer Groups data into Conduit Disconnected");

                        WasherGroup objWasherGroup = Mapper.Map<Models.WasherGroup.WasherGroup, WasherGroup>(washerGroup);
                        DateTime lastModifiedTimeStamp = DateTime.UtcNow;
                        SaveWasherGroupInConduit(ecolabAccountNumber, objWasherGroup, lastModifiedTimeStamp);
                    }
                    else
                    {
                        Log.Info("Insert Or Update Washer Groups data into Conduit Connected");
                        washerGroup.MaxNumberOfRecords = WasherGroupAccess.GetMaxNumberOfRecords(ecolabAccountNumber);
                        response = Push.PushToLocal<Ecolab.Models.WasherGroup.WasherGroup>(washerGroup, washerGroup.EcolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceWasherGroup);
                        if (response != 0)
                        {
                            responseFlag = false;
                        }
                    }
                }
            }
        }

        private void SaveWasherGroupInConduit(string ecolabAccountNumber, WasherGroup objWasherGroup, DateTime lastModifiedTimeStamp)
        {
            try
            {
                WasherGroupAccess.SaveWasherGroup(objWasherGroup, SystemUserId, ecolabAccountNumber, out lastModifiedTimeStamp, null, DateTime.UtcNow);
            }
            catch (Exception ex)
            {
                Log.Error("Error in WasherGroupProcessor : " + ex.ToString());
                Log.Error("Washer Group Details ::" + MyServiceCommon.SerializeToJsonFromEntity<WasherGroup>(objWasherGroup));
                responseFlag = false;
            }
        }

        private List<WasherGroup> GetMyServiceWasherGroupDetails(DateTime myServiceTime, string ecolabAccountNumber)
        {
            try
            {
                List<WasherGroup> myserviceWasherGroupDetails = WasherGroupsAccess.GetWasherGroupsDetails(ecolabAccountNumber, myServiceTime);
                return myserviceWasherGroupDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in WasherGroupProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Not Implemented.
        /// </summary>
        public void Save(List<Entities.Plant> plants)
        {
            throw new NotImplementedException();
        }
    }
}