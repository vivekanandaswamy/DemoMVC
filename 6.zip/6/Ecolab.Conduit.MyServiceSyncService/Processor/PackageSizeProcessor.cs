﻿// -----------------------------------------------------------------------
// <copyright file="PackageSizeProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PackageSize processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.PlantSetup.Chemical;
    using log4net;

    /// <summary>
    /// Package size processor class
    /// </summary>
    public class PackageSizeProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>        
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        public void Save(List<Plant> plants)
        {
            Log.Info("Started sync For PackageSize");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "PackageSize");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<PackageSize> myservicePackageSizeDetails = GetMyServicePackageSizeDetails(myServiceTime);

            ProcessMyServiceObject(plants, log, myservicePackageSizeDetails);
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details</param>
        /// <param name="myservicePackageSizeDetails">The myservice package size details.</param>
        private void ProcessMyServiceObject(List<Entities.Plant> plants, MyServiceSyncLog log, List<PackageSize> myservicePackageSizeDetails)
        {
            if (myservicePackageSizeDetails != null && myservicePackageSizeDetails.Count > 0)
            {
                int response = 0;

                Log.Info("Insert Or Update PackageSize data into Central");
                Log.Info("Total Package :: " + myservicePackageSizeDetails.Count);
                foreach (PackageSize item in myservicePackageSizeDetails)
                {
                    Log.Info("PackageSize Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PackageSize>(item));
                    InsertOrUpdatePackageSizeDetails(item);
                }

                Log.Info("Insert Or Update PackageSize data into Local Plants");
                foreach (var plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Ecolab.Models.PackageSize> plantContactPositionDetails = Mapper.Map<List<PackageSize>, List<Ecolab.Models.PackageSize>>(myservicePackageSizeDetails);
                        response = Push.PushMasterData<List<Ecolab.Models.PackageSize>>(plantContactPositionDetails, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServicePackageSize);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "PackageSize");
                            responseFlag = false;
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for PackageSize");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PackageSize", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for PackageSize");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PackageSize", "Fail");
                }
            }
        }

        private List<PackageSize> GetMyServicePackageSizeDetails(DateTime lastSyncTime)
        {
            try
            {
                List<PackageSize> myservicePackageSizeDetails = PackageSizeAccess.GetMyServicePackageSizeDetails(lastSyncTime);
                return myservicePackageSizeDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PackageSizeProcessor :: " + ex.ToString());
                return null;
            }
        }

        private void InsertOrUpdatePackageSizeDetails(Entities.PackageSize myservicePackageSize)
        {
            try
            {
                myservicePackageSize.Id = Access.PackageSizeAccess.SaveMyServicePackageSizeDetails(myservicePackageSize);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in PackageSizeProcessor :: " + ex.ToString());
                Log.Error("PackageSize Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PackageSize>(myservicePackageSize));
            }
        }
    }
}
