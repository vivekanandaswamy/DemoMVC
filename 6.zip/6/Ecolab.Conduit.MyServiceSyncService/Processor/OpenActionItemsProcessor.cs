﻿// -----------------------------------------------------------------------
// <copyright file="OpenActionItemsProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Open Action Items Processor class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    /// <summary>
    /// OpenActionItemsProcessor class
    /// </summary>
    public class OpenActionItemsProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        public void Save(string ecolabAccountNumber)
        {
            Log.Info("Started sync For OpneActionItems");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "OpneActionItems");

            DateTime myServiceTime;

            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<OpenActionItems> myserviceOpenActionItemsDetails = GetMyServiceOpenActionItemsDetails(ecolabAccountNumber, myServiceTime);

            ProcessMyServiceData(ecolabAccountNumber, log, myserviceOpenActionItemsDetails);
        }

        /// <summary>
        /// Not implemented
        /// </summary>
        /// <param name="plants"></param>
        public void Save(List<Entities.Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Gets my service open action items details.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="lastSyncTimeInCentral">The last synchronize time in central.</param>
        /// <returns></returns>
        private List<OpenActionItems> GetMyServiceOpenActionItemsDetails(string ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<OpenActionItems> myserviceOpenActionItemsDetails = Ecolab.Conduit.MyServiceSyncService.MyServiceAccess.OpenActionItemsAccess.GetOpenActionItemsDetails(ecolabAccountNumber, lastSyncTimeInCentral);
                return myserviceOpenActionItemsDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in OpenActionItemsProcessor :: " + ex);
                return null;
            }
        }

        /// <summary>
        /// Processes my service data.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="log">The log.</param>
        /// <param name="myserviceOpenActionItemsDetails">The myservice open action items details.</param>
        private void ProcessMyServiceData(string ecolabAccountNumber, MyServiceSyncLog log, List<OpenActionItems> myserviceOpenActionItemsDetails)
        {
            if (myserviceOpenActionItemsDetails != null && myserviceOpenActionItemsDetails.Count > 0)
            {
                int response = 0;

                Log.Info("Insert Or Update Open Action Items data into Central");
                response = SaveInCentral(myserviceOpenActionItemsDetails);

                if (response < 0)
                {
                    responseFlag = false;
                }

                Log.Info("Insert Or Update Open Action Items data into Local Plant for EcolabAccountNumber: " + ecolabAccountNumber);

                bool isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
                if (!isDisconnected)
                {
                    Log.Info("Plant " + ecolabAccountNumber + " is " + "Connected");

                    List<Models.OpenActionItems> openActionItemDetails =
                        Mapper.Map<List<OpenActionItems>, List<Models.OpenActionItems>>(myserviceOpenActionItemsDetails);
                    response = Push.PushMasterData<List<Models.OpenActionItems>>(openActionItemDetails, ecolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateOpenActionItems);

                    if (response != 0)
                    {
                        responseFlag = false;
                    }
                }
            }
            else
            {
                Log.Info("OpenActionItem Processor: No open action item availble to sync to enVision for EcolabAccountNumber: " + ecolabAccountNumber);
            }
            if (responseFlag)
            {
                Log.Info("Syncing Success in Local Plant: " + ecolabAccountNumber + "for OpenActionItems");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "OpenActionItems", "Yes");
            }
            else
            {
                Log.Info("Syncing Fail in Plant: " + ecolabAccountNumber + "for " + "OpenActionItems");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "OpenActionItems", "Fail");
            }
        }

        private int SaveInCentral(List<OpenActionItems> myserviceOpenActionItemsDetails)
        {
            try
            {
                int response = 0;
                foreach (var openActionItems in myserviceOpenActionItemsDetails)
                {
                    Log.Info("OpenActionItems Detail : " + MyServiceCommon.SerializeToJsonFromEntity<OpenActionItems>(openActionItems));
                    response = Access.OpenActionItemsAccess.SaveMyServiceOpenActionItemsDetails(openActionItems);
                    openActionItems.Id = response;
                }
                return response;
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in OpenActionItemsProcessor :: " + ex);
                return 0;
            }
        }
    }
}