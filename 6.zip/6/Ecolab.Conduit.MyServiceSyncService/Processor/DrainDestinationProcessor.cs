﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The DrainDestination processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access;
    using AutoMapper;
    using Common;
    using Entities;
    using Library.Enums;
    using log4net;
    using PushHandler;

    /// <summary>
    ///     DrainDestinationProcessor class
    /// </summary>
    public class DrainDestinationProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///     Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///     Save Drain Destination details from myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            Log.Info("Started My Service Sync For DrainDestination");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "DrainDestination");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            Log.Info("Getting Drain Destination Details from My Service ");
            List<DrainDestination> myserviceDrainDestinationDetails =
                this.GetMyServiceDrainDestinationDetails(myServiceTime);

            this.ProcessMyServiceObject(plants, log, myserviceDrainDestinationDetails);
        }

        /// <summary>
        ///     process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myserviceDrainDestinationDetails">MyService Object</param>
        public void ProcessMyServiceObject(List<Plant> plants, MyServiceSyncLog log,
            List<DrainDestination> myserviceDrainDestinationDetails)
        {
            if (myserviceDrainDestinationDetails != null && myserviceDrainDestinationDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Looping each Drain Destination to save in Central Conduit");
                Log.Info("Total Drain Destination :: " + myserviceDrainDestinationDetails.Count);
                foreach (DrainDestination item in myserviceDrainDestinationDetails)
                {
                    Log.Info("DrainDestination Detail : " + MyServiceCommon.SerializeToJsonFromEntity<DrainDestination>(item));
                    this.InsertOrUpdateDrainDestinationDetails(item);
                }

                Log.Info("Saving DrainDestination data into Local Plants");
                foreach (Plant plant in plants)
                {
                    Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.DrainDestination> drainDestinations =
                            Mapper.Map<List<DrainDestination>, List<Models.DrainDestination>>(
                                myserviceDrainDestinationDetails);

                        Log.Info("DrainDestination send to Push To Master for Plant : " + plant.EcoalabAccountNumber);
                        response = Push.PushMasterData(drainDestinations, plant.EcoalabAccountNumber, this.SystemUserId,
                            (int)TcdAdminMessageTypes.TcdUpdateMyServiceDrainDestination);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for DrainDestination");
                            responseFlag = false;
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for DrainDestination");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "DrainDestination", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for DrainDestination");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "DrainDestination", "Fail");
                }
            }
        }

        /// <summary>
        ///     Insert or Update DrainDestination Details in Central
        /// </summary>
        /// <param name="myserviceDrainDestinationDetails">DrainDestination from MyService</param>
        private void InsertOrUpdateDrainDestinationDetails(DrainDestination myserviceDrainDestinationDetails)
        {
            try
            {
                Log.Info("Saving Drain Destination into Central Conduit");
                myserviceDrainDestinationDetails.DrainDestinationId =
                    DrainDestinationAccess.SaveMyServiceDrainDestinationDetails(myserviceDrainDestinationDetails);
                DrainDestinationAccess.SaveMyServiceDrainDestinationLocaleDetails(myserviceDrainDestinationDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in DrainDestinationProcessor :: " + ex.ToString());
                Log.Error("DrainDestination Detail : " + MyServiceCommon.SerializeToJsonFromEntity<DrainDestination>(myserviceDrainDestinationDetails));
            }
        }

        /// <summary>
        ///     Get MyService DrainDestination
        /// </summary>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <returns>List of DrainDestination object</returns>
        private List<DrainDestination> GetMyServiceDrainDestinationDetails(DateTime lastSyncTime)
        {
            try
            {
                List<DrainDestination> myserviceDrainDestinationDetails =
                    MyServiceAccess.DrainDestinationAccess.GetDrainDestinationDetails(lastSyncTime);
                return myserviceDrainDestinationDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in DrainDestinationProcessor :: " + ex.ToString());
                return null;
            }
        }
    }
}