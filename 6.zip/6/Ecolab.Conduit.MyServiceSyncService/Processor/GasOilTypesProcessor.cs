﻿// -----------------------------------------------------------------------
// <copyright file="GasOilTypesProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelWaterInletDrainLookup Processor  class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access.PlantSetup;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.PlantSetup;
    using Library.Enums;
    using log4net;
    using Models.PlantSetup;
    using MyServiceAccess;
    using Nalco.Data.Validation.General;
    using PushHandler;

    /// <summary>
    /// GasOilTypesProcessor
    /// </summary>
    public class GasOilTypesProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        public void Save(List<Plant> plants)
        {
            Log.Info("Started sync For GasOilTypes");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "PlantutilityGasoilTypes");
            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }
            List<PlantutilityGasoilTypes> myserviceGasOilTypesDetails = this.GetMyServiceGasoilTypesDetails(myServiceTime);
            this.ProcessMyServiceData(plants, log, myserviceGasOilTypesDetails);
        }

        /// <summary>
        /// GetMyServiceGasOilTypesDetails from Myservice table
        /// </summary>
        /// <param name="lastSyncTimeInCentral">lastSyncTimeInCentral</param>
        /// <returns>list of gas oil types</returns>
        public List<PlantutilityGasoilTypes> GetMyServiceGasoilTypesDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<PlantutilityGasoilTypes> myserviceGasOilTypesDetails =
                    GasOilTypesAccess.GetGasoilTypesDetails(lastSyncTimeInCentral);
                foreach (var gasOilTypes in myserviceGasOilTypesDetails)
                {
                    if (gasOilTypes.UomCode.TrimEnd().Equals("Btu/ccf") && gasOilTypes.GasoilTypeName.Equals("Natural Gas"))
                    {
                        gasOilTypes.Units = "GasConsumption";
                        gasOilTypes.UsageKey = "GasConsumption_NaturalGas";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("Btu/ccf") && gasOilTypes.GasoilTypeName.Equals("Propane"))
                    {
                        gasOilTypes.Units = "GasConsumption";
                        gasOilTypes.UsageKey = "GasConsumption_Propane";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("Btu/gal") && gasOilTypes.GasoilTypeName.Equals("Fuel Oil Heavy"))
                    {
                        gasOilTypes.Units = "FuelConsumption";
                        gasOilTypes.UsageKey = "FuelConsumption_CommonUse";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("Btu/gal") && gasOilTypes.GasoilTypeName.Equals("Fuel Oil Light"))
                    {
                        gasOilTypes.Units = "FuelConsumption";
                        gasOilTypes.UsageKey = "FuelConsumption_CommonUse";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("kWh/m3") && gasOilTypes.GasoilTypeName.Equals("Natural Gas"))
                    {
                        gasOilTypes.Units = "GasConsumption";
                        gasOilTypes.UsageKey = "GasConsumption_NaturalGas";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("kWh/L") && gasOilTypes.GasoilTypeName.Equals("Propane"))
                    {
                        gasOilTypes.Units = "GasConsumption";
                        gasOilTypes.UsageKey = "GasConsumption_Propane";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("kWh/L") && gasOilTypes.GasoilTypeName.Equals("Fuel Oil Heavy"))
                    {
                        gasOilTypes.Units = "FuelConsumption";
                        gasOilTypes.UsageKey = "FuelConsumption_CommonUse";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("kWh/L") && gasOilTypes.GasoilTypeName.Equals("Fuel Oil Light"))
                    {
                        gasOilTypes.Units = "FuelConsumption";
                        gasOilTypes.UsageKey = "FuelConsumption_CommonUse";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("kWh/kg") && gasOilTypes.GasoilTypeName.Equals("Coal Brown"))
                    {
                        gasOilTypes.Units = "FossilConsumption";
                        gasOilTypes.UsageKey = "FossilConsumption_CommonUse";
                    }
                    else if (gasOilTypes.UomCode.TrimEnd().Equals("kWh/kg") && gasOilTypes.GasoilTypeName.Equals("Coal Anthr"))
                    {
                        gasOilTypes.Units = "FossilConsumption";
                        gasOilTypes.UsageKey = "FossilConsumption_CommonUse";
                    }
                }
                return myserviceGasOilTypesDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in GasOilTypesProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// ProcessMyServiceData
        /// </summary>
        /// <param name="plants">list of plants</param>
        /// <param name="log">log object</param>
        /// <param name="myserviceGasoilTypesDetails">myserviceGasOilTypesDetails</param>
        public void ProcessMyServiceData(List<Plant> plants, MyServiceSyncLog log,
            List<PlantutilityGasoilTypes> myserviceGasoilTypesDetails)
        {
            if (myserviceGasoilTypesDetails != null && myserviceGasoilTypesDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Insert Or Update GasOilTypes data into Central");
                foreach (PlantutilityGasoilTypes myserviceGasOilTypes in myserviceGasoilTypesDetails)
                {
                    Log.Info("GasoilType Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PlantutilityGasoilTypes>(myserviceGasOilTypes));
                    this.InsertOrUpdateGasoilTypeDetails(myserviceGasOilTypes);
                }
                Log.Info("Insert Or Update GasOilTypes data into Local Plants");
                foreach (Plant plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<PlantUtilityGasoilTypes> objGasOilTypes =
                            Mapper.Map<List<PlantutilityGasoilTypes>, List<PlantUtilityGasoilTypes>>(
                                myserviceGasoilTypesDetails);
                        response = Push.PushMasterData(objGasOilTypes, plant.EcoalabAccountNumber, this.SystemUserId,
                            (int)TcdAdminMessageTypes.TcdUpdateMyServiceGasOilTypes);
                        if (response != 0)
                        {
                            responseFlag = false;
                        }
                    }
                }
                if (responseFlag)
                {
                    Log.Info("Syncing Success for PlantutilityGasoilTypes");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantutilityGasoilTypes", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for PlantutilityGasoilTypes");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantutilityGasoilTypes", "Fail");
                }
            }
        }

        public void InsertOrUpdateGasoilTypeDetails(
            PlantutilityGasoilTypes myserviceGasoilTypesDetails)
        {
            try
            {
                myserviceGasoilTypesDetails.GasoilTypeId =
                    PlantUtilityGasOilTypeAccess.SaveMyServiceGasoilTypeDetails(myserviceGasoilTypesDetails);
                PlantUtilityGasOilTypeAccess.SaveMyServiceGasoilTypeLocaleDetails(myserviceGasoilTypesDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in GasoilTypesProcessor :: " + ex.ToString());
                Log.Error("GasoilType Detail : " + MyServiceCommon.SerializeToJsonFromEntity<PlantutilityGasoilTypes>(myserviceGasoilTypesDetails));
            }
        }
    }
}