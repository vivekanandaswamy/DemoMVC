﻿// -----------------------------------------------------------------------
// <copyright file="PlantChemicalProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The PlantChemical Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.PlantSetup.Chemical;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using Newtonsoft.Json;
    using PushHandler;

    /// <summary>
    /// PlantChemicalProcessor
    /// </summary>
    public class PlantChemicalProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int userId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///  Save Plant Chemical details from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        public void Save(string ecolabAccountNumber)
        {
            try
            {
                Log.Info("Started sync Plant Chemicals for Plant :" + ecolabAccountNumber);
                MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "PlantChemical");
                DateTime myServiceTime;
                if (log != null)
                {
                    Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                    myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
                }
                else
                {
                    myServiceTime = DateTime.Now.AddYears(-100);
                }
                List<ProductMaster> myservicePlantChemicalDetails = GetMyServicePlantChemicalDetails(ecolabAccountNumber, myServiceTime);
                List<ProductMaster> conduitPlantChemicalDetails = GetConduitPlantChemicalDetails(ecolabAccountNumber);

                List<ProductMaster> plantChemicalsForConduit = GetPlantChemicalListForConduit(myservicePlantChemicalDetails, conduitPlantChemicalDetails);

                SavePlantChemicalDetailsInConduit(ecolabAccountNumber, plantChemicalsForConduit);
                List<ProductMaster> plantChemicalsForMyService = null;

                if (log != null)
                {
                    plantChemicalsForMyService = GetPlantChemicalListForMyService(conduitPlantChemicalDetails, log.MyServiceLastSynchTime);
                    SavePlantChemicalDetailsInMyService(plantChemicalsForMyService);
                }

                if (responseFlag)
                {
                    Log.Info("Syncing success for PlantChemical." + ecolabAccountNumber);
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantChemical", "Yes");
                    }
                }
                else
                {
                    Log.Info("Syncing Fail for PlantChemical." + ecolabAccountNumber);
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantChemical", "Fail");
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error method:Save, in PlantChemicalProcessor : " + ex.ToString());

            }

            SyncProductStandardPrice(ecolabAccountNumber);
        }

        /// <summary>
        /// SavePlantContactDetails In MyService
        /// </summary>
        /// <param name="conduitPlantChemicalsDetails">conduitPlantChemicalsDetails</param>
        public void SavePlantChemicalDetailsInMyService(List<ProductMaster> conduitPlantChemicalsDetails)
        {
            if (conduitPlantChemicalsDetails != null && conduitPlantChemicalsDetails.Count > 0)
            {
                Log.Info("Saving Chemicals in MyService...");
                foreach (var plantChemical in conduitPlantChemicalsDetails)
                {
                    try
                    {
                        PlantChemicalAccess.SavePlantChemicalDetails(plantChemical);
                        responseFlag = true;
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in PlantChemicalProcessor : " + ex.ToString());
                        Log.Error("Plant Chemical Details to save in myService :: " + JsonConvert.SerializeObject(plantChemical));
                        responseFlag = false;
                    }
                }
                Log.Info("Saved Chemicals in MyService...");
            }
        }

        /// <summary>
        /// SavePlantChemicalDetailsInConduit
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>        
        /// <param name="myserviceplantChemicalsDetails">plantChemicals</param>
        public void SavePlantChemicalDetailsInConduit(string ecolabAccountNumber, List<ProductMaster> myserviceplantChemicalsDetails)
        {
            bool isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
            int response = 0;
            if (isDisconnected)
            {
                Log.Info("Plant " + ecolabAccountNumber + " is " + "DisConnected");
            }
            else
            {
                Log.Info("Plant " + ecolabAccountNumber + " is " + "Connected");
            }
            if (myserviceplantChemicalsDetails != null && myserviceplantChemicalsDetails.Count > 0)
            {
                Log.Info("Saving Chemicals in Conduit...");
                foreach (var plantChemical in myserviceplantChemicalsDetails)
                {
                    try
                    {
                        List<ProductMaster> productMaster =
                            Access.PlantSetup.Chemical.ProductMasterAccess.FetchPlantChemicalProductId(plantChemical.MyServiceProdId);
                        foreach (var item in productMaster)
                        {
                            plantChemical.ProductId = item.ProductId;
                            plantChemical.Sku = item.Sku;
                        }
                        if (isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                            Access.PlantSetup.Chemical.ProductMasterAccess.SavePlantChemicalDetails(plantChemical, userId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            Models.PlantSetup.Chemical.ProductMaster plantChemicalDetails = Mapper.Map<ProductMaster, Models.PlantSetup.Chemical.ProductMaster>(plantChemical);
                            plantChemicalDetails.MaxNumberOfRecords = Access.PlantSetup.Chemical.ProductMasterAccess.GetMaxNumberOfRecords(plantChemicalDetails.EcolabAccountNumber);
                            response = Push.PushToLocal<Models.PlantSetup.Chemical.ProductMaster>(plantChemicalDetails, plantChemicalDetails.EcolabAccountNumber, userId, (int)TcdAdminMessageTypes.TcdUpdateMyServicePlantChemical);
                            if (response == 0)
                            {
                                responseFlag = true;
                            }
                            else
                            {
                                responseFlag = false;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in PlantChemicalProcessor in  : " + ex.ToString());
                        Log.Error("Plant Chemical Details :: " + JsonConvert.SerializeObject(plantChemical));
                        responseFlag = false;
                    }
                }
                Log.Info("Saved Chemicals in Conduit...");
            }
        }

        /// <summary>
        /// Get the list of Chemicals that to be saved in Myservice
        /// </summary>
        /// <param name="conduitPlantChemicalDetails">conduitPlantChemicalDetails</param>
        /// <param name="myServiceLastSynchTime">myServiceLastSynchTime</param>
        /// <returns>list of chemicals</returns>
        public List<ProductMaster> GetPlantChemicalListForMyService(List<ProductMaster> conduitPlantChemicalDetails, DateTime myServiceLastSynchTime)
        {
            List<ProductMaster> plantChemicals = new List<ProductMaster>();
            if (conduitPlantChemicalDetails != null)
            {
                plantChemicals = conduitPlantChemicalDetails.Where(t => t.LastModifiedTimestamp > myServiceLastSynchTime).ToList();
            }

            Log.Info("PlantChemicalListForMyService : " + JsonConvert.SerializeObject(plantChemicals));

            return plantChemicals;
        }

        /// <summary>
        /// Get Plant Chemical List For Conduit
        /// </summary>
        /// <param name="myservicePlantChemicalDetails">myservice Plant Chemical Details</param>
        /// <param name="conduitPlantChemicalDetails">conduit Plant Chemical Details</param>
        /// <returns>List of Chemicals to sync</returns>
        public List<ProductMaster> GetPlantChemicalListForConduit(List<ProductMaster> myservicePlantChemicalDetails, List<ProductMaster> conduitPlantChemicalDetails)
        {
            List<ProductMaster> plantChemicals = new List<ProductMaster>();
            if (myservicePlantChemicalDetails != null && myservicePlantChemicalDetails.Count > 0)
            {
                foreach (ProductMaster item in myservicePlantChemicalDetails)
                {
                    ProductMaster chemical =
                        conduitPlantChemicalDetails.FirstOrDefault(t => t.MyServiceProdId == item.MyServiceProdId);

                    if (chemical != null)
                    {
                        if (MyServiceCommon.ConvertMyServiceTimeToUTCTime(item.MyServiceLastSynchTime) > chemical.LastModifiedTimestamp)
                        {
                            MergeMyserviceWithConduit(chemical, item);
                            plantChemicals.Add(chemical);
                        }
                    }
                    else
                    {
                        plantChemicals.Add(item);
                    }
                }
            }
            Log.Info("PlantChemicalListForConduit : " + JsonConvert.SerializeObject(plantChemicals));
            return plantChemicals;
        }

        /// <summary>
        /// Merge object
        /// </summary>
        /// <param name="conduitChemical">Conduit Chemical</param>
        /// <param name="myserviceChemical">Myservice Chemical</param>
        public void MergeMyserviceWithConduit(ProductMaster conduitChemical, ProductMaster myserviceChemical)
        {
            if (conduitChemical != null && myserviceChemical != null)
            {
                conduitChemical.MyServiceProdId = myserviceChemical.MyServiceProdId;
                conduitChemical.Cost = myserviceChemical.Cost;
                conduitChemical.IncludeinCI = myserviceChemical.IncludeinCI;
                conduitChemical.InventoryExpense = myserviceChemical.InventoryExpense;
                conduitChemical.IsDelete = myserviceChemical.IsDelete;
            }
        }

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get plant chemical list from conduit
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account NUmber</param>
        /// <returns>List of chemicals</returns>
        private List<ProductMaster> GetConduitPlantChemicalDetails(string ecolabAccountNumber)
        {
            try
            {
                List<ProductMaster> conduitPlantChemicalDetails = Access.PlantSetup.Chemical.ProductMasterAccess.FetchPlantChemicalListForReSync(ecolabAccountNumber);
                return conduitPlantChemicalDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantChemicalProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Get plant chemical list from myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account NUmber</param>
        /// <param name="myServiceTime">last sync time</param>
        /// <returns>List of chemicals</returns>
        private List<ProductMaster> GetMyServicePlantChemicalDetails(string ecolabAccountNumber, DateTime myServiceTime)
        {
            try
            {
                List<ProductMaster> myservicePlantChemicalDetails = PlantChemicalAccess.GetPlantChemicalDetails(ecolabAccountNumber, myServiceTime);
                return myservicePlantChemicalDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantChemicalProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Sync Product Standard Price from myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account NUmber</param>
        private void SyncProductStandardPrice(string ecolabAccountNumber)
        {
            responseFlag = true;
            try
            {
                Log.Info("Started sync ProductStandardPrice for Plant :" + ecolabAccountNumber);
                MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "ProductStandardPrice");
                DateTime myServiceTime;
                if (log != null)
                {
                    Log.Info("Message fetched for ProductStandardPrice from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                    myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
                }
                else
                {
                    myServiceTime = DateTime.Now.AddYears(-100);
                }

                List<ProductStandardPrice> myserviceProductStandardPrice = GetMyServiceProductStandardPrice(ecolabAccountNumber, myServiceTime);
                List<ProductStandardPrice> conduitProductStandardPrice = GetConduitProductStandardPrice(ecolabAccountNumber);

                List<ProductStandardPrice> productStandardPriceForConduit = GetPlantProductStandarPriceForConduit(myserviceProductStandardPrice, conduitProductStandardPrice);

                SavePlantProductStandartPriceInConduit(ecolabAccountNumber, productStandardPriceForConduit);

                if (responseFlag)
                {
                    Log.Info("Syncing success for ProductStandardPrice." + ecolabAccountNumber);
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ProductStandardPrice", "Yes");
                    }
                }
                else
                {
                    Log.Info("Syncing Fail for ProductStandardPrice." + ecolabAccountNumber);
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ProductStandardPrice", "Fail");
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error method:SyncProductStandardPrice, in PlantChemicalProcessor : " + ex.ToString());
            }
        }
        /// <summary>
        /// Get Product Standard list from myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account NUmber</param>
        /// <param name="myServiceTime">last sync time</param>
        /// <returns>List of Product Standard Price</returns>
        private List<ProductStandardPrice> GetMyServiceProductStandardPrice(string ecolabAccountNumber, DateTime myServiceTime)
        {
            try
            {
                List<ProductStandardPrice> myserviceProductStandardPrice = PlantChemicalAccess.GetPlantProductStandardPrice(ecolabAccountNumber, myServiceTime);
                return myserviceProductStandardPrice;
            }
            catch (Exception ex)
            {
                Log.Error("Error Method:GetMyServiceProductStandardPrice; Class: PlantChemicalProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }
        /// <summary>
        /// Get plant chemical list from conduit
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account NUmber</param>
        /// <returns>List of chemicals</returns>
        private List<ProductStandardPrice> GetConduitProductStandardPrice(string ecolabAccountNumber)
        {
            try
            {
                List<ProductStandardPrice> conduitProductStandardPrice = Access.PlantSetup.Chemical.ProductMasterAccess.FetchPlantProductStandardPriceForReSync(ecolabAccountNumber);
                return conduitProductStandardPrice;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantChemicalProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }
        /// <summary>
        /// Get Plant Chemical List For Conduit
        /// </summary>
        /// <param name="myserviceProductStandardPrice">The myservice product standard price.</param>
        /// <param name="conduitProductStandardPrice">The conduit product standard price.</param>
        /// <returns>
        /// List of Chemicals to sync
        /// </returns>
        public List<ProductStandardPrice> GetPlantProductStandarPriceForConduit(List<ProductStandardPrice> myserviceProductStandardPrice, List<ProductStandardPrice> conduitProductStandardPrice)
        {
            List<ProductStandardPrice> productStandardPrice = new List<ProductStandardPrice>();
            foreach (ProductStandardPrice item in myserviceProductStandardPrice)
            {
                ProductStandardPrice chemical =
                    conduitProductStandardPrice.FirstOrDefault(t => t.ProductId == item.ProductId);

                if (chemical != null)
                {
                    if (MyServiceCommon.ConvertMyServiceTimeToUTCTime(item.MyServiceLastSynchTime) > chemical.LastModifiedTimestamp)
                    {
                        // MergeMyserviceWithConduit(chemical, item);
                        productStandardPrice.Add(item);
                    }
                }
                else
                {
                    productStandardPrice.Add(item);
                }
            }

            Log.Info("PlantProductStandarPriceForConduit : " + JsonConvert.SerializeObject(productStandardPrice));
            return productStandardPrice;
        }

        /// <summary>
        /// SavePlantChemicalDetailsInConduit
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>        
        /// <param name="myserviceplantProductStandartPrice">The myserviceplant product standart price.</param>
        public void SavePlantProductStandartPriceInConduit(string ecolabAccountNumber, List<ProductStandardPrice> myserviceplantProductStandartPrice)
        {
            bool isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
            int response = 0;
            if (isDisconnected)
            {
                Log.Info("Plant " + ecolabAccountNumber + " is " + "DisConnected");
            }
            else
            {
                Log.Info("Plant " + ecolabAccountNumber + " is " + "Connected");
            }

            if (myserviceplantProductStandartPrice != null && myserviceplantProductStandartPrice.Count > 0)
            {
                Log.Info("Saving ProductStandartPrice in Conduit....");
                foreach (var plantProductStandartPrice in myserviceplantProductStandartPrice)
                {
                    try
                    {
                        List<ProductMaster> productMaster =
                            Access.PlantSetup.Chemical.ProductMasterAccess.FetchPlantChemicalProductId(plantProductStandartPrice.ProductId);
                        foreach (var item in productMaster)
                        {
                            plantProductStandartPrice.ProductId = item.ProductId;
                        }
                        if (isDisconnected)
                        {
                            DateTime lastModifiedTimeStamp;
                            Access.PlantSetup.Chemical.ProductMasterAccess.SavePlantProductStandardPrice(plantProductStandartPrice, userId, out lastModifiedTimeStamp);
                        }
                        else
                        {
                            Models.PlantSetup.Chemical.ProductStandardPrice plantProductStandardPrice = Mapper.Map<ProductStandardPrice, Models.PlantSetup.Chemical.ProductStandardPrice>(plantProductStandartPrice);
                            plantProductStandardPrice.MaxNumberOfRecords = Access.PlantSetup.Chemical.ProductMasterAccess.GetMaxNumberOfRecords(plantProductStandardPrice.EcolabAccountNumber);
                            response = Push.PushToLocal<Models.PlantSetup.Chemical.ProductStandardPrice>(plantProductStandardPrice, plantProductStandardPrice.EcolabAccountNumber, userId, (int)TcdAdminMessageTypes.TcdUpdateMyServicePlantProductStandardPrice);
                            if (response == 0)
                            {
                                responseFlag = true;
                            }
                            else
                            {
                                responseFlag = false;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in PlantChemicalProcessor : " + ex.ToString());
                        Log.Error("Plant Chemical Details :: " + JsonConvert.SerializeObject(plantProductStandartPrice));
                        responseFlag = false;
                    }
                }

                Log.Info("Saved ProductStandartPrice in Conduit....");
            }
        }
    }
}