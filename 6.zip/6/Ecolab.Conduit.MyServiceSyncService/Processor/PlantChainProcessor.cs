﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant chain processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access;
    using AutoMapper;
    using Common;
    using Entities;
    using Library.Enums;
    using log4net;
    using PushHandler;

    /// <summary>
    ///     PlantSetupProcessor class
    /// </summary>
    public class PlantChainProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        ///     Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///     To Get the data from myservice.
        /// </summary>
        /// <param name="plants"></param>
        public void Save(List<Plant> plants)
        {
            Log.Info("Started sync For PlantChainDetails");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "PlantChainDetails");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + log.Id + "," + log.EcolabAccountNumber +
                         "," + log.Entity + "," + log.Active + "," + log.Status + "," + log.MyServiceLastSynchTime);
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }
            List<PlantChain> myservicePlantChainDetails = this.GetMyServicePlantChainDetails(myServiceTime);
            Log.Info("PlantChainDetails: Myservice Data : " + MyServiceCommon.SerializeToJsonFromEntity(myservicePlantChainDetails));
            this.ProcessMyServiceData(plants, log, myservicePlantChainDetails);
        }

        /// <summary>
        ///     To save the myService data to central and local.
        /// </summary>
        /// <param name="plants"></param>
        /// <param name="log"></param>
        /// <param name="myservicePlantChainDetails"></param>
        public void ProcessMyServiceData(List<Plant> plants, MyServiceSyncLog log,
            List<PlantChain> myservicePlantChainDetails)
        {
            Log.Info("PlantChainDetails: Processing MyserviceData.");
            if (myservicePlantChainDetails != null && myservicePlantChainDetails.Count > 0)
            {
                int response = 0;
                bool responseFlag = true;
                try
                {
                    Log.Info("Insert Or Update plantChainDetails Central");
                    foreach (PlantChain plantChainDetails in myservicePlantChainDetails)
                    {
                        this.InsertOrUpdatePlantChainDetails(plantChainDetails);
                    }
                    Log.Info("PlantChainDetails: Save to Central: Success");
                    Log.Info("Insert Or Update plantChainDetails into Local Plants");
                    foreach (Plant plant in plants)
                    {
                        bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                        if (!isDisconnected)
                        {
                            Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                            var plantChainDetails =
                                myservicePlantChainDetails.Where(t => t.PlantChainId == plant.PlantChainId).ToList();
                            List<PlantChain> plantChains = new List<PlantChain>();
                            if (plantChainDetails.Count > 0)
                            {
                                PlantChain plantChain = plantChainDetails.FirstOrDefault();
                                plantChains.Add(plantChain);

                                List<Models.PlantChain> plantChainDetailsList = Mapper.Map<List<PlantChain>, List<Models.PlantChain>>(plantChains);

                                response = Push.PushMasterData(plantChainDetailsList, plant.EcoalabAccountNumber, this.SystemUserId,
                               (int)TcdAdminMessageTypes.TcdUpdateMyServicePlantChain);
                                if (response != 0)
                                {
                                    Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " +
                                             "Plant Chain");
                                    responseFlag = false;
                                }
                                else
                                {
                                    Log.Info("Syncing Success in Local Plant: " + plant.EcoalabAccountNumber +
                                             "for Plant Chain");
                                }
                            }
                            else
                            {
                                Log.Info("No PlantChain details for : " + plant.EcoalabAccountNumber);
                            }
                        }
                        else
                        {
                            Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
                        }
                    }

                    if (responseFlag)
                    {
                        Log.Info("Syncing Success for plantChainDetails");
                        if (log != null)
                            MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                        else
                            MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantChainDetails", "Yes");
                    }
                    else
                    {
                        Log.Info("Syncing Fail for plantChainDetails");
                        if (log != null)
                            MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                        else
                            MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantChainDetails", "Fail");
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message + "error in saving plantChainDetails");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantChainDetails", "Fail");
                }
            }
        }

        /// <summary>
        ///     Insert or Update Plant Chain details in Central
        /// </summary>
        /// <param name="plantChain">Product Master from MyService</param>
        private void InsertOrUpdatePlantChainDetails(PlantChain plantChain)
        {
            plantChain.PlantChainId = PlantChainAccess.SaveMyServicePlantChainDetails(plantChain);
        }

        /// <summary>
        ///     Get MyService Plant Chain Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">EcolabAccountNumber</param>
        /// <returns>Plant details object</returns>
        private List<PlantChain> GetMyServicePlantChainDetails(DateTime lastSyncTimeInCentral)
        {
            List<PlantChain> myservicePlantChainDetails =
                MyServiceAccess.PlantChainAccess.GetPlantChains(lastSyncTimeInCentral);
            return myservicePlantChainDetails;
            //List<PlantChain> myservicePlantChainDetails = new List<PlantChain>();
           // return myservicePlantChainDetails;
        }
    }
}