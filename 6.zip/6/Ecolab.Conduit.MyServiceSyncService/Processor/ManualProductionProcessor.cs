﻿// -----------------------------------------------------------------------
// <copyright file="ManualProductionProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Manual Production Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Common;
    using PushHandler;
    using Entities;
    using log4net;
    using MyServiceAccess;
    using Services;
    using Library.Enums;

    /// <summary>
    ///     Plant Formula Processor
    /// </summary>
    public class ManualProductionProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///     save method for saving in conduit
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            bool isDisconnected = Common.MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
            if (!isDisconnected)
            {
                Log.Info("ManualProduction: Sync Started for Manual Production For Plant: " + ecolabAccountNumber);
                MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "ManualProduction");
                DateTime myServiceTime = DateTime.Now.AddYears(-100);
                if (log != null)
                {
                    Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                    myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
                }

                List<MyServiceManualProduction> myserviceManualProductionDetails = GetMyServiceManualProductionDetails(ecolabAccountNumber, myServiceTime);

                ProcessMyServiceObject(myserviceManualProductionDetails, ecolabAccountNumber);

                if (responseFlag)
                {
                    Log.Info("Syncing Success for ManualProduction." + ecolabAccountNumber);
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ManualProduction", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for ManualProduction." + ecolabAccountNumber);
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "ManualProduction", "Fail");
                }
            }
        }

        /// <summary>
        /// Process myservice object details
        /// </summary>
        /// <param name="myserviceManualProductionDetails">Manual Production Details</param>
        /// <param name="ecolabAccountNumber">The Plant Number</param>        
        private void ProcessMyServiceObject(List<MyServiceManualProduction> myserviceManualProductionDetails, string ecolabAccountNumber)
        {
            if (myserviceManualProductionDetails != null && myserviceManualProductionDetails.Count > 0)
            {
                Log.Info("ManualProduction: Insert Or Update Production Details started");
                Log.Info("Total Manual Production :: " + myserviceManualProductionDetails.Count);

                foreach (MyServiceManualProduction manualProduction in myserviceManualProductionDetails)
                {
                    try
                    {
                        Models.MyServiceManualProduction objManualProduction = Mapper.Map<MyServiceManualProduction, Models.MyServiceManualProduction>(manualProduction);
                        objManualProduction.EcolabAccountNumber = ecolabAccountNumber;
                        Push.PushToLocal<Models.MyServiceManualProduction>(objManualProduction, ecolabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceManualProduction);
                    }
                    catch (Exception ex)
                    {
                        responseFlag = false;
                        Log.Error("Error in ManualProductionProcessor for " + ecolabAccountNumber + " :: " + ex.ToString());
                        Log.Error("ManualProduction Detail : " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceManualProduction>(manualProduction));
                    }
                }
                Log.Info("ManualProduction: Insert Or Update Production Details ended.");
            }
        }

        /// <summary>
        /// GetMyServiceManualProductionDetails
        /// </summary>
        /// <param name="ecolabAccountNumber">The Plant Number</param>
        /// <param name="myServiceTime">The myService</param>
        /// <returns>Get the manual production details</returns>
        private List<MyServiceManualProduction> GetMyServiceManualProductionDetails(string ecolabAccountNumber, DateTime myServiceTime)
        {
            List<MyServiceManualProduction> myServiceManualProductionDetails = null;
            try
            {
                myServiceManualProductionDetails = ManualProductionAccess.GetMyServiceManualProductionDetails(ecolabAccountNumber, myServiceTime);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in ManualProductionProcessor for " + ecolabAccountNumber + " :: " + ex.ToString());
            }

            return myServiceManualProductionDetails;
        }

        /// <summary>
        /// Saves the specified plants.
        /// </summary>
        /// <param name="plants">The plants Value.</param>
        /// <exception cref="System.NotImplementedException">Not Implemented Exception.</exception>
        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }
    }
}