﻿// -----------------------------------------------------------------------
// <copyright file="LanguageMasterProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Language Master Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    public class LanguageMasterProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///  Save Alarm Master details from Myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("LanguageMaster: Sync Started");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "LanguageMaster");

            DateTime lastSynchTime;
            if (log == null)
            {
                lastSynchTime = DateTime.Now.AddYears(-100);
            }
            else
            {
                lastSynchTime = log.MyServiceLastSynchTime;
            }

            List<LanguageMaster> languageMasterDetails = GetLanguageMasterDetails(lastSynchTime);
            languageMasterDetails.Each(t => t.LastModifiedTime = DateTime.SpecifyKind(t.LastModifiedTime, DateTimeKind.Utc));

            ProcessCentralObject(plants, log, languageMasterDetails);
        }

        /// <summary>
        /// Get Language Master list from central
        /// </summary>
        /// <param name="lastSynchTime"></param>
        /// <returns></returns>
        private List<LanguageMaster> GetLanguageMasterDetails(DateTime lastSynchTime)
        {
            try
            {
                List<LanguageMaster> languageMasterDetails = LanguageMasterAccess.GetLanguageMasterDetails(lastSynchTime);
                return languageMasterDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in LanguageMasterProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Processing of central language Master Details
        /// </summary>
        /// <param name="plants"> plants from central </param>
        /// <param name="log">log</param>
        /// <param name="languageMasterDetails"> language Master Details to be synched</param>
        private void ProcessCentralObject(List<Plant> plants, MyServiceSyncLog log, List<LanguageMaster> languageMasterDetails)
        {
            Log.Info("Insert Or Update languageMaster data into Local Plants");

            foreach (Plant plant in plants)
            {
                bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                if (!isDisconnected)
                {
                    int response = 0;
                    Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                    List<Models.LanguageMaster> languageMasterData = Mapper.Map<List<LanguageMaster>, List<Models.LanguageMaster>>(languageMasterDetails);

                    response = Push.PushMasterData(languageMasterData, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateLanguageMaster);
                    if (response != 0)
                    {
                        Log.Info("LanguageMaster: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Failed");
                        responseFlag = false;
                    }
                    else
                    {
                        Log.Info("LanguageMaster: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Success");
                    }

                }
            }
            if (responseFlag)
            {

                Log.Info("Syncing Success for LanguageMaster");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "LanguageMaster", "Yes");

            }
            else
            {
                Log.Info("Syncing Fail for LanguageMaster");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "LanguageMaster", "Fail");
            }
        }

        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

    }
}
