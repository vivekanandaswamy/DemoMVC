﻿// -----------------------------------------------------------------------
// <copyright file="DeviceModelProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The DeviceModel processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.PlantSetup;
    using Entities.PlantSetup.Chemical;
    using log4net;

    /// <summary>
    /// DeviceModelProcessor class
    /// </summary>
    public class DeviceModelProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// response flag
        /// </summary>
        private bool ResponseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Device Model details from myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("Started My Service Sync For Entity : DeviceModel");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "DeviceModel");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            Log.Info("Getting list of My Service Device Model Details from My Service");
            List<DeviceModel> myserviceDeviceModelDetails = GetMyServiceDeviceModelDetails(myServiceTime);

            Log.Info("Process started for saving Device Model in COnduit");
            ProcessMyServiceObject(plants, log, myserviceDeviceModelDetails);
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myserviceDeviceModelDetails">MyService Object</param>
        public void ProcessMyServiceObject(List<Entities.Plant> plants, MyServiceSyncLog log, List<DeviceModel> myserviceDeviceModelDetails)
        {
            if (myserviceDeviceModelDetails != null && myserviceDeviceModelDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Looping each Device model to save in Central Conduit");
                Log.Info("Total Device model :: " + myserviceDeviceModelDetails.Count);
                foreach (DeviceModel item in myserviceDeviceModelDetails)
                {
                    Log.Info("DeviceModel Detail : " + MyServiceCommon.SerializeToJsonFromEntity<DeviceModel>(item));
                    InsertOrUpdateDeviceModelDetails(item);
                }

                Log.Info("Saving DeviceModel data into Local Plants");
                foreach (var plant in plants)
                {
                    Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Ecolab.Models.PlantSetup.DeviceModel> deviceModels = Mapper.Map<List<DeviceModel>, List<Ecolab.Models.PlantSetup.DeviceModel>>(myserviceDeviceModelDetails);

                        Log.Info("Device Model send to Push To Master for Plant : " + plant.EcoalabAccountNumber);
                        response = Push.PushMasterData<List<Ecolab.Models.PlantSetup.DeviceModel>>(deviceModels, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceDeviceModel);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for DeviceModel");
                            ResponseFlag = false;
                        }
                    }
                }

                if (ResponseFlag)
                {
                    Log.Info("Syncing Success for DeviceModel");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "DeviceModel", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for DeviceModel");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "DeviceModel", "Fail");
                }
            }
        }

        /// <summary>
        /// Insert or Update DeviceModel Details in Central
        /// </summary>
        /// <param name="myserviceDeviceModelDetails">Device Model from MyService</param>
        public int InsertOrUpdateDeviceModelDetails(DeviceModel myserviceDeviceModelDetails)
        {
            try
            {
                Log.Info("Saving Device Model into Central Conduit");
                myserviceDeviceModelDetails.DeviceModelId = Access.PlantSetup.DeviceModelAccess.SaveMyServiceDeviceModelDetails(myserviceDeviceModelDetails);
                return myserviceDeviceModelDetails.DeviceModelId;
            }
            catch (Exception ex)
            {
                ResponseFlag = false;
                Log.Error("Error in DeviceModelProcessor :: " + ex.ToString());
                Log.Error("DeviceModel Detail : " + MyServiceCommon.SerializeToJsonFromEntity<DeviceModel>(myserviceDeviceModelDetails));
                return 0;
            }
        }

        /// <summary>
        /// Get MyService TunnelWaterFlowType
        /// </summary>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <returns>List of TunnelWaterFlowType object</returns>
        public List<DeviceModel> GetMyServiceDeviceModelDetails(DateTime lastSyncTime)
        {
            try
            {
                List<DeviceModel> myserviceDeviceModelDetails = DeviceModelAccess.GetDeviceModelDetails(lastSyncTime);
                return myserviceDeviceModelDetails; ;
            }
            catch (Exception ex)
            {
                Log.Error("Error in DeviceModelProcessor :: " + ex.ToString());
                return null;
            }
        }
    }
}
