﻿// -----------------------------------------------------------------------
// <copyright file="PlantUserProcessor.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The plant user processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
	using System;
	using System.Collections.Generic;
	using System.Configuration;
	using System.Data.Common;
	using Ecolab.Conduit.MyServiceSyncService.Common;
	using Ecolab.Conduit.MyServiceSyncService.Model;
	using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
	using Entities;
	using Library.Enums;
	using log4net;
	using Models.PlantSetup.UserManagement;
	using Nalco.Data.Common;
	using PushHandler;
	using Services;

	/// <summary>
	/// PlantUserProcessor class
	/// </summary>
	public class PlantUserProcessor : IProcessor
	{
		/// <summary>
		/// Default System UserId
		/// </summary>
		private readonly static int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

		/// <summary>
		/// logger instance
		/// </summary>
		private static readonly ILog Log = LogManager.GetLogger(typeof(PlantUserProcessor));

		/// <summary>
		/// Save plant user in envision table
		/// </summary>
		/// <param name="ecolabAccountNumber">Ecolab Account Number</param>
		public void Save(string ecolabAccountNumber)
		{
			if (Convert.ToBoolean(ConfigurationManager.AppSettings["PlantCreationInEnvision"]))
			{
				bool response = true;
				Log.Info("Getting list of users from myService...");
				MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "EnVisionUserMaster");

				DateTime myServiceTime = DateTime.Now.AddYears(-100);
				if (log != null)
				{
					Log.Info("Myservice Sync Data : " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

					myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
				}

				List<User> users = PlantUserAccess.GetUserList(ecolabAccountNumber, myServiceTime);

				if (users != null && users.Count > 0)
				{
					Log.Info(string.Format("No of users which can access plant {0} is {1}", ecolabAccountNumber, users.Count));
					response = ProcessPlantUser(users, ecolabAccountNumber);
				}
				else
				{
					Log.Info("No users are there to sync with enVision in MyService.");
				}

                try
                {
                    string contractNumber = PlantUserAccess.GetContractNumber(ecolabAccountNumber);

                    if (!string.IsNullOrEmpty(contractNumber))
                    {
                        Log.Info("Contract Number : " + contractNumber);
                        List<User> envisionCustomersList = PlantUserAccess.GetEnvisionCustomersList(contractNumber);

                        if (envisionCustomersList != null && envisionCustomersList.Count > 0)
                        {
                            ProcessEnVisionCustomers(envisionCustomersList, ecolabAccountNumber);
                        }
                    }
                    else
                    {
                        Log.Info("No Contract number is available for plant : " + ecolabAccountNumber);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("Error occurred while processing enVision Customers from HCForms for plant  : " + ecolabAccountNumber, ex);
                }

				if (response)
				{
					Log.Info("Syncing Success for User. :: " + ecolabAccountNumber);
					if (log != null)
						MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
					else
						MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "EnVisionUserMaster", "Yes");
				}
				else
				{
					Log.Info("Syncing Fail for User. :: " + ecolabAccountNumber);
					if (log != null)
						MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
					else
						MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "EnVisionUserMaster", "Fail");
				}
			}
		}

		/// <summary>
		/// ProcessPlantUser
		/// </summary>
		/// <param name="users">the user details</param>
		/// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
		/// <returns>boolean value</returns>
		private static bool ProcessPlantUser(List<User> users, string ecolabAccountNumber)
		{
			bool transactionStatus = true;
			foreach (User user in users)
			{
				if (user != null)
				{
					try
					{
						user.EmailId = MyServiceCommon.GetEmailIdFromActiveDirectory(user.UserLogin);
					}
					catch (Exception ex)
					{
						Log.Error("User email could not be fetched. Domain Name: " + user.UserLogin + ", Error: " + ex);
					}

					Log.Info("myService User data : " + MyServiceCommon.SerializeToJsonFromEntity<User>(user));

                    if (!string.IsNullOrEmpty(user.EmailId))
                     {
                        try
                        {
                            transactionStatus = DbClient.ExecuteTransaction(delegate (DbTransaction trans, DbContext context)
                                {
                                    transactionStatus = SavePlantUserInEnvision(user, ecolabAccountNumber, trans, context);
                                    if (transactionStatus)
                                    {
                                        transactionStatus = SavePlantUserInConduit(user, ecolabAccountNumber);
                                    }

                                    return transactionStatus;
                                });
                        }
                        catch (Exception ex)
                        {
                            transactionStatus = false;
                            Log.Error("Plant User creation fail in PlantUserProcessor for Plant " + ecolabAccountNumber + "error : " + ex.Message);
                            Log.Error("User Data : " + MyServiceCommon.SerializeToJsonFromEntity<User>(user));
                        }
                    }
                    else
                    {
                        Log.Info("User Data : " + MyServiceCommon.SerializeToJsonFromEntity<User>(user));
                        Log.Info("Invalid EmailId for the User.");
                        return false;
                    }
				}
			}
			return transactionStatus;
		}

		/// <summary>
		/// Saves the plant user in conduit.
		/// </summary>
		/// <param name="user">The user.</param>
		/// <param name="ecolabAccountNumber">The ecolab account number.</param>
		/// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
		private static bool SavePlantUserInConduit(User user, string ecolabAccountNumber)
		{
            Log.Info("Save UserDetails in Conduit for Plant" + ecolabAccountNumber);
			UserManagementService userManagementService = new UserManagementService();
			DateTime lastModifiedTimeStamp;
			int userMasterId;
			int errorCode = 0;
			UserManagement userDetails = new UserManagement();
			if (user.ExtendedUserType.Contains("TERR_MNGR"))
			{
				userDetails.EcolabAccountNumber = ecolabAccountNumber;
				userDetails.Email = user.EmailId;
				userDetails.LoginName = user.UserLogin;
				userDetails.ContactNo = user.PhoneNumber;
				userDetails.IsActive = Convert.ToBoolean(user.Status);
				userDetails.FirstName = user.FirstName;
				userDetails.LastName = user.LastName;
				userDetails.Password = "baloce";
				userDetails.LevelId = 2;
				userDetails.MaxNumberOfRecords = userManagementService.GetMaxNumberOfRecords(ecolabAccountNumber);
				Log.Info("User To be Save in Conduit: " + userDetails);

				int status = PlantUserAccess.ValidateUserInConduit(userDetails);
                Log.Info("Validation Successful for Plant" + ecolabAccountNumber + "status : " + status);

                bool isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
				if (isDisconnected)
				{
					Log.Info("Plant : " + ecolabAccountNumber + " is disconnected");
					if (status == 101)
					{
						errorCode = Convert.ToInt32(userManagementService.InsertUserManagement(userDetails, SystemUserId, out lastModifiedTimeStamp, out userMasterId));
					}
					else
					{
						userDetails.UserNumber = status;
						userDetails.LastModifiedTime = PlantUserAccess.FetchLastModifiedTimeAtCental(ecolabAccountNumber, userDetails.UserNumber);
						errorCode = Convert.ToInt32(userManagementService.UpdateUserManagement(userDetails, SystemUserId, out lastModifiedTimeStamp, out userMasterId));
					}
				}
				else
				{
					if (status != 101)
					{
						userDetails.UserNumber = status;
						userDetails.LastModifiedTime = PlantUserAccess.FetchLastModifiedTimeAtCental(ecolabAccountNumber, userDetails.UserNumber);
						userDetails.LastModifiedTime = DateTime.SpecifyKind(userDetails.LastModifiedTime, DateTimeKind.Utc);
					}
					errorCode = Push.PushToLocal(userDetails, ecolabAccountNumber, SystemUserId, status == 101 ? (int)TcdAdminMessageTypes.TcdAddUserManagement : (int)TcdAdminMessageTypes.TcdUpdateUserManagement);
				}
			}
			return errorCode > 0 ? false : true;
		}

		/// <summary>
		/// SavePlantUserInEnvision
		/// </summary>
		/// <param name="user">the user details</param>
		/// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
		/// <param name="trans">transaction</param>
		/// <param name="context">db context.</param>
		/// <returns>success/failure</returns>
		private static bool SavePlantUserInEnvision(User user, string ecolabAccountNumber, DbTransaction trans, DbContext context)
		{
			int errorCode = 0;

			errorCode = PlantUserAccess.SaveUser(user, trans, context);

			if (errorCode > 0)
			{
				Log.Error("Error occured in SavePlantUserInEnvision to Save User in enVision : " + errorCode + " for EcolabAccountNumber " + ecolabAccountNumber);
			}
			else
			{
				errorCode = PlantUserAccess.SaveUserAccess(user.UserLogin, ecolabAccountNumber, trans, context);
				if (errorCode > 0)
				{
					Log.Error("Error occured in SavePlantUserInEnvision to grant Access in enVision : " + errorCode + " for EcolabAccountNumber " + ecolabAccountNumber);
				}
			}

			return errorCode > 0 ? false : true;
		}

        /// <summary>
        /// Processes the en vision customers.
        /// </summary>
        /// <param name="users">The users.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns></returns>
        private static bool ProcessEnVisionCustomers(List<User> users, string ecolabAccountNumber)
        {
            bool transactionStatus = true;
            foreach (User user in users)
            {
                if (user != null)
                {
                    try
                    {
                        if (Convert.ToBoolean(ConfigurationManager.AppSettings["SaveInActiveDirectory"]))
                        {
                            MyServiceCommon.SaveUserInactiveDirectory(user, user.UserLogin);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("User email could not be fetched. Domain Name: " + user.UserLogin + ", Error: " + ex);
                    }

                    Log.Info("HCForms Customer data : " + MyServiceCommon.SerializeToJsonFromEntity<User>(user));

                    try
                    {
                        transactionStatus = DbClient.ExecuteTransaction(delegate (DbTransaction trans, DbContext context)
                        {
                            transactionStatus = SaveHCFormsCustomersInEnvision(user, ecolabAccountNumber, trans, context);
                            return transactionStatus;
                        });
                    }
                    catch (Exception ex)
                    {
                        Log.Error("HCForms Customer creation fail in PlantUserProcessor. " + ex);
                        Log.Error("User Data : " + MyServiceCommon.SerializeToJsonFromEntity<User>(user));
                    }
                }
            }
            return transactionStatus;
        }

        /// <summary>
        /// Saves the hc forms customers in envision.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="trans">The trans.</param>
        /// <param name="context">The context.</param>
        /// <returns></returns>
        private static bool SaveHCFormsCustomersInEnvision(User user, string ecolabAccountNumber, DbTransaction trans, DbContext context)
        {
            int errorCode = 0;
            errorCode = PlantUserAccess.SaveHCFormsCustomers(user, ecolabAccountNumber, trans, context);
			return errorCode > 0 ? false : true;
		}

		/// <summary>
		/// Not implemented
		/// </summary>
		/// <param name="plants"></param>
		public void Save(List<Plant> plants)
		{
			throw new NotImplementedException();
		}
	}
}