﻿// -----------------------------------------------------------------------
// <copyright file="ProductMasterProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The product master processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
	using System.Collections.Generic;
	using System.Configuration;
	using System.Linq;
    using AutoMapper;
	using Ecolab.Conduit.Library.Enums;
	using Ecolab.Conduit.MyServiceSyncService.Common;
	using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
	using Ecolab.Conduit.PushHandler;
	using Entities;
	using Entities.PlantSetup.Chemical;
	using log4net;

	/// <summary>
	/// ProductMasterProcessor class
	/// </summary>
	public class ProductMasterProcessor : IProcessor
	{
		/// <summary>
		/// logger instance
		/// </summary>
		private static readonly ILog Log = LogManager.GetLogger(typeof(ProductMasterProcessor));

		/// <summary>
		/// Default System UserId
		/// </summary>
		private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

		/// <summary>
		/// response flag
		/// </summary>
		private bool responseFlag = true;

		/// <summary>
		/// Not Implemented
		/// </summary>
		/// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
		public void Save(string ecolabAccountNumber)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Save Product Master details from myservice
		/// </summary>
		/// <param name="plants">List of Plants</param>
		public void Save(List<Entities.Plant> plants)
		{
			Log.Info("Started sync For Product Master");

			MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "ProductMaster");

			DateTime myServiceTime;
			if (log != null)
			{
				Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

				myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
			}
			else
			{
				myServiceTime = DateTime.Now.AddYears(-100);
			}

			List<ProductMaster> myserviceProductDetails = GetMyServiceProductDetails(myServiceTime);

			ProcessMyServiceObject(plants, log, myserviceProductDetails);
		}

		/// <summary>
		/// process the myservice object
		/// </summary>
		/// <param name="plants">Plant List</param>
		/// <param name="log">MySeriveSyncLog Details </param>
		/// <param name="myserviceProductMasterDetails">MyService Object</param>
		private void ProcessMyServiceObject(List<Entities.Plant> plants, MyServiceSyncLog log, List<ProductMaster> myserviceProductMasterDetails)
		{
			if (myserviceProductMasterDetails != null && myserviceProductMasterDetails.Count > 0)
			{
				int response = 0;
				Log.Info("Insert Or Update Product Master data into Central");
				Log.Info("Total ProductMaster :: " + myserviceProductMasterDetails.Count);
				List<ProductMaster> prodMasterList = GetProductMasterForSync();
				foreach (var item in myserviceProductMasterDetails)
				{
					var firstOrDefault = prodMasterList.FirstOrDefault(t => t.MyServiceProdId == item.MyServiceProdId);
					item.EnvisionDisplayName = firstOrDefault != null ? firstOrDefault.EnvisionDisplayName : string.Empty;
				}
				foreach (ProductMaster item in myserviceProductMasterDetails)
				{
					Log.Info("ProductMaster Detail : " + MyServiceCommon.SerializeToJsonFromEntity<ProductMaster>(item));
					InsertOrUpdateProductDetails(item);
				}

                DateTime lastSynchTime;
                if (log == null)
                {
                    lastSynchTime = DateTime.Now.AddYears(-100);
                }
                else
                {
                    lastSynchTime = log.MyServiceLastSynchTime;
                }
                List<ProductMaster> centralProductDetails = GetProductDetailsfromCentral(lastSynchTime);

                Log.Info("Insert Or Update Product Master data into Local Plants");

				foreach (var plant in plants)
				{
					bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

					if (!isDisconnected)
					{
						Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
						List<Ecolab.Models.PlantSetup.Chemical.ProductMaster> productDetails =
							Mapper.Map<List<ProductMaster>, List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>>(
                                centralProductDetails);
						Push.PushMasterData<List<Ecolab.Models.PlantSetup.Chemical.ProductMaster>>(productDetails,
							plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceProductMasterDetails);
						if (response != 0)
						{
							Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "ProductMaster");
							responseFlag = false;
						}
					}
				}
				if (responseFlag)
				{
					Log.Info("Syncing Success for ProductMaster");
					if (log != null)
						MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
					else
						MyServiceCommon.UpdateMyServiceSyncLog(null, "ProductMaster", "Yes");
				}
				else
				{
					Log.Info("Syncing Fail for ProductMaster");
					if (log != null)
						MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
					else
						MyServiceCommon.UpdateMyServiceSyncLog(null, "ProductMaster", "Fail");
				}
			}
		}

		/// <summary>
		/// Insert or Update Product Master in Central
		/// </summary>
		/// <param name="myserviceProductDetails">Product Master from MyService</param>
		private void InsertOrUpdateProductDetails(ProductMaster myserviceProductDetails)
		{
			try
			{
				//if (myserviceProductDetails.ProductCategoryId != null)
				//{
				//	myserviceProductDetails.ProductCategoryId = Access.PlantSetup.Chemical.ProductMasterAccess.GetConduitProductCategoryId(myserviceProductDetails.ProductCategoryId);
				//}
				myserviceProductDetails.ProductId = Access.PlantSetup.Chemical.ProductMasterAccess.SaveMyServiceProductMasterDetails(myserviceProductDetails);
				Access.PlantSetup.Chemical.ProductMasterAccess.SaveMyServiceProductMasterLocaleDetails(myserviceProductDetails);
			}
			catch (Exception ex)
			{
				responseFlag = false;
				Log.Error("Error in ProductMasterProcessor :: " + ex.ToString());
				Log.Error("ProductMaster Detail : " + MyServiceCommon.SerializeToJsonFromEntity<ProductMaster>(myserviceProductDetails));
			}
		}

		/// <summary>
		/// Get MyService Product Master
		/// </summary>
		/// <param name="lastSyncTime">Last Sync Time</param>
		/// <returns>List of Product Master object</returns>
		private List<ProductMaster> GetMyServiceProductDetails(DateTime lastSyncTime)
		{
			try
			{
				List<ProductMaster> myserviceProductDetails = ProductMasterAccess.GetProductMasterDetails(lastSyncTime);
				return myserviceProductDetails;
			}
			catch (Exception ex)
			{
				Log.Error("Error in ProductMasterProcessor :: " + ex.ToString());
				return null;
			}
		}

        /// <summary>
        /// Get ProductMaster details from central
        /// </summary>
        /// <param name="lastSyncTime"></param>
        /// <returns></returns>
        private List<ProductMaster> GetProductDetailsfromCentral(DateTime lastSyncTime)
        {
            try
            {
                List<ProductMaster> centralProductDetails = Access.PlantSetup.Chemical.ProductMasterAccess.GetProductMasterDetailsfromCentral(lastSyncTime);
                return centralProductDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in ProductMasterProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Get Product Master for sync
        /// </summary>
        /// <returns>List of Product Master object</returns>
        private List<ProductMaster> GetProductMasterForSync()
		{
			try
			{
				List<ProductMaster> productDetails = ProductMasterAccess.GetProductMasterForSync();
				return productDetails;
			}
			catch (Exception ex)
			{
				Log.Error("Error in ProductMasterProcessor :: " + ex);
				return null;
			}
		}
	}
}
