﻿// -----------------------------------------------------------------------
// <copyright file="FormulaCategoryProcessor.cs" company="Ecolab">
// 2016 Copyright © Ecolab . 
// </copyright>
// <summary>The FormulaCategoryProcessor processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    /// <summary>
    /// FormulaCategoryProcessor class
    /// </summary>
    public class FormulaCategoryProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Chain TextileCategory details from central
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("Started sync For FormulaCategory");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "FormulaCategory");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                //Since we are syncing Central admin to local, no need to convert UTC time to MyService DB timezone.
                myServiceTime = log.MyServiceLastSynchTime; //MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            this.ProcessFormulaCategory(plants, log, myServiceTime);
        }

        /// <summary>
        /// Process Formula category
        /// </summary>
        /// <param name="plants">plants</param>
        /// <param name="log">log</param>
        /// <param name="myServiceDateTime">myServiceDateTime</param>
        public void ProcessFormulaCategory(List<Entities.Plant> plants, MyServiceSyncLog log, DateTime myServiceDateTime)
        {
            int response = 0;
            Log.Info("Getting Region Details from Central Conduit");

            List<RegionMaster> regionMaster = Access.RegionMasterAccess.GetRegionMasterDetails();

            Log.Info("Fetched Region Master Details from central Conduit" + regionMaster);

            foreach (RegionMaster rm in regionMaster)
            {
                List<FormulaCategory> formulaCategories = Access.FormulaCategoryAccess.GetFormulaCategoryByRegionId(rm.RegionId, myServiceDateTime);

                if (formulaCategories != null && formulaCategories.Count > 0)
                {
                    foreach (var plant in plants)
                    {
                        Log.Info("Check Plant" + plant.EcoalabAccountNumber + "is connected or not ");
                        bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                        if (!isDisconnected)
                        {
                            Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                            List<Ecolab.Models.FormulaCategory> formulaCategorys = Mapper.Map<List<FormulaCategory>, List<Ecolab.Models.FormulaCategory>>(formulaCategories);

                            Log.Info("Formula Category send to Push To Master for Plant : " + plant.EcoalabAccountNumber);
                            response = Push.PushMasterData<List<Ecolab.Models.FormulaCategory>>(formulaCategorys, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateFormulaCategory);
                            if (response != 0)
                            {
                                Log.Info("Formula Category: Push To local: Failed for Plant " + plant.EcoalabAccountNumber);
                                responseFlag = false;
                            }
                            else
                            {
                                Log.Info("Formula Category: Push To local: Success for Plant " + plant.EcoalabAccountNumber);
                            }
                        }
                        else
                        {
                            Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
                        }
                    }
                }
                else
                {
                    Log.Info("Formula Category: Region Master is not match from Central to local, Region Id:" + rm.RegionId);
                }

            }
            if (responseFlag)
            {
                Log.Info("Syncing Success for Formula Category");
                if (log != null)
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "FormulaCategory", "Yes");
                }

            }
            else
            {
                Log.Info("Syncing Fail for FormulaCategory");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "FormulaCategory", "Fail");
            }
        }
    }
}
