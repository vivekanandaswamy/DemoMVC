﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PlantFormula Processor  class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Common;
    using Entities;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;
    using Newtonsoft.Json;

    /// <summary>
    ///     Plant Formula Processor
    /// </summary>
    public class PlantFormulaProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///     save method for saving in conduit
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            try
            {
                Log.Info("PlantFormula: Sync Started for Plant Formula For Plant: " + ecolabAccountNumber);
                MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "PlantFormula");
                DateTime myServiceTime;
                myServiceTime = DateTime.Now.AddYears(-100);
                Log.Info("PlantFormula: First Time Synch Start");
                this.SaveInConduitForFirstTimeSynch(myServiceTime, ecolabAccountNumber);
                if (responseFlag)
                {
                    Log.Info("Syncing Success for PlantFormula." + ecolabAccountNumber);
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantFormula", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for PlantFormula." + ecolabAccountNumber);
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantFormula", "Fail");
                }
            }
            catch (Exception ex)
            {
                Log.Error("Failed to save in Conduit for Plant " + ecolabAccountNumber + "with error ::" + ex.ToString());
            }
        }

        public void Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///     SaveInConduitForFirstTimeSynch
        /// </summary>
        /// <param name="myServiceTime">myServiceTime</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        public void SaveInConduitForFirstTimeSynch(DateTime myServiceTime, string ecolabAccountNumber)
        {
            try
            {
                int response = 0;
                bool isDisconnected = MyServiceCommon.IsPlantConnected(ecolabAccountNumber);
                Log.Info("PlantFormula: Last Syncing time from myservice in Conduit: " + myServiceTime);
                Log.Info("PlantFormula: Getting the list of formula for EcolabAccountNumber : " + ecolabAccountNumber);

                List<Formula> formulaList = GetPlantFormulaDetails(ecolabAccountNumber);
                List<Formula> distinctFormulaList = new List<Formula>();
                if (formulaList != null && formulaList.Count > 0)
                {
                    distinctFormulaList = formulaList.GroupBy(a => a.Name).Select(g => g.First()).ToList();
                }
                Log.Info("PlantFormula: Saving in Local for Plant : " + ecolabAccountNumber);
                foreach (Formula formula in distinctFormulaList)
                {
                    Models.Formula formulas = Mapper.Map<Formula, Models.Formula>(formula);
                    if (isDisconnected)
                    {
                        Log.Info("Insert Or Update PlantFormula data into Conduit Disconnected");
                        SaveMyServiceFormulaDetails(formula);
                    }
                    else
                    {
                        Log.Info("Insert Or Update Plant Formulas data into Conduit Connected");
                        formulas.MaxNumberOfRecords = Access.PlantFormulaAccess.GetMaxNumberOfRecords(ecolabAccountNumber);
                        response = Push.PushToLocal(formulas, ecolabAccountNumber, this.SystemUserId,
                            (int)TcdAdminMessageTypes.TcdUpdateMyServicePlantFormula);
                        if (response != 0)
                        {
                            Log.Info("PlantFormula: Sync to Local Plant: " + ecolabAccountNumber + " :Failed");
                            responseFlag = false;
                        }
                        else
                        {
                            Log.Info("PlantFormula: Sync to Local Plant: " + ecolabAccountNumber + " :Success");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Failed to save data in Conduit for Plant :" + ecolabAccountNumber + "with error ::" + ex.ToString());
            }
        }

        private void SaveMyServiceFormulaDetails(Formula formula)
        {
            try
            {
                DateTime lastModifiedTime;
                Access.PlantFormulaAccess.SaveMyServiceFormulaDetails(formula, this.SystemUserId,
                    out lastModifiedTime);
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantFormulaProcessor : " + ex.ToString());
                Log.Error("Plant Formula Details ::" + JsonConvert.SerializeObject(formula));
                responseFlag = false;
            }
        }

        private List<Formula> GetPlantFormulaDetails(string ecolabAccountNumber)
        {
            try
            {
                List<Formula> formulaList = PlantFormulaAccess.GetPlantFormulaDetails(ecolabAccountNumber);
                return formulaList;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantFormulaProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }
    }
}