﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWaterFlowTypeProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelWaterFlowType processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using Entities.PlantSetup.Chemical;
    using log4net;

    /// <summary>
    /// TunnelWaterFlowTypeProcessor class
    /// </summary>
    public class TunnelWaterFlowTypeProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"].ToString());

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Product Master details from myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("Started sync For TunnelWaterFlowType");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "TunnelWaterFlowType");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<TunnelWaterFlowType> myserviceTunnelWaterFlowTypeDetails = GetMyServiceTunnelWaterFlowTypeDetails(myServiceTime);

            ProcessMyServiceObject(plants, log, myserviceTunnelWaterFlowTypeDetails);
        }

        /// <summary>
        /// process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myserviceTunnelWaterFlowTypeDetails">MyService Object</param>
        private void ProcessMyServiceObject(List<Entities.Plant> plants, MyServiceSyncLog log, List<TunnelWaterFlowType> myserviceTunnelWaterFlowTypeDetails)
        {
            if (myserviceTunnelWaterFlowTypeDetails != null && myserviceTunnelWaterFlowTypeDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Insert Or Update TunnelWaterFlowType data into Central");
                Log.Info("Total TunnelWaterFlowType :: " + myserviceTunnelWaterFlowTypeDetails.Count);
                foreach (TunnelWaterFlowType item in myserviceTunnelWaterFlowTypeDetails)
                {
                    Log.Info("TunnelWaterFlowType Detail : " + MyServiceCommon.SerializeToJsonFromEntity<TunnelWaterFlowType>(item));
                    InsertOrUpdateTunnelWaterFlowTypeDetails(item);
                }

                Log.Info("Insert Or Update TunnelWaterFlowType data into Local Plants");
                foreach (var plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Ecolab.Models.TunnelWaterFlowType> tunnelWaterFlowTypes = Mapper.Map<List<TunnelWaterFlowType>, List<Ecolab.Models.TunnelWaterFlowType>>(myserviceTunnelWaterFlowTypeDetails);
                        response = Push.PushMasterData<List<Ecolab.Models.TunnelWaterFlowType>>(tunnelWaterFlowTypes, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceTunnelWaterFlowTypeDetails);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "TunnelWaterFlowType");
                            responseFlag = false;
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for TunnelWaterFlowType");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "TunnelWaterFlowType", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for TunnelWaterFlowType");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "TunnelWaterFlowType", "Fail");
                }
            }
        }

        /// <summary>
        /// Insert or Update TunnelWaterFlowType Details in Central
        /// </summary>
        /// <param name="myserviceTunnelWaterFlowTypeDetails">Product Master from MyService</param>
        private void InsertOrUpdateTunnelWaterFlowTypeDetails(TunnelWaterFlowType myserviceTunnelWaterFlowTypeDetails)
        {
            try
            {
                myserviceTunnelWaterFlowTypeDetails.TunnelWaterFlowTypeID = Access.TunnelWaterFlowTypeAccess.SaveMyServiceTunnelWaterFlowTypeDetails(myserviceTunnelWaterFlowTypeDetails);
                Access.TunnelWaterFlowTypeAccess.SaveMyServiceTunnelWaterFlowTypeLocaleDetails(myserviceTunnelWaterFlowTypeDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in TunnelWaterFlowTypeProcessor :: " + ex.ToString());
                Log.Error("TunnelWaterFlowType Detail : " + MyServiceCommon.SerializeToJsonFromEntity<TunnelWaterFlowType>(myserviceTunnelWaterFlowTypeDetails));
            }
        }

        /// <summary>
        /// Get MyService TunnelWaterFlowType
        /// </summary>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <returns>List of TunnelWaterFlowType object</returns>
        private List<TunnelWaterFlowType> GetMyServiceTunnelWaterFlowTypeDetails(DateTime lastSyncTime)
        {
            try
            {
                List<TunnelWaterFlowType> myserviceTunnelWaterFlowTypeDetails = TunnelWaterFlowTypeAccess.GetTunnelWaterFlowTypeDetails(lastSyncTime);
                return myserviceTunnelWaterFlowTypeDetails; ;
            }
            catch (Exception ex)
            {
                Log.Error("Error in TunnelWaterFlowTypeProcessor :: " + ex.ToString());
                return null;
            }
        }
    }
}
