﻿// -----------------------------------------------------------------------
// <copyright file="WasherWaterLevelReferenceProcessor.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherWaterLevelReferenceProcessor </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Access.WasherGroup;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.WasherGroup;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;
    using Access.Washers.Tunnel;

    public class WasherWaterLevelReferenceProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly ILog _log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// logger instance
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        public void Save(List<Plant> plants)
        {
            this._log.Info("Started sync For WasherWaterLevelReference");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "WasherWaterLevelReference");

            DateTime myServiceTime;
            if (log != null)
            {
                this._log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<WasherWaterLevelReference> myserviceWasherWaterLevelReferenceDetails =
                this.GetMyServiceWasherWaterLevelReferenceDetails(myServiceTime);

            this.ProcessMyServiceData(plants, log, myserviceWasherWaterLevelReferenceDetails);
        }

        public List<WasherWaterLevelReference> GetMyServiceWasherWaterLevelReferenceDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<WasherWaterLevelReference> myserviceWasherWaterLevelReferenceDetails =
                    WasherWaterLevelReferenceAccess.GetWasherWaterLevelReferenceDetails(lastSyncTimeInCentral);
                return myserviceWasherWaterLevelReferenceDetails;
            }
            catch (Exception ex)
            {
                _log.Error("Error in WasherWaterLevelReference :: " + ex.ToString());
                return null;
            }
        }

        public void ProcessMyServiceData(List<Plant> plants, MyServiceSyncLog log,
           List<WasherWaterLevelReference> myserviceWasherWaterLevelReferenceDetails)
        {
            if (myserviceWasherWaterLevelReferenceDetails != null && myserviceWasherWaterLevelReferenceDetails.Count > 0)
            {
                int response = 0;
                this._log.Info("Insert Or Update WasherWaterLevelReference data into Central");
                _log.Info("Total WasherWaterLevelReference :: " + myserviceWasherWaterLevelReferenceDetails.Count);

                foreach (WasherWaterLevelReference washerWaterLevelReferenceDetails in myserviceWasherWaterLevelReferenceDetails)
                {
                    _log.Info("washerWaterLevelReference Detail : " + MyServiceCommon.SerializeToJsonFromEntity<WasherWaterLevelReference>(washerWaterLevelReferenceDetails));
                    this.InsertOrUpdateWasherWaterLevelReferenceDetails(washerWaterLevelReferenceDetails);
                }
                this._log.Info("Insert Or Update WasherWaterLevelReference data into Local Plants");

                foreach (Plant plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        _log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.WasherWaterLevelReference> objWasherWaterReferenceExtractor =
                            Mapper.Map<List<WasherWaterLevelReference>, List<Models.WasherWaterLevelReference>>(
                                myserviceWasherWaterLevelReferenceDetails);

                        response = Push.PushMasterData(objWasherWaterReferenceExtractor, plant.EcoalabAccountNumber, this.SystemUserId,
                            (int)TcdAdminMessageTypes.TcdUpdateMyServiceWasherWaterLevelReference);

                        if (response != 0)
                        {
                            _log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " + "WasherWaterLevelReference");
                            responseFlag = false;
                        }
                    }
                }

                if (responseFlag)
                {
                    this._log.Info("Syncing Success for WasherWaterLevelReference");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "WasherWaterLevelReference", "Yes");
                }
                else
                {
                    this._log.Info("Syncing Fail for WasherWaterLevelReference");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "WasherWaterLevelReference", "Fail");
                }
            }
            else
            {
                _log.Info("No data fetched from MyService");
            }
        }

        public void InsertOrUpdateWasherWaterLevelReferenceDetails(WasherWaterLevelReference WasherWaterLevelReferenceDetails)
        {
            try
            {
                WasherWaterLevelReferenceDetails.Id =
                    TunnelGeneralAccess.SaveMyServiceWasherWaterLevelReferenceDetails(WasherWaterLevelReferenceDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                _log.Error("Error in WasherWaterReferenceProcessesor :: " + ex.ToString());
                _log.Error("WasherWaterReference Detail : " + MyServiceCommon.SerializeToJsonFromEntity<WasherWaterLevelReference>(WasherWaterLevelReferenceDetails));
            }
        }
    }
}
