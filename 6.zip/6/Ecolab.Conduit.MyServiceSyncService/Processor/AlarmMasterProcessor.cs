﻿// -----------------------------------------------------------------------
// <copyright file="AlarmMasterProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>TheAlarm Master Processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using Ecolab.Conduit.Library.Enums;
    using Ecolab.Conduit.MyServiceSyncService.Common;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Conduit.PushHandler;
    using Entities;
    using log4net;

    public class AlarmMasterProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;
       
        /// <summary>
        ///  Save Alarm Master details from Myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            Log.Info("AlarmMaster: Sync Started");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "AlarmMaster");

            DateTime lastSynchTime;
            if (log == null)
            {
                lastSynchTime = DateTime.Now.AddYears(-100);
            }
            else
            {
                lastSynchTime = log.MyServiceLastSynchTime;
            }

            List<AlarmMaster> alarmMasterDetails = GetAlarmMasterDetails(lastSynchTime);

            ProcessCentralObject(plants, log, alarmMasterDetails);
        }

        /// <summary>
        /// Get alarm master list from central
        /// </summary>
        /// <param name="lastSynchTime">last Synch Time from Central to Local</param>
        /// <returns></returns>
        private List<AlarmMaster> GetAlarmMasterDetails(DateTime lastSynchTime)
        {
            try
            {
                List<AlarmMaster> alarmMasterDetails = AlarmMasterAccess.GetAlarmMasterDetails(lastSynchTime);
                return alarmMasterDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in AlarmMasterProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Processing of central alarm list
        /// </summary>
        /// <param name="plants"> plants from central </param>
        /// <param name="log">log</param>
        /// <param name="alarmMasterDetails"> alarm master list to be synched</param>
        private void ProcessCentralObject(List<Plant> plants, MyServiceSyncLog log, List<AlarmMaster> alarmMasterDetails)
        {
            Log.Info("Insert Or Update AlarmMaster data into Local Plants");

            foreach (Plant plant in plants)
            {
                bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                if (!isDisconnected)
                {
                    int response = 0;
                    Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                    List<Models.AlarmMaster> alarmMasterData = Mapper.Map<List<AlarmMaster>, List<Models.AlarmMaster>>(alarmMasterDetails);

                    response = Push.PushMasterData(alarmMasterData, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateAlarmMaster);
                    if (response != 0)
                    {
                        Log.Info("AlarmMaster: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Failed");
                        responseFlag = false;
                    }
                    else
                    {
                        Log.Info("AlarmMaster: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Success");
                    }
                    
                }
            }
            if (responseFlag)
            {
               
                Log.Info("Syncing Success for AlarmMaster");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "AlarmMaster", "Yes");

            }
            else
            {
                Log.Info("Syncing Fail for AlarmMaster");
                if (log != null)
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                else
                    MyServiceCommon.UpdateMyServiceSyncLog(null, "AlarmMaster", "Fail");
            }
        }

        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }
        
    }
}
