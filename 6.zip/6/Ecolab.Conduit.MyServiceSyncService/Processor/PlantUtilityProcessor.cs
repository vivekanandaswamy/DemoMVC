﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant utility processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.PlantSetup;
    using log4net;
    using MyServiceAccess;
    using Services;
    using Services.PlantSetup;

    public class PlantUtilityProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// The default User Identifier 
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// The plant utility factors
        /// </summary>
        private List<PlantUtilityFactorTypes> plantUtility;

        /// <summary>
        /// mResponse Flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        /// Save MyService Sync Log Details
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(ecolabAccountNumber, "PlantUtility");

            DateTime myServiceTime = DateTime.Now.AddYears(-100);

            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));
                this.ProcessMyServiceSync(ecolabAccountNumber, log);
            }
            else
            {
                Log.Info("Last Syncing time from myservice in central : " + myServiceTime);
                ProcessSync(ecolabAccountNumber, log, myServiceTime);
            }
        }

        /// <summary>
        /// Save Not Implemented
        /// </summary>
        /// <param name="plants">Plant Details</param>
        void IProcessor.Save(List<Plant> plants)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get Water Type Details
        /// </summary>
        /// <param name="plantUtilityFactorTypes">plant Utility Factor Types</param>
        /// <param name="myServiceTime">myService Time</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        private void GetWaterTypeDetails(List<PlantUtilityFactorTypes> plantUtilityFactorTypes, DateTime myServiceTime, string ecolabAccountNumber)
        {
            List<PlantUtility> plantUtilityEntity = PlantUtilityAccess.GetPlantUtilWaterFactorDetails(myServiceTime, Resources.PlantUtilityFactorWaterType, ecolabAccountNumber);
            if (plantUtilityEntity.Count > 0)
            {
                foreach (PlantUtility util in plantUtilityEntity)
                {
                    PlantUtilityFactorTypes puft = new PlantUtilityFactorTypes();

                    puft.FactorType = util.FactorType;
                    puft.Price = util.Price;
                    puft.Temperature = util.Temperature;
                    puft.MyServiceWatrFctrId = util.MyServiceWatrFctrId;
                    puft.UtilityWaterType = util.UtilityTypeCode;
                    plantUtilityFactorTypes.Add(puft);
                }
                Log.Info("Able to retrieve Water type details from MyService");
            }
            else
            {
                Log.Info(string.Format("Unable to retrieve Water type details from MyService, no records for Gas Oil type for ecolabaccountnumber:{0}", ecolabAccountNumber));
            }
        }

        /// <summary>
        /// Get Gas Oil Details
        /// </summary>
        /// <param name="plantUtilityFactorTypes">plant Utility Factor Types</param>
        /// <param name="myServiceTime">myService Time</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        private void GetGasoilDetails(List<PlantUtilityFactorTypes> plantUtilityFactorTypes, DateTime myServiceTime, string ecolabAccountNumber)
        {
            List<PlantUtility> plantUtilityEntity = PlantUtilityAccess.GetPlantUtilWaterFactorDetails(myServiceTime, Resources.PlantUtilityEnergyPropertiesGasOil, ecolabAccountNumber);

            if (plantUtilityEntity.Count > 0)
            {
                foreach (PlantUtility util in plantUtilityEntity)
                {
                    foreach (PlantUtilityFactorTypes puft in plantUtilityFactorTypes)
                    {
                        puft.RewashFactor = util.RewashFactor;
                        puft.EvaporationFactor = util.EvaporationFactor;
                        puft.GasoilType = util.GasoilType;
                        puft.GasoilTypeId = PlantUtilityAccess.GetGasoilTypeId(util.GasoilType);
                        puft.EnergyPrice = util.GasPrice;
                        switch (util.MyServiceEnergyPriceUom.Trim())
                        {
                            case "Btu":
                                puft.EnergyPriceUnit = "Btu";
                                break;
                            case "ccf":
                                puft.EnergyPriceUnit = "ccf";
                                break;
                            case "thm":
                                puft.EnergyPriceUnit = "thm";
                                break;
                            case "gal":
                                puft.EnergyPriceUnit = "gal";
                                break;
                            case "mcf":
                                puft.EnergyPriceUnit = "mcf";
                                break;
                            default:
                                puft.EnergyPriceUnit = "Btu";
                                break;
                        }
                        puft.GasoilTypeId = PlantUtilityAccess.GetGasoilTypeId(util);
                    }
                }
                Log.Info("Able to retrieve Gas oil type details from MyService");
            }
            else
            {
                plantUtilityFactorTypes.ForEach(t => { t.EnergyPrice = 0; t.EnergyPriceUnit = "Btu"; });
                Log.Info(string.Format("Unable to retrieve Gas oil type details from MyService, no records for Gas Oil type for ecolabaccountnumber:{0}", ecolabAccountNumber));
            }
        }

        /// <summary>
        /// Get Boiler Details
        /// </summary>
        /// <param name="plantUtilityFactorTypes">plant Utility Factor Types</param>
        /// <param name="myServiceTime">myService Time</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        private void GetBoilerDetails(List<PlantUtilityFactorTypes> plantUtilityFactorTypes, DateTime myServiceTime, string ecolabAccountNumber)
        {
            List<PlantUtility> plantUtilityEntity = PlantUtilityAccess.GetPlantUtilWaterFactorDetails(myServiceTime, Resources.PlantUtilityEnergyPropertiesBoiler, ecolabAccountNumber);

            if (plantUtilityEntity.Count > 0)
            {
                foreach (PlantUtility util in plantUtilityEntity)
                {
                    foreach (PlantUtilityFactorTypes puft in plantUtilityFactorTypes)
                    {
                        puft.BoilerSteam = util.BoilerSteam;
                        puft.BoilerPercentage = util.BoilerPercentage;
                        puft.SteamPercentage = util.SteamPercentage;
                        puft.StackPercentage = util.StackPercentage;
                        puft.ElectricPrice = util.ElectricityTarrif;
                        puft.BoilerType = util.BoilerType;
                    }
                }
                Log.Info("Able to retrieve Boiler type details from MyService");
            }

            Log.Info(string.Format("Unable to retrieve Boiler type details from MyService, no records for Gas Oil type for ecolabaccountnumber:{0}", ecolabAccountNumber));
        }

        /// <summary>
        /// Get Utility Details From Conduit
        /// </summary>
        /// <param name="ecolabAccntNbr">ecolab Account Number</param>
        /// <returns>utility factors details</returns>
        private List<PlantUtilityFactorTypes> GetUtilityDetailsFromConduit(string ecolabAccntNbr)
        {
            try
            {
                List<PlantUtilityFactorTypes> plantUtilityFactorTypes = Access.PlantSetup.PlantUtilityFactorTypesAccess.GetPlantUtilityDetails(ecolabAccntNbr);
                return plantUtilityFactorTypes;
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantUtilityProcessor : " + ex.ToString());
                responseFlag = false;
                return null;
            }
        }

        /// <summary>
        /// Get Myservice Gasoil Id
        /// </summary>
        /// <param name="gasoilId">The Gas Oil ID</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns></returns>
        public int GetMyserviceGasoilId(int gasoilId, string ecolabAccountNumber)
        {
            int myServiceGasOilId = PlantUtilityAccess.GetMyServiceGasoilTypeId(gasoilId, ecolabAccountNumber);
            return myServiceGasOilId;
        }

        /// <summary>
        /// The Process Sync
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <param name="log">MyService sync log</param>
        /// <param name="myServiceTime">myService Time</param>
        private void ProcessSync(string ecolabAccountNumber, MyServiceSyncLog log, DateTime myServiceTime)
        {
            try
            {
                Log.Info("Save data for new plants in my Service");
                plantUtility = new List<PlantUtilityFactorTypes>();

                Models.Plant plant = new Models.Plant();
                PlantService plantService = new PlantService();
                plant = plantService.GetPlantDetails(ecolabAccountNumber);

                GetWaterTypeDetails(plantUtility, myServiceTime, ecolabAccountNumber);
                GetGasoilDetails(plantUtility, myServiceTime, ecolabAccountNumber);
                GetBoilerDetails(plantUtility, myServiceTime, ecolabAccountNumber);

                plantUtility.ForEach(t => t.EcolabAccountNumber = ecolabAccountNumber);
                plantUtility.ForEach(t => t.UtilityType = 1);
                Log.Info("Myservice PlantUtility Data : " + MyServiceCommon.SerializeToJsonFromEntity(plantUtility));
                
                if (plant.RegionId == 1)
                {
                    foreach (var item in plantUtility)
                    {
                        if (item.FactorType == "Fresh")
                        {
                            item.WaterFactorTypeId = 1;
                            item.FreeType = 1;
                        }
                        else if (item.FactorType == "Hot")
                        {
                            item.WaterFactorTypeId = 2;
                            item.FreeType = 2;
                        }
                        else if (item.FactorType == "Tempered")
                        {
                            item.WaterFactorTypeId = 3;
                            item.FreeType = 3;
                        }
                        else if (item.FactorType.ToUpperInvariant().Contains("SEWER"))
                        {
                            item.WaterFactorTypeId = 4;
                            item.FreeType = 4;
                        }
                        else
                        {
                            if (item.UtilityWaterType.Equals("V"))
                            {
                                item.WaterFactorTypeId = PlantUtilityAccess.GetWaterFactortypeId(item.FactorType, plant.RegionId);
                                item.FreeType = 0; 
                            }
                        }
                    }
                }
                else
                {
                    foreach (var item in plantUtility)
                    {
                        if (item.FactorType == "Cold")
                        {
                            item.WaterFactorTypeId = 12;
                            item.FreeType = 12;
                        }
                        else if (item.FactorType == "Hot")
                        {
                            item.WaterFactorTypeId = 14;
                            item.FreeType = 14;
                        }
                        else if (item.FactorType == "Tempered")
                        {
                            item.WaterFactorTypeId = 15;
                            item.FreeType = 15;
                        }
                        else if (item.FactorType.ToUpperInvariant().Contains("SEWER"))
                        {
                            item.WaterFactorTypeId = 16;
                            item.FreeType = 16;
                        }
                        else
                        {
                            if (item.UtilityWaterType.Equals("V"))
                            {
                                item.WaterFactorTypeId = PlantUtilityAccess.GetWaterFactortypeId(item.FactorType, plant.RegionId);
                                item.FreeType = 0;
                            }
                        }
                    }
                }

                DateTime lastSyncTime;
                PlantUtilityService plantUtilityService = new PlantUtilityService();
                Log.Info("Attempting to save Plant utility details to conduit central");
                List<Models.PlantSetup.PlantUtilityFactorTypes> plantUtilityFactorTypes = Mapper.Map<List<PlantUtilityFactorTypes>, List<Models.PlantSetup.PlantUtilityFactorTypes>>(plantUtility);

                if (CheckPlantUtilityExists(ecolabAccountNumber))
                {
                    CreateDefaultUtilityDetails(ecolabAccountNumber, plantUtilityFactorTypes, plant);
                }

                plantUtilityService.SavePlantWaterEnergyUtilityDetails(plantUtilityFactorTypes, SystemUserId, out lastSyncTime);
                Log.Info("Saved Plant utility details to conduit central");
            }
            catch (Exception ex)
            {
                Log.Error("Error in PlantUtilityProcessor : " + ex.ToString());
                responseFlag = false;
            }

            if (responseFlag)
            {
                Log.Info("Syncing Success for PlantUtility");
                if (log != null)
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantUtility", "Yes");
                }
            }
            else
            {
                Log.Info("Syncing Fail for PlantUtility");
                if (log != null)
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                }
                else
                {
                    MyServiceCommon.UpdateMyServiceSyncLog(ecolabAccountNumber, "PlantUtility", "Fail");
                }
            }
        }

        /// <summary>
        /// Create Default Utility Details
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="utilityFactorTypes">utility Factor Types</param>
        /// <param name="plant">The plant Details</param>
        private void CreateDefaultUtilityDetails(string ecolabAccountNumber, List<Models.PlantSetup.PlantUtilityFactorTypes> utilityFactorTypes, Models.Plant plant)
        {
            List<PlantUtilityFactorTypes> plantUtilityFactorTypes = new List<PlantUtilityFactorTypes>();
            for (int i = 0; i < 7; i++)
            {
                PlantUtilityFactorTypes plantUtilityFactorType = new PlantUtilityFactorTypes();
                plantUtilityFactorType.EcolabAccountNumber = ecolabAccountNumber;
                plantUtilityFactorType.UtilityType = 0;
                plantUtilityFactorType.MyServiceLastSyncTime = DateTime.UtcNow;
                plantUtilityFactorType.MyServiceWatrFctrId = 0;
                if (i == 0)
                {
                    if (plant.RegionId == 1)
                    {
                        plantUtilityFactorType.FactorType = "Fresh";
                    }
                    else
                    {
                        plantUtilityFactorType.FactorType = "Cold";
                    }
                    plantUtilityFactorType.GasoilTypeId = 0;
                    plantUtilityFactorType.BoilerType = 0;
                    plantUtilityFactorType.EnergyPriceUnit = "0";
                }
                else if (i == 1)
                {
                    plantUtilityFactorType.FactorType = "Hot";
                }
                else if (i == 2)
                {
                    plantUtilityFactorType.FactorType = "Tempered";
                }
                else if (i == 3)
                {
                    plantUtilityFactorType.FactorType = "Sewer";
                }
                else
                {
                    plantUtilityFactorType.FactorType = "None";
                }
                plantUtilityFactorTypes.Add(plantUtilityFactorType);
            }
            DateTime lastSyncTime;
            PlantUtilityService plantUtilityService = new PlantUtilityService();
            List<Models.PlantSetup.PlantUtilityFactorTypes> objPlantUtility = Mapper.Map<List<PlantUtilityFactorTypes>, List<Models.PlantSetup.PlantUtilityFactorTypes>>(plantUtilityFactorTypes);
            plantUtilityService.SavePlantWaterEnergyUtilityDetails(objPlantUtility, SystemUserId, out lastSyncTime);

            foreach (Models.PlantSetup.PlantUtilityFactorTypes item in utilityFactorTypes)
            {
                PlantUtilityAccess.UpdateMyServiceWaterFactrId(item, false);
            }

            if (utilityFactorTypes.Count > 0)
            {
                PlantUtilityAccess.UpdateMyServiceWaterFactrId(utilityFactorTypes.FirstOrDefault(), true);
            }
        }

        /// <summary>
        /// Check Plant Utility Exists
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Returns a boolean value</returns>
        private bool CheckPlantUtilityExists(string ecolabAccountNumber)
        {
            return PlantUtilityAccess.CheckPlantUtilityExists(ecolabAccountNumber);
        }

        /// <summary>
        /// Processing ConduitData to Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="log">Myservice Sync Log</param>
        public void ProcessMyServiceSync(string ecolabAccountNumber, MyServiceSyncLog log)
        {
            Log.Info("PlantUtility: Processing Conduit Data to Myservice");
            List<PlantUtilityFactorTypes> utility = new List<PlantUtilityFactorTypes>();
            Log.Info(string.Format("Attempting to update conduit central Plant Utility details data to MyService, ecolabaccountnumber:{0}", ecolabAccountNumber));
            Log.Info("PlantUtility: Fetching List Utility from Conduit.");
            utility = GetUtilityDetailsFromConduit(ecolabAccountNumber);
            utility = utility.Where(t => t.LastModifiedTime > log.MyServiceLastSynchTime).ToList().OrderBy(t => t.WaterUtilityDetailsID).ToList();
            Log.Info("PlantUtility: Data Recieved: " + MyServiceCommon.SerializeToJsonFromEntity(utility));
            if (utility != null && utility.Count > 0)
            {
                int myServiceGasOilTypeId = GetMyserviceGasoilId(utility.FirstOrDefault().GasoilTypeId, ecolabAccountNumber);
                utility.ForEach(t => t.GasoilTypeId = myServiceGasOilTypeId);
                int count = 1;
                foreach (PlantUtilityFactorTypes plantUtilityFactorTypes in utility)
                {
                    try
                    {
                        if (plantUtilityFactorTypes.WaterFactorTypeId > 0)
                        {
                            plantUtilityFactorTypes.WaterFactorTypeId = GetMyserviceWatrFctrId(plantUtilityFactorTypes.WaterFactorTypeId, ecolabAccountNumber);
                            PlantUtilityAccess.SavePlantUtilityDetails(plantUtilityFactorTypes, count);
                            count = count + 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.Error("Error in PlantUtilityProcessor : " + ex.ToString());
                        responseFlag = false;
                    }

                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for PlantUtility");
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantUtility", "Yes");
                    }
                }
                else
                {
                    Log.Info("Syncing Fail for PlantUtility");
                    if (log != null)
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    }
                    else
                    {
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "PlantUtility", "Fail");
                    }
                }
            }
            else
            {
                Log.Info(string.Format("Plant utility details not present in conduit, PlantUtilityEnergyFactor may have value, but repective data is not present in PlantUtilityFactor table in conduit central, ecolabaccountnumber:{0}", ecolabAccountNumber));
            }
        }

        /// <summary>
        /// Get Myservice Water Factor Id
        /// </summary>
        /// <param name="wtrFctrId">The Water Factor Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>myService Watar Factor Id</returns>
        private int GetMyserviceWatrFctrId(int wtrFctrId, string ecolabAccountNumber)
        {
            int myServiceWatarFctrId = PlantUtilityAccess.GetMyserviceWatrFctrId(wtrFctrId, ecolabAccountNumber);
            return myServiceWatarFctrId;
        }
    }
}
