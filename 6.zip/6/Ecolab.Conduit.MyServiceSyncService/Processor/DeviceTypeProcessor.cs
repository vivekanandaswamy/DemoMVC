﻿// -----------------------------------------------------------------------
// <copyright file="DeviceTypeProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Device Type Processor class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access.PlantSetup;
    using AutoMapper;
    using Common;
    using Entities;
    using Entities.Common;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;

    /// <summary>
    /// Device Type Processor class
    /// </summary>
    public class DeviceTypeProcessor : IProcessor
    {
        /// <summary>
        /// Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// response flag
        /// </summary>
        private bool _mResponseFlag = true;

        /// <summary>
        ///  Save Washer Model Size details from Myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            Log.Info("DeviceType: Sync Started");
            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "DeviceType");
            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }
            List<DeviceType> myserviceDeviceTypeDetails = GetMyServiceDeviceTypeDetails(myServiceTime);

            ProcessMyServiceObject(plants, log, myserviceDeviceTypeDetails);
        }

        private void ProcessMyServiceObject(List<Plant> plants, MyServiceSyncLog log, List<DeviceType> myserviceDeviceTypeDetails)
        {
            if (myserviceDeviceTypeDetails != null && myserviceDeviceTypeDetails.Count > 0)
            {
                Log.Info("DeviceType: Insert Or Update DeviceType data into Central");
                Log.Info("Total DeviceType :: " + myserviceDeviceTypeDetails.Count);
                foreach (DeviceType deviceType in myserviceDeviceTypeDetails)
                {
                    Log.Info("DeviceType Detail : " + MyServiceCommon.SerializeToJsonFromEntity<DeviceType>(deviceType));
                    int deviceTypeId = InsertOrUpdateDeviceTypeDetails(deviceType);
                    deviceType.DeviceTypeId = deviceTypeId;
                }
                Log.Info("DeviceType: Sync to central: Success.");
                Log.Info("Insert Or Update DeviceType data into Local Plants");

                foreach (Plant plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);
                    if (!isDisconnected)
                    {
                        int response = 0;
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.Common.DeviceType> devicetypeDetails = Mapper.Map<List<DeviceType>, List<Models.Common.DeviceType>>(myserviceDeviceTypeDetails);
                        response = Push.PushMasterData(devicetypeDetails, plant.EcoalabAccountNumber, SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceDeviceType);
                        if (response != 0)
                        {
                            Log.Info("DeviceType: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Failed");
                            _mResponseFlag = false;
                        }
                        else
                        {
                            Log.Info("DeviceType: Sync to Local Plant: " + plant.EcoalabAccountNumber + " :Success");
                        }
                    }
                }
                if (_mResponseFlag)
                {
                    Log.Info("Syncing Success for Device Type");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "DeviceType", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for Device Type");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "DeviceType", "Fail");
                }
            }
        }

        /// <summary>
        /// Get MyService DeviceType Details
        /// </summary>
        /// <param name="lastSyncTimeInCentral">lastSyncTimeInCentral</param>
        /// <returns>List of DeviceType</returns>
        private List<DeviceType> GetMyServiceDeviceTypeDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<DeviceType> myserviceDeviceTypeDetails = DeviceTypeAccess.GetDeviceTypeDetails(lastSyncTimeInCentral);
                return myserviceDeviceTypeDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in DeviceTypeProcessor :: " + ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// Insert or Update Device Type in Central
        /// </summary>
        /// <param name="deviceType">device Type from MyService</param>
        private int InsertOrUpdateDeviceTypeDetails(DeviceType deviceType)
        {
            try
            {
                deviceType.DeviceTypeId = UtilityAccess.SaveMyServiceDeviceTypeDetails(deviceType);
                UtilityAccess.SaveMyServiceDeviceTypeLocaleDetails(deviceType);
                return deviceType.DeviceTypeId;
            }
            catch (Exception ex)
            {
                _mResponseFlag = false;
                Log.Error("Error in DeviceTypeProcessor :: " + ex.ToString());
                Log.Error("DeviceType Detail : " + MyServiceCommon.SerializeToJsonFromEntity<DeviceType>(deviceType));
                return 0;
            }
        }

        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }
    }
}
