﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainProgramProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PlantChainProgram processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using AutoMapper;
    using Common;
    using Entities;
    using Library.Enums;
    using log4net;
    using PushHandler;

    /// <summary>
    /// PlantChainProgramProcessor class
    /// </summary>
    public class PlantChainProgramProcessor : IProcessor
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// Default System UserId
        /// </summary>
        private int UserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Plant ChainProgram details from central
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Entities.Plant> plants)
        {
            int response = 0;
            Log.Info("Started sync For PlantChainProgram");

            Log.Info("Getting PlantChain Details from central");

            List<PlantChain> plantChains = Access.PlantChainAccess.GetPlantChainDetails();

            Log.Info("Fetched PlantChain Details from central");

            foreach (PlantChain pc in plantChains)
            {
                List<PlantChainProgram> plantChainPrograms = Access.PlantChainProgramAccess.GetPlantChainProgramByPlantChainId(pc.PlantChainId);
                List<Plant> plantsForChain = plants.Where(p => p.PlantChainId == pc.PlantChainId).ToList();
                if (plantChainPrograms != null && plantChainPrograms.Count != 0)
                {
                    foreach (var plant in plantsForChain)
                    {
                        bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                        if (!isDisconnected)
                        {
                            Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                            List<Models.PlantChainProgram> plantChainPrgms = Mapper.Map<List<PlantChainProgram>, List<Models.PlantChainProgram>>(plantChainPrograms);
                            response = Push.PushMasterData(plantChainPrgms, plant.EcoalabAccountNumber, UserId, (int)TcdAdminMessageTypes.TcdUpdatePlantChainProgram);
                            if (response != 0)
                            {
                                Log.Info("Plant Chain Program: Push To local: Failed for Plant " + plant.EcoalabAccountNumber);
                            }
                            else
                            {
                                Log.Info("Plant Chain Program: Push To local: Success for Plant " + plant.EcoalabAccountNumber);
                            }
                        }
                        else
                        {
                            Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "DisConnected");
                        }
                    }
                }
            }
        }

    }
}
