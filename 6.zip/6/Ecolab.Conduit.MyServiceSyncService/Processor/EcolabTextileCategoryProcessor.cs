﻿// -----------------------------------------------------------------------
// <copyright file="EcolabTextileCategoryProcessor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The EcolabTextileCategory processor class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Processor
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using Access;
    using AutoMapper;
    using Common;
    using Entities;
    using Library.Enums;
    using log4net;
    using MyServiceAccess;
    using PushHandler;

    /// <summary>
    ///     EcolabTextileCategoryProcessor class
    /// </summary>
    public class EcolabTextileCategoryProcessor : IProcessor
    {
        /// <summary>
        ///     logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        ///     Default System UserId
        /// </summary>
        private readonly int SystemUserId = Convert.ToInt32(ConfigurationManager.AppSettings["SystemUserId"]);

        /// <summary>
        /// response flag
        /// </summary>
        private bool responseFlag = true;

        /// <summary>
        ///     Not Implemented
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public void Save(string ecolabAccountNumber)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///     Save Ecolab TexttileCategory details from myservice
        /// </summary>
        /// <param name="plants">List of Plants</param>
        public void Save(List<Plant> plants)
        {
            Log.Info("Started sync For EcolabTexttileCategory");

            MyServiceSyncLog log = MyServiceCommon.GetMyServiceSyncLogDetails(null, "EcolabTextileCategory");

            DateTime myServiceTime;
            if (log != null)
            {
                Log.Info("Message fetched from MyService Sync log Table is: " + MyServiceCommon.SerializeToJsonFromEntity<MyServiceSyncLog>(log));

                myServiceTime = MyServiceCommon.ConvertUTCTimeToMyServiceTime(log.MyServiceLastSynchTime);
            }
            else
            {
                myServiceTime = DateTime.Now.AddYears(-100);
            }

            List<EcolabTextileCategory> myserviceEcolabTextileCategoryDetails =
                this.GetMyServiceEcolabTextileCategoryDetails(myServiceTime);

            this.ProcessMyServiceObject(plants, log, myserviceEcolabTextileCategoryDetails);
        }

        /// <summary>
        ///     process the myservice object
        /// </summary>
        /// <param name="plants">Plant List</param>
        /// <param name="log">MySeriveSyncLog Details </param>
        /// <param name="myserviceEcolabTextileCategoryDetails">MyService Object</param>
        public void ProcessMyServiceObject(List<Plant> plants, MyServiceSyncLog log, List<EcolabTextileCategory> myserviceEcolabTextileCategoryDetails)
        {
            if (myserviceEcolabTextileCategoryDetails != null && myserviceEcolabTextileCategoryDetails.Count > 0)
            {
                int response = 0;
                Log.Info("Insert Or Update EcolabTextileCategory data into Central");
                Log.Info("Total EcolabTextileCategory :: " + myserviceEcolabTextileCategoryDetails.Count);
                foreach (EcolabTextileCategory item in myserviceEcolabTextileCategoryDetails)
                {
                    Log.Info("EcolabTextileCategory Detail : " + MyServiceCommon.SerializeToJsonFromEntity<EcolabTextileCategory>(item));
                    this.InsertOrUpdateEcolabTextileCategoryDetails(item);
                }
                Log.Info("EcolabTextileCategory: Save to Central Success");
                Log.Info("Insert Or Update EcolabTextileCategory data into Local Plants");
                foreach (Plant plant in plants)
                {
                    bool isDisconnected = MyServiceCommon.IsPlantConnected(plant.EcoalabAccountNumber);

                    if (!isDisconnected)
                    {
                        Log.Info("Plant " + plant.EcoalabAccountNumber + " is " + "Connected");
                        List<Models.EcolabTextileCategory> ecolabTextileCategorys =
                            Mapper.Map<List<EcolabTextileCategory>, List<Models.EcolabTextileCategory>>(
                                myserviceEcolabTextileCategoryDetails);
                        response = Push.PushMasterData(ecolabTextileCategorys, plant.EcoalabAccountNumber,
                            this.SystemUserId, (int)TcdAdminMessageTypes.TcdUpdateMyServiceEcolabTextileCategory);

                        if (response != 0)
                        {
                            Log.Info("Syncing Fail in Local Plant: " + plant.EcoalabAccountNumber + "for " +
                                     "EcolabTextileCategory");
                            responseFlag = false;
                        }
                        else
                        {
                            Log.Info("Syncing Success in Local Plant: " + plant.EcoalabAccountNumber + "for " +
                                     "EcolabTextileCategory");
                        }
                    }
                }

                if (responseFlag)
                {
                    Log.Info("Syncing Success for EcolabTextileCategory");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Yes");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "EcolabTextileCategory", "Yes");
                }
                else
                {
                    Log.Info("Syncing Fail for EcolabTextileCategory");
                    if (log != null)
                        MyServiceCommon.UpdateMyServiceSyncLog(log.EcolabAccountNumber, log.Entity, "Fail");
                    else
                        MyServiceCommon.UpdateMyServiceSyncLog(null, "EcolabTextileCategory", "Fail");
                }
            }
        }

        /// <summary>
        ///     Insert or Update EcolabTextileCategory Details in Central
        /// </summary>
        /// <param name="myserviceEcolabTextileCategoryDetails">EcolabTextileCategory from MyService</param>
        private void InsertOrUpdateEcolabTextileCategoryDetails(
            EcolabTextileCategory myserviceEcolabTextileCategoryDetails)
        {
            try
            {
                myserviceEcolabTextileCategoryDetails.TextileId =
                    PlantTextileCategoryAccess.SaveMyServiceEcolabTextileCategoryDetails(
                        myserviceEcolabTextileCategoryDetails);
                PlantTextileCategoryAccess.SaveMyServiceEcolabTextileCategoryLocaleDetails(
                    myserviceEcolabTextileCategoryDetails);
            }
            catch (Exception ex)
            {
                responseFlag = false;
                Log.Error("Error in EcolabTextileCategoryProcessor :: " + ex.ToString());
                Log.Error("EcolabTextileCategory Detail : " + MyServiceCommon.SerializeToJsonFromEntity<EcolabTextileCategory>(myserviceEcolabTextileCategoryDetails));
            }
        }

        /// <summary>
        ///     Get MyService EcolabTextileCategory
        /// </summary>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <returns>List of EcolabTextileCategory object</returns>
        private List<EcolabTextileCategory> GetMyServiceEcolabTextileCategoryDetails(DateTime lastSyncTime)
        {
            try
            {
                List<EcolabTextileCategory> myserviceEcolabTextileCategoryDetails =
                    EcolabTextileCategoryAccess.GetEcolabTextileCategoryDetails(lastSyncTime);
                return myserviceEcolabTextileCategoryDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Error in EcolabTextileCategoryProcessor :: " + ex.ToString());
                return null;
            }
        }
    }
}
