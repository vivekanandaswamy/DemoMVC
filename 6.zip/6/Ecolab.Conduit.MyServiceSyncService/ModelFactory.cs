﻿// -----------------------------------------------------------------------
// <copyright file="ModelFactory.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Model Factory class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService
{
    using System;
    using System.Data;
    using System.Windows.Forms;
    using Ecolab.Conduit.MyServiceSyncService.Processor;

    /// <summary>
    /// The ModelFactory class
    /// </summary>
    public static class ModelFactory
    {
        /// <summary>
        /// Gets the Processor object
        /// </summary>
        /// <param name="action">action</param>
        /// <returns>IProcessor</returns>
        public static IProcessor GetProcessorObject(string action)
        {
            var T = Type.GetType("Ecolab.Conduit.MyServiceSyncService.Processor." + action + "Processor,Ecolab.Conduit.MyServiceSyncService");
            if (T != null) return (IProcessor)Activator.CreateInstance(T);

            return null;
        }
    }
}
