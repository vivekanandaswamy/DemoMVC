﻿// -----------------------------------------------------------------------
// <copyright file="TestMyserviceIntegration.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TestMyserviceIntegration </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using log4net;

namespace Ecolab.Conduit.MyServiceSyncService
{
    public partial class TestMyserviceIntegration : Form
    {
        MyServiceSyncService objMyservice = new MyServiceSyncService();
        public TestMyserviceIntegration()
        {
            InitializeComponent();
            Trace.Listeners.Add(new TestMyserviceIntegrationTraceListener(this.LogOutput));
        }

        private void btnStartService_Click(object sender, EventArgs e)
        {
            objMyservice.Start();
        }

        private void btnStopService_Click(object sender, EventArgs e)
        {
            if (objMyservice.CanStop)
            {
                objMyservice.Stop();
            }
        }

        private void TestMyserviceIntegration_Load(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            LogOutput.Text = string.Empty;
        }
    }

    internal class TestMyserviceIntegrationTraceListener : TraceListener
    {
        TextBox LogTextBox;
        public TestMyserviceIntegrationTraceListener(TextBox logTextBox)
        {
            LogTextBox = logTextBox;
        }

        public override void Write(string message)
        {
            if (LogTextBox.InvokeRequired)
            {
                LogTextBox.Invoke((MethodInvoker)delegate
                {
                    Write(message);
                });
                return;
            }

            LogTextBox.AppendText(message);
        }

        public override void WriteLine(string message)
        {
            Write(message);
            Write(Environment.NewLine);
        }
    }
}
