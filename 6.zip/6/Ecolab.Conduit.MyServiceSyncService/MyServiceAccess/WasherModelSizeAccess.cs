﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSizeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Washer Model Size Access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Entities.Washers.Conventional;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for WasherModelSize
    /// </summary>
    public class WasherModelSizeAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of WasherModelSize
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>
        /// List of PlantContact
        /// </returns>
        public static List<WasherModelSize> GetWasherModelSizeDetails(DateTime lastSyncTimeInCentral)
        {
            List<WasherModelSize> washerModelSizeList = DbClient.ExecuteReader<WasherModelSize>(DEFAULT_AREA, Resources.WasherModelSize,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return washerModelSizeList;
        }
    }
}
