﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant chain access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for PlantChain
    /// </summary>
    public class PlantChainAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of PlantChain
        /// </summary>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <returns>
        /// List of PlantChain
        /// </returns>
        public static PlantChain GetPlantChainDetails(int plantChainId)
        {
            return DbClient.ExecuteReader<PlantChain>(DEFAULT_AREA, Resources.PlantChainSetup,
              (cmd, dbContext) =>
              {
                  cmd.AddParameter("MyServiceChainId", plantChainId);
              }).FirstOrDefault();
        }

        public static List<PlantChain> GetPlantChains(DateTime lastSyncTimeInCentral)
        {
            List<PlantChain> plantChainList = DbClient.ExecuteReader<PlantChain>(Resources.PlantChain,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return plantChainList;
        }

    }
}
