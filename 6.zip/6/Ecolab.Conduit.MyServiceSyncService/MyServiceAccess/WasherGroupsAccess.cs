﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupsAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Washer Groups Access class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities.WasherGroup;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for WasherGroupsAccess
    /// </summary>
    public class WasherGroupsAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of WasherGroups 
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of WasherGroups</returns>
        public static List<WasherGroup> GetWasherGroupsDetails(String ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            List<WasherGroup> washerGroupsList = DbClient.ExecuteReader<WasherGroup>(DEFAULT_AREA, Resources.WasherGroups,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return washerGroupsList;
        }

        /// <summary>
        /// Save List of WasherGroups in MyService.
        /// </summary>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns></returns>
        public static int SaveWasherGroupInMyService(WasherGroup washerGroup)
        {
            int response = 0;

            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.InsertUpdateWasherGroups,
                         (cmd, dbContext) =>
                         {
                             cmd.AddParameter("MyServiceWasherGroupGuid", washerGroup.MyServiceWasherGroupGuid);
                             cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                             cmd.AddParameter("WasherGroupNumber", DbType.String, 1000, washerGroup.WasherGroupNumber.ToString());
                             cmd.AddParameter("WasherGroupName", DbType.String, 1000, washerGroup.WasherGroupName);
                             cmd.AddParameter("WasherGroupTypeId", washerGroup.WasherGroupTypeId);
                             cmd.AddParameter("IsDeleted", washerGroup.IsDelete);
                             cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, washerGroup.LastModifiedTimestamp); // Need to verify
                         });

            return response;
        }

        public static int InsertDefaultMachineGroup(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Resources.InsertDefaultMachineGroup,
                        (cmd, dbContext) =>
                        {
                            cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                        });
        }
    }
}
