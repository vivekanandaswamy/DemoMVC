﻿// -----------------------------------------------------------------------
// <copyright file="FormulaSegmentAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FormulaSegmentAccess </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Class for Formula Segment Access
    /// </summary>
    /// <seealso cref="Ecolab.Conduit.MyServiceSyncService.MyServiceAccess.BaseAccess" />
    public class FormulaSegmentAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of FormulaSegments 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of FormulaSegment</returns>
        public static List<FormulaSegment> FetchFormulaSegments(DateTime lastSyncTimeInCentral)
        {
            List<FormulaSegment> formulaSegments = DbClient.ExecuteReader<FormulaSegment>(Resources.FetchFormulaSegments,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("@TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return formulaSegments;
        }
    }
}
