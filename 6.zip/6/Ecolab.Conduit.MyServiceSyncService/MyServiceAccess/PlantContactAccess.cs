﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant contact access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for PlantContact
    /// </summary>
    public class PlantContactAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of PlantContact 
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of PlantContact</returns>
        public static List<PlantContact> GetPlantContactDetails(string ecolabAccountNumber, DateTime lastSyncTimeInCentral) 
        {
            List<PlantContact> plantContacts = DbClient.ExecuteReader<PlantContact>(DEFAULT_AREA, Resources.PlantContact,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000,  ecolabAccountNumber);
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);   
                           }).ToList();

            return plantContacts;
        }

        /// <summary>
        /// Save plant Contacts in my service
        /// </summary>
        /// <param name="conduitPlantContactDetail">Conduit Plant Contact</param>
        public static void SavePlantContactDetails(PlantContact conduitPlantContactDetail)
        {
            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SavePlantContact,
                (cmd, dbContext) =>
                {
                    cmd.CommandTimeout = 0;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, conduitPlantContactDetail.EcoalabAccountNumber);
                    cmd.AddParameter("MyServiceCntctGuid", conduitPlantContactDetail.MyServiceCntctGuid);
                    cmd.AddParameter("FirstName", DbType.String, 40, conduitPlantContactDetail.ContactFirstName);
                    cmd.AddParameter("LastName", DbType.String, 40, conduitPlantContactDetail.ContactLastName);
                    cmd.AddParameter("EmailId", DbType.String, 60, conduitPlantContactDetail.ContactEmailAdresss);
                    cmd.AddParameter("OfficePhnNo", DbType.String, 30, conduitPlantContactDetail.ContactOfficePhone);
                    cmd.AddParameter("MobilePhnNo", DbType.String, 30, conduitPlantContactDetail.ContactMobilePhone);
                    cmd.AddParameter("FaxNo", DbType.String, 30, conduitPlantContactDetail.ContactFaxNumber);
                    cmd.AddParameter("ContactPositionId", conduitPlantContactDetail.MyServiceContactPositionId);
                    cmd.AddParameter("IsDelete", conduitPlantContactDetail.IsDelete);
                    cmd.AddParameter("ContactTitle", DbType.String, 30, string.IsNullOrEmpty(conduitPlantContactDetail.ContactTitle) ? "Mr." : conduitPlantContactDetail.ContactTitle.Contains('.') ? conduitPlantContactDetail.ContactTitle :
                                                                        conduitPlantContactDetail.ContactTitle + ".");
                });
        }
    }
}
