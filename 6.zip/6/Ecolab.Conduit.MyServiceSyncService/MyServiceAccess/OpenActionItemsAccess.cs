﻿// -----------------------------------------------------------------------
// <copyright file="OpenActionItemsAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Washer Model Size Access class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for OpenActionItems
    /// </summary>
    public class OpenActionItemsAccess : BaseAccess 
    {
        /// <summary>
        /// Get the List of OpenActionItems 
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of PlantContact</returns>
        public static List<OpenActionItems> GetOpenActionItemsDetails(string ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            List<OpenActionItems> openActionItemsList = DbClient.ExecuteReader<OpenActionItems>(DEFAULT_AREA, Resources.OpenActionItems,
                          (cmd, dbContext) =>
                          {
                              cmd.CommandTimeout = 0;
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return openActionItemsList;
        }
    }
}
