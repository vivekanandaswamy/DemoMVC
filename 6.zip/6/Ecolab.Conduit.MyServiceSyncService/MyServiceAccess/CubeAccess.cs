﻿// -----------------------------------------------------------------------
// <copyright file="CubeAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CubeAccess </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.MyServiceSyncService.Common;
using Ecolab.Conduit.MyServiceSyncService.Model;

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    public class CubeAccess
    {
        public static List<WashFloorFormula> FetchFormulaWashfloorData(DateTime lastSyncTime)
        {
            //            string mdxQuery = @"SELECT NON EMPTY { [Measures].[NoOfLoads] } ON COLUMNS,
            //                                NON EMPTY { ([Location].[EcolabAccountNumber].[EcolabAccountNumber].ALLMEMBERS *
            //                                [Washer].[WasherId].[WasherId].ALLMEMBERS *[Program].[ProgramId].[ProgramId] .ALLMEMBERS *
            //                                [Date].[Year].[Year].ALLMEMBERS * [Date].[Month].[Month].ALLMEMBERS ) } 
            //                                ON ROWS FROM (SELECT({[Date].[Year].&[" + DateTime.Now.Year.ToString() + @"]},
            //                                {[Date].[Month].[Month].&[" + DateTime.Now.Month.ToString() + @"]&[" + DateTime.Now.Year.ToString() + @"]})
            //                                ON COLUMNS FROM [TCDReport])";
            string mdxQuery = @"WITH MEMBER [Measures].[Key] AS          
                                IIF(ISEMPTY([Measures].[TotalEfficiency_All]),[Measures].[TotalEfficiency_All],
                                [Location].[EcolabAccountNumber].CurrentMember.Properties('Key'))
                                                                MEMBER [Measures].[WasheridKey] AS
                                IIF(ISEMPTY([Measures].[TotalEfficiency_All]),[Measures].[TotalEfficiency_All],[Washer].[WasherId].
                                CurrentMember.Properties('Key0'))                              
                                    MEMBER [Measures].[ProgramIdKey] AS                          
                                            IIF(ISEMPTY([Measures].[TotalEfficiency_All]),[Measures].[TotalEfficiency_All],[Program].
                                            [ProgramId].CurrentMember.Properties('Key0')) SELECT NON EMPTY { [Measures].
                                            [NoOfLoads],[Measures].[Key] ,[Measures].[WasheridKey],[Measures].[ProgramIdKey] }
                                             ON COLUMNS,                            
                                                NON EMPTY { ([Location].[EcolabAccountNumber].[EcolabAccountNumber].ALLMEMBERS * 
                                 [Washer].[WasherId].[WasherId].ALLMEMBERS *[Program].[ProgramId].[ProgramId] .ALLMEMBERS *   
                                                             [Date].[Year].[Year].ALLMEMBERS * [Date].[Month].[Month].ALLMEMBERS ) }  
                                ON ROWS FROM (SELECT( {[Date].[Year].[Year].&[" + lastSyncTime.Year.ToString() + @"] : [Date].[Year].[Year].&[" + DateTime.Now.Year.ToString() + @"]},                             
                                 {[Date].[Month].[Month].&[" + lastSyncTime.Month.ToString() + @"]&[" + lastSyncTime.Year.ToString() + @"] : [Date].[Month].[Month].&[" + DateTime.Now.Month.ToString() + @"]&[" + DateTime.Now.Year.ToString() + @"]})   
                                                             ON COLUMNS FROM [TCDReport])";
            DataTable dtcube = CubeUtility.FetchDataFromCube(mdxQuery);

            List<WashFloorFormula> washFloorFormula = CubeDatatableToList.ConvertToList<WashFloorFormula>(dtcube);
            return washFloorFormula;
        }

        public static List<CustLoadsWashFloor> FetchCustomerFormulaWashfloorData(DateTime lastSyncTime)
        {
            string mdxQuery = @"WITH MEMBER [Measures].[Key] AS
                                   IIF(ISEMPTY([Measures].[NoofLoads]),[Measures].[NoofLoads],[Location].[EcolabAccountNumber].CurrentMember.Properties('Key'))
                                SELECT NON EMPTY { [Measures].[NoOfLoads],[Measures].[Totalweight] ,[Measures].[Key] } ON COLUMNS,
                                 NON EMPTY { ([Location].[EcolabAccountNumber].[EcolabAccountNumber].ALLMEMBERS * 
                                [Date].[Datefield].[Datefield].ALLMEMBERS ) }
                                ON ROWS FROM (SELECT ({{[DATE].[Datefield].&[" + lastSyncTime.ToString("yyyy-MM-dd") + @"T00:00:00] : [DATE].[Datefield].&[" + DateTime.Now.ToString("yyyy-MM-dd") + @"T00:00:00]}})                                
                                ON COLUMNS FROM [TCDReport])";

            DataTable dtcube = CubeUtility.FetchDataFromCube(mdxQuery);

            List<CustLoadsWashFloor> washFloorFormula = CubeDatatableToList.ConvertToList<CustLoadsWashFloor>(dtcube);
            return washFloorFormula;
        }

        public static List<CustEfficiencyWashFloor> FetchEfficiencyWashfloorData(DateTime lastSyncTime)
        {
            var cal = System.Globalization.DateTimeFormatInfo.CurrentInfo.Calendar;
            int week = cal.GetWeekOfYear(lastSyncTime, System.Globalization.CalendarWeekRule.FirstDay, DayOfWeek.Sunday);
            string mdxQuery = @"WITH MEMBER [Measures].[Key] AS
                                IIF(ISEMPTY([Measures].[TotalEfficiency_All]),[Measures].[TotalEfficiency_All],[Location].[EcolabAccountNumber].CurrentMember.Properties('Key'))
                                SELECT NON EMPTY { [Measures].[TotalEfficiency_All] ,[Measures].[LoadEfficiency] ,[Measures].[Key] } ON COLUMNS,
                                NON EMPTY { ([Location].[EcolabAccountNumber].[EcolabAccountNumber] .ALLMEMBERS *
                                [Date].[Week Of Year].[Week Of Year].ALLMEMBERS * [Washer].[MachineGroupType].[MachineGroupType].ALLMEMBERS) }
                                ON ROWS FROM (SELECT ({[Date].[Year].[Year].&[" + lastSyncTime.Year.ToString() + @"]},
                                {[Date].[Week Of Year].[Week Of Year].&[" + week + @"]&[" + lastSyncTime.Year.ToString() + @"]})                               
                                ON COLUMNS FROM [TCDReport])";

            DataTable dtcube = CubeUtility.FetchDataFromCube(mdxQuery);

            List<CustEfficiencyWashFloor> washFloorFormula = CubeDatatableToList.ConvertToList<CustEfficiencyWashFloor>(dtcube);
            return washFloorFormula;
        }
    }
}
