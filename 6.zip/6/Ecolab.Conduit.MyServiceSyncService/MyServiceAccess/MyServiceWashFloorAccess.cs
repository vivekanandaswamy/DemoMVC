﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceWashFloorAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Wash floor Access  class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Ecolab.Conduit.MyServiceSyncService.Model;
    using Entities;
    using Nalco.Data.Common;
    
    /// <summary>
    /// MyServiceWashFloorAccess class
    /// </summary>
    public class MyServiceWashFloorAccess : BaseAccess
    {
        /// <summary>
        /// Save Formula wash floor data to myservice
        /// </summary>
        /// <param name="myServiceFormulaGuid">MyServiceWashFloor object</param>
        /// <param name="loads">number of loads</param>
        public static void SaveMyServiceWashFloorFormula(MyServiceWashFloor myServiceFormulaGuid, int loads)
        {
            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SaveWashFloorFormula,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("CustGuid", DbType.String, 1000, myServiceFormulaGuid.CustGuid.ToString());
                    cmd.AddParameter("FrmMchGrpGuid", DbType.String, 255, myServiceFormulaGuid.WasherProgramGuid.ToString());
                    cmd.AddParameter("MchGuid", DbType.String, 1000, myServiceFormulaGuid.MachineGuid.ToString());
                    cmd.AddParameter("Loads",  loads);
                });
        }

        /// <summary>
        /// Save customer wash floor data to myservice
        /// </summary>
        /// <param name="ecolabAccNum">EcolabAccountNumber</param>
        /// <param name="loads">number of loads</param>
        /// <param name="soilWeight">total weight</param>
        public static void SaveMyServiceCustWashFloorFormula(string ecolabAccNum, int loads, double soilWeight, string washFloorDate)
        {
            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SaveCustWashFloor,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000,ecolabAccNum );
                    cmd.AddParameter("Loads", loads);
                    cmd.AddParameter("SoilWeight", soilWeight);
					cmd.AddParameter("WashFloorDate", DbType.String, 255, washFloorDate);
                });
        }

        /// <summary>
        /// Save efficiency wash floor data to myservice
        /// </summary>
        /// <param name="ecolabAccNum">Account number</param>
        /// <param name="totEff">total efficiency</param>
        /// <param name="loadEff">load efficiency</param>
        /// <param name="turnTime">total turn time</param>
        /// <param name="tfrTime">Transfer time</param>
        public static void SaveMyServiceEffWashFloor(string ecolabAccNum, double totEff, double loadEff, int turnTime, int tfrTime, DateTime lastSyncTime)
        {
            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SaveEffWashFloor,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccNum);
                    cmd.AddParameter("TotalEfficiency", Convert.ToDecimal(totEff));
					cmd.AddParameter("LoadEfficiency", Convert.ToDecimal(loadEff));
                    cmd.AddParameter("TurnTime", turnTime);
                    cmd.AddParameter("TransferTime", tfrTime);
					cmd.AddParameter("WashFloorDate", DbType.String, 255, lastSyncTime.ToString("yyyy-MM-dd"));
                });
        }
    }
}
