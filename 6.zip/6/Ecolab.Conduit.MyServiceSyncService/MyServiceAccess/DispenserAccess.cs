﻿// -----------------------------------------------------------------------
// <copyright file="DispenserAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Dispenser Access Class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Entities.ControllerSetup;
    using Entities.WasherGroup;
    using Nalco.Data.Common;
    public  class DispenserAccess : BaseAccess
    {
        /// <summary>
        /// Saves the dispenser data.
        /// </summary>
        /// <param name="dispenser">The dispenser.</param>
        /// <returns>return int value</returns>
        public static int SaveDispenserData(Model.Controller dispenserData)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveDispenserDataInMyService,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, dispenserData.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceDispenserGUID", dispenserData.MyServiceDispenserGUID);
                   cmd.AddParameter("ControllerNumber", dispenserData.ControllerNumber);
                   cmd.AddParameter("ControllerName",DbType.String,1000,dispenserData.ControllerName);
                   cmd.AddParameter("SerialNo",DbType.String,1000, dispenserData.SerialNumber);
                   cmd.AddParameter("InstallDate", DbType.DateTime, dispenserData.InstallDate);
                   cmd.AddParameter("ControllerModelName", DbType.String, 50, dispenserData.ControllerModelName);
                   cmd.AddParameter("RegionId",dispenserData.RegionId);
                   cmd.AddParameter("IsDelete", dispenserData.IsDelete);
               });
        }

        /// <summary>
        /// Get dispenser data from central
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        /// <param name="canControlTunnel"></param>
        /// <param name="isDelete"></param>
        /// <returns>return list of controller</returns>
        public static IList<Model.Controller> GetControllerDetails(string ecolabAccountNumber, bool? canControlTunnel = null, bool? isDelete = null)
        {
            return DbClient.ExecuteReader<Model.Controller>(Resources.GetDispenserData, (cmd, dbContext) => 
            {
                if (canControlTunnel != null)
                {
                    cmd.AddParameter("CanControlTunnel", canControlTunnel);
                }
                if (isDelete != null)
                {
                    cmd.AddParameter("IsDelete", isDelete);
                }
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        /// Saves the dispenser data in ServiceItem(MyService)
        /// </summary>
        /// <param name="dispenserData">The dispenser.</param>
        /// <returns>return int value</returns>
        public static int SaveDispenserDataInServiceItem(Model.Controller dispenserData)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveDataInServiceItem,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, dispenserData.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceDispenserGUID", dispenserData.MyServiceDispenserGUID);
                   cmd.AddParameter("ControllerName", DbType.String, 1000, dispenserData.ControllerName);
                   cmd.AddParameter("SerialNo", DbType.String, 1000, dispenserData.SerialNumber);
                   cmd.AddParameter("RegionId", dispenserData.RegionId);
                   cmd.AddParameter("IsDelete", dispenserData.IsDelete);
                   cmd.AddParameter("EntityType", DbType.String, 1000, "Dispenser");
               });
        }
    }
}
