﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWaterInletDrainLookupAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Product Category Master Access </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.Washers.Tunnel;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for product category
    /// </summary>
    public class TunnelWaterInletDrainLookupAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of Tunnel water inlet drain lookup
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of Tunnel water inlet drain lookup</returns>
        public static List<PressExtractor> GetTunnelWaterInletDrainLookupDetails(DateTime lastSyncTimeInCentral)
        {
            List<PressExtractor> tunnelWaterInletDrainLookup = DbClient.ExecuteReader<PressExtractor>(DEFAULT_AREA, Resources.TunnelWaterInletDrainLookup,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return tunnelWaterInletDrainLookup;
        }
    }
}
