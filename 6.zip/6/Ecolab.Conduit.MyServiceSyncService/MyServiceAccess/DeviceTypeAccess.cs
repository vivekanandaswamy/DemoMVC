﻿// -----------------------------------------------------------------------
// <copyright file="DeviceTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Device Type Access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities.Common;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for DeviceTyp
    /// </summary>
    public class DeviceTypeAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of DeviceType 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of DeviceType</returns>
        public static List<DeviceType> GetDeviceTypeDetails(DateTime lastSyncTimeInCentral)
        {
            List<DeviceType> deviceTypeList = DbClient.ExecuteReader<DeviceType>(DEFAULT_AREA, Resources.DeviceType,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return deviceTypeList;
        }

    }
}
