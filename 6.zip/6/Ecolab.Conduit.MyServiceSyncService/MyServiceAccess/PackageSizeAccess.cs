﻿// -----------------------------------------------------------------------
// <copyright file="PackageSizeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The package size access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    class PackageSizeAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of Package Size Access
        /// </summary>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <returns>
        /// List of Package
        /// </returns>
        public static List<PackageSize> GetMyServicePackageSizeDetails(DateTime lastSyncTime)
        {
            return DbClient.ExecuteReader<PackageSize>(DEFAULT_AREA, Resources.PackageSize,
             (cmd, dbContext) =>
             {
                 cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTime);
             }).ToList();
        }
    }
}
