﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWasherFormulaAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The TunnelWasherFormula access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.WasherGroup;
    using Entities.Washers.Tunnel;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for TunnelWasherFormulaAccess
    /// </summary>
    public class TunnelWasherFormulaAccess : BaseAccess
    {

        /// <summary>
        /// Saves the washer group formula.
        /// </summary>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <param name="washerGroup">The washer group.</param>
        /// <returns> return integer value</returns>
        public static int SaveWasherGroupFormula(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveTunnelWasherGroupFormula,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                   cmd.AddParameter("MyServiceWasherGroupGuid", washerGroup.MyServiceWasherGroupGuid);
                   cmd.AddParameter("NominalLoad", washerGroupFormula.NominalLoad);
                   cmd.AddParameter("IsDelete", washerGroupFormula.IsDelete);
                   cmd.AddParameter("ProgramName", DbType.String, 1000, washerGroupFormula.ProductName);
                   cmd.AddParameter("ProgramNumber", washerGroupFormula.ProgramNumber);
                   cmd.AddParameter("MyServiceMstrLnnTypId", washerGroupFormula.MyServiceMstrLnnTypId);
                   cmd.AddParameter("MyServiceSaturationTypeId", washerGroupFormula.MyServiceSaturationTypeId);
               });
        }

        /// <summary>
        /// Save the Tunnel Formula WashStep
        /// </summary>
        /// <param name="tunnelWashStep"></param>
        /// <param name="washerGroupFormula"></param>
        /// <param name="washerGroup"></param>
        /// <returns> return int value</returns>
        public static int SaveTunnelFormulaWashStep(TunnelWashStep tunnelWashStep, WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveTunnelFormulaWashStep,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                   cmd.AddParameter("MyServiceCusrFrmulaStpGuid", tunnelWashStep.MyServiceCusrFrmulaStpGuid);
                   cmd.AddParameter("StepNumber", tunnelWashStep.CompartmentNumber);
                   cmd.AddParameter("MyServiceWashOprId", tunnelWashStep.MyServiceWshOpId);
                   cmd.AddParameter("MyServiceWaterTypeId", tunnelWashStep.MyServiceUtilId);
                   cmd.AddParameter("MyServiceDrainTypId", tunnelWashStep.MyServiceDrainTypId);
                   cmd.AddParameter("RunTime", tunnelWashStep.StepRuntime);
                   cmd.AddParameter("Temperature", tunnelWashStep.Temperature);
                   cmd.AddParameter("WaterLevel", tunnelWashStep.WaterLevel);
                   cmd.AddParameter("IsDelete", tunnelWashStep.IsDelete);
                   cmd.AddParameter("Notes", DbType.String, 1000, tunnelWashStep.Notes);
               });
        }

        /// <summary>
        /// Saves the tunnel wash step product.
        /// </summary>
        /// <param name="tunnelWashStepProduct">The tunnel wash step product.</param>
        /// <param name="tunnelWashStep">The tunnel wash step.</param>
        /// <param name="washerGroupFormula">The washer group formula.</param>
        /// <returns> retutn int value</returns>
        public static int SaveTunnelWashStepProduct(TunnelWashStepProducts tunnelWashStepProduct, TunnelWashStep tunnelWashStep, WasherGroupFormula washerGroupFormula)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveTunnelWashStepProduct,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                    cmd.AddParameter("MyServiceFrmulaStpDsgDvcGUID", tunnelWashStepProduct.MyServiceFrmulaStpDsgDvcGUID);
                    cmd.AddParameter("MyServiceCusrFrmulaStpGuid", tunnelWashStep.MyServiceCusrFrmulaStpGuid);
                    cmd.AddParameter("MyServiceCmpmtDsgDvcguid", tunnelWashStepProduct.MyServiceCmpmtDsgDvcguid);
                    cmd.AddParameter("Quantity", tunnelWashStepProduct.Quantity);
                    cmd.AddParameter("IsDelete", tunnelWashStepProduct.IsDeleted);
                });
        }

        /// <summary>
        /// To Get the WasherGroup Formula
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        /// <param name="myServiceTime"></param>
        /// <returns>return list of washergroupformula</returns>
        public static List<WasherGroupFormula> GetWasherGroupFormula(string ecolabAccountNumber, DateTime myServiceTime, Guid custMchGrpGuid)
        {
            return DbClient.ExecuteReader<WasherGroupFormula>(DEFAULT_AREA, Resources.TunnelWasherProgramSetup,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                              cmd.AddParameter("TimeStamp", DbType.DateTime, myServiceTime);
                              cmd.AddParameter("CustMchGrpGuid", custMchGrpGuid);
                          }).ToList();
        }

        /// <summary>
        /// Gets the tunnel wash steps.
        /// </summary>
        /// <param name="myServiceCustFrmulaMchGrpGUID">My service customer frmula MCH GRP unique identifier.</param>
        /// <returns>return list of tunnelwashstep</returns>
        public static List<TunnelWashStep> GetTunnelWashSteps(Guid myServiceCustFrmulaMchGrpGUID)
        {
            return DbClient.ExecuteReader<TunnelWashStep>(DEFAULT_AREA, Resources.TunnelWashStep,
                         (cmd, dbContext) =>
                         {
                             cmd.AddParameter("MyServiceCustFrmulaMchGrpGUID", myServiceCustFrmulaMchGrpGUID);
                         }).ToList();
        }

        /// <summary>
        /// Gets the tunnel wash step products.
        /// </summary>
        /// <param name="myServiceCusrFrmulaStpGuid">My service cusr frmula STP unique identifier.</param>
        /// <returns>return list of tunnelwashstepproducts</returns>
        public static List<TunnelWashStepProducts> GetTunnelWashStepProducts(Guid myServiceCusrFrmulaStpGuid)
        {
            return DbClient.ExecuteReader<TunnelWashStepProducts>(DEFAULT_AREA, Resources.TunnelWashStepProduct,
                        (cmd, dbContext) =>
                        {
                            cmd.AddParameter("MyServiceCustFrmulaStpGUID", myServiceCusrFrmulaStpGuid);
                        }).ToList();
        }

        /// <summary>
        /// Update proposed formula to current
        /// </summary>
        /// <param name="tunnelFormula">The tunnel formula.</param>
        /// <returns>return int value</returns>
        public static int UpdateProposedToCurrentFormula(WasherGroupFormula tunnelFormula)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.UpdateFormulaInMyservice,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("InCustFrmulaMchGrpGUID", tunnelFormula.MyServiceCustFrmulaMchGrpGUID);
               });
        }

        /// <summary>
        /// Gets the tunnel compartment dosing device unique identifier.
        /// </summary>
        /// <param name="controllerEquipmentSetupId">The controller equipment setup identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns> return GUID value</returns>
        public static Guid? GetTunnelCompartmentDosingDeviceGuid(short controllerEquipmentSetupId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<Guid>(Resources.MyServiceCompartmentdosingDeviceId,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("ControllerEquipmentSetupId", controllerEquipmentSetupId);
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 50, ecolabAccountNumber);
               });
        }

        /// <summary>
        /// SaveFormulaMachineRefrenceInMyService
        /// </summary>
        /// <param name="washerGroupFormula">washerGroupFormula</param>
        /// <param name="washerGroup">washerGroup</param>
        /// <param name="myserviceTunnelGeneralDetails">myserviceTunnelGeneralDetails</param>
        public static void SaveFormulaMachineRefrenceInMyService(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup, TunnelGeneral myserviceTunnelGeneralDetails)
        {
            DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveFormulaMachineRefrenceInMyService,
                 (cmd, dbContext) =>
                 {
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                     cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                     cmd.AddParameter("MyServiceWasherGroupGuid", washerGroup.MyServiceWasherGroupGuid);
                     cmd.AddParameter("SoilWgtPctg", 0);
                     cmd.AddParameter("SoilWgt", washerGroupFormula.NominalLoad);
                     cmd.AddParameter("MyServiceMchGuid", myserviceTunnelGeneralDetails.MyServiceWashersGuid);
                     cmd.AddParameter("SoilWgtUomCode", DbType.String, 100, myserviceTunnelGeneralDetails.MaxLoad_UOMCode);
                 });
        }
    }
}