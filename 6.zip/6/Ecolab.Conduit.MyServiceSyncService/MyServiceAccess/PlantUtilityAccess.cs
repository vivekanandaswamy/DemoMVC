﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantUtilityAccess </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;

    public class PlantUtilityAccess : BaseAccess
    {

        public static List<PlantUtility> GetPlantUtilWaterFactorDetails(DateTime lastSyncTime, string spname, string ecolabAccntNbr)
        {
            return DbClient.ExecuteReader<PlantUtility>(DEFAULT_AREA, spname,
             (cmd, dbContext) =>
             {
                 cmd.AddParameter("EcolabAccountNumber", DbType.String, 10, ecolabAccntNbr);
                 cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTime);
             }).ToList();
        }

        public static void SavePlantUtilityDetails(PlantUtilityFactorTypes plantUtilityFactorType, int count)
        {
            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SavePlantUtility,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, plantUtilityFactorType.EcolabAccountNumber);
                    cmd.AddParameter("WaterFactorType", DbType.String, 255, plantUtilityFactorType.FactorType);
                    cmd.AddParameter("WaterTypeId", plantUtilityFactorType.WaterFactorTypeId);
                    cmd.AddParameter("Temperature", plantUtilityFactorType.Temperature);
                    cmd.AddParameter("Price", plantUtilityFactorType.Price);
                    cmd.AddParameter("GasOilTypeId", plantUtilityFactorType.GasoilTypeId);
                    cmd.AddParameter("EnergyPrice", plantUtilityFactorType.EnergyPrice);
                    cmd.AddParameter("EnergyPriceUnit", DbType.String, 250, plantUtilityFactorType.EnergyPriceUnit);
                    cmd.AddParameter("ElectricalPrice", plantUtilityFactorType.ElectricPrice);
                    cmd.AddParameter("BoilerSteam", plantUtilityFactorType.BoilerSteam);
                    cmd.AddParameter("BoilerType", plantUtilityFactorType.BoilerType);
                    cmd.AddParameter("Steam", plantUtilityFactorType.SteamPercentage);
                    cmd.AddParameter("Boiler", plantUtilityFactorType.BoilerPercentage);
                    cmd.AddParameter("Stack", plantUtilityFactorType.StackPercentage);
                    cmd.AddParameter("RewashFactor", plantUtilityFactorType.RewashFactor);
                    cmd.AddParameter("EvaporationFactor", plantUtilityFactorType.EvaporationFactor);
                    cmd.AddParameter("MyServiceWatrFctrId", plantUtilityFactorType.MyServiceWatrFctrId > 0 ? plantUtilityFactorType.MyServiceWatrFctrId : count);
					cmd.AddParameter("EnergyContent", plantUtilityFactorType.EnergyContent);
                    cmd.AddParameter("EnergyContentUnit", DbType.String, 250, plantUtilityFactorType.EnergyContentUnit);
                    cmd.AddParameter("Count", count);
                });
        }

		/// <summary>
		/// GetGasOilTypeId
		/// </summary>
		/// <param name="plantUtilty">plantUtilty</param>
		/// <returns>Gas oil type ID</returns>
		public static int GetGasoilTypeId(PlantUtility plantUtilty)
        {
            return DbClient.ExecuteScalar<int>(Resources.GetGasOilTypeId,
             (cmd, dbContext) =>
             {
                 cmd.AddParameter("Name", DbType.String, 100, plantUtilty.GasoilType);
             });
        }

        public static bool CheckPlantUtilityExists(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<bool>(Resources.CheckPlantUtilityExists,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 100, ecolabAccountNumber);
                });
        }

        public static int GetWaterFactortypeId(string factorType, short regionId)
        {
            return DbClient.ExecuteScalar<int>(Resources.GetWaterFactortypeId,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("FactorType", DbType.String, 100, factorType);
                    cmd.AddParameter("RegionId", regionId);
                });
        }

        public static int GetGasoilTypeId(string gasoilType)
        {
            return DbClient.ExecuteScalar<int>(Resources.GetGasOilTypeId,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("Name", DbType.String, 100, gasoilType);
               });
        }

        /// <summary>
        /// GetMyServiceGasOilTypeId
        /// </summary>
        /// <param name="gasoilTypeId"></param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns></returns>
        public static int GetMyServiceGasoilTypeId(int gasoilTypeId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<short>(Resources.GetMyServiceGasOilTypeId,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("GasOilTypeId",  gasoilTypeId);
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
               });
        }

        /// <summary>
        /// GetMyServiceGasOilTypeId
        /// </summary>
        /// <param name="wtrFctrId"></param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns></returns>
        public static int GetMyserviceWatrFctrId(int wtrFctrId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<short>(Resources.GetMyserviceWatrFctrId,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("WaterFactrId", wtrFctrId);
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
               });
        }

        public static void UpdateMyServiceWaterFactrId(Models.PlantSetup.PlantUtilityFactorTypes item, bool updateOthers)
        {
            DbClient.ExecuteNonQuery(Resources.UpdateMyServiceWaterFactrId,
              (cmd, dbContext) =>
              {
                  cmd.AddParameter("MyServiceWtrFctrId", item.MyServiceWatrFctrId);
                  cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, item.EcolabAccountNumber);
                  cmd.AddParameter("WaterFactorTypeId", item.WaterFactorTypeId);
                  cmd.AddParameter("UpdateOthers", updateOthers);
              });
        }
    }
}
