﻿// -----------------------------------------------------------------------
// <copyright file="DbHelper.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DbHelper </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess.DB
{
    using Nalco.Data.Common;

	public class DbHelper
	{
        public const string DEFAULTAREA = "MyService";

        public const string DEFAULTAREAHCForms = "HCForms";

        public static void InitializeConnection(string conString)
		{
            DbContext.AddConnectionString(DEFAULTAREA, conString);
		}
        
		public static void InitializeConnection(string dataSource, string initialCatalog)
		{
			DbContext.AddTrustedDataSource(dataSource, initialCatalog);
		}

        public static void InitializeHCFormConnection(string conString)
        {
            DbContext.AddConnectionString(DEFAULTAREAHCForms, conString);
        }
    }
}
