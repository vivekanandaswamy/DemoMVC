﻿// -----------------------------------------------------------------------
// <copyright file="TunnelPressExtractorAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Tunnel PressExtractor Access </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.Washers.Tunnel;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for Tunnel press extractor
    /// </summary>
    public class TunnelPressExtractorAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of Tunnel press extractor
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of Tunnel press extractor</returns>
        public static List<PressExtractor> GetTunnelPressExtractorDetails(DateTime lastSyncTimeInCentral)
        {
            List<PressExtractor> tunnelPressExtractor = DbClient.ExecuteReader<PressExtractor>(DEFAULT_AREA, Resources.TunnelPressExtractor,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return tunnelPressExtractor;
        }
    }
}
