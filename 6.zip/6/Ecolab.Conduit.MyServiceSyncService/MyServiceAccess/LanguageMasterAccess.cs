﻿// -----------------------------------------------------------------------
// <copyright file="LanguageMasterAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Language Master Access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities;
    using Entities.Common;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for LanguageMaster
    /// </summary>
    public class LanguageMasterAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of LanguageMaster 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of AlarmMaster</returns>
        public static List<LanguageMaster> GetLanguageMasterDetails(DateTime lastSyncTimeInCentral)
        {
            List<LanguageMaster> languageMasterList = DbClient.ExecuteReader<LanguageMaster>(Resources.LanguageMaster,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return languageMasterList;
        }
    }
}
