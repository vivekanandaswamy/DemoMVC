﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasherAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Ecolab TextileCategory access class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.Washers.Conventional;
    using Nalco.Data.Common;

    /// <summary>
    /// Conventional Washer myService Access
    /// </summary>
    public class ConventionalWasherAccess : BaseAccess
    {
        /// <summary>
        ///     Save Conventional Washers In MyService
        /// </summary>
        /// <param name="conventionalWasher">washer details.</param>
        /// <returns>success/failure</returns>
        public static int SaveConventionalGeneralInMyService(ConventionalGeneral conventionalWasher)
        {
            int response = 0;

            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.ConventionalWasher,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("MyServiceWashersGuid", conventionalWasher.MyServiceCustMchGuid);
                    cmd.AddParameter("MyServiceWasherGroupGuid", conventionalWasher.MyServiceCustMchGrpGuid);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, conventionalWasher.EcolabAccountNumber);
                    cmd.AddParameter("MyServiceMCHId", conventionalWasher.MyServiceMCHId);
                    cmd.AddParameter("PlantWasherNumber", conventionalWasher.PlantWasherNumber);
                    cmd.AddParameter("MaxLoad", conventionalWasher.MaxLoad);
                    cmd.AddParameter("IsDeleted", conventionalWasher.IsDelete);
					cmd.AddParameter("CustMchName", DbType.String, 250, conventionalWasher.Name);
					cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, conventionalWasher.LastModifiedTimestamp);
                });
            return response;
        }

        public static List<ConventionalGeneral> GetConventionalDetails(System.Guid myServiceWasherGroupGuid, string ecolabAccountNumber, System.DateTime lastSyncTimeInCentral)
        {
            List<ConventionalGeneral> conventionalGeneralList = DbClient.ExecuteReader<ConventionalGeneral>(DEFAULT_AREA, Resources.GetConventionalWasher,
                         (cmd, dbContext) =>
                         {
                             cmd.AddParameter("MyServiceWasherGroupGuid", myServiceWasherGroupGuid);
                             cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                             cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                         }).ToList();

            return conventionalGeneralList;
        }

        public static void CreateVirtualController(string ecolabAccountNumber)
        {
            DbClient.ExecuteNonQuery(Resources.VirtualController,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
               });
        }

        public static bool IsWasherExist(string ecolabAccountNumber, Guid myServiceCustMchGuid)
        {
            return DbClient.ExecuteScalar<bool>(Resources.IsConventionalWasherExist,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                    cmd.AddParameter("MyServiceCustMchGuid", myServiceCustMchGuid);
                });
        }

        /// <summary>
        ///     Save Conventional Washers In MyService
        /// </summary>
        /// <param name="conventionalWasher">washer details.</param>
        /// <returns>success/failure</returns>
        public static int SaveConventionalGeneralInServiceItem(ConventionalGeneral conventionalWasher)
        {
            int response = 0;

            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SaveDataInServiceItem,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, conventionalWasher.EcolabAccountNumber);
                    cmd.AddParameter("MyServiceDispenserGUID", conventionalWasher.MyServiceCustMchGuid);    
                    cmd.AddParameter("ControllerName", DbType.String, 1000, conventionalWasher.Name);
                    cmd.AddParameter("SerialNo", DbType.String, 1000, Convert.ToString(conventionalWasher.PlantWasherNumber));
                    cmd.AddParameter("IsDelete", conventionalWasher.IsDeleted);
                    cmd.AddParameter("EntityType", DbType.String, 1000, "Conventional Washer");
                });
            return response;
        }
    }
}