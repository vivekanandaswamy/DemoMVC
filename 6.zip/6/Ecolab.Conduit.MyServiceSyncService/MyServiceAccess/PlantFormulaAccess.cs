﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The PlantFormula Access  class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Plant Formula Access
    /// </summary>
    public class PlantFormulaAccess : BaseAccess
    {
        /// <summary>
        ///     GetPlantFormulaDetails from Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>list of Formulas</returns>
        public static List<Formula> GetPlantFormulaDetails(String ecolabAccountNumber)
        {
            List<Formula> plantFormulaDetails =
                DbClient.ExecuteReader<Formula>(DEFAULT_AREA, Resources.PlantFormula,
                    (cmd, dbContext) =>
                    {
                    cmd.CommandTimeout = 0;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                    }).ToList();
            return plantFormulaDetails;
        }
    }
}