﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWasherAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Tunnel Washer Access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.Washers.Tunnel;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for WasherGroupsAccess
    /// </summary>
    public class TunnelWasherAccess : BaseAccess
    {
        /// <summary>
        /// Save List of Tunnel General in MyService.
        /// </summary>
        /// <param name="tunnelGeneral">The tunnel general.</param>
        /// <returns></returns>
        public static int SaveTunnelGeneralInMyService(TunnelGeneral tunnelGeneral)
        {
            int response = 0;

            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.InsertUpdateWasher,
                         (cmd, dbContext) =>
                         {
                             cmd.AddParameter("MyServiceWashersGuid", tunnelGeneral.MyServiceWashersGuid);
                             cmd.AddParameter("MyServiceWasherGroupGuid", tunnelGeneral.MyServiceWasherGroupGuid);
                             cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, tunnelGeneral.EcolabAccountNumber);
                             cmd.AddParameter("MyServiceMCHId", tunnelGeneral.MyServiceMCHId);
                             cmd.AddParameter("PlantWasherNumber", tunnelGeneral.PlantWasherNumber);
                             cmd.AddParameter("MaxLoad", tunnelGeneral.MaxLoad);
                             cmd.AddParameter("NoofCompartments", tunnelGeneral.NoofCompartments);
                             cmd.AddParameter("NoofTanks", tunnelGeneral.NoofTanks);
                             cmd.AddParameter("PressExtractorName", DbType.String, 1000, tunnelGeneral.PressExtractorName);
                             cmd.AddParameter("TransferTypeName", DbType.String, 1000, tunnelGeneral.TransferTypeName);
                             cmd.AddParameter("IsDeleted", tunnelGeneral.IsDelete);
                             cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, tunnelGeneral.LastModifiedTimestamp);
                         });

            return response;
        }

        /// <summary>
        /// Save List of Tunnel Compartment in MyService.
        /// </summary>
        /// <param name="tunnelComp">The tunnel comp.</param>
        /// <returns></returns>
        public static int SaveTunnelCompartment(TunnelCompartment tunnelComp)
        {
            int result = 0;

            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.InsertUpdateTunnelCompartment,
                       (cmd, dbContext) =>
                       {
                           cmd.AddParameter("CompartmentNumber", tunnelComp.CompartmentNumber);
                           cmd.AddParameter("MyServiceWasherGuid", tunnelComp.MyServiceWasherId);
                           cmd.AddParameter("WashStepId", tunnelComp.WashStepId);
                           cmd.AddParameter("MyServiceDrainLookUpId", tunnelComp.MyServiceDrainLookupId);
                           cmd.AddParameter("MyServiceTunnelWaterFlowTypeId", tunnelComp.MyServiceTunnelWaterFlowTypeId);
                           cmd.AddParameter("WaterLevel", tunnelComp.WaterLevel);
                           cmd.AddParameter("Iterationpoint", tunnelComp.Iterationpoint);
                           cmd.AddParameter("TempControlPMR", tunnelComp.TemperatureControlByPmr);
                           cmd.AddParameter("PressExtract", tunnelComp.UsePressExtractWater);
                           cmd.AddParameter("SplitCompartment", tunnelComp.SplitCompartment);
                           cmd.AddParameter("RecycleWaterInlet", tunnelComp.RecycledWaterInlet);
                           cmd.AddParameter("Steam", tunnelComp.Steam);
                           cmd.AddParameter("IsDeleted", tunnelComp.IsDeleted);
                           cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, tunnelComp.LastModifiedTimestamp);
                       });

            return result;
        }

        /// <summary>
        /// Get the List of TunnelGeneral
        /// </summary>
        /// <param name="myServiceWasherGroupGuid">My service washer group unique identifier.</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>
        /// List of TunnelGeneral
        /// </returns>
        public static TunnelGeneral GetTunnelGeneralDetails(Guid myServiceWasherGroupGuid, string ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            TunnelGeneral tunnelGeneral = DbClient.ExecuteReader<TunnelGeneral>(DEFAULT_AREA, Resources.GetTunnelWasher,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("MyServiceWasherGroupGuid", myServiceWasherGroupGuid);
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).FirstOrDefault();

            return tunnelGeneral;
        }

        /// <summary>
        /// Get the List of TunnelCompartment
        /// </summary>
        /// <param name="myServiceWasherId">MyServiceWasherId</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of TunnelCompartment</returns>
        public static List<TunnelCompartment> GetTunnelCompartmentList(Guid myServiceWasherId, string ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            List<TunnelCompartment> tunnelCompartmentList = DbClient.ExecuteReader<TunnelCompartment>(DEFAULT_AREA, Resources.GetTunnelCompartment,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("MyServiceWasherId", myServiceWasherId);
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return tunnelCompartmentList;
        }

        public static int GetMyServiceProdId(short controllerEquipmentSetupId, string ecolabAccNum)
        {
            return DbClient.ExecuteScalar<int>(Resources.MyServiceProdId,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("ControllerEquipmentSetupId", controllerEquipmentSetupId);
                              cmd.AddParameter("EcolabAccountNumber",DbType.String, 1000, ecolabAccNum);
                          });
        }

        public static int SaveTunnelDosingInMyservice(PumpAssociation pump, Guid myServiceWasherGroupId, short compartmentNumber)
        {
            int result = 0;

            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SaveTunnelCompartmentDosingProduct,
                       (cmd, dbContext) =>
                       {
                           cmd.AddParameter("MyServiceCmpmtDsgDvcguid", pump.MyServiceCmpmtDsgDvcGuid);
                           cmd.AddParameter("MyServiceWasherGroupId", myServiceWasherGroupId);
                           cmd.AddParameter("MyServiceProdId", pump.MyServiceProdId);
                           cmd.AddParameter("MyServiceWasherId", pump.MyServiceWasherGuid);
                           cmd.AddParameter("CompartmentNumber", compartmentNumber);
                           cmd.AddParameter("IsDelete", pump.Is_Deleted);
                           cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, pump.EcolabAccountNumber);
                       });

            return result;
        }

        public static List<PumpAssociation> GetPumpAssociationList(TunnelCompartment tunnelCompartment, Guid washerGroupGuid)
        {
            List<PumpAssociation> pumpAssociationList = DbClient.ExecuteReader<PumpAssociation>(DEFAULT_AREA, Resources.GetCompartmentProductDetails,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("MyServiceWasherGuid", tunnelCompartment.MyServiceWasherId);
                              cmd.AddParameter("CompartmentNumber", tunnelCompartment.CompartmentNumber);
                              cmd.AddParameter("MyServiceWasherGroupGuid", washerGroupGuid);
                          }).ToList();

            return pumpAssociationList;
        }

        public static short GetConduitWaterInletDrainId(short myServiceWaterInletId)
        {
            return DbClient.ExecuteScalar<Int16>(Resources.GetConduitWaterInletDrainId,
                         (cmd, dbContext) =>
                         {
                             cmd.AddParameter("MyServiceWaterInletId", myServiceWaterInletId);
                         });
        }

        public static short GetConduitWaterFlowId(short myServiceWaterFlowId)
        {
            return DbClient.ExecuteScalar<Int16>(Resources.GetConduitWaterFlowId,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("MyServiceWaterFlowId", myServiceWaterFlowId);
                          });
        }

        public static int GetConduitWashStepId(int myServiceWashStepId)
        {
            return DbClient.ExecuteScalar<int>(Resources.GetConduitWashStepId,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("MyServiceWashStepId", myServiceWashStepId);
                });
        }

		public static Int16 GetMyServiceWashOperationId(int washStepId, string ecolabAccountNumber)
		{
			return DbClient.ExecuteScalar<Int16>(Resources.GetMyserviceWashOperationId,
						 (cmd, dbContext) =>
						 {
							 cmd.AddParameter("WashStepId", washStepId);
							 cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
						 });
		}

        /// <summary>
        /// Saves the tunnelGeneral in ServiceItem
        /// </summary>
        /// <param name="tunnelGeneral">The tunnelGeneral.</param>
        /// <returns></returns>
        public static int SaveTunnelGeneralInServiceItem(TunnelGeneral tunnelGeneral)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveDataInServiceItem,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, tunnelGeneral.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceDispenserGUID", tunnelGeneral.MyServiceWashersGuid);
                   cmd.AddParameter("ControllerName", DbType.String, 1000, tunnelGeneral.Name);
                   cmd.AddParameter("SerialNo", DbType.String, 1000, Convert.ToString(tunnelGeneral.PlantWasherNumber));
                   cmd.AddParameter("IsDelete", tunnelGeneral.IsDeleted);
                   cmd.AddParameter("EntityType", DbType.String, 1000, "Tunnel");
               });
        }
    }
}