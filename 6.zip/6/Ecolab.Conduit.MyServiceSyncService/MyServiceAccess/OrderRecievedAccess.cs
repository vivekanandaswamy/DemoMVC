﻿// -----------------------------------------------------------------------
// <copyright file="OrderRecievedAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The OrderRecievedAccess </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Entities;
using Nalco.Data.Common;

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    public class OrderRecievedAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of WasherModelSize 
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>List of PlantContact</returns>
        public static List<OrderRecieved> GetOrderRecievedDetails(string ecolabAccountNumber, DateTime myServiceTime)
        {
            List<OrderRecieved> orderRecievedList = DbClient.ExecuteReader<OrderRecieved>(DEFAULT_AREA, Resources.OrderRecieved,
                          (cmd, dbContext) =>
                          {
                              cmd.CommandTimeout = 0;
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
							  cmd.AddParameter("Timestamp", DbType.DateTime, myServiceTime);
                          }).ToList();

            return orderRecievedList;
        }

    }
}
