﻿// -----------------------------------------------------------------------
// <copyright file="GasOilTypesAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Gas Oil TypesAccess</summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;

    /// <summary>
    ///     Access class for Gas oil types master data.
    /// </summary>
    public class GasOilTypesAccess : BaseAccess
    {
        /// <summary>
        /// GetGasoilTypesDetails
        /// </summary>
        /// <param name="lastSyncTimeInCentral">lastSyncTimeInCentral</param>
        /// <returns>List of Gas oil types data from my Service</returns>
        public static List<PlantutilityGasoilTypes> GetGasoilTypesDetails(DateTime lastSyncTimeInCentral)
        {
            List<PlantutilityGasoilTypes> gasOilTypesDetails =
                DbClient.ExecuteReader<PlantutilityGasoilTypes>(DEFAULT_AREA, Resources.GasOilTypes,
                    (cmd, dbContext) => cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral))
                    .ToList();

            return gasOilTypesDetails;
        }
    }
}