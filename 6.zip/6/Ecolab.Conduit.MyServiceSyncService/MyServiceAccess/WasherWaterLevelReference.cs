﻿// -----------------------------------------------------------------------
// <copyright file="WasherWaterLevelReferenceAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherWaterLevelReferenceAccess </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities;
    using Entities.Washers.Tunnel;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for Tunnel press extractor
    /// </summary>
    public class WasherWaterLevelReferenceAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of Tunnel press extractor
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>
        /// List of Tunnel press extractor
        /// </returns>
        public static List<WasherWaterLevelReference> GetWasherWaterLevelReferenceDetails(DateTime lastSyncTimeInCentral)
        {
            try
            {
                List<WasherWaterLevelReference> washerWaterLevelReference = DbClient.ExecuteReader<WasherWaterLevelReference>(DEFAULT_AREA, Resources.WasherWaterLevelReference,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

                return washerWaterLevelReference;
            }
            catch
            {
                throw;
            }         
        }
    }
}
