﻿// -----------------------------------------------------------------------
// <copyright file="TunnelTransferTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Tunnel TransferType Access </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.Washers.Tunnel;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for tunnel transfer type
    /// </summary>
    public class TunnelTransferTypeAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of Tunnel transfer type
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of Tunnel transfer type</returns>
        public static List<PressExtractor> GetTunnelTransferTypeDetails(DateTime lastSyncTimeInCentral)
        {
            List<PressExtractor> tunnelTransferType = DbClient.ExecuteReader<PressExtractor>(DEFAULT_AREA, Resources.TunnelTransferType,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return tunnelTransferType;
        }
    }
}
