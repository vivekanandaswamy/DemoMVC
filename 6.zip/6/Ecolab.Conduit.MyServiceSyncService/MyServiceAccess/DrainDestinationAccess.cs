﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Drain Destination Access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for DrainDestination
    /// </summary>
    public class DrainDestinationAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of DrainDestination 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of DrainDestination</returns>
        public static List<DrainDestination> GetDrainDestinationDetails(DateTime lastSyncTimeInCentral)
        {
            List<DrainDestination> drainDestinations = DbClient.ExecuteReader<DrainDestination>(DEFAULT_AREA, Resources.DrainDestination,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return drainDestinations;
        }
    }
}
