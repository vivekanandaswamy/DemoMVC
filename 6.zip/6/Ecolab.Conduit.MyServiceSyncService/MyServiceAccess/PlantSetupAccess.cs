﻿// -----------------------------------------------------------------------
// <copyright file="PlantSetupAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant setup access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Ecolab.Conduit.MyServiceSyncService.Model;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for PlantSetup
    /// </summary>
    public class PlantSetupAccess : BaseAccess
    {
        /// <summary>
        /// Get the list of plants
        /// </summary>
        /// <returns>plant list</returns>
        public static List<Plant> GetPlantList(DateTime lastSyncTime, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Plant>(DEFAULT_AREA, Resources.PlantSetup,
                           (cmd, dbContext) =>
                           {
                               cmd.CommandTimeout = 0;
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTime);
                           }).ToList();
        }

        /// <summary>
        /// Get the object of plant
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>Plant Object</returns>
        public static Plant GetPlantSetupDetails(string ecolabAccountNumber, DateTime? lastSyncTimeInCentral)
        {
            string region = null;
            Plant plant = DbClient.ExecuteReader<Plant>(DEFAULT_AREA, Resources.PlantSetup,
                           (cmd, dbContext) =>
                           {
                               cmd.CommandTimeout = 0;
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                               cmd.AddParameter("Region", DbType.String, 10, region);
                           }).FirstOrDefault();

            return plant;
        }

        /// <summary>
        /// Check plant is exist or not
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        /// <param name="inEnvision"></param>
        /// <returns></returns>
        public static bool IsPlantExists(string ecolabAccountNumber, bool inEnvision)
        {
            return DbClient.ExecuteScalar<bool>(Resources.IsPlantExists,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                    cmd.AddParameter("InEnvision", inEnvision);
                });
        }

        public static int SavePlantInEnvision(Plant plant, PlantCustomerAddress myservicePlantAddress, DbTransaction trans, DbContext context)
        {
            return DbClient.ExecuteScalar<int>(trans, context, Resources.SavePlantInEnvision,
                 (cmd, dbContext) =>
                 {
                     cmd.AddParameter("InEcolabAccountNumber", DbType.String, 1000, plant.EcoalabAccountNumber);
                     cmd.AddParameter("InPlantCountryCode", DbType.String, 10, plant.PlantCountryCode);
                     cmd.AddParameter("InPlantName", DbType.String, 55, plant.Name);
                     cmd.AddParameter("InAddress", DbType.String, 55, myservicePlantAddress.ShippingAddr1 + " " + myservicePlantAddress.ShippingAddr2);
                     cmd.AddParameter("InCity", DbType.String, 55, myservicePlantAddress.Shippingcity);
                     cmd.AddParameter("InState", DbType.String, 55, myservicePlantAddress.Shippingstate);
                     cmd.AddParameter("InZIPCode", DbType.String, 55, myservicePlantAddress.Shippingzip);
                     cmd.AddParameter("InSalesDistrict", DbType.String, 55, plant.SalesDistrict);
                     cmd.AddParameter("InSalesTerritory", DbType.String, 55, plant.SalesTerritory);
                     cmd.AddParameter("InCustomerName", DbType.String, 55, string.IsNullOrEmpty(plant.PlantChainName) ? plant.Name : plant.PlantChainName); 
                     cmd.AddParameter("InCompanyName", DbType.String, 55, string.IsNullOrEmpty(plant.PlantChainName) ? plant.Name : plant.PlantChainName);  
                     cmd.AddParameter("InLevelType", DbType.String, 10, "1");  
                 });
        }

        public static int UpdatePlantInEnvision(Plant plant, PlantCustomerAddress myservicePlantAddress, DbTransaction trans, DbContext context)
        {
            return DbClient.ExecuteScalar<int>(trans, context, Resources.UpdatePlantInEnvision,
                 (cmd, dbContext) =>
                 {
                     cmd.AddParameter("InEcolabAccountNumber", DbType.String, 1000, plant.EcoalabAccountNumber);
                     cmd.AddParameter("InPlantName", DbType.String, 55, plant.Name);
                     cmd.AddParameter("InAddress", DbType.String, 55, myservicePlantAddress.ShippingAddr1 + " " + myservicePlantAddress.ShippingAddr2);
                     cmd.AddParameter("InCity", DbType.String, 55, myservicePlantAddress.Shippingcity);
                     cmd.AddParameter("InState", DbType.String, 55, myservicePlantAddress.Shippingstate);
                     cmd.AddParameter("InZIPCode", DbType.String, 55, myservicePlantAddress.Shippingzip);
                 });
        }

        public static int GetLanguageIdFromCode(string myServiceLanguageCode)
        {
            return DbClient.ExecuteScalar<int>(Resources.GetConduitLanguageId,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("LanguageCode", DbType.String, 1000, myServiceLanguageCode);
               });
        }

        public static List<MyServicePlant> GetPlants()
        {
            return DbClient.ExecuteReader<MyServicePlant>(Resources.GetPlants,
              (cmd, dbContext) =>
              {
                  
              }).ToList();
        }

        public static void UpdatePlantSyncTime(string ecolabAccountNumber)
        {
            DbClient.ExecuteScalar<int>(Resources.UpdatePlantSyncTime,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                });
        }
    }
}
