﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerAddressAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant customer address access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for PlantCustomerAddress
    /// </summary>
    public class PlantCustomerAddressAccess : BaseAccess
    {
        /// <summary>
        /// Get the PlantCustomerAddress object
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>PlantCustomerAddress</returns>
        public static PlantCustomerAddress GetPlantCustomerAddress(string ecolabAccountNumber, DateTime? lastSyncTimeInCentral) 
        {
            PlantCustomerAddress plantAddress = DbClient.ExecuteReader<PlantCustomerAddress>(DEFAULT_AREA, Resources.PlantCustomerAddress,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000,  ecolabAccountNumber);
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);   
                           }).FirstOrDefault();

            return plantAddress;
        }
    }
}
