﻿// -----------------------------------------------------------------------
// <copyright file="EcolabSaturationAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Ecolab Saturation access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for EcolabSaturation
    /// </summary>
    public class EcolabSaturationAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of EcolabSaturation 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of EcolabSaturation</returns>
        public static List<EcolabSaturation> GetEcolabSaturationDetails(DateTime lastSyncTimeInCentral)
        {
            List<EcolabSaturation> ecolabSaturations = DbClient.ExecuteReader<EcolabSaturation>(DEFAULT_AREA, Resources.EcolabSaturation,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return ecolabSaturations;
        }
    }
}
