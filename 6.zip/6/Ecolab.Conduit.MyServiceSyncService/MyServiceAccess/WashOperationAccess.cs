﻿// -----------------------------------------------------------------------
// <copyright file="WashOperationAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The wash operation access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.WasherGroup;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for WashOperation
    /// </summary>
    public class WashOperationAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of WashOperation 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of WashOperation</returns>
        public static List<WashStep> GetWashOperationDetails(DateTime lastSyncTimeInCentral)
        {
            List<WashStep> washOperations = DbClient.ExecuteReader<WashStep>(DEFAULT_AREA, Resources.WashOperation,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return washOperations;
        }
    }
}
