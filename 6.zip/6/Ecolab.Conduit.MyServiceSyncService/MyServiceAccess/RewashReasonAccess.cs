﻿// -----------------------------------------------------------------------
// <copyright file="RewashReasonAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RewashReasonAccess </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.ManualInput.Rewash;
using Nalco.Data.Common;

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    public class RewashReasonAccess
    {
        /// <summary>
        /// Get the List of ProductMaster
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>
        /// List of ProductMaster
        /// </returns>
        public static List<RewashReason> FetchRewashReasonForSync(DateTime lastSyncTimeInCentral)
        {
            List<RewashReason> rewashReasonColl = DbClient.ExecuteReader<RewashReason>(Resources.FetchRewashReason,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("@TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return rewashReasonColl;
        }
    }
}
