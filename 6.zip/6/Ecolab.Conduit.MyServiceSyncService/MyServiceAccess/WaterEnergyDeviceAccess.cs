﻿// -----------------------------------------------------------------------
// <copyright file="WaterEnergyDeviceAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The WaterEnergyDevice access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Entities.PlantSetup;
    using Entities.WasherGroup;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for WaterEnergyDevice
    /// </summary>
    public class WaterEnergyDeviceAccess : BaseAccess
    {
        /// <summary>
        /// Saves the water energy device.
        /// </summary>
        /// <param name="waterEnergyDevice">The water energy device.</param>
        /// <returns></returns>
        public static int SaveWaterEnergyDevice(Utility waterEnergyDevice)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveWaterEnergyDevice,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, waterEnergyDevice.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceCustWtrEnrgDvcGuid", waterEnergyDevice.MyServiceCustWtrEnrgDvcGUID);
                   cmd.AddParameter("WaterEnergyDeviceId", waterEnergyDevice.DeviceModelId);
                   cmd.AddParameter("WaterEnergyDeviceNo", waterEnergyDevice.DeviceNumber);
                   cmd.AddParameter("InstallDate", DbType.DateTime,waterEnergyDevice.InstallDate);
                   cmd.AddParameter("Comment", DbType.String, 1000, waterEnergyDevice.Comment);
                   cmd.AddParameter("IsDelete", waterEnergyDevice.IsDeleted);
               });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ecolabAccountNumber"></param>
        /// <param name="myServiceTime"></param>
        /// <returns></returns>
        public static List<Utility> GetWaterEnergyDevice(string ecolabAccountNumber, DateTime myServiceTime)
        {
            return DbClient.ExecuteReader<Utility>(DEFAULT_AREA, Resources.WaterEnergyDevice,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                              cmd.AddParameter("TimeStamp", DbType.DateTime, myServiceTime);
                          }).ToList();
        }

        /// <summary>
        /// Check water and energy device already exist or not
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="myServiceCustWtrEnrgDvcGUID">MyServiceCustWtrEnrgDvcGUID</param>
        /// <returns>true if exist otherwise false</returns>
        public static bool IsWaterAndEnergyDeviceExist(string ecolabAccountNumber, Guid myServiceCustWtrEnrgDvcGUID)
        {
            return DbClient.ExecuteScalar<bool>(Resources.IsWaterAndEnergyDeviceExist,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                   cmd.AddParameter("MyServiceCustWtrEnrgDvcGUID", myServiceCustWtrEnrgDvcGUID);
               });
        }

        /// <summary>
        /// Saves the water energy device in ServiceItem
        /// </summary>
        /// <param name="waterEnergyDevice">The water energy device.</param>
        /// <returns></returns>
        public static int SaveWEDataInServiceItem(Utility waterEnergyDevice)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveDataInServiceItem,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, waterEnergyDevice.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceDispenserGUID", waterEnergyDevice.MyServiceCustWtrEnrgDvcGUID);
                   cmd.AddParameter("ControllerName", DbType.String, 1000, waterEnergyDevice.DeviceName);
                   cmd.AddParameter("SerialNo",DbType.String,1000, Convert.ToString(waterEnergyDevice.DeviceNumber));
                   cmd.AddParameter("IsDelete", waterEnergyDevice.IsDeleted);
                   cmd.AddParameter("EntityType", DbType.String, 1000, "Water & Energy Device");
               });
        }
    }
}
