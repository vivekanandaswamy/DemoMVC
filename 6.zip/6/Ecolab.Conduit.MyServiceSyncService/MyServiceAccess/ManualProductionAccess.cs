﻿// -----------------------------------------------------------------------
// <copyright file="ManualProductionAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ManualProductionAccess class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Linq;
	using Entities;
	using Nalco.Data.Common;

	/// <summary>
	/// Plant Formula Access
	/// </summary>
	public class ManualProductionAccess : BaseAccess
	{
        /// <summary>
        /// GetMyServiceManualProductionDetails
        /// </summary>
        /// <param name="ecolabAccountNumber">The Plant Number</param>
        /// <param name="myServiceTime">The myService</param>
        /// <returns>
        /// Get the manual production details
        /// </returns>
        public static List<MyServiceManualProduction> GetMyServiceManualProductionDetails(string ecolabAccountNumber, DateTime myServiceTime)
		{
			List<MyServiceManualProduction> myServiceManualProduction =
				DbClient.ExecuteReader<MyServiceManualProduction>(DEFAULT_AREA, Resources.GetManualProductionDetails, (cmd, dbContext) =>
				{
					cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
					cmd.AddParameter("TimeStamp", DbType.DateTime, myServiceTime);
				}).ToList();
			return myServiceManualProduction;
		}
	}
}