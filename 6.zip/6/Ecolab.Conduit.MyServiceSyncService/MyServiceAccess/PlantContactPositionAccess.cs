﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactPositionAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant contact access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Entities.Common;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for PlantContactPosition
    /// </summary>
    class PlantContactPositionAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of PlantContact
        /// </summary>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <returns>
        /// List of PlantContact
        /// </returns>
        public static List<PlantContactPosition> GetPlantContactPositionDetails(DateTime lastSyncTime)
        {
            return DbClient.ExecuteReader<PlantContactPosition>(DEFAULT_AREA, Resources.PlantContactPosition,
             (cmd, dbContext) =>
             {
                 cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTime);
             }).ToList();
        }        
    }
}
