﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasherFormulaAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ConventionalWasherFormula access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.WasherGroup;
    using Nalco.Data.Common;
    using Entities.Washers.Conventional;

    /// <summary>
    /// Access class for ConventionalWasherFormula
    /// </summary>
    public class ConventionalWasherFormulaAccess : BaseAccess
    {
        /// <summary>
        /// SaveWasherGroupFormula
        /// </summary>
        /// <param name="washerGroupFormula">washerGroupFormula</param>
        /// <param name="washerGroup">washerGroup</param>
        public static int SaveWasherGroupFormula(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveWasherGroupFormula,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                   cmd.AddParameter("MyServiceWasherGroupGuid", washerGroup.MyServiceWasherGroupGuid);
                   cmd.AddParameter("NominalLoad", washerGroupFormula.NominalLoad);
                   cmd.AddParameter("IsDelete", washerGroupFormula.IsDelete);
                   cmd.AddParameter("ProgramName", DbType.String, 1000, washerGroupFormula.ProductName);
                   cmd.AddParameter("ProgramNumber", washerGroupFormula.ProgramNumber);
                   cmd.AddParameter("MyServiceMstrLnnTypId", washerGroupFormula.MyServiceMstrLnnTypId);
                   cmd.AddParameter("MyServiceSaturationTypeId", washerGroupFormula.MyServiceSaturationTypeId);
               });
        }

        /// <summary>
        /// SaveWasherFormulaWashStep
        /// </summary>
        /// <param name="washerFormulaWashStep">washerFormulaWashStep</param>
        /// <param name="washerGroupFormula">washerGroupFormula</param>
        /// <param name="washerGroup">washerGroup</param>
        /// <returns>id</returns>
        public static int SaveWasherFormulaWashStep(WasherFormulaWashStep washerFormulaWashStep, WasherGroupFormula washerGroupFormula, WasherGroup washerGroup)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveWasherFormulaWashStep,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                   cmd.AddParameter("MyServiceCusrFrmulaStpGuid", washerFormulaWashStep.MyServiceCusrFrmulaStpGuid);
                   cmd.AddParameter("StepNumber", washerFormulaWashStep.StepNumber);
                   cmd.AddParameter("MyServiceWashOprId", washerFormulaWashStep.MyServiceWshOpId);
                   cmd.AddParameter("MyServiceWaterTypeId", washerFormulaWashStep.MyServiceUtilId);
                   cmd.AddParameter("MyServiceDrainTypId", washerFormulaWashStep.MyServiceDrainTypId);
                   cmd.AddParameter("RunTime", washerFormulaWashStep.Runtime);
                   cmd.AddParameter("Temperature", washerFormulaWashStep.Temperature);
                   cmd.AddParameter("WaterLevel", washerFormulaWashStep.WaterLevel); 
                   cmd.AddParameter("PhLevel", washerFormulaWashStep.PhLevel);
                   cmd.AddParameter("IsDelete", washerFormulaWashStep.IsDelete);
               });
        }

        /// <summary>
        /// SaveWasherDosingProduct
        /// </summary>
        /// <param name="washerDosingProduct">washerDosingProduct</param>
        /// <param name="washerFormulaWashStep">washerFormulaWashStep</param>
        /// <param name="washerGroupFormula">washerGroupFormula</param>
        /// <param name="washerGroup">washerGroup</param>
        /// <returns>id</returns>
        public static int SaveWasherDosingProduct(WasherDosingProduct washerDosingProduct, WasherFormulaWashStep washerFormulaWashStep, WasherGroupFormula washerGroupFormula, WasherGroup washerGroup, int myServiceProdId)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveWasherDosingProduct,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("MyServiceFrmulaStpDsgDvcGUID", washerDosingProduct.MyServiceFrmulaStpDsgDvcGUID);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                    cmd.AddParameter("MyServiceWasherGroupId", washerGroup.MyServiceWasherGroupGuid);
                    cmd.AddParameter("MyServiceProdId", myServiceProdId);
                    cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                    cmd.AddParameter("MyServiceCusrFrmulaStpGuid", washerFormulaWashStep.MyServiceCusrFrmulaStpGuid);
                    cmd.AddParameter("Quantity", washerDosingProduct.Quantity);
                    cmd.AddParameter("IsDelete", washerDosingProduct.IsDeleted);
                });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="myServiceTime">myServiceTime</param>
        /// <param name="custMchGrpGuid">custMchGrpGuid</param>
        /// <returns>list of washerGroup Formula</returns>
        public static List<WasherGroupFormula> GetWasherGroupFormula(string ecolabAccountNumber, DateTime myServiceTime, Guid custMchGrpGuid)
        {
            return DbClient.ExecuteReader<WasherGroupFormula>(DEFAULT_AREA, Resources.ConventionalWasherProgramSetup,
                          (cmd, dbContext) =>
                          {
                              cmd.CommandTimeout = 0;
                              cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                              cmd.AddParameter("TimeStamp", DbType.DateTime, myServiceTime);
                              cmd.AddParameter("CustMchGrpGuid", custMchGrpGuid);
                          }).ToList();
        }

        /// <summary>
        /// GetWasherGroupFormulaWashSteps
        /// </summary>
        /// <param name="myServiceCustFrmulaMchGrpGUID">myServiceCustFrmulaMchGrpGUID</param>
        /// <returns>list of washer formula</returns>
        public static List<WasherFormulaWashStep> GetWasherGroupFormulaWashSteps(Guid myServiceCustFrmulaMchGrpGUID)
        {
            return DbClient.ExecuteReader<WasherFormulaWashStep>(DEFAULT_AREA, Resources.ConventionalWasherFormulaWashStep,
                         (cmd, dbContext) =>
                         {
                             cmd.CommandTimeout = 0;
                             cmd.AddParameter("MyServiceCustFrmulaMchGrpGUID", myServiceCustFrmulaMchGrpGUID);
                         }).ToList();
        }

        /// <summary>
        /// GetWasherDosingProducts
        /// </summary>
        /// <param name="myServiceCusrFrmulaStpGuid">myServiceCusrFrmulaStpGuid</param>
        /// <returns></returns>
        public static List<WasherDosingProduct> GetWasherDosingProducts(Guid myServiceCusrFrmulaStpGuid)
        {
            return DbClient.ExecuteReader<WasherDosingProduct>(DEFAULT_AREA, Resources.ConventionalWasherDosingProduct,
                        (cmd, dbContext) =>
                        {
                            cmd.CommandTimeout = 0;
                            cmd.AddParameter("MyServiceCustFrmulaStpGUID", myServiceCusrFrmulaStpGuid);
                        }).ToList();
        }

        /// <summary>
        /// Update proposed formula to current
        /// </summary>
        /// <param name="washerGroupFormula">formula details</param>
        public static int UpdateProposedToCurrentFormula(WasherGroupFormula washerGroupFormula)
        {
            return DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.UpdateFormulaInMyservice,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("InCustFrmulaMchGrpGUID", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
               });
        }

        public static int GetMyServiceProductId(int productId)
        {
            return DbClient.ExecuteScalar<int>(Resources.MyServiceProductIdFromProductMaster,
               (cmd, dbContext) =>
               {
                   cmd.CommandTimeout = 0;
                   cmd.AddParameter("ProductId", productId);
               });
        }
        /// <summary>
        /// SaveFormulaMachineRefrenceInMyService
        /// </summary>
        /// <param name="washerGroupFormula">washerGroupFormula</param>
        /// <param name="washerGroup">washerGroup</param>
        /// <param name="item">item</param>
        public static void SaveFormulaMachineRefrenceInMyService(WasherGroupFormula washerGroupFormula, WasherGroup washerGroup, ConventionalGeneral item)
        {
            int soilWgt = ((washerGroupFormula.NominalLoad * item.MaxLoad) / 100);

            DbClient.ExecuteScalar<int>(DEFAULT_AREA, Resources.SaveFormulaMachineRefrenceInMyService,
               (cmd, dbContext) =>
               {
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, washerGroup.EcolabAccountNumber);
                   cmd.AddParameter("MyServiceCustFrmulaMchGrpGuid", washerGroupFormula.MyServiceCustFrmulaMchGrpGUID);
                   cmd.AddParameter("MyServiceWasherGroupGuid", washerGroup.MyServiceWasherGroupGuid);
                   cmd.AddParameter("SoilWgtPctg", washerGroupFormula.NominalLoad);
                   cmd.AddParameter("SoilWgt", soilWgt);
                   cmd.AddParameter("MyServiceMchGuid", item.MyServiceCustMchGuid);
                   cmd.AddParameter("SoilWgtUomCode", DbType.String, 100, item.MaxLoad_UOMCode);                   
               });
        }        
    }
}
