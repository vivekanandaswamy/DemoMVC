SELECT 
	p.EcolabAccountNumber
,	p.SyncedDate
,	p.Active
FROM TCD.SyncPlant p