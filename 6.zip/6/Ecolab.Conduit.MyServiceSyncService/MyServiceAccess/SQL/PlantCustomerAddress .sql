--Plant Cust Address...
--Check, if any of the Shipping or Billing address record has been updated, only then fetch the data...
IF	EXISTS	(	SELECT	1
				FROM	CUST_ADDR				CA
				JOIN	ADDR_TYP_REF			ATR
					ON	CA.ADDR_TYP_ID			=			ATR.ADDR_TYP_ID
					AND	ATR.ADDR_TYP_NM			IN			(	'Bill To Address',	'Ship To Address'	)
				WHERE	CA.CUST_GUID			=			(
															SELECT	TOP 1
																	C.CUST_GUID
															FROM	CUST					C
															WHERE	C.CUST_ACCT_NBR			=			@EcolabAccountNumber
																AND	C.CUST_TYP_ID			=			1
															ORDER BY
																	C.CUST_GUID
															)
					AND	CA.ROW_STAT_IND			=			'A'
					AND	CA.MOD_DTTM				>=			ISNULL(@TimeStamp, '01 Jan 1900')
			)
		BEGIN
				SELECT	TOP 1
						@EcolabAccountNumber					AS			EcolabAccountNumber
					,	BA.ADDR_LN_1							AS			BillingAddr1
					,	BA.ADDR_LN_2_3							AS			BillingAddr2
					,	BA.CTY_NM								AS			City
					,	BA.ST_PROV_NM							AS			[State]
					,	BA.CNTRY_NM								AS			Country
					,	BA.POST_CD								AS			Zip

					,	SA.ADDR_LN_1							AS			ShippingAddr1
					,	SA.ADDR_LN_2_3							AS			ShippingAddr2
					,	SA.CTY_NM								AS			ShippingCity
					,	SA.ST_PROV_NM							AS			ShippingState
					,	SA.CNTRY_NM								AS			ShippingCountry
					,	SA.POST_CD								AS			ShippingZip
					--We may not require these (below)...
					,	BA.MOD_DTTM								AS			MyServiceBillingAddressModDtTm
					,	SA.MOD_DTTM								AS			MyServiceShippingAddressModDtTm
				FROM	CUST									C
				LEFT JOIN
						(
						SELECT	CA.CUST_GUID					AS			CUST_GUID
							,	CA.ADDR_LN_1					AS			ADDR_LN_1
							,	ISNULL(CA.ADDR_LN_2, '') +
								ISNULL(CA.ADDR_LN_3, '')		AS			ADDR_LN_2_3
							,	CTY_NM							AS			CTY_NM
							,	POST_CD							AS			POST_CD
							,	SPR.ST_PROV_NM					AS			ST_PROV_NM
							,	CR.CNTRY_NM						AS			CNTRY_NM
							,	CA.CUST_ADDR_GUID				AS			CUST_ADDR_GUID
							,	CA.MOD_DTTM						AS			MOD_DTTM
						FROM	CUST_ADDR						CA
						JOIN	ADDR_TYP_REF					ATR
							ON	CA.ADDR_TYP_ID					=			ATR.ADDR_TYP_ID
						LEFT JOIN
								CNTRY_REF						CR
							ON	CA.CNTRY_ID						=			CR.CNTRY_ID
						LEFT JOIN
								ST_PROV_REF						SPR
							ON	CA.ST_ID						=			SPR.ST_ID
							AND	CA.CNTRY_ID						=			SPR.CNTRY_ID
						WHERE	ATR.ADDR_TYP_NM					=			'Bill To Address'
							AND	CA.ROW_STAT_IND					=			'A'
						)		BA
					ON	C.CUST_GUID								=			BA.CUST_GUID
				LEFT JOIN
						(
						SELECT	CA.CUST_GUID					AS			CUST_GUID
							,	CA.ADDR_LN_1					AS			ADDR_LN_1
							,	ISNULL(CA.ADDR_LN_2, '') +
								ISNULL(CA.ADDR_LN_3, '')		AS			ADDR_LN_2_3
							,	CTY_NM							AS			CTY_NM
							,	POST_CD							AS			POST_CD
							,	SPR.ST_PROV_NM					AS			ST_PROV_NM
							,	CR.CNTRY_NM						AS			CNTRY_NM
							,	CA.CUST_ADDR_GUID				AS			CUST_ADDR_GUID
							,	CA.MOD_DTTM						AS			MOD_DTTM
						FROM	CUST_ADDR						CA
						JOIN	ADDR_TYP_REF					ATR
							ON	CA.ADDR_TYP_ID					=			ATR.ADDR_TYP_ID
						LEFT JOIN
								CNTRY_REF						CR
							ON	CA.CNTRY_ID						=			CR.CNTRY_ID
						LEFT JOIN
								ST_PROV_REF						SPR
							ON	CA.ST_ID						=			SPR.ST_ID
							AND	CA.CNTRY_ID						=			SPR.CNTRY_ID
						WHERE	ATR.ADDR_TYP_NM					=			'Ship To Address'
							AND	CA.ROW_STAT_IND					=			'A'
						)		SA
					ON	C.CUST_GUID								=			SA.CUST_GUID
				WHERE	C.CUST_ACCT_NBR							=			@EcolabAccountNumber
					AND	C.CUST_TYP_ID							=			1
		END

