--Script to save Plant data (along with Customer, Company) to enVision schema.
SET	NOCOUNT	ON


DECLARE	
	--	input variables
		--Facility details
--		@InEcolabAccountNumber					NVARCHAR(1000)			=			NULL			--Key for Plant (Facility) from Conduit; also value for SoldTo, ShipTo
--	,	@InPlantCountryCode						CHAR(2)					=			NULL
--	,	@InPlantName							NVARCHAR(55)			=			NULL			--input for FacilityName, FacilityName2
--	,	@InAddress								NVARCHAR(150)			=			NULL			--input for Address
--	,	@InCity									NVARCHAR(50)			=			NULL			--input for City
--	,	@InState								NVARCHAR(50)			=			NULL			--input for State
--	,	@InZIPCode								NVARCHAR(50)			=			NULL			--input for ZIPCode
		@InUserId								INT						=			NULL			--input for CreatedBy, ModifiedBy
--	,	@InSalesDistrict						VARCHAR(50)				=			NULL			--input for SalesDistrict
--	,	@InSalesTerritory						NVARCHAR(250)			=			NULL			--input for SalesTerritory
		--Customer details
--	,	@InCustomerName							NVARCHAR(50)			=			NULL			--Key for Customer; input for CustomerName
		--Company details
--	,	@InCompanyName							NVARCHAR(250)			=			NULL			--Key for Company; input for CompanyName
--	,	@InLevelType							VARCHAR(10)				=			NULL			--input for LevelType - 1/2
--	,	@InParentCompanyName					NVARCHAR(250)			=			NULL			--input for parent company
--	,	@InDisplayCompanyName					NVARCHAR(250)			=			NULL			--input for company display name, 
																									--It is not required as company name and display name are same

	--	other script variables
	,	@CustomerId								INT						=			NULL			--To be set based on input CustomerName
	
	,	@CompanyId								INT						=			NULL			--To be set based on input CompanyName
	,	@ParentCompanyId						INT						=			NULL			--To be set based on input ParentCompanyName

	--	master data in enVision schema
	,	@PlantCountryId							INT						=			NULL			--To be set based on input PlantCountryCode
	,	@SourceId								INT						=			NULL			--Id in ERPSource in enVision for 'myService'
	
	,	@TimeStamp								DATETIME				=			GETDATE()

	--	Script variable
	,	@ScriptError							INT						=			0				--To be returned back, if non-0, implies some error; rollback

	--	output variable



--Setting user id based on 'Admin_Tool' userlogin
SET		@InUserId								=				(
																SELECT	TOP	1
																		UM.UserId
																FROM	dbo.UserMaster			UM
																WHERE	UM.UserLogin			=			'Admin_Tool'
																ORDER BY
																		UM.UserId
																)


--Get/Set master data Ids...

	--Get CountryId based on CountryCode input
SET		@PlantCountryId							=			(
															SELECT	CM.CountryID
															FROM	dbo.CountryMaster			CM
															WHERE	CM.CountryCode				=			@InPlantCountryCode
															)

SET		@SourceId								=			(
															SELECT	ES.SourceId
															FROM	dbo.ERPSources				ES
															WHERE	SourceName					=			'myService'
															)
--any other above this



--First get customerId or insert a new entry for it...
SELECT	TOP	1
		@CustomerId					=			CM.CustomerID
FROM	dbo.CustomerMaster			CM
WHERE	CM.CustomerName				=			@InCustomerName
ORDER By
		CM.CustomerId

--check for valid customer Id
IF	(@CustomerId	IS	NULL)
	BEGIN
			INSERT	INTO	dbo.CustomerMaster	(
						--	CustomerID													--Will be auto-generated
							CustomerName
						,	CustomerName2
						,	CreatedBy
						,	CreatedOn
						,	ModifiedBy
						,	ModifiedOn
						)
				SELECT
						--	CustomerId													--Will be auto-generated
							@InCustomerName				AS			CustomerName
						,	@InCustomerName				AS			CustomerName2
						,	@InUserId					AS			CreatedBy
						,	@TimeStamp					AS			CreatedOn
						,	@InUserId					AS			ModifiedBy
						,	@TimeStamp					AS			ModifiedOn

			--Capture any error Script
			SET		@ScriptError			=			@@ERROR

			--if any error, return
			IF	(	@ScriptError			<>			0)
				BEGIN
						SELECT	@ScriptError
						RETURN	--return from script
				END

			SET		@CustomerId			=			SCOPE_IDENTITY()
	END


--Now, get CompanyId or insert a new entry for it...
SELECT	TOP	1
		@CompanyId					=			C.CompanyId
FROM	dbo.Company					C
WHERE	C.CompanyName				=			@InCompanyName
ORDER BY
		C.CompanyId

--check for valid Company Id
IF	(@CompanyId	IS	NULL)
	BEGIN
			--Insert a new Company entry...
			
				INSERT	INTO	dbo.Company	(
							--	CompanyId
								CompanyName
							,	LevelType
							,	DisplayCompanyName
							,	[Weight]
							)
					SELECT	
							--	CompanyId															--auto-generated
								@InCompanyName					AS			CompanyName
							,	@InLevelType					AS			LevelType
							,	@InCompanyName					AS			DisplayCompanyName
							,	1								AS			[Weight]				--default 1

				--Capture any error Script
				SET		@ScriptError			=			@@ERROR

				--if any error, return
				IF	(	@ScriptError			<>			0)
					BEGIN
							SELECT	@ScriptError
							RETURN	--return from script
					END
				
				SET		@CompanyId			=			SCOPE_IDENTITY()
	END

IF NOT EXISTS (SELECT 1 FROM dbo.KeyAccounts ka WHERE ka.KEYACCNAME = @InCompanyName)
	BEGIN
		INSERT INTO dbo.KeyAccounts
		(
		    --KEYACCID - this column value is auto-generated
		    dbo.KeyAccounts.KEYACCNAME,
		    dbo.KeyAccounts.KeyAccountCode
		)
		VALUES
		(
		    -- KEYACCID - int
		    @InCompanyName, -- KEYACCNAME - nvarchar
		    NULL -- KeyAccountCode - varchar
		)
	END


--Now, insert into Customer x Company i.e.	Company_CustomerMaster
IF	NOT	EXISTS	(
				SELECT	1
				FROM	dbo.Company_CustomerMaster			CCM
				WHERE	CCM.CompanyId						=			@CompanyId
					AND	CCM.CustomerId						=			@CustomerId
				)
		BEGIN
				INSERT	INTO	dbo.Company_CustomerMaster	(
								CompanyId
							,	CustomerId
							)
					SELECT
								@CompanyId					AS			CompanyId
							,	@CustomerId					AS			CustomerId

				--Capture any error Script
				SET		@ScriptError			=			@@ERROR

				--if any error, return
				IF	(	@ScriptError			<>			0)
					BEGIN
							SELECT	@ScriptError
							RETURN	--return from script
					END
		END


--We can now insert the actual data...
--into FacilityMaster

INSERT	INTO	dbo.FacilityMaster	(
			--	FacilityID														--auto-generated Id
				CustomerID
			,	CountryID
			,	FacilityName
			,	FacilityName2
			,	[Address]
			,	City
			,	[State]
			,	[ZIPCode]
			,	CreatedBy
			,	CreatedOn
			,	ModifiedBy
			,	ModifiedOn
			,	SoldTo
			,	ShipTo
			,	SalesDistrict
			,	SalesTerritory
			,	SourceID
			)
	SELECT
			--	FacilityId
				@CustomerId					AS			CustomerId
			,	@PlantCountryId				AS			CountryId
			,	@InPlantName				AS			FacilityName
			,	@InPlantName				AS			FacilityName2
			,	@InAddress					AS			[Address]
			,	@InCity						AS			City
			,	@InState					AS			[State]
			,	@InZIPCode					AS			[ZIPCode]
			,	@InUserId					AS			CreatedBy
			,	@Timestamp					AS			CreatedOn
			,	@InUserId					AS			ModifiedBy
			,	@Timestamp					AS			ModifiedOn
			,	@InEcolabAccountNumber		AS			SoldTo
			,	@InEcolabAccountNumber		AS			ShipTo
			,	@InSalesDistrict			AS			SalesDistrict
			,	@InSalesTerritory			AS			SalesTerritory
			,	@SourceId					AS			SourceId

--Capture any error Script
SET		@ScriptError			=			@@ERROR

--Either ways - error or none, select error value and return
SELECT	@ScriptError


SET	NOCOUNT	OFF


RETURN			--return from script