--Washer Groups formula steps (Tunnel)
/*
DECLARE	@MyServiceCustFrmulaMchGrpGUID			UNIQUEIDENTIFIER			--MyService GUID for WG 2 Frmla association from TPS
	,	@TimeStamp								DATETIME


SET		@MyServiceCustFrmulaMchGrpGUID			=			'E1F119CA-9D91-45B7-87D5-0B5AD316B2AC'
SET		@TimeStamp								=			'01 Jan 1900'
*/

--We need to fetch the Water Level based on Region (Modified on -8/9/2016, Modified By: Veerabhadra Kattamudi)
DECLARE @RGN_CD varchar(10)

SELECT @RGN_CD=RGN_CD FROM CUST 
		WHERE CUST_GUID= 
						(SELECT TOP 1 CUST_GUID FROM CUST_FRMULA_MCH_GRP_XREF Where CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGUID)

SELECT	--TOP 10
	--*	,
	--														TunnelDosingSetupId					--Conduit generated Id
	--														EcolabAccountNumber					--Conduit EcolabAccountNumber
	--														TunnelProgramSetupId				--Id from TPS based on the parameter @MyServiceCustFrmulaMchGrpGUID
	--														GroupId								--Conduit WasherGroupId from TPS
	--														ProgramNumber						--Conduit ProgramNumber from TPS
		FS.WSH_OP_ID							AS			StepTypeId							--To be translated to Conduit's WashStepId (from WashStep)
	,	FS.WSH_OP_TM							AS			StepRunTime
	,	FS.FRMULA_STP_NBR						AS			CompartmentNumber
	--														Delay								--No
	--														DosingNumber						--No
	--Temperature with UOM
	,	FS.WSH_OP_TEMP							AS			Temperature
	,	UR_WOTemp.UOM_CD						AS			Temperature_UOMCode

	,	FS.WTR_TYP_ID							AS			WaterType							--To be translated to Conduit's Id (from WaterType)
	
	--WaterLevel with UOM
	, CASE WHEN @RGN_CD='NA' THEN	FS.WSH_OP_WTR_LVL
		   WHEN @RGN_CD='EMEA' THEN	FS.WSH_OP_WTR_VOL END					AS			WaterLevel
	,	UR_WtrLvl.UOM_CD						AS			WaterLevel_UOMCode
	--Drain destination
	,	FS.DRAIN_DEST_ID						AS			DrainDestinationId					--We cannot use this unless we Synch this table
	--,	DTR.DRAIN_TYP_NM						AS			DrainDestinationName				--This may not be reqd. now
	,	NULL									AS			WaterInletDrain						--This has a broken reference; Not available in myService primary source
	--,	FS.PH_PROBE_LVL							AS			pHLevel								--NOt to be synch'd
	,	FS.CMNT_TXT								AS			Note
	,	CAST	(
				CASE	FS.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)								AS			Is_Deleted
	,	FS.CUST_FRMULA_STP_GUID					AS			MyServiceCustFrmulaStpGUID
	,	FS.MOD_DTTM								AS			MyServiceModDtTm
FROM	CUST_FRMULA_MCH_GRP_XREF				FMGX
JOIN	CUST_FRMULA_STP							FS
	ON	FMGX.CUST_FRMULA_GUID					=			FS.CUST_FRMULA_GUID
LEFT JOIN
		UOM_REF									UR_WOTemp
	ON	FS.WSH_OP_TEMP_UOM_ID					=			UR_WOTemp.UOM_ID
LEFT JOIN
		UOM_REF									UR_WtrLvl
	ON  CASE WHEN @RGN_CD='NA' THEN	FS.WSH_OP_WTR_LVL_UOM_ID				
		   WHEN @RGN_CD='EMEA' THEN	FS.WSH_OP_WTR_VOL_UOM_ID END =	UR_WtrLvl.UOM_ID
LEFT JOIN
		DRAIN_TYP_REF							DTR
	ON	FS.DRAIN_DEST_ID						=			DTR.DRAIN_TYP_ID
--JOIN	WSH_OP_REF								WOR
--	ON	FS.WSH_OP_ID							=			WOR.WSH_OP_ID
WHERE	FMGX.CUST_FRMULA_MCH_GRP_GUID			=			@MyServiceCustFrmulaMchGrpGUID
	AND	FMGX.ASSN_TYP_CD						=			'G'
	AND	EXISTS									(			SELECT	1
															FROM	CUST_MCH_GRP			MG
															JOIN	MCH_TYP_REF				MTR
																ON	MG.MCH_GRP_TYP			=			MTR.MCH_TYP_ID
																AND	MTR.MCH_TYP_NM			=			'Tunnel'
															WHERE	MG.CUST_GUID			=			FMGX.CUST_GUID
																AND	MG.CUST_MCH_GRP_GUID	=			FMGX.CUST_MCH_GRP_GUID
																AND	MG.CUST_MCH_GRP_NBR		<>			0
												)
	AND	EXISTS									(			SELECT	1
															FROM	CUST					C
															WHERE	C.CUST_GUID				=			FMGX.CUST_GUID
																AND	C.CUST_TYP_ID			=			1
												)
	AND	EXISTS									(			SELECT	1
															FROM	CUST_FRMULA_REF			F
															WHERE	F.CUST_GUID				=			FMGX.CUST_GUID
																AND	F.CUST_FRMULA_GUID		=			FMGX.CUST_FRMULA_GUID
																--AND	F.FRMULA_TYP_ID			=			3
																--Commenting the above and replacing with new condn. for Current and Proposed formula
																AND	(
																		F.FRMULA_TYP_ID		=			(
																										SELECT	FTR.FRMULA_TYP_ID
																										FROM	FRMULA_TYP_REF			FTR
																										WHERE	FTR.FRMULA_TYP_NM		=			'Current'
																										)
																	OR	(	F.FRMULA_TYP_ID		IN		(
																										SELECT	FTR.FRMULA_TYP_ID
																										FROM	FRMULA_TYP_REF			FTR
																										WHERE	FTR.FRMULA_TYP_NM		IN			('Proposed 1', 'Proposed 2', 'Proposed 3', 'Proposed 4')
																										)
																		AND	F.PRPD_TO_CRNT_IND	=		1										--'TRUE'	This is smallint with 0/1 vals and not BIT as anticipated
																		)
																	)
												)
ORDER BY
		FS.FRMULA_STP_NBR
--GO
