--Washers (Tunnel)
/*
DECLARE	@EcolabAccountNumber				NVARCHAR(1000)
	,	@TimeStamp							DATETIME
	,	@MyServiceCustMchGrpGuid			UNIQUEIDENTIFIER

SET		@EcolabAccountNumber	=			N'040000464'
SET		@TimeStamp				=			'01 Jan 1900'
--SET		@MyServiceWasherGroupGuid	=		''			--valid myService Group GUID
*/

SELECT	--*	,
	
	
	--	Columns in MachineSetup table; leaving out duplicate columns...
		M.CUST_MCH_GRP_GUID						AS			MyServiceWasherGroupId								--myService WGroup's GUID to be translated to Conduit's Id
	--														MachineInternalId					--No
	--														ControllerId						--No
	,	M.CUST_MCH_GUID							AS			MyServiceWasherId
	,	M.CUST_MCH_NM							AS			WasherName
	,	M.MCH_ID								AS			ModelId								--To be translated to Conduit's Id from WasherModelSize
	,	MR.MCH_MDL_NM							AS			ModelName
	,	M.MCH_CAP								AS			MaxLoad
	,	M.CUST_MCH_NBR							AS			PlantWasherNumber
	,	M.TANK_CNT								AS			NumberOfTanks
	,	M.CMPMT_CNT								AS			NumberOfComp
	,	M.XFER_TYP_ID							AS			TransferTypeId
	,	M.PRESS_EXTROR_ID						As			PressExtractorId	
	,	CAST	(
				CASE	M.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)								AS			Is_Deleted
	
	
	--,	M.MOD_DTTM								AS			MyServiceModDtTm
	,	C.RGN_CD								As			RegionCode
	,	UR_MCap.UOM_CD							AS			MaxLoad_UOMCode
FROM	CUST_MCH_GRP							MG
JOIN	CUST_MCH								M
	ON	MG.CUST_MCH_GRP_GUID					=			M.CUST_MCH_GRP_GUID
JOIN	CUST									C
	ON	MG.CUST_GUID							=			C.CUST_GUID
	AND	M.CUST_GUID								=			C.CUST_GUID
JOIN	MCH_REF									MR
	ON	M.MCH_ID								=			MR.MCH_ID
JOIN	MCH_TYP_REF								MTR_M
	ON	MR.MCH_TYP_ID							=			MTR_M.MCH_TYP_ID
	AND	MTR_M.MCH_TYP_NM						=			'Tunnel'
JOIN	MCH_TYP_REF								MTR_MG
	ON	MG.MCH_GRP_TYP							=			MTR_MG.MCH_TYP_ID
	AND	MTR_MG.MCH_TYP_NM						=			'Tunnel'
LEFT JOIN
		UOM_REF									UR_MCap
	ON	M.MCH_CAP_UOM_ID						=			UR_MCap.UOM_ID
LEFT JOIN
		TNNL_MCH_PROP_REF						TMPR_TTy
	ON	M.XFER_TYP_ID							=			TMPR_TTy.PROP_ID
LEFT JOIN
		TNNL_MCH_PROP_REF						TMPR_TPE
	ON	M.PRESS_EXTROR_ID						=			TMPR_TPE.PROP_ID
WHERE	C.CUST_ACCT_NBR							=			@EcolabAccountNumber
	AND	C.CUST_TYP_ID							=			1
	AND	MG.CUST_MCH_GRP_GUID					=			ISNULL(@MyServiceWasherGroupGuid, MG.CUST_MCH_GRP_GUID)
	AND	M.MOD_DTTM								>=			ISNULL(@Timestamp, '01 Jan 1900')
	AND	MG.CUST_MCH_GRP_NBR						<>			0
--	The below condition has been added since, multiple tunnels exists in a tunnel washer group in myService...
	AND	M.CUST_MCH_GUID							=			(
															SELECT	TOP	1
																	MDS.CUST_MCH_GUID
															FROM	CUST_MCH					MDS
															WHERE	MDS.CUST_MCH_GRP_GUID		=			M.CUST_MCH_GRP_GUID
																AND	MDS.ROW_STAT_IND			=			'A'
															ORDER BY
																	MDS.CUST_MCH_NBR
															)

