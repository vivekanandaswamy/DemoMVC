IF @UpdateOthers = 'True'
BEGIN
	declare @i int = 0
, @Y int = 0
Select @Y = Count(*) FROm TCD.WaterUtilityDetails wud WHERE wud.MyServiceWtrFctrId IS NULL

while @i < @Y
begin
	UPDATE TOP (1) TCD.WaterUtilityDetails
SET
    MyServiceWtrFctrId		=	(SELECT MAX(MyServiceWtrFctrId) FROM TCD.WaterUtilityDetails WHERE EcolabAccountNUmber = @EcolabAccountNumber) + 1 
	WHERE MyServiceWtrFctrId IS NULL
	AND EcolabAccountNumber = @EcolabAccountNumber
	set @i =@i + 1
end
END
ELSE
BEGIN
	UPDATE TCD.WaterUtilityDetails
	SET
		MyServiceWtrFctrId		=	@MyServiceWtrFctrId 
	WHERE 
		EcolabAccountNumber = @EcolabAccountNumber AND
		WaterFactorTypeId	= @WaterFactorTypeId
END
