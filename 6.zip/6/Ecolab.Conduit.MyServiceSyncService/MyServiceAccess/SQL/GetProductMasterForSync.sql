SELECT  
	pm.ProductId
,	pm.MyServiceProdId
,	pm.EnvisionDisplayName
FROM TCD.ProductMaster pm