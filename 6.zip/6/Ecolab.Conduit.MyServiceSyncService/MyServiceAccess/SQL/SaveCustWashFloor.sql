DECLARE	@CustGUID							UNIQUEIDENTIFIER
	,	@ErrorId							INT	

	SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST								C
											WHERE	C.CUST_ACCT_NBR						=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID						=			1
											ORDER BY
													C.CUST_GUID
											)

SET @ErrorId = 0

IF NOT EXISTS (SELECT 1 FROM CUST_WSH_FLR_DATA WHERE CUST_GUID = @CustGUID AND WSH_FLR_DATA_DT = @WashFloorDate)
	BEGIN
	
	INSERT INTO CUST_WSH_FLR_DATA
		(CUST_GUID,
			WSH_FLR_DATA_DT,
			LDS_PER_DAY,
			ACTL_SOIL_WGT,
			SYNC_DTTM,
			ROW_DEL_FLG,
			ROW_STAT_IND,
			CRE_DTTM,
			CRE_OPER,
			MOD_DTTM,
			MOD_OPER)
		VALUES (@CustGUID,
				@WashFloorDate,
				@Loads,
				@SoilWeight,
				GETDATE(),
				'N',
				'A',
				GETDATE(),
				'TCD',
				GETDATE(),
				'TCD')
	END





