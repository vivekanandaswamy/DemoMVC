--Tunnel-Compartments
/*
DECLARE	@MyServiceWasherId				UNIQUEIDENTIFIER
	,	@TimeStamp				DATETIME

SET		@MyServiceWasherId		=			'75EEA0D0-D7F3-4A10-96B1-27F4647396BD'
SET		@TimeStamp				=			'01 Jan 1900'
*/

SELECT	--*	,
	
	--														EcolabAccountNumber
	--														TunnelCompartmentId					--Conduit generated Id
	--														WasherId							--Conduit WasherId

		MC.CMPMT_NBR							AS			CompartmentNumber
	,	CUST_MCH_GUID							As			MyServiceWasherId
	,	MC.WTR_INLET_DRAIN_ID					AS			WaterInletDrainId					--To be translated to Conduit's lookup-Id (from TunnelWaterInletDrainLookup)
	
	--	Waterlevel
	,	MC.CMPMT_WTR_LVL						AS			WaterLevel							--This will come as NUMERIC, whereas it is INT in Conduit--	UsePressExtractWater
	,	CAST	(
				CASE	MC.USE_PRESS_EXTR_WTR_IND
					WHEN	'Y'
					THEN	'TRUE'
					WHEN	'N'
					THEN	'FALSE'
				END
		AS	BIT	)								AS			UsePressExtractWater
		--	SplitCompartment
	,	CAST	(
				CASE	MC.SPLIT_CMPMT_IND
					WHEN	'Y'
					THEN	'TRUE'
					WHEN	'N'
					THEN	'FALSE'
				END
		AS	BIT	)								AS			SplitCompartment
		--	Steam
	,	CAST	(
				CASE	MC.STM_IND
					WHEN	'Y'
					THEN	'TRUE'
					WHEN	'N'
					THEN	'FALSE'
				END
		AS	BIT	)								AS			Steam
	
	--,	MC.WSH_ZN_ID							AS			WashStepId							--?? To be clarified
	--	Adding below sub-query with changes as used in myService
	,	(
		SELECT	WSH_OP_ID
		FROM	TNNL_MCH_PROP_REF				A
		JOIN	WSH_OP_REF						B
			ON	B.WSH_OP_NM						=			A.PROP_NM
			AND A.RGN_CD						=			B.RGN_CD
		WHERE	A.ROW_STAT_IND					=			'A'
			AND B.ROW_STAT_IND					=			'A'
			AND PROP_TYP_CD						=			'Wash Zone Type'
			AND MCH_TYP_NM						=			'TUNNEL'
			--AND A.RGN_CD						=			'NA'
			AND	A.PROP_ID						=			MC.WSH_ZN_ID
			AND	A.RGN_CD						=			(
															SELECT	C.RGN_CD
															FROM	CUST					C
															JOIN	CUST_MCH				M
																ON	C.CUST_GUID				=			M.CUST_GUID
															WHERE	M.CUST_MCH_GUID			=			MC.CUST_MCH_GUID
															)
		)										AS			WashStepId							--To be translated to Conduit's WashStepId
	,	MC.WTR_FLOW_ID							AS			WaterFlowId			
	--	TemperatureControlByPMR
	,	CAST	(
				CASE	MC.PMR_TEMP_CTRL_NBR
					WHEN	'Y'
					THEN	'TRUE'
					WHEN	'N'
					THEN	'FALSE'
				END
		AS	BIT	)								AS			TemperatureControlByPMR
		,	CAST	(
				CASE	MC.DSG_PNT_IND
					WHEN	'N'
					THEN	'FALSE'
					WHEN	'Y'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)					As				DosagePoint
	
	
	--	RecycledWaterInlet
	,	CAST	(
				CASE	MC.RECYL_WTR_INLET_IND
					WHEN	'Y'
					THEN	'TRUE'
					WHEN	'N'
					THEN	'FALSE'
				END
		AS	BIT	)								AS			RecycledWaterInlet
	,	CAST	(
				CASE	MC.TITRATION_PNT_IND
					WHEN	'Y'
					THEN	'TRUE'
					WHEN	'N'
					THEN	'FALSE'
				END
		AS	BIT	)								AS			IterationPoint
	
	--,	MC.MOD_DTTM								AS			MyServiceModDtTm
FROM	CUST_MCH_CMPMT							MC
LEFT JOIN
		UOM_REF									UR_WtrLvl
	ON	MC.CMPMT_WTR_LVL_UOM_ID					=			UR_WtrLvl.UOM_ID
WHERE	MC.CUST_MCH_GUID						=			@MyServiceWasherId
	AND	MC.ROW_STAT_IND							=			'A'
	AND	MC.MOD_DTTM								>=			ISNULL(@Timestamp, '01 Jan 1900')
	AND	EXISTS									(			SELECT	1
															FROM	CUST_MCH					M
															JOIN	CUST						C
																ON	M.CUST_GUID					=			C.CUST_GUID
															WHERE	M.CUST_MCH_GUID				=			MC.CUST_MCH_GUID
																AND	C.CUST_TYP_ID				=			1
																AND	M.CUST_MCH_GUID				=			(
																											SELECT	TOP	1
																													MDS.CUST_MCH_GUID
																											FROM	CUST_MCH					MDS
																											WHERE	MDS.CUST_MCH_GRP_GUID		=			M.CUST_MCH_GRP_GUID
																												AND	MDS.ROW_STAT_IND			=			'A'
																											ORDER BY
																													MDS.CUST_MCH_NBR
																											)
												)
ORDER BY
		MC.CMPMT_NBR


