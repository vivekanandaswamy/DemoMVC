SELECT	DISTINCT
				
				rkm.ResourceId 
			,	rkm.[Key]

FROM		tcd.ResourceKeyMaster			rkm
 
INNER JOIN	tcd.ResourceKeyValue			rkv 

ON			rkv.ResourceId					=				rkm.ResourceId

WHERE		rkv.LastModifiedTime			>=				@TimeStamp