--User Access	(for enVision)
/*
DECLARE	@EcolabAccountNumber			NVARCHAR(1000)

SET		@EcolabAccountNumber	=			N'040242802'
*/

SELECT
		--*
		DISTINCT
		E.DOMAIN_ACCT_NM		AS			DOMAIN_ACCT_NM
FROM	EMP						E
JOIN	CUST_EMP_SHR			CES
	ON	E.EMP_ID				=			CES.EMP_ID
JOIN	CUST					C
	ON	CES.CUST_GUID			=			C.CUST_GUID
WHERE	C.CUST_ACCT_NBR			=			@EcolabAccountNumber
	AND	E.ROLE_CD				IN			(	'TERR_MNGR'
											,	'DIST_MNGR'
											,	'RGN_MNGR'
											)
	AND	E.ROW_STAT_IND			=			'A'
	AND	CES.ROW_STAT_IND		=			'A'
	AND	C.ROW_STAT_IND			=			'A'
	AND	C.CUST_TYP_ID			=			1
	AND	E.MOD_DTTM				>=			ISNULL(@Timestamp, '01 Jan 1900')
