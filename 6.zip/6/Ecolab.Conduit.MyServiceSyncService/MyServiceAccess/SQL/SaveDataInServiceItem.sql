DECLARE @ErrorId INT,
@ServiceItemTypeId INT,
@LocationId UNIQUEIDENTIFIER
SET @LocationId = (SELECT 
			LocationId 
		FROM location 
		WHERE cust_guid in (SELECT 
					cust_guid 
				FROM cust c 
				WHERE c.cust_acct_nbr = @EcolabAccountNumber) 
AND locationtypeid IN (Select locationtypeid from LOCATIONTYPEREF where locationtypedesc like 'Wash Area') 
AND businesstypeid IN (Select businesstypeid from BUSINESSTYPEREF where businesstypedesc like 'laundry' AND div_cd = 011))
SET @ServiceItemTypeId = (Select ServiceItemTypeId from SERVICEITEMTYPEREF where serviceitemtypedesc like @EntityType 
AND businesstypeid IN (Select businesstypeid from BUSINESSTYPEREF where businesstypedesc like 'laundry' AND div_cd = 011))
SET @ErrorId = 0;
IF NOT EXISTS (SELECT 1 FROM [dbo].[ServiceItem] WHERE MACHINETYPEID = @MyServiceDispenserGUID)
	BEGIN		
			INSERT INTO [dbo].[ServiceItem]
           ([SERVICEITEMID]
           ,[LOCATIONID]
           ,[SERVICEITEMNAME]
		   ,[SERVICEITEMTYPEID]
		   ,[MACHINETYPEID]
		   ,[SERIALNUMBER]    
		   ,[ROW_DEL_FLG]      
           ,[ROW_STAT_IND]
		   ,[CRE_DTTM]
		   ,[CRE_OPER]
		   ,[MOD_DTTM]
		   ,[MOD_OPER]
          )
     VALUES
           (NEWID()
           ,@LocationId
		   ,@ControllerName
		   ,@ServiceItemTypeId
		   ,@MyServiceDispenserGUID
		   ,@SerialNo
		   ,'N'
           ,	CAST(CASE	@IsDelete
						WHEN	'FALSE'
						THEN	'A'
						WHEN	'TRUE'
						THEN	'I'
						ELSE	'A'
					END  AS Char(1))
		,GETUTCDATE(), 
			'TCD',
			GETUTCDATE(),
			'TCD'
			)
			SET	@ErrorId	=	@@ERROR
	END
	ELSE
	BEGIN
	UPDATE [dbo].[ServiceItem]
		SET
			[SERVICEITEMNAME]	=		@ControllerName,
			[SERIALNUMBER]		=		@SerialNo,
			[LOCATIONID]        =		@LocationId,
			[ROW_STAT_IND]			=		CAST(CASE @IsDelete
													WHEN 'FALSE'
													THEN	'A'
													WHEN	'TRUE'
													THEN	'I'
													ELSE	'A'
													END  AS Char(1)),
			MOD_DTTM			=				GetUTCDATE(),
			MOD_OPER			=				'TCD'
		WHERE MACHINETYPEID = @MyServiceDispenserGUID 
		SET	@ErrorId	=	@@ERROR
	END
	SELECT	@ErrorId