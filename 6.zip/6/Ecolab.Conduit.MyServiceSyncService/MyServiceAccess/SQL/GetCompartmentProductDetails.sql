SELECT 

DISTINCT	CDD.PROD_ID								AS			MyServiceProdId
			, CMCDDX.CUST_MCH_GUID					AS			MyServiceWasherGuid
			, CMCDDX.CMPMT_NBR						AS			CompartmentNumber
			, CMCDDX.CUST_MCH_CMPMT_DSG_DVC_GUID	AS			MyServiceCmpmtDsgDvcguid

FROM		CUST_MCH_CMPMT_DSG_DVC_XREF			CMCDDX 

INNER JOIN	CUST_DSG_DVC						CDD 
ON			CMCDDX.CUST_DSG_DVC_GUID			=				CDD.CUST_DSG_DVC_GUID
WHERE		CMCDDX.CUST_MCH_GUID				=				@MyServiceWasherGuid
AND			CMCDDX.CUST_MCH_GRP_GUID			=				@MyServiceWasherGroupGuid
AND			CMCDDX.CMPMT_NBR					=				@CompartmentNumber
AND			CDD.ROW_stat_ind					=				'A'


