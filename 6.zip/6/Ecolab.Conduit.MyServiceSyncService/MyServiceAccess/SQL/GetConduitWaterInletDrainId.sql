IF @MyServiceWaterInletId = 0 OR @MyServiceWaterInletId IS NULL
	BEGIN
		SELECT CAST(twidl.TunnelWaterInletDrainLookupId AS smallint) FROM TCD.TunnelWaterInletDrainLookup twidl WHERE twidl.Name = 'None' AND twidl.RegionId = 1
	END
ELSE
	BEGIN
		SELECT CAST(twidl.TunnelWaterInletDrainLookupId AS smallint) FROM TCD.TunnelWaterInletDrainLookup twidl WHERE twidl.MyServicePropId = @MyServiceWaterInletId AND twidl.RegionId = 1
	END

