DECLARE	@CustGUID					UNIQUEIDENTIFIER
	,	@MyServiceCustFrmulaGuid	UNIQUEIDENTIFIER
	,	@ErrorId					INT			
			SET		@CustGUID					=			(
															SELECT	TOP 1
																	C.CUST_GUID
															FROM	CUST						C
															WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
																AND	C.CUST_TYP_ID				=			1
															ORDER BY
																	C.CUST_GUID
															)

SET @ErrorId = 0

IF NOT EXISTS (SELECT 1 FROM dbo.CUST_MCH_GRP cmg WHERE cmg.CUST_MCH_GRP_GUID = @MyServiceWasherGroupGuid AND cmg.CUST_GUID = @CustGUID)
BEGIN
	SET @ErrorId = 50124
	Select @ErrorId
	return 
END

IF @MyServiceMstrLnnTypId Is NULL OR @MyServiceMstrLnnTypId = 0
BEGIN
	SELECT @MyServiceMstrLnnTypId = mltr.MSTR_LNN_TYP_ID FROM dbo.MSTR_LNN_TYP_REF mltr WHERE mltr.LNN_TYP_NM = 'TBD' AND mltr.RGN_CD = N'NA' 
END

IF @MyServiceSaturationTypeId Is NULL OR @MyServiceSaturationTypeId = 0
BEGIN
	SELECT @MyServiceSaturationTypeId = mltr.MSTR_LNN_TYP_ID FROM dbo.MSTR_LNN_TYP_REF mltr WHERE mltr.LNN_TYP_NM = 'TBD' AND mltr.RGN_CD = N'NA' 
END

SET @MyServiceCustFrmulaGuid	=	NEWID()

IF NOT EXISTS (SELECT 1 FROM [dbo].[CUST_FRMULA_MCH_GRP_XREF] WHERE CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGuid AND CUST_GUID = @CustGUID)
	BEGIN
	INSERT INTO [dbo].[CUST_FRMULA_REF]
           ([CUST_FRMULA_GUID]
           ,[CUST_GUID]
           ,[FRMULA_TYP_ID]
           ,[MCH_TYP_ID]
           ,[MSTR_LNN_TYP_ID]
		   ,[SAT_LNN_TYP_ID]
           ,[FRMULA_NBR]
           ,[FRMULA_NM]
           ,[FRMULA_ORIG_CD]
           ,[FRMULA_PROM_CD]
           ,[ROW_STAT_IND]
          )
     VALUES
           (@MyServiceCustFrmulaGuid
           ,@CustGUID
           ,3
           ,1
           ,@MyServiceMstrLnnTypId
		   ,@MyServiceSaturationTypeId
           ,@ProgramNumber
           ,@ProgramName
           ,'N'
           ,'N'
           ,CASE @IsDelete 
							WHEN	0
							THEN	'A'
							WHEN	1
							THEN	'I'
							ELSE	'A'
					END
			)


		INSERT INTO [dbo].[CUST_FRMULA_MCH_GRP_XREF]
				   ([CUST_FRMULA_MCH_GRP_GUID]
				   ,[CUST_FRMULA_GUID]
				   ,[CUST_MCH_GRP_GUID]
				   ,[ASSN_TYP_CD]
				   ,[CUST_GUID]
				   ,[SOIL_WGT_PCTG]
				   ,[ROW_STAT_IND]
				   )
		VALUES
				   ( @MyServiceCustFrmulaMchGrpGuid
					,@MyServiceCustFrmulaGuid
					,@MyServiceWasherGroupGuid
					,'G'
					,@CustGUID
					,@NominalLoad
					,CASE @IsDelete 
							WHEN	0
							THEN	'A'
							WHEN	1
							THEN	'I'
							ELSE	'A'
					END
					)

		SET	@ErrorId	=	@@ERROR
	END
ELSE
	BEGIN
		Select @MyServiceCustFrmulaGuid = CUST_FRMULA_GUID  FROM  [dbo].[CUST_FRMULA_MCH_GRP_XREF] WHERE CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGuid AND CUST_GUID = @CustGUID

		UPDATE [dbo].[CUST_FRMULA_MCH_GRP_XREF]
		SET
			[SOIL_WGT_PCTG]			=		@NominalLoad
		,	[ROW_STAT_IND]			=		CASE  @IsDelete 
											WHEN	0
											THEN	'A'
											WHEN	1
											THEN	'I'
											ELSE	'A'
										END
		WHERE CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGuid AND CUST_GUID = @CustGUID

		UPDATE [dbo].[CUST_FRMULA_REF]
		SET		
			[MSTR_LNN_TYP_ID]		=				@MyServiceMstrLnnTypId
		,	[SAT_LNN_TYP_ID]		=				@MyServiceSaturationTypeId
		,	[FRMULA_NBR]			=				@ProgramNumber
		,	[FRMULA_NM]				=				@ProgramName
		,	[ROW_STAT_IND]			=				CASE @IsDelete 
														WHEN	0
														THEN	'A'
														WHEN	1
														THEN	'I'
														ELSE	'A'
													END
		WHERE CUST_FRMULA_GUID = @MyServiceCustFrmulaGuid AND CUST_GUID = @CustGUID

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId




