-- Plant Utility Water Factor data

/*
DECLARE		@EcolabAccountNumber		CHAR(10)
		,	@TimeStamp					DATETIME


SET			@TimeStamp									=			'01 Jan 1900'
*/


SELECT 
						--	*
							REWSH_FCTR					AS					RewashFactor 
						,	EVPTN_FCTR					AS					EvaporationFactor
						,	UTIL.UTIL_NM				AS					GasOilType
						,	UR.UOM_CD					AS					EnergyPriceUom
						,	WTR.GAS_OIL_PRC				AS					GasOilPrice
FROM						CUST_UTIL_FCTR		WTR
							INNER JOIN UOM_REF  UR
							ON WTR.GAS_OIL_PRC_UOM_ID = UR.UOM_ID
						,	UTIL_REF			UTIL

WHERE						CUST_GUID 
IN 
		(
		SELECT				CUST_GUID 
		FROM				CUST_UTIL_FCTR		
		INNER JOIN			UTIL_REF
		ON					UTIL.UTIL_ID				=					WTR.GAS_OIL_TYP_ID
		WHERE				UTIL.UTIL_CLS_CD			=					'GAS OIL'
		AND					WTR.CUST_GUID				IN					

			(
			SELECT			CUST_GUID 
			FROM			CUST 
			WHERE			CUST_ACCT_NBR				=					@EcolabAccountNumber
			)
		)
AND							WTR.MOD_DTTM					>=					@TimeStamp