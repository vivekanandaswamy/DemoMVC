
/*DECLARE	@TimeStamp							DATETIME

SET		@TimeStamp				=			'01 Jan 1900'
*/
SELECT 
		MCH.MCH_ID								AS		MyServiceMCHId
	,	MCH.MCH_MDL_NM							AS		WasherModelName
	,	MCH.MCH_TYP_ID							AS		ModelTypeId
	,	MCH.RGN_CD								AS		RegionCode
	,	MCH.SIZE								AS		WasherSize
	,	CAST(CASE	MCH.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
				AS	BIT
			)									AS			Is_Deleted
	,	MCH.MOD_DTTM							AS			MyServiceModDtTm
FROM	MCH_REF									MCH
WHERE	MCH.MOD_DTTM							>=          @TimeStamp
