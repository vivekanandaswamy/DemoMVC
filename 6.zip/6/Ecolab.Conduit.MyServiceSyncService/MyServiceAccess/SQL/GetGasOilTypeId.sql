SELECT GasOilId
       FROM [TCD].GasoilTypeMaster where Name = @Name 