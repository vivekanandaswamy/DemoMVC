  DECLARE	@CustGUID				UNIQUEIDENTIFIER 
	
SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
											)


SELECT			
				CID.CONSUMPTION_INV_HDR_GUID			AS		MyServiceInventoryId
			,	CID.PROD_ID								AS		MyServiceProdId
			,	@EcolabAccountNumber					AS		EcolabAccountNumber
			,	CIH.OPNING_INV_DT						AS		InventoryDate
			,	UR.[UOM_CD]								AS		UnitSize
			,	CID.OPNING_QTY							AS		OpeningQuantity
			,	CID.ADJUSTED_QTY						AS		Adjustedquantity
			,	CID.PRCH_QTY							AS		Purchasequantity
			,	CID.CLOSING_QTY							AS		ClosingQuantity
			,	CID.USED_QTY							AS		UsedQuantity
	
FROM			CONSUMPTION_INV_DTL								CID
Inner Join		UOM_REF											UR
ON				CID.QTY_UOM_ID							=		UR.UOM_ID
Inner JOIN		CONSUMPTION_INV_HDR								CIH
ON				CID.CONSUMPTION_INV_HDR_GUID			=		CIH.CONSUMPTION_INV_HDR_GUID
INNER JOIN PROD P ON P.PROD_ID = CID.PROD_ID
WHERE
		CIH.cust_guid			=		@CustGUID  
		AND CIH.ROW_STAT_IND = 'A' 
		AND CID.ROW_STAT_IND = 'A'
		AND (CID.MOD_DTTM >= @Timestamp
		OR CIH.MOD_DTTM >= @Timestamp)
