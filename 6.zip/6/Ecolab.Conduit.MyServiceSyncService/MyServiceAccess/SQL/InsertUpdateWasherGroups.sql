DECLARE		@CustGuid	uniqueidentifier
		,	@ErrorId						INT				

		SET @ErrorId   =			0

Select @CustGuid = CUST_GUID FROM CUST WHERE cust_acct_nbr = @EcolabAccountNumber

IF EXISTS (SELECT 1 FROM CUST_MCH_GRP WHERE  CUST_MCH_GRP_GUID = @MyServiceWasherGroupGuid AND CUST_GUID = @CustGuid)

BEGIN

		UPDATE CUST_MCH_GRP 

			SET	
					CUST_MCH_GRP_NBR		=		@WasherGroupNumber
				,	CUST_MCH_GRP_NM			=		@WasherGroupName	
				,	MCH_GRP_TYP				=		@WasherGroupTypeId
				,	ROW_STAT_IND			=		CAST(CASE	@IsDeleted
														WHEN	'FALSE'
														THEN	'A'
														WHEN	'TRUE'
														THEN	'I'
														ELSE	'A'
													END  AS Char(1))
				,	MOD_DTTM				=		@LastModifiedTimeStamp

			FROM CUST_MCH_GRP
			
			WHERE  

			CUST_MCH_GRP_GUID = @MyServiceWasherGroupGuid AND CUST_GUID = @CustGuid

			SET	@ErrorId	=	@@ERROR
	
END

ELSE
	
BEGIN
		INSERT INTO CUST_MCH_GRP
		(  
				
				CUST_MCH_GRP_GUID		
			,   CUST_GUID
			,	CUST_MCH_GRP_NBR
			,	CUST_MCH_GRP_NM
			,	MCH_GRP_TYP
			,	ROW_STAT_IND
			,	MOD_DTTM
	
		)
		VALUES
		(
				@MyServiceWasherGroupGuid   
			,	@CustGuid
			,	@WasherGroupNumber
			,	@WasherGroupName
			,	@WasherGroupTypeId
			,	CAST(CASE	@IsDeleted
						WHEN	'FALSE'
						THEN	'A'
						WHEN	'TRUE'
						THEN	'I'
						ELSE	'A'
					END  AS Char(1))
			,	@LastModifiedTimeStamp
		)
				
		SET	@ErrorId	=	@@ERROR


END	

		
IF (@IsDeleted = 'TRUE')
BEGIN
	UPDATE cfr
	SET 
		cfr.ROW_STAT_IND = 'I'
	FROM CUST_FRMULA_MCH_GRP_XREF cfmgx
	INNER JOIN dbo.CUST_FRMULA_REF cfr ON cfr.CUST_FRMULA_GUID = cfmgx.CUST_FRMULA_GUID AND cfr.CUST_GUID = cfmgx.CUST_GUID
	WHERE cfmgx.CUST_GUID = @CustGuid
	AND cfmgx.CUST_MCH_GRP_GUID = @MyServiceWasherGroupGuid

	UPDATE dbo.CUST_FRMULA_MCH_GRP_XREF
	SET
	   ROW_STAT_IND = 'I'
	WHERE CUST_MCH_GRP_GUID = @MyServiceWasherGroupGuid
	AND CUST_GUID = @CustGuid
END

		