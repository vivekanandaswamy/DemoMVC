DECLARE @UomId int;
DECLARE @BatesPerMo int;

SELECT @UomId = ur.UOM_ID FROM dbo.UOM_REF ur WHERE ur.UOM_CD = @SoilWgtUomCode
SET @BatesPerMo = (SELECT	SUM(FMX.BATES_PER_MO) FROM	CUST_FRMULA_MCH_XREF FMX
			WHERE	FMX.CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGuid)

IF NOT EXISTS (SELECT 1 FROM dbo.CUST_FRMULA_MCH_XREF cfmx WHERE cfmx.CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGuid AND cfmx.CUST_MCH_GUID = @MyServiceMchGuid)
BEGIN
	INSERT INTO dbo.CUST_FRMULA_MCH_XREF
	(
	    CUST_FRMULA_MCH_GUID,
	    CUST_FRMULA_MCH_GRP_GUID,
	    CUST_MCH_GUID,
	    SOIL_WGT,
	    SOIL_WGT_UOM_ID,
	    SOIL_WGT_PCTG,
	    BATES_PER_MO,
	    AUTO_DSTRN_IND,
	    ROW_DEL_FLG,
	    ROW_STAT_IND
	)
	VALUES
	(
	    NEWID(), -- CUST_FRMULA_MCH_GUID - uniqueidentifier
	    @MyServiceCustFrmulaMchGrpGuid, -- CUST_FRMULA_MCH_GRP_GUID - uniqueidentifier
	    @MyServiceMchGuid, -- CUST_MCH_GUID - uniqueidentifier
	    @SoilWgt, -- SOIL_WGT - numeric
	    @UomId, -- SOIL_WGT_UOM_ID - smallint
	    @SoilWgtPctg, -- SOIL_WGT_PCTG - numeric
	    @BatesPerMo, -- BATES_PER_MO - int
	    'N', -- AUTO_DSTRN_IND - char
	    'N', -- ROW_DEL_FLG - char
	    'A' -- ROW_STAT_IND - char
	)
END
ELSE
BEGIN
	UPDATE dbo.CUST_FRMULA_MCH_XREF
	SET
	    SOIL_WGT = @SoilWgt, -- numeric
	    SOIL_WGT_UOM_ID = @UomId, -- smallint
	    SOIL_WGT_PCTG = @SoilWgtPctg, -- numeric
	    BATES_PER_MO = @BatesPerMo -- int
	WHERE CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGuid
	AND CUST_MCH_GUID = @MyServiceMchGuid
END