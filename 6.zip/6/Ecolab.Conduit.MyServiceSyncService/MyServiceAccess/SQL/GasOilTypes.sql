--Gas Oil Type master
--DECLARE	@TimeStamp				DATETIME

--SET		@TimeStamp				=			'01 Jan 1900'

SELECT
	--*
	--,														GasOilId					--This is Conduitgenerated Id
		UR.UTIL_NM								AS			Name
	,	UDVR.DFLT_VAL							AS			DefaultValue

	,	UomR.UOM_ID								AS			UOMId						--This is NOT to be presisted.
	,	UomR.UOM_CD								AS			UOMCode						--This is NOT to be presisted.
	,	UomR.UOM_DESC							AS			UOMDescription				--This is NOT to be presisted.

	,	UR.RGN_CD								AS			RegionCode					--To be converted to RegionId using RegionMaster
	,	CAST(		CASE	UR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
			AS	BIT
			)									AS			IsDeleted					--Col. 2b added in Conduit schema
	--,	UR.UTIL_TYP_CD							AS			UtillityTypeCode			--this is pending confirmation
	,	UR.UTIL_ID								AS			MyServiceUtilId
	,	UR.MOD_DTTM								AS			MyServiceModDtTm			--Not to be persisted in Conduit
	,   (SELECT DISTINCT UTIL_NM FROM UTIL_LCLE_REF WHERE LANG_ID=37 AND UTIL_ID=UR.UTIL_ID)
												AS			sp_SP
	,   (SELECT DISTINCT UTIL_NM FROM UTIL_LCLE_REF WHERE LANG_ID=28 AND UTIL_ID=UR.UTIL_ID)
												AS			nr_NR
	,   (SELECT DISTINCT UTIL_NM FROM UTIL_LCLE_REF WHERE LANG_ID=11 AND UTIL_ID=UR.UTIL_ID)
												AS			nl_BE
FROM	UTIL_REF								UR
LEFT JOIN
		UTIL_DFLT_VALS_REF						UDVR
	ON	UR.UTIL_ID								=			UDVR.UTIL_ID
	AND	UR.DFLT_VAL_FLG							=			'Y'
LEFT JOIN
		UOM_REF									UomR
	ON	UDVR.DFLT_VAL_UOM_ID					=			UomR.UOM_ID
WHERE	UR.UTIL_CLS_CD							=			'GAS OIL'
	AND	UR.MOD_DTTM								>=			@TimeStamp
ORDER BY
		UR.UTIL_ID



