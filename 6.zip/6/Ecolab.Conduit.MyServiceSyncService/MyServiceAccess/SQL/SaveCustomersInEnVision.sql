--Script to save myService EMP as user in enVision schema
SET	NOCOUNT	ON

DECLARE	
	--	input variables
--		@InLanguageCode							CHAR(2)					=			NULL			--input for Language; to be matched on CODE in TCD schema
		@InUserLogin							NVARCHAR(50)			=			NULL			--input for UserLogin
--	,	@InPassword								NVARCHAR(50)			=			NULL			--input for Password
--	,	@InLastName								NVARCHAR(30)			=			NULL			--input for LastName
--	,	@InFirstName							NVARCHAR(30)			=			NULL			--input for FirstName
	,	@InMiddleName							NVARCHAR(30)			=			NULL			--input for FirstName; NOT available in myService, will remain NULL
	,	@CustomerId								INT						=			NULL
--	,	@InStatus								TINYINT					=			NULL			--input for Status - (enVision)1/0 <==> Active/InActive (myService)
--	,	@InPhoneNumber							NVARCHAR(30)			=			NULL			--input for PhoneNumber
--	,	@InUserCountryCode						CHAR(2)					=			NULL			--input for UserCountry
--	,	@InEmpId								INT						=			NULL			--input for EmpId; EMP_NBR from myService
--	,	@InManId								INT						=			NULL			--input for ManId; EMP_NBR of manager from myService
--	,	@InExtendedUserType						NCHAR(10)				=			NULL			--input for ExtendedUserType; the values in myService and enVision do not match
	,	@InUserId								INT						=			NULL

	--	other script variables

	
	--	master data in enVision schema
	,	@LanguageId								SMALLINT				=			NULL			--To be set based on input LanguageCode
	,	@UserCountryId							SMALLINT				=			NULL			--To be set based on input UserCountryCode
	,	@ExtendedUserTypeId						INT						=			NULL			--ExtendedUserTypeId of RegionManager in enVision
	,	@ExtendedUserTypeId_Default				INT						=			NULL			--ExtendedUserTypeId Default in enVision
	
	,	@TimeStamp								DATETIME				=			GETDATE()
	,   @FacilityId								INT						=			NULL			--To be set based on input EcolabAccountNumber
	--	Script variable
	,	@ScriptError							INT						=			0				--To be returned back, if non-0, implies some error; rollback
		--	master data in enVision schema
	,	@SourceId								INT						=			NULL			--Id in ERPSource in enVision for 'myService'
	,   @UserId									INT	
	--	output variable

SET		@InUserLogin				=		@InFirstName + @InLastName

SET		@CustomerId					=		(SELECT fm.CustomerID FROM dbo.FacilityMaster fm WHERE fm.SoldTo = @EcolabAccountNumber)
--Setting user id based on 'Admin_Tool' userlogin
SET		@InUserId					=				ISNULL(	(
															SELECT	TOP	1
																	UM.UserId
															FROM	dbo.UserMaster			UM
															WHERE	UM.UserLogin			=			'Admin_Tool'
															ORDER BY
																	UM.UserId
															)
														,	1)



-- Default LanguageId
SELECT @LanguageId = lm.LanguageId FROM TCD.LanguageMaster lm WHERE lm.MyServiceISOLangCD = 'EN'
 
--Get LanguageId based on LanguageCode
SELECT
		@LanguageId					=			ISNULL	(enVLM.LanguageID
														,	(
															SELECT	TOP	1	LanguageId	
															FROM	dbo.LanguageMaster
															)
														)
FROM	TCD.LanguageMaster			TCDLM
JOIN	dbo.LanguageMaster			enVLM
	ON	TCDLM.Name					=			enVLM.LanguageName	
WHERE	TCDLM.MyServiceISOLangCD	=			@InLanguageCode


--Set CountryId based in input CountryCode
SET		@UserCountryId							=			(
															SELECT	CM.CountryID
															FROM	dbo.CountryMaster			CM
															WHERE	CM.CountryCode				=			@InUserCountryCode
															)


----Set Id of RegionManager ExtendedUserType
SET		@ExtendedUserTypeId					=			(
															SELECT	EUT.Id
															FROM	dbo.ExtendedUserTypes			EUT
															WHERE	EUT.Name						=			@EnvisionRole
															)

--Set Id of Default ExtendedUserType
SET		@ExtendedUserTypeId_Default				=			(
															SELECT	EUT.Id
															FROM	dbo.ExtendedUserTypes			EUT
															WHERE	EUT.Name						=			'None'
															)
IF	NOT	EXISTS	(
				SELECT	1
				FROM	dbo.UserMaster			UM
				WHERE	UM.UserLogin			=			@InUserLogin
				)
		BEGIN
				--Insert in dbo.UserMaster
				INSERT	INTO	dbo.UserMaster	(
							--	UserId																	--Will be auto-generated
								CustomerId																--To be NULL
							,	LanguageID
							,	UserLogin
							,	[Password]
							,	LastName																--Last Name of the user/EMP
							,	FirstName																--First Name of the user/EMP
							,	MiddleName																--Middle Name of the user/EMP; will be NULL, not available in myService
							,	UserType
							,	EmailAddress
							,	[Status]
							,	CreatedBy																
							,	CreatedOn
							,	ModifiedBy
							,	ModifiedOn
							,	PhoneNumber
							,	UserCountry
							--,	EmpId																	--EMP_NBR from myService
							--,	ManId																	--EMP_NBR of MGR_ID for this EMP/User
							/*
							,	UserTimeZone															--These fields are not-available in myService
							,	A3DTAccess																--and as per decision will be NULL
							,	DefaultPage
							,	LastLoginDate
							,	UpgradesUserLevel
							,	ShowATLAS
							,	HDeskRoleID
							,	UOM
							*/
							--,	TLMAlert1																--Not from myService; NOT NULLable, hence will use DEFAULT
							--,	TLMAlert2																--Not from myService; NOT NULLable, hence will use DEFAULT
							--,	TLMAlert3																--Not from myService; NOT NULLable, hence will use DEFAULT
							--,	HideDiagnosticParam														--Not from myService; NOT NULLable, hence will use DEFAULT
							,	ExtendedUserTypeId
							)
				SELECT		
							--	UserId																	--Will be auto-generated
								@CustomerId						AS			CustomerId					--CustomerId
							,	@LanguageId						AS			LanguageId
							,	@InUserLogin					AS			UserLogin
							,	@InPassword						AS			[Password]
							,	@InLastName						AS			LastName					--Last Name of the user/EMP
							,	@inFirstName					AS			FirstName					--First Name of the user/EMP
							,	@InMiddleName					AS			MiddleName					--Middle Name of the user/EMP; will be NULL, not available in myService
							,	'C'								AS			UserType					--Always C for Customers
							,	@InEmailAddress					AS			EmailAddress				--Not available in myService, will thus be set to NULL
							,	@InStatus						AS			[Status]					--(enVision)1/0 <==> Active/InActive (myService)
							,	@InUserId						AS			CreatedBy
							,	@TimeStamp						AS			CreatedOn
							,	@InUserId						AS			ModifiedBy
							,	@TimeStamp						AS			ModifiedOn
							,	@InPhoneNumber					AS			PhoneNumber
							,	@UserCountryId					AS			UserCountry
							--,	@InEmpId						AS			EmpId
							--,	@InManId						AS			ManId
							--,	DEFAULT							AS			TLMAlert1					--Not from myService; NOT NULLable, hence will use DEFAULT
							--,	DEFAULT							AS			TLMAlert2					--Not from myService; NOT NULLable, hence will use DEFAULT
							--,	DEFAULT							AS			TLMAlert3					--Not from myService; NOT NULLable, hence will use DEFAULT
							--,	DEFAULT							AS			HideDiagnosticParam			--Not from myService; NOT NULLable, hence will use DEFAULT
							,	@ExtendedUserTypeId				AS			ExtendedUserType			--TODO : As column is not there in 207 or 208 schema need to ask about production
		SET @UserId = SCOPE_IDENTITY()
		END
ELSE
		BEGIN
				UPDATE dbo.UserMaster
					SET		
						LastName			=		@InLastName	
					,	FirstName			=		@inFirstName
					,	PhoneNumber			=		@InPhoneNumber
					,	EmailAddress		=		@InEmailAddress
					,	[Status]			=		@InStatus
				WHERE	UserLogin			=		@InUserLogin
					
		END

--Capture any error Script
SET		@ScriptError			=			@@ERROR

														--Get/Set master data Ids...
	--Get SourceId for 'myservice'
SET		@SourceId								=			(
															SELECT	ES.SourceId
															FROM	dbo.ERPSources				ES
															WHERE	SourceName					=			'myService'
															)

--Get FacilityId for the input EcolabAccountNumber
SET		@FacilityId								=			(
															SELECT	TOP	1
																	FM.FacilityId
															FROM	dbo.FacilityMaster			FM
															WHERE	FM.SoldTo					=			@EcolabAccountNumber
																AND	FM.SourceId					=			@SourceId
															ORDER BY
																	FM.FacilityId
															)

--Fetch a valid UserId and proceed to insert, if found, else abort
IF @UserId IS NULL
BEGIN
SELECT	TOP	1
		@UserId					=			UM.UserId
FROM	dbo.UserMaster			UM
WHERE	UM.UserLogin			=			@InUserLogin
ORDER BY
		UM.UserId
END

IF	@UserId	IS	NULL
		BEGIN
				SET			@ScriptError	=	1			--since we didn't find a user entry for this login
				SELECT		@ScriptError					--return error id
				RETURN		--return from script
		END

IF	@FacilityId	IS	NULL
		BEGIN
				RETURN		--return from script
		END

--if we found a valid userId, proceed further
IF	NOT	EXISTS	(
				SELECT	1
				FROM	dbo.MDS_HierarchyAccess			MDSHA
				WHERE	MDSHA.UserId					=			@UserId
					AND	MDSHA.Location_Access_Type		=			'Location'
					AND	MDSHA.Node_Level				=			5
					AND	MDSHA.Node_Id					=			@FacilityId
				)
			BEGIN
					INSERT	INTO	dbo.MDS_HierarchyAccess	(
								--	Id												--auto-generated Id
									UserId											--UserId for which access is being added
								,	Location_Access_Type							--"Location" for Facility access
								,	Setting											--NULL for Facility access
								,	Access_Type										--1 = Read/Write
								,	Node_Level										--5 for Facility access
								,	Node_Id											--Facility ID for Facility access
								,	CreatedBy
								,	CreatedDate
								)
						SELECT	--	Id												--auto-generated Id
									@UserId					AS			UserId
								,	'Location'				AS			Location_Access_Type
								,	NULL					AS			Setting
								,	1						AS			Access_Type
								,	5						AS			Node_Level
								,	@FacilityId				AS			Node_Id
								,	@UserId					AS			CreatedBy
								,	@TimeStamp				AS			CreatedDate

						SET		@ScriptError			=			@@Error
			END
--Either ways - error or none, select error value and return
SELECT	@ScriptError


SET	NOCOUNT	OFF

RETURN			--return from script
