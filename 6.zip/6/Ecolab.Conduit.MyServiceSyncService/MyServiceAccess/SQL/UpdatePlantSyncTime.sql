UPDATE TCD.SyncPlant
SET
    SyncedDate = GETUTCDATE() -- datetime
WHERE 
	EcolabAccountNumber = @EcolabAccountNumber
  
	