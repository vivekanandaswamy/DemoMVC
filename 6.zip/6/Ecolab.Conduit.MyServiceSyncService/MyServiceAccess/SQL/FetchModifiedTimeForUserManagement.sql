Declare @LastModifiedTime DateTime

IF EXISTS (SELECT 1 FROM TCD.UserMaster um 
				WHERE 
					um.EcolabAccountNumber = @EcolabAccountNumber 
				AND um.UserId = @UserId
		  )
BEGIN

SET @LastModifiedTime = ( SELECT um.LastModifiedTime FROM TCD.UserMaster um 
									WHERE 
										um.EcolabAccountNumber = @EcolabAccountNumber 
									AND um.UserId = @UserId
						)
SELECT @LastModifiedTime
END