--Chain


SELECT	
	--														PlantChainId						--This is conduit generated Id	
		CR.CNTRCT_NM							AS			PlantChainName		--In Conduit this is to be translated to Id
	,	CAST	(
				CASE	CR.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)								AS			Is_Deleted
	,	CR.CNTRCT_ID							AS			MyServiceChnId
	,	CR.MOD_DTTM								AS			MyServiceLastModDtTm
FROM	CNTRCT									CR		
WHERE	CR.CNTRCT_ID							=			@MyServiceChainId

