﻿
SELECT	FormulaSegmentID,
		SegmentName,
		LastModifiedTime,
		Is_Deleted,
		LastSyncTime 
FROM TCD.formulasegments 
WHERE LastModifiedTime >= @TimeStamp