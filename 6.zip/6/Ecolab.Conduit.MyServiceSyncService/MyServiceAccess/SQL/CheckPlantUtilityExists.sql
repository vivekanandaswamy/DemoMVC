DECLARE @IsExists BIT = 1	


IF EXISTS (SELECT 1 FROM TCD.EnergyUtilityDetails eud WHERE eud.EcolabAccountNumber = @EcolabAccountNumber)
	BEGIN
		SET @IsExists = 0
	END
ELSE
	BEGIN
		SET @IsExists = 1
	END 

SELECT @IsExists