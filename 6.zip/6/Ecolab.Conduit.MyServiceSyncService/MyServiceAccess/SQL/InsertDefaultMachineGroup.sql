DECLARE @IsExists INT = 0	
,		@NewId	  INT = 0


IF EXISTS (SELECT 1 FROM TCD.MachineGroup mg WHERE mg.EcolabAccountNumber = @EcolabAccountNumber AND mg.GroupDescription = N'Plant')
	BEGIN
		SET @IsExists = 1
	END
ELSE
	BEGIN
		SET	@NewId		=	(
											SELECT	ISNULL(MAX(mg.Id), 0) + 1
											FROM	TCD.MachineGroup			mg
											WHERE	mg.EcolabAccountNumber	=	@EcolabAccountNumber
											)

		INSERT INTO TCD.MachineGroup
			(
				TCD.MachineGroup.Id, 
				TCD.MachineGroup.GroupDescription,
				TCD.MachineGroup.GroupTypeId,
				TCD.MachineGroup.EcolabAccountNumber,
				TCD.MachineGroup.Is_Deleted,
				TCD.MachineGroup.LastModifiedByUserId,
				TCD.MachineGroup.LastModifiedTime,
				TCD.MachineGroup.LastSyncTime,
				TCD.MachineGroup.MyServiceCustMchGrpGuid
			)
			VALUES
			(
				@NewId,
				N'Plant', -- GroupDescription - nvarchar
				1, -- GroupTypeId - int
				@EcolabAccountNumber, -- EcolabAccountNumber - nvarchar
				0, -- Is_Deleted - bit
				0, -- LastModifiedByUserId - int
				GETUTCDATE(), -- LastModifiedTime - datetime
				GETUTCDATE(), -- LastSyncTime - datetime
				NULL -- MyServiceCustMchGrpGuid - uniqueidentifier
			)

			SET @IsExists = 0
	END 


IF EXISTS (SELECT 1 FROM TCD.MachineGroup mg WHERE mg.EcolabAccountNumber = @EcolabAccountNumber AND mg.GroupDescription = N'Water And Energy Device')
	BEGIN
		SET @IsExists = 1
	END
ELSE
	BEGIN
		SET	@NewId		=	(
											SELECT	ISNULL(MAX(mg.Id), 0) + 1
											FROM	TCD.MachineGroup			mg
											WHERE	mg.EcolabAccountNumber	=	@EcolabAccountNumber
											)

		INSERT INTO TCD.MachineGroup
			(
				TCD.MachineGroup.Id, 
				TCD.MachineGroup.GroupDescription,
				TCD.MachineGroup.GroupTypeId,
				TCD.MachineGroup.EcolabAccountNumber,
				TCD.MachineGroup.Is_Deleted,
				TCD.MachineGroup.LastModifiedByUserId,
				TCD.MachineGroup.LastModifiedTime,
				TCD.MachineGroup.LastSyncTime,
				TCD.MachineGroup.MyServiceCustMchGrpGuid
			)
			VALUES
			(
				@NewId,
				N'Water And Energy Device', -- GroupDescription - nvarchar
				5, -- GroupTypeId - int
				@EcolabAccountNumber, -- EcolabAccountNumber - nvarchar
				0, -- Is_Deleted - bit
				0, -- LastModifiedByUserId - int
				GETUTCDATE(), -- LastModifiedTime - datetime
				GETUTCDATE(), -- LastSyncTime - datetime
				NULL -- MyServiceCustMchGrpGuid - uniqueidentifier
			)

			SET @IsExists = 0
	END

SELECT @IsExists