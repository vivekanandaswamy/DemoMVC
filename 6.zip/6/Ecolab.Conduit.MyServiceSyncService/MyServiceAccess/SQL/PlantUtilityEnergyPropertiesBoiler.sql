-- Plant Utility Water Factor data

/*
DECLARE		@EcolabAccountNumber		CHAR(10)
		,	@TimeStamp					DATETIME


SET			@TimeStamp									=			'01 Jan 1900'
*/


SELECT 
							CAST
							(
									CASE BLR_STM_IND	
										WHEN 'Y'
										THEN 'TRUE'
										WHEN 'N'
										THEN 'FALSE'
									END
								AS BIT
							)							AS					BoilerSteam
						,	STM_FCTR					AS					SteamPercentage
						,	BLR_FCTR					AS					BoilerPercentage
						,	STCK_FCTR					AS					StackPercentage						
						,	ELCTRICTY_PER_UNIT_PRC		AS					ElectricTarif
						,	CAST
							(
								CASE (SELECT ur.UTIL_NM FROM dbo.UTIL_REF ur WHERE ur.UTIL_ID = BLR_TYP_ID)
									WHEN 'Boiler'
									THEN 1
									WHEN 'Direct Fire'
									THEN 2
									ELSE 0
								END
								AS INT
							)							AS					BoilerType			
FROM						CUST_UTIL_FCTR 
WHERE						CUST_GUID 
IN 
		(
			SELECT			CUST_GUID 
			FROM			CUST 
			WHERE			CUST_ACCT_NBR				=					@EcolabAccountNumber
		)
AND							MOD_DTTM					>=					@TimeStamp