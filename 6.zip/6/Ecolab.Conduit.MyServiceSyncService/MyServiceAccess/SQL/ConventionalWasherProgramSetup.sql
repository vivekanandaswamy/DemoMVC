--Washer Groups To formula association (Conventional)
--adding filter for WasherGroup	@CustMchGrpGuid
DECLARE	@CustGUID				UNIQUEIDENTIFIER

SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
											)

SELECT	--*	,
	--														WasherProgramSetupId				--Conduit generated Id
	--														EcolabAccountNumber					--Conduit EcolabAccountNumber
	--														WasherGroupId						--Conduit WasherGroupId
		@EcolabAccountNumber					AS			EcolabAccountNumber
	,	F.FRMULA_NBR							AS			ProgramNumber
	--														Description							--No
	--											AS			ProgramId							--Conduit ProgramId
	--,	NULL									AS			NominalLoad							--**	Clarity sought
		--Adding below sub-query to get NominalLoad if avlbl at Group-level, if not, calculating based on SOIL_WGT and CAP -
		--for the machine with highest capcity in that group and as defined at machine-level in CUST_FRMULA_MCH_XREF
	,	ISNULL	(	FMGX.SOIL_WGT_PCTG
				,	(
					SELECT	TOP 1
							(FMX.SOIL_WGT * 100) / M.MCH_CAP
					FROM	CUST_FRMULA_MCH_XREF			FMX
					JOIN	CUST_MCH						M
						ON	FMX.CUST_MCH_GUID				=			M.CUST_MCH_GUID
					WHERE	FMX.CUST_FRMULA_MCH_GRP_GUID	=			FMGX.CUST_FRMULA_MCH_GRP_GUID
						--AND	FMX.ROW_STAT_IND				=			'A'
						--AND	M.ROW_STAT_IND					=			'A'
						AND	FMX.SOIL_WGT					IS NOT		NULL
						AND	M.MCH_CAP						IS NOT		NULL
						AND	FMX.SOIL_WGT_UOM_ID				=			M.MCH_CAP_UOM_ID
					ORDER BY
							M.MCH_CAP	DESC				-->	take the TOP 1 machine withe highest capcity defined in the group
					)
				)								AS			NominalLoad	
	,	(
		SELECT	SUM(FS.WSH_OP_TM)
		FROM	CUST_FRMULA_STP					FS
		WHERE	FS.CUST_GUID					=			C.CUST_GUID
			AND	FS.CUST_FRMULA_GUID				=			FMGX.CUST_FRMULA_GUID
			--AND	FS.ROW_STAT_IND					=			'A'
		)										AS			TotalRunTime
	--														ExtraTime							--No
	,	(
		SELECT	COUNT(FS.CUST_FRMULA_STP_GUID)
		FROM	CUST_FRMULA_STP					FS
		WHERE	FS.CUST_GUID					=			C.CUST_GUID
			AND	FS.CUST_FRMULA_GUID				=			FMGX.CUST_FRMULA_GUID
			--AND	FS.ROW_STAT_IND					=			'A'
		)										AS			TotalSteps
	--														FinalExtractingTime					--No
	--														CustomProgramName					--No
	--														PlantProgramNumber					--No
	,	CAST	(
				CASE	FMGX.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)								AS			Is_Deleted
	,	FMGX.CUST_FRMULA_MCH_GRP_GUID			AS			MyServiceCustFrmulaMchGrpGUID
	,	FMGX.MOD_DTTM							AS			MyServiceModDtTm
	,	FMGX.CUST_MCH_GRP_GUID					AS			MyServiceMchGrpGuid
	,	F.FRMULA_NM								AS			FormulaName							--Newly added; not in Conduit
	,	CASE	WHEN	FTR.FRMULA_TYP_NM	=	'Current'
				THEN	'C'
				WHEN	FTR.FRMULA_TYP_NM	IN	('Proposed 1', 'Proposed 2', 'Proposed 3', 'Proposed 4')
				THEN	'P'
				ELSE	NULL
		END										AS			FormulaTypeCode						--Newly added; not in Conduit
FROM	CUST									C
JOIN	CUST_MCH_GRP							MG
	ON	C.CUST_GUID								=			MG.CUST_GUID
	AND	MG.CUST_MCH_GRP_NBR						<>			0									--excluding stand alone groups
JOIN	MCH_TYP_REF								MTR
	ON	MG.MCH_GRP_TYP							=			MTR.MCH_TYP_ID
	AND	MTR.MCH_TYP_NM							=			'Conventional'
JOIN	CUST_FRMULA_MCH_GRP_XREF				FMGX
	ON	MG.CUST_MCH_GRP_GUID					=			FMGX.CUST_MCH_GRP_GUID
	AND	FMGX.ASSN_TYP_CD						=			'G'
JOIN	CUST_FRMULA_REF							F
	ON	FMGX.CUST_FRMULA_GUID					=			F.CUST_FRMULA_GUID
	AND	C.CUST_GUID								=			F.CUST_GUID
	--AND	F.FRMULA_TYP_ID							=			3									-->Current formula
	--Commenting the above and replacing with join below + filter below, since now we want Current and Proposed with PROD_TO_CRNT_IND flag set
JOIN	FRMULA_TYP_REF							FTR													--Adding for the below filter condn. + FormulaType to be returned
	ON	F.FRMULA_TYP_ID							=			FTR.FRMULA_TYP_ID
				
WHERE	C.CUST_GUID								=			@CustGUID
	AND	MG.CUST_GUID							=			@CustGUID
	AND	MG.CUST_MCH_GRP_GUID					=			ISNULL(@CustMchGrpGuid	,MG.CUST_MCH_GRP_GUID)
	AND	C.CUST_TYP_ID							=			1
	AND	FMGX.MOD_DTTM							>=			ISNULL(@TimeStamp, '01 Jan 1900')
	AND	(
			FTR.FRMULA_TYP_NM					=			'Current'
		OR	(	FTR.FRMULA_TYP_NM				IN			('Proposed 1', 'Proposed 2', 'Proposed 3', 'Proposed 4')
			AND	F.PRPD_TO_CRNT_IND				=			1										--'TRUE'	This is smallint with 0/1 vals and not BIT as anticipated
			)
		)
	

