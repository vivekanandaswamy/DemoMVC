DECLARE	@CustGUID				UNIQUEIDENTIFIER
,	@CntctTitleID				INT
,	@CntctAddrGuid				UNIQUEIDENTIFIER				

SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
											)

SELECT @CntctTitleID = CTR.COURTESY_TTL_ID FROM COURTESY_TTL_REF CTR WHERE CTR.COURTESY_TTL_NM = @ContactTitle

SET @CntctAddrGuid = NEWID()

IF NOT EXISTS (SELECT 1 FROM CNTCT WHERE CNTCT_GUID = @MyServiceCntctGuid)
	BEGIN
		INSERT INTO CNTCT
		(
			 CNTCT_GUID
			,CUST_GUID
			,COURTESY_TTL_ID
			,FRST_NM
			,LST_NM			
			,EMAIL_ID			
			,OFFC_PH_NBR		
			,MOBILE_PH_NBR	
			,FAX_NBR
			,CNTCT_POSN_ID
			,ROW_STAT_IND
			,RGN_CD)
		VALUES
		(	 @MyServiceCntctGuid
			,@CustGUID
			,@CntctTitleID
			,@FirstName
			,@LastName
			,@EmailId
			,@OfficePhnNo
			,@MobilePhnNo
			,@FaxNo
			,@ContactPositionId
			,CASE @IsDelete 
					WHEN	0
					THEN	'A'
					WHEN	1
					THEN	'I'
					ELSE	'A'
			END
			,'NA')
		
	END
ELSE
	BEGIN
		UPDATE CNTCT
		SET
			FRST_NM				=		@FirstName
		,	LST_NM				=		@LastName
		,	EMAIL_ID			=		@EmailId
		,	OFFC_PH_NBR			=		@OfficePhnNo
		,	MOBILE_PH_NBR			=		@MobilePhnNo
		,	FAX_NBR				=		@FaxNo
		,	CNTCT_POSN_ID			=		@ContactPositionId
		,	COURTESY_TTL_ID			=		@CntctTitleID
		,	ROW_STAT_IND			=		CASE @IsDelete 
											WHEN	0
											THEN	'A'
											WHEN	1
											THEN	'I'
											ELSE	'A'
										END
		WHERE CNTCT_GUID		=		@MyServiceCntctGuid
	END


	IF NOT EXISTS (SELECT 1 FROM dbo.CNTCT_ADDR ca WHERE ca.CNTCT_GUID = @MyServiceCntctGuid)
	BEGIN
	    INSERT INTO dbo.CNTCT_ADDR
	    (
	       CNTCT_ADDR_GUID,
	       CNTCT_GUID,
	       ADDR_TYP_ID,
	       SRC_SYS_CD,
	       ADDR_LN_1,
	       ADDR_LN_2,
	       ADDR_LN_3,
	       CTY_NM,
	       POST_CD,
	       ST_ID,
	       CNTRY_ID,
	       MSTR_DATA_FLG,
	       ROW_DEL_FLG,
	       ROW_STAT_IND
	    )
	    SELECT  @CntctAddrGuid,
		    @MyServiceCntctGuid,
		    4,
		    ca2.SRC_SYS_CD,
		    ca2.ADDR_LN_1, 
		    ca2.ADDR_LN_2, 
		    ca2.ADDR_LN_3, 
		    ca2.CTY_NM, 
		    ca2.POST_CD, 
		    ca2.ST_ID, 
		    ca2.CNTRY_ID,
		    N'N',
		    N'N',
		   CASE @IsDelete 
			WHEN	0
			THEN	'A'
			WHEN	1
			THEN	'I'
			ELSE	'A'
		    END
	    FROM dbo.CUST_ADDR ca2 
	    WHERE ca2.CUST_GUID = @CustGUID
	    AND ca2.ADDR_TYP_ID = 1
	END
	