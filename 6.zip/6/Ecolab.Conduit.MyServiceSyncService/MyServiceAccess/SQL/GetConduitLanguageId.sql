SELECT 
		lm.LanguageId 
FROM	tcd.LanguageMaster						lm 
WHERE	lm.MyServiceISOLangCD		=			@LanguageCode