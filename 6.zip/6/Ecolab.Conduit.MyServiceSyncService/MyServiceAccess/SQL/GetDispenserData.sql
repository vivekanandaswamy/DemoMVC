 SELECT C.ControllerId  
  ,C.ControllerModelId  
  ,CM.NAME ControllerModelName  
  ,C.NAME ControllerName  
  ,C.ControllerNumber  
  ,C.ControllerTypeId  
  ,CT.NAME AS ControllerType  
  ,C.ControllerVersion  
  ,C.InstallDate  
  ,C.EcoalabAccountNumber  
  ,C.LastModifiedTime  
  ,C.LastSyncTime  
  ,C.IsDeleted  
  ,C.TopicName  
  ,CMCTM.MaximumWasherExtractorCount WasherExtractorCount  
  ,CMCTM.MaxTunnelCount tunnelCount  
  , C.MyServiceDispenserGUID
  , CSD.Value AS SerialNumber
  , P.RegionId
 FROM [TCD].ConduitController C  
 INNER JOIN [TCD].ControllerModel CM ON CM.Id = C.ControllerModelId  
 INNER JOIN [TCD].ControllerType CT ON CT.Id = C.ControllerTypeId  
 INNER JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON C.ControllerTypeId = CMCTM.ControllerTypeId  
  AND C.ControllerModelId = CMCTM.ControllerModelId  
  INNER JOIN tcd.controllersetupdata CSD ON CSD.ControllerId = C.ControllerId AND C.ControllerModelId = CSD.ControllerModelId 
  and CSD.EcolabAccountNumber = C.EcoalabAccountNumber
   INNER JOIN TCD.Plant P ON P.EcolabAccountNumber = C.EcoalabAccountNumber
 WHERE C.EcoalabAccountNumber = @EcolabAccountNumber    
  AND c.ControllerId <> 0  
  AND CSD.FieldId IN (select  F.id from [TCD].[FieldGroup] FG  
  INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId  
  INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId  
  LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId  
  LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId   
  LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId 
  LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id AND FRM.RoleId=9
    where FG.TabId = '1' 
  AND label like '%serial%' AND FG.[ControllerModelId] = C.ControllerModelId  
 AND  
 FG.[ControllerTypeId] = C.ControllerTypeId)