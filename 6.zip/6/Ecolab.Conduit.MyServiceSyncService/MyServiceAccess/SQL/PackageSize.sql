SELECT
	--*
	--,														PackageSizeId				--This is Conduitgenerated Id
		PKG_SZ_DESC								AS			PackageSizeDescription

	,	UNIT_PER_PKG							AS			UnitPerPackage

	,	UNIT_WGT_VOL							AS			UnitWeightVolume
	,	UNIT_WGT_VOL_UOM_ID						AS			UnitWeightVolumeUOMId		--Not to be persisted as-is; This is to be translated into equivalent Conduit Id

	,	PKG_SZ_VOL								AS			PackageSizeVolume
	,	PKG_SZ_VOL_UOM_ID						AS			PackageSizeVolumeUOMId		--Not to be persisted as-is; This is to be translated into equivalent Conduit Id

	,	PKG_SZ_WGT								AS			PackageSizeWeight
	,	PKG_SZ_WGT_UOM_ID						AS			PackageSizeWeightUOMId		--Not to be persisted as-is; This is to be translated into equivalent Conduit Id

	,	PKG_SZ_DENSITY							AS			PackageSizeDensity
	,	PKG_SZ_DENSITY_UOM_ID					AS			PackageSizeDensityUOMId		--Not to be persisted as-is; This is to be translated into equivalent Conduit Id

	,	RGN_CD									AS			RegionCode					--Not to be persisted as-is; This is to be translated into equivalent Conduit Id
	,	CAST(		CASE		PSR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
			AS	BIT
			)									AS			IsDeleted
	,	PKG_SZ_ID								AS			MyServicePkgSzId
	,	PSR.MOD_DTTM								AS			MyServiceModDtTm			--Not to be persisted in Conduit
	,	UR.UOM_CD								AS			UOMCode
FROM	PKG_SZ_REF								PSR
INNER JOIN UOM_REF									UR
ON PSR.UNIT_WGT_VOL_UOM_ID = UR.UOM_ID

WHERE	PSR.MOD_DTTM							>=				@TimeStamp
	
ORDER BY
		PSR.PKG_SZ_ID
