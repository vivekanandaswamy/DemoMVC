DECLARE		@Cust_Formula_Guid	UNIQUEIDENTIFIER
		,	@ErrorId	INT		


SET		@Cust_Formula_Guid		=			(
											SELECT	cfmgx.CUST_FRMULA_GUID 
											FROM	dbo.CUST_FRMULA_MCH_GRP_XREF		cfmgx 
											WHERE	cfmgx.CUST_FRMULA_MCH_GRP_GUID		=			@MyServiceCustFrmulaMchGrpGuid
											)		

SET @ErrorId = 0

IF NOT EXISTS (SELECT 1 FROM [dbo].[FRMULA_STP_DSG_DVC_XREF] WHERE [FRMULA_STP_DSG_DVC_GUID] = @MyServiceFrmulaStpDsgDvcGUID )
	BEGIN
		INSERT INTO [dbo].[FRMULA_STP_DSG_DVC_XREF]
           (
				[FRMULA_STP_DSG_DVC_GUID]
			   ,[CUST_FRMULA_GUID]
			   ,[CUST_FRMULA_STP_GUID]
			   ,[CUST_MCH_CMPMT_DSG_DVC_GUID]
			   ,[DSG_METH_ID]
			   ,[DSG_VOL]
			   ,[DSG_VOL_UOM_ID]
			   ,[ROW_STAT_IND]
		   )
     VALUES
           (
				@MyServiceFrmulaStpDsgDvcGUID
			,	@Cust_Formula_Guid
			,	@MyServiceCusrFrmulaStpGuid
			,	@MyServiceCmpmtDsgDvcguid
			,	1
			,	@Quantity
			,	41
			,	CASE  @IsDelete 
				WHEN	0
				THEN	'A'
				WHEN	1
				THEN	'I'
				ELSE	'A'
			END
		   )

		SET	@ErrorId	=	@@ERROR
	END
ELSE
	BEGIN
		UPDATE [dbo].[FRMULA_STP_DSG_DVC_XREF]
		SET
				[CUST_FRMULA_GUID]				=		@Cust_Formula_Guid
			,	[CUST_FRMULA_STP_GUID]			=		@MyServiceCusrFrmulaStpGuid
			,	[CUST_MCH_CMPMT_DSG_DVC_GUID]	=		@MyServiceCmpmtDsgDvcguid
			,	[DSG_METH_ID]					=		1
			,	[DSG_VOL]						=		@Quantity
			,	[DSG_VOL_UOM_ID]				=		41
			,	[ROW_STAT_IND]					=		CASE  @IsDelete 
															WHEN	0
															THEN	'A'
															WHEN	1
															THEN	'I'
															ELSE	'A'
														END
		WHERE [FRMULA_STP_DSG_DVC_GUID] = @MyServiceFrmulaStpDsgDvcGUID 

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId




