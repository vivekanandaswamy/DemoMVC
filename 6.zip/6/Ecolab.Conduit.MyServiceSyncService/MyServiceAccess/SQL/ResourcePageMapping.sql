SELECT	
			rkpm.Id, 
			rkpm.ResourceId,
			rkpm.PageId 

FROM		tcd.ResourceKeyPageMapping rkpm

WHERE		rkpm.ResourceId				=			@ResourceId