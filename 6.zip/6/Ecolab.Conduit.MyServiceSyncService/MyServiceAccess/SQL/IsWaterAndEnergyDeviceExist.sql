DECLARE @IsExists BIT = 0	


IF EXISTS (SELECT 1 FROM TCD.WaterAndEnergy wae WHERE wae.EcolabAccountNumber = @EcolabAccountNumber AND wae.MyServiceCustWtrEnrgDvcGuid = @MyServiceCustWtrEnrgDvcGUID)
	BEGIN
		SET @IsExists = 1
	END
ELSE
	BEGIN
		SET @IsExists = 0
	END 

SELECT @IsExists