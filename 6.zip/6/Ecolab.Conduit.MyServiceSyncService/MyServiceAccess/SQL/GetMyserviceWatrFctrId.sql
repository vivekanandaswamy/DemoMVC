SELECT wt.MyServiceUtilId 
FROM TCD.WaterType wt 
INNER JOIN TCD.Plant p 
ON wt.RegionID = p.RegionId
WHERE p.EcolabAccountNumber = @EcolabAccountNumber
AND wt.Id = @WaterFactrId