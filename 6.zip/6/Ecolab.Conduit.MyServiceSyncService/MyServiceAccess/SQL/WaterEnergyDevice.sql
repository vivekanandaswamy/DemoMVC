--Plant Contacts

--DECLARE	@TimeStamp				DATETIME

--SET		@TimeStamp				=			'01 Jan 1900'

DECLARE	@CustGUID				UNIQUEIDENTIFIER

SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
											)
												
SELECT	@EcolabAccountNumber					AS			EcolabAccountNumber
	,	CWED.WTR_ENRG_DVC_NBR					AS			DeviceNumber
	,	(select WTR_ENRG_DVC_TYP_ID from WTR_ENRG_DVC_REF where WTR_ENRG_DVC_ID = CWED.WTR_ENRG_DVC_ID)									AS			DeviceTypeId
	,	CWED.WTR_ENRG_DVC_ID					AS			DeviceModelId
	,	CWED.NTE_TXT							AS			Comment
	,	CWED.DVC_INSTL_DT						AS			InstallDate
	,	CAST(	CASE	CWED.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
			AS	BIT)							AS			Is_Deleted
	,	CWED.CUST_WTR_ENRG_DVC_GUID				AS			MyServiceCustWtrEnrgDvcGuid
	,	CWED.MOD_DTTM							AS			MyServiceLastModDtTm
FROM	CUST_WTR_ENRG_DVC						CWED
WHERE	CWED.CUST_GUID								=			@CustGUID
	AND	CWED.MOD_DTTM								>=			@TimeStamp
