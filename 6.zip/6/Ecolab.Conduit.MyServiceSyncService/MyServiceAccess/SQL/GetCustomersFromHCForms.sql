DECLARE @ChainContract INT
SET @ChainContract = (SELECT
                                  tc.Id FROM dbo.tblContract AS tc WHERE tc.ContractNo = @ContractNumber)

SELECT
        tusu.FirstName, 
        tusu.LastName, 
        tusu.Phone, 
        tusu.Email, 
        tusu.Country, 
        tusu.[Language], 
        tusu.Region, 
       CAST(
				CASE	tusu.DeleteFlag
					WHEN	'True'
					THEN	0
					WHEN	'False'
					THEN	1
					ELSE	1
				END
			AS	BIT
			) as [Status], 
        tusu.ChainContract,
		tusu.EvisionRole
    FROM dbo.tblUserSetUp AS tusu
    WHERE tusu.ChainContract = @ChainContract