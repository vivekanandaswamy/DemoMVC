DECLARE @ReturnValue int

IF EXISTS (
		SELECT 1 FROM TCD.UserMaster um 
			WHERE 
				um.LoginName = @UserLogin 
			AND um.EcolabAccountNumber = @EcolabAccountNumber
			 )
	BEGIN
		SET @ReturnValue = (SELECT TOP 1 um.UserId FROM TCD.UserMaster um WHERE um.EcolabAccountNumber = @EcolabAccountNumber and um.LoginName = @UserLogin and IsActive = 1)
	END

ELSE
	BEGIN
		SET @ReturnValue = 101
	END

SELECT @ReturnValue