
SELECT mwlr.MCH_ID AS MyServiceMchId,
       mwlr.WTR_LVL_IN_IN AS WaterLevel,
       mwlr.WTR_LVL_VOL AS WaterLevelVolume,
       ur.UOM_CD, 
	   ur.UOM_DESC AS UomDescription,
       convert(bit, CASE WHEN(mwlr.ROW_STAT_IND = 'A') 
	   THEN 0
	   ELSE 1 END ) AS  IsDelete
FROM dbo.MCH_WTR_LVL_REF mwlr
INNER JOIN dbo.UOM_REF ur
ON ur.UOM_ID = mwlr.WTR_LVL_VOL_UOM_ID
WHERE mwlr.MOD_DTTM >= ISNULL(@TimeStamp, '01-01-1990')
ORDER BY mwlr.MCH_ID