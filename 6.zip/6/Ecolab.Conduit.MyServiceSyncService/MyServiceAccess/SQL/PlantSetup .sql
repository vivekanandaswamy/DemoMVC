/*
--Plant details
DECLARE	@EcolabAccountNumber	NVARCHAR(1000)
	,	@TimeStamp				DATETIME

	SET @EcolabAccountNumber = NULL
*/


SELECT
         C.CUST_ACCT_NBR											AS			EcolabAccountNumber
     ,   C.CUST_FULL_NM												AS			[Name]							--This is to be CONFIRMED, if the source field is correct. CONFIRMED.
	 ,	 C2.CNTRCT_NM												AS			ChainName
	 ,	 (SELECT	TOP	1
					EMP.EMP_FULL_NM
		FROM	CUST_EMP_SHR		CES
		JOIN	EMP					EMP
			ON	CES.EMP_ID			=	EMP.EMP_ID
		WHERE	CES.CUST_GUID		=	C.CUST_GUID
			AND	CES.ROW_STAT_IND	=	'A'
			AND	EMP.ROW_STAT_IND	=	'A'
			AND	EMP.ROLE_CD			=	'TERR_MNGR'
			AND EMP.ROW_DEL_FLG		=	'N'
			AND CES.ROW_DEL_FLG		=	'N'
			AND CES.PRIM_ASGN_IND	=	'Y' 
			AND	CES.ACCT_SHR_CD		=	'P'
         ORDER BY
					CES.CUST_EMP_SHR_ID
		)															AS			TMName
     ,	 (SELECT	TOP	1
					EMP.EMP_PH_NBR
		FROM	CUST_EMP_SHR		CES
		JOIN	EMP					EMP
			ON	CES.EMP_ID			=	EMP.EMP_ID
		WHERE	CES.CUST_GUID		=	C.CUST_GUID
			AND	CES.ROW_STAT_IND	=	'A'
			AND	EMP.ROW_STAT_IND	=	'A'
			AND	EMP.ROLE_CD			=	'TERR_MNGR'
			AND EMP.ROW_DEL_FLG		=	'N'
			AND CES.ROW_DEL_FLG		=	'N'
			AND CES.PRIM_ASGN_IND	=	'Y' 
			AND	CES.ACCT_SHR_CD		=	'P'
         ORDER BY
					CES.CUST_EMP_SHR_ID
		)															AS			TMPhoneNumber					--Mapping given but not navigable, but clarity needed. CLARIFIED
     ,	 (SELECT  TOP 1
				SA.DIST_EMP_FULL_NM
		FROM    SLS_ALGN			SA
		--JOIN	EMP					EMP_DM									--> we should not require this addnl. join here, as in DM Phone number sub-query
		--	ON	SA.DIST_EMP_NBR		=			EMP_DM.EMP_NBR
		WHERE	SA.TERR_EMP_ID		=			(							--Using the TM's EMP_ID, get the DM's name from SLS_ALGN!
												SELECT	TOP	1				--Get the TM's EMP_ID for the CUST...
														EMP.EMP_ID			AS	TM_EMP_ID
												FROM	CUST_EMP_SHR		CES
												JOIN	EMP					EMP
													ON	CES.EMP_ID			=	EMP.EMP_ID
												WHERE	CES.CUST_GUID		=	C.CUST_GUID
													AND	CES.PRIM_ASGN_IND	=	'Y'
													AND CES.ACCT_SHR_CD		=	'P'
													AND	CES.ROW_STAT_IND	=	'A'
													AND CES.ROW_DEL_FLG		=	'N'
													AND EMP.ROW_STAT_IND	=	'A'
													AND	EMP.ROLE_CD			=	'TERR_MNGR'
													AND EMP.ROW_DEL_FLG		=	'N'
			
         ORDER BY
				    CES.CUST_EMP_SHR_ID
												)
			AND	SA.ROW_STAT_IND		=			'A'
         ORDER BY
				SA.SLS_ALGN_CD
			,	SA.SRC_SYS_CD
		)															AS			DMName
     ,	(SELECT  TOP 1
				EMP_DM.EMP_PH_NBR
		FROM    SLS_ALGN			SA
		JOIN	EMP					EMP_DM
			ON	SA.DIST_EMP_NBR		=			EMP_DM.EMP_NBR
		WHERE	SA.TERR_EMP_ID		=			(							--Using the TM's EMP_ID and DIST_EMP_NBR in SLS_ALGN, get the DM's Ph. nbr from EMP!
												SELECT	TOP	1				--Get the TM's EMP_ID for the CUST...
														EMP.EMP_ID			AS	TM_EMP_ID
												FROM	CUST_EMP_SHR		CES
												JOIN	EMP					EMP
													ON	CES.EMP_ID			=	EMP.EMP_ID
												WHERE	CES.CUST_GUID		=	C.CUST_GUID
													AND	CES.PRIM_ASGN_IND	=	'Y'
													AND CES.ACCT_SHR_CD		=	'P'
													AND	CES.ROW_STAT_IND	=	'A'
													AND CES.ROW_DEL_FLG		=	'N'
													AND EMP.ROW_STAT_IND	=	'A'
													AND	EMP.ROLE_CD			=	'TERR_MNGR'
												ORDER BY
					CES.CUST_EMP_SHR_ID
												)
			AND	SA.ROW_STAT_IND		=			'A'
		ORDER BY
				SA.SLS_ALGN_CD
			,	SA.SRC_SYS_CD
		)															AS			DMPhoneNumber
     ,	C.UNIT_NBR													AS			ChainUnitNumber
     ,	CCT.CENS_TYP_FRST_TGT_VAL									AS			CensusPriceKg			     --Mapping given but not navigable, but clarity needed
	 ,	CCT_UOM.UOM_DESC											AS			CensusPriceKg_UOM
	 ,	CCT_CR.CURR_CD												AS			CensusPriceKg_CurrencyCode
     ,	C.NTE_TXT													AS			Remarks
	 ,	C.LANG_ID													AS			LanguageId
     ,	LR.ISO_LANG_CD												AS			LanguageCode
	 ,	CR.CURR_CD													AS			CurrencyCode
	 ,	C.RGN_CD													AS			RegionCode				      --In Conduit we need to map this to RegionId from RegionMaster; MyService doesn't have a RegionID
	 ,	CASE	C.RGN_CD
			WHEN	'NA'
			THEN	'US Default'
			WHEN	'EMEA'
			THEN	'Metrics Default'
			WHEN	'APLA'
			THEN	'US Default'
			ELSE	'US Default'
		END															AS				UOMDesc						  --Mapping given but not navigable, but clarity needed. CLARIFIED. See ref. qry below
	,	CASE	C.RGN_CD
			WHEN	'NA'
			THEN	C.CNTRCT_ID
			WHEN	'EMEA'
			THEN	C.CHN_ID
			WHEN	'APLA'
			THEN	C.CHN_ID
			ELSE	C.CNTRCT_ID
		END															AS				PlantChainId	
	   ,	 CAST    (
                 CASE    C.ROW_STAT_IND
                     WHEN    'A'
                     THEN    'FALSE'
                     WHEN    'I'
                     THEN    'TRUE'
                     ELSE    'FALSE'
                 END
         AS    BIT    )												AS			IsDeleted
     ,    C.CUST_GUID												AS			MyServiceCustGuid
	 ,    C.SYNC_DTTM												AS			MyServiceModDtTm


	--adding enVision reqd. fields
	,	(
		SELECT	TOP	1																	--TOP 1 is since, there seems to be some erroneous data in myservice
				SA.DIST_NM																--Can be removed, once we are sure, that only 1 DIST_NM will be returned for a CUST
		FROM	CUST_EMP_SHR					CES 
		JOIN	EMP								EMP 
			ON	CES.EMP_ID						=			EMP.EMP_ID
		JOIN	(
				SELECT	DISTINCT 
						DIST_NM, TERR_NM, TERR_EMP_ID, SRC_SYS_CD 
				FROM	SLS_ALGN
				WHERE	ROW_STAT_IND			=			'A'
				)	SA
			ON	SA.TERR_EMP_ID					=			CES.EMP_ID
		WHERE	CES.CUST_GUID					=			C.CUST_GUID
			AND CES.ROW_STAT_IND				=			'A' 
			AND CES.ROW_DEL_FLG					=			'N'
			AND EMP.ROW_STAT_IND				=			'A'
			AND EMP.ROLE_CD						=			'TERR_MNGR'
			AND CES.PRIM_ASGN_IND				=			'Y' 
			AND	CES.ACCT_SHR_CD					=			'P'
		ORDER By
				CES.CUST_EMP_SHR_ID	,SA.TERR_EMP_ID
		)															AS			SalesDistrictName
	,	(
		SELECT	TOP	1
				SA.TERR_NM
		FROM	CUST_EMP_SHR					CES 
		JOIN	EMP								EMP 
			ON	CES.EMP_ID						=			EMP.EMP_ID
		JOIN	(
				SELECT	DISTINCT 
						DIST_NM, TERR_NM, TERR_EMP_ID, SRC_SYS_CD 
				FROM	SLS_ALGN
				WHERE	ROW_STAT_IND			=			'A'
				)	SA
			ON	SA.TERR_EMP_ID					=			CES.EMP_ID
		WHERE	CES.CUST_GUID					=			C.CUST_GUID
			AND CES.ROW_STAT_IND				=			'A' 
			AND CES.ROW_DEL_FLG					=			'N'
			AND EMP.ROW_STAT_IND				=			'A'
			AND EMP.ROLE_CD						=			'TERR_MNGR'
			AND PRIM_ASGN_IND					=			'Y' 
			AND	ACCT_SHR_CD						=			'P'
		ORDER By
				CES.CUST_EMP_SHR_ID	,SA.TERR_EMP_ID
		)															AS			SalesTerritoryName
	,	CnTry.CNTRY_CD												AS			PlantCountryCode
	,	CustLogo.CUST_LOGO_IMG										AS			CustLogo
	,	C2.CNTRCT_NBR												AS			ContractNumber
	,	(SELECT TOP 1 dsvd.SVC_VST_DAY_END_TS FROM dbo.SERVICECALLHEADER s
			INNER JOIN dbo.DLY_SVC_VST_DTL dsvd 
		ON dsvd.SERVICECALLHEADERID = s.SERVICECALLHEADERID
		WHERE s.ROW_STAT_IND = 'A' 
			AND dsvd.ROW_STAT_IND = 'A' 
			AND s.CUST_GUID = C.CUST_GUID 
		ORDER BY dsvd.SVC_VST_DAY_END_TS DESC )						AS			LastServiceVisitDate
	,	(SELECT TOP 1 s.DATE_SCHEDULED 
		FROM dbo.SERVICECALLSCHEDULE s 
		WHERE s.CUST_GUID = C.CUST_GUID
			AND s.ROW_STAT_IND = 'A' 
		ORDER BY s.DATE_SCHEDULED DESC )							AS			NextServiceVisitDate
	,	C.SRC_SYS_CD											    AS			SourceSystemCode
FROM	CUST									C
LEFT JOIN
		dbo.CNTRCT C2
	ON	C2.CNTRCT_ID = C.CNTRCT_ID AND C2.ROW_STAT_IND = C.ROW_STAT_IND	
--to get CurrencyCode
LEFT JOIN
		CURR_REF								CR
	ON	C.CURR_ID								=			CR.CURR_ID
LEFT JOIN
		CUST_CENS_TYP							CCT
	ON	C.CUST_GUID								=			CCT.CUST_GUID AND CCT.ROW_STAT_IND = C.ROW_STAT_IND
LEFT JOIN
		CENS_TYP_REF							CTR
	ON	C.RGN_CD								=			CTR.RGN_CD
	AND	CTR.CENS_TYP_NM							=			'Kg'
	AND	CCT.CENS_TYP_ID							=			CTR.CENS_TYP_ID
--	--Adding 2 more joins to bring UOM and CURR...
LEFT JOIN
		UOM_REF									CCT_UOM
	ON	CCT.CENS_TYP_FRST_TGT_VAL_UOM_ID		=			CCT_UOM.UOM_ID
LEFT JOIN
		CURR_REF								CCT_CR
	ON	CCT.CENS_TYP_FRST_CURR_ID				=			CCT_CR.CURR_ID
----For data to enVision schema...
LEFT JOIN
		CNTRY_REF								CnTry
	ON	C.CNTRY_ID								=			CnTry.CNTRY_ID
LEFT JOIN 
		CUST_LOGO								CustLogo
	ON  C.CUST_GUID								=			CustLogo.CUST_GUID
LEFT JOIN
		dbo.LANG_REF							LR
	ON	LR.LANG_ID								=			C.LANG_ID
--get Active and if modified after the last updated timestamp
WHERE	C.CUST_ACCT_NBR							=			ISNULL(@EcolabAccountNumber, C.CUST_ACCT_NBR)
	AND	C.MOD_DTTM								>=			ISNULL(@TimeStamp, '01 Jan 1900')
	AND	C.CUST_TYP_ID							=			1	
	AND c.ROW_STAT_IND							=			'A'	
ORDER BY C.CUST_FULL_NM 			  
