--User	(for enVision)
/*
DECLARE	@DOMAIN_ACCT_NM				NVARCHAR(1000)
,		@EcolabAccountNumber		NVARCHAR(1000)
,		@Timestamp					datetime   = NULL
SET		@DOMAIN_ACCT_NM				=			N'ANDERM6'
SET		@EcolabAccountNumber		=			N'040242802'
*/
SELECT
		--* 
		DISTINCT
		LR.ISO_LANG_CD			AS			LanguageCode
	,	E.DOMAIN_ACCT_NM		AS			UserLogin
	,	ISNULL(	E.EMP_LST_NM
			,	E.EMP_FULL_NM)	AS			LastName
	,	ISNULL(E.EMP_FRST_NM 
			,	E.EMP_FULL_NM)	AS			FirstName
	--,	'S'						AS			UserType
	,	CAST(
				CASE	E.ROW_STAT_IND
					WHEN	'A'
					THEN	1
					WHEN	'I'
					THEN	0
					ELSE	1
				END
			AS	TINYINT
			)					AS			[Status]
	,	E.EMP_PH_NBR			AS			PhoneNumber
	,	CR.CNTRY_CD				AS			UserCountryCode
	,	E.EMP_NBR				AS			EmpId
	,	EMP_MGR.EMP_NBR			AS			ManId
	--,	TZR.GMT_OFFSET_NBR		AS			UserTimeZone					--This will be NULL
	,	E.ROLE_CD				AS			ExtendedUserType
FROM	EMP						E
INNER JOIN	CUST_EMP_SHR			CES
	ON	E.EMP_ID				=			CES.EMP_ID
INNER JOIN	CUST					C
	ON	CES.CUST_GUID			=			C.CUST_GUID
INNER JOIN
		EMP						EMP_MGR
	ON	E.MGR_ID				=			EMP_MGR.EMP_ID
LEFT JOIN
		LANG_REF				LR
	ON	E.LANG_ID				=			LR.LANG_ID
LEFT JOIN
		CNTRY_REF				CR
	ON	E.CNTRY_ID				=			CR.CNTRY_ID
--LEFT JOIN
--		TMZN_REF				TZR
--	ON	E.TMZN_ID				=			TZR.TMZN_ID

WHERE	E.ROLE_CD				IN			(	'TERR_MNGR'
											,	'DIST_MNGR'
											,	'RGN_MNGR'
											)
	AND C.CUST_ACCT_NBR			=			@EcolabAccountNumber
	AND	E.MOD_DTTM				>=			ISNULL(@Timestamp, '01 Jan 1900')
	AND	E.ROW_STAT_IND			=			'A'
	AND	CES.ROW_STAT_IND		=			'A'
	AND	C.ROW_STAT_IND			=			'A'
	AND	C.CUST_TYP_ID			=			1
