SELECT gotm.MyServiceUtilId 
FROM TCD.GasOilTypeMapping gotm 
INNER JOIN TCD.Plant p 
	ON p.RegionId = gotm.RegionId 
WHERE gotm.GasOilId = @GasOilTypeId AND p.EcolabAccountNumber = @EcolabAccountNumber