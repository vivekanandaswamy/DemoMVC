DECLARE	@CustGUID							UNIQUEIDENTIFIER
	,	@ErrorId							INT			
	,	@MyServiceWasherId					UNIQUEIDENTIFIER
	,	@CUST_DSG_DVC_GUID					UNIQUEIDENTIFIER
	,	@MyServiceCustMchDsgDvcGuid			UNIQUEIDENTIFIER	
	,	@MyServiceCustMchCmpmtDsgDvcGuid	UNIQUEIDENTIFIER
	,	@Cust_Formula_Guid					UNIQUEIDENTIFIER
	,	@DSG_DVC_NBR						INT

SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST								C
											WHERE	C.CUST_ACCT_NBR						=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID						=			1
											ORDER BY
													C.CUST_GUID
											)
SET		@MyServiceWasherId		=			(	SELECT	TOP 1 
														cm.CUST_MCH_GUID 
												FROM	dbo.CUST_MCH					cm 
												WHERE	cm.CUST_MCH_GRP_GUID			=			@MyServiceWasherGroupId)

SET		@Cust_Formula_Guid		=			(
											SELECT	cfmgx.CUST_FRMULA_GUID 
											FROM	dbo.CUST_FRMULA_MCH_GRP_XREF		cfmgx 
											WHERE	cfmgx.CUST_FRMULA_MCH_GRP_GUID		=			@MyServiceCustFrmulaMchGrpGuid
											)		
SET @DSG_DVC_NBR				=			(
											SELECT ISNULL(MAX(DSG_DVC_NBR),0)+1 FROM dbo.CUST_DSG_DVC WHERE CUST_GUID=@CustGUID
											)
IF NOT EXISTS (SELECT 1 FROM dbo.CUST_DSG_DVC cdd WHERE	cdd.PROD_ID	= @MyServiceProdId  AND	cdd.CUST_GUID	= @CustGUID)
	BEGIN
		INSERT INTO dbo.CUST_DSG_DVC
		( CUST_DSG_DVC_GUID
		, CUST_GUID
		, DSG_DVC_ID
		, PROD_ID
		, DSG_DVC_NBR
		, DSG_DVC_INSTL_DT
		, DSG_METH_ID)

		VALUES
		( NEWID()
		, @CustGUID
		, 0
		, @MyServiceProdId
		, @DSG_DVC_NBR
		, GETDATE()
		, 1)
	END

SET		@CUST_DSG_DVC_GUID		=			(
												SELECT		cdd.CUST_DSG_DVC_GUID	
												FROM		dbo.CUST_DSG_DVC cdd
												WHERE		cdd.PROD_ID					=			@MyServiceProdId 
												AND			cdd.CUST_GUID				=			@CustGUID
											)

SET @ErrorId = 0

SET @MyServiceCustMchDsgDvcGuid =	NEWID() 


IF NOT EXISTS (SELECT 1  FROM [dbo].CUST_MCH_CMPMT cmc WHERE cmc.CUST_MCH_GUID = @MyServiceWasherId)
	BEGIN
		INSERT INTO [dbo].CUST_MCH_CMPMT
		(	[CMPMT_NBR]
		,	[CUST_MCH_GUID]
		,	[CMPMT_TYP_CD]
		)
		VALUES
		(	1
		,	@MyServiceWasherId
		,	'C'
		)
	END
	IF NOT EXISTS (SELECT 1 FROM dbo.CUST_MCH_CMPMT_DSG_DVC_XREF cmcddx WHERE cmcddx.CUST_MCH_GRP_GUID = @MyServiceWasherGroupId AND cmcddx.CUST_MCH_GUID = @MyServiceWasherId
													AND cmcddx.CUST_DSG_DVC_GUID = @CUST_DSG_DVC_GUID
													AND	cmcddx.CUST_GUID = @CustGUID
										
				)
		BEGIN
			INSERT INTO dbo.CUST_MCH_CMPMT_DSG_DVC_XREF
			(	CUST_MCH_CMPMT_DSG_DVC_GUID
			,	CUST_MCH_GRP_GUID
			,	CUST_DSG_DVC_GUID
			,	CUST_MCH_GUID
			,	CMPMT_NBR
			,	ASSN_TYP_CD
			,	CUST_GUID
			)
			VALUES
			(	@MyServiceCustMchDsgDvcGuid
			,	@MyServiceWasherGroupId
			,	@CUST_DSG_DVC_GUID
			,	@MyServiceWasherId
			,	1
			,	'G'
			,	@CustGUID
			)
		END
SET			@MyServiceCustMchCmpmtDsgDvcGuid		=	(	SELECT		cmcddx.CUST_MCH_CMPMT_DSG_DVC_GUID 
															FROM		dbo.CUST_MCH_CMPMT_DSG_DVC_XREF					cmcddx 
															WHERE		cmcddx.CUST_MCH_GRP_GUID				=		@MyServiceWasherGroupId 
															AND			cmcddx.CUST_MCH_GUID					=		@MyServiceWasherId
															AND			cmcddx.CUST_DSG_DVC_GUID				=		@CUST_DSG_DVC_GUID
															AND			cmcddx.CUST_GUID						=		@CustGUID
														)

IF NOT EXISTS (SELECT 1 FROM [dbo].[FRMULA_STP_DSG_DVC_XREF] WHERE FRMULA_STP_DSG_DVC_GUID = @MyServiceFrmulaStpDsgDvcGUID AND CUST_FRMULA_GUID = @Cust_Formula_Guid)
	BEGIN
		INSERT INTO [dbo].[FRMULA_STP_DSG_DVC_XREF]
           (	[FRMULA_STP_DSG_DVC_GUID]
           ,	[CUST_FRMULA_GUID]
           ,	[CUST_FRMULA_STP_GUID]
           ,	[CUST_MCH_CMPMT_DSG_DVC_GUID]
		   ,	[DSG_METH_ID]
           ,	[DSG_VOL]
           ,	[DSG_VOL_UOM_ID]
           ,	[ROW_STAT_IND]
		   )
     VALUES
           (	@MyServiceFrmulaStpDsgDvcGUID
           ,	@Cust_Formula_Guid
		   ,	@MyServiceCusrFrmulaStpGuid
		   ,	@MyServiceCustMchCmpmtDsgDvcGuid
		   ,	1
		   ,	@Quantity
		   ,	41
		   ,	CASE  @IsDelete 
											WHEN	0
											THEN	'A'
											WHEN	1
											THEN	'I'
											ELSE	'A'
				END
		   )

		SET	@ErrorId	=	@@ERROR
	END
ELSE
	BEGIN
		UPDATE [dbo].[FRMULA_STP_DSG_DVC_XREF]
		SET
			[CUST_FRMULA_GUID]				=		@Cust_Formula_Guid
		,	[CUST_FRMULA_STP_GUID]			=		@MyServiceCusrFrmulaStpGuid
		,	[CUST_MCH_CMPMT_DSG_DVC_GUID]	=		@MyServiceCustMchCmpmtDsgDvcGuid
		,	[DSG_VOL]						=		@Quantity
		,	[DSG_VOL_UOM_ID]				=		41
		,	[ROW_STAT_IND]					=		CASE  @IsDelete 
														WHEN	0
														THEN	'A'
														WHEN	1
														THEN	'I'
														ELSE	'A'
													END
		WHERE [FRMULA_STP_DSG_DVC_GUID] = @MyServiceFrmulaStpDsgDvcGUID AND CUST_FRMULA_GUID = @Cust_Formula_Guid

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId




