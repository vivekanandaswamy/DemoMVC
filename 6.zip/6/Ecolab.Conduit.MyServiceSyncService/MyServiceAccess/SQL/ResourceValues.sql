SELECT 
			rkv.ResourceId
		,	rkv.[Value]
		,	rkv.Locale
		,	rkv.LanguageID
		,	rkv.LastModifiedTime
		,	rkv.Id 

FROM		tcd.ResourceKeyValue rkv 

WHERE		rkv.ResourceId				=			@ResourceId