DECLARE	@CustGUID UNIQUEIDENTIFIER,
@DosingDeviceId INT,
@SourceSystem VARCHAR(3),
@RegionName NVARCHAR(50),
@Prod_Id INT,
		@ErrorId					INT
			SET		@CustGUID					=			(
															SELECT	TOP 1
																	C.CUST_GUID
															FROM	CUST						C
															WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
																AND	C.CUST_TYP_ID				=			1
															ORDER BY
																	C.CUST_GUID
															)

SET @ErrorId = 0;
IF(@RegionId = 1)
BEGIN
	SET @RegionName = 'NA'
	SET @Prod_Id = 0
	SET @SourceSystem = 'STP';
END
ELSE
BEGIN
SET @RegionName = 'EMEA'
	SET @Prod_Id = -2
	SET @SourceSystem = 'EBS'
END

SET @DosingDeviceId = (Select  DSG_DVC_ID 
		from dsg_dvc_ref 
		where dsg_dvc_mdl_nm like @ControllerModelName 
			AND rgn_cd = @RegionName 
			AND ROW_STAT_IND = 'A')

IF NOT EXISTS (SELECT 1 FROM [dbo].[CUST_PROD_XREF] WHERE CUST_GUID = @CustGUID AND PROD_ID = @Prod_Id)
BEGIN
	INSERT INTO [dbo].[CUST_PROD_XREF] (
			[CUST_GUID],
			[PROD_ID],
			[SRC_SYS_CD],
			[MSTR_DATA_FLG],
			[ROW_STAT_IND],
			[CRE_DTTM],
			[CRE_OPER],
			[MOD_DTTM],
			[MOD_OPER]
		)
		  VALUES
           (@CustGUID
           ,@Prod_Id
		   ,@SourceSystem
		   , 'N'
           ,	CAST(CASE	@IsDelete
						WHEN	'FALSE'
						THEN	'A'
						WHEN	'TRUE'
						THEN	'I'
						ELSE	'A'
					END  AS Char(1)),
			GETUTCDATE(), 
			'TCD',
			GETUTCDATE(),
			'TCD'
			)
END

IF NOT EXISTS (SELECT 1 FROM [dbo].[CUST_DSG_DVC] WHERE CUST_DSG_DVC_GUID = @MyServiceDispenserGUID AND CUST_GUID = @CustGUID)
	BEGIN
	INSERT INTO [dbo].[CUST_DSG_DVC]
           ([CUST_DSG_DVC_GUID]
           ,[CUST_GUID]
           ,[DSG_DVC_ID]
		   ,[PROD_ID]
		   ,[DSG_DVC_NBR]
		   ,[DSG_DVC_INSTL_DT]
           ,[DSG_METH_ID]
           ,[DSG_DVC_SHAREABLE_IND]
		   ,[ROW_DEL_FLG]
           , [ROW_STAT_IND]
		   ,[CRE_DTTM]
		   ,[CRE_OPER]
		   ,[MOD_DTTM]
		   ,[MOD_OPER]
          )
     VALUES
           (@MyServiceDispenserGUID
           ,@CustGUID
		   ,@DosingDeviceId
		   ,@Prod_Id
		   ,@ControllerNumber
		   ,@InstallDate
		   , 4
		   , 'Y'
		   ,'N'
           ,	CAST(CASE	@IsDelete
						WHEN	'FALSE'
						THEN	'A'
						WHEN	'TRUE'
						THEN	'I'
						ELSE	'A'
					END  AS Char(1)),
			GETUTCDATE(), 
			'TCD',
			GETUTCDATE(),
			'TCD'
			)
	
		SET	@ErrorId	=	@@ERROR
	END
ELSE
	BEGIN
		UPDATE [dbo].[CUST_DSG_DVC]
		SET
			[DSG_DVC_NBR]			=		@ControllerNumber,
			[DSG_DVC_INSTL_DT]		=		@InstallDate,
			[ROW_STAT_IND]			=		CAST(CASE	@IsDelete
													WHEN	'FALSE'
													THEN	'A'
													WHEN	'TRUE'
													THEN	'I'
													ELSE	'A'
													END  AS Char(1)),
			MOD_DTTM			=				GetUTCDATE(),
			MOD_OPER			=				'TCD'
		WHERE CUST_DSG_DVC_GUID = @MyServiceDispenserGUID AND CUST_GUID = @CustGUID
		

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId




