DECLARE	@CustGUID	UNIQUEIDENTIFIER
	,	@MyServiceCustFrmulaGuid	UNIQUEIDENTIFIER	
	,	@ErrorId	INT			
SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
											)

SET @ErrorId = 0

IF (@MyServiceWaterTypeId = 0)
BEGIN
	SET @MyServiceWaterTypeId = NULL
END

IF (@MyServiceDrainTypId = 0)
BEGIN
	SET @MyServiceDrainTypId = NULL
END

IF (@MyServiceWashOprId = 0)
BEGIN
	SET @MyServiceWashOprId = NULL
END

Select @MyServiceCustFrmulaGuid = CUST_FRMULA_GUID  FROM  [dbo].[CUST_FRMULA_MCH_GRP_XREF] WHERE CUST_FRMULA_MCH_GRP_GUID = @MyServiceCustFrmulaMchGrpGuid AND CUST_GUID = @CustGUID

IF NOT EXISTS (SELECT 1 FROM [dbo].[CUST_FRMULA_STP] WHERE CUST_FRMULA_STP_GUID = @MyServiceCusrFrmulaStpGuid AND CUST_FRMULA_GUID = @MyServiceCustFrmulaGuid AND CUST_GUID = @CustGUID)
	BEGIN
		INSERT INTO [dbo].[CUST_FRMULA_STP]
           ([CUST_FRMULA_STP_GUID]
           ,[CUST_GUID]
           ,[CUST_FRMULA_GUID]
           ,[FRMULA_STP_NBR]
           ,[FRMULA_SPLIT_STP_CD]
           ,[WSH_OP_ID]
           ,[WSH_OP_TM]
           ,[WSH_OP_TM_UOM_ID]
           ,[WSH_OP_TEMP]
           ,[WSH_OP_TEMP_UOM_ID]
           ,[WSH_OP_WTR_LVL]
           ,[WSH_OP_WTR_LVL_UOM_ID]
           ,[WSH_OP_WTR_VOL_UOM_ID]
           ,[DSG_STP_NBR]
           ,[WTR_TYP_ID]
           ,[DRAIN_DEST_ID]
           ,[PH_PROBE_LVL]
		   ,[CNDVTY_PROBE_LVL]
           ,[ROW_STAT_IND]
		   ,[CMNT_TXT]
           )
     VALUES
           (@MyServiceCusrFrmulaStpGuid
           ,@CustGUID
           ,@MyServiceCustFrmulaGuid
           ,@StepNumber
           ,'A'
           ,@MyServiceWashOprId
           ,@RunTime
           ,52
           ,@Temperature
           ,22
           ,@WaterLevel
           ,19
           ,19
           ,NULL -- what is dsg_stp_nbr
           ,@MyServiceWaterTypeId
           ,@MyServiceDrainTypId
           ,NULL
           ,NULL
           ,CASE  @IsDelete 
				WHEN	0
				THEN	'A'
				WHEN	1
				THEN	'I'
				ELSE	'A'
			END
			,@Notes
           )

		SET	@ErrorId	=	@@ERROR
	END
ELSE
	BEGIN
		UPDATE [dbo].[CUST_FRMULA_STP]
		SET
			[FRMULA_STP_NBR]		=		@StepNumber
		,	[WSH_OP_ID]				=		@MyServiceWashOprId
		,	[WSH_OP_TM]				=		@RunTime
		,	[WSH_OP_TEMP]			=		@Temperature
		,	[WSH_OP_WTR_LVL]		=		@WaterLevel
		,	[DSG_STP_NBR]			=		NULL -- what is dsg_stp_nbr
		,	[WTR_TYP_ID]			=		@MyServiceWaterTypeId
		,	[DRAIN_DEST_ID]			=		@MyServiceDrainTypId
		,	[PH_PROBE_LVL]			=		NULL
		,	[CMNT_TXT]				=		@Notes
		,	[ROW_STAT_IND]			=		CASE  @IsDelete 
											WHEN	0
											THEN	'A'
											WHEN	1
											THEN	'I'
											ELSE	'A'
										END

		WHERE CUST_FRMULA_STP_GUID = @MyServiceCusrFrmulaStpGuid AND CUST_FRMULA_GUID = @MyServiceCustFrmulaGuid AND CUST_GUID = @CustGUID

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId




