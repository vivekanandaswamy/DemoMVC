SELECT wt.MyServiceWshOpId 
FROM TCD.WashStep wt 
INNER JOIN TCD.Plant p 
ON wt.RegionID = p.RegionId
WHERE p.EcolabAccountNumber = @EcolabAccountNumber
AND wt.StepId = @WashStepId
AND wt.Istunnel = 1