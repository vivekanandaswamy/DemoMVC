--Device Model (Water-Energy)
--DECLARE	@TimeStamp				DATETIME

--SET		@TimeStamp				=			'01 Jan 1900'

SELECT
	--*
	--,														Id							--This is Conduitgenerated Id
		WEDR.WTR_ENRG_DVC_TYP_ID				AS			DeviceTypeId				--To be translated to 
	,	WEDR.DVC_MDL_NM							AS			[Description]
	,	WEDR.RGN_CD								AS			RegionCode					--might have to be removed on confirmation or to be translated to Conduit RegionId
	,	CAST(		CASE	WEDR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
			AS	BIT
			)									AS			IsDeleted					--Col. added in Conduit schema
	,	WEDR.WTR_ENRG_DVC_ID					AS			MyServiceWtrEnrgDvcId
	,	WEDR.MOD_DTTM							AS			MyServiceModDtTm			--Not to be persisted in Conduit
FROM	WTR_ENRG_DVC_REF						WEDR
WHERE	WEDR.MOD_DTTM							>=			@TimeStamp
ORDER BY
		WEDR.WTR_ENRG_DVC_ID



