-- Plant Formula
SELECT
		DISTINCT
			@EcolabAccountNumber	AS			EcolabAccountNumber
		,	FRMULA_NM				AS			Name
		,	MSTR_LNN_TYP_ID			AS			MyServiceEcolabTextileCategoryId

FROM
		CUST_FRMULA_REF CFR
JOIN	CUST									C
ON	C.CUST_GUID						=			CFR.CUST_GUID
WHERE 
	C.CUST_ACCT_NBR = @EcolabAccountNumber