--Washer Groups
/*
DECLARE	@EcolabAccountNumber	NVARCHAR(1000)
	,	@TimeStamp				DATETIME

SET		@EcolabAccountNumber	=			N'0501023045'
SET		@TimeStamp				=			'01 Jan 1900'
*/

SELECT	--*	,
	--														Id									--Conduit generated Id
		@EcolabAccountNumber					AS			EcolabAccountNumber
	,	MG.CUST_MCH_GRP_NM						AS			GroupDescription
	--,	NULL									AS			GroupTypeId							--Id to be retrieved from Conduit
	,	CAST	(
				CASE	MG.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)								AS			Is_Deleted
	
	--Columns required in WasherGroup table; leaving out duplicate columns...
	--,	EcolabAccountNumber																		--same as above - EcolabAccountNumber
	--,	WasherGroupId																			--same as above - Id
	--,	NULL									AS			ControllerId
	--,	MTR.MCH_TYP_NM							AS			WasherGroupType						--to be translated to Id in Conduit
	,	CAST(	CASE	MTR.MCH_TYP_NM
					WHEN	'Conventional'
					THEN	1
					WHEN	'Tunnel'
					THEN	2
					ELSE	NULL
				END
			AS	TINYINT
			)									AS			WasherGroupTypeId
	,	MG.CUST_MCH_GRP_NM						AS			WasherGroupName
	,	MG.CUST_MCH_GRP_NBR						AS			WasherGroupNumber
	,	MG.CUST_MCH_GRP_GUID					AS			MyServiceCustMchGrpGuid
	,	MG.MOD_DTTM								AS			MyServiceModDtTm
FROM	CUST_MCH_GRP							MG
JOIN	CUST									C
	ON	C.CUST_GUID								=			MG.CUST_GUID
JOIN	MCH_TYP_REF								MTR
	ON	MG.MCH_GRP_TYP							=			MTR.MCH_TYP_ID
WHERE	C.CUST_ACCT_NBR							=			@EcolabAccountNumber
	AND	C.CUST_TYP_ID							=			1
	AND	MG.MOD_DTTM								>=			ISNULL(@Timestamp, '01 Jan 1900')
	AND	MG.CUST_MCH_GRP_NBR						<>			0
