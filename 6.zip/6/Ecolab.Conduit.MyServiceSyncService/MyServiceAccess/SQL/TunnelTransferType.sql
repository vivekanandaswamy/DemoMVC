/*
DECLARE	@TimeStamp				DATETIME

SET		@TimeStamp				=			'01 Jan 1900'
*/
SELECT
	--*
	--,														TunnelWaterFlowTypeId		--This is Conduitgenerated Id
		
		TMPR.PROP_NM							AS			TunnelTransferTypeName
	,	TMPR.RGN_CD								AS			RegionCode					--To be converted to RegionId using RegionMaster
	,	CAST(		CASE	TMPR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
			AS	BIT
			)									AS			Is_Delete					--Col. 2b added in Conduit schema
	,	TMPR.PROP_ID							AS			MyServicePropId
	,	TMPR.MOD_DTTM							AS			MyServiceModDtTm			--Not to be persisted in Conduit
	,   (SELECT DISTINCT PROP_NM FROM TNNL_MCH_PROP_LCLE_REF WHERE LANG_ID=37 AND PROP_ID=TMPR.PROP_ID)
												AS			sp_SP
	,   (SELECT DISTINCT PROP_NM FROM TNNL_MCH_PROP_LCLE_REF WHERE LANG_ID=28 AND PROP_ID=TMPR.PROP_ID)
												AS			nr_NR
	,   (SELECT DISTINCT PROP_NM FROM TNNL_MCH_PROP_LCLE_REF WHERE LANG_ID=11 AND PROP_ID=TMPR.PROP_ID)
												AS			nl_BE
FROM	TNNL_MCH_PROP_REF						TMPR
WHERE	TMPR.PROP_TYP_CD						=			'Transfer Type'
	AND	TMPR.MOD_DTTM							>=			@TimeStamp
ORDER BY
		TMPR.PROP_ID

