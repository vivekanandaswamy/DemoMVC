DECLARE @IsExists BIT = 0	


IF EXISTS (SELECT 1 FROM TCD.Washer w WHERE w.EcoLabAccountNumber = @EcolabAccountNumber AND w.MyServiceCustMchGuid = @MyServiceCustMchGuid )
	BEGIN
		SET @IsExists = 1
	END
ELSE
	BEGIN
		SET @IsExists = 0
	END 

SELECT @IsExists