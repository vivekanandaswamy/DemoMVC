DECLARE		@CustGuid	uniqueidentifier
		,	@ErrorId						INT	

SET @ErrorId = 0

IF EXISTS (SELECT 1 FROM CUST_MCH_CMPMT WHERE  CUST_MCH_GUID = @MyServiceWasherGuid AND CMPMT_NBR = @CompartmentNumber)

BEGIN

		UPDATE CUST_MCH_CMPMT 

			SET	
					CMPMT_NBR				=		@CompartmentNumber
				,	WTR_INLET_DRAIN_ID		=		@MyServiceDrainLookUpId	
				,	CMPMT_WTR_LVL			=		@WaterLevel
				,	USE_PRESS_EXTR_WTR_IND	=		CAST(CASE	@PressExtract
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
				,	SPLIT_CMPMT_IND			=		CAST(CASE	@SplitCompartment
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
				,	STM_IND					=		CAST(CASE	@Steam
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
				,	WSH_ZN_ID				=		@WashStepId
				,	WTR_FLOW_ID				=		@MyServiceTunnelWaterFlowTypeId
				,	PMR_TEMP_CTRL_NBR		=		CAST(CASE	@TempControlPMR
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
				,	RECYL_WTR_INLET_IND		=		CAST(CASE	@RecycleWaterInlet
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
				,	TITRATION_PNT_IND		=		CAST(CASE	@Iterationpoint
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
				,	CMPMT_TYP_CD			=		'C'
				,	ROW_STAT_IND			=		CAST(CASE	@IsDeleted
														WHEN	'FALSE'
														THEN	'A'
														WHEN	'TRUE'
														THEN	'I'
														ELSE	'A'
													END  AS Char(1))
				,	MOD_DTTM				=		@LastModifiedTimeStamp
			WHERE  
			CUST_MCH_GUID = @MyServiceWasherGuid AND CMPMT_NBR = @CompartmentNumber
			SET	@ErrorId	=	@@ERROR
	
END

ELSE
	
BEGIN
		INSERT INTO CUST_MCH_CMPMT
		(  
				CUST_MCH_GUID		
			,	CMPMT_NBR				
			,	WTR_INLET_DRAIN_ID		
			,	CMPMT_WTR_LVL			
			,	USE_PRESS_EXTR_WTR_IND	
			,	SPLIT_CMPMT_IND			
			,	STM_IND					
			,	WSH_ZN_ID				
			,	WTR_FLOW_ID				
			,	PMR_TEMP_CTRL_NBR		
			,	RECYL_WTR_INLET_IND		
			,	TITRATION_PNT_IND
			,	CMPMT_TYP_CD
			,	ROW_STAT_IND
			,	MOD_DTTM
		)
		VALUES
		(
				@MyServiceWasherGuid   
			,	@CompartmentNumber
			,	@MyServiceDrainLookUpId	
			,	@WaterLevel
			,	CAST(CASE	@PressExtract
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
			,	CAST(CASE	@SplitCompartment
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
			,	CAST(CASE	@Steam
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
			,	@WashStepId
			,	@MyServiceTunnelWaterFlowTypeId
			,	CAST(CASE	@TempControlPMR
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
			,	CAST(CASE	@RecycleWaterInlet
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
			,	CAST(CASE	@Iterationpoint
														WHEN	'FALSE'
														THEN	'N'
														WHEN	'TRUE'
														THEN	'Y'
														ELSE	'N'
													END  AS Char(1))
			,	'C'
			,	CAST(CASE	@IsDeleted
														WHEN	'FALSE'
														THEN	'A'
														WHEN	'TRUE'
														THEN	'I'
														ELSE	'A'
													END  AS Char(1))
			,	@LastModifiedTimeStamp
		)		
		SET	@ErrorId	=	@@ERROR


END	

		