IF @MyServiceWaterFlowId = 0 OR @MyServiceWaterFlowId IS NULL
	BEGIN
		SELECT CAST(twft.TunnelWaterFlowTypeId AS smallint) FROM TCD.TunnelWaterFlowType twft WHERE twft.TunnelWaterFlowTypeName = 'None' AND twft.RegionId = 1
	END
ELSE
	BEGIN
		SELECT CAST(twft.TunnelWaterFlowTypeId AS smallint) FROM TCD.TunnelWaterFlowType twft WHERE twft.MyServicePropId = @MyServiceWaterFlowId AND twft.RegionId = 1
	END

