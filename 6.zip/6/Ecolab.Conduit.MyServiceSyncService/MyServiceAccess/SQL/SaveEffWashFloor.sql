DECLARE	@CustGUID							UNIQUEIDENTIFIER
	,	@ErrorId							INT	

	SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST								C
											WHERE	C.CUST_ACCT_NBR						=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID						=			1
											ORDER BY
													C.CUST_GUID
											)


SET @ErrorId = 0

IF NOT EXISTS (SELECT 1 FROM CUST_WSHR_EFFCY WHERE CUST_GUID = @CustGUID AND WSH_FLR_DATA_DT >= DATEADD(week, DATEDIFF(week, '18991231', getdate()), '18991231')
AND WSH_FLR_DATA_DT < DATEADD(week, 1 + DATEDIFF(week, '18991231', getdate()), '18991231'))
	BEGIN
	
	INSERT INTO CUST_WSHR_EFFCY
	(CUST_GUID,
		WSH_FLR_DATA_DT,
		TOT_WSHED_EFFCY,
		WSHR_LD_EFFCY,
		WSHR_TURN_TM,
		SYNC_DTTM,
		ROW_DEL_FLG,
		ROW_STAT_IND,
		CRE_DTTM,
		CRE_OPER,
		MOD_DTTM,
		MOD_OPER)
	VALUES (@CustGuid,
			@WashFloorDate,
			@TotalEfficiency,
			@LoadEfficiency,
			@TurnTime,
			GETDATE(),
			'N',
			'A',
			GETDATE(),
			'TCD',
			GETDATE(),
			'TCD')
	END
ELSE
	BEGIN
	UPDATE CUST_WSHR_EFFCY
		SET WSH_FLR_DATA_DT = @WashFloorDate,
			TOT_WSHED_EFFCY = @TotalEfficiency,
			WSHR_LD_EFFCY = @LoadEfficiency,
			WSHR_TURN_TM = @TurnTime,
			SYNC_DTTM = GETDATE(),
			MOD_DTTM = GETDATE(),
			MOD_OPER = 'TCD'
		WHERE
			Cust_Guid = @CustGuid
			AND WSH_FLR_DATA_DT >= DATEADD(week, DATEDIFF(week, '18991231', getdate()), '18991231')
			AND WSH_FLR_DATA_DT < DATEADD(week, 1 + DATEDIFF(week, '18991231', getdate()), '18991231')
	END





