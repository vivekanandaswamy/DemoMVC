-- Plant Utility Water Factor data

/*
DECLARE		@EcolabAccountNumber		CHAR(10)
		,	@TimeStamp					DATETIME


SET			@TimeStamp									=			'01 Jan 1900'
*/


SELECT 

				UTIL.UTIL_NM							AS					FactorTypes			
			,	WTR.WTR_TEMP							AS					Temperature
			,	WTR.WTR_PRC								AS					Price
			,	UTIL_TYP_CD								AS					UtilityTypeCode
			,	RGN_CD									AS					RegionCode	
			,	WTR.CUST_WTR_FCTR_ID					AS					MyServiceWatrFctrId 
FROM			UTIL_REF UTIL

INNER JOIN		CUST_WTR_FCTR WTR
	ON			UTIL.UTIL_ID = WTR.WTR_TYP_ID 

WHERE wtr.CUST_GUID 
	IN	
		(
		SELECT	CUST_GUID 
		FROM	CUST 
		WHERE	CUST_ACCT_NBR							=					@EcolabAccountNumber	
		)

AND				UTIL.UTIL_CLS_CD						=					'WATER TYPE'
AND				UTIL.MOD_DTTM							>=					@TimeStamp
AND             WTR.ROW_STAT_IND						=					'A'
AND				UTIL.RGN_CD								=					 UTIL.RGN_CD