--Washers (Conventional)
/*
DECLARE	@EcolabAccountNumber				NVARCHAR(1000)
	,	@TimeStamp							DATETIME
	,	@MyServiceWasherGroupGuid			UNIQUEIDENTIFIER

SET		@EcolabAccountNumber	=			N'0501023045'
SET		@TimeStamp				=			'01 Jan 1900'
--SET		@MyServiceWasherGroupGuid	=		''			--valid myService Group GUID
*/

SELECT	--*	,
	
	--	Common cols. for both - Washer (primary) and MacihenSetup table
		@EcolabAccountNumber					AS			EcolabAccountNumber
	--														WasherId							--Conduit generated Id
	
	--	Columns in MachineSetup table; leaving out duplicate columns...
	,	M.CUST_MCH_GRP_GUID						AS			GroupId								--myService WGroup's GUID to be translated to Conduit's Id
	--														MachineInternalId					--No
	--														ControllerId						--No
	,	M.CUST_MCH_NM							AS			MachineName
	,	MR.MCH_MDL_NM							AS			ModelName
	,	MR.SIZE									AS			Size
	--														IsPony								--Not available
	,	'FALSE'									AS			IsTunnel							--Conventional
	

	--	Columns in Washer table
	--														EcolabWasherId						--No
	,	M.CUST_MCH_NBR							AS			PlantWasherNumber
	,	M.MCH_ID								AS			ModelId								--To be translated to Conduit's Id from WasherModelSize
	--														WasherMode							--No
	
	,	M.MCH_CAP								AS			MaxLoad
	,	UR_MCap.UOM_CD							AS			MaxLoad_UOMCode

	--														AWEActive							--No
	--														EndOfFormula						--No
	,	M.CUST_MCH_NM							AS			[Description]
	
	
	--														HoldSignal							--No
	--														HoldDelay							--No
	--														TargetTurnTime						--No
	--														WaterFlushTime						--No
	--														Xtra_Rt								--No
	--														Tunnel_Trf							--No
	
	,	CAST	(
				CASE	M.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)								AS			Is_Deleted
	
	,	M.CUST_MCH_GUID							AS			MyServiceCustMchGUID
	,	M.MOD_DTTM								AS			MyServiceModDtTm
	,	CAST	(
				CASE	C.RGN_CD
					WHEN	'EMEA'
					THEN	 2
					WHEN	'NA'
					THEN	 1
					ELSE	 1
				END
		AS	INT	)								AS			RegionId
FROM	CUST_MCH_GRP							MG
JOIN	CUST_MCH								M
	ON	MG.CUST_MCH_GRP_GUID					=			M.CUST_MCH_GRP_GUID
JOIN	CUST									C
	ON	MG.CUST_GUID							=			C.CUST_GUID
	AND	M.CUST_GUID								=			C.CUST_GUID
JOIN	MCH_REF									MR
	ON	M.MCH_ID								=			MR.MCH_ID
JOIN	MCH_TYP_REF								MTR_M
	ON	MR.MCH_TYP_ID							=			MTR_M.MCH_TYP_ID
	AND	MTR_M.MCH_TYP_NM						=			'Conventional'
JOIN	MCH_TYP_REF								MTR_MG
	ON	MG.MCH_GRP_TYP							=			MTR_MG.MCH_TYP_ID
	AND	MTR_MG.MCH_TYP_NM						=			'Conventional'
LEFT JOIN
		UOM_REF									UR_MCap
	ON	M.MCH_CAP_UOM_ID						=			UR_MCap.UOM_ID
WHERE	C.CUST_ACCT_NBR							=			@EcolabAccountNumber
	AND	C.CUST_TYP_ID							=			1
	AND	MG.CUST_MCH_GRP_GUID					=			ISNULL(@MyServiceWasherGroupGuid, MG.CUST_MCH_GRP_GUID)
	AND	M.MOD_DTTM								>=			ISNULL(@Timestamp, '01 Jan 1900')
	AND	MG.CUST_MCH_GRP_NBR						<>			0

