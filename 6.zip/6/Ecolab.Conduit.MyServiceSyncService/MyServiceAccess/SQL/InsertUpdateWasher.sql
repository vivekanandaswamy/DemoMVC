DECLARE		@CustGuid						uniqueidentifier
		,	@Press_Extractor_Id				smallint
		,	@Transfer_Type_Id				smallint  
		,	@Model_Name						nchar(50)
		,	@ErrorId						INT	

SELECT	@CustGuid = CUST_GUID FROM CUST WHERE	cust_acct_nbr = @EcolabAccountNumber
SELECT	@Press_Extractor_Id = PROP_ID	FROM	TNNL_MCH_PROP_REF	WHERE  PROP_TYP_CD = 'Press Extractor' AND  PROP_NM = @PressExtractorName
SELECT	@Transfer_Type_Id	= PROP_ID	FROM	TNNL_MCH_PROP_REF	WHERE  PROP_TYP_CD = 'Transfer Type'   AND  PROP_NM = @TransferTypeName
SELECT	@Model_Name	=	MCH_MDL_NM		FROM	MCH_REF				WHERE	MCH_ID	=	@MyServiceMCHId

SET @ErrorId = 0

IF EXISTS (SELECT 1 FROM CUST_MCH WHERE  CUST_MCH_GUID = @MyServiceWashersGuid AND CUST_GUID = @CustGuid)

BEGIN

		UPDATE CUST_MCH 

			SET	
					MCH_ID					=		@MyServiceMCHId
				,	CUST_MCH_NBR			=		@PlantWasherNumber	
				,	CUST_MCH_NM				=		@Model_Name
				,	MCH_CAP					=		@MaxLoad
				,	MCH_CAP_UOM_ID			=		6
				,	CMPMT_CNT				=		@NoofCompartments
				,	TANK_CNT				=		@NoofTanks
				,	PRESS_EXTROR_ID			=		@Press_Extractor_Id
				,	XFER_TYP_ID				=		@Transfer_Type_Id
				,	ROW_STAT_IND			=		CAST(CASE	@IsDeleted
														WHEN	'FALSE'
														THEN	'A'
														WHEN	'TRUE'
														THEN	'I'
														ELSE	'A'
													END  AS Char(1))
				,	MOD_DTTM				=		@LastModifiedTimeStamp

			FROM CUST_MCH
			
			WHERE  

			CUST_MCH_GRP_GUID = @MyServiceWasherGroupGuid AND CUST_GUID = @CustGuid AND	CUST_MCH_GUID = @MyServiceWashersGuid

			SET	@ErrorId	=	@@ERROR
	
END

ELSE
	
BEGIN
		INSERT INTO CUST_MCH
		(  
				CUST_MCH_GUID			
			,   CUST_GUID
			,	CUST_MCH_GRP_GUID
			,	MCH_ID
			,	CUST_MCH_NBR
			,	CUST_MCH_NM
			,	MCH_CAP
			,	MCH_CAP_UOM_ID
			,	MCH_INSTL_DT
			,	MCH_INSTL_DT_TMZN_ID
			,	CMPMT_CNT
			,	TANK_CNT
			,	PRESS_EXTROR_ID
			,	XFER_TYP_ID
			,	ROW_STAT_IND
			,	MOD_DTTM
	
		)
		VALUES
		(
				@MyServiceWashersGuid
			,	@CustGuid
			,	@MyServiceWasherGroupGuid   
			,	@MyServiceMCHId
			,	@PlantWasherNumber
			,	@Model_Name
			,	@MaxLoad
			,	6
			,	@LastModifiedTimeStamp
			,	0					--Need Clarification
			,	@NoofCompartments
			,	@NoofTanks
			,	@Press_Extractor_Id
			,	@Transfer_Type_Id
			,	CAST(CASE	@IsDeleted
						WHEN	'FALSE'
						THEN	'A'
						WHEN	'TRUE'
						THEN	'I'
						ELSE	'A'
					END  AS Char(1))
			,	@LastModifiedTimeStamp
		)		
		SET	@ErrorId	=	@@ERROR


END	

		