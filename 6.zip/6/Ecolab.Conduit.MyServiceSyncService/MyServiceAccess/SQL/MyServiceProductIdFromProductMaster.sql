SELECT 
			PM.MyServiceProdId 
FROM		TCD.ProductMaster			PM 
WHERE		PM.ProductId				=			@ProductId