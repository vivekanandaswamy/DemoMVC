SELECT 
			tcem.MyServiceCmpmtDsgDvcguid 
FROM		tcd.TunnelCompartmentEquipmentMapping							tcem 
WHERE		tcem.ControllerEquipmentSetupId					=				@ControllerEquipmentSetupId
AND tcem.EcoLabAccountNumber = @EcolabAccountNumber;