DECLARE		@CustGUID					UNIQUEIDENTIFIER
DECLARE		@CUST_DSG_DVC_GUID			UNIQUEIDENTIFIER
		,	@ErrorId							INT
		,	@DSG_DVC_NBR						INT	
SET			@CustGUID				=			(
										SELECT	TOP 1
												C.CUST_GUID
										FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
										)

SET @ErrorId = 0

SET @DSG_DVC_NBR				=			(
											SELECT ISNULL(MAX(DSG_DVC_NBR),0)+1 FROM dbo.CUST_DSG_DVC WHERE CUST_GUID=@CustGUID
											)

IF NOT EXISTS (SELECT 1 FROM dbo.CUST_DSG_DVC cdd WHERE	cdd.PROD_ID	= @MyServiceProdId  AND	cdd.CUST_GUID	= @CustGUID)
	BEGIN
		INSERT INTO dbo.CUST_DSG_DVC
		( CUST_DSG_DVC_GUID
		, CUST_GUID
		, DSG_DVC_ID
		, PROD_ID
		, DSG_DVC_NBR
		, DSG_DVC_INSTL_DT
		, DSG_METH_ID)

		VALUES
		( NEWID()
		, @CustGUID
		, 0
		, @MyServiceProdId
		, @DSG_DVC_NBR
		, GETDATE()
		, 1)
	END

SET			@CUST_DSG_DVC_GUID		=		(SELECT cdd.CUST_DSG_DVC_GUID FROM dbo.CUST_DSG_DVC cdd
WHERE		cdd.PROD_ID				=		@MyServiceProdId 
AND			cdd.CUST_GUID			=		@CustGUID)

IF NOT EXISTS (SELECT 1 FROM [dbo].[CUST_MCH_CMPMT_DSG_DVC_XREF] WHERE CUST_MCH_CMPMT_DSG_DVC_GUID = @MyServiceCmpmtDsgDvcGuid AND CUST_GUID = @CustGUID)
	BEGIN
		INSERT INTO [dbo].[CUST_MCH_CMPMT_DSG_DVC_XREF]
           ([CUST_MCH_CMPMT_DSG_DVC_GUID]
           ,[CUST_MCH_GRP_GUID]
           ,[CUST_DSG_DVC_GUID]
		   ,[CUST_MCH_GUID]
		   ,[CMPMT_NBR]
           ,[CUST_GUID]
           ,[ASSN_TYP_CD]
		   ,[ROW_STAT_IND]
           )
     VALUES
           (@MyServiceCmpmtDsgDvcguid
           ,@MyServiceWasherGroupId
           ,@CUST_DSG_DVC_GUID
           ,@MyServiceWasherId
           ,@CompartmentNumber
           ,@CustGUID
           ,'G'
           ,CASE  @IsDelete 
				WHEN	0
				THEN	'A'
				WHEN	1
				THEN	'I'
				ELSE	'A'
			END
           )

		SET	@ErrorId	=	@@ERROR
	END
ELSE
	BEGIN
		UPDATE [dbo].[CUST_MCH_CMPMT_DSG_DVC_XREF]
		SET
			[CUST_MCH_GRP_GUID]		=		@MyServiceWasherGroupId
		,	[CUST_DSG_DVC_GUID]		=		@CUST_DSG_DVC_GUID
		,	[CUST_MCH_GUID]			=		@MyServiceWasherId
		,	[CMPMT_NBR]				=		@CompartmentNumber
		,	[ASSN_TYP_CD]			=		'G'
		,	[ROW_STAT_IND]			=		CASE  @IsDelete 
											WHEN	0
											THEN	'A'
											WHEN	1
											THEN	'I'
											ELSE	'A'
										END

		WHERE CUST_MCH_CMPMT_DSG_DVC_GUID = @MyServiceCmpmtDsgDvcguid AND CUST_GUID = @CustGUID 

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId
