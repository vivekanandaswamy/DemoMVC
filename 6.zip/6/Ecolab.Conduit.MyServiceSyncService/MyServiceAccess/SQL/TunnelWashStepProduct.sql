--Washer Groups formula steps Products/Chemicals (Tunnel)

SELECT	--TOP 10
	--*,
	--														TunnelDosingProductMappingId		--Conduit generated Id
	--														EcolabAccountNumber					--Conduit EcolabAccountNumber
	--														TunnelDosingSetupId					--Id from TDS based on the parameter @MyServiceCustFrmulaStpGUID
	--														GroupId								--Conduit's Washer Group Id
		MCDDX.CMPMT_NBR							AS			CompartmentNumber
	--														ControllerEquipmentSetupId			--Conduit's Id from CES
	--														InjectionNumber						--Conduit generated number
	--,	DD.PROD_ID								AS			ProductId							--Struck-out in the mapping sheet
	--	Quantity	--Composite, to be consumed to be translated to Conduit's single col. Quantity
	,	FSDDX.DSG_WGT							AS			DosingWeight
	,	UR_DsgWgt.UOM_CD						AS			DosingWeightUOMCode
	,	FSDDX.DSG_VOL							AS			DosingVolume
	,	UR_DsgVol.UOM_CD						AS			DosingVolumeUOMCode

	,	FSDDX.FRMULA_STP_DSG_DVC_GUID			AS			MyServiceFrmulaStpDsgDvcGUID
	,	FSDDX.MOD_DTTM							AS			MyServiceModDtTm
	,	MCDDX.CUST_MCH_CMPMT_DSG_DVC_GUID		AS			MyServiceCmpmtDsgDvcguid
FROM	FRMULA_STP_DSG_DVC_XREF					FSDDX
JOIN	CUST_FRMULA_STP							FS
	ON	FSDDX.CUST_FRMULA_STP_GUID				=			FS.CUST_FRMULA_STP_GUID
JOIN	CUST_FRMULA_MCH_GRP_XREF				FMGX
	ON	FSDDX.CUST_FRMULA_GUID					=			FMGX.CUST_FRMULA_GUID
	AND	FMGX.ASSN_TYP_CD						=			'G'
JOIN	CUST_MCH_CMPMT_DSG_DVC_XREF				MCDDX
	ON	FMGX.CUST_MCH_GRP_GUID					=			MCDDX.CUST_MCH_GRP_GUID
	AND	MCDDX.CUST_MCH_CMPMT_DSG_DVC_GUID		=			FSDDX.CUST_MCH_CMPMT_DSG_DVC_GUID
	AND	MCDDX.ASSN_TYP_CD						=			'G'

JOIN	CUST_DSG_DVC							DD
	ON	MCDDX.CUST_DSG_DVC_GUID					=			DD.CUST_DSG_DVC_GUID
JOIN	PROD									P
	ON	DD.PROD_ID								=			P.PROD_ID
LEFT JOIN
		UOM_REF									UR_DsgWgt
	ON	FSDDX.DSG_WGT_UOM_ID					=			UR_DsgWgt.UOM_ID
LEFT JOIN
		UOM_REF									UR_DsgVol
	ON	FSDDX.DSG_VOL_UOM_ID					=			UR_DsgVol.UOM_ID
					
WHERE	FSDDX.CUST_FRMULA_STP_GUID				=			@MyServiceCustFrmulaStpGUID
	AND	FSDDX.ROW_STAT_IND						=			'A'
	AND	EXISTS									(			SELECT	1
															FROM	CUST					C
															WHERE	C.CUST_GUID				=			FMGX.CUST_GUID
																AND	C.CUST_GUID				=			DD.CUST_GUID
																AND	C.CUST_TYP_ID			=			1
												)		
	AND	EXISTS									(			SELECT	1
															FROM	CUST_FRMULA_REF			F
															WHERE	F.CUST_GUID				=			FMGX.CUST_GUID
																AND	F.CUST_FRMULA_GUID		=			FMGX.CUST_FRMULA_GUID
																--AND	F.FRMULA_TYP_ID			=			3
																--Commenting the above and replacing with new condn. for Current and Proposed formula
																AND	(
																		F.FRMULA_TYP_ID		=			(
																										SELECT	FTR.FRMULA_TYP_ID
																										FROM	FRMULA_TYP_REF			FTR
																										WHERE	FTR.FRMULA_TYP_NM		=			'Current'
																										)
																	OR	(	F.FRMULA_TYP_ID		IN		(
																										SELECT	FTR.FRMULA_TYP_ID
																										FROM	FRMULA_TYP_REF			FTR
																										WHERE	FTR.FRMULA_TYP_NM		IN			('Proposed 1', 'Proposed 2', 'Proposed 3', 'Proposed 4')
																										)
																		AND	F.PRPD_TO_CRNT_IND	=		1										--'TRUE'	This is smallint with 0/1 vals and not BIT as anticipated
																		)
																	)
												)
	AND	EXISTS									(			SELECT	1
															FROM	CUST_MCH_GRP			MG
															JOIN	MCH_TYP_REF				MTR
																ON	MG.MCH_GRP_TYP			=			MTR.MCH_TYP_ID
																AND	MTR.MCH_TYP_NM			=			'Tunnel'
															WHERE	MG.CUST_GUID			=			FMGX.CUST_GUID
																AND	MG.CUST_MCH_GRP_GUID	=			FMGX.CUST_MCH_GRP_GUID
																AND	MG.CUST_MCH_GRP_NBR		<>			0
												)
ORDER BY
		FSDDX.FRMULA_STP_DSG_DVC_GUID
--GO
