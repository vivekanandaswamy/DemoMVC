DECLARE	@CustGUID				UNIQUEIDENTIFIER,
		@GasOilPriceUOMId		INT,
		@BoilerName				NVARCHAR(100),
		@BoilerIND				CHAR,
		@BoilerTypeId			INT,
		@ENRG_CNTNT_UOM_ID		INT

SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
											)
SET		@BoilerIND				=			CAST(
												CASE	@BoilerSteam
													WHEN	'TRUE'
													THEN	'Y'
													WHEN	'FALSE'
													THEN	'N'
												END
											AS	CHAR													
										)

IF(@Count=1)
BEGIN
	IF EXISTS (select 1 from CUST_UTIL_FCTR where CUST_GUID = @CustGUID AND ROW_STAT_IND = 'A')
		BEGIN
		-- Update for Energy Utilities.
		IF @BoilerType = 1
			SET @BoilerName = 'Boiler'
		ELSE IF @BoilerType = 2
			SET @BoilerName = 'Direct Fire'
		SELECT @GasOilPriceUOMId = UOM_ID FROM UOM_REF WHERE UOM_CD = @EnergyPriceUnit
		SELECT @BoilerTypeId	= UTIL_ID  FROM UTIL_REF WHERE UTIL_NM =  @BoilerName AND RGN_CD = 'NA'
		SELECT @ENRG_CNTNT_UOM_ID = UOM_ID FROM UOM_REF WHERE UOM_CD = @EnergyContentUnit

		UPDATE CUST_UTIL_FCTR
			SET
				EVPTN_FCTR					=			@EvaporationFactor,
				REWSH_FCTR					=			@RewashFactor,
				GAS_OIL_TYP_ID				=			@GasOilTypeId,
				GAS_OIL_PRC					=			@EnergyPrice,
				GAS_OIL_PRC_UOM_ID			=			@GasOilPriceUOMId,
				ELCTRICTY_PER_UNIT_PRC		=			@ElectricalPrice, 
				BLR_STM_IND					=			@BoilerIND,
				STM_FCTR					=			@Steam,
				BLR_FCTR					=			@Boiler,
				STCK_FCTR					=			@Stack,
				BLR_TYP_ID					=			@BoilerTypeId,
				ROW_DEL_FLG					=			'N',
				ROW_STAT_IND				=			'A',
			
				ENRG_CNTNT					=			@EnergyContent,
				ENRG_CNTNT_UOM_ID			=			@ENRG_CNTNT_UOM_ID
			WHERE
				CUST_GUID					=			@CustGUID

		END
	ELSE
		BEGIN
			INSERT INTO dbo.CUST_UTIL_FCTR
			(
				CUST_GUID,
				EVPTN_FCTR,
				REWSH_FCTR,
				GAS_OIL_TYP_ID,
				GAS_OIL_PRC,
				GAS_OIL_PRC_UOM_ID,
				ENRG_CNTNT,
				ELCTRICTY_PER_UNIT_PRC,
				BLR_STM_IND,
				STM_FCTR,
				BLR_FCTR,
				STCK_FCTR,
				BLR_TYP_ID,
				ROW_DEL_FLG,
				ROW_STAT_IND,
				ENRG_CNTNT_UOM_ID
			)
			VALUES
			(
				@CustGUID, 
				@EvaporationFactor, 
				@RewashFactor, 
				@GasOilTypeId, 
				@EnergyPrice, 
				@GasOilPriceUOMId,
				@EnergyContent, 
				@ElectricalPrice, 
				@BoilerIND, 
				@Steam, 
				@Boiler, 
				@Stack, 
				@BoilerTypeId,
				'N', 
				'A',
				@ENRG_CNTNT_UOM_ID
			)
		END
END

IF EXISTS (SELECT 1 from CUST_WTR_FCTR where CUST_GUID = @CustGUID AND CUST_WTR_FCTR_ID = @MyServiceWatrFctrId AND ROW_STAT_IND = 'A')
	BEGIN
			UPDATE dbo.CUST_WTR_FCTR
			SET
					WTR_TYP_ID = @WaterTypeId, -- int
					WTR_TEMP = @Temperature, -- int
					WTR_PRC = @Price -- numeric
			WHERE	CUST_GUID = @CustGUID
			AND		CUST_WTR_FCTR_ID = @MyServiceWatrFctrId
	END
ELSE
	BEGIN
		IF @WaterTypeId IS NOT NULL AND @WaterTypeId > 0
			BEGIN
					INSERT INTO dbo.CUST_WTR_FCTR
					(
						CUST_GUID,
						WTR_TYP_ID,
						CUST_WTR_FCTR_ID,
						WTR_TEMP,
						TEMP_UOM_ID,
						WTR_PRC,
						ROW_STAT_IND,
						DISP_SEQ_NBR
					)
					VALUES
					(
						@CustGUID, -- CUST_GUID - uniqueidentifier
						@WaterTypeId, -- WTR_TYP_ID - int
						@MyServiceWatrFctrId, -- CUST_WTR_FCTR_ID - int
						@Temperature, -- WTR_TEMP - int
						22, -- TEMP_UOM_ID - smallint
						@Price, -- WTR_PRC - numeric
						'A', -- ROW_STAT_IND - char,
						CASE @Count WHEN 5 THEN 1 WHEN 6 THEN 2 WHEN 7 THEN 3 ELSE 0 END
					)	
			END
	END

