--EcolabTextile Category
/*
DECLARE	@TimeStamp				DATETIME

SET		@TimeStamp				=			'01 Jan 1900'
*/

SELECT
	--	*
	--,														TextileId					--This is Conduitgenerated Id
		MLTR.LNN_TYP_NM							AS			CategoryName
	,	MLTR.RGN_CD								AS			RegionCode					--This is being excluded, since this is irrelevant;	To be converted to RegionId using RegionMaster
	,	CAST(		CASE	MLTR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
			AS	BIT
			)									AS			Is_Delete					--Col. 2b added in Conduit schema
	,	MLTR.MSTR_LNN_TYP_ID					AS			MyServiceMstrLnnTypId
	,	MLTR.MOD_DTTM							AS			MyServiceModDtTm
	,   (SELECT DISTINCT LNN_TYP_NM FROM MSTR_LNN_TYP_LCLE_REF WHERE LANG_ID=37 AND MSTR_LNN_TYP_ID=MLTR.MSTR_LNN_TYP_ID)
												AS			sp_SP
	,   (SELECT DISTINCT LNN_TYP_NM FROM MSTR_LNN_TYP_LCLE_REF WHERE LANG_ID=28 AND MSTR_LNN_TYP_ID=MLTR.MSTR_LNN_TYP_ID)
												AS			nr_NR
	,   (SELECT DISTINCT LNN_TYP_NM FROM MSTR_LNN_TYP_LCLE_REF WHERE LANG_ID=11 AND MSTR_LNN_TYP_ID=MLTR.MSTR_LNN_TYP_ID)
												AS			nl_BE
FROM	MSTR_LNN_TYP_REF						MLTR
WHERE	MLTR.MOD_DTTM							>=			@TimeStamp
	AND	MLTR.ABSORBANCY_FCTR					IS 		NULL	
ORDER BY
		MLTR.MSTR_LNN_TYP_ID
