DECLARE	@CustGUID				UNIQUEIDENTIFIER

SET		@CustGUID				=			(
											SELECT	
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
											)

IF NOT EXISTS (SELECT 1 FROM CUST_PROD_XREF WHERE PROD_ID = @ProductId AND CUST_GUID = @CustGUID)
	BEGIN
		INSERT INTO CUST_PROD_XREF
		(
			 CUST_GUID
			,PROD_ID
			,SRC_SYS_CD
			,CUST_PROD_UNIT_PRC
			,CONSUMPTION_AND_INV_IND				
			,INV_OR_EXPN_CD		
			,ROW_STAT_IND
		)
		VALUES
		(	 @CustGUID
			,@ProductId
			,'STP'
			,@Cost
			,@IncludeinCi
			,@InventoryExpense
			,CAST(CASE	@IsDelete
					WHEN	'FALSE'
					THEN	'A'
					WHEN	'TRUE'
					THEN	'I'
					ELSE	'A'
			END  AS Char(1))
			)

	END
ELSE
	BEGIN
		UPDATE CUST_PROD_XREF
		SET
			CUST_PROD_UNIT_PRC				=		@Cost
		,	CONSUMPTION_AND_INV_IND			=		@IncludeinCi
		,	INV_OR_EXPN_CD					=		@InventoryExpense
		,	ROW_STAT_IND					=		CAST(CASE	@IsDelete
														WHEN	'FALSE'
														THEN	'A'
														WHEN	'TRUE'
														THEN	'I'
														ELSE	'A'
													END  AS Char(1))
		WHERE 
			CUST_GUID						=		@CustGUID
		AND	  
			PROD_ID							=		@ProductId
	END

DECLARE @DSG_DVC_NBR INT;
SET @DSG_DVC_NBR = (SELECT ISNULL(MAX(DSG_DVC_NBR),0) + 1 FROM dbo.CUST_DSG_DVC WHERE CUST_GUID = @CustGUID);

IF NOT EXISTS (SELECT 1 FROM dbo.CUST_DSG_DVC cdd WHERE	cdd.PROD_ID	= @ProductId  AND	cdd.CUST_GUID	= @CustGUID)
BEGIN
		INSERT INTO dbo.CUST_DSG_DVC
		( CUST_DSG_DVC_GUID
		, CUST_GUID
		, DSG_DVC_ID
		, PROD_ID
		, DSG_DVC_NBR
		, DSG_DVC_INSTL_DT
		, DSG_METH_ID)

		VALUES
		( NEWID()
		, @CustGUID
		, 0
		, @ProductId
		, @DSG_DVC_NBR
		, GETDATE()
		, 1)
END