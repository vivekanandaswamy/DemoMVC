--Plant Contact Position
/*
DECLARE	@TimeStamp				DATETIME

SET		@TimeStamp				=			'01 Jan 1900'
*/
SELECT
	--	*													
	--														[Id]						--This is conduit generated Id	
		CPR.POSN_NM								AS			Position_Name
	,	CAST(		CASE	CPR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
				AS	BIT
			)									AS			Is_Deleted
	,	CPR.CNTCT_POSN_ID						AS			MyServiceCntctPosnId
	,	CPR.MOD_DTTM							AS			MyServiceModDtTm
	,   (SELECT DISTINCT POSN_NM FROM CNTCT_POSN_LCLE_REF WHERE LANG_ID=37 AND CNTCT_POSN_ID=CPR.CNTCT_POSN_ID)
												AS			sp_SP
	,   (SELECT DISTINCT POSN_NM FROM CNTCT_POSN_LCLE_REF WHERE LANG_ID=28 AND CNTCT_POSN_ID=CPR.CNTCT_POSN_ID)
												AS			nr_NR
	,   (SELECT DISTINCT POSN_NM FROM CNTCT_POSN_LCLE_REF WHERE LANG_ID=11 AND CNTCT_POSN_ID=CPR.CNTCT_POSN_ID)
												AS			nl_BE
FROM	CNTCT_POSN_REF							CPR
WHERE	CPR.MOD_DTTM							>=			@TimeStamp
ORDER BY
		CPR.CNTCT_POSN_ID
