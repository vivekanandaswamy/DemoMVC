SELECT
AGM_V_CMT.AlarmCode
,AGM.DESCRIPTION
,AGM_V_CMT.ControllerModelTypeId
,AGM.ResourceKey
,AGM_V_CMT.IsDefault
,AGM.IsDelete
,AGM.AlarmGroupMasterId as alrmMasterId
,AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId as AlarmMachineMappingId
,AGM_V_CMT.MachineNumber
,CMCTM.ControllerModelId
,CMCTM.ControllerTypeId
,AGM.LastModifiedTime
,AGM.WasherType
,AGM_V_CMT.IsDelete AS IsDeleteAlarmMapping
,AGM.IsHoldCondition AS IsHoldCondition
,AGM.AlarmNumber AS AlarmNumber
FROM [TCD].[AlarmGroupMaster] AGM
INNER JOIN [TCD].[AlarmGroupMsterVsControllerModelType] AGM_V_CMT ON AGM_V_CMT.AlarmGroupMasterId = AGM.AlarmGroupMasterId
INNER JOIN [TCD].[ControllerModelControllerTypeMapping] CMCTM ON CMCTM.Id = AGM_V_CMT.ControllerModelTypeId
AND	AGM.LastModifiedTime				>					 @TimeStamp
