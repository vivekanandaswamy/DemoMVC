SELECT
		 TOP 1 pm.MyServiceProdId 

FROM		TCD.TunnelCompartmentEquipmentMapping tcem
INNER JOIN	TCD.ControllerEquipmentSetup ces 
ON			tcem.ControllerEquipmentSetupId					=				ces.ControllerEquipmentSetupId
AND tcem.EcolabAccountNumber=ces.EcolabAccountNumber
INNER JOIN	TCD.ProductMaster pm 
ON			ces.ProductId									=				pm.ProductId
WHERE		tcem.ControllerEquipmentSetupId					=				@ControllerEquipmentSetupId
AND tcem.EcolabAccountNumber=@EcolabAccountNumber
