--Device Model (Water-Energy)
--DECLARE	@TimeStamp				DATETIME

--SET		@TimeStamp				=			'01 Jan 1900'

SELECT
		UR.UTIL_NM								AS			Name				
	,	UR.RGN_CD								AS			RegionCode					
	,	CAST(		CASE	UR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
			AS	BIT
			)									AS			IsDeleted					
	,	UR.UTIL_ID								AS			MyServiceUtilId 
	,	UR.MOD_DTTM								AS			MyServiceModDtTm			--Not to be persisted in Conduit
	,   UR.UTIL_TYP_CD							AS			MyServiceUtilTypeCode
	,   (SELECT DISTINCT UTIL_NM FROM UTIL_LCLE_REF WHERE LANG_ID=37 AND UTIL_ID=UR.UTIL_ID)
												AS			sp_SP
	,   (SELECT DISTINCT UTIL_NM FROM UTIL_LCLE_REF WHERE LANG_ID=28 AND UTIL_ID=UR.UTIL_ID)
												AS			nr_NR
	,   (SELECT DISTINCT UTIL_NM FROM UTIL_LCLE_REF WHERE LANG_ID=11 AND UTIL_ID=UR.UTIL_ID)
												AS			nl_BE
FROM	UTIL_REF						UR
WHERE	UR.UTIL_CLS_CD							=			'Water Type'
		AND UR.MOD_DTTM								>=			@TimeStamp
		AND UR.UTIL_TYP_CD						!=	'P'
ORDER BY
		UR.UTIL_ID



