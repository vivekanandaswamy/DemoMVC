DECLARE	@CustGUID					UNIQUEIDENTIFIER
	,	@ErrorId					INT
			SET		@CustGUID					=			(
															SELECT	TOP 1
																	C.CUST_GUID
															FROM	CUST						C
															WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
																AND	C.CUST_TYP_ID				=			1
															ORDER BY
																	C.CUST_GUID
															)

SET @ErrorId = 0

IF NOT EXISTS (SELECT 1 FROM [dbo].[CUST_WTR_ENRG_DVC] WHERE CUST_WTR_ENRG_DVC_GUID = @MyServiceCustWtrEnrgDvcGuid AND CUST_GUID = @CustGUID)
	BEGIN
	INSERT INTO [dbo].[CUST_WTR_ENRG_DVC]
           ([CUST_WTR_ENRG_DVC_GUID]
           ,[CUST_GUID]
           ,[WTR_ENRG_DVC_ID]
		   ,[WTR_ENRG_DVC_NBR]
		   ,[DVC_INSTL_DT]
		   ,[NTE_TXT]
           ,[ROW_STAT_IND]
          )
     VALUES
           (@MyServiceCustWtrEnrgDvcGuid
           ,@CustGUID
		   ,@WaterEnergyDeviceId
		   ,@WaterEnergyDeviceNo
		   ,@InstallDate
		   ,@Comment
           ,	CAST(CASE	@IsDelete
						WHEN	'FALSE'
						THEN	'A'
						WHEN	'TRUE'
						THEN	'I'
						ELSE	'A'
					END  AS Char(1))
			)

		SET	@ErrorId	=	@@ERROR
	END
ELSE
	BEGIN
		UPDATE [dbo].[CUST_WTR_ENRG_DVC]
		SET		
			[WTR_ENRG_DVC_ID]			=				@WaterEnergyDeviceId,
			[WTR_ENRG_DVC_NBR]			=				@WaterEnergyDeviceNo,
			[DVC_INSTL_DT]				=				@InstallDate,
			[NTE_TXT]					=				@Comment,
			[ROW_STAT_IND]				=			CAST(CASE	@IsDelete
													WHEN	'FALSE'
													THEN	'A'
													WHEN	'TRUE'
													THEN	'I'
													ELSE	'A'
													END  AS Char(1))
		WHERE CUST_WTR_ENRG_DVC_GUID = @MyServiceCustWtrEnrgDvcGuid AND CUST_GUID = @CustGUID

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId




