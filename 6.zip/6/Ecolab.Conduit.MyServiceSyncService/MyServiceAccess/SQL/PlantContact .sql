--Plant Contacts
DECLARE	@CustGUID				UNIQUEIDENTIFIER

SET		@CustGUID				=			(
											SELECT	TOP 1
													C.CUST_GUID
											FROM	CUST						C
											WHERE	C.CUST_ACCT_NBR				=			@EcolabAccountNumber
												AND	C.CUST_TYP_ID				=			1
											ORDER BY
													C.CUST_GUID
											)
												
SELECT	@EcolabAccountNumber					AS			EcolabAccountNumber
	,	CT.FRST_NM								AS			ContactFirstName
	,	CTR.COURTESY_TTL_NM						AS			ContactTitle
	,	CT.LST_NM								AS			ContactLastName
	,	CT.CNTCT_POSN_ID						AS			MyServiceContactPositionId
	,	CT.EMAIL_ID								AS			ContactEMail
	,	CT.OFFC_PH_NBR							AS			ContactOfficePhone
	,	CT.MOBILE_PH_NBR						AS			ContactMobilePhone
	,	CT.FAX_NBR								AS			ContactFaxNumber
	,	CAST(	CASE	CT.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
			AS	BIT)							AS			Is_Deleted
	,	CT.CNTCT_GUID							AS			MyServiceCntctGuid
	,	CT.MOD_DTTM								AS			MyServiceLastModDtTm
FROM	CNTCT									CT
JOIN	COURTESY_TTL_REF						CTR
	ON	CT.COURTESY_TTL_ID						=			CTR.COURTESY_TTL_ID
WHERE	CT.CUST_GUID							=			@CustGUID
	AND	CT.MOD_DTTM								>			@TimeStamp
