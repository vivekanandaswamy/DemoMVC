--Script to update Plant data to enVision schema.
SET	NOCOUNT	ON

DECLARE	
	--	input variables
-- 		@InEcolabAccountNumber					NVARCHAR(1000)			=			NULL			--Key for Plant (Facility) from Conduit
--	,	@InPlantName							NVARCHAR(55)			=			NULL			--input for FacilityName, FacilityName2
--	,	@InAddress								NVARCHAR(150)			=			NULL			--input for Address
--	,	@InCity									NVARCHAR(50)			=			NULL			--input for City
--	,	@InState								NVARCHAR(50)			=			NULL			--input for State
--	,	@InZIPCode								NVARCHAR(50)			=			NULL			--input for ZIPCode
		@InUserId								INT						=			NULL			--input for CreatedBy, ModifiedBy

	--	other script variables
	,	@FacilityId								INT						=			NULL			--To be set based on input EcolabAccountNumber; Key for Facility
	
	--	master data in enVision schema
	,	@SourceId								INT						=			NULL			--Id in ERPSource in enVision for 'myService'
	
	--	Script variable
	,	@TimeStamp								DATETIME				=			GETDATE()
	,	@ScriptError							INT						=			0				--To be returned back, if non-0, implies some error; rollback

	--	output variable


--Setting user id based on 'Admin_Tool' userlogin
SET		@InUserId								=				(
																SELECT	TOP	1
																		UM.UserId
																FROM	dbo.UserMaster			UM
																WHERE	UM.UserLogin			=			'Admin_Tool'
																ORDER BY
																		UM.UserId
																)


--Get/Set master data Ids...
	--Get SourceId for 'myservice'
SET		@SourceId								=			(
															SELECT	ES.SourceId
															FROM	dbo.ERPSources				ES
															WHERE	SourceName					=			'myService'
															)
--any other above this


--Get FacilityId for the input EcolabAccountNumber
SET		@FacilityId								=			(
															SELECT	TOP	1
																	FM.FacilityId
															FROM	dbo.FacilityMaster			FM
															WHERE	FM.SoldTo					=			@InEcolabAccountNumber
																AND	FM.SourceId					=			@SourceId
															ORDER BY
																	FM.FacilityId
															)

IF		@FacilityId	IS	NOT	NULL
		--then you can udpate
		BEGIN
				UPDATE	FM
					SET	FM.FacilityName				=			@InPlantName
					,	FM.FacilityName2			=			@InPlantName
					,	FM.[Address]				=			@InAddress
					,	FM.City						=			@InCity
					,	FM.[State]					=			@InState
					,	FM.ZIPCode					=			@InZIPCode
					,	FM.ModifiedBy				=			@InUserId
					,	FM.ModifiedOn				=			@TimeStamp
				FROM	dbo.FacilityMaster			FM
				WHERE	FM.FacilityId				=			@FacilityId
					AND	FM.SourceID					=			@SourceId

				SET		@ScriptError			=			@@Error

				SELECT	@ScriptError

				RETURN			--return from script
		END


--we couldn't udpate, since we didn't find a valid FacilityId, thus return non-zero error-id
SET		@ScriptError	=	1			--since, we didn't find a NON-NULL FacilityId

SELECT	@ScriptError

SET	NOCOUNT	OFF

RETURN			--return from script

