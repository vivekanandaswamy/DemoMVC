SET	NOCOUNT	ON

DECLARE	
	--	input variables
--		@InUserLogin							NVARCHAR(50)			=			NULL			--input for UserLogin
--	,	@InEcolabAccountNumber					NVARCHAR(50)			=			NULL			--input for FacilityId/Node_id
		@InUserId								INT						=			NULL

	--	other script variables
	,	@UserId									INT						=			NULL			--To be set based on input UserLogin
	,	@FacilityId								INT						=			NULL			--To be set based on input EcolabAccountNumber
	
	--	master data in enVision schema
	,	@SourceId								INT						=			NULL			--Id in ERPSource in enVision for 'myService'

	,	@TimeStamp								DATETIME				=			GETDATE()

	--	Script variable
	,	@ScriptError							INT						=			0				--To be returned back, if non-0, implies some error; rollback

	--	output variable



--Setting user id based on 'Admin_Tool' userlogin
SET		@InUserId					=				ISNULL(	(
															SELECT	TOP	1
																	UM.UserId
															FROM	dbo.UserMaster			UM
															WHERE	UM.UserLogin			=			'Admin_Tool'
															ORDER BY
																	UM.UserId
															)
														,	1)


--Get/Set master data Ids...
	--Get SourceId for 'myservice'
SET		@SourceId								=			(
															SELECT	ES.SourceId
															FROM	dbo.ERPSources				ES
															WHERE	SourceName					=			'myService'
															)


--Get FacilityId for the input EcolabAccountNumber
SET		@FacilityId								=			(
															SELECT	TOP	1
																	FM.FacilityId
															FROM	dbo.FacilityMaster			FM
															WHERE	FM.SoldTo					=			@InEcolabAccountNumber
																AND	FM.SourceId					=			@SourceId
															ORDER BY
																	FM.FacilityId
															)


--Fetch a valid UserId and proceed to insert, if found, else abort
SELECT	TOP	1
		@UserId					=			UM.UserId
FROM	dbo.UserMaster			UM
WHERE	UM.UserLogin			=			@InUserLogin
ORDER BY
		UM.UserId


IF	@UserId	IS	NULL
		BEGIN
				SET			@ScriptError	=	1			--since we didn't find a user entry for this login
				SELECT		@ScriptError					--return error id
				RETURN		--return from script
		END

IF	@FacilityId	IS	NULL
		BEGIN
				RETURN		--return from script
		END

--if we found a valid userId, proceed further
IF	NOT	EXISTS	(
				SELECT	1
				FROM	dbo.MDS_HierarchyAccess			MDSHA
				WHERE	MDSHA.UserId					=			@UserId
					AND	MDSHA.Location_Access_Type		=			'Location'
					AND	MDSHA.Node_Level				=			5
					AND	MDSHA.Node_Id					=			@FacilityId
				)
			BEGIN
					INSERT	INTO	dbo.MDS_HierarchyAccess	(
								--	Id												--auto-generated Id
									UserId											--UserId for which access is being added
								,	Location_Access_Type							--"Location" for Facility access
								,	Setting											--NULL for Facility access
								,	Access_Type										--1 = Read/Write
								,	Node_Level										--5 for Facility access
								,	Node_Id											--Facility ID for Facility access
								,	CreatedBy
								,	CreatedDate
								)
						SELECT	--	Id												--auto-generated Id
									@UserId					AS			UserId
								,	'Location'				AS			Location_Access_Type
								,	NULL					AS			Setting
								,	1						AS			Access_Type
								,	5						AS			Node_Level
								,	@FacilityId				AS			Node_Id
								,	@UserId					AS			CreatedBy
								,	@TimeStamp				AS			CreatedDate

						SET		@ScriptError			=			@@Error
			END


SELECT	@ScriptError


SET	NOCOUNT	OFF

RETURN			--return from script
