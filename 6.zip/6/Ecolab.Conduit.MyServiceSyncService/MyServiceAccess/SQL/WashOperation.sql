--Wash operations
/*
DECLARE	@TimeStamp				DATETIME

SET		@TimeStamp				=			'01 Jan 1900'
*/

SELECT
		WOR.RGN_CD								AS			RegionCode					--To be converted to RegionId using RegionMaster
	--,														StepId						--This is Conduitgenerated Id
	,	WOR.WSH_OP_NM							AS			StepName
	,	CAST(		CASE	WOR.MCH_TYP_NM
						WHEN	'Tunnel'
						THEN	'TRUE'
						WHEN	'Conventional'
						THEN	'FALSE'
						ELSE	NULL
					END
			AS	BIT
			)									AS			IsTunnel
	,	CAST(		CASE	WOR.ROW_STAT_IND
						WHEN	'A'
						THEN	'TRUE'
						WHEN	'I'
						THEN	'FALSE'
						ELSE	'TRUE'
					END
			AS	BIT
			)									AS			IsActive
	,	WOR.WSH_OP_TYP_CD						AS			MyServiceWshOpTypCd
	,	WOR.WSH_OP_ID							AS			MyServiceWshOpId
	,	WOR.MOD_DTTM							AS			MyServiceModDtTm
	,   (SELECT DISTINCT WSH_OP_NM FROM WSH_OP_LCLE_REF WHERE LANG_ID=37 AND WSH_OP_ID=WOR.WSH_OP_ID)
												AS			sp_SP
	,   (SELECT DISTINCT WSH_OP_NM FROM WSH_OP_LCLE_REF WHERE LANG_ID=28 AND WSH_OP_ID=WOR.WSH_OP_ID)
												AS			nr_NR
	,   (SELECT DISTINCT WSH_OP_NM FROM WSH_OP_LCLE_REF WHERE LANG_ID=11 AND WSH_OP_ID=WOR.WSH_OP_ID)
												AS			nl_BE
FROM	WSH_OP_REF								WOR
WHERE	WOR.MOD_DTTM							>=			@TimeStamp
ORDER BY
		WOR.WSH_OP_NM, WOR.MCH_TYP_NM, WOR.RGN_CD, WOR.WSH_OP_TYP_CD
