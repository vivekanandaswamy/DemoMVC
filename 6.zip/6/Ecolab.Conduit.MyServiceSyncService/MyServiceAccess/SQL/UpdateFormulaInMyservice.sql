DECLARE @Frmulatypid_Current INT, 
        @Scripterror INT;


SET @Frmulatypid_Current = (SELECT
                                           FRMULA_TYP_ID FROM FRMULA_TYP_REF AS FTR WHERE FTR.FRMULA_TYP_NM = 'Current')

SET @Scripterror = 0;


UPDATE F SET
        F.FRMULA_TYP_ID = @Frmulatypid_Current, 
        F.PRPD_TO_CRNT_IND = 0
    FROM CUST_FRMULA_MCH_GRP_XREF FMGX
         JOIN CUST_FRMULA_REF F ON FMGX.CUST_FRMULA_GUID = F.CUST_FRMULA_GUID
    WHERE
        FMGX.CUST_FRMULA_MCH_GRP_GUID = @Incustfrmulamchgrpguid;


SET @Scripterror = @@Error;


SELECT
        @Scripterror;


RETURN;
