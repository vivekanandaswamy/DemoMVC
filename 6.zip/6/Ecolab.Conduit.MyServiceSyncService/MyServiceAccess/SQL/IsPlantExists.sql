DECLARE @IsExist BIT = NULL

IF @InEnvision  = 0
	BEGIN
		SELECT @IsExist  = COUNT(*) FROM TCD.PLANT WHERE EcolabAccountNumber = @EcolabAccountNumber
	END
ELSE
	BEGIN
		SELECT @IsExist  = COUNT(*) FROM dbo.FacilityMaster WHERE SoldTo = @EcolabAccountNumber
	END

SELECT @IsExist

