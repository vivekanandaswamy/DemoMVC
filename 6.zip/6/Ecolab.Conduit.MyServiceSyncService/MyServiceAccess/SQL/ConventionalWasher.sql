DECLARE @CustGuid uniqueidentifier
, @Model_Name nchar(50)
, @ErrorId INT

SET @ErrorId = 0

SELECT @CustGuid = CUST_GUID FROM CUST WHERE CUST_ACCT_NBR = @EcolabAccountNumber
SELECT @Model_Name = MCH_MDL_NM FROM MCH_REF WHERE MCH_ID = @MyServiceMCHId

IF EXISTS (SELECT 1 FROM CUST_MCH WHERE  CUST_MCH_GUID = @MyServiceWashersGuid AND CUST_GUID = @CustGuid)

BEGIN

	UPDATE 
		CUST_MCH 

	SET
			MCH_ID = @MyServiceMCHId
		,   CUST_MCH_NBR = @PlantWasherNumber
		,   CUST_MCH_NM = @CustMchName
		,   MCH_CAP = @MaxLoad
		,   MCH_CAP_UOM_ID = 6
		,	CUST_MCH_GRP_GUID = @MyServiceWasherGroupGuid
		,   ROW_STAT_IND = CAST(CASE @IsDeleted
		WHEN 'FALSE'
		THEN 'A'
		WHEN 'TRUE'
		THEN 'I'
		ELSE 'A'
		END  AS Char(1))
		,   MOD_DTTM = @LastModifiedTimeStamp

	FROM 
		CUST_MCH
	WHERE  
		CUST_GUID = @CustGuid AND CUST_MCH_GUID = @MyServiceWashersGuid

	SET @ErrorId = @@ERROR
END

ELSE
BEGIN
	INSERT INTO 
		CUST_MCH
	(  
			CUST_MCH_GUID
		,   CUST_GUID
		,	CUST_MCH_GRP_GUID
		,	MCH_ID
		,	CUST_MCH_NBR
		,	CUST_MCH_NM
		,	MCH_CAP
		,	MCH_CAP_UOM_ID
		,	MCH_INSTL_DT
		,	MCH_INSTL_DT_TMZN_ID
		,	ROW_STAT_IND
		,	MOD_DTTM
	)
	VALUES
	(
			@MyServiceWashersGuid
		,	@CustGuid
		,	@MyServiceWasherGroupGuid   
		,	@MyServiceMCHId
		,	@PlantWasherNumber
		,	@CustMchName
		,	@MaxLoad
		,	6
		,	getutcdate() --Need Clarification
		,	0 --Need Clarification
		,	CAST(CASE @IsDeleted
			WHEN 'FALSE'
			THEN 'A'
			WHEN 'TRUE'
			THEN 'I'
			ELSE 'A'
		END  AS Char(1))
		,	@LastModifiedTimeStamp
	)
	SET @ErrorId = @@ERROR
END 