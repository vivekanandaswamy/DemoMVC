SELECT 
			LanguageId,
			Name,
			Locale,
			IsActive,
			LastModifiedTime 

FROM		tcd.LanguageMaster 

WHERE		LastModifiedTime				>					 @TimeStamp