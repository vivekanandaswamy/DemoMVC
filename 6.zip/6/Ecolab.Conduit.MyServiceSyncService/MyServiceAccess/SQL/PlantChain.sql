SELECT PlantChainId,
PlantChainName,
RegionId,
Is_Deleted,
MyServiceChnId,
MyServiceLastSynchTime
FROM TCD.PlantChain WHERE MyServiceLastSynchTime > @TimeStamp