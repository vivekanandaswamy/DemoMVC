/*
--Products
DECLARE	@TimeStamp				DATETIME
	,	@RegionCode				VARCHAR(4)

SET		@TimeStamp				=			'01 Jan 1900'
SET		@RegionCode				=			'NA'

*/

SELECT	
	--	*	,
		P.PROD_NBR								AS			SKU
	,	P.PROD_DESC								AS			[Name]
	,	CAST(NULL	AS	FLOAT)					AS			Cost
	,	PSR.PKG_SZ_DENSITY						AS			DensityFactor
	,	PSR.PKG_SZ_DENSITY_UOM_ID				AS			DensityFactorUOMId
	,	UR_Density.UOM_DESC						AS			DensityFactorUOM
	,	CAST(NULL	AS	DECIMAL)				AS			AcceptedDeviation
	,	P.PROD_CAT_ID							AS			ProductCategoryId
	,	PrSR.PROD_ST_DESC						AS			[Type]
	,	S.SPPLR_NM								AS			Supplier
	,	CAST(NULL	AS	BIT)					AS			IncludeinCI
	,	PSR.PKG_SZ_DESC							AS			PackagingSize
	,	PSR.PKG_SZ_WGT							AS			[Weight]
	,	PSR.PKG_SZ_WGT_UOM_ID					AS			[Weight_UOMId]
	,	UR_Weight.UOM_DESC						AS			[Weight_UOM]
	,	PSR.PKG_SZ_VOL							AS			Volume
	,	PSR.PKG_SZ_VOL_UOM_ID					AS			Volume_UOMId
	,	UR_Volume.UOM_DESC						AS			Volume_UOM
	,	CAST	(
				CASE	P.ROW_STAT_IND
					WHEN	'A'
					THEN	'FALSE'
					WHEN	'I'
					THEN	'TRUE'
					ELSE	'FALSE'
				END
		AS	BIT	)								AS			IsDeleted
	,	PCR.PROD_CAT_DESC						AS			ProductcategoryName
	,	P.RGN_CD								AS			RegionCode
	,	CR.CNTRY_NM								AS			Country
	,	P.PROD_ID								AS			MyServiceProdId
	,	P.MOD_DTTM								AS			MyServiceLastModDtTm
	,   (SELECT DISTINCT PROD_DESC FROM PROD_LCLE WHERE LANG_ID=37 AND PROD_ID=P.PROD_ID)
												AS			sp_SP
	,   (SELECT DISTINCT PROD_DESC FROM PROD_LCLE WHERE LANG_ID=28 AND PROD_ID=P.PROD_ID)
												AS			nr_NR
	,   (SELECT DISTINCT PROD_DESC FROM PROD_LCLE WHERE LANG_ID=11 AND PROD_ID=P.PROD_ID)
												AS			nl_BE
	,	PSR.PKG_SZ_ID							AS			PackageSizeId
	,	P.SRC_SYS_CD							AS			SourceSystem
FROM	PROD									P
LEFT JOIN
		PROD_CNTRY_XREF							PCX
	ON	P.PROD_ID								=			PCX.PROD_ID
LEFT JOIN
		CNTRY_REF								CR
	ON	PCX.CNTRY_ID							=			CR.CNTRY_ID
LEFT JOIN
		PKG_SZ_REF								PSR
	ON	P.PKG_SZ_ID								=			PSR.PKG_SZ_ID
LEFT JOIN
		UOM_REF									UR_Density
	ON	PSR.PKG_SZ_DENSITY_UOM_ID				=			UR_Density.UOM_ID
LEFT JOIN
		UOM_REF									UR_Weight
	ON	PSR.PKG_SZ_WGT_UOM_ID					=			UR_Weight.UOM_ID
LEFT JOIN
		UOM_REF									UR_Volume
	ON	PSR.PKG_SZ_VOL_UOM_ID					=			UR_Volume.UOM_ID
LEFT JOIN
		PROD_ST_REF								PrSR
	ON	P.PROD_ST_ID							=			PrSR.PROD_ST_ID
JOIN	SPPLR_MAT_XREF							SMX
	ON	P.SPPLR_ID								=			SMX.SPPLR_ID
	AND	P.SPPLR_MAT_CAT_CD						=			SMX.SPPLR_MAT_CAT_CD
JOIN	SPPLR									S
	ON	SMX.SPPLR_ID							=			S.SPPLR_ID
LEFT JOIN
		PROD_CAT_REF							PCR
	ON	P.PROD_CAT_ID							=			PCR.PROD_CAT_ID

WHERE	P.MOD_DTTM								>=			@TimeStamp
	AND	P.RGN_CD								=			ISNULL(@RegionCode, P.RGN_CD)
	--AND	P.PROD_CAT_ID							IS	NULL
ORDER BY
		P.PROD_ID
