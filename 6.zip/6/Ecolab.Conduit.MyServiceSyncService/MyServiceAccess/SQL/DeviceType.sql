/*DECLARE	@TimeStamp				DATETIME

SET		@TimeStamp				=			'01 Jan 1900'
*/

SELECT
	--*
	--,														DeviceTypeId				--This is Conduitgenerated Id
		WEDTR.WTR_ENRG_DVC_TYP_NM				AS			[Description]
	,	NULL									AS			RegionCode					--might have to be removed on confirmation
	,	CAST(		CASE	WEDTR.ROW_STAT_IND
						WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
					END
			AS	BIT
			)									AS			IsDeleted					--Col. added in Conduit schema
	,	WEDTR.WTR_ENRG_DVC_TYP_ID				AS			MyServiceWtrEnrgDvcTypId
	,	WEDTR.MOD_DTTM							AS			MyServiceModDtTm			--Not to be persisted in Conduit
	,   (SELECT DISTINCT WTR_ENRG_DVC_TYP_NM FROM WTR_ENRG_DVC_TYP_LCLE_REF WHERE LANG_ID=37 AND WTR_ENRG_DVC_TYP_ID=WEDTR.WTR_ENRG_DVC_TYP_ID)
												AS			sp_SP
	,   (SELECT DISTINCT WTR_ENRG_DVC_TYP_NM FROM WTR_ENRG_DVC_TYP_LCLE_REF WHERE LANG_ID=28 AND WTR_ENRG_DVC_TYP_ID=WEDTR.WTR_ENRG_DVC_TYP_ID)
												AS			nr_NR
	,   (SELECT DISTINCT WTR_ENRG_DVC_TYP_NM FROM WTR_ENRG_DVC_TYP_LCLE_REF WHERE LANG_ID=11 AND WTR_ENRG_DVC_TYP_ID=WEDTR.WTR_ENRG_DVC_TYP_ID)
												AS			nl_BE
FROM	WTR_ENRG_DVC_TYP_REF					WEDTR
WHERE	WEDTR.MOD_DTTM							>=			@TimeStamp
ORDER BY
		WEDTR.WTR_ENRG_DVC_TYP_ID
