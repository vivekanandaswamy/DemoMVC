--Drain Destination
--DECLARE	@TimeStamp				DATETIME

--SET		@TimeStamp				=			'01 Jan 1900'

SELECT 
			DTR.DRAIN_TYP_ID							 AS  MyServiceDrainTypeId
		,  DTR.DRAIN_TYP_NM								 AS  DrainDestinationName
		,  CAST(	CASE  DTR.ROW_STAT_IND 
				WHEN	'A'
						THEN	'FALSE'
						WHEN	'I'
						THEN	'TRUE'
						ELSE	'FALSE'
				END
			 AS BIT
			 )											AS	IsDeleted
		,  DTR.MOD_DTTM									AS  MyServiceLastSynchTime
		,   (SELECT DISTINCT DRAIN_TYP_NM FROM DRAIN_TYP_LCLE_REF WHERE LANG_ID=37 AND DRAIN_TYP_ID=DTR.DRAIN_TYP_ID)
												AS			sp_SP
		,   (SELECT DISTINCT DRAIN_TYP_NM FROM DRAIN_TYP_LCLE_REF WHERE LANG_ID=28 AND DRAIN_TYP_ID=DTR.DRAIN_TYP_ID)
												AS			nr_NR
		,   (SELECT DISTINCT DRAIN_TYP_NM FROM DRAIN_TYP_LCLE_REF WHERE LANG_ID=11 AND DRAIN_TYP_ID=DTR.DRAIN_TYP_ID)
												AS			nl_BE
FROM DRAIN_TYP_REF				 DTR
WHERE	DTR.MOD_DTTM							>=			@TimeStamp
ORDER BY
		DTR.DRAIN_TYP_ID




