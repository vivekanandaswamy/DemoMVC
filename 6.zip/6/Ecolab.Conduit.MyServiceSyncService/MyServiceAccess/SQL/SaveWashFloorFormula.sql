DECLARE @CustFrmMchGuid UNIQUEIDENTIFIER 
DECLARE	@ErrorId							INT	

SELECT @CustFrmMchGuid=CUST_FRMULA_MCH_GUID FROM CUST_FRMULA_MCH_XREF WHERE CUST_FRMULA_MCH_GRP_GUID = @FrmMchGrpGuid 
		AND CUST_MCH_GUID=@MchGuid AND Month(SYNC_DTTM) = Month(GetUTCDATE())

SET @ErrorId = 0

IF @CustFrmMchGuid IS NULL
	BEGIN
	SELECT @CustFrmMchGuid = NEWID()
	INSERT INTO CUST_FRMULA_MCH_XREF (CUST_FRMULA_MCH_GUID,
			CUST_FRMULA_MCH_GRP_GUID,
			CUST_MCH_GUID, 
			BATES_PER_MO,
			SYNC_DTTM, 
			ROW_DEL_FLG, 
			ROW_STAT_IND, 
			CRE_DTTM, 
			CRE_OPER, 
			MOD_DTTM, 
			MOD_OPER)
	VALUES (@CustFrmMchGuid,
			@FrmMchGrpGuid,
			@MchGuid,
			@Loads,
			GetUTCDATE(), 
			'N', 
			'A', 
			GETUTCDATE(), 
			'TCD',
			GETUTCDATE(),
			'TCD')
	END
ELSE
	BEGIN
		UPDATE CUST_FRMULA_MCH_XREF
		SET		
			BATES_PER_MO		=				@Loads,
			SYNC_DTTM			=				GetUTCDATE(),
			MOD_DTTM			=				GetUTCDATE(),
			MOD_OPER			=				'TCD'
		WHERE CUST_FRMULA_MCH_GUID = @CustFrmMchGuid

		SET	@ErrorId	=	@@ERROR
	END

SELECT	@ErrorId




