SELECT	[RewashReasonId], [Description], [IsDeleted], [LastModifiedTime], [LastSyncTime] 
	FROM	TCD.RewashReason WHERE LastModifiedTime >= @TimeStamp