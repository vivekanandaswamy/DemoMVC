  SELECT 		CategoryId,
			Name,
			MyServiceProdCatId,
			Is_Deleted,
			LastModifiedTime

FROM		TCD.ProductCategory 

WHERE		LastModifiedTime				>					 @TimeStamp 
ORDER BY CategoryId 
