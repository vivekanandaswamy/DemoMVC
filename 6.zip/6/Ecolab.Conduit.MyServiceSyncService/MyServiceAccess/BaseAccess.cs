﻿// -----------------------------------------------------------------------
// <copyright file="BaseAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The base access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Access;

    /// <summary>
    /// Base class for Access
    /// </summary>
    public class BaseAccess
    {
        /// <summary>
        /// Default Area to use two different connection string 
        /// </summary>
        public const string DEFAULT_AREA = "MyService";

        /// <summary>
        /// Default Area to use two different connection string 
        /// </summary>
        public const string DEFAULT_AREA_HCForms = "HCForms";
    }
}
