﻿// -----------------------------------------------------------------------
// <copyright file="PlantChemicalAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Plant Chemical Access class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.PlantSetup.Chemical;
    using Nalco.Data.Common;

    /// <summary>
    /// Plant Chemical Access
    /// </summary>
    public class PlantChemicalAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of ProductMaster 
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of ProductMaster</returns>
        public static List<ProductMaster> GetPlantChemicalDetails(string ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            List<ProductMaster> plantChemical = DbClient.ExecuteReader<ProductMaster>(DEFAULT_AREA, Resources.PlantChemical,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return plantChemical;
        }

        /// <summary>
        /// Save plant Chemical in my service
        /// </summary>
        /// <param name="conduitPlantChemicalDetail">Conduit Plant Chemical</param>
        public static void SavePlantChemicalDetails(ProductMaster conduitPlantChemicalDetail)
        {
            DbClient.ExecuteNonQuery(DEFAULT_AREA, Resources.SavePlantChemical,
                (cmd, dbContext) =>
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, conduitPlantChemicalDetail.EcolabAccountNumber);
                    cmd.AddParameter("ProductId", conduitPlantChemicalDetail.MyServiceProdId);
                    cmd.AddParameter("Cost", conduitPlantChemicalDetail.Cost);
                    cmd.AddParameter("IncludeinCi", DbType.String, 10, conduitPlantChemicalDetail.IncludeinCI ? "Y" : "N");
                    cmd.AddParameter("InventoryExpense", DbType.String, 10, conduitPlantChemicalDetail.InventoryExpense);
                    cmd.AddParameter("IsDelete", conduitPlantChemicalDetail.IsDelete);
                    cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, conduitPlantChemicalDetail.LastModifiedTimestamp);
                });
        }

        /// <summary>
        /// Get the List of ProductMaster 
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of ProductMaster</returns>
        public static List<ProductStandardPrice> GetPlantProductStandardPrice(string ecolabAccountNumber, DateTime lastSyncTimeInCentral)
        {
            List<ProductStandardPrice> productStandardPrice = DbClient.ExecuteReader<ProductStandardPrice>(DEFAULT_AREA, Resources.ProductStandardPrice,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return productStandardPrice;
        }
    }
}
