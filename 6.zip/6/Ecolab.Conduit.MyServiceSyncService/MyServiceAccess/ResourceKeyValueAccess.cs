﻿// -----------------------------------------------------------------------
// <copyright file="ResourceKeyValueAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The ResourceKeyValueAccess class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities;
    using Entities.Common;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for ResourceKeyValue
    /// </summary>
    public class ResourceKeyValueAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of ResourceKeyValue 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of ResourceKeyValue</returns>
        public static List<ResourceKeyValue> GetResourceKeysDetails(DateTime lastSyncTimeInCentral)
        {
            List<ResourceKeyValue> resourceKeyValueList = DbClient.ExecuteReader<ResourceKeyValue>(Resources.ResourceKeys,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return resourceKeyValueList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="resourceId"></param>
        /// <returns></returns>
        public static List<ResourceValues> GetResourceValues(int resourceId)
        {
            List<ResourceValues> resourceValuesList = DbClient.ExecuteReader<ResourceValues>(Resources.ResourceValues,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("ResourceId", resourceId);
                          }).ToList();

            return resourceValuesList;
        }

        public static List<ResourceKeyPageMapping> GetResourceKeyMapping(int resourceId)
        {
            List<ResourceKeyPageMapping> resourcePageMappingList = DbClient.ExecuteReader<ResourceKeyPageMapping>(Resources.ResourcePageMapping,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("ResourceId", resourceId);
                          }).ToList();

            return resourcePageMappingList;
        }
    }
}
