﻿// -----------------------------------------------------------------------
// <copyright file="ProductMasterAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant Master access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup.Chemical;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for ProductMaster
    /// </summary>
    public class ProductMasterAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of ProductMaster 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of ProductMaster</returns>
        public static List<ProductMaster> GetProductMasterDetails(DateTime lastSyncTimeInCentral)
        {
            string regionCode = null;
            return DbClient.ExecuteReader<ProductMaster>(DEFAULT_AREA, Resources.ProductMaster,
              (cmd, dbContext) =>
              {
                  cmd.AddParameter("RegionCode", DbType.String, 4, regionCode);
                  cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
              }).ToList();
        }

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public static List<ProductMaster> GetProductMasterForSync()
		{
			return
			   DbClient.ExecuteReader<ProductMaster>(Resources.GetProductMasterForSync,
				   delegate(DbCommand cmd, DbContext context)
				   {
				   }).ToList();
		}
    }
}
