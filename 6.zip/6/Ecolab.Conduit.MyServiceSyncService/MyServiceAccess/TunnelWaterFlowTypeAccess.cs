﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWaterFlowTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The TunnelWaterFlowType access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for ProductMaster
    /// </summary>
    public class TunnelWaterFlowTypeAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of TunnelWaterFlowType 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of TunnelWaterFlowType</returns>
        public static List<TunnelWaterFlowType> GetTunnelWaterFlowTypeDetails(DateTime lastSyncTimeInCentral)
        {
            return DbClient.ExecuteReader<TunnelWaterFlowType>(DEFAULT_AREA, Resources.TunnelWaterFlowType,
              (cmd, dbContext) =>
              {
                  cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
              }).ToList();
        }
    }
}
