﻿// -----------------------------------------------------------------------
// <copyright file="EcolabTextileCategoryAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Ecolab TextileCategory access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for EcolabTextileCategory
    /// </summary>
    public class EcolabTextileCategoryAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of EcolabTextileCategory 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of EcolabTextileCategory</returns>
        public static List<EcolabTextileCategory> GetEcolabTextileCategoryDetails(DateTime lastSyncTimeInCentral)
        {
            List<EcolabTextileCategory> ecolabTextileCategories = DbClient.ExecuteReader<EcolabTextileCategory>(DEFAULT_AREA, Resources.EcolabTextileCategory,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return ecolabTextileCategories;
        }
    }
}
