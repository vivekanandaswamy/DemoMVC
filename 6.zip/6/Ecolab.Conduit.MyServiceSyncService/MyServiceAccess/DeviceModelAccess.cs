﻿// -----------------------------------------------------------------------
// <copyright file="DeviceModelAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The device model access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for DeviceModel
    /// </summary>
    public class DeviceModelAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of DeviceModel 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of DeviceModel</returns>
        public static List<DeviceModel> GetDeviceModelDetails(DateTime lastSyncTimeInCentral)
        {
            List<DeviceModel> deviceModels = DbClient.ExecuteReader<DeviceModel>(DEFAULT_AREA, Resources.DeviceModel,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return deviceModels;
        }
    }
}
