﻿// -----------------------------------------------------------------------
// <copyright file="ProductCategoryAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Product Category Master Access </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.PlantSetup.Chemical;    
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for product category
    /// </summary>
    public class ProductCategoryAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of Product Category
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of Product Categories</returns>
        public static List<ProductMaster> GetProductCategoryDetails(DateTime lastSyncTimeInCentral)
        {
            List<ProductMaster> productCategories = DbClient.ExecuteReader<ProductMaster>(Resources.ProductCategory,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return productCategories;
        }

    }
}
