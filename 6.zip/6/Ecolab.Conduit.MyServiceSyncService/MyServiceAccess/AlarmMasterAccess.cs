﻿// -----------------------------------------------------------------------
// <copyright file="AlarmMasterAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Alarm Master Access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Entities;
    using Entities.Common;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for AlarmMaster
    /// </summary>
    public class AlarmMasterAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of AlarmMaster 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of AlarmMaster</returns>
        public static List<AlarmMaster> GetAlarmMasterDetails(DateTime lastSyncTimeInCentral)
        {
            List<AlarmMaster> alarmMasterList = DbClient.ExecuteReader<AlarmMaster>(Resources.AlarmMaster,
                          (cmd, dbContext) =>
                          {
                              cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                          }).ToList();

            return alarmMasterList;
        }
    }
}
