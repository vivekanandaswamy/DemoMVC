﻿// -----------------------------------------------------------------------
// <copyright file="WaterTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The water type access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for WaterType
    /// </summary>
    public class WaterTypeAccess : BaseAccess
    {
        /// <summary>
        /// Get the List of WaterType 
        /// </summary>
        /// <param name="lastSyncTimeInCentral">when the last sync happend in central</param>
        /// <returns>List of WaterType</returns>
        public static List<PlantUtilityWaterTypeMaster> GetWaterTypeDetails(DateTime lastSyncTimeInCentral)
        {
            List<PlantUtilityWaterTypeMaster> waterTypes = DbClient.ExecuteReader<PlantUtilityWaterTypeMaster>(DEFAULT_AREA, Resources.WaterType,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("TimeStamp", DbType.DateTime, lastSyncTimeInCentral);
                           }).ToList();

            return waterTypes;
        }
    }
}
