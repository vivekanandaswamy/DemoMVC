﻿// -----------------------------------------------------------------------
// <copyright file="PlantUserAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The plant user access class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.MyServiceAccess
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Ecolab.Conduit.MyServiceSyncService.Model;
    using Models.PlantSetup.UserManagement;
    using Nalco.Data.Common;

    /// <summary>
    /// Access class for PlantUserAccess
    /// </summary>
    public class PlantUserAccess : BaseAccess
    {
        /// <summary>
        /// Get the list of Users
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="lastSyncTime">lastSyncTime</param>
        /// <returns>plant users</returns>
        public static List<User> GetUserList(string ecolabAccountNumber, DateTime lastSyncTime)
        {
            return DbClient.ExecuteReader<User>(DEFAULT_AREA, Resources.User,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                               cmd.AddParameter("Timestamp", DbType.DateTime, lastSyncTime);
                           }).ToList();
        }

        /// <summary>
        /// Get the list of UsersAccess
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>        
        /// <returns>
        /// plant users access list
        /// </returns>
        public static List<string> GetUserAccessList(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<string>(DEFAULT_AREA, Resources.UserAccess,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);

                           }).ToList();
        }

        /// <summary>
        /// Saves the user.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <param name="trans">The trans.</param>
        /// <param name="context">The context.</param>
        /// <returns></returns>
        public static int SaveUser(User user, DbTransaction trans, DbContext context)
        {
            return DbClient.ExecuteScalar<int>(trans, context, Resources.SaveUserInEnVision,
                (cmd, dbcontext) =>
                {
                    cmd.AddParameter("InLanguageCode", DbType.String, 2, string.IsNullOrEmpty(user.LanguageCode) ? "EN" : user.LanguageCode);
                    cmd.AddParameter("InUserLogin", DbType.String, 55, user.UserLogin);
                    cmd.AddParameter("InPassword", DbType.String, 55, "Envision123@");
                    cmd.AddParameter("InLastName", DbType.String, 55, user.LastName);
                    cmd.AddParameter("InFirstName", DbType.String, 55, user.FirstName);
                    cmd.AddParameter("InStatus", user.Status);
                    cmd.AddParameter("InPhoneNumber", DbType.String, 55, user.PhoneNumber);
                    cmd.AddParameter("InUserCountryCode", DbType.String, 2, user.UserCountryCode);
                    cmd.AddParameter("InEmpId", user.EmpId);
                    cmd.AddParameter("InManId", user.ManId);
                    cmd.AddParameter("InExtendedUserType", DbType.String, 10, user.ExtendedUserType);
                    cmd.AddParameter("InEmailAddress", DbType.String, 100, user.EmailId);
                });
        }

        /// <summary>
        /// Saves the hc forms customers.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="trans">The trans.</param>
        /// <param name="context">The context.</param>
        /// <returns></returns>
        public static int SaveHCFormsCustomers(User user, string ecolabAccountNumber, DbTransaction trans, DbContext context)
        {
            return DbClient.ExecuteScalar<int>(trans, context, Resources.SaveCustomersInEnVision,
                (cmd, dbcontext) =>
                {
                    cmd.AddParameter("InLanguageCode", DbType.String, 2, string.IsNullOrEmpty(user.LanguageCode) ? "EN" : user.LanguageCode);
                    cmd.AddParameter("InPassword", DbType.String, 55, "Envision123@");
                    cmd.AddParameter("InLastName", DbType.String, 55, user.LastName);
                    cmd.AddParameter("InFirstName", DbType.String, 55, user.FirstName);
                    cmd.AddParameter("InStatus", user.IsDeleted);
                    cmd.AddParameter("InPhoneNumber", DbType.String, 55, user.PhoneNumber);
                    cmd.AddParameter("InUserCountryCode", DbType.String, 2, user.UserCountryCode);
                    cmd.AddParameter("InExtendedUserType", DbType.String, 10, user.ExtendedUserType);
                    cmd.AddParameter("InEmailAddress", DbType.String, 100, user.EmailId);
                    cmd.AddParameter("EnvisionRole", DbType.String, 100, user.EnvisionRole);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                });
        }

        /// <summary>
        /// Gets the en vision customers list.
        /// </summary>
        /// <param name="contractNumber">The contract number.</param>
        /// <returns></returns>
        public static List<User> GetEnvisionCustomersList(string contractNumber)
        {
            return DbClient.ExecuteReader<User>(DEFAULT_AREA_HCForms, Resources.GetCustomersFromHCForms,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("ContractNumber", DbType.String, 25, contractNumber);
                           }).ToList();
        }

        /// <summary>
        /// Gets the contract number.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns></returns>
        public static string GetContractNumber(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<string>(DEFAULT_AREA, Resources.GetContractNumber,
                           (cmd, dbContext) =>
                           {
                               cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);

                           });
        }

        /// <summary>
        /// SaveUserAccess
        /// </summary>
        /// <param name="userLogin">user Login</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="trans">the transactions</param>
        /// <param name="context">database context</param>
        /// <returns>success/failure</returns>
        public static int SaveUserAccess(string userLogin, string ecolabAccountNumber, DbTransaction trans, DbContext context)
        {
            return DbClient.ExecuteScalar<int>(trans, context, Resources.SaveUserAccessInEnVision,
                (cmd, dbcontext) =>
                {
                    cmd.AddParameter("InUserLogin", DbType.String, 55, userLogin);
                    cmd.AddParameter("InEcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                });
        }

        /// <summary>
        /// Validate User In Conduit
        /// </summary>
        /// <param name="userDetails">model contains user details</param>
        /// <returns>101(insert)/userId(update)</returns>
        public static int ValidateUserInConduit(UserManagement userDetails)
        {
            int returnValue = 0;
            returnValue = DbClient.ExecuteScalar<int>(Resources.ValidateUserInConduit, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, userDetails.EcolabAccountNumber);
                cmd.AddParameter("UserLogin", DbType.String, 1000, userDetails.LoginName);
            });
            return returnValue;
        }

        /// <summary>
        /// FetchLastModifiedTimeAtCental
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="userId">userId</param>
        /// <returns>Last Modified time</returns>
        public static DateTime FetchLastModifiedTimeAtCental(string ecolabAccountNumber, int userId)
        {
            DateTime lastModifiedTime;
            lastModifiedTime = DbClient.ExecuteScalar<DateTime>(Resources.FetchModifiedTimeForUserManagement, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                cmd.AddParameter("UserId", userId);
            });
            return lastModifiedTime;
        }

    }
}
