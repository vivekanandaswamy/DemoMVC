﻿// -----------------------------------------------------------------------
// <copyright file="WashFloorFormula.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The WashFloorFormula </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.MyServiceSyncService.Common;

namespace Ecolab.Conduit.MyServiceSyncService.Model
{
    public class WashFloorFormula
    {
        //public WashFloorFormula(string ecolabAccountNumber, int washerId, int programNum, int loads)
        //{
        //    EcolabAccountNumber = ecolabAccountNumber;
        //    WasherId = washerId;
        //    ProgramNumber = programNum;
        //    Loads = loads;
        //}

        [ModelHeaderAttribute("[Measures].[Key]")]
        public string EcolabAccountNumber { get; set; }
        [ModelHeaderAttribute("[Measures].[WasheridKey]")]
        public string WasherId { get; set; }
        [ModelHeaderAttribute("[Measures].[ProgramIdKey]")]
        public string ProgramNumber { get; set; }
        [ModelHeaderAttribute("[Measures].[NoOfLoads]")]
        public int Loads { get; set; }
    }
}
