﻿// -----------------------------------------------------------------------
// <copyright file="CustEfficiencyWashFloor.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CustEfficiencyWashFloor </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.MyServiceSyncService.Common;

namespace Ecolab.Conduit.MyServiceSyncService.Model
{
    public class CustEfficiencyWashFloor
    {
        //public WashFloorFormula(string ecolabAccountNumber, int washerId, int programNum, int loads)
        //{
        //    EcolabAccountNumber = ecolabAccountNumber;
        //    WasherId = washerId;
        //    ProgramNumber = programNum;
        //    Loads = loads;
        //}

        [ModelHeaderAttribute("[Measures].[Key]")]
        public string EcolabAccountNumber { get; set; }

        [ModelHeaderAttribute("[Measures].[TotalEfficiency]")]
        public double TotalEfficiency { get; set; }

        [ModelHeaderAttribute("[Measures].[LoadEfficiency]")]
        public double LoadEfficiency { get; set; }

        [ModelHeaderAttribute("[Date].[Week Of Year].[Week Of Year]")]
        public string Week { get; set; }

        public int TurnTime { get; set; }

        public int TransferTime { get; set; }

        [ModelHeaderAttribute("[Washer].[MachineGroupType].[MachineGroupType]")]
        public string WasherGroupType { get; set; }
    }
}
