﻿// -----------------------------------------------------------------------
// <copyright file="MyServicePlant.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MyServicePlant </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Conduit.MyServiceSyncService.Model
{
    /// <summary>
    /// MyService Plant Creation Model
    /// </summary>
    public class MyServicePlant
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public MyServicePlant()
        {

        }

        /// <summary>
        /// Parametriezed Constructor
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="syncDateTime">syncDateTime</param>
        /// <param name="active">Active param</param>
        public MyServicePlant(string ecolabAccountNumber, DateTime? syncDateTime, bool active)
        {
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.SyncDateTime = syncDateTime;
            this.Active = active;
        }

        /// <summary>
        /// Gets or sets EcolabAccountNumber
        /// </summary>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets SyncDateTime
        /// </summary>
        public DateTime? SyncDateTime { get; set; }

        /// <summary>
        /// Gets or sets Active
        /// </summary>
        public bool Active { get; set; }
    }
}
