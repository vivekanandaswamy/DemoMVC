﻿// -----------------------------------------------------------------------
// <copyright file="CustLoadsWashFloor.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CustLoadsWashFloor </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ecolab.Conduit.MyServiceSyncService.Common;

namespace Ecolab.Conduit.MyServiceSyncService.Model
{
    public class CustLoadsWashFloor
    {
        //public WashFloorFormula(string ecolabAccountNumber, int washerId, int programNum, int loads)
        //{
        //    EcolabAccountNumber = ecolabAccountNumber;
        //    WasherId = washerId;
        //    ProgramNumber = programNum;
        //    Loads = loads;
        //}

        [ModelHeaderAttribute("[Measures].[Key]")]
        public string EcolabAccountNumber { get; set; }

        [ModelHeaderAttribute("[Measures].[NoOfLoads]")]
        public int Loads { get; set; }

        [ModelHeaderAttribute("[Measures].[Totalweight]")]
        public int SoilWeight { get; set; }

		[ModelHeaderAttribute("[Date].[Datefield].[Datefield].[MEMBER_CAPTION]")]
		public string WashFloorDate { get; set; }
    }
}
