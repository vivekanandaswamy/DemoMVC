﻿// -----------------------------------------------------------------------
// <copyright file="Controller.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller </summary>
// ----------------------------------------------------------------------- 

using System;

namespace Ecolab.Conduit.MyServiceSyncService.Model
{
   public class Controller
    {
        #region "Constructor"

        /// <summary>
        ///     Constructor for the Controller
        /// </summary>
        /// <param name="controllerId">The ControllerId</param>
        /// <param name="controllerModelId">The ControllerModelId</param>
        /// <param name="controllerModelName">The Controller Model Name</param>
        /// <param name="controllerName">The Controller Name</param>
        /// <param name="controllerNumber">The Controller Number</param>
        /// <param name="controllerTypeId">The Controller Type Id</param>
        /// <param name="controllerType">The Controller Type</param>
        /// <param name="controllerVersion">The Controller Version</param>
        /// <param name="installDate">The Install Date</param>
        /// <param name="ecolabAccountNumber">Ecolab account number</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <param name="isDeleted">isDeleted Flag</param>
        /// <param name="topicName">The Topic Name</param>
        /// <param name="washerExtractorCount">washer Extractor Count</param>
        /// <param name="maxTunnelCount">maximum Tunnel Count</param>
        /// <param name="myServiceDispenserGuid">myService Dispenser Guid</param>
        /// <param name="serialNumber">Serial Number</param>
        /// <param name="regionId">The Region Id</param>
        public Controller(
            int controllerId,
            int controllerModelId,
            string controllerModelName,
            string controllerName,
            int controllerNumber,
            int controllerTypeId,
            string controllerType,
            string controllerVersion,
            DateTime? installDate,
            string ecolabAccountNumber,
            DateTime lastModifiedTimestamp,
            DateTime lastSyncTime,
            bool isDeleted,
            string topicName,
            byte washerExtractorCount,
            byte maxTunnelCount,
            Guid myServiceDispenserGuid,
            string serialNumber,
            short regionId
            )
        {
            ControllerId = controllerId;
            ControllerModelId = controllerModelId;
            ControllerModelName = controllerModelName;
            ControllerName = controllerName;
            ControllerNumber = controllerNumber;
            ControllerTypeId = controllerTypeId;
            ControllerType = controllerType;
            ControllerVersion = controllerVersion;
            InstallDate = installDate;
            EcolabAccountNumber = ecolabAccountNumber;
            LastModifiedTimeStamp = lastModifiedTimestamp;
            LastSyncTime = lastSyncTime;
            IsDelete = isDeleted;
            TopicName = topicName;
            this.WasherExtractorCount = washerExtractorCount;
            this.MaxTunnelCount = maxTunnelCount;
            MyServiceDispenserGUID = myServiceDispenserGuid;
            SerialNumber = serialNumber;
            RegionId = regionId;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Controller Id
        /// </summary>
        /// <value>The Parameter Controller Id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value>The Parameter Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Name
        /// </summary>
        /// <value>The Parameter Controller Model Name</value>
        public string ControllerModelName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Name
        /// </summary>
        /// <value>The Parameter Controller Name</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Number
        /// </summary>
        /// <value>The Parameter Controller Number</value>
        public int ControllerNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type Id
        /// </summary>
        /// <value>The Parameter Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type
        /// </summary>
        /// <value>The Parameter Controller Type</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Version
        /// </summary>
        /// <value>The Parameter Controller Version</value>
        public string ControllerVersion { get; set; }

        /// <summary>
        ///     Gets or sets the Install Date
        /// </summary>
        /// <value>The Parameter Install Date</value>
        public DateTime? InstallDate { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Install Date as string form
        /// </summary>
        /// <value>The Parameter Install Date as String</value>
        public string InstallDateAsString { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Topic Name
        /// </summary>
        /// <value>Topic Name</value>
        public string TopicName { get; set; }
        /// <summary>
        /// WasherExtractorCount
        /// </summary>
        public byte WasherExtractorCount { get; set; }
        /// <summary>
        /// MaxTunnelCount
        /// </summary>
        public byte MaxTunnelCount { get; set; }

        /// <summary>
        /// Gets or sets MyServiceDispenserGUID
        /// </summary>
        /// <value>MyServiceDispenserGUID</value> 
        public Guid MyServiceDispenserGUID { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        /// <value>SerialNumber</value> 
        public string SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets RegionId
        /// </summary>
        /// <value>RegionId</value> 
        public short RegionId { get; set; }

        #endregion
    }
}
