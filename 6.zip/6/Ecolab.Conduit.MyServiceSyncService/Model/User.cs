﻿// -----------------------------------------------------------------------
// <copyright file="User.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The User </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Conduit.MyServiceSyncService.Model
{
    public class User
    {
        #region Constructor
        /// <summary>
        /// Default Constructor
        /// </summary>
        public User()
        {

        }

        /// <summary>
        /// parametrized Constructor
        /// </summary>
        public User(string languageCode,
                            string userLogin,
                            string lastName,
                            string firstName,
                            byte status,
                            string phnNumber,
                            string userCountryCode,
                            int? empNumber,
                            int? manNumber,
                            string extendedUserType)
        {
            LanguageCode = languageCode;
            UserLogin = userLogin;
            LastName = lastName;
            FirstName = firstName;
            Status = status;
            PhoneNumber = phnNumber;
            UserCountryCode = userCountryCode;
            EmpId = empNumber;
            ManId = manNumber;
            ExtendedUserType = extendedUserType;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="User" /> class.
        /// </summary>
        /// <param name="firstName">The first name.</param>
        /// <param name="lastName">The last name.</param>
        /// <param name="phone">The phone.</param>
        /// <param name="email">The email.</param>
        /// <param name="country">The country.</param>
        /// <param name="language">The language.</param>
        /// <param name="region">The region.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="chainContract">The chain contract.</param>
        /// <param name="envisionRole">The envision role.</param>
        public User(string firstName, string lastName, string phone, string email, string country, string language, string region, bool isDeleted, int chainContract, string envisionRole)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.PhoneNumber = phone;
            this.EmailId = email;
            this.UserCountryCode = country;
            this.LanguageCode = language;
            this.PlantChainContract = chainContract;
            this.Region = region;
            this.IsDeleted = isDeleted;
            this.EnvisionRole = envisionRole;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets LanguageCode
        /// </summary>
        public string LanguageCode { get; set; }

        /// <summary>
        /// Gets or sets UserLogin
        /// </summary>
        public string UserLogin { get; set; }

        /// <summary>
        /// Gets or sets LastName
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets FirstName
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        public byte Status { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets UserCountryCode
        /// </summary>
        public string UserCountryCode { get; set; }

        /// <summary>
        /// Gets or sets EmpId
        /// </summary>
        public int? EmpId { get; set; }

        /// <summary>
        /// Gets or sets ManId
        /// </summary>
        public int? ManId { get; set; }

        /// <summary>
        /// Gets or sets ExtendedUserType
        /// </summary>
        public string ExtendedUserType { get; set; }

        /// <summary>
        /// Gets or sets EmailId
        /// </summary>
        public string EmailId { get; set; }

        /// <summary>
        /// Gets or sets the plant chain contract.
        /// </summary>
        /// <value>
        /// The plant chain contract.
        /// </value>
        public int PlantChainContract { get; set; }

        /// <summary>
        /// Gets or sets the region.
        /// </summary>
        /// <value>
        /// The region.
        /// </value>
        public string Region { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is deleted; otherwise, <c>false</c>.
        /// </value>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets the envision role.
        /// </summary>
        /// <value>
        /// The envision role.
        /// </value>
        public string EnvisionRole { get; set; }
        #endregion
    }
}
