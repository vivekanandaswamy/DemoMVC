﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceSyncService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MyServiceSyncService </summary>
// -----------------------------------------------------------------------

using System;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Timers;
using Ecolab.Conduit.MyServiceSyncService.Processor;
using Ecolab.Conduit.MyServiceSyncService.Properties;
using log4net;

namespace Ecolab.Conduit.MyServiceSyncService
{
    public partial class MyServiceSyncService : ServiceBase
    {
        /// <summary>
        /// logger instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("MyServiceSyncService");

        /// <summary>
        /// enable or disable washfloor sync
        /// </summary>
        private static bool enableWashFloor = Convert.ToBoolean(ConfigurationManager.AppSettings["EnableWashFloorSync"].ToString());

        private Timer batchTimer;

        public MyServiceSyncService()
        {
            InitializeComponent();
        }

        internal void Start()
        {
            OnStart(null);
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                if (!Debugger.IsAttached)
                {
                    batchTimer = new Timer();
                    batchTimer.AutoReset = bool.Parse(Settings.Default.TimerAutoReset);
                    batchTimer.Start();
                    batchTimer.Elapsed += ReCallProcess;

                    Log.Info("MyServiceSyncService : Timer property set successfully. ");
                }
                else
                {
                    ProcessIntegration();
                    ProcessWashFloorData();
                }
            }
			catch(Exception ex)
            {
                Log.Error("OnStart", ex);
            }
        }

        private void ReCallProcess(object sender, EventArgs e)
        {
			try
			{
				Log.Info("Batch Timer stopped.");
            batchTimer.Stop(); //stop the timer till batch process doesn't complete.
            ProcessIntegration();
            if (enableWashFloor)
            {
                ProcessWashFloorData();
            }
			}
			catch (Exception ex)
			{
				Log.Error("Error in myService Sync process." + ex);
			}
			finally
			{
				Log.Info("Batch timer started.");
            batchTimer.Enabled = bool.Parse(Settings.Default.TimerEnabled);
            batchTimer.Interval = double.Parse(Settings.Default.TimerInterval, CultureInfo.CurrentCulture) * 1000;
            batchTimer.Start(); // start the time. It will take Interval time ( 15 min ) to fire next time.
        }
		}

        protected override void OnStop()
        {
			if(!Debugger.IsAttached)
                batchTimer.Stop();
            Log.Info("Service stopped.");
        }

        private static void ProcessIntegration()
        {
            try
            {
                Log.Info("MyServiceSyncService process started....");
                ProcessEntities.StartIntegrationProcess();

                System.Threading.Thread.Sleep(60);
            }
			catch(SocketException socEx)
            {
                Log.Error("Error Received While processing :" + socEx);
            }
			catch(Exception ex)
            {
                Log.Error("Error occured while processing :" + ex);
            }
        }

        private static void ProcessWashFloorData()
        {
            try
            {
                Log.Info("Washfloordata sync started....");
                ProcessEntities.StartWashFloorDataSync();

                System.Threading.Thread.Sleep(60);
            }
            catch (SocketException socEx)
            {
                Log.Error("Error Received While processing :" + socEx);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured while processing :" + ex);
            }
        }
    }
}
