﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Program </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess.DB;
using Ecolab.Data.Access;
using Ecolab.Services.Infra;
using Ecolab.Conduit.PushHandler;

namespace Ecolab.Conduit.MyServiceSyncService
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
			Push.LoggerName = "MyServiceSyncService";
			log4net.Config.XmlConfigurator.Configure();
            Database.ApplicationMode = Entities.ApplicationMode.Central;
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            DbHelper.InitializeConnection(ConfigurationManager.ConnectionStrings["MyServiceConnection"].ToString());
            DbHelper.InitializeHCFormConnection(ConfigurationManager.ConnectionStrings["HCFormsConnection"].ToString());
            AutoMapper.Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
            if (Debugger.IsAttached)
            {
                using (TestMyserviceIntegration form = new TestMyserviceIntegration())
                {
                    Application.Run(form);
                }
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] 
            { 
                new MyServiceSyncService() 
            };
                log4net.Config.XmlConfigurator.Configure();
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}
