﻿// -----------------------------------------------------------------------
// <copyright file="CubeDatatableToList.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CubeDatatableToList </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using log4net;
using Microsoft.AnalysisServices.AdomdClient;

namespace Ecolab.Conduit.MyServiceSyncService.Common
{
    /// <summary>
    ///     An Extension class to convert the Data Table to List T.
    /// </summary>
    /// <remarks></remarks>
    public static class CubeDatatableToList
    {
        /// <summary>
        ///     Converts to list.
        /// </summary>
        /// <typeparam name="T"> Type of T is generic object.</typeparam>
        /// <param name="dt">The Data Table.</param>
        /// <returns>Returns the list of generic object</returns>
        public static List<T> ConvertToList<T>(DataTable dt)
        {
            List<T> lst = new List<T>();
            foreach (DataRow dw in dt.Rows)
            {
                Type tp = typeof(T);
                T obj = Activator.CreateInstance<T>();
                PropertyInfo[] pf = tp.GetProperties();
                foreach (PropertyInfo pinfo in pf)
                {
                    object[] colname = pinfo.GetCustomAttributes(typeof(ModelHeaderAttribute), false);
                    if (colname.Length == 0)
                        continue;
                    string col = (colname[0] as ModelHeaderAttribute).Name;

                    var res = (from DataColumn x in dt.Columns
                               where col.Contains(x.ColumnName)
                               select x.ColumnName).ToList();

                    if (!res.Any())
                    {
                        continue;
                    }
                    col = res.ToList()[0];

                    if (dw[col] == null)
                        continue;
                    if (dw[col] == DBNull.Value)
                        continue;
                    pinfo.SetValue(obj, dw[col], null);
                }
                lst.Add(obj);
            }
            return lst;
        }
    }

    /// <summary>
    /// Model header attribute class
    /// </summary>
    public class ModelHeaderAttribute : Attribute
    {
        /// <summary>
        ///  Gets or Sets Name 
        /// </summary>
        /// <value>Contains Name Value for the Header</value>
        public string Name { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ModelHeaderAttribute"/> class.
        /// </summary>
        /// <param name="name">The name value.</param>
        public ModelHeaderAttribute(string name)
        {
            this.Name = name;
        }
    }

    /// <summary>
    /// Utility to fetch data from Cube
    /// </summary>
    public static class CubeUtility
    {
        /// <summary>
        /// The connection string
        /// </summary>
        public static string CubeConnectionString = ConfigurationManager.ConnectionStrings["TcdCubeConnection"].ToString();

        /// <summary>
        /// Log4net logger.
        /// </summary>
        public static ILog Logger = LogManager.GetLogger("Cental Reports");

        private static void LogMDX(string mdxQuery)
        {
            StringBuilder infoBuilder = new StringBuilder();
            infoBuilder.AppendLine();
            infoBuilder.AppendLine("------------------------------------------------------------------------------------------------------");
            infoBuilder.AppendLine(mdxQuery);
            Logger.Info(infoBuilder);

        }
        /// <summary>
        /// Get details from Analysis Services(CUBE)
        /// </summary>
        /// <param name="mdxQuery">MDX Query to be executed to fetch details</param>
        /// <returns>Returns the data tale.</returns>
        public static DataTable FetchDataFromCube(string mdxQuery)
        {
            LogMDX(mdxQuery);

            DataSet ds = new DataSet();

            using (AdomdConnection conn = new AdomdConnection(CubeConnectionString))
            {
                conn.Open();

                AdomdCommand adomdCmd = new AdomdCommand(mdxQuery, conn);

                CellSet cst = adomdCmd.ExecuteCellSet();

                ds = ConvertCellSetToDataSet(cst);
            }

            return ds.Tables.Count > 0 ? ds.Tables[0] : new DataTable();
        }

        /// <summary>
        /// Converts cell set to dataset
        /// </summary>
        /// <param name="csresult">Cellset</param>
        /// <returns>Dataset</returns>
        public static DataSet ConvertCellSetToDataSet(CellSet csresult)
        {
            if (csresult == null)
            {
                return null;
            }

            DataSet dsresult = new DataSet();
            DataTable dtresult = new DataTable();
            DataColumn dcresult = null;
            DataRow drresult = null;
            if (csresult.Axes[1].Positions.Count > 0)
            {
                Position py = csresult.Axes[1].Positions[0];

                int index = 1;
                foreach (Member m in py.Members)
                {
                    dcresult = new DataColumn();
                    dcresult.ColumnName = m.LevelName;
                    dtresult.Columns.Add(dcresult);
                    index++;
                }
            }

            String name = null;
            foreach (Position pos in csresult.Axes[0].Positions)
            {
                dcresult = new DataColumn();
                name = string.Empty;
                foreach (Member m in pos.Members)
                {
                    name += m.Name + string.Empty;
                }
                dcresult.ColumnName = name;

                if (dcresult.ColumnName.Contains("Measures"))
                {
                    dcresult.DataType = System.Type.GetType("System.Object");
                }
                dtresult.Columns.Add(dcresult);
            }

            int y = 0;
            int colIndex = 0;
            int x = 0;
            foreach (Position py in csresult.Axes[1].Positions)
            {
                drresult = dtresult.NewRow();
                colIndex = 0;
                foreach (Member m in py.Members)
                {
                    drresult[colIndex] = m.Caption;
                    colIndex++;
                }

                for (x = 0; x < csresult.Axes[0].Positions.Count; x++)
                {

                    drresult[colIndex] = csresult[x, y].Value;
                    colIndex++;
                }
                dtresult.Rows.Add(drresult);
                y++;
            }
            dsresult.Tables.Add(dtresult);
            return dsresult;
        }
    }
}
