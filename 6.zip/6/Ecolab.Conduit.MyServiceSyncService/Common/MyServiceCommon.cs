﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceCommon.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The common helper class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.MyServiceSyncService.Common
{
    using System;
    using System.Configuration;
    using System.DirectoryServices;
    using System.DirectoryServices.AccountManagement;
    using Access;
    using Entities;
    using Model;
    using Newtonsoft.Json;

    /// <summary>
    /// Common Helper class
    /// </summary>
    public class MyServiceCommon
    {
        /// <summary>
        /// The LDAP path
        /// </summary>
        private static string LDAPPath = (ConfigurationManager.AppSettings["LDAPPath"]).ToString();
        /// <summary>
        /// The LDAP user
        /// </summary>
        private static string LDAPUser = (ConfigurationManager.AppSettings["LDAPUser"]).ToString();
        /// <summary>
        /// The LDAP password
        /// </summary>
        private static string LDAPPassword = (ConfigurationManager.AppSettings["LDAPPassword"]).ToString();

        /// <summary>
        /// The _directory entry
        /// </summary>
        private DirectoryEntry _directoryEntry = null;

        /// <summary>
        /// Check whether plant is connected or not
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <returns>
        /// true if plant is not connected otherwise false
        /// </returns>
        public static bool IsPlantConnected(string ecolabAccountNumber)
        {
            return PlantAccess.IsConnectedPlant(ecolabAccountNumber);
        }

        /// <summary>
        /// Get MyServiceSyncLog Object
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="entityName">Entity Name which we sync last time</param>
        /// <returns>
        /// Object of MyServiceSyncLog
        /// </returns>
        public static MyServiceSyncLog GetMyServiceSyncLogDetails(string ecolabAccountNumber, string entityName)
        {
            return MyServiceSyncLogAccess.GetMyServiceSyncLogDetails(ecolabAccountNumber, entityName);
        }

        /// <summary>
        /// Update myservice log details
        /// </summary>
        /// <param name="ecolabAccountNumber">Plant Number</param>
        /// <param name="entity">Entity of Table Name</param>
        /// <param name="status">Yes if success otherwise Fail</param>
        public static void UpdateMyServiceSyncLog(string ecolabAccountNumber, string entity, string status)
        {
            MyServiceSyncLogAccess.UpdateMyServiceSyncLog(ecolabAccountNumber, entity, status);
        }

        /// <summary>
        /// Serialize To JSON From Entity
        /// </summary>
        /// <typeparam name="T">Any entity of any type</typeparam>
        /// <param name="t">object of entity</param>
        /// <returns>
        /// Returns the string
        /// </returns>
        public static string SerializeToJsonFromEntity<T>(T t)
        {
            return JsonConvert.SerializeObject(t);
        }

        /// <summary>
        /// Convert the Utc time into MyService Time zone
        /// </summary>
        /// <param name="utcTime">Date time in UTC Time format</param>
        /// <returns>
        /// My Service Time
        /// </returns>
        public static DateTime ConvertUTCTimeToMyServiceTime(DateTime utcTime)
        {
            DateTime myServiceTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utcTime, DateTimeKind.Utc),
                                            TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings["TimeZone"]));

            return myServiceTime;
        }

        /// <summary>
        /// Converts the UTC time to my service time.
        /// </summary>
        /// <param name="utcTime">The UTC time.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>My Service Time</returns>
        public static DateTime ConvertUTCTimeToMyServiceTime(DateTime utcTime, string ecolabAccountNumber)
        {
            DateTime myServiceTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utcTime, DateTimeKind.Utc),
                                           TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings["TimeZone"]));
            return myServiceTime;
        }

        /// <summary>
        /// Convert the MyService Time zone into  Utc time
        /// </summary>
        /// <param name="myServiceTime">MyServiceTime</param>
        /// <returns>
        /// The UTC time.
        /// </returns>
        public static DateTime ConvertMyServiceTimeToUTCTime(DateTime myServiceTime)
        {

            DateTime utcTime = TimeZoneInfo.ConvertTimeToUtc(myServiceTime,
                                            TimeZoneInfo.FindSystemTimeZoneById(ConfigurationManager.AppSettings["TimeZone"]));

            return DateTime.SpecifyKind(utcTime, DateTimeKind.Utc);
        }

        /// <summary>
        /// Converts my service time to UTC time.
        /// </summary>
        /// <param name="myServiceTime">My service time.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>The My Service Time.</returns>
        public static DateTime ConvertMyServiceTimeToUTCTime(DateTime myServiceTime, string ecolabAccountNumber)
        {

            DateTime utcTime = TimeZoneInfo.ConvertTimeToUtc(myServiceTime,
                                            TimeZoneInfo.FindSystemTimeZoneById(GetPlantTimeZone(ecolabAccountNumber)));

            return DateTime.SpecifyKind(utcTime, DateTimeKind.Utc);
        }

        /// <summary>
        /// Gets the plant time zone.
        /// </summary>
        /// <param name="ecolabAccntNbr">The ecolab accnt NBR.</param>
        /// <returns>Plant Time Zone</returns>
        private static string GetPlantTimeZone(string ecolabAccntNbr)
        {
            Plant plant = PlantAccess.GetPlantLocalTimeZone(ecolabAccntNbr);

            return plant.TimeZone;
        }

        /// <summary>
        /// Get GetRegionId
        /// </summary>
        /// <param name="regionCode">The region Code</param>
        /// <returns>Returns the integer value</returns>
        public static int GetRegionId(string regionCode)
        {
            return MyServiceSyncLogAccess.GetRegionId(regionCode);
        }

        /// <summary>
        /// Gets the email id for the myservice domain account name
        /// </summary>
        /// <param name="domainAcctName">MyService login name</param>
        /// <returns>
        /// Returns the email id
        /// </returns>
        public static string GetEmailIdFromActiveDirectory(string domainAcctName)
        {
            string emailId = string.Empty;
            DirectoryEntry entry = new DirectoryEntry();
            DirectorySearcher search = new DirectorySearcher(entry);

            search.Filter = "(&(objectClass=user)(anr=" + domainAcctName + "))";

            search.PropertiesToLoad.Add("givenName");
            search.PropertiesToLoad.Add("sn");
            search.PropertiesToLoad.Add("mail");

            SearchResult result = search.FindOne();
            if (result != null)
            {
                emailId = result.Properties["mail"][0].ToString();
            }

            return emailId;
        }

        /// <summary>
        /// Saves the user in active directory.
        /// </summary>
        /// <param name="user">The user data.</param>
        /// <param name="domainAcctName">Name of the domain acct.</param>
        /// <returns>Returns the boolean value</returns>
        public static bool SaveUserInactiveDirectory(User user, string domainAcctName)
        {
            try
            {
                PrincipalContext context = new PrincipalContext(ContextType.Machine, LDAPPath, LDAPUser, LDAPPassword);
                GroupPrincipal group = GroupPrincipal.FindByIdentity(context, domainAcctName);
                UserPrincipal userPrincipal = UserPrincipal.FindByIdentity(context, user.UserLogin);
                if (user != null & group != null)
                {
                    group.Members.Add(userPrincipal);
                    group.Save();
                  userPrincipal.IsMemberOf(group);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
