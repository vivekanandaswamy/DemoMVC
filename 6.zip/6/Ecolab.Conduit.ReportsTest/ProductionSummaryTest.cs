﻿// -----------------------------------------------------------------------
// <copyright file="ProductionSummaryTest.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary> Production Summary Test class</summary>
// -----------------------------------------------------------------------

using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ecolab.Services.Reports.FormulaEngine;
using Ecolab.Models.Reports.ResourcesUtilization;
using Ecolab.Models.Reports.ProductionEfficiency;

namespace Ecolab.Conduit.ReportsTest
{
    /// <summary>
    /// Summary description for ProductionSummaryTest
    /// </summary>
    [TestClass]
    public class ProductionSummaryTest
    {
        ProductionSummaryFormula productionSummaryFormula;
        ProductionSummary productionSummary;


        /// <summary>
        /// Initialize the tests with default values
        /// </summary>
        [TestInitialize]
        public void InitializeProductionSummary()
        {
            List<ProductionSummary> productionSummaryList = new List<ProductionSummary>();
            productionSummaryList.Add(new ProductionSummary
            {
                ActualProduction = 100,
                TargetProduction = 100,
                ActualRunTime = 100,
                TargetRunTime = 100
            });
            productionSummaryFormula = new ProductionSummaryFormula(productionSummaryList);
            productionSummaryFormula.ComputeProductionSummary();
            productionSummary = productionSummaryList.FirstOrDefault();
        }

        /// <summary>
        /// Test to verify formula for Actualproductionhour
        /// </summary>
        [TestMethod]
        public void GetActualproductionhour()
        {
            Assert.IsTrue(Math.Round(productionSummary.Actualproductionhour,2) == 3600);
        }

        /// <summary>
        /// Test to verify formula for Targetproductionhour
        /// </summary>
        [TestMethod]
        public void GetTargetproductionhour()
        {
            Assert.IsTrue(Math.Round(productionSummary.Targetproductionhour,2) ==  3600);
        }
    }
}
