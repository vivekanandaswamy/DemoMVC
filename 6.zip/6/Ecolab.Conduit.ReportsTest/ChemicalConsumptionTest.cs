﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalConsumptionTest.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary> Chemical Consumption Test class</summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;
using System.Linq;

using Ecolab.Models.Reports.ResourcesUtilization;
using Ecolab.Services.Reports.FormulaEngine;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace Ecolab.Conduit.ReportsTest
{
    /// <summary>
    /// Summary description for ChemicalConsumptionTest
    /// </summary>
    [TestClass]
    public class ChemicalConsumptionTest
    {
        public ChemicalConsumptionTest()
        {
        }

        ChemicalConsumptionFormula formula;
        ChemicalConsumption chemicalConsumption;

        /// <summary>
        ///  Initialize the tests with default values
        /// </summary>
        [TestInitialize]
        public void InitializeChemicalConsumption()
        {
            List<ChemicalConsumption> chemicalConsumptionList = new List<ChemicalConsumption>();
            chemicalConsumptionList.Add(new ChemicalConsumption
            {
                TotalConsumption = 100,
                ProgramCount = 10,
                NoOfLoads = 10,
                NoOfDays = 10,
                TotalConsumptionMetrics = 100,
                Cost = 100,
                TargetCost = 50
            });

            formula = new ChemicalConsumptionFormula(chemicalConsumptionList,1);
            formula.ComputeChemicalConsumption();
            chemicalConsumption = chemicalConsumptionList.FirstOrDefault();

        }

        /// <summary>
        /// Test to verify formula for AverageConsumption
        /// </summary>
        [TestMethod]
        public void GetAverageConsumption()
        {
            Assert.IsTrue(chemicalConsumption.AverageConsumption == 10);
        }

        /// <summary>
        /// Test to verify formula for AverageDailyConsumption
        /// </summary>
        [TestMethod]
        public void GetAverageDailyConsumption()
        {
            Assert.IsTrue(chemicalConsumption.AverageDailyConsumption == 10);
        }

        /// <summary>
        /// Test to verify formula for ActualConsumptionPerLoad
        /// </summary>
        [TestMethod]
        public void GetActualConsumptionPerLoad()
        {
            Assert.IsTrue(chemicalConsumption.ActualConsumptionPerLoad == 10);
        }

        /// <summary>
        /// Test to verify formula for CostPerLoad
        /// </summary>
        [TestMethod]
        public void GetCostPerLoad()
        {
            Assert.IsTrue(chemicalConsumption.CostPerLoad == 10);
        }

        /// <summary>
        /// Test to verify formula for CostExcess
        /// </summary>
        [TestMethod]
        public void GetCostExcess()
        {
            Assert.IsTrue(chemicalConsumption.CostExcess == 50);
        }
    }
}
