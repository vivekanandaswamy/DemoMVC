﻿// -----------------------------------------------------------------------
// <copyright file="ProductionMixTest.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary> PProduction Mix Test class</summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;
using System.Linq;
using Ecolab.Models.Reports.ProductionEfficiency;
using Ecolab.Services.Reports.FormulaEngine;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Ecolab.Conduit.ReportsTest
{
    /// <summary>
    /// Summary description for ProductionMixTest
    /// </summary>
    [TestClass]
    public class ProductionMixTest
    {
        ProductionMixFormula productionmixFormula;
        ProductionMix productionmix;

        /// <summary>
        /// Initialize the tests with default values
        /// </summary>
        [TestInitialize]
        public void InitializeProductiomMix()
        {
            List<ProductionMix> productionmixList = new List<ProductionMix>();
            productionmixList.Add(new ProductionMix
            {
                RewashLoad = 100,
                ActualProduction = 100,
                TargetProduction = 100,
                StandardLoad = 100,
                ActualRunTime = 100,
                TargetRunTime = 100
            });
            productionmixFormula = new ProductionMixFormula(productionmixList);
            productionmixList = productionmixFormula.ComputeProductionMixDetail(1);
            productionmix = productionmixList.FirstOrDefault();
        }


        /// <summary>
        /// Test to verify formula for LoadEfficiency
        /// </summary>
        [TestMethod]
        public void GetLoadEfficiency()
        {
            Assert.IsTrue(productionmix.LoadEfficiency == 100);
        }

        /// <summary>
        /// Test to verify formula for ProductionDifference
        /// </summary>        
        [TestMethod]
        public void GetProductionDifference()
        {
            Assert.IsTrue(productionmix.ProductionDiff == 0);
        }

        /// <summary>
        /// Test to verify formula for ProductionMixValue
        /// </summary>
        [TestMethod]
        public void GetProductionMixValue()
        {
            Assert.IsTrue(productionmix.ProductionMixValue == 100);
        }

        /// <summary>
        /// Test to verify formula for Rewash
        /// </summary>
        [TestMethod]
        public void GetRewash()
        {
            Assert.IsTrue(productionmix.Rewash == 100);
        }
    }
}
