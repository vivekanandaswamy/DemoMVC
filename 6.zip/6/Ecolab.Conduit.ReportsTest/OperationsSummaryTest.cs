﻿// -----------------------------------------------------------------------
// <copyright file="OperationsSummaryTest.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary> Operations Summary Test class</summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;
using System.Linq;
using Ecolab.Models.Reports.ResourcesUtilization;
using Ecolab.Services.Reports.FormulaEngine;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Ecolab.Conduit.ReportsTest
{
    /// <summary>
    /// Summary description for OperationsSummaryTest
    /// </summary>
    [TestClass]
    public class OperationsSummaryTest
    {
        public OperationsSummaryTest()
        {           
        }

        OperationsSummaryFormula operationsSummaryFormula;
        OperationsSummary operationSummary;

        /// <summary>
        /// Initialize the tests with default values
        /// </summary>
        [TestInitialize]
        public void InitializeOperationsSummary()
        {
            List<OperationsSummary> opertationSummaryList = new List<OperationsSummary>();
            opertationSummaryList.Add(new OperationsSummary
            {
                ActualProduction = 100,
                ActualWaterCost = 100,
                ActualEnergyCost = 100,
                AactualChemicalCost = 100,
                ActualWaterUsage = 100,
                ActualEnergy = 100,
                ActualProductionMetrics = 100,
                ActualChemicalusage = 100,
                TargetWaterConsumption = 100,
                TargetEnergyConsumption = 100,
                TargetChemicalConsumption = 100
            });

            operationsSummaryFormula = new OperationsSummaryFormula();
            operationsSummaryFormula.ComputeOpertationsSummary(opertationSummaryList, 1);
            operationSummary = opertationSummaryList.FirstOrDefault();

        }

        /// <summary>
        /// Test to verify formula for ProductionMixValue
        /// </summary>
        [TestMethod]
        public void GetProductionMixValue()
        {
            Assert.IsTrue(operationSummary.ProductionMixValue == 100);
        }

        /// <summary>
        /// Test to verify formula for ActualWaterCostperload
        /// </summary>
        [TestMethod]
        public void GetActualWaterCostperload()
        {
            Assert.IsTrue(operationSummary.ActualWaterCostperload == 1);
        }

        /// <summary>
        /// Test to verify formula for ActualEnergyCostperload
        /// </summary>
        [TestMethod]
        public void GetActualEnergyCostperload()
        {
            Assert.IsTrue(operationSummary.ActualEnergyCostperload == 1);
        }

        /// <summary>
        /// Test to verify formula for ActualChemicalCostperLoad 
        /// </summary>
        [TestMethod]
        public void GetActualChemicalCostperLoad()
        {
            Assert.IsTrue(operationSummary.ActualChemicalCostperLoad == 1);
        }

        /// <summary>
        /// Test to verify formula for ActualWaterUsagePerLoad
        /// </summary>
        [TestMethod]
        public void GetActualWaterUsagePerLoad()
        {
            Assert.IsTrue(operationSummary.ActualWaterUsagePerLoad == 1);
        }

        /// <summary>
        /// Test to verify formula for ActualEnergyperload
        /// </summary>
        [TestMethod]
        public void GetActualEnergyperload()
        {
            Assert.IsTrue(operationSummary.ActualEnergyperload == 1);
        }

        /// <summary>
        /// Test to verify formula for ActualChemicalLoadPerLoad
        /// </summary>
        [TestMethod]
        public void GetActualChemicalLoadPerLoad()
        {
            Assert.IsTrue(operationSummary.ActualChemicalLoadPerLoad == 1);
        }

        /// <summary>
        /// Test to verify formula for TargetWaterUsagePerLoad
        /// </summary>
        [TestMethod]
        public void GetTargetWaterUsagePerLoad()
        {
            Assert.IsTrue(operationSummary.TargetWaterUsagePerLoad == 1);
        }

        /// <summary>
        /// Test to verify formula for EnergyTargetperload
        /// </summary>
        [TestMethod]
        public void GetEnergyTargetperload()
        {
            Assert.IsTrue(operationSummary.EnergyTargetperload == 1);
        }

        /// <summary>
        /// Test to verify formula for TargetChemicalLoadPerLoad
        /// </summary>
        [TestMethod]
        public void GetTargetChemicalLoadPerLoad()
        {
            Assert.IsTrue(operationSummary.TargetChemicalLoadPerLoad == 1);
        }

    }
}
