﻿// -----------------------------------------------------------------------
// <copyright file="SyncEmailService.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>Sync Email Service </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncEmailService
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.ServiceProcess;
    using Ecolab.Services;
    using log4net;
    using Services.Interfaces;

    /// <summary>
    /// The Synch Email Service
    /// </summary>
    partial class SyncEmailService : ServiceBase
    {
        /// <summary>
        ///     Logger Instance
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger("SyncEmailService");
        /// <summary>
        ///     Sync Lapse Time
        /// </summary>
        private static int syncLapseTime = Convert.ToInt32(ConfigurationManager.AppSettings["SyncLapseTimeInMinutes"].ToString());
        /// <summary>
        ///     Timer Auto Reset
        /// </summary>
        private static bool timerAutoReset = Convert.ToBoolean(ConfigurationManager.AppSettings["SyncTimerAutoreset"].ToString());
        /// <summary>
        ///     Sync Timer Interval
        /// </summary>
        private static int syncTimerInterval = Convert.ToInt32(ConfigurationManager.AppSettings["SyncTimerIntervalInHour"].ToString());
        /// <summary>
        ///     Sync Timer
        /// </summary>
        private System.Timers.Timer synchTimer;
        /// <summary>
        ///     Initializes a new instance of the <see cref="SyncEmailService"/> class.
        /// </summary>
        public SyncEmailService()
        {
            InitializeComponent();
        }

        /// <summary>
        /// On Start Synch Email Service
        /// </summary>
        /// <param name="args">Command Line arguments</param>
        protected override void OnStart(string[] args)
        {
            
            Log.Info(" Synch Email Service has started. ");
            if (!Debugger.IsAttached)
            {
                synchTimer = new System.Timers.Timer();
                synchTimer.AutoReset = timerAutoReset;

                synchTimer.Start();
                synchTimer.Elapsed += RestartProcess;

            }
            else
            {
                ProcessEmail();
            }
            Log.Info(" Synch Email Service has successfully completed. ");
        }

        /// <summary>
        /// Restarts the process.
        /// </summary>
        /// <param name="sender">The sender for Sync Email Services.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void RestartProcess(object sender, EventArgs e)
        {
            try
            {
                Log.Info("Sync Email Timer stopped.");
                synchTimer.Stop();
                ProcessEmail();
                Log.Info("Sync Process Email successfully started .");
            }
            catch (Exception ex)
            {
                Log.Error("Sync Emails Failure :" + ex);
            }
            finally
            {
                Log.Info("Synch Email Timer has started");
                synchTimer.Enabled = timerAutoReset;
                synchTimer.Interval = syncTimerInterval * 60000 * 60;
                synchTimer.Start();
            }
            
        }

        /// <summary>
        /// On Stop SyncEmailService 
        /// </summary>
        protected override void OnStop()
        {
            Log.Info("Synch Email Stopped.");
            if (!Debugger.IsAttached)
            {
                synchTimer.Stop();
            }
        }

        /// <summary>
        /// This method will verify time of the sync in plant table and syncAlarmLogService table in central db 
        /// </summary>
        private static void ProcessEmail()
        {           
                Log.Info("Email Process has started ");
                int isPlantNotSynch = 1;
                List<Entities.PlantSynch> plants = GetPlants();
                Log.Info("Number of Plants:" + plants.Count);
                foreach (var plant in plants)
                {
                    int checkplantSynch = CheckPlantSynch(plant.PlantId);
                    Log.Info("CheckplantSynch IsPlantInSynch-0 IsPlantNotInSynch-1: result-  " + checkplantSynch);
                    if (checkplantSynch == isPlantNotSynch)
                    {
                        SendEmail(plant.PlantId, plant.Name, plant.EcoalabAccountNumber);
                    }
                }            
        }

        /// <summary>
		/// Get Plants related information
		/// </summary>
		/// <returns>List of plantIds</returns>
		private static List<Entities.PlantSynch> GetPlants()
        {
            Log.Info("Get All Plants information");
            
                IPlantService plantService = new PlantService();
                return plantService.GetPlants();
        }
        /// <summary>
        /// This method will Validate Plant wether synch got completed or not with in given time. Will return yes if synch happens with in time else no
        /// </summary>
        /// <param name="plantId">Plant Id</param>
        /// <returns>Returns Integer</returns>
        private static int CheckPlantSynch(int plantId)
        {
            
                Log.Info("CheckPlant Synch for PlantId " + plantId);
                IPlantService plantService = new PlantService();
                return plantService.CheckPlantSynch(plantId, syncLapseTime);
        }

        /// <summary>
        ///     Only used to start the service when debugging
        /// </summary>
        internal void Start()
        {
            OnStart(null);
        }

        /// <summary>
        /// This method will intitate sendEmail
        /// </summary>
        /// <param name="plantId">Plant ID</param>
        /// <param name="plantName">Plant Name</param>
        /// <param name="ecolabaccountno">Ecolab Account Number</param>
        public static void SendEmail(int plantId, string plantName, string ecolabaccountno)
        {
            Log.Info("Email has been intialized for plant " + plantName);

            IPlantService plantService = new PlantService();
            List<string> territoryManagerEmails = new List<string>();
            territoryManagerEmails = plantService.GetTMUsers(plantId);
            if (territoryManagerEmails.Count == 0)
            {
                Log.Info("Not found any Territroy Managers for the Plant: " + plantName);
            }

            foreach (var territoryManagerEmail in territoryManagerEmails)
            {
                string body = EmailHelper.CreateEmailBody(territoryManagerEmail, plantName, ecolabaccountno);
                EmailHelper.SendMail(body, territoryManagerEmail);
            }

            Log.Info("Email has been successfully sent to TM for plant " + plantName);
        }
    }
}
