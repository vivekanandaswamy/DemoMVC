﻿// -----------------------------------------------------------------------
// <copyright file="TestSyncEmailService.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>The TestSyncEmailService </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecolab.Conduit.SyncEmailService
{
    /// <summary>
    ///     TestSyncEmailService class
    /// </summary>
    public partial class TestSyncEmailService : Form
    {
        /// <summary>
        ///     Sync Email Service
        /// </summary>
        private readonly SyncEmailService objSyncEmailService = new SyncEmailService();
        /// <summary>
        ///     Initializes a new instance of the <see cref="TestSyncEmailService"/> class.
        /// </summary>
        public TestSyncEmailService()
        {
            InitializeComponent();
        }
        /// <summary>
        ///     To Test Sync Email Service
        /// </summary>
        /// <param name="sender">The sender for Sync Email Services.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void btnSyncEmailService_Click(object sender, EventArgs e)
        {
            objSyncEmailService.Start();
        }
    }
}
