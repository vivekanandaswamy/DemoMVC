﻿// -----------------------------------------------------------------------
// <copyright file="ProjectInstaller.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>ProjectInstaller Class </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;

namespace Ecolab.Conduit.SyncEmailService
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }
    }
}
