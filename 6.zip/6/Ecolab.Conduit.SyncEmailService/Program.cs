﻿// -----------------------------------------------------------------------
// <copyright file="Program.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>Program Class </summary>
// -----------------------------------------------------------------------
namespace Ecolab.Conduit.SyncEmailService
{
    using System.Configuration;
    using System.Diagnostics;
    using System.ServiceProcess;
    using System.Windows.Forms;
    using AutoMapper;
    using Data.Access;
    using log4net.Config;
    using Services.Infra;
    /// <summary>
    ///     Main Program class
    /// </summary>
    static class Program
    {
        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        private static void Main()
        {
           // Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);
            if (Debugger.IsAttached)
            {
                using (TestSyncEmailService form = new TestSyncEmailService())
                {
                    XmlConfigurator.Configure();
                    Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                    Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
                    Application.Run(form);
                }
            }
            else
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new SyncEmailService() };
                XmlConfigurator.Configure();
                Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                Mapper.Initialize(cfg => cfg.AddProfile(new ServiceMappingProfile()));
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}
