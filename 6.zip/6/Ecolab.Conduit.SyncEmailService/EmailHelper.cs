﻿// -----------------------------------------------------------------------
// <copyright file="EmailHelper.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Email Helper Class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Conduit.SyncEmailService
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.IO;
    using System.Net.Mail;
    using System.Reflection;
    using System.Text;
    using System.Windows.Forms;
    using log4net;
    using Ecolab.Services;
    using Services.Interfaces;

    /// <summary>
    /// Email Helper class used for sending emails
    /// </summary>
    public class EmailHelper
    {
        private static readonly ILog Log = LogManager.GetLogger("SyncEmailService");
        private static int syncLapseTime = Convert.ToInt32(ConfigurationManager.AppSettings["SyncLapseTimeInMinutes"].ToString());
        private static string emailSubject = ConfigurationManager.AppSettings["EmailSubject"].ToString();
        private static string templatePath = ConfigurationManager.AppSettings["TemplatePath"].ToString();
        private static string emailFrom = ConfigurationManager.AppSettings["EmailFrom"].ToString();
       
        /// <summary>
        /// Method for sending Email to TMManagers of the  respective plant.
        /// </summary>
        /// <param name="body">Body of the Mail</param>
        /// <param name="recipientEmail">Recipient Email</param>
        public static void SendMail(string body, string recipientEmail)
        {
            Log.Info("Begin- Sync SendMail.");
           
                if (!string.IsNullOrEmpty(recipientEmail))
                {
                    using (SmtpClient client = new SmtpClient())
                    {
                        MailMessage message = new MailMessage();
                        message.Body = body;
                        message.IsBodyHtml = true;
                        message.From = new MailAddress(emailFrom);
                        message.To.Add(new MailAddress(recipientEmail));
                        message.Subject = emailSubject;
                        client.Send(message);
                    }
                 }
                else
                {
                    Log.Info("Receipient Email should not be empty");
                }
        }

        /// <summary>
        /// This method will generate Email Body
        /// </summary>
        /// <param name="territoryManagerEmail">Teritory Manager Email</param>
        /// <param name="plantName">Plant Name</param>
        /// <param name="ecolabaccountno">Ecolab Account Number</param>
        /// <returns>Body of the mail</returns>
        public static string CreateEmailBody(string territoryManagerEmail, string plantName, string ecolabaccountno)
        {
            Log.Info("Started Creating Email Body");
            string body = string.Empty;
            StreamReader reader = null;
            string emailTemplatePath = Application.StartupPath + templatePath;
            if (File.Exists(emailTemplatePath))
            {
                using (reader = new StreamReader(emailTemplatePath, Encoding.GetEncoding("iso-8859-1")))
                {
                    body = reader.ReadToEnd();
                }
                body = body.Replace("##TMName##", territoryManagerEmail);
                body = body.Replace("##PlantName##", plantName);
                body = body.Replace("##LapseTime##", Convert.ToString(syncLapseTime));
                body = body.Replace("##EcolabAccountNo##", Convert.ToString(ecolabaccountno));

                return body;
            }
            else
            {
                Log.Info("EmailTemplate is not found in the following path:  "+ emailTemplatePath);
            }
            return body;
        }
    }
}
