﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Chain Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    public class PlantChainAccess
    {
        /// <summary>
        /// Save myservice plant chain details
        /// </summary>
        /// <param name="plantChain">PlantChain Object</param>
        /// <returns>Plant Chain Id</returns>
        public static int SaveMyServicePlantChainDetails(PlantChain plantChain)
        {
            int returnValue = 0;

            var paramChainId = new SqlParameter
            {
                ParameterName = "@OutputChainId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              Resources.Ecolab_UpdateMyServicePlantChainDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("PlantChainId", plantChain.PlantChainId);
                  cmd.AddParameter("PlantChainName", DbType.String, 1000, plantChain.PlantChainName);
                  cmd.AddParameter("RegionCode", DbType.String, 1000, string.IsNullOrEmpty(plantChain.RegionCode) ? "NA" : plantChain.RegionCode);
                  cmd.AddParameter("Is_Deleted", plantChain.Is_Deleted);
                  cmd.AddParameter("MyServiceChnId", plantChain.MyServiceChnId);
                  cmd.Parameters.Add(paramChainId);
              });

            returnValue = Convert.IsDBNull(paramChainId.Value) ? 0 : (int)paramChainId.Value;
            return returnValue;
        }

        /// <summary>
        /// Get plant chain details
        /// </summary>
        /// <returns>List of Plant Chain</returns>
        public static List<PlantChain> GetPlantChainDetails()
        {
            return DbClient.ExecuteReader<PlantChain>(Resources.Ecolab_GetPlantChainDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}