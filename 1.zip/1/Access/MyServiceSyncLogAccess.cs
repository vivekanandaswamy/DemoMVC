﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceSyncLogAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyServiceSyncLog Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Access.Properties;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Class for MyServiceSyncLog
    /// </summary>
    public class MyServiceSyncLogAccess
    {
        /// <summary>
        /// Get MyServiceSyncLog Object
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="entityName">Entity Name which we sync last time</param>
        /// <returns>Object of MyServiceSyncLog</returns>
        public static MyServiceSyncLog GetMyServiceSyncLogDetails(string ecolabAccountNumber, string entityName)
        {
            return DbClient.ExecuteReader<MyServiceSyncLog>("[TCD].[GetMyServiceSyncLogDetails]",
                   delegate(DbCommand cmd, DbContext context)
                   {
                       cmd.CommandType = CommandType.StoredProcedure;
                       cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                       cmd.AddParameter("Entity", DbType.String, 1000, entityName);
                   }).FirstOrDefault();
        }

        /// <summary>
        /// Insert and Update sync log details
        /// </summary>
        /// <param name="ecolabAccountNumber">Plant Number</param>
        /// <param name="entity">Entity Name for which need to insert and update record</param>
        /// <param name="status">Status whether it is succesfully sync or not</param>
        public static void UpdateMyServiceSyncLog(string ecolabAccountNumber, string entity, string status)
        {
            DbClient.ExecuteNonQuery("[TCD].[UpdateMyServiceSyncLog]",
                   delegate(DbCommand cmd, DbContext context)
                   {
                       cmd.CommandType = CommandType.StoredProcedure;
                       cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                       cmd.AddParameter("Entity", DbType.String, 1000, entity);
                       cmd.AddParameter("Status", DbType.String, 100, status);
                   });
        }

        /// <summary>
        /// Get GetRegionId
        /// </summary>
        /// <param name="regionCode">regionCode</param>
        public static int GetRegionId(string regionCode)
        {
            Int16 result = 0;
            result = DbClient.ExecuteScalar<Int16>("[TCD].[GetRegionId]",
                  delegate(DbCommand cmd, DbContext context)
                  {
                      cmd.CommandType = CommandType.StoredProcedure;
                      cmd.AddParameter("RegionCode", DbType.String, 1000, regionCode);
                  });
            return result;
        }
    }
}
