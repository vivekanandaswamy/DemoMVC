﻿// -----------------------------------------------------------------------
// <copyright file="DimensionalUnitSystemsAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class for DimensionalUnitSystemsAccess
    /// </summary>
    public class DimensionalUnitSystemsAccess
    {
        /// <summary>
        ///     Get Dimensional UnitSystems
        /// </summary>
        /// <returns>different currencies</returns>
        public static List<DimensionalUnitSystems> GetDimensionalUnitSystems()
        {
            return DbClient.ExecuteReader<DimensionalUnitSystems>(Resources.Ecolab_GetDimensionalUnitSystems, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}