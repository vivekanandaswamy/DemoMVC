﻿// -----------------------------------------------------------------------
// <copyright file="ChainFormulaAccess.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>The Chain Formula Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    /// ChainFormulaAccess
    /// </summary>
    public class ChainFormulaAccess
    {
        /// <summary>
        ///     Get Chain Formula details
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<ChainTextileCategory> GetChainTextileCategory(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ChainTextileCategory>(Resources.Ecolab_GetChainTextileCategory,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.CommandType = CommandType.StoredProcedure;
                }).ToList();
        }

        /// <summary>
        ///     Get Chain Textile Category details based on Plant chain id
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<ChainFormula> GetChainFormulaByPlantChainId(int plantChainId, DateTime myServiceTime)
        {
            return DbClient.ExecuteReader<ChainFormula>(Resources.Ecolab_GetChainFormulaByPlantChainId, delegate(DbCommand cmd, DbContext context)
                {
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("PlantChainId", plantChainId);
                    cmd.AddParameter("TimeStamp", DbType.DateTime, myServiceTime);
                }).ToList();
        }

        /// <summary>
        /// Insert or update ChainFormula Details 
        /// </summary>
        /// <param name="chainFormulaDetails">Object</param>
        /// <returns>New Generated id</returns>
        public static int SaveChainFormulaDetails(ChainFormula chainFormulaDetails)
        {
            int returnValue = 0;
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveChainFormulaDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("PlantProgramId", chainFormulaDetails.PlantProgramId);
                  cmd.AddParameter("PlantProgramName", DbType.String, 1000, chainFormulaDetails.PlantProgramName);
                  cmd.AddParameter("ChainTextileCategoryId", chainFormulaDetails.ChainTextileCategoryId);
                  cmd.AddParameter("FormulaSegmentId", chainFormulaDetails.FormulaSegmentId);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, chainFormulaDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : chainFormulaDetails.LastModifiedTime);
                  cmd.AddParameter("LastModifiedByUserId", chainFormulaDetails.LastModifiedByUserId);
                  cmd.AddParameter("Is_Deleted", chainFormulaDetails.IsDeleted);
                  cmd.AddParameter("PlantChainId", chainFormulaDetails.PlantChainId);
                  cmd.AddParameter("EcolabSaturationId", chainFormulaDetails.EcolabSaturationId);
                  cmd.AddParameter("ResourceKey", DbType.String, 1000, chainFormulaDetails.ResourceKey);
                  cmd.AddParameter("LastSyncTime", DbType.DateTime, chainFormulaDetails.LastSyncTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : chainFormulaDetails.LastSyncTime);
              });
            return returnValue;
        }

        /// <summary>
        /// Saves the chain textile category details for first time synchronize.
        /// </summary>
        /// <param name="chainTextileCategoryDetails">The chain textile category details.</param>
        public static void SaveChainTextileCategoryDetailsForFirstTimeSync(ChainTextileCategory chainTextileCategoryDetails)
        {
            
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveChainTextileCategoryForFirstTimeSync,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("ChainTextileId", chainTextileCategoryDetails.TextileId);
                  cmd.AddParameter("ChainTextileName", DbType.String, 1000, chainTextileCategoryDetails.Name);
                  cmd.AddParameter("PlantChainId", chainTextileCategoryDetails.ChainId);
                  cmd.AddParameter("IsDeleted", chainTextileCategoryDetails.IsDeleted);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, chainTextileCategoryDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : chainTextileCategoryDetails.LastModifiedTime);
                  cmd.AddParameter("ResourceKey", DbType.String, 1000, chainTextileCategoryDetails.ResourceKey);
              });
            
        }
    }
}