﻿// -----------------------------------------------------------------------
// <copyright file="AlarmReportAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The AlarmReport Access class</summary>
// -----------------------------------------------------------------------

namespace Access.Reports.WashingProcessValidation
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Entities.Reports.WashingProcessValidation;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for AlarmReportAccess
    /// </summary>
    public class AlarmReportAccess
    {
        /// <summary>
        ///     Get the alarm reports details
        /// </summary>
        /// <param name="reportSettings">reportSettings object</param>
        /// <returns>return the list of alarm report details.</returns>
        public static IEnumerable<AlarmDetails> FetchAlarmDetails(ReportSettings reportSettings)
        {
            return DbClient.ExecuteReader<AlarmDetails>(Resources.Ecolab_AlarmReportDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, reportSettings.EcolabAccountNumber ?? string.Empty);
                cmd.AddParameter("Controller", DbType.String, 100, reportSettings.Controller ?? string.Empty);
                cmd.AddParameter("Machine", DbType.String, 100, reportSettings.Machine ?? string.Empty);
                cmd.AddParameter("machineGroup", DbType.String, 100, reportSettings.MachineGroup ?? string.Empty);
                cmd.AddParameter("Formula", DbType.String, 100, reportSettings.PlantFormula ?? string.Empty);
                cmd.AddParameter("MachineType", DbType.String, 100, reportSettings.MachineType ?? string.Empty);
                cmd.AddParameter("Alarm", DbType.String, 100, reportSettings.Alarm ?? string.Empty);
                cmd.AddParameter("FromDate", DbType.DateTime, reportSettings.FromDateUTC);
                cmd.AddParameter("ToDate", DbType.DateTime, reportSettings.ToDateUTC.AddSeconds(-1));
                cmd.AddParameter("GroupId", DbType.String, 100, reportSettings.GroupId ?? string.Empty);
                cmd.AddParameter("MachineInternalId", DbType.String, 100, reportSettings.MachineInternalId ?? string.Empty);
                cmd.AddParameter("SortColumnID", reportSettings.SortColumnId == 0 ? 0 : reportSettings.SortColumnId);
                cmd.AddParameter("SortDirection", DbType.String, 100, reportSettings.SortDirection ?? string.Empty);
                cmd.AddParameter("UserId", reportSettings.UserId);
                cmd.AddParameter("PageNo", reportSettings.CurrentPageIndex == 0 ? 0 : reportSettings.CurrentPageIndex);
                cmd.AddParameter("RecordsPerPage", reportSettings.PageSize);
            });
        }
    }
}