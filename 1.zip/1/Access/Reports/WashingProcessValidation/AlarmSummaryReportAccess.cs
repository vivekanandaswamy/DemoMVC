﻿// -----------------------------------------------------------------------
// <copyright file="AlarmSummaryReportAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved. 
// </copyright>
// <summary>The AlarmSummaryReportAccess </summary>
// -----------------------------------------------------------------------

namespace Access.Reports.WashingProcessValidation
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Entities.Reports.WashingProcessValidation;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for AlarmSummaryReportAccess
    /// </summary>
    public class AlarmSummaryReportAccess
    {
        /// <summary>
        ///     Get the alarm summary reports details
        /// </summary>
        /// <param name="reportSettings">reportSettings object</param>
        /// <returns>return the list of alarm summary report details.</returns>
        public static IEnumerable<AlarmSummary> FetchAlarmSummaryReport(ReportSettings reportSettings)
        {
            return DbClient.ExecuteReader<AlarmSummary>(Resources.Ecolab_GetAlarmSummaryReport, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("Corporate", DbType.String, 100, reportSettings.Corporate == null ? string.Empty : reportSettings.Corporate);
                cmd.AddParameter("Country", DbType.String, 100, reportSettings.Country == null ? string.Empty : reportSettings.Country);
                cmd.AddParameter("Region", DbType.String, 100, reportSettings.Region == null ? string.Empty : reportSettings.Region);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, reportSettings.EcolabAccountNumber == null ? string.Empty : reportSettings.EcolabAccountNumber);
                cmd.AddParameter("Controller", DbType.String, 100, reportSettings.Controller == null ? string.Empty : reportSettings.Controller);
                cmd.AddParameter("Machine", DbType.String, 100, reportSettings.Machine == null ? string.Empty : reportSettings.Machine);
                cmd.AddParameter("machineGroup", DbType.String, 100, reportSettings.MachineGroup == null ? string.Empty : reportSettings.MachineGroup);
                cmd.AddParameter("Formula", DbType.String, 100, reportSettings.PlantFormula == null ? string.Empty : reportSettings.PlantFormula);
                cmd.AddParameter("MachineType", DbType.String, 100, reportSettings.MachineType == null ? string.Empty : reportSettings.MachineType);
                cmd.AddParameter("Alarm", DbType.String, -1, reportSettings.Alarm == null ? string.Empty : reportSettings.Alarm);
                cmd.AddParameter("FromDate", DbType.DateTime, reportSettings.FromDateUTC);
                cmd.AddParameter("ToDate", DbType.DateTime, reportSettings.ToDateUTC.AddSeconds(-1));
                cmd.AddParameter("GroupId", DbType.String, 100, reportSettings.GroupId == null ? string.Empty : reportSettings.GroupId);
                cmd.AddParameter("MachineInternalId", DbType.String, 100, reportSettings.MachineInternalId == null ? string.Empty : reportSettings.MachineInternalId);
                cmd.AddParameter("SortColumnID", reportSettings.SortColumnId == 0 ? 0 : reportSettings.SortColumnId);
                cmd.AddParameter("SortDirection", DbType.String, 100, reportSettings.SortDirection == null ? string.Empty : reportSettings.SortDirection);
                cmd.AddParameter("UserId", reportSettings.UserId);
                cmd.AddParameter("PageNo", reportSettings.CurrentPageIndex == 0 ? 0 : reportSettings.CurrentPageIndex);
                cmd.AddParameter("RecordsPerPage", reportSettings.PageSize);
            });
        }
    }
}