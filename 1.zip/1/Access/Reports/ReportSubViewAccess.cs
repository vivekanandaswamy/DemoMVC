﻿// -----------------------------------------------------------------------
// <copyright file="ReportSubViewAccess.cs" company="Nalco">
// TODO: Update copyright text.
// </copyright>
// <summary>The ReportLocalizationAccess object</summary>
// -----------------------------------------------------------------------

namespace Access.Reports
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Access.Properties;
    using Entities.Reports;
    using Nalco.Data.Common;

    public class ReportSubViewAccess
    {
        /// <summary>
        /// Get the Subviews for a View
        /// </summary>
        /// <param name="viewModeId">viewModeId</param>
        /// <returns>return the list of subviews for a View.</returns>
        public static IEnumerable<ReportSubView> FetchSubViewsForView(int viewModeId, int languageId)
        {
            return DbClient.ExecuteReader<ReportSubView>(Resources.Ecolab_GetReportSubViewsForView,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("ViewModeId", viewModeId);
                    cmd.AddParameter("LanguageId", languageId);
                    
                });
        }
    }
}
