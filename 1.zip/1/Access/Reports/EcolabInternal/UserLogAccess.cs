﻿// -----------------------------------------------------------------------
// <copyright file="UserLogAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Log Access class</summary>
// -----------------------------------------------------------------------

namespace Access.Reports.EcolabInternal
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Entities.Reports.EcolabInternal;
    using Nalco.Data.Common;
    using Properties;

    public class UserLogAccess
    {
        /// <summary>
        ///     Gets the User Log data.
        /// </summary>
        /// <param name="reportSettings">The report settings.</param>
        /// <returns> list of user details </returns>
        public static IEnumerable<UserLog> GetUserLogData(ReportSettings reportSettings)
        {
            return DbClient.ExecuteReader<UserLog>(Resources.Ecolab_GetUserLogReportData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandTimeout = 100;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, reportSettings.EcolabAccountNumber ?? string.Empty);
                cmd.AddParameter("FromDate", DbType.DateTime, reportSettings.FromDateUTC);
                cmd.AddParameter("ToDate", DbType.DateTime, reportSettings.ToDateUTC);
                cmd.AddParameter("UserIdListCSV", DbType.String, 50, reportSettings.Users);
                cmd.AddParameter("SortColumnID", reportSettings.SortColumnId == 0 ? 0 : reportSettings.SortColumnId);
                cmd.AddParameter("SortDirection", DbType.String, 100, reportSettings.SortDirection ?? string.Empty);
                cmd.AddParameter("UserId", reportSettings.UserId);
                cmd.AddParameter("ActionTypeListCSV", DbType.String, 50, reportSettings.ActionType ?? string.Empty);
                cmd.AddParameter("PageNo", reportSettings.CurrentPageIndex);
                cmd.AddParameter("RecordsPerPage", reportSettings.PageSize);
            });
        }
    }
}