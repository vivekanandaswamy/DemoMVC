﻿// -----------------------------------------------------------------------
// <copyright file="ReportCategoryAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report category Access class</summary>
// -----------------------------------------------------------------------

using System;

namespace Access.Reports
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for ReportCategoryAccess
    /// </summary>
    public class ReportCategoryAccess
    {
        /// <summary>
        /// Get the reports details
        /// </summary>
        /// <param name="role">The role.</param>
        /// <returns>
        /// return the list of reports with category and sub-category.
        /// </returns>
        public static IEnumerable<Report> FetchReports(int role,int languageId)
        {
            return DbClient.ExecuteReader<Report>(Resources.Ecolab_GetReports, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("RoleId", DbType.String, 100,Convert.ToString(role));
                cmd.AddParameter("LanguageId", languageId);
            });
        }
    }
}