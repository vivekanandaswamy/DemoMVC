﻿// -----------------------------------------------------------------------
// <copyright file="RibbonOptionAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Ribbon Option Access class</summary>
// -----------------------------------------------------------------------

using System.Linq;

namespace Access.Reports
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for RibbonOptionAccess
    /// </summary>
    public class RibbonOptionAccess
    {
        /// <summary>
        ///     Get the ribbon option details
        /// </summary>
        /// <param name="reportId">selected report reportId</param>
        /// <returns>list of ribbon options for selected report</returns>
        public static IEnumerable<RibbonOption> FetchRibbonOption(int reportId)
        {
            return DbClient.ExecuteReader<RibbonOption>(Resources.Ecolab_GetReportRibbonOprtion, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ReportId", reportId);
            });
        }

        /// <summary>
        ///     Get the switch category details
        /// </summary>
        /// <param name="reportId">selected report reportId</param>       
        /// <returns>list of switch categories for selected report</returns>
        public static IEnumerable<SwitchCategory> FetchSwitchCategories(int reportId)
        {
            return DbClient.ExecuteReader<SwitchCategory>(Resources.Ecolab_GetSwitchCategories, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ReportId", reportId);
            });
        }

        /// <summary>
        ///     Get the report filter details
        /// </summary>
        /// <param name="reportId">selected report reportId</param>        
        /// <returns>list of report filters for selected report</returns>
        public static IEnumerable<ReportFilter> FetchReportFilters(int reportId)
        {
            return DbClient.ExecuteReader<ReportFilter>(Resources.Ecolab_GetReportFiltersDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ReportId", reportId);
            });
        }

        /// <summary>
        ///     Get the report all column details
        /// </summary>
        /// <param name="reportSettings">Report Settings</param>
        /// <returns>list of report all column details for selected report</returns>
        public static IEnumerable<ReportAllColumns> FetchReportAllColumns(ReportSettings reportSettings)
        {
            return DbClient.ExecuteReader<ReportAllColumns>(Resources.Ecolab_GetReportAllColumns, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("ReportId", reportSettings.ReportId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, reportSettings.EcolabAccountNumber);
                cmd.AddParameter("ViewById", reportSettings.ViewModeId);
                cmd.AddParameter("SwitchModeId", reportSettings.SwitchModeId);
                cmd.AddParameter("UserId", reportSettings.UserId);
                cmd.AddParameter("RoleId", reportSettings.RoleId);
                cmd.AddParameter("SubViewID", reportSettings.SubViewId);
                cmd.AddParameter("LanguageId", reportSettings.UserLanguageId);
                //cmd.AddParameter("Usercurrencycode", DbType.String, reportSettings.UserCurrency.ToString().Length, reportSettings.UserCurrency);
            });
        }

        /// <summary>
        ///     Get the report chart display details
        /// </summary>
        /// <param name="reportId">selected report reportId</param>
        /// <param name="ecolabAccNum">plant Ecolab account Number</param>
        /// <returns>list of report chart display details for selected report</returns>
        public static IEnumerable<ReportAllColumns> FetchReportchartDisplay(int reportId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<ReportAllColumns>(Resources.Ecolab_GetChartDisplay, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ReportId", reportId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            });
        }

        /// <summary>
        ///     Get the report filters by filter id
        /// </summary>
        /// <param name="filterId">selected filter Id</param>
        /// <param name="ecolabAccNum">plant Ecolab account Number</param>
        /// <returns>list of report filters by selected filter id</returns>
        public static IEnumerable<ReportFilterList> FetchReportFiltersDataByFilterId(int filterId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<ReportFilterList>(Resources.Ecolab_GetReportFiltersByFilterId, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("FilterId", filterId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            });
        }

        /// <summary>
        /// Get the ribbon option data for report
        /// </summary>
        /// <param name="reportId">selected report id</param>
        /// <param name="viewById">The view by identifier.</param>
        /// <param name="roleId">The role identifier.</param>
        /// <returns>
        /// list of report ribbon options data for report by selected report id
        /// </returns>
        public static IEnumerable<ReportRibbonOptions> FetchRibbonOptionDataForReport(int reportId, int viewById, int roleId, int languageId)
        {
            return DbClient.ExecuteReader<ReportRibbonOptions>(Resources.Ecolab_GetRibbonOptionDataForReport, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ReportId", reportId);
                // cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("ViewById", viewById);
                cmd.AddParameter("RoleId", roleId);
                cmd.AddParameter("LanguageId", languageId);
            });
        }

        /// <summary>
        /// Gets the filters.
        /// </summary>
        /// <param name="reportId">The report identifier.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="roleId">The role identifier.</param>
        /// <param name="isLocal">if set to <c>true</c> [is local].</param>
        /// <returns></returns>
        public static IEnumerable<Filter> GetFilters(int reportId, int userId, int roleId, bool isLocal, int languageId)
        {
            var filters = DbClient.ExecuteReader<Filter>(
                Resources.Ecolab_GetReportFilters,
                 delegate (DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.StoredProcedure;
                     cmd.AddParameter("ReportId", reportId);
                     cmd.AddParameter("UserId", userId);
                     cmd.AddParameter("RoleId", roleId);
                     cmd.AddParameter("IsLocal", isLocal);
                     cmd.AddParameter("LanguageId", languageId);
                 });

            return GetFiltetData(filters, reportId, userId, roleId);
        }

        /// <summary>
        /// Gets the Report Filter Data
        /// </summary>
        /// <param name="filters">The report filters</param>
        /// <param name="reportId">The report Id</param>
        /// <param name="userId">The User Id</param>
        /// <param name="roleId">The Role Id</param>
        /// <returns></returns>
        private static IEnumerable<Filter> GetFiltetData(IEnumerable<Filter> filters, int reportId, int userId, int roleId)
        {
            var filtetData = filters as IList<Filter> ?? filters.ToList();
            foreach (var filter in filtetData)
            {
                if (filter.TypeId == 5)
                {
                    filter.Data = GetFilterDropDownDataById(reportId, string.Empty, string.Empty, 8, userId, roleId, true).ToList();
                }
                else if (filter.TypeId == 6)
                {
                    filter.Data = GetFilterDropDownDataById(reportId, string.Empty, string.Empty, 5, userId, roleId, true).ToList();
                }
                else if (filter.TypeId != 8)
                {
                    filter.Data = GetFilterDropDownDataById(reportId, string.Empty, string.Empty, filter.TypeId, userId, roleId, true).ToList();
                }
                else
                {
                    filter.Data = GetFilterDropDownDataById(reportId, string.Empty, string.Empty, null, userId, roleId, true).ToList();
                }
            }

            return filtetData;
        }

        public static IEnumerable<SelectList> GetFilterDropDownDataById(int reportId, string machinType, string machinGroup, int? typeId, int userId, int roleId, bool isLocal)
        {
            return DbClient.ExecuteReader<SelectList>(
               Resources.Ecolab_GetReportDataByFilterId,
               delegate (DbCommand cmd, DbContext context)
               {
                   cmd.CommandType = CommandType.StoredProcedure;
                   cmd.AddParameter("UserId", userId);
                   cmd.AddParameter("RoleId", roleId);
                   cmd.AddParameter("IsLocal", isLocal);
                   if (machinType.Length > 0) { cmd.AddParameter("MachineTye", DbType.String, 1000, machinType); }
                   if (machinGroup.Length > 0) { cmd.AddParameter("Machinegroup", DbType.String, 1000, machinGroup); }
                   cmd.AddParameter("ReportId", reportId);
                   cmd.AddParameter("FilterId", typeId);
               });
        }

        public static IEnumerable<SelectList> GetOptionalFilterData(int typeId)
        {
            return DbClient.ExecuteReader<SelectList>(
               Resources.Ecolab_GetReportDynamicDataByFilterId,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("FilterId", typeId);
              });
        }
    }
}