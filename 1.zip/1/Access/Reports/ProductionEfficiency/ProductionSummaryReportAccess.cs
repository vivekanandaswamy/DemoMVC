﻿// -----------------------------------------------------------------------
// <copyright file="ProductionSummaryReportAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Production Summary Report Access </summary>
// -----------------------------------------------------------------------

using System;

namespace Access.Reports.ProductionEfficiency
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Entities.Reports.ProductionEfficiency;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for ProductionSummaryReportAccess
    /// </summary>
    public class ProductionSummaryReportAccess
    {
        /// <summary>
        ///     Get the production summary report details
        /// </summary>
        /// <param name="reportSettings">reportSettings object</param>
        /// <returns>return the list of production summary report details.</returns>
        public static IEnumerable<ProductionSummary> FetchProductionSummaryReportDetails(ReportSettings reportSettings)
        {
           
            return DbClient.ExecuteReader<ProductionSummary>(Resources.Ecolab_GetProductionSummaryReport, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Machine", DbType.String, 100, reportSettings.Machine ?? string.Empty);
                cmd.AddParameter("MachineGroup", DbType.String, 100, reportSettings.MachineGroup ?? string.Empty);
                cmd.AddParameter("MachineType", DbType.String, 20, reportSettings.MachineType ?? string.Empty);
                cmd.AddParameter("startdate", DbType.DateTime, reportSettings.FromDateUTC);
                cmd.AddParameter("enddate", DbType.DateTime, reportSettings.ToDateUTC.AddSeconds(-1));
                cmd.AddParameter("Viewtype", reportSettings.ViewModeId);
                cmd.AddParameter("Subview", reportSettings.SubViewId);
                cmd.AddParameter("Drillvalue", DbType.String, 100, Convert.ToString(reportSettings.DrilldownId) == "0" ? string.Empty : Convert.ToString(reportSettings.DrilldownId));
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, reportSettings.EcolabAccountNumber ?? string.Empty);
                cmd.AddParameter("SortColumnID", reportSettings.SortColumnId);
                cmd.AddParameter("SortDirection", DbType.String, 100, reportSettings.SortDirection ?? string.Empty);
                cmd.AddParameter("UserId", reportSettings.UserId);
                cmd.AddParameter("ChainFormula", DbType.String, 1000, reportSettings.ChainFormula ?? string.Empty);
                cmd.AddParameter("Customer", DbType.String, 1000, reportSettings.Customer ?? string.Empty);
                cmd.AddParameter("CurrencyCode", DbType.String, 1000, reportSettings.UserCurrency ?? string.Empty);

                cmd.AddParameter("@FormulaSegement", DbType.String, 1000, reportSettings.Category ?? string.Empty);
                cmd.AddParameter("@FormulaCategory", DbType.String, 1000, reportSettings.ChainCategory ?? string.Empty);
                cmd.AddParameter("@Formula", DbType.String, 1000, reportSettings.PlantFormula ?? string.Empty);
            });
        }
    }
}