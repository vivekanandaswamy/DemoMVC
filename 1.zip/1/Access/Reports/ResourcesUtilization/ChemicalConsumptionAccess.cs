﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalConsumptionAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemical Consumption Access class</summary>
// -----------------------------------------------------------------------

namespace Access.Reports.ResourcesUtilization
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Entities.Reports.ResourcesUtilization;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for
    /// </summary>
    public class ChemicalConsumptionAccess
    {
        /// <summary>
        ///     Gets the chemical consumption data.
        /// </summary>
        /// <param name="reportSettings">The report settings.</param>
        /// <returns>List of ChemicalConsumption</returns>
        public static IEnumerable<ChemicalConsumption> GetChemicalconsumptionData(ReportSettings reportSettings)
        {
            return DbClient.ExecuteReader<ChemicalConsumption>(Resources.Ecolab_ReportChemicalConsumption, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("startdate", DbType.DateTime, reportSettings.FromDateUTC);
                cmd.AddParameter("enddate", DbType.DateTime, reportSettings.ToDateUTC.AddSeconds(-1));
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, reportSettings.EcolabAccountNumber ?? string.Empty);
                cmd.AddParameter("MachineType", DbType.String, 100, reportSettings.MachineType ?? string.Empty);
                cmd.AddParameter("MachineGroup", DbType.String, 100, reportSettings.MachineGroup ?? string.Empty);
                cmd.AddParameter("Machine", DbType.String, 100, reportSettings.Machine ?? string.Empty);
                cmd.AddParameter("ChainFormula", DbType.String, 100, reportSettings.ChainFormula ?? string.Empty);
                cmd.AddParameter("Customer", DbType.String, 100, reportSettings.Customer ?? string.Empty);
                cmd.AddParameter("CurrencyCode", DbType.String, 100, reportSettings.UserCurrency ?? string.Empty);
                cmd.AddParameter("UserId", reportSettings.UserId);
                cmd.AddParameter("View", reportSettings.ViewModeId);
                cmd.AddParameter("@FormulaSegement", DbType.String, 1000, reportSettings.Category ?? string.Empty);
                cmd.AddParameter("@FormulaCategory", DbType.String, 1000, reportSettings.ChainCategory ?? string.Empty);
                cmd.AddParameter("@Formula", DbType.String, 1000, reportSettings.PlantFormula ?? string.Empty);
            });
        }
    }
}