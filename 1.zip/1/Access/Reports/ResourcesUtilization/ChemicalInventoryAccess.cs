﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalInventoryAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemical InventoryAccess Access class</summary>
// -----------------------------------------------------------------------

namespace Access.Reports.ResourcesUtilization
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.Reports;
    using Entities.Reports.ResourcesUtilization;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for ChemicalInventoryAccess
    /// </summary>
    public class ChemicalInventoryAccess
    {
        /// <summary>
        ///     Gets the chemical inventory data.
        /// </summary>
        /// <param name="reportSettings">The report settings.</param>
        /// <returns>list of chemical inventory data</returns>
        public static IEnumerable<ChemicalInventory> FetchChemicalInventoryReportData(ReportSettings reportSettings)
        {
            return DbClient.ExecuteReader<ChemicalInventory>(Resources.Ecolab_ReportChemicalInventory, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, reportSettings.EcolabAccountNumber ?? string.Empty);
                cmd.AddParameter("UserId", reportSettings.UserId);
                cmd.AddParameter("ReportId", reportSettings.ReportId);
            });
        }
    }
}