﻿// -----------------------------------------------------------------------
// <copyright file="ReportLocalizationAccess.cs" company="Nalco">
// TODO: Update copyright text.
// </copyright>
// <summary>The ReportLocalizationAccess object</summary>
// -----------------------------------------------------------------------

namespace Access.Reports
{

    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Access.Properties;
    using Entities.Reports;
    using Nalco.Data.Common;

    public class ReportLocalizationAccess
    {
        /// <summary>
        /// Get the report language details
        /// </summary>
        /// <param name="reportId">selected report reportId</param> 
        /// <param name="languageId">language id </param>
        /// <returns>list of report language details</returns>
        public static IEnumerable<ReportLocalization> FetchReportLocalizationDetails(int reportId, int languageId)
        {
            //TextitleCare_Reports_GetReportRibbonDetails
            return DbClient.ExecuteReader<ReportLocalization>(
               "[TCD].[GetReportLocalizationDetails]",
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("ReportId", reportId);
                    cmd.AddParameter("LanguageId", languageId);
                });
        }

        /// <summary>
        /// Get ReportLocalization Detail
        /// </summary>
        /// <param name="languageId">language id</param>
        /// <returns>list of key values pair localized values</returns>
        public static IEnumerable<ReportLocalizationKeyValue> FetchReportLocalizationDetails(int languageId)
        {
            return DbClient.ExecuteReader<ReportLocalizationKeyValue>(Resources.Ecolab_TextileCare_Reports_GetLocalizedReportLabels,
               delegate (DbCommand cmd, DbContext context)
               {
                   cmd.CommandType = CommandType.Text;
                   cmd.AddParameter("LanguageID", languageId);
               });
        }

    }
}
