﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainProgramAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Chain Program Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    public class PlantChainProgramAccess
    {
        /// <summary>
        ///     Get Plant Chain Program
        /// </summary>
        /// <returns>List of Programs</returns>
        public static List<PlantChainProgram> GetPlantChainProgram()
        {
            return DbClient.ExecuteReader<PlantChainProgram>(Resources.Ecolab_GetPlantChainPrograms, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }

        /// <summary>
        ///     Get Plant Chain Program details based on Plant chain id
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<PlantChainProgram> GetPlantChainProgramByPlantChainId(int plantChainId)
        {
            return DbClient.ExecuteReader<PlantChainProgram>(Resources.Ecolab_GetPlantChainProgramByPlantChainId, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("PlantChainId", plantChainId);
                    cmd.CommandType = CommandType.StoredProcedure;
                }).ToList();
        }

        /// <summary>
        /// Insert or update PlantChainProgram Details 
        /// </summary>
        /// <param name="plantChainProgramDetails">Object</param>
        /// <returns>New Generated id</returns>
        public static int SavePlantChainProgramDetails(PlantChainProgram plantChainProgramDetails, int userId)
        {
            int returnValue = 0;
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SavePlantChainProgramDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("PlantProgramId", plantChainProgramDetails.PlantProgramId);
                  cmd.AddParameter("PlantProgramName", DbType.String, 50, plantChainProgramDetails.PlantProgramName);
                  cmd.AddParameter("ChainTextileCategoryId", plantChainProgramDetails.ChainTextileId);
                  cmd.AddParameter("EcolabTextileCategoryId", plantChainProgramDetails.EcolabTextileId);
                  cmd.AddParameter("FormulaSegmentId", plantChainProgramDetails.FormulaSegmentId);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, plantChainProgramDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : plantChainProgramDetails.LastModifiedTime);
                  cmd.AddParameter("Is_Deleted", plantChainProgramDetails.IsDeleted);
                  cmd.AddParameter("EcolabSaturationId", plantChainProgramDetails.EcolabSaturationId);
                  cmd.AddParameter("PlantChainId", plantChainProgramDetails.PlantChainId);
                  cmd.AddParameter("UserId", userId);
              });
            return returnValue;
        }

        /// <summary>
        /// Saves the plant chain program details for first time synchronize.
        /// </summary>
        /// <param name="plantChainProgramDetails">The plant chain program details.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SavePlantChainProgramDetailsForFirstTimeSync(PlantChainProgram plantChainProgramDetails, int userId)
        {
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SavePlantChainProgramDetailsForFirstTimeSync,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("PlantProgramId", plantChainProgramDetails.PlantProgramId);
                  cmd.AddParameter("PlantProgramName", DbType.String, 50, plantChainProgramDetails.PlantProgramName);
                  cmd.AddParameter("ChainTextileCategoryId", plantChainProgramDetails.ChainTextileId);
                  cmd.AddParameter("EcolabTextileCategoryId", plantChainProgramDetails.EcolabTextileId);
                  cmd.AddParameter("FormulaSegmentId", plantChainProgramDetails.FormulaSegmentId);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, plantChainProgramDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : plantChainProgramDetails.LastModifiedTime);
                  cmd.AddParameter("Is_Deleted", plantChainProgramDetails.IsDeleted);
                  cmd.AddParameter("EcolabSaturationId", plantChainProgramDetails.EcolabSaturationId);
                  cmd.AddParameter("PlantChainId", plantChainProgramDetails.PlantChainId);
                  cmd.AddParameter("UserId", userId);
              });
        }

        /// <summary>
        /// Get the current plant chain id.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab Account Number.</param>
        public static int GetPlantChainId(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantChainId : Resources.Ecolab_GetPlantChainId, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
            });
        }
    }
}