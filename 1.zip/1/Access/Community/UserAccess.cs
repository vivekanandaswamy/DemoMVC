﻿// -----------------------------------------------------------------------
// <copyright file="UserAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The UserAccess object</summary>
// -----------------------------------------------------------------------

namespace Access.Community
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class UserAccess
    /// </summary>
    public class UserAccess
    {
        /// <summary>
        ///     Checks to see if the provided login and password are valid and match an existing
        ///     user.
        /// </summary>
        /// <param name="loginName">User's Login Name</param>
        /// <param name="password">User's Password</param>
        /// <returns>User details if user exists in the database</returns>
        public static UserProfile GetUserProfile(string loginName, string password)
        {
            return DbClient.ExecuteReader<UserProfile>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_usp_get_authenticateuser : Resources.Ecolab_usp_get_authenticateuser, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("UserLogin", DbType.String, 50, loginName);
                cmd.AddParameter("Password", DbType.String, 50, password);
            }).FirstOrDefault();
        }

        /// <summary>
        ///     Gets the List of User Roles
        /// </summary>
        /// <param name="userName">The Users Name</param>
        /// <returns>The List of User Roles</returns>
        public static List<UserRoles> GetUserRoles(string userName, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<UserRoles>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_usp_UsersInRoles_GetRolesForUser : Resources.Ecolab_usp_UsersInRoles_GetRolesForUser, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("LoginName", DbType.String, 250, userName);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        public static List<UserRoles> GetAllRoles()
        {
            return DbClient.ExecuteReader<UserRoles>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_usp_GetRoles : Resources.Ecolab_usp_GetRoles).ToList();
        }

        /// <summary>
        ///     Gets the Menus Based on user roles
        /// </summary>
        /// <param name="code">The Parameter Code</param>
        /// <returns>The list of Menu items</returns>
        public static List<MenuItem> GetMenusByUserRoles(string code)
        {
            return DbClient.ExecuteReader<MenuItem>(Resources.Ecolab_usp_tcd_FetchMenuSettingsByRoleCode, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("PassingRoleCode", DbType.String, 250, code);
            }).ToList();
        }

        /// <summary>
        /// Fetches the data based on selected language
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="locale">The parameter Locale to get the language</param>
        /// <returns>
        /// The list of selcted Languages
        /// </returns>
        public static List<Locale> Fetchspeciftedlanguagedata(int userId, string locale, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Locale>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_usp_get_specifiedlang : Resources.Ecolab_usp_get_specifiedlang, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("Locale", DbType.String, 50, locale);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 50, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        ///     Fetches the Meta data By group Id
        /// </summary>
        /// <param name="tab">The parameter Tab</param>
        /// <returns>The list of Meta data Values </returns>
        public static List<MetaData> FetchMetadataBygroupId(int tab)
        {
            return DbClient.ExecuteReader<MetaData>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_usp_GetMetadataBygroupID : Resources.Ecolab_usp_GetMetadataBygroupID, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("Tab", tab);
            }).ToList();
        }

        /// <summary>
        ///     Method to fetch all field sources
        /// </summary>
        /// <returns>Collection of Field Sources</returns>
        public static IEnumerable<FieldSource> GetAllFieldSources()
        {
            return DbClient.ExecuteReader<FieldSource>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Central_MasterDataAccess_GetAll_FieldSource : Resources.MasterDataAccess_GetAll_FieldSource);
        }

        /// <summary>
        ///     Fetches the data based on selected language
        /// </summary>
        /// <param name="pageName">The page number.</param>
        /// <param name="ecoalabAccountNumber">ecolab account number.</param>
        /// <returns>The list of selcted Languages</returns>
        public static List<Locale> FetchLanguageDataForPage(string pageName, string ecoalabAccountNumber)
        {
            return DbClient.ExecuteReader<Locale>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetLanguageDataForPage : Resources.Ecolab_GetLanguageDataForPage, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("PageName", DbType.String, 1000, pageName);
                cmd.AddParameter("PlantId", DbType.String, 1000, ecoalabAccountNumber);
            }).ToList();
        }

        public static void SaveUserAudit(UserAudit objData)
        {
            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveUserAudit : Resources.Ecolab_SaveUserAudit, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, objData.EcolabAccountNumber);
                cmd.AddParameter("UserId", objData.UserId);
                cmd.AddParameter("IPAddress", DbType.String, 200, objData.IpAddress);
                cmd.AddParameter("UserActivityId", objData.UserActivity);
            });
        }

        /// <summary>
        /// Gets the resource key values for uom.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns></returns>
        public static List<Locale> GetResourceKeyValuesForUom(int userId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Locale>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetResourceKeyValuesForUom : Resources.Ecolab_GetResourceKeyValuesForUom, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// This method is used to get Configurator User Information
        /// </summary>
        /// <param name="emailAddress">The email address.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// User details if user exists in the database
        /// </returns>
        public static UserProfile GetUserInformationByEmailandPlantId(string emailAddress, string ecolabAccountNumber)
        {
            //dbo].[usp_get_authenticateuserDetails
            return DbClient.ExecuteReader<UserProfile>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetUserDetailsByEmail : Resources.Ecolab_GetUserDetailsByEmail, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("@Email", DbType.String, 1000, emailAddress);
                cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).FirstOrDefault();
        }
    }
}