﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantContact Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Data.SqlTypes;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class PlantContactAccess
    /// </summary>
    public class PlantContactAccess
    {
        /// <summary>
        ///     Get plant contact details
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>List PlantContact .</returns>
        public static List<PlantContact> GetPlantContactDetails(string ecolabAccountNumber = "")
        {
            return DbClient.ExecuteReader<PlantContact>(Resources.Ecolab_GetPlantContactDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if(!string.IsNullOrEmpty(ecolabAccountNumber))
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }
            }).ToList();
        }

        /// <summary>
        ///     Save Contact details
        /// </summary>
        /// <param name="plantContact">PlantContact object</param>
        /// <param name="userId">Plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>Returns parameter values</returns>
        public static int SavePlantContactDetails(PlantContact plantContact, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            SqlParameter param = new SqlParameter { ParameterName = "OutputPlantContactId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter param1 = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantContactDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if(plantContact.Id.HasValue)
                {
                    cmd.AddParameter("Id", plantContact.Id);
                }
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantContact.EcoalabAccountNumber);
                cmd.AddParameter("ContactFirstName", DbType.String, 1000, plantContact.ContactFirstName.Trim());
                cmd.AddParameter("ContactLastName", DbType.String, 1000, plantContact.ContactLastName.Trim());
                cmd.AddParameter("ContactTitle", DbType.String, 1000, plantContact.ContactTitle);
                cmd.AddParameter("ContactPositionId", plantContact.ContactPositionId);
                cmd.AddParameter("ContactEmail", DbType.String, 1000, plantContact.ContactEmailAdresss ?? string.Empty);
                cmd.AddParameter("ContactOfficePhone", DbType.String, 1000, plantContact.ContactOfficePhone ?? string.Empty);
                cmd.AddParameter("ContactMobilePhone", DbType.String, 1000, plantContact.ContactMobilePhone ?? string.Empty);
                cmd.AddParameter("ContactFaxNumber", DbType.String, 1000, plantContact.ContactFaxNumber ?? string.Empty);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("MyServiceContactGuid", plantContact.MyServiceCntctGuid);
                if(plantContact.LastModifiedTimestampAtCentral.HasValue)
                {
	                if (plantContact.LastModifiedTimestampAtCentral.Value != DateTime.MinValue)
	                {
						cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, plantContact.LastModifiedTimestampAtCentral.Value);    
	                }
                }
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(param1);
            });
            lastModifiedTimestamp = Convert.IsDBNull(param1.Value) ? DateTime.UtcNow : (DateTime)param1.Value;
            returnValue = Convert.IsDBNull(param.Value) ? 0 : (int)param.Value;

            return returnValue;
        }

        /// <summary>
        ///     Delete PlantContact.
        /// </summary>
        /// <param name="plantContact">PlantContact object</param>
        /// <param name="userId">Plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>Returns 0(success) or error code</returns>
        public static int DeletePlantContactDetails(PlantContact plantContact, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            SqlParameter param = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_DeletePlantContactDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ID", plantContact.Id);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantContact.EcoalabAccountNumber);
                cmd.AddParameter("UserID", userId);
                if(plantContact.LastModifiedTimestampAtCentral.HasValue)
                {
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, plantContact.LastModifiedTimestampAtCentral.Value);
                }
                cmd.Parameters.Add(param);
            });
            lastModifiedTimestamp = Convert.IsDBNull(param.Value) ? DateTime.UtcNow : (DateTime)param.Value;
            return returnValue;
        }

        /// <summary>
        ///     Gets the Plant contact List using name
        /// </summary>
        /// <param name="contact">Part of First Name or Last Name</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>List of filtered Contact details</returns>
        public static IEnumerable<PlantContact> GetContactList(string contact, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<PlantContact>(Resources.Ecolab_GetPlantContactList, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("Contact", DbType.String, 1000, contact);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// To Update the last sync time.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Max Record Count
        /// </returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.PlantContact");
            });
        }

        /// <summary>
        ///     validate contact for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateContactSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidateContactSave, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Save Contact details
        /// </summary>
        /// <param name="plantContact">PlantContact object</param>
        /// <param name="userId">Plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>
        /// Returns parameter values
        /// </returns>
        public static int SaveMyServicePlantContactDetails(PlantContact plantContact, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            var param = new SqlParameter
            {
                ParameterName = "OutputPlantContactId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };
            var param1 = new SqlParameter
            {
                ParameterName = "OutputLastModifiedTimestampAtLocal",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
                Resources.Ecolab_UpdateMyServicePlantContact,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantContact.EcoalabAccountNumber);
                    cmd.AddParameter("ContactFirstName", DbType.String, 1000, plantContact.ContactFirstName.Trim());
                    cmd.AddParameter("ContactLastName", DbType.String, 1000, plantContact.ContactLastName.Trim());
                    cmd.AddParameter("ContactTitle", DbType.String, 1000, plantContact.ContactTitle.Trim());
                    cmd.AddParameter("MyServiceContactPositionId", plantContact.MyServiceContactPositionId);
                    cmd.AddParameter("ContactEmail", DbType.String, 1000, plantContact.ContactEmailAdresss ?? string.Empty);
                    cmd.AddParameter("ContactOfficePhone", DbType.String, 1000, plantContact.ContactOfficePhone ?? string.Empty);
                    cmd.AddParameter("ContactMobilePhone", DbType.String, 1000, plantContact.ContactMobilePhone ?? string.Empty);
                    cmd.AddParameter("ContactFaxNumber", DbType.String, 1000, plantContact.ContactFaxNumber ?? string.Empty);
                    cmd.AddParameter("IsDelete", plantContact.IsDelete);
                    cmd.AddParameter("MyServiceCntctGuid", plantContact.MyServiceCntctGuid);
                    cmd.AddParameter("UserID", userId);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(param1);
                });
            lastModifiedTimestamp = Convert.IsDBNull(param1.Value) ? DateTime.UtcNow : (DateTime)param1.Value;
            returnValue = Convert.IsDBNull(param.Value) ? 0 : (int)param.Value;

            return returnValue;
        }

        /// <summary>
        /// Saves the plant contact details for first time synchronize.
        /// </summary>
        /// <param name="plantContact">The plant contact.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SavePlantContactDetailsForFirstTimeSync(PlantContact plantContact, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantContactDetailsForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                if (plantContact.Id.HasValue)
                {
                    cmd.AddParameter("ID", plantContact.Id.Value);
                }
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantContact.EcoalabAccountNumber);
                cmd.AddParameter("ContactFirstName", DbType.String, 1000, plantContact.ContactFirstName.Trim());
                cmd.AddParameter("ContactLastName", DbType.String, 1000, plantContact.ContactLastName.Trim());
                cmd.AddParameter("ContactTitle", DbType.String, 1000, plantContact.ContactTitle);
                cmd.AddParameter("ContactPositionId", plantContact.ContactPositionId);
                cmd.AddParameter("ContactEmailAdresss", DbType.String, 1000, plantContact.ContactEmailAdresss ?? string.Empty);
                cmd.AddParameter("ContactOfficePhone", DbType.String, 1000, plantContact.ContactOfficePhone ?? string.Empty);
                cmd.AddParameter("ContactMobilePhone", DbType.String, 1000, plantContact.ContactMobilePhone ?? string.Empty);
                cmd.AddParameter("ContactFaxNumber", DbType.String, 1000, plantContact.ContactFaxNumber ?? string.Empty);
                cmd.AddParameter("IsDelete", plantContact.IsDelete);
                cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, plantContact.LastModifiedTimestamp);
                cmd.AddParameter("MyServiceCntctGuid", plantContact.MyServiceCntctGuid);
                if (plantContact.MyServiceLastSynchTime != DateTime.MinValue)
                {
                    cmd.AddParameter("MyServiceLastSynchTime", DbType.DateTime, plantContact.MyServiceLastSynchTime);
                }
                else
                {
                    cmd.AddParameter("MyServiceLastSynchTime", DbType.DateTime, null);
                }
                cmd.AddParameter("UserID", userId);
            });
        }
    }
}