﻿// -----------------------------------------------------------------------
// <copyright file="Database.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Database object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Data.Access
{
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    ///     Initializes the connection string to connect to database
    /// </summary>
    public static class Database
    {
        public static ApplicationMode ApplicationMode  { get; set; }

        public static void InitializeConnection(string connectionString)
        {
            DbContext.AddConnectionString(connectionString);
        }

        public static void InitializeConnection(string area, string connectionString)
        {
            DbContext.AddConnectionString(area, connectionString);
        }
    }
}