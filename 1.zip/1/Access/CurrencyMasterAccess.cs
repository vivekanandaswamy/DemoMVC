﻿// -----------------------------------------------------------------------
// <copyright file="CurrencyMasterAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class CurrencyMasterAccess
    /// </summary>
    public class CurrencyMasterAccess
    {
        /// <summary>
        ///     Get currency details
        /// </summary>
        /// <returns>different currencies</returns>
        public static List<CurrencyMaster> GetCurrencyDetails()
        {
            return DbClient.ExecuteReader<CurrencyMaster>(Resources.Ecolab_GetCurrencyDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}