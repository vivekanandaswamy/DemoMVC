﻿// -----------------------------------------------------------------------
// <copyright file="OrderRecievedAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Order Recieved Access class.</summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using Access.Properties;
using Entities;
using Nalco.Data.Common;

namespace Access
{
    public class OrderRecievedAccess
    {
        /// <summary>
        ///     Save Order recieved details
        /// </summary>
        /// <returns>the list of details</returns>
        public static int SaveOrderRecievedDetaisl(OrderRecieved orderRecieved)
        {
            int returnValue = 0;

            var paramOrderRecievedId = new SqlParameter
            {
                ParameterName = "OutputOrderRecievedId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              "[TCD].[UpdateMyServiceOrderRecievedDetails]",
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("Id", orderRecieved.Id);
                  cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, orderRecieved.EcolabAccountNumber);
                  cmd.AddParameter("ProductId", orderRecieved.ProductId);
                  cmd.AddParameter("InventoryDate", DbType.DateTime, orderRecieved.InventoryDate);
                  cmd.AddParameter("UnitSize", DbType.String, 50, orderRecieved.UnitSize);
                  cmd.AddParameter("OpeningQuantity", orderRecieved.OpeningQuantity);
                  cmd.AddParameter("AdjustedQuantity", orderRecieved.AdjustedQuantity);
                  cmd.AddParameter("PurcharsedQuantity", orderRecieved.PurcharsedQuantity);
                  cmd.AddParameter("ClosingQuantity", orderRecieved.ClosingQuantity);
                  cmd.AddParameter("UsedQuantity", orderRecieved.UsedQuantity);
                  cmd.AddParameter("MyServiceInventoryId", orderRecieved.MyServiceInventoryId);
                  cmd.Parameters.Add(paramOrderRecievedId);
              });

            returnValue = Convert.IsDBNull(paramOrderRecievedId.Value) ? 0 : (int)paramOrderRecievedId.Value;
            return returnValue;
        }

        public static int SaveMyServiceOrderRecievedDetailsInLocal(OrderRecieved orderRecieved)
        {
            int returnvalue = 0;
            DbClient.ExecuteNonQuery(
              "[TCD].[UpdateMyServiceOrderRecievedDetails]",
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("Id", orderRecieved.Id);
                  cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, orderRecieved.EcolabAccountNumber);
                  cmd.AddParameter("ProductId", orderRecieved.ProductId);
                  cmd.AddParameter("InventoryDate", DbType.DateTime, orderRecieved.InventoryDate);
                  cmd.AddParameter("UnitSize", DbType.String, 50, orderRecieved.UnitSize);
                  cmd.AddParameter("OpeningQuantity", orderRecieved.OpeningQuantity);
                  cmd.AddParameter("AdjustedQuantity", orderRecieved.AdjustedQuantity);
                  cmd.AddParameter("PurcharsedQuantity", orderRecieved.PurcharsedQuantity);
                  cmd.AddParameter("ClosingQuantity", orderRecieved.ClosingQuantity);
                  cmd.AddParameter("UsedQuantity", orderRecieved.UsedQuantity);
                  cmd.AddParameter("MyServiceInventoryId", orderRecieved.MyServiceInventoryId);
              });
            return returnvalue;
        }

        /// <summary>
        /// Gets order recived details
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNUmber</param>
        /// <returns>order recived object</returns>
        public static List<OrderRecieved> GetOrderRecievedDetails(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<OrderRecieved>(Resources.Ecolab_GetOrderRecievedDetails,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }
    }
}
