﻿// -----------------------------------------------------------------------
// <copyright file="PlantTextileCategoryAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Textile Category Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class PlantTextileCategoryAccess
    /// </summary>
    public class PlantTextileCategoryAccess
    {
        /// <summary>
        ///     Get Textile Category
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>List of textile category</returns>
        public static List<EcolabTextileCategory> GetTextileCategory(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<EcolabTextileCategory>(Resources.Ecolab_GetEcolabTextileCategory, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 50, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// Insert or update EcolabTextileCategory Details 
        /// </summary>
        /// <param name="myserviceEcolabTextileCategoryDetails">myServiceObject</param>
        /// <returns>New Generated id</returns>
        public static int SaveMyServiceEcolabTextileCategoryDetails(EcolabTextileCategory myserviceEcolabTextileCategoryDetails)
        {
            int returnValue = 0;

            var paramTextileId = new SqlParameter
            {
                ParameterName = "OutputTextileId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              Resources.Ecolab_UpdateMyServiceEcolabTextileCategoryDetails,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("TextileId", myserviceEcolabTextileCategoryDetails.TextileId);
                  cmd.AddParameter("CategoryName", DbType.String, 50, myserviceEcolabTextileCategoryDetails.CategoryName);
                  cmd.AddParameter("IsDeleted", myserviceEcolabTextileCategoryDetails.IsDeleted);
                  cmd.AddParameter("MyServiceMstrLnnTypId", myserviceEcolabTextileCategoryDetails.MyServiceMstrLnnTypId);
                  cmd.AddParameter("RegionCode", DbType.String, 50, myserviceEcolabTextileCategoryDetails.RegionCode);
                  cmd.Parameters.Add(paramTextileId);
              });

            returnValue = Convert.IsDBNull(paramTextileId.Value) ? 0 : (int)paramTextileId.Value;
            return returnValue;
        }

        /// <summary>
        ///     Save or update myservice EcolabTextileCategory locale details
        /// </summary>
        /// <param name="myserviceEcolabTextileCategoryDetails">myserviceEcolabTextileCategoryDetails</param>
        public static void SaveMyServiceEcolabTextileCategoryLocaleDetails(EcolabTextileCategory myserviceEcolabTextileCategoryDetails)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252, "FIELD_" + myserviceEcolabTextileCategoryDetails.CategoryName.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myserviceEcolabTextileCategoryDetails.CategoryName);
                    cmd.AddParameter("Spanish", DbType.String, 252, myserviceEcolabTextileCategoryDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myserviceEcolabTextileCategoryDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myserviceEcolabTextileCategoryDetails.nl_BE);
                });
        }
    }
}