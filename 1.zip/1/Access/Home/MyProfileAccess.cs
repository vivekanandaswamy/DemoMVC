﻿// -----------------------------------------------------------------------
// <copyright file="MyProfileAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyProfile Access class </summary>
// -----------------------------------------------------------------------

namespace Access.Home
{
    using System;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities.UserManagement;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for MyProfileAccess
    /// </summary>
    public class MyProfileAccess
    {
        /// <summary>
        ///     Gets my profile details
        /// </summary>
        /// <param name="userNumber">User Number</param>
        /// <param name="ecoalabAccountNumber">Plant number</param>
        /// <returns>UserManagement</returns>
        public static UserManagement FetchMyProfileDetails(int? userNumber, string ecoalabAccountNumber)
        {
            return DbClient.ExecuteReader<UserManagement>(Resources.Ecolab_GetUserdetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("UserNumber", userNumber);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecoalabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            }).FirstOrDefault();
        }

        /// <summary>
        ///     Update my profile details
        /// </summary>
        /// <param name="userManagement">User Management object</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <returns>success/failure message code</returns>
        public static string UpdateMyProfile(UserManagement userManagement, string ecolabAccNum)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateMyProfileDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("UserNumber", userManagement.UserNumber);
                cmd.AddParameter("Title", DbType.String, 50, userManagement.Title);
                cmd.AddParameter("FirstName", DbType.String, 50, userManagement.FirstName);
                cmd.AddParameter("LastName", DbType.String, 50, userManagement.LastName);
                cmd.AddParameter("Email", DbType.String, 50, userManagement.Email);
                cmd.AddParameter("LanguageId", userManagement.LanguageId);
                cmd.AddParameter("Phone", DbType.String, 50, userManagement.ContactNo);
                cmd.AddParameter("Mobile", DbType.String, 50, userManagement.Mobile);
                cmd.AddParameter("Fax", DbType.String, 50, userManagement.Fax);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("CurrencyCode", DbType.String, 100, userManagement.CurrencyCode);
                cmd.AddParameter("UOMId", userManagement.UOMId != 0 ? userManagement.UOMId : null);
                cmd.Parameters.Add(param);
            });

            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Update password details
        /// </summary>
        /// <param name="userManagement">User Management object</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <returns>success/failure message code</returns>
        public static string UpdateUserPassword(UserManagement userManagement, string ecolabAccNum)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateUserPassword, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("UserNumber", userManagement.UserNumber);
                cmd.AddParameter("Password", DbType.String, 50, userManagement.Password);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.Parameters.Add(param);
            });

            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }
    }
}