WITH CTE
AS
(
	SELECT A.*,Usage.TotalUsage AS Usage FROM 
	(
	SELECT  mdr.ModuleId, mdr.PlantId, psd.ShiftId, mdr.ModuleTypeId,mdr.Reading,
	mdr.PartitionOn, mdr.LastSyncTime, mdr.TimeStamp,
	ROW_NUMBER() OVER (PARTITION BY psd.ShiftId , mdr.ModuleId ORDER BY mdr.TimeStamp DESC) rownum
	FROM TCD.ModuleReading as mdr, TCD.ProductionShiftData psd
	WHERE(mdr.TimeStamp BETWEEN Cast(psd.StartDateTime as datetime) and Cast(psd.EndDateTime as datetime))
	AND mdr.LastSyncTime is null AND mdr.PartitionOn is not null
	AND psd.ShiftId is not null 
	AND ( GETUTCDATE() NOT BETWEEN psd.StartDateTime AND psd.EndDateTime)
	)A
	INNER JOIN 
		(
			SELECT  sum(Usage) as TotalUsage,psd.ShiftId,mdr.ModuleId
			FROM TCD.ModuleReading as mdr, TCD.ProductionShiftData psd
			WHERE(mdr.TimeStamp BETWEEN Cast(psd.StartDateTime as datetime) and Cast(psd.EndDateTime as datetime))
			AND mdr.LastSyncTime is null AND mdr.PartitionOn is not null
			AND psd.ShiftId is not null AND psd.LastSyncTime IS NOT NULL
			AND ( GETUTCDATE() NOT BETWEEN psd.StartDateTime AND psd.EndDateTime)
			group by psd.ShiftId, mdr.ModuleId
		) as Usage ON A.ShiftId=Usage.ShiftId and A.ModuleId=Usage.ModuleId
		
)
SELECT TOP (@RecordCount) 
	   ModuleId,
       PlantId, 
	   ShiftId,
	   ModuleTypeId, 
	   Reading,
	   Usage,
	   PartitionOn,
	   LastSyncTime
	   FROM CTE WHERE rownum = 1