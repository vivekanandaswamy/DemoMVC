SELECT 
	SWU.BatchId,
	SWU.StepCompartment,
	SWU.WaterTypeId, 
	SWU.ActualQuantity, 
	SWU.StandardQuantity, 
	SWU.Price ,
	SWU.EcolabWasherId,
	SWU.PartitionOn
FROM TCD.BatchStepWaterUsageData SWU
WHERE BatchId = @BatchID