SELECT   TOP (@RecordCount)
		 BD.BatchId,
		 BD.ControllerBatchId,
		 BD.EcolabWasherId,
		 BD.GroupId,
		 BD.MachineInternalId,
		 BD.PlantWasherNumber,
		 BD.StartDate,
		 BD.EndDate,
		 BD.ProgramNumber,
		 BD.ProgramMasterId,
		 BD.MachineId,
		 BD.ActualWeight,
		 BD.StandardWeight,
		 BD.CurrencyCode,
		 BD.LastSyncTime,
		 BD.ManualInputWeight,
		 BD.LastModifiedByUserId,
		 BD.PartitionOn,
		 BD.EndDateFormula,
		 BD.ShiftId,
		 BD.TargetTurnTime,
		 BD.EcolabTextileCategoryId,
		 BD.ChainTextileCategoryId,
		 BD.FormulaSegmentId,
		 BD.EcolabSaturationId,
		 BD.PlantProgramId,
		 BD.SyncReady, 
		 BD.StdInjectionSteps, 
	     BD.StdWashSteps,  
	     BD.ETechlastDroppedTimeStamp 
	 FROM TCD.BatchData BD
	 INNER JOIN TCD.ProductionShiftData psd
	 ON psd.ShiftId = BD.ShiftId
	 INNER JOIN TCD.CWBatchData CWB 
	ON CWB.BatchId = BD.BatchId
	WHERE 
	BD.StartDate BETWEEN (SELECT min(StartDate) FROM TCD.BatchData) and (( SELECT DATEADD(M, 3, (SELECT min(StartDate) FROM TCD.BatchData))))  AND
	BD.EndDate IS NOT NULL AND BD.LastSyncTime IS NULL  AND BD.EcolabWasherId IS NOT NULL AND BD.EcolabWasherId>0
	AND BD.ShiftId IS NOT NULL AND BD.SyncReady = 1 AND psd.LastSyncTime IS NOT NULL