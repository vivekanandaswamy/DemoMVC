IF EXISTS(select 1 from TCD.PlantChainProgram where PlantProgramId = @PlantProgramId)

	BEGIN

	UPDATE [TCD].[PlantChainProgram]
		SET 
		 PlantProgramId = @PlantProgramId
			,PlantProgramName = @PlantProgramName
			,ChainTextileCategoryId = @ChainTextileCategoryId
			,FormulaSegmentId = @FormulaSegmentId
			,LastModifiedTime = @LastModifiedTime
			,LastModifiedByUserId = @LastModifiedByUserId
			,Is_Deleted = @Is_Deleted
			,PlantChainId = @PlantChainId
			,EcolabSaturationId = @EcolabSaturationId
			,ResourceKey = @ResourceKey
			,LastSyncTime = @LastSyncTime
		WHERE PlantProgramId = @PlantProgramId
	END

ELSE

	BEGIN
		INSERT INTO [TCD].[PlantChainProgram]
           (
		    PlantProgramId
			,PlantProgramName
			,ChainTextileCategoryId
			,FormulaSegmentId
			,LastModifiedTime
			,LastModifiedByUserId
			,Is_Deleted
			,PlantChainId
			,EcolabSaturationId
			,ResourceKey
			,LastSyncTime
           )
		VALUES(
				 @PlantProgramId
			,@PlantProgramName
			,@ChainTextileCategoryId
			,@FormulaSegmentId
			,@LastModifiedTime
			,@LastModifiedByUserId
			,@Is_Deleted
			,@PlantChainId
			,@EcolabSaturationId
			,@ResourceKey
			,@LastSyncTime
			)
	END