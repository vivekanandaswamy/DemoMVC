
INSERT INTO TCD.SoftwareUpdateHistory
(
    VersionNumber,
    IsSuccess
)
VALUES
(
    @VersionNumber, 
    @IsSuccess
)