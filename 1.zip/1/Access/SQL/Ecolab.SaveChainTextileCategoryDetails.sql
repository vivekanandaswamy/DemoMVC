IF EXISTS(select 1 from TCD.ChainTextileCategory where TextileId = @ChainTextileId)

	BEGIN

	UPDATE [TCD].[ChainTextileCategory]
		SET 
		Name = @ChainTextileName
		,PlantChainId = @PlantChainId
		,IsDeleted = @IsDeleted
		,LastModifiedTime = @LastModifiedTime
		,LastSyncTime = @LastSyncTime
		,ResourceKey = @ResourceKey
		WHERE TextileId = @ChainTextileId
	END

ELSE

	BEGIN
		INSERT INTO [TCD].[ChainTextileCategory]
           (
		   TextileId
		  ,Name
		  ,PlantChainId
		  ,IsDeleted
		  ,LastModifiedTime
		  ,LastSyncTime
		  ,ResourceKey
           )
		VALUES(
				@ChainTextileId
			,	@ChainTextileName
			,	@PlantChainId
			,	@IsDeleted
			,	@LastModifiedTime
			,	@LastSyncTime
			,	@ResourceKey
			)
	END