-- Sp Name of this prepared statement [TCD].[UpdateMeterModuleTags]
BEGIN
    SET NOCOUNT ON;
    SET @Scope = '';
    IF @Controllerid != -1
        BEGIN
            DECLARE @Newmeterid INT, 
                    @Tagtype VARCHAR(50) = 'Tag_MPLC', 
                    @Moduletypeid INT = 2, 
                    @Result INT = NULL, 
                    @Type INT = 2, 
                    @Allowtagedit BIT, 
                    @Allowmanualentry BIT = 0;

            SELECT
                    @Allowtagedit = CASE
                                        WHEN COUNT(*) > 0 THEN 'TRUE'
                                        ELSE 'FALSE'
                                    END
                FROM TCD.UserMaster AS UM
                     INNER JOIN TCD.UserInRole AS UIR ON UM.UserId = UIR.UserId
                     INNER JOIN TCD.UserRoles AS UR ON UIR.RoleId = UR.RoleId
                WHERE UM.UserId = @Userid
                  AND UR.LevelId >= 8;

            IF @Allowtagedit = 'TRUE'
                BEGIN
                    IF @Digitalinputnumber IS NOT NULL
                   AND @Digitalinputnumber <> ''
                        BEGIN EXEC @Result = TCD.CheckDuplicateTag @Digitalinputnumber, @Controllerid, @Meternumber, @Type;
                        END;
                END;

            IF EXISTS(SELECT
                              1
                          FROM TCD.Meter AS m
                          WHERE m.MeterId = @Meternumber
                            AND m.EcolabAccountNumber = @Ecolabaccountnumber
                            AND m.Is_deleted = 0)
                BEGIN
                    SELECT
                            @Allowmanualentry = m.AllowManualentry
                        FROM TCD.Meter AS m
                        WHERE m.MeterId = @Meternumber
                          AND m.EcolabAccountNumber = @Ecolabaccountnumber
                          AND m.Is_deleted = 0;
                END;

            IF @Result IS NULL
            OR @Result = 1
                BEGIN
                    IF @Allowtagedit = 'TRUE'
                        BEGIN
                            IF NOT EXISTS(SELECT
                                                  1
                                              FROM TCD.ModuleTags
                                              WHERE ModuleID = @Meternumber
                                                AND ModuleTypeId = @Moduletypeid
                                                AND EcolabAccountNumber = @Ecolabaccountnumber)
                                BEGIN
                                    IF @Allowmanualentry = 0
                                   AND @Digitalinputnumber IS NOT NULL
                                   AND @Digitalinputnumber <> ''
                                        BEGIN
                                            INSERT INTO TCD.ModuleTags(
                                                    EcolabAccountNumber, 
                                                    TagType, 
                                                    TagAddress, 
                                                    ModuleTypeId, 
                                                    ModuleID, 
                                                    DeadBand, 
                                                    Active)
                                            VALUES
                                                   (
                                                    @Ecolabaccountnumber, 
                                                    @Tagtype, 
                                                    @Digitalinputnumber, 
                                                    @Moduletypeid, 
                                                    @Meternumber, 
                                                    20, 
                                                    1);
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    --Update Tag or Delete it if empty
                                    IF @Allowmanualentry = 0
                                   AND @Digitalinputnumber IS NOT NULL
                                   AND @Digitalinputnumber <> ''
                                        BEGIN
                                            UPDATE TCD.ModuleTags SET
                                                    TagAddress = @Digitalinputnumber, 
                                                    Active = 1
                                                WHERE
                                                    ModuleID = @Meternumber
                                                AND ModuleTypeId = @Moduletypeid
                                                AND EcolabAccountNumber = @Ecolabaccountnumber;
                                        END;
                                    ELSE
                                        BEGIN
                                            UPDATE TCD.ModuleTags SET
                                                    TagAddress = @Digitalinputnumber, 
                                                    Active = 0
                                                WHERE
                                                    ModuleID = @Meternumber
                                                AND ModuleTypeId = @Moduletypeid
                                                AND Active = 1
                                                AND EcolabAccountNumber = @Ecolabaccountnumber;
                                        END;
                                END;
                        END;
                END;
            ELSE
                BEGIN
                    SET @Scope = @Scope + '802,';
                    SELECT
                            @Scope;
                END;

        END;
END;

