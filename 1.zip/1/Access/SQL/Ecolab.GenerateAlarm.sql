DECLARE @AlarmGroupMasterId Int

SET @AlarmGroupMasterId  = 
				(SELECT AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT 
					INNER JOIN TCD.AlarmGroupMaster AGM 
						ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
					WHERE AGMVCMT.AlarmCode = 9999
				)
INSERT INTO TCD.AlarmData
(
    TCD.AlarmData.EcoalabAccountNumber,
    TCD.AlarmData.AlarmCode,
    TCD.AlarmData.IsActive,
	TCD.AlarmData.AlarmGroupMasterId
)
VALUES
(
    @EcolabAccountNumber,
    9999, 
    @IsActive,
	@AlarmGroupMasterId
)