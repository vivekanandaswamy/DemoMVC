SELECT MAX(CAST(wg.WasherGroupNumber AS INT)) + 1 FROM TCD.WasherGroup wg
INNER JOIN TCD.MachineGroup mg ON mg.Id = wg.WasherGroupId AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
WHERE mg.Is_Deleted = 'False' AND mg.GroupTypeId = 2 AND wg.EcolabAccountNumber = @EcolabAccountNumber