SELECT wwlr.WasherModelId,
	wwlr.WaterLevel,
	wwlr.WaterLevelVolume 
  FROM TCD.WasherWaterLevelReference wwlr
INNER JOIN TCD.WasherModelSize wms 
ON wms.WasherModelId = wwlr.WasherModelId
INNER JOIN TCD.Washer w 
ON w.ModelId = wms.WasherModelId
WHERE w.WasherId = @WasherId
AND w.EcoLabAccountNumber = @EcolabAccountNumber