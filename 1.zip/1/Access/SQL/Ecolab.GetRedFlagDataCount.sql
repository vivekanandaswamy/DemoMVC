	SELECT COUNT(*)
FROM TCD.RedFlagData rfd
INNER JOIN TCD.ProductionShiftData psd
ON psd.ShiftId = rfd.ShiftId
WHERE rfd.LastSyncTime IS NULL 
AND rfd.ShiftId IS NOT NULL 
AND psd.LastSyncTime IS NOT NULL
AND rfd.PartitionOn IS NOT NULL