DECLARE		@ErrorId						INT				=			0



IF EXISTS	(	SELECT		1
				FROM		tcd.ResourceKeyValue rkv	
				WHERE		rkv.ResourceId				=				@ResourceId
				AND			rkv.Locale					=				@Locale
			)
BEGIN

	
	UPDATE		TCD.ResourceKeyValue
	
	SET
				
				[Value]					=		@ResourceValue
			,	Locale					=		@Locale
			,	LanguageID				=		@LanguageId
			,	LastModifiedTime		=		@LastModifiedTime
			,	Id						=		@Id
	
	WHERE		ResourceId				=		@ResourceId

	AND			Locale					=		@Locale

	SET			@ErrorId				=		@@ERROR

END

ELSE

BEGIN

	INSERT INTO TCD.ResourceKeyValue
	(
		ResourceId,
		[Value],
		Locale,
		LanguageID,
		Id,
		LastModifiedTime
	)
	VALUES
	(
		@ResourceId,
		@ResourceValue,
		@Locale,
		@LanguageId,
		@Id,
		@LastModifiedTime
	)

SET		@ErrorId	=	@@ERROR

END

SET		@ErrorId	=	@@ERROR

Select @ErrorId