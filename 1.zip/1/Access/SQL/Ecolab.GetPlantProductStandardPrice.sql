Select [EcolabAccountNumber]
,pm.MyServiceProdId
,[ListPrice]
,[ContractPrice]
,[CountryPrice]
,PSP.LastModifiedTime
from [TCD].[ProductStandardPrice] PSP
INNER JOIN TCD.ProductMaster pm
ON psp.ProductId = pm.ProductId
WHERE	PSP.EcolabAccountNumber			=			@EcolabAccountNumber