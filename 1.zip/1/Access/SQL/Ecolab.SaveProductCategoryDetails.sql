 
IF EXISTS(select 1 from TCD.ProductCategory where  CategoryId = @ProductCategoryId)

	BEGIN
UPDATE [TCD].[ProductCategory]
  SET
      [Name]      =   @Name
    , [Is_Deleted]    =   @IsDelete
    , [MyServiceLastSynchTime] =   GETUTCDATE()
    , [LastModifiedTime] =   GETUTCDATE()
    WHERE
   CategoryId = @ProductCategoryId
	END

ELSE

	BEGIN
		INSERT INTO [TCD].ProductCategory(
            [CategoryId]
           ,[Name]
           ,[Is_Deleted]
           ,[MyServiceLastSynchTime]
           ,LastModifiedTime)
  
  SELECT 
              @ProductCategoryId
            , @Name
            , @IsDelete
            , GETUTCDATE() 
			, GETUTCDATE()
	END