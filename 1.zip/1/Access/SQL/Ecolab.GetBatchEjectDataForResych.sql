DECLARE @PlantId int 
SET @PlantId = (SELECT p.PlantId FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)
SELECT 
    becs.BatchEjectConditionId, 
    becs.MachineId, 
    becs.PlantId,
    becs.LastModifiedTime 
FROM TCD.BatchEjectConditionStatus becs
WHERE becs.PlantId = @PlantId