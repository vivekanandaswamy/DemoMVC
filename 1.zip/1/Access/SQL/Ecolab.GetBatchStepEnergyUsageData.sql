SELECT 
	SWU.BatchId,
	SWU.StepCompartment,
	SWU.GasOilTypeId, 
	SWU.ActualQuantity, 
	SWU.StandardQuantity, 
	SWU.Price ,
	SWU.EcolabWasherId,
	SWU.PartitionOn
FROM TCD.BatchEnergyUsageData SWU
WHERE BatchId = @BatchID