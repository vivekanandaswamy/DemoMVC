IF EXISTS(select 1 from TCD.EcolabTextileCategory where TextileId = @TextileId)

	BEGIN

	UPDATE [TCD].[EcolabTextileCategory]
		SET 
		 TextileId = @TextileId
		  , CategoryName = @CategoryName
		   ,IsDeleted = @IsDeleted
		   ,MyServiceMstrLnnTypId = @MyServiceMstrLnnTypId
		   ,MyServiceLastSynchTime = @MyServiceLastSynchTime
		   ,LastModifiedTime = @LastModifiedTime
		   , RegionId = @RegionId
		WHERE TextileId = @TextileId
	END

ELSE

	BEGIN
		INSERT INTO [TCD].[EcolabTextileCategory]
           (
		   TextileId,
		   CategoryName,
		   IsDeleted,
		   MyServiceMstrLnnTypId,
		   MyServiceLastSynchTime,
		   LastModifiedTime,
		   RegionId
           )
		VALUES(
				 @TextileId,
		   @CategoryName,
		   @IsDeleted,
		   @MyServiceMstrLnnTypId,
		   @MyServiceLastSynchTime,
		   @LastModifiedTime,
		   @RegionId
			)
	END