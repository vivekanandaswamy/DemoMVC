DECLARE		@ErrorId						INT				=			0



IF EXISTS	(		SELECT		1 
					FROM		TCD.ResourceKeyPageMapping rkpm
					WHERE		rkpm.ResourceId				=			@ResourceId
					
			)
BEGIN

	
	UPDATE	TCD.ResourceKeyPageMapping
	
	SET
				Id						=		@Id,
				ResourceId				=		@ResourceId,
				PageId					=		@PageId
	
	WHERE		ResourceId				=		@ResourceId
	
	SET			@ErrorId				=		@@ERROR

END

ELSE

BEGIN

	INSERT INTO TCD.ResourceKeyPageMapping
	(
		Id,
		ResourceId,
		PageId
	)
	VALUES
	(
		@Id,
		@ResourceId,
		@PageId
	)

SET		@ErrorId	=	@@ERROR

END

SET		@ErrorId	=	@@ERROR

Select @ErrorId