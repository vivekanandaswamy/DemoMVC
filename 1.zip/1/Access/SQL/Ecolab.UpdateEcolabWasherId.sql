  IF EXISTS (SELECT 1 FROM TCD.WASHER WHERE EcoLabAccountNumber = @EcoLabAccountNumber AND WasherId = @WasherId)
	BEGIN
		UPDATE TCD.WASHER
			SET EcolabWasherId = @EcolabWasherId
		WHERE
			EcoLabAccountNumber = @EcoLabAccountNumber AND WasherId = @WasherId

		UPDATE TCD.BatchData
			SET EcolabWasherId = @EcolabWasherId
		WHERE
			MachineId = @WasherId
			
		UPDATE bpd SET bpd.EcolabWasherid=bd.EcolabWasherid
			FROM tcd.batchdata bd INNER JOIN tcd.batchproductdata bpd ON bd.batchid=bpd.batchid
		WHERE bd.EcolabWasherId=@EcolabWasherId

		UPDATE bcd SET bcd.EcolabWasherId = bd.EcolabWasherId
			FROM TCD.BatchData bd INNER JOIN TCD.BatchCustomerData bcd ON bcd.BatchId = bd.BatchId
		WHERE bd.EcolabWasherId = @EcolabWasherId

		UPDATE bwsd SET bwsd.EcolabWasherId = bd.EcolabWasherId
			FROM TCD.BatchData bd INNER JOIN TCD.BatchWashStepData bwsd ON bwsd.BatchId = bd.BatchId
		WHERE bd.EcolabWasherId = @EcolabWasherId

		UPDATE bp SET bp.EcolabWasherId = bd.EcolabWasherId
			FROM TCD.BatchData bd INNER JOIN TCD.BatchParameters bp ON bp.BatchId = bd.BatchId
		WHERE bd.EcolabWasherId = @EcolabWasherId

		UPDATE bswud SET bswud.EcolabWasherId = bd.EcolabWasherId
			FROM TCD.BatchData bd INNER JOIN TCD.BatchStepWaterUsageData bswud ON bswud.BatchId = bd.BatchId
		WHERE bd.EcolabWasherId = @EcolabWasherId

		UPDATE bswud SET bswud.EcolabWasherId = bd.EcolabWasherId
			FROM TCD.BatchData bd INNER JOIN TCD.BatchEnergyUsageData bswud ON bswud.BatchId = bd.BatchId
		WHERE bd.EcolabWasherId = @EcolabWasherId

		UPDATE TCD.WasherReading
			SET EcolabWasherId = @EcolabWasherId
		WHERE WasherId = @WasherId

	END