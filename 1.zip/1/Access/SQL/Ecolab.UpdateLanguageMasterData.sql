DECLARE		@ErrorId						INT				=			0



IF EXISTS	(	SELECT		1	
				FROM		tcd.LanguageMaster am 
				WHERE		LanguageId		=			@LanguageId
			)
BEGIN

	UPDATE	tcd.LanguageMaster
	SET
		Name = @Name, 
		Locale = @Locale, 
		IsActive = @IsActive,
		LastModifiedTime = @LastModifiedTime 

	WHERE LanguageId = @LanguageId

	SET		@ErrorId	=	@@ERROR

END

ELSE

BEGIN

	INSERT INTO tcd.LanguageMaster
	(
		LanguageId,
		Name,
		Locale,
		IsActive,
		LastModifiedTime 
	)
	VALUES
	(
			@LanguageId,
			@Name,
			@Locale,
			@IsActive,
			@LastModifiedTime
	)

SET		@ErrorId	=	@@ERROR

END


SET		@ErrorId	=	@@ERROR

Select @ErrorId