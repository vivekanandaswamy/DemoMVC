WITH BatchEndData
	AS (SELECT
				bd.BatchId, 
				Lead(bd.StartDate, ms.NumberOfComp)OVER(PARTITION BY bd.GroupId, 
																	bd.MachineId ORDER BY bd.StartDate ASC)AS NewEndDate
			FROM TCD.BatchData AS bd
				INNER JOIN TCD.MachineSetup AS ms ON ms.GroupId = bd.GroupId
												AND ms.WasherId = bd.MachineId
				INNER JOIN tcd.ProductionShiftData AS psd ON psd.ShiftId = bd.ShiftId
														AND ms.EcoalabAccountNumber = psd.EcolabAccountNumber
			WHERE MS.IsTunnel = 1
			AND bd.SyncReady = 0)
	--ORDER BY bd.GroupId ASC, bd.MachineId ASC,bd.StartDate ASC)
	UPDATE TCD.BatchData SET
			EndDate = NewEndDate, 
			SyncReady = 1
		FROM TCD.BatchData bd
			INNER JOIN BatchEndData bed ON bd.BatchId = bed.BatchId
		WHERE
			bd.SyncReady = 0
		AND bed.NewEndDate IS NOT NULL;