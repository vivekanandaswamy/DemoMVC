Declare @MaxInjectionsCount int

CREATE TABLE #SetupDataTemp 
		( 
		   val varchar(32) not null 
		); 

IF @ControllerID IS NULL
BEGIN
 SELECT @ControllerID = wg.ControllerId 
	  FROM   TCD.WasherGroup wg 
	  WHERE  wg.WasherGroupId = @Washergroupid
			 AND wg.EcolabAccountNumber = @Ecolabaccountnumber

	  SELECT @ControllerModelID = cc.ControllerModelId 
	  FROM   TCD.ConduitController cc 
	  WHERE  cc.ControllerId = @ControllerID
			 AND cc.EcoalabAccountNumber = @Ecolabaccountnumber
END

IF @ControllerModelID IS NULL 
				OR @ControllerModelID < 7 
				OR @ControllerModelID IN( 12, 13 ) 
			  BEGIN ; 
				  WITH InjectValues (Value) 
					   AS (SELECT csd.[Value] 
						   FROM   TCD.ControllerSetupData AS csd 
								  INNER JOIN TCD.ConduitController AS cc(NOLOCK) 
										  ON cc.ControllerId = csd.ControllerId 
											 AND cc.EcoalabAccountNumber = csd.EcolabAccountNumber
								  INNER JOIN TCD.FieldGroup AS fg 
										  ON fg.ControllerModelId = cc.ControllerModelId 
											 AND fg.ControllerTypeId = cc.ControllerTypeId 
								  INNER JOIN TCD.FieldGroupFieldMapping AS fgfm 
										  ON fgfm.FieldGroupId = fg.Id 
								  INNER JOIN TCD.Field AS f 
										  ON f.Id = fgfm.FieldId 
											 AND f.ResourceKey = 'Max_Formula_Injections' 
											 AND csd.FieldId = f.Id 
								  INNER JOIN TCD.MachineSetup AS ms(NOLOCK) 
										  ON ms.ControllerId = cc.ControllerId 
											 AND cc.EcoalabAccountNumber = ms.EcoalabAccountNumber
								  INNER JOIN TCD.WasherGroup AS wg(NOLOCK) 
										  ON wg.WasherGroupId = ms.GroupId 
											 AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
						   WHERE  wg.WasherGroupId = @Washergroupid 
								  AND ms.IsDeleted = 'False' 
								  AND wg.EcolabAccountNumber = @Ecolabaccountnumber) 
				  INSERT INTO #SetupDataTemp 
				  SELECT iv.[Value] 
				  FROM   InjectValues iv 

				  SELECT @MaxInjectionsCount = Min(Cast(t.val AS INT)) 
				  FROM   #SetupDataTemp t 

				  DROP TABLE #SetupDataTemp 
			  END 
			ELSE 
			  BEGIN 
				  SET @MaxInjectionsCount = 20 
			  END 

			  Select @MaxInjectionsCount