SELECT COUNT(1)
	 FROM TCD.BatchData BD
	 INNER JOIN TCD.ProductionShiftData psd
	 ON psd.ShiftId = BD.ShiftId
	WHERE
	(SELECT COUNT(1) FROM TCD.CWBatchData
	WHERE BatchId = BD.BatchId) = 0 AND
	BD.EndDate IS NOT NULL AND BD.LastSyncTime IS NULL  AND BD.EcolabWasherId IS NOT NULL AND BD.EcolabWasherId>0
	AND BD.ShiftId IS NOT NULL AND BD.SyncReady = 1 AND psd.LastSyncTime IS NOT NULL
	