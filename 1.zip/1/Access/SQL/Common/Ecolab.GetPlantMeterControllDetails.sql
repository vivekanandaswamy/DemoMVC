
	  DECLARE @ControllerModelId AS INT = NULL 

	  IF @LocationId = 2 
		 AND @MachineId IS NOT NULL 
		BEGIN 
			SELECT DISTINCT CC.ControllerID, 
							CC.Name, 
							CC.ControllerModelId, 
							CM.Name                           AS ControllerModelName, 
							CM.RegionId, 
							CC.ControllerTypeId, 
							CT.Name                           AS ControllerType, 
							Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel 
			FROM   TCD.ConduitController CC 
				   INNER JOIN TCD.ControllerModel CM 
						   ON CC.ControllerModelId = CM.Id 
				   LEFT JOIN TCD.ControllerType CT 
						  ON CT.Id = CC.ControllerTypeId 
				   LEFT JOIN TCD.ControllerSetupData csd 
						  ON csd.ControllerId = CC.ControllerID 
							 AND csd.FieldId = 473 
							 AND csd.FieldGroupId = 20 
							 AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber 
			WHERE  CC.IsDeleted = 0 
				   AND CC.EcoalabAccountNumber = @EcolabAccountNumber 
				   AND CC.ControllerId > 0 
				   AND Cast(ISNULL(csd.Value, 0) AS BIT) = 1 
		END; 
	  ELSE IF @LocationId IS NULL 
		  OR @MachineId IS NULL 
		BEGIN 
			SELECT DISTINCT CC.ControllerID, 
							CC.Name, 
							CC.ControllerModelId, 
							CM.Name                           AS ControllerModelName, 
							CM.RegionId, 
							CC.ControllerTypeId, 
							CT.Name                           AS ControllerType, 
							Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel 
			FROM   TCD.ConduitController CC 
				   INNER JOIN TCD.ControllerModel CM 
						   ON CC.ControllerModelId = CM.Id 
				   LEFT JOIN TCD.ControllerType CT 
						  ON CT.Id = CC.ControllerTypeId 
				   LEFT JOIN TCD.ControllerSetupData csd 
						  ON csd.ControllerId = CC.ControllerID 
							 AND csd.FieldId = 473 
							 AND csd.FieldGroupId = 20 
							 AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber 
			WHERE  CC.IsDeleted = 0 
				   AND CC.EcoalabAccountNumber = @EcolabAccountNumber 
				   AND CC.ControllerModelId = 5 
				   AND CC.ControllerId > 0; 
		END 
	  ELSE 
		BEGIN 
			SELECT @ControllerModelId = CC.ControllerModelId 
			FROM   TCD.ConduitController CC 
				   INNER JOIN TCD.ControllerModel CM 
						   ON CC.ControllerModelId = CM.Id 
				   LEFT JOIN TCD.ControllerType CT 
						  ON CT.Id = CC.ControllerTypeId 
				   LEFT JOIN tcd.MachineSetup MS 
						  ON ms.ControllerId = CC.ControllerId 
							 AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber 
				   LEFT JOIN TCD.ControllerSetupData csd 
						  ON csd.ControllerId = CC.ControllerID 
							 AND csd.FieldId = 473 
							 AND csd.FieldGroupId = 20 
							 AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber 
			WHERE  CC.IsDeleted = 0 
				   AND CC.EcoalabAccountNumber = @EcolabAccountNumber 
				   AND ( ms.GroupId = @LocationId 
						 AND ( Ms.WasherId = CASE 
											   WHEN MS.IsTunnel = 0 THEN @MachineId 
											   ELSE (SELECT WasherId 
													 FROM   tcd.MachineSetup 
													 WHERE  GroupID = @LocationId 
														  AND EcoalabAccountNumber = @EcolabAccountNumber) 
											 END 
								OR @MachineId = 0 ) ) 
				   AND CC.ControllerId > 0 

			IF @ControllerModelId = 7 
			  BEGIN 
				  SELECT DISTINCT CC.ControllerID, 
								  CC.Name, 
								  CC.ControllerModelId, 
								  CM.Name                           AS ControllerModelName, 
								  CM.RegionId, 
								  CC.ControllerTypeId, 
								  CT.Name                           AS ControllerType, 
								  Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel 
				  FROM   TCD.ConduitController CC 
						 INNER JOIN TCD.ControllerModel CM 
								 ON CC.ControllerModelId = CM.Id 
						 LEFT JOIN TCD.ControllerType CT 
								ON CT.Id = CC.ControllerTypeId 
						 LEFT JOIN tcd.MachineSetup MS 
								ON ms.ControllerId = CC.ControllerId 
								   AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber 
						 LEFT JOIN TCD.ControllerSetupData csd 
								ON csd.ControllerId = CC.ControllerID 
								   AND csd.FieldId = 473 
								   AND csd.FieldGroupId = 20 
								   AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber 
				  WHERE  CC.IsDeleted = 0 
						 AND CC.EcoalabAccountNumber = @EcolabAccountNumber 
						 AND ( CC.ControllerModelId = 5 
								OR ms.GroupId = @LocationId 
								   AND ( Ms.WasherId = CASE 
														 WHEN MS.IsTunnel = 0 THEN @MachineId
														 ELSE (SELECT WasherId 
															   FROM   tcd.MachineSetup 
															   WHERE  GroupID = @LocationId 
																	AND EcoalabAccountNumber = @EcolabAccountNumber) 
													   END 
										  OR @MachineId = 0 ) ) 
						 AND CC.ControllerId > 0 
				  UNION 
				  SELECT DISTINCT CC.ControllerID, 
								  CC.Name, 
								  CC.ControllerModelId, 
								  CM.Name                           AS ControllerModelName, 
								  CM.RegionId, 
								  CC.ControllerTypeId, 
								  CT.Name                           AS ControllerType, 
								  Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel 
				  FROM   TCD.ConduitController CC 
						 INNER JOIN TCD.ControllerModel CM 
								 ON CC.ControllerModelId = CM.Id 
						 LEFT JOIN TCD.ControllerType CT 
								ON CT.Id = CC.ControllerTypeId 
						 LEFT JOIN tcd.MachineSetup MS 
								ON ms.ControllerId = CC.ControllerId 
								   AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber 
						 LEFT JOIN TCD.ControllerSetupData csd 
								ON csd.ControllerId = CC.ControllerID 
								   AND csd.FieldId = 473 
								   AND csd.FieldGroupId = 20 
								   AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber 
				  WHERE  CC.IsDeleted = 0 
						 AND CC.EcoalabAccountNumber = @EcolabAccountNumber 
						 AND CC.ControllerId > 0 
						 AND Cast(ISNULL(csd.Value, 0) AS BIT) = 1 
				  ORDER  BY CC.ControllerModelId DESC 
			  END 
			ELSE 
			  BEGIN 
				  SELECT DISTINCT CC.ControllerID, 
								  CC.Name, 
								  CC.ControllerModelId, 
								  CM.Name                           AS ControllerModelName, 
								  CM.RegionId, 
								  CC.ControllerTypeId, 
								  CT.Name                           AS ControllerType, 
								  Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel 
				  FROM   TCD.ConduitController CC 
						 INNER JOIN TCD.ControllerModel CM 
								 ON CC.ControllerModelId = CM.Id 
						 LEFT JOIN TCD.ControllerType CT 
								ON CT.Id = CC.ControllerTypeId 
						 LEFT JOIN tcd.MachineSetup MS 
								ON ms.ControllerId = CC.ControllerId 
								   AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber 
						 LEFT JOIN TCD.ControllerSetupData csd 
								ON csd.ControllerId = CC.ControllerID 
								   AND csd.FieldId = 473 
								   AND csd.FieldGroupId = 20 
								   AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber 
				  WHERE  CC.IsDeleted = 0 
						 AND CC.EcoalabAccountNumber = @EcolabAccountNumber 
						 AND ( CC.ControllerModelId = 5 
								OR ms.GroupId = @LocationId 
								   AND ( Ms.WasherId = CASE 
														 WHEN MS.IsTunnel = 0 THEN @MachineId
														 ELSE (SELECT WasherId 
															   FROM   tcd.MachineSetup 
															   WHERE  GroupID = @LocationId 
																	AND EcoalabAccountNumber = @EcolabAccountNumber) 
													   END 
										  OR @MachineId = 0 ) ) 
						 AND CC.ControllerId > 0 
				  ORDER  BY CC.ControllerModelId DESC 
			  END; 
		END; 