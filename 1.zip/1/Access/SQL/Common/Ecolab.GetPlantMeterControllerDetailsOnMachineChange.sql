
IF @Locationid IS NULL
OR @Machineid IS NULL

    BEGIN
        SELECT DISTINCT
                CC.ControllerID, 
                CC.Name, 
                CC.ControllerModelId, 
                CM.Name AS ControllerModelName, 
                CM.RegionId, 
                CC.ControllerTypeId, 
                CT.Name AS ControllerType, 
                CAST(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel
            FROM TCD.ConduitController AS CC
                 INNER JOIN TCD.ControllerModel AS CM ON CC.ControllerModelId = CM.Id
                 LEFT JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
                 LEFT JOIN TCD.ControllerSetupData AS csd ON csd.ControllerId = CC.ControllerID
                                                         AND csd.FieldId = 473
                                                         AND csd.FieldGroupId = 20
                                                         AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber
            WHERE CC.IsDeleted = 0
              AND CC.EcoalabAccountNumber = @Ecolabaccountnumber
              AND (CC.ControllerModelId IN(1, 2, 5, 13)
                OR CC.ControllerModelId = 7
               AND csd.FieldId = 473
               AND csd.Value = '1')
              AND CC.ControllerId <> 0;
    END;
ELSE

    BEGIN

        SELECT DISTINCT
                CC.ControllerID, 
                CC.Name, 
                CC.ControllerModelId, 
                CM.Name AS ControllerModelName, 
                CM.RegionId, 
                CC.ControllerTypeId, 
                CT.Name AS ControllerType, 
                CAST(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel
            FROM TCD.ConduitController AS CC
                 INNER JOIN TCD.ControllerModel AS CM ON CC.ControllerModelId = CM.Id
                 LEFT JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
                 LEFT JOIN tcd.MachineSetup AS MS ON ms.ControllerId = CC.ControllerId
                                                 AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
                 LEFT JOIN TCD.ControllerSetupData AS csd ON csd.ControllerId = CC.ControllerID
                                                         AND csd.FieldId = 473
                                                         AND csd.FieldGroupId = 20
                                                         AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber
            WHERE CC.IsDeleted = 0
              AND CC.ControllerId > 0
              AND (CC.ControllerModelId IN(1, 2, 5, 13)
                OR (CC.ControllerModelId = 7
               AND csd.FieldId = 473
               AND csd.Value = '1'))
              AND CC.EcoalabAccountNumber = @Ecolabaccountnumber
               OR (ms.GroupId = @Locationid
              AND CC.ControllerModelId <> 3)
              AND (Ms.WasherId = CASE
                                     WHEN MS.IsTunnel = 0 THEN @Machineid
                                     ELSE(SELECT
                                                  WasherId
                                              FROM tcd.MachineSetup
                                              WHERE GroupID = @Locationid
                                                AND EcoalabAccountNumber = @Ecolabaccountnumber)
                                 END
                OR @Machineid = 0)
            ORDER BY
                CC.ControllerModelId DESC;
    END;