SELECT
        wps.WasherProgramSetupId
    FROM TCD.WasherProgramSetup AS wps
    WHERE wps.WasherGroupId = @WasherGroupId
      AND wps.ProgramNumber = @ProgramNumber
      AND wps.EcolabAccountNumber = @EcolabAccountNumber