IF NOT EXISTS (SELECT 1 FROM TCD.PlantSettings ps WHERE ps.PlantId = @PlantId)
BEGIN
    INSERT INTO TCD.PlantSettings
    (
        PlantId,
        NodeId,
        IPAddress,
        PortNumber,
        ReadTimeout,
        PlantVersion,
        FTRLastModifiedTime,
        LastModifiedTime
    )
    VALUES
    (
        @PlantId,
        NULL,
        NULL,
        NULL,
        30000,
        @PlantVersion, 
        @FTRLastModifiedTime, 
        GETUTCDATE()
    )
END
ELSE
BEGIN
    UPDATE TCD.PlantSettings
    SET
        PlantVersion = @PlantVersion, 
        FTRLastModifiedTime = @FTRLastModifiedTime, 
        LastModifiedTime = GETUTCDATE()
	WHERE
		PlantId = @PlantId
END