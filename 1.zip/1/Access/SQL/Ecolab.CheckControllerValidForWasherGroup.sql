DECLARE @CntProd INT = 0

IF((SELECT COUNT(1) from tcd.MachineSetup ms WHERE ms.GroupId = @WasherGroupId AND ms.EcoalabAccountNumber = @EcolabAccountNumber AND ms.IsDeleted = 0) > 0 
	AND (SELECT MAX(ms.ControllerId) from tcd.MachineSetup ms WHERE ms.GroupId = @WasherGroupId AND ms.EcoalabAccountNumber = @EcolabAccountNumber AND ms.IsDeleted = 0) > 0)
BEGIN
SELECT @CntProd=COUNT(CE.ProductId)
                FROM TCD.ControllerEquipmentSetup CE 
				INNER JOIN TCD.ConduitController CC ON CC.ControllerId=CE.ControllerId
													AND CC.EcoalabAccountNumber = CE.EcolabAccountNumber
                WHERE CC.ControllerId = ISNULL(@ControllerId, CE.ControllerId)
				AND CC.EcoalabAccountNumber=@EcolabAccountNumber
IF(@CntProd>0)
BEGIN
;WITH CTE AS (SELECT DISTINCT
					CE.ProductId
                FROM TCD.WasherGroup AS wg
                     INNER JOIN TCD.MachineGroup AS mg ON mg.Id = wg.WasherGroupId
                                                      AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
                                                      AND mg.Is_Deleted = 'False'
                     INNER JOIN TCD.MachineSetup AS ms ON wg.WasherGroupId = ms.GroupId
                                                      AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
                                                      AND ms.IsDeleted = 'False'
					 INNER JOIN TCD.ControllerEquipmentSetup CE ON CE.ControllerId=ms.ControllerId
																AND CE.EcolabAccountNumber=wg.EcolabAccountNumber
																AND CE.IsActive = 1
                WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, WG.WasherGroupId)
				AND wg.EcolabAccountNumber=@EcolabAccountNumber) , CTE1
				 AS (SELECT DISTINCT
                    CE.ProductId
                FROM TCD.ControllerEquipmentSetup CE 
				INNER JOIN TCD.ConduitController CC ON CC.ControllerId=CE.ControllerId
													AND CC.EcoalabAccountNumber = CE.EcolabAccountNumber
                WHERE CC.ControllerId = ISNULL(@ControllerId, CE.ControllerId)
				AND CC.EcoalabAccountNumber=@EcolabAccountNumber
				AND CE.ProductId IS NOT NULL)
				 
				SELECT COUNT(*) FROM CTE t1 FULL OUTER JOIN CTE1 t2 ON t1.ProductId = t2.ProductId
                WHERE t1.ProductId IS NULL OR t2.ProductId IS NULL
END
ELSE
BEGIN
 SELECT 0
END
END
ELSE
BEGIN
 SELECT 0
END