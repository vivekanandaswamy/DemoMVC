IF EXISTS(select 1 from TCD.PlantChainProgram where PlantProgramId = @PlantProgramId)

	BEGIN

	UPDATE [TCD].[PlantChainProgram]
		SET PlantProgramName = @PlantProgramName,
			ChainTextileCategoryId = @ChainTextileCategoryId,
			EcolabTextileCategoryId = @EcolabTextileCategoryId,
			FormulaSegmentId = @FormulaSegmentId,
			LastModifiedTime = @LastModifiedTime,
			Is_Deleted = @Is_Deleted,
			PlantChainId = @PlantChainId,
			EcolabSaturationId = @EcolabSaturationId,
			LastModifiedByUserId = @UserId
		WHERE PlantProgramId = @PlantProgramId
	END

ELSE

	BEGIN
		INSERT INTO [TCD].[PlantChainProgram]
           (
		   PlantProgramId, 
		   PlantProgramName, 
		   ChainTextileCategoryId, 
		   EcolabTextileCategoryId, 
		   FormulaSegmentId, 
		   LastModifiedTime, 
		   Is_Deleted, 
		   PlantChainId, 
		   EcolabSaturationId,
		   LastModifiedByUserId 
           )
	VALUES(
		   @PlantProgramId, 
		   @PlantProgramName, 
		   @ChainTextileCategoryId, 
		   @EcolabTextileCategoryId, 
		   @FormulaSegmentId, 
		   @LastModifiedTime, 
		   @Is_Deleted, 
		   @PlantChainId, 
		   @EcolabSaturationId,
		   @UserId 
		  )
END