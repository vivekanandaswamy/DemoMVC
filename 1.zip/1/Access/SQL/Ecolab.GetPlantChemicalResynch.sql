SELECT 
		pm.ID,
		pm.ProductID, 
		pm.Cost,
		pm.Is_Deleted, 
		pm.IncludeCI,
		pm.InventoryExpense, 
		pm.EcolabAccountNumber,
		pm.LastModifiedTime,
		pm2.MyServiceProdId,
		pm2.Name,
		pm2.SKU
FROM	TCD.ProductdataMapping pm 
INNER JOIN TCD.ProductMaster pm2
ON pm.ProductID = pm2.ProductId
WHERE	pm.EcolabAccountNumber			=			@EcolabAccountNumber