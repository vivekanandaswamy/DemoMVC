
IF(@SyncToPlc = 1)
BEGIN
   DELETE FROM TCD.PLCDiscrepancyData WHERE ParentEntityType = @ParentEntityType AND EntityType = @EntityType	
   AND ParentEntityId = @ParentEntityId AND EntityId = @EntityId AND ControllerId = @ControllerId
END
