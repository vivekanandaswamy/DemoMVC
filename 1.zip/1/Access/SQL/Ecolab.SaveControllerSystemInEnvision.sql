SET	NOCOUNT	ON

DECLARE	
	--	input variables
--		@InEcolabAccountNumber					NVARCHAR(1000)			=			NULL			--input for FacilityId
--	,	@InWasherId								INT						=			NULL			--input to generate SerialNo
--	,	@InWasherName							NVARCHAR(50)			=			NULL			--input for ControllerName
--	,	@InWasherType							TINYINT					=			NULL			--input for conventional/tunnel <==> 1/2
--	,	@InStatus								TINYINT					=			NULL			--input for Status
		@InWasherActivationDate					DATETIME				=			NULL
--	,	@InSystemSource							VARCHAR(20)				=			NULL
	,	@InIPAddress							NVARCHAR(50)			=			NULL
	,	@InUserId								INT						=			NULL

	--	other script variables
	,	@FacilityId								INT						=			NULL			--To be set based on input EcolabAccountNUmber
	,	@FacilityName							NVARCHAR(55)			=			NULL			--To be set based on input EcolabAccountNUmber
	,	@CustomerId								INT						=			NULL			--To be set based on input EcolabAccountNUmber
	,	@CustomerNameInController				NVARCHAR(100)			=			NULL			--CustomerName
	,	@LocationNameInController				NVARCHAR(100)			=			NULL			--Facility Name; To be set based on input EcolabAccountNUmber
	,	@SerialNo								NVARCHAR(30)			=			NULL			--to be set based on washerID+Facility+NAME
	,	@ExistingWasherName						NVARCHAR(100)			=			NULL
	
	--	master data in enVision schema
	,	@SystemId								INT				=			NULL
	,	@SystemMasterId							SMALLINT				=			NULL
	,	@ConTechId								SMALLINT				=			NULL
	,	@TechGroupId							SMALLINT				=			NULL
	,	@TimeStamp								DATETIME				=			GETDATE()

	--	Script variable
	,	@ScriptError							INT						=			0				--To be returned back, if non-0, implies some error; rollback

	--	output variable
--	,	@OutEcolabWasherId						INT						=			NULL			--To be sent back using SELECT

--Setting user id based on 'Admin_Tool' userlogin
SET		@InUserId					=				(
													SELECT	TOP	1
															UM.UserId
													FROM	dbo.UserMaster			UM
													WHERE	UM.UserLogin			=			'Admin_Tool'
													ORDER BY
															UM.UserId
													)

--first get a NON-NULL EcolabWasherId based on EcolabAccountNumber and Conduit's WasherId passed
--NOTE - we are going to TCD schema for the same...
SET		@OutEcolabWasherId				=			(
													SELECT	W.EcolabWasherId
													FROM	TCD.Washer					W
													WHERE	W.EcolabAccountNumber		=			@InEcolabAccountNumber
														AND	W.WasherId					=			@InWasherId
													)

IF		@OutEcolabWasherId	IS	NOT	NULL 
		--then you can udpate
		BEGIN
				--First get other determinants... this is to get SystemId in ControllerSystem
				SELECT	@FacilityID						=			CM.FacilityID
					,	@ExistingWasherName				=			CM.ControllerName
					,	@ContechId						=			CM.ConTechID
				FROM	dbo.ControllerMaster			CM
				WHERE	CM.ControllerID					=			@OutEcolabWasherId

				--based on the above values, reteieve SystemId for ControllerSystem to update...
				SELECT	TOP	1															--TOP...since this is not enforced, so a just-in-case
						@SystemId						=			CS.SystemId
				FROM	dbo.Controllersystem			CS
				WHERE	CS.ParentLevelID				=			5
					AND	CS.ParentId						=			@FacilityId
					AND	CS.ApplicationType				=			@ContechId
					AND	CS.SystemName					=			@ExistingWasherName

				--Set SerialNo as washerID+Facility+NAME
				SET		@SerialNo						=			CAST(@InWasherId AS NVARCHAR(12))
														+			CAST(@FacilityId AS NVARCHAR(12))
														+			@InWasherName

				--update	stmt here
				UPDATE	CM
					SET	CM.ControllerName				=			@InWasherName
					,	CM.SystemName					=			@InWasherName
					,	CM.SerialNo						=			@SerialNo
					,	CM.ModifiedBy					=			@InUserId
					,	CM.ModifiedOn					=			@TimeStamp
					,	CM.[Status]						=			@InStatus
				FROM	dbo.ControllerMaster			CM
				WHERE	CM.ControllerId					=			@OutEcolabWasherId

				--capture error, if any...
				SET		@ScriptError			=			@@ERROR

				--IF ANY error, return...(rollback will happen from Access layer)
				IF	(	@ScriptError			<>			0)
					BEGIN
							SELECT	@ScriptError
							RETURN
					END

				--else proceed to update ControllerSystem based on SystemId retirieved...

				UPDATE	CS
					SET	CS.SystemName					=			@InWasherName
					,	CS.SystemDisplayName			=			@InWasherName
					,	CS.ModifiedBy					=			@InUserId
					,	CS.ModifiedOn					=			@TimeStamp
				FROM	dbo.ControllerSystem			CS
				WHERE	CS.SystemId						=			@SystemId

				SET		@ScriptError			=			@@ERROR

				--select and return
				SELECT	@ScriptError

				RETURN			--return from script
		END

ELSE
		-- then you have to insert
		BEGIN
			--Get FacilityId based on EcolabAccountNumber
				SELECT	TOP	1	
						@FacilityID					=				FM.FacilityId
					,	@FacilityName				=				FM.FacilityName
					,	@CustomerId					=				FM.CustomerId
				FROM	dbo.FacilityMaster			FM
				WHERE	FM.SoldTo					=				@InEcolabAccountNumber
				AND		SourceId					=				(
																	select	ES.SourceId
																	FROM	dbo.ERPSources		ES
																	WHERE	SourceName			=			'myService'
																	)
				ORDER BY
						FM.FacilityId


			--SystemId (for Conventional/Tunnel) based on Washer Type input
				SET		@SystemMasterId					=			(
													SELECT	SM.SystemID
													FROM	dbo.SystemMaster			SM
													WHERE	SM.SystemName				=			CASE	@InWasherType
																										WHEN	1
																										THEN	'Conventional Washer'
																										WHEN	2
																										THEN	'Tunnel Washer'
																									END
													)

			--Get TechGroupId (to determine ConTechId) for 'TCD'
			SET		@TechGroupId					=			(
													SELECT	TG.TechGroupID
													FROM	dbo.TechnologyGroup			TG
													WHERE	TG.TechGroupName			=			'Washer'
													)

			--Get ConTechId from ControllerTechnology
			SET		@ConTechId						=			(
													SELECT	CT.ConTechID
													FROM	dbo.ControllerTechnology	CT
													WHERE	CT.ConTechName				=			CASE	@InWasherType
																										WHEN	1
																										THEN	'Conventional Washer'
																										WHEN	2
																										THEN	'Tunnel Washer'
																									END
														AND	CT.TechGroupID				=			@TechGroupId
													)

			--Set SerilaNo as washerID+Facility+NAME
			SET		@SerialNo						=			CAST(@InWasherId AS NVARCHAR(12))
												+	CAST(@FacilityId AS NVARCHAR(12))
												+	@InWasherName

			--Set Customer Name
			SET		@CustomerNameInController		=			(
													SELECT	CM.CustomerName
													FROM	dbo.CustomerMaster			CM
													WHERE	CM.CustomerId				=			@CustomerId
													)


			--first insert in dbo.ControllerMaster and generate EcolabWasherId
			INSERT	INTO	dbo.ControllerMaster	(
			--	ControllerID															--Will be auto-generated
				FacilityID              
			,	SystemID																--From SystemMaster
			,	ConTechID																--From ControllerTechnology
			,	[Status]
			,	ControllerName															--Name of the washer
			,	SerialNo                
			,	CustomerNameInController												--CustomerName
			,	LocationNameInController												--Facility Name
			,	SystemName																--Washer Name
			,	CreatedBy																
			--,	CreatedOn																--DEFAULT
			,	ModifiedBy
			,	ModifiedOn
			,	DataLastCall
			--,	ControllerTimeZone														--DEFAULT
			--,	ControllerLanguage
			,	IPAddress
			,	IsNextGenController
			--,	ControllerGUID															--DEFAULT
			,	MacAddress
			,	CommissioningCompletedOn
			,	IsNextGenReplicated
			)
SELECT		
			--	ControllerID															--Will be auto-generated
				@FacilityId						AS			FacilityId
			,	@SystemMasterId					AS			SystemId
			,	@ConTechId						AS			ConTechId
			,	@InStatus						AS			[Status]
			,	@InWasherName					AS			ControllerName
			,	@SerialNo						AS			SerialNo
			,	@CustomerNameInController		AS			CustomerNameInController
			,	@FacilityName					AS			LocationNameInController
			,	@InWasherName					AS			SystemName
			,	@InUserId						AS			CreatedBy
			--,	DEFAULT							AS			CreatedOn
			,	@InUserId						AS			ModifiedBy
			,	@TimeStamp						AS			ModifiedOn
			,	NULL							AS			DataLastCall
			--,	DEFAULT							AS			ControllerTimeZone			--TBD, when NGG comes in...
			--,	DEFAULT							AS			ControllerLanguage
			,	@InIPAddress						AS			IPAddress
			,	'FALSE'							AS			IsNextGenController			--Will be false for TCD
			--,	DEFAULT							AS			ControllerGUID
			,	N''								AS			MacAddress					--empty
			,	@InWasherActivationDate			AS			CommissioningCompletedOn	--Populate the washer activation
			,	'FALSE'							AS			IsNextGenReplicated			--Will be false for TCD

			--Capture any error Script
			SET		@ScriptError			=			@@ERROR

			--if any error, return... (rollback will be from Access layer)
															IF	(	@ScriptError			<>			0)
	BEGIN
		SELECT	@ScriptError
		RETURN	--return from script
	END

			--if not, then capture the generated Id into EcolabWasherId and INSERT into Controller System

			SET		@OutEcolabWasherId			=			SCOPE_IDENTITY()

			--insert into ControllerSystem...
			INSERT	INTO	dbo.ControllerSystem	(
			--	SystemID																--auto-generated Id
				SystemName
			,	SystemDisplayName
			,	ApplicationType
			,	CreatedBy
			,	CreatedOn
			,	ModifiedBy
			,	ModifiedOn
			,	ParentLevelID
			,	ParentID
			,	SystemSource
			)
SELECT		--	SystemID																--auto-generated Id
				@InWasherName					AS			SystemName					--washer name
			,	@InWasherName					AS			SystemDisplayName			--Display name of the washer
			,	@ConTechId						AS			ApplicationType				--ControllerTechonolgy
			,	@InUserId						AS			CreatedBy
			,	@TimeStamp						AS			CreatedOn
			,	@InUserId						AS			ModifiedBy
			,	@TimeStamp						AS			ModifiedOn
			,	5								AS			ParentLevelID				--This will location lavel Id (LevelId 5)
			,	@FacilityId						AS			ParentID					--This will location id or facility id
			,	@InSystemSource					AS			SystemSource				--TCP/ENV

			--Capture any error Script
			SET		@ScriptError			=			@@ERROR
		END

SELECT	@ScriptError

SET	NOCOUNT	OFF

RETURN			--return from script
