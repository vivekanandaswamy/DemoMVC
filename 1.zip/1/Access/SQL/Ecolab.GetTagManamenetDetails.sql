DECLARE @Active INT = 1, 
        @Tankmoduletypeid INT, 
        @Sensormoduletypeid INT, 
        @Pumpmoduletypeid INT, 
        @Langunageid INT, 
        @Splchars VARCHAR(50) = ' # -', 
        @Localisevalue VARCHAR(200), 
        @Factormultiplier INT, 
        @Timevolumemultipler INT, 
        @Controllermodelid INT, 
        @Controllertypeid INT;

SELECT
        @Tankmoduletypeid = mty.ModuleTypeId
    FROM TCD.ModuleType AS mty
    WHERE mty.ModuleDescription = 'Tank';
SELECT
        @Sensormoduletypeid = mty.ModuleTypeId
    FROM TCD.ModuleType AS mty
    WHERE mty.ModuleDescription = 'Sensor';
SELECT
        @Pumpmoduletypeid = mty.ModuleTypeId
    FROM TCD.ModuleType AS mty
    WHERE mty.ModuleDescription = 'Pumps/Valves';
SELECT
        @Langunageid = p.languageID
    FROM TCD.Plant AS p
    WHERE p.EcolabAccountNumber = @Ecolabaccountnumber;

SELECT
        @Timevolumemultipler = CAST(csd.[Value] AS DECIMAL(18, 0))
    FROM TCD.ControllerSetupData AS csd
         INNER JOIN TCD.Field AS f ON f.Id = csd.FieldId
    WHERE csd.FieldId IN(SELECT
                                 f2.Id FROM TCD.Field AS f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%')
      AND csd.ControllerId = @Controllerid
      AND csd.EcolabAccountNumber = @Ecolabaccountnumber
      AND ISNUMERIC(csd.[Value]) = 1;

SELECT
        @Factormultiplier = CAST(csd.[Value] AS DECIMAL(18, 0))
    FROM TCD.ControllerSetupData AS csd
         INNER JOIN TCD.Field AS f ON f.Id = csd.FieldId
    WHERE csd.FieldId IN(SELECT
                                 f2.Id FROM TCD.Field AS f2 WHERE f2.Label LIKE '%Factors Multiplier%')
      AND csd.ControllerId = @Controllerid
      AND csd.EcolabAccountNumber = @Ecolabaccountnumber
      AND ISNUMERIC(csd.[Value]) = 1;

SELECT
        @Controllermodelid = ControllerModelId, 
        @Controllertypeid = ControllerTypeId
    FROM tcd.ConduitController AS cc
    WHERE ControllerId = @Controllerid;

CREATE TABLE #tmpTagManagementDetails(
        Id INT, 
        TagAddress VARCHAR(100), 
        Description VARCHAR(1000), 
        Value VARCHAR(500), 
        LastModifiedTime DATETIME, 
        ColName VARCHAR(500), 
        DataType VARCHAR(100), 
        RowNumber DECIMAL(3, 2), 
        OriginalColumnName VARCHAR(100), 
        EntityType VARCHAR(100), 
        TagType VARCHAR(100), 
        ControllerEquipmentSetupId VARCHAR(100), 
        SortingOrder VARCHAR(100), 
        PlcParentEntityType INT, 
        PlcEntityType INT, 
        PlcParentEntityId INT, 
        PlcEntityId INT);
--For Info : Dispenser = 1, Devices = 2,WasherGroup = 3,Washer = 4,TunnelFormula = 5,ConventionalFormula = 6,Meters = 7,Sensors = 8,StorageTanks=9

INSERT INTO #tmpTagManagementDetails(
        Id, 
        TagAddress, 
        Description, 
        [Value], 
        LastModifiedTime, 
        colName, 
        DataType, 
        RowNumber, 
        OriginalColumnName, 
        EntityType, 
        TagType, 
        ControllerEquipmentSetupId, 
        SortingOrder, 
        PlcParentEntityType, 
        PlcEntityType, 
        PlcParentEntityId, 
        PlcEntityId)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT
        ms.WasherId, 
        wt.TagAddress, 
        CONVERT(VARCHAR(100), w.PlantWasherNumber) + ' : ' + ms.MachineName, 
        CONVERT(VARCHAR(100), CONVERT(INT, w.EndOfFormula)), 
        w.LastModifiedTime, 
        'EndofFormulaNumber', 
        tt.DataType, 
        1, 
        'EndOfFormula' AS OriginalColumnName, 
        '[TCD].[Washer]' AS EntityName, 
        tt.TagType AS TagType, 
        ms.MachineInternalId AS ControllerEquipmentSetupId, 
        2 AS SortingOrder, 
        3 AS PlcParentEntityType, 
        4 AS PlcEntityType, 
        ms.GroupId AS PlcParentEntityId, 
        ms.WasherId AS PlcEntityId
    FROM TCD.WasherTags AS wt
         INNER JOIN TCD.Washer AS w ON w.WasherId = wt.WasherId
         INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = wt.WasherId
         INNER JOIN tcd.TagType AS tt ON wt.TagType = tt.TagType
    WHERE wt.WasherId IN(SELECT
                                 wt.WasherId FROM TCD.MachineSetup AS ms2 WHERE ms2.ControllerId = @Controllerid)
      AND MS.ControllerId = @Controllerid
      AND wt.Active = @Active
      AND wt.TagType = 'Tag_EOF'
      AND ms.IsTunnel IN(0, 1)
UNION
SELECT
        ms.WasherId, 
        wt.TagAddress, 
        CONVERT(VARCHAR(100), w.PlantWasherNumber) + ' : ' + ms.MachineName, 
        CONVERT(VARCHAR(100), CONVERT(INT, (SELECT
                                                    wmm.WasherModeNumber
                                                FROM TCD.WasherModeMapping AS wmm
                                                     INNER JOIN tcd.ControllerModelControllerTypeMapping AS cmctm ON cmctm.Id = wmm.
ControllerModelControllerTypeMappingId
                                                                                                                 AND cmctm.ControllerModelId =
@Controllermodelid
                                                                                                                 AND cmctm.ControllerTypeId =
@Controllertypeid
                                                                                                                 AND wmm.WasherModeId = w.WasherMode))), 
        w.LastModifiedTime, 
        'WasherMode', 
        tt.DataType, 
        1, 
        'WasherMode' AS OriginalColumnName, 
        '[TCD].[Washer]' AS EntityName, 
        tt.TagType AS TagType, 
        ms.MachineInternalId AS ControllerEquipmentSetupId, 
        5 AS SortingOrder, 
        3 AS PlcParentEntityType, 
        4 AS PlcEntityType, 
        ms.GroupId AS PlcParentEntityId, 
        ms.WasherId AS PlcEntityId
    FROM TCD.WasherTags AS wt
         INNER JOIN TCD.Washer AS w ON w.WasherId = wt.WasherId
         INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = wt.WasherId
         INNER JOIN tcd.TagType AS tt ON wt.TagType = tt.TagType
    WHERE wt.WasherId IN(SELECT
                                 wt.WasherId FROM TCD.MachineSetup AS ms2 WHERE ms2.ControllerId = @Controllerid)
      AND MS.ControllerId = @Controllerid
      AND wt.Active = @Active
      AND wt.TagType = 'Tag_MODE'
      AND ms.IsTunnel IN(0, 1)
UNION
SELECT
        ms.WasherId, 
        wt.TagAddress, 
        CONVERT(VARCHAR(100), w.PlantWasherNumber) + ' : ' + ms.MachineName, 
        CONVERT(VARCHAR(100), CONVERT(INT, w.AWEActive)), 
        w.LastModifiedTime, 
        'AWEActive', 
        tt.DataType, 
        1, 
        'AWEActive' AS OriginalColumnName, 
        '[TCD].[Washer]' AS EntityName, 
        tt.TagType AS TagType, 
        ms.MachineInternalId AS ControllerEquipmentSetupId, 
        1 AS SortingOrder, 
        3 AS PlcParentEntityType, 
        4 AS PlcEntityType, 
        ms.GroupId AS PlcParentEntityId, 
        ms.WasherId AS PlcEntityId
    FROM TCD.WasherTags AS wt
         INNER JOIN TCD.Washer AS w ON w.WasherId = wt.WasherId
         INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = wt.WasherId
         INNER JOIN tcd.TagType AS tt ON wt.TagType = tt.TagType
    WHERE wt.WasherId IN(SELECT
                                 wt.WasherId FROM TCD.MachineSetup AS ms2 WHERE ms2.ControllerId = @Controllerid)
      AND MS.ControllerId = @Controllerid
      AND wt.Active = @Active
      AND wt.TagType = 'Tag_AWEA'
      AND ms.IsTunnel IN(0, 1)
UNION
SELECT
        ms.WasherId, 
        wt.TagAddress, 
        CONVERT(VARCHAR(100), w.PlantWasherNumber) + ' : ' + ms.MachineName, 
        CONVERT(VARCHAR(100), CONVERT(INT, w.HoldDelay)), 
        w.LastModifiedTime, 
        'HoldDelay', 
        tt.DataType, 
        1, 
        'HoldDelay' AS OriginalColumnName, 
        '[TCD].[Washer]' AS EntityName, 
        tt.TagType AS TagType, 
        ms.MachineInternalId AS ControllerEquipmentSetupId, 
        3 AS SortingOrder, 
        3 AS PlcParentEntityType, 
        4 AS PlcEntityType, 
        ms.GroupId AS PlcParentEntityId, 
        ms.WasherId AS PlcEntityId
    FROM TCD.WasherTags AS wt
         INNER JOIN TCD.Washer AS w ON w.WasherId = wt.WasherId
         INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = wt.WasherId
         INNER JOIN tcd.TagType AS tt ON wt.TagType = tt.TagType
    WHERE wt.WasherId IN(SELECT
                                 wt.WasherId FROM TCD.MachineSetup AS ms2 WHERE ms2.ControllerId = @Controllerid)
      AND MS.ControllerId = @Controllerid
      AND wt.Active = @Active
      AND wt.TagType = 'Tag_HOLDD'
      AND ms.IsTunnel = 0
UNION
SELECT
        ms.WasherId, 
        wt.TagAddress, 
        CONVERT(VARCHAR(100), w.PlantWasherNumber) + ' : ' + ms.MachineName, 
        CONVERT(VARCHAR(100), CONVERT(INT, w.WaterFlushTime)), 
        w.LastModifiedTime, 
        'WaterFlushTime', 
        tt.DataType, 
        1, 
        'WaterFlushTime' AS OriginalColumnName, 
        '[TCD].[Washer]' AS EntityName, 
        tt.TagType AS TagType, 
        ms.MachineInternalId AS ControllerEquipmentSetupId, 
        6 AS SortingOrder, 
        3 AS PlcParentEntityType, 
        4 AS PlcEntityType, 
        ms.GroupId AS PlcParentEntityId, 
        ms.WasherId AS PlcEntityId
    FROM TCD.WasherTags AS wt
         INNER JOIN TCD.Washer AS w ON w.WasherId = wt.WasherId
         INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = wt.WasherId
         INNER JOIN tcd.TagType AS tt ON wt.TagType = tt.TagType
    WHERE wt.WasherId IN(SELECT
                                 wt.WasherId FROM TCD.MachineSetup AS ms2 WHERE ms2.ControllerId = @Controllerid)
      AND MS.ControllerId = @Controllerid
      AND wt.Active = @Active
      AND wt.TagType = 'Tag_FLSHT'
      AND ms.IsTunnel = 0
UNION
SELECT
        ms.WasherId, 
        wt.TagAddress, 
        CONVERT(VARCHAR(100), w.PlantWasherNumber) + ' : ' + ms.MachineName, 
        CONVERT(VARCHAR(100), CONVERT(INT, w.RatioDosingActive)), 
        w.LastModifiedTime, 
        'RatioDosingActive', 
        tt.DataType, 
        1, 
        'RatioDosingActive' AS OriginalColumnName, 
        '[TCD].[Washer]' AS EntityName, 
        tt.TagType AS TagType, 
        ms.MachineInternalId AS ControllerEquipmentSetupId, 
        4 AS SortingOrder, 
        3 AS PlcParentEntityType, 
        4 AS PlcEntityType, 
        ms.GroupId AS PlcParentEntityId, 
        ms.WasherId AS PlcEntityId
    FROM TCD.WasherTags AS wt
         INNER JOIN TCD.Washer AS w ON w.WasherId = wt.WasherId
         INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = wt.WasherId
         INNER JOIN tcd.TagType AS tt ON wt.TagType = tt.TagType
    WHERE wt.WasherId IN(SELECT
                                 wt.WasherId FROM TCD.MachineSetup AS ms2 WHERE ms2.ControllerId = @Controllerid)
      AND MS.ControllerId = @Controllerid
      AND wt.Active = @Active
      AND wt.TagType = 'Tag_RATA'
      AND ms.IsTunnel = 0
UNION
------------------------------------
---- Tanks---
------------------------------------
SELECT
        ts.TankId AS Id, 
        mt.TagAddress AS TagAddress, 
        ts.TankName AS Description, 
        CONVERT(VARCHAR(10), CONVERT(INT, ts.Size)) AS Value, 
        ts.LastModifiedTime, 
        'Size', 
        tt.DataType, 
        1, 
        'Size-Size_Display' AS OriginalColumnName, 
        '[TCD].[TankSetup]' AS EntityName, 
        tt.TagType AS TagType, 
        0 AS ControllerEquipmentSetupId, 
        0 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        9 AS PlcEntityType, 
        ts.ControllerId AS PlcParentEntityId, 
        ts.TankId AS PlcEntityId
    FROM TCD.ModuleTags AS mt
         INNER JOIN TCD.TankSetup AS ts ON ts.TankId = mt.ModuleId
         INNER JOIN tcd.TagType AS tt ON mt.TagType = tt.TagType
    WHERE mt.ModuleTypeId = @Tankmoduletypeid
      AND ts.ControllerId = @Controllerid
      AND mt.Active = @Active
      AND mt.TagType = 'Tag_SIZ'
UNION
SELECT
        ts.TankId, 
        mt.TagAddress, 
        ts.TankName, 
        CONVERT(VARCHAR(100), CONVERT(INT, ts.LevelDeviation_Display)), 
        ts.LastModifiedTime, 
        'Dead Band', 
        tt.DataType, 
        1, 
        'LevelDeviation-LevelDeviation_Display' AS OriginalColumnName, 
        '[TCD].[TankSetup]' AS EntityName, 
        tt.TagType AS TagType, 
        0 AS SortingOrder, 
        0 AS ControllerEquipmentSetupId, 
        1 AS PlcParentEntityType, 
        9 AS PlcEntityType, 
        ts.ControllerId AS PlcParentEntityId, 
        ts.TankId AS PlcEntityId
    FROM TCD.ModuleTags AS mt
         INNER JOIN TCD.TankSetup AS ts ON ts.TankId = mt.ModuleId
         INNER JOIN tcd.TagType AS tt ON mt.TagType = tt.TagType
    WHERE mt.ModuleTypeId = @Tankmoduletypeid
      AND ts.ControllerId = @Controllerid
      AND mt.Active = @Active
      AND mt.TagType = 'Tag_DEV'
UNION

----------------------------------------
---- Sensor---
----------------------------------------
SELECT
        s.SensorId, 
        mt.TagAddress, 
        s.Description, 
        CONVERT(VARCHAR(100), CAST(s.Calibration4mA AS FLOAT)), 
        s.LastModifiedTime, 
        'Calibration4mA', 
        tt.DataType, 
        3, 
        'Calibration4mA' AS OriginalColumnName, 
        '[TCD].[Sensor]' AS EntityName, 
        tt.TagType AS TagType, 
        0 AS ControllerEquipmentSetupId, 
        0 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        8 AS PlcEntityType, 
        s.ControllerId AS PlcParentEntityId, 
        s.SensorId AS PlcEntityId
    FROM TCD.ModuleTags AS mt
         INNER JOIN TCD.Sensor AS s ON MT.ModuleId = s.SensorId
         INNER JOIN tcd.TagType AS tt ON mt.TagType = tt.TagType
    WHERE mt.ModuleTypeId = @Sensormoduletypeid
      AND s.ControllerId = @Controllerid
      AND mt.Active = @Active
      AND mt.TagType = 'Tag_SC4'
UNION
SELECT
        s.SensorId, 
        mt.TagAddress, 
        s.Description, 
        CONVERT(VARCHAR(100), CAST(s.Calibration20mA AS FLOAT)), 
        s.LastModifiedTime, 
        'Calibration20mA', 
        tt.DataType, 
        3, 
        'Calibration20mA' AS OriginalColumnName, 
        '[TCD].[Sensor]' AS EntityName, 
        tt.TagType AS TagType, 
        0 AS ControllerEquipmentSetupId, 
        0 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        8 AS PlcEntityType, 
        s.ControllerId AS PlcParentEntityId, 
        s.SensorId AS PlcEntityId
    FROM TCD.ModuleTags AS mt
         INNER JOIN TCD.Sensor AS s ON MT.ModuleId = s.SensorId
         INNER JOIN tcd.TagType AS tt ON mt.TagType = tt.TagType
    WHERE mt.ModuleTypeId = @Sensormoduletypeid
      AND s.ControllerId = @Controllerid
      AND mt.Active = @Active
      AND mt.TagType = 'Tag_SC20'
UNION
--------------------------------------
-- Pumps---
--------------------------------------
SELECT
        CONVERT(INT, ces.ControllerEquipmentSetupId), 
        mt.TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CONVERT(VARCHAR(100), CONVERT(FLOAT, ces.KFactor * @Factormultiplier)), 
        ces.LastModifiedTime, 
        'K-Factor', 
        tt.DataType, 
        2, 
        'KFactor' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityName, 
        tt.TagType AS TagType, 
        ControllerEquipmentId AS ControllerEquipmentSetupId, 
        1 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM TCD.ModuleTags AS mt
         INNER JOIN TCD.ControllerEquipmentSetup AS ces ON mt.ModuleId = ces.ControllerEquipmentSetupId
         INNER JOIN tcd.TagType AS tt ON mt.TagType = tt.TagType
    WHERE mt.ModuleTypeId = @Pumpmoduletypeid
      AND ces.ControllerId = @Controllerid
      AND mt.Active = @Active
      AND mt.TagType = 'Tag_PPOL'
UNION
SELECT
        CONVERT(INT, ces.ControllerEquipmentSetupId), 
        mt.TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CONVERT(VARCHAR(100), CONVERT(FLOAT, ces.PumpCalibration * @Timevolumemultipler)), 
        ces.LastModifiedTime, 
        'Time Volume Calibration', 
        tt.DataType, 
        2, 
        'PumpCalibration' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityName, 
        tt.TagType AS TagType, 
        ControllerEquipmentId AS ControllerEquipmentSetupId, 
        3 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM TCD.ModuleTags AS mt
         INNER JOIN TCD.ControllerEquipmentSetup AS ces ON mt.ModuleId = ces.ControllerEquipmentSetupId
         INNER JOIN tcd.TagType AS tt ON mt.TagType = tt.TagType
    WHERE mt.ModuleTypeId = @Pumpmoduletypeid
      AND ces.ControllerId = @Controllerid
      AND mt.Active = @Active
      AND mt.TagType = 'Tag_OPSL'
UNION
SELECT
        CONVERT(INT, ces.ControllerEquipmentSetupId), 
        mt.TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        ces.LfsChemicalName, 
        ces.LastModifiedTime, 
        'LFS Chemical Name', 
        tt.DataType, 
        2, 
        'LfsChemicalName' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityName, 
        tt.TagType AS TagType, 
        ControllerEquipmentId AS ControllerEquipmentSetupId, 
        2 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM TCD.ModuleTags AS mt
         INNER JOIN TCD.ControllerEquipmentSetup AS ces ON mt.ModuleId = ces.ControllerEquipmentSetupId
         INNER JOIN tcd.TagType AS tt ON mt.TagType = tt.TagType
    WHERE mt.ModuleTypeId = @Pumpmoduletypeid
      AND ces.ControllerId = @Controllerid
      AND mt.Active = @Active
      AND mt.TagType = 'Tag_NML'
UNION
SELECT
        ces.ControllerEquipmentSetupId, 
        'stMachineConfig.xFlowSwitchType[' + CAST(ControllerEquipmentId AS VARCHAR(20)) + ']' AS TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CAST(FlowDetectorType AS VARCHAR(20)) AS Value, 
        ces.LastModifiedTime, 
        'Flow Detector Type' AS Lable, 
        'BIT' AS DataType, 
        2.1, 
        'FlowDetectorType' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityType, 
        'stMachineConfig.xFlowSwitchType' AS TagType, 
        ces.ControllerEquipmentId AS ControllerEquipmentSetupId, 
        5 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM tcd.ControllerEquipmentSetup AS ces
    WHERE ces.ControllerId = @Controllerid
      AND ces.IsActive = @Active
      AND @Controllermodelid = 3
UNION --Flow Switch Alarm
SELECT
        ces.ControllerEquipmentSetupId, 
        'stMachineConfig.xFlowAlarmOverride[' + CAST(ControllerEquipmentId AS VARCHAR(20)) + ']' AS TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CAST(ces.FlowSwitchAlarm AS VARCHAR(20)) AS Value, 
        ces.LastModifiedTime, 
        'Flow Switch Alarm' AS Lable, 
        'BIT' AS DataType, 
        2.2, 
        'FlowSwitchAlarm' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityType, 
        'stMachineConfig.xFlowAlarmOverride' AS TagType, 
        ces.ControllerEquipmentId AS ControllerEquipmentSetupId, 
        10 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM tcd.ControllerEquipmentSetup AS ces
    WHERE ces.ControllerId = @Controllerid
      AND ces.IsActive = @Active
      AND @Controllermodelid = 3
UNION --Flow Meter Alarm
SELECT
        ces.ControllerEquipmentSetupId, 
        'stMachineConfig.xFlowMeterAlarmOverride[' + CAST(ControllerEquipmentId AS VARCHAR(20)) + ']' AS TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CAST(ces.FlowMeterAlarm AS VARCHAR(20)) AS Value, 
        ces.LastModifiedTime, 
        'Flow Meter Alarm' AS Lable, 
        'BIT' AS DataType, 
        2.3, 
        'FlowMeterAlarm' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityType, 
        'stMachineConfig.xFlowMeterAlarmOverride' AS TagType, 
        ces.ControllerEquipmentId AS ControllerEquipmentSetupId, 
        6 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM tcd.ControllerEquipmentSetup AS ces
    WHERE ces.ControllerId = @Controllerid
      AND ces.IsActive = @Active
      AND @Controllermodelid = 3
UNION --Flow Meter Type
     
SELECT
        ces.ControllerEquipmentSetupId, 
        'stPumpConfig[' + CAST(ControllerEquipmentId AS VARCHAR(20)) + '].eFlowMeterMode' AS TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CAST(ces.FlowMeterType AS VARCHAR(20)) AS Value, 
        ces.LastModifiedTime, 
        'Flow Meter Type' AS Lable, 
        'INT' AS DataType, 
        2.4, 
        'FlowMeterType' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityType, 
        'stPumpConfig.eFlowMeterMode' AS TagType, 
        ces.ControllerEquipmentId AS ControllerEquipmentSetupId, 
        9 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM tcd.ControllerEquipmentSetup AS ces
    WHERE ces.ControllerId = @Controllerid
      AND ces.IsActive = @Active
      AND @Controllermodelid = 3
UNION --Flow Alarm Delay Time
SELECT
        ces.ControllerEquipmentSetupId, 
        'stPumpConfig[' + CAST(ControllerEquipmentId AS VARCHAR(20)) + '].fLossOfFlowDuration' AS TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CAST(ces.FlowAlarmDelay AS VARCHAR(20)) AS Value, 
        ces.LastModifiedTime, 
        'Flow Alarm Delay Time' AS Lable, 
        'FLOAT' AS DataType, 
        2.5, 
        'FlowAlarmDelay' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityType, 
        'stPumpConfig.fLossofFlowDuration' AS TagType, 
        ces.ControllerEquipmentId AS ControllerEquipmentSetupId, 
        4 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM tcd.ControllerEquipmentSetup AS ces
    WHERE ces.ControllerId = @Controllerid
      AND ces.IsActive = @Active
      AND @Controllermodelid = 3
UNION --Flow Meter Pump Delay
SELECT
        ces.ControllerEquipmentSetupId, 
        'stPumpConfig[' + CAST(ControllerEquipmentId AS VARCHAR(20)) + '].fTdFlowMeter' AS TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CAST(ces.FlowMeterPumpDelay AS VARCHAR(20)) AS Value, 
        ces.LastModifiedTime, 
        'Flow Meter Pump Delay' AS Lable, 
        'FLOAT' AS DataType, 
        2.6, 
        'FlowMeterPumpDelay' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityType, 
        'stPumpConfig.fTdFlowMeter' AS TagType, 
        ces.ControllerEquipmentId AS ControllerEquipmentSetupId, 
        8 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM tcd.ControllerEquipmentSetup AS ces
    WHERE ces.ControllerId = @Controllerid
      AND ces.IsActive = @Active
      AND @Controllermodelid = 3
UNION -- Flow Meter Alarm Delay
SELECT
        ces.ControllerEquipmentSetupId, 
        'stPumpConfig[' + CAST(ControllerEquipmentId AS VARCHAR(20)) + '].fTAlarmDelayFlowMeter' AS TagAddress, 
        'P/V' + CONVERT(VARCHAR(100), ces.ControllerEquipmentId), 
        CAST(ces.FlowMeterAlarmDelay AS VARCHAR(20)) AS Value, 
        ces.LastModifiedTime, 
        'Flow Meter Alarm Delay' AS Lable, 
        'FLOAT' AS DataType, 
        2.7, 
        'FlowMeterAlarmDelay' AS OriginalColumnName, 
        '[TCD].[ControllerEquipmentSetup]' AS EntityType, 
        'stPumpConfig.fTAlarmDelayFlowMeter' AS TagType, 
        ces.ControllerEquipmentId AS ControllerEquipmentSetupId, 
        7 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        2 AS PlcEntityType, 
        ces.ControllerId AS PlcParentEntityId, 
        ces.ControllerEquipmentSetupId AS PlcEntityId
    FROM tcd.ControllerEquipmentSetup AS ces
    WHERE ces.ControllerId = @Controllerid
      AND ces.IsActive = @Active
      AND @Controllermodelid = 3
UNION
SELECT
        csd.ControllerId, 
        ct.TagAddress, 
        NULL, 
        csd.[Value], 
        cc.LastModifiedTime, 
        f.Label, 
        tt.DataType, 
        6, 
        'Value-' + CAST(csd.FieldId AS VARCHAR) AS OriginalColumnName, 
        '[TCD].[ControllerSetupData]' AS EntityName, 
        tt.TagType AS TagType, 
        0 AS ControllerEquipmentSetupId, 
        0 AS SortingOrder, 
        1 AS PlcParentEntityType, 
        9 AS PlcEntityType, 
        csd.ControllerId AS PlcParentEntityId, 
        csd.ControllerId AS PlcEntityId
    FROM TCD.ControllerTags AS ct
         INNER JOIN TCD.ControllerSetupData AS csd ON csd.ControllerId = ct.ControllerId
         INNER JOIN tcd.Field AS f ON f.Id = csd.FieldId
                                  AND ct.TagType = f.HasFieldTag
         INNER JOIN TCD.ConduitController AS cc ON cc.ControllerId = ct.ControllerId
         INNER JOIN tcd.TagType AS tt ON ct.TagType = tt.TagType
    WHERE ct.ControllerId = @Controllerid
      AND ct.Active = @Active;

SELECT
        ttmd.Id, 
        ttmd.TagAddress, 
        ISNULL(ttmd.Description, ''), 
        ttmd.Value, 
        ttmd.LastModifiedTime, 
        ttmd.ColName, 
        ttmd.DataType, 
        ttmd.OriginalColumnName, 
        ttmd.EntityType, 
        ttmd.TagType, 
        ttmd.SortingOrder, 
        ttmd.ControllerEquipmentSetupId, 
        ttmd.PlcParentEntityType, 
        ttmd.PlcEntityType, 
        ttmd.PlcParentEntityId, 
        ttmd.PlcEntityId
    FROM dbo.#tmpTagManagementDetails AS ttmd
    WHERE ttmd.[Value] IS NOT NULL
      AND ttmd.[Value] <> ''
    ORDER BY
        ttmd.RowNumber;