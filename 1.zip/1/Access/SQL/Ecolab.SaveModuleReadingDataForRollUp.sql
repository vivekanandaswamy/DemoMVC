IF NOT EXISTS(SELECT 1 FROM TCD.ModuleReadingRollup WHERE ModuleId = @ModuleId AND ShiftId = @ShiftId)
BEGIN
    INSERT INTO TCD.ModuleReadingRollUp
(
    ModuleId,
    ModuleTypeId,
    Reading,
    [TimeStamp],
    Usage,
    PlantId,
    PartitionOn,
    ShiftId
)
VALUES
(
    @ModuleId,
    @ModuleTypeId,
    @Reading,
    GETUTCDATE(),
    @Usage,
    @PlantId,
    @PartitionOn,
    @ShiftId
)
END