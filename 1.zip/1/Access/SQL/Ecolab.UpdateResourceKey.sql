DECLARE		@ErrorId						INT				=			0



IF EXISTS	(	SELECT		1
				FROM		tcd.ResourceKeyMaster rkm
				WHERE		rkm.ResourceId				=				@ResourceId
			)
BEGIN

	UPDATE		TCD.ResourceKeyMaster
	SET
	
				[Key]				=			@Key
	WHERE		ResourceId			=			@ResourceId

	SET			@ErrorId			=			@@ERROR

END

ELSE

BEGIN

	INSERT INTO TCD.ResourceKeyMaster
	(
			ResourceId			
		,	[Key]
	)
	VALUES
	(
			@ResourceId
		,	@Key
	)

SET		@ErrorId	=	@@ERROR

END

SET		@ErrorId	=	@@ERROR

Select @ErrorId