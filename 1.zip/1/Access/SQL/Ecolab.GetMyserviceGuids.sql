DECLARE @WasherId INT
SELECT @WasherId = WasherId FROM TCD.Washer WHERE EcolabWasherId=@EcolabWasherId
IF EXISTS (SELECT 1 FROM TCD.MachineSetup WHERE WasherId=@WasherId AND IsTunnel = 0)
BEGIN
SELECT DISTINCT w.MyServiceCustMchGuid, 
		mg.MyServiceCustMchGrpGuid, 
		wps.MyServiceCustFrmulaMchGrpGUID, 
		p.MyServiceCustGuid 
		FROM tcd.plant p INNER JOIN tcd.washer w 
			ON p.EcolabAccountNumber = w.EcoLabAccountNumber
			INNER JOIN tcd.MachineSetup ms
			ON w.WasherId = ms.WasherId AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber
			INNER JOIN tcd.MachineGroup mg
			ON mg.Id = ms.GroupId AND mg.EcolabAccountNumber = ms.EcoalabAccountNumber
			INNER JOIN tcd.WasherProgramSetup wps
			ON wps.WasherGroupId = mg.id AND wps.EcolabAccountNumber=mg.EcolabAccountNumber
			WHERE p.EcoLabAccountNumber = @EcolabAccountNumber
				AND w.EcoLabAccountNumber = @EcolabAccountNumber
				AND ms.EcoaLabAccountNumber = @EcolabAccountNumber
				AND mg.EcoLabAccountNumber = @EcolabAccountNumber
				AND wps.EcoLabAccountNumber = @EcolabAccountNumber
				AND w.WasherId = @WasherId
				AND wps.ProgramNumber = @ProgramNumber
END
ELSE
BEGIN
SELECT DISTINCT w.MyServiceCustMchGuid, 
		mg.MyServiceCustMchGrpGuid, 
		wps.MyServiceCustFrmulaMchGrpGUID, 
		p.MyServiceCustGuid 
		FROM tcd.plant p INNER JOIN tcd.washer w 
			ON p.EcolabAccountNumber = w.EcoLabAccountNumber
			INNER JOIN tcd.MachineSetup ms
			ON w.WasherId = ms.WasherId AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber
			INNER JOIN tcd.MachineGroup mg
			ON mg.Id = ms.GroupId AND mg.EcolabAccountNumber = ms.EcoalabAccountNumber
			INNER JOIN tcd.TunnelProgramSetup wps
			ON wps.WasherGroupId = mg.id AND wps.EcolabAccountNumber=mg.EcolabAccountNumber
			WHERE p.EcoLabAccountNumber = @EcolabAccountNumber
				AND w.EcoLabAccountNumber = @EcolabAccountNumber
				AND ms.EcoaLabAccountNumber = @EcolabAccountNumber
				AND mg.EcoLabAccountNumber = @EcolabAccountNumber
				AND wps.EcoLabAccountNumber = @EcolabAccountNumber
				AND w.WasherId = @WasherId
				AND wps.ProgramNumber = @ProgramNumber
END