
SELECT CONVERT(varchar(1000), ((select MAX(PlantWasherNumber) from tcd.Washer where EcoLabAccountNumber=@EcoLabAccountNumber)+1))