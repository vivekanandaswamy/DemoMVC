SELECT	wmm.WasherModeNumber
 FROM TCD.WasherModeMapping wmm	
 INNER JOIN	tcd.ControllerModelControllerTypeMapping cmctm	ON cmctm.Id	=wmm.ControllerModelControllerTypeMappingId	 
 AND cmctm.ControllerModelId= @ControllerModelId 
 AND cmctm.ControllerTypeId= @ControllerTypeId 
 AND wmm.WasherModeId= @WasherModeId

