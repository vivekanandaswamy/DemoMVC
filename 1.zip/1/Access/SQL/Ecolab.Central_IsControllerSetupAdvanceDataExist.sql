DECLARE @Istrue BIT = NULL;
		SELECT @Istrue = 1
						FROM TCD.ControllerSetupData AS CSD
							INNER JOIN TCD.FieldGroup AS FG ON FG.Id = CSD.FieldGroupId
						WHERE CSD.ControllerId = @Controllerid
						AND FG.TabId = @Tabid
						AND CSD.EcolabAccountNumber = @Ecolabaccountnumber
	SELECT 		ISNULL(@Istrue, 0);