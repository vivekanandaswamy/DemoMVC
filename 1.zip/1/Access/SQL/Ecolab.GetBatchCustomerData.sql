SELECT 
		BatchId,
		CustomerId,
		Weight,
		PiecesCount,
		EcolabWasherId,
		PartitionOn 
FROM TCD.BatchCustomerData 
WHERE BatchId=@BatchID