
IF NOT EXISTS (SELECT 1 FROM TCD.ConduitController WHERE ControllerId = 0 AND EcoalabAccountNumber = @EcolabAccountNumber)
BEGIN
	SET IDENTITY_INSERT TCD.ConduitController ON
	INSERT [TCD].[ConduitController] 
				(	[ControllerId]
				,	[EcoalabAccountNumber]
				,	[TopicName]
				,	[ControllerNumber]
				,	[ControllerModelId]
				,	[ControllerTypeId]
				,	[ControllerVersion]
				,	[InstallDate]
				,	[Description]
				,	[Name]
				,	[Active]
				,	[IsDeleted]
				,	[LastConnectedTime]
				,	[LastModifiedByUserId]) 
	
	VALUES		(	0
				,	@EcolabAccountNumber
				,	N'Default Controller For myService'
				,	4001
				,	1
				,	1
				,	NULL
				,	NULL
				,	N'Dober Ultrax System #3'
				,	N'4001 (Ultrax 6/12/16- Allen Bradley)'
				,	0
				,	0
				,	NULL
				,	0
				)
	
	INSERT [TCD].[ControllerSetupData]
				 (	[ControllerId]
				 ,	[FieldGroupId]
				 ,	[FieldId]
				 ,	[Value]
				 ,	[FieldTagValue]
				 ,	[ControllerModelId]
				 ,	[LastModifiedByUserId]
				 ,	[EcolabAccountNumber]
				 )
	
	VALUES		(0	,6	,56	,N'10'		,NULL	,1	,0	,@EcolabAccountNumber),
				(0	,6	,57	,N'10'		,NULL	,1	,0	,@EcolabAccountNumber),
				(0	,6	,21	,N'10'		,NULL	,1	,0	,@EcolabAccountNumber),
				(0	,6	,58	,N'10'		,NULL	,1	,0	,@EcolabAccountNumber),
				(0	,6	,79	,N'33'		,NULL	,1	,0	,@EcolabAccountNumber),
				(0	,6	,33	,N'false'	,NULL	,1	,0	,@EcolabAccountNumber)
	SET IDENTITY_INSERT TCD.ConduitController OFF
END








