SET NOCOUNT ON;
	DECLARE	@SQLString	NVARCHAR(2000)	=	N''
	
	

	IF (@TableName = 'MachineSetup' OR @TableName = 'ConduitController' OR @TableName = 'TankSetup')
		BEGIN
			SET	@SQLString	=	'SELECT MAX(LastModifiedTime) FROM TCD.'+ @TableName + ' WHERE EcoalabAccountNumber = ''' + @EcolabAccountNumber + ''''
		END
	ELSE IF (@TypeName = 'DryerGroup')
		BEGIN
			SET	@SQLString	=	'SELECT  MAX(LastModifiedTime) FROM TCD.MachineGroup WHERE EcolabAccountNumber = ''' + @EcolabAccountNumber + ''' AND GroupTypeId = 3'
		END
	ELSE IF (@TypeName = 'FinnisherGroup')
		BEGIN
			SET	@SQLString	=	'SELECT  MAX(LastModifiedTime) FROM TCD.MachineGroup WHERE EcolabAccountNumber = ''' +  @EcolabAccountNumber + ''' AND GroupTypeId = 4'
		END
	ELSE IF (@TypeName = 'WasherGroup')
		BEGIN
			SET	@SQLString	=	'SELECT  MAX(LastModifiedTime) FROM TCD.MachineGroup WHERE EcolabAccountNumber = ''' +  @EcolabAccountNumber + ''' AND GroupTypeId = 2'
		END
	ELSE IF (@TypeName = 'ConventionalGeneral')
		BEGIN
			SET	@SQLString	=  'SELECT MAX(w.LastModifiedTime) FROM TCD.Washer w INNER JOIN TCD.MachineSetup mg ON w.WasherId = mg.WasherId AND w.EcoLabAccountNumber = mg.EcoalabAccountNumber WHERE w.EcoLabAccountNumber = '''+  @EcolabAccountNumber +''' AND mg.IsTunnel = 0'
		END
	ELSE IF (@TypeName = 'Tunnel')
		BEGIN
			SET	@SQLString	=  'SELECT MAX(w.LastModifiedTime) FROM TCD.Washer w INNER JOIN TCD.MachineSetup mg ON w.WasherId = mg.WasherId AND w.EcoLabAccountNumber = mg.EcoalabAccountNumber WHERE w.EcoLabAccountNumber = '''+ @EcolabAccountNumber +''' AND mg.IsTunnel = 1'
		END
	ELSE IF (@TypeName = 'PlantId')
		BEGIN
			SET	@SQLString	=	'Declare @PlantId int = 0; SET			@PlantId		=		(	SELECT		PlantId 
										FROM		tcd.Plant 
										WHERE		EcolabAccountNumber			=	'+ char(39) +	@EcolabAccountNumber + char(39) +' ); SELECT MAX(LastModifiedTime) FROM TCD.'+  @TableName +' WHERE PlantId	= ' + '@PlantId'
		END

	ELSE
		BEGIN
			SET	@SQLString	=	'SELECT MAX(LastModifiedTime) FROM TCD.'+ @TableName + ' WHERE EcolabAccountNumber = ''' +  @EcolabAccountNumber +''''
		END

	PRINT @SQLString

	EXEC (@SQLString)
	
SET NOCOUNT OFF;