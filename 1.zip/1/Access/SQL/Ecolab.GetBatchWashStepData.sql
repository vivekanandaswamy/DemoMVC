SELECT 
	WS.BatchId,
	WS.StepCompartment,
	WS.StartTime,
	WS.EndTime ,
	WS.EcolabWasherId,
	WS.PartitionOn
FROM TCD.BatchWashStepData WS
WHERE BatchId=@BatchID