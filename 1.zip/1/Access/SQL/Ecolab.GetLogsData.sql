SELECT		Top 10
			L.Id
		,	L.Date
		,	L.Thread
		,	L.Level
		,	L.Logger
		,	L.Message
		,	L.Exception
		,	L.Source
		,	L.HostName
		
FROM TCD.Logs L 

WHERE L.LastSynctime IS NULL