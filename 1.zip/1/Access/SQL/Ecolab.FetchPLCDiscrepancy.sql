SELECT  cc.ControllerNumber,
	   cc.TopicName AS ControllerName,
	   pd.SyncFromCentral,
	   CAST(pd.ParentEntityType AS INT),
	   CAST(pd.EntityType AS INT),
	   pd.ParentEntityId,
	   pd.EntityId,
	   pd.ControllerId,
	   CASE
		  WHEN pd.ParentEntityType = 1 THEN 'Dispenser Setup'
		  WHEN pd.ParentEntityType = 3 THEN 'Washer group ' + 
								CASE WHEN wg.WasherGroupTypeId = 1 THEN 'Conv.'
								    ELSE 'Tunnel'
								END
		  WHEN pd.ParentEntityType = 4 THEN ms.MachineName		  
		  WHEN pd.ParentEntityType = 7 THEN 'Meters'
		  WHEN pd.ParentEntityType = 8 THEN 'Sensors'		  
	   END AS ParentEntityName,
	   CASE
		  WHEN pd.EntityType = 1 THEN cc.Description
		  WHEN pd.EntityType = 2 THEN 'Devices/' + CASE WHEN ces.ControllerEquipmentTypeId = 1 THEN 'Pump' ELSE 'ME' END + '-' + CAST(ces.ControllerEquipmentId AS NVARCHAR(2))
		  WHEN pd.EntityType = 4 THEN ms.MachineName
		  WHEN pd.EntityType = 5 THEN CAST(tps.ProgramNumber AS VARCHAR) + '-' + pm.Name
		  WHEN pd.EntityType = 6 THEN CAST(wps.ProgramNumber AS VARCHAR) + '-' + pm.Name
		  WHEN pd.EntityType = 7 THEN m.Description
		  WHEN pd.EntityType = 8 THEN s.Description
		  WHEN pd.EntityType = 9 THEN 'Advanced'
	   END AS EntityName,
	   wg.WasherGroupTypeId AS WasherGroupType,
	   CASE WHEN pd.CreatedUserId = 0 THEN 'Sync' ELSE um.FullName END AS UserName
	   FROM TCD.PLCDiscrepancyData pd
	   INNER JOIN TCD.ConduitController cc ON CC.ControllerId = pd.ControllerId
	   LEFT JOIN TCD.UserMaster um ON um.UserId = pd.CreatedUserId
	   LEFT JOIN TCD.ControllerEquipmentSetup ces ON pd.EntityType = 2 AND ces.ControllerEquipmentSetupId = pd.EntityId AND ces.ControllerId = pd.ParentEntityId
	   LEFT JOIN TCD.WasherGroup wg ON pd.ParentEntityType = 3 AND wg.WasherGroupId = pd.ParentEntityId 
	   LEFT JOIN TCD.MachineSetup ms ON pd.EntityType = 4 AND ms.WasherId = pd.EntityId AND ms.GroupId = pd.ParentEntityId
	   LEFT JOIN TCD.WasherProgramSetup wps ON pd.EntityType = 6 AND wps.WasherProgramSetupId = pd.EntityId AND wps.WasherGroupId = pd.ParentEntityId
	   LEFT JOIN TCD.TunnelProgramSetup tps ON pd.EntityType = 5 AND tps.TunnelProgramSetupId = pd.EntityId AND tps.WasherGroupId = pd.ParentEntityId
	   LEFT JOIN TCD.ProgramMaster pm ON pd.EntityType IN (5,6) AND (pm.ProgramId = wps.ProgramId OR pm.ProgramId = tps.ProgramId)
	   LEFT JOIN TCD.Meter m ON pd.EntityType = 7 AND m.MeterId = pd.EntityId
	   LEFT JOIN TCD.Sensor s ON pd.EntityType = 8 AND s.SensorId = pd.EntityId