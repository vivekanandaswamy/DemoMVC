SELECT 
	BP.BatchId,
	BP.EcolabWasherId,
	BP.ParameterId,
	BP.ParameterValue,
	BP.PartitionOn
FROM TCD.BatchParameters BP
WHERE BatchId=@BatchID