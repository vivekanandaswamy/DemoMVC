SELECT 
	PD.BatchId,
	PD.StepCompartment,
	PD.ActualQuantity,
	PD.StandardQuantity,
	PD.Price ,
	PD.EcolabWasherId,
	PD.PartitionOn,
	PD.Timestamp,
	PD.ProductId
FROM TCD.BatchProductData PD
WHERE BatchId=@BatchID