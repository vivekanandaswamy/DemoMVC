SELECT 
    Id, 
    AlarmGroupMsterVsControllerModelTypeId, 
    Active, 
    MachineNumber, 
    LastModifiedTime, 
	WasherId,
    EcolabAccountNumber
FROM TCD.AlarmStatus 
WHERE EcolabAccountNumber = @EcolabAccountNumber