SELECT TOP (@RecordCount)	
		 AD.Id,
		 AD.EcoalabAccountNumber,
		 AD.AlarmCode,
		 AD.ControllerId,
		 AD.StartDate,
		 AD.GroupId,
		 AD.MachineInternalId,
		 AD.ProgramId,
		 AD.MENumber,
		 AD.BatchId,
		 AD.Valve,
		 AD.InjectionNumber,
		 AD.MachineId,
		 AD.IsActive,
		 AD.EndDate,
		 AD.DesiredQuatity,
		 AD.MeasuredQuantity,
		 AD.TempStatus,
		 AD.ProbeNumber,
		 AD.UserId,
		 AD.StepId,
		 AD.PartitionOn,
		 AD.LastSyncTime,
		 AD.AlarmGroupMasterId
	 FROM TCD.AlarmData AD 
	WHERE AD.EndDate IS NOT NULL AND AD.LastSyncTime IS NULL AND AD.AlarmGroupMasterId IS NOT NULL
	AND AD.PartitionOn IS NOT NULL