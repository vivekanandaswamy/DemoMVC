DECLARE		@ErrorId						INT				=			0



IF EXISTS	(	SELECT		1	
				FROM		[TCD].[AlarmGroupMaster] agm 
				WHERE		[AlarmGroupMasterId]	=			@Id
			)
BEGIN

	UPDATE	[TCD].[AlarmGroupMaster]
	SET		
		Description = @Description, 		
		IsDelete = @IsDelete,
		WasherType = @WasherType,
		IsHoldCondition = @IsHoldCondition,
		AlarmNumber =  @AlarmNumber
	WHERE AlarmGroupMasterId = @Id
	
	SET		@ErrorId	=	@@ERROR

END

ELSE

BEGIN

	INSERT INTO [TCD].[AlarmGroupMaster]
	(		
		[AlarmGroupMasterId]
		,[DESCRIPTION]
		,[ResourceKey]		
		,[IsDelete]
		,[WasherType]
		,[IsHoldCondition]
		,[AlarmNumber]
	)
	VALUES
	(
			@Id
		,	@Description
		,	@ResourceKey		
		,	@IsDelete
		,	@WasherType
		,	@IsHoldCondition
		,	@AlarmNumber
	)

SET		@ErrorId	=	@@ERROR

END

IF EXISTS(	SELECT		1	
				FROM		[TCD].[AlarmGroupMsterVsControllerModelType] AGM_V_CMT
				WHERE		[AlarmGroupMsterVsControllerModelTypeId]	=			@AlarmMachineMappingId
			)
BEGIN

UPDATE [TCD].[AlarmGroupMsterVsControllerModelType]
SET
    
    AlarmCode = @AlarmCode,
    ControllerModelTypeId = @ControllerModelTypeId,
	IsDelete = @IsDeleteAlarmMapping,
	AlarmGroupMasterId = @Id,
	MACHINENUMBER = @MachineNumber
WHERE [AlarmGroupMsterVsControllerModelTypeId]		=			@AlarmMachineMappingId

END

ELSE
BEGIN

INSERT INTO [TCD].[AlarmGroupMsterVsControllerModelType]
(
		[AlarmGroupMsterVsControllerModelTypeId],
		[AlarmCode],
		[ControllerModelTypeId],
		[IsDefault],
		[IsDelete],
		[AlarmGroupMasterId],
		[MachineNumber]
)
VALUES
(
	@AlarmMachineMappingId,
    @AlarmCode,
	@ControllerModelTypeId,
	@IsDefault,
	@IsDeleteAlarmMapping,
	@Id,
	@MachineNumber
)

END

SET		@ErrorId	=	@@ERROR

Select @ErrorId