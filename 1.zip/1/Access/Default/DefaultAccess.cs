﻿// -----------------------------------------------------------------------
// <copyright file="DefaultAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Default Access class </summary>
// -----------------------------------------------------------------------

namespace Access.Default
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities;
    using Entities.Default;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     DefaultAccess Class
    /// </summary>
    public class DefaultAccess
    {
        /// <summary>
        /// Insert User PortletData
        /// </summary>
        /// <param name="portlet">The portlet.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="trans">The Trans parameter.</param>
        /// <param name="context">The Context parameter.</param>
        /// <param name="userId">The user id</param>
        /// <param name="count">The count.</param>
        /// <returns>
        /// Returns The string.
        /// </returns>
        public static string CreateUserPortletData(Portlet portlet, string ecolabAccountNumber, ref DbTransaction trans, ref DbContext context, int userId, int count)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;
            string status = DbClient.ExecuteScalar<string>(trans, context, Resources.Ecolab_SaveUserPortlets, delegate(DbCommand cmd, DbContext context2)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("PortletId", portlet.PortletId);
                cmd.AddParameter("DisplayOrder", portlet.DisplayOrder);
                cmd.AddParameter("IsEnabled", portlet.IsEnabled);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("Count", count);
                cmd.Parameters.Add(param);
            });
            status = Convert.IsDBNull(param.Value) ? null : (string)param.Value;
            return status;
        }

        /// <summary>
        ///     Fetches the Portlets based on the User
        /// </summary>
        /// <param name="userId">The parameter to get portlets by userid</param>
        /// <returns>The list of Portlets based on user</returns>
        public static List<Portlet> FetchPortletsByUser(int userId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Portlet>(Resources.Ecolab_GetPortletsByUser, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        ///     gets the shift summary details
        /// </summary>
        /// <returns>ShiftSummary object</returns>
        public static ShiftSummary FetchShiftSummary()
        {
            return DbClient.ExecuteReader<ShiftSummary>(Resources.Ecolab_GetShiftSummaryDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;               
            }).FirstOrDefault();
        }
    }
}