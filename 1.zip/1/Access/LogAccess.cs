﻿// -----------------------------------------------------------------------
// <copyright file="LogAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Log Access class.</summary>
// -----------------------------------------------------------------------
namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Access.Properties;
    using Entities;
    using Nalco.Data.Common;

    public class LogAccess
    {
        /// <summary>
        ///     Gets the Batch Collection Details
        /// </summary>
        /// <returns>the Batch Collection Details</returns>
        public static List<Logs> GetLogsData()
        {
            return DbClient.ExecuteReader<Logs>(Resources.Ecolab_GetLogsData,
                                               delegate(DbCommand cmd, DbContext context)
                                               {
                                                   cmd.CommandType = CommandType.Text;
                                               }).ToList();
        }
    }
}
