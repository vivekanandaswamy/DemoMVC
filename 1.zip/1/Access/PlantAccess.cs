﻿// -----------------------------------------------------------------------
// <copyright file="PlantAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.Common;
	using System.Data.SqlClient;
	using System.Linq;
	using System.Text.RegularExpressions;
	using Entities;
    using Entities.Common;
    using Nalco.Data.Common;
	using Properties;
 
	/// <summary>
	///     class PlantAccess
	/// </summary>
	public class PlantAccess
	{
        /// <summary>
        /// Gets the Plant details
        /// </summary>
        /// <param name="userId">Parameter User Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Row of Plant details
        /// </returns>
        public static Plant GetPlantDetails(int userId, string ecolabAccountNumber = "")
		{
            return DbClient.ExecuteReader<Plant>(Resources.Ecolab_GetPlantDetailsByUserId, delegate (DbCommand cmd, DbContext context)
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("UserId", userId);
					cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				}).FirstOrDefault();
		}

        /// <summary>
        /// Gets the Plant UOM details
        /// </summary>
        /// <param name="userId">Parameter User Id</param>
        /// <param name="unitSystemId">The unit system identifier.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// List of UOM details
        /// </returns>
        public static List<UOMSubUnit> GetPlantUomSubunits(int userId, int unitSystemId, string ecolabAccountNumber = "")
		{
            return DbClient.ExecuteReader<UOMSubUnit>(Resources.Ecolab_GetPlantUOMSubUnits, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("UserId", userId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				cmd.AddParameter("UOMID", unitSystemId);
			}).ToList();
		}

        /// <summary>
        /// Gets the Plant details
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Row of Plant details
        /// </returns>
        public static Plant GetPlantDetails(string ecolabAccountNumber = "")
		{
            return DbClient.ExecuteReader<Plant>(Resources.Ecolab_GetPlant, delegate (DbCommand cmd, DbContext context)
				{
					cmd.CommandType = CommandType.StoredProcedure;
                    if (!string.IsNullOrEmpty(ecolabAccountNumber))
					{
						cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
					}
				}).FirstOrDefault();
		}

        /// <summary>
        /// Save/Update Plant details.
        /// </summary>
        /// <param name="plant">Plant object</param>
        /// <param name="userId">Plant user ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>
        /// Returns The EcolabAccount Number.
        /// </returns>
        public static string SavePlantDetails(Plant plant, int userId, out DateTime lastModifiedTimestamp)
		{
			string returnValue = string.Empty;
			lastModifiedTimestamp = DateTime.Now;

			byte[] imglogo = null;
            if (!string.IsNullOrEmpty(plant.Logo))
			{
				imglogo = Convert.FromBase64String(plant.Logo.Substring(plant.Logo.IndexOf(',') + 1));
			}
			SqlParameter paramEcolabAccountNumber = new SqlParameter { ParameterName = "OutputEcolabAccountNumber", SqlDbType = SqlDbType.VarChar, Size = 1000, Direction = ParameterDirection.Output };
			SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlant, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plant.EcoalabAccountNumber);
				cmd.AddParameter("LanguageId", plant.LanguageId);
				cmd.AddParameter("CurrencyCode", DbType.String, 255, plant.CurrencyCode);
				cmd.AddParameter("Rate", plant.Rate);
				cmd.AddParameter("ExportPath", DbType.String, 1000, plant.ExportPath);
				cmd.AddParameter("DataLiveTime", plant.DataLiveTime);
				cmd.AddParameter("BudgetCustomer", plant.BudgetCustomer);
				cmd.AddParameter("UOMId", plant.UomId);
				cmd.AddParameter("Logo", DbType.Binary, imglogo != null ? imglogo.Length : 0, imglogo);
				cmd.AddParameter("UserId", userId);
				cmd.AddParameter("AllowManualRewash", plant.AllowManualRewash);
                if (plant.LastModifiedTimestampAtCentral.HasValue)
				{
					cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, plant.LastModifiedTimestampAtCentral.Value);
				}
                cmd.AddParameter("DayId", plant.DayId);
                cmd.AddParameter("StartTime", plant.StartTime);
                cmd.AddParameter("EndTime", plant.EndTime);
                cmd.AddParameter("EtechIpAddress", DbType.String, 100, plant.EtechIpAddress);
                cmd.AddParameter("IsETechEnable", plant.IsETechEnable);
                cmd.Parameters.Add(paramEcolabAccountNumber);
				cmd.Parameters.Add(paramLastModifiedTimeStamp);
			});
			lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
			returnValue = Convert.IsDBNull(paramEcolabAccountNumber.Value) ? "0" : paramEcolabAccountNumber.Value.ToString();

			return returnValue;
		}

        /// <summary>
        /// Gets the Plant contact List using name
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Max Record Count
        /// </returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
		{
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate (DbCommand cmd, DbContext context)
				{
					cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
					cmd.AddParameter("TableName", DbType.String, 1000, "TCD.Plant");
				});
		}

        /// <summary>
        /// Check For Connected Plant(Only for Central).
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// true/false.
        /// </returns>
        public static bool IsConnectedPlant(string ecolabAccountNumber)
		{
            return DbClient.ExecuteScalar<bool>(Resources.Ecolab_CheckForConnectedPlant, delegate (DbCommand cmd, DbContext context)
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				});
		}

        /// <summary>
        /// validate plant for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>
        /// success/failure
        /// </returns>
        public static int ValidatePlantSave(string ecolabAccountNumber, int maxNumberOfRecords)
		{
			int returnValue;
			try
			{
                returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidatePlantSave, delegate (DbCommand cmd, DbContext context)
				 {
					 cmd.CommandType = CommandType.StoredProcedure;
					 cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
					 cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
				 });
			}
            catch (Exception ex)
			{
				returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
			}
			return returnValue;
		}

        /// <summary>
        /// GetPlantSettings
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>plant settings</returns>
		public static PlantSetting GetPlantSettings(string ecolabAccountNumber)
		{
            return DbClient.ExecuteReader<PlantSetting>("TCD.GetplantSettings", delegate (DbCommand cmd, DbContext context)
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				}).FirstOrDefault();
		}

        /// <summary>
        /// Insert or update myservice plant details
        /// </summary>
        /// <param name="plant">The plant.</param>
        /// <param name="userId">userId</param>
        /// <returns>success/failure</returns>
        public static int SaveMyServicePlantDetails(Plant plant, int userId)
		{
			return DbClient.ExecuteScalar<int>(
			   Resources.Ecolab_UpdateMyServicePlantDetails,
               delegate (DbCommand cmd, DbContext context)
			   {
				   cmd.CommandType = CommandType.StoredProcedure;
                   cmd.AddParameter("PlantId", plant.PlantId);
				   cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plant.EcoalabAccountNumber);
				   cmd.AddParameter("Name", DbType.String, 1000, plant.Name);
				   cmd.AddParameter("DataLiveTime", plant.DataLiveTime);
				   cmd.AddParameter("BudgetCustomer", plant.BudgetCustomer);
				   cmd.AddParameter("ExportPath", DbType.String, 1000, plant.ExportPath);
				   cmd.AddParameter("LanguageId", 1); ////TODO: Modify for other languages.
				   cmd.AddParameter("CurrencyCode", DbType.String, 255, plant.CurrencyCode);
				   cmd.AddParameter("PlantCategoryId", plant.PlantCategoryId);
				   cmd.AddParameter("AcutalIsTarget", plant.AcutalIsTarget);
				   cmd.AddParameter("PlantChainId", plant.PlantChainId);
				   cmd.AddParameter("TMName", DbType.String, 255, plant.TmName);
				   cmd.AddParameter("TMPhoneNumber", DbType.String, 255, plant.TmPhoneNumner);
				   cmd.AddParameter("DMName", DbType.String, 255, plant.DmName);
				   cmd.AddParameter("DMPhoneNumber", DbType.String, 255, plant.DmPhoneNumner);
				   cmd.AddParameter("ChainUnitNumber", DbType.String, 255, plant.ChainUnitNumber);
				   cmd.AddParameter("CensusPriceKg", plant.CensusPriceKg);
				   cmd.AddParameter("Remarks", DbType.String, 255, plant.Remarks);
				   cmd.AddParameter("Rate", plant.Rate);
				   cmd.AddParameter("AllowManualRewash", plant.AllowManualRewash);
				   cmd.AddParameter("IsDelete", plant.IsDelete);
				   cmd.AddParameter("MyServiceCustGuid", plant.MyServiceCustGuid);
				   cmd.AddParameter("UserId", userId);
				   cmd.AddParameter("RegionCode", DbType.String, 255, plant.RegionCode);
				   cmd.AddParameter("RegionId", plant.RegionId);
				   cmd.AddParameter("UOMDesc", DbType.String, 100, plant.UOMDesc);
				   cmd.AddParameter("UOMId", plant.UomId);
				   cmd.AddParameter("PlantContractNumber", DbType.String, 100, plant.PlantContractNumber);
                   cmd.AddParameter("DayId", plant.DayId);
                   cmd.AddParameter("StartTime", plant.StartTime);
                   cmd.AddParameter("IsEtechEnable", plant.IsETechEnable);
                   cmd.AddParameter("EtechIpAddress", DbType.String, 25, plant.EtechIpAddress);
				   cmd.AddParameter("LastServiceVisitDate", DbType.DateTime, plant.LastServiceVisitDate == DateTime.MinValue ? null : plant.LastServiceVisitDate);
				   cmd.AddParameter("NextServiceVisitDate", DbType.DateTime, plant.NextServiceVisitDate == DateTime.MinValue ? null : plant.NextServiceVisitDate);
                   cmd.AddParameter("SourceSystemCode", DbType.String, 25, plant.SourceSystemCode);
                   cmd.AddParameter("SourceSystemId", plant.SourceSystemId);
               });
		}

        /// <summary>
        /// Gets the Plant details
        /// </summary>
        /// <returns>
        /// List of plant
        /// </returns>
        public static List<Plant> GetPlantDetails()
		{
			return DbClient.ExecuteReader<Plant>(Resources.Ecolab_GetPlant,
                    delegate (DbCommand cmd, DbContext context)
					{
						cmd.CommandType = CommandType.StoredProcedure;
					}).ToList();
		}

        /// <summary>
        /// Save myservice plant Address in conduit
        /// </summary>
        /// <param name="myservicePlantAddress">The myservice plant address.</param>
        public static void SaveMyServicePlantAddress(PlantCustomerAddress myservicePlantAddress)
		{
			DbClient.ExecuteNonQuery(
			   Resources.Ecolab_UpdateMyServicePlantAddress,
               delegate (DbCommand cmd, DbContext context)
			   {
				   cmd.CommandType = CommandType.StoredProcedure;
				   cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, myservicePlantAddress.EcolabAccountNumber);
				   cmd.AddParameter("BillingAddr1", DbType.String, 1000, myservicePlantAddress.BillingAddr1);
				   cmd.AddParameter("BillingAddr2", DbType.String, 1000, myservicePlantAddress.BillingAddr2);
				   cmd.AddParameter("City", DbType.String, 1000, myservicePlantAddress.City);
				   cmd.AddParameter("Country", DbType.String, 1000, string.IsNullOrEmpty(myservicePlantAddress.Country) ? myservicePlantAddress.Shippingcountry : myservicePlantAddress.Country);
				   cmd.AddParameter("Zip", DbType.String, 1000, myservicePlantAddress.Zip);
				   cmd.AddParameter("ShippingAddr1", DbType.String, 1000, myservicePlantAddress.ShippingAddr1);
				   cmd.AddParameter("ShippingAddr2", DbType.String, 1000, myservicePlantAddress.ShippingAddr2);
				   cmd.AddParameter("Shippingcity", DbType.String, 1000, myservicePlantAddress.Shippingcity);
				   cmd.AddParameter("Shippingcountry", DbType.String, 1000, string.IsNullOrEmpty(myservicePlantAddress.Shippingcountry) ? myservicePlantAddress.Country : myservicePlantAddress.Shippingcountry);
				   cmd.AddParameter("Shippingzip", DbType.String, 1000, myservicePlantAddress.Shippingzip);
			   });
		}

        /// <summary>
        /// Save myservice plant Address in conduit
        /// </summary>
        /// <param name="plant">The plant.</param>
        public static void SaveMyServicePlantAddress(Plant plant)
        {
            DbClient.ExecuteNonQuery(
               Resources.Ecolab_UpdateMyServicePlantAddress,
               delegate (DbCommand cmd, DbContext context)
               {
                   cmd.CommandType = CommandType.StoredProcedure;
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plant.EcoalabAccountNumber);
                   cmd.AddParameter("BillingAddr1", DbType.String, 1000, plant.PlantCustAddr.BillingAddr1);
                   cmd.AddParameter("BillingAddr2", DbType.String, 1000, plant.PlantCustAddr.BillingAddr2);
                   cmd.AddParameter("City", DbType.String, 1000, plant.PlantCustAddr.City);
                   cmd.AddParameter("Country", DbType.String, 1000, plant.PlantCustAddr.Country);
                   cmd.AddParameter("Zip", DbType.String, 1000, plant.PlantCustAddr.Zip);
                   cmd.AddParameter("ShippingAddr1", DbType.String, 1000, plant.ShippingAddr.ShippingAddr1);
                   cmd.AddParameter("ShippingAddr2", DbType.String, 1000, plant.ShippingAddr.ShippingAddr2);
                   cmd.AddParameter("Shippingcity", DbType.String, 1000, plant.ShippingAddr.Shippingcity);
                   cmd.AddParameter("Shippingcountry", DbType.String, 1000, plant.ShippingAddr.Shippingcountry);
                   cmd.AddParameter("Shippingzip", DbType.String, 1000, plant.ShippingAddr.Shippingzip);
               });
        }

        /// <summary>
        /// Inserts the update plant settings.
        /// </summary>
        /// <param name="plantSetting">The plant setting.</param>
        public static void InsertUpdatePlantSettings(PlantSetting plantSetting)
        {
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_InsertUpdatePlantSettings,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.Text;
                  cmd.AddParameter("PlantId", DbType.String, 25, plantSetting.EcolabAccountNumber);
                  cmd.AddParameter("FTRLastModifiedTime", DbType.DateTime, plantSetting.FtrLastModifiedTime == DateTime.MinValue ? DateTime.UtcNow : plantSetting.FtrLastModifiedTime);
                  cmd.AddParameter("PlantVersion", DbType.String, 25, plantSetting.PlantVersion);
              });
        }

        /// <summary>
        /// GetPlantLocalTimeZone
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <returns>
        /// plant details
        /// </returns>
		public static Plant GetPlantLocalTimeZone(string ecolabAccountNumber)
		{
			return DbClient.ExecuteReader<Plant>("[TCD].[GetLocalPlantTimeZone]",
                   delegate (DbCommand cmd, DbContext context)
				   {
					   cmd.CommandType = CommandType.StoredProcedure;
					   cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				   }).FirstOrDefault();
		}

        /// <summary>
        /// Save plant Settings
        /// </summary>
        /// <param name="plantSetting">plantSetting</param>
        /// <returns>true/false</returns>
        public static bool SavePlantSettings(PlantSetting plantSetting)
		{
			return DbClient.ExecuteScalar<bool>(
			   Resources.Ecolab_SavePlantSettings,
               delegate (DbCommand cmd, DbContext context)
			   {
				   cmd.CommandType = CommandType.StoredProcedure;
				   cmd.AddParameter("PlantId", DbType.String, 25, plantSetting.EcolabAccountNumber);
				   cmd.AddParameter("IPAddress", DbType.String, 1000, plantSetting.IpAddress);
				   cmd.AddParameter("PortNumber", DbType.String, 1000, plantSetting.PortNumber);
                   cmd.AddParameter("PlantVersion", DbType.String, 25, plantSetting.PlantVersion);
			   });
		}

        /// <summary>
        /// Update Plant Settings
        /// </summary>
        /// <param name="plantSetting">plantSetting</param>
        /// <returns>
        /// boolean value
        /// </returns>
        public static bool UpdatePlantSettings(PlantSetting plantSetting)
		{
			return DbClient.ExecuteScalar<bool>(
			   Resources.Ecolab_UpdatePlantSettings,
               delegate (DbCommand cmd, DbContext context)
			   {
				   cmd.CommandType = CommandType.Text;
				   cmd.AddParameter("PlantVersion", DbType.String, 1000, plantSetting.PlantVersion);
			   });
		}

        /// <summary>
        /// Save plant Settings
        /// </summary>
        /// <param name="plantSetting">plantSetting</param>
        /// <param name="iterator">The iterator.</param>
        public static void UpdateFtrModifiedTime(PlantSetting plantSetting, int iterator)
		{
			DbClient.ExecuteNonQuery(
			  Resources.Ecolab_UpdateFTRModifiedTime,
              delegate (DbCommand cmd, DbContext context)
			  {
				  cmd.CommandType = CommandType.StoredProcedure;
				  cmd.AddParameter("PlantId", DbType.String, 25, plantSetting.EcolabAccountNumber);
                  cmd.AddParameter("FTRLastModifiedTime", DbType.DateTime, plantSetting.FtrLastModifiedTime == DateTime.MinValue ? null : plantSetting.FtrLastModifiedTime);
                  cmd.AddParameter("Iterator", iterator);
			  });
		}

        /// <summary>
        /// Update Node Id generated from TLA.Nodes
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        /// <param name="nodeId">Node Id</param>
        /// <param name="lastModifiedTime">last Modified time</param>
		public static void UpdateNodeId(string ecolabAccountNumber, int nodeId, DateTime lastModifiedTime)
		{
			DbClient.ExecuteScalar<bool>(
			  Resources.Ecolab_UpdateNodeIdInPlantSettings,
              delegate (DbCommand cmd, DbContext context)
			  {
				  cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				  cmd.AddParameter("NodeId", nodeId);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, lastModifiedTime);
              });
        }

        /// <summary>
        /// Run post migration script
        /// </summary>
        public static void RunPostMigrationScript()
        {
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_PostMigrationScript,
              delegate (DbCommand cmd, DbContext context)
              {
			  });
		}

        /// <summary>
        /// Fetches the missing Fieldss
        /// </summary>
        /// <param name="ecolabAccNumber">The Ecolab Account Number</param>
        /// <returns>
        /// List of missing fields
        /// </returns>
        public static List<MissingFields> FetchMissingFields(string ecolabAccNumber)
		{
			return DbClient.ExecuteReader<MissingFields>(Resources.Ecolab_GetMissingFields,
                   delegate (DbCommand cmd, DbContext context)
				   {
					   cmd.CommandType = CommandType.StoredProcedure;
					   cmd.AddParameter("EcolabAccNumber", DbType.String, 250, ecolabAccNumber);
					   
				   }).ToList();
		}

        /// <summary>
        /// Generate Alarm For Software Update failure
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
		public static void GenerateAlarmForSoftwareUpdate(string ecolabAccountNumber)
        {
            DbClient.ExecuteScalar<bool>(Resources.Ecolab_GenerateAlarm, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("IsActive", true);
            });
        }

        /// <summary>
        /// SaveSoftwareUpdateDetails
        /// </summary>
        /// <param name="versionNumber">versionNumber</param>
        /// <param name="isSuccess">isSuccess</param>
        public static void SaveSoftwareUpdateDetails(string versionNumber, bool isSuccess)
        {
            DbClient.ExecuteScalar<bool>(Resources.Ecolab_SaveSoftwareUpdateHistory, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("VersionNumber", DbType.String, 1000, versionNumber);
                cmd.AddParameter("IsSuccess", isSuccess);
            });
        }

        /// <summary>
        /// Saves the PLC Discrepancy Model
        /// </summary>
        /// <param name="plcDiscrepancyModel">The PLC Discrepancy Model</param>
        public static void SavePLCDiscrepancy(PLCDiscrepancyModel plcDiscrepancyModel)
        {
            DbClient.ExecuteScalar<bool>(Resources.Ecolab_SavePLCDiscrepancy, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ParentEntityType", plcDiscrepancyModel.ParentEntity);
                cmd.AddParameter("EntityType", plcDiscrepancyModel.Entity);
                cmd.AddParameter("ParentEntityId", plcDiscrepancyModel.ParentEntityId);
                cmd.AddParameter("EntityId", plcDiscrepancyModel.EntityId);
                cmd.AddParameter("SyncFromCentral", plcDiscrepancyModel.IsCentral);
                cmd.AddParameter("ControllerId", plcDiscrepancyModel.ControllerId);
                cmd.AddParameter("SyncToPlc", !plcDiscrepancyModel.IsPLCError);
                cmd.AddParameter("UserId", plcDiscrepancyModel.UserId);
                cmd.AddParameter("LastModifiedTime", DbType.String, 200, DateTime.Now.ToString());
            });
        }

        /// <summary>
        /// Gets the all Plants in central
        /// </summary>
        /// <returns>List of Plants</returns>
        public static List<PlantSynch> GetPlants()
        {
            return DbClient.ExecuteReader<PlantSynch>(Resources.Ecolab_GetPlants,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = CommandType.Text;
                    }).ToList();
        }
        
        /// <summary>
        /// validate plant for sync.public static List<string> GetTMUsers(int PlantId)
        /// </summary>
        /// <param name="plantId">plantId</param>
        /// <param name="syncLapseTime">Sync Lapse Time</param>
        /// <returns> success/failure </returns>
        public static int CheckPlantSynch(int plantId, int syncLapseTime)
        {
            int returnValue = 0;
                returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidatePlantSynch, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.AddParameter("PlantId", plantId);
                    cmd.AddParameter("SyncLapseTime", syncLapseTime);
                });
            
            return returnValue;
        }

        /// <summary>
        /// validate plant for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="syncLapseTime">Sync Lapse Time</param>
        /// <returns>Returns Integer value</returns>
        public static int CheckPlantSynch(string ecolabAccountNumber, int syncLapseTime)
        {
            int returnValue = 0;
            returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidatePlantSynchConfigurator, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 100, ecolabAccountNumber);
                    cmd.AddParameter("SyncLapseTime", syncLapseTime);
                });
            
            return returnValue;
        }

        /// <summary>
        /// Get TM Users list
        /// </summary>
        /// <param name="PlantId">The Plant Identifier</param>
        /// <returns>List of TM Users</returns>
        public static List<string> GetTMUsers(int plantId)
        {
            List<string> result = DbClient.ExecuteReader<string>(Resources.Ecolab_TMUsersList,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.AddParameter("PlantId", plantId);
                }).ToList();

                return result;
            
        }
    }
}