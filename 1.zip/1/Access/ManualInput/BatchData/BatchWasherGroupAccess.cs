﻿// -----------------------------------------------------------------------
// <copyright file="BatchWasherGroupAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  BatchWasherGroup Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput.BatchData
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.ManualInput;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for BatchWasherGroupAccess
    /// </summary>
    public class BatchWasherGroupAccess
    {
        /// <summary>
        ///     Get the Washer group details by selected date
        /// </summary>
        /// <param name="selectedDate">selected date</param>
        /// <param name="ecolabAccNum">Ecolab Account Number</param>
        /// <returns> The list of washer groups </returns>
        public static IEnumerable<GroupType> FetchBatchWasherGroupBySelectedDate(DateTime selectedDate, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<GroupType>(Resources.Ecolab_GetWasherGroupsByBatchDate, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("BatchDate", DbType.DateTime, selectedDate.Date);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            }).ToList();
        }

        /// <summary>
        /// Get the Washer group details by selected date
        /// </summary>
        /// <param name="ecolabAccNum">Ecolab Account Number</param>
        /// <returns>
        /// The list of washer groups
        /// </returns>
        public static IEnumerable<Entities.WasherGroup.WasherGroup> FetchBatchWasherGroups(string ecolabAccNum)
		{
			return DbClient.ExecuteReader<Entities.WasherGroup.WasherGroup>(Resources.Ecolab_GetWasherGroupDetails, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("WasherGroupId", -1);
            }).ToList();
		}
    }
}