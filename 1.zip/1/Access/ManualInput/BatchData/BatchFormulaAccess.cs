﻿// -----------------------------------------------------------------------
// <copyright file="BatchFormulaAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  BatchFormula Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput.BatchData
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
	using System.Linq;
    using Entities.ManualInput;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for BatchFormulaAccess
    /// </summary>
    public class BatchFormulaAccess
    {
        /// <summary>
        ///     Get the formula details
        /// </summary>
        /// <param name="groupTypeId">groupTypeId</param>
        /// <param name="ecolabAccNum">Ecolab account Number</param>
        /// <returns>list of formulas by group id</returns>
        public static IEnumerable<WashProgramSetup> FetchBatchFormulasByGroupId(int groupTypeId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<WashProgramSetup>(Resources.Ecolab_GetBatchFormulasByGroupId, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("GroupId", groupTypeId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            });
		}

		#region NewMethods

		/// <summary>
		///     Get the formula details
		/// </summary>
		/// <param name="groupTypeId">groupTypeId</param>
		/// <param name="ecolabAccNum">Ecolab account Number</param>
		/// <returns>list of formulas by group id</returns>
		public static IEnumerable<WashProgramSetup> FetchBatchFormulasByGroupId(string groupTypeId, string ecolabAccNum)
		{
			return DbClient.ExecuteReader<WashProgramSetup>(Resources.Ecolab_GetBatchFormulasByGroupId, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("GroupId",DbType.String,1000, groupTypeId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
			});
		}

		#endregion
	}
}