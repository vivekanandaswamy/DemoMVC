﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatchDataAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualBatchData Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput.BatchData
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.Common;
	using System.Data.SqlClient;
	using System.Linq;
	using Entities.ManualInput;
	using Nalco.Data.Common;
	using Properties;

	/// <summary>
	///     Access class for ManualBatchDataAccess
	/// </summary>
	public class ManualBatchDataAccess
	{
        /// <summary>
        /// Get the Batchdata by groupTypeId washerId and programId
        /// </summary>
        /// <param name="groupTypeId">The Parameter groupTypeId</param>
        /// <param name="washerId">The washer id.</param>
        /// <param name="programId">the program id.</param>
        /// <param name="startDate">The start date.</param>
        /// <param name="ecolabAccNum">The Parameter Ecolab account Number</param>
        /// <returns>
        /// list of formulas by group id
        /// </returns>
        public static IEnumerable<ManualBatchData> FetchBatchByGroupId(int groupTypeId, int washerId, int programId, DateTime startDate, string ecolabAccNum)
		{
			return DbClient.ExecuteReader<ManualBatchData>(Resources.Ecolab_GetBatchByGroupId, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("GroupId", groupTypeId);
				cmd.AddParameter("MachineId", washerId);
				cmd.AddParameter("ProgramId", programId);
				cmd.AddParameter("StartDate", DbType.DateTime, startDate);			

			});
		}

		/// <summary>
		///     Get the Batchdata by batch time
		/// </summary>
		/// <param name="batchId">The Parameter  batch Id.</param>
		/// <param name="ecolabAccNum">Ecolab account Number</param>
		/// <returns>list of formulas by group id</returns>
		public static ManualBatchData FetchBatchDetailsByBatchId(int batchId, string ecolabAccNum)
		{
			return DbClient.ExecuteReader<ManualBatchData>(Resources.Ecolab_GetBatchDetailsByBatchId, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("BatchId", batchId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
			}).FirstOrDefault();
		}

		/// <summary>
		///     Update manual batch data details
		/// </summary>
		/// <param name="manualBatchData">manual batch data.</param>
		/// <param name="ecolabAccNum">Ecolab account number</param>
		/// <param name="userId">The Parameter user id</param>
		/// <returns>success/failure message code</returns>
		public static string UpdateManualRewash(ManualBatchData manualBatchData, string ecolabAccNum, int userId)
		{
			SqlParameter param = new SqlParameter();
			param.ParameterName = "Scope";
			param.SqlDbType = SqlDbType.VarChar;
			param.Size = 100;
			param.Direction = ParameterDirection.Output;

			DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateManualBatchData, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("BatchId", manualBatchData.Id);
				cmd.AddParameter("ActualWeight", manualBatchData.ActualWeight);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
				cmd.AddParameter("UserId", userId);
				cmd.Parameters.Add(param);
			});
			return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
		}

		/// <summary>
		///     Gets the latets batch  date.
		/// </summary>
		/// <param name="ecolabAccNum">Ecolab account number.</param>
		/// <returns>the latest batch run date.</returns>
		public static ManualBatchData GetManualBatchDate(string ecolabAccNum)
		{
			return DbClient.ExecuteReader<ManualBatchData>(Resources.Ecolab_GetManualInputBatchDate, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("EcoalabWasherId", DbType.String, 100, ecolabAccNum);
			}).FirstOrDefault();
		}

        #region newMethods

        /// <summary>
        /// Get the Batchdata by groupTypeId washerId and programId
        /// </summary>
        /// <param name="groupTypeId">The Parameter groupTypeId</param>
        /// <param name="washerId">The washer id.</param>
        /// <param name="programId">the program id.</param>
        /// <param name="startDate">The start date.</param>
        /// <param name="rowsPerPage">The rows per page.</param>
        /// <param name="pageNumber">The page number.</param>
        /// <returns>
        /// list of formulas by group id
        /// </returns>
        public static IEnumerable<ManualBatchData> FetchBatchData(string groupTypeId, int washerId, int programId, DateTime startDate, int rowsPerPage, int pageNumber)
        {
			return DbClient.ExecuteReader<ManualBatchData>(Resources.Ecolab_GetBatchByGroupId, delegate (DbCommand cmd, DbContext context)
            {
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("GroupId", DbType.String, 1000, groupTypeId);
				cmd.AddParameter("MachineId", washerId);
				cmd.AddParameter("ProgramId", programId);
				cmd.AddParameter("StartDate", DbType.DateTime, startDate);
                cmd.AddParameter("RowsPerPage", rowsPerPage);
				cmd.AddParameter("PageNumber", pageNumber);
			});
		}

		public static IEnumerable<ManualBatchData> FetchDispencerRecordedLoads(string groupTypeId, int washerId, int programId, DateTime startDate, int rowsPerPage, int pageNumber)
		{
			return DbClient.ExecuteReader<ManualBatchData>(Resources.Ecolab_GetDispencerRecordedLoads, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("GroupId", DbType.String, 1000, groupTypeId);
				cmd.AddParameter("MachineId", washerId);
				cmd.AddParameter("ProgramId", programId);
				cmd.AddParameter("StartDate", DbType.DateTime, startDate.Date);
				cmd.AddParameter("RowsPerPage", rowsPerPage);
				cmd.AddParameter("PageNumber", pageNumber);
				cmd.AddParameter("EndDate", DbType.DateTime, startDate.Date.AddDays(1).AddSeconds(-1));
			});
		}

		#endregion newMethods
	}
}