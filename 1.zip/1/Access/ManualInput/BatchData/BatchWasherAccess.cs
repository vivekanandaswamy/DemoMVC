﻿// -----------------------------------------------------------------------
// <copyright file="BatchWasherAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  BatchWasher Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput.BatchData
{
	using System.Collections.Generic;
	using System.Data;
	using System.Data.Common;
	using System.Linq;
	using Entities.PlantSetup;
	using Nalco.Data.Common;
	using Properties;
	using Entities;

	/// <summary>
	///     Access class for BatchWasherAccess
	/// </summary>
	public class BatchWasherAccess
	{
		/// <summary>
		///     Get the washer details
		/// </summary>
		/// <param name="groupTypeId">washer group id</param>
		/// <param name="ecolabAccNum">Ecolab account Number</param>
		/// <returns>The list of washers by group id</returns>
		public static IEnumerable<MachineSetup> FetchBatchWashersByGroupId(int groupTypeId, string ecolabAccNum)
		{
			return DbClient.ExecuteReader<MachineSetup>(Resources.Ecolab_GetBatchWashersByGroupId, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("GroupId", groupTypeId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
			}).ToList();
		}

        #region newMethods

        /// <summary>
        /// Get the washer details
        /// </summary>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="ecolabAccNum">Ecolab account Number</param>
        /// <returns>
        /// The list of washers by group id
        /// </returns>
        public static List<MachineSetup> FetchWashersByGroupId(string groupId, string ecolabAccNum)
		{
			return DbClient.ExecuteReader<MachineSetup>(Resources.Ecolab_GetBatchWashersByGroupId, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);

				cmd.AddParameter("GroupId", DbType.String, 1000, groupId);
			}).ToList();
		}

		#endregion
	}
}