﻿// -----------------------------------------------------------------------
// <copyright file="GroupTypeAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The GroupTypeAccess class </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.ManualInput;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for GroupTypeAccess
    /// </summary>
    public class GroupTypeAccess
    {
        /// <summary>
        ///     Get the Washer group details details
        /// </summary>
        /// <param name="ecolabAccNum">Ecolab Account Number</param>
        /// <returns> The list of washer groups </returns>
        public static List<GroupType> FetchWasherGroups(string ecolabAccNum)
        {
            return DbClient.ExecuteReader<GroupType>(Resources.Ecolab_GetWasherGroups, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            }).ToList();
        }
    }
}