﻿// -----------------------------------------------------------------------
// <copyright file="FormulaAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Formula Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.ManualInput;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for FormulaAccess
    /// </summary>
    public class FormulaAccess
    {
        /// <summary>
        ///     Get the formula details
        /// </summary>
        /// <param name="groupTypeId">groupTypeId</param>
        /// <param name="ecolabAccNum">Ecolab account Number</param>
        /// <returns>list of formulas by group id</returns>
        public static List<WashProgramSetup> FetchFormulasByGroupId(int groupTypeId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<WashProgramSetup>(Resources.Ecolab_GetFormulasByGroupId, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherGroupId", groupTypeId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            }).ToList();
        }
    }
}