﻿// -----------------------------------------------------------------------
// <copyright file="ManualUtilityAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualUtility Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using Entities.ManualInput;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for ManualUtilityAccess
    /// </summary>
    public class ManualUtilityAccess
    {
        /// <summary>
        ///     Get the manual utility data
        /// </summary>
        /// <param name="ecolabAccNum">Ecolab Account Number</param>
        /// <returns>returns the Manual Input utility details</returns>
        public static IEnumerable<ManualUtility> FetchManualUtility(string ecolabAccNum)
        {
            return DbClient.ExecuteReader<ManualUtility>(Resources.Ecolab_GetManualUtility, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            });
        }

        /// <summary>
        ///     Insert manual utility data details
        /// </summary>
        /// <param name="manualUtility">manual utility object</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string SaveManualUtility(ManualUtility manualUtility, string ecolabAccNum, int userId, out int utilityId)
        {
            int returnValue = 0;

            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            SqlParameter paramUtility = new SqlParameter { ParameterName = "OutputUtilityId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveManualUtility, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("MeterId", manualUtility.MeterId);
                cmd.AddParameter("RecordedDate", DbType.DateTime, manualUtility.RecordedDate);
                cmd.AddParameter("Value", manualUtility.Value);
                cmd.AddParameter("Usage", manualUtility.Usage);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramUtility);
            });
            returnValue = Convert.IsDBNull(paramUtility.Value) ? 0 : (int)paramUtility.Value;
            utilityId = returnValue;
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Update manual utility data details
        /// </summary>
        /// <param name="manualUtility">manual utility object</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string UpdateManualUtility(ManualUtility manualUtility, string ecolabAccNum, int userId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateManualUtility, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("UtilityId", manualUtility.Id);
                cmd.AddParameter("RecordedDate", DbType.DateTime, manualUtility.RecordedDate);
                cmd.AddParameter("Value", manualUtility.Value);
                cmd.AddParameter("Usage", manualUtility.Usage);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
            });
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Delete manual utility data details
        /// </summary>
        /// <param name="utilityId">The utility id.</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string DeleteManualUtility(int utilityId, string ecolabAccNum, int userId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            DbClient.ExecuteNonQuery(Resources.Ecolab_DeleteManualUtility, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("UtilityId", utilityId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
            });
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }
    }
}