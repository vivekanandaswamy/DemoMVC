﻿// -----------------------------------------------------------------------
// <copyright file="ManualRewashAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualRewash Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput.Rewash
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities.ManualInput.Rewash;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for ManualRewashAccess
    /// </summary>
    public class ManualRewashAccess
    {
        /// <summary>
        ///     Get the manual rewash data
        /// </summary>
        /// <param name="groupId">The Parameter group Id</param>
        /// <param name="ecolabAccNum">Ecolab Account Number</param>
        /// <returns>returns the rewash details</returns>
        public static List<ManualRewash> FetchManualRewash(int groupId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<ManualRewash>(Resources.Ecolab_GetManualRewash, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherGroupId", groupId);                
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);                
            }).ToList();
        }

        /// <summary>
        ///     Insert manual rewash data details
        /// </summary>
        /// <param name="manualRewash">manual rewash object</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string SaveManualRewash(ManualRewash manualRewash, string ecolabAccNum, int userId, out int rewashId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;
            
            SqlParameter paramManualRewashId = new SqlParameter { ParameterName = "OutputRewashId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveManualRewash, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherGroupId", manualRewash.WasherGroupId);
                cmd.AddParameter("FormulaId", manualRewash.FormulaId);
                cmd.AddParameter("RewashReasonId", manualRewash.RewashReasonId);
                cmd.AddParameter("RecordedDate", DbType.DateTime, manualRewash.RecordedDate);
                cmd.AddParameter("Value", manualRewash.Value);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramManualRewashId);
            });
            rewashId = Convert.IsDBNull(paramManualRewashId.Value) ? 0 : (int)paramManualRewashId.Value;
            
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Update manual rewash data details
        /// </summary>
        /// <param name="manualRewash">manual rewash object</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string UpdateManualRewash(ManualRewash manualRewash, string ecolabAccNum, int userId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateManualRewash, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("RewashId", manualRewash.Id);
                cmd.AddParameter("RecordedDate", DbType.DateTime, manualRewash.RecordedDate);
                cmd.AddParameter("Value", manualRewash.Value);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
            });
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Delete manual rewash data details
        /// </summary>
        /// <param name="rewashId">rewash id</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string DeleteManualRewash(int? rewashId, string ecolabAccNum, int userId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 10;
            param.Direction = ParameterDirection.Output;

            DbClient.ExecuteNonQuery(Resources.Ecolab_DeleteManualRewash, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("RewashId", rewashId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
            });
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Get the manual rewash product data
        /// </summary>
        /// <param name="rewashId">The Parameter rewash Id</param>
        /// <param name="ecolabAccNum">Ecolab Account Number</param>
        /// <returns>returns the rewash product data details</returns>
        public static IEnumerable<RewashProduct> FetchManualRewashProductData(int rewashId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<RewashProduct>("TCD.GetManualRewashProductData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("RewashId", rewashId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            }).ToList();
        }
    }
}