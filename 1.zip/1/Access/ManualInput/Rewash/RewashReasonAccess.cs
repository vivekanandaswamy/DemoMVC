﻿// -----------------------------------------------------------------------
// <copyright file="RewashReasonAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RewashReason Access class </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput.Rewash
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.ManualInput.Rewash;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for RewashReasonAccess
    /// </summary>
    public class RewashReasonAccess
    {
        /// <summary>
        ///     Get the rewash reason details
        /// </summary>
        /// <returns>list of rewash reasons</returns>
        public static IEnumerable<RewashReason> FetchRewashReason()
        {
            return DbClient.ExecuteReader<RewashReason>(Resources.Ecolab_GetManualRewashReason, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; });
        }

        /// <summary>
        ///     Save the rewash reason details
        /// </summary>
        /// <returns>success/failure message code</returns>
        public static string SaveRewashReasons(List<RewashReason> lstRewashReasons)
        {
            string message = string.Empty;
            try
            {
                foreach (var item in lstRewashReasons)
                {
                    DbClient.ExecuteNonQuery(Resources.Ecolab_SaveRewashReason, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.AddParameter("@RewashReasonId", item.RewashReasonId);
						cmd.AddParameter("@Description", DbType.String, 1000, item.Description);
                        cmd.AddParameter("@IsDeleted", item.IsDeleted);
                        cmd.AddParameter("@LastModifiedTime",DbType.DateTime, item.LastModified);
						if (item.LastSync == DateTime.MinValue)
						{
							item.LastSync = null;
							cmd.AddParameter("@LastSyncTime", DbType.DateTime, item.LastSync); 
						}
						else
						{
							cmd.AddParameter("@LastSyncTime", DbType.DateTime, item.LastSync); 
						}
                    });
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            return message;
        }
    }
}