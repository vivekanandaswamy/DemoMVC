﻿// -----------------------------------------------------------------------
// <copyright file="RewashFormulaAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RewashFormula Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput.Rewash
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.ManualInput;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for RewashFormulaAccess
    /// </summary>
    public class RewashFormulaAccess
    {
        /// <summary>
        ///     Get the formula details
        /// </summary>
        /// <param name="groupTypeId">groupTypeId</param>
        /// <param name="ecolabAccNum">Ecolab account Number</param>
        /// <returns>list of formulas by group id</returns>
        public static List<WashProgramSetup> FetchFormulasByGroupId(int groupTypeId, string ecolabAccNum, string recordedDate)
        {
            return DbClient.ExecuteReader<WashProgramSetup>(Resources.Ecolab_GetRewashFormulasByGroupId, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherGroupId", groupTypeId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("RecordedDate", DbType.Date, DateTime.Parse(recordedDate));
            }).ToList();
        }
    }
}