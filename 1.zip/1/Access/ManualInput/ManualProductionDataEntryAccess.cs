﻿// -----------------------------------------------------------------------
// <copyright file="ManualProductionDataEntryAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualProductionDataEntry Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput
{
    using System;
	using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
	using Entities.ManualInput;
    using Entities.ManualInput.ProductData;
	using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for MIProductionAccess
    /// </summary>
    public class ManualProductionDataEntryAccess
    {
        /// <summary>
        ///     Get the manual production data
        /// </summary>
        /// <param name="groupId">The Parameter group Id</param>
        /// <param name="washerId">The Parameter washer Id</param>
        /// <param name="formulaId">The Parameter formula Id</param>
        /// <param name="ecolabAccNum">The Parameter Ecolab Account Number</param>
        /// <returns>returns the production data</returns>
        public static ManualProduction FetchManualProductionData(int groupId, int washerId, int formulaId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<ManualProduction>(Resources.Ecolab_GetManualProduction, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherGroupId", groupId);
                cmd.AddParameter("WasherId", washerId);
                cmd.AddParameter("FormulaId", formulaId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            }).FirstOrDefault();
        }

        /// <summary>
        ///     Insert manual production data details
        /// </summary>
        /// <param name="manualProduction">manual production object</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string SaveManualProduction(ManualProduction manualProduction, string ecolabAccNum, int userId, out int productionId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            SqlParameter paramProduction = new SqlParameter { ParameterName = "OutputProductionId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveManualProduction, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
               // cmd.AddParameter("WasherGroupId", manualProduction.WasherGroupId);
                cmd.AddParameter("WasherId", manualProduction.WasherId);
                cmd.AddParameter("FormulaId", manualProduction.FormulaId);
                cmd.AddParameter("RecordedDate", DbType.DateTime, manualProduction.RecordedDate);
                cmd.AddParameter("Value", manualProduction.Value);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramProduction);
            });
            productionId = Convert.IsDBNull(paramProduction.Value) ? 0 : (int)paramProduction.Value;
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Update manual production data details
        /// </summary>
        /// <param name="manualProduction">manual production object.</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string UpdateManualProduction(ManualProduction manualProduction, string ecolabAccNum, int userId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateManualProduction, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ProductionId", manualProduction.ProductionId);
                cmd.AddParameter("RecordedDate", DbType.DateTime, manualProduction.RecordedDate);
                cmd.AddParameter("Value", manualProduction.Value);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
            });
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        ///     Delete manual production data details
        /// </summary>
        /// <param name="productionId">production id</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <param name="userId">The Parameter user id</param>
        /// <returns>success/failure message code</returns>
        public static string DeleteManualProduction(int? productionId, string ecolabAccNum, int userId)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            DbClient.ExecuteNonQuery(Resources.Ecolab_DeleteManualProduction, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ProductionId", productionId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
            });
            return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
        }

        /// <summary>
        /// Get the Batchdata by groupTypeId washerId and programId
        /// </summary>
        /// <param name="groupTypeId">The Parameter groupTypeId</param>
        /// <param name="washerId">The washer id.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="startDate">The start date.</param>
        /// <param name="ecolabAccNum">The Parameter Ecolab account Number</param>
        /// <param name="pageNumber">The page number.</param>
        /// <param name="rowsPerPage">The rows per page.</param>
        /// <returns>
        /// list of formulas by group id
        /// </returns>
        public static IEnumerable<ManualProduction> FetchProductionData(string groupTypeId, int washerId, int formulaId, DateTime startDate, string ecolabAccNum, int pageNumber, int rowsPerPage)
        {
            return DbClient.ExecuteReader<ManualProduction>(Resources.Ecolab_GetManualProduction, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("@WasherGroupId", DbType.String, 1000, groupTypeId);
                cmd.AddParameter("@WasherId", washerId);
                cmd.AddParameter("@FormulaId", formulaId);
                cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                cmd.AddParameter("@RecordedDate", DbType.DateTime, startDate);
                cmd.AddParameter("RowsPerPage", rowsPerPage);
                cmd.AddParameter("PageNumber", pageNumber);
            });
        }

        #region new methods

        /// <summary>
        /// Get the washer details
        /// </summary>
        /// <param name="groupIds">The group ids.</param>
        /// <param name="ecolabAccNum">Ecolab account Number</param>
        /// <returns>
        /// The list of washers by group id
        /// </returns>
        public static List<MachineSetup> FetchWashersForManualProduction(string groupIds, string ecolabAccNum)
		{
			return DbClient.ExecuteReader<MachineSetup>(Resources.Ecolab_GetWashersForManualProduction, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("WasherGroupId", DbType.String, 1000, groupIds);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
			}).ToList();
		}

        /// <summary>
        /// Get the formula details
        /// </summary>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="ecolabAccNum">Ecolab account Number</param>
        /// <returns>
        /// list of formulas by group id
        /// </returns>
        public static List<WashProgramSetup> FetchFormulasForProductionData(string groupId, string ecolabAccNum)
		{
			return DbClient.ExecuteReader<WashProgramSetup>(Resources.Ecolab_GetFormulasForProductionData, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("WasherGroupId", DbType.String, 1000, groupId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
			}).ToList();
		}
		#endregion
    }
}