﻿// -----------------------------------------------------------------------
// <copyright file="ManualLaborAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ManualLabor Access </summary>
// -----------------------------------------------------------------------

namespace Access.ManualInput
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities.ManualInput.ManualLabor;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for Manual Labor
    /// </summary>
    public class ManualLaborAccess
    {
        /// <summary>
        ///     Inserts Manual Labor details
        /// </summary>
        /// <param name="manualLabor">Manual Labor Object</param>
        /// <param name="userId">The Parameter user ID</param>
        public static int SaveManualLaborDetails(ManualLabor manualLabor, int userId)
        {
            int returnValue = 0;

            SqlParameter paramManualLaborId = new SqlParameter { ParameterName = "OutputManualLaborId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveManualLaborDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("LocationId", manualLabor.LocationId);
                cmd.AddParameter("ManHourTypeId", manualLabor.ManHourTypeId);
                cmd.AddParameter("StartDate", DbType.Date, manualLabor.StartDate);
                cmd.AddParameter("EndDate", DbType.Date, manualLabor.EndDate);
                cmd.AddParameter("LaborCost", manualLabor.LaborCost);
                cmd.AddParameter("AllocatedManHours", manualLabor.AllocatedManHours);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, manualLabor.EcolabAccNum);
                cmd.AddParameter("LastModifiedByUserId", userId);
                cmd.Parameters.Add(paramManualLaborId);
            });
            returnValue = Convert.IsDBNull(paramManualLaborId.Value) ? 0 : (int)paramManualLaborId.Value;
            return returnValue;
        }

        /// <summary>
        ///     Gets the labor cost.
        /// </summary>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="type">The type.</param>
        /// <returns>System.Int32.</returns>
        public static int GetLaborCost(int locationId, int type)
        {
            int cost = DbClient.ExecuteScalar<int>(Resources.Ecolab_GetLabourCost, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("LocationId", locationId);
                cmd.AddParameter("type", type);
            });
            return cost;
        }

        /// <summary>
        /// Gets all the details of labor based on the account number and region id.
        /// </summary>
        /// <param name="ecolabAccountNumber">passing the value of the ecolabaccountnumber.</param>
        /// <param name="manHourTypeId">The man hour type identifier.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <returns>
        /// Gets the list of labor details.
        /// </returns>
        public static IEnumerable<ManualLabor> GetManualLaborDetails(string ecolabAccountNumber, int manHourTypeId, int locationId)
        {
            return DbClient.ExecuteReader<ManualLabor>(Resources.Ecolab_GetManualLaborDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ManHourTypeId", manHourTypeId);
                cmd.AddParameter("LocationId", locationId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// Gets all the details of labor based on the account number and region id.
        /// </summary>
        /// <param name="manualLaborId">The manual labor identifier.</param>
        /// <returns>
        /// Gets the list of labor details.
        /// </returns>
        public static List<ManualLabor> GetManualLaborDetail(int manualLaborId)
        {
            return DbClient.ExecuteReader<ManualLabor>(Resources.Ecolab_GetManualLaborDetail, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ManualLaborId", manualLaborId);              
            }).ToList();
        }

        /// <summary>
        ///     Deletes Manual Labor details
        /// </summary>
        /// <param name="id">Manual Labor id</param>
        /// <param name="userId">The Parameter user ID</param>
        public static void DeleteManualLabor(int id, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_DeleteManualLaborDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Id", id);
                cmd.AddParameter("LastModifiedByUserId", userId);
            });
        }

        /// <summary>
        ///     Updates Manual Labor details
        /// </summary>
        /// <param name="manualLabor">Manual Labor Object</param>
        /// <param name="userId">The Parameter user ID</param>
        public static void UpdateManualLaborDetails(ManualLabor manualLabor, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateManualLaborDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Id", manualLabor.Id);
                cmd.AddParameter("LocationId", manualLabor.LocationId);
                cmd.AddParameter("ManHourTypeId", manualLabor.ManHourTypeId);
                cmd.AddParameter("StartDate", DbType.Date, manualLabor.StartDate);
                cmd.AddParameter("EndDate", DbType.Date, manualLabor.EndDate);
                cmd.AddParameter("LaborCost", manualLabor.LaborCost);
                cmd.AddParameter("AllocatedManHours", manualLabor.AllocatedManHours);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, manualLabor.EcolabAccNum);
                cmd.AddParameter("LastModifiedByUserId", userId);
            });
        }
    }
}