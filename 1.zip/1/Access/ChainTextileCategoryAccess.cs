﻿// -----------------------------------------------------------------------
// <copyright file="ChainTextileCategoryAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chain Textile Category Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    /// ChainTextileCategoryAccess
    /// </summary>
    public class ChainTextileCategoryAccess
    {
        /// <summary>
        ///     Get Chain Textile Category details
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<ChainTextileCategory> GetChainTextileCategory(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ChainTextileCategory>(Resources.Ecolab_GetChainTextileCategory,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.CommandType = CommandType.StoredProcedure;
                }).ToList();
        }

        /// <summary>
        ///     Get Chain Textile Category details based on Plant chain id
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<ChainTextileCategory> GetChainTextileCategoryByPlantChainId(int plantChainId, DateTime myServiceTime)
        {
            return DbClient.ExecuteReader<ChainTextileCategory>(Resources.Ecolab_GetChainTextileCategoryByPlantChainId, delegate(DbCommand cmd, DbContext context)
                {
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("PlantChainId", plantChainId);
                    cmd.AddParameter("TimeStamp", DbType.DateTime, myServiceTime);
                }).ToList();
        }

        /// <summary>
        /// Insert or update ChainTextileCategory Details 
        /// </summary>
        /// <param name="chainTextileCategoryDetails">Object</param>
        /// <returns>New Generated id</returns>
        public static int SaveChainTextileCategoryDetails(ChainTextileCategory chainTextileCategoryDetails)
        {
            int returnValue = 0;
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveChainTextileCategoryDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("ChainTextileId", chainTextileCategoryDetails.TextileId);
                  cmd.AddParameter("ChainTextileName", DbType.String, 1000, chainTextileCategoryDetails.Name);
                  cmd.AddParameter("PlantChainId", chainTextileCategoryDetails.ChainId);
                  cmd.AddParameter("IsDeleted", chainTextileCategoryDetails.IsDeleted);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, chainTextileCategoryDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : chainTextileCategoryDetails.LastModifiedTime);
                  cmd.AddParameter("LastSyncTime", DbType.DateTime, chainTextileCategoryDetails.LastSyncTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : chainTextileCategoryDetails.LastSyncTime);
                  cmd.AddParameter("ResourceKey", DbType.String, 1000, chainTextileCategoryDetails.ResourceKey);
              });
            return returnValue;
        }

        /// <summary>
        /// Saves the chain textile category details for first time synchronize.
        /// </summary>
        /// <param name="chainTextileCategoryDetails">The chain textile category details.</param>
        public static void SaveChainTextileCategoryDetailsForFirstTimeSync(ChainTextileCategory chainTextileCategoryDetails)
        {
            
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveChainTextileCategoryForFirstTimeSync,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("ChainTextileId", chainTextileCategoryDetails.TextileId);
                  cmd.AddParameter("ChainTextileName", DbType.String, 1000, chainTextileCategoryDetails.Name);
                  cmd.AddParameter("PlantChainId", chainTextileCategoryDetails.ChainId);
                  cmd.AddParameter("IsDeleted", chainTextileCategoryDetails.IsDeleted);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, chainTextileCategoryDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : chainTextileCategoryDetails.LastModifiedTime);
                  cmd.AddParameter("ResourceKey", DbType.String, 1000, chainTextileCategoryDetails.ResourceKey);
              });
            
        }
    }
}