﻿// -----------------------------------------------------------------------
// <copyright file="DataReaderAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Data Reader Access </summary>
// -----------------------------------------------------------------------

namespace Access.DataReader
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities;
    using Entities.Common;
    using Entities.DataReader;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    /// Class for DataReaderAccess
    /// </summary>
    public class DataReaderAccess
    {
        public static IEnumerable<Controller> GetActiveControllers()
        {
            return DbClient.ExecuteReader<Controller>(Resources.Ecolab_GetActiveControllers, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; });
        }

        public static IEnumerable<Washer> GetActiveWashers(int controllerId)
        {
            return DbClient.ExecuteReader<Washer>(Resources.Ecolab_GetActiveWahsersByControllerId, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
            });
        }

        public static int ProcessWasherTags(int washerId, string tagsXml, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessConventionalWasherData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherId", washerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tagsXml.Length, tagsXml);
                cmd.Parameters.Add(param);
            });
            
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static IEnumerable<ControllerTag> GetActiveControllerTags(int controllerId)
        {
            return DbClient.ExecuteReader<ControllerTag>(Resources.Ecolab_GetActiveControllerTags, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
            });
        }

        public static IEnumerable<ModuleTag> GetActiveModuleTags(int controllerId)
        {
            return DbClient.ExecuteReader<ModuleTag>(Resources.Ecolab_GetActiveModuleTags, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
            });
        }

        public static void ProcessNowTags(int controllerId, string tagsXml)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessNowTags, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tagsXml.Length, tagsXml);
            });
        }

        public static void ProcessModuleTags(int moduleId, int moduleTypeId, Double value, DateTime timestamp, long rolloverPoint, Double usage)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessModuleTags, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ModuleId", moduleId);
                cmd.AddParameter("ModuleTypeId", moduleTypeId);
                cmd.AddParameter("Reading", value);
                cmd.AddParameter("TimeStamp", DbType.DateTime2, timestamp);
                cmd.AddParameter("RollOverPoint", rolloverPoint);
                cmd.AddParameter("Usage", usage);
            });
        }
        public static void ProcessBeckhoffModuleTags(int moduleId, int moduleTypeId, Double value, DateTime timestamp, Double usage, int rolloverPoint)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessModuleTags, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ModuleId", moduleId);
                cmd.AddParameter("ModuleTypeId", moduleTypeId);
                cmd.AddParameter("Reading", value);
                cmd.AddParameter("TimeStamp", DbType.DateTime2, timestamp);
                cmd.AddParameter("Usage", usage);
                cmd.AddParameter("RollOverPoint", rolloverPoint);
            });
        }
        public static int ProcessPlcxlOnlineConventionalData(int controllerId, string washerData, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            string sqcmd = "TCD.ProcessConventionalOnlineDataForPLCXL";
            DbClient.ExecuteNonQuery(sqcmd, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, washerData.Length, washerData);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static int ProcessEcontrolPlusOnlineConventionalData(int controllerId, string washerData, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            string sqcmd = "TCD.ProcessConventionalOnlineDataForEcontrolPlus";
            DbClient.ExecuteNonQuery(sqcmd, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, washerData.Length, washerData);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static int ProcessMyControlOnlineConventionalData(int controllerId, string washerData, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            string sqcmd = "TCD.ProcessMyControlConventionalData_Online";
            DbClient.ExecuteNonQuery(sqcmd, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, washerData.Length, washerData);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static void ProcessMyControlOnlineCWWaterPerStepData(int controllerId, string washerData)
        {
 
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessMyControlOnlineCWStepWaterConsumptionData, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, washerData.Length, washerData);
            });
        }

        public static int ProcessMyControlBatchConventionalData(int controllerId, string washerData, int plcPointer, int readPointer, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessMyControlConventionalData_CompletedBatches, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, washerData.Length, washerData);
                cmd.AddParameter("PLCPointer", plcPointer);
                cmd.AddParameter("ReadPointer", readPointer);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static void ProcessEcontrolPlusAlarmData(int controllerId, string alarmData)
        {
            DbClient.ExecuteNonQuery("[TCD].[ProcessEcontrolPlusAlarmData]", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, alarmData.Length, alarmData);
            });
        }
        public static void ProcessPlcxlAlarmData(int controllerId, string alarmData)
        {
            DbClient.ExecuteNonQuery("[TCD].[ProcessPLCXLAlarmData]", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, alarmData.Length, alarmData);
            });
        }
        public static void ProcessMyControlAlarmData(int controllerId, string alarmData)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessMyControlAlarmData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, alarmData.Length, alarmData);
            });
        }

        public static void ProcessMyControlOnlineProductDosing(int controllerId, string xml)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessMyControlOnlineProductDosing, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, xml.Length, xml);
            });
        }

        public static int ProcessTunnelWasherTags(int washerId, string tunnelData, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessTunnelWasherData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherId", washerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
                cmd.Parameters.Add(param);
            });

            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static int ProcessMyControlTunnelWasherOnlineData(int controllerId, string tunnelData, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery("TCD.ProcessMyControlTunnelWasherOnlineData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static int ProcessMyControlTunnelWasherProdData(int controllerId, string tunnelData, int plcPtr, int readPtr, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery("TCD.ProcessMyControlTunnelWasherProdData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
                cmd.AddParameter("PLCPointer", plcPtr);
                cmd.AddParameter("ReadPointer", readPtr);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static int ProcessMitsubishiTunnelWasherOnlineData(int controllerId, string tunnelData, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery("TCD.ProcessMitsubishiTunnelWasherOnlineData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }
        public static void ProcessEcontrolPlusTunnelWasherOnlineData(int controllerId, string tunnelData)
        {
            DbClient.ExecuteNonQuery("TCD.ProcessEcontrolPlusTunnelWasherOnlineData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
            });
        }

        public static int ProcessMitsubishiAccessSaveData(int controllerId, string tunnelData, int redFlagShiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery("TCD.ProcessMitsubishiAccessSaveData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
                cmd.Parameters.Add(param);
            });
            redFlagShiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return redFlagShiftId;
        }
        public static int ProcessMitsubishiStepSaveData(int controllerId, string stepSaveData, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery("TCD.ProcessMitsubishiStepSaveData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, stepSaveData.Length, stepSaveData);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static void ProcessMitsubishiTunnelWasherProdData(int controllerId, string tunnelData)
        {
            
            DbClient.ExecuteNonQuery("TCD.ProcessMitsubishiTunnelWasherProdData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
            });
        }

        public static void ProcessMyControlAnalogData(int controllerId, string xml)
        {
            DbClient.ExecuteNonQuery("TCD.ProcessMyControlAnalogData", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, xml.Length, xml);
            });
        }     

        public static void ProcessTunnelWasherTagsBeckhoff(int washerId, string tunnelData)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessTunnelWasherDataBeckhoff, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherId", washerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
            });
        }

        public static bool GetActiveMeterConnectedtoWasher(int washerId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "MeterExists", SqlDbType = SqlDbType.Bit, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_GetActiveMeterConnectedtoWasher, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherId", washerId);
                cmd.Parameters.Add(param);
            });

            return Convert.IsDBNull(param.Value) ? false : true;
        }

        public static IEnumerable<Washer> GetActiveMetersByWasherandControllerId(int controllerId, int washerId)
        {
            return DbClient.ExecuteReader<Washer>(Resources.Ecolab_GetActiveMetersByWasherandControllerId, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("WasherId", washerId);
            });
        }
        public static IEnumerable<WasherTags> GetWasherDetailsById(int washerId)
        {
            return DbClient.ExecuteReader<WasherTags>(Resources.Ecolab_GetWasherDetailsById, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherId", washerId);
            });
        }

        public static void ProcessBeckhoffArrayQueue(int controllerId, int washerId, string address, string value, DateTime timestamp)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessBeckhoffArrayQueue, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerId);
                cmd.AddParameter("Washerid", washerId);
                cmd.AddParameter("Address", DbType.String, 50, address);
                cmd.AddParameter("Value", DbType.String, 50, value);
                cmd.AddParameter("Timestamp", DbType.DateTime2, timestamp);
            });
        }

        public static void ProcessHoldSignal(int controllerId, int washerId, string address, string value, DateTime timestamp)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessHoldSignal, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerId);
                cmd.AddParameter("Washerid", washerId);
                cmd.AddParameter("Address", DbType.String, 50, address);
                cmd.AddParameter("Value", DbType.String, 50, value);
                cmd.AddParameter("Timestamp", DbType.DateTime2, timestamp);
            });
        }

        public static void ProcessDeleteBeckhoffArrayQueue(int controllerId, int washerId, string address, string value, DateTime timestamp, bool isTunnel)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessDeleteBeckhoffArrayQueue, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerId);
                cmd.AddParameter("Washerid", washerId);
                cmd.AddParameter("Address", DbType.String, 50, address);
                cmd.AddParameter("Value", DbType.String, 50, value);
                cmd.AddParameter("Timestamp", DbType.DateTime2, timestamp);
                cmd.AddParameter("IsTunnel", isTunnel);
            });
        }

        public static IEnumerable<BeckhoffXmlTag> GetActiveBeckhoffArrayQueue(int controllerid, int washerid)
        {
            return DbClient.ExecuteReader<BeckhoffXmlTag>(Resources.Ecolab_GetActiveBeckhoffArrayQueue, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerid);
                cmd.AddParameter("Washerid", washerid);
            });
        }
        public static void ProcessAllenBradleyArrayQueue(int controllerid, int washerid, string address, string value, DateTime timestamp)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessAllenBradleyArrayQueue, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerid);
                cmd.AddParameter("Washerid", washerid);
                cmd.AddParameter("Address", DbType.String, 50, address);
                cmd.AddParameter("Value", DbType.String, 50, value);
                cmd.AddParameter("Timestamp", DbType.DateTime2, timestamp);
            });
        }
        public static void ProcessDeleteAllenBradleyArrayQueue(int controllerId, int washerId, string address, string value, DateTime timestamp, bool isTunnel)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ProcessDeleteAllenBradleyArrayQueue, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerId);
                cmd.AddParameter("Washerid", washerId);
                cmd.AddParameter("Address", DbType.String, 50, address);
                cmd.AddParameter("Value", DbType.String, 50, value);
                cmd.AddParameter("Timestamp", DbType.DateTime2, timestamp);
                cmd.AddParameter("IsTunnel", isTunnel);
            });
        }

        public static IEnumerable<AllenBradleyXmlTag> GetActiveAllenBradleyArrayQueue(int controllerid, int washerid)
        {
            return DbClient.ExecuteReader<AllenBradleyXmlTag>(Resources.Ecolab_GetActiveAllenBradleyArrayQueue, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerid);
                cmd.AddParameter("Washerid", washerid);
            });
        }

        public static IEnumerable<RatioDosing> GetActiveSWbyWasherIdAndFormula(int washerid, int formula)
        {
            return DbClient.ExecuteReader<RatioDosing>(Resources.Ecolab_GetActiveSWbyWasherIdANDFormula, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Washerid", washerid);
                cmd.AddParameter("Formula", formula);
            });
        }

        /// <summary>
        ///     GetTunnelStatus
        /// </summary>
        /// <param name="washerId">fetching data through washer id</param>
        /// <returns>returns a list.</returns>
        public static IEnumerable<TunnelCompartment> GetTunnelStatus(int washerId)
        {
            return DbClient.ExecuteReader<TunnelCompartment>(Resources.Ecolab_GetTunnelStatus, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("WasherId", washerId);
                cmd.CommandType = CommandType.StoredProcedure;
            }).ToList();
        }

        public static bool GetActiveBatchtoWasher(int washerId, int currentFormula, DateTime currentFormulaDate)
        {
            SqlParameter param = new SqlParameter { ParameterName = "BatchExists", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_GetActiveBatchtoWasher, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("WasherId", washerId);
                cmd.AddParameter("CurrentFormula", currentFormula);
                cmd.AddParameter("CurrentFormulaDate", DbType.DateTime2, currentFormulaDate);
                cmd.Parameters.Add(param);
            });

            return Convert.IsDBNull(param.Value) ? false : true;
        }

        public static void UpdateControllerConnectivityAlarm(int controllerId, bool isActive, int alarmCode)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateControllerConnectivityAlarm, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Controllerid", controllerId);
                cmd.AddParameter("IsActive", isActive);
                cmd.AddParameter("AlarmCode", alarmCode);
            });
        }

        public static void ProcessRedFlagData(int shiftId)
        {
            DbClient.ExecuteNonQuery("TCD.ProcessRedFlagData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ShiftId", shiftId);
            });
        }

        public static int ProcessEControlPlusBatchConventionalProdData(int controllerId, string washerData, int plcPointer, int readPointer, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            string sqcmd = "TCD.ProcessEControlPlusBatchConventionalProdData";
            DbClient.ExecuteNonQuery(sqcmd, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("VxML", DbType.Xml, washerData.Length, washerData);
                cmd.AddParameter("PLCPointer", plcPointer);
                cmd.AddParameter("ReadPointer", readPointer);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static int ProcessEControlPlusBatchTunnelProdData(int controllerId, string tunnelData, int plcPtr, int readPtr, int shiftId)
        {
            SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery("TCD.ProcessEcontrolPlusTunnelWasherProdData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, tunnelData.Length, tunnelData);
                cmd.AddParameter("PLCPointer", plcPtr);
                cmd.AddParameter("ReadPointer", readPtr);
                cmd.Parameters.Add(param);
            });
            shiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);

            return shiftId;
        }

        public static Plant GetPlantInfo()
        {
            return DbClient.ExecuteReader<Plant>("TCD.GetPlantInfo", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }).FirstOrDefault();
        }

        /// <summary>
        /// Processes my control wand e digital data.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="digitalInputData">The digital input data.</param>
        /// <param name="isOnline">isOnline is false when calling for CSV(historical) data and true for trending data .</param>
        public static void ProcessMyControlWandEDigitalData(int controllerId,string digitalInputData, bool isOnline)
        {
            DbClient.ExecuteNonQuery("TCD.ProcessMyControlWandEDigitalData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, digitalInputData.Length, digitalInputData);
                cmd.AddParameter("IsOnline", isOnline);
            });
        }

        /// <summary>
        /// Processes my control wand e digital alarm data.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="digitalAlarmData">The digital alarm data.</param>
        public static void ProcessMyControlWandEDigitalAlarmData(int controllerId, string digitalAlarmData)
        {
            DbClient.ExecuteNonQuery("TCD.ProcessMyControlWandEDigitalAlarmData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, digitalAlarmData.Length, digitalAlarmData);
            });
        }

        /// <summary>
        /// Processes my control wand e analog data.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="analogInputData">The analog input data.</param>
        public static void ProcessMyControlWandEAnalogData(int controllerId,string analogInputData)
        {
            DbClient.ExecuteNonQuery("TCD.ProcessMyControlWAndEAnalogData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, analogInputData.Length, analogInputData);
            });
        }

        /// <summary>
        /// Processes my control wand e analog alarm data.
        /// </summary>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="analogAlarmData">The analog alarm data.</param>
        public static void ProcessMyControlWandEAnalogAlarmData(int controllerId, string analogAlarmData)
        {
            DbClient.ExecuteNonQuery("TCD.ProcessMyControlWAndEAnalogAlarmData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerID", controllerId);
                cmd.AddParameter("xmlTags", DbType.Xml, analogAlarmData.Length, analogAlarmData);
            });
        }

        /// <summary>
        /// Gets the e tech configuration settings.
        /// </summary>
        /// <returns>Returns the string value</returns>
        public static string GetETechConfigSettings()
        {
            return DbClient.ExecuteReader<string>("TCD.GetETechConfigSettings", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }).FirstOrDefault();
        }
        /// <summary>
        /// Saves the PLC Discrepancy Model
        /// </summary>
        /// <param name="plcDiscrepancyModel">The PLC Discrepancy Model</param>
        public static void DeletePlcDiscrepancy(PLCDiscrepancyModel plcDiscrepancyModel)
        {
            DbClient.ExecuteScalar<bool>(Resources.Ecolab_SavePLCDiscrepancy, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("ParentEntityType", plcDiscrepancyModel.ParentEntity);
                cmd.AddParameter("EntityType", plcDiscrepancyModel.Entity);
                cmd.AddParameter("ParentEntityId", plcDiscrepancyModel.ParentEntityId);
                cmd.AddParameter("EntityId", plcDiscrepancyModel.EntityId);
                cmd.AddParameter("SyncFromCentral", plcDiscrepancyModel.IsCentral);
                cmd.AddParameter("ControllerId", plcDiscrepancyModel.ControllerId);
                cmd.AddParameter("SyncToPlc", !plcDiscrepancyModel.IsPLCError);
                cmd.AddParameter("UserId", plcDiscrepancyModel.UserId);
                cmd.AddParameter("LastModifiedTime", DbType.String, 200, DateTime.Now.ToString());
            });
        }
        /// <summary>
        /// Fetches the Plc Discrepancy Data
        /// </summary>
        /// <returns>Returns the List of Plc Discrepancy</returns>
        public static IEnumerable<PLCDiscrepancyModel> FetchPlcDiscrepancyData()
        {
            return DbClient.ExecuteReader<PLCDiscrepancyModel>(Resources.Ecolab_FetchPLCDiscrepancy, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;                
            }).ToList();
        }
    }
}