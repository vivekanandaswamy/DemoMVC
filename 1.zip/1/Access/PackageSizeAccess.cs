﻿// -----------------------------------------------------------------------
// <copyright file="PackageSizeAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PackageSizeAccess </summary>
// -----------------------------------------------------------------------
namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using Entities.Common;
    using Nalco.Data.Common;
    using Properties;

    public class PackageSizeAccess
    {
        public static int SaveMyServicePackageSizeDetails(Entities.PackageSize packageSize)
        {
            int returnValue = 0;

            var paramPackageSizeId = new SqlParameter
            {
                ParameterName = "OutputPackageSizeId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

                DbClient.ExecuteNonQuery(
                Resources.Ecolab_UpdateMyServicePackageSize,
                delegate(DbCommand cmd, DbContext context)
                {
                   cmd.CommandType = CommandType.StoredProcedure;
                   cmd.AddParameter("PackageSizeDescription", DbType.String, 1000, packageSize.PackageSizeDescription);
                   cmd.AddParameter("UnitPerPackage", packageSize.UnitPerPackage);
                   cmd.AddParameter("UnitWeightVolume", packageSize.UnitWeightVolume);
                   cmd.AddParameter("UnitWeightVolumeUOMId", packageSize.UnitWeightVolumeUOMId);
                   cmd.AddParameter("PackageSizeVolume", packageSize.PackageSizeVolume);
                   cmd.AddParameter("PackageSizeVolumeUOMId", packageSize.PackageSizeVolumeUOMId);
                   cmd.AddParameter("PackageSizeWeight", packageSize.PackageSizeWeight);
                   cmd.AddParameter("PackageSizeWeightUOMId", packageSize.PackageSizeWeightUOMId);
                   cmd.AddParameter("PackageSizeWeightUOMCode", DbType.String, 100, packageSize.PackageSizeWeightUOMCode);
                   cmd.AddParameter("PackageSizeDensity", packageSize.PackageSizeDensity);
                   cmd.AddParameter("PackageSizeDensityUOMId", packageSize.PackageSizeDensityUOMId);
                   cmd.AddParameter("RegionCode", DbType.String, 4, packageSize.RegionCode);
                   cmd.AddParameter("IsDeleted", packageSize.IsDeleted);
                   cmd.AddParameter("MyServicePkgSzId", packageSize.MyServicePkgSzId);
                   cmd.AddParameter("PackageSizeId", packageSize.Id);  
                   cmd.Parameters.Add(paramPackageSizeId);                   
                });
           
            returnValue = Convert.IsDBNull(paramPackageSizeId.Value) ? 0 : (Int32)paramPackageSizeId.Value;

            return returnValue;
            
        }

    }
}
