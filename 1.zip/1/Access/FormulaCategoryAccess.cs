﻿// -----------------------------------------------------------------------
// <copyright file="FormulaCategoryAccess.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>The Formula Category Access Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    /// FormulaCategoryAccess
    /// </summary>
    public class FormulaCategoryAccess
    {
        /// <summary>
        ///     Get Formula Category details
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<FormulaCategory> GetFormulaCategory(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<FormulaCategory>(Resources.Ecolab_GetChainTextileCategory,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.CommandType = CommandType.StoredProcedure;
                }).ToList();
        }

        /// <summary>
        ///     Get Chain Textile Category details based on Plant chain id
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<FormulaCategory> GetFormulaCategoryByRegionId(int regionId, DateTime myServiceTime)
        {
            return DbClient.ExecuteReader<FormulaCategory>(Resources.Ecolab_GetFormulaCategoryByRegionId, delegate(DbCommand cmd, DbContext context)
                {
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("RegionId", regionId);
                    cmd.AddParameter("TimeStamp", DbType.DateTime, myServiceTime);
                }).ToList();
        }

        /// <summary>
        /// Insert or update FormulaCategory Details 
        /// </summary>
        /// <param name="formulaCategoryDetails">Object</param>
        /// <returns>New Generated id</returns>
        public static int SaveFormulaCategoryDetails(FormulaCategory formulaCategoryDetails)
        {
            int returnValue = 0;
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveFormulaCategoryDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("TextileId", formulaCategoryDetails.TextileId);
                  cmd.AddParameter("CategoryName", DbType.String, 1000, formulaCategoryDetails.CategoryName);
                  cmd.AddParameter("IsDeleted", formulaCategoryDetails.IsDeleted);
                  cmd.AddParameter("MyServiceMstrLnnTypId", formulaCategoryDetails.MyServiceMstrLnnTypId);
                  cmd.AddParameter("MyServiceLastSynchTime", DbType.DateTime, formulaCategoryDetails.MyServiceLastSynchTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : formulaCategoryDetails.MyServiceLastSynchTime);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, formulaCategoryDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : formulaCategoryDetails.LastModifiedTime);
                  cmd.AddParameter("RegionId", formulaCategoryDetails.RegionId);                  
              });
            return returnValue;
        }

        /// <summary>
        /// Saves the chain textile category details for first time synchronize.
        /// </summary>
        /// <param name="chainTextileCategoryDetails">The chain textile category details.</param>
        public static void SaveChainTextileCategoryDetailsForFirstTimeSync(ChainTextileCategory chainTextileCategoryDetails)
        {
            
            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveChainTextileCategoryForFirstTimeSync,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.AddParameter("ChainTextileId", chainTextileCategoryDetails.TextileId);
                  cmd.AddParameter("ChainTextileName", DbType.String, 1000, chainTextileCategoryDetails.Name);
                  cmd.AddParameter("PlantChainId", chainTextileCategoryDetails.ChainId);
                  cmd.AddParameter("IsDeleted", chainTextileCategoryDetails.IsDeleted);
                  cmd.AddParameter("LastModifiedTime", DbType.DateTime, chainTextileCategoryDetails.LastModifiedTime.Equals(DateTime.MinValue) ? DateTime.UtcNow : chainTextileCategoryDetails.LastModifiedTime);
                  cmd.AddParameter("ResourceKey", DbType.String, 1000, chainTextileCategoryDetails.ResourceKey);
              });
            
        }
    }
}