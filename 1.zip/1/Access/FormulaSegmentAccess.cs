﻿// -----------------------------------------------------------------------
// <copyright file="FormulaSegmentAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FormulaSegmentAccess </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Access.Properties;
    using Entities;
    using Nalco.Data.Common;

    public class FormulaSegmentAccess
    {
        /// <summary>
        /// Save Formula Segments
        /// </summary>
        /// <param name="lstFormulaSegments">List of formula segments</param>
        /// <returns>response message</returns>
        public static string SaveFormulaSegments(List<FormulaSegment> lstFormulaSegments)
        {
            string message = string.Empty;
            try
            {
                foreach (var item in lstFormulaSegments)
                {
                    DbClient.ExecuteNonQuery(Resources.Ecolab_SaveFormulaSegment, delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.AddParameter("@FormulaSegmentID", item.FormulaSegmentId);
                        cmd.AddParameter("@SegmentName", DbType.String, 1000, item.FormulaSegmentName);
                        cmd.AddParameter("@IsDeleted", item.IsDeleted);
                        cmd.AddParameter("@LastModifiedTime", DbType.DateTime, item.LastModified);
                        if (item.LastSync == DateTime.MinValue)
                        {
                            item.LastSync = null;
                            cmd.AddParameter("@LastSyncTime", DbType.DateTime, item.LastSync);
                        }
                        else
                        {
                            cmd.AddParameter("@LastSyncTime", DbType.DateTime, item.LastSync);
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            return message;
        }
    }
}
