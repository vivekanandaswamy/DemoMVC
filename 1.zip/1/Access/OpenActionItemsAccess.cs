﻿// -----------------------------------------------------------------------
// <copyright file="OpenActionItemsAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The OpenActionItems Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Nalco.Data.Common;

    /// <summary>
    /// Class for OpenActionItemsAccess
    /// </summary>
    public class OpenActionItemsAccess
    {
        public static int SaveMyServiceOpenActionItemsDetails(Entities.OpenActionItems openActionItems)
        {
            int returnValue = 0;

            var paramOpenActionItemsId = new SqlParameter
            {
                ParameterName = "OutputOpenActionItemsId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              "[TCD].[UpdateMyServiceOpenActionItemsDetails]",
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, openActionItems.EcolabAccountNumber);
                  cmd.AddParameter("PlantName", DbType.String, 1000, openActionItems.PlantName);
                  cmd.AddParameter("ItemDescription", DbType.String, 1000, openActionItems.ItemDescription);
                  cmd.AddParameter("CreatedDate", DbType.DateTime, openActionItems.CreatedDate);
                  cmd.AddParameter("InChargeId", openActionItems.InChargeId);
                  cmd.AddParameter("InChargeDesc", DbType.String, 1000, openActionItems.InChargeDesc);
                  cmd.AddParameter("Comment", DbType.String, 1000, openActionItems.Comment);
                  cmd.AddParameter("IsActive", openActionItems.IsActive);
                  cmd.AddParameter("MyServiceOpenActionItemId", openActionItems.MyServiceOpenActionItemId);
                  cmd.AddParameter("AdditionalDetails", DbType.String, 1000, openActionItems.AdditionalDetails);
                  cmd.Parameters.Add(paramOpenActionItemsId);
              });
            returnValue = Convert.ToInt32(Convert.IsDBNull(paramOpenActionItemsId.Value) ? 0 : Convert.ToInt32(paramOpenActionItemsId.Value));
            return returnValue;
        }

        public static int SaveMyServiceOpenActionItemsDetailsInLocal(Entities.OpenActionItems openActionItems)
        {
            Int16 returnValue = 0;

            DbClient.ExecuteNonQuery(
              "[TCD].[UpdateMyServiceOpenActionItemsDetails]",
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("ItemId", openActionItems.Id);
                  cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, openActionItems.EcolabAccountNumber);
                  cmd.AddParameter("PlantName", DbType.String, 1000, openActionItems.PlantName);
                  cmd.AddParameter("ItemDescription", DbType.String, 1000, openActionItems.ItemDescription);
                  cmd.AddParameter("CreatedDate", DbType.DateTime, openActionItems.CreatedDate);
                  cmd.AddParameter("InChargeId", openActionItems.InChargeId);
                  cmd.AddParameter("InChargeDesc", DbType.String, 1000, openActionItems.InChargeDesc);
                  cmd.AddParameter("Comment", DbType.String, 1000, openActionItems.Comment);
                  cmd.AddParameter("IsActive", openActionItems.IsActive);
                  cmd.AddParameter("MyServiceOpenActionItemId", openActionItems.MyServiceOpenActionItemId);
                  cmd.AddParameter("AdditionalDetails", DbType.String, 1000, openActionItems.AdditionalDetails);
              });
            return returnValue;
        }
    }
}
