﻿// -----------------------------------------------------------------------
// <copyright file="ExchangeRateAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Exchange Rate Access class.</summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Nalco.Data.Common;
    using Properties;
    using Entities;

    /// <summary>
    ///     class ExchangeRateAccess
    /// </summary>
    public class ExchangeRateAccess
    {
        /// <summary>
        ///     Get Exchange Rate details
        /// </summary>
        /// <returns>the list of details</returns>
        public static List<ExchangeRate> GetExchangeRates()
        {
            return DbClient.ExecuteReader<ExchangeRate>(Resources.Ecolab_GetCurrencyExchangeRateDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }

        /// <summary>
        ///     Get Exchange Rate details
        /// </summary>
        /// <param name="sourceCurrencyCode">Object</param>
        /// <param name="targetCurrencyCode">Object</param>
        /// <returns>the exchange rate details</returns>
        public static ExchangeRate GetExchangeRates(string sourceCurrencyCode, string targetCurrencyCode)
        {
            return DbClient.ExecuteReader<ExchangeRate>(Resources.Ecolab_GetCurrencyExchangeRateDetails_New, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("@Sourcecurrencycode",DbType.String, 50,sourceCurrencyCode);
                cmd.AddParameter("@Targetcurrencycode", DbType.String, 50, targetCurrencyCode);
            }).FirstOrDefault();
        }

        /// <summary>
        /// Insert or update ExchangeRate Details 
        /// </summary>
        /// <param name="exchangeRateDetails">Object</param>
        /// <returns>New Generated id</returns>
        public static int SaveExchangeRateDetails(ExchangeRate exchangeRateDetails)
        {
            int returnValue = 0;

            var paramExchangeRateId = new SqlParameter
            {
                ParameterName = "OutputExchangeRateId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveExchangeRateDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("ExchangeRateId", exchangeRateDetails.ExchangeRateId);
                  cmd.AddParameter("CurrencyCode", DbType.String, 50, exchangeRateDetails.CurrencyCode);
                  cmd.AddParameter("Rate", exchangeRateDetails.Rate);
                  cmd.AddParameter("TargetCurrencyCode", DbType.String, 50, exchangeRateDetails.TargetCurrencyCode);
                  cmd.AddParameter("EffectiveExchangeRateDate", DbType.DateTime, exchangeRateDetails.EffectiveExchangeRateDate);
                  cmd.AddParameter("CreatedDate", DbType.DateTime, exchangeRateDetails.CreatedDate);
                  cmd.Parameters.Add(paramExchangeRateId);
              });

            returnValue = Convert.IsDBNull(paramExchangeRateId.Value) ? 0 : (int)paramExchangeRateId.Value;
            return returnValue;
        }
    }
}
