﻿// -----------------------------------------------------------------------
// <copyright file="MachineSetupTunnelAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machine Setup Tunnel Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Data access class for MachineSetupTunnelAccess
    /// </summary>
    public class MachineSetupTunnelAccess
    {
        /// <summary>
        ///     Get tunnel details
        /// </summary>
        /// <returns> tunnels </returns>
        public static List<MachineSetupTunnel> GetTunnelDetails()
        {
            return DbClient.ExecuteReader<MachineSetupTunnel>(Resources.Ecolab_GetTunnelDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}