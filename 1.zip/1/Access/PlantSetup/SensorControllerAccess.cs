﻿// -----------------------------------------------------------------------
// <copyright file="SensorControllerAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  Sensor Controller Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for SensorControllerAccess
    /// </summary>
    public class SensorControllerAccess
    {
        /// <summary>
        ///     Get Sensor controller details
        /// </summary>
        /// <returns>The list of Sensor controller Chart</returns>
        public static List<SensorController> GetSensorControllerDetails()
        {
            return DbClient.ExecuteReader<SensorController>(Resources.Ecolab_GetSensorControllerDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}