﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityDimensionTypeAccess.cs" company="Ecolab">
// This class is for getting the utility dimension type values from database.
// </copyright>
// <summary>The Plant Utility Dimension Type Access for getting data.</summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Class is for getting the dimensions of the plant utility based on the region.
    /// </summary>
    public class PlantUtilityDimensionTypeAccess
    {
        /// <summary>
        ///     Get GasOil Type details list.
        /// </summary>
        /// <returns>plant utility dimension types.</returns>
        public static List<PlantUtilityDimensionTypes> GetDimensionTypes(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<PlantUtilityDimensionTypes>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantUtilityDimensionTypes : Resources.Ecolab_GetPlantUtilityDimensionTypes, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }
    }
}