﻿// -----------------------------------------------------------------------
// <copyright file="LaborCostAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Labor Cost Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.ShiftLabor;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for LaborCostAccess
    /// </summary>
    public class LaborCostAccess
    {
        /// <summary>
        ///     Get the labor cost  details
        /// </summary>
        /// <param name="ecolabAccNumber"> Ecolab account number </param>
        /// <returns>Rows of labor cost details</returns>
        public static IEnumerable<LaborCost> FetchLaborTypeCostDetails(string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<LaborCost>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetLabourTypeCost : Resources.Ecolab_GetLabourTypeCost, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                });
        }

        /// <summary>
        ///     Save labor cost details
        /// </summary>
        /// <param name="laborCost">LaborCost object</param>
        /// <param name="trans">The trans parameter</param>
        /// <param name="context">The Context parameter.</param>
        /// <param name="userId">The Parameter user id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <param name="errorCode">error Code. </param>
        /// <returns>Id of labor cost record</returns>
        public static int SaveLaborCost(LaborCost laborCost, ref DbTransaction trans, ref DbContext context, int userId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            errorCode = 0;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramLaborCostId = new SqlParameter { ParameterName = "OutputLaborCostId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveLabourCost : Resources.Ecolab_SaveLabourCost, delegate (DbCommand cmd, DbContext context2)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("LaborTypeId", laborCost.LaborTypeId);
                        cmd.AddParameter("LaborCost", laborCost.Cost);
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, laborCost.EcolabAccountNumber);
                        cmd.AddParameter("UserID", userId);
                        if (laborCost.LastModifiedTimestampAtCentral.HasValue)
                        {
                            cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, laborCost.LastModifiedTimestampAtCentral.Value);
                        }
                        cmd.Parameters.Add(param);
                        cmd.Parameters.Add(paramLaborCostId);
                        cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    });
            int status = 0;
            status = int.TryParse(param.Value.ToString(), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;

            if (Convert.ToInt32(param.Value) != 201)
            {
                errorCode = (int)param.Value;
            }
            else
            {
                returnValue = Convert.IsDBNull(paramLaborCostId.Value) ? 0 : (int)paramLaborCostId.Value;
                returnValue = status > 0 && status != 201 ? status : returnValue;
            }

            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("TableName", DbType.String, 1000, "TCD.LaborCost");
                 });
        }

        /// <summary>
        ///     validate Labor Cost for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateLaborCostSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(
                "TCD.ValidateLaborCostSave",
                 delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Saves the labor cost for first time synchronize.
        /// </summary>
        /// <param name="objLaborCost">The object labor cost.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveLaborCostForFirstTimeSync(LaborCost objLaborCost, int userId)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_SaveLaborCostDetailsForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("LaborCostId", objLaborCost.Id);
                cmd.AddParameter("LaborTypeId", objLaborCost.LaborTypeId);
                cmd.AddParameter("Cost", objLaborCost.Cost);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, objLaborCost.EcolabAccountNumber);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, objLaborCost.LastModifiedTimeStamp);
            });
        }
    }
}