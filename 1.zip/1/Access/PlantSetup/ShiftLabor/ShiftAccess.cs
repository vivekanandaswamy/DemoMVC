﻿// -----------------------------------------------------------------------
// <copyright file="ShiftAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Shift Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup;
    using Entities.PlantSetup.ShiftLabor;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    /// </summary>
    public class ShiftAccess
    {
        /// <summary>
        ///     Get the shift and break details
        /// </summary>
        /// <param name="shiftId">The Shift Id.</param>
        /// <param name="dayId">The day id.</param>
        /// <param name="ecolabAccNumber">Ecolab Account number</param>
        /// <returns>Row of shift details</returns>
        public static List<Shift> FetchShiftDetails(int? shiftId, int? dayId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<Shift>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetShiftDetails : Resources.Ecolab_GetShiftDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ShiftId", shiftId);
                cmd.AddParameter("DayId", dayId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Get the shift and break details
        /// </summary>
        /// <param name="shiftId">The Shift Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account number</param>
        /// <returns>Row of shift details</returns>
        public static List<Shift> FetchFullShiftDetails(int shiftId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Shift>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetShiftBulkObject : "TCD.GetShiftBulkObject", delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ShiftId", shiftId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Insert shift and break Details
        /// </summary>
        /// <param name="shift">the shift object</param>
        /// <param name="trans">The Trans parameter.</param>
        /// <param name="context">The Context parameter.</param>
        /// <param name="userId">The user id</param>
        /// <param name="shiftId">The shift id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>Returns The string.</returns>
        public static string InsertShiftAndBreak(Shift shift, ref DbTransaction trans, ref DbContext context, int userId, out int shiftId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            errorCode = 0;
            shiftId = 0;
            string status = String.Empty;
            try
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "Scope";
                param.SqlDbType = SqlDbType.VarChar;
                param.Size = 100;
                param.Direction = ParameterDirection.Output;

                SqlParameter paramShiftId = new SqlParameter { ParameterName = "OutputShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
                SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
                if (shift.ShiftBreak.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.ShiftBreak.EndTime = new TimeSpan(23, 59, 59);
                }
                if (shift.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.EndTime = new TimeSpan(23, 59, 59);
                }

                status = DbClient.ExecuteScalar<string>(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_InsertShiftAndBreak : Resources.Ecolab_InsertShiftBreak, delegate (DbCommand cmd, DbContext context2)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ShiftId", shift.ShiftId);
                    cmd.AddParameter("ShiftName", DbType.String, 100, shift.ShiftName);
                    cmd.AddParameter("DayId", shift.DayId);
                    cmd.AddParameter("StartTime", shift.StartTime);
                    cmd.AddParameter("EndTime", shift.EndTime);
                    cmd.AddParameter("TargetProd", shift.TargetProduction);
                    cmd.AddParameter("BreakStartTime", shift.ShiftBreak.StartTime);
                    cmd.AddParameter("BreakEndTime", shift.ShiftBreak.EndTime);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shift.EcolabAccountNumber);
                    cmd.AddParameter("Count", shift.Count);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("TargetProdDisplay", shift.TargetProductionDisplay);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramShiftId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
                status = Convert.IsDBNull(param.Value) ? null : (string)param.Value;
                lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : Convert.ToDateTime(paramLastModifiedTimeStamp.Value.ToString());
                shiftId = Convert.IsDBNull(paramShiftId.Value) ? 0 : (int)paramShiftId.Value;
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }

            return status;
        }

        /// <summary>
        ///     Update shift and break Details
        /// </summary>
        /// <param name="shift">the shift object</param>
        /// <param name="trans">The trans parameter.</param>
        /// <param name="context">The context parameter.</param>
        /// <param name="userId">the user id</param>
        /// <param name="shiftId">The shift id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>returns the string.</returns>
        public static string UpdateShiftAndBreak(Shift shift, ref DbTransaction trans, ref DbContext context, int userId, out int shiftId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            errorCode = 0;
            shiftId = 0;
            string status = String.Empty;

            try
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "Result";
                param.SqlDbType = SqlDbType.VarChar;
                param.Size = 100;
                param.Direction = ParameterDirection.Output;

                SqlParameter paramShiftId = new SqlParameter { ParameterName = "OutputShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
                SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
                if (shift.ShiftBreak.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.ShiftBreak.EndTime = new TimeSpan(23, 59, 59);
                }
                if (shift.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.EndTime = new TimeSpan(23, 59, 59);
                }

                status = DbClient.ExecuteScalar<string>(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateShiftAndBreak : Resources.Ecolab_UpdateShiftBreak, delegate (DbCommand cmd, DbContext context2)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ShiftId", shift.ShiftId);
                    cmd.AddParameter("ShiftName", DbType.String, 50, shift.ShiftName);
                    cmd.AddParameter("StartTime", shift.StartTime);
                    cmd.AddParameter("EndTime", shift.EndTime);
                    cmd.AddParameter("TargetProd", shift.TargetProduction);
                    cmd.AddParameter("BreakId", shift.ShiftBreak.BreakId);
                    cmd.AddParameter("BreakStartTime", shift.ShiftBreak.StartTime);
                    cmd.AddParameter("BreakEndTime", shift.ShiftBreak.EndTime);
                    cmd.AddParameter("IsDeleted", shift.ShiftBreak.IsDeleted);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shift.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("IsMonday", shift.IsMonday);
                    cmd.AddParameter("IsTuesday", shift.IsTuesday);
                    cmd.AddParameter("IsWednesday", shift.IsWednesday);
                    cmd.AddParameter("IsThursday", shift.IsThursday);
                    cmd.AddParameter("IsFriday", shift.IsFriday);
                    cmd.AddParameter("IsSaturday", shift.IsSaturday);
                    cmd.AddParameter("IsSunday", shift.IsSunday);
                    cmd.AddParameter("Count", shift.Count);
                    cmd.AddParameter("TargetProdDisplay", shift.TargetProductionDisplay);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramShiftId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
                if (param.Value != null)
                {
                    status = Convert.IsDBNull(param.Value) ? null : (string)param.Value;
                }

                if (paramLastModifiedTimeStamp.Value != null)
                {
                    DateTime dt;
                    if (DateTime.TryParse(paramLastModifiedTimeStamp.Value.ToString(), out dt))
                    {
                        lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
                    }
                }
                if (paramShiftId.Value != null)
                {
                    shiftId = Convert.IsDBNull(paramShiftId.Value) ? 0 : (int)paramShiftId.Value;
                }
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return status;
        }

        /// <summary>
        ///     Delete shift and break Details
        /// </summary>
        /// <param name="shift">shift object</param>
        /// <param name="userId">the user id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>The boolean value .</returns>
        public static int DeleteShiftAndBreak(Shift shift, int userId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            errorCode = 0;

            try
            {
                SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteShiftAndBreak : Resources.Ecolab_DeleteShiftBreak, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ShiftId", shift.ShiftId);
                    cmd.AddParameter("DayId", shift.DayId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shift.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
                lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     Delete break Details
        /// </summary>
        /// <param name="shift">shoft object.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>The boolean value.</returns>
        public static int DeleteBreak(Shift shift, int userId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.UtcNow;
            errorCode = 0;

            try
            {
                SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteBreak : Resources.Ecolab_DeleteBreak, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ShiftId", shift.ShiftId);
                    cmd.AddParameter("DayId", shift.DayId);
                    cmd.AddParameter("BreakId", shift.ShiftBreak.BreakId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shift.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
                lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     Get the Target Production details
        /// </summary>
        /// <param name="ecolabAccNumber">Ecolab Account number</param>
        /// <returns>Row of target production details</returns>
        public static List<TargetProduction> FetchTargetProduction(string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<TargetProduction>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_FetchTargetProductionDetails : Resources.Ecolab_FetchTargetProductionDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        /// Saves Target Production
        /// </summary>
        /// <param name="shift">shoft object.</param>
        /// <param name="trans">The trans.</param>
        /// <param name="context">The context.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="targetProductionId">The target production identifier.</param>
        /// <param name="lastModifiedTimestamp">The last modified time stamp.</param>
        /// <param name="errorCode">The error code.</param>
        /// <returns>
        /// The string value.
        /// </returns>
        public static string SaveTargetProduction(TargetProduction shift, ref DbTransaction trans, ref DbContext context, string ecolabAccountNumber, int userId, out int targetProductionId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            targetProductionId = 0;
            errorCode = 0;
            string status = String.Empty;
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            SqlParameter paramTargetProductionId = new SqlParameter { ParameterName = "OutputTargetProductionId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            status = DbClient.ExecuteScalar<string>(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveTargetProduction : Resources.Ecolab_SaveTargetProduction, delegate (DbCommand cmd, DbContext context2)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ShiftId", shift.ShiftId);
                cmd.AddParameter("DayId", shift.DayId);
                cmd.AddParameter("TargetProduction", shift.TargetProd);
                cmd.AddParameter("RecordedDate", DbType.DateTime, shift.RecordedDate);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("TargetProductionDisplay", shift.TargetProdDisplay);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramTargetProductionId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            if (paramLastModifiedTimeStamp.Value != null)
            {
                DateTime dt;
                if (DateTime.TryParse(paramLastModifiedTimeStamp.Value.ToString(), out dt))
                {
                    lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
                }
            }
            if (paramTargetProductionId.Value != null)
            {
                targetProductionId = Convert.IsDBNull(paramTargetProductionId.Value) ? 0 : (int)paramTargetProductionId.Value;
            }
            if (param.Value != null)
            {
                status = Convert.IsDBNull(param.Value) ? null : (string)param.Value;
            }
            return status;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.ShiftData");
            });
        }

        /// <summary>
        ///     validate Shift for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateShiftSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateShiftSave : Resources.Ecolab_ValidateShiftSave, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                });
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// To rollup the data based on shift for reports
        /// </summary>
        /// <returns>returns status</returns>
        public static int RollupDataForReports(ref int redFlagShiftId)
        {
            int returnValue = 0;
            try
            {
                SqlParameter param = new SqlParameter { ParameterName = "RedFlagShiftId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
                returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ProductionShiftDataRollup, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("InputShiftId", 0);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(param);
                });
                redFlagShiftId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);
            }
            catch (Exception ex)
            {
                //returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     validate Shift for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateTargetProductionSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidateTargetProductionSave, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                });
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("51030"))
                {
                    returnValue = 51030;
                }
                else
                {
                    throw;
                }
            }
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecordsForTargetProduction(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.TargetProductionDetails");
            });
        }

        /// <summary>
        ///     Get the Target Production details
        /// </summary>
        /// <param name="ecolabAccNumber">Ecolab Account number</param>
        /// <returns>Row of target production details</returns>
        public static List<TargetProduction> FetchTargetProductionForSync(string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<TargetProduction>(Resources.Ecolab_FetchTargetProductionForSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Get the Cost by LabourType
        /// </summary>
        /// <returns> The Parameter  cost </returns>
        public static List<Shift> FetchRunningShiftDetails()
        {
            return DbClient.ExecuteReader<Shift>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetRunningShifts : Resources.Ecolab_GetRunningShifts, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Get the shift and break details
        /// </summary>
        /// <param name="shiftId">The Shift Id.</param>
        /// <param name="dayId">The day id.</param>
        /// <param name="ecolabAccNumber">Ecolab Account number</param>
        /// <param name="isDeleted">isDeleted</param>
        /// <returns>Row of shift details</returns>
        public static List<Shift> FetchShiftDetailsForSync(int? shiftId, int? dayId, string ecolabAccNumber, bool isDeleted)
        {
            return DbClient.ExecuteReader<Shift>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetShiftDetails : Resources.Ecolab_GetShiftDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ShiftId", shiftId);
                cmd.AddParameter("DayId", dayId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                cmd.AddParameter("IsDeleted", isDeleted);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Insert shift and break Details
        /// </summary>
        /// <param name="shift">the shift object</param>
        /// <param name="trans">The Trans parameter.</param>
        /// <param name="context">The Context parameter.</param>
        /// <param name="userId">The user id</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>Returns The string.</returns>
        public static string ValidateShiftOverlapp(Shift shift, ref DbTransaction trans, ref DbContext context, int userId, out int errorCode)
        {
            errorCode = 0;
            string status = string.Empty;
            try
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "Scope";
                param.SqlDbType = SqlDbType.VarChar;
                param.Size = 100;
                param.Direction = ParameterDirection.Output;

                if (shift.ShiftBreak.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.ShiftBreak.EndTime = new TimeSpan(23, 59, 59);
                }
                if (shift.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.EndTime = new TimeSpan(23, 59, 59);
                }
                DateTime endTime = Convert.ToDateTime(shift.EndTime.ToString());
                DateTime startTime = Convert.ToDateTime(shift.StartTime.ToString());
                status = DbClient.ExecuteScalar<string>(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateShiftsOverlapp : Resources.Ecolab_ValidateShiftsOverlapp, delegate (DbCommand cmd, DbContext context2)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ShiftId", shift.ShiftId);
                    cmd.AddParameter("ShiftName", DbType.String, 100, shift.ShiftName);
                    cmd.AddParameter("DayId", shift.DayId);
                    cmd.AddParameter("StartTime", DbType.DateTime, startTime);
                    cmd.AddParameter("EndTime", DbType.DateTime, endTime);
                    cmd.AddParameter("TargetProd", shift.TargetProduction);
                    cmd.AddParameter("BreakStartTime", shift.ShiftBreak.StartTime);
                    cmd.AddParameter("BreakEndTime", shift.ShiftBreak.EndTime);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shift.EcolabAccountNumber);
                    cmd.AddParameter("Count", shift.Count);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("TargetProdDisplay", shift.TargetProductionDisplay);
                    cmd.Parameters.Add(param);
                });
                status = Convert.IsDBNull(param.Value) ? null : (string)param.Value;
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }

            return status;
        }

        /// <summary>
        ///     Update shift and break Details
        /// </summary>
        /// <param name="shift">the shift object</param>
        /// <param name="trans">The trans parameter.</param>
        /// <param name="context">The context parameter.</param>        
        /// <param name="errorCode">Error Code</param>
        /// <returns>returns the string.</returns>
        public static string ValidateUpdateShiftOverlapp(Shift shift, ref DbTransaction trans, ref DbContext context, out int errorCode)
        {
            errorCode = 0;
            string status = string.Empty;

            try
            {
                SqlParameter param = new SqlParameter();
                param.ParameterName = "Result";
                param.SqlDbType = SqlDbType.VarChar;
                param.Size = 100;
                param.Direction = ParameterDirection.Output;

                if (shift.ShiftBreak.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.ShiftBreak.EndTime = new TimeSpan(23, 59, 59);
                }
                if (shift.EndTime == new TimeSpan(00, 00, 00))
                {
                    shift.EndTime = new TimeSpan(23, 59, 59);
                }

                status = DbClient.ExecuteScalar<string>(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateUpdateShiftsOverlapp : Resources.Ecolab_ValidateUpdateShiftsOverlapp, delegate (DbCommand cmd, DbContext context2)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ShiftId", shift.ShiftId);
                    cmd.AddParameter("ShiftName", DbType.String, 50, shift.ShiftName);
                    cmd.AddParameter("StartTime", shift.StartTime);
                    cmd.AddParameter("EndTime", shift.EndTime);
                    cmd.AddParameter("TargetProd", shift.TargetProduction);
                    cmd.AddParameter("BreakId", shift.ShiftBreak.BreakId);
                    cmd.AddParameter("BreakStartTime", shift.ShiftBreak.StartTime);
                    cmd.AddParameter("BreakEndTime", shift.ShiftBreak.EndTime);
                    cmd.AddParameter("IsDeleted", shift.ShiftBreak.IsDeleted);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shift.EcolabAccountNumber);
                    cmd.AddParameter("IsMonday", shift.IsMonday);
                    cmd.AddParameter("IsTuesday", shift.IsTuesday);
                    cmd.AddParameter("IsWednesday", shift.IsWednesday);
                    cmd.AddParameter("IsThursday", shift.IsThursday);
                    cmd.AddParameter("IsFriday", shift.IsFriday);
                    cmd.AddParameter("IsSaturday", shift.IsSaturday);
                    cmd.AddParameter("IsSunday", shift.IsSunday);
                    cmd.AddParameter("Count", shift.Count);
                    cmd.AddParameter("TargetProdDisplay", shift.TargetProductionDisplay);
                    cmd.Parameters.Add(param);
                });
                if (param.Value != null)
                {
                    status = Convert.IsDBNull(param.Value) ? null : (string)param.Value;
                }
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return status;
        }

        /// <summary>
        ///     Get the Fetch Shift Production Data
        /// </summary>
        /// <returns>Fetch Shift ProductionData details</returns>
        public static List<ProductionShiftData> FetchShiftProductionData()
        {
            return DbClient.ExecuteReader<ProductionShiftData>(Resources.Ecolab_FetchProductionShiftData, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        /// Saves the shift details for first time synchronize.
        /// </summary>
        /// <param name="shift">The shift.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveShiftDetailsForFirstTimeSync(Shift shift, int userId)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_InsertUpdateShiftDetailsForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ShiftId", shift.ShiftId);
                cmd.AddParameter("ShiftName", DbType.String, 100, shift.ShiftName);
                cmd.AddParameter("DayId", shift.DayId);
                cmd.AddParameter("StartTime", shift.StartTime);
                cmd.AddParameter("EndTime", shift.EndTime);
                cmd.AddParameter("TargetProduction", shift.TargetProduction);
                cmd.AddParameter("IsDeleted", shift.IsDelete);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shift.EcolabAccountNumber);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, shift.LastModifiedTimeStamp);
                cmd.AddParameter("TargetProductionDisplay", shift.TargetProductionDisplay);
                cmd.AddParameter("BreakId", shift.ShiftBreak.BreakId);
                cmd.AddParameter("BreakStartTime", shift.ShiftBreak.StartTime);
                cmd.AddParameter("BreakEndTime", shift.ShiftBreak.EndTime);
                cmd.AddParameter("IsBreakDeleted", shift.ShiftBreak.IsDeleted);
            });
        }

        /// <summary>
        /// Saves the target production for first time synchronize.
        /// </summary>
        /// <param name="targetProduction">The target production.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveTargetProductionForFirstTimeSync(TargetProduction targetProduction, int userId)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_SaveTargetProductionDetailsForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("Id", targetProduction.Id);
                cmd.AddParameter("ShiftId", targetProduction.ShiftId);
                cmd.AddParameter("DayId", targetProduction.DayId);
                cmd.AddParameter("RecordedDate", DbType.DateTime, targetProduction.RecordedDate);
                cmd.AddParameter("TargetProduction", targetProduction.TargetProd);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, targetProduction.EcolabAccountNumber);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("TargetProductionDisplay", targetProduction.TargetProdDisplay);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, targetProduction.LastModifiedTime);
            });
        }
    }
}