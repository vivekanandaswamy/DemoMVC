﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Shift Labor Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.ShiftLabor;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for ShiftLaborAccess
    /// </summary>
    public class ShiftLaborAccess
    {
        /// <summary>
        ///     Get the shift labor details
        /// </summary>
        /// <param name="plantId"> Ecolab account number </param>
        /// <returns>list of shift labor details</returns>
        public static List<ShiftLabor> FetchShiftLaborDetails(string plantId)
        {
            return DbClient.ExecuteReader<ShiftLabor>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetShiftLabor : Resources.Ecolab_GetShiftLabor, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantId);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Insert shift and break Details
        /// </summary>
        /// <param name="shiftLabor">shift labor object.</param>
        /// <param name="userId">The Parameter user id</param>
        /// <param name="lastModifiedTimestamp">Last Modified TimeStamp</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>returns Integer.</returns>
        public static int InsertShiftLabor(ShiftLabor shiftLabor, int userId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            errorCode = 0;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramShiftLaborId = new SqlParameter { ParameterName = "OutputShiftLaborDataId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_InsertShiftLabor : Resources.Ecolab_InsertShiftLabor, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ShiftId", shiftLabor.ShiftId);
                cmd.AddParameter("DayId", shiftLabor.DayId);
                cmd.AddParameter("LaborHours", shiftLabor.LaborHours);
                cmd.AddParameter("PricePerHr", shiftLabor.PricePerHr);
                cmd.AddParameter("LaborTypeId", shiftLabor.LaborTypeId);
                cmd.AddParameter("LaborCount", shiftLabor.LaborCount);
                cmd.AddParameter("LocationId", shiftLabor.LocationId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shiftLabor.EcolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramShiftLaborId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramShiftLaborId.Value) ? 0 : (int)paramShiftLaborId.Value;
            if (returnValue > 0)
            {
                shiftLabor.LaborId = returnValue;
            }
            returnValue = status > 0 ? status : returnValue;

            return returnValue;
        }

        /// <summary>
        ///     Update shift and break Details
        /// </summary>
        /// <param name="shiftLabor">The shift labor object.</param>
        /// <param name="userId">The Parameter user id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>returns Integer.</returns>
        public static int UpdateShiftLabor(ShiftLabor shiftLabor, int userId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            errorCode = 0;

            try
            {
                SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

                SqlParameter paramShiftLaborId = new SqlParameter { ParameterName = "OutputShiftLaborDataId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

                SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

                DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateShiftLabor : Resources.Ecolab_UpdateShiftLabor, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Id", shiftLabor.LaborId);
                    cmd.AddParameter("ShiftId", shiftLabor.ShiftId);
                    cmd.AddParameter("DayId", shiftLabor.DayId);
                    cmd.AddParameter("LaborHours", shiftLabor.LaborHours);
                    cmd.AddParameter("PricePerHr", shiftLabor.PricePerHr);
                    cmd.AddParameter("LaborTypeId", shiftLabor.LaborTypeId);
                    cmd.AddParameter("LaborCount", shiftLabor.LaborCount);
                    cmd.AddParameter("LocationId", shiftLabor.LocationId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shiftLabor.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    if (Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central)
                    {
                        cmd.AddParameter("Lastmodifiedtimestampatcentral", DbType.DateTime, null);
                    }
                    
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramShiftLaborId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
                int status = 0;
                status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
                lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
                returnValue = Convert.IsDBNull(paramShiftLaborId.Value) ? 0 : (int)paramShiftLaborId.Value;
                returnValue = status > 0 ? status : returnValue;
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     Delete shift and break Details
        /// </summary>
        /// <param name="shiftLabor">the shift labor object</param>
        /// <param name="userId">The Parameter user id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="errorCode">Error Code</param>
        /// <returns>Returns ?Integer.</returns>
        public static int DeleteShiftLabor(ShiftLabor shiftLabor, int userId, out DateTime lastModifiedTimestamp, out int errorCode)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.UtcNow;
            errorCode = 0;

            try
            {
                SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

                SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
                DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteShiftLabor : Resources.Ecolab_DeleteShiftLabor, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Id", shiftLabor.LaborId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shiftLabor.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
                int status = 0;
                status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
                lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
                returnValue = status;
            }
            catch (Exception ex)
            {
                errorCode = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     Get the Cost by LabourType
        /// </summary>
        /// <param name="laborTypeId">labor type id</param>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <returns> The Parameter  cost </returns>
        public static LaborTypeCost FetchCostByLabourType(int laborTypeId, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<LaborTypeCost>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetCostByLabourTypeId : Resources.Ecolab_GetCostByLabourTypeId, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("LaborTypeId", laborTypeId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            }).FirstOrDefault();
        }

        /// <summary>
        ///     validate Labor Cost for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateShiftLaborDataSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateShiftLaborDataSave : Resources.Ecolab_ValidateShiftLaborDataSave, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                });
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     Get the shift labor details for sync
        /// </summary>
        /// <param name="plantId"> Ecolab account number </param>
        /// <param name="isDeleted">isDeleted</param>
        /// <returns>list of shift labor details</returns>
        public static List<ShiftLabor> FetchShiftLaborDetailsForSync(string plantId, bool isDeleted)
        {
            return DbClient.ExecuteReader<ShiftLabor>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetShiftLabor : Resources.Ecolab_GetShiftLabor, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantId);
                cmd.AddParameter("IsDeleted", isDeleted);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.ShiftLaborData");
            });
        }

        /// <summary>
        /// Saves the shift labor for first time synchronize.
        /// </summary>
        /// <param name="shiftLabor">The shift labor.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveShiftLaborForFirstTimeSync(ShiftLabor shiftLabor, int userId)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_InsertUpdateShiftLaborForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("LaborId", shiftLabor.LaborId);
                cmd.AddParameter("ShiftId", shiftLabor.ShiftId);
                cmd.AddParameter("DayId", shiftLabor.DayId);
                cmd.AddParameter("LaborHours", shiftLabor.LaborHours);
                cmd.AddParameter("PricePerHr", shiftLabor.PricePerHr);
                cmd.AddParameter("LaborTypeId", shiftLabor.LaborTypeId);
                cmd.AddParameter("LaborCount", shiftLabor.LaborCount);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, shiftLabor.EcolabAccountNumber);
                cmd.AddParameter("IsDeleted", shiftLabor.IsDeleted);
                cmd.AddParameter("LocationId", shiftLabor.LocationId);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, shiftLabor.LastModifiedTimeStamp);
            });
        }
    }
}