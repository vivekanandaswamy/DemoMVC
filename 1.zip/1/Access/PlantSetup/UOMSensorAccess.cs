﻿// -----------------------------------------------------------------------
// <copyright file="UOMSensorAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  UOM Sensor Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for UOMSensorAccess
    /// </summary>
    public class UomSensorAccess
    {
        /// <summary>
        ///     Get SensorOutPutType details
        /// </summary>
        /// <param name="sensorType">sensor type values</param>
        /// <returns>The list of Sensor output type</returns>
        public static List<UomSensor> GetUomSensoretails(int? sensorType)
        {
            return DbClient.ExecuteReader<UomSensor>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetUOMSensorDetails : Resources.Ecolab_GetUOMSensorDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("SensorType", sensorType);
            }).ToList();
        }
    }
}