﻿// -----------------------------------------------------------------------
// <copyright file="SensorChemicalChartAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  Sensor Chemical Chart Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for SensorChemicalChartAccess
    /// </summary>
    public class SensorChemicalChartAccess
    {
        /// <summary>
        ///     Get Sensor Chemical Chart details
        /// </summary>
        /// <param name="groupId">The Group Id</param>
        /// <param name="machineId">The Machine Id</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="ecolabAccountNumber">The Ecolab Account Number</param>
        /// <returns>The list of Sensor Chemical Chart</returns>
        public static List<SensorChemicalChart> GetSensorChemicalChartDetails(int? groupId, int? machineId, int? controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<SensorChemicalChart>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetSensorChemicalDetails : Resources.Ecolab_GetSensorChemicalDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("GroupId", groupId);
                cmd.AddParameter("MachineId", machineId);
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }
    }
}