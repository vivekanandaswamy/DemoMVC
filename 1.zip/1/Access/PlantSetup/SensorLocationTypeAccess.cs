﻿// -----------------------------------------------------------------------
// <copyright file="SensorLocationTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  Sensor Location Type Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for SensorLocationTypeAccess
    /// </summary>
    public class SensorLocationTypeAccess
    {
        /// <summary>
        ///     Get Sensor location type details
        /// </summary>
        /// <returns>The list of Sensor location type</returns>
        public static List<SensorLocationType> GetSensorLocationTypeDetails()
        {
            return DbClient.ExecuteReader<SensorLocationType>(Resources.Ecolab_GetSensorLocationDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}