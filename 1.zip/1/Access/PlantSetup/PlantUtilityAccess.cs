﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityAccess.cs" company="Ecolab">
// This class is for saving the utility values in database.
// </copyright>
// <summary>The Plant Utility Access for saving data.</summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for plant utility to save values.
    /// </summary>
    public class PlantUtilityAccess
    {
        /// <summary>
        ///     Save/Update utility details.
        /// </summary>
        /// <param name="utility">The utility object</param>
        /// <param name="userId"> user id </param>
        public static int SavePlantUtilityDetails(PlantUtility utility, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            string factorTypes = utility.Location == "1" ? "Cold,Hot,Tempered,Waste/Sewer,Free1,Free2,Free3,Energy,Electricity" : "Cold Soft,Cold Hard,Soft,Hot Hard,Hot,Tempered,Waste/Sewer,Free1,Free2,Free3,Energy,Electricity";
            SqlParameter paramPlantUtilityId = new SqlParameter { ParameterName = "OutputId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_savePlantUtilityDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("UtilityType", utility.UtilityType);
                cmd.AddParameter("FactorType", DbType.String, 255, utility.FactorType);
                cmd.AddParameter("FactorTypes", DbType.String, 255,factorTypes );
                cmd.AddParameter("ColdTemprature", utility.ColdTemp);
                cmd.AddParameter("ColdPrice", utility.ColdPrice);
                cmd.AddParameter("HotTemparature", utility.HotTemp);
                cmd.AddParameter("HotPrice", utility.HotPrice);
                cmd.AddParameter("TemperedTemprature", utility.TemperedTemp);
                cmd.AddParameter("TemperedPrice", utility.TemperedPrice);
                cmd.AddParameter("WasteWaterPrice", utility.WastewaterPrice);
                cmd.AddParameter("Free1Temprature", utility.Free1Temp);
                cmd.AddParameter("Free1Price", utility.Free1Price);
                cmd.AddParameter("Free2Temprature", utility.Free2Temp);
                cmd.AddParameter("Free2Price", utility.Free2Price);
                cmd.AddParameter("Free3Temprature", utility.Free3Temp);
                cmd.AddParameter("Free3Price", utility.Free3Price);
                cmd.AddParameter("Energy", utility.Energy);
                cmd.AddParameter("GasPrice", utility.GasPrice);
                cmd.AddParameter("ElectricityTarrif", utility.ElectricityTarrif);
                cmd.AddParameter("Location", DbType.String, 255, utility.Location);
                cmd.AddParameter("BolierSteam", utility.BoilerSteam);
                cmd.AddParameter("BolierType", utility.BoilerType);
                cmd.AddParameter("Steam", utility.SteamPercentage);
                cmd.AddParameter("Boiler", utility.BoilerPercentage);
                cmd.AddParameter("Stack", utility.StackPercentage);
                cmd.AddParameter("RewashFactor", utility.RewashFactor);
                cmd.AddParameter("ColdSoftTemprature", utility.ColdSoftTemp);
                cmd.AddParameter("ColdSoftPrice", utility.ColdSoftPrice);
                cmd.AddParameter("HotHardTemparature", utility.HotHardTemp);
                cmd.AddParameter("HotHardPrice", utility.HotHardPrice);
                cmd.AddParameter("ColdHardTemprature", utility.ColdHardTemp);
                cmd.AddParameter("ColdHardPrice", utility.ColdHardPrice);
                cmd.AddParameter("HotSoftTemparature", utility.HotSoftTemp);
                cmd.AddParameter("HotSoftPrice", utility.HotSoftPrice);
                cmd.AddParameter("Free1FactorType", DbType.String, 255, utility.Free1FactorType != "None" ? utility.Free1FactorType : "0");
                cmd.AddParameter("Free2FactorType", DbType.String, 255, utility.Free2FactorType != "None" ? utility.Free2FactorType : "0");
                cmd.AddParameter("Free3FactorType", DbType.String, 255, utility.Free3FactorType != "None" ? utility.Free3FactorType : "0");
                cmd.AddParameter("GasOilType", DbType.String, 255, utility.GasoilType);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("EnergyContentUnit", DbType.String, 255, utility.EnergyContentUnit);
                cmd.AddParameter("EnergyPriceUnit", DbType.String, 255, utility.EnergyPriceUnit);
                cmd.AddParameter("EvaporationFactor", utility.EvaporationFactor);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, utility.EcoalabAccountNumber);
                cmd.AddParameter("RegionCode", DbType.String, 1000, utility.RegionCode);
                cmd.Parameters.Add(paramPlantUtilityId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            int status = 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramPlantUtilityId.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramPlantUtilityId.Value) ? 0 : (int)paramPlantUtilityId.Value;
            returnValue = status > 0 ? status : returnValue;

            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.PlantUtilityEnergyProperties");
            });
        }

        /// <summary>
        ///     validate Plant Utility for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidatePlantUtilitySave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateCustomerSave : Resources.Ecolab_ValidateCustomerSave, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }
    }
}