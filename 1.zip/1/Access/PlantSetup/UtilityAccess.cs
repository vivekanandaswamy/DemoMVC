﻿// -----------------------------------------------------------------------
// <copyright file="UtilityAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  Water Energy Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.Common;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for UtilityAccess
    /// </summary>
    public class UtilityAccess
    {
        /// <summary>
        ///     Get the water energy details
        /// </summary>
        /// <returns> Row of  water energy details</returns>
        public static List<Utility> GetUtilityyDetails(string ecolabAccountNumber, bool? isResync = null)
        {
            return DbClient.ExecuteReader<Utility>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetUtilityyDetails : Resources.Ecolab_GetUtilityyDetails,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("IsResync", isResync);
                }).ToList();
        }

        /// <summary>
        /// Save/Update water energy details.
        /// </summary>
        /// <param name="utility">The utility object.</param>
        /// <param name="userId">The Parameter  user Id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="myServiceLastSyncTime">My service last synchronize time.</param>
        /// <returns>
        /// Returns Integer
        /// </returns>
        public static int SaveUtilityDetails(Utility utility, int userId, out DateTime lastModifiedTimestamp, DateTime? myServiceLastSyncTime = null)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;

            var paramDeviceNumber = new SqlParameter
            {
                ParameterName = "OutputDeviceNumber",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            var paramLastModifiedTimeStamp = new SqlParameter
            {
                ParameterName = "OutputLastModifiedTimestampAtLocal",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveUtilityDetails : Resources.Ecolab_SaveUtilityDetails,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("MyServiceCustWtrEnrgDvcGuid", utility.MyServiceCustWtrEnrgDvcGUID);
                    cmd.AddParameter("ID", utility.Id);
                    cmd.AddParameter("DeviceNumber", utility.DeviceNumber);
                    cmd.AddParameter("DeviceName", DbType.String, 200, utility.DeviceName);
                    cmd.AddParameter("DeviceTypeId", utility.DeviceTypeId);
                    cmd.AddParameter("DeviceModelId", utility.DeviceModelId);
                    cmd.AddParameter("DeviceNote", DbType.String, 200, utility.DeviceNoteDesc);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, utility.EcolabAccountNumber);
                    cmd.AddParameter("Comment", DbType.String, 200, utility.Comment);
                    cmd.AddParameter("InstallDate", DbType.DateTime, utility.InstallDate);
                    cmd.AddParameter("Is_deleted", utility.IsDeleted);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("MyServiceLastSyncTime", DbType.DateTime, myServiceLastSyncTime);
                    if (utility.LastModifiedTimestampAtCentral.HasValue && utility.LastModifiedTimestampAtCentral.Value != DateTime.MinValue)
                    {
                        cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, utility.LastModifiedTimestampAtCentral.Value);
                    }
                    cmd.Parameters.Add(paramDeviceNumber);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });

            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramDeviceNumber.Value) ? 0 : (int)paramDeviceNumber.Value;

            return returnValue;
        }

        /// <summary>
        /// Delete water energy.
        /// </summary>
        /// <param name="deviceNumber">The Parameter  device number</param>
        /// <param name="userId">The Parameter User Id</param>
        /// <param name="ecolabAccountNumber">The Parameter ecolab Account Number</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>
        /// Returns Integer value
        /// </returns>
        public static int DeleteUtilityDetails(int deviceNumber, int userId, string ecolabAccountNumber, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;

            var paramLastModifiedTimeStamp = new SqlParameter
            {
                ParameterName = "OutputLastModifiedTimestampAtLocal",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteUtilityDetails : Resources.Ecolab_DeleteUtilityDetails,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ID", deviceNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(deviceNumber) ? 0 : (int)deviceNumber;

            return returnValue;
        }

        /// <summary>
        ///      Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords,
                 delegate (DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("TableName", DbType.String, 1000, "TCD.WaterAndEnergy"); //to be verified
                 });
        }

        /// <summary>
        ///     validate formula for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateUtilitySave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateUtilitySave : Resources.Ecolab_ValidateUtilitySave,
                 delegate (DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Save or update myservice DeviceType details
        /// </summary>
        /// <param name="deviceType">Type of the device.</param>
        /// <returns></returns>
        public static Int16 SaveMyServiceDeviceTypeDetails(DeviceType deviceType)
        {
            Int16 returnValue = 0;

            var paramDeviceTypeId = new SqlParameter
            {
                ParameterName = "OutputDeviceTypeId",
                SqlDbType = SqlDbType.SmallInt,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              "[TCD].[UpdateMyServiceDeviceTypeDetails]",
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("DeviceTypeId", deviceType.DeviceTypeId);
                  cmd.AddParameter("Description", DbType.String, 255, deviceType.Description);
                  cmd.AddParameter("RegionCode", deviceType.RegionCode);
                  cmd.AddParameter("IsDeleted", deviceType.IsDeleted);
                  cmd.AddParameter("MyServiceWtrEnrgDvcTypId", deviceType.MyServiceDeviceTypeId);
                  cmd.Parameters.Add(paramDeviceTypeId);
              });
            returnValue = Convert.ToInt16(Convert.IsDBNull(paramDeviceTypeId.Value) ? 0 : Convert.ToInt16(paramDeviceTypeId.Value));
            return returnValue;
        }

        /// <summary>
        ///     Save or update myservice DeviceType locale details
        /// </summary>
        /// <param name="myserviceDeviceTypeDetails">myserviceDeviceTypeDetails</param>
        public static void SaveMyServiceDeviceTypeLocaleDetails(DeviceType myserviceDeviceTypeDetails)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252, "FIELD_" + myserviceDeviceTypeDetails.Description.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myserviceDeviceTypeDetails.Description);
                    cmd.AddParameter("Spanish", DbType.String, 252, myserviceDeviceTypeDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myserviceDeviceTypeDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myserviceDeviceTypeDetails.nl_BE);
                });
        }

        /// <summary>
        ///     Get MyService WtrEnrgDvcId From Conduit.
        /// </summary>
        /// <param name="deviceModelId">deviceModelId</param>
        /// <returns>MyServiceWtrEnrgDvcId</returns>
        public static short GetMyServiceWtrEnrgDvcIdFromConduit(int deviceModelId)
        {
            short returnValue;
            returnValue = DbClient.ExecuteScalar<short>(
                "select MyServiceWtrEnrgDvcId from TCD.DeviceModel where Id = " + deviceModelId,
                 delegate (DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.Text;
                 });
            return returnValue;
        }

        /// <summary>
        ///     Get Conduit Device ModelId.
        /// </summary>
        /// <param name="myServiceDeviceModelId">myServiceDeviceModelId</param>
        /// <returns>ConduitDeviceModelId</returns>
        public static int GetConduitDeviceModelId(int myServiceDeviceModelId)
        {
            int returnValue;
            returnValue = DbClient.ExecuteScalar<int>(
                "select Id from TCD.DeviceModel where MyServiceWtrEnrgDvcId = " + myServiceDeviceModelId,
                 delegate (DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.Text;
                 });
            return returnValue;
        }

        /// <summary>
        ///     Get Conduit Device TypeId.
        /// </summary>
        /// <param name="myServiceDeviceTypeId">myServiceDeviceTypeId</param>
        /// <returns>ConduitDeviceTypeId</returns>
        public static int GetConduitDeviceTypeId(int myServiceDeviceTypeId)
        {
            int returnValue;
            returnValue = DbClient.ExecuteScalar<int>(
                "select DeviceTypeId from TCD.DeviceType where MyServiceWtrEnrgDvcTypId = " + myServiceDeviceTypeId,
                 delegate (DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.Text;
                 });
            return returnValue;
        }

        /// <summary>
        /// Saves the utility details for first time synch.
        /// </summary>
        /// <param name="utility">The utility.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveUtilityDetailsForFirstTimeSynch(Utility utility, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveUtilityDetailsForFirstTimeSynch, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("MyServiceCustWtrEnrgDvcGuid", utility.MyServiceCustWtrEnrgDvcGUID);
                cmd.AddParameter("Id", utility.Id);
                cmd.AddParameter("DeviceNumber", utility.DeviceNumber);
                cmd.AddParameter("DeviceName", DbType.String, 200, utility.DeviceName);
                cmd.AddParameter("DeviceTypeId", utility.DeviceTypeId);
                cmd.AddParameter("DeviceModelId", utility.DeviceModelId);
                cmd.AddParameter("DeviceNote", DbType.String, 200, utility.DeviceNoteDesc);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, utility.EcolabAccountNumber);
                cmd.AddParameter("Comment", DbType.String, 200, utility.Comment);
                cmd.AddParameter("InstallDate", DbType.DateTime, utility.InstallDate);
                cmd.AddParameter("Is_deleted", utility.IsDeleted);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, utility.LastModifiedTimestamp);
            });
        }
    }
}