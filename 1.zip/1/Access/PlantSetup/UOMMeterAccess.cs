﻿// -----------------------------------------------------------------------
// <copyright file="UOMMeterAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The UOM Meter Access</summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for UOM
    /// </summary>
    public class UomMeterAccess
    {
        /// <summary>
        ///     Get utility type details
        /// </summary>
        /// <returns>different utilities</returns>
        public static List<UomMeter> GetUomMeterDetails(int utilityTypeId)
        {
            return DbClient.ExecuteReader<UomMeter>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetUOMMeterDetails : Resources.Ecolab_GetUOMMeterDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("UtilityType", utilityTypeId);
            }).ToList();
        }
    }
}