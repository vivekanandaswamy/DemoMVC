﻿// -----------------------------------------------------------------------
// <copyright file="ParentMeterAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Parent Meter Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    public class ParentMeterAccess
    {
        /// <summary>
        ///     Get the parent meter details
        /// </summary>
        /// <param name="utilityId">The Utility Id</param>
        /// <param name="meterId">The Meter id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns> The list of utility locations </returns>
        public static List<ParentMeter> GetParentMeterDetails(int utilityId, int? meterId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ParentMeter>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetParentMeterDetails : Resources.Ecolab_GetParentMeterDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("UtilityTypeId", utilityId);
                cmd.AddParameter("MeterID", meterId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }
    }
}