﻿// -----------------------------------------------------------------------
// <copyright file="DryerGroupAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dryer Group Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.Dryer
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.Dryer;
    using Nalco.Data.Common;
    using Properties;

    public class DryerGroupAccess
    {
        /// <summary>
        ///     Get the List of dryer details  by its Group
        /// </summary>
        /// <returns>Returns List of Dryer Groups</returns>
        public static List<DryerGroup> FetchDryerGroupDetails(string plantId)
        {
            return DbClient.ExecuteReader<DryerGroup>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetDryerGroupDetails : Resources.Ecolab_GetDryerGroupDetails, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantId);
                }).ToList();
        }

        /// <summary>
        /// Insert Dryer Group
        /// </summary>
        /// <param name="dryerGroup">The dryer group .</param>
        /// <param name="userId">The User Id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp.</param>
        /// <returns>
        /// The int return value .
        /// </returns>
        public static int InsertDryerGroup(DryerGroup dryerGroup, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;

            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            SqlParameter paramDryerGroupId = new SqlParameter { ParameterName = "OutputDryerGroupId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_InsertDryerGroup : Resources.Ecolab_InsertDryerGroup, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("GroupDescription", DbType.String, 100, dryerGroup.Name);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, dryerGroup.EcolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramDryerGroupId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            if(Convert.ToInt32(param.Value) == 301)
            {
                returnValue = Convert.ToInt32(param.Value);
            }
            else
            {
                returnValue = Convert.IsDBNull(paramDryerGroupId.Value) ? 0 : (int)paramDryerGroupId.Value;
                returnValue = status > 0 && status != 101 ? status : returnValue;
            }
            return returnValue;
        }

        /// <summary>
        /// Update Dryer Group
        /// </summary>
        /// <param name="dryerGroup">The dryer group .</param>
        /// <param name="userId">The User Id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp.</param>
        /// <returns>
        /// The int return value .
        /// </returns>
        public static int UpdateDryerGroup(DryerGroup dryerGroup, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;

            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            SqlParameter paramDryerGroupId = new SqlParameter { ParameterName = "OutputDryerGroupId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateDryerGroup : Resources.Ecolab_UpdateDryerGroup, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("GroupTypeId", dryerGroup.Id);
                    cmd.AddParameter("GroupDescription", DbType.String, 100, dryerGroup.Name);
                    cmd.AddParameter("UserID", userId);
                if(dryerGroup.LastModifiedTimestampAtCentral.HasValue)
                    {
                        cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, dryerGroup.LastModifiedTimestampAtCentral.Value);
                    }
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramDryerGroupId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, dryerGroup.EcolabAccountNumber);
                });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramDryerGroupId.Value) ? 0 : (int)paramDryerGroupId.Value;
            returnValue = status > 0 && status != 102 ? status : returnValue;

            return returnValue;
        }

        /// <summary>
        /// Delete Dryer Group Details
        /// </summary>
        /// <param name="dryerGroup">The dryer group.</param>
        /// <param name="dryerGroupId">The dryer group id.</param>
        /// <param name="userId">The User Id.</param>
        /// <param name="ecolabAccountNumber">The ecolab Account Number.</param>
        /// <param name="lastModifiedTimestamp">The last Modified Time Stamp.</param>
        /// <returns>
        /// The int .
        /// </returns>
        public static int DeleteDryerGroup(DryerGroup dryerGroup, int dryerGroupId, int userId, string ecolabAccountNumber, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            DateTime modifiedTimeStamp = new DateTime();

            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.VarChar;
            param.Size = 100;
            param.Direction = ParameterDirection.Output;

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteDryerGroup : Resources.Ecolab_DeleteDryerGroup, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("GroupTypeId", dryerGroupId);
                    cmd.AddParameter("UserID", userId);
                if(dryerGroup.LastModifiedTimestampAtCentral.HasValue)
                    {
                        cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, dryerGroup.LastModifiedTimestampAtCentral.Value);
                    }
                    cmd.Parameters.Add(param);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            modifiedTimeStamp = (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = status > 0 && status != 501 ? status : returnValue;

            lastModifiedTimestamp = modifiedTimeStamp;
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecordsForGroups : Resources.Ecolab_GetMaxNumberOfRecordsForGroups, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("GroupMainType", DbType.String, 1000, "Dryer Group");
                 });
        }

        /// <summary>
        ///     validate DryerGroup for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateDryerGroupSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateDryerGroupSave : Resources.Ecolab_ValidateDryerGroupSave, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Inserts the dryer group for first time synchronize.
        /// </summary>
        /// <param name="objDryerGroup">The object dryer group.</param>
        /// <param name="userId">The user identifier.</param>
        public static void InsertDryerGroupForFirstTimeSync(DryerGroup objDryerGroup, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_InsertDryerGroupForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("Id", objDryerGroup.Id);
                cmd.AddParameter("GroupDescription", DbType.String, 100, objDryerGroup.Name);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, objDryerGroup.EcolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, objDryerGroup.LastModifiedTimestampDryerGroup);
                cmd.AddParameter("Is_Deleted", objDryerGroup.IsDeleted);
            });
        }
    }
}