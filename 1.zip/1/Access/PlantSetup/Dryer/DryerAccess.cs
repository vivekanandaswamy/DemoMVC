﻿// -----------------------------------------------------------------------
// <copyright file="DryerAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Dryer Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.Dryer
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.Dryer;
    using Nalco.Data.Common;
    using Properties;

    public class DryerAccess
    {
        /// <summary>
        ///     Get the List of dryer details
        /// </summary>
        /// <returns>Returns List of Dryers</returns>
        public static List<Dryer> FetchDryerByGroupId(int dryerGroupId, int page, int pageSize, string sortcolumn, char sortDirection)
        {
            return DbClient.ExecuteReader<Dryer>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetDryersByGroupId : Resources.Ecolab_GetDryersByGroupId, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("DryerGroupId", dryerGroupId);
                    cmd.AddParameter("PageNo", page);
                    cmd.AddParameter("RecordsPerPage", pageSize);
                    cmd.AddParameter("sortcolumn", DbType.String, 100, sortcolumn);
                    cmd.AddParameter("sortDirection", sortDirection);
                }).ToList();
        }

        /// <summary>
        ///     Get the List of dryer details
        /// </summary>
        /// <returns>Returns List of Dryers</returns>
        public static List<Dryer> FetchDryers(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Dryer>(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetDryers : Resources.Ecolab_GetDryers,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }

        /// <summary>
        ///     Get the List of dryer Types
        /// </summary>
        /// <returns>List of Dryers Types</returns>
        public static List<DryerType> FetchDryerTypes()
        {
            return DbClient.ExecuteReader<DryerType>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetDryerTypes : Resources.Ecolab_GetDryerTypes, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure; }).ToList();
        }

        /// <summary>
        /// Insert Dryer Details
        /// </summary>
        /// <param name="dryer">The dryer parameter.</param>
        /// <param name="dryerGroupId">The dryer group id.</param>
        /// <param name="userId">The User id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp.</param>
        /// <returns>
        /// returns the string.
        /// </returns>
        public static int InsertDryer(Dryer dryer, int dryerGroupId, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramDryerId = new SqlParameter { ParameterName = "OutputDryerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_InsertDryer : Resources.Ecolab_InsertDryer, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("DryerGroupId", dryerGroupId);
                        cmd.AddParameter("DryerNo", dryer.Number);
                        cmd.AddParameter("Description", DbType.String, 100, dryer.Name);
                        cmd.AddParameter("Capacity", dryer.Nominalload);
                        cmd.AddParameter("DryerTypeId", dryer.DryerType.Id);
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, dryer.EcolabAccountNumber);
                        cmd.AddParameter("UserId", userId);
                        cmd.AddParameter("Capacity_Display", dryer.ConvertedNominalload);
                        cmd.Parameters.Add(param);
                        cmd.Parameters.Add(paramDryerId);
                        cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    });
                int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            if(Convert.ToInt32(param.Value) == 301 || Convert.ToInt32(param.Value) == 302 || Convert.ToInt32(param.Value) == 303)
                {
                returnValue = Convert.ToInt32(param.Value);
                }
                else
                {
                    returnValue = Convert.IsDBNull(paramDryerId.Value) ? 0 : (int)paramDryerId.Value;
                    returnValue = status > 0 && status != 101 ? status : returnValue;
                }

            return returnValue;
        }

        /// <summary>
        /// Update Dryer Details
        /// </summary>
        /// <param name="dryer">The dryer parameter.</param>
        /// <param name="userId">the User id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp.</param>
        /// <returns>
        /// returns the int.
        /// </returns>
        public static int UpdateDryer(Dryer dryer, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramDryerId = new SqlParameter { ParameterName = "OutputDryerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateDryer : Resources.Ecolab_UpdateDryer, delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("Id", dryer.Id);
                        cmd.AddParameter("DryerNo", dryer.Number);
                        cmd.AddParameter("Description", DbType.String, 100, dryer.Name);
                        cmd.AddParameter("Capacity", dryer.Nominalload);
                        cmd.AddParameter("DryerTypeId", dryer.DryerType.Id);
                        cmd.AddParameter("UserId", userId);
                        cmd.AddParameter("Capacity_Display", dryer.ConvertedNominalload);
                        if (dryer.LastModifiedTimestampAtCentral.HasValue)
                        {
                            cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, dryer.LastModifiedTimestampAtCentral.Value);
                        }
                        cmd.Parameters.Add(param);
                        cmd.Parameters.Add(paramDryerId);
                        cmd.Parameters.Add(paramLastModifiedTimeStamp);
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, dryer.EcolabAccountNumber);
                    });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramDryerId.Value) ? 0 : (int)paramDryerId.Value;
            returnValue = status > 0 && status != 102 ? status : returnValue;

            return returnValue;
        }

        /// <summary>
        /// Delete Dryer Details
        /// </summary>
        /// <param name="dryer">The dryer.</param>
        /// <param name="id">The dryer Id.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp.</param>
        /// <returns>
        /// returns the int.
        /// </returns>
        public static int DeleteDryer(Dryer dryer, int id, int userId, string ecolabAccountNumber, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteDryer : Resources.Ecolab_DeleteDryer, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("Id", id);
                        cmd.AddParameter("UserID", userId);
                        cmd.Parameters.Add(param);
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                if(dryer.LastModifiedTimestampAtCentral.HasValue)
                        {
                            cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, dryer.LastModifiedTimestampAtCentral.Value);
                        }
                        cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            returnValue = status > 0 && status == 501 ? status : returnValue;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
                
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("TableName", DbType.String, 1000, "TCD.Dryers");
                 });
        }

        /// <summary>
        ///     validate DryerGroup for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateDryersSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateDryersSave : Resources.Ecolab_ValidateDryersSave, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Inserts the dryer for first time synchronize.
        /// </summary>
        /// <param name="dryer">The dryer.</param>
        /// <param name="userId">The user identifier.</param>
        public static void InsertDryerForFirstTimeSync(Dryer dryer, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_InsertDryerForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("Id", dryer.Id);
                cmd.AddParameter("DryerGroupId", dryer.GroupId);
                cmd.AddParameter("DryerNo", dryer.Number);
                cmd.AddParameter("Description", DbType.String, 100, dryer.Name);
                cmd.AddParameter("Capacity", dryer.Nominalload);
                cmd.AddParameter("DryerTypeId", dryer.DryerType.Id);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, dryer.EcolabAccountNumber);
                cmd.AddParameter("LastModifiedByUserId", userId);
                cmd.AddParameter("CapacityDisplay", dryer.ConvertedNominalload);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, dryer.LastModifiedTimestampDryer);
                cmd.AddParameter("IsDeleted", dryer.IsDeleted);
            });
        }
    }
}