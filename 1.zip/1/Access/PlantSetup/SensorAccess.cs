﻿// -----------------------------------------------------------------------
// <copyright file="SensorAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  Sensor Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.Common;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for Sensor
    /// </summary>
    public class SensorAccess
    {
        /// <summary>
        ///     Get the Plant sensor details
        /// </summary>
        /// <returns>Row of Plant sensor details</returns>
        public static List<Sensor> GetPlantSensorDetails(int? id, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Sensor>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetSensorDetails : Resources.Ecolab_GetSensorDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("SensorID", id);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Save/Update Plant sensor details.
        /// </summary>
        /// <param name="sensor">The sensor object</param>
        /// <param name="userId"> user id </param>
        /// <param name="lastModifiedTimestamp">The Last Modified Time</param>
        /// <param name="errorCode">The Error Code</param>
        /// <param name="lastModifiedTimestampAtCentral">The Last modified time in Central</param>
        /// <returns>The string.</returns>
        public static int SavePlantSensorDetails(Sensor sensor, int userId, out DateTime lastModifiedTimestamp, out string errorCode, DateTime? lastModifiedTimestampAtCentral = null)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramSensorId = new SqlParameter { ParameterName = "OutputSensorId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveSensorDetails : Resources.Ecolab_SaveSensorDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("SensorNumber", DbType.String, 225, Convert.ToString(sensor.SensorNumber));
                cmd.AddParameter("SensorName", DbType.String, 255, sensor.SensorName);
                cmd.AddParameter("SensorType", DbType.String, 225, Convert.ToString(sensor.SensorType));
                cmd.AddParameter("SensorLocation", sensor.SensorLocationId);
                cmd.AddParameter("MachineCompartment", sensor.MachineId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, sensor.EcolabAccountNumber);
                cmd.AddParameter("ControllerID", sensor.ControllerId);
                cmd.AddParameter("OutputType", DbType.String, 255, sensor.OutputType);
                cmd.AddParameter("ChemicalforChart", sensor.ChemicalforChartId);
                cmd.AddParameter("UOM", DbType.String, 225, Convert.ToString(sensor.Uom));
                cmd.AddParameter("DashboardActualValue ", DbType.String, 225, Convert.ToString(sensor.DashboardActualValue));
                cmd.AddParameter("UserID ", userId);
                cmd.AddParameter("AnalogueInputNumber", DbType.String, 225, sensor.AnalogueImputNumber);
                cmd.AddParameter("Calibration4mA", sensor.CalibrationValue4);
                cmd.AddParameter("Calibration20mA", sensor.CalibrationValue20);
                cmd.AddParameter("TagAddress4mA", DbType.String, 225, sensor.CalibrationTag4);
                cmd.AddParameter("TagAddress20mA", DbType.String, 225, sensor.CalibrationTag20);
                cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                cmd.AddParameter("SensorNum", sensor.SensorNum);
                cmd.AddParameter("AlarmEnable", sensor.AlarmEnable);
                cmd.AddParameter("MinimumAlarmValue", sensor.MinimumAlarmValue);
                cmd.AddParameter("MaximumAlarmValue", sensor.MaximumAlarmValue);
                cmd.AddParameter("ExternalSensor", sensor.ExternalSensor);
                cmd.AddParameter("PumpNumber", sensor.PumpNumber);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramSensorId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            errorCode = param.Value.ToString();
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
            return Convert.IsDBNull(paramSensorId.Value) ? 0 : (int)paramSensorId.Value;
        }

        /// <summary>
        ///     Save Plant sensor tag details.
        /// </summary>
        /// <param name="sensor">The sensor object</param>
        /// <param name="userId"> user id </param>
        /// <param name="errorCode">The Error Code</param>

        public static void SavePlantSensorTags(Sensor sensor, int userId, out string errorCode)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveSensorTags, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("SensorNumber", DbType.String, 225, Convert.ToString(sensor.SensorNumber));
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, sensor.EcolabAccountNumber);
                cmd.AddParameter("ControllerID", sensor.ControllerId);
                cmd.AddParameter("UserID ", userId);
                cmd.AddParameter("AnalogueInputNumber", DbType.String, 225, (string.IsNullOrEmpty(sensor.AnalogueImputNumber) || string.IsNullOrWhiteSpace(sensor.AnalogueImputNumber)) ? null : sensor.AnalogueImputNumber);
                cmd.AddParameter("Calibration4mA", sensor.CalibrationValue4);
                cmd.AddParameter("Calibration20mA", sensor.CalibrationValue20);
                cmd.AddParameter("TagAddress4mA", DbType.String, 225, (string.IsNullOrEmpty(sensor.CalibrationTag4) || string.IsNullOrWhiteSpace(sensor.CalibrationTag4)) ? null : sensor.CalibrationTag4);
                cmd.AddParameter("TagAddress20mA", DbType.String, 225, (string.IsNullOrEmpty(sensor.CalibrationTag20) || string.IsNullOrWhiteSpace(sensor.CalibrationTag20)) ? null : sensor.CalibrationTag20);
                cmd.Parameters.Add(param);
            });
            errorCode = param.Value.ToString();
        }

        /// <summary>
        ///     Update Plant sensor tag details.
        /// </summary>
        /// <param name="sensor">The sensor object</param>
        /// <param name="userId"> user id </param>
        /// <param name="errorCode">The Error Code</param>

        public static void UpdatePlantSensorTags(Sensor sensor, int userId, out string errorCode)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateSensorTags, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("SensorNumber", DbType.String, 225, Convert.ToString(sensor.SensorNumber));
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, sensor.EcolabAccountNumber);
                cmd.AddParameter("ControllerID", sensor.ControllerId);
                cmd.AddParameter("UserID ", userId);
                cmd.AddParameter("AnalogueInputNumber", DbType.String, 225, (string.IsNullOrEmpty(sensor.AnalogueImputNumber) || string.IsNullOrWhiteSpace(sensor.AnalogueImputNumber)) ? null : sensor.AnalogueImputNumber);
                cmd.AddParameter("Calibration4mA", sensor.CalibrationValue4);
                cmd.AddParameter("Calibration20mA", sensor.CalibrationValue20);
                cmd.AddParameter("TagAddress4mA", DbType.String, 225, (string.IsNullOrEmpty(sensor.CalibrationTag4) || string.IsNullOrWhiteSpace(sensor.CalibrationTag4)) ? null : sensor.CalibrationTag4);
                cmd.AddParameter("TagAddress20mA", DbType.String, 225, (string.IsNullOrEmpty(sensor.CalibrationTag20) || string.IsNullOrWhiteSpace(sensor.CalibrationTag20)) ? null : sensor.CalibrationTag20);
                cmd.Parameters.Add(param);
            });
            errorCode = param.Value.ToString();
        }

        /// <summary>
        ///     Delete Plant sensor.
        /// </summary>
        /// <param name="sensor"> sensor Model</param>
        /// <param name="userId">User ID</param>
        /// <param name="lastModifiedTimestamp">The Last Modified Time</param>
        /// <param name="errorCode">The Error Code</param>
        /// <param name="lastModifiedTimestampAtCentral">The Last modified time in Central</param>
        /// <returns>Returns Boolean value</returns>
        public static int DeletePlantSensorDetails(Sensor sensor, int userId, out DateTime lastModifiedTimestamp, out int errorCode, DateTime? lastModifiedTimestampAtCentral = null)
        {
            lastModifiedTimestamp = DateTime.Now;
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteSensorDetails : Resources.Ecolab_DeleteSensorDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, sensor.EcolabAccountNumber);
                cmd.AddParameter("Sensorid", sensor.SensorNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
                cmd.Parameters.Add(param);
            });
            errorCode = int.TryParse(param.Value.ToString(), out errorCode) ? errorCode : errorCode;
            if (!string.IsNullOrWhiteSpace(paramLastModifiedTimeStamp.Value.ToString()))
            {
                lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            }

            return sensor.SensorNumber.HasValue ? sensor.SensorNumber.Value : 0;
        }

        /// <summary>
        ///     Get Meter Utility Location
        /// </summary>
        /// <returns>List of GroupType Model</returns>
        public static List<GroupType> GetSensorUtilityLocation(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<GroupType>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMeterUtilityLocation : Resources.Ecolab_GetMeterUtilityLocation, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Gets the sensor details by sensor Id
        /// </summary>
        /// <param name="sensorId">parameter sensor id</param>
        /// <param name="ecolabAccountNumber">parameter ecolab account number</param>
        /// <returns>sensor details object</returns>
        public static SensorModel GetPlantSensorDetailsBySensorId(int sensorId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<SensorModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantSensorDetailsBySensorId : Resources.Ecolab_GetPlantSensorDetailsBySensorId, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("SensorId", sensorId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).FirstOrDefault();
        }

        /// <summary>
        ///     Gets the module tags details
        /// </summary>
        /// <param name="sensorId">Patameter Sensor Id</param>
        /// <param name="moduleTypeId">Module Type Id/ Sensor = 3</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Module Tags Object</returns>
        public static List<ModuleTagsModel> GetModuleTagsDetails(int sensorId, int moduleTypeId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ModuleTagsModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetModuleTagsDetails : Resources.Ecolab_GetModuleTagsDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ModuleId", sensorId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("ModuleTypeId", moduleTypeId);
            }).ToList();
        }

        /// <summary>
        ///     validate customer for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateSensorSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateSensorSave : Resources.Ecolab_ValidateSensorSave, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                });
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.Sensor");
            });
        }

        /// <summary>
        ///     Gets the Plant Sensor details for resync process
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Sensor Details Object</returns>
        public static List<SensorModel> GetPlantSensorDetailsForResync(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<SensorModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantSensorDetailsBySensorId : Resources.Ecolab_GetPlantSensorDetailsBySensorId, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// Saves the plant sensor details for first time synch.
        /// </summary>
        /// <param name="sensor">The sensor.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SavePlantSensorDetailsForFirstTimeSynch(SensorModel sensor, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantSensorDetailsForFirstTimeSynch, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("SensorId", sensor.SensorId);
                cmd.AddParameter("SensorName", DbType.String, 255, sensor.Description);
                cmd.AddParameter("SensorType", DbType.String, 225, Convert.ToString(sensor.SensorType));
                cmd.AddParameter("GroupId", sensor.GroupId);
                //cmd.AddParameter("SensorLocation", sensor.SensorLocationId);
                cmd.AddParameter("MachineCompartment", sensor.MachineCompartment);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, sensor.EcolabAccountNumber);
                cmd.AddParameter("ControllerID", sensor.ControllerId);
                cmd.AddParameter("OutputType", DbType.String, 255, sensor.OutputType);
                cmd.AddParameter("ChemicalforChart", sensor.ChemicalforChart);
                cmd.AddParameter("UOM", DbType.String, 225, Convert.ToString(sensor.Uom));
                cmd.AddParameter("DashboardActualValue ", DbType.String, 225, Convert.ToString(sensor.DashboardActualValue));
                cmd.AddParameter("UserID ", userId);
                cmd.AddParameter("AnalogueInputNumber", sensor.AnalogueInputNumber);
                cmd.AddParameter("Calibration4mA", sensor.Calibration4mA);
                cmd.AddParameter("Calibration20mA", sensor.Calibration20mA);
                //cmd.AddParameter("TagAddress4mA", DbType.String, 225, sensor.CalibrationTag4);
                //cmd.AddParameter("TagAddress20mA", DbType.String, 225, sensor.CalibrationTag20);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, sensor.LastModifiedTime);
                cmd.AddParameter("IsDeleted", sensor.IsDeleted);
                cmd.AddParameter("IsPlant", sensor.IsPlant);
                cmd.AddParameter("IsPress", sensor.IsPress);
                cmd.AddParameter("SensorNum", sensor.SensorNum);
                cmd.AddParameter("AlarmEnable", sensor.AlarmEnable);
                cmd.AddParameter("MinimumAlarmValue", sensor.MinimumAlarmValue);
                cmd.AddParameter("MaximumAlarmValue", sensor.MaximumAlarmValue);
            });
        }

        /// <summary>
        /// Fetches the external and internal counters
        /// </summary>
        /// <param name="locationId"></param>
        /// <param name="washerId"></param>
        /// <param name="utilityTypeId">Utility Type Id</param>
        /// <param name="isTunnel">Is Tunnel</param>
        /// <param name="isMeter">is Meter Flag</param>
        /// <param name="ecolabAccNumber">Ecolab Account Number</param>
        /// <param name="Id">Sensor/Meter Id</param>
        /// <param name="controllerId">Controller Id</param>
        /// <returns>Dictionary object</returns>
        public static Dictionary<string, string> FetchCounters(int? locationId, int? washerId, string utilityTypeId, bool isTunnel, bool isMeter, string ecolabAccNumber, int? id, int? controllerId)
        {
            List<string> listCounters = DbClient.ExecuteReader<string>(Resources.Ecolab_GetMeterOrSensorConters, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("LocationId", locationId);
                cmd.AddParameter("WasherId", washerId);
                cmd.AddParameter("IsMeter", isMeter);
                cmd.AddParameter("EcolabAccNumber", DbType.String, 200, ecolabAccNumber);
                cmd.AddParameter("UtilityTypeId", DbType.String, 50, utilityTypeId);
                cmd.AddParameter("Id", id);                
                cmd.AddParameter("IsTunnel", isTunnel);
                cmd.AddParameter("ControllerIdForExternalCounter", controllerId);
            }).ToList();

            var dictCounters = new Dictionary<string, string>();
            dictCounters.Add("InternalCounters", listCounters[0]);
            dictCounters.Add("ExternalCounters", listCounters[1]);
            return dictCounters;
        }
    }
}