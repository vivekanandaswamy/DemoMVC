﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityGasOilTypeAccess.cs" company="Ecolab">
// This class is for getting the utility gas/oil type values from database.
// </copyright>
// <summary>The Plant Utility gas/oil Type Access for getting data.</summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Class is for plant utility gas/oil types.
    /// </summary>
    public class PlantUtilityGasOilTypeAccess
    {
        /// <summary>
        ///     Get GasOil Type details
        /// </summary>
        ///<param name="ecolabAccountNumber">ecolab account  number of the plant.</param>
        /// <returns>Different gas/oil types.</returns>
        public static List<PlantutilityGasoilTypes> GetGasoilTypes(string ecolabAccountNumber)
        {
            return
                DbClient.ExecuteReader<PlantutilityGasoilTypes>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetGasoilTypes : Resources.Ecolab_GetGasOilTypes,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    })
                    .ToList();
        }

        /// <summary>
        ///     Save or update myservice gas oil type Details
        /// </summary>
        /// <param name="myServiceGasoilTypes">myServiceGasoilTypes</param>
        public static int SaveMyServiceGasoilTypeDetails(PlantutilityGasoilTypes myServiceGasoilTypes)
        {
            int returnValue = 0;

            var paramGasOilTypesId = new SqlParameter
            {
                ParameterName = "OutputGasoilTypes",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            var paramGasOilLastModifedTime = new SqlParameter
            {
                ParameterName = "OutputLastModifiedDate",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateMyServiceGasoilTypeDetails : "[TCD].[UpdateMyServiceGasOilTypeDetails]",
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("GasOilId", myServiceGasoilTypes.GasoilTypeId);
                    cmd.AddParameter("Name", DbType.String, 255, myServiceGasoilTypes.GasoilTypeName);
                    cmd.AddParameter("DefaultValue", myServiceGasoilTypes.DefaultValue);
                    cmd.AddParameter("UOMCode", DbType.String, 255, myServiceGasoilTypes.UomCode);
                    cmd.AddParameter("UOMDesc", DbType.String, 255, myServiceGasoilTypes.UomDescription);
                    cmd.AddParameter("UsageKey", DbType.String, 255, myServiceGasoilTypes.UsageKey);
                    cmd.AddParameter("Units", DbType.String, 255, myServiceGasoilTypes.Units);
                    cmd.AddParameter("RegionCode", DbType.String, 255, myServiceGasoilTypes.RegionCode);
                    cmd.AddParameter("IsDeleted", myServiceGasoilTypes.IsDeleted);
                    cmd.AddParameter("MyServiceUtilId", myServiceGasoilTypes.MyServiceUtilId);
                    cmd.AddParameter("LastModifiedTime", DbType.DateTime, myServiceGasoilTypes.MyServiceLastSynchTime);
                    cmd.Parameters.Add(paramGasOilTypesId);
                    cmd.Parameters.Add(paramGasOilLastModifedTime);
                });
            returnValue = Convert.IsDBNull(paramGasOilTypesId.Value) ? 0 : (int)paramGasOilTypesId.Value;
            return returnValue;
        }

        /// <summary>
        ///     Save or update myservice GasOilType locale details
        /// </summary>
        /// <param name="myServiceGasoilTypes">myServiceGasoilTypes</param>
        public static void SaveMyServiceGasoilTypeLocaleDetails(PlantutilityGasoilTypes myServiceGasoilTypes)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252, "FIELD_" + myServiceGasoilTypes.GasoilTypeName.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myServiceGasoilTypes.GasoilTypeName);
                    cmd.AddParameter("Spanish", DbType.String, 252, myServiceGasoilTypes.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myServiceGasoilTypes.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myServiceGasoilTypes.nl_BE);
                });
        }
    }
}