﻿// -----------------------------------------------------------------------
// <copyright file="SensorMachineSetupAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  Sensor Machine Setup Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for SensorMachineSetupAccess
    /// </summary>
    public class SensorMachineSetupAccess
    {
        /// <summary>
        ///     Get Sensor Machine Setup details
        /// </summary>
        /// <returns>The list of Sensor machine setup </returns>
        public static List<SensorMachineSetup> GetSensorMachineSetupDetails()
        {
            return DbClient.ExecuteReader<SensorMachineSetup>(Resources.Ecolab_GetSensorMachineDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}