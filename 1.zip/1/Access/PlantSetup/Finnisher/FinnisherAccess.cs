﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Finnisher Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.Finnisher
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.Finnisher;
    using Nalco.Data.Common;
    using Properties;

    public class FinnisherAccess
    {
        /// <summary>
        ///     Get the List of Finnisher Types
        /// </summary>
        /// <returns>List of Finnisher Type</returns>
        public static List<FinnisherType> FetchFinnisherTypes()
        {
            return DbClient.ExecuteReader<FinnisherType>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetFinnisherTypes : Resources.Ecolab_GetFinnisherTypes, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure; }).ToList();
        }

        /// <summary>
        ///     Get the List of Finnishers
        /// </summary>
        /// <returns>List of Finnisher</returns>
        public static List<Finnisher> FetchFinnishers(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Finnisher>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetFinnishers : Resources.Ecolab_GetFinnishers,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }

        /// <summary>
        ///     Insert Finnisher Details
        /// </summary>
        /// <param name="finnisher">The finnisher .</param>
        /// <param name="finnisherGroupId">The finnisher group id.</param>
        /// <param name="userId">The User id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <returns>The string.</returns>
        public static int InsertFinnisher(Finnisher finnisher, int finnisherGroupId, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramFinnisherId = new SqlParameter { ParameterName = "OutputFinisherId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_InsertFinnisher : Resources.Ecolab_InsertFinnisher, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("FinnisherGroupId", finnisherGroupId);
                cmd.AddParameter("Name", DbType.String, 100, finnisher.Name.Trim());
                cmd.AddParameter("FinnisherTypeId", finnisher.FinnisherType.Id);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, finnisher.EcolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("FinnisherNo", finnisher.Number);
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramFinnisherId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            int status;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            if(Convert.ToInt32(param.Value) == 301 || Convert.ToInt32(param.Value) == 302)
            {
                returnValue = Convert.ToInt32(param.Value);
            }
            else
            {
                returnValue = Convert.IsDBNull(paramFinnisherId.Value) ? 0 : (int)paramFinnisherId.Value;
                returnValue = status > 0 && status != 101 ? status : returnValue;
            }
            return returnValue;
        }

        /// <summary>
        ///     Update Finnisher Details
        /// </summary>
        /// <param name="finnisher">The finnisher.</param>
        /// <param name="userId">The user Id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <returns>The string.</returns>
        public static int UpdateFinnisher(Finnisher finnisher, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramFinnisherId = new SqlParameter { ParameterName = "OutputFinisherId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateFinnisher : Resources.Ecolab_UpdateFinnisher, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("FinnisherId", finnisher.FinisherId);
                cmd.AddParameter("Name", DbType.String, 100, finnisher.Name.Trim());
                cmd.AddParameter("FinnisherTypeId", finnisher.FinnisherType.Id);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, finnisher.EcolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("FinnisherNo", finnisher.Number);
                if(finnisher.LastModifiedTimestampAtCentral.HasValue)
                {
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, finnisher.LastModifiedTimestampAtCentral.Value);
                }
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramFinnisherId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramFinnisherId.Value) ? 0 : (int)paramFinnisherId.Value;
            returnValue = status > 0 && status != 102 ? status : returnValue;
            return returnValue;
        }

        /// <summary>
        /// Delete Finnisher Details
        /// </summary>
        /// <param name="finnisher">The finnisher.</param>
        /// <param name="finnisherNumber">The finnisher Number.</param>
        /// <param name="userId">The User Id.</param>
        /// <param name="plantId">The plant id.</param>
        /// <param name="lastModifiedTimestamp">The Last Modified Time Stamp</param>
        /// <returns>
        /// returns the string .
        /// </returns>
        public static int DeleteFinnisher(Finnisher finnisher, int finnisherNumber, int userId, string plantId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteFinnisher : Resources.Ecolab_DeleteFinnisher, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("FinnisherId", finnisherNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantId);
                if(finnisher.LastModifiedTimestampAtCentral.HasValue)
                {
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, finnisher.LastModifiedTimestampAtCentral.Value);
                }
                cmd.Parameters.Add(param);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            int status;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            returnValue = status > 0 && status == 501 ? status : returnValue;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;

            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.Finnishers");
            });
        }

        /// <summary>
        ///     validate Finnisher for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateFinnisherSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateFinnisherSave : Resources.Ecolab_ValidateFinnisherSave, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Inserts the finnisher for first time synchronize.
        /// </summary>
        /// <param name="finnisher">The finnisher.</param>
        /// <param name="userId">The user identifier.</param>
        public static void InsertFinnisherForFirstTimeSync(Finnisher finnisher, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_InsertFinnisherForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("FinnisherId", finnisher.FinisherId);
                cmd.AddParameter("FinnisherGroupId", finnisher.GroupId);
                cmd.AddParameter("Name", DbType.String, 100, finnisher.Name.Trim());
                cmd.AddParameter("FinnisherTypeId", finnisher.FinnisherType.Id);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, finnisher.EcolabAccountNumber);
                cmd.AddParameter("LastModifiedByUserId", userId);
                cmd.AddParameter("FinnisherNo", finnisher.Number);
                cmd.AddParameter("Is_deleted", finnisher.IsDeleted);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, finnisher.LastModifiedTimestampFinnisher);
            });
        }
    }
}