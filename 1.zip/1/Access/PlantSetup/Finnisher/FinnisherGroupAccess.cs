﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherGroupAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Finnisher Group Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.Finnisher
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.Finnisher;
    using Nalco.Data.Common;
    using Properties;

    public class FinnisherGroupAccess
    {
        /// <summary>
        ///     Get the List of Finnisher details  by its Group
        /// </summary>
        /// <returns>List of Finnisher Group</returns>
        public static List<FinnisherGroup> FetchFinnisherGroupDetails(string plantId)
        {
            return DbClient.ExecuteReader<FinnisherGroup>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetFinnisherGroupDetails : Resources.Ecolab_GetFinnisherGroupDetails, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantId);
                }).ToList();
        }

        /// <summary>
        ///     Insert Finnisher Group
        /// </summary>
        /// <param name="finnisherGroup">The Finnisher Group .</param>
        /// <param name="userId">The User Id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>The int . </returns>
        public static int InsertFinnisherGroup(FinnisherGroup finnisherGroup, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramFinnisherGroupId = new SqlParameter { ParameterName = "OutputFinisherGroupId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_InsertFinnisherGroup : Resources.Ecolab_InsertFinnisherGroup, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("GroupDescription", DbType.String, 100, finnisherGroup.Name.Trim());
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, finnisherGroup.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramFinnisherGroupId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            int status = 0;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramFinnisherGroupId.Value) ? 0 : (int)paramFinnisherGroupId.Value;
            returnValue = status > 0 && status != 101 ? status : returnValue;

            return returnValue;
        }

        /// <summary>
        ///     Update Finnisher Group
        /// </summary>
        /// <param name="finnisherGroup">The Finnisher Group .</param>
        /// <param name="userId">The User Id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <returns>The String . </returns>
        public static int UpdateFinnisherGroup(FinnisherGroup finnisherGroup, int userId, out DateTime lastModifiedTimestamp)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramFinnisherGroupId = new SqlParameter { ParameterName = "OutputFinisherGroupId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateFinnisherGroup : Resources.Ecolab_UpdateFinnisherGroup, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("GroupTypeId", finnisherGroup.Id);
                    cmd.AddParameter("GroupDescription", DbType.String, 100, finnisherGroup.Name.Trim());
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, finnisherGroup.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
					if (finnisherGroup.LastModifiedTimestampFinnisherGroup != null && finnisherGroup.LastModifiedTimestampFinnisherGroup != DateTime.MinValue)
                    {
						cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, finnisherGroup.LastModifiedTimestampFinnisherGroup);
                    }
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramFinnisherGroupId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            int status;
            status = int.TryParse(Convert.ToString(param.Value), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            int returnValue = Convert.IsDBNull(paramFinnisherGroupId.Value) ? 0 : (int)paramFinnisherGroupId.Value;
            returnValue = status > 0 && status != 102 ? status : returnValue;

            return returnValue;
        }

        /// <summary>
        ///     Delete Finnisher Group Details
        /// </summary>
        /// <param name="finnisherGroup">Finnisher Group</param>
        /// <param name="finnisherGroupId">The finnisher group Id.</param>
        /// <param name="userId">The User Id.</param>
        /// <param name="plantId">The Plant Id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <returns>returns the int . </returns>
        public static int DeleteFinnisherGroup(FinnisherGroup finnisherGroup, int finnisherGroupId, int userId, string plantId, out DateTime lastModifiedTimestamp)
        {
            int returnValue;

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteFinnisherGroup : Resources.Ecolab_DeleteFinnisherGroup, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("GroupTypeId", finnisherGroupId);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantId);
					if (finnisherGroup.LastModifiedTimestampFinnisherGroup != null && finnisherGroup.LastModifiedTimestampFinnisherGroup != DateTime.MinValue)
					{
						cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, finnisherGroup.LastModifiedTimestampFinnisherGroup);
					}
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = int.TryParse(Convert.ToString(param.Value), out returnValue) ? returnValue : 0;
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecordsForGroups : Resources.Ecolab_GetMaxNumberOfRecordsForGroups, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("GroupMainType", DbType.String, 1000, "Finnisher Group");
                });
        }

        /// <summary>
        ///     validate FinnisherGroup for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateFinnisherGroupSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateFinnisherGroupSave : Resources.Ecolab_ValidateFinnisherGroupSave, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                        cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                    });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Inserts the finnisher group for first time synchronize.
        /// </summary>
        /// <param name="objFinnisherGroup">The object finnisher group.</param>
        /// <param name="userId">The user identifier.</param>
        public static void InsertFinnisherGroupForFirstTimeSync(FinnisherGroup objFinnisherGroup, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_InsertFinnisherGroupForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("Id", objFinnisherGroup.Id);
                cmd.AddParameter("GroupDescription", DbType.String, 100, objFinnisherGroup.Name);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, objFinnisherGroup.EcolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, objFinnisherGroup.LastModifiedTimestampFinnisherGroup);
                cmd.AddParameter("Is_Deleted", objFinnisherGroup.IsDeleted);
            });
        }

    }
}