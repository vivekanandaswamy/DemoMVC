﻿// -----------------------------------------------------------------------
// <copyright file="DeviceNoteAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Device Note Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for DeviceNoteAccess
    /// </summary>
    public class DeviceNoteAccess
    {
        /// <summary>
        ///     Get the device note details
        /// </summary>
        /// <param name="deviceTypeId">device type id.</param>
        /// <returns> The list of device notes </returns>
        public static List<DeviceNote> GetDeviceNoteDetails(int deviceTypeId)
        {
            return DbClient.ExecuteReader<DeviceNote>(Resources.Ecolab_GetDeviceNoteDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("DeviceTypeId", deviceTypeId);
            }).ToList();
        }
    }
}