﻿// -----------------------------------------------------------------------
// <copyright file="MeterAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Meter Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.Common;
	using Entities.PlantSetup;
	using Entities.PlantSetup.ModuleRead;
    using Entities.PlantSetup.ModuleRead;
	using Nalco.Data.Common;
	using Properties;

    /// <summary>
    /// class for Plant Meter Access
    /// </summary>
    public class MeterAccess
    {
        /// <summary>
        /// Get the Plant meter details
        /// </summary>
        /// <param name="meterId">Parameter Meter Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Row of Plant meter details
        /// </returns>
        public static List<Meter> GetPlantMeterDetails(int? meterId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Meter>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMeterDetails : Resources.Ecolab_GetPlantMeterDetails, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.AddParameter("MeterId", meterId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }

        /// <summary>
        /// Save/Update Plant meter details.
        /// </summary>
        /// <param name="meter">The meter object</param>
        /// <param name="userId">The user id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="errorCode">The Error Code</param>
        /// <param name="lastModifiedTimestampAtCentral">The Last modified time at central</param>
        /// <returns>
        /// Returns Paramter Values
        /// </returns>
        public static int SavePlantMeterDetails(Meter meter, int userId, out DateTime lastModifiedTimestamp, out string errorCode, DateTime? lastModifiedTimestampAtCentral = null)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramMeterId = new SqlParameter { ParameterName = "OutputMeterId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            
            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMeterDetails : Resources.Ecolab_SavePlantMeterDetails, delegate(DbCommand cmd, DbContext context)
            {
                    cmd.CommandType = CommandType.Text;
                    cmd.AddParameter("MeterNumber", meter.MeterId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, meter.EcolabAccountNumber);
                    cmd.AddParameter("MeterName", DbType.String, 255, meter.Description);
                    cmd.AddParameter("Uitiliy", DbType.String, 255, meter.MeterType);
                    cmd.AddParameter("UtilityLocation", meter.UtilityId);
                    cmd.AddParameter("MachineCompartment", meter.MachineId);
                    cmd.AddParameter("Parent", meter.ParentId);
                    cmd.AddParameter("Calibration", meter.Calibration);
                    cmd.AddParameter("UOFfoRCalibration", DbType.String, 255, meter.MeterTickUnit);
                    cmd.AddParameter("Usagefactor", meter.UsageFactor);
                    cmd.AddParameter("ControllerID", meter.ControllerId);
                    cmd.AddParameter("ControllerModelID", meter.ControllerModelId);
                    cmd.AddParameter("DigitalInputNumber", DbType.String, 255, meter.DigitalInputNumber);
                    cmd.AddParameter("AllowmanualEntry", meter.AllowManualEntry);
                    cmd.AddParameter("Meterrolloverpoint", meter.MaxValueLimit);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                    cmd.AddParameter("WaterType", meter.WaterType == 0 ? null : meter.WaterType);
                    cmd.AddParameter("WaterTypeFromFormulaSetup", meter.WaterTypeFromFormulaSetup);                    
                    cmd.AddParameter("CounterNum", meter.CounterNum);                  
                    cmd.AddParameter("CounterUsage", meter.CounterUsage);
                    cmd.AddParameter("RunningTimeUsage", meter.RunningTimeUsage);
                    cmd.AddParameter("CounterAlarmValue", meter.CounterAlarmValue);
                    cmd.AddParameter("RunningTimeAlarmValue", meter.RunningTimeAlarmValue);
                    cmd.AddParameter("ExternalCounter", meter.ExternalCounter);
                    cmd.AddParameter("IncludeInOperationReport", meter.IncludeInOperationReport);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramMeterId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            errorCode = param.Value.ToString();
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
            return Convert.IsDBNull(paramMeterId.Value) ? 0 : (int)paramMeterId.Value;
        }

        /// <summary>
        /// Save Plant meter tag details.
        /// </summary>
        /// <param name="meter">The meter object</param>
        /// <param name="userId">The user id</param>
        /// <param name="errorCode">The Error Code</param>
        public static void SavePlantMeterTags(Meter meter, int userId,out string errorCode)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantMeterTags, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("MeterNumber", meter.MeterId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, meter.EcolabAccountNumber);
                cmd.AddParameter("ControllerID", meter.ControllerId);
                cmd.AddParameter("DigitalInputNumber", DbType.String, 255, meter.DigitalInputNumber);
                cmd.AddParameter("UserID", userId);
                cmd.Parameters.Add(param);
            });
            errorCode = param.Value.ToString();
        }

        /// <summary>
        /// updates Plant meter tag details.
        /// </summary>
        /// <param name="meter">The meter object</param>
        /// <param name="userId">The user id</param>
        /// <param name="errorCode">The Error Code</param>
        public static void UpdatePlantMeterTags(Meter meter, int userId, out string errorCode)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdatePlantMeterTags, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("MeterNumber", meter.MeterId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, meter.EcolabAccountNumber);
                cmd.AddParameter("ControllerID", meter.ControllerId);
                cmd.AddParameter("DigitalInputNumber", DbType.String, 255, meter.DigitalInputNumber);
                cmd.AddParameter("UserID", userId);
                cmd.Parameters.Add(param);
            });
            errorCode = param.Value.ToString();
        }

        /// <summary>
        /// Delete the meter details
        /// </summary>
        /// <param name="meter">the meter object.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp.</param>
        /// <param name="errorCode">The Error Code</param>
        /// <param name="lastModifiedTimestampAtCentral">The Last modified time at central</param>
        /// <returns>
        /// The integer value.
        /// </returns>
        public static int DeletePlantMeterDetails(Meter meter, int userId, out DateTime lastModifiedTimestamp, out int errorCode, DateTime? lastModifiedTimestampAtCentral = null)
        {
            lastModifiedTimestamp = DateTime.Now;
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteMeterDetails : Resources.Ecolab_DeletePlantMeterDetails, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, meter.EcolabAccountNumber);
                    cmd.AddParameter("Meterid", meter.MeterId);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    cmd.Parameters.Add(param);
                });
            errorCode = int.TryParse(param.Value.ToString(), out errorCode) ? errorCode : errorCode;
            if (!string.IsNullOrWhiteSpace(paramLastModifiedTimeStamp.Value.ToString()))
            {
                lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            }
            return meter.MeterId.HasValue ? meter.MeterId.Value : 0;
        }

        /// <summary>
        /// Get Meter Utility Location
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// List of GroupType Model
        /// </returns>
        public static List<GroupType> GetMeterUtilityLocation(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<GroupType>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMeterUtilityLocation : Resources.Ecolab_GetMeterUtilityLocation, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }

        /// <summary>
        /// Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Max Record Count
        /// </returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("TableName", DbType.String, 1000, "TCD.Meter");
                });
        }

        /// <summary>
        /// validate customer for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>
        /// success/failure
        /// </returns>
        public static int ValidateMeterSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMeterDetails : Resources.Ecolab_ValidateMeterSave, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Gets the Plant Meter details by meter id
        /// </summary>
        /// <param name="meterId">Patameter Meter Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Meter Details Object
        /// </returns>
        public static MeterModel GetPlantMeterDetailsByMeterId(int meterId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<MeterModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantMeterDetailsByMeterId : Resources.Ecolab_GetPlantMeterDetailsByMeterId, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.Text;
                     cmd.AddParameter("MeterId", meterId);
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                 }).FirstOrDefault();
        }

        /// <summary>
        /// Gets the module tags details
        /// </summary>
        /// <param name="meterId">Patameter Meter Id</param>
        /// <param name="moduleTypeId">Module Type Id/ Meter = 2</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>
        /// Module Tags Object
        /// </returns>
        public static ModuleTagsModel GetModuleTagsDetails(int meterId, int moduleTypeId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ModuleTagsModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetModuleTagsDetails : Resources.Ecolab_GetModuleTagsDetails, delegate(DbCommand cmd, DbContext context)
                  {
                      cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                      cmd.AddParameter("ModuleId", meterId);
                      cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                      cmd.AddParameter("ModuleTypeId", moduleTypeId);
                  }).FirstOrDefault();
        }

        /// <summary>
        /// get plant meter details for resync
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <returns>
        /// List of meter details
        /// </returns>
        public static List<MeterModel> GetPlantMeterDetailsForResync(string ecolabAccountNumber)
        {
            int? meterId = null;
            return DbClient.ExecuteReader<MeterModel>(Resources.Ecolab_GetPlantMeterDetailsByMeterId, delegate(DbCommand cmd, DbContext context)
                {                    
                    cmd.CommandType = CommandType.Text;
                    cmd.AddParameter("MeterId", meterId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }
        /// <summary>
        /// Saves the plant meter details for first time synch.
        /// </summary>
        /// <param name="meter">The meter value.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SavePlantMeterDetailsForFirstTimeSynch(MeterModel meter, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantMeterDetailsForFirstTimeSynch, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("MeterId", meter.MeterId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, meter.EcolabAccountNumber);
                cmd.AddParameter("MeterName", DbType.String, 255, meter.Description);
                cmd.AddParameter("Uitiliy", DbType.String, 255, meter.MeterType);
                cmd.AddParameter("GroupId", meter.GroupId);
                cmd.AddParameter("MachineCompartment", meter.MachineId);
                cmd.AddParameter("Parent", meter.ParentId);
                cmd.AddParameter("Calibration", meter.Calibration);
                cmd.AddParameter("UOFfoRCalibration", DbType.String, 255, meter.MeterTickUnit);
                cmd.AddParameter("Usagefactor", meter.UsageFactor);
                cmd.AddParameter("ControllerID", meter.ControllerId);
                cmd.AddParameter("DigitalInputNumber", meter.DigitalInputNumber);
                cmd.AddParameter("AllowmanualEntry", meter.AllowManualEntry);
                cmd.AddParameter("Meterrolloverpoint", meter.MaxValueLimit);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, meter.LastModifiedTime);
                cmd.AddParameter("IsDeleted", meter.IsDeleted);
                cmd.AddParameter("IsPlant", meter.IsPlant);
                cmd.AddParameter("IsPress", meter.IsPress);
                cmd.AddParameter("CounterNum", meter.CounterNum);
                cmd.AddParameter("CounterUsage", meter.CounterUsage);
                cmd.AddParameter("RunningTimeUsage", meter.RunningTimeUsage);
                cmd.AddParameter("CounterAlarmValue", meter.CounterAlarmValue);
                cmd.AddParameter("WaterType", meter.WaterType);
                cmd.AddParameter("WaterTypeFromFormulaSetup", meter.WaterTypeFromFormulaSetup);
                cmd.AddParameter("RunningTimeAlarmValue", meter.RunningTimeAlarmValue);
                cmd.AddParameter("IncludeInOperationReport", meter.IncludeInOperationReport);                
            });
        }

        /// <summary>
        /// Fetches the module data details for synchronize.
        /// </summary>
        /// <param name="noOfRecordsToBeProcessed">The no of records to be processed.</param>
        /// <returns>Returns the List of ModuleReadData</returns>
        public static List<ModuleReadData> FetchModuleDataDetailsForSync(int noOfRecordsToBeProcessed)
		{
			return DbClient.ExecuteReader<ModuleReadData>(Resources.Ecolab_GetModuleReadDataForSync, delegate (DbCommand cmd, DbContext context)
			{
				cmd.AddParameter("RecordCount", noOfRecordsToBeProcessed);
				cmd.CommandType = CommandType.Text;
			}).ToList();
		}

        /// <summary>
        /// Gets the meter data count.
        /// </summary>
        /// <returns>Returns the integer data.</returns>
        public static int GetMeterDataCount()
		{
			return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetModuleReadDataCount, delegate (DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.Text;
			});
		}

        /// <summary>
        /// Saves the module reading rollup data.
        /// </summary>
        /// <param name="moduleReadData">The module read data.</param>
        public static void SaveModuleReadingRollupData(ModuleReadData moduleReadData)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveModuleReadingDataForRollUp, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ModuleId", moduleReadData.ModuleId);
                cmd.AddParameter("ModuleTypeId", moduleReadData.ModuleTypeId);
                cmd.AddParameter("Reading", moduleReadData.Reading);
                cmd.AddParameter("Usage", moduleReadData.Usage);
                cmd.AddParameter("PlantId", moduleReadData.PlantId);
                cmd.AddParameter("PartitionOn", DbType.DateTime, moduleReadData.PartitionOn);
                cmd.AddParameter("ShiftId", moduleReadData.ShiftId);
            });
        }
    }
}