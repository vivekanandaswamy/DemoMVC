﻿// -----------------------------------------------------------------------
// <copyright file="PlantFormulaAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Formula Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class Plant Formula Access
    /// </summary>
    public class PlantFormulaAccess
    {
        /// <summary>
        /// Get Plant Formula Details
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="isResync">The is resync for Plant Formula.</param>
        /// <returns>
        /// List of Formulas
        /// </returns>
        public static List<Formula> GetPlantFormulaDetails(string ecolabAccountNumber, int programId, bool? isResync = null)
        {
            return DbClient.ExecuteReader<Formula>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPrograms : Resources.Ecolab_GetPrograms, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("IsResync", isResync);
                    cmd.AddParameter("ProgramId", programId);

                }).ToList();
        }

        /// <summary>
        /// Save the Save Plant Formula Details
        /// </summary>
        /// <param name="formula">the formula</param>
        /// <param name="userId">user id</param>
        /// <param name="lastModifiedTimestamp">The last modified timestamp.</param>
        /// <returns>System.Int32.</returns>
        public static int SavePlantFormulaDetails(Formula formula, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            SqlParameter paramProgramId = new SqlParameter { ParameterName = "OutputProgramId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_saveProgramDetails : Resources.Ecolab_saveProgramDetails, delegate(DbCommand cmd, DbContext context)
           {
               cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
               cmd.AddParameter("ProgramId", formula.ProgramId);
               cmd.AddParameter("Name", DbType.String, 255, formula.Name);
               cmd.AddParameter("PlantChainId", formula.PlantChainId);
               cmd.AddParameter("PlantProgramId", (formula.PlantProgramId == 0) ? null : formula.PlantProgramId);
               cmd.AddParameter("FormulaCategoryId", formula.FormulaCategory);
               cmd.AddParameter("EcolabSaturationId", (formula.EcolabSaturationId == 0) ? null : formula.EcolabSaturationId);
               cmd.AddParameter("FormulaSegmentId", (formula.FormulaSegmentId == 0) ? null : formula.FormulaSegmentId);
               cmd.AddParameter("CustomerId", formula.CustomerId);
               cmd.AddParameter("Rewash", formula.Rewash);
               cmd.AddParameter("Pieces", formula.Pieces);
               cmd.AddParameter("Weight", formula.WeightDisplay);
               cmd.AddParameter("UserID", userId);
               cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, formula.EcolabAccountNumber);
               if (formula.LastModifiedTimestampAtCentral.HasValue && formula.LastModifiedTimestampAtCentral.Value != DateTime.MinValue)
               {
                   cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, formula.LastModifiedTimestampAtCentral.Value);
               }
               cmd.Parameters.Add(paramProgramId);
               cmd.Parameters.Add(paramLastModifiedTimeStamp);
           });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramProgramId.Value) ? 0 : (int)paramProgramId.Value;

            return returnValue;
        }

        /// <summary>
        /// Delete Plant Formula Details
        /// </summary>
        /// <param name="programId">program Id for Plant Formula.</param>
        /// <param name="lastmodifiedtime">The lastmodifiedtime.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="userId">the userId</param>
        /// <param name="lastModifiedTimestamp">The last modified time stamp.</param>
        /// <returns>
        /// Returns Boolean value
        /// </returns>
        public static int DeletePlantFormulaDetails(int programId, DateTime lastmodifiedtime, string ecolabAccountNumber, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;

            SqlParameter param = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_deleteProgramDetails : Resources.Ecolab_deleteProgramDetails, delegate(DbCommand cmd, DbContext context)
           {
               cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
               cmd.AddParameter("ProgramId", programId);
               cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
               cmd.AddParameter("UserID", userId);
               cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastmodifiedtime);
               cmd.Parameters.Add(param);
           });
            lastModifiedTimestamp = Convert.IsDBNull(param.Value) ? DateTime.UtcNow : (DateTime)param.Value;
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("TableName", DbType.String, 1000, "TCD.ProgramMaster");
                 });
        }

        /// <summary>
        ///     validate formula for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateFormulaSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidatePlantFormulaSave : Resources.Ecolab_ValidatePlantFormulaSave, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Get Plant Formula Details
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="isResync">if set to <c>true</c> [is resync].</param>
        /// <returns>List&lt;Formula&gt;.</returns>
        public static List<Formula> GetPlantFormulaDetailsForResync(string ecolabAccountNumber, bool isResync)
        {
            return DbClient.ExecuteReader<Formula>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPrograms : Resources.Ecolab_GetPrograms,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("PageNo", 0);
                    cmd.AddParameter("RecordsPerPage", 0);
                    cmd.AddParameter("IsResync", isResync);

                }).ToList();
        }

        /// <summary>
        /// SaveMyServiceFormulaDetails in central
        /// </summary>
        /// <param name="formula">Object of formula</param>
        /// <param name="userId">userid</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        /// <returns>success/failure</returns>
        public static int SaveMyServiceFormulaDetails(Formula formula, int userId, out DateTime lastModifiedTime)
        {
            int returnValue = 0;
            lastModifiedTime = DateTime.UtcNow;

            SqlParameter paramProgramId = new SqlParameter { ParameterName = "@OutputProgramId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SavePlantFormulaFromMyService : Resources.Ecolab_SavePlantFormulaFromMyService, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, formula.EcolabAccountNumber);
                    cmd.AddParameter("Name", DbType.String, 1000, formula.Name);
                    cmd.AddParameter("MyServiceEcolabTextileCategory", formula.EcolabTextileId);
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameter("Pieces", formula.Pieces);
                    cmd.AddParameter("Rewash", formula.Rewash);
                    cmd.AddParameter("Weight", formula.Weight);
                    cmd.AddParameter("PlantProgramId", formula.PlantProgramId);
                    cmd.AddParameter("ChainTextileId", formula.ChainTextileId);
                    cmd.AddParameter("CustomerId", formula.CustomerId);
                    cmd.Parameters.Add(paramProgramId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
                lastModifiedTime = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
                returnValue = Convert.IsDBNull(paramProgramId.Value) ? 0 : (int)paramProgramId.Value;
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Gets the formula segments.
        /// </summary>
        /// <returns>List&lt;FormulaSegment&gt;.</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public static List<FormulaSegment> GetFormulaSegments()
        {
            return DbClient.ExecuteReader<FormulaSegment>(Resources.Ecolab_GetFormulaSegments, delegate (DbCommand cmd, DbContext context)
            {
            }).ToList();
        }

        /// <summary>
        /// Gets the chain formula names.
        /// </summary>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <returns>List&lt;PlantChainProgram&gt;.</returns>
        public static List<PlantChainProgram> GetChainFormulaNames(int plantChainId)
        {
            return DbClient.ExecuteReader<PlantChainProgram>(Resources.Ecolab_GetChainFormulaNames, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("PlantChainId", plantChainId);
            }).ToList();
        }

        /// <summary>
        /// Gets the chain formula data.
        /// </summary>
        /// <param name="plantProgramId">The plant program identifier.</param>
        /// <returns>List&lt;PlantChainProgram&gt;.</returns>
        public static List<PlantChainProgram> GetChainFormulaData(int plantProgramId)
        {
            return DbClient.ExecuteReader<PlantChainProgram>(Resources.Ecolab_GetChainFormulaData, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("PlantProgramId", plantProgramId);
            }).ToList();
        }

        /// <summary>
        /// Gets the plant formulas for synchronize.
        /// </summary>
        /// <param name="programId">The program identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns></returns>
        public static List<Formula> GetPlantFormulasForSync(int? programId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Formula>(Resources.Ecolab_GetPlantFormulasForSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ProgramId", programId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// Saves the plant chain programs.
        /// </summary>
        /// <param name="plantChainProgram">The plant chain program.</param>
        public static void SavePlantChainPrograms(PlantChainProgram plantChainProgram)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_SavePlantChainProgram, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("PlantProgramId", plantChainProgram.PlantProgramId);
                cmd.AddParameter("PlantProgramName", DbType.String, 1000, plantChainProgram.PlantProgramName);
                cmd.AddParameter("PlantChainId", plantChainProgram.PlantChainId);
                cmd.AddParameter("ChainTextileCategoryId", plantChainProgram.ChainTextileId);
                cmd.AddParameter("EcolabTextileCategoryId", plantChainProgram.EcolabTextileId);
                cmd.AddParameter("FormulaSegmentId", plantChainProgram.FormulaSegmentId);
                cmd.AddParameter("Is_Deleted", plantChainProgram.IsDeleted);
                cmd.AddParameter("EcolabSaturationId", plantChainProgram.EcolabSaturationId);
            });
        }

        /// <summary>
        /// Saves the chain textile category.
        /// </summary>
        /// <param name="chainTextiles">The chain textiles.</param>
        public static void SaveChainTextileCategory(ChainTextileCategory chainTextiles)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_SaveChainTextileCategory, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("TextileId", chainTextiles.TextileId);
                cmd.AddParameter("Name", DbType.String, 1000, chainTextiles.Name);
                cmd.AddParameter("PlantChainId", chainTextiles.ChainId);
                cmd.AddParameter("Is_Deleted", chainTextiles.IsDeleted);
            });
        }

        /// <summary>
        /// Saves the formula details for first time synchronize.
        /// </summary>
        /// <param name="formula">The formula.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveFormulaDetailsForFirstTimeSync(Formula formula, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveFormulaDetailsForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ProgramId", formula.ProgramId);
                cmd.AddParameter("Name", DbType.String, 255, formula.Name);
                cmd.AddParameter("Pieces", formula.Pieces);
                cmd.AddParameter("EcolabTextileCategoryId", formula.EcolabTextileId);
                cmd.AddParameter("EcolabSaturationId", formula.EcolabSaturationId);
                cmd.AddParameter("PlantProgramId", formula.PlantProgramId);
                cmd.AddParameter("TextileId", formula.ChainTextileId);
                cmd.AddParameter("Rewash", formula.Rewash);
                cmd.AddParameter("Weight", formula.Weight);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("CustomerId", formula.CustomerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, formula.EcolabAccountNumber);
                cmd.AddParameter("Weight_Display", formula.WeightDisplay);
                cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, formula.LastModifiedTimestamp);
                cmd.AddParameter("IsDelete", formula.IsDelete);
                cmd.AddParameter("FormulaSegmentId", formula.FormulaSegmentId);
            });
        }
    }
}