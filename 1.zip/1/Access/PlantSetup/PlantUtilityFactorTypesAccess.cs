﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityFactorTypesAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Utility Factor Types model </summary>
// -----------------------------------------------------------------------

using System;
using System.Data.SqlClient;

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     This class is the data layer for plant utility .
    /// </summary>
    public class PlantUtilityFactorTypesAccess
    {
        /// <summary>
        ///     Gets or sets the list of plant utility factor types.
        /// </summary>
        /// <value>List of Plant Utility Factor Types</value>
        public static List<PlantUtilityFactorTypes> ListPlantUtility { get; set; }

        /// <summary>
        ///     Gets the Plant utility details
        /// </summary>
        /// <returns>Row of Plant utility details</returns>
        public static List<PlantUtilityFactorTypes> GetPlantUtilityDetails(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<PlantUtilityFactorTypes>(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantUtilityDetails : Resources.Ecolab_GetPlantUtilityDetails,
                delegate(DbCommand cmd, DbContext context) 
                { 
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }

        /// <summary>
        /// Gets the list of water factor types from plant utility page to display in wash step.
        /// </summary>
        /// <param name="ecolabAccountNumber">passing ecolabaccountnumber</param>
        /// <returns>List of water factor types from plant utility page to display in wash step.</returns>
        public static List<PlantUtilityWaterTypeMaster> GetPlantUtilityWaterFactorTypes(string ecolabAccountNumber, int regionId = 0)
        {
            return DbClient.ExecuteReader<PlantUtilityWaterTypeMaster>(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetWaterTypesFromUtility : Resources.Ecolab_GetWaterTypesFromUtility,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("RegionId", regionId);
                }).ToList();
        }

		/// <summary>
		/// Gets the default values of the plant utility entities.
		/// </summary>
		/// <param name="regionId">The region identifier.</param>
		/// <returns>
		/// Plant utility factor types class object.
		/// </returns>
		public static List<PlantUtilityFactorTypes> GetPlantUtilityDetailsList(int regionId)
        {
            ListPlantUtility = new List<PlantUtilityFactorTypes>();
            List<PlantUtilityWaterTypeMaster> waterFactors = PlantUtilityWaterTypeAccess.GetWaterTypeDetails(regionId);
            foreach (var item in waterFactors)
            {
                if (item.MyServiceUtilTypeCode == "S")
                {
                    PlantUtilityFactorTypes objPlantUtility = new PlantUtilityFactorTypes();
                    objPlantUtility.UtilityType = 0;
                    objPlantUtility.FactorType = item.WaterTypeName;
                    objPlantUtility.Temperature = 0;
                    objPlantUtility.EnergyContent = 0;
                    objPlantUtility.Price = 0;
                    objPlantUtility.Location = item.RegionCode;
                    objPlantUtility.BoilerSteam = true;
                    objPlantUtility.BoilerType = 0;
                    objPlantUtility.SteamPercentage = 0;
                    objPlantUtility.BoilerPercentage = 0;
                    objPlantUtility.StackPercentage = 0;
                    objPlantUtility.RewashFactor = 0;
                    objPlantUtility.FreeType = 0;
                    objPlantUtility.Subunit = "Kwh/m3";
                    objPlantUtility.UtilityWaterType = "S";
                    objPlantUtility.WaterFactorTypeId = 0;
                    ListPlantUtility.Add(objPlantUtility);
                }
            }
            string[] factorTypes = { "Energy", "Electricity" };
            for (int i = 0; i < factorTypes.Length; i++)
            {
                PlantUtilityFactorTypes objPlantUtility = new PlantUtilityFactorTypes();
                objPlantUtility.UtilityType = 0;
                objPlantUtility.FactorType = factorTypes[i];
                objPlantUtility.Temperature = 0;
                objPlantUtility.EnergyContent = 0;
                objPlantUtility.Price = 0;
                objPlantUtility.Location = "1";
                objPlantUtility.BoilerSteam = true;
                objPlantUtility.BoilerType = 0;
                objPlantUtility.SteamPercentage = 0;
                objPlantUtility.BoilerPercentage = 0;
                objPlantUtility.StackPercentage = 0;
                objPlantUtility.RewashFactor = 0;
                if (factorTypes[i] == "Energy")
                {
                    objPlantUtility.FreeType = 4;
                }
                else
                {
                    objPlantUtility.FreeType = 0;
                }

                objPlantUtility.Subunit = "Kwh/m3";
                ListPlantUtility.Add(objPlantUtility);
            }

            return ListPlantUtility;
        }

        /// <summary>
        ///  saving the water and energy utility for plant.
        /// </summary>
        /// <param name="plantUtilityFactorType">the class object for plant utility factor types.</param>
        /// <param name="userId">Logged user Id.</param>
        /// <param name="lastModifiedTimestamp">Las date modified.</param>
        /// <param name="count">For inserting energy utility factors.</param>
        public static void SavePlantWaterEnergyUtilityDetails(PlantUtilityFactorTypes plantUtilityFactorType, int userId, out DateTime lastModifiedTimestamp, int count)
        {
            lastModifiedTimestamp = DateTime.Now;
            if (plantUtilityFactorType.UtilityType == 0)
            {
                if (plantUtilityFactorType.FactorType == "Cold" && plantUtilityFactorType.RegionId == 1)
                {
                    plantUtilityFactorType.FactorType = "Fresh";
                }

                DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SavePlantUtilityDetails : Resources.Ecolab_savePlantUtilityDetails,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;

                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantUtilityFactorType.EcolabAccountNumber);
                        cmd.AddParameter("WaterFactorType", DbType.String, 255, plantUtilityFactorType.FactorType);
                        cmd.AddParameter("Temperature", plantUtilityFactorType.Temperature);
                        cmd.AddParameter("Price", plantUtilityFactorType.Price);
                        cmd.AddParameter("GasOilTypeId", plantUtilityFactorType.GasoilTypeId);
                        cmd.AddParameter("EnergyPrice", plantUtilityFactorType.EnergyPrice);
                        cmd.AddParameter("EnergyPriceSubUnit", DbType.String, 250, plantUtilityFactorType.EnergyPriceUnit);
                        cmd.AddParameter("ElectricalPrice", plantUtilityFactorType.ElectricPrice);
                        cmd.AddParameter("BoilerSteam", plantUtilityFactorType.BoilerSteam);
                        cmd.AddParameter("BoilerType", plantUtilityFactorType.BoilerType);
                        cmd.AddParameter("Steam", plantUtilityFactorType.SteamPercentage);
                        cmd.AddParameter("Boiler", plantUtilityFactorType.BoilerPercentage);
                        cmd.AddParameter("Stack", plantUtilityFactorType.StackPercentage);
                        cmd.AddParameter("RewashFactor", plantUtilityFactorType.RewashFactor);
                        cmd.AddParameter("EvaporationFactor", plantUtilityFactorType.EvaporationFactor);
                        cmd.AddParameter("UserId", userId);
                        cmd.AddParameter("Count", count);
                        cmd.AddParameter("MyServiceWtrFctrId", plantUtilityFactorType.MyServiceWatrFctrId);
                        cmd.AddParameter("MyServiceLastSyncTime", DbType.DateTime, plantUtilityFactorType.MyServiceLastSyncTime);
                    });
            }
            else if (plantUtilityFactorType.WaterFactorTypeId != 0 || plantUtilityFactorType.UtilityType == 1)
            {
                lastModifiedTimestamp = DateTime.Now;
                if (plantUtilityFactorType.FactorType == "Cold")
                {
                    plantUtilityFactorType.FactorType = "Fresh";
                }

                DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdatePlantUtilityDetails : Resources.Ecolab_updatePlantUtilityDetails,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;

                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantUtilityFactorType.EcolabAccountNumber);
                        cmd.AddParameter("WaterFactorType", DbType.String, 255, plantUtilityFactorType.FactorType);
                        cmd.AddParameter("WaterFactorTypeId", plantUtilityFactorType.WaterFactorTypeId);
                        cmd.AddParameter("Temperature", plantUtilityFactorType.Temperature);
                        cmd.AddParameter("Price", plantUtilityFactorType.Price);
                        cmd.AddParameter("GasOilTypeId", plantUtilityFactorType.GasoilTypeId);
                        cmd.AddParameter("EnergyPrice", plantUtilityFactorType.EnergyPrice);
                        cmd.AddParameter("EnergyPriceSubUnit", DbType.String, 250, plantUtilityFactorType.EnergyPriceUnit);
                        cmd.AddParameter("ElectricalPrice", plantUtilityFactorType.ElectricPrice);
                        cmd.AddParameter("BoilerSteam", plantUtilityFactorType.BoilerSteam);
                        cmd.AddParameter("BoilerType", plantUtilityFactorType.BoilerType);
                        cmd.AddParameter("Steam", plantUtilityFactorType.SteamPercentage);
                        cmd.AddParameter("Boiler", plantUtilityFactorType.BoilerPercentage);
                        cmd.AddParameter("Stack", plantUtilityFactorType.StackPercentage);
                        cmd.AddParameter("RewashFactor", plantUtilityFactorType.RewashFactor);
                        cmd.AddParameter("EvaporationFactor", plantUtilityFactorType.EvaporationFactor);
                        cmd.AddParameter("UserId", userId);
                        cmd.AddParameter("Count", count);
                        cmd.AddParameter("InitalValue", plantUtilityFactorType.FreeType);
                    });
            }
        }

        /// <summary>
        /// Saves the plant utility details for first time synchronize.
        /// </summary>
        /// <param name="plantUtilityFactorType">Type of the plant utility factor.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SavePlantUtilityDetailsForFirstTimeSync(PlantUtilityFactorTypes plantUtilityFactorType, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantUtilityDeatilsForFirstTimeSync,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantUtilityFactorType.EcolabAccountNumber);
                        cmd.AddParameter("WaterFactorTypeId", plantUtilityFactorType.WaterFactorTypeId);
                        cmd.AddParameter("Temperature", plantUtilityFactorType.Temperature);
                        cmd.AddParameter("Price", plantUtilityFactorType.Price);
                        cmd.AddParameter("UserId", userId);
                        cmd.AddParameter("LastModifiedTime", DbType.DateTime, plantUtilityFactorType.LastModifiedTime);
                        cmd.AddParameter("MyServiceWtrFctrId", plantUtilityFactorType.MyServiceWatrFctrId);
                        cmd.AddParameter("MyServiceLastSyncTime", DbType.DateTime, plantUtilityFactorType.MyServiceLastSyncTime);
                        cmd.AddParameter("WaterUtilityDetailsId", plantUtilityFactorType.WaterUtilityDetailsID);
                        cmd.AddParameter("GasOilTypeId", plantUtilityFactorType.GasoilTypeId);
                        cmd.AddParameter("EnergyPrice", plantUtilityFactorType.EnergyPrice);
                        cmd.AddParameter("EnergySubUnit", DbType.String, 250, plantUtilityFactorType.EnergyPriceUnit);
                        cmd.AddParameter("ElectricPrice", plantUtilityFactorType.ElectricPrice);
                        cmd.AddParameter("BolierSteam", plantUtilityFactorType.BoilerSteam);
                        cmd.AddParameter("BolierType", plantUtilityFactorType.BoilerType);
                        cmd.AddParameter("Steam", plantUtilityFactorType.SteamPercentage);
                        cmd.AddParameter("Boiler", plantUtilityFactorType.BoilerPercentage);
                        cmd.AddParameter("Stack", plantUtilityFactorType.StackPercentage);
                        cmd.AddParameter("RewashFactor", plantUtilityFactorType.RewashFactor);
                        cmd.AddParameter("EvaporationFactor", plantUtilityFactorType.EvaporationFactor);
                    });
        }
    }
}