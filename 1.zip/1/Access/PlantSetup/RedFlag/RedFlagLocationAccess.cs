﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagLocationAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RedFlagLocation Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.RedFlag
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Entities.PlantSetup.RedFlag;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for RedFlagLocationAccess
    /// </summary>
    public class RedFlagLocationAccess
    {
        /// <summary>
        ///     Get the red flag location details
        /// </summary>
        /// <param name="itemId">The Parameter  item id </param>
        /// <param name="ecolabAccNumber">Ecolab Account Number </param>
        /// <returns>List of RedFlag Locations</returns>
        public static List<RedFlagLocation> FetchRedFlagLocationDetails(int itemId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<RedFlagLocation>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetRedFlagLocation : Resources.Ecolab_GetRedFlagLocation, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ItemId", itemId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        /// Get the machine details
        /// <param name="groupTypeId">the groupTypeId</param>
        /// <param name="ecolabAccNumber">Ecolab Account Number </param>
        /// </summary>
        /// <returns> The list of machines </returns>
        public static List<MachineSetup> GetRedFlagMachineDetails(int? groupTypeId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<MachineSetup>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantRedFlagmachines : Resources.Ecolab_GetPlantRedFlagmachines, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("GroupId", groupTypeId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        ///     Gets list of Meters for the location
        /// </summary>
        /// <param name="locationId">the location id</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of Meters for the location passed</returns>
        public static List<Meter> GetRedFlagMetersByLocation(int locationId, string ecolabAccountNumber, int itemId)
        {
            return DbClient.ExecuteReader<Meter>(Resources.Ecolab_GetRedFlagMetersByLocation, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("@LocationId", locationId);
                cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("@itemId", itemId);

            }).ToList();
        }

        /// <summary>
        ///     Gets list of Sensors for the location
        /// </summary>
        /// <param name="locationId">the location id</param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns>List of Sensors for the location passed</returns>
        public static List<Sensor> GetRedFlagSensorsByLocation(int locationId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Sensor>(Resources.Ecolab_GetRedFlagSensorsByLocation, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("@LocationId", locationId);
                cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// Gets list of Sensors for the location
        /// </summary>
        /// <param name="locationId">the location id</param>
        /// <param name="ecolabAccNumber">The ecolab acc number.</param>
        /// <returns>
        /// List of Sensors for the location passed
        /// </returns>
        public static List<Entities.Formula> FetchFormulaCategorybyLocationId(int? locationId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<Entities.Formula>(Resources.Ecolab_GetFormulabyLocationId,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("LocationId", locationId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                    cmd.CommandType = CommandType.Text;
                }).ToList();
        }

    }
}