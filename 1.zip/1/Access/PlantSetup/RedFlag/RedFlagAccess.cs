﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RedFlag Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.RedFlag
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.RedFlag;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for RedFlagAccess
    /// </summary>
    public class RedFlagAccess
    {
        /// <summary>
        ///     Get the red flag details
        /// </summary>
        /// <param name="id">red flag id</param>
        /// <param name="ecolabAccNumber"> Ecolab account number </param>
        /// <returns>Row of red flag details</returns>
        public static List<RedFlag> FetchRedFlagDetails(int? id, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<RedFlag>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetRedFlagDetails : Resources.Ecolab_GetRedFlagDetails, delegate(DbCommand cmd, DbContext context)
            {
                    cmd.AddParameter("Id", id);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                }).ToList();
        }

        /// <summary>
        ///     Insert the red flag
        /// </summary>
        /// <param name="redFlag">RedFlag object</param>
        /// <param name="trans">trans parameter.</param>
        /// <param name="context">The context parameter.</param>
        /// <param name="userId">current user id</param>
        /// <param name="errorCode">The error code</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <returns>scope value</returns>
        public static int InsertRedFlag(RedFlag redFlag, ref DbTransaction trans, ref DbContext context, int userId, out int errorCode, out DateTime lastModifiedTimestamp)
        {
            int returnValue;
            errorCode = 0;
            lastModifiedTimestamp = DateTime.Now;
            if (redFlag.FormulaId == -1)
            {
                redFlag.FormulaId = null;
            }
            
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramRedFlagId = new SqlParameter { ParameterName = "OutputRedFlagId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            DbClient.ExecuteScalar<string>(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_InsertRedFlag : Resources.Ecolab_InsertRedFlag, delegate(DbCommand cmd, DbContext context2)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Id", redFlag.Id);
                    cmd.AddParameter("ItemID", redFlag.ItemId);
                    cmd.AddParameter("MinRange", redFlag.MinimumRange);
                    cmd.AddParameter("MaxRange", redFlag.MaximumRange);
                    cmd.AddParameter("LocationID", redFlag.LocationId);
                    cmd.AddParameter("MachineCompartmentId", redFlag.MachineId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, redFlag.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramRedFlagId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    cmd.AddParameter("CategoryId", redFlag.CategoryId);
                    cmd.AddParameter("FormulaId", redFlag.FormulaId);
                    cmd.AddParameter("ProductId", redFlag.ProductId);
                    cmd.AddParameter("MeterId", redFlag.MeterId);
                    cmd.AddParameter("SensorId", redFlag.SensorId);

                });

            int status;
            status = int.TryParse(param.Value.ToString(), out status) ? status : 0;
            DateTime dt;
            if (DateTime.TryParse(paramLastModifiedTimeStamp.Value.ToString(), out dt))
            {
                lastModifiedTimestamp = (DateTime)paramLastModifiedTimeStamp.Value;
            }
            if (status > 0 && (status == 401 || status == 301))
            {
                returnValue = status;
                errorCode = returnValue;
            }
            else
            {
                returnValue = Convert.IsDBNull(paramRedFlagId.Value) ? 0 : (int)paramRedFlagId.Value;
                returnValue = status > 0 ? status : returnValue;
            }

            return returnValue;
        }

        /// <summary>
        ///     update the red flag
        /// </summary>
        /// <param name="redFlag">RedFlag object</param>
        /// <param name="trans">the trans parameter.</param>
        /// <param name="context">The context parameter.</param>
        /// <param name="userId">current user id</param>
        /// <param name="errorCode">The error code</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <returns>Red Flag ID</returns>
        public static int UpdateRedFlag(RedFlag redFlag, ref DbTransaction trans, ref DbContext context, int userId, out int errorCode, out DateTime lastModifiedTimestamp)
        {
            int returnValue;
            errorCode = 0;
            if (redFlag.FormulaId == -1)
            {
                redFlag.FormulaId = null;
            }
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };

            SqlParameter paramRedFlagId = new SqlParameter { ParameterName = "OutputRedFlagId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteScalar<string>(trans, context, Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateRedFlag : Resources.Ecolab_UpdateRedFlag, delegate(DbCommand cmd, DbContext context2)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Id", redFlag.Id);
                    cmd.AddParameter("ItemID", redFlag.ItemId);
                    cmd.AddParameter("MinRange", redFlag.MinimumRange);
                    cmd.AddParameter("MaxRange", redFlag.MaximumRange);
                    cmd.AddParameter("LocationID", redFlag.LocationId);
                    cmd.AddParameter("MachineCompartmentId", redFlag.MachineId);
                    cmd.AddParameter("IsSelected", redFlag.IsSelected);
                    cmd.AddParameter("IsDirty", redFlag.IsDirty);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, redFlag.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    if (redFlag.LastModifiedTimestampAtCentral.HasValue)
                    {
                        cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, redFlag.LastModifiedTimestampAtCentral.Value);
                    }
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramRedFlagId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    cmd.AddParameter("CategoryId", redFlag.CategoryId);
                    cmd.AddParameter("FormulaId", redFlag.FormulaId);
                    cmd.AddParameter("ProductId", redFlag.ProductId);
                    cmd.AddParameter("MeterId", redFlag.MeterId);
                    cmd.AddParameter("SensorId", redFlag.SensorId);
                });
            int status;
            status = int.TryParse(param.Value.ToString(), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            if (status == 401 || status == 301)
            {
                returnValue = Convert.ToInt32(param.Value);
                errorCode = returnValue;
            }
            else
            {
                returnValue = Convert.IsDBNull(paramRedFlagId.Value) ? 0 : (int)paramRedFlagId.Value;
                returnValue = status > 0 && status == 201 ? status : returnValue;
            }

            return returnValue;
        }

        /// <summary>
        ///     delete the red flag
        /// </summary>
        /// <param name="redFlag">RedFlag object</param>
        /// <param name="userId">current user id</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp. </param>
        /// <returns>scope value</returns>
        public static int DeleteRedFlag(RedFlag redFlag, int userId, out DateTime lastModifiedTimestamp)
        {
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteRedFlag : Resources.Ecolab_DeleteRedFlag, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Id", redFlag.Id);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, redFlag.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    if (redFlag.LastModifiedTimestampAtCentral.HasValue)
                    {
                        cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, redFlag.LastModifiedTimestampAtCentral.Value);
                    }
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            DateTime modifiedTimeStamp = (DateTime)paramLastModifiedTimeStamp.Value;
            lastModifiedTimestamp = modifiedTimeStamp;
            return 0;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("TableName", DbType.String, 1000, "TCD.RedFlag");
                 });
        }

        /// <summary>
        ///     validate RedFlag for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateRedFlagSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateRedFlagSave : Resources.Ecolab_ValidateRedFlagSave, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        ///     Get the red flag details
        /// </summary>
        /// <param name="id">red flag id</param>
        /// <param name="ecolabAccNumber"> Ecolab account number </param>
        /// <returns>Row of red flag details</returns>
        public static List<RedFlag> FetchRedFlagDetailsForRESync(int? id, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<RedFlag>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetRedFlagDetailsForReSync : Resources.Ecolab_GetRedFlagDetailsForReSync,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("Id", id);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                }).ToList();
        }

		/// <summary>
		///     Get the red flag details
		/// </summary>
		/// <param name="id">red flag id</param>
		/// <param name="ecolabAccNumber"> Ecolab account number </param>
		/// <returns>Row of red flag details</returns>
		public static List<RedFlagMappingData> FetchRedFlagMappingDataForSync(int? id, string ecolabAccNumber)
		{
			return DbClient.ExecuteReader<RedFlagMappingData>(Resources.Ecolab_GetRedFlagMappingDataForSync,
				delegate(DbCommand cmd, DbContext context)
				{
					cmd.AddParameter("MappingId", id);
					cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
					cmd.CommandType = CommandType.StoredProcedure;
				}).ToList();
		}

        /// <summary>
		///     Get the red flag details
		/// </summary>
		/// <param name="locationId">locationId</param>
        ///  <param name="EcolabTextileCategoryId"> EcolabTextileCategoryId </param>
		/// <param name="ecolabAccNumber"> Ecolab account number </param>
		/// <returns>Row of red flag details</returns>
		public static List<Entities.Formula> FetchFormulaName(int? locationId, int? ecolabTextileCategoryId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<Entities.Formula>(Resources.Ecolab_GetFormulaName,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("@LocationId", locationId);
                    cmd.AddParameter("EcolabTextileCategoryId", ecolabTextileCategoryId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                    cmd.CommandType = CommandType.Text;
                }).ToList();
        }

        /// <summary>
        ///     Get the red flag details
        /// </summary>
        /// <param name="locationId">locationId</param>
        /// <param name="formulaId">formulaId </param>
        /// <param name="ecolabAccNumber">The Ecolab Acc Number</param>
        /// <returns>Row of red flag details</returns>
        public static List<Entities.PlantSetup.Chemical.ProductMaster> FetchProductsByFormulaId(int? locationId, int? formulaId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<Entities.PlantSetup.Chemical.ProductMaster>(Resources.Ecolab_GetProductsByFormulaId,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("@LocationId", locationId);
                    cmd.AddParameter("@ProgramId", formulaId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                    cmd.CommandType = CommandType.Text;
                }).ToList();
        }

        /// <summary>
        ///     Get the red flag Category
        /// </summary>
        /// <returns>Row of redflagcategory details</returns>
        public static List<RedFlagCategory> FetchRedFlagCategory()
        {
            return DbClient.ExecuteReader<RedFlagCategory>(Resources.Ecolab_GetRedFlagCategory,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.Text;
                }).ToList();
        }

        /// <summary>
        ///     Get the red flag Category
        /// </summary>
        /// <param name="categoryId">categoryId</param>
        /// <returns>Row of redflagcategory details</returns>
        public static List<RedFlagItem> GetRedFlagItemListByCategory(int categoryId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<RedFlagItem>(Resources.Ecolab_GetRedFlagItemListByCategory, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("@CategoryId", categoryId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        /// Gets the red flag data count.
        /// </summary>
        /// <returns></returns>
        public static int GetRedFlagDataCount()
        {
            return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetRedFlagDataCount, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
            });
        }

        /// <summary>
        /// Fetches the red flag details for synchronize.
        /// </summary>
        /// <param name="noOfRecordsToBeProcessed">The no of records to be processed.</param>
        /// <returns></returns>
        public static List<RedFlagData> FetchRedFlagDetailsForSync(int noOfRecordsToBeProcessed)
        {
            return DbClient.ExecuteReader<RedFlagData>(Resources.Ecolab_GetRedFlagDataForSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("RecordCount", noOfRecordsToBeProcessed);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        /// Saves the red flag data for first time synchronize.
        /// </summary>
        /// <param name="redFlag">The red flag.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveRedFlagDataForFirstTimeSync(RedFlag redFlag, int userId)
        {
            DbClient.ExecuteScalar<string>(Resources.Ecolab_SaveRedFlagDetailsForFirstTimeSync, delegate (DbCommand cmd, DbContext context2)
            {
                cmd.AddParameter("Id", redFlag.Id);
                cmd.AddParameter("Item", redFlag.ItemId);
                cmd.AddParameter("MaximumRange", redFlag.MaximumRange);
                cmd.AddParameter("MinimumRange", redFlag.MinimumRange);
                cmd.AddParameter("Location", redFlag.LocationId);
                cmd.AddParameter("IsDeleted", redFlag.IsDeleted);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, redFlag.EcolabAccountNumber);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, redFlag.LastModifiedTimestamp);
                cmd.AddParameter("RedFlagCategoryId", redFlag.FormulaCategoryId);
                cmd.AddParameter("FormulaId", redFlag.FormulaId);
                cmd.AddParameter("ProductId", redFlag.ProductId);
                cmd.AddParameter("MeterId", redFlag.MeterId);
                cmd.AddParameter("SensorId", redFlag.SensorId);
                cmd.AddParameter("PlantId", redFlag.PlantId);
            });
        }

        /// <summary>
        /// Saves the red flag mapping data for first time synchronize.
        /// </summary>
        /// <param name="mappingData">The mapping data.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveRedFlagMappingDataForFirstTimeSync(RedFlagMappingData mappingData, int userId)
        {
            DbClient.ExecuteScalar<string>(Resources.Ecolab_SaveRedFlagMappingDataForFirstTimeSync, delegate (DbCommand cmd, DbContext context2)
            {
                cmd.AddParameter("Id", mappingData.Id);
                cmd.AddParameter("MappingId", mappingData.MappingId);
                cmd.AddParameter("MachineId", mappingData.MachineId);
                cmd.AddParameter("IsDeleted", mappingData.IsDeleted);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, mappingData.EcolabAccountNumber);
                cmd.AddParameter("UserId", userId);
            });
        }
    }
    
}