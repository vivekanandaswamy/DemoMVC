﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagItemAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RedFlag Item Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.RedFlag
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup.RedFlag;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for RedFlagListItemAccess
    /// </summary>
    public class RedFlagItemAccess
    {
        /// <summary>
        ///     Get the red flag list item details
        /// </summary>
        /// <param name="itemId">The Item id.</param>
        /// <param name="ecolabAccNumber"> Ecolab account number </param>
        /// <returns>Row of red flag list item details</returns>
        public static List<RedFlagItem> FetchRedFlagItemDetails(int? itemId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<RedFlagItem>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetRedFlagListItems : Resources.Ecolab_GetRedFlagListItems, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ItemId", itemId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
            }).ToList();
        }
    }
}