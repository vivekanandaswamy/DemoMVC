﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Management Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.Common;
	using System.Data.SqlClient;
	using System.Text.RegularExpressions;
	using Entities.UserManagement;
	using Nalco.Data.Common;
	using Properties;

	/// <summary>
	///     Class UserManagementAccess
	/// </summary>
	public class UserManagementAccess
	{
		/// <summary>
		///     Gets user details
		/// </summary>
		/// <param name="userNumber">The Parameter User Number</param>
		/// <param name="ecoalabAccountNumber">The Parameter Ecolab Account Number</param>
		/// <returns>IEnumerable List of UserManagement</returns>
		public static IEnumerable<UserManagement> FetchPlantUserDetails(int? userNumber, string ecoalabAccountNumber)
		{
			return DbClient.ExecuteReader<UserManagement>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetUserdetails : Resources.Ecolab_GetUserdetails, delegate(DbCommand cmd, DbContext context)
			{
				cmd.AddParameter("UserNumber", userNumber);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecoalabAccountNumber);
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
			});
		}

		/// <summary>
		///     Insert a User in User Management
		/// </summary>
		/// <param name="userManagement">UserManagement object</param>
		/// <param name="userId">Parameter User Id</param>
		/// <param name="lastModifiedTimestamp">Output parameter last modified time</param>
		/// <param name="outputId">Id Generated in local to be used for Sync/resync</param>
		/// <returns>Returns Status</returns>
		public static string InsertUserManagement(UserManagement userManagement, int userId, out DateTime lastModifiedTimestamp, out int outputId)
		{
			SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };
			SqlParameter paramUserId = new SqlParameter { ParameterName = "OutputUserId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

			SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
			DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveUserDetails : Resources.Ecolab_SaveUserDetails, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
				cmd.AddParameter("ContactId", userManagement.ContactId);
				cmd.AddParameter("FirstName", DbType.String, 255, userManagement.FirstName);
				cmd.AddParameter("LastName", DbType.String, 255, userManagement.LastName);
				cmd.AddParameter("LoginName", DbType.String, 255, userManagement.LoginName);
				cmd.AddParameter("Password", DbType.String, 255, userManagement.Password);
				cmd.AddParameter("MailId", DbType.String, 255, userManagement.Email);
				cmd.AddParameter("ContactNo", DbType.String, 255, userManagement.ContactNo);
				cmd.AddParameter("RoleId", userManagement.LevelId);
				cmd.AddParameter("UserId", userId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, userManagement.EcolabAccountNumber);
				cmd.AddParameter("CurrencyCode", DbType.String, 100, userManagement.CurrencyCode);
				cmd.AddParameter("UOMId", userManagement.UOMId == 0 ? null : userManagement.UOMId);
				cmd.Parameters.Add(param);
				cmd.Parameters.Add(paramUserId);
				cmd.Parameters.Add(paramLastModifiedTimeStamp);
			});
			lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
			outputId = (paramUserId.Value == DBNull.Value) ? 0 : (int)paramUserId.Value;
			return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
		}

		/// <summary>
		///     Updates a User in User Management
		/// </summary>
		/// <param name="userManagement">UserManagement object</param>
		/// <param name="userId">Parameter User Id</param>
		/// <returns>Returns Status</returns>
		public static string UpdateUserManagement(UserManagement userManagement, int userId, out DateTime lastModifiedTimestamp, out int outputId)
		{
			SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };
			SqlParameter paramUserId = new SqlParameter { ParameterName = "OutputUserId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
			SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
			DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateUserDetails : Resources.Ecolab_UpdateUserDetails, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
				cmd.AddParameter("FirstName", DbType.String, 255, userManagement.FirstName);
				cmd.AddParameter("LastName", DbType.String, 255, userManagement.LastName);
				cmd.AddParameter("UserNumber", userManagement.UserNumber);
				cmd.AddParameter("LoginName", DbType.String, 255, userManagement.LoginName);
				cmd.AddParameter("Password", DbType.String, 255, userManagement.Password);
				cmd.AddParameter("MailId", DbType.String, 255, userManagement.Email);
				cmd.AddParameter("ContactNo", DbType.String, 255, userManagement.ContactNo);
				cmd.AddParameter("RoleId", userManagement.LevelId);
				cmd.AddParameter("UserId", userId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, userManagement.EcolabAccountNumber);
				cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, userManagement.LastModifiedTimestampAtCentral);
				cmd.Parameters.Add(param);
				cmd.Parameters.Add(paramUserId);
				cmd.Parameters.Add(paramLastModifiedTimeStamp);
			});
			lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
			outputId = (paramUserId.Value == DBNull.Value) ? 0 : (int)paramUserId.Value;
			return Convert.IsDBNull(param.Value) ? null : (string)param.Value;
		}

		/// <summary>
		///     Deletes a User in User Management
		/// </summary>
		/// <param name="userManagement">UserManagement object</param>
		/// <param name="userId">Parameter User Id</param>
		/// <returns>Returns Status</returns>
		public static bool DeleteUserManagement(UserManagement userManagement, int userId, out DateTime lastModifiedTimestamp)
		{
			SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
			DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeleteUserDetails : Resources.Ecolab_DeleteUserDetails, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
				cmd.AddParameter("UserNumber", userManagement.UserNumber);
				cmd.AddParameter("UserId", userId);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, userManagement.EcolabAccountNumber);
				cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, userManagement.LastModifiedTimestampAtCentral);
				cmd.Parameters.Add(paramLastModifiedTimeStamp);
			});
			lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
			return true;
		}

		/// <summary>
		///     Get Max Number Of Records.
		/// </summary>
		/// <param name="ecolabAccountNumber">Ecolab Account Number</param>
		/// <returns>Max Record Count</returns>
		public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
		{
			return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				cmd.AddParameter("TableName", DbType.String, 1000, "TCD.UserMaster");
			});
		}

		/// <summary>
		///     validate User Master for sync.
		/// </summary>
		/// <param name="ecolabAccountNumber">Ecolab Account Number</param>
		/// <param name="maxNumberOfRecords">Max Number Of Records</param>
		/// <returns>success/failure</returns>
		public static int ValidateUserManagementSave(string ecolabAccountNumber, int maxNumberOfRecords)
		{
			int returnValue;
			try
			{
				returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidateUserManagementSave, delegate(DbCommand cmd, DbContext context)
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
					cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
				});
			}
			catch (Exception ex)
			{
				returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
			}
			return returnValue;
		}

        /// <summary>
        /// save the user management for first time synchronize.
        /// </summary>
        /// <param name="userManagement">The user management.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveUserManagementForFirstTimeSync(UserManagement userManagement, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_InsertUpdateUserManagementForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("UserNumber", userManagement.UserNumber);
                cmd.AddParameter("ContactId", userManagement.ContactId);
                cmd.AddParameter("FirstName", DbType.String, 255, userManagement.FirstName);
                cmd.AddParameter("LastName", DbType.String, 255, userManagement.LastName);
                cmd.AddParameter("LoginName", DbType.String, 255, userManagement.LoginName);
                cmd.AddParameter("Password", DbType.String, 255, userManagement.Password);
                cmd.AddParameter("MailId", DbType.String, 255, userManagement.Email);
                cmd.AddParameter("ContactNo", DbType.String, 255, userManagement.ContactNo);
                cmd.AddParameter("RoleId", userManagement.LevelId);
                cmd.AddParameter("LanguageId", userManagement.LanguageId);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, userManagement.EcolabAccountNumber);
                cmd.AddParameter("CurrencyCode", DbType.String, 100, userManagement.CurrencyCode);
                cmd.AddParameter("UOMId", userManagement.UOMId == 0 ? null : userManagement.UOMId);
                cmd.AddParameter("Fax", DbType.String, 1000, userManagement.Fax);
                cmd.AddParameter("IsActive", userManagement.IsActive);
                cmd.AddParameter("Mobile", DbType.String, 1000, userManagement.Mobile);
                cmd.AddParameter("Title", DbType.String, 1000, userManagement.Title);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, userManagement.LastModifiedTime);
            });
        }
    }
}