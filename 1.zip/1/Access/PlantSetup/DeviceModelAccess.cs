﻿// -----------------------------------------------------------------------
// <copyright file="DeviceModelAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Device Model Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for DeviceModelAccess
    /// </summary>
    public class DeviceModelAccess
    {
        /// <summary>
        ///     Get the device model details
        /// </summary>
        /// <param name="deviceTypeId">device type id.</param>
        /// <param name="ecolabAccountNumber">ecolab Account Number.</param>
        /// <returns> The list of device models </returns>
        public static List<DeviceModel> GetDeviceModelDetails(int deviceTypeId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<DeviceModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetDeviceModelDetails : Resources.Ecolab_GetDeviceModelDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("DeviceTypeId", deviceTypeId);
                cmd.AddParameterUnsafe("EcolabAccountNumber", ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// Insert or update DeviceModel Details 
        /// </summary>
        /// <param name="myserviceDeviceModelDetails">myServiceObject</param>
        /// <returns>New Generated id</returns>
        public static int SaveMyServiceDeviceModelDetails(DeviceModel myserviceDeviceModelDetails)
        {
            int returnValue = 0;

            var paramDeviceModelId = new SqlParameter
            {
                ParameterName = "OutputDeviceModelId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateMyServiceDeviceModelDetails : Resources.Ecolab_UpdateMyServiceDeviceModelDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                  cmd.AddParameter("DeviceModelId", myserviceDeviceModelDetails.DeviceModelId);
                  cmd.AddParameter("MyServiceDeviceTypeId", myserviceDeviceModelDetails.DeviceTypeId);
                  cmd.AddParameter("Description", DbType.String, 50, myserviceDeviceModelDetails.Description);
                  cmd.AddParameter("RegionCode", DbType.String, 50, myserviceDeviceModelDetails.RegionCode);
                  cmd.AddParameter("IsDeleted", myserviceDeviceModelDetails.IsDeleted);
                  cmd.AddParameter("MyServiceWtrEnrgDvcId", myserviceDeviceModelDetails.MyServiceWtrEnrgDvcId);
                  cmd.Parameters.Add(paramDeviceModelId);
              });

            returnValue = Convert.IsDBNull(paramDeviceModelId.Value) ? 0 : (int)paramDeviceModelId.Value;
            return returnValue;
        }
    }
}