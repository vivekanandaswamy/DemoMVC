﻿// -----------------------------------------------------------------------
// <copyright file="SensorTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The  Sensor Type Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for SensorTypeAccess
    /// </summary>
    public class SensorTypeAccess
    {
        /// <summary>
        ///     Get SensorType details
        /// </summary>
        /// <returns>The list of Sensor type</returns>
        public static List<SensorType> GetSensorTypeDetails()
        {
            return DbClient.ExecuteReader<SensorType>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetSensorTypeDetails : Resources.Ecolab_GetSensorTypeDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure; }).ToList();
        }
    }
}