﻿// -----------------------------------------------------------------------
// <copyright file="MachineSetupAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machine Setup Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for MachineSetupAccess
    /// </summary>
    public class MachineSetupAccess
    {
        /// <summary>
        ///     Get the machine details
        /// </summary>
        /// <param name="groupTypeId">The group Type Id.</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="sensorTypeId">Sensor Type Id</param>
        /// <returns> The list of machines </returns>
        public static List<MachineSetup> GetPlantMachineDetails(int? groupTypeId, string ecolabAccountNumber,int sensorTypeId=0)
        {
            return DbClient.ExecuteReader<MachineSetup>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantMeterMachines : Resources.Ecolab_GetPlantMeterMachines, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("GroupTypeID", groupTypeId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("SensorTypeId",sensorTypeId);
            }).ToList();
        }
    }
}