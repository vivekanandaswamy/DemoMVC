﻿// -----------------------------------------------------------------------
// <copyright file="ProductChemicalAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Chemical Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.Chemical
{
	using System.Collections.Generic;
	using System.Data;
	using System.Data.Common;
	using System.Linq;
	using Entities.PlantSetup.Chemical;
	using Nalco.Data.Common;
	using Properties;

	/// <summary>
	///     class for ProductMasterAccess
	/// </summary>
	public class ProductChemicalAccess
	{
		/// <summary>
		///     Get the Product Chemical list
		/// </summary>
		/// <param name="searchTerm">Search term to get matching chemicals</param>
		/// <param name="ecolabAccNumber">eco lab account number.</param>
		/// <returns>The list of Chemicals </returns>
		public static List<Chemicals> FetchChemicalList(string searchTerm, string ecolabAccNumber)
		{
			return DbClient.ExecuteReader<Chemicals>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetChemicalNames : Resources.Ecolab_GetChemicalNames, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
				cmd.AddParameter("ChemName", DbType.String, 1000, searchTerm);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
			}).ToList();
		}

		/// <summary>
		///     Get the Product Chemical list
		/// </summary>
		/// <param name="searchTerm">Search term to get matching chemicals</param>
		/// <param name="ecolabAccNumber">eco lab account number.</param>
		/// <param name="washerGroupId">WasherGroupId</param> 
		/// <returns>The list of Chemicals </returns>
		public static List<Chemicals> FetchUsedChemicalList(string searchTerm, string ecolabAccNumber, int? washerGroupId = null)
		{
			return DbClient.ExecuteReader<Chemicals>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetUsedChemicalName : Resources.Ecolab_GetUsedChemicalName, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
				cmd.AddParameter("ChemName", DbType.String, 1000, searchTerm);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
				if (washerGroupId != null)
				{
					cmd.AddParameter("WasherGroupId", washerGroupId);
				}
			}).ToList();
		}

		/// <summary>
		///     Get the chemical names
		/// </summary>
		/// <param name="ecolabAccNumber">Ecolab Account Number</param>
		/// <param name="washerGroupId">WasherGroupId</param>
		/// <returns>list of chemicals</returns>
		public static List<Chemicals> GetUnusedPlantChemicalList(string ecolabAccNumber, int washerGroupId)
		{
			return DbClient.ExecuteReader<Chemicals>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetUnusedPlantChemicalList : Resources.Ecolab_GetUnUsedPlantChemicalList, delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNumber);
                if (washerGroupId > 0)
                {
                    cmd.AddParameter("WasherGroupId", washerGroupId);
                }
                else
                {
                    cmd.AddParameter("WasherGroupId", 0);
                }

            }).ToList();
		}

		/// <summary>
		///     Check whether new product is used by any other washer group
		/// </summary>
		/// <param name="washerGroupId">The WasherGroupId</param>
		/// <param name="ecolabAccountNumber">The EcolabAccountNumber</param>
		/// <returns>List of washergroup ids if any</returns>
		public static List<int> CheckWasherGroupForProduct(int washerGroupId, string ecolabAccountNumber)
		{
			return DbClient.ExecuteReader<int>("TCD.CheckWasherGroupForProduct", delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				cmd.AddParameter("WasherGroupId", washerGroupId);
			}).ToList();
		}

		/// <summary>
		///     update the old chemical with new chemical
		/// </summary>
		/// <param name="objChemical">Chemical data to update</param>
		/// <returns>Responce Message</returns>
		public static int SaveSubstitueChemical(SubstituteChemical objChemical)
        {
			if (objChemical.WasherGroupIds == null)
			{
				objChemical.WasherGroupIds = new List<int>();
			}

			objChemical.WasherGroupIds.Add(objChemical.WasherGroupId);
			string WasherGroupIds= string.Join(",", objChemical.WasherGroupIds);
			return DbClient.ExecuteScalar<int>("TCD.SaveSubstituteChemical", delegate(DbCommand cmd, DbContext context)
			{
				cmd.CommandType = CommandType.StoredProcedure;
				
				cmd.AddParameter("OldProductId", objChemical.OldProductId);
				cmd.AddParameter("NewProductId", objChemical.NewProductId);
				cmd.AddParameter("ScalarOption", objChemical.ScalarOption);
				cmd.AddParameter("ScalarAmountPercent", objChemical.ScalarAmountPercent);
				cmd.AddParameter("WasherGroupId", DbType.String, 1000, WasherGroupIds);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, objChemical.EcolabAccountNumber);
			});
		}

		/// <summary>
		/// Get the washerdosing product list
		/// </summary>
		/// <param name="ecolabAccountNumber">The EcolabAccountNumber</param>
		/// <param name="washerGroupId">The WasherGroupId</param>
		/// <returns>List of products</returns>
		public static List<Chemicals> FetchWasherDosingProductList(string ecolabAccountNumber, int washerGroupId)
		{
			return DbClient.ExecuteReader<Chemicals>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_FetchWasherDosingProductList : Resources.Ecolab_FetchWasherDosingProductList, delegate(DbCommand cmd, DbContext context)
			{
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				if (washerGroupId > 0)
				{ cmd.AddParameter("WasherGroupId", washerGroupId); }
			}).ToList();
		}
	}
}