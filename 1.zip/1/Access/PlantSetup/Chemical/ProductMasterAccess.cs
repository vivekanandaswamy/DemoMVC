﻿// -----------------------------------------------------------------------
// <copyright file="ProductMasterAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Master Access </summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup.Chemical
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities.PlantSetup.Chemical;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class for ProductMasterAccess
    /// </summary>
    public class ProductMasterAccess
    {
        /// <summary>
        ///     Get the PlantChemical list
        /// </summary>
        /// <param name="ecolabAccNum"> Ecolab account number </param>
        /// <returns>The list of Product Maste</returns>
        public static List<ProductMaster> FetchPlantChemicalList(string ecolabAccNum)
        {
            return
                DbClient.ExecuteReader<ProductMaster>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantChemicalDetails : Resources.Ecolab_GetPlantChemicalDetails,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    }).ToList();
        }

        /// <summary>
        ///     Save Plant Chemical Details
        /// </summary>
        /// <param name="prodMaster">The product master.</param>
        /// <param name="userId">The plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>Returns Integer</returns>
        public static int SavePlantChemicalDetails(ProductMaster prodMaster, int userId,
            out DateTime lastModifiedTimestamp)
        {
            SqlParameter paramProductId = new SqlParameter
            {
                ParameterName = "OutputChemicalId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter
            {
                ParameterName = "OutputLastModifiedTimestampAtLocal",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SavePlantChemicalDetails : Resources.Ecolab_SavePlantChemicalDetails,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ProductId", prodMaster.ProductId);
                    cmd.AddParameter("Cost", prodMaster.Cost);
                    cmd.AddParameter("IncludeCI", prodMaster.IncludeinCI);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, prodMaster.EcolabAccountNumber);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("InventoryExpense", DbType.String, 1, prodMaster.InventoryExpense);
                    cmd.AddParameter("IsDeleted", prodMaster.IsDelete);
                    cmd.Parameters.Add(paramProductId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value)
                ? DateTime.UtcNow
                : (DateTime)paramLastModifiedTimeStamp.Value;
            return Convert.IsDBNull(paramProductId.Value) ? 0 : (int)paramProductId.Value;
        }

        /// <summary>
        ///     Update Plant Chemical Details
        /// </summary>
        /// <param name="prodMaster"> Product Master</param>
        /// <param name="userId">The plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>Returns Integer</returns>
        public static int UpdateChemicalDetails(ProductMaster prodMaster, int userId, out DateTime lastModifiedTimestamp)
        {
            SqlParameter paramProductId = new SqlParameter
            {
                ParameterName = "OutputChemicalId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter
            {
                ParameterName = "OutputLastModifiedTimestampAtLocal",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };
            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdatePlantChemical : Resources.Ecolab_UpdatePlantChemical, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("Id", prodMaster.Id);
                cmd.AddParameter("Cost", prodMaster.Cost);
                cmd.AddParameter("IncludeCI", prodMaster.IncludeinCI);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, prodMaster.EcolabAccountNumber);
                cmd.AddParameter("InventoryExpense", DbType.String, 1, prodMaster.InventoryExpense);
                cmd.AddParameter("UserID", userId);
                if (prodMaster.LastModifiedTimestampAtCentral.HasValue)
                {
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime,
                        prodMaster.LastModifiedTimestampAtCentral.Value);
                }
                cmd.Parameters.Add(paramProductId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value)
                ? DateTime.UtcNow
                : (DateTime)paramLastModifiedTimeStamp.Value;
            return Convert.IsDBNull(paramProductId.Value) ? 0 : (int)paramProductId.Value;
        }

        /// <summary>
        ///     Delete Plant Chemical Details
        /// </summary>
        /// <param name="prodMaster"> Product Master</param>
        /// <param name="userId">The plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>Returns Id</returns>
        public static int DeleteChemicalDetails(ProductMaster prodMaster, int userId, out DateTime lastModifiedTimestamp)
        {
            SqlParameter paramProductId = new SqlParameter
            {
                ParameterName = "OutputChemicalId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter
            {
                ParameterName = "OutputLastModifiedTimestampAtLocal",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };
            DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeletePlantChemical : Resources.Ecolab_DeletePlantChemical, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("Id", prodMaster.Id);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, prodMaster.EcolabAccountNumber);
                if (prodMaster.LastModifiedTimestampAtCentral.HasValue)
                {
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime,
                        prodMaster.LastModifiedTimestampAtCentral.Value);
                }
                cmd.AddParameter("UserID", userId);
                cmd.Parameters.Add(paramProductId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value)
                ? DateTime.UtcNow
                : (DateTime)paramLastModifiedTimeStamp.Value;

            return Convert.IsDBNull(paramProductId.Value) ? 0 : (int)paramProductId.Value;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("TableName", DbType.String, 1000, "TCD.ProductdataMapping");
                });
        }

        /// <summary>
        ///     validate formula for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateChemicalSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateChemicalSave : Resources.Ecolab_ValidateChemicalSave,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                        cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                    });
            }
            catch (Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Fetch ProductMaster details from sync
        /// </summary>
        /// <param name="lastSyncTime"></param>
        /// <returns></returns>
        public static List<ProductMaster> GetProductMasterDetailsfromCentral(DateTime lastSyncTime)
        {
            List<ProductMaster> productlist = new List<ProductMaster>();

            productlist = DbClient.ExecuteReader<ProductMaster>(Resources.Ecolab_Central_GetCentralProductMasterDetails,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("LastSyncTime", DbType.DateTime, lastSyncTime);
                }).ToList();
            return productlist;
        }

        /// <summary>
        ///     Save or update myservice product master details
        /// </summary>
        /// <param name="myserviceProductDetails">myserviceProductDetails</param>
        public static int SaveMyServiceProductMasterDetails(ProductMaster myserviceProductDetails)
        {
            SqlParameter paramProductId = new SqlParameter
            {
                ParameterName = "OutputProductId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateMyServiceProductMasterDetails : Resources.Ecolab_UpdateMyServiceProductMasterDetails,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("ProductId", myserviceProductDetails.ProductId);
                    cmd.AddParameter("SKU", DbType.String, 252, myserviceProductDetails.Sku);
                    cmd.AddParameter("Name", DbType.String, 255, myserviceProductDetails.Name);
                    cmd.AddParameter("Cost", myserviceProductDetails.Cost);
                    cmd.AddParameter("DensityFactor", myserviceProductDetails.DensityFactor);
                    cmd.AddParameter("AcceptedDeviation", myserviceProductDetails.AcceptedDeviation);
                    cmd.AddParameter("ProductCategoryId", myserviceProductDetails.ProductCategoryId);
                    cmd.AddParameter("Type", DbType.String, 100, myserviceProductDetails.Type);
                    cmd.AddParameter("Supplier", DbType.String, 100, myserviceProductDetails.Supplier);
                    cmd.AddParameter("IncludeinCI", myserviceProductDetails.IncludeinCI);
                    cmd.AddParameter("PackagingSize", DbType.String, 255, myserviceProductDetails.PackagingSize);
                    cmd.AddParameter("Weight", myserviceProductDetails.Weight);
                    cmd.AddParameter("Volume", myserviceProductDetails.Volume);
                    cmd.AddParameter("IsDelete", myserviceProductDetails.IsDelete);
                    cmd.AddParameter("ProductcategoryName", DbType.String, 1000,
                    myserviceProductDetails.ProductcategoryName);
                    cmd.AddParameter("RegionCode", DbType.String, 255, myserviceProductDetails.RegionCode);
                    cmd.AddParameter("Country", DbType.String, 100, myserviceProductDetails.Country);
                    cmd.AddParameter("MyServiceProdId", myserviceProductDetails.MyServiceProdId);
                    cmd.AddParameter("MyServicePackageSizeId", myserviceProductDetails.PackageSizeId);
                    cmd.AddParameter("EnvisionDisplayName", DbType.String, 1000, myserviceProductDetails.EnvisionDisplayName);
                    cmd.AddParameter("SourceSystemCode", DbType.String, 100, myserviceProductDetails.SourceSystemCode);
                    cmd.Parameters.Add(paramProductId);
                });

            return Convert.IsDBNull(paramProductId.Value) ? 0 : (int)paramProductId.Value;
        }

        /// <summary>
        ///     Save or update myservice product Category details
        /// </summary>
        /// <param name="myserviceProductCategoryDetails">myserviceProductCategoryDetails</param>
        public static int SaveMyServiceProductCategoryDetails(ProductMaster myserviceProductCategoryDetails)
        {
            try
            {
                var response = DbClient.ExecuteNonQuery(
              Resources.Ecolab_SaveProductCategoryDetails,
              delegate (DbCommand cmd, DbContext context)
              {
                  try
                  {
                      cmd.AddParameter("ProductCategoryId", myserviceProductCategoryDetails.ProductCategoryId);
                      cmd.AddParameter("Name", DbType.String, 1000, myserviceProductCategoryDetails.ProductcategoryName.Trim());
                      cmd.AddParameter<bool>("IsDelete", myserviceProductCategoryDetails.IsDelete);
                  }
                  catch (Exception)
                  {

                      throw;
                  }
              });
                return response;

            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        ///     Save or update myservice ProductCategory locale details
        /// </summary>
        /// <param name="myserviceProductCategoryDetails">myserviceProductCategoryDetails</param>
        public static void SaveMyServiceProductCategoryLocaleDetails(ProductMaster myserviceProductCategoryDetails)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252,
                        "FIELD_" +
                        myserviceProductCategoryDetails.ProductcategoryName.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myserviceProductCategoryDetails.ProductcategoryName);
                    cmd.AddParameter("Spanish", DbType.String, 252, myserviceProductCategoryDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myserviceProductCategoryDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myserviceProductCategoryDetails.nl_BE);
                });
        }

        /// <summary>
        ///     Save or update myservice ProductMaster locale details
        /// </summary>
        /// <param name="myserviceProductMasterDetails">myserviceProductMasterDetails</param>
        public static void SaveMyServiceProductMasterLocaleDetails(ProductMaster myserviceProductMasterDetails)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252,
                        "FIELD_" + myserviceProductMasterDetails.Name.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myserviceProductMasterDetails.Name);
                    cmd.AddParameter("Spanish", DbType.String, 252, myserviceProductMasterDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myserviceProductMasterDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myserviceProductMasterDetails.nl_BE);
                });
        }

        /// <summary>
        ///     Get the PlantChemical product id for Myservice
        /// </summary>
        /// <param name="myServiceProductId">myService ProductId </param>
        /// <returns>Product Id of a particular Product</returns>
        public static List<ProductMaster> FetchPlantChemicalProductId(int myServiceProductId)
        {
            return
                DbClient.ExecuteReader<ProductMaster>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantChemicalsProductId : Resources.Ecolab_GetPlantChemicalsProductId,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.AddParameter("MyServiceProdId", myServiceProductId);
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    }).ToList();
        }

        /// <summary>
        ///     Get Conduit Product CategoryId.
        /// </summary>
        /// <param name="myServiceProductCategoryId">myServiceProductCategoryId</param>
        /// <returns>ConduitProductCategoryId</returns>
        public static int? GetConduitProductCategoryId(int? myServiceProductCategoryId)
        {
            return DbClient.ExecuteScalar<int?>(
                "select CategoryId from TCD.ProductCategory where MyServiceProdCatId = " + myServiceProductCategoryId,
                delegate (DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.Text; });
        }

        /// <summary>
        /// Get the Plant Chemical List For ReSync
        /// </summary>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <returns>
        /// The list of Product Maste
        /// </returns>
        public static List<ProductMaster> FetchPlantChemicalListForReSync(string ecolabAccNum)
        {
            return
                DbClient.ExecuteReader<ProductMaster>(Resources.Ecolab_GetPlantChemicalResynch,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                    }).ToList();
        }
        /// <summary>
        /// Get the Plant Chemical List For ReSync
        /// </summary>
        /// <param name="ecolabAccNum">Ecolab account number</param>
        /// <returns>
        /// The list of Product Maste
        /// </returns>
        public static List<ProductStandardPrice> FetchPlantProductStandardPriceForReSync(string ecolabAccNum)
        {
            return
                DbClient.ExecuteReader<ProductStandardPrice>(Resources.Ecolab_GetPlantProductStandardPrice,
                    delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
                    }).ToList();
        }

        /// <summary>
        /// Save Plant Chemical Details
        /// </summary>
        /// <param name="productStandardPrice">The product standard price.</param>
        /// <param name="userId">The plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>
        /// Returns Integer
        /// </returns>
        public static int SavePlantProductStandardPrice(ProductStandardPrice productStandardPrice, int userId,
            out DateTime lastModifiedTimestamp)
        {
            SqlParameter paramProductId = new SqlParameter
            {
                ParameterName = "OutputStandardPriceId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter
            {
                ParameterName = "OutputLastModifiedTimestampAtLocal",
                SqlDbType = SqlDbType.DateTime,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SavePlantProductStandardPrice : Resources.Ecolab_SavePlantProductStandardPrice,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, productStandardPrice.EcolabAccountNumber);
                    cmd.AddParameter("ProductId", productStandardPrice.ProductId);
                    cmd.AddParameter("ListPrice", productStandardPrice.ListPrice);
                    cmd.AddParameter("ContractPrice", productStandardPrice.ContractPrice);
                    cmd.AddParameter("CountryPrice", productStandardPrice.CountryPrice);
                    cmd.AddParameter("UserID", userId);
                    cmd.Parameters.Add(paramProductId);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value)
                ? DateTime.UtcNow
                : (DateTime)paramLastModifiedTimeStamp.Value;
            return Convert.IsDBNull(paramProductId.Value) ? 0 : (int)paramProductId.Value;
        }

        /// <summary>
        /// Saves the product standard price for first time synchronize.
        /// </summary>
        /// <param name="productStandardPrice">The product standard price.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveProductStandardPriceForFirstTimeSync(ProductStandardPrice productStandardPrice, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveProductStandardPriceDetailsForFirstTimeSync,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("Id", productStandardPrice.Id);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, productStandardPrice.EcolabAccountNumber);
                    cmd.AddParameter("ProductId", productStandardPrice.ProductId);
                    cmd.AddParameter("ListPrice", productStandardPrice.ListPrice);
                    cmd.AddParameter("ContractPrice", productStandardPrice.ContractPrice);
                    cmd.AddParameter("CountryPrice", productStandardPrice.CountryPrice);
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameter("LastModifiedTime", DbType.DateTime, productStandardPrice.LastModifiedTimestamp);
                });
        }

        /// <summary>
        /// Saves the plant chemical details for first time synchronize.
        /// </summary>
        /// <param name="prodMaster">The product master.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SavePlantChemicalDetailsForFirstTimeSync(ProductMaster prodMaster, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantChemicalDetailsForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("Id", prodMaster.Id);
                cmd.AddParameter("ProductId", prodMaster.ProductId);
                cmd.AddParameter("Cost", prodMaster.Cost);
                cmd.AddParameter("Sku", DbType.String, 100, prodMaster.Sku);
                cmd.AddParameter("IncludeCI", prodMaster.IncludeinCI);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, prodMaster.EcolabAccountNumber);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("InventoryExpense", DbType.String, 1, prodMaster.InventoryExpense);
                cmd.AddParameter("IsDeleted", prodMaster.IsDelete);
                cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, prodMaster.LastModifiedTimestamp);
            });
        }
    }
}