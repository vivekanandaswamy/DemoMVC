﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityWaterTypeAccess.cs" company="Ecolab">
// This class is for getting the utility water type values from database.
// </copyright>
// <summary>The Plant Utility water Type Access for getting data.</summary>
// -----------------------------------------------------------------------

namespace Access.PlantSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using Entities.PlantSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Class is for getting the free water types from database.
    /// </summary>
    public class PlantUtilityWaterTypeAccess
    {
        /// <summary>
        /// Gets Water Type details
        /// </summary>
        /// <param name="regionId">The region identifier.</param>
        /// <returns>
        /// Different free water types.
        /// </returns>
        public static List<PlantUtilityWaterTypeMaster> GetWaterTypeDetails(int regionId)
        {
            return DbClient.ExecuteReader<PlantUtilityWaterTypeMaster>(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantUtilityWaterTypes : Resources.Ecolab_GetPlantUtilityWaterTypes,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("RegionId", regionId);
                }).ToList();
        }

        /// <summary>
        /// Insert or update WaterType Details
        /// </summary>
        /// <param name="myserviceWaterTypeDetails">The myservice water type details.</param>
        /// <returns>
        /// New Generated id
        /// </returns>
        public static int SaveMyServiceWaterTypeDetails(PlantUtilityWaterTypeMaster myserviceWaterTypeDetails)
        {
            int returnValue = 0;

            var paramDeviceModelId = new SqlParameter
            {
                ParameterName = "OutputWaterTypeId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdateMyServiceWaterTypeDetails : Resources.Ecolab_UpdateMyServiceWaterTypeDetails,
              delegate (DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                  cmd.AddParameter("Id", myserviceWaterTypeDetails.WaterTypeId);
                  cmd.AddParameter("Name", DbType.String, 252, myserviceWaterTypeDetails.WaterTypeName);
                  cmd.AddParameter("RegionCode", DbType.String, 252, myserviceWaterTypeDetails.RegionCode);
                  cmd.AddParameter("IsDeleted", myserviceWaterTypeDetails.IsDeleted);
                  cmd.AddParameter("MyServiceUtilId", myserviceWaterTypeDetails.MyServiceUtilId);
                  cmd.AddParameter("MyServiceUtilTypeCode", DbType.String, 252, myserviceWaterTypeDetails.MyServiceUtilTypeCode);
                  cmd.Parameters.Add(paramDeviceModelId);
              });

            returnValue = Convert.IsDBNull(paramDeviceModelId.Value) ? 0 : (int)paramDeviceModelId.Value;
            return returnValue;
        }

        /// <summary>
        ///     Save or update myservice water type locale details
        /// </summary>
        /// <param name="myserviceWaterTypeDetails">myserviceWaterTypeDetails</param>
        public static void SaveMyServiceWaterTypeLocaleDetails(PlantUtilityWaterTypeMaster myserviceWaterTypeDetails)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252, "FIELD_" + myserviceWaterTypeDetails.WaterTypeName.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myserviceWaterTypeDetails.WaterTypeName);
                    cmd.AddParameter("Spanish", DbType.String, 252, myserviceWaterTypeDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myserviceWaterTypeDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myserviceWaterTypeDetails.nl_BE);
                });
        }
    }
}