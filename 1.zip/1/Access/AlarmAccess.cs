﻿// -----------------------------------------------------------------------
// <copyright file="AlarmAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm Access class</summary>
// -----------------------------------------------------------------------

namespace Access
{
	using System;
	using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class fore AlarmAccess
    /// </summary>
    public class AlarmAccess
    {
        /// <summary>
        ///     Gets alarm details
        /// </summary>
        /// <param name="ecoalabAccountNumber">plant number</param>
        /// <returns>IEnumerable List of Alarms</returns>
        public static IEnumerable<Alarm> FetchAlarmDetails(string ecoalabAccountNumber)
        {
            return DbClient.ExecuteReader<Alarm>(Resources.Ecolab_GetAlarmdetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecoalabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// Fetch alarm data for syncing
        /// </summary>
        /// <param name="recordCount">Number of records</param>
        /// <returns>Alarm list</returns>
        public static List<Alarm> FetchAlarmDetailsForSync(int recordCount)
        {
            return DbClient.ExecuteReader<Alarm>(Resources.Ecolab_GetAlarmDataSync, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("RecordCount", recordCount);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        public static int GetAlarmCount()
        {
            return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetAlarmDataCount, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
            });
        }

        /// <summary>
        ///     Save Central alarm details in local plants
        /// </summary>
        /// <param name="alarmMaster">Alarm Master object</param>
        /// <returns>status</returns>
        public static int SaveAlarmMasterDetails(AlarmMaster alarmMaster)
        {
			try
			{
				int returnStatus =
					DbClient.ExecuteScalar<int>(
					  Resources.Ecolab_UpdateAlarmsData,
					  delegate(DbCommand cmd, DbContext context)
					  {

						  cmd.AddParameter("AlarmCode", alarmMaster.AlarmCode);
						  cmd.AddParameter("Description", DbType.String, 255, alarmMaster.Description);
						  cmd.AddParameter("ControllerModelTypeId", alarmMaster.ControllerModelTypeId);
                          cmd.AddParameter("ControllerModelId", alarmMaster.ControllerModelId);
                          cmd.AddParameter("ControllerTypeId", alarmMaster.ControllerTypeId);
						  cmd.AddParameter("ResourceKey", DbType.String, 255, alarmMaster.ResourceKey);
						  cmd.AddParameter("IsDefault", alarmMaster.IsDefault);
						  cmd.AddParameter("IsDelete", alarmMaster.IsDeleted);
						  cmd.AddParameter("Id", alarmMaster.Id);
						  cmd.AddParameter("AlarmMachineMappingId", alarmMaster.AlarmMaachineMappingId);
						  cmd.AddParameter("WasherType", DbType.String, 255, alarmMaster.WasherType);
						  cmd.AddParameter("IsDeleteAlarmMapping", alarmMaster.IsDeleteAlarmMapping);
						  cmd.AddParameter("MachineNumberMappingId", alarmMaster.MachineNumberMappingId);
						  cmd.AddParameter("MachineNumber", alarmMaster.MachineNumber);
						  cmd.AddParameter("IsHoldCondition", alarmMaster.IsHoldCondition);
						  cmd.AddParameter("AlarmNumber", alarmMaster.AlarmNumber);
					  });
				return returnStatus;
			}
			catch (Exception)
			{				
				throw;
			}
            
        }

        public static int GetAlarmGroupMsterVsControllerModelTypeIdByControllerIdAndSCNumber(int alarmCode, int controllerModelTypeId, string washerType)
        {

            return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetAlarmGroupMsterVsControllerModelTypeIdByControllerIdAndSCNumber, 
                delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("@AlarmCode", alarmCode);
                cmd.AddParameter("@ControllerModelTypeId", controllerModelTypeId);
                cmd.AddParameter("@WasherType", DbType.String, 255, washerType);
                cmd.CommandType = CommandType.Text;
            });
        }

        public static int GetAlarmGroupMsterVsControllerModelTypeIdByControllerIdAndSCNumberForBatchEjectConditions(int alarmCode, int controllerModelTypeId)
        {

            return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetAlarmGroupMsterVsControllerModelTypeIdByControllerIdAndSCNumberForBatchEjectConditions,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("@AlarmCode", alarmCode);
                    cmd.AddParameter("@ControllerModelTypeId", controllerModelTypeId);
                    cmd.CommandType = CommandType.Text;
                });
        }
    }
}