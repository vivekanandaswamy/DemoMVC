﻿// -----------------------------------------------------------------------
// <copyright file="LanguageMasterAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LanguageMasterAccess object</summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class LanguageMasterAccess
    /// </summary>
    public class LanguageMasterAccess
    {
        /// <summary>
        ///     Get language details
        /// </summary>
        /// <returns>The list of Languages</returns>
        public static List<LanguageMaster> GetLanguageDetails()
        {
            return DbClient.ExecuteReader<LanguageMaster>(Resources.Ecolab_GetLanguageDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }

        /// <summary>
        /// saving language master data from central to local
        /// </summary>
        /// <param name="languageMaster"></param>
        /// <returns></returns>
        public static int SaveLanguageMasterDetails(LanguageMaster languageMaster)
        {
            try
            {
                int returnStatus =
                    DbClient.ExecuteScalar<int>(
                      Resources.Ecolab_UpdateLanguageMasterData,
                      delegate(DbCommand cmd, DbContext context)
                      {
                          cmd.AddParameter("LanguageId", languageMaster.LanguageId);
                          cmd.AddParameter("Name", DbType.String, 255, languageMaster.Name);
                          cmd.AddParameter("Locale", DbType.String, 255, languageMaster.Locale);
                          cmd.AddParameter("IsActive", languageMaster.IsActive);
                          cmd.AddParameterUnsafe("LastModifiedTime", languageMaster.LastModifiedTime);
                      });
                return returnStatus;
            }
            catch (Exception)
            {
                throw;
            }
            
        }
    }
}