﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityUnitTypesAccess.cs" company="Ecolab">
// Constructor and entities of the plantutility class.
// </copyright>
// <summary>The Utility class for entities.</summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Class for PlantUtilityUnitTypesAccess for getting  the unit types.
    /// </summary>
    public class PlantUtilityUnitTypesAccess
    {
        /// <summary>
        ///     Get the Plant utility unit list for energy content.
        /// </summary>
        /// <returns>Row of Plant utility unit list for energy content.</returns>
        public static List<PlantUtilityUnitTypes> GetPlantUtilityEnergyContentUnits(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<PlantUtilityUnitTypes>(Resources.Ecolab_GetPlantUtilityUnitTypeList, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("UsageKey", DbType.String, 1000, "Energy_Content_");
            }).ToList();
        }

        /// <summary>
        ///     Get the Plant utility unit list for energy prices.
        /// </summary>
        /// <returns>Row of Plant utility unit list for energy prices.</returns>
        public static List<PlantUtilityUnitTypes> GetPlantUtilityEnergyPriceUnits(string ecolabAccountNumber, int regionId)
        {
            return DbClient.ExecuteReader<PlantUtilityUnitTypes>(Resources.Ecolab_GetPlantUtilityUnitTypeList, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				if (regionId == 1)
				{
					cmd.AddParameter("UsageKey", DbType.String, 1000, "TCD_GasOil_Price");
				}
				else
				{
					cmd.AddParameter("UsageKey", DbType.String, 1000, "TCD_GasOil_Price_EMEA");
				}
			}).ToList();
        }

        /// <summary>
        ///     Get the Formula Units
        /// </summary>
        /// <returns>Row of Plant utility unit list </returns>
        public static List<PlantUtilityUnitTypes> GetFormulaUnits(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<PlantUtilityUnitTypes>(Resources.Ecolab_GetPlantUtilityUnitTypeList, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("UsageKey", DbType.String, 1000, "WEIGHT");
            }).ToList();
        }
    }
}