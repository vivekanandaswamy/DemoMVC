﻿// -----------------------------------------------------------------------
// <copyright file="ConduitControllerAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved. 
// </copyright>
// <summary>The ConduitControllerAccess object</summary>
// -----------------------------------------------------------------------

namespace Access.Common
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities.Common;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Conduit controller Access class
    /// </summary>
    public class ConduitControllerAccess
    {
        /// <summary>
        ///     Get the controller details
        /// </summary>
        /// <param name="locationId">The Location Id</param>
        /// <param name="machineId">The Machine Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns> returns the controllers </returns>
        public static List<ConduitController> GetPlantMeterControllerDetails(int? locationId, int? machineId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ConduitController>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantMeterControllDetails : Resources.Ecolab_GetPlantMeterControllDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("LocationId", locationId);
                cmd.AddParameter("MachineId", machineId);
            }).ToList();
        }

        public static List<ConduitController> GetPlantMeterControllerDetailsOnMachineChange(int? locationId, int? machineId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ConduitController>( Resources.Ecolab_GetPlantMeterControllerDetailsOnMachineChange, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("LocationId", locationId);
                cmd.AddParameter("MachineId", machineId);
            }).ToList();
        }

        public static List<ControllerInfoForPlc> GetControllerInfoById(int controllerId, string ecolabAccountNumber = "")
        {
            return DbClient.ExecuteReader<ControllerInfoForPlc>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetControllerInfoById : Resources.Ecolab_GetControllerInfoById, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
                if (!string.IsNullOrEmpty(ecolabAccountNumber))
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }
            }).ToList();
        }

        /// <summary>
        ///     Duplicate tag for washers and controller.
        /// </summary>
        /// <param name="washerId">Gets the value of washerId.</param>
        /// <param name="controllerId">Gets the value of ControllerId.</param>
        /// <param name="tagAddress">Gets the value of tag value.</param>
        /// <param name="type">Gets the value of type</param>
        /// <param name="ecolabAccountNumber"> Ecolab Account Number.</param>
        /// <returns>the status of execution of query.</returns>
        public static bool ValidateWashersTags(int washerId, int controllerId, string tagAddress, int type, string ecolabAccountNumber = "")
        {
            SqlParameter param = new SqlParameter { ParameterName = "return", SqlDbType = SqlDbType.Bit, Direction = ParameterDirection.ReturnValue };

            DbClient.ExecuteScalar<bool>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateWasherTags : Resources.Ecolab_ValidateWasherTags, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("TagAddress", DbType.String, 50, tagAddress);
                cmd.AddParameter("ControllerId", controllerId);
                if (washerId > 0)
                {
                    cmd.AddParameter("Id", washerId);
                    cmd.AddParameter("Type", type);
                }
                if (!string.IsNullOrEmpty(ecolabAccountNumber))
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }
                cmd.Parameters.Add(param);
            });
            return param.Value != null && Convert.ToBoolean(param.Value);
        }
    }
}