﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactPositionAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Plant Contact Position Access </summary>
// -----------------------------------------------------------------------

namespace Access.Common
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using Entities.Common;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for PlantContactPositionAccess
    /// </summary>
    public class PlantContactPositionAccess
    {
        /// <summary>
        ///     Get the PlantContactPosition details
        /// </summary>
        /// <returns> The list of plant contact position </returns>
        public static IEnumerable<PlantContactPosition> FetchPlantContactPosition()
        {
            return DbClient.ExecuteReader<PlantContactPosition>(Resources.Ecolab_GetPlantContactPosition, delegate (DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; });
        }

        public static int SaveMyServicePlantContactPositionDetails(PlantContactPosition plantContactPosition)
        {
            int returnValue = 0;

            var param = new SqlParameter
            {
                ParameterName = "OutputPlantContactId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
                 Resources.Ecolab_UpdateMyServicePlantContactPosition,
                 delegate (DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.StoredProcedure;
                     cmd.AddParameter("PositionId", plantContactPosition.Id);
                     cmd.AddParameter("Position_Name", DbType.String, 1000, plantContactPosition.PositionName);
                     cmd.AddParameter("Is_Deleted", plantContactPosition.IsDeleted);
                     cmd.AddParameter("MyServiceCntctPosnId", plantContactPosition.MyServiceCntctPosnId);
                     cmd.Parameters.Add(param);
                 });

            returnValue = Convert.IsDBNull(param.Value) ? 0 : (int)param.Value;

            return returnValue;
        }

        /// <summary>
        ///     Save or update myservice PlantContactPosition locale details
        /// </summary>
        /// <param name="myservicePlantContactPositionDetails">myservicePlantContactPositionDetails</param>
        public static void SaveMyServicePlantContactPositionLocaleDetails(PlantContactPosition myservicePlantContactPositionDetails)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252, "FIELD_" + myservicePlantContactPositionDetails.PositionName.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myservicePlantContactPositionDetails.PositionName);
                    cmd.AddParameter("Spanish", DbType.String, 252, myservicePlantContactPositionDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myservicePlantContactPositionDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myservicePlantContactPositionDetails.nl_BE);
                });
        }
    }
}