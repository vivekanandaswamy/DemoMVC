﻿// -----------------------------------------------------------------------
// <copyright file="ResourceMasterAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Resource Master Access</summary>
// -----------------------------------------------------------------------

namespace Access.Common
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.Common;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for ResourceMaster
    /// </summary>
    public class ResourceMasterAccess
    {
        /// <summary>
        ///     Get utility type details
        /// </summary>
        /// <returns>different utilities</returns>
        public static List<ResourceMaster> GetUtilitySetupDetails()
        {
            return DbClient.ExecuteReader<ResourceMaster>(Resources.Ecolab_GetUtilitySetupDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}