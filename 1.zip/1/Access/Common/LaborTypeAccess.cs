﻿// -----------------------------------------------------------------------
// <copyright file="LaborTypeAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Labor Type Access </summary>
// -----------------------------------------------------------------------

namespace Access.Common
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.Common;
    using Nalco.Data.Common;
    using Properties;

    public class LaborTypeAccess
    {
        /// <summary>
        ///     Get the LabourType details
        /// </summary>
        /// <returns> The list of labor types </returns>
        public static List<LaborType> FetchLabourType()
        {
            return DbClient.ExecuteReader<LaborType>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetLabourTypes : Resources.Ecolab_GetLabourTypes, delegate (DbCommand cmd, DbContext context) { cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure; }).ToList();
        }
    }
}