﻿// -----------------------------------------------------------------------
// <copyright file="DeviceTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Device Type Access </summary>
// -----------------------------------------------------------------------

namespace Access.Common
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.Common;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for DeviceTypeAccess
    /// </summary>
    public class DeviceTypeAccess
    {
        /// <summary>
        ///     Get the device type details
        /// </summary>
        /// <returns> The list of device types </returns>
        public static List<DeviceType> GetDeviceTypeDetails()
        {
            return DbClient.ExecuteReader<DeviceType>(Resources.Ecolab_GetDeviceTypeDetails, delegate(DbCommand cmd, DbContext context) { cmd.CommandType = CommandType.StoredProcedure; }).ToList();
        }
    }
}