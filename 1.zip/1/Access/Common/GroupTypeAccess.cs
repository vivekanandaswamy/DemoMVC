﻿// -----------------------------------------------------------------------
// <copyright file="GroupTypeAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The GroupTypeAccess object</summary>
// -----------------------------------------------------------------------

namespace Access.Common
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.Common;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for GroupTypeAccess
    /// </summary>
    public class GroupTypeAccess
    {
        /// <summary>
        /// Get the utility location details
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// The list of utility locations
        /// </returns>
        public static List<GroupType> GetGroupTypeDetails(string ecolabAccountNumber = "")
        {
            return DbClient.ExecuteReader<GroupType>(Resources.Ecolab_GetGroupTypeDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if(!string.IsNullOrEmpty(ecolabAccountNumber))
                {
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }
            }).ToList();
        }
    }
}