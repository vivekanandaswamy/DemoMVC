﻿// -----------------------------------------------------------------------
// <copyright file="ConfigHelperAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>Config Helper Access </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Access.Properties;
using Nalco.Data.Common;

namespace Access
{
    public class ConfigHelperAccess
    {
        /// <summary>
        ///     executes the common queries
        /// </summary>
        /// <param name="value">value</param>
        public static void ExecuteQuery(string value)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_ConfigHelper, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("Query",DbType.String,5000, value);
            });
        }
    }
}
