﻿// -----------------------------------------------------------------------
// <copyright file="ResourceKeyValuesAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Resource Key Values Access class</summary>
// -----------------------------------------------------------------------

namespace Access
{
	using System;
	using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class fore ResourceKeyValuesAccess
    /// </summary>
    public class ResourceKeyValuesAccess
    {

        /// <summary>
        /// Save Central ResourceKeys details in local plants
        /// </summary>
        /// <param name="resourceKey">The resource key.</param>
        /// <returns>
        /// status
        /// </returns>
        public static int SaveResourceKeysDetails(ResourceKeyValue resourceKey)
        {
			try
			{
				int returnStatus =
					DbClient.ExecuteScalar<int>(
					  Resources.Ecolab_UpdateResourceKey,
					  delegate(DbCommand cmd, DbContext context)
					  {
                          cmd.AddParameter("ResourceId", resourceKey.ResourceId);
                          cmd.AddParameter("Key", DbType.String, 255, resourceKey.Key);
					  });
				return returnStatus;
			}
			catch (Exception)
			{
				throw;
			}
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="resourceValues"></param>
        /// <returns></returns>
        public static int SaveResourceValuesDetails(ResourceValues resourceValues)
        {
            try
            {
                int returnStatus =
                    DbClient.ExecuteScalar<int>(
                      Resources.Ecolab_UpdateResourceValues,
                      delegate(DbCommand cmd, DbContext context)
                      {
                          cmd.AddParameter("ResourceId", resourceValues.ResourceId);
                          cmd.AddParameter("ResourceValue", DbType.String, 255, resourceValues.ResourceValue);
                          cmd.AddParameter("Locale", DbType.String, 255, resourceValues.Locale);
                          cmd.AddParameter("LanguageId", resourceValues.LanguageId);
                          cmd.AddParameterUnsafe("LastModifiedTime", resourceValues.LastModifiedTime);
                          cmd.AddParameter("Id", resourceValues.Id);
                      });
                return returnStatus;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static int SaveResourcePageMappingDetails(ResourceKeyPageMapping resourcePageMapping)
        {
            try
            {
                int returnStatus =
                    DbClient.ExecuteScalar<int>(
                      Resources.Ecolab_UpdateResourcePageMapping,
                      delegate(DbCommand cmd, DbContext context)
                      {
                          cmd.AddParameter("Id", resourcePageMapping.Id);
                          cmd.AddParameter("ResourceId", resourcePageMapping.ResourceId);
                          cmd.AddParameter("PageId", resourcePageMapping.PageId);
                      });
                return returnStatus;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}