﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Navigation Menu Access class</summary>
// -----------------------------------------------------------------------

namespace Access.NavigationMenu
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using Entities.ControllerSetup;
    using Entities.NavigationMenu;
    using Entities.Visualization.Monitor;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Access class for NavigationMenuAccess
    /// </summary>
    public class NavigationMenuAccess
    {
        /// <summary>
        /// Gets Controller for navigation menu
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// IEnumerable List of controllers for navigation menu
        /// </returns>
        public static IEnumerable<ControllerType> FetchControllerForNavigationMenu(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ControllerType>(Resources.Ecolab_GetControllersForNavigationMenu, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// Gets equipments for navigation menu
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// List of Equipments for navigation menu
        /// </returns>
        public static IEnumerable<Equipment> FetchEquipmentsForNavigationMenu(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Equipment>(Resources.Ecolab_GetEquipmentsForNavigationMenu, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// Gets storage tanks for navigation menu
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// IEnumerable List of storage tanks for navigation menu
        /// </returns>
        public static IEnumerable<StorageTank> FetchStorageTanksForNavigationMenu(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<StorageTank>(Resources.Ecolab_GetStorageTankersForNavigationMenu, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// Gets formulas for navigation menu
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// IEnumerable List of formulas for navigation menu
        /// </returns>
        public static IEnumerable<Formula> FetchFormulasForNavigationMenu(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Formula>(Resources.Ecolab_GetFormulasForNavigationMenu, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// Gets washers for navigation menu
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// IEnumerable List of washers for navigation menu
        /// </returns>
        public static IEnumerable<Washer> FetchWashersForNavigationMenu(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Washer>(Resources.Ecolab_GetWashersForNavigationMenu, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// Gets washer groups for navigation menu
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>
        /// IEnumerable List of washerGroups for navigation menu
        /// </returns>
        public static IEnumerable<WasherGroupType> FetchWasherGroupsForNavigationMenu(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<WasherGroupType>(Resources.Ecolab_GetWasherGroupsForNavigationMenu, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        /// Gets washer groups for navigation menu
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="roles">The roles.</param>
        /// <returns>
        /// IEnumerable List of Navigation for navigation menu
        /// </returns>
        public static IEnumerable<NavigationMenu> FetchNavigationMenuDetails(string ecolabAccountNumber,string roles)
        {
            return DbClient.ExecuteReader<NavigationMenu>(Resources.Ecolab_GetNavigationMenuDetails, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("PassingRoleCode", DbType.String, 250, roles);
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }
    }
}