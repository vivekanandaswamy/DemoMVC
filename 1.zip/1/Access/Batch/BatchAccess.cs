﻿// -----------------------------------------------------------------------
// <copyright file="BatchAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Batch Access class</summary>
// -----------------------------------------------------------------------

namespace Access.Batch
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using Entities.Batch;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     Batch Access
    /// </summary>
    public class BatchAccess
    {
        /// <summary>
        ///     Gets the Batch Collection Details
        /// </summary>
        /// <returns>the Batch Collection Details</returns>
        public static List<BatchData> GetBatchCollectionDetails(int recordCount)
        {
          return DbClient.ExecuteReader<BatchData>(Resources.Ecolab_GetBatchData, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("RecordCount", recordCount);
                    cmd.CommandType = CommandType.Text;
                }).ToList();
            
         }

        /// <summary>
        ///     GetBatchCustomerData
        /// </summary>
        /// <param name="batchId">fetching data through batch id</param>
        /// <returns>returns a list.</returns>
        public static List<BatchCustomerData> GetBatchCustomerData(int batchId)
        {
            return DbClient.ExecuteReader<BatchCustomerData>(Resources.Ecolab_GetBatchCustomerData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("BatchID", batchId);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        ///     GetBatchProductData
        /// </summary>
        /// <param name="batchId">fetching data through batch id</param>
        /// <returns>returns a list.</returns>
        public static List<BatchProductData> GetBatchProductData(int batchId)
        {
            return DbClient.ExecuteReader<BatchProductData>(Resources.Ecolab_GetBatchProductData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("BatchID", batchId);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        ///     GetBatchWashStepData
        /// </summary>
        /// <param name="batchId">fetching data through batch id</param>
        /// <returns>returns a list.</returns>
        public static List<BatchWashStepData> GetBatchWashStepData(int batchId)
        {
            return DbClient.ExecuteReader<BatchWashStepData>(Resources.Ecolab_GetBatchWashStepData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("BatchID", batchId);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        ///     GetBatchStepWaterUsageData
        /// </summary>
        /// <param name="batchId">fetching data through batch id</param>
        /// <returns>returns a list.</returns>
        public static List<BatchStepWaterUsageData> GetBatchStepWaterUsageData(int batchId)
        {
            return DbClient.ExecuteReader<BatchStepWaterUsageData>(Resources.Ecolab_GetBatchStepWaterUsageData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("BatchID", batchId);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        ///     GetBatchStepEnergyUsageData
        /// </summary>
        /// <param name="batchId">fetching data through batch id</param>
        /// <returns>returns a list.</returns>
        public static List<BatchStepEnergyUsageData> GetBatchStepEnergyUsageData(int batchId)
        {
            return DbClient.ExecuteReader<BatchStepEnergyUsageData>(Resources.Ecolab_GetBatchStepEnergyUsageData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("BatchID", batchId);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        ///     GetBatchParameterData
        /// </summary>
        /// <param name="batchId">fetching data through batch id</param>
        /// <returns>returns a list.</returns>
        public static List<BatchParameterData> GetBatchParameterData(int batchId)
        {
            return DbClient.ExecuteReader<BatchParameterData>(Resources.Ecolab_GetBatchParameterData, delegate(DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("BatchID", batchId);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        ///  Gets count of the Batch for the shift to process
        /// </summary>
        /// <returns></returns>
        public static int GetBatchCount()
        {
            return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetBatchDataCount, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
            });
        }

        /// <summary>
        /// Calculating Priority One count which is first 3 months migrated data.
        /// </summary>
        /// <returns></returns>
        public static int GetThreeMonthsBatchCount()
        {
            return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetThreeMonthsBatchCount, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandTimeout = 0;
                cmd.CommandType = CommandType.Text;
            });
        }

        /// <summary>
        /// Calculating Priority One count of Live Data.
        /// </summary>
        /// <returns></returns>
        public static int GetLiveBatchDataCount()
        {
            return DbClient.ExecuteScalar<int>(Resources.Ecolab_GetLiveBatchDataCount, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
            });
        }

        /// <summary>
        ///     Gets the Batch Collection Details
        /// </summary>
        /// <returns>the Batch Collection Details</returns>
        public static List<BatchData> GetBatchCollectionThreeMonths(int recordCount)
        {
                return DbClient.ExecuteReader<BatchData>(Resources.Ecolab_GetBatchDataThreeMonths, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.AddParameter("RecordCount", recordCount);
                    cmd.CommandType = CommandType.Text;
                }).ToList();
        }

        /// <summary>
        ///     Gets the Batch Collection Details
        /// </summary>
        /// <returns>the Batch Collection Details</returns>
        public static List<BatchData> GetLiveBatchCollectionData(int recordCount)
        {
            return DbClient.ExecuteReader<BatchData>(Resources.Ecolab_GetLiveBatchData, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("RecordCount", recordCount);
                cmd.CommandType = CommandType.Text;
            }).ToList();
        }

        /// <summary>
        /// Updates the batch end date for na batches.
        /// </summary>
        public static void UpdateBatchEndDateForNABatches()
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateBatchEndDateForNABatches, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
            });
        }
    }
}