﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceWashFloorDataAccess.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Wash floor Access  class </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Access.Properties;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// MyServiceWashFloorDataAccess class
    /// </summary>
    public class MyServiceWashFloorDataAccess
    {
        /// <summary>
        /// Get myservice ID's
        /// </summary>
        /// <param name="washerId">EcolabWasherid</param>
        /// <param name="programNum">Formula number</param>
        /// <param name="ecolabAccNum">Account number</param>
        /// <returns>MyServiceWashFloor</returns>
        public static MyServiceWashFloor GetMyServiceDetails(int washerId, int programNum, string ecolabAccNum)
        {
            return DbClient.ExecuteReader<MyServiceWashFloor>(Resources.Ecolab_GetMyserviceGuids, delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("EcolabWasherId", washerId);
                cmd.AddParameter("ProgramNumber", programNum);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccNum);
            }).FirstOrDefault();
        }
    }
}
