﻿// -----------------------------------------------------------------------
// <copyright file="PlantSaturationAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Saturation Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class Plant Saturation Access
    /// </summary>
    public class PlantSaturationAccess
    {
        /// <summary>
        ///     Get Plant Saturation
        /// </summary>
        /// <returns>List of plant saturation</returns>
        public static List<EcolabSaturation> GetPlantSaturation(int textileId)
        {
            return DbClient.ExecuteReader<EcolabSaturation>(Resources.Ecolab_GetEcolabSaturation,
                delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("TextileId", textileId);
                }).ToList();
        }

        /// <summary>
        /// Insert or update EcolabSaturation Details 
        /// </summary>
        /// <param name="myserviceEcolabSaturationDetails">myServiceObject</param>
        /// <returns>New Generated id</returns>
        public static int SaveMyServiceEcolabSaturationDetails(EcolabSaturation myserviceEcolabSaturationDetails)
        {
            int returnValue = 0;

            var paramSaturationId = new SqlParameter
            {
                ParameterName = "OutputSaturationId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
              Resources.Ecolab_UpdateMyServiceEcolabSaturationDetails,
              delegate(DbCommand cmd, DbContext context)
              {
                  cmd.CommandType = CommandType.StoredProcedure;
                  cmd.AddParameter("SaturationId", myserviceEcolabSaturationDetails.EcolabSaturationId);
                  cmd.AddParameter("SaturationName", DbType.String, 50, myserviceEcolabSaturationDetails.EcolabSaturationName);
                  cmd.AddParameter("AbsorbancyFactor", myserviceEcolabSaturationDetails.AbsorbancyFactor);
                  cmd.AddParameter("SpeedAbsorbancyFactor", myserviceEcolabSaturationDetails.SpeedAbsorbancyFactor);
                  cmd.AddParameter("LowAbsorbancyFactor", myserviceEcolabSaturationDetails.LowAbsorbancyFactor);
                  cmd.AddParameter("IntermediateAbsorbancyFactor", myserviceEcolabSaturationDetails.IntermediateAborbancyFactor);
                  cmd.AddParameter("HighAbsorbancyFactor", myserviceEcolabSaturationDetails.HighAbsorbancyFactor);
                  cmd.AddParameter("IsDeleted", myserviceEcolabSaturationDetails.IsDeleted);
                  cmd.AddParameter("MyServiceMstrLnnTypId", myserviceEcolabSaturationDetails.MyServiceMstrLnnTypId);
                  cmd.Parameters.Add(paramSaturationId);
              });

            returnValue = Convert.IsDBNull(paramSaturationId.Value) ? 0 : (int)paramSaturationId.Value;
            return returnValue;
        }

        /// <summary>
        ///     Save or update myservice EcolabSaturation locale details
        /// </summary>
        /// <param name="myserviceEcolabSaturationDetails">myserviceEcolabSaturationDetails</param>
        public static void SaveMyServiceEcolabSaturationLocaleDetails(EcolabSaturation myserviceEcolabSaturationDetails)
        {
            DbClient.ExecuteNonQuery(
				Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
				delegate (DbCommand cmd, DbContext context)
                {
					cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
					cmd.AddParameter("Key", DbType.String, 252, "FIELD_" + myserviceEcolabSaturationDetails.EcolabSaturationName.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myserviceEcolabSaturationDetails.EcolabSaturationName);
                    cmd.AddParameter("Spanish", DbType.String, 252, myserviceEcolabSaturationDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myserviceEcolabSaturationDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myserviceEcolabSaturationDetails.nl_BE);
                });
        }
    }
}