DECLARE @SyncTimeGap INT,
@SyncStatus INT;

SET @SyncTimeGap =(SELECT 
			DATEDIFF ( MINUTE ,  MAX(slr.CreatedDate) ,GETUTCDATE() )  AS SyncTimeGap 
		FROM tcd.SyncLogRequests AS SLR
		WHERE SLR.SyncLogParameterId = 1
			AND SLR.PlantId = @PlantId )
IF(@SyncTimeGap > @SyncLapseTime)
BEGIN
	SET @SyncStatus = 1;
END
ELSE
BEGIN
	SET @SyncStatus = 0;
END
SELECT 
		@SyncStatus	AS SyncStatus
