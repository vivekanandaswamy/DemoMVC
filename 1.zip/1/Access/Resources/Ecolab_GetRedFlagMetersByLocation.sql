
/*
Item id Gas consumption=7,Energy consumption=8
*/


IF @itemId = 7 OR @itemId = 8
    BEGIN
        DECLARE
           @MeterTickUnit varchar( 1000),
		   @LanguageId int,
		   @UomEndPart varchar (100);

		   Select @UomEndPart = (case when RegionId=1 then 'CWT' else 'kg' end),@LanguageId=LanguageId  from TCD.Plant where EcolabAccountNumber = @EcolabAccountNumber


        IF @itemId = 7
            BEGIN
                SELECT
                        @MeterTickUnit =isnull( rkv.Value,MeterTickUnit)
                  FROM TCD.Meter m
				  left join tcd.ResourceKeyValue rkv on M.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
                  WHERE ISNULL( GroupId , 0) = 0
                    AND UtilityType = 1
                    AND EcolabAccountNumber = @EcolabAccountNumber
                    AND Is_deleted = 0;
            END;
        ELSE
            BEGIN
                SELECT
                        @MeterTickUnit = isnull( rkv.Value,MeterTickUnit)
                  FROM TCD.Meter m
				    left join tcd.ResourceKeyValue rkv on M.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
                  WHERE ISNULL( GroupId , 0) = 0
                    AND UtilityType IN( 1 , 4)
                    AND EcolabAccountNumber = @EcolabAccountNumber
                    AND Is_deleted = 0;
            END;
        SELECT
                -1 , 
                'All' , 
              (CASE WHEN  @MeterTickUnit IS NULL  THEN '' ELSE  @MeterTickUnit+'/'+@UomEndPart end)
        UNION
        SELECT
                M.MeterId , 
                M.Description , 
                isnull( rkv.Value,MeterTickUnit) +'/'+@UomEndPart
          FROM TCD.Meter AS M
		    left join tcd.ResourceKeyValue rkv on M.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
          WHERE M.GroupId = @LocationId
            AND M.EcolabAccountNumber = @EcolabAccountNumber
            AND Is_deleted = 0;
    END;
ELSE
    BEGIN

        SELECT
                M.MeterId , 
                M.Description , 
               isnull( rkv.Value,MeterTickUnit) +'/'+@UomEndPart
          FROM TCD.Meter AS M
		   left join tcd.ResourceKeyValue rkv on M.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
          WHERE M.GroupId = @LocationId
            AND M.EcolabAccountNumber = @EcolabAccountNumber
            AND Is_deleted = 0;
    END;

