SELECT

		P.EcolabAccountNumber, 

		P.Name, 

		P.PlantId

		FROM TCD.Plant AS P

WHERE P.Is_Deleted = 0