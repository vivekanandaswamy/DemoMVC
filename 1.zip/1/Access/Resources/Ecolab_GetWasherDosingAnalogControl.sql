
BEGIN 
DECLARE  @WasherDosingSetupId INT;
SET @WasherDosingSetupId = (SELECT TOP 1 WasherDosingSetupId FROM [TCD].WasherDosingSetup 
WHERE  WasherProgramSetupId= @WasherProgramSetupId AND StepNumber=@StepNumber AND EcoLabAccountNumber = @EcoLabAccountNumber
order by WasherDosingSetupId desc) 
SELECT   
CAST(ACM.WasherDosingAnalogControllerMappingId AS INT) ,  
--ACM.PlantId,  
CAST(ACM.WasherDosingSetupId AS INT),  
ACM.SetPointTemperature AS TempSetPoint,  
CAST(ACM.MinimumTime AS INT) AS MinTime,  
CAST(ACM.StartDelay AS INT),  
CAST(ACM.AcceptedDelay AS INT),  
CAST(ACM.ProductId AS INT),  
ACM.PhControlDuringDrain,  
CAST(ACM.PhDelayTime AS INT),  
CAST(ACM.PhMeasuringTime AS INT),  
ACM.PhMininum,  
ACM.PhMaximum,  
CAST(WDS.StepNumber AS INT)  
 FROM [TCD].WasherDosingAnalogControllerMapping AS ACM  
 JOIN [TCD].WasherDosingSetup AS WDS ON WDS.WasherDosingSetupId = ACM.WasherDosingSetupId  
 WHERE ACM.EcoLabAccountNumber = @EcoLabAccountNumber 
 AND WDS.EcoLabAccountNumber = @EcoLabAccountNumber
 AND ACM.WasherDosingSetupId = @WasherDosingSetupId  
 END  
   
  
   