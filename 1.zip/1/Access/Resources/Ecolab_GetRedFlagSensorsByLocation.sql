SELECT 
		S.SensorId,
		S.Description
	FROM TCD.Sensor AS S
	WHERE S.GroupId = @LocationId AND S.EcolabAccountNumber = @EcolabAccountNumber AND Is_deleted = 0