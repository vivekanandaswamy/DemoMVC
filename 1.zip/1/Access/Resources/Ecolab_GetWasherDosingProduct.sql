[TCD].[GetWasherDosingAnalogControl]
	

 
