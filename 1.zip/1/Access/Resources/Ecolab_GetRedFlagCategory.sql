SELECT 
		RFC.RedFlagCategoryID,
		RFC.Name  
	FROM TCD.RedFlagCategory AS RFC
