Select AlarmGroupMsterVsControllerModelTypeId FROM TCD.AlarmGroupMsterVsControllerModelType
Where AlarmGroupMasterId IN(
SELECT AlarmGroupMasterId FROM TCD.AlarmGroupMaster AGM WHere AlarmGroupMasterId  In
(SELECT AlarmGroupMasterId FROM [TCD].[AlarmGroupMsterVsControllerModelType] 
Where AlarmCode =  @AlarmCode And ControllerModelTypeId = (
SELECT Id FROM TCD.ControllerModelControllerTypeMapping WHere ControllerModelId =  @ControllerModelTypeId
) )   AND AGM.WasherType = @WasherType )