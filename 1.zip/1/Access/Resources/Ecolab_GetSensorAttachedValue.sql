(SELECT STUFF((SELECT ',' + CAST(S.SensorType AS VARCHAR(2))    
      
     FROM TCD.Sensor S WHERE  S.GroupId = @washerGroupId
     AND S.EcolabAccountNumber = @EcolabAccountNumber
     AND S.Is_deleted = 0 GROUP BY S.SensorType    
     FOR XML PATH('')) ,1,1,''))