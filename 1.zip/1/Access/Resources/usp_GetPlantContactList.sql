﻿/* 
 ========================================================================================== 
 Purpose:  Used to get contacts to popuplate in User Management Add.

 Author:  Krishna Gangadhar Thota 

 -------------------------------------------------------------- 
 November-11-2014 ENT: Initial version. 
 ========================================================================================== 
*/ 
CREATE PROCEDURE [dbo].[usp_GetPlantContactList] (
@Contact Varchar(1000),@EcolabAccountNumber Varchar(100))
AS   
BEGIN
		SET NOCOUNT ON;
		BEGIN   
    SELECT  
			PC.ID,  
			PC.EcolabAccountNumber ,  
			PC.ContactFirstName,  
			PC.ContactLastName,  
			PC.ContactTitle ,  
			PC.ContactPositionId,  
			(
		SELECT 
			CP.Position_Name 
		FROM PlantContactPosition CP 
		WHERE 
			CP.Id = PC.ContactPositionId
			) 
		AS 
			ContactPositionName,
			PC.ContactEMail,  
			PC.ContactOfficePhone ,  
			PC.ContactMobilePhone ,  
			PC.ContactFaxNumber  
		FROM PlantContact PC 
		WHERE 
			(
			PC.ContactFirstName LIKE '%' + @Contact + '%'
			OR 
			PC.ContactLastName LIKE '%' + @Contact + '%'
			) 
			AND PC.Is_Deleted = 0 
			AND PC.EcolabAccountNumber = @EcolabAccountNumber;
		END;
END;