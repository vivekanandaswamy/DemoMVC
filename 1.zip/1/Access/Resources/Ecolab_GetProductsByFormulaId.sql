DECLARE @IStunnel INT = NULL;
DECLARE @ControllerId INT = (SELECT 
			ControllerId 
		FROM tcd.washerGroup 
		WHERE washerGroupId = @LocationId)
DECLARE @Controllermodelid INT = (SELECT ControllerModelId FROM TCD.ConduitController WHERE ControllerId = @ControllerId)
SELECT @IStunnel = Istunnel  
 FROM TCD.machinesetup  
 WHERE GroupId = @LocationId
IF(@IStunnel <> 1)
BEGIN

IF(@ProgramId = -1 OR @programId IS NULL)
BEGIN
IF(@Controllermodelid = 7)
BEGIN
SELECT
		PM.ProductId,
		PM.Name	
	FROM TCD.ProductMaster PM
		JOIN TCD.WasherDosingProductMapping WDPM ON WDPM.ProductId = PM.ProductId AND WDPM.EcoLabAccountNumber = @EcolabAccountNumber
		JOIN TCD.WasherDosingSetup WDS ON WDS.WasherDosingSetUpId = WDPM.WasherDosingSetUpId AND WDS.EcoLabAccountNumber = WDPM.EcoLabAccountNumber 
		JOIN TCD.WasherProgramSetUp WPS ON WPS.WasherProgramSetUpId = WDS.WasherProgramSetUpId AND WPS.EcolabAccountNumber = WDS.EcoLabAccountNumber 
		AND (WPS.WasherGroupId = WDS.GroupId OR WPS.WasherGroupId IS NULL)
		WHERE  
		 (CASE WHEN WPS.WasherGroupId IS NULL THEN WPS.Controllerid ELSE WPS.WasherGroupId END)	= (CASE WHEN WPS.WasherGroupId IS NULL THEN
				 @ControllerId ELSE @LocationId END)  AND 
				  WDS.GroupId	IS NULL AND PM.ProductId NOT IN (1) 
END
ELSE
BEGIN
	SELECT
		PM.ProductId,
		PM.Name	
	FROM TCD.ProductMaster PM
		JOIN TCD.WasherDosingProductMapping WDPM ON WDPM.ProductId = PM.ProductId AND WDPM.EcoLabAccountNumber = @EcolabAccountNumber
		JOIN TCD.WasherDosingSetup WDS ON WDS.WasherDosingSetUpId = WDPM.WasherDosingSetUpId AND WDS.EcoLabAccountNumber = WDPM.EcoLabAccountNumber 
		JOIN TCD.WasherProgramSetUp WPS ON WPS.WasherProgramSetUpId = WDS.WasherProgramSetUpId AND WPS.EcolabAccountNumber = WDS.EcoLabAccountNumber AND WPS.WasherGroupId = WDS.GroupId
		WHERE  WDS.GroupId = @LocationId AND PM.ProductId NOT IN (1)

END
END
ELSE

BEGIN
IF(@Controllermodelid = 7)
BEGIN
SELECT
		PM.ProductId,
		PM.Name	
	FROM TCD.ProductMaster PM
		JOIN TCD.WasherDosingProductMapping WDPM ON WDPM.ProductId = PM.ProductId AND WDPM.EcoLabAccountNumber = @EcolabAccountNumber
		JOIN TCD.WasherDosingSetup WDS ON WDS.WasherDosingSetUpId = WDPM.WasherDosingSetUpId AND WDS.EcoLabAccountNumber = WDPM.EcoLabAccountNumber 
		JOIN TCD.WasherProgramSetUp WPS ON WPS.WasherProgramSetUpId = WDS.WasherProgramSetUpId AND WPS.EcolabAccountNumber = WDS.EcoLabAccountNumber 
		AND (WPS.WasherGroupId = WDS.GroupId OR WPS.WasherGroupId IS NULL)
		JOIN TCD.ProgramMaster PMS ON PMS.ProgramId = WPS.ProgramId AND PMS.EcolabAccountNumber = WPS.EcolabAccountNumber
		WHERE  
		 (CASE WHEN WPS.WasherGroupId IS NULL THEN WPS.Controllerid ELSE WPS.WasherGroupId END)	= (CASE WHEN WPS.WasherGroupId IS NULL THEN
				 @ControllerId ELSE @LocationId END)  AND 
				  WDS.GroupId	IS NULL AND PM.ProductId NOT IN (1) AND PMS.ProgramId = @ProgramId
END
ELSE
BEGIN
SELECT
		PM.ProductId,
		PM.Name	
	FROM TCD.ProductMaster PM
		JOIN TCD.WasherDosingProductMapping WDPM ON WDPM.ProductId = PM.ProductId AND WDPM.EcoLabAccountNumber = @EcolabAccountNumber
		JOIN TCD.WasherDosingSetup WDS ON WDS.WasherDosingSetUpId = WDPM.WasherDosingSetUpId AND WDS.EcoLabAccountNumber = WDPM.EcoLabAccountNumber 
		JOIN TCD.WasherProgramSetUp WPS ON WPS.WasherProgramSetUpId = WDS.WasherProgramSetUpId AND WPS.EcolabAccountNumber = WDS.EcoLabAccountNumber 
		AND (WPS.WasherGroupId = WDS.GroupId OR WPS.WasherGroupId IS NULL)
		JOIN TCD.ProgramMaster PMS ON PMS.ProgramId = WPS.ProgramId AND PMS.EcolabAccountNumber = WPS.EcolabAccountNumber
		WHERE  
		 (CASE WHEN WPS.WasherGroupId IS NULL THEN WPS.Controllerid ELSE WPS.WasherGroupId END)	= (CASE WHEN WPS.WasherGroupId IS NULL THEN
				 @ControllerId ELSE @LocationId END)  AND 
				  WDS.GroupId	=@LocationId AND PMS.ProgramId = @ProgramId AND PM.ProductId NOT IN (1)
		
END

END
END

ELSE

IF(@ProgramId = -1 OR @programId IS NULL)

BEGIN
	SELECT 
			PM.ProductId,
			PM.Name	
	FROM	TCD.TunnelCompartment TC 
	JOIN	TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False'	
	JOIN	TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
	JOIN	TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
	JOIN	TCD.ProductMaster PM ON PM.ProductId = CES.ProductId 
	JOIN	TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN	TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
								AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
	JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
								AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
		WHERE 
		MS.GroupId=@LocationId AND TC.EcoLabAccountNumber = @EcolabAccountNumber
END

ELSE
BEGIN
	SELECT 
			PM.ProductId,
			PM.Name	
	FROM	TCD.TunnelCompartment TC 
	JOIN	TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False'	
	JOIN	TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
	JOIN	TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
	JOIN	TCD.ProductMaster PM ON PM.ProductId = CES.ProductId 
	JOIN	TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN    TCD.ProgramMaster PMS ON PMS.ProgramId = TPS.TunnelProgramSetupId AND PMS.EcolabAccountNumber = TPS.EcolabAccountNumber
	JOIN	TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
								AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
	JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
								AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
		WHERE 
		MS.GroupId=@LocationId AND PMS.ProgramId= @ProgramId AND TC.EcoLabAccountNumber = @EcolabAccountNumber
END