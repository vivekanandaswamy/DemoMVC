IF ISNULL(@WasherDosingSetupId, 0) = 0 
  BEGIN 
      SET @WasherDosingSetupId =(SELECT WasherDosingSetupId 
                                 from   TCD.WasherDosingSetup 
                                 WHERE  WasherProgramSetupId = @ProgramSetupId 
                                        AND StepNumber = @StepNumber
										AND EcoLabAccountNumber = @EcolabAccountNumber 
                                        AND Is_Deleted = 0) 
  END 

IF NOT EXISTS(SELECT 1 
              FROM   TCD.WasherDosingAnalogControllerMapping AS WAC 
                     JOIN TCD.WasherDosingSetup AS WDS 
                       ON WDS.WasherDosingSetupId = WAC.WasherDosingSetupId 
              WHERE  WasherProgramSetupId = @ProgramSetupId 
                     AND StepNumber = @StepNumber 
                     AND WAC.EcolabAccountNumber = @EcolabAccountNumber 
                     AND WAC.WasherDosingSetupId = ISNULL(@WasherDosingSetupId, 0)) 
  BEGIN 
      DECLARE @PlantId INT; 

      SET @PlantId= (SELECT PlantId 
                     from   TCD.Plant 
                     WHERE  EcolabAccountNumber = @EcolabAccountNumber) 

      INSERT INTO TCD.WasherDosingAnalogControllerMapping 
                  (PlantId, 
                   WasherDosingSetupId, 
                   SetPointTemperature, 
                   MinimumTime, 
                   StartDelay, 
                   AcceptedDelay, 
                   ProductId, 
                   PhControlDuringDrain, 
                   PhDelayTime, 
                   PhMeasuringTime, 
                   PhMininum, 
                   PhMaximum, 
                   LastModifiedByUserId, 
                   LastModifiedTime, 
                   EcolabAccountNumber) 
      VALUES      (@PlantId, 
                   @WasherDosingSetupId, 
                   @SetPointTemperature, 
                   @MinimumTime, 
                   @StartDelay, 
                   @AcceptedDelay, 
                   @ProductId, 
                   @PhControlDuringDrain, 
                   @PhDelayTime, 
                   @PhMeasuringTime, 
                   @PhMininum, 
                   @PhMaximum, 
                   @UserId, 
                   Getutcdate(), 
                   @EcolabAccountNumber) 
  END 
ELSE 
  BEGIN 
      UPDATE TCD.WasherDosingAnalogControllerMapping 
      SET    SetPointTemperature = @SetPointTemperature, 
             MinimumTime = @MinimumTime, 
             StartDelay = @StartDelay, 
             AcceptedDelay = @AcceptedDelay, 
             ProductId = @ProductId, 
             PhControlDuringDrain = @PhControlDuringDrain, 
             PhDelayTime = @PhDelayTime, 
             PhMeasuringTime = @PhMeasuringTime, 
             PhMininum = @PhMininum, 
             PhMaximum = @PhMaximum 
      WHERE  EcolabAccountNumber = @EcolabAccountNumber 
             AND WasherDosingSetupId = @WasherDosingSetupId 
  END 