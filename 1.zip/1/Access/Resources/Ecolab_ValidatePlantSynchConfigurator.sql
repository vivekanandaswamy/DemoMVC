DECLARE @SyncTimeGap INT,
@PlantId INT,
@SyncStatus INT,
@SyncLogRequestCount INT;

SET @SyncLogRequestCount = ( SELECT COUNT(*) FROM tcd.SyncLogRequests )

IF(@SyncLogRequestCount > 0)
   BEGIN
		SET @PlantId = (SELECT PlantId from tcd.Plant where EcolabAccountNumber = @EcolabAccountNumber)
		SET @SyncTimeGap =(SELECT 
					DATEDIFF ( MINUTE ,  MAX(slr.CreatedDate) ,GETUTCDATE() )  AS SyncTimeGap 
				FROM tcd.SyncLogRequests AS SLR
				WHERE SLR.SyncLogParameterId = 1
					AND SLR.PlantId = @PlantId )
		IF(@SyncTimeGap > 60)
		BEGIN
			SET @SyncStatus = 1;
		END
		ELSE
		BEGIN
			SET @SyncStatus = 0;
		END
  END
ELSE
	BEGIN
		SET @SyncStatus = 1;
	END
SELECT 
		@SyncStatus	AS SyncStatus
