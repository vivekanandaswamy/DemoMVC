DECLARE @IStunnel INT = NULL;
SELECT @IStunnel = Istunnel  
 FROM TCD.machinesetup  
 WHERE GroupId = @LocationId
IF(@IStunnel <> 1)
BEGIN
	IF(@EcolabTextileCategoryId = 0)
	BEGIN
		SELECT DISTINCT
			PM.ProgramId,
			CONCAT(WPS.ProgramNumber,':',PM.Name) AS Name
		FROM TCD.WasherProgramSetup AS WPS
			INNER JOIN  TCD.ProgramMaster AS PM ON WPS.ProgramID = PM.ProgramId	
		WHERE PM.EcolabAccountNumber = @EcolabAccountNumber	
	END
	ELSE
	BEGIN
		SELECT	DISTINCT
				PM.ProgramId,
				CONCAT(WPS.ProgramNumber,':',PM.Name) AS Name
			FROM TCD.WasherProgramSetup AS WPS
				INNER JOIN  TCD.ProgramMaster AS PM ON WPS.ProgramID = PM.ProgramId	
			WHERE PM.EcolabTextileCategoryId = @EcolabTextileCategoryId
				AND PM.EcolabAccountNumber = @EcolabAccountNumber
		END
END
ELSE
BEGIN
	IF(@EcolabTextileCategoryId = 0)
	BEGIN
		SELECT	DISTINCT
				PM.ProgramId,
				CONCAT(TPS.ProgramNumber,':',PM.Name) AS Name
			FROM TCD.TunnelProgramSetup AS TPS
				INNER JOIN  TCD.ProgramMaster AS PM ON TPS.ProgramID = PM.ProgramId	
				AND PM.EcolabAccountNumber = @EcolabAccountNumber
	END
	ELSE
	BEGIN
		SELECT	DISTINCT
				PM.ProgramId,
				CONCAT(TPS.ProgramNumber,':',PM.Name) AS Name
			FROM TCD.TunnelProgramSetup AS TPS
				INNER JOIN  TCD.ProgramMaster AS PM ON TPS.ProgramID = PM.ProgramId	
			WHERE PM.EcolabTextileCategoryId = @EcolabTextileCategoryId
				AND PM.EcolabAccountNumber = @EcolabAccountNumber
	END
END
	
