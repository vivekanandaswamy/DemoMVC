IF EXISTS(SELECT
                  1 FROM TCD.MachineGroup)
    BEGIN
        UPDATE tcd.MachineGroup SET
                TCD.MachineGroup.EcolabAccountNumber = @Ecolabaccountnumber;
    END;
