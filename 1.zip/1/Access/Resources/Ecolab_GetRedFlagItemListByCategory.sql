DECLARE @RegionId INT;
SET @RegionId = (SELECT 
			RegionId
		FROM TCD.Plant
		WHERE EcolabAccountNumber = @EcolabAccountNumber)
IF (@RegionId = 2)
BEGIN
SELECT 
		RFIL.Id,
		RFIL.ItemName,
		RFIL.UOMEurope
	FROM TCD.RedFlagItemList AS RFIL
	WHERE RFIL.CategoryId=@CategoryId
END
ELSE
BEGIN
SELECT 
		RFIL.Id,
		RFIL.ItemName,
		RFIL.UOMNA
	FROM TCD.RedFlagItemList AS RFIL
	WHERE RFIL.CategoryId=@CategoryId
END
