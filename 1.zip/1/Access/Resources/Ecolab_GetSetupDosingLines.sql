DECLARE 
  @DosingLineMode INT, 
  @EnableAuxiliary INT


set @DosingLineMode=
(select value  from tcd.ControllerSetupData 
where  FieldTagValue = @Tag_DLM and controllerid = @controllerid)

set @EnableAuxiliary=
(select value  from tcd.ControllerSetupData 
where  FieldTagValue =@Tag_EAP and controllerid = @controllerid)

select @DosingLineMode as DosingLineMode ,@EnableAuxiliary as EnableAuxiliary