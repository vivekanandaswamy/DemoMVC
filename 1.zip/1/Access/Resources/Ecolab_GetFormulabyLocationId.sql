DECLARE @IStunnel INT = NULL, @PlantChainID INT = NULL;
DECLARE @ControllerId INT = (SELECT 
			ControllerId 
		FROM tcd.washerGroup 
		WHERE washerGroupId = @LocationId)
SELECT 
		@IStunnel = Istunnel  
	FROM TCD.machinesetup  
	WHERE GroupId = @LocationId AND EcoalabAccountNumber = @EcolabAccountNumber AND IsDeleted =0; ;

SELECT 
		@PlantChainID = p.PlantChainID
	FROM TCD.Plant p
	WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

IF (@LocationId = 1)
BEGIN
IF (@PlantChainID IS NULL OR @PlantChainID = 0)
    BEGIN 
    SELECT	DISTINCT							
					    PM.ProgramID AS id,
					    PM.Name AS Name,
					    ETC.TextileId AS EcolabTextileCategoryID,
					    ETC.CategoryName AS EcolabTextileCategoryName,
					    0 AS ChainTextileCategoryID,
					    CAST('' AS NVARCHAR(10)) AS ChainTextileCategoryName
				    FROM TCD.TunnelProgramSetup AS TPS
					    INNER JOIN  TCD.ProgramMaster AS PM ON TPS.ProgramID = PM.ProgramId
					    JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
															
				    WHERE PM.EcolabAccountNumber = @EcolabAccountNumber 
				    and TPS.Is_Deleted = 0

				    UNION

				    SELECT	DISTINCT
					    PM.ProgramID AS id,
					    PM.Name AS Name,
					    ETC.TextileId AS EcolabTextileCategoryID,
					    ETC.CategoryName AS EcolabTextileCategoryName,
					    0 AS ChainTextileCategoryID,
					    CAST('' AS NVARCHAR(10)) AS ChainTextileCategoryName
				    FROM TCD.WasherProgramSetup AS WPS
					    INNER JOIN  TCD.ProgramMaster AS PM ON WPS.ProgramID = PM.ProgramId
					    JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
				    WHERE PM.EcolabAccountNumber = @EcolabAccountNumber and WPS.Is_Deleted = 0;
    END
    ELSE 
    BEGIN 
    SELECT	DISTINCT
					PM.ProgramID AS ID,
					PM.Name AS Name,
					ISNULL(ETC.TextileId,0) AS EcolabTextileCategoryID,
					ETC.CategoryName AS EcolabTextileCategoryName,
					ISNULL(ctc.TextileId,0) AS ChainTextileCategoryID,
					ctc.Name AS ChainTextileCategoryName
				FROM TCD.WasherProgramSetup AS WPS
					INNER JOIN  TCD.ProgramMaster AS PM ON WPS.ProgramID = PM.ProgramId
					INNER JOIN TCD.PlantChainProgram pcp ON pcp.PlantProgramId = PM.PlantProgramId
					LEFT JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = pcp.EcolabTextileCategoryId															
					LEFT JOIN TCD.ChainTextileCategory ctc ON ctc.TextileId = pcp.ChainTextileCategoryId																												
				WHERE PM.EcolabAccountNumber = @EcolabAccountNumber
				and WPS.Is_Deleted = 0

				UNIOn

				SELECT	DISTINCT					
					PM.ProgramID AS ID,
					PM.Name AS Name,
					ISNULL(ETC.TextileId,0) AS EcolabTextileCategoryID,
					ETC.CategoryName AS EcolabTextileCategoryName,
					ISNULL(ctc.TextileId,0) AS ChainTextileCategoryID,
					ctc.Name AS ChainTextileCategoryName
				FROM TCD.TunnelProgramSetup AS TPS
					INNER JOIN  TCD.ProgramMaster AS PM ON TPS.ProgramID = PM.ProgramId
					INNER JOIN TCD.PlantChainProgram pcp ON pcp.PlantProgramId = PM.PlantProgramId
					LEFT JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = pcp.EcolabTextileCategoryId															
					LEFT JOIN TCD.ChainTextileCategory ctc ON ctc.TextileId = pcp.ChainTextileCategoryId																												
				WHERE PM.EcolabAccountNumber = @EcolabAccountNumber
				and TPS.Is_Deleted = 0; END
END

ELSE
BEGIN
IF(@IStunnel = 1)
BEGIN
	
	IF (@PlantChainID IS NULL OR @PlantChainID = 0)
	BEGIN
		SELECT	DISTINCT							
					PM.ProgramID,
					PM.Name AS Name,
					ETC.TextileId AS EcolabTextileCategoryID,
					ETC.CategoryName AS EcolabTextileCategoryName,
					0 AS ChainTextileCategoryID,
					CAST('' AS NVARCHAR(10)) AS ChainTextileCategoryName
				FROM TCD.TunnelProgramSetup AS TPS
					INNER JOIN  TCD.ProgramMaster AS PM ON TPS.ProgramID = PM.ProgramId
					JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
															AND TPS.WasherGroupId = @LocationId 
				WHERE PM.EcolabAccountNumber = @EcolabAccountNumber and TPS.Is_Deleted = 0;
	END
	ELSE
		SELECT	DISTINCT					
					PM.ProgramID,
					PM.Name AS Name,
					ISNULL(ETC.TextileId,0) AS EcolabTextileCategoryID,
					ETC.CategoryName AS EcolabTextileCategoryName,
					ISNULL(ctc.TextileId,0) AS ChainTextileCategoryID,
					ctc.Name AS ChainTextileCategoryName
				FROM TCD.TunnelProgramSetup AS TPS
					INNER JOIN  TCD.ProgramMaster AS PM ON TPS.ProgramID = PM.ProgramId
					INNER JOIN TCD.PlantChainProgram pcp ON pcp.PlantProgramId = PM.PlantProgramId
					LEFT JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = pcp.EcolabTextileCategoryId															
					LEFT JOIN TCD.ChainTextileCategory ctc ON ctc.TextileId = pcp.ChainTextileCategoryId																												
				WHERE PM.EcolabAccountNumber = @EcolabAccountNumber
				AND TPS.WasherGroupId = @LocationId and TPS.Is_Deleted = 0;
END
ELSE
BEGIN
	
	IF (@PlantChainID IS NULL OR @PlantChainID = 0)
	BEGIN
		SELECT	DISTINCT
					PM.ProgramID,
					PM.Name AS Name,
					ETC.TextileId AS EcolabTextileCategoryID,
					ETC.CategoryName AS EcolabTextileCategoryName,
					0 AS ChainTextileCategoryID,
					CAST('' AS NVARCHAR(10)) AS ChainTextileCategoryName
				FROM TCD.WasherProgramSetup AS WPS
					INNER JOIN  TCD.ProgramMaster AS PM ON WPS.ProgramID = PM.ProgramId
					JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
															AND WPS.WasherGroupId = @LocationId
				WHERE PM.EcolabAccountNumber = @EcolabAccountNumber and WPS.Is_Deleted = 0;
	END
	ELSE
		SELECT	DISTINCT
					PM.ProgramID,
					PM.Name AS Name,
					ISNULL(ETC.TextileId,0) AS EcolabTextileCategoryID,
					ETC.CategoryName AS EcolabTextileCategoryName,
					ISNULL(ctc.TextileId,0) AS ChainTextileCategoryID,
					ctc.Name AS ChainTextileCategoryName
				FROM TCD.WasherProgramSetup AS WPS
					INNER JOIN  TCD.ProgramMaster AS PM ON WPS.ProgramID = PM.ProgramId
					INNER JOIN TCD.PlantChainProgram pcp ON pcp.PlantProgramId = PM.PlantProgramId
					LEFT JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = pcp.EcolabTextileCategoryId															
					LEFT JOIN TCD.ChainTextileCategory ctc ON ctc.TextileId = pcp.ChainTextileCategoryId																												
				WHERE PM.EcolabAccountNumber = @EcolabAccountNumber
				AND (CASE WHEN WPS.WasherGroupId IS NULL THEN WPS.Controllerid ELSE WPS.WasherGroupId END)	= (CASE WHEN WPS.WasherGroupId IS NULL THEN
				 @ControllerId ELSE @LocationId END)	and WPS.Is_Deleted = 0;
END
END