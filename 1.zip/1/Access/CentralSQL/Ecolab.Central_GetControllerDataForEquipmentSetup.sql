/*
History-
Feb. 2016		mrayalla@allianceglobalservice.com		created prepared statement
*/
BEGIN
	SET NOCOUNT ON;
	SELECT 
			MS.MachineInternalId AS Id,
			'No. Of Compartments T1' AS Label,
			MS.NumberOfComp AS Value
		FROM TCD.MachineSetup MS
		WHERE MS.ControllerId = @ControllerId
			AND MS.IsDeleted = 0
			AND MS.IsTunnel = 1
			AND MS.MachineInternalId = 1
			AND MS.EcoalabAccountNumber = @EcolabAccountNumber
    UNION
    SELECT 
			MS.MachineInternalId,
			'No. Of Compartments T2',
			MS.NumberOfComp
		FROM TCD.MachineSetup MS
		WHERE MS.ControllerId = @ControllerId
			AND MS.IsDeleted = 0
			AND MS.IsTunnel = 1
	   AND MS.MachineInternalId = 2
	   AND MS.EcoalabAccountNumber = @EcolabAccountNumber
    UNION
    SELECT 
			CSD.FieldId,
			F.Label,
			CSD.[Value]
		FROM TCD.ControllerSetupData CSD
			JOIN TCD.Field F ON F.Id = CSD.FieldId
		WHERE CSD.FieldId	IN (251, 256, 261)
			AND CSD.ControllerId = @ControllerId
			AND CSD.EcolabAccountNumber = @EcolabAccountNumber
	UNION
	SELECT 
			CSD.FieldId,
			F.Label,
			CASE CSD.[Value]
		 WHEN 'TRUE' THEN 1
			ELSE 0
		 END
	 FROM TCD.ControllerSetupData CSD
		JOIN TCD.Field F ON F.Id = CSD.FieldId
	 WHERE CSD.FieldId	IN (249, 254, 259)
		AND CSD.ControllerId = @ControllerId
		AND CSD.EcolabAccountNumber = @EcolabAccountNumber;
END;