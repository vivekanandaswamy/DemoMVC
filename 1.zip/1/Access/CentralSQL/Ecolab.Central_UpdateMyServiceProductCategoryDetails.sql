
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Currentutctime DATETIME = GETUTCDATE()


	--DECLARE @Sourcesystemid INT

	--SET @Sourcesystemid = (SELECT
	--							   ss.Id FROM TCD.SourceSystem AS ss WHERE ss.Code = @Sourcesystemcode)

	DECLARE @Outputlist AS TABLE(
			ProductCategoryId INT)

	IF NOT EXISTS(SELECT
						  1 FROM TCD.ProductCategory WHERE CategoryId = @ProductCategoryId)--need to change
		BEGIN
			INSERT INTO TCD.ProductCategory(
					Name, 
					Is_Deleted, 
					--MyServiceProdCatId, 
					MyServiceLastSynchTime, 
					LastModifiedTime)
					--SourceSystemId)
			OUTPUT
					inserted.CategoryId AS ProductCategoryId
				   INTO @Outputlist(
					ProductCategoryId)
				SELECT
						@Name, 
						@IsDelete, 
						--@Myserviceprodcategoryid, 
						@Currentutctime, 
						@Currentutctime
						--@Sourcesystemid
		END
	ELSE
		BEGIN
			UPDATE TCD.ProductCategory SET
					Name = @Name, 
					Is_Deleted = @Isdelete, 
					MyServiceLastSynchTime = @Currentutctime,
					LastModifiedTime = @Currentutctime
					--SourceSystemId = @Sourcesystemid
			OUTPUT
					inserted.CategoryId AS ProductCategoryId
				   INTO @Outputlist(
					ProductCategoryId)
				WHERE
					CategoryId = @ProductCategoryId
		END

	SELECT TOP 1
			@Outputproductcategoryid = O.ProductCategoryId FROM @Outputlist AS O

END