/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
	BEGIN
		SET NOCOUNT ON;
		BEGIN
			DECLARE @Tab NVARCHAR(100);

			SELECT DISTINCT
					FG.Id AS FieldGroupId, 
					FG.NAME AS FieldGroupName, 
					FG.image_Url AS FieldGroupImageUrl, 
					FG.helpText AS FieldGroupHelpText, 
					FGT.NAME AS FieldGroupTypeName, 
					F.Id AS FieldId, 
					FT.Name AS FieldType, 
					F.Label AS FieldLabel, 
					F.Min AS FieldMinValue, 
					F.Max AS FieldMaxValue, 
					F.IsMandatory AS FieldIsMandatory, 
					F.HelpText AS FieldHelpText, 
					F.HelpTextUrl AS FieldHelpUrl, 
					FG.TabId AS TabIndex, 
					DT.Name AS ControlType, 
					F.DataSourceId AS DataSourceId, 
					F.DataCategoryId AS DataCategoryId, 
					F.DefaultValue AS FieldDefaultValue, 
					F.CurrencyId AS FieldCurrencyCode, 
					F.ResourceKey AS FieldResourceKey, 
					FG.ResourceKey AS FieldGroupResourceKey, 
					FG.DisplayOrder AS FieldGroupDO, 
					F.DisplayOrder AS FieldDO
				FROM TCD.FieldGroup AS FG
					 INNER JOIN TCD.FieldGroupFieldMapping AS FGFM ON FG.Id = FGFM.FieldGroupId
					 INNER JOIN TCD.Field AS F ON F.Id = FGFM.FieldId
					 LEFT JOIN TCD.FieldGroupType AS FGT ON FGT.Id = FG.FieldGroupTypeId
					 LEFT JOIN TCD.FieldType AS FT ON FT.Id = F.TypeId
					 LEFT JOIN TCD.DataType AS DT ON DT.Id = F.DataTypeId
				WHERE FG.TabId = @Tab
				ORDER BY
					FG.DisplayOrder, F.DisplayOrder, F.Id;
		END;
	END;