/*
History-
Feb. 2016		mrayalla@allianceglobalservice.com		created prepared statement
*/
BEGIN

	SET NOCOUNT ON

	SELECT
			ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name) AS ProductName, 
			PM.ProductId AS ProductId
		FROM TCD.ProductMaster AS PM
			 JOIN TCD.ProductDataMapping AS PdM ON PM.ProductId = PdM.ProductID
			 JOIN TCD.Plant AS P ON PdM.EcolabAccountNumber = P.EcolabAccountNumber
								AND P.RegionId = PM.RegionId
			 JOIN TCD.PlantCustAddress AS PCA ON PCA.EcolabAccountNumber = P.EcolabAccountNumber
		WHERE PdM.EcolabAccountNumber = @Ecolabaccountnumber
		  AND PM.Is_Deleted = 0
		  AND PdM.Is_Deleted = 0
		   AND PM.ProductId NOT IN (SELECT ProductId FROM TCD.PRODUCTMASTER WHERE Name LIKE '%DUMMY PRODUCT%')
	SET NOCOUNT OFF

END