/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
BEGIN
	DECLARE  @Userid INT, 
	   @Ecolabaccountnumber NVARCHAR(25), 
	   @Ipaddress VARCHAR(200), 
	   @Useractivityid TINYINT

	SET NOCOUNT ON;

	INSERT INTO TCD.UserAudit(
			EcoLabAccountNumber, 
			UserId, 
			IPAddress, 
			UserActivityId)
		VALUES
			   (
				@Ecolabaccountnumber, 
				@Userid, 
				@Ipaddress, 
				@Useractivityid)

	SET NOCOUNT OFF;

END