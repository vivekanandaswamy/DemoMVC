/*
History-
Feb. 2016		mrayalla@allianceglobalservice.com		created prepared statement
*/
BEGIN
	SET NOCOUNT ON;
    DECLARE
		@DDFlag BIT = CAST(
		CASE
		WHEN EXISTS(SELECT 1
				   FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					   JOIN
					   TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
				   WHERE CES.ControllerEquipmentId = @EquipmentId
					AND TCEVM.DirectDosingFlag = 1
					AND CES.EcoLabAccountNumber = @EcolabAccountNumber) THEN 1
		   ELSE 0
		END
		AS BIT);
	SELECT
			TCEVM.TunnelCompartmentEquipmentValveMappingID
			, CES.ControllerEquipmentId
			, CES.ControllerID
			, TCEVM.TunnelNumber
			, CES.LineNumber
			, TCEVM.DosingPointNumber
			, TCEVM.ValveNumber
			, TCEVM.CompartmentNumber
			, TCEVM.DirectDosingFlag
			, TCEVM.WasherExtractorNumber  
			, TCEVM.LastModifiedDate
	 FROM TCD.ControllerEquipmentSetup CES
		 JOIN
		 TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON TCEVM.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId
	 WHERE @DDFlag = 1
		AND CES.ControllerEquipmentId = @EquipmentId
		AND TCEVM.DirectDosingFlag = 1
		OR @DDFlag = 0
		AND CES.LineNumber = @LineNumber
		AND CES.ControllerId = @ControllerId
		AND CES.EcoLabAccountNumber = @EcolabAccountNumber;
END;