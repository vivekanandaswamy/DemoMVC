/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
BEGIN

	SET NOCOUNT ON

	DECLARE @Emailaddress TABLE(
			EmailAdd VARCHAR(500))
	DECLARE @Sql VARCHAR(1000)
	SET @Sql = 'TCD.CharlistToTable ''' + @Email + ''''
	INSERT INTO @Emailaddress (EmailAdd)
	EXEC (@Sql)

	SELECT
			UserId, 
			FirstName, 
			LastName, 
			LoginName, 
			ISNULL(UM.LanguageId, PT.LanguageId)AS LanguageId, 
			Email, 
			PT.EcolabAccountNumber, 
			ISNULL(PCA.Country, PCA.Shippingcountry)AS CountryName, 
			RM.RegionId, 
			RM.RegionName, 
			(SELECT
					 lm.Locale
				 FROM TCD.LanguageMaster AS lm
				 WHERE lm.LanguageId = ISNULL(UM.LanguageId, PT.LanguageId))AS Locale
		FROM TCD.UserMaster AS UM
			 INNER JOIN TCD.Plant AS PT ON PT.EcolabAccountNumber = UM.EcolabAccountNumber
			 INNER JOIN TCD.RegionMaster AS RM ON RM.RegionId = PT.RegionId
			 INNER JOIN TCD.PlantCustAddress AS PCA ON PCA.EcolabAccountNumber = PT.EcolabAccountNumber
		WHERE UM.Email IN(SELECT
							   EmailAdd FROM @Emailaddress)
		  AND PT.EcolabAccountNumber = @Ecolabaccountnumber
		  AND UM.IsActive = 1
END