
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Regionid INT = NULL, 
			@Devicetypeid INT = NULL, 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Outputlist AS TABLE(
			DeviceModelId INT)

	SELECT
			@Regionid = RegionId
		FROM TCD.RegionMaster
		WHERE MyServiceRegionCode = @Regioncode

	SELECT
			@Devicetypeid = DeviceTypeId
		FROM TCD.DeviceType
		WHERE MyServiceWtrEnrgDvcTypId = @Myservicedevicetypeid

	IF NOT EXISTS(SELECT
						  1 FROM TCD.DeviceModel WHERE MyServiceWtrEnrgDvcId = @Myservicewtrenrgdvcid)
	BEGIN
			INSERT INTO TCD.DeviceModel(
					DeviceTypeId, 
					Description, 
					RegionID, 
					IsDeleted, 
					MyServiceWtrEnrgDvcId, 
					MyServiceLastSynchTime)
		OUTPUT
					inserted.Id AS DeviceModelId
				   INTO @Outputlist(
					DeviceModelId)
		SELECT
                        @Devicetypeid, 
                        @Description, 
                        @Regionid, 
                        @Isdeleted, 
                        @Myservicewtrenrgdvcid, 
                        @Currentutctime
	END
ELSE
	BEGIN
			UPDATE TCD.DeviceModel SET
					DeviceTypeId = @Devicetypeid, 
					Description = @Description, 
					RegionID = @Regionid, 
					IsDeleted = @Isdeleted, 
					MyServiceLastSynchTime = @Currentutctime
		OUTPUT
					inserted.Id AS DeviceModelId
				   INTO @Outputlist(
					DeviceModelId)
				WHERE MyServiceWtrEnrgDvcId = @Myservicewtrenrgdvcid
	END

	SELECT TOP 1
			@Outputdevicemodelid = O.DeviceModelId FROM @Outputlist AS O

END