/*
	History-
	Feb. 2016		sidrameshwar@allianceglobalservice.com		Created a prepared statement
	*/
BEGIN
	DECLARE @Tagaddress VARCHAR(200),
			@Controllerid INT,
			@Id INT = NULL,
			@Type INT = NULL,
			@Ecolabaccountnumber NVARCHAR(1000) = NULL
	SET NOCOUNT ON

	SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)

	IF @Type IS NULL
	OR @Type = 1
	OR @Type = 2
	OR @Type = 3
	OR @Type = 4
		BEGIN
			IF(
				SELECT
						COUNT(1)
					FROM TCD.ModuleTags AS MT
						LEFT JOIN TCD.TankSetup AS TS ON MT.EcolabAccountNumber = TS.EcoalabAccountNumber
														AND MT.ModuleID = TS.TankId
														AND MT.ModuleTypeId = 1
						LEFT JOIN TCD.Meter AS M ON MT.EcolabAccountNumber = M.EcolabAccountNumber
													AND MT.ModuleID = M.MeterId
													AND MT.ModuleTypeId = 2
						LEFT JOIN TCD.Sensor AS S ON MT.EcolabAccountNumber = S.EcolabAccountNumber
													AND MT.ModuleID = S.SensorId
													AND MT.ModuleTypeId = 3
						LEFT JOIN TCD.ControllerEquipmentSetup AS CES ON MT.EcolabAccountNumber = CES.EcolabAccountNumber
																		AND MT.ModuleID = CES.ControllerEquipmentSetupId
																		AND MT.ModuleTypeId = 4
						LEFT JOIN TCD.ConduitController AS CC ON M.EcolabAccountNumber = CC.EcoalabAccountNumber
																AND M.ControllerId = CC.ControllerId
																OR S.EcolabAccountNumber = CC.EcoalabAccountNumber
																AND S.ControllerId = CC.ControllerId
																OR TS.EcoalabAccountNumber = CC.EcoalabAccountNumber
																AND TS.ControllerId = CC.ControllerId
																OR CES.EcolabAccountNumber = CC.EcoalabAccountNumber
																AND CES.ControllerId = CC.ControllerId
					WHERE(M.EcolabAccountNumber = @Ecolabaccountnumber
							AND M.ControllerId = @Controllerid
							OR S.EcolabAccountNumber = @Ecolabaccountnumber
							AND S.ControllerId = @Controllerid
							OR TS.EcoalabAccountNumber = @Ecolabaccountnumber
							AND TS.ControllerId = @Controllerid
							OR CES.EcolabAccountNumber = @Ecolabaccountnumber
							AND CES.ControllerId = @Controllerid)
						AND MT.Active = 1
						AND MT.TagAddress = @Tagaddress
						AND (@Id IS NULL
							AND @Type IS NULL
							OR @Id != CASE
										WHEN @Type = 1 THEN ISNULL(TS.TankId, '')
										WHEN @Type = 2 THEN ISNULL(M.MeterId, '')
										WHEN @Type = 3 THEN ISNULL(S.SensorId, '')
										WHEN @Type = 4 THEN ISNULL(CES.ControllerEquipmentSetupId, '')
									END
						AND @Ecolabaccountnumber = CASE
													WHEN @Type = 1 THEN ISNULL(TS.EcoalabAccountNumber, '')
													WHEN @Type = 2 THEN ISNULL(M.EcolabAccountNumber, '')
													WHEN @Type = 3 THEN ISNULL(S.EcolabAccountNumber, '')
													WHEN @Type = 4 THEN ISNULL(CES.EcoLabAccountNumber, '')
												END)) > 0
				BEGIN
					RETURN 0;
				END

			IF(SELECT
						COUNT(1)
					FROM TCD.WasherTags AS WT
						LEFT JOIN TCD.MachineSetup AS MS ON MS.EcoalabAccountNumber = WT.EcolabAccountNumber
														AND MS.WasherId = WT.WasherId
					WHERE MS.EcoalabAccountNumber = @Ecolabaccountnumber
						AND WT.EcolabAccountNumber = @Ecolabaccountnumber
						AND MS.ControllerId = @Controllerid
						AND WT.TagAddress = @Tagaddress
						AND MS.IsDeleted = 0
						AND WT.Active = 1) > 0
				BEGIN
					RETURN 0;
				END

			IF(
				SELECT
						COUNT(1)
					FROM TCD.ControllerTags AS CT
						LEFT JOIN TCD.ConduitController AS CC ON CT.EcolabAccountNumber = CC.EcoalabAccountNumber
															 AND CT.ControllerID = CC.ControllerId
					WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
						AND CT.EcolabAccountNumber = @Ecolabaccountnumber
						AND CC.ControllerId = @Controllerid
						AND CT.TagAddress = @Tagaddress
						AND CC.IsDeleted = 0
						AND CT.Active = 1) > 0
				BEGIN
					RETURN 0;
				END

		END
	ELSE
		BEGIN
			IF @Type IS NULL
			OR @Type = 11
				BEGIN
					IF(SELECT
								COUNT(1)
							FROM TCD.ModuleTags AS MT
								LEFT JOIN TCD.TankSetup AS TS ON MT.EcolabAccountNumber = TS.EcoalabAccountNumber
																AND MT.ModuleID = TS.TankId
																AND MT.ModuleTypeId = 1
								LEFT JOIN TCD.Meter AS M ON MT.EcolabAccountNumber = M.EcolabAccountNumber
															AND MT.ModuleID = M.MeterId
															AND MT.ModuleTypeId = 2
								LEFT JOIN TCD.Sensor AS S ON MT.EcolabAccountNumber = S.EcolabAccountNumber
															AND MT.ModuleID = S.SensorId
															AND MT.ModuleTypeId = 3
								LEFT JOIN TCD.ControllerEquipmentSetup AS CES ON MT.EcolabAccountNumber = CES.EcolabAccountNumber
																				AND MT.ModuleID = CES.ControllerEquipmentId
																				AND MT.ModuleTypeId = 4
								LEFT JOIN TCD.ConduitController AS CC ON M.EcolabAccountNumber = CC.EcoalabAccountNumber
																		AND M.ControllerId = CC.ControllerId
																		OR S.EcolabAccountNumber = CC.EcoalabAccountNumber
																		AND S.ControllerId = CC.ControllerId
																		OR TS.EcoalabAccountNumber = CC.EcoalabAccountNumber
																		AND TS.ControllerId = CC.ControllerId
																		OR CES.EcolabAccountNumber = CC.EcoalabAccountNumber
																		AND CES.ControllerId = CC.ControllerId
							WHERE(M.EcolabAccountNumber = CC.EcoalabAccountNumber
									AND M.ControllerId = CC.ControllerId
									OR S.EcolabAccountNumber = CC.EcoalabAccountNumber
									AND S.ControllerId = CC.ControllerId
									OR TS.EcoalabAccountNumber = CC.EcoalabAccountNumber
									AND TS.ControllerId = CC.ControllerId
									OR CES.EcolabAccountNumber = CC.EcoalabAccountNumber
									AND CES.ControllerId = CC.ControllerId)
								AND MT.Active = 1
							AND MT.TagAddress = @Tagaddress) > 0
						BEGIN
							RETURN 0;
						END


					IF(SELECT
								COUNT(1)
							FROM TCD.WasherTags AS WT
								LEFT JOIN TCD.MachineSetup AS MS ON MS.EcoalabAccountNumber = WT.EcolabAccountNumber
																AND MS.WasherId = WT.WasherId
							WHERE MS.EcoalabAccountNumber = @Ecolabaccountnumber
								AND WT.EcolabAccountNumber = @Ecolabaccountnumber
								AND MS.ControllerId = @Controllerid
								AND WT.TagAddress = @Tagaddress
								AND MS.IsDeleted = 0
								AND WT.Active = 1
								AND (@Id IS NULL
								AND @Type IS NULL
								OR WT.EcolabAccountNumber = @Ecolabaccountnumber
								AND WT.WasherId != @Id)) > 0
						BEGIN
							RETURN 0;
						END

					IF(SELECT
								COUNT(1)
							FROM TCD.ControllerTags AS CT
								LEFT JOIN TCD.ConduitController AS CC ON CT.EcolabAccountNumber = CC.EcoalabAccountNumber
																	 AND CT.ControllerID = CC.ControllerId
							WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
								AND CT.EcolabAccountNumber = @Ecolabaccountnumber
								AND CC.ControllerId = @Controllerid
								AND CT.TagAddress = @Tagaddress
								AND CC.IsDeleted = 0
								AND CT.Active = 1) > 0
						BEGIN
							RETURN 0;
						END
				END
			ELSE
				BEGIN
					IF @Type IS NULL
					OR @Type = 12
						BEGIN
							IF(SELECT
									COUNT(1)
								FROM TCD.ModuleTags AS MT
									LEFT JOIN TCD.TankSetup AS TS ON MT.EcolabAccountNumber = TS.EcoalabAccountNumber
																	AND MT.ModuleID = TS.TankId
																	AND MT.ModuleTypeId = 1
									LEFT JOIN TCD.Meter AS M ON MT.EcolabAccountNumber = M.EcolabAccountNumber
																AND MT.ModuleID = M.MeterId
																AND MT.ModuleTypeId = 2
									LEFT JOIN TCD.Sensor AS S ON MT.EcolabAccountNumber = S.EcolabAccountNumber
																AND MT.ModuleID = S.SensorId
																AND MT.ModuleTypeId = 3
									LEFT JOIN TCD.ControllerEquipmentSetup AS CES ON MT.EcolabAccountNumber = CES.EcolabAccountNumber
																					AND MT.ModuleID = CES.ControllerEquipmentId
																					AND MT.ModuleTypeId = 4
									LEFT JOIN TCD.ConduitController AS CC ON M.EcolabAccountNumber = CC.EcoalabAccountNumber
																			AND M.ControllerId = CC.ControllerId
																			OR S.EcolabAccountNumber = CC.EcoalabAccountNumber
																			AND S.ControllerId = CC.ControllerId
																			OR TS.EcoalabAccountNumber = CC.EcoalabAccountNumber
																			AND TS.ControllerId = CC.ControllerId
																			OR CES.EcolabAccountNumber = CC.EcoalabAccountNumber
																			AND CES.ControllerId = CC.ControllerId
									WHERE(M.EcolabAccountNumber = @Ecolabaccountnumber
										AND M.ControllerId = @Controllerid
										OR S.EcolabAccountNumber = @Ecolabaccountnumber
										AND S.ControllerId = @Controllerid
										OR TS.EcoalabAccountNumber = @Ecolabaccountnumber
										AND TS.ControllerId = @Controllerid
										OR CES.EcolabAccountNumber = @Ecolabaccountnumber
										AND CES.ControllerId = @Controllerid)
										AND MT.Active = 1
									AND MT.TagAddress = @Tagaddress) > 0
								BEGIN
									RETURN 0;
								END

							IF(SELECT
									COUNT(1)
								FROM TCD.WasherTags AS WT
										LEFT JOIN TCD.MachineSetup AS MS ON MS.EcoalabAccountNumber = WT.EcolabAccountNumber
																		AND MS.WasherId = WT.WasherId
								WHERE MS.EcoalabAccountNumber = @Ecolabaccountnumber
									AND WT.EcolabAccountNumber = @Ecolabaccountnumber
									AND MS.ControllerId = @Controllerid
									AND WT.TagAddress = @Tagaddress
									AND MS.IsDeleted = 0
									AND WT.Active = 1) > 0
								BEGIN
									RETURN 0;
								END


							IF(SELECT
									COUNT(1)
								FROM TCD.ControllerTags AS CT
									LEFT JOIN TCD.ConduitController AS CC ON CT.EcolabAccountNumber = CC.EcoalabAccountNumber
																			AND CT.ControllerID = CC.ControllerId
								WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
									AND CT.EcolabAccountNumber = @Ecolabaccountnumber
									AND CC.ControllerId = @Controllerid
									AND CT.TagAddress = @Tagaddress
									AND CC.IsDeleted = 0
									AND CT.Active = 1
									AND (@Id IS NULL
									AND @Type IS NULL
									OR CT.EcolabAccountNumber = @Ecolabaccountnumber
									AND CT.ControllerID != @Id)) > 0
								BEGIN
									RETURN 0;
								END
						END
				END
		END
	RETURN 1;

END