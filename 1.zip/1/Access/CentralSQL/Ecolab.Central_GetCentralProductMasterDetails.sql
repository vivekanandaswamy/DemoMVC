
BEGIN
SELECT PM.[ProductId]
      ,PM.[SKU]
      ,PM.[Name]
      ,PM.[Cost]
      ,PM.[DensityFactor]
      ,PM.[AcceptedDeviation]
      ,PM.[ProductCategoryId]
      ,PM.[Type]
      ,PM.[Supplier]
      ,PM.[IncludeinCI]
      ,PM.[PackagingSize]
      ,PM.[Weight]
      ,PM.[Volume]
      ,PM.[Is_Deleted]
      ,PM.[ProductcategoryName]
      ,PM.[RegionId]
      ,PM.[Country]
      ,PM.[MyServiceProdId]
      ,PM.[MyServiceLastSynchTime]
      ,PM.[PackageSizeId]
      ,PM.[EnvisionDisplayName]
      ,PM.[SourceSystemId]
      
  FROM [TCD].[ProductMaster] PM
  
  WHERE PM.LastModifiedTime >=  @LastSyncTime
END
