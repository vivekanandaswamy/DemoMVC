
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Regionid INT = NULL, 
			@Watertypeid INT = NULL, 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Outputlist AS TABLE(
			WaterTypeId INT)

	SELECT
			@Regionid = RegionId
		FROM TCD.RegionMaster
		WHERE MyServiceRegionCode = @Regioncode

	IF NOT EXISTS(SELECT
						  1 FROM TCD.WaterType WHERE MyServiceUtilId = @Myserviceutilid)
		BEGIN
			INSERT INTO TCD.WaterType(
					Name, 
					RegionID, 
					IsDeleted, 
					MyServiceUtilTypeCode, 
					MyServiceUtilId, 
					MyServiceLastSynchTime)
			OUTPUT
					inserted.Id AS WaterTypeId
				   INTO @Outputlist(
					WaterTypeId)
				SELECT
						@Name, 
						@Regionid, 
						@Isdeleted, 
						@Myserviceutiltypecode, 
						@Myserviceutilid, 
						@Currentutctime
		END
	ELSE
		BEGIN
			UPDATE TCD.WaterType SET
					Name = @Name, 
					RegionID = @Regionid, 
					IsDeleted = @Isdeleted, 
					MyServiceUtilTypeCode = @Myserviceutiltypecode, 
					MyServiceLastSynchTime = @Currentutctime
			OUTPUT
					inserted.Id AS WaterTypeId
				   INTO @Outputlist(
					WaterTypeId)
				WHERE
					MyServiceUtilId = @Myserviceutilid
		END

	SELECT TOP 1
			@Outputwatertypeid = O.WaterTypeId FROM @Outputlist AS O

END