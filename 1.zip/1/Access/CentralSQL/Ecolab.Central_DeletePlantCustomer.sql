
  BEGIN 
	  SET NOCOUNT ON; 

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL 
	 




	UPDATE TCD.PlantCustomer SET
			Is_Deleted = 1, 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Currentutctime
		WHERE Id = @Id
			  AND EcolabAccountNumber = @Ecolabaccountnumber
	SELECT
			@Outputlastmodifiedtimestampatlocal = GETDATE()
	 
	--RETURN @Returnvalue
	--SET NOCOUNT OFF; 
  END