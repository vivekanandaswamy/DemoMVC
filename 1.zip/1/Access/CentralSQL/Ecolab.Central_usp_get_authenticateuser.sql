/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
BEGIN
	SET NOCOUNT ON; 

	DECLARE @Userlogin NVARCHAR(50), 
			@Password NVARCHAR(50)
	/* Yes, there are multiple records in the UserMaster for a UserLogin.  This should be corrected.  */

	DECLARE @Userid INT;

	SELECT TOP 1
			@Userid = UM.UserId
		FROM TCD.UserMaster AS UM WITH (READUNCOMMITTED)
		WHERE UM.LoginName = @Userlogin
		  AND BINARY_CHECKSUM(UM.Password) = BINARY_CHECKSUM(@Password)
		  AND UM.IsActive = 1

	IF @@Rowcount = 0
		BEGIN
			SELECT
					0 AS UserID, 
					'First Name' AS FirstName, 
					'Last Name' AS LastName, 
					'Authentication Failed' AS FullName, 
					'Login Name' AS LoginName, 
					1 AS LanguageID, 
					'English' AS Name, 
					000000 AS Phone, 
					0 AS UOMID, 
					'No Email' AS Email, 
					0 AS EcolabAccountNumber, 
					0 AS RegionId, 
					'False' AS IsActive, 
					'Authentication Failed' AS ErrorMessage
		END;
	ELSE
		BEGIN

			UPDATE TCD.UserMaster SET
					UserMaster.LastLoggedin = GETUTCDATE()
				WHERE UserMaster.UserId = @Userid

			SELECT
					UM.UserId, 
					UM.FirstName, 
					UM.LastName, 
					UM.FirstName + ' ' + UM.LastName AS FullName, 
					UM.LoginName, 
					UM.LanguageId, 
					LM.Name, 
					UM.Phone, 
					UM.UOMID, 
					UM.Email, 
					P.EcolabAccountNumber, 
					P.RegionId, 
					UM.IsActive, 
					'' AS ErrorMessage
				FROM TCD.UserMaster AS UM WITH (READUNCOMMITTED)
					 INNER JOIN TCD.LanguageMaster AS LM WITH (READUNCOMMITTED)ON LM.LanguageId = UM.LanguageId
					 INNER JOIN TCD.UserProfile AS UP WITH (READUNCOMMITTED)ON UP.UserId = UM.UserId
					 INNER JOIN TCD.Plant AS P WITH (READUNCOMMITTED)ON P.EcolabAccountNumber = UP.EcolabAccountNumber
				WHERE UM.UserId = @Userid
		END
END;