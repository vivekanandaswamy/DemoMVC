/*
History-
Feb. 2016		mrayalla@allianceglobalservice.com		created prepared statement
*/
BEGIN

	SET NOCOUNT ON


	DECLARE @Returnvalue INT = 0, 
			@Isactive BIT, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL, 
			@Maximumchemicalcount TINYINT = NULL, 
			@Distinctchemicalcount TINYINT = NULL, 
			@Controllertypeid INT, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Newcontrollerequipmentsetupid INT = NULL

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
	SET @Outputlastmodifiedtimestampatlocal = @Currentutctime
	SET @Outputcontrollerequipmentsetupid = ISNULL(@Outputcontrollerequipmentsetupid, NULL)



	SELECT
			@Maximumchemicalcount = CMCTM.MaximumChemicalCount, 
			@Controllertypeid = CC.ControllerTypeId
		FROM TCD.ConduitController AS CC
			 JOIN TCD.ControllerModelControllerTypeMapping AS CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
																   AND CC.ControllerTypeId = CMCTM.ControllerTypeId
		WHERE CC.ControllerId = @Controllerid
		  AND CC.EcoalabAccountNumber = @Ecolabaccountnumber
	SET @Maximumchemicalcount = 30 -- Added dummy value by srikanth, at times we are getting this value as 1, so that user is not able to add pumps more than 1. //Lemuel handled how many pumps should display based on the configuration so this check is useless.

	SET @Isactive = CASE
						WHEN @Productid IS NULL THEN 'FALSE'
						ELSE 'TRUE'
															END

	DECLARE @Moduletype INT = 4, 
			@Defaultfrequency INT = 60, 
			@Tagtypelfs VARCHAR(100) = 'Tag_NML', 
			@Tagtypekfactor VARCHAR(100) = 'Tag_PPOL', 
			@Tagtypecalibration VARCHAR(100) = 'Tag_OPSL', 
			@Result1 INT = NULL, 
			@Result2 INT = NULL, 
			@Result3 INT = NULL, 
			@Type INT = 4, 
			@Roleid INT = (SELECT
								   UR.LevelId
							   FROM TCD.UserMaster AS UM
									INNER JOIN TCD.UserInRole AS UIR ON UM.UserId = UIR.UserId
																	AND UM.EcoLabAccountNumber = UIR.EcoLabAccountNumber
									INNER JOIN TCD.UserRoles AS UR ON UIR.RoleId = UR.RoleId
							   WHERE UM.UserId = @Userid
								 AND UM.EcolabAccountNumber = @Ecolabaccountnumber)

	IF EXISTS(SELECT
					  1
				  FROM TCD.ControllerEquipmentSetup AS CES
				  WHERE CES.ControllerId = @Controllerid
					AND CES.ControllerEquipmentId = @Controllerequipmentid
					AND CES.EcoLabAccountNumber = @Ecolabaccountnumber)
		BEGIN
				--Proceed, since it's for a disconnected scenario
			SELECT
					@Distinctchemicalcount = COUNT(DISTINCT D.ProductId)	--distinct count
				FROM(SELECT
							 @Productid AS ProductId					--being assigned
						UNION
					 SELECT DISTINCT
							 ProductId AS ProductId					--already assigned
						 FROM TCD.ControllerEquipmentSetup
						 WHERE EcoLabAccountNumber = @Ecolabaccountnumber
						   AND ControllerId = @Controllerid
						   AND ControllerEquipmentId <> @Controllerequipmentid
						   AND ProductId <> @Productid)AS D

			IF @Distinctchemicalcount > @Maximumchemicalcount
				BEGIN
					SET @Errorid = 51000
					SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) +N' Maximum chemical count exceeded. Cannot assign new chemical'

					RAISERROR(@Errormessage, 16, 1)
					SET @Returnvalue = -1
					--RETURN @Returnvalue
				END
				
			DECLARE @Pumpid INT = (SELECT
										   ControllerEquipmentSetupId
									   FROM TCD.ControllerEquipmentSetup
									   WHERE ControllerId = @Controllerid
										 AND ControllerEquipmentId = @Controllerequipmentid
										 AND EcoLabAccountNumber = @Ecolabaccountnumber)

			IF @Roleid = 8
					BEGIN
					IF @Lfschemicalnametag IS NOT NULL
				   AND @Lfschemicalnametag <> ''
						BEGIN EXEC @Result1 = TCD.CheckDuplicateTag @Ecolabaccountnumber, @Lfschemicalnametag, @Controllerid, @Pumpid, @Type
							IF @Result1 = 0
								BEGIN
									SET @Errormessage = '801,'
								END
							END
					IF @Kfactortag IS NOT NULL
				   AND @Kfactortag <> ''
						BEGIN EXEC @Result2 = TCD.CheckDuplicateTag @Ecolabaccountnumber, @Kfactortag, @Controllerid, @Pumpid, @Type
							IF @Result2 = 0
								BEGIN
									SET @Errormessage = @Errormessage + '802,'
								END
								END
					IF @Calibrationtag IS NOT NULL
				   AND @Calibrationtag <> ''
						BEGIN EXEC @Result3 = TCD.CheckDuplicateTag @Ecolabaccountnumber, @Calibrationtag, @Controllerid, @Pumpid, @Type
							IF @Result3 = 0
								BEGIN
									SET @Errormessage = @Errormessage + '803,'
								END
					END
					END
			SET @Errormessage = @Errormessage + CONVERT(VARCHAR(100), '')

			IF @Errormessage <> ''
				BEGIN
					RAISERROR(@Errormessage, 16, 1)
				END
				ELSE
					BEGIN
					BEGIN TRY
						BEGIN TRAN

						UPDATE TCD.ControllerEquipmentSetup SET
								ProductId = @Productid, 
								 IsActive      =   @IsActive          
								 , LfsChemicalName    =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
								 , KFactor      =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
								 , PumpCalibration    =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
				
								 , TunnelHold     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
								 , FlowDetectorType    =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN(2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END   
								 , FlowSwitchNumber    =    @FlowSwitchNumber  
								 , FlowSwitchAlarm    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
								 , FlowMeterAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
								 , FlowMeterType     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
								 , FlowAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay ELSE NULL END ELSE NULL END          
								 , FlowMeterPumpDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
								 , FlowMeterAlarmDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
								 , ControllerEquipmentTypeModelId =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
								     , ConventionalWasherGroupConnection =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
								     , AxillaryPumpCalibration   =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
								     , FlowmeterSwitchActivated   =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
								     , FlushWhileDosing     =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
								     , WeightControlledDosage    =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
								     , EquipmentDoseAlone       =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
								     , LowLevelAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
								     , LeakageAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
								     , FlushTime         =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
								     , PumpingTime        =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
								     , PreFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
								     , NightFlushPauseTime       =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
								     , NightFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime        ELSE NULL END          
								     , AcceptedDeviation       =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
								     , LineNumber        =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE 0 END          
								     , MaximumDosingTime    =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
								 , FlowSwitchTimeOut    =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END       
								, ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END        

								 , LastModifiedByUserId   =   @UserId          
								--** Adding a part of integration with Synch./Central -->          
								 , LastModifiedTime    =   @CurrentUTCTime                  
							       , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
							 , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
							       , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
							       , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
							       , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
							       , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE 0 END             
							       , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE 0 END        
							    , FlushTimeForFlushValve = @FlushTimeForFlushValve   
							       , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
							       , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END          
							       , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
							       , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
							       , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END
							WHERE
								ControllerId = @Controllerid
							AND ControllerEquipmentId = @Controllerequipmentid
							AND EcoLabAccountNumber = @Ecolabaccountnumber

						SET @Errorid = @@Error

						IF @Errorid <> 0
									BEGIN
								IF @@Trancount > 0
									BEGIN
											ROLLBACK
									END

								SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) + N' Error occurred updating Equipment data'

								RAISERROR(@Errormessage, 16, 1)
								SET @Returnvalue = -1
								--RETURN @Returnvalue
									END

								---Tags---
						IF @Roleid = 8
									BEGIN
								IF @Isactive = 'TRUE'
													BEGIN
															--1st if-else...
										IF NOT EXISTS(SELECT
															  1
														  FROM TCD.ModuleTags
														  WHERE EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND Active = 1
															AND TagType = @Tagtypelfs)
																	BEGIN
												IF @Lfschemicalnametag IS NOT NULL
											   AND @Lfschemicalnametag <> ''
													BEGIN
														INSERT INTO TCD.ModuleTags(
																EcolabAccountNumber, 
																TagType, 
																TagAddress, 
																ModuleTypeId, 
																ModuleID, 
																DeadBand, 
																Active)
															VALUES
																   (
																	@Ecolabaccountnumber, 
																	@Tagtypelfs, 
																	@Lfschemicalnametag, 
																	@Moduletype, 
																	@Pumpid, 
																	@Defaultfrequency, 
																	1)
																	END
											END
															ELSE
											BEGIN
												IF @Lfschemicalnametag IS NOT NULL
											   AND @Lfschemicalnametag <> ''
													BEGIN
														UPDATE TCD.ModuleTags SET
																TagAddress = @Lfschemicalnametag
															WHERE
																EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND TagType = @Tagtypelfs
															AND Active = 1
													END
															ELSE
													BEGIN
														UPDATE TCD.ModuleTags SET
																Active = 0
															WHERE
																EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND TagType = @Tagtypelfs
															AND Active = 1
													END
											END

															--2nd if-else...
										IF NOT EXISTS(SELECT
															  1
														  FROM TCD.ModuleTags
														  WHERE EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND Active = 1
															AND TagType = @Tagtypekfactor)
																	BEGIN
												IF @Kfactortag IS NOT NULL
											   AND @Kfactortag <> ''
													BEGIN
														INSERT INTO TCD.ModuleTags(
																EcolabAccountNumber, 
																TagType, 
																TagAddress, 
																ModuleTypeId, 
																ModuleID, 
																DeadBand, 
																Active)
															VALUES
																   (
																	@Ecolabaccountnumber, 
																	@Tagtypekfactor, 
																	@Kfactortag, 
																	@Moduletype, 
																	@Pumpid, 
																	@Defaultfrequency, 
																	1)
																	END
											END
															ELSE 
											BEGIN
												IF @Kfactortag IS NOT NULL
											   AND @Kfactortag <> ''
													BEGIN
														UPDATE TCD.ModuleTags SET
																TagAddress = @Kfactortag
															WHERE
																EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND TagType = @Tagtypekfactor
															AND Active = 1
													END
															ELSE
													BEGIN
														UPDATE TCD.ModuleTags SET
																Active = 0
															WHERE
																EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND TagType = @Tagtypekfactor
															AND Active = 1
													END
											END

															--3rd if-else...
										IF NOT EXISTS(SELECT
															  1
														  FROM TCD.ModuleTags
														  WHERE EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND Active = 1
															AND TagType = @Tagtypecalibration)
											BEGIN
												IF @Calibrationtag IS NOT NULL
											   AND @Calibrationtag <> ''
																	BEGIN
														INSERT INTO TCD.ModuleTags(
																EcolabAccountNumber, 
																TagType, 
																TagAddress, 
																ModuleTypeId, 
																ModuleID, 
																DeadBand, 
																Active)
															VALUES
																   (
																	@Ecolabaccountnumber, 
																	@Tagtypecalibration, 
																	@Calibrationtag, 
																	@Moduletype, 
																	@Pumpid, 
																	@Defaultfrequency, 
																	1)
													END
																	END
															ELSE 
											BEGIN
												IF @Calibrationtag IS NOT NULL
											   AND @Calibrationtag <> ''
													BEGIN
														UPDATE TCD.ModuleTags SET
																TagAddress = @Calibrationtag
															WHERE
																EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND TagType = @Tagtypecalibration
															AND Active = 1
													END
															ELSE
													BEGIN
														UPDATE TCD.ModuleTags SET
																Active = 0
															WHERE
																EcolabAccountNumber = @Ecolabaccountnumber
															AND ModuleID = @Pumpid
															AND ModuleTypeId = @Moduletype
															AND TagType = @Tagtypecalibration
															AND Active = 1
													END
											END
													END	--@IsActive = 'TRUE'
											ELSE
													BEGIN	--Can be combined into 1 update stmt. ...
										UPDATE TCD.ModuleTags SET
														Active = 0
											WHERE
														EcolabAccountNumber = @Ecolabaccountnumber
													AND ModuleID = @Pumpid
													AND ModuleTypeId = @Moduletype
													AND TagType = @Tagtypelfs
													AND Active = 1
										UPDATE TCD.ModuleTags SET
												Active = 0
											WHERE
												EcolabAccountNumber = @Ecolabaccountnumber
											AND ModuleID = @Pumpid
											AND ModuleTypeId = @Moduletype
											AND TagType = @Tagtypekfactor
											AND Active = 1
										UPDATE TCD.ModuleTags SET
												Active = 0
											WHERE
												EcolabAccountNumber = @Ecolabaccountnumber
											AND ModuleID = @Pumpid
											AND ModuleTypeId = @Moduletype
											AND TagType = @Tagtypecalibration
											AND Active = 1
													END
									END
								---Tags---			
							
								--SELECT	TOP	1
								--		@OutputControllerEquipmentSetupId	=	O.ControllerEquipmentSetupId
								--FROM	@OutputList			O

						IF @@Trancount > 0
							BEGIN
									COMMIT
							END
					END TRY
					BEGIN CATCH
						IF @@Trancount > 0
							BEGIN
									ROLLBACK
							END
							
								SELECT	--@ErrorNumber				=		ERROR_NUMBER()
								@Errormessage = ERROR_MESSAGE(), 
								@Errorprocedure = ERROR_PROCEDURE(), 
								@Errorseverity = ERROR_SEVERITY()
							
								--SET		@OutputControllerEquipmentSetupId
								--									=		NULL
						SET @Returnvalue = -1
						SET @Messagestring = N'An error occured while Updating Pump/Valve details. The error is: ' + @Errormessage + '	' +'Module: ' + @Errorprocedure
							
						RAISERROR(@Messagestring, @Errorseverity, 1)
					END CATCH
					END
		END
ELSE
		BEGIN
			DECLARE @Newpumpid INT = NULL
			SELECT
					@Distinctchemicalcount = COUNT(DISTINCT D.ProductId)	--distinct count
				FROM(SELECT
							 @Productid AS ProductId					--being assigned
						UNION
					 SELECT DISTINCT
							 ProductId AS ProductId					--already assigned
						 FROM TCD.ControllerEquipmentSetup
						 WHERE EcoLabAccountNumber = @Ecolabaccountnumber
						   AND ControllerId = @Controllerid
						   AND ProductId <> @Productid)AS D

			IF @Distinctchemicalcount > @Maximumchemicalcount
				BEGIN
					SET @Errorid = 51000
					SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) +N' Maximum chemical count exceeded. Cannot assign new chemical'

					RAISERROR(@Errormessage, 16, 1)
					SET @Returnvalue = -1
					--RETURN @Returnvalue
				END

			IF @Roleid = 8
								BEGIN
					IF @Lfschemicalnametag IS NOT NULL
				   AND @Lfschemicalnametag <> ''
						BEGIN EXEC @Result1 = TCD.CheckDuplicateTag @Ecolabaccountnumber, @Lfschemicalnametag, @Controllerid
							IF @Result1 = 0
										BEGIN
									SET @Errormessage = '801,'
										END
								END
					IF @Kfactortag IS NOT NULL
				   AND @Kfactortag <> ''
						BEGIN EXEC @Result2 = TCD.CheckDuplicateTag @Ecolabaccountnumber, @Kfactortag, @Controllerid
							IF @Result2 = 0
										BEGIN
									SET @Errormessage = @Errormessage + '802,'
										END
								END
					IF @Calibrationtag IS NOT NULL
				   AND @Calibrationtag <> ''
						BEGIN EXEC @Result3 = TCD.CheckDuplicateTag @Ecolabaccountnumber, @Calibrationtag, @Controllerid
							IF @Result3 = 0
								BEGIN
									SET @Errormessage = @Errormessage + '803,'
								END
							END
								END

			SET @Errormessage = @Errormessage + CONVERT(VARCHAR(100), '')
			IF @Errormessage <> ''
				BEGIN
					RAISERROR(@Errormessage, 16, 1)
				END
				ELSE
					BEGIN
					BEGIN TRY
						SET @Newcontrollerequipmentsetupid = (SELECT
																	  ISNULL(MAX(CES.ControllerEquipmentSetupId), 0) + 1
																  FROM TCD.ControllerEquipmentSetup AS CES
																  WHERE CES.EcolabAccountNumber = @Ecolabaccountnumber)
						BEGIN TRAN

						INSERT TCD.ControllerEquipmentSetup(
								EcoLabAccountNumber 
							,	ControllerEquipmentSetupId         
						    ,    ControllerId          
						    ,    ControllerEquipmentId          
						    ,    ControllerEquipmentTypeId          
						    ,    ProductId          
						    ,    IsActive          
						    ,    LfsChemicalName          
						    ,    KFactor          
						    ,    PumpCalibration          
						    ,    TunnelHold          
						    ,    FlowDetectorType     
						    ,     FlowSwitchNumber       
						    ,    FlowSwitchAlarm          
						    ,    FlowMeterAlarm          
						    ,    FlowMeterType          
						    ,    FlowAlarmDelay          
						    ,    FlowMeterPumpDelay          
						    ,    FlowMeterAlarmDelay          
						    , ControllerEquipmentTypeModelId           
						    , ConventionalWasherGroupConnection           
						    , AxillaryPumpCalibration             
						    , FlowmeterSwitchActivated             
						    , FlushWhileDosing               
						    , WeightControlledDosage              
						    , EquipmentDoseAlone                 
						    , LowLevelAlarm                    
						    , LeakageAlarm                    
						    , FlushTime                   
						    , PumpingTime                  
						    , PreFlushTime                  
						    , NightFlushPauseTime                 
						    , NightFlushTime                  
						    , AcceptedDeviation                 
						    , LineNumber                 
						    , MaximumDosingTime              
						    , FlowSwitchTimeOut   
						   , ValveOutputAsTom         
						    , LastModifiedByUserId            
						   --** Adding a part of integration with Synch./Central -->          
						    , LastModifiedTime          
						    , FlushValveNumber              
						   , CalibrationConductSS_Tank           
						   , BackFlowControl                
						   , FactorFM_B_FM                    
						   , AcceptedDeviationRingLine           
						   , UsePumpOfGroup1ForTunnel             
						   , pHSensorEnabled      
						, FlushTimeForFlushValve    
						   , Concentration       
						   , Deadband      
						    , MinimumFlowRate 
					      , ProductDensity 
					      , MaximumConcentration)
							--OUTPUT	inserted.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
							--	,	inserted.LastModifiedTime					AS			LastModifiedTime
							--INTO	@OutputList	(
							--		ControllerEquipmentSetupId
							--	,	LastModifiedTimestamp
							--	)
							--**	<--
						SELECT
								 @EcoLabAccountNumber    AS   EcoLabAccountNUmber  
								,@Newcontrollerequipmentsetupid	        
							    , @ControllerId      AS   ControllerEquipmentId          
							    , @ControllerEquipmentId    AS   ControllerEquipmentId          
							    , @ControllerEquipmentTypeId   AS   ControllerEquipmentTypeId          
							    , @ProductId      AS   ProductId          
							    , @IsActive       AS   IsActive          

							    , LfsChemicalName     =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
							    , KFactor       =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
							    , PumpCalibration     =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
				
							    , TunnelHold      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
							    , FlowDetectorType     =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN (2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END          
							    , FlowSwitchNumber        =    @FlowSwitchNumber  
							    , FlowSwitchAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
							  , FlowMeterAlarm      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
							    , FlowMeterType      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
							    , FlowAlarmDelay      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay  ELSE NULL END ELSE NULL END          
							    , FlowMeterPumpDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
							    , FlowMeterAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
							    , ControllerEquipmentTypeModelId  =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
							    , ConventionalWasherGroupConnection      =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
							    , AxillaryPumpCalibration        =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
							    , FlowmeterSwitchActivated        =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
							    , FlushWhileDosing          =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
							    , WeightControlledDosage         =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
							    , EquipmentDoseAlone            =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
							    , LowLevelAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
							    , LeakageAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
							    , FlushTime              =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
							    , PumpingTime             =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
							    , PreFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
							    , NightFlushPauseTime            =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
							    , NightFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime  ELSE NULL END          
							    , AcceptedDeviation            =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
							    , LineNumber           =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE NULL END          
							    , MaximumDosingTime         =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
							    , FlowSwitchTimeOut     =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END         
							   , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END     

							    --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterSwitchFlag ELSE NULL END AS FlowMeterSwitchFlag           
							    --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterCalibration ELSE NULL END AS FlowMeterCalibration          
							    --, CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime ELSE NULL END AS MaximumDosingTime          
							    --, CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut ELSE NULL END AS FlowSwitchTimeOut          
							    , @UserId        AS   LastModifiedByUserId          
								--Synch./Central integration additions
							    , @CurrentUTCTime      AS   LastModifiedTime          
							   , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
							   , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
							   , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
							   , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
							   , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
							   , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE 0 END             
							   , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE 0 END    
							, FlushTimeForFlushValve = @FlushTimeForFlushValve     
							   , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
							   , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END       
							    , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
							   , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
							   , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END 
					
						SET @Newpumpid = @Newcontrollerequipmentsetupid					--	SCOPE_IDENTITY() 
					
								---Tags---
						IF @Roleid = 8
							BEGIN
								IF @Isactive = 'TRUE'
									BEGIN
										IF @Lfschemicalnametag IS NOT NULL
									   AND @Lfschemicalnametag <> ''
												BEGIN
												INSERT INTO TCD.ModuleTags(
														EcolabAccountNumber, 
														TagType, 
														TagAddress, 
														ModuleTypeId, 
														ModuleId, 
														DeadBand, 
														Active)
													VALUES
														   (
															@Ecolabaccountnumber, 
															@Tagtypelfs, 
															@Lfschemicalnametag, 
															@Moduletype, 
															@Newpumpid, 
															@Defaultfrequency, 
															1)
											END

										IF @Kfactortag IS NOT NULL
									   AND @Kfactortag <> ''
											BEGIN
												INSERT INTO TCD.ModuleTags(
														EcolabAccountNumber, 
														TagType, 
														TagAddress, 
														ModuleTypeId, 
														ModuleId, 
														DeadBand, 
														Active)
													VALUES
														   (
															@Ecolabaccountnumber, 
															@Tagtypekfactor, 
															@Kfactortag, 
															@Moduletype, 
															@Newpumpid, 
															@Defaultfrequency, 
															1)
											END

										IF @Calibrationtag IS NOT NULL
									   AND @Calibrationtag <> ''
											BEGIN
												INSERT INTO TCD.ModuleTags(
														EcolabAccountNumber, 
														TagType, 
														TagAddress, 
														ModuleTypeId, 
														ModuleId, 
														DeadBand, 
														Active)
													VALUES
														   (
															@Ecolabaccountnumber, 
															@Tagtypecalibration, 
															@Calibrationtag, 
															@Moduletype, 
															@Newpumpid, 
															@Defaultfrequency, 
															1)
											END
												END
									END
								---Tags---
						SET @Errorid = @@Error
						IF @Errorid <> 0
							BEGIN
								IF @@Trancount > 0
									BEGIN
											ROLLBACK
									END

								SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) +N' Error occurred associating Equipment to Controller'

								RAISERROR(@Errormessage, 16, 1)
								SET @Returnvalue = -1
								--RETURN @Returnvalue
							END

								--SELECT	TOP	1
								--		@OutputControllerEquipmentSetupId	=	O.ControllerEquipmentSetupId
								--FROM	@OutputList			O

						IF @@Trancount > 0
							BEGIN
									COMMIT
							END
					END TRY
					BEGIN CATCH
						IF @@Trancount > 0
							BEGIN
									ROLLBACK
							END
							
								SELECT	--@ErrorNumber				=		ERROR_NUMBER()
								@Errormessage = ERROR_MESSAGE(), 
								@Errorprocedure = ERROR_PROCEDURE(), 
								@Errorseverity = ERROR_SEVERITY()
							
								--SET		@OutputControllerEquipmentSetupId
								--									=		NULL
						SET @Returnvalue = -1
						SET @Messagestring = N'An error occured while Updating Pump/Valve details. The error is: ' + @Errormessage + '	' +'Module: ' + @Errorprocedure
							
						RAISERROR(@Messagestring, @Errorseverity, 1)
					END CATCH
					END
		END

		-------------------------------------------
  IF((SELECT CONTROLLERMODELID FROM TCD.ConduitController WHERE ControllerId=@ControllerId AND EcoalabAccountNumber = @EcoLabAccountNumber)='11')
  BEGIN
	IF(@ControllerEquipmentTypeId=2 AND @ControllerEquipmentId IN(13,14,27,28))
	BEGIN

		UPDATE TCD.ControllerEquipmentSetup  SET CalibrationConductSS_Tank=@CalibrationConductSS_Tank
		WHERE EcoLabAccountNumber=@EcoLabAccountNumber AND	ControllerId=@ControllerId AND ControllerEquipmentTypeId=@ControllerEquipmentTypeId
		AND ControllerEquipmentId=CASE WHEN @ControllerEquipmentId=13 THEN 27 
								   WHEN @ControllerEquipmentId=27 THEN 13  	
								   WHEN @ControllerEquipmentId=14 THEN 28
								   WHEN @ControllerEquipmentId=28 THEN 14 END 
					END
		END
  -------------------------------------------

	--IF @Errorid = 0
	--BEGIN
	--	--GOTO	ExitModule

	--		--RETURN @Returnvalue
	--	END

	SET NOCOUNT OFF
	--RETURN @Returnvalue


END
