/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
	BEGIN
		SET NOCOUNT ON;

		DECLARE @Userid INT = NULL;
		SELECT
				@Userid = NULL;

		SELECT
				@Userid = UserId
			FROM TCD.UserMaster
			WHERE LoginName = @Loginname
				AND IsActive = 1
				AND EcolabAccountNumber = @Ecolabaccountnumber;

		SELECT DISTINCT
				r.LevelID AS RoleId, 
				r.RoleName, 
				r.code
			FROM TCD.UserRoles AS r
				 INNER JOIN TCD.UserInRole AS ur ON r.RoleId = ur.RoleId
			WHERE ur.UserId = @Userid
				AND ur.IsDeleted = 0
			ORDER BY
				r.RoleName;
		SET NOCOUNT OFF;
	END;