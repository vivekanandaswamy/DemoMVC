BEGIN
    --SET NOCOUNT ON;
	DECLARE @Output VARCHAR(100) = '';
	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Newuseridtobeinserted INT = NULL, 
			@Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL

	DECLARE @Outputlist AS TABLE(
			UserId INT, 
			LastModifiedTimestamp DATETIME)
	SET @Scope = ISNULL(@Scope, NULL)
	SET @Outputuserid = ISNULL(@Outputuserid, NULL)

	IF @Contactid IS NOT NULL
   AND EXISTS(SELECT
					  1 FROM TCD.UserMaster WHERE ContactId = @Contactid
			   AND IsActive = 1 AND EcolabAccountNumber = @Ecolabaccountnumber)
	   BEGIN
			SET @Output = '302';
			SET @Scope = @Output;
			SELECT
					@Scope;
	   END;
    ELSE
	   BEGIN
			IF EXISTS(SELECT
							  1 FROM TCD.UserMaster WHERE LoginName = @Loginname
					  AND IsActive = 1 AND EcolabAccountNumber = @Ecolabaccountnumber)
			 BEGIN
					BEGIN
						SET @Output = '301';
						SET @Scope = @Output;
						SELECT
								@Scope;
				END;
			 END;
			IF EXISTS (SELECT 1 FROM TCD.UserMaster WHERE Email = @MailId AND ISACTIVE=1)
				  BEGIN
					BEGIN Set @OutPut = '501'   
					SET @Scope = @OutPut 
					Select @Scope  
					END
				 END
		  ELSE
			 BEGIN
					IF @Contactid IS NOT NULL
				    BEGIN
							UPDATE TCD.PlantContact SET
									ContactFirstName = @Firstname, 
									ContactLastName = @Lastname, 
									ContactEmail = @Mailid, 
									ContactMobilePhone = @Contactno, 
									LastModifiedByUserId = @Userid
								WHERE
									ID = @Contactid
								AND EcolabAccountNumber = @Ecolabaccountnumber;

							SET @Newuseridtobeinserted = (SELECT
																  ISNULL(MAX(UM.UserId), 0) + 1
															  FROM TCD.UserMaster AS UM
															  WHERE UM.EcolabAccountNumber = @Ecolabaccountnumber)
							INSERT INTO TCD.UserMaster(
					   UserId,
					   FirstName,
					   LastName,
					   FullName,
					   LoginName,
					   Password,
					   LanguageId,
					   IsActive,
					   LastModifiedByUserId,
					   EcolabAccountNumber,
					   ContactId,
					   CurrencyCode,
					   UOMId)
					   OUTPUT
									inserted.UserId AS Id, 
									inserted.LastModifiedTime AS LastModifiedTimestamp
								   INTO @Outputlist(
									UserId, 
									LastModifiedTimestamp)
								VALUES
									   (
										@Newuseridtobeinserted, 
										@Firstname, 
										@Lastname, 
										@Firstname + ' ' + @Lastname, 
										@Loginname, 
							@Password,
										(SELECT
												 LanguageId FROM TCD.Plant WHERE EcolabAccountNumber = @Ecolabaccountnumber), 
							1,
										@Userid, 
										@Ecolabaccountnumber, 
										@Contactid, 
										@Currencycode, 
										@Uomid);
				    END
				ELSE
				    BEGIN
							SET @Newuseridtobeinserted = (SELECT
																  ISNULL(MAX(UM.UserId), 0) + 1
															  FROM TCD.UserMaster AS UM
															  WHERE UM.EcolabAccountNumber = @Ecolabaccountnumber)
							INSERT INTO TCD.UserMaster(
											 UserId,
											 FirstName,
											 LastName,
											 FullName,
											 LoginName,
											 Password,
											 Email,
											 Phone,
											 LanguageId,
											 IsActive,
											 LastModifiedByUserId,
											 EcolabAccountNumber,
											 CurrencyCode,
											UOMId)
						OUTPUT
									inserted.UserId AS Id, 
									inserted.LastModifiedTime AS LastModifiedTimestamp
								   INTO @Outputlist(
									UserId, 
									LastModifiedTimestamp)
								VALUES
									   (
										@Newuseridtobeinserted, 
										@Firstname, 
										@Lastname, 
										@Firstname + ' ' + @Lastname, 
										@Loginname, 
								@Password,
										@Mailid, 
										@Contactno, 
										(SELECT
												 LanguageId FROM TCD.Plant WHERE EcolabAccountNumber = @Ecolabaccountnumber), 
								1,
										@Userid, 
										@Ecolabaccountnumber, 
										@Currencycode, 
										@Uomid);
				   END
					DECLARE @Newusernumber INT = SCOPE_IDENTITY();
					INSERT INTO TCD.UserInRole(
									   EcoLabAccountNumber,
									   UserId,
									   RoleId,
									   LastModifiedByUserId)
						VALUES
							   (
								@Ecolabaccountnumber, 
								@Newuseridtobeinserted, 
								@Roleid, 
								@Userid);
			 END;
	   END;
   -- SET NOCOUNT OFF;

	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputuserid = O.UserId
		FROM @Outputlist AS O

	--RETURN @Returnvalue
END;