
  BEGIN 
	SET NOCOUNT ON;
	DECLARE @Output VARCHAR(100) = ''
	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Newuseridtobeinserted INT = NULL, 
			@Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL
  
	DECLARE @Outputlist AS TABLE(
			UserId INT, 
			LastModifiedTimestamp DATETIME)
	
	SET @Scope = ISNULL(@Scope, NULL)
	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)
	SET @Outputuserid = ISNULL(@Outputuserid, NULL)

	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.UserMaster AS UM
					  WHERE UM.IsActive = 'TRUE'
						AND UM.LoginName = @Loginname
						AND UM.UserId != @Usernumber
						AND UM.EcolabAccountNumber = @Ecolabaccountnumber)
	  BEGIN
			DECLARE @Contactid INT = (SELECT
											  UM.ContactId
										  FROM TCD.UserMaster AS UM
										  WHERE UM.UserId = @Usernumber
											AND UM.EcolabAccountNumber = @Ecolabaccountnumber);
			IF @Contactid IS NOT NULL
		BEGIN
					UPDATE TCD.PlantContact SET
							ContactFirstName = @Firstname, 
							ContactLastName = @Lastname, 
							ContactEmail = @Mailid, 
							ContactMobilePhone = @Contactno, 
							LastModifiedByUserId = @Userid
						WHERE ID = @Contactid
							  AND EcolabAccountNumber = @Ecolabaccountnumber

					UPDATE TCD.UserMaster SET
							LoginName = @Loginname, 
				Password = @Password,
							LastModifiedByUserId = @Userid, 
				LastModifiedTime = GETUTCDATE()
		OUTPUT
							inserted.UserId AS Id, 
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							UserId, 
							LastModifiedTimestamp)
						WHERE UserId = @Usernumber
				  AND EcolabAccountNumber = @Ecolabaccountnumber
		END
		ELSE
		BEGIN
		
			 IF NOT EXISTS(SELECT * FROM TCD.UserMaster WHERE Email = @MailId AND UserId != @UserNumber AND ISACTIVE=1)
				BEGIN
					UPDATE TCD.UserMaster SET
							FirstName = @Firstname, 
							LastName = @Lastname, 
							LoginName = @Loginname, 
				Password = @Password,
							Email = @Mailid, 
							Phone = @Contactno, 
							LastModifiedByUserId = @Userid, 
				LastModifiedTime = GETUTCDATE()
		OUTPUT
							inserted.UserId AS Id, 
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							UserId, 
							LastModifiedTimestamp)
						WHERE UserId = @Usernumber
							  AND EcolabAccountNumber = @Ecolabaccountnumber
							  END
			ELSE
				  BEGIN
						BEGIN Set @OutPut = '501'   
						SET @Scope = @OutPut 
						Select @Scope  
				END
		  END
		END
			UPDATE TCD.UserInRole SET
					UserId = @Usernumber, 
					RoleId = @Roleid, 
					LastModifiedByUserId = @Userid
				WHERE UserId = @Usernumber
					  AND EcoLabAccountNumber = @Ecolabaccountnumber
		 END  
	  ELSE
	  BEGIN
			BEGIN
				SET @Output = '301'
				SET @Scope = @Output
				SELECT
						@Scope
		   	  END
       END

	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputuserid = O.UserId
		FROM @Outputlist AS O

	--RETURN @Returnvalue
	SET NOCOUNT OFF;
  END