
BEGIN
	SET NOCOUNT ON
	SELECT
			UM.UserId, 
			CASE
				WHEN UM.ContactId IS NOT NULL THEN C.ContactFirstName
				ELSE UM.FirstName
			END AS FirstName, 
			CASE
				WHEN UM.ContactId IS NOT NULL THEN C.ContactLastName
				ELSE UM.LastName
			END AS LastName, 
			UM.LoginName, 
			UM.Password, 
			CASE
				WHEN UM.ContactId IS NOT NULL THEN C.ContactEMail
				ELSE UM.Email
			END AS Email, 
			CASE
				WHEN UM.ContactId IS NOT NULL THEN C.ContactMobilePhone
				ELSE UM.Phone
			END AS Phone, 
			UR.RoleId, 
			UM.LanguageId, 
			CASE
				WHEN UM.LanguageId IS NOT NULL THEN(SELECT
															Name FROM TCD.LanguageMaster WHERE LanguageId = UM.LanguageId)
				WHEN UM.LanguageId IS NULL THEN(SELECT
														Name
													FROM TCD.LanguageMaster
													WHERE LanguageId IN(
												SELECT
														LanguageId FROM TCD.Plant WHERE Is_Deleted = 0))
			END AS LanguageName, 
			UR.RoleName, 
			UM.EcolabAccountNumber, 
			UM.Title, 
			UM.Mobile, 
			UM.Fax, 
			UM.ContactId, 
			CASE
				WHEN UM.UOMid IS NOT NULL THEN(SELECT TOP (1)
													   UOMID
												   FROM TCD.USERMASTER
												   WHERE UserId = Um.UserId
													 AND EcolabAccountNumber = @Ecolabaccountnumber
													 AND UOMId IS NOT NULL)
				WHEN UM.UOMID IS NULL THEN(SELECT TOP (1)
												   UOMID
											   FROM TCD.PLANT
											   WHERE IS_DELETED = 0
												 AND ECOLABACCOUNTNUMBER = @Ecolabaccountnumber)
			END AS UOMid, 
			CASE
				WHEN UM.CurrencyCode IS NOT NULL THEN(SELECT TOP (1)
															  CurrencyCode
														  FROM TCD.USERMASTER
														  WHERE UserId = @Usernumber
															AND EcolabAccountNumber = @Ecolabaccountnumber)
				WHEN UM.CurrencyCode IS NULL THEN(SELECT TOP (1)
														  TCD.PLANT.CurrencyCode
													  FROM TCD.PLANT
													  WHERE IS_DELETED = 0
														AND ECOLABACCOUNTNUMBER = @Ecolabaccountnumber)
			END AS CurrencyCode, 
			UM.IsActive, 
			UM.LastModifiedTime, 
			UM.LastSyncTime,
			UR.LevelId as MaxLevel
		FROM TCD.UserMaster AS UM
			 LEFT JOIN TCD.PlantContact AS C ON UM.ContactId = C.ID
											AND C.EcolabAccountNumber = UM.EcolabAccountNumber
			 INNER JOIN TCD.UserInRole AS UI ON UM.UserId = UI.UserId
											AND UM.EcolabAccountNumber = UI.EcoLabAccountNumber
			 INNER JOIN TCD.UserRoles AS UR ON UI.RoleId = UR.RoleId
		WHERE UM.EcolabAccountNumber = @Ecolabaccountnumber 
			  --AND UM.IsActive=1
		  AND CASE ISNULL(@Usernumber, '')
				  WHEN '' THEN 'TRUE'
				  ELSE CASE
						   WHEN UM.UserId = @Usernumber THEN 'TRUE'
					   END
			  END = 'TRUE'
		ORDER BY
			UM.UserId
	SET NOCOUNT OFF
END