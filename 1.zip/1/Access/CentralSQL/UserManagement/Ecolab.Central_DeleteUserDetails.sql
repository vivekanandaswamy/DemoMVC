
  BEGIN 
	  SET NOCOUNT ON;
	DECLARE @Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N''


	DECLARE @Outputlist AS TABLE(
			LastModifiedTimestamp DATETIME)

	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)

	IF @Lastmodifiedtimestampatcentral IS NOT NULL
   AND NOT EXISTS(SELECT
						  1
					  FROM TCD.UserMaster AS UM
					  WHERE UM.EcolabAccountNumber = @Ecolabaccountnumber
						AND UM.UserId = @Usernumber
						AND UM.LastModifiedTime = @Lastmodifiedtimestampatcentral)
	BEGIN
			SET @Errorid = 60000
			SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR)
			RAISERROR(@Errormessage, 16, 1)
			SET @Returnvalue = -1
			--RETURN @Returnvalue
	END

	UPDATE TCD.UserMaster SET
			IsActive = 0, 
			LastModifiedByUserId = @Userid
	OUTPUT
			inserted.LastModifiedTime AS LastModifiedTimestamp
		   INTO @Outputlist(
			LastModifiedTimestamp)
		WHERE
			UserId = @Usernumber

	UPDATE TCD.UserInRole SET
			IsDeleted = 1, 
			LastModifiedByUserId = @Userid
		WHERE UserId = @Usernumber

	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp
		FROM @Outputlist AS O

	  SET NOCOUNT OFF;
   END