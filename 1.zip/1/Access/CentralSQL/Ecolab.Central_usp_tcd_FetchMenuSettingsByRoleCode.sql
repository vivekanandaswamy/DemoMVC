/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
	BEGIN
		SET NOCOUNT ON;
		BEGIN
			DECLARE @String VARCHAR(MAX) = @Passingrolecode, 
					@Delimiter CHAR(1) = ',', 
					@Row_Count INT, 
					@Parentid INT;
			DECLARE @Temptable TABLE(
					items VARCHAR(MAX));
			IF @String = ''
				BEGIN
					SELECT
							@String = 'N';
				END;
			ELSE
				BEGIN
					SELECT
							@String = @Passingrolecode;
				END;
			BEGIN
				DECLARE @Idx INT;
				DECLARE @Slice VARCHAR(8000);
				SELECT
						@Idx = 1;
				IF LEN(@String) < 1
				OR @String IS NULL
					BEGIN
						RETURN;
					END;
				WHILE @Idx != 0
					BEGIN
						SET @Idx = CHARINDEX(@Delimiter, @String);
						IF @Idx != 0
							BEGIN
								SET @Slice = LEFT(@String, @Idx - 1);
							END;
						ELSE
							BEGIN
								SET @Slice = @String;
							END;
						IF LEN(@Slice) > 0
							BEGIN
								INSERT INTO @Temptable(
										items)
								VALUES
										(
										@Slice);
							END;
						SET @String = RIGHT(@String, LEN(@String) - @Idx);
						IF LEN(@String) = 0
							BEGIN BREAK;
							END;
					END;
				BEGIN
					SELECT
							sectionid AS SectionID, 
							sectionname AS SectionName, 
							UM.sectioncode AS SectionCode, 
							UM.sectiontype AS SectionType, 
							UM.controllername AS ControllerName, 
							UM.viewname AS ViewName, 
							UM.resourceclass AS ResourceClass, 
							UM.resourcekey AS ResourceKey, 
							UM.parentid AS ParentId INTO
							#Role_Menu
						FROM TCD.conduitmenu AS UM
							 INNER JOIN TCD.conduitmenurolemapping AS MR ON Um.sectioncode = mr.sectioncode
						WHERE parentid IS NULL
							OR mr.userrolecode IN(SELECT
														 items FROM @Temptable)
							AND mr.settingvalue = 'true';

					SELECT DISTINCT
							SectionID, 
							SectionName, 
							SectionCode, 
							SectionType, 
							ControllerName, 
							ViewName, 
							ResourceClass, 
							ResourceKey, 
							ParentId
						FROM #Role_Menu;


					DROP TABLE
							#Role_Menu;
				END;
			END;
		END;
	END;