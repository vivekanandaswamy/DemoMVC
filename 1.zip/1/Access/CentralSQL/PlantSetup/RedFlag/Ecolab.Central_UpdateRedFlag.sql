
BEGIN
SET NOCOUNT ON

	DECLARE @Output VARCHAR(100) = '', 
			@Min DECIMAL(18, 3) = NULL, 
			@Max DECIMAL(18, 3) = NULL, 
			@Existingloc INT = NULL, 
			@Existingitem INT = NULL, 
			@Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL, 
			@Errornumber INT = 0,
			@RedFlagMappingId INT;

	DECLARE @Outputlist AS TABLE(
			RedFlagId INT, 
			LastModifiedTimestamp DATETIME)

	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)			--SQLEnlight

	SELECT
																														@Min = RM.MinimumRange
		FROM TCD.RedFlag AS RM
		WHERE Item = @Itemid
		  AND Id = @Id
		  AND EcolabAccountNumber = @Ecolabaccountnumber
	SELECT
			@Max = RM.MaximumRange
		FROM TCD.RedFlag AS RM
		WHERE Item = @Itemid
		  AND Id = @Id
		  AND EcolabAccountNumber = @Ecolabaccountnumber
	SELECT
			@Existingloc = Location
		FROM TCD.RedFlag
		WHERE Id = @Id
		  AND Is_Deleted = 0
		  AND EcolabAccountNumber = @Ecolabaccountnumber
	SELECT
			@Existingitem = Item
		FROM TCD.RedFlag
		WHERE Id = @Id
		  AND Is_Deleted = 0
		  AND EcolabAccountNumber = @Ecolabaccountnumber
	DECLARE @Plantid INT = (SELECT
									MG.Id
								FROM TCD.MachineGroupType AS MGT
									 INNER JOIN TCD.MachineGroup AS MG ON MGT.Id = MG.GroupTypeId
				   WHERE MGT.Id = 1
								  AND MG.Is_Deleted = 0
								  AND MG.EcolabAccountNumber = @Ecolabaccountnumber);
	IF @MeterId IS NOT NULL AND @SensorId IS NOT NULL AND @Locationid > 1
   AND @Machinecompartmentid IS NULL
   AND NOT EXISTS(SELECT
						  *
					  FROM tcd.MachineGroup AS MG
						   LEFT JOIN TCD.Meter AS M ON MG.Id = CASE M.IsPlant
																   WHEN 'TRUE' THEN COALESCE(M.GroupId, @Plantid)
																   ELSE M.GroupId
															   END
												   AND M.EcolabAccountNumber = MG.EcolabAccountNumber
						   LEFT JOIN TCD.Sensor AS S ON MG.Id = CASE S.IsPlant
																	WHEN 'TRUE' THEN COALESCE(S.GroupId, @Plantid)
																	ELSE S.GroupId
																END
													AND S.EcolabAccountNumber = MG.EcolabAccountNumber
					  WHERE(S.SensorId IS NOT NULL
          AND S.Is_deleted = 0
						AND S.MachineCompartment IS NULL
						AND S.EcolabAccountNumber = @Ecolabaccountnumber
						 OR M.MeterId IS NOT NULL
          AND M.Is_deleted = 0
						AND M.MachineCompartment IS NULL
						AND S.EcolabAccountNumber = @Ecolabaccountnumber)
					   AND MG.Id = @Locationid)
		BEGIN
			SET @Scope = '301'
		END
		ELSE
		BEGIN
			IF @Isdirty = 1
   BEGIN
   
					UPDATE TCD.RedFlag SET
							MinimumRange = @Minrange, 
							MaximumRange = @Maxrange, 
							LastModifiedByUserId = @Userid,
							FormulaId = @FormulaId,
							RedFlagCategoryId = @CategoryId,
							Location = @LocationID,
							ProductId = @ProductId,
							MeterId = @MeterId,
							SensorId = @SensorId
					OUTPUT
							inserted.ID AS Id, 
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							RedFlagId, 
							LastModifiedTimestamp)
						FROM TCD.RedFlag
						WHERE
							Item = @Itemid
						AND Id = @Id
						AND EcolabAccountNumber = @Ecolabaccountnumber
					SET @Output = '201'
					SET @Scope = @Output
					SELECT
							@Scope
   END
   ELSE
   BEGIN

					IF NOT EXISTS(SELECT
										  1
									  FROM TCD.RedFlag
									  WHERE Item = @Itemid
										AND Location = @Locationid
										AND Id <> @Id
										AND Is_Deleted = 0
										AND EcolabAccountNumber = @Ecolabaccountnumber)
				   AND @Isselected = 1
      BEGIN

							IF @Existingloc <> @Locationid
							OR @Existingitem <> @Itemid
							OR EXISTS(SELECT
											  1
										  FROM TCD.RedFlagMappingData
										  WHERE MappingId = @Id
											AND MachineId IS NOT NULL
											AND @Machinecompartmentid IS NULL
											AND Is_Deleted = 0
											AND EcolabAccountNumber = @Ecolabaccountnumber)
							OR EXISTS(SELECT
											  1
										  FROM TCD.RedFlagMappingData
										  WHERE MappingId = @Id
											AND MachineId IS NULL
											AND @Machinecompartmentid IS NOT NULL
											AND Is_Deleted = 0
											AND EcolabAccountNumber = @Ecolabaccountnumber)
			 BEGIN
									UPDATE TCD.RedFlagMappingData SET
											Is_Deleted = 1, 
											LastModifiedByUserId = @Userid
										WHERE
											MappingId = @Id
										AND EcolabAccountNumber = @Ecolabaccountnumber
			 END
		 BEGIN
								UPDATE TCD.RedFlag SET
										Item = @Itemid, 
										MaximumRange = @Maxrange, 
										MinimumRange = @Minrange, 
										Location = @Locationid, 
										LastModifiedByUserId = @Userid,
										FormulaId = @FormulaId,
										RedFlagCategoryId = @CategoryId,
										ProductId = @ProductId,
										MeterId = @MeterId,
										SensorId = @SensorId 
								OUTPUT
										inserted.ID AS Id, 
										inserted.LastModifiedTime AS LastModifiedTimestamp
									   INTO @Outputlist(
										RedFlagId, 
										LastModifiedTimestamp)
									WHERE
										ID = @Id
									AND EcolabAccountNumber = @Ecolabaccountnumber

								SET @RedFlagMappingId  = (SELECT ISNULL(Max(Id),0)+1 FROM TCD.RedFlagMappingData WHERE TCD.RedFlagMappingData.EcolabAccountNumber = @Ecolabaccountnumber);
								INSERT INTO TCD.RedFlagMappingData(
										Id,
										MappingId, 
										MachineId, 
										EcolabAccountNumber, 
										LastModifiedByUserId)
									VALUES
										   (
											@RedFlagMappingId,
											@Id, 
											@Machinecompartmentid, 
											@Ecolabaccountnumber, 
											@Userid)
								SET @Output = '201'
								SET @Scope = @Output
								SELECT
										@Scope
		END
     END
  ELSE 
						BEGIN

							IF NOT EXISTS(SELECT
												  1
											  FROM TCD.RedFlagMappingData AS RM
												   INNER JOIN TCD.RedFlag AS RF ON RM.MappingId = RF.Id
																			   AND RM.EcolabAccountNumber = RF.EcolabAccountNumber
											  WHERE ISNULL(RM.MachineId, '') = ISNULL(@Machinecompartmentid, '')
												AND RF.Item = @Itemid
												AND RF.Location = @Locationid
												AND RF.Is_Deleted = 0
												AND RM.Is_Deleted = 0
												AND RM.EcolabAccountNumber = @Ecolabaccountnumber
												AND @Isselected = 1)

  BEGIN

		  /* Machine level Update and adding for already existing redflag details */

									IF @Machinecompartmentid IS NOT NULL
								   AND @Isselected = 1
			 BEGIN
											IF EXISTS(SELECT
															  1
														  FROM TCD.RedFlagMappingData
														  WHERE MachineId IS NULL
															AND MappingId = @Id
															AND Is_Deleted = 0
															AND EcolabAccountNumber = @Ecolabaccountnumber)
			 BEGIN
													UPDATE TCD.RedFlagMappingData SET
															Is_Deleted = 1, 
															LastModifiedByUserId = @Userid
														WHERE
															MappingId = @Id
														AND EcolabAccountNumber = @Ecolabaccountnumber

													UPDATE TCD.RedFlag SET
															Item = @Itemid, 
															MaximumRange = @Maxrange, 
															MinimumRange = @Minrange, 
															Location = @Locationid, 
															LastModifiedByUserId = @Userid,
															RedFlagCategoryId = @CategoryId,    
															FormulaId = @FormulaId,    
															ProductId = @ProductId,    
															MeterId = @MeterId,    
															SensorId = @SensorId
						OUTPUT
															inserted.ID AS Id, 
															inserted.LastModifiedTime AS LastModifiedTimestamp
														   INTO @Outputlist(
															RedFlagId, 
															LastModifiedTimestamp)
														WHERE
															ID = @Id
														AND EcolabAccountNumber = @Ecolabaccountnumber
													
													SET @RedFlagMappingId  = (SELECT ISNULL(Max(Id),0)+1 FROM TCD.RedFlagMappingData WHERE TCD.RedFlagMappingData.EcolabAccountNumber = @Ecolabaccountnumber);
													INSERT INTO TCD.RedFlagMappingData(
															Id,
															MappingId, 
															MachineId, 
															EcolabAccountNumber, 
															LastModifiedByUserId)
														VALUES
															   (
															   @RedFlagMappingId,
																@Id, 
																@Machinecompartmentid, 
																@Ecolabaccountnumber, 
																@Userid)
			 END
			 ELSE
			 BEGIN
													
													SET @RedFlagMappingId = (SELECT ISNULL(Max(Id),0)+1 FROM TCD.RedFlagMappingData WHERE TCD.RedFlagMappingData.EcolabAccountNumber = @Ecolabaccountnumber);
													INSERT INTO TCD.RedFlagMappingData(
															Id,
															MappingId, 
															MachineId, 
															EcolabAccountNumber, 
															LastModifiedByUserId)
														VALUES
															   (
															   @RedFlagMappingId,
																@Id, 
																@Machinecompartmentid, 
																@Ecolabaccountnumber, 
																@Userid)
			  END
			  END
			  ELSE
			  BEGIN
											UPDATE TCD.RedFlagMappingData SET
													Is_Deleted = CASE
																	 WHEN @Isselected = 0 THEN 1
																	 WHEN @Isselected = 1 THEN 0
																 END, 
													LastModifiedByUserId = @Userid
												WHERE
													MachineId = @Machinecompartmentid
												AND MappingId = @Id
												AND EcolabAccountNumber = @Ecolabaccountnumber

											IF @Isselected = 1
												BEGIN
													SET @RedFlagMappingId = (SELECT ISNULL(Max(Id),0)+1 FROM TCD.RedFlagMappingData WHERE TCD.RedFlagMappingData.EcolabAccountNumber = @Ecolabaccountnumber);
													INSERT INTO TCD.RedFlagMappingData(
															Id,
															MappingId, 
															MachineId, 
															EcolabAccountNumber, 
															LastModifiedByUserId)
														VALUES
															   (
															   @RedFlagMappingId,
																@Id, 
																@Machinecompartmentid, 
																@Ecolabaccountnumber, 
																@Userid)
												END
			  END

			 /* End of the Machine Level logic */

									/*	Group level Update and adding for already existing redflag details */

									IF @Machinecompartmentid IS NULL
								   AND @Isselected = 1
			 BEGIN
											UPDATE TCD.RedFlagMappingData SET
													Is_Deleted = 1
												WHERE
													MappingId = @Id
												AND EcolabAccountNumber = @Ecolabaccountnumber
											SET @RedFlagMappingId = (SELECT ISNULL(Max(Id),0)+1 FROM TCD.RedFlagMappingData WHERE TCD.RedFlagMappingData.EcolabAccountNumber = @Ecolabaccountnumber);
											INSERT INTO TCD.RedFlagMappingData(
													Id,
													MappingId, 
													MachineId, 
													EcolabAccountNumber, 
													LastModifiedByUserId)
												VALUES
													   (
													   @RedFlagMappingId,
														@Id, 
														@Machinecompartmentid, 
														@Ecolabaccountnumber, 
														@Userid)
			 END

			 /* End of the Group Level logic */

									SET @Output = '201'
									SET @Scope = @Output --SELECT @Scope  
			 
									IF @Min <> @Minrange
									OR @Max <> @Maxrange
			BEGIN
								--			IF @Lastmodifiedtimestampatcentral IS NOT NULL
								--		   AND NOT EXISTS(SELECT
								--								  1
								--							  FROM TCD.RedFlag AS RF
								--							  WHERE RF.EcolabAccountNumber = @Ecolabaccountnumber
								--								AND RF.ID = @Id
								--								AND RF.LastModifiedTime = @Lastmodifiedtimestampatcentral)
								--BEGIN
								--					SET @Errorid = 60000
								--					SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR) + N': Record not in-synch between plant and central.'
								--					RAISERROR(@Errormessage, 16, 1)
								--					SET @Returnvalue = -1
								--					--RETURN @Returnvalue
								--END   
											UPDATE TCD.RedFlag 
												SET
													MinimumRange = @Minrange, 
													MaximumRange = @Maxrange, 
													LastModifiedByUserId = @Userid,
													RedFlagCategoryId = @CategoryId,    
													FormulaId = @FormulaId,    
													ProductId = @ProductId,    
													MeterId = @MeterId,    
													SensorId = @SensorId
						  OUTPUT
													inserted.ID AS Id, 
													inserted.LastModifiedTime AS LastModifiedTimestamp
												   INTO @Outputlist(
													RedFlagId, 
													LastModifiedTimestamp)
												FROM TCD.RedFlag
												WHERE
													Item = @Itemid
												AND Id = @Id
												AND EcolabAccountNumber = @Ecolabaccountnumber
											SET @Output = '201'
											SET @Scope = @Output --SELECT @Scope  
	   END

	  END   
	  ELSE
		  BEGIN
									SET @Output = '401'
									SET @Scope = @Output --SELECT @Scope  
								END
		  END 
 END

			--RETURN @Returnvalue
END
	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputredflagid = O.RedFlagId
		FROM @Outputlist AS O
SET NOCOUNT OFF
END