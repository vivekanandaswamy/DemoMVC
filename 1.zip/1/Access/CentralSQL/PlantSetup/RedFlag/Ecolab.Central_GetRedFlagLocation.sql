BEGIN
	SET NOCOUNT ON;
	SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)

	DECLARE @Locationtable TABLE(
Id INT,
			GroupDescription NVARCHAR(100), 
			GroupTypeId INT)

	IF @Itemid IN(1,2,5,12,13,14,15,16,17,20,21,22,23,24,25,26,28,29,30,31,32,33)
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
END
ELSE IF (@ItemId IN (11))
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber			
END
	IF @Itemid IN(3,18,19)
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
					 INNER JOIN TCD.MachineSetup AS MS ON GT.Id = MS.GroupId
				WHERE GT.Is_Deleted = 0
				  AND MS.IsTunnel = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
				  AND MS.EcoalabAccountNumber = @Ecolabaccountnumber

END

	IF @Itemid = 4
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
					 INNER JOIN TCD.MachineSetup AS MS ON GT.Id = MS.GroupId
				WHERE GT.Is_Deleted = 0
				  AND MS.IsTunnel = 1
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
				  AND MS.EcoalabAccountNumber = @Ecolabaccountnumber
END

	IF @Itemid = 6
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
					 INNER JOIN TCD.Meter AS M ON GT.Id = M.GroupId
											  AND M.utilityType = 2
											  AND GT.Is_deleted = 0
											  AND M.Is_deleted = 0
											  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
											  AND M.EcolabAccountNumber = @Ecolabaccountnumber
END

	IF @Itemid = 7
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
					 INNER JOIN TCD.Meter AS M ON GT.Id = M.GroupId
											  AND M.utilityType IN(1, 3, 4)
											  AND GT.Is_deleted = 0
											  AND M.Is_deleted = 0
											  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
											  AND M.EcolabAccountNumber = @Ecolabaccountnumber
END

	IF @Itemid = 8
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
					 INNER JOIN TCD.Meter AS M ON GT.Id = M.GroupId
											  AND M.utilityType IN(1)
											  AND GT.Is_deleted = 0
											  AND M.Is_deleted = 0
											  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
											  AND M.EcolabAccountNumber = @Ecolabaccountnumber
END

	IF @Itemid = 9
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE(GroupTypeId = 2
				   OR gt.Id = 0)
				 AND GT.Is_Deleted = 0
				 AND GT.EcolabAccountNumber = @Ecolabaccountnumber
END

	IF @Itemid = 10
BEGIN
			INSERT INTO @Locationtable(
					Id, 
					GroupDescription, 
					GroupTypeId)
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
				WHERE GT.GroupTypeId = 1
				  AND GT.Is_Deleted = 0
				  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
			UNION ALL
			SELECT
					GT.Id, 
					GT.GroupDescription, 
					GT.GroupTypeId
				FROM TCD.MachineGroup AS GT
					 INNER JOIN TCD.Dryers AS D ON GT.Id = D.DryerGroupId
				WHERE(GroupTypeId = 3
				   OR gt.Id = 0)
				 AND GT.Is_Deleted = 0
				 AND GT.EcolabAccountNumber = @Ecolabaccountnumber
END

ELSE IF(@ItemId = 27)
BEGIN
		INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)

	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
END

	SELECT DISTINCT L.Id,L.GroupDescription,L.GroupTypeId FROM @LocationTable L

	SET NOCOUNT OFF;
END
