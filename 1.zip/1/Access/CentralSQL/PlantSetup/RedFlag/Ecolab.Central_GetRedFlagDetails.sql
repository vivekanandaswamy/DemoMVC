
BEGIN
SET NOCOUNT ON;

DECLARE @PlantId INT;    
SET @PlantId = (SELECT 
			PlantId 
		FROM TCD.Plant 
		WHERE EcolabAccountNumber=@EcolabAccountNumber)  
	SELECT Distinct
			PR.Id, 
			ItemID = PR.Item, 
			ItemName = (SELECT
								RF.ItemName FROM TCD.RedFlagItemList AS RF WHERE RF.Id = PR.Item), 
			PR.MinimumRange, 
			PR.MaximumRange, 
			CASE(SELECT
						 RegionId FROM TCD.Plant WHERE EcolabAccountNumber = @Ecolabaccountnumber)
				WHEN 1 THEN IL.UOMNA
				WHEN 2 THEN IL.UOMEurope
			END AS UOM, 
			LocationID = PR.Location, 
			LocationName = (SELECT
									GT.GroupDescription
								FROM TCD.MachineGroup AS GT
								WHERE GT.Id = PR.Location
								  AND GT.Is_Deleted = 0
								  AND GT.EcolabAccountNumber = @Ecolabaccountnumber), 
			PR.EcolabAccountNumber, 
			(SELECT
					 STUFF((
			 SELECT DISTINCT
					 ',' + CAST(ISNULL(MachineId, -1)AS VARCHAR(1000))
				 FROM TCD.RedFlagMappingData AS MD
				 WHERE MD.MappingID = PR.ID
				   AND MD.Is_Deleted = 0
				   AND MD.EcolabAccountNumber = PR.EcolabAccountNumber
				 FOR
				 XML PATH('')), 1, 1, ''))AS MachineID, 
			(SELECT
					 LTRIM(ISNULL(STUFF((
			 SELECT DISTINCT
					 ', ' + (
			 SELECT
					 CASE
						 WHEN(
			 SELECT TOP 1
					 Istunnel
				 FROM TCD.machinesetup AS S
				 WHERE S.groupId = PR.Location
				 AND S.Washerid = MD.MachineId				 
				   AND S.EcoalabAccountNumber = @Ecolabaccountnumber) = 1 THEN CASE
																				   WHEN(
			SELECT TOP 1
					 RD.MachineId
				 FROM TCD.RedFlag AS MM
					  INNER JOIN TCD.RedFlagMappingData AS RD ON MM.Id = RD.MappingId
															 AND RD.EcolabAccountNumber = MM.EcolabAccountNumber
				 WHERE RD.MachineId = MD.MachineId
				   AND RD.MachineId = 0
				   AND MM.Is_Deleted = 0
				   AND RD.Is_Deleted = 0
				   AND RD.EcolabAccountNumber = @Ecolabaccountnumber) = 0 THEN 'Press'
																				   ELSE 
					 CASE WHEN(SELECT TOP 1 MS.IsDeleted FROM TCD.MachineSetup MS WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId AND  MS.IsDeleted=0 ) IS NOT NULL THEN (SELECT TOP(1) CAST(WS.PlantWasherNumber AS nvarchar)+':'+MS.MachineName FROM TCD.MachineSetup MS INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId) ELSE '0' END
																			   END
						 WHEN(
			 SELECT TOP 1
					 Istunnel FROM TCD.machinesetup AS S WHERE S.groupId = PR.Location AND S.Washerid = MD.MachineId AND S.EcoalabAccountNumber = @Ecolabaccountnumber) = 0 THEN
					 ISNULL(( SELECT TOP (1)
					 CAST(WS.PlantWasherNumber AS NVARCHAR) + ':' + MS.MachineName
				 FROM TCD.MachineSetup AS MS
					  INNER JOIN TCD.Washer AS WS ON MS.WasherId = WS.WasherId
					  AND MS.EcoalabAccountNumber = WS.EcoLabAccountNumber
				 WHERE MS.GroupId = PR.Location
				   AND MS.WasherId = MD.MachineId
				   AND  MS.IsDeleted =0
				   AND MS.EcoalabAccountNumber = PR.EcolabAccountNumber),'0')
						 WHEN(
			 SELECT DISTINCT
					 GroupTypeId
				 FROM TCD.MachineGroup AS GT
				 WHERE GT.Id = PR.Location
				   AND GT.EcolabAccountNumber = @Ecolabaccountnumber) = 3 THEN(
			 SELECT
					 Description
				 FROM TCD.Dryers AS D
				 WHERE D.DryerGroupId = PR.Location
				   AND D.DryerNo = MD.MachineId
				   AND D.Is_deleted = 0
				   AND D.EcolabAccountNumber = @Ecolabaccountnumber)
						 WHEN(
			 SELECT DISTINCT
					 GroupTypeId
				 FROM TCD.MachineGroup AS GT
				 WHERE GT.Id = PR.Location
				   AND GT.EcolabAccountNumber = @Ecolabaccountnumber) = 4 THEN(
			 SELECT
					 Name
				 FROM TCD.Finnishers AS F
				 WHERE F.FinnisherGroupId = PR.Location
				   AND F.FinnisherNo = MD.MachineId
				   AND F.Is_deleted = 0
				   AND F.EcolabAccountNumber = @Ecolabaccountnumber)
			END)
				 FROM TCD.RedFlagMappingData AS MD
				 WHERE MD.MappingID = PR.ID
				   AND MD.Is_Deleted = 0
				FOR
				XML PATH('')), 1, 1, ''), 'ALL')))AS MachineName, 
				PR.RedFlagCategoryId AS CategoryId,
				PR.FormulaId AS FormulaId,
				PM.Name AS FormulaName,
				PR.ProductId,
				PRM.Name AS ProductName,
				PR.MeterId,
				ME.Description AS MeterName,
				PR.LastModifiedTime, 
				PR.LastSyncTime, 
				PR.Is_Deleted,
				PR.SensorID
		FROM TCD.RedFlag AS PR
			INNER JOIN TCD.RedFlagItemList AS IL ON PR.Item = IL.Id
			LEFT JOIN TCD.WasherProgramSetup WPS ON CASE PR.Location WHEN 1 THEN 1 ELSE PR.Location END  =  CASE PR.Location WHEN 1 THEN 1 ELSE WPS.WasherGroupId END AND WPS.ProgramID = PR.FormulaId AND WPS.Ecolabaccountnumber = @Ecolabaccountnumber
			LEFT JOIN TCD.TunnelProgramSetup TPS ON CASE PR.Location WHEN 1 THEN 1 ELSE PR.Location END  =  CASE PR.Location WHEN 1 THEN 1 ELSE TPS.WasherGroupId END AND TPS.ProgramID = PR.FormulaId AND TPS.Ecolabaccountnumber = @Ecolabaccountnumber
			LEFT JOIN tcd.ProgramMaster AS PM ON PM.ProgramId = (CASE WHEN WPS.WasherProgramSetupId IS NOT NULL THEN WPS.ProgramId ELSE TPS.ProgramId END) and PM.Ecolabaccountnumber = @Ecolabaccountnumber--Identify whether its tunnel or washer formula        
			LEFT JOIN TCD.ProductMaster AS PRM ON PRM.ProductId = PR.ProductId       
			LEFT JOIN TCD.Meter AS ME ON ME.MeterId = PR.MeterId AND ME.EcolabAccountNumber = @Ecolabaccountnumber      
			LEFT JOIN TCD.RedFlagCategory AS RFC ON RFC.RedFlagCategoryId = PR.RedFlagCategoryId  
			INNER JOIN TCD.MachineGroup AS GT ON PR.Location = GT.Id
											  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
		WHERE PR.PlantId = @PlantId 
		  AND PR.Is_Deleted = 0
		  AND PR.EcolabAccountNumber = @Ecolabaccountnumber
--AND GT.Is_Deleted = 0
		  AND CASE ISNULL(@Id, '')
				  WHEN '' THEN 'TRUE'
				  ELSE CASE
						   WHEN PR.Id = @Id THEN 'TRUE'
					   END
			  END = 'TRUE'
SET NOCOUNT OFF;
END

/*
SELECT * FROM RedFlagMappingData

SELECT * FROM RedFlag

SELECT * FROM RedFlagItemList

SELECT * FROM GroupType

SELECT * FROM Dryers WHERE Is_deleted = 0
*/
