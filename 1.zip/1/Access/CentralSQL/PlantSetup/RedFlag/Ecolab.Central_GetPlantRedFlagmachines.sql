
BEGIN
    SET NOCOUNT ON;
	DECLARE @Istunnel INT = NULL, 
			@Grouptypeid INT = NULL;
	SELECT
			@Istunnel = Istunnel
	FROM TCD.machinesetup
		WHERE GroupId = @Groupid
		  AND EcoalabAccountNumber = @Ecolabaccountnumber AND IsDeleted = 0;

	SELECT
			@Grouptypeid = GroupTypeId
	FROM TCD.MachineGroup
		WHERE Id = @Groupid
    AND Is_Deleted = 0
		  AND EcolabAccountNumber = @Ecolabaccountnumber;

	IF @Grouptypeid = 2
    BEGIN
			IF @Istunnel = 1
		BEGIN

					SELECT DISTINCT MS.WasherId,  
				CAST( WS.PlantWasherNumber AS NVARCHAR)+ ':'+ MS.MachineName ,      
				MS.ControllerId  
			FROM TCD.machinesetup MS  
			LEFT JOIN TCD.Meter M ON MS.GroupId = M.GroupId  
				AND M.MachineCompartment = MS.WasherId  
			LEFT JOIN TCD.Sensor S ON MS.GroupId = S.GroupId  
				AND S.MachineCompartment = MS.WasherId  
			LEFT JOIN  TCD.Washer WS ON WS.WasherId = MS.WasherId AND WS.EcoLabAccountNumber = @EcolabAccountNumber 
			WHERE  MS.IsDeleted = 0  
				AND MS.GroupId = @GroupId  
				AND MS.EcoalabAccountNumber = @EcolabAccountNumber
				AND MS.IStunnel =1
		END;
		ELSE
		BEGIN
					SELECT DISTINCT
							MS.WasherId, 
							CAST(WS.PlantWasherNumber AS NVARCHAR) + ':' + MS.MachineName, 
				MS.ControllerId
						FROM TCD.machinesetup AS MS
							 LEFT JOIN TCD.Meter AS M ON MS.GroupId = M.GroupId
				  AND M.MachineCompartment = MS.WasherId
							 LEFT JOIN TCD.Sensor AS S ON MS.GroupId = S.GroupId
				   AND S.MachineCompartment = MS.WasherId
							 LEFT JOIN TCD.Washer AS WS ON WS.WasherId = MS.WasherId  AND WS.EcoLabAccountNumber = @EcolabAccountNumber
						WHERE
				--		(S.SensorId IS NOT NULL
			 -- AND S.Is_deleted = 0
				--		  AND S.EcolabAccountNumber = @Ecolabaccountnumber
			 --  OR M.MeterId IS NOT NULL
			 -- AND M.Is_deleted = 0
				--		  AND M.EcolabAccountNumber = @Ecolabaccountnumber)
				--AND 
				MS.IsDeleted = 0
						 AND MS.GroupId = @Groupid
						 AND MS.EcoalabAccountNumber = @Ecolabaccountnumber;
		END;
    END;
    ELSE
    BEGIN 
			IF @Grouptypeid = 3
		BEGIN
					SELECT DISTINCT
							D.DryerNo, 
			  D.Description,
			  NULL
						FROM TCD.Dryers AS D
						WHERE D.Is_deleted = 0
						 AND D.DryerGroupId = @Groupid
						 AND D.EcolabAccountNumber = @Ecolabaccountnumber;
		END;
      ELSE
      BEGIN 
					IF @Grouptypeid = 4
        BEGIN
							SELECT DISTINCT
									F.FinnisherNo, 
				F.Name,
				NULL
								FROM TCD.Finnishers AS F
									 LEFT JOIN TCD.Meter AS M ON F.FinnisherGroupId = M.GroupId
			  AND M.MachineCompartment = F.FinnisherId
									 LEFT JOIN TCD.Sensor AS S ON F.FinnisherGroupId = S.GroupId
			   AND S.MachineCompartment = F.FinnisherId
								WHERE(S.SensorId IS NOT NULL
			  AND S.Is_deleted = 0
								  AND S.EcolabAccountNumber = @Ecolabaccountnumber
			   OR M.MeterId IS NOT NULL
			  AND M.Is_deleted = 0
								  AND M.EcolabAccountNumber = @Ecolabaccountnumber)
			AND F.Is_deleted = 0
								 AND F.FinnisherGroupId = @Groupid
								 AND F.EcolabAccountNumber = @Ecolabaccountnumber;
        END;
        ELSE
        BEGIN 
							IF @Grouptypeid = 5
			BEGIN

									DECLARE @Waterandenergygroupid INT = (SELECT TOP (1)
																				  MG.Id
																			  FROM TCD.MachineGroup AS MG
																				   INNER JOIN TCD.MachineGroupType AS MGT ON MGT.Id = MG.GroupTypeId
																			  WHERE MGT.Id = @Grouptypeid);

									SELECT DISTINCT
											WE.DeviceNumber, 
				  WE.DeviceName,
				  NULL
										FROM TCD.WaterAndEnergy AS WE
											 LEFT JOIN TCD.Meter AS M ON M.GroupId = @Waterandenergygroupid
				AND M.MachineCompartment = WE.DeviceNumber
											 LEFT JOIN TCD.Sensor AS S ON S.GroupId = @Waterandenergygroupid
				 AND S.MachineCompartment = WE.DeviceNumber
										WHERE(S.SensorId IS NOT NULL
				AND S.Is_deleted = 0
										  AND S.EcolabAccountNumber = @Ecolabaccountnumber
				 OR M.MeterId IS NOT NULL
				AND M.Is_deleted = 0
										  AND M.EcolabAccountNumber = @Ecolabaccountnumber)
			  AND WE.Is_deleted = 0
										 AND WE.EcolabAccountNumber = @Ecolabaccountnumber;
			END;
        END;
      END;
    END;
    SET NOCOUNT OFF;
END;