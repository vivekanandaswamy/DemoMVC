
  BEGIN 
SET NOCOUNT ON
    DECLARE @Output VARCHAR(100) = '', 
            @Returnvalue INT = 0, 
            @Errorid INT = 0, 
            @Errormessage NVARCHAR(4000) = N'', 
            @Currentutctime DATETIME = GETUTCDATE(), 
            @Newidtobeinserted INT = NULL, 
            @Newmappingidtobeinserted INT = NULL, 
            @Errornumber INT = 0, 
            @Errorseverity INT = NULL, 
            @Errorprocedure SYSNAME = NULL, 
            @Messagestring NVARCHAR(2500) = NULL,
			@NewId INT =0
    DECLARE @Outputlist AS TABLE(
            RedFlagId INT, 
            LastModifiedTimestamp DATETIME)
 
	
 DECLARE @PlantId INT;
     SET @PlantId = (SELECT 
				PlantId 
			FROM TCD.Plant 
			WHERE EcolabAccountNumber=@EcolabAccountNumber) 
    DECLARE @MachineGroupId INT = (SELECT
                                    MG.Id
                                FROM TCD.MachineGroupType AS MGT
                                     INNER JOIN TCD.MachineGroup AS MG ON MGT.Id = MG.GroupTypeId
				   WHERE MGT.Id = 1
                                  AND MG.Is_Deleted = 0
                                  AND MG.ecolabaccountnumber = @Ecolabaccountnumber);
    IF @MeterId IS NOT NULL AND @SensorId IS NOT NULL AND @Locationid > 1
   AND @Machinecompartmentid IS NULL
   AND NOT EXISTS(SELECT
                          *
                      FROM tcd.MachineGroup AS MG
                           LEFT JOIN TCD.Meter AS M ON MG.Id = CASE M.IsPlant
                                                                   WHEN 'TRUE' THEN COALESCE(M.GroupId, @MachineGroupId)
                                                                   ELSE M.GroupId
                                                               END
                           LEFT JOIN TCD.Sensor AS S ON MG.Id = CASE S.IsPlant
                                                                    WHEN 'TRUE' THEN COALESCE(S.GroupId, @MachineGroupId)
                                                                    ELSE S.GroupId
                                                                END
                      WHERE(S.SensorId IS NOT NULL
          AND S.Is_deleted = 0
                        AND S.MachineCompartment IS NULL
                         OR M.MeterId IS NOT NULL
          AND M.Is_deleted = 0
                        AND M.MachineCompartment IS NULL)
                       AND MG.Id = @Locationid)
	BEGIN
	   SET @Scope = '301' 
	END
	ELSE
	BEGIN
            IF NOT EXISTS(SELECT
                                  1
                              FROM TCD.RedFlag
                              WHERE Item = @Itemid
                                AND Location = @Locationid
                                AND Is_Deleted = 0
                                AND EcolabAccountNumber = @Ecolabaccountnumber)
		
		
    BEGIN
                    SET @Newidtobeinserted = (SELECT
                                                      ISNULL(MAX(RF.ID), 0) + 1
                                                  FROM TCD.RedFlag AS RF
                                                  WHERE RF.EcolabAccountNumber = @Ecolabaccountnumber)
                    INSERT INTO TCD.RedFlag(
                            Id, 
                            Item, 
                            MaximumRange, 
                            MinimumRange, 
                            Location, 
                            EcolabAccountNumber, 
                            LastModifiedByUserId,
							RedFlagCategoryId,
							FormulaId,
							ProductId,
							MeterId,
							SensorId,
							PlantId)
	   OUTPUT
                            inserted.ID AS Id, 
                            inserted.LastModifiedTime AS LastModifiedTimestamp
                           INTO @Outputlist(
                            RedFlagId, 
                            LastModifiedTimestamp)
                        VALUES
                               (
                                @Newidtobeinserted, 
                                @Itemid, 
                                @Maxrange, 
                                @Minrange, 
                                @Locationid, 
                                @Ecolabaccountnumber, 
                                @Userid,
								@CategoryId,
								@FormulaId,
								@ProductId,
								@MeterId,
								@SensorId,
								@PlantId)

                    SET @Newid  = SCOPE_IDENTITY()
                    SET @Newmappingidtobeinserted = (SELECT
                                                             ISNULL(MAX(rfmd.ID), 0) + 1
                                                         FROM TCD.RedFlagMappingData AS rfmd
                                                         WHERE rfmd.EcolabAccountNumber = @Ecolabaccountnumber)
                    INSERT INTO TCD.RedFlagMappingData(
                            Id, 
                            MappingId, 
                            MachineId, 
                            EcolabAccountNumber, 
                            LastModifiedByUserId)
                        VALUES
                               (
                                @Newmappingidtobeinserted, 
                                @Newidtobeinserted, 
                                @Machinecompartmentid, 
                                @Ecolabaccountnumber, 
                                @Userid)
                    SET @Output = @Newidtobeinserted
                    SET @Scope = @Output
                    SELECT
                            @Scope

  END      
	ELSE IF (@Itemid = 5 ) 
	BEGIN   
	IF NOT EXISTS (SELECT 
				1      
			FROM   [TCD].RedFlag      
			WHERE  @Itemid = 5 
				AND Location = @LocationID 
				AND Is_Deleted=0 
				AND FormulaId = @FormulaId)      
		BEGIN      
			INSERT INTO [TCD].RedFlag (
					Item,
					MaximumRange,
					MinimumRange,
					Location,
					EcolabAccountNumber,
					LastModifiedByUserId,
					RedFlagCategoryId,
					FormulaId,
					ProductId,
					MeterId,
					SensorId,
					PlantId
				)      
		OUTPUT      
			inserted.ID      AS   Id      
			, inserted.LastModifiedTime  AS   LastModifiedTimestamp      
		INTO   @OutputList (      
				RedFlagId      
				, LastModifiedTimestamp      
		)      
			VALUES (
					@ItemID,
					@MaxRange,
					@MinRange,
					@LocationID,
					@EcolabAccountNumber,
					@UserID,
					@CategoryId,
					@FormulaId,
					@ProductId,
					@MeterId,
					@SensorId,
					@PlantId
				)      
      
		set @NewId  = SCOPE_IDENTITY()      
      
			INSERT INTO [TCD].RedFlagMappingData (
					MappingId,
					MachineId,
					EcolabAccountNumber,
					LastModifiedByUserId
				)      
				VALUES (
						@NewId,
						@MachineCompartmentId,
						@EcolabAccountNumber,
						@UserID
					)      
      
SET @OutPut = @NewId      
SET @Scope = @OutPut SELECT @Scope      
 END 
 ELSE      
BEGIN      
SET @OutPut = '401'      
SET @Scope = @OutPut SELECT @Scope      
END    
END     
ELSE      
BEGIN      
	   --DECLARE @Id INT
	   --SELECT @Id = ID FROM RedFlag R WHERE R.Location = @LocationID AND Item = @ItemID
                    IF @Id = -1
	   BEGIN
                            IF NOT EXISTS(SELECT
                                                  1
                                              FROM TCD.RedFlagMappingData AS RM
                                                   INNER JOIN TCD.RedFlag AS RF ON RM.MappingId = RF.Id
                                                                               AND RM.EcolabAccountNumber = @Ecolabaccountnumber
                                              WHERE ISNULL(RM.MachineId, '') = ISNULL(@Machinecompartmentid, '')
                                                AND RF.Item = @Itemid
                                                AND RF.Location = @Locationid
                                                AND RF.Is_Deleted = 0
                                                AND RM.Is_Deleted = 0)
	   BEGIN
                                    SET @Newidtobeinserted = (SELECT
                                                                      ISNULL(MAX(RF.ID), 0) + 1
                                                                  FROM TCD.RedFlag AS RF
                                                                  WHERE RF.EcolabAccountNumber = @Ecolabaccountnumber)
                                    INSERT INTO TCD.RedFlag(
                                            Id, 
                                            Item, 
                                            MaximumRange, 
                                            MinimumRange, 
                                            Location, 
                                            EcolabAccountNumber, 
                                            LastModifiedByUserId,
											RedFlagCategoryId,
											FormulaId,
											ProductId,
											MeterId,
											SensorId,
											PlantId)
			  OUTPUT
                                            inserted.ID AS Id, 
                                            inserted.LastModifiedTime AS LastModifiedTimestamp
                                           INTO @Outputlist(
                                            RedFlagId, 
                                            LastModifiedTimestamp)
                                        VALUES
                                               (
                                                @Newidtobeinserted, 
                                                @Itemid, 
                                                @Maxrange, 
                                                @Minrange, 
                                                @Locationid, 
                                                @Ecolabaccountnumber, 
                                                @Userid,
												@CategoryId,
												@FormulaId,
												@ProductId,
												@MeterId,
												@SensorId,
												@PlantId)

                                    DECLARE @Newgroupid INT = SCOPE_IDENTITY()
                                    SET @Newmappingidtobeinserted = (SELECT
                                                                             ISNULL(MAX(rfmd.ID), 0) + 1
                                                                         FROM TCD.RedFlagMappingData AS rfmd
                                                                         WHERE rfmd.EcolabAccountNumber = @Ecolabaccountnumber)
                                    INSERT INTO TCD.RedFlagMappingData(
                                            Id, 
                                            MappingId, 
                                            MachineId, 
                                            EcolabAccountNumber, 
                                            LastModifiedByUserId)
                                        VALUES
                                               (
                                                @Newmappingidtobeinserted, 
                                                @Newidtobeinserted, 
                                                @Machinecompartmentid, 
                                                @Ecolabaccountnumber, 
                                                @Userid)
                                    SET @Output = @Newgroupid
                                    SET @Scope = @Output
                                    SELECT
                                            @Scope

		END
		ELSE
		BEGIN
                                    SET @Output = '401'
                                    SET @Scope = @Output
                                    SELECT
                                            @Scope
		END
	   END
	   ELSE
                        BEGIN
                            IF NOT EXISTS(SELECT
                                                  MachineId
                                              FROM TCD.RedFlagMappingData
                                              WHERE MappingId = @Id
                                                AND MachineId = @Machinecompartmentid
                                                AND Is_Deleted = 0
                                                AND EcolabAccountNumber = @Ecolabaccountnumber)
		  BEGIN
                                    SET @Newmappingidtobeinserted = (SELECT
                                                                             ISNULL(MAX(rfmd.ID), 0) + 1
                                                                         FROM TCD.RedFlagMappingData AS rfmd
                                                                         WHERE rfmd.EcolabAccountNumber = @Ecolabaccountnumber)
                                    INSERT INTO TCD.RedFlagMappingData(
                                            Id, 
                                            MappingId, 
                                            MachineId, 
                                            EcolabAccountNumber, 
                                            LastModifiedByUserId)
                                        VALUES
                                               (
                                                @Newmappingidtobeinserted, 
                                                @Id, 
                                                @Machinecompartmentid, 
                                                @Ecolabaccountnumber, 
                                                @Userid)
                                    SET @Output = @Id
                                    SET @Scope = @Output
                                    SELECT
                                            @Scope
		  END
		  ELSE
		  BEGIN
                                    SET @Output = '401'
                                    SET @Scope = @Output
                                    SELECT
                                            @Scope
                                END
		  END 
	   END
	END
    SELECT TOP 1
            @Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
            @Outputredflagid = O.RedFlagId
        FROM @Outputlist AS O


SET NOCOUNT OFF	  
  END
 
 --SELECT * FROM RedFlag

 --SELECT * FROM RedFlagMappingData