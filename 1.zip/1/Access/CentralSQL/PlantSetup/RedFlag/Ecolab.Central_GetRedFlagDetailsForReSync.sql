
BEGIN
SET NOCOUNT ON;

DECLARE @PlantId INT;    
SET @PlantId = (SELECT 
			PlantId 
		FROM TCD.Plant 
		WHERE EcolabAccountNumber=@EcolabAccountNumber)  
SELECT
			PR.Id, 
			ItemID = PR.Item, 
			ItemName = (SELECT
								RF.ItemName FROM TCD.RedFlagItemList AS RF WHERE RF.Id = PR.Item), 
			PR.MinimumRange, 
			PR.MaximumRange, 
			CASE(SELECT
						 RegionId FROM TCD.Plant WHERE EcolabAccountNumber = @Ecolabaccountnumber)
				WHEN 1 THEN IL.UOMNA
				WHEN 2 THEN IL.UOMEurope
			END AS UOM, 
			LocationID = PR.Location, 
			LocationName = (SELECT
									GT.GroupDescription FROM TCD.MachineGroup AS GT WHERE GT.Id = PR.Location), 
			PR.EcolabAccountNumber, 
			(SELECT
					 STUFF((
			 SELECT DISTINCT
					 ',' + CAST(ISNULL(MachineId, -1)AS VARCHAR(1000))
				 FROM TCD.RedFlagMappingData AS MD
				 WHERE MD.MappingID = PR.ID
				 FOR
				 XML PATH('')), 1, 1, ''))AS MachineID, 
			(SELECT
					 LTRIM(ISNULL(STUFF((
			 SELECT DISTINCT
					 ', ' + (
			 SELECT
					 CASE
						 WHEN(
			 SELECT DISTINCT
					 Istunnel FROM TCD.machinesetup AS S WHERE S.groupId = PR.Location) = 1 THEN CASE
																									 WHEN(
			 SELECT
					 RD.MachineId
				 FROM TCD.RedFlag AS MM
					  INNER JOIN TCD.RedFlagMappingData AS RD ON MM.Id = RD.MappingId
				 WHERE RD.MachineId = MD.MachineId
				   AND RD.MachineId = 0) = 0 THEN 'Press'
																									 ELSE 'Comapartment' + CAST(MD.MachineId AS
VARCHAR(100))
																								 END
						 WHEN(
			 SELECT DISTINCT
					 Istunnel FROM TCD.machinesetup AS S WHERE S.groupId = PR.Location) = 0 THEN(
			 SELECT TOP (1)
					 MachineName
				 FROM TCD.MachineSetup AS MS
				 WHERE MS.GroupId = PR.Location
				   AND MS.WasherId = MD.MachineId)
						 WHEN(
			 SELECT DISTINCT
					 GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = PR.Location) = 3 THEN(
			 SELECT
					 Description
				 FROM TCD.Dryers AS D
				 WHERE D.DryerGroupId = PR.Location
				   AND D.DryerNo = MD.MachineId)
						 WHEN(
			 SELECT DISTINCT
					 GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = PR.Location) = 4 THEN(
			 SELECT
					 Name
				 FROM TCD.Finnishers AS F
				 WHERE F.FinnisherGroupId = PR.Location
				   AND F.FinnisherNo = MD.MachineId)
			END)
				 FROM TCD.RedFlagMappingData AS MD
				 WHERE MD.MappingID = PR.ID
				 FOR
				 XML PATH('')), 1, 1, ''), 'ALL')))AS MachineName, 
				 PR.RedFlagCategoryId AS CategoryId,
				PR.FormulaId AS FormulaId,
				PM.Name AS FormulaName,
				PR.ProductId,
				PRM.Name AS ProductName,
				PR.MeterId,
				ME.Description AS MeterName,
			PR.LastModifiedTime, 
			PR.LastSyncTime, 
			PR.Is_Deleted
		FROM TCD.RedFlag AS PR
			 INNER JOIN TCD.RedFlagItemList AS IL ON PR.Item = IL.Id
			 LEFT JOIN tcd.ProgramMaster AS PM ON PM.ProgramId = PR.FormulaId        
			LEFT JOIN TCD.ProductMaster AS PRM ON PRM.ProductId = PR.ProductId       
			LEFT JOIN TCD.Meter AS ME ON ME.MeterId = PR.MeterId       
			LEFT JOIN TCD.RedFlagCategory AS RFC ON RFC.RedFlagCategoryId = PR.RedFlagCategoryId
			 INNER JOIN TCD.MachineGroup AS GT ON PR.Location = GT.Id
		WHERE PR.PlantId = @PlantId 
		  AND CASE ISNULL(@Id, '')
				  WHEN '' THEN 'TRUE'
				  ELSE CASE
						   WHEN PR.Id = @Id THEN 'TRUE'
					   END
			  END = 'TRUE'
SET NOCOUNT OFF;
END

/*
SELECT * FROM RedFlagMappingData

SELECT * FROM RedFlag

SELECT * FROM RedFlagItemList

SELECT * FROM GroupType

SELECT * FROM Dryers WHERE Is_deleted = 0
*/