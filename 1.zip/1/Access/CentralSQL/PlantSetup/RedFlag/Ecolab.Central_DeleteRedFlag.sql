
BEGIN
SET NOCOUNT ON
BEGIN 
		DECLARE @Returnvalue INT = 0, 
				@Errorid INT = 0, 
				@Errormessage NVARCHAR(4000) = N''


		DECLARE @Outputlist AS TABLE(
				LastModifiedTimestamp DATETIME)

		SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)

   BEGIN   
			UPDATE TCD.RedFlag SET
				Is_Deleted = 1,
					LastModifiedByUserId = @Userid
				OUTPUT
					inserted.LastModifiedTime AS LastModifiedTimestamp
				   INTO @Outputlist(
					LastModifiedTimestamp)
				FROM TCD.RedFlag
				WHERE ID = @Id
					  AND EcolabAccountNumber = @Ecolabaccountnumber

			UPDATE TCD.RedFlagMappingData SET
				Is_Deleted = 1,
					LastModifiedByUserId = @Userid
				FROM TCD.RedFlagMappingData
				WHERE MappingId = @Id
					  AND EcolabAccountNumber = @Ecolabaccountnumber

			SELECT TOP 1
					@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp
				FROM @Outputlist AS O

			--RETURN @Returnvalue
  END
  SET NOCOUNT OFF
END
END