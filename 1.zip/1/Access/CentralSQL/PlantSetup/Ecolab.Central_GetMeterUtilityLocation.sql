BEGIN
    SET NOCOUNT ON;
	SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)
	SELECT DISTINCT
			GT.Id, 
				GT.GroupDescription,
				GT.GroupTypeId,
				MS.IsTunnel,
				(SELECT cc.ControllerModelId FROM TCD.ConduitController cc WHERE cc.ControllerId = (SELECT wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = GT.Id AND wg.EcolabAccountNumber = @EcolabAccountNumber) AND cc.EcoalabAccountNumber = @EcolabAccountNumber ) AS ControllerModelId
		FROM TCD.MachineGroup AS GT
			 LEFT JOIN TCD.MachineSetup AS MS ON GT.Id = MS.GroupId
											 AND GT.EcolabAccountNumber = MS.EcoalabAccountNumber
	 WHERE GT.Is_Deleted = 0
	   AND COALESCE(MS.IsDeleted, 0) = 0
		  AND GT.EcolabAccountNumber = @Ecolabaccountnumber
		ORDER BY
			GT.GroupTypeId, GT.Id
	SET NOCOUNT OFF
END