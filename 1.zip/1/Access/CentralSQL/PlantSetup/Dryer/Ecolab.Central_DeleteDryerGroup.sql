
BEGIN


	SET NOCOUNT ON


	DECLARE @Output VARCHAR(100) = ''

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL

	DECLARE @Outputlist AS TABLE(
			LastModifiedTimestamp DATETIME)

--IF	NOT EXISTS	(SELECT	1
--				FROM	[TCD].Meter
--				WHERE	EcolabAccountNumber		=			@EcolabAccountNumber
--					AND	GroupId					=			@GroupTypeId
--					AND	Is_deleted				=			0
--				)
--		BEGIN
				--Proceed to soft-delete...
				
	UPDATE TCD.MachineGroup SET
			Is_Deleted = 1, 
			LastModifiedTime = @Currentutctime
		WHERE EcolabAccountNumber = @Ecolabaccountnumber
			  AND Id = @Grouptypeid

	UPDATE TCD.Dryers SET
			is_deleted = 1, 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Currentutctime
		WHERE EcolabAccountNumber = @Ecolabaccountnumber
			  AND DryerGroupId = @Grouptypeid

	 SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()
	--RETURN @Returnvalue
	SET NOCOUNT ON;
END