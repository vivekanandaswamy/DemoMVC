
BEGIN    


SET NOCOUNT ON   
	DECLARE @Table_Name VARCHAR(100) = 'MachineGroup'
	DECLARE @Output VARCHAR(100) = ''
    
	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL

	DECLARE @Outputlist AS TABLE(
			DryerGroupId INT, 
			LastModifiedTimestamp DATETIME)

	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)

	IF EXISTS(SELECT
					  1
				  FROM TCD.MachineGroup
				  WHERE Id = @Grouptypeid
					AND IS_DELETED = 0
					AND EcolabAccountNumber = @Ecolabaccountnumber)
BEGIN    
			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.MachineGroup
							  WHERE Id != @Grouptypeid
								AND GroupDescription = @Groupdescription
								AND IS_DELETED = 0
								AND EcolabAccountNumber = @Ecolabaccountnumber)
BEGIN    
		BEGIN
							--Proceed to update, since it's either a local call or Synch. call with synch. time matching
						UPDATE TCD.MachineGroup SET
								GroupDescription = @Groupdescription, 
								LastModifiedByUserId = @Userid
							WHERE
								Id = @Grouptypeid
							AND EcolabAccountNumber = @Ecolabaccountnumber
		END

					SET @Output = '102'
					SET @Scope = @Output
					SELECT
							@Scope
END    
ELSE    
BEGIN    
					SET @Output = '301'
					SET @Scope = @Output
					SELECT
							@Scope
END    
END    
ELSE    
BEGIN    
			SET @Output = '302'
			SET @Scope = @Output
			SELECT
					@Scope
END    
--set at-least the datetime output param to limit the impact in service layer
	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()
	--RETURN @Returnvalue
SET NOCOUNT OFF
END
