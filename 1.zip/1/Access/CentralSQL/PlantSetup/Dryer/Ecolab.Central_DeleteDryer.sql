
BEGIN

SET NOCOUNT ON

	DECLARE @Output VARCHAR(100) = '', 
			@Dryerno INT = (SELECT
									DryerNo
								FROM TCD.Dryers
								WHERE EcolabAccountNumber = @Ecolabaccountnumber
								  AND Id = @Id)

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL



	UPDATE TCD.Dryers SET
			Is_Deleted = 1, 
			LastModifiedTime = @Currentutctime
		WHERE
			EcolabAccountNumber = @Ecolabaccountnumber
		AND Id = @Id

	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()

	--RETURN @Returnvalue


END