
BEGIN    
SET NOCOUNT ON
	DECLARE @Output VARCHAR(100) = ''
    
	DECLARE @Outputlist AS TABLE(
			DryerGroupId INT, 
			LastModifiedTimestamp DATETIME)
	SET @Scope = ISNULL(@Scope, NULL)
	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)
	SET @Outputdryergroupid = ISNULL(@Outputdryergroupid, NULL)


SET NOCOUNT ON


	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Dryergroupid INT = NULL

	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.MachineGroup
					  WHERE GroupDescription = @Groupdescription
						AND GroupTypeId = 3
						AND IS_DELETED <> 1
						AND EcolabAccountNumber = @Ecolabaccountnumber)
    
BEGIN    
						--Generate new Id for the DG being created
			SET @Dryergroupid = (SELECT
										 ISNULL(MAX(GT.Id), 0) + 1
									 FROM TCD.MachineGroup AS GT
									 WHERE GT.EcolabAccountNumber = @Ecolabaccountnumber)
    
			INSERT INTO TCD.MachineGroup(
					Id, 
					GroupDescription, 
					GroupTypeId, 
					EcolabAccountNumber, 
					LastModifiedByUserId, 
					LastModifiedTime)
				VALUES
					   (
						@Dryergroupid, 
						@Groupdescription, 
						3, 
						@Ecolabaccountnumber, 
						@Userid, 
						@Currentutctime)
    
			SET @Output = '101'
			SET @Scope = @Output
			   
END    
ELSE    
BEGIN    
			SET @Output = '301'
			SET @Scope = @Output
		--SELECT @Scope	   
END    
--set at-least the datetime output param to limit the impact in service layer
	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()
	--RETURN @Returnvalue
SET NOCOUNT OFF
END
