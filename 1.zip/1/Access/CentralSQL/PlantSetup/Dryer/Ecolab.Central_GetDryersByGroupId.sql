
BEGIN
	SET NOCOUNT ON;

	DECLARE @Firstrec INT
	DECLARE @Lastrec INT
	DECLARE @Totalrows INT

	SET @Firstrec = (@Pageno - 1) * @Recordsperpage
	SET @Lastrec = @Pageno * @Recordsperpage + 1
	SET @Totalrows = @Firstrec - @Lastrec + 1
	;WITH CTE_Results
		AS (SELECT
					ROW_NUMBER()OVER(ORDER BY d.DryerNo DESC)AS RowNum, 
					COUNT(*)OVER()AS TotalCount, 
					D.DryerNo, 
					D.Description, 
					D.Model, 
					D.Capacity
				FROM TCD.Dryers AS d)
		SELECT
				DryerNo, 
				Description, 
				Model, 
				Capacity, 
				TotalCount
FROM CTE_Results AS c
			WHERE RowNum > @Firstrec
			  AND RowNum < @Lastrec
			ORDER BY RowNum ASC
END
GO
