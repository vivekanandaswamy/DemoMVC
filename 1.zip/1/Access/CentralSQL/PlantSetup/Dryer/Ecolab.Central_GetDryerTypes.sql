
BEGIN

	SET NOCOUNT ON
	SELECT
			DryerTypeId, 
			Name FROM TCD.DryerType WHERE Is_Deleted <> 1
	SET NOCOUNT OFF
END