
BEGIN


	SET NOCOUNT ON


	DECLARE @Output VARCHAR(100) = ''

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Dryerid INT = NULL


	SET @Outputdryerid = ISNULL(@Outputdryerid, NULL)

	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.Dryers
					  WHERE EcolabAccountNumber = @Ecolabaccountnumber
						AND DryerNo = @Dryerno
						AND Is_deleted <> 1)
		BEGIN
			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.Dryers
							  WHERE EcolabAccountNumber = @Ecolabaccountnumber
								AND Description = @Description
								AND Is_deleted <> 1)
				BEGIN
					--Generate new Dryer's Id...
					SET @Dryerid = (SELECT
											ISNULL(MAX(D.Id), 0) + 1
										FROM TCD.Dryers AS D
										WHERE D.EcolabAccountNumber = @Ecolabaccountnumber)

					INSERT INTO TCD.Dryers(
							EcolabAccountNumber, 
							Id, 
							DryerGroupId, 
							DryerNo, 
							Description, 
							Capacity, 
							DryerTypeId, 
							LastModifiedByUserId, 
							LastModifiedTime, 
							Capacity_Display)
						VALUES
							   (
								@Ecolabaccountnumber, 
								@Dryerid, 
								@Dryergroupid, 
								@Dryerno, 
								@Description, 
								@Capacity, 
								@Dryertypeid, 
								@Userid, 
								@Currentutctime, 
								@Capacity_Display)


					SET @Output = '101'
					SET @Scope = @Output	--SELECT @Scope
				END
			ELSE
				BEGIN
					SET @Output = '301'
					SET @Scope = @Output	--SELECT @Scope
				END
		END
	ELSE
		BEGIN
			SET @Output = '302'
			IF EXISTS(SELECT
							  1
						  FROM TCD.Dryers
						  WHERE EcolabAccountNumber = @Ecolabaccountnumber
							AND Description = @Description
							AND Is_deleted <> 1)
				BEGIN

					SET @Output = '303'
				END
		END


	SET @Scope = @Output		--SELECT @Scope	 


	--set at-least the datetime output param to limit the impact in service layer
	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()

	--RETURN @Returnvalue


END