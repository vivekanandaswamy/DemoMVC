
BEGIN


	SET NOCOUNT ON;
	;WITH CTE
		AS (SELECT
					Id, 
					DryerNo, 
					Description, 
					Capacity, 
					Capacity_Display, 
					DryerGroupId, 
					DryerTypeId, 
					D.LastModifiedTime AS DryerLastModifiedTime
				FROM TCD.Dryers AS D
				WHERE D.EcolabAccountNumber = @Ecolabaccountnumber
				  AND D.Is_Deleted = 'FALSE')
	SELECT
				G.Id, 
				D.Id, 
				D.DryerNo, 
				D.Description, 
				D.Capacity, 
				G.GroupDescription, 
				G.EcolabAccountNumber, 
				DT.DryerTypeId, 
				DT.Name AS DryerTypeName, 
				G.LastModifiedTime AS DryerGroupLastModifiedTime, 
				G.Is_Deleted AS IsDeleted, 
				D.DryerLastModifiedTime AS DryerLastModifiedTime, 
				D.Capacity_Display
			FROM TCD.MachineGroup AS G
				 LEFT OUTER JOIN CTE AS D ON G.Id = D.DryerGroupId
				 LEFT JOIN TCD.DryerType AS DT ON DT.DryerTypeId = D.DryerTypeId
			WHERE G.EcolabAccountNumber = @Ecolabaccountnumber
--AND G.Is_Deleted = 0
AND G.GroupTypeId = 3
			ORDER BY G.Id DESC

END