
BEGIN
    SET NOCOUNT ON;
    SET @Scope = '';
    DECLARE @Returnvalue INT = 0, 
            @Errorid INT = 0, 
            @Errormessage NVARCHAR(4000) = N'', 
            @Currentutctime DATETIME = GETUTCDATE(), 
            @Newidtobeinserted INT = NULL;
    DECLARE @Outputlist AS TABLE(
            MeterId INT, 
            LastModifiedTimestamp DATETIME);
    SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL);
    SET @Outputmeterid = ISNULL(@Outputmeterid, NULL);

    /* Business vaidations for setingup the meters to controllers */

    -- Begin Defining Limits

    BEGIN
        DECLARE @Utilitylimit INT = NULL, 
                @Washerlimit INT = NULL, 
                @Tunnellimit INT = NULL, 
                @Istunnel BIT ,
				@MeterNameLimit INT = NULL;

	 SELECT @MeterNameLimit = COUNT(1)
		FROM TCD.Meter 
		WHERE [Description] = @MeterName 
		AND EcolabAccountNumber = @EcolabAccountNumber
		AND Is_deleted = 0

        SELECT
                @Utilitylimit = COUNT(1)
		FROM TCD.meter
            WHERE GroupId = @Utilitylocation
		  AND UtilityType = @Uitiliy
              AND ISNULL(MachineCompartment, 0) = @Machinecompartment
		  AND Is_deleted = 0
              AND EcolabAccountNumber = @Ecolabaccountnumber
              AND ControllerID IN(SELECT
                                          ControllerId
			   FROM TCD.ConduitController
                                      WHERE ControllerId = @Controllerid
                                        AND EcoalabAccountNumber = @Ecolabaccountnumber);

										
        SELECT
                @Washerlimit = COUNT(1)
            FROM TCD.Meter AS M
                 LEFT OUTER JOIN TCD.machinesetup AS MS ON M.GroupId = MS.groupId
						    AND M.MachineCompartment = MS.MachineInternalID
							AND M.EcolabAccountNumber = MS.EcoalabAccountNumber
		WHERE M.UtilityType = 2
              AND M.GroupID = @Utilitylocation
		  AND Is_deleted = 0
              AND EcolabAccountNumber = @Ecolabaccountnumber
              AND M.ControllerID IN(SELECT
                                            ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = @Controllermodelid
                                          AND EcoalabAccountNumber = @Ecolabaccountnumber);
        SELECT
                @Tunnellimit = COUNT(1)
            FROM TCD.Meter AS M
                 LEFT OUTER JOIN TCD.machinesetup AS MS ON M.GroupId = MS.groupId
                                                       AND M.EcolabAccountNumber = MS.EcoalabAccountNumber
		WHERE M.UtilityType = 2
              AND M.GroupID = @Utilitylocation
		  AND Ms.Istunnel = 1
		  AND Is_deleted = 0
              AND EcoalabAccountNumber = @Ecolabaccountnumber
              AND M.ControllerID IN(SELECT
                                            ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = @Controllermodelid
                                          AND EcoalabAccountNumber = @Ecolabaccountnumber);
        SELECT
                @Istunnel = Istunnel
            FROM TCD.machinesetup AS MS
            WHERE Ms.GroupId = @Utilitylocation
              AND EcoalabAccountNumber = @Ecolabaccountnumber;
    END;

    -- End Defining Limits
    --Begin Defining Variables - IsPlant, IsPress, ControllerId, ControllerModelId

    BEGIN
        DECLARE @Isplant BIT = NULL, 
                @Ispress BIT = NULL;
        IF @IStunnel = 1
        BEGIN				
            IF @MachineCompartment = 1
                BEGIN
                    SET @IsPress = 1;
                END;		
        END;

		IF @MachineCompartment = 0
            BEGIN
			SET @MachineCompartment = NULL;
			END;

        IF @Utilitylocation = 1
		  BEGIN
                SET @Isplant = 1;
                SET @Utilitylocation = NULL;
                SET @Machinecompartment = NULL;
		  END;
        IF @Controllerid = -1
		  BEGIN
                SELECT TOP (1)
                        @Controllerid = ControllerID
			   FROM TCD.ConduitController
                    WHERE ControllerModelId = @Controllermodelid
                      AND EcoalabAccountNumber = @Ecolabaccountnumber;
		  END;
	   ELSE
		  BEGIN
                SELECT
                        @Controllermodelid = ControllerModelId
			   FROM TCD.ConduitController
                    WHERE ControllerId = @Controllerid
                      AND EcoalabAccountNumber = @Ecolabaccountnumber;
		  END;
    END;

    --End Defining Variables

    IF @Controllerid != -1
	   BEGIN
            DECLARE @Newmeterid INT, 
                    @Tagtype VARCHAR(50) = 'Tag_MPLC', 
                    @Moduletypeid INT = 2, 
                    @Result INT = NULL, 
                    @Type INT = 2
          
            IF NOT EXISTS(SELECT
                                  1
                              FROM TCD.Meter
                              WHERE MeterID = @Meternumber
                                AND EcolabAccountNumber = @Ecolabaccountnumber)

			 -- Begin Create Meter

			 BEGIN

				IF @Result IS NULL
				OR @Result = 1
				    BEGIN
                            DECLARE @Allowinsert BIT = 'FALSE';

					   -- Begin Business Validations
					    IF @MeterNameLimit < 1
					   	   BEGIN	
					   IF @UtilityLimit < 1 OR @Uitiliy = 2
						  BEGIN
                                    IF @Controllermodelid = 7
											BEGIN
													  IF @UtilityLimit >= 1 AND @Uitiliy != 2
														   BEGIN
															  SET @Scope = @Scope + '301,';
														   END;
																 IF @Uitiliy = 2 AND @IStunnel = 1
																	   BEGIN   										
																
																				IF @TunnelLimit < 6
																			   BEGIN
																						SET @AllowInsert = 'TRUE';
																					END;
																				ELSE
																					BEGIN											
																						SET @Scope = @Scope + '101,';
																					END;
																		END;
																			ELSE IF @Uitiliy = 2 AND @IStunnel != 1
																			   BEGIN		
																				 IF @WasherLimit < 2
																					BEGIN
																						SET @AllowInsert = 'TRUE';												
																					END;
																				ELSE
																					BEGIN
																						SET @Scope = @Scope + '201,';												
																					END;
																									END;									   
																			ELSE
																			   BEGIN
																				  SET @AllowInsert = 'TRUE';										  
																		END;
											END;

									ELSE IF @Controllermodelid = 11
											BEGIN
												IF @UtilityLimit >= 1 AND @Uitiliy != 2
														 BEGIN
															  SET @Scope = @Scope + '301,';
														 END;
												IF @Uitiliy = 2 AND @IStunnel = 1 
														BEGIN   										
															IF @TunnelLimit < 3
																	BEGIN
																	 										
																		SET @AllowInsert = 'TRUE';
																	END;									   
															ELSE
																	BEGIN
																		SET @Scope = @Scope + '102,';
																	END;
														END;
												ELSE IF @Uitiliy = 2 AND @IStunnel != 1
															   BEGIN		
																 IF @WasherLimit < 1
																	BEGIN
																													
																		SET @AllowInsert = 'TRUE';										  
																	END;
																ELSE
																	BEGIN
																		SET @Scope = @Scope + '301,';												
																	END;


													END;	
													ELSE 
													BEGIN
									   					  SET @AllowInsert = 'TRUE';										  
													END;
										END
							 ELSE
								BEGIN
								IF @UtilityLimit >= 1 
										BEGIN
											SET @Scope = @Scope + '301,';
										END;
								ELSE
											SET @AllowInsert = 'TRUE';
								END;
						  END;
					   ELSE
						  BEGIN
							 SET @Scope = @Scope + '301,';
						  END;
						
						IF @Uitiliy = 12
						 BEGIN
							SET @AllowInsert = 'TRUE';
							SET @Scope = '';
						 END;		
						  END;
						ELSE
							BEGIN
								SET @Scope = @Scope + '302,';
							END;
					   -- End Business Validations
					   -- Begin Insert if Validation Succeeds

                            IF @Allowinsert = 'TRUE'
						  BEGIN
                                    SET @Newidtobeinserted = (SELECT
                                                                      ISNULL(MAX(M.MeterId), 0) + 1
                                                                  FROM TCD.Meter AS M
                                                                  WHERE M.EcolabAccountNumber = @Ecolabaccountnumber);
                                    INSERT INTO TCD.Meter(
                                            MeterId, 
											    EcolabAccountNumber,
											    Description,
											    UtilityType,
											    GroupId,
											    MachineCompartment,
											    MaxValueLimit,
											    MeterTickUnit,
											    UsageFactor,
											    ControllerID,
											    Parent,
											    Calibration,
                                            AllowManualentry, 
											    LastModifiedByUserId,
											    IsPlant,
											    IsPress,
												WaterType,
												WaterTypeFromFormulaSetup,
												CounterNum,
												CounterUsage,
												RunningTimeUsage,
												CounterAlarmValue,
												RunningTimeAlarmValue,
												DigitalInputNumber,
												IncludeInOperationReport)
							 OUTPUT
                                            inserted.MeterId AS MeterId, 
                                            inserted.LastModifiedTime AS LastModifiedTimestamp
                                           INTO @Outputlist(
                                            MeterId, 
                                            LastModifiedTimestamp)
							 SELECT
                                                @Newidtobeinserted, 
                                                @Ecolabaccountnumber, 
                                                @Metername, 
							 @Uitiliy,
                                                @Utilitylocation, 
                                                @Machinecompartment, 
							 @Meterrolloverpoint,
                                                @Uofforcalibration, 
							 @Usagefactor,
                                                @Controllerid, 
							 @Parent,
							 @Calibration,
                                                @Allowmanualentry, 
                                                @Userid, 
                                                @Isplant, 
                                                @Ispress,
												@WaterType,
												@WaterTypeFromFormulaSetup,
												@CounterNum,
												@CounterUsage,
												@RunningTimeUsage,
												@CounterAlarmValue,
												@RunningTimeAlarmValue,
												@ExternalCounter,
												@IncludeInOperationReport;
						  END;

				    -- End Insert if Validation Succeeds

				    END;
				ELSE
				    BEGIN
					   SET @Scope = @Scope + '802,';
				    END;
			 END;

		  --End Create Meter

		  ELSE

			 -- Begin Update Meter

			 BEGIN
                    DECLARE @Plantid INT = (SELECT
                                                    MG.Id
                                                FROM TCD.MachineGroupType AS MGT
                                                     INNER JOIN TCD.MachineGroup AS MG ON MGT.Id = MG.GroupTypeId
								   WHERE MGT.Id = 1
                                                  AND MG.Is_Deleted = 0
                                                  AND MG.EcolabAccountNumber = @Ecolabaccountnumber);

				-- Check RedFlag Association and Update Meter

		IF(EXISTS(SELECT 1 FROM TCD.RedFlag RF INNER JOIN TCD.RedFlagMappingData RFM ON RF.Id = RFM.MappingId AND RF.EcolabAccountNumber = RFM.EcolabAccountNumber AND  RF.Is_Deleted = 0
              AND RFM.Is_Deleted = 0 
			  LEFT JOIN TCD.Meter M ON RF.Location = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId , @PlantId) ELSE M.GroupId END
           AND COALESCE(  M.MachineCompartment , 0) = COALESCE(  RFM.MachineId , 0) AND RF.EcolabAccountNumber = M.EcolabAccountNumber AND M.Is_deleted = 0 
       WHERE M.MeterId = @MeterNumber AND (M.GroupId != @UtilityLocation OR M.MachineCompartment != @MachineCompartment)))
        BEGIN
		SET @Scope = '405,';
        END;
				ELSE
				    BEGIN
                            DECLARE @Allowupdate BIT = 'FALSE';


					   IF @Result IS NULL
					   OR @Result = 1
						  BEGIN

							 --Begin Get old Meter Values 

							 BEGIN
                                        DECLARE @Uty INT = (SELECT
                                                                    UtilityType
											    FROM TCD.Meter
                                                                WHERE MeterID = @Meternumber
                                                                  AND EcolabAccountNumber = @Ecolabaccountnumber);
                                        DECLARE @Grpid INT = (SELECT
                                                                      GroupId
												 FROM TCD.Meter
                                                                  WHERE MeterID = @Meternumber
                                                                    AND EcolabAccountNumber = @Ecolabaccountnumber);
                                        DECLARE @Machid INT = (SELECT
                                                                       MachineCompartment
												  FROM TCD.Meter
                                                                   WHERE MeterID = @Meternumber
                                                                     AND EcolabAccountNumber = @Ecolabaccountnumber);
																	 
								  DECLARE  @Mname INT =(SELECT COUNT(1) 
													FROM TCD.Meter 
													WHERE [Description] = @MeterName
														AND MeterId <> @MeterNumber
														AND EcolabAccountNumber = @EcolabAccountNumber
														AND Is_deleted = 0);
							 END;

							 -- Begin Business Validations
							 IF @Mname < 1
								Begin
                                    IF @Uty <> @Uitiliy
                                    OR @Grpid <> @Utilitylocation
                                    OR @Machid <> @Machinecompartment
								BEGIN
                                            IF @Utilitylimit < 1 OR @Uitiliy = 2
												 BEGIN
                                                    IF @Controllermodelid = 7
														 BEGIN
															IF @Uitiliy = 2
																BEGIN
																				IF @Istunnel = 'TRUE'
																						 BEGIN
																								DECLARE @CompartmentUsed int = 0
																								SELECT @CompartmentUsed =  COUNT(1)
																								FROM TCD.Meter M
																								LEFT OUTER JOIN
																								TCD.machinesetup MS ON M.GroupId = MS.groupId
																								WHERE M.UtilityType = 2
																								AND M.GroupID = @UtilityLocation
																								AND Ms.Istunnel = 1
																								AND Is_deleted = 0
																								AND ISNULL(MachineCompartment, 0) = @MachineCompartment
																								AND EcoalabAccountNumber = @EcolabAccountNumber
																								AND M.ControllerID IN (
																											SELECT ControllerId
																											FROM TCD.ConduitController
																											WHERE ControllerModelId = 7
																											AND EcoalabAccountNumber = @EcolabAccountNumber);

																							IF @Tunnellimit < 6
																							OR @Tunnellimit <= 6
																							AND @Uty = @Uitiliy
																							AND @Grpid = @Utilitylocation
																								BEGIN
																									 IF @CompartmentUsed > 0
																										BEGIN
																											SET @Scope = @Scope + '301,';
																										END
																									ELSE
																										BEGIN  
																											SET @AllowUpdate = 'TRUE';
																										END
																								END;
																				ELSE
																						BEGIN
																								SET @Scope = @Scope + '101,';
																						END;
																	  END;
																   ELSE
																	  BEGIN
																						IF @Washerlimit < 2
																						OR @Washerlimit <= 2
																					   AND @Uty = @Uitiliy
																					   AND @Grpid = @Utilitylocation
																							BEGIN
																								SET @Allowupdate = 'TRUE';
																							END;
																						 ELSE
																							BEGIN
																								SET @Allowupdate = 'FALSE';
																								SET @Scope = @Scope + '201,';
																							END;
																					  END;
																END;
															ELSE
																BEGIN
																	SET @Allowupdate = 'TRUE';
																END;
														 END;
													ELSE IF @Controllermodelid = 11
															BEGIN
																IF @Uitiliy = 2 AND @IStunnel = 1 
																		BEGIN   										
																			IF @TunnelLimit < 3
																					BEGIN
																						SET @Allowupdate = 'TRUE';
																					END;									   
																			ELSE
																					BEGIN
																						SET @Scope = @Scope + '102,';
																					END;
																		END;
																ELSE IF @Uitiliy = 2 AND @IStunnel != 1
															    BEGIN		
																		 IF @WasherLimit < 1
																			BEGIN
																				SET @Allowupdate = 'TRUE';										  
																			END;
																		ELSE
																			BEGIN
																				SET @Scope = @Scope + '301,';												
																			END;


																END;	
															END

													ELSE
														BEGIN
															SET @Allowupdate = 'TRUE';
														END;
									   END;
											ELSE
												 BEGIN
												  SET @Scope = @Scope + '301,';
											   END;
								END;
							 ELSE
								BEGIN
                                            SET @Allowupdate = 'TRUE';
								END;
								END;
							ELSE
								BEGIN
								 SET @Scope = @Scope + '302,';
								END;

							 -- End Business Validations 
							 -- Begin Update if Validation Succeeds

                                    IF @Allowupdate = 'TRUE'
								BEGIN
                                            UPDATE P SET
                                                    Description = @Metername, 
										 UtilityType = @Uitiliy,
                                                    GroupId = @Utilitylocation, 
                                                    MachineCompartment = @Machinecompartment, 
										 Parent = @Parent,
										 Calibration = @Calibration,
                                                    ControllerID = @Controllerid, 
                                                    MeterTickUnit = @Uofforcalibration, 
										 UsageFactor = @Usagefactor,
                                                    AllowmanualEntry = @Allowmanualentry, 
										 Maxvaluelimit = @Meterrolloverpoint,
                                                    IsPlant = @Isplant, 
                                                    IsPress = @Ispress, 
                                                    LastModifiedByUserId = @Userid,
													WaterType = @WaterType,
												 WaterTypeFromFormulaSetup = @WaterTypeFromFormulaSetup,
												 CounterNum = @CounterNum,
												 CounterUsage = @CounterUsage,
												 RunningTimeUsage = @RunningTimeUsage,
												 CounterAlarmValue = @CounterAlarmValue,
												 RunningTimeAlarmValue = @RunningTimeAlarmValue,
												 DigitalInputNumber = @ExternalCounter,
												 IncludeInOperationReport = @IncludeInOperationReport
								    OUTPUT
                                                    inserted.MeterId AS MeterId, 
                                                    inserted.LastModifiedTime AS LastModifiedTimestamp
                                                   INTO @Outputlist(
                                                    MeterId, 
                                                    LastModifiedTimestamp)
                                                FROM TCD.Meter P
                                                WHERE
                                                    MeterID = @Meternumber
                                                AND EcolabAccountNumber = @Ecolabaccountnumber;
												    END;

						  -- End Update if Validation Succeeds 

						  END;
					   ELSE
						  BEGIN
							 SET @Scope = @Scope + '802,';
						  END;
				    END;
			 END;

	   -- End Update Meter

	   END;
    ELSE
	   BEGIN
		  SET @Scope = '701,';
	   END;
    SET NOCOUNT OFF;
    SELECT TOP 1
            @Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
            @Outputmeterid = O.MeterId
        FROM @Outputlist AS O;
END;