
BEGIN

	SET NOCOUNT ON;

	SELECT
			M.MeterId AS MeterId, 
			M.Description AS Description, 
			M.UtilityType AS MeterType, 
			M.GroupId AS GroupId, 
			M.EcolabAccountNumber AS EcolabAccountNumber, 
			M.MaxValueLimit AS MaxValueLimit, 
			M.MeterTickUnit AS MeterTickUnit, 
			M.UsageFactor AS UsageFactor, 
			M.ControllerID AS ControllerId, 
			M.Parent AS ParentId, 
			M.Calibration AS Calibration, 
			M.DigitalInputNumber AS DigitalInputNumber, 
			M.AllowManualentry AS AllowManualEntry, 
			M.Is_deleted AS IsDeleted, 
			M.MachineCompartment AS MachineId, 
			M.Id AS Id, 
			M.LastModifiedByUserId AS LastModifiedByUserId, 
			M.LastSyncTime AS LastSyncTime, 
			M.IsPlant AS IsPlant, 
			M.IsPress AS IsPress, 
			M.LastModifiedTime AS LastModifiedTime,
			M.CounterAlarmValue,
			M.WaterType,
			M.WaterTypeFromFormulaSetup,
			M.RunningTimeAlarmValue,
			CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel,
			M.DigitalInputNumber,
			M.CounterUsage,
			M.RunningTimeUsage,
			M.CounterNum,
			M.IncludeInOperationReport
		FROM TCD.Meter AS M
		LEFT JOIN TCD.ControllerSetupData csd 
		ON csd.ControllerId = M.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = M.EcolabAccountNumber
		WHERE M.MeterId = ISNULL(@Meterid, M.MeterId)
		  AND M.EcolabAccountNumber = @Ecolabaccountnumber

END
