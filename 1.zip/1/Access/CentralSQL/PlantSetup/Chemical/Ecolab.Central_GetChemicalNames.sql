
BEGIN
	SET NOCOUNT ON
	BEGIN
		DECLARE @Regionid INT
		DECLARE @Country VARCHAR(250)
		SELECT
				@Regionid = RegionID
			FROM TCD.Plant
			WHERE EcolabAccountNumber = @Ecolabaccountnumber
		SELECT
				@Country = ISNULL(NULLIF(PLA.Country, ''), PLA.Shippingcountry)
			FROM TCD.Plant AS P
				 JOIN TCD.PlantCustAddress AS PLA ON P.EcolabAccountNumber = PLA.EcolabAccountNumber
			WHERE P.EcolabAccountNumber = @Ecolabaccountnumber

IF @RegionId = 1

BEGIN
			SELECT
				M.ProductId, 
				RTRIM(Name) + ' ( ' + RTRIM(SKU) + ' )' AS Name, 
				(CASE WHEN ISNULL( M.Cost,0)>0 then M.Cost 
					WHEN ISNULL(PSP.ListPrice,0)>0 THEN PSP.ListPrice
					WHEN ISNULL(PSP.ContractPrice,0)>0 THEN PSP.ContractPrice
					WHEN ISNULL(PSP.CountryPrice,0)>0 THEN PSP.CountryPrice
					ELSE M.Cost 
				END) Cost
				,M.IncludeinCI
			FROM TCD.ProductMaster AS M
			 LEFT JOIN TCD.ProductStandardPrice PSP on M.ProductId=PSP.ProductId and PSP.EcolabAccountNumber=@EcolabAccountNumber
			WHERE(M.SKU LIKE '%' + @Chemname + '%'
			   OR M.Name LIKE '%' + @Chemname + '%')
			 AND M.RegionId = @Regionid
			 AND M.Country IS NOT NULL
			 AND M.Is_Deleted = 0
			 AND NOT EXISTS(SELECT
									ProductId
								FROM TCD.ProductdataMapping AS Map
								WHERE M.ProductId = Map.ProductId
								  AND Map.Is_Deleted = 0
								  AND Map.EcolabAccountNumber = @Ecolabaccountnumber)
			ORDER BY
				M.Name
END

ELSE IF @RegionId = 2

BEGIN
SELECT * FROM (
		SELECT
				M.ProductId, 
				RTRIM(Name) + ' ( ' + RTRIM(SKU) + ' )' AS Name, 
				(CASE WHEN ISNULL( M.Cost,0)>0 then M.Cost 
					WHEN ISNULL(PSP.ListPrice,0)>0 THEN PSP.ListPrice
					WHEN ISNULL(PSP.ContractPrice,0)>0 THEN PSP.ContractPrice
					WHEN ISNULL(PSP.CountryPrice,0)>0 THEN PSP.CountryPrice
					ELSE M.Cost 
				END) Cost
				,M.IncludeinCI
			FROM TCD.ProductMaster AS M
			 LEFT JOIN TCD.ProductStandardPrice PSP on M.ProductId=PSP.ProductId and PSP.EcolabAccountNumber=@EcolabAccountNumber
			WHERE(M.SKU LIKE '%' + @Chemname + '%'
			   OR M.Name LIKE '%' + @Chemname + '%')
			 AND M.RegionId = @Regionid
			 AND M.Country IS NOT NULL
			 AND M.Is_Deleted = 0
			 AND NOT EXISTS(SELECT
									ProductId
								FROM TCD.ProductdataMapping AS Map
								WHERE M.ProductId = Map.ProductId
								  AND Map.Is_Deleted = 0
								  AND Map.EcolabAccountNumber = @Ecolabaccountnumber)
AND M.SourceSystemId = (SELECT p.SourceSystemId FROM TCD.Plant p WHERE p.EcolabAccountNumber = @Ecolabaccountnumber)
			--ORDER BY
				--M.Name
				) a 
WHERE a.Cost > 0 and a.Cost is not null ORDER BY a.Name
	END
END
END
