
BEGIN
SET NOCOUNT ON
BEGIN
		DECLARE --@Returnvalue INT = 0, 
				@Currentutctime DATETIME = GETUTCDATE(), 
				@Errornumber INT = 0, 
				@Errormessage NVARCHAR(2048) = NULL, 
				@Errorseverity INT = NULL, 
				@Errorprocedure SYSNAME = NULL, 
				@Messagestring NVARCHAR(2500) = NULL
	
		DECLARE @Outputlist AS TABLE(
				Id INT, 
				LastModifiedTimestamp DATETIME)
		BEGIN
			UPDATE TCD.ProductdataMapping SET
					Cost = @Cost, 
					IncludeCI = @Includeci, 
					InventoryExpense = @Inventoryexpense, 
					LastModifiedByUserId = @Userid, 
					LastModifiedTime = @Currentutctime
	OUTPUT
					inserted.ID AS Id, 
					inserted.LastModifiedTime AS LastModifiedTimestamp
				   INTO @Outputlist(
					Id, 
					LastModifiedTimestamp)
				WHERE ProductID = @Id
					  AND EcolabAccountNumber = @Ecolabaccountnumber
		END

		SELECT TOP 1
				@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
				@Outputchemicalid = O.Id
			FROM @Outputlist AS O
		--RETURN @Returnvalue

	--SET NOCOUNT OFF;

END
END