
BEGIN
	SET NOCOUNT ON;

	SELECT
			PM.ProductID, 
			PM.sku
		FROM TCD.productmaster AS PM
		WHERE PM.MyServiceProdId = @Myserviceprodid

	SET NOCOUNT OFF;
END