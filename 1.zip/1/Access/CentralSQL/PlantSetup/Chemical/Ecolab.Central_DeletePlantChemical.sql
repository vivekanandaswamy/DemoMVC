
  BEGIN   

	SET NOCOUNT ON; 

	DECLARE @Lastmodifiedtimestampatcentral DATETIME

	SET @Outputchemicalid = ISNULL(@Outputchemicalid, NULL)

	DECLARE @Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Outputlist AS TABLE(
			PlantChemicalId INT, 
			LastModifiedTimestamp DATETIME)

	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)			

	--	  DECLARE @Table_name NVARCHAR(1000) = 'productdatamapping' 


	IF @Lastmodifiedtimestampatcentral IS NOT NULL
   AND NOT EXISTS(SELECT
						  1
					  FROM TCD.ProductDataMapping AS PDM
					  WHERE PDM.EcolabAccountNumber = @Ecolabaccountnumber
						AND PDM.ProductID = @Id
						AND PDM.LastModifiedTime = @Lastmodifiedtimestampatcentral)
	BEGIN
			SET @Errorid = 60000
			SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR(@Errormessage, 16, 1)
			SET @Returnvalue = -1
			--RETURN @Returnvalue
	END

	UPDATE TCD.ProductdataMapping SET
			Is_Deleted = 1, 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Currentutctime
	 OUTPUT
			inserted.ID AS Id, 
			inserted.LastModifiedTime AS LastModifiedTimestamp
		   INTO @Outputlist(
			PlantChemicalId, 
			LastModifiedTimestamp)
		WHERE ProductID = @Id
			  AND EcolabAccountNumber = @Ecolabaccountnumber

	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputchemicalid = O.PlantChemicalId
		FROM @Outputlist AS O

	--RETURN @Returnvalue
	 
	SET NOCOUNT OFF; 
  END
