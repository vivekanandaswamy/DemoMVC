DECLARE @FromControllerID					INT     =   NULL
,		@FromControllerModelID				INT     =   NULL


	SELECT  @FromControllerID   =  wg.ControllerId 
	 FROM TCD.WasherGroup   wg
	 WHERE   wg.WasherGroupId  =  @WasherGroupId
	AND   wg.EcolabAccountNumber =  @EcolabAccountNumber

	SELECT  @FromControllerModelID  =  cc.ControllerModelId
	 FROM TCD.ConduitController cc
	 WHERE cc.ControllerId   =  @FromControllerID
	AND   cc.EcoalabAccountNumber =  @EcolabAccountNumber

		IF @FromControllerModelID = 7
		BEGIN
			SET @WasherGroupId = NULL
		END	

SELECT pm.ProductId
		, RTRIM(Name) + ' ( ' + RTRIM(pm.SKU) + ' )' as Name
		, pm.Cost
		, pm2.IncludeinCI
FROM TCD.ProductdataMapping pm
INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
WHERE EXISTS (
SELECT 1
FROM TCD.WasherDosingSetup wds
INNER JOIN TCD.WasherDosingProductMapping wdpm 
ON wdpm.EcoLabAccountNumber = wds.EcoLabAccountNumber 
AND wdpm.WasherDosingSetupId = wds.WasherDosingSetupId
WHERE 
(CASE WHEN @WasherGroupId IS NOT NULL 
	 THEN wds.GroupId
	 ELSE wds.ControllerID
END)   =	(CASE WHEN @WasherGroupId IS NOT NULL 
					THEN @WasherGroupId
					ELSE @FromControllerID
			END)
AND wdpm.EcoLabAccountNumber = @EcolabAccountNumber
AND wdpm.ProductId = pm.ProductId
AND wdpm.IsDeleted = 'False'
AND wds.Is_Deleted = 'False'
)
AND pm.Is_Deleted = 'False' 
AND pm.EcolabAccountNumber = @EcolabAccountNumber