
BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @Regionid INT = NULL, 
            @Controllerid INT = NULL, 
            @Controllermodelid INT = NULL, 
            @Controllertypeid INT = NULL,
			@WasherDosingNumber  INT    =    NULL,
			@ControllerEquipmentId TINYINT = NULL,
			@ControllerEquipmentSetupId SMALLINT = NULL
    
    SELECT 
            @Regionid = RegionID
        FROM TCD.Plant
        WHERE EcolabAccountNumber = @Ecolabaccountnumber

    SELECT
            @Controllerid = wg.ControllerId,  @WasherDosingNumber = wg.WasherDosingNumber
        FROM TCD.WasherGroup AS wg
        WHERE wg.WasherGroupId = @Washergroupid
          AND wg.EcolabAccountNumber = @Ecolabaccountnumber


    IF @Controllerid IS NULL OR @Controllerid = 0
    BEGIN
            IF @Washergroupid IS NULL
    BEGIN
        SELECT 
							@ControllerEquipmentId,
							@ControllerEquipmentSetupId,
                            Map.ProductId, 
                            RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name  ,
                            M.Cost, 
                            M.IncludeinCI, 
                            TCD.FnChemicalCostInOunce(Map.ProductId, @Ecolabaccountnumber)AS Price, 
                            0
                        FROM TCD.ProductMaster AS M
                             INNER JOIN TCD.ProductdataMapping AS Map ON M.ProductId = Map.ProductId
                                                                     AND Map.Is_Deleted = 0
                        WHERE(M.SKU LIKE '%' + @Chemname + '%'
                           OR M.Name LIKE '%' + @Chemname + '%')
                         AND M.RegionId = @Regionid
                         AND M.Is_Deleted = 0
                         AND Map.EcolabAccountNumber = @Ecolabaccountnumber
    END
    ELSE
    BEGIN
        SELECT DISTINCT
							@ControllerEquipmentId,
							@ControllerEquipmentSetupId,
                            Map.ProductId, 
                            RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name  , 
                            M.Cost, 
                            M.IncludeinCI, 
                            TCD.FnChemicalCostInOunce(Map.ProductId, @Ecolabaccountnumber)AS Price, 
                            0
                        FROM TCD.ProductMaster AS M
                             INNER JOIN TCD.ProductdataMapping AS Map ON M.ProductId = Map.ProductId
                                                                     AND Map.Is_Deleted = 0
                             LEFT JOIN TCD.ControllerEquipmentSetup AS ces ON ces.ProductId = Map.ProductId
                                                                          AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
                             INNER JOIN TCD.MachineSetup AS ms ON ms.ControllerId = ces.ControllerId
                                                              AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber
                                                              AND ms.IsDeleted = 'False'
                             INNER JOIN TCD.WasherGroup AS wg ON wg.WasherGroupId = ms.GroupId
                                                             AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
                        WHERE wg.WasherGroupId = ISNULL(@Washergroupid, wg.WasherGroupId)
                          AND (M.SKU LIKE '%' + @Chemname + '%'
                            OR M.Name LIKE '%' + @Chemname + '%')
                          AND M.RegionId = @Regionid
                          AND M.Is_Deleted = 0
                          AND Map.EcolabAccountNumber = @Ecolabaccountnumber
        END
     END
    ELSE
    BEGIN
            SELECT
                    @Controllermodelid = cc.ControllerModelId, 
                    @Controllertypeid = cc.ControllerTypeId
                FROM TCD.ConduitController AS cc
                WHERE cc.ControllerId = @Controllerid
                  AND cc.EcoalabAccountNumber = @Ecolabaccountnumber

            IF @Controllermodelid = 11
        BEGIN
            SELECT			
							ces.ControllerEquipmentId,
							ces.ControllerEquipmentSetupId,	
                            Map.ProductId, 
                            RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name ,
                            M.Cost, 
                            M.IncludeinCI, 
							TCD.FnChemicalCostInOunce(Map.ProductId, @Ecolabaccountnumber)AS Price, 
                            CAST(ces.ControllerEquipmentTypeId AS INT)AS ControllerEquipmentTypeId
                        FROM TCD.ProductMaster AS M
                             INNER JOIN TCD.ProductdataMapping AS Map ON M.ProductId = Map.ProductId
                                                                     AND Map.Is_Deleted = 0
                             INNER JOIN TCD.ControllerEquipmentSetup AS ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber   AND ces.WasherGroupNumber=@WasherDosingNumber
                                                                           AND ces.ProductId = Map.ProductID AND ces.ConventionalWasherGroupConnection = 1
                             LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping AS tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID
                                                                                          AND tcevm.DirectDosingFlag = 1
                                                                                          AND tcevm.PlantID IN(SELECT
                                                                                                                       p.PlantId FROM TCD.Plant AS p
WHERE p.EcolabAccountNumber = @Ecolabaccountnumber)
                        WHERE(M.SKU LIKE '%' + @Chemname + '%'
                           OR M.Name LIKE '%' + @Chemname + '%')
            AND tcevm.ControllerEquipmentSetupID IS NULL
                         AND M.RegionId = @Regionid
                         AND M.Is_Deleted = 0
                         AND ces.ControllerId = @Controllerid
                         AND ces.WasherGroupNumber = CASE
                                                         WHEN @Controllertypeid = 13 THEN 1
                                                         ELSE ces.WasherGroupNumber
                                                     END
                         AND Map.EcolabAccountNumber = @Ecolabaccountnumber
    END
        ELSE
        BEGIN
            SELECT 
							CASE ces.ControllerEquipmentTypeId WHEN 2 THEN 
											   CASE @ControllerModelId WHEN 7 THEN CAST(ces.ControllerEquipmentId-24 AS tinyint) 
											   ELSE ces.ControllerEquipmentId END 
											   ELSE ces.ControllerEquipmentId END,
							ces.ControllerEquipmentSetupId,
                            Map.ProductId, 
                           RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name ,
                            M.Cost, 
                            M.IncludeinCI, 
                            TCD.FnChemicalCostInOunce(Map.ProductId, @Ecolabaccountnumber)AS Price, 
                            CAST(ces.ControllerEquipmentTypeId AS INT)AS ControllerEquipmentTypeId
                        FROM TCD.ProductMaster AS M
                             INNER JOIN TCD.ProductdataMapping AS Map ON M.ProductId = Map.ProductId
                                                                     AND Map.Is_Deleted = 0
                             INNER JOIN TCD.ControllerEquipmentSetup AS ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber
                                                                           AND ces.ProductId = Map.ProductID
																		    AND CASE WHEN @ControllerModelId IN (7, 10, 8) THEN ces.ConventionalWasherGroupConnection ELSE ISNULL(ces.ConventionalWasherGroupConnection, 0) END = CASE WHEN @ControllerModelId IN (7, 10, 8) THEN 1 ELSE 0 END
                             LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping AS tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID
                                                                                          AND tcevm.DirectDosingFlag = 1
                                                                                          AND tcevm.PlantID IN(SELECT
                                                                                                                       p.PlantId FROM TCD.Plant AS p
WHERE p.EcolabAccountNumber = @Ecolabaccountnumber)
                        WHERE(M.SKU LIKE '%' + @Chemname + '%'
                           OR M.Name LIKE '%' + @Chemname + '%')
            AND tcevm.ControllerEquipmentSetupID IS NULL
                         AND M.RegionId = @Regionid
                         AND M.Is_Deleted = 0
                         AND ces.ControllerId = @Controllerid
                         AND Map.EcolabAccountNumber = @Ecolabaccountnumber
        END
    END
        

    SET NOCOUNT OFF 
 
END
