
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Regionid INT = NULL
			
	SELECT
			@Regionid = RegionID FROM TCD.Plant WHERE EcolabAccountNumber = @Ecolabaccountnumber

	IF @WasherGroupId = 0
	BEGIN
		SET @WasherGroupId = NULL
	END

	;WITH CTE
		AS (SELECT DISTINCT
					wg.WasherGroupId, 
					ms.ControllerId, 
					ControllerWasherGroupID.WasherGroupId AS ChildWGID, 
					ControllerWasherGroupID.ControllerId AS ChildControllerID
				FROM TCD.WasherGroup AS wg
					 INNER JOIN TCD.MachineGroup AS mg ON mg.Id = wg.WasherGroupId
													  AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
													  AND mg.Is_Deleted = 'False'
					 INNER JOIN TCD.MachineSetup AS ms ON wg.WasherGroupId = ms.GroupId
													  AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
													  AND ms.IsDeleted = 'False'
					 CROSS APPLY(SELECT
										 wg2.WasherGroupId, 
										 ms2.ControllerId
									 FROM TCD.WasherGroup AS wg2
										  INNER JOIN TCD.MachineGroup AS mg2 ON mg2.Id = wg2.WasherGroupId
																			AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
																			AND mg2.Is_Deleted = 'False'
										  INNER JOIN TCD.MachineSetup AS ms2 ON wg2.WasherGroupId = ms2.GroupId
																			AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
																			AND ms2.IsDeleted = 'False'
									 WHERE ms2.ControllerId = ms.ControllerId)AS ControllerWasherGroupID
				WHERE wg.WasherGroupId = ISNULL(@Washergroupid, WG.WasherGroupId)
				  AND wg.EcolabAccountNumber = @Ecolabaccountnumber), CTE_Level2
		AS (SELECT DISTINCT
					wg.WasherGroupId, 
					ms.ControllerId, 
					ControllerWasherGroupID.WasherGroupId AS ChildWGID, 
					ControllerWasherGroupID.ControllerId AS ChildControllerID
				FROM TCD.WasherGroup AS wg
					 INNER JOIN TCD.MachineGroup AS mg ON mg.Id = wg.WasherGroupId
													  AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
													  AND mg.Is_Deleted = 'False'
					 INNER JOIN TCD.MachineSetup AS ms ON wg.WasherGroupId = ms.GroupId
													  AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
													  AND ms.IsDeleted = 'False'
					 CROSS APPLY(SELECT
										 wg2.WasherGroupId, 
										 ms2.ControllerId
									 FROM TCD.WasherGroup AS wg2
										  INNER JOIN TCD.MachineGroup AS mg2 ON mg2.Id = wg2.WasherGroupId
																			AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
																			AND mg2.Is_Deleted = 'False'
										  INNER JOIN TCD.MachineSetup AS ms2 ON wg2.WasherGroupId = ms2.GroupId
																			AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
																			AND ms2.IsDeleted = 'False'
									 WHERE ms2.ControllerId = ms.ControllerId)AS ControllerWasherGroupID
				WHERE wg.WasherGroupId IN(SELECT
												  ChildWGID FROM CTE)
				  AND wg.EcolabAccountNumber = @Ecolabaccountnumber), CTE_Level3
		AS (SELECT DISTINCT
					wg.WasherGroupId, 
					ms.ControllerId, 
					ControllerWasherGroupID.WasherGroupId AS ChildWGID, 
					ControllerWasherGroupID.ControllerId AS ChildControllerID
				FROM TCD.WasherGroup AS wg
					 INNER JOIN TCD.MachineGroup AS mg ON mg.Id = wg.WasherGroupId
													  AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
													  AND mg.Is_Deleted = 'False'
					 INNER JOIN TCD.MachineSetup AS ms ON wg.WasherGroupId = ms.GroupId
													  AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
													  AND ms.IsDeleted = 'False'
					 CROSS APPLY(SELECT
										 wg2.WasherGroupId, 
										 ms2.ControllerId
									 FROM TCD.WasherGroup AS wg2
										  INNER JOIN TCD.MachineGroup AS mg2 ON mg2.Id = wg2.WasherGroupId
																			AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
																			AND mg2.Is_Deleted = 'False'
										  INNER JOIN TCD.MachineSetup AS ms2 ON wg2.WasherGroupId = ms2.GroupId
																			AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
																			AND ms2.IsDeleted = 'False'
									 WHERE ms2.ControllerId = ms.ControllerId)AS ControllerWasherGroupID
				WHERE wg.WasherGroupId IN(SELECT
												  ChildWGID FROM CTE_Level2)
				  AND wg.EcolabAccountNumber = @Ecolabaccountnumber)
		SELECT DISTINCT
				pm.ProductId, 
				pm2.Name, 
				pm.Cost, 
				pm.IncludeCI
			FROM CTE_Level3 AS WG
				 INNER JOIN TCD.ConduitController AS cc ON WG.ChildControllerID = cc.ControllerId
													   AND cc.IsDeleted = 'False'
				 INNER JOIN tcd.ControllerEquipmentSetup AS ces ON cc.ControllerId = ces.ControllerId
				 RIGHT JOIN tcd.ProductdataMapping AS pm ON ces.ProductId = pm.ProductID
														AND pm.EcolabAccountNumber = ces.EcoLabAccountNumber
				 INNER JOIN TCD.ProductMaster AS pm2 ON pm2.ProductId = pm.ProductId
			WHERE ces.ProductId IS NULL
			  AND pm.EcolabAccountNumber = @Ecolabaccountnumber
			  AND pm2.SKU NOT IN('0', '-1')
			  AND pm.Is_Deleted = 'False'
			  AND pm2.RegionId = @Regionid
			ORDER BY
				pm.ProductID

	SET NOCOUNT OFF
END