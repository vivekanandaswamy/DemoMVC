
BEGIN

SET NOCOUNT ON;

	DECLARE @Usagekey NVARCHAR(100)

	DECLARE @Waterfactortypeid INT = 0

	DECLARE @WaterUtilityDetailsId INT = 0
	-- To get the usage key for gasoil type 

	SET @Usagekey = 'TCD_GasOil_Price'
	-- To get the water factor Id
	
	IF @Myservicewtrfctrid = 0
	BEGIN
	    SET @Myservicewtrfctrid = NULL 
	END

	IF @Waterfactortype <> 'None'

		BEGIN

			SELECT
					@Waterfactortypeid = wt.Id
				FROM TCD.WaterType AS wt
				WHERE Name = @Waterfactortype
				  AND wt.RegionID = (SELECT
											 P.RegionID FROM TCD.Plant AS P WHERE P.EcolabAccountNumber = @Ecolabaccountnumber)

		END

	-- Insert for water utilities

	IF(SELECT
			   COUNT(*)
		   FROM TCD.WaterUtilityDetails
		   WHERE EcolabAccountNumber = @Ecolabaccountnumber) < 8
		BEGIN

			SET @WaterUtilityDetailsId = (SELECT ISNULL(MAX(WaterUtilityDetailsId),0) + 1 FROM TCD.WaterUtilityDetails WHERE EcolabAccountNumber = @Ecolabaccountnumber);
			
			INSERT INTO TCD.WaterUtilityDetails(
					WaterUtilityDetailsId,
					EcolabAccountNumber, 
					WaterFactorTypeId, 
					Temperature, 
					Price, 
					LastModifiedByUserId, 
					LastModifiedTime, 
					MyServiceLastSyncTime, 
					MyServiceWtrFctrId)
				VALUES
					   (
					   @WaterUtilityDetailsId,
						@Ecolabaccountnumber, 
						@Waterfactortypeid, 
						@Temperature, 
						@Price, 
						@Userid, 
						GETUTCDATE(), 
						@Myservicelastsynctime, 
						@Myservicewtrfctrid)

		END
	IF @Count = 1
   AND (SELECT
				COUNT(*)
			FROM TCD.EnergyUtilityDetails
			WHERE EcolabAccountNumber = @Ecolabaccountnumber) = 0

		BEGIN

			-- Insert for Energy Utilities.

			INSERT INTO TCD.EnergyUtilityDetails(
					EcolabAccountNumber, 
					GasOilTypeId, 
					EnergyPrice, 
					EnergyPriceUsageKey, 
					EnergySubUnit, 
					ElectricPrice, 
					BolierSteam, 
					BolierType, 
					Steam, 
					Boiler, 
					Stack, 
					RewashFactor, 
					EvaporationFactor, 
					LastModifiedByUserId, 
					MyServiceLastSyncTime)
				VALUES
					   (
						@Ecolabaccountnumber, 
						-- EcolabAccountNumber - nvarchar

						@Gasoiltypeid, 
						-- GasOilTypeId - int

						@Energyprice, 
						-- EnergyPrice - decimal

						@Usagekey, 
						-- EnergyPriceUsageKey - nvarchar

						@Energypricesubunit, 
						@Electricalprice, 
						-- ElectricPrice - decimal

						@Boilersteam, 
						-- BolierSteam - bit

						@Boilertype, 
						-- BolierType - int

						@Steam, 
						-- Steam - decimal

						@Boiler, 
						-- Boiler - decimal

						@Stack, 
						-- Stack - decimal

						@Rewashfactor, 
						-- RewashFactor - decimal

						@Evaporationfactor, 
						-- EvaporationFactor - decimal

						@Userid, 
						-- LastModifiedByUserId - int

						@Myservicelastsynctime)

		END

END