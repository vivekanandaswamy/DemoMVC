
BEGIN
SET NOCOUNT ON
	DECLARE @Price NVARCHAR(500) = NULL
	DECLARE @Electrictariff NVARCHAR(500) = NULL
	DECLARE @Gasoilprice NVARCHAR(500) = NULL
	DECLARE @Temperature NVARCHAR(500) = NULL
	DECLARE @Energycontent NVARCHAR(500) = NULL
	DECLARE @CurrencySymbol nvarchar(10) ='$'
	DECLARE @Uom INT = (SELECT
								UOMId FROM TCD.plant WHERE EcolabAccountNumber = @Ecolabaccountnumber) --Remove the EcolabAccountNumber from here and pass it as parameter
	DECLARE @Languageid INT = (SELECT
									   LanguageId FROM TCD.plant WHERE EcolabAccountNumber = @Ecolabaccountnumber) --Remove the EcolabAccountNumber from here and pass it as parameter
  BEGIN 
		SELECT 
				TOP(1) @CurrencySymbol = cs.CurrencySymbol  
			FROM dbo.CurrencySymbol cs 
			WHERE cs.CurrencyCode = ( SELECT TOP(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)

		SELECT
				@Price = SubUnit FROM TCD.GetDimensionalUnits('Price_tcd', @Uom)
		SELECT
				@Electrictariff = SubUnit
			FROM TCD.GetDimensionalUnits('Price_Electric_Tariff_Tcd', @Uom)
		SELECT
				@Gasoilprice = SubUnit FROM TCD.GetDimensionalUnits('Price_GasOil_Tcd', @Uom)
		SELECT
				@Temperature = SubUnit FROM TCD.GetDimensionalUnits('Temperature_CandF', @Uom)
		SELECT
				@Energycontent = SubUnit
			FROM TCD.GetDimensionalUnits('Energy_Content_TCD', @Uom)

		SELECT
				@Price = ResourceKeyValue.Value
			FROM TCD.ResourceKeyMaster
				 INNER JOIN TCD.ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName
			WHERE ResourceKeyMaster.KeyName = @Price
			  AND languageID = @Languageid
		SELECT
				@Electrictariff = ResourceKeyValue.Value
			FROM TCD.ResourceKeyMaster
				 INNER JOIN TCD.ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName
			WHERE ResourceKeyMaster.KeyName = @Electrictariff
			  AND languageID = @Languageid
		SELECT
				@Gasoilprice = ResourceKeyValue.Value
			FROM TCD.ResourceKeyMaster
				 INNER JOIN TCD.ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName
			WHERE ResourceKeyMaster.KeyName = @Gasoilprice
			  AND languageID = @Languageid
		SELECT
				@Temperature = ResourceKeyValue.Value
			FROM TCD.ResourceKeyMaster
				 INNER JOIN TCD.ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName
			WHERE ResourceKeyMaster.KeyName = @Temperature
			  AND languageID = @Languageid
		SELECT
				@Energycontent = ResourceKeyValue.Value
			FROM TCD.ResourceKeyMaster
				 INNER JOIN TCD.ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName
			WHERE ResourceKeyMaster.KeyName = @Energycontent
			  AND languageID = @Languageid

		SELECT	REPLACE(@price, '#currency#', @CurrencySymbol) AS Price 
    ,			REPLACE(@ElectricTariff, '#currency#', @CurrencySymbol) AS ElectricPrice
    ,			REPLACE(@gasOilPrice, '#currency#', @CurrencySymbol) AS GasPrice
    ,			@Temperature AS Temperature
    ,			@EnergyContent AS EnergyContent
 
  END 
END