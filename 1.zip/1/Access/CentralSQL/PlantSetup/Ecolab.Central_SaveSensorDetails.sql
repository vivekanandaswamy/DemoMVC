BEGIN 
	BEGIN 
		SET NOCOUNT ON; 

		DECLARE @Isplant  BIT = NULL, 
				@Ispress  BIT = NULL, 
				@Istunnel INT = ''; 
		DECLARE @Typelimit         INT = NULL, 
				@Templimit         INT = NULL, 
				@Phlimit           INT = NULL, 
				@Conductivitylimit INT = NULL, 
				@Weightlimit       INT = NULL, 
				@RedoxLimit        INT = NULL, 
				@Controllermodelid INT = NULL; 
		DECLARE @Returnvalue       INT = 0, 
				@Errorid           INT = 0, 
				@Errormessage      NVARCHAR(4000) = N'', 
				@Currentutctime    DATETIME = Getutcdate(), 
				@Newidtobeinserted INT = NULL; 
		DECLARE @Outputlist AS TABLE 
		  ( 
			 SensorId              INT, 
			 LastModifiedTimestamp DATETIME 
		  ); 

		SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL);
		SET @Outputsensorid = ISNULL(@Outputsensorid, NULL); 
		/*Maximum one Sensor with the same type can be connected to one machine/Compartement */
		SET @Scope = ''; 

		SELECT @Typelimit = Count(1) 
		FROM   TCD.Sensor AS S 
		WHERE  GroupId = @Sensorlocation 
			   AND S.SensorType = @Sensortype 
			   AND ISNULL(MachineCompartment, 0) = @Machinecompartment 
			   AND Is_deleted = 0 
			   AND ControllerID IN(SELECT ControllerId 
								   FROM   TCD.ConduitController 
								   WHERE  ControllerId = @Controllerid 
										  AND EcoalabAccountNumber = @Ecolabaccountnumber) 
			   AND EcolabAccountNumber = @Ecolabaccountnumber; 

		/*Maximum 6 Temperature sensor can be connected to the same Washter-Tunnel */ 
		SELECT @Templimit = Count(1) 
		FROM   TCD.Sensor AS S 
			   LEFT OUTER JOIN TCD.machinesetup AS MS 
							ON S.GroupId = MS.groupId 
							   AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
		WHERE  S.SensorType = 1 
			   AND S.GroupID = @Sensorlocation 
			   AND Ms.Istunnel = 1 
			   AND IS_deleted = 0 
			   AND S.ControllerID IN(SELECT ControllerId 
									 FROM   TCD.ConduitController 
									 WHERE  ControllerModelId = 7 
											AND EcoalabAccountNumber = @Ecolabaccountnumber) 
			   AND S.EcolabAccountNumber = @Ecolabaccountnumber; 

		/* Maximum 2 pH sensor can be connected to the same Washer-Tunnel */ 
		SELECT @Phlimit = Count(1) 
		FROM   TCD.Sensor AS S 
			   LEFT OUTER JOIN TCD.machinesetup AS MS 
							ON S.GroupId = MS.groupId 
							   AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
		WHERE  S.SensorType = 2 
			   AND S.GroupID = @Sensorlocation 
			   AND Ms.Istunnel = 1 
			   AND IS_deleted = 0 
			   AND S.ControllerID IN(SELECT ControllerId 
									 FROM   TCD.ConduitController 
									 WHERE  ControllerModelId = 7 
											AND EcoalabAccountNumber = @Ecolabaccountnumber) 
			   AND S.EcolabAccountNumber = @Ecolabaccountnumber; 

		/* Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel */ 
		SELECT @Conductivitylimit = Count(1) 
		FROM   TCD.Sensor AS S 
			   LEFT OUTER JOIN TCD.machinesetup AS MS 
							ON S.GroupId = MS.groupId 
							   AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
		WHERE  S.SensorType = 4 
			   AND S.GroupID = @Sensorlocation 
			   AND Ms.Istunnel = 1 
			   AND IS_deleted = 0 
			   AND S.ControllerID IN(SELECT ControllerId 
									 FROM   TCD.ConduitController 
									 WHERE  ControllerModelId = 7 
											AND EcoalabAccountNumber = @Ecolabaccountnumber) 
			   AND S.EcolabAccountNumber = @Ecolabaccountnumber; 

		/* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */ 
		SELECT @Weightlimit = Count(1) 
		FROM   TCD.Sensor AS S 
			   LEFT OUTER JOIN TCD.machinesetup AS MS 
							ON S.GroupId = MS.groupId 
							   AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
		WHERE  S.SensorType = 5 
			   AND S.GroupID = @Sensorlocation 
			   AND Ms.Istunnel = 1 
			   AND IS_deleted = 0 
			   AND S.ControllerID IN(SELECT ControllerId 
									 FROM   TCD.ConduitController 
									 WHERE  ControllerModelId = 7 
											AND EcoalabAccountNumber = @Ecolabaccountnumber) 
			   AND S.EcolabAccountNumber = @Ecolabaccountnumber; 

		/* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */ 
		SELECT @RedoxLimit = Count(1) 
		FROM   TCD.Sensor AS S 
			   LEFT OUTER JOIN TCD.machinesetup AS MS 
							ON S.GroupId = MS.groupId 
							   AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
		WHERE  S.SensorType = 5 
			   AND S.GroupID = @Sensorlocation 
			   AND Ms.Istunnel = 1 
			   AND IS_deleted = 0 
			   AND S.ControllerID IN(SELECT ControllerId 
									 FROM   TCD.ConduitController 
									 WHERE  ControllerModelId = 7 
											AND EcoalabAccountNumber = @Ecolabaccountnumber) 
			   AND S.EcolabAccountNumber = @Ecolabaccountnumber; 

		SELECT @Controllermodelid = ControllerModelId 
		FROM   TCD.ConduitController 
		WHERE  ControllerId = @Controllerid 
			   AND EcoalabAccountNumber = @Ecolabaccountnumber; 

		SELECT @Istunnel = Istunnel 
		FROM   TCD.machinesetup AS MS 
		WHERE  Ms.GroupId = @Sensorlocation 
			   AND MS.EcoalabAccountNumber = @Ecolabaccountnumber; 

		IF @IStunnel = 1 
		  BEGIN 
			  IF @MachineCompartment = 1 
				BEGIN 
					SET @IsPress = 1; 
				END; 
		  END; 

		IF @MachineCompartment = 0 
		  BEGIN 
			  SET @MachineCompartment = NULL; 
		  END; 

		IF @Sensorlocation = 1 
		  BEGIN 
			  SET @Isplant = 1; 
			  SET @Sensorlocation = NULL; 
			  SET @Machinecompartment = NULL; 
			  SELECT @Typelimit = Count(1) 
		FROM   TCD.Sensor AS S 
		WHERE  GroupId IS NULL
			   AND S.SensorType = @Sensortype 
			   AND MachineCompartment IS NULL
			   AND Is_deleted = 0 
			   AND ControllerID IN(SELECT ControllerId 
								   FROM   TCD.ConduitController 
								   WHERE  ControllerId = @Controllerid 
										  AND EcoalabAccountNumber = @Ecolabaccountnumber) 
			   AND EcolabAccountNumber = @Ecolabaccountnumber; 
		  END; 

		IF @Controllerid = -1 
		  BEGIN 
			  SELECT TOP (1) @Controllerid = ControllerID 
			  FROM   TCD.ConduitController 
			  WHERE  ControllerModelId = @Controllermodelid 
					 AND EcoalabAccountNumber = @Ecolabaccountnumber; 
		  END; 
		ELSE 
		  BEGIN 
			  SELECT @Controllermodelid = ControllerModelId 
			  FROM   TCD.ConduitController 
			  WHERE  ControllerId = @Controllerid 
					 AND EcoalabAccountNumber = @Ecolabaccountnumber; 
		  END; 

		IF @Controllerid != -1 
		  BEGIN 
			  /* Inserting the values in to Sensor table if it is new Sensor */ 
			  DECLARE @Newsensorid      INT, 
					  @Moduletype       INT = 3, 
					  @Defaultfrequency INT = 60, 
					  @Tagtype          VARCHAR(100) = 'Tag_MPLC', 
					  @Tagtypesc4       VARCHAR(100) = 'Tag_SC4', 
					  @Tagtypesc20      VARCHAR(100) = 'Tag_SC20', 
					  @Result1          INT = NULL, 
					  @Result2          INT = NULL, 
					  @Result3          INT = NULL, 
					  @Type             INT = 3 

			  IF NOT EXISTS(SELECT * 
							FROM   TCD.Sensor s1 
							WHERE  SensorID = @Sensornumber 
								   AND s1.EcolabAccountNumber = @Ecolabaccountnumber) 
				-- Begin Create Sensor 
				BEGIN 
					IF( @Result1 IS NULL 
						 OR @Result1 <> 0 ) 
					  AND ( @Result2 IS NULL 
							 OR @Result2 <> 0 ) 
					  AND ( @Result3 IS NULL 
							 OR @Result3 <> 0 ) 
					  BEGIN 
						  DECLARE @Allowinsert BIT = 'FALSE'; 

						  -- Begin Business Validations 
						  IF @Typelimit < 1 
							BEGIN 
								IF @Controllermodelid = 7 
								  BEGIN 
									  IF @Sensortype = 1 
										BEGIN 
											IF @Templimit < 6 
											  BEGIN 
												  SET @Allowinsert = 'TRUE'; 
											  END; 
											ELSE 
											  BEGIN 
												  SET @Scope = @Scope + '401,'; 
											  END; 
										END; 
									  ELSE 
										BEGIN 
											IF @Sensortype = 2 
											  BEGIN 
												  IF @Phlimit < 2 
													BEGIN 
														SET @Allowinsert = 'TRUE'; 
													END; 
												  ELSE 
													BEGIN 
														SET @Scope = @Scope + '301,'; 
													END; 
											  END; 
											ELSE 
											  BEGIN 
												  IF @SensorType = 3 
													BEGIN 
														IF @RedoxLimit < 1 
														  BEGIN 
															  SET @AllowInsert = 'TRUE'; 
														  END; 
														ELSE 
														  BEGIN 
															  SET @SCOPE = @SCOPE + '301,'; 
														  END; 
													END; 
												  ELSE 
													BEGIN 
														IF @Sensortype = 4 
														  BEGIN 
															  IF @Conductivitylimit < 1 
																BEGIN 
																	SET @Allowinsert = 'TRUE';
																END; 
															  ELSE 
																BEGIN 
																	SET @Scope = @Scope + '201,';
																END; 
														  END; 
														ELSE 
														  BEGIN 
															  IF @Sensortype = 5 
																BEGIN 
																	IF @Weightlimit < 1 
																	  BEGIN 
																		  SET @Allowinsert = 'TRUE';
																	  END; 
																	ELSE 
																	  BEGIN 
																		  SET @Scope = @Scope + '101,';
																	  END; 
																END; 
														  END; 
													END; 
											  END; 
										END; 
								  END; 
								ELSE 
								  BEGIN 
									  SET @Allowinsert = 'TRUE'; 
								  END; 
							END; 
						  ELSE 
							BEGIN 
								SET @Scope = @Scope + '501,'; 
							END; 

						  -- End Business Validations 
						  -- Begin Insert if Validation Succeeds 
						  IF @Allowinsert = 'TRUE' 
							BEGIN 
								DECLARE @Sensorcount INT 

								SELECT @Sensorcount = Max(s.SensorId) 
								FROM   TCD.Sensor AS s WITH (NOLOCK) 

								SELECT @Sensorcount = CASE 
														WHEN Count(@Sensorcount) <> 1 THEN 1 
														ELSE @Sensorcount + 1 
													  END 

								SET @Newidtobeinserted = (SELECT ISNULL(Max(S.SensorId), 0) + 1
														  FROM   TCD.Sensor AS S 
														  WHERE  S.EcolabAccountNumber = @Ecolabaccountnumber);

								INSERT INTO TCD.Sensor 
											(SensorId, 
											 Description, 
											 SensorType, 
											 GroupId, 
											 MachineCompartment, 
											 EcolabAccountNumber, 
											 ControllerID, 
											 OutputType, 
											 ChemicalforChart, 
											 UOM, 
											 DashboardActualValue, 
											 LastModifiedByUserId, 
											 IsPlant, 
											 IsPress, 
											 Calibration4mA, 
											 Calibration20mA, 
											 Id, 
											 SensorNum, 
											 AlarmEnable, 
											 MinimumAlarmValue, 
											 MaximumAlarmValue, 
											 AnalogueInputNumber,
										 ControllerEquipmentID) 
								OUTPUT      inserted.SensorId AS SensorId, 
											inserted.LastModifiedTime AS LastModifiedTimestamp
								INTO @Outputlist( SensorId, LastModifiedTimestamp) 
								SELECT @Newidtobeinserted, 
									   @Sensorname, 
									   @Sensortype, 
									   @Sensorlocation, 
									   @Machinecompartment, 
									   @Ecolabaccountnumber, 
									   @Controllerid, 
									   @Outputtype, 
									   @Chemicalforchart, 
									   @Uom, 
									   @Dashboardactualvalue, 
									   @Userid, 
									   @Isplant, 
									   @Ispress, 
									   @Calibration4ma, 
									   @Calibration20ma, 
									   @Sensorcount, 
									   @SensorNum, 
									   @AlarmEnable, 
									   @MinimumAlarmValue, 
									   @MaximumAlarmValue, 
									   @ExternalSensor,
								   @PumpNumber; 

								SELECT TOP 1 @Newsensorid = O.SensorId 
								FROM   @Outputlist AS O; 
							END; 
					  -- End Insert if Validation Succeeds 
					  --UPDATE TCD.Sensor 
					  --  SET Id = @NewSensorId 
					  --  ,LastModifiedByUserId = @UserID 
					  --  WHERE SensorId = @NewSensorId 
					  --AND EcolabAccountNumber = @EcolabAccountNumber; 
					  END; 
				END; 
			  -- End Create Sensor 
			  ELSE 
				-- Begin Update Sensor 
				BEGIN 
					DECLARE @Plantid INT = (SELECT MG.Id 
					   FROM   TCD.MachineGroupType AS MGT 
							  INNER JOIN TCD.MachineGroup AS MG 
									  ON MGT.Id = MG.GroupTypeId 
					   WHERE  MGT.Id = 1 
							  AND MG.Is_Deleted = 0 
							  AND MG.EcolabAccountNumber = @Ecolabaccountnumber); 

					-- Check RedFlag Association and Update Sensor 
					IF( (SELECT COALESCE(S.GroupId, '') 
						 FROM   TCD.Sensor AS S 
						 WHERE  S.SensorId = @Sensornumber 
								AND S.EcolabAccountNumber = @Ecolabaccountnumber) != COALESCE(@Sensorlocation, '')
						 OR (SELECT COALESCE(S.MachineCompartment, '') 
							 FROM   TCD.Sensor AS S 
							 WHERE  S.SensorId = @Sensornumber 
									AND S.EcolabAccountNumber = @Ecolabaccountnumber) != COALESCE(@Machinecompartment, '') )
					  AND EXISTS(SELECT 1 
								 FROM   TCD.RedFlag AS RF 
										INNER JOIN TCD.RedFlagMappingData AS RFM 
												ON RF.Id = RFM.MappingId 
												   AND RF.Is_Deleted = 0 
												   AND RFM.Is_Deleted = 0 
												   AND RF.EcolabAccountNumber = RFM.EcolabAccountNumber
										LEFT JOIN TCD.Sensor AS S 
											   ON RF.Location = CASE S.IsPlant 
																  WHEN 'TRUE' THEN COALESCE(S.GroupId, @Plantid)
																  ELSE S.GroupId 
																END 
												  AND COALESCE(S.MachineCompartment, 0) = COALESCE(RFM.MachineId, 0)
												  AND S.Is_deleted = 0 
												  AND S.EcolabAccountNumber = RF.EcolabAccountNumber
								 WHERE  S.SensorId = @Sensornumber 
										AND RF.EcolabAccountNumber = @Ecolabaccountnumber) 
					  BEGIN 
						  SET @Scope = '405,'; 
					  END; 
					ELSE 
					  BEGIN 
						  SET @Scope = @Scope + CONVERT(VARCHAR(100), ''); 

						  IF( @Result1 IS NULL 
							   OR @Result1 <> 0 ) 
							AND ( @Result2 IS NULL 
								   OR @Result2 <> 0 ) 
							AND ( @Result3 IS NULL 
								   OR @Result3 <> 0 ) 
							BEGIN 
								DECLARE @Allowupdate BIT = 'FALSE'; 

								--Begin Get old Sensor Values  
								BEGIN 
									DECLARE @Uty INT = (SELECT sensortype 
									   FROM   TCD.Sensor 
									   WHERE  SensorID = @Sensornumber 
											  AND EcolabAccountNumber = @Ecolabaccountnumber);
									DECLARE @Grpid INT = (SELECT GroupId 
									   FROM   TCD.Sensor 
									   WHERE  SensorID = @Sensornumber 
											  AND EcolabAccountNumber = @Ecolabaccountnumber);
									DECLARE @Machid INT = (SELECT MachineCompartment 
									   FROM   TCD.Sensor 
									   WHERE  SensorID = @Sensornumber 
											  AND EcolabAccountNumber = @Ecolabaccountnumber);
								END; 

								--Begin Get old Sensor Values  
								IF @Uty <> @Sensortype 
									OR @Grpid <> @Sensorlocation 
									OR @Machid <> @Machinecompartment 
								  BEGIN 
									  IF @Typelimit < 1 
										BEGIN 
											IF @Controllermodelid = 7 
											  BEGIN 
												  IF @Sensortype = 1 
													BEGIN 
														IF @Templimit <= 6 
														  BEGIN 
															  SET @Allowupdate = 'TRUE'; 
														  END; 
														ELSE 
														  BEGIN 
															  SET @Scope = @Scope + '401,'; 
														  END; 
													END; 
												  ELSE 
													BEGIN 
														IF @Sensortype = 2 
														  BEGIN 
															  IF @Phlimit <= 2 
																BEGIN 
																	SET @Allowupdate = 'TRUE';
																END; 
															  ELSE 
																BEGIN 
																	SET @Scope = @Scope + '301,';
																END; 
														  END; 
														ELSE 
														  BEGIN 
															  IF @SensorType = 3 
																BEGIN 
																	IF @RedoxLimit <= 1 
																	  BEGIN 
																		  SET @Allowupdate = 'TRUE';
																	  END; 
																	ELSE 
																	  BEGIN 
																		  SET @SCOPE = @SCOPE + '301,';
																	  END; 
																END; 
															  ELSE 
																BEGIN 
																	IF @Sensortype = 4 
																	  BEGIN 
																		  IF @Conductivitylimit <= 1
																			BEGIN 
																				SET @Allowupdate = 'TRUE';
																			END; 
																		  ELSE 
																			BEGIN 
																				SET @Scope = @Scope + '201,';
																			END; 
																	  END; 
																	ELSE 
																	  BEGIN 
																		  IF @Sensortype = 5 
																			BEGIN 
																				IF @Weightlimit <= 1
																				  BEGIN 
																					  SET @Allowupdate = 'TRUE';
																				  END; 
																				ELSE 
																				  BEGIN 
																					  SET @Scope = @Scope + '101,';
																				  END; 
																			END; 
																	  END; 
																END; 
														  END; 
													END; 
											  END; 
											ELSE 
											  BEGIN 
												  BEGIN 
													  SET @Allowupdate = 'TRUE'; 
												  END; 
											  END; 
										END; 
									  ELSE 
										BEGIN 
											SET @Scope = @Scope + '501,'; 
										END; 
								  END; 
								ELSE 
								  BEGIN 
									  SET @Allowupdate = 'TRUE'; 
								  END; 

								IF @Allowupdate = 'TRUE' 
								  BEGIN 
									  IF @Lastmodifiedtimestampatcentral IS NOT NULL 
										 AND NOT EXISTS(SELECT 1 
														FROM   TCD.Sensor AS S 
														WHERE  S.EcolabAccountNumber = @Ecolabaccountnumber
															   AND S.SensorId = @Sensornumber
															   AND S.LastModifiedTime = @Lastmodifiedtimestampatcentral)
										BEGIN 
											SET @Errorid = 60000; 
											SET @Errormessage = N'' + Cast(@Errorid AS NVARCHAR)
																+ N': Record not in-synch between plant and central.'; 

											RAISERROR(@Errormessage,16,1); 

											SET @Returnvalue = -1; 
										--RETURN @Returnvalue; 
										END; 

									  UPDATE s 
									  SET    Description = @Sensorname, 
											 SensorType = @Sensortype, 
											 GroupId = @Sensorlocation, 
											 MachineCompartment = @Machinecompartment, 
											 S.ControllerID = @Controllerid, 
											 OutputType = @Outputtype, 
											 ChemicalforChart = @Chemicalforchart, 
											 UOM = @Uom, 
											 DashboardActualValue = @Dashboardactualvalue, 
											 LastModifiedByUserId = @Userid, 
											 Calibration4mA = @Calibration4ma, 
											 Calibration20mA = @Calibration20ma, 
											 LastModifiedTime = @Currentutctime, 
											 SensorNum = @SensorNum, 
											 AlarmEnable = @AlarmEnable, 
											 MinimumAlarmValue = @MinimumAlarmValue, 
											 MaximumAlarmValue = @MaximumAlarmValue, 
											 AnalogueInputNumber = @ExternalSensor  ,
										   ControllerEquipmentID = @PumpNumber
									  OUTPUT inserted.SensorId AS SensorId, 
											 inserted.LastModifiedTime AS LastModifiedTimestamp
									  INTO @Outputlist( SensorId, LastModifiedTimestamp) 
									  FROM   TCD.Sensor S 
									  WHERE  SensorID = @Sensornumber 
											 AND EcolabAccountNumber = @Ecolabaccountnumber; 
								  END; 
							END; 
					  END; 
				END; 
		  -- End Update Sensor 
		  END; 
		ELSE 
		  BEGIN 
			  SELECT @Scope = '701,'; 
		  END; 

		SET NOCOUNT OFF; 

		SELECT TOP 1 @Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
					 @Outputsensorid = O.SensorId 
		FROM   @Outputlist AS O; 
	END; 
/* -----------TEST CASES -------------- 
   
  SELECT * FROM AUDITCOLUMNS 

  SELECT * FROM AUDITCOLUMNSDETAILS_NEW 

  SELECT * FROM PLANTCONTACT ORDER BY ID 

  TRUNCATE TABLE AUDITCOLUMNS 
  TRUNCATE TABLE AUDITCOLUMNSDETAILS_NEW 

  TRUNCATE TABLE SENSOR 

  SELECT * FROM SENSOR 

  SELECT * FROM METER 

  EXEC [dbo].[usp_AuditingInsertDetails] 1,'SENSOR',1 

  */ 
END; 