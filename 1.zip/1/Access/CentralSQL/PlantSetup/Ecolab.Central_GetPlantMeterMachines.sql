
    BEGIN 
	SET NOCOUNT ON;
	DECLARE @Istunnel INT = NULL, 
			@Typeid INT = NULL;
	SELECT
			@Istunnel = Istunnel
		FROM TCD.machinesetup
		WHERE GroupId = @Grouptypeid
			AND EcoalabAccountNumber = @Ecolabaccountnumber;
		
	SELECT
			@Typeid = GroupTypeId
		FROM TCD.MachineGroup
		WHERE Id = @Grouptypeid
			AND Is_Deleted = 0
			AND EcolabAccountNumber = @Ecolabaccountnumber;
	IF @Typeid = 1
		BEGIN
			SELECT
					0, 
					'ALL', 
					NULL, 
					0;
		END;
		ELSE
			BEGIN
			IF @Typeid = 2
				BEGIN
					IF @Istunnel = 1
						BEGIN
							DECLARE @Noofcomp INT, 
									@Count INT = 2, 
									@Haspress BIT, 
									@Controllerid INT,
									@Controllermodelid INT,
									@Washerid INT;
							SELECT
									@Washerid = ms.WasherId
								FROM TCD.MachineSetup AS ms
								WHERE ms.EcoalabAccountNumber = @Ecolabaccountnumber
									AND Groupid = @Grouptypeid
									AND IsTunnel = 1;
							SELECT
									@Controllermodelid = cc.ControllerModelId,
									@Controllerid = cc.ControllerId
								FROM tcd.ConduitController AS cc
								WHERE cc.EcoalabAccountNumber = @Ecolabaccountnumber
									AND cc.ControllerId = (SELECT
																	ControllerId
																FROM TCD.MachineSetup AS ms
																WHERE ms.EcoalabAccountNumber = @Ecolabaccountnumber
																	AND ms.WasherId = @Washerid);
							IF @Controllermodelid = 11 AND @Sensortypeid = 5
							BEGIN
									SELECT
											@Noofcomp = NumberOfCompartmentsConveyorBelt
										FROM tcd.washer AS w
										WHERE w.EcolabAccountNumber = @Ecolabaccountnumber
											AND w.WasherId = @Washerid;
								END;
							ELSE
							BEGIN
								SELECT
										@Noofcomp = NumberOfComp, 
										@Controllerid = ControllerId
									FROM TCD.MachineSetup
										WHERE EcoalabAccountNumber = @Ecolabaccountnumber
									  AND Groupid = @Grouptypeid
											AND IsTunnel = 1;
								END;
							SELECT
									@Haspress = HasPress
								FROM TCD.machinesetup
								WHERE EcoalabAccountNumber = @Ecolabaccountnumber
									AND GroupId = @Grouptypeid;
							--IF((SELECT COUNT(1) FROM TCD.GROUPTYPE GT LEFT JOIN TCD.MachineSetup MS ON MS.GroupId = GT.Id WHERE GT.Id = @GroupTypeID AND MS.HasPress = 1)>0)
							--SET @HasPress = 1 ELSE SET @HasPress = 0
							CREATE TABLE #GET_COMPARTMENT(
					MachineID INT,
					CompartmentNumber VARCHAR(1000),
					ControllerId INT,
									PlantWasherNumber INT);
							WHILE @Count <= @Noofcomp + 1
					BEGIN 
									INSERT INTO #GET_COMPARTMENT(
											MachineID, 
											CompartmentNumber, 
											ControllerId, 
											PlantWasherNumber)
									SELECT
											@Count - 1,
											'Compartment' + CAST(@Count - 1 AS VARCHAR(1000)) + '', 
											@Controllerid, 
											0;
									SET @Count = @Count + 1;
								END;
							IF @Haspress = 1
								BEGIN
									  SELECT
											  0, 
											  'ALL', 
											  @Controllerid, 
											  0
									  UNION
									  SELECT
											  1, 
											  'Press', 
											  @Controllerid, 
											  0
									  UNION ALL
									  SELECT
											  MachineID, 
											  CompartmentNumber, 
											  ControllerId, 
											  PlantWasherNumber
											FROM #GET_COMPARTMENT;
								END;
							ELSE
								BEGIN
									  SELECT
											  0, 
											  'ALL', 
											  @Controllerid, 
											  0
									  UNION ALL
									  SELECT
											  MachineID, 
											  CompartmentNumber, 
											  ControllerId, 
											  PlantWasherNumber
											FROM #GET_COMPARTMENT;
								END;
						END;
					ELSE 
						BEGIN 
							SELECT
									  0, 
									  'ALL', 
									  NULL, 
									  0
							  UNION 
							  SELECT DISTINCT
										CAST(MS.WasherId AS INT),
									  MS.MachineName, 
										CAST(MS.ControllerId AS INT),
										CAST(WS.PlantWasherNumber AS INT)
								  FROM TCD.machinesetup AS MS
										LEFT JOIN TCD.Washer AS WS ON MS.WasherId = WS.WasherId
																AND MS.EcoalabAccountNumber = WS.Ecolabaccountnumber
								  WHERE GroupID = @Grouptypeid
									AND IsDeleted = 0
									AND EcoalabAccountNumber = @Ecolabaccountnumber
										AND ISNULL(MS.ControllerId, 0) != 0;
						END;
				END;
		 ELSE
				BEGIN
					IF @Typeid = 3
						BEGIN SELECT
									  0, 
									  'ALL', 
									  NULL, 
									  0
			UNION 
							  SELECT DISTINCT
									  Id, 
									  Description, 
									  NULL, 
									  0
								  FROM TCD.Dryers AS D
								  WHERE D.DryerGroupId = @Grouptypeid
									AND Is_deleted = 0
										AND EcolabAccountNumber = @Ecolabaccountnumber;
						END;
	    ELSE
						BEGIN
							IF @Typeid = 4
								BEGIN SELECT
											  0, 
											  'ALL', 
											  NULL, 
											  0
			UNION 
									  SELECT DISTINCT
											  FinnisherId, 
											  Name, 
											  NULL, 
											  0
										  FROM TCD.Finnishers AS F
										  WHERE F.FinnisherGroupId = @Grouptypeid
											AND Is_deleted = 0
												AND EcolabAccountNumber = @Ecolabaccountnumber;
								END;
		 ELSE
		 BEGIN
									IF @Typeid = 5
										BEGIN SELECT
													  0, 
													  'ALL', 
													  NULL, 
													  0
			UNION
											  SELECT DISTINCT
													  WE.DeviceNumber, 
													  WE.DeviceName, 
													  NULL, 
													  0
												  FROM TCD.WaterAndEnergy AS WE
												  WHERE WE.Is_deleted = 0
														AND EcolabAccountNumber = @Ecolabaccountnumber;
										END;
								END;
						END;
				END;
		END;

	SET NOCOUNT OFF;
END;