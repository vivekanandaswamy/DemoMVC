
  BEGIN 
	SET NOCOUNT ON;

	SELECT
			we.Id, 
			we.DeviceNumber, 
	 we.DeviceName,
	 we.DeviceTypeId,
			(SELECT DISTINCT
					 dt.Description
				 FROM TCD.DeviceType AS dt
				 WHERE we.DeviceTypeId = dt.DeviceTypeId)AS DeviceType, 
	 we.DeviceModelId,
			(SELECT DISTINCT
					 dm.Description FROM TCD.DeviceModel AS dm WHERE we.DeviceModelId = dm.Id)AS DeviceModel, 
	 we.DeviceNote,
			we.EcolabAccountNumber, 
			we.Comment, 
			we.InstallDate, 
			we.LastModifiedTime, 
     we.LastSyncTime,
     we.Is_deleted,
     we.MyServiceCustWtrEnrgDvcGuid
		FROM TCD.WaterAndEnergy AS we
		WHERE (@Isresync IS NULL
		  AND we.Is_deleted != 1
		  AND we.EcolabAccountNumber = @Ecolabaccountnumber)
		   OR (@Isresync IS NOT NULL
		  AND we.EcolabAccountNumber = @Ecolabaccountnumber)
		ORDER BY we.DeviceNumber
	SET NOCOUNT OFF;
  END