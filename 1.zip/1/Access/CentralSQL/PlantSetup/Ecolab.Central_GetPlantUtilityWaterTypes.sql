
  BEGIN 
	SET NOCOUNT ON;
	SELECT
			Id, 
			Name, 
			TCD.WaterType.RegionID, 
			MyServiceUtilTypeCode
		FROM TCD.WaterType
		WHERE RegionID = @RegionId
		AND (Name NOT IN ('Cold Soft', 'Hot Soft')) 
		ORDER BY Id
  END