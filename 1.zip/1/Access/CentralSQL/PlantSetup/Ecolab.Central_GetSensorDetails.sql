BEGIN 
    SET NOCOUNT ON; 

    DECLARE @Controllerid INT = NULL 

    SELECT @Controllerid = ControllerID 
    FROM   TCD.Sensor 
    WHERE  SensorId = @Sensorid 
           AND EcolabAccountNumber = @Ecolabaccountnumber 

    DECLARE @Waterandenergygroupid INT = (SELECT TOP (1) MG.Id 
       FROM   TCD.MachineGroup AS MG 
              INNER JOIN TCD.MachineGroupType AS MGT 
                      ON MGT.Id = MG.GroupTypeId 
       WHERE  MGT.Id = 5 
              AND MG.EcolabAccountNumber = @Ecolabaccountnumber); 

    SELECT S.SensorId, 
           S.Description, 
           S.SensorType, 
           (SELECT Name 
            FROM   TCD.SensorTypemaster AS rm 
            WHERE  rm.Resourceid = S.SensorType)                    AS SensorTypeName, 
           S.EcolabAccountNumber, 
           CASE 
             WHEN S.Machinecompartment IS NULL THEN 
               CASE 
                 WHEN S.IsPress = 1 THEN 1 
                 ELSE 0 
               END 
             ELSE S.Machinecompartment 
           END                                                      AS Machinecompartment, 
           CASE 
             WHEN S.MachineCompartment IS NULL 
                  AND ( S.IsPress = 0 
                         OR S.IsPress IS NULL )THEN 'ALL' 
             WHEN(SELECT DISTINCT Istunnel 
                  FROM   TCD.machinesetup AS M 
                  WHERE  M.groupId = S.GroupId 
                         AND M.EcoalabAccountNumber = @Ecolabaccountnumber 
                         AND M.IsDeleted = 0) = 1 THEN 
               CASE 
                 WHEN S.MachineCompartment IS NULL 
                      AND S.IsPress = 1 THEN 'Press' 
                 ELSE 'Compartment' 
                      + Cast(S.Machinecompartment AS VARCHAR(100)) 
               END 
             WHEN(SELECT DISTINCT Istunnel 
                  FROM   TCD.machinesetup AS M 
                  WHERE  M.groupId = S.GroupId 
                         And M.EcoalabAccountNumber = @EcolabAccountNumber 
                         AND M.IsDeleted = 0) = 0 THEN(SELECT Cast(WS.PlantWasherNumber AS NVARCHAR)
                                                              + ':' + MachineName 
                                                       FROM   TCD.MachineSetup AS M 
                                                              INNER JOIN TCD.Washer AS WS 
                                                                      ON M.WasherId = WS.WasherId
                                                                         AND M.EcoalabAccountNumber = WS.EcoLabAccountNumber
                                                       WHERE  M.GroupId = S.GroupId 
                                                              AND M.WasherId = S.MachineCompartment
                                                              AND M.EcoalabAccountNumber = @EcolabAccountNumber)
             WHEN(SELECT DISTINCT GroupTypeId 
                  FROM   TCD.MachineGroup AS GT 
                  WHERE  GT.Id = S.GroupId 
                         AND EcolabAccountNumber = @Ecolabaccountnumber 
                         AND GT.Is_Deleted = 0) = 3 THEN(SELECT D.Description 
                                                         FROM   TCD.Dryers AS D 
                                                         WHERE  D.DryerGroupId = S.GroupId 
                                                                AND D.Id = S.MachineCompartment
                                                                AND EcolabAccountNumber = @Ecolabaccountnumber
                                                                AND D.Is_deleted = 0) 
             WHEN(SELECT DISTINCT GroupTypeId 
                  FROM   TCD.MachineGroup AS GT 
                  WHERE  GT.Id = S.GroupId 
                         AND EcolabAccountNumber = @Ecolabaccountnumber 
                         AND GT.Is_Deleted = 0) = 4 THEN(SELECT F.Name 
                                                         FROM   TCD.Finnishers AS F 
                                                         WHERE  F.FinnisherGroupId = S.GroupId
                                                                AND F.FinnisherId = S.MachineCompartment
                                                                AND EcolabAccountNumber = @Ecolabaccountnumber
                                                                AND F.Is_deleted = 0) 
             WHEN(SELECT DISTINCT GroupTypeId 
                  FROM   TCD.MachineGroup AS GT 
                  WHERE  GT.Id = S.GroupId 
                         AND EcolabAccountNumber = @Ecolabaccountnumber 
                         AND GT.Is_Deleted = 0) = 5 THEN(SELECT DeviceName 
                                                         FROM   TCD.WaterAndEnergy AS WE 
                                                         WHERE  S.GroupId = @Waterandenergygroupid
                                                                AND WE.DeviceNumber = S.MachineCompartment
                                                                AND WE.Is_deleted = 0 
                                                                AND EcolabAccountNumber = @Ecolabaccountnumber)
             WHEN(SELECT MM.MachineCompartment 
                  FROM   TCD.Meter AS MM 
                  WHERE  MM.GroupId = S.GroupId 
                         AND EcolabAccountNumber = @Ecolabaccountnumber 
                         AND MM.Is_deleted = 0) = 0 THEN 'Press' 
           END                                                      AS MachinecompartmentName,
           CC.ControllerID, 
           CC.Name                                                  AS ControllerName, 
           CC.ControllerModelId, 
           CM.RegionId                                              AS ControllerRegionId, 
           CT.Id                                                    AS ControllerTypeId, 
           CT.Name                                                  AS ControllerType, 
           S.OutputType, 
           S.ChemicalforChart, 
           (SELECT DISTINCT p.Name 
            FROM   TCD.productmaster AS P 
            WHERE  P.productId = S.ChemicalforChart 
                   AND s.EcolabAccountNumber = @Ecolabaccountnumber)AS ChemicalforChartName, 
           s.UOM, 
           'S.UOMName'                                              AS UOMName, 
           S.DashboardActualValue, 
           CASE 
             WHEN S.groupID IS NULL 
                  AND S.IsPlant = 1 THEN 1 
             ELSE(SELECT G.Id 
                  FROM   TCD.MachineGroup AS G 
                  WHERE  G.Id = S.groupID 
                         AND G.EcolabAccountNumber = @Ecolabaccountnumber) 
           END                                                      AS GroupId, 
           CASE 
             WHEN S.groupID IS NULL 
                  AND S.MachineCompartment IS NULL 
                  AND S.IsPlant = 1 THEN 'Plant' 
             ELSE(SELECT GroupDescription 
                  FROM   TCD.MachineGroup AS G 
                  WHERE  G.Id = S.groupID 
                         AND G.EcolabAccountNumber = @Ecolabaccountnumber) 
           END                                                      AS SensorLocation, 
           (SELECT MTS.TagAddress 
            FROM   TCD.ModuleTags AS MTS 
            WHERE  MTS.TagType = 'Tag_MPLC' 
                   AND MTS.ModuleID = SensorId 
                   AND MTS.ModuleTypeId = 3 
                   AND MTS.Active = 1)                              AS AnalogueInputNumber, 
           S.Calibration4mA, 
           S.Calibration20mA, 
           (SELECT MTS.TagAddress 
            FROM   TCD.ModuleTags AS MTS 
            WHERE  MTS.TagType = 'Tag_SC4' 
                   AND MTS.ModuleID = SensorId 
                   AND MTS.ModuleTypeId = 3 
                   AND MTS.Active = 1 
                   AND EcolabAccountNumber = @Ecolabaccountnumber)  AS CalibrationTag4, 
           (SELECT MTS.TagAddress 
            FROM   TCD.ModuleTags AS MTS 
            WHERE  MTS.TagType = 'Tag_SC20' 
                   AND MTS.ModuleID = SensorId 
                   AND MTS.ModuleTypeId = 3 
                   AND MTS.Active = 1 
                   AND EcolabAccountNumber = @Ecolabaccountnumber)  AS CalibrationTag20, 
           S.LastSyncTime, 
           S.LastModifiedTime, 
           s.SensorNum, 
           s.AlarmEnable, 
           s.MinimumAlarmValue, 
           s.MaximumAlarmValue, 
           s.AnalogueInputNumber,
		   M.MachineInternalId,  
           Cast(ISNULL(csd.Value, 0) AS BIT)                        AS ISWaterEnergyLogSel ,
		   wg.WasherGroupTypeId,
			 S.ControllerEquipmentID
    FROM   TCD.Sensor AS S 
			LEFT JOIN tcd.WasherGroup wg 
                     ON wg.WasherGroupId = S.GroupId 
					 AND s.EcolabAccountNumber = wg.EcolabAccountNumber
           LEFT JOIN TCD.ConduitController AS CC 
                  ON CC.ControllerId = S.ControllerID 
                     AND S.EcolabAccountNumber = CC.EcoalabAccountNumber 
           LEFT JOIN TCD.ControllerModel AS CM 
                  ON CM.Id = CC.ControllerModelId 
           LEFT JOIN TCD.ControllerType AS CT 
                  ON CT.Id = CC.ControllerTypeId 
           LEFT JOIN TCD.ControllerSetupData csd 
                  ON csd.ControllerId = S.ControllerID 
                     AND csd.FieldId = 473 
                     AND csd.FieldGroupId = 20 
                     AND csd.EcolabAccountNumber = S.EcolabAccountNumber 
			LEFT JOIN TCD.MachineSetup M 
                  ON m.WasherId = s.MachineCompartment 
				  AND s.EcolabAccountNumber = m.EcoalabAccountNumber
    WHERE  Is_Deleted = 0 
           AND s.EcolabAccountNumber = @Ecolabaccountnumber 

    SET NOCOUNT OFF; 
END 