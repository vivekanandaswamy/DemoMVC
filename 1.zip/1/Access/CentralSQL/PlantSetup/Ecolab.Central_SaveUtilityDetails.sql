
BEGIN
	SET NOCOUNT ON;
	DECLARE @Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Newidtobeinserted INT = 0,
			@Lastmodifiedtimestampatcentral DATETIME = NULL
	DECLARE @Outputlist AS TABLE(
			OutputDeviceNumber INT, 
			LastModifiedTimestamp DATETIME);

	/* Inserting the values in to WaterAndEnergy table if it is new meter */

	SET @Outputdevicenumber = ISNULL(@Outputdevicenumber, NULL)
	--SET @Scope = ISNULL(@Scope, NULL)
	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)
	SET @Myservicecustwtrenrgdvcguid = ISNULL(@Myservicecustwtrenrgdvcguid, NULL)

	IF NOT EXISTS(SELECT
						  *
					  FROM TCD.WaterAndEnergy
					  WHERE Id = @Id
						AND EcolabAccountNumber = @Ecolabaccountnumber)
		BEGIN
			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.WaterAndEnergy
							  WHERE DeviceName = @Devicename
								AND DeviceTypeId = @Devicetypeid
								AND DeviceModelId = @Devicemodelid
								AND Is_deleted = 'FALSE'
								AND EcolabAccountNumber = @Ecolabaccountnumber)
				BEGIN

					SET @Newidtobeinserted = (SELECT
													  ISNULL(MAX(WE.ID), 0) + 1
												  FROM TCD.WaterAndEnergy AS WE
												  WHERE WE.EcolabAccountNumber = @Ecolabaccountnumber)
								
					/* Inserting the Details of Water and Energy  in to WaterAndEnergy table if it is new device */

					INSERT INTO TCD.WaterAndEnergy(
							Id, 
							DeviceNumber, 
							DeviceName, 
							DeviceTypeId, 
							DeviceModelId, 
							DeviceNote, 
							EcolabAccountNumber, 
							Comment, 
							InstallDate, 
							Is_deleted, 
							LastModifiedByUserId, 
							MyServiceCustWtrEnrgDvcGuid, 
							MyServiceLastSynchTime)
					OUTPUT
							inserted.Id AS DeviceNumber, 
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							OutputDeviceNumber, 
							LastModifiedTimestamp)
						SELECT
								@Newidtobeinserted, 
								@Devicenumber, 
								@Devicename, 
								@Devicetypeid, 
								@Devicemodelid, 
								@Devicenote, 
								@Ecolabaccountnumber, 
								@Comment, 
								@Installdate, 
								@Is_Deleted, 
								@Userid, 
								@Myservicecustwtrenrgdvcguid, 
								@Myservicelastsynctime
				END
			ELSE
				BEGIN
					SET @Errormessage = '401';
					RAISERROR(@Errormessage, 16, 1);
					RETURN;
				END;
		END
	ELSE
		BEGIN
			IF @Lastmodifiedtimestampatcentral IS NOT NULL
		   AND NOT EXISTS(SELECT
								  1
							  FROM TCD.WaterAndEnergy AS WE
							  WHERE WE.EcolabAccountNumber = @Ecolabaccountnumber
								AND WE.Id = @Id
								AND WE.LastModifiedTime = @Lastmodifiedtimestampatcentral)
				BEGIN
					SET @Errorid = 60000;
					SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Record not in-synch between plant and central.';
					RAISERROR(@Errormessage, 16, 1)
					SET @Returnvalue = -1
					--RETURN @Returnvalue
				END

			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.WaterAndEnergy
							  WHERE DeviceName = @Devicename
								AND DeviceTypeId = @Devicetypeid
								AND DeviceModelId = @Devicemodelid
								AND Id != @Id
								AND Is_deleted = 'FALSE'
								AND EcolabAccountNumber = @Ecolabaccountnumber)
				BEGIN 
									
					/* Updating the value of Water And Energy details */

					UPDATE WE SET
							DeviceNumber = @Devicenumber, 
							DeviceName = @Devicename, 
							DeviceTypeId = @Devicetypeid, 
							DeviceModelId = @Devicemodelid, 
							Comment = @Comment, 
							InstallDate = @Installdate, 
							DeviceNote = @Devicenote, 
							LastModifiedByUserId = @Userid, 
							LastModifiedTime = @Currentutctime
					OUTPUT
							inserted.Id AS DeviceNumber, 
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							OutputDeviceNumber, 
							LastModifiedTimestamp)
						FROM TCD.WaterAndEnergy WE
						WHERE
							Id = @Id
						AND EcolabAccountNumber = @Ecolabaccountnumber

					--SELECT
							--@Scope = @Devicenumber
				END
			ELSE
				BEGIN
					SET @Errormessage = '401';
					RAISERROR(@Errormessage, 16, 1);
					RETURN;
				END
		END

	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputdevicenumber = O.OutputDeviceNumber
		FROM @Outputlist AS O

	--RETURN @Returnvalue

--SET NOCOUNT OFF;

END