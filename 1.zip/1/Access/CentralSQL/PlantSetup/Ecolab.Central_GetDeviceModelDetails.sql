
BEGIN
	SET NOCOUNT ON;

	SELECT
			Id, 
			Description 
			FROM TCD.DeviceModel DM
			INNER JOIN TCD.RegionMaster RM ON DM.RegionID=RM.RegionId  WHERE DeviceTypeId = @Devicetypeid AND DM.IsDeleted=0
			AND RM.RegionId IN (SELECT distinct RegionID from TCD.Plant where EcolabAccountNumber= @EcolabAccountNumber)
	SET NOCOUNT OFF;
END