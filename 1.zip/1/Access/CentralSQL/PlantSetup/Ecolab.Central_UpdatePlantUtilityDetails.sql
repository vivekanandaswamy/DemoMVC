
BEGIN
	DECLARE @Energyusagekey NVARCHAR(200), 
			@Lastmodifiedtime DATETIME

	SET @Energyusagekey = 'TCD_GasOil_Price'
	SET @Lastmodifiedtime = GETUTCDATE()

	IF @Waterfactortype = 'None'
BEGIN
			SET @Waterfactortypeid = 0
END


	UPDATE TOP (1) TCD.WaterUtilityDetails SET
			WaterFactorTypeId = @Waterfactortypeid, 
			Temperature = @Temperature, 
			Price = @Price, 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Lastmodifiedtime
		WHERE
			EcolabAccountNumber = @Ecolabaccountnumber
		AND WaterFactorTypeId = @Initalvalue

	IF @Count = 1
    BEGIN
			UPDATE TCD.EnergyUtilityDetails SET
					EcolabAccountNumber = @Ecolabaccountnumber, 
					GasOilTypeId = @Gasoiltypeid, 
					EnergyPrice = @Energyprice, 
					EnergyPriceUsageKey = @Energyusagekey, 
					EnergySubUnit = @Energypricesubunit, 
					ElectricPrice = @Electricalprice, 
					BolierSteam = @Boilersteam, 
					BolierType = @Boilertype, 
					Steam = @Steam, 
					Boiler = @Boiler, 
					Stack = @Stack, 
					RewashFactor = @Rewashfactor, 
					EvaporationFactor = @Evaporationfactor, 
					LastModifiedByUserId = @Userid, 
					LastModifiedTime = @Lastmodifiedtime
				WHERE EcolabAccountNumber = @Ecolabaccountnumber
 END
END