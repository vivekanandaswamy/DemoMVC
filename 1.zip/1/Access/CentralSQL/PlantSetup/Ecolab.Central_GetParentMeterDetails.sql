
BEGIN
	SET NOCOUNT ON;

	SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)

	IF @Meterid IS NULL
		BEGIN
			SELECT
					MeterID, 
					Description
				FROM TCD.Meter
				WHERE UtilityType = @Utilitytypeid
				  AND IS_deleted = 0
				  AND EcolabAccountNumber = @Ecolabaccountnumber;
		END;
	ELSE
		BEGIN
			SELECT
					MeterID, 
					Description
				FROM TCD.Meter
				WHERE UtilityType = @Utilitytypeid
				  AND MeterID <> @Meterid
				  AND MeterID NOT IN(SELECT
											 MeterID
										 FROM TCD.Meter
										 WHERE parent IN(@Meterid)
										   AND EcolabAccountNumber = @Ecolabaccountnumber)
				  AND IS_deleted = 0
				  AND EcolabAccountNumber = @Ecolabaccountnumber;
		END;
END;