
  BEGIN 
	SET NOCOUNT ON;

	DECLARE @Name VARCHAR(100), 
			@Usagekey VARCHAR(100)

	SELECT
			@Name = Name FROM TCD.SENSORTYPEMASTER WHERE ResourceID = @Sensortype

	SET @Usagekey = CASE
						WHEN @Name = 'Temperature' THEN 'Temparature_TCD'
						WHEN @Name = 'pH' THEN 'pH_TCD'
						WHEN @Name = 'Redox' THEN 'Redox_TCD'
						WHEN @Name = 'Conductivity' THEN 'ConductivityElectrolytic_CommonUse'
						WHEN @Name = 'Weight' THEN 'Weight_TCD'
						WHEN @Name = 'Water Hardness' THEN 'WaterHardness_TCD'
						WHEN @Name = 'Others' THEN 'UnitLess'
            END
	IF @Name = 'Others'
		  BEGIN
		  SELECT
					ddu.Unit, 
                      ddu.Subunit
				FROM TCD.DimensionalDisplayUnits AS ddu
					 INNER JOIN TCD.DimensionalUsageKey AS duk ON duk.DisplayUnitID = ddu.DisplayUnitID
				WHERE duk.UsageKey IN('Temparature_TCD', 'pH_TCD', 'Redox_TCD', 'ConductivityElectrolytic_CommonUse', 'Weight_TCD','WaterHardness_TCD')
				ORDER BY ddu.Unit, ddu.OrderID;
			END
		  ELSE
		  BEGIN
				SELECT
					ddu.Unit, 
				      ddu.Subunit
				FROM TCD.DimensionalDisplayUnits AS ddu
					 INNER JOIN TCD.DimensionalUsageKey AS duk ON duk.DisplayUnitID = ddu.DisplayUnitID
				WHERE duk.UsageKey = @Usagekey
				ORDER BY ddu.Unit, ddu.OrderID;
		  END
  END