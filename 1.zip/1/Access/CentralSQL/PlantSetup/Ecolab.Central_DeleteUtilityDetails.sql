
 BEGIN 
	SET NOCOUNT ON;

	DECLARE --@Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE()
	 

	DECLARE @Newgrouptypeid INT = SCOPE_IDENTITY()
	UPDATE TCD.WaterAndEnergy SET
			is_deleted = 1, 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Currentutctime
		WHERE DeviceNumber = @Id
		  AND EcolabAccountNumber = @Ecolabaccountnumber
	SELECT
			@Outputlastmodifiedtimestampatlocal = GETDATE()

	--RETURN @Returnvalue
	 
 --SET nocount OFF; 
  END