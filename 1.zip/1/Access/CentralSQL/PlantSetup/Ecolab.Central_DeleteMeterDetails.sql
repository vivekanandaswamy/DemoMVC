
  BEGIN 
	SET NOCOUNT ON;
	DECLARE @Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL, 
			@Errornumber INT = 0

	DECLARE @Outputlist AS TABLE(
			LastModifiedTimestamp DATETIME)

	--DECLARE @Table_name NVARCHAR(1000) = 'Meter' 

	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)
	SET @Scope = ISNULL(@Scope, NULL)


	IF @Lastmodifiedtimestampatcentral IS NOT NULL
   AND NOT EXISTS(SELECT
						  1
					  FROM TCD.Meter AS M
					  WHERE M.EcolabAccountNumber = @Ecolabaccountnumber
						AND M.MeterId = @Meterid
						AND M.LastModifiedTime = @Lastmodifiedtimestampatcentral)
	BEGIN
			SET @Errorid = 60000
			SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR(@Errormessage, 16, 1)
			SET @Returnvalue = -1
			--RETURN @Returnvalue
	END

	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.Meter AS M
					  WHERE Parent = @Meterid
						AND Is_deleted = 0
						AND EcolabAccountNumber = @Ecolabaccountnumber)
			BEGIN
			DECLARE @Plantid INT = (SELECT
											MG.Id
										FROM TCD.MachineGroupType AS MGT
											 INNER JOIN TCD.MachineGroup AS MG ON MGT.Id = MG.GroupTypeId
								   WHERE MGT.Id = 1
										  AND MG.Is_Deleted = 0
										  AND MG.EcolabAccountNumber = @Ecolabaccountnumber);
			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.RedFlag AS RF
								   INNER JOIN TCD.RedFlagMappingData AS RFM ON RF.Id = RFM.MappingId
												   AND RF.Is_Deleted = 0
												   AND RFM.Is_Deleted = 0
												   AND RF.EcolabAccountNumber = RFM.EcolabAccountNumber 
								   LEFT JOIN TCD.Meter AS M ON RF.Location = CASE M.IsPlant
																				 WHEN 'TRUE' THEN COALESCE(M.GroupId, @Plantid)
																				 ELSE M.GroupId
																			 END
									   AND M.Is_deleted = 0
									   AND M.EcolabAccountNumber = RF.EcolabAccountNumber
							 WHERE M.MeterId = @Meterid  
								AND RF.EcolabAccountNumber = @Ecolabaccountnumber)
			BEGIN
					UPDATE TCD.meter SET
							is_deleted = 1, 
							LastModifiedByUserId = @Userid
				  OUTPUT
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							LastModifiedTimestamp)
						WHERE MeterID = @Meterid
							  AND EcolabAccountNumber = @Ecolabaccountnumber

						
			END
						ELSE
						BEGIN
						SET @Scope = 405
					SET @Returnvalue = 405
						END
			END
			ELSE
			BEGIN
			SET @Scope = 404
			SET @Returnvalue = 404
			END


	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp
		FROM @Outputlist AS O

	--RETURN @Returnvalue
  END

