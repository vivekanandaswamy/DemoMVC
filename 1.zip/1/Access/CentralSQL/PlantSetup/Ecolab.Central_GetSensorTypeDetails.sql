
  BEGIN 
	SET NOCOUNT ON;

	SELECT
			Resourceid, 
			name FROM TCD.SensorTypeMaster

  END 