
BEGIN
    SET NOCOUNT ON;
			DECLARE @Waterandenergygroupid INT = (SELECT TOP (1)
														  MG.Id
													  FROM TCD.MachineGroup AS MG
														   INNER JOIN TCD.MachineGroupType AS MGT ON MGT.Id = MG.GroupTypeId
													  WHERE MGT.Id = 5
														AND MG.EcolabAccountNumber = @Ecolabaccountnumber);


	IF EXISTS(SELECT
					  1 FROM TCD.ConduitController WHERE EcoalabAccountNumber = @Ecolabaccountnumber)
        BEGIN
			
			SELECT DISTINCT
					M.MeterId, 
					M.Description, 
					M.UtilityType, 
					CASE M.UtilityType
						WHEN 12 THEN 'Pieces'
						ELSE(SELECT
									 Name FROM TCD.UtilityMaster AS rm WHERE rm.ResourceId = M.UtilityType)
					END AS MeterTypeName, 
					M.EcolabAccountNumber, 
					M.MaxValueLimit, 
					M.MeterTickUnit, 
					M.UsageFactor, 
					CASE
						WHEN M.Machinecompartment IS NULL THEN CASE
																   WHEN M.IsPress = 1 THEN 1
																   WHEN M.GroupId IS NULL
																	AND (M.IsPress = 0
																	  OR M.IsPress IS NULL)
																	AND (M.IsPlant = 0
																	  OR M.IsPlant IS NULL)THEN NULL
																   ELSE 0
															   END
			   ELSE M.Machinecompartment 
					END AS Machinecompartment, 
					CASE
						WHEN M.MachineCompartment IS NULL
						 AND (M.IsPress = 0
						   OR M.IsPress IS NULL)THEN CASE
														 WHEN M.GroupId IS NULL
														  AND (M.IsPlant = 0
															OR M.IsPlant IS NULL)THEN NULL
														 ELSE 'ALL'
													 END
						WHEN(SELECT DISTINCT
									 Istunnel
								 FROM TCD.machinesetup AS S
								 WHERE S.groupId = M.GroupId
								   AND S.IsDeleted = 0
								   AND S.EcoalabAccountNumber = @Ecolabaccountnumber) = 1 THEN CASE
																								   WHEN M.MachineCompartment IS NULL
																									AND M.IsPress = 1 THEN 'Press'
																								   ELSE 'Compartment' + CAST(M.Machinecompartment AS VARCHAR(100))
																							   END
						WHEN(SELECT DISTINCT
									 Istunnel
								 FROM TCD.MachineSetup AS S
								 WHERE S.groupId = M.GroupId
								   AND S.IsDeleted = 0
								   AND S.EcoalabAccountNumber = @Ecolabaccountnumber) = 0 THEN(SELECT
																									   MachineName
																								   FROM TCD.MachineSetup AS S
																								   WHERE S.GroupId = M.GroupId
																									 AND S.WasherId = M.MachineCompartment
																									 AND S.IsDeleted = 0
																									 AND EcoalabAccountNumber = @Ecolabaccountnumber)
						WHEN(SELECT DISTINCT
									 GroupTypeId
								 FROM TCD.MachineGroup AS GT
								 WHERE GT.Id = M.GroupId
								   AND GT.EcolabAccountNumber = @Ecolabaccountnumber) = 3 THEN(SELECT
																									   Description
																								   FROM TCD.Dryers AS D
																								   WHERE D.DryerGroupId = M.GroupId
																									 AND D.Id = M.MachineCompartment
																									 AND D.Is_Deleted = 0
																									 AND EcoalabAccountNumber = @Ecolabaccountnumber)
						WHEN(SELECT DISTINCT
									 GroupTypeId
								 FROM TCD.MachineGroup AS GT
								 WHERE GT.Id = M.GroupId
								   AND GT.EcolabAccountNumber = @Ecolabaccountnumber) = 4 THEN(SELECT
																									   Name
																								   FROM TCD.Finnishers AS F
																								   WHERE F.FinnisherGroupId = M.GroupId
																									 AND F.FinnisherId = M.MachineCompartment
																									 AND F.Is_Deleted = 0
																									 AND EcoalabAccountNumber = @Ecolabaccountnumber)
						WHEN(SELECT DISTINCT
									 GT.GroupTypeId
								 FROM TCD.MachineGroup AS GT
								 WHERE GT.Id = M.GroupId
								   AND GT.EcolabAccountNumber = @Ecolabaccountnumber) = 5 THEN(SELECT
																									   WE.DeviceName
																								   FROM TCD.WaterAndEnergy AS WE
																								   WHERE M.GroupId = @Waterandenergygroupid
																									 AND WE.DeviceNumber = M.MachineCompartment
																									 AND WE.Is_deleted = 0
																									 AND EcoalabAccountNumber = @Ecolabaccountnumber)
					END AS MachinecompartmentName, 
					CC.ControllerId, 
                   CC.Name AS ControllerName,
									 CC.ControllerModelId,
									 CM.RegionId AS ControllerRegionId,	
									 CT.Id AS ControllerTypeId,
									 CT.Name AS ControllerType,			     
                   CASE M.Parent
                   WHEN NULL THEN NULL
						ELSE(SELECT
									 MeterId
								 FROM TCD.meter AS MM
								 WHERE MM.EcolabAccountNumber = @Ecolabaccountnumber
								   AND MM.MeterID IN(
							 SELECT
									 parent
								 FROM TCD.Meter
								 WHERE parent = M.parent
								   AND M.EcolabAccountNumber = @Ecolabaccountnumber))
					END AS ParentId, 
                   CASE M.Parent
                   WHEN NULL THEN NULL
						ELSE(SELECT
									 Description
								 FROM TCD.meter AS MM
								 WHERE MM.EcolabAccountNumber = @Ecolabaccountnumber
								   AND MM.MeterID IN(
							 SELECT
									 parent
								 FROM TCD.Meter
								 WHERE parent = M.parent
								   AND M.EcolabAccountNumber = @Ecolabaccountnumber))
					END AS Parent, 
					M.Calibration, 
									 MT.TagAddress,
                   --M.DigitalInputNumber , 
					M.AllowManualentry, 
					CASE
						WHEN M.groupID IS NULL
						 AND M.IsPlant = 1 THEN 1
						ELSE(SELECT
									 G.Id
								 FROM TCD.MachineGroup AS G
								 WHERE G.Id = M.groupID
								   AND COALESCE(G.EcolabAccountNumber, @Ecolabaccountnumber) = @Ecolabaccountnumber)
					END AS UtilityId, 
					CASE
						WHEN M.groupID IS NULL
						 AND M.MachineCompartment IS NULL
						 AND M.IsPlant = 1 THEN 'Plant'
						ELSE(SELECT
									 GroupDescription
								 FROM TCD.MachineGroup AS G
								 WHERE G.Id = M.groupID
								   AND COALESCE(G.EcolabAccountNumber, @Ecolabaccountnumber) = @Ecolabaccountnumber)
					END AS UtilityLocation, 
									 M.LastSyncTime,
									 M.LastModifiedTime,
									 M.MyServiceMeterGuid,
									 M.CounterNum,
									 M.CounterUsage,
									 M.RunningTimeUsage,
									 M.CounterAlarmValue,
									 M.WaterType,
									 M.WaterTypeFromFormulaSetup,
									 M.RunningTimeAlarmValue,
									 CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel,
									 M.DigitalInputNumber,
									 M.IncludeInOperationReport
				FROM TCD.Meter AS M
					 LEFT JOIN TCD.ConduitController AS CC ON CC.ControllerId = M.ControllerID
														  AND M.EcolabAccountNumber = CC.EcoalabAccountNumber
					 LEFT JOIN TCD.ControllerModel AS CM ON CM.Id = CC.ControllerModelId
					 LEFT JOIN TCD.ModuleTags AS MT ON MT.ModuleID = M.MeterId
							AND MT.ModuleTypeId = 2 
							AND MT.Active = 1
							AND MT.EcolabAccountNumber = M.EcolabAccountNumber
					 LEFT JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
					 LEFT JOIN TCD.ControllerSetupData csd 
							ON csd.ControllerId = M.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = M.EcolabAccountNumber
				WHERE Is_Deleted = 0
				  AND M.EcolabAccountNumber = @Ecolabaccountnumber
				  AND (M.MeterId = @Meterid
					OR @Meterid IS NULL);
        END;
    ELSE
        BEGIN
			SELECT
					M.MeterId, 
					M.Description, 
					M.UtilityType, 
					(SELECT
							 Name FROM TCD.UtilityMaster AS rm WHERE rm.ResourceId = M.UtilityType)AS MeterTypeName, 
					M.EcolabAccountNumber, 
					M.MaxValueLimit, 
					M.MeterTickUnit, 
					M.UsageFactor, 
					CASE
						WHEN M.Machinecompartment IS NULL THEN CASE
																   WHEN M.IsPress = 1 THEN 1
																   WHEN M.GroupId IS NULL
																	AND (M.IsPress = 0
																	  OR M.IsPress IS NULL)
																	AND (M.IsPlant = 0
																	  OR M.IsPlant IS NULL)THEN NULL
																   ELSE 0
															   END
				   ELSE M.Machinecompartment 
					END AS Machinecompartment, 
					CASE
						WHEN M.MachineCompartment IS NULL
						 AND (M.IsPress = 0
						   OR M.IsPress IS NULL)THEN CASE
														 WHEN M.GroupId IS NULL
														  AND (M.IsPlant = 0
															OR M.IsPlant IS NULL)THEN NULL
														 ELSE 'ALL'
													 END
						WHEN(SELECT DISTINCT
									 Istunnel
								 FROM TCD.machinesetup AS S
								 WHERE S.groupId = M.GroupId
								   AND S.IsDeleted = 0
								   AND S.EcoalabAccountNumber = @Ecolabaccountnumber) = 1 THEN CASE
																								   WHEN M.MachineCompartment IS NULL
																									AND M.IsPress = 1 THEN 'Press'
																								   ELSE 'Comapartment' + CAST(M.Machinecompartment - 1 AS VARCHAR(100))
																							   END
						WHEN(SELECT DISTINCT Istunnel 
                                 FROM   TCD.MachineSetup AS S 
                                 WHERE  S.groupId = M.GroupId 
                                        AND S.IsDeleted = 0 
                                        AND S.EcoalabAccountNumber = @Ecolabaccountnumber) = 0 THEN(SELECT MachineName
                                                                                                    FROM   TCD.MachineSetup AS S
                                                                                                    WHERE  S.GroupId = M.GroupId
																	   AND S.WasherId = M.MachineCompartment
                                                                                                           AND S.IsDeleted = 0
                                                                                                           AND EcoalabAccountNumber = @Ecolabaccountnumber)
						WHEN(SELECT DISTINCT
									 GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = M.GroupId) = 3 THEN(SELECT
																													   Description
																												   FROM TCD.Dryers AS D
																												   WHERE D.DryerGroupId = M.GroupId
																													 AND D.Id = M.MachineCompartment
																													 AND D.Is_Deleted = 0)
						WHEN(SELECT DISTINCT
									 GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = M.GroupId) = 4 THEN(SELECT
																													   Name
																												   FROM TCD.Finnishers AS F
																												   WHERE F.FinnisherGroupId = M.GroupId
																													 AND F.FinnisherId = M.MachineCompartment
																													 AND F.Is_Deleted = 0)
						WHEN(SELECT DISTINCT
									 GT.GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = M.GroupId) = 5 THEN(SELECT
																														  WE.DeviceName
																													  FROM TCD.WaterAndEnergy AS WE
																													  WHERE M.GroupId = @Waterandenergygroupid
																														AND WE.DeviceNumber = M.MachineCompartment
																														AND WE.Is_deleted = 0)
					END AS MachinecompartmentName, 
					CC.ControllerId, 
                   CC.Name AS ControllerName,
									 CC.ControllerModelId,
									 CM.RegionId AS ControllerRegionId,	
									 CT.Id AS ControllerTypeId,
									 CT.Name AS ControllerType,
                   CASE M.Parent
                   WHEN NULL THEN NULL
						ELSE(SELECT
									 MeterId
								 FROM TCD.meter AS MM
								 WHERE MM.EcolabAccountNumber = @Ecolabaccountnumber
								   AND MM.MeterID IN(
							 SELECT
									 parent
								 FROM TCD.Meter
								 WHERE parent = M.parent
								   AND M.EcolabAccountNumber = @Ecolabaccountnumber))
					END AS ParentId, 
                   CASE M.Parent
                   WHEN NULL THEN NULL
						ELSE(SELECT
									 Description
								 FROM TCD.meter AS MM
								 WHERE MM.EcolabAccountNumber = @Ecolabaccountnumber
								   AND MM.MeterID IN(
							 SELECT
									 parent
								 FROM TCD.Meter
								 WHERE parent = M.parent
								   AND M.EcolabAccountNumber = @Ecolabaccountnumber))
					END AS Parent, 
					M.Calibration, 
									 MT.TagAddress,
                   --M.DigitalInputNumber , 
					M.AllowManualentry, 
					CASE
						WHEN M.groupID IS NULL
						 AND M.IsPlant = 1 THEN 1
						ELSE(SELECT
									 G.Id
								 FROM TCD.MachineGroup AS G
								 WHERE G.Id = M.groupID
								   AND COALESCE(G.EcolabAccountNumber, @Ecolabaccountnumber) = @Ecolabaccountnumber)
					END AS UtilityId, 
					CASE
						WHEN M.groupID IS NULL
						 AND M.MachineCompartment IS NULL
						 AND M.IsPlant = 1 THEN 'Plant'
						ELSE(SELECT
									 GroupDescription
								 FROM TCD.MachineGroup AS G
								 WHERE G.Id = M.groupID
								   AND COALESCE(G.EcolabAccountNumber, @Ecolabaccountnumber) = @Ecolabaccountnumber)
					END AS UtilityLocation, 
									 M.LastSyncTime,
									 M.LastModifiedTime,
									 M.MyServiceMeterGuid,
									 M.CounterNum,
									 M.CounterUsage,
									 M.RunningTimeUsage,
									 M.CounterAlarmValue,
									 M.WaterType,
									 M.WaterTypeFromFormulaSetup,
									 M.RunningTimeAlarmValue,
									 CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel,
									 M.DigitalInputNumber,
									 M.IncludeInOperationReport
				FROM TCD.Meter AS M
					 LEFT JOIN TCD.ConduitController AS CC ON CC.ControllerId = M.ControllerID
														  AND M.EcolabAccountNumber = CC.EcoalabAccountNumber
					 LEFT JOIN TCD.ControllerModel AS CM ON CM.Id = CC.ControllerModelId
					 LEFT JOIN TCD.ModuleTags AS MT ON MT.ModuleID = M.MeterId
							AND MT.ModuleTypeId = 2 
							AND MT.Active = 1
							AND MT.EcolabAccountNumber = M.EcolabAccountNumber
					 LEFT JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
					 LEFT JOIN TCD.ControllerSetupData csd 
							ON csd.ControllerId = M.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = M.EcolabAccountNumber
				WHERE Is_Deleted = 0
				  AND M.EcolabAccountNumber = @Ecolabaccountnumber
				  AND (M.MeterId = @Meterid
					OR @Meterid IS NULL);
        END;
END;