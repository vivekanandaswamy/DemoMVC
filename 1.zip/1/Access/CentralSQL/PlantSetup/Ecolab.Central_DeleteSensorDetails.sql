
  BEGIN 
	SET NOCOUNT ON; 

	DECLARE @Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Outputlist AS TABLE(
			LastModifiedTimestamp DATETIME)

	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)
	SET @Scope = ISNULL(@Scope, NULL)

	IF @Lastmodifiedtimestampatcentral IS NOT NULL
   AND NOT EXISTS(SELECT
						  1
					  FROM TCD.Sensor AS S
					  WHERE S.EcolabAccountNumber = @Ecolabaccountnumber
						AND S.SensorId = @Sensorid
						AND S.LastModifiedTime = @Lastmodifiedtimestampatcentral)
		BEGIN
			SET @Errorid = 60000
			SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR(@Errormessage, 16, 1)
			SET @Returnvalue = -1
		END
	DECLARE @Plantid INT = (SELECT
									MG.Id
								FROM TCD.MachineGroupType AS MGT
									 INNER JOIN TCD.MachineGroup AS MG ON MGT.Id = MG.GroupTypeId
								   WHERE MGT.Id = 1
								  AND MG.Is_Deleted = 0
								  AND MG.EcolabaccountNumber = @Ecolabaccountnumber);
	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.RedFlag AS RF
						   INNER JOIN TCD.RedFlagMappingData AS RFM ON RF.Id = RFM.MappingId
												   AND RF.Is_Deleted = 0
												   AND RFM.Is_Deleted = 0
												   AND RF.EcolabAccountNumber = RFM.EcolabAccountNumber
						   LEFT JOIN TCD.Sensor AS S ON RF.Location = CASE S.IsPlant
																		  WHEN 'TRUE' THEN COALESCE(S.GroupId, @Plantid)
																		  ELSE S.GroupId
																	  END
									   AND S.Is_deleted = 0
									   AND S.EcolabAccountNumber = RF.EcolabAccountNumber
					  WHERE S.SensorId = @Sensorid
						AND RF.EcolabAccountNumber = @Ecolabaccountnumber)
		  BEGIN
			UPDATE TCD.Sensor SET
					is_deleted = 1, 
					LastModifiedByUserId = @Userid, 
					LastModifiedTime = @Currentutctime
	  OUTPUT
					inserted.LastModifiedTime AS LastModifiedTimestamp
				   INTO @Outputlist(
					LastModifiedTimestamp)
				WHERE  SensorID = @Sensorid
					   AND EcolabAccountNumber = @Ecolabaccountnumber
		  END
		  ELSE
		  BEGIN
		  SET @Scope = 405
		  END
	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp
		FROM @Outputlist AS O
	 
/* audit the DELETED details */


	
  END