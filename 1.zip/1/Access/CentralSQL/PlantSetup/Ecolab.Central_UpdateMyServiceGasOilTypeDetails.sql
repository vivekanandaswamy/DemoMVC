
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Regionid INT = NULL, 
			@Currentutctime DATETIME = GETUTCDATE()
	DECLARE @Outputlist AS TABLE(
			GasoilId INT, 
			LastModifiedDate DATETIME)
	
	SELECT
			@Regionid = RegionId
		FROM TCD.RegionMaster
		WHERE MyServiceRegionCode = @Regioncode

	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.GasOilTypeMapping
					  WHERE MyServiceUtilId = @Myserviceutilid
						AND RegionId = @Regionid)
	BEGIN
			SET @Gasoilid = (SELECT
									 ISNULL(MAX(GasOilId), 0) + 1 FROM TCD.GasoilTypeMaster)
			IF NOT EXISTS(SELECT
								  1 FROM TCD.GasoilTypeMaster WHERE Name = @Name)
			BEGIN
					INSERT INTO TCD.GasoilTypeMaster(
							GasoilId, 
							Name, 
							UOM_Code, 
							UOM_Desc, 
							UsageKey, 
							Units, 
							IsDeleted)
				OUTPUT
							inserted.GasoilId AS GasoilId, 
							@Currentutctime AS LastModifiedDate
						   INTO @Outputlist(
							GasoilId, 
							LastModifiedDate)
				SELECT
								@Gasoilid, 
								@Name, 
								@Uomcode, 
								@Uomdesc, 
								@Usagekey, 
								@Units, 
								@Isdeleted
			END
		ELSE
			BEGIN
					SELECT
							@Gasoilid = GTM.GasoilId FROM TCD.GasoilTypeMaster AS GTM WHERE Name = @Name
					INSERT INTO @Outputlist(
							GasoilId)
					VALUES
						   (
							@Gasoilid)
			END

			INSERT INTO TCD.GasOilTypeMapping(
					GasOilId, 
					RegionId, 
					DefaultValue, 
					MyServiceUtilId, 
					MyServiceLastSynchTime)
				SELECT
						@Gasoilid, 
						@Regionid, 
						@Defaultvalue, 
						@Myserviceutilid, 
						@Currentutctime
	END
ELSE
	BEGIN
			UPDATE TCD.GasoilTypeMaster SET
					Name = @Name, 
					UOM_Code = @Uomcode, 
					UOM_Desc = @Uomdesc, 
					UsageKey = @Usagekey, 
					Units = @Units, 
					IsDeleted = @Isdeleted
		OUTPUT
					inserted.GasoilId AS GasoilId, 
					@Currentutctime AS LastModifiedDate
				   INTO @Outputlist(
					GasoilId, 
					LastModifiedDate)
	   WHERE
			Name = @Name

			UPDATE TCD.GasOilTypeMapping SET
					RegionId = @Regionid, 
					DefaultValue = @Defaultvalue, 
					MyServiceLastSynchTime = @Currentutctime
				WHERE GasOilId = @Gasoilid
					  AND MyServiceUtilId = @Myserviceutilid
	END

	SELECT TOP 1
			@Outputgasoiltypes = O.GasoilId, 
			@Outputlastmodifieddate = O.LastModifiedDate
		FROM @Outputlist AS O

END