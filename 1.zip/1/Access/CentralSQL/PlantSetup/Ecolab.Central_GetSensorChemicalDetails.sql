
BEGIN
	SET NOCOUNT ON;
	DECLARE @Istunnel BIT = (SELECT DISTINCT
									 Istunnel
								 FROM TCD.machinesetup AS MS
								 WHERE Ms.GroupId = @Groupid
								   AND EcoalabAccountNumber = @Ecolabaccountnumber
								   AND MS.IsDeleted = 0);

	DECLARE @ControllerModelId int,	
			@Isna	BIT	=	'FALSE';

	IF @Controllerid IS NULL
		BEGIN
			SELECT TOP (1)
					@Controllerid = ControllerID
				FROM TCD.ConduitController
				WHERE ControllerModelId = 5
				  AND EcoalabAccountNumber = @Ecolabaccountnumber
				  AND TCD.ConduitController.IsDeleted = 0;
		END;

	SELECT @ControllerModelId = cc.ControllerModelId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcolabAccountNumber

	IF	@Controllermodelid	IS	NULL
	OR	@Controllermodelid	<	7
	OR	@Controllermodelid	IN(12,	13)
		BEGIN
			SET	@Isna	=	'TRUE';
		END;

	IF @Istunnel = 'TRUE'
		BEGIN
			SELECT	DISTINCT	PM.ProductId,
			CES.ControllerEquipmentId,
			CES.ControllerEquipmentTypeId,
			CC.ControllerModelId,
					   CASE  
			WHEN PM.EnvisionDisplayName IS NULL THEN PM.NAME 
			ELSE PM.EnvisionDisplayName 
			END as NAME 
				FROM TCD.MachineSetup AS MS
					 INNER JOIN TCD.TunnelCompartment AS TC ON TC.WasherId = MS.WasherId
					 INNER JOIN TCD.ConduitController AS CC ON CC.ControllerId = MS.ControllerId
					 INNER JOIN TCD.TunnelCompartmentEquipmentMapping AS TCEM ON TCEM.TunnelCompartmentId = TC.TunnelCompartmentId
					   INNER JOIN TCD.ControllerEquipmentSetup CES 
                           ON CES.ControllerId = CC.ControllerId
				LEFT JOIN tcd.TunnelCompartmentEquipmentValveMapping tcevm 
					   ON tcevm.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId 
					   AND tcevm.CompartmentNumber = TC.CompartmentNumber
					 INNER JOIN TCD.ProductdataMapping AS PDM ON PDM.ProductID = CES.ProductId
					 INNER JOIN TCD.ProductMaster AS PM ON PM.ProductId = PDM.ProductID
				WHERE MS.IsDeleted = 0
				  AND CC.IsDeleted = 0
				  AND TCEM.Is_Deleted = 0
				  AND CES.IsActive = 1
				  AND PDM.Is_Deleted = 0
				  AND MS.EcoalabAccountNumber = @Ecolabaccountnumber
				  AND TC.EcoLabAccountNumber = @Ecolabaccountnumber
				  AND CC.EcoalabAccountNumber = @Ecolabaccountnumber
				  AND TCEM.EcoLabAccountNumber = @Ecolabaccountnumber
				  AND CES.EcoLabAccountNumber = @Ecolabaccountnumber
				  AND PDM.EcolabAccountNumber = @Ecolabaccountnumber
				  AND (MS.GroupId = @Groupid
					OR @Groupid IS NULL
					OR @Groupid = 1)
				  AND (TC.CompartmentNumber = @Machineid
					OR @Machineid IS NULL
					OR @Machineid = 0)
				  AND CC.ControllerId = @Controllerid
				  	AND PM.Name NOT LIKE '%DUMMY PRODUCT%';
		END;
	ELSE
		BEGIN

			IF @ControllerModelId = 7
			BEGIN
				SET @GroupId = NULL
			END

			 SELECT DISTINCT pm.ProductId, 
		  CES.ControllerEquipmentId,
		  CES.ControllerEquipmentTypeId,
		  CC.ControllerModelId,
		 CASE  
			WHEN PM.EnvisionDisplayName IS NULL THEN PM.NAME 
			ELSE PM.EnvisionDisplayName 
			END as NAME 
				FROM TCD.Washer AS WS
					 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
					 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
					 INNER JOIN TCD.WasherProgramSetup AS Wps ON CASE WHEN @GroupId IS NULL THEN Wps.ControllerID ELSE Wps.WasherGroupId END = CASE WHEN @GroupId IS NULL THEN Wg.ControllerId ELSE Wg.WasherGroupId  END
					 INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
					 INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
					 INNER JOIN TCD.ConduitController AS CC ON CC.ControllerId = Mst.ControllerId
					 INNER JOIN tcd.ControllerEquipmentSetup ces
					   ON ces.ControllerId = CC.ControllerId AND ces.ProductId = Wdpm.ProductId
					 INNER JOIN TCD.ProductdataMapping AS PDM ON PDM.ProductID = WDPM.ProductId
					 INNER JOIN TCD.ProductMaster AS pm ON pm.ProductId = Wdpm.ProductId
				WHERE WS.Is_Deleted = 0
				  AND Mst.IsDeleted = 0
				  AND Wds.Is_Deleted = 0
				  AND PDM.Is_Deleted = 0
				  AND pm.Is_Deleted = 0
				  AND CC.IsDeleted = 0
				  AND Wdpm.IsDeleted = 0
				  AND WS.EcoLabAccountNumber = @Ecolabaccountnumber
				  AND Wg.EcolabAccountNumber = @Ecolabaccountnumber
				  AND Wps.EcolabAccountNumber = @Ecolabaccountnumber
				  AND Wds.EcoLabAccountNumber = @Ecolabaccountnumber
				  AND Wdpm.EcoLabAccountNumber = @Ecolabaccountnumber
				  AND PDM.EcolabAccountNumber = @Ecolabaccountnumber
				  and ces.EcolabAccountNumber = @Ecolabaccountnumber
				  AND (MST.GroupId = @Groupid
					OR @Groupid IS NULL
					OR @Groupid = 1)
				  AND (mst.WasherId = @Machineid
					OR @Machineid IS NULL
					OR @Machineid = 0)
				  AND CC.ControllerId = @Controllerid
				  	AND pm.Name NOT LIKE '%DUMMY PRODUCT%'
					AND ((@Isna = 'FALSE' AND ces.conventionalwashergroupconnection	=	1) OR (@Isna = 'TRUE'));
		END;
	SET NOCOUNT OFF;
END;