
BEGIN

	DECLARE @Isdeleted BIT = 'FALSE'
	SET NOCOUNT ON;



	SELECT
			SD.EcolabAccountNumber, 
			SD.ShiftId, 
			ShiftName, 
			SD.DayId, 
			DayName = (SELECT
							   W.DayName FROM TCD.WeekDay AS W WHERE W.DayId = SD.DayId), 
			ShiftStartTime = SD.StartTime, 
			ShiftEndTime = SD.EndTime, 
			CASE
				WHEN SBD.IS_Deleted = 0
				  OR @Isdeleted = 'True' THEN SBD.BreakId
				WHEN SBD.IS_Deleted = 1 THEN NULL
			END AS BreakId, 
			CASE
				WHEN SBD.IS_Deleted = 0
				  OR @Isdeleted = 'True' THEN SBD.ShiftId
				WHEN SBD.IS_Deleted = 1 THEN NULL
			END AS BreakShiftId, 
			CASE
				WHEN SBD.IS_Deleted = 0
				  OR @Isdeleted = 'True' THEN SBD.DayId
				WHEN SBD.IS_Deleted = 1 THEN NULL
			END AS BreakDayId, 
			CASE
				WHEN SBD.IS_Deleted = 0
				  OR @Isdeleted = 'True' THEN SBD.StartTime
				WHEN SBD.IS_Deleted = 1 THEN NULL
			END AS BreakStartTime, 
			CASE
				WHEN SBD.IS_Deleted = 0
				  OR @Isdeleted = 'True' THEN SBD.EndTime
				WHEN SBD.IS_Deleted = 1 THEN NULL
			END AS BreakEndTime, 
			CASE
				WHEN SBD.IS_Deleted = 0
				  OR @Isdeleted = 'True' THEN SBD.IS_Deleted
				WHEN SBD.IS_Deleted = 1 THEN NULL
			END AS IsDeleted, 
			SD.TargetProduction, 
			SD.LastModifiedTime AS LastModifiedTime, 
			SD.LastSyncTime AS LastSyncTime, 
			SD.TargetProduction_Display AS TargetProduction_Display, 
			SD.Is_Deleted AS IsDeleted
		FROM TCD.ShiftData AS SD
			 LEFT JOIN TCD.ShiftBreakData AS SBD ON SD.ShiftId = SBD.ShiftId
												AND SD.DayId = SBD.DayId
												AND SD.EcolabAccountNumber = SBD.EcolabAccountNumber
		WHERE SD.EcolabAccountNumber = @Ecolabaccountnumber
		  AND (SD.Is_Deleted = 'FALSE'
			OR SD.Is_Deleted = @Isdeleted)
		  AND CASE ISNULL(@Shiftid, '')
				  WHEN '' THEN 'true'
				  WHEN @Shiftid THEN CASE
										 WHEN SD.ShiftId = @Shiftid THEN 'true'
									 END
			  END = 'true'
		  AND CASE ISNULL(@Dayid, '')
				  WHEN '' THEN 'true'
				  WHEN @Dayid THEN CASE
									   WHEN SD.DayId = @Dayid THEN 'true'
								   END
			  END = 'true'
		ORDER BY
			SD.DayId, SD.StartTime ASC

	SET NOCOUNT OFF;
END