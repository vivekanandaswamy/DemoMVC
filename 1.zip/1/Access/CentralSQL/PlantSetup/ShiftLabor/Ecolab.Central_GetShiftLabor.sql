
BEGIN
	DECLARE @Isdeleted BIT = 'FALSE'
	SET NOCOUNT ON;
	BEGIN

		SELECT
				SLD.LaborId, 
				SLD.ShiftId, 
				SLD.DayId, 
				SLD.LaborTypeId, 
				LaborTypeName = (SELECT
										 L.Description FROM TCD.LaborType AS l WHERE L.LaborTypeId = SLD.LaborTypeId), 
				SLD.LocationId, 
				LoactionName = (SELECT
										G.GroupDescription
									FROM TCD.MachineGroup AS G
									WHERE G.Id = SLD.LocationId
									  AND G.EcolabAccountNumber = @Ecolabaccountnumber), 
				SLD.LaborHours, 
				LC.Cost, 
				SLD.LastModifiedTime AS LastModifiedTime, 
				SLD.LastSyncTime AS LastSyncTime, 
				SLD.EcolabAccountNumber AS EcolabAccountNumber, 
				SLD.IS_Deleted AS IsDeleted
			FROM TCD.ShiftData AS SD
				 INNER JOIN TCD.ShiftLaborData AS SLD ON SD.ShiftId = SLD.ShiftId
													 AND SD.DayId = SLD.DayId
													 AND SLD.EcolabAccountNumber = SD.EcolabAccountNumber
				 INNER JOIN TCD.LaborCost AS LC ON SLD.LaborTypeId = LC.LaborTypeId
											   AND LC.EcolabAccountNumber = SLD.EcolabAccountNumber
			WHERE SLD.EcolabAccountNumber = @Ecolabaccountnumber
			  AND (SD.Is_Deleted = 'FALSE'
				OR SD.Is_Deleted = @Isdeleted)
			  AND (SLD.IS_Deleted = 'FALSE'
				OR SLD.IS_Deleted = @Isdeleted)
		SET NOCOUNT OFF;
	END
END