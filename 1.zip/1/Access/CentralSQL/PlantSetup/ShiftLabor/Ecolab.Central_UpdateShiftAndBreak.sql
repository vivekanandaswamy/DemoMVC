
BEGIN
	SET NOCOUNT ON
	BEGIN

		DECLARE @Returnvalue INT = 0, 
				@Errorid INT = 0, 
				@Errormessage NVARCHAR(4000) = N'', 
				@Currentutctime DATETIME = GETUTCDATE(), 
				@Allowupdate BIT = 'TRUE', 
				@Rollingcount INT = 1, 
				@Rowcount INT = NULL, 
				@Dayid INT = NULL, 
				@Datestarttime DATETIME, 
				@Dateendtime DATETIME, 
				@Prevday INT, 
				@Nextday INT,
				@Lastmodifiedtimestampatcentral DATETIME = NULL
		--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
		--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
		SET @Outputlastmodifiedtimestampatlocal = @Currentutctime
		SET @Outputshiftid = ISNULL(@Outputshiftid, NULL)

		SET @Result = ISNULL(@Result, NULL)

		CREATE TABLE #OutputList(
				ShiftId INT, 
				LastModifiedTimestamp DATETIME)

		--If the call is not local, check that the LastModifiedTime matches with the central
		IF @Lastmodifiedtimestampatcentral IS NOT NULL
	   AND @Count != 0			--i.e. we are NOT creating a new Shift (condn. in SaveShiftBreakDetails, which -
	   AND --	is called by UpdateShifts that is called here)
		   NOT EXISTS(SELECT
							  1
						  FROM TCD.ShiftData AS S
						  WHERE S.EcolabAccountNumber = @Ecolabaccountnumber
							AND S.ShiftId = @Shiftid
							AND S.LastModifiedTime = @Lastmodifiedtimestampatcentral)
			BEGIN
				SET @Errorid = 60000
				SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR) + N': Record not in-synch between plant and central.'
				RAISERROR(@Errormessage, 16, 1)
				SET @Returnvalue = -1
				--RETURN @Returnvalue
			END

		--Proceed, since it's either a local call or Synch. call with synch. time matching

		IF @Issunday = 1
			BEGIN
				SET @Dayid = 1
			END
		ELSE
			BEGIN
				IF @Ismonday = 1
					BEGIN
						SET @Dayid = 2
					END
				ELSE
					BEGIN
						IF @Ismonday = 1
							BEGIN
								SET @Dayid = 2
							END
						ELSE
							BEGIN
								IF @Istuesday = 1
									BEGIN
										SET @Dayid = 3
									END
								ELSE
									BEGIN
										IF @Iswednesday = 1
											BEGIN
												SET @Dayid = 4
											END
										ELSE
											BEGIN
												IF @Isthursday = 1
													BEGIN
														SET @Dayid = 5
													END
												ELSE
													BEGIN
														IF @Isfriday = 1
															BEGIN
																SET @Dayid = 6
															END
														ELSE
															BEGIN
																IF @Issaturday = 1
																	BEGIN
																		SET @Dayid = 7
																	END
															END
													END
											END
									END
							END
					END
			END 
	
		/* SHIFT OVERLAPPING OF TIMINGS */

		SELECT
				@Prevday = CASE
							   WHEN @Dayid = 1 THEN 7
							   ELSE @Dayid - 1
						   END, 
				@Nextday = CASE
							   WHEN @Dayid = 7 THEN 1
							   ELSE @Dayid + 1
						   END

		IF @Endtime < @Starttime
		OR @Endtime = @Starttime
			BEGIN
				SELECT
						@Datestarttime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Starttime AS DATETIME))
				SET @Dateendtime = DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(@Endtime AS DATETIME))
			--SELECT @DateStartTime,@DateEndTime  
			END
		ELSE
			BEGIN
				SET @Datestarttime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Starttime AS DATETIME))
				SET @Dateendtime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Endtime AS DATETIME))
			--SELECT @DateStartTime,@DateEndTime
			END

		DECLARE @Result_Table TABLE(
				Result INT)
		CREATE TABLE #shiftdata_temp(
				SNo INT IDENTITY(1, 1), 
				ShiftId INT, 
				ShiftName NVARCHAR(1000), 
				DayId INT, 
				StartTime [TIME](7), 
				EndTime [TIME](7), 
				TargetProduction DECIMAL(18, 2), 
				Is_Deleted BIT, 
				EcolabAccountNumber NVARCHAR(1000), 
				LastModifiedByUserId INT, 
				LastModifiedTime DATETIME, 
				LastSyncTime DATETIME, 
				TargetProduction_Display DECIMAL(18, 2), )
		INSERT INTO #shiftdata_temp
					(ShiftId ,
					ShiftName ,
					DayId ,
					StartTime ,
					EndTime ,
					TargetProduction,
					Is_Deleted,
					EcolabAccountNumber ,
					LastModifiedByUserId ,
					LastModifiedTime ,
					LastSyncTime ,
					TargetProduction_Display)
			SELECT
					ShiftId, 
					ShiftName, 
					DayId, 
					StartTime, 
					EndTime, 
					TargetProduction, 
					Is_Deleted, 
					EcolabAccountNumber, 
					LastModifiedByUserId, 
					LastModifiedTime, 
					LastSyncTime, 
					TargetProduction_Display
			FROM TCD.ShiftData
			WHERE(DayId = @Dayid
			   OR DayId = @Prevday
			  AND (EndTime < StartTime
				OR EndTime = StartTime)
			   OR DayId = @Nextday)
			 AND IS_Deleted = 0
			 AND ShiftId <> @Shiftid
			 AND EcolabAccountNumber = @Ecolabaccountnumber

		UPDATE #shiftdata_temp SET
				DayId = CASE
							WHEN @Dayid = 1 THEN 0
							ELSE DayId
						END WHERE
				DayId = 7
		UPDATE #shiftdata_temp SET
				DayId = CASE
							WHEN @Dayid = 7 THEN 8
							ELSE DayId
						END WHERE
				DayId = 1

		SELECT
				@Rowcount = SNo FROM #shiftdata_temp

		WHILE @Rollingcount <= @Rowcount
			BEGIN
				DECLARE @Validstart DATETIME, 
						@Validend DATETIME
				SELECT
						@Validstart = CASE
										  WHEN DayId > @Dayid THEN DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(starttime AS DATETIME))
										  WHEN DayId < @Dayid THEN DATEADD(day, DATEDIFF(day, 1, GETDATE()), CAST(starttime AS DATETIME))
										  ELSE DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(starttime AS DATETIME))
									  END, 
						@Validend = CASE
										WHEN DayId > @Dayid
										 AND EndTime > StartTime
										  OR DayId = @Dayid
										 AND (EndTime = StartTime
										   OR EndTime < StartTime)THEN DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(EndTime AS DATETIME))
										WHEN DayId < @Dayid
										 AND (EndTime < StartTime
										   OR EndTime = StartTime)THEN DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS DATETIME))
										WHEN DayId > @Dayid
										 AND (EndTime < StartTime
										   OR EndTime = StartTime)THEN DATEADD(day, DATEDIFF(day, -2, GETDATE()), CAST(EndTime AS DATETIME))
										ELSE DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS DATETIME))
									END
					FROM #shiftdata_temp
					WHERE SNo = @Rollingcount

				IF @Datestarttime > @Validstart
			   AND @Datestarttime < @Validend
				OR @Dateendtime > @Validstart
			   AND @Dateendtime < @Validend
				OR @Datestarttime = @Validstart
			   AND @Dateendtime > @Validend
				OR @Datestarttime < @Validstart
			   AND @Dateendtime = @Validend
				OR @Datestarttime < @Validstart
			   AND @Dateendtime > @Validend
					BEGIN
						SET @Allowupdate = 'FALSE'
					END		   
		 
				--	  IF(@DateStartTime > @VALIDSTART AND @DateEndTime < @VALIDEND)
				--BEGIN
				--UPDATE @result_table set Result = 0  
				--END		  

				SET @Rollingcount = @Rollingcount + 1
			END
		DROP TABLE
				#shiftdata_temp		  

		/* COMPLETED LOGIC FOR VALIDATION */

		IF @Allowupdate = 'TRUE'
			BEGIN EXEC TCD.UpdateShifts @Shiftid, @Shiftname, @Dayid, @Starttime, @Endtime, @Targetprod, @Breakid, @Breakstarttime, @Breakendtime,
@Isdeleted, @Ecolabaccountnumber, @Count, @Targetproddisplay, @Userid, @Scopeupdate = @Result OUTPUT
				SELECT
						@Result
			END
		ELSE
			BEGIN
				SET @Result = '501' + '_' + CAST(@Dayid AS VARCHAR(10))
				SELECT
						@Result
			END

		--For Synch. integration
		IF EXISTS(SELECT
						  1 FROM #OutputList)	-->at-least 1 row got inserted/updated for the Shift
			BEGIN
				--	****	Update timestamp for the Shift	****
				UPDATE TCD.ShiftData SET
						LastModifiedTime = @Currentutctime
					WHERE
						EcolabAccountNumber = @Ecolabaccountnumber
					AND ShiftId = @Shiftid

				--Alternately, we can leave this out
				--SET		@OutputLastModifiedTimestampAtLocal
				--									=			@CurrentUTCTime			--We comment this here now, since we set the value above
				SET @Outputshiftid = @Shiftid				--Also, can be set using TOP 1 from the OutputList
			END

		SET NOCOUNT OFF
	END
END