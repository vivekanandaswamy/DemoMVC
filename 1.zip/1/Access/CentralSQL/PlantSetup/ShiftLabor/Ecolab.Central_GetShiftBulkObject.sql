
BEGIN

	SET NOCOUNT ON


SELECT	
	--Shift attributes
			S.EcolabAccountNumber AS EcolabAccountNumber, 
			S.ShiftId AS ShiftId, 
			S.ShiftName AS ShiftName, 
			S.Is_Deleted AS Is_Deleted, 
			S.LastModifiedTime AS LastModifiedTime, 
			SD.DayId AS SD_DayId, 
			SD.StartTime AS SD_StartTime, 
			SD.EndTime AS SD_EndTime, 
			SD.TargetProduction AS SD_TargetProduction, 
			SD.Is_Deleted AS SD_Is_Deleted, 
			SBD.BreakId AS SBD_BreakId, 
			SBD.StartTime AS SBD_StartTime, 
			SBD.EndTime AS SBD_EndTime, 
			SBD.IS_Deleted AS SBD_Is_Deleted, 
			SBD.ID AS SBD_Id
		FROM TCD.Shift AS S
			 LEFT OUTER JOIN TCD.ShiftData AS SD ON S.EcolabAccountNumber = SD.EcolabAccountNumber
												AND S.ShiftId = SD.ShiftId
			 LEFT OUTER JOIN TCD.ShiftBreakData AS SBD ON SD.EcolabAccountNumber = SBD.EcolabAccountNumber
													  AND SD.ShiftId = SBD.ShiftId
													  AND SD.DayId = SBD.DayId
		WHERE S.EcolabAccountNumber = @Ecolabaccountnumber
		  AND S.ShiftId = @Shiftid


--RETURN 0


END