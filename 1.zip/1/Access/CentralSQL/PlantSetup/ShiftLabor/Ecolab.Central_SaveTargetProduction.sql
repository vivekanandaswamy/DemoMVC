
BEGIN
	SET NOCOUNT ON;
    DECLARE @Output VARCHAR(50) = ''
    DECLARE @Returnvalue INT = 0, 
            @Currentutctime DATETIME = GETUTCDATE(), 
            @Newidtobeinserted INT = NULL, 
            @Errornumber INT = 0, 
            @Errormessage NVARCHAR(2048) = NULL, 
            @Errorseverity INT = NULL, 
            @Errorprocedure SYSNAME = NULL, 
            @Messagestring NVARCHAR(2500) = NULL

    DECLARE @Outputlist AS TABLE(
            TargetProductionId INT, 
            LastModifiedTime DATETIME)

    SET @Scope = ISNULL(@Scope, NULL)
    SET @Outputtargetproductionid = ISNULL(@Outputtargetproductionid, NULL)

    IF EXISTS(SELECT
                      1
                  FROM TCD.TARGETPRODUCTIONDETAILS
                  WHERE ShiftId = @Shiftid
                    AND DayId = @Dayid
                    AND EcolabAccountNumber = @Ecolabaccountnumber
                    AND @Recordeddate >= CAST(RecordedDate AS DATE)
                    AND @Recordeddate < DATEADD(dd, 1, CAST(RecordedDate AS DATE)))
			BEGIN
            UPDATE TCD.TARGETPRODUCTIONDETAILS SET
                    TargetProduction = @Targetproduction, 
                    LastModifiedByUserId = @Userid, 
                    RecordedDate = @Recordeddate, 
                    TargetProduction_Display = @Targetproductiondisplay
						OUTPUT
                    inserted.ID AS Id, 
                    inserted.LastModifiedTime AS LastModifiedTime
                   INTO @Outputlist(
                    TargetProductionId, 
                    LastModifiedTime)
                WHERE
                    ShiftId = @Shiftid
                AND DayId = @Dayid
                AND EcolabAccountNumber = @Ecolabaccountnumber
                AND @Recordeddate >= CAST(RecordedDate AS DATE)
                AND @Recordeddate < DATEADD(dd, 1, CAST(RecordedDate AS DATE))
            SET @Output = '201'
            SET @Scope = @Output
            SELECT
                    @Scope
			END
			ELSE
			BEGIN
            SET @Newidtobeinserted = (SELECT
                                              ISNULL(MAX(TPD.ID), 0) + 1
                                          FROM TCD.TargetProductionDetails AS TPD
                                          WHERE TPD.EcolabAccountNumber = @Ecolabaccountnumber)
            INSERT INTO TCD.TARGETPRODUCTIONDETAILS(
                    ID, 
                    ShiftId, 
                    DayId, 
                    RecordedDate, 
                    TargetProduction, 
                    EcolabAccountNumber, 
                    LastModifiedByUserId, 
                    TargetProduction_Display, 
                    LastModifiedTime)
						OUTPUT
                    inserted.ID AS Id, 
                    inserted.LastModifiedTime AS LastModifiedTime
                   INTO @Outputlist(
                    TargetProductionId, 
                    LastModifiedTime)
                VALUES
                       (
                        @Newidtobeinserted, 
                        @Shiftid, 
                        @Dayid, 
                        @Recordeddate, 
                        @Targetproduction, 
                        @Ecolabaccountnumber, 
                        @Userid, 
                        @Targetproductiondisplay, 
                        @Currentutctime)
            SET @Output = '201'
            SET @Scope = @Output
            SELECT
                    @Scope
			END

    SELECT TOP 1
            @Outputlastmodifiedtimestampatlocal = O.LastModifiedTime, 
            @Outputtargetproductionid = O.TargetProductionId
        FROM @Outputlist AS O

    --RETURN @Returnvalue
			
	SET NOCOUNT OFF;
END