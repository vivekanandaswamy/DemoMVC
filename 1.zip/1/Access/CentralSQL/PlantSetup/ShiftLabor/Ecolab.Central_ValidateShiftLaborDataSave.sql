
BEGIN

	SET NOCOUNT ON


	DECLARE @Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N''


	IF((SELECT
			   COUNT(*)
		   FROM TCD.ShiftLaborData
		   WHERE EcolabAccountNumber = @Ecolabaccountnumber) <> @Maxnoofrec)
	BEGIN
			SET @Errorid = 51030
			SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR) + N': Record count does not match.'
			RAISERROR(@Errormessage, 16, 1)
			SET @Returnvalue = -1
			--RETURN @Returnvalue
	END

	SET NOCOUNT OFF

	--RETURN @Returnvalue

END