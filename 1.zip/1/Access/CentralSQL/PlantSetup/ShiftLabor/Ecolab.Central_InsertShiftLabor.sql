
BEGIN


SET NOCOUNT ON


    DECLARE @Output VARCHAR(50) = ''

    DECLARE @Currentutctime DATETIME = GETUTCDATE()
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
    SET @Outputlastmodifiedtimestampatlocal = @Currentutctime

    DECLARE @Returnvalue INT = 0, 
            @Newshiftlabordataid INT = NULL

    IF NOT EXISTS(SELECT
                          1
                      FROM TCD.ShiftLaborData AS SLD
                      WHERE SLD.LaborTypeId = @Labortypeid
                        AND SLD.LocationId = @Locationid
						 AND SLD.IS_Deleted <> 1
                        AND SLD.ShiftId = @Shiftid
                        AND SLD.EcolabAccountNumber = @Ecolabaccountnumber)
BEGIN
--Generate new Id...
            SET @Newshiftlabordataid = (SELECT
                                                ISNULL(MAX(SLD.LaborId), 0) + 1
                                            FROM TCD.ShiftLaborData AS SLD
                                            WHERE SLD.EcolabAccountNumber = @Ecolabaccountnumber)
			
			/*INSERTING THE DATA FOR SHIFT LABOUR DATA*/

            INSERT INTO TCD.ShiftLaborData(
                    EcolabAccountNumber, 
                    LaborId, 
                    ShiftId, 
                    DayId, 
                    LaborHours, 
                    PricePerHr, 
                    LaborTypeId, 
                    LocationId, 
                    LastModifiedByUserId, 
                    LastModifiedTime)
                VALUES
                       (
                        @Ecolabaccountnumber, 
                        @Newshiftlabordataid, 
                        @Shiftid, 
                        @Dayid, 
                        @Laborhours, 
                        @Priceperhr, 
                        @Labortypeid, 
                        @Locationid, 
                        @Userid, 
                        @Currentutctime)

END
    SET @Output = '101'
    SET @Scope = @Output
    SELECT
            @Scope
    SET @Outputshiftlabordataid = @Newshiftlabordataid
    --RETURN @Returnvalue

END