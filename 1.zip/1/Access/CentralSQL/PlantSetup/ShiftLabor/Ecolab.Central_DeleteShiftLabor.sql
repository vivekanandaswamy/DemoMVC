
BEGIN


SET NOCOUNT ON



	DECLARE @Output VARCHAR(50) = ''

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE()


	--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
	--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
	SET @Outputlastmodifiedtimestampatlocal = @Currentutctime
	--We thus won't set this output param after the operation
	SET @Scope = ISNULL(@Scope, NULL)



	UPDATE SLD SET
			SLD.IS_Deleted = 1, 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Currentutctime
		FROM TCD.ShiftLaborData SLD
		WHERE EcolabAccountNumber = @Ecolabaccountnumber
			  AND LaborId = @Id


	SET @Output = @Id
	SET @Scope = @Output
	SELECT
			@Scope

END