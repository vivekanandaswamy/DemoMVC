
BEGIN
SET NOCOUNT ON
  BEGIN
		DECLARE @Output VARCHAR(50) = ''

		DECLARE @Returnvalue INT = 0, 
				@Errorid INT = 0, 
				@Errormessage NVARCHAR(4000) = N'', 
				@Currentutctime DATETIME = GETUTCDATE()

		DECLARE @Outputlist AS TABLE(
				ShiftLaborDataId INT, 
				LastModifiedTimestamp DATETIME)

		--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
		--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
		SET @Outputlastmodifiedtimestampatlocal = @Currentutctime

  BEGIN
		--If the call is not local, check that the LastModifiedTime matches with the central
			IF @Lastmodifiedtimestampatcentral IS NOT NULL
		   AND NOT EXISTS(SELECT
								  1
							  FROM TCD.ShiftLaborData AS SLD
							  WHERE SLD.EcolabAccountNumber = @Ecolabaccountnumber
								AND SLD.LaborId = @Id
								AND SLD.LastModifiedTime = @Lastmodifiedtimestampatcentral)
				BEGIN
				
					SET @Scope = 60000
					SELECT @Scope 

					--SET @Errorid = 60000
					--SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
					--RAISERROR(@Errormessage, 16, 1)
					--SET @Returnvalue = -1
					--RETURN @Returnvalue


				END

		--Proceed to update, since it's either a local call or Synch. call with synch. time matching
		  
		  /*UPDATING THE DATA FOR SHIFT LABOUR DATA*/
		  
			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.ShiftLaborData
							  WHERE LaborTypeId = @Labortypeid
								AND LocationId = @Locationid
								AND IS_Deleted <> 1
								AND LaborId <> @Id
								AND ShiftId = @Shiftid
								AND EcolabAccountNumber = @Ecolabaccountnumber)
						 BEGIN
					UPDATE SLD SET
							ShiftId = @Shiftid, 
							DayId = @Dayid, 
							LaborHours = @Laborhours, 
							PricePerHr = @Priceperhr, 
							LaborTypeId = @Labortypeid, 
							LaborCount = @Laborcount, 
							LocationId = @Locationid, 
							LastModifiedByUserId = @Userid, 
							LastModifiedTime = @Currentutctime
									OUTPUT
							inserted.LaborId AS ShiftLaborDataId, 
							inserted.LastModifiedTime AS LastModifiedTime
						   INTO @Outputlist(
							ShiftLaborDataId, 
							LastModifiedTimestamp)
						FROM TCD.ShiftLaborData SLD
						WHERE
							LaborId = @Id
						AND EcolabAccountNumber = @Ecolabaccountnumber

					SET @Output = '201'
					SET @Scope = @Output
					SELECT
							@Scope
	END
	ELSE
	BEGIN

					SET @Output = '301'
					SET @Scope = @Output
					SELECT
							@Scope
	END
			SELECT TOP 1
					@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
					@Outputshiftlabordataid = O.ShiftLaborDataId
				FROM @Outputlist AS O

   END
   END
END