
BEGIN

	SET NOCOUNT ON;

	DECLARE @Returnvalue INT = 0, 
			@Output VARCHAR(100) = '', 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Newlaborcostidtobeinserted INT = NULL, 
			@Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL,
			@Laborcostid INT = NULL

	DECLARE @Outputlist AS TABLE(
			OutputLaborCostId INT, 
			LastModifiedTimestamp DATETIME)
	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)
	SET @Scope = ISNULL(@Scope, NULL)
	SET @Outputlaborcostid = ISNULL(@Outputlaborcostid, NULL)
	SET @Laborcostid = ISNULL(@Laborcostid, NULL)									

	/* Inserting the values in to Labor Cost table if it is new meter */

	IF NOT EXISTS(SELECT
						  *
					  FROM TCD.LaborCost
					  WHERE LaborTypeId = @Labortypeid
						AND EcolabAccountNumber = @Ecolabaccountnumber)
		BEGIN

			--INSERT here
			--Generate id using Max

			SET @Newlaborcostidtobeinserted = (SELECT
													   ISNULL(MAX(LC.LaborCostId), 0) + 1
												   FROM TCD.LaborCost AS LC
												   WHERE LC.EcolabAccountNumber = @Ecolabaccountnumber)

			/* Inserting the Details of Labor Costs	 into LaborCost table if it is the first entry */

			INSERT INTO TCD.LaborCost(
					LaborCostId, 
					LaborTypeId, 
					Cost, 
					EcolabAccountNumber, 
					LastModifiedByUserId, 
					LastModifiedTime)
			OUTPUT
					inserted.LaborCostId AS LaborCostId, 
					inserted.LastModifiedTime AS LastModifiedTimestamp
				   INTO @Outputlist(
					OutputLaborCostId, 
					LastModifiedTimestamp)
				SELECT
						@Newlaborcostidtobeinserted, 
						@Labortypeid, 
						@Laborcost, 
						@Ecolabaccountnumber, 
						@Userid, 
						@Currentutctime

		END
	ELSE
		BEGIN

			/* Updating the value of Labor Cost details */

			UPDATE LC SET
					LC.Cost = @Laborcost, 
					LC.LaborTypeId = @Labortypeid, 
					LC.LastModifiedByUserId = @Userid, 
					LC.LastModifiedTime = @Currentutctime
			OUTPUT
					inserted.LaborCostId AS LaborCostId, 
					inserted.LastModifiedTime AS LastModifiedTimestamp
				   INTO @Outputlist(
					OutputLaborCostId, 
					LastModifiedTimestamp)
				FROM TCD.LaborCost LC
				WHERE
					LaborTypeId = @Labortypeid
				AND EcolabAccountNumber = @Ecolabaccountnumber
		END

	SET @Output = '201'
	SET @Scope = @Output
	SELECT
			@Scope


	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputlaborcostid = O.OutputLaborCostId
		FROM @Outputlist AS O

	--RETURN @Returnvalue

	SET NOCOUNT OFF;

END