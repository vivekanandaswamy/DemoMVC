
BEGIN
SET NOCOUNT ON;
	SELECT
			ShiftName, 
			CAST(StartDateTime AS TIME)AS StartTime, 
			CAST(EndDateTime AS TIME)AS EndTime
		FROM tcd.productionshiftdata
		WHERE StartDateTime IN(SELECT
									   DATEADD(day, DATEDIFF(day, '19000101', GETUTCDATE()), CAST(DATEADD(second, DATEDIFF(second, GETDATE(),GETUTCDATE()), StartTime)AS DATETIME))
								   FROM tcd.shiftdata)
		   OR EndDateTime IN(SELECT
									 DATEADD(day, DATEDIFF(day, '19000101', GETUTCDATE()), CAST(DATEADD(second, DATEDIFF(second, GETDATE(),GETUTCDATE()), StartTime)AS DATETIME))
								 FROM tcd.shiftdata)
END