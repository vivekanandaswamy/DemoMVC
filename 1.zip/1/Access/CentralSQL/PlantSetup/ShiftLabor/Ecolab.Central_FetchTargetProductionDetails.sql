
BEGIN
	SET NOCOUNT ON;
	DECLARE @Targetproduction TABLE(
			ShiftName VARCHAR(100), 
			ShiftId INT, 
			TargetProduction DECIMAL(18, 2), 
			DayId INT, 
			StartTime TIME, 
			EndTime TIME, 
			TargetProduction_display DECIMAL(18, 2), 
			LastModifiedTime DATETIME)
	DECLARE @Count INT
	SET @Count = (SELECT
						  COUNT(1)
					  FROM TCD.TARGETPRODUCTIONDETAILS
					  WHERE EcolabAccountNumber = @Ecolabaccountnumber)
	IF @Count > 0
	   BEGIN
			WITH temp
				AS((SELECT
			S.ShiftName, 
							CAST(S.ShiftId AS INT)AS ShiftId, 
			TPD.TargetProduction,
			TPD.DAYID,
			S.StartTime,
			S.EndTime,
			TPD.TargetProduction_Display,
			TPD.LastModifiedTime
						FROM tcd.ShiftData AS S
							 LEFT JOIN TCD.TARGETPRODUCTIONDETAILS AS TPD ON S.ShiftId = TPD.ShiftId
																		 AND S.EcolabAccountNumber = TPD.EcolabAccountNumber
						WHERE DATEADD(day, 1, TPD.RECORDEDDATE) > GETDATE()
						  AND s.Is_Deleted = 0
						  AND S.EcolabAccountNumber = @Ecolabaccountnumber))
				INSERT INTO @Targetproduction(
							ShiftName , 
							ShiftId ,
							TargetProduction ,
							DayId ,
							StartTime ,
							EndTime ,
							TargetProduction_display ,
							LastModifiedTime)
				SELECT
						* FROM temp 
		--SELECT * FROM @TARGETPRODUCTION
			   END
	SELECT
			sd.ShiftName, 
			CAST(sd.ShiftId AS INT)AS ShiftId, 
			sd.TargetProduction,
			sd.DAYID,
			sd.StartTime,
			sd.EndTime,
			sd.TargetProduction_Display,
			sd.LastModifiedTime INTO
			#TARGETPRODUCTION1
		FROM TCD.ShiftData AS sd
		WHERE Is_Deleted <> 1
		  AND EcolabAccountNumber = @Ecolabaccountnumber
		  AND sd.ShiftId NOT IN(SELECT
										ShiftId FROM @Targetproduction)
	INSERT INTO #TARGETPRODUCTION1(ShiftName , 
							ShiftId ,
							TargetProduction ,
							DayId ,
							StartTime ,
							EndTime ,
							TargetProduction_display ,
							LastModifiedTime)
	SELECT
			* FROM @Targetproduction
	SELECT
			* FROM #TARGETPRODUCTION1
	DROP TABLE
			#TARGETPRODUCTION1
	SET NOCOUNT OFF;
END