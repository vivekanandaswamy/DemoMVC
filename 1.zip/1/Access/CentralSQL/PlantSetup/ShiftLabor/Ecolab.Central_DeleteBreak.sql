
BEGIN
SET NOCOUNT ON
BEGIN

		DECLARE @Returnvalue INT = 0, 
				@Errorid INT = 0, 
				@Errormessage NVARCHAR(4000) = N'', 
				@Currentutctime DATETIME = GETUTCDATE()

		DECLARE @Outputlist AS TABLE(
				ShiftId INT)
		DECLARE @Errorseverity INT = NULL, 
				@Errorprocedure SYSNAME = NULL, 
				@Messagestring NVARCHAR(2500) = NULL, 
				@Errornumber INT = 0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
		SET @Outputlastmodifiedtimestampatlocal = @Currentutctime
--If the call is not local, check that the LastModifiedTime matches with the central
--IF	(
--		@LastModifiedTimestampAtCentral			IS NOT	NULL
--	AND																	--	is called by UpdateShifts that is called here)
--	NOT	EXISTS	(	SELECT	1
--					FROM	TCD.[Shift]				S
--					WHERE	S.EcolabAccountNumber	=	@EcolabAccountNumber
--						AND	S.ShiftId				=	@ShiftId
--						AND	S.LastModifiedTime		=	@LastModifiedTimestampAtCentral
--				)
--	)
--	BEGIN
--			SET			@ErrorId					=	60000
--			SET			@ErrorMessage				=	N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
--			RAISERROR	(@ErrorMessage, 16, 1)
--			SET			@ReturnValue				=	-1
--			RETURN		(@ReturnValue)
--	END

--Proceed, since it's either a local call or Synch. call with synch. time matching

		UPDATE TCD.ShiftBreakData SET
				Is_Deleted = 1, 
				LastModifiedByUserId = @Userid
		OUTPUT
				inserted.ShiftId
			   INTO @Outputlist(
				ShiftId)
			WHERE
				BreakId = @Breakid
			AND ShiftId = @Shiftid
			AND DayId = @Dayid
			AND EcolabAccountNumber = @Ecolabaccountnumber


--IF	EXISTS	(SELECT	1	FROM	@OutputList)
--	BEGIN
--			UPDATE	TCD.[Shift]
--				SET	LastModifiedTime			=			@CurrentUTCTime
--			WHERE	EcolabAccountNumber			=			@EcolabAccountNumber
--				AND	ShiftId						=			@ShiftId

--			--SELECT	TOP	1
--			--		@OutputShiftId				=			ShiftId
--			--FROM	@OutputList
--	END

/* Auditing the deleted data in the SHIFT BREAK table */

--EXEC [TCD].[AuditingDeleteDetails] @BreakId,@BreakTable_name,@UserID
END
END