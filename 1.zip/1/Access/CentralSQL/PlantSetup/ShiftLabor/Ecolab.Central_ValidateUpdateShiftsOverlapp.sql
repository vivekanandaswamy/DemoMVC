
BEGIN
SET NOCOUNT ON      
BEGIN  

		DECLARE @Returnvalue INT = 0, 
				@Errorid INT = 0, 
				@Errormessage NVARCHAR(4000) = N'', 
				@Currentutctime DATETIME = GETUTCDATE(), 
				@Allowupdate BIT = 'TRUE', 
				@Rollingcount INT = 1, 
				@Rowcount INT = NULL, 
				@Dayid INT = NULL, 
				@Datestarttime DATETIME, 
				@Dateendtime DATETIME, 
				@Prevday INT, 
				@Nextday INT  
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded

		SET @Result = ISNULL(@Result, 'Success')

		IF @Issunday = 1
			BEGIN
				SET @Dayid = 1
			END
		ELSE
			BEGIN
				IF @Ismonday = 1
					BEGIN
						SET @Dayid = 2
					END
				ELSE
					BEGIN
						IF @Ismonday = 1
							BEGIN
								SET @Dayid = 2
							END
						ELSE
							BEGIN
								IF @Istuesday = 1
									BEGIN
										SET @Dayid = 3
									END
								ELSE
									BEGIN
										IF @Iswednesday = 1
											BEGIN
												SET @Dayid = 4
											END
										ELSE
											BEGIN
												IF @Isthursday = 1
													BEGIN
														SET @Dayid = 5
													END
												ELSE
													BEGIN
														IF @Isfriday = 1
															BEGIN
																SET @Dayid = 6
															END
														ELSE
															BEGIN
																IF @Issaturday = 1
																	BEGIN
																		SET @Dayid = 7
																	END
															END
													END
											END
									END
							END
					END
			END 
	
	 /* SHIFT OVERLAPPING OF TIMINGS */ 
	 
		SELECT
				@Prevday = CASE
							   WHEN @Dayid = 1 THEN 7
							   ELSE @Dayid - 1
						   END, 
				@Nextday = CASE
							   WHEN @Dayid = 7 THEN 1
							   ELSE @Dayid + 1
						   END
  
		IF @Endtime < @Starttime
		OR @Endtime = @Starttime
    BEGIN
				SELECT
						@Datestarttime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Starttime AS DATETIME))
				SET @Dateendtime = DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(@Endtime AS DATETIME))
		--SELECT @DateStartTime,@DateEndTime  
    END
    ELSE
    BEGIN
				SET @Datestarttime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Starttime AS DATETIME))
				SET @Dateendtime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Endtime AS DATETIME))
		--SELECT @DateStartTime,@DateEndTime
    END     

		DECLARE @Output VARCHAR(100) = ''
		DECLARE @Result_Table TABLE(
				Result INT)
		CREATE TABLE #shiftdata_temp(
				SNo INT IDENTITY(1, 1), 
				ShiftId INT, 
				ShiftName NVARCHAR(1000), 
				DayId INT, 
				StartTime [TIME](7), 
				EndTime [TIME](7), 
				TargetProduction DECIMAL(18, 2), 
				Is_Deleted BIT, 
				EcolabAccountNumber NVARCHAR(1000), 
				LastModifiedByUserId INT, 
				LastModifiedTime DATETIME, 
				LastSyncTime DATETIME, 
				TargetProduction_Display DECIMAL(18, 2), )
      INSERT INTO #shiftdata_temp  (ShiftId ,
								    ShiftName ,
									DayId ,
									StartTime ,
									EndTime ,
									TargetProduction,
									Is_Deleted,
									EcolabAccountNumber ,
									LastModifiedByUserId ,
									LastModifiedTime ,
									LastSyncTime ,
									TargetProduction_Display)
     SELECT 
					ShiftId, 
					ShiftName, 
					DayId, 
					StartTime, 
					EndTime, 
					TargetProduction, 
					Is_Deleted, 
					EcolabAccountNumber, 
					LastModifiedByUserId, 
					LastModifiedTime, 
					LastSyncTime, 
					TargetProduction_Display
			FROM TCD.ShiftData
			WHERE(DayId = @Dayid
			   OR DayId = @Prevday
			  AND (EndTime < StartTime
				OR EndTime = StartTime)
			   OR DayId = @Nextday)
			 AND IS_Deleted = 0
			 AND ShiftId <> @Shiftid
			 AND EcolabAccountNumber = @Ecolabaccountnumber

		UPDATE #shiftdata_temp SET
				DayId = CASE
							WHEN @Dayid = 1 THEN 0
							ELSE DayId
						END WHERE
				DayId = 7
		UPDATE #shiftdata_temp SET
				DayId = CASE
							WHEN @Dayid = 7 THEN 8
							ELSE DayId
						END WHERE
				DayId = 1

		SELECT
				@Rowcount = SNo FROM #shiftdata_temp
	     
		WHILE @Rollingcount <= @Rowcount
    BEGIN        
				DECLARE @Validstart DATETIME, 
						@Validend DATETIME
				SELECT
						@Validstart = CASE
										  WHEN DayId > @Dayid THEN DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(starttime AS DATETIME))
										  WHEN DayId < @Dayid THEN DATEADD(day, DATEDIFF(day, 1, GETDATE()), CAST(starttime AS DATETIME))
										  ELSE DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(starttime AS DATETIME))
									  END, 
						@Validend = CASE
										WHEN DayId > @Dayid
										 AND EndTime > StartTime
										  OR DayId = @Dayid
										 AND (EndTime = StartTime
										   OR EndTime < StartTime)THEN DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(EndTime AS DATETIME))
										WHEN DayId < @Dayid
										 AND (EndTime < StartTime
										   OR EndTime = StartTime)THEN DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS DATETIME))
										WHEN DayId > @Dayid
										 AND (EndTime < StartTime
										   OR EndTime = StartTime)THEN DATEADD(day, DATEDIFF(day, -2, GETDATE()), CAST(EndTime AS DATETIME))
										ELSE DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS DATETIME))
														  END
					FROM #shiftdata_temp
					WHERE SNo = @Rollingcount

				IF @Datestarttime > @Validstart
			   AND @Datestarttime < @Validend
				OR @Dateendtime > @Validstart
			   AND @Dateendtime < @Validend
				OR @Datestarttime = @Validstart
			   AND @Dateendtime > @Validend
				OR @Datestarttime < @Validstart
			   AND @Dateendtime = @Validend
				OR @Datestarttime < @Validstart
			   AND @Dateendtime > @Validend
		   BEGIN  
						SET @Allowupdate = 'FALSE'
						INSERT INTO @Result_Table(
								Result)
						VALUES
							   (
								1)
		   END        
		ELSE     
		   BEGIN        
						INSERT INTO @Result_Table(
								Result)
						VALUES
							   (
								0)
		   END   	  
		          
			SET @Rollingcount = @Rollingcount + 1        
    END        
		DROP TABLE
				#shiftdata_temp		  

	 /* COMPLETED LOGIC FOR VALIDATION */    
		
		IF @Allowupdate = 'TRUE'
	BEGIN
				IF EXISTS(SELECT
								  1
							  FROM TCD.ShiftData AS SD
								   INNER JOIN TCD.ShiftBreakData AS SBD ON SD.ShiftId = SBD.ShiftId
																	   AND SD.DayId = SBD.DayId
																	   AND SBD.EcolabAccountNumber = SD.EcolabAccountNumber
							  WHERE SD.StartTime = CAST(@Starttime AS TIME)
								AND SD.EndTime = CAST(@Endtime AS TIME)
								AND SBD.StartTime = @Breakstarttime
								AND SD.ShiftName = @Shiftname
								AND SBD.EndTime = @Breakendtime
								AND SD.EcolabAccountNumber = @Ecolabaccountnumber
								AND SD.Is_Deleted = @Isdeleted
								AND SD.DayId = @Dayid
								AND SD.TargetProduction = @Targetprod
								AND SBD.Is_Deleted = @Isdeleted)
							BEGIN
						IF EXISTS(SELECT
										  1
									  FROM TCD.ShiftData AS S
									  WHERE S.ShiftName = @Shiftname
										AND S.IS_DELETED <> 1
										AND S.DayId = @Dayid
										AND S.ShiftId <> @Shiftid
										AND S.EcolabAccountNumber = @Ecolabaccountnumber)
								BEGIN
								SET @Output = '301' + '_' + CAST(@Dayid AS VARCHAR(10))
								SET @Result+=@Output + '#'
								SELECT
										@Result
								--RETURN @Result
								END

						DECLARE @Shiftstarttime TIME = NULL, 
								@Shiftendtime TIME = NULL
						SELECT
								@Shiftstarttime = StartTime, 
								@Shiftendtime = EndTime
							FROM TCD.shiftdata
							WHERE ShiftId = @Shiftid
							  AND DayId = @Dayid
							  AND EcolabAccountNumber = @Ecolabaccountnumber
			
						IF @Shiftstarttime = CAST(@Starttime AS TIME)
					   AND @Shiftendtime = CAST(@Endtime AS TIME)
									 BEGIN  
								UPDATE @Result_Table SET
										Result = 0
									 END  

						IF EXISTS(SELECT
										  1 FROM @Result_Table WHERE Result = 1)
										BEGIN
								SET @Output = '501' + '_' + CAST(@Dayid AS VARCHAR(10))
								SET @Result+=@Output + '#'
								SELECT
										@Result
										END

							END
				SELECT
						@Result
	END
	ELSE
	BEGIN
				SET @Result = '501' + '_' + CAST(@Dayid AS VARCHAR(10))
				SELECT
						@Result
	END
 
  SET NOCOUNT OFF
END
END