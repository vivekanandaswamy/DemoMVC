
BEGIN
SET NOCOUNT ON          
  BEGIN           
           
        DECLARE @Output VARCHAR(100) = '', 
                @Rollingcount INT = 1, 
                @Rowcount INT = NULL, 
                @Datestarttime DATETIME, 
                @Dateendtime DATETIME, 
                @Prevday INT, 
                @Nextday INT

        SET @Outputshiftid = ISNULL(@Outputshiftid, NULL)            

 
        SELECT
                @Prevday = CASE
                               WHEN @Dayid = 1 THEN 7
                               ELSE @Dayid - 1
                           END, 
                @Nextday = CASE
                               WHEN @Dayid = 7 THEN 1
                               ELSE @Dayid + 1
                           END
  
        IF @Endtime < @Starttime
        OR @Endtime = @Starttime
    BEGIN
                SELECT
                        @Datestarttime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Starttime AS DATETIME))
                SET @Dateendtime = DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(@Endtime AS DATETIME))
        --SELECT @DateStartTime,@DateEndTime  
    END
    ELSE
    BEGIN
                SET @Datestarttime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Starttime AS DATETIME))
                SET @Dateendtime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(@Endtime AS DATETIME))
        --SELECT @DateStartTime,@DateEndTime
    END     

        DECLARE @Result_Table TABLE(
                Result INT)
        CREATE TABLE #shiftdata_temp(
                SNo INT IDENTITY(1, 1), 
                ShiftId INT, 
                ShiftName NVARCHAR(1000), 
                DayId INT, 
                StartTime [TIME](7), 
                EndTime [TIME](7), 
                TargetProduction DECIMAL(18, 2), 
                Is_Deleted BIT, 
                EcolabAccountNumber NVARCHAR(1000), 
                LastModifiedByUserId INT, 
                LastModifiedTime DATETIME, 
                LastSyncTime DATETIME, 
                TargetProduction_Display DECIMAL(18, 2))
      INSERT INTO #shiftdata_temp (ShiftId ,
									ShiftName ,
									DayId ,
									StartTime ,
									EndTime ,
									TargetProduction,
									Is_Deleted,
									EcolabAccountNumber ,
									LastModifiedByUserId ,
									LastModifiedTime ,
									LastSyncTime ,
									TargetProduction_Display)
            SELECT
                    ShiftId, 
                    ShiftName, 
                    DayId, 
                    StartTime, 
                    EndTime, 
                    TargetProduction, 
                    Is_Deleted, 
                    EcolabAccountNumber, 
                    LastModifiedByUserId, 
                    LastModifiedTime, 
                    LastSyncTime, 
                    TargetProduction_Display
            FROM TCD.ShiftData
            WHERE(DayId = @Dayid
               OR DayId = @Prevday
              AND (EndTime < StartTime
                OR EndTime = StartTime)
               OR DayId = @Nextday)
             AND IS_Deleted = 0
             AND EcolabAccountnumber = @Ecolabaccountnumber

        UPDATE #shiftdata_temp SET
                DayId = CASE
                            WHEN @Dayid = 1 THEN 0
                            ELSE DayId
                        END WHERE
                DayId = 7
        UPDATE #shiftdata_temp SET
                DayId = CASE
                            WHEN @Dayid = 7 THEN 8
                            ELSE DayId
                        END WHERE
                DayId = 1
      
        SELECT
                @Rowcount = SNo FROM #shiftdata_temp
         
        WHILE @Rollingcount <= @Rowcount
    BEGIN        
                DECLARE @Validstart DATETIME, 
                        @Validend DATETIME, 
                        @Result VARCHAR(10) = ''
                SELECT
                        @Validstart = CASE
                                          WHEN DayId > @Dayid THEN DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(starttime AS DATETIME))
                                          WHEN DayId < @Dayid THEN DATEADD(day, DATEDIFF(day, 1, GETDATE()), CAST(starttime AS DATETIME))
                                          ELSE DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(starttime AS DATETIME))
                                      END, 
                        @Validend = CASE
                                        WHEN DayId > @Dayid
                                         AND EndTime > StartTime
                                          OR DayId = @Dayid
                                         AND (EndTime = StartTime
                                           OR EndTime < StartTime)THEN DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(EndTime AS DATETIME))
                                        WHEN DayId < @Dayid
                                         AND (EndTime < StartTime
                                           OR EndTime = StartTime)THEN DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS DATETIME))
                                        WHEN DayId > @Dayid
                                         AND (EndTime < StartTime
                                           OR EndTime = StartTime)THEN DATEADD(day, DATEDIFF(day, -2, GETDATE()), CAST(EndTime AS DATETIME))
                                        ELSE DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS DATETIME))
                                                          END
                    FROM #shiftdata_temp
                    WHERE SNo = @Rollingcount

                IF @Datestarttime > @Validstart
               AND @Datestarttime < @Validend
                OR @Dateendtime > @Validstart
               AND @Dateendtime < @Validend
                OR @Datestarttime = @Validstart
               AND @Dateendtime > @Validend
                OR @Datestarttime < @Validstart
               AND @Dateendtime = @Validend
                OR @Datestarttime < @Validstart
               AND @Dateendtime > @Validend
           BEGIN        
                        INSERT INTO @Result_Table(
                                Result)
                            VALUES
                                   (
                                    1)
           END        
           ELSE     
           BEGIN        
                        INSERT INTO @Result_Table(
                                Result)
                            VALUES
                                   (
                                    0)
           END        
                 
        
            SET @Rollingcount = @Rollingcount + 1        
    END        
        DROP TABLE
                #shiftdata_temp       
    
    /* COMPLETED LOGIC FOR VALIDATION */          
        
        DECLARE @Currentutctime DATETIME = GETUTCDATE()
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
        SET @Outputlastmodifiedtimestampatlocal = @Currentutctime

        DECLARE @Errornumber INT = 0, 
                @Errormessage NVARCHAR(2048) = NULL, 
                @Errorseverity INT = NULL, 
                @Errorprocedure SYSNAME = NULL, 
                @Messagestring NVARCHAR(2500) = NULL

        DECLARE @Newshiftid INT = NULL, 
                @Newbreakid INT = NULL

        IF NOT EXISTS(SELECT
                              1
                          FROM TCD.ShiftData AS SD
                          WHERE SD.DayId = @Dayid
                            AND SD.Is_Deleted = 0
                            AND SD.ShiftName = @Shiftname
                            AND SD.EcolabAccountNumber = @Ecolabaccountnumber)
                                BEGIN

                IF NOT EXISTS(SELECT
                                      1 FROM @Result_Table WHERE Result = 1)
                
                BEGIN           

                        IF NOT EXISTS(SELECT
                                              1
                                          FROM TCD.ShiftData AS SD
                                          WHERE SD.StartTime = CAST(@Starttime AS TIME)
                                            AND SD.EndTime = CAST(@Endtime AS TIME)
                                            AND SD.DayId = @Dayid
                                            AND SD.Is_Deleted = 0
                                            AND SD.EcolabAccountNumber = @Ecolabaccountnumber)
                                    BEGIN

                                    --Generate new ShiftId...
                                SET @Newshiftid = (SELECT
                                                           ISNULL(MAX(S.ShiftId), 0) + 1
                                                       FROM TCD.ShiftData AS S
                                                       WHERE S.EcolabAccountNumber = @Ecolabaccountnumber)
                                INSERT INTO TCD.ShiftData(
                                        ShiftId, 
                                        ShiftName, 
                                        DayId, 
                                        StartTime, 
                                        EndTime, 
                                        EcolabAccountNumber, 
                                        TargetProduction, 
                                        LastModifiedByUserId, 
                                        TargetProduction_Display)
                                    VALUES
                                           (
                                            @Newshiftid, 
                                            @Shiftname, 
                                            @Dayid, 
                                            CAST(@Starttime AS TIME), 
                                            CAST(@Endtime AS TIME), 
                                            @Ecolabaccountnumber, 
                                            @Targetprod, 
                                            @Userid, 
                                            @Targetproddisplay)

                                SELECT
                                        @Shiftid = ShiftId
                                    FROM TCD.ShiftData AS S
                                    WHERE S.ShiftName = @Shiftname
                                      AND S.IS_DELETED <> 1
                                      AND DayId = @Dayid
                                      AND S.EcolabAccountNumber = @Ecolabaccountnumber

                                                                                                                                                                                                                        
								--IF NOT EXISTS(	SELECT 1 FROM [TCD].ShiftBreakData SBD 
								--WHERE				SBD.StartTime					 =				  @BreakStartTime
								--AND				 SBD.EndTime						=				 @BreakEndTime
								--AND				 SBD.DayId						  =				   @DayId
								--AND				 SBD.Is_Deleted					   =				0
								--AND				 SBD.ShiftId						=				 @ShiftId
                                                        --)
                                                        --Begin
                                                            
                                                            --Generate new BreakId...
                                SET @Newbreakid = (SELECT
                                                           ISNULL(MAX(SBD.BreakId), 0) + 1
                                                       FROM TCD.ShiftBreakData AS SBD
                                                       WHERE SBD.EcolabAccountNumber = @Ecolabaccountnumber)
                                INSERT INTO TCD.ShiftBreakData(
                                        BreakId, 
                                        ShiftId, 
                                        DayId, 
                                        StartTime, 
                                        EndTime, 
                                        EcolabAccountNumber, 
                                        LastModifiedByUserId)
                                    VALUES
                                           (
                                            @Newbreakid, 
                                            @Shiftid, 
                                            @Dayid, 
                                            @Breakstarttime, 
                                            @Breakendtime, 
                                            @Ecolabaccountnumber, 
                                            @Userid)   

                                                                            --UPDATE [TCD].ShiftBreakData SET Id = SCOPE_IDENTITY() WHERE EcolabAccountNumber  =  @EcolabAccountNumber

                                                                        
                                                            
                                SET @Output = '101'
                                SET @Scope = @Output
                                SELECT
                                        @Scope, 
                                        LastModifiedByUserId = @Userid    
                                                        --END
                                        END
                        ELSE
                            BEGIN
                                SET @Output = '501' + '_' + CAST(@Dayid AS VARCHAR(10))
                                SET @Scope = @Output
                                SELECT
                                        @Scope, 
                                        LastModifiedByUserId = @Userid
                                                        END
                                    
            END    
            ELSE

            BEGIN
                        SET @Output = '501' + '_' + CAST(@Dayid AS VARCHAR(10))
                        SET @Scope = @Output
                        SELECT
                                @Scope, 
                                LastModifiedByUserId = @Userid
                END        
                
                    


			END
		ELSE
                                            BEGIN
				IF @Count <> 0
                               BEGIN             
                        SELECT TOP 1
                                @Shiftid = sd.ShiftId
                            FROM TCD.ShiftData AS SD
                            WHERE SD.StartTime = CAST(@Starttime AS TIME)
                              AND SD.EndTime = CAST(@Endtime AS TIME)
                              AND SD.DayId = @Dayid
                              AND SD.Is_Deleted = 0
                              AND SD.EcolabAccountNumber = @Ecolabaccountnumber

                        SET @Newbreakid = (SELECT
                                                   ISNULL(MAX(SBD.BreakId), 0) + 1
                                               FROM TCD.ShiftBreakData AS SBD
                                               WHERE SBD.EcolabAccountNumber = @Ecolabaccountnumber)
                        INSERT INTO TCD.ShiftBreakData(
                                BreakId, 
                                ShiftId, 
                                DayId, 
                                StartTime, 
                                EndTime, 
                                EcolabAccountNumber, 
                                LastModifiedByUserId)
                            VALUES
                                   (
                                    @Newbreakid, 
                                    @Shiftid, 
                                    @Dayid, 
                                    @Breakstarttime, 
                                    @Breakendtime, 
                                    @Ecolabaccountnumber, 
                                    @Userid)  
                                     
                        --UPDATE [TCD].ShiftBreakData SET Id = SCOPE_IDENTITY()  
                        SET @Output = '101'
                        SET @Scope = @Output
                        SELECT
                                @Scope, 
                                LastModifiedByUserId = @Userid
                    
                           END                 
ELSE
    BEGIN
                        SET @Output = '301_' + CAST(@Dayid AS VARCHAR(10))
                        SET @Scope = @Output
                        SELECT
                                @Scope, 
                                LastModifiedByUserId = @Userid
                    END
    END
   
        SET @Scope = ISNULL(@Scope, NULL)
    END
END