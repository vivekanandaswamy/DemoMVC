
BEGIN

	SET NOCOUNT ON


	SELECT
			LC.LaborTypeId, 
			LC.COST
		FROM TCD.LABORCOST AS LC
			 JOIN TCD.LABORTYPE AS LT ON LT.LABORTYPEID = LC.LABORTYPEID
		WHERE LC.LABORTYPEID = @Labortypeid
		  AND LC.EcolabAccountNumber = @Ecolabaccountnumber


END