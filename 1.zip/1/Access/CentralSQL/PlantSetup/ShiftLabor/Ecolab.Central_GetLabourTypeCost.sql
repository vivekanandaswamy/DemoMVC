
BEGIN
	SET NOCOUNT ON
	SELECT
			LC.LaborCostId, 
			LT.LaborTypeId, 
			LT.Description, 
			LC.Cost, 
			LC.EcolabAccountNumber, 
			LC.LastModifiedTime, 
			LC.LastSyncTime
		FROM TCD.LaborType AS LT
			 LEFT JOIN TCD.LaborCost AS LC ON LC.LaborTypeId = Lt.LaborTypeId
										  AND LC.EcolabAccountNumber = @Ecolabaccountnumber
	SET NOCOUNT OFF
END