
BEGIN

SET NOCOUNT ON;

	SELECT DISTINCT
			gtm.GasoilId, 
			Name, 
			gotm.DefaultValue, 
			(SELECT DISTINCT
					 rkv.[Value]
				 FROM TCD.DimensionalSubunits AS ds
					  INNER JOIN tcd.DimensionalUnits AS du ON du.Unit = ds.Unit
					  INNER JOIN TCD.DimensionalUsageKey AS duk ON duk.Unit = ds.Unit
					  INNER JOIN TCD.DimensionalUnitsDefaults AS dud ON dud.UsageKey = duk.UsageKey
					  INNER JOIN TCD.ResourceKeyMaster AS rkm ON rkm.KeyName = dud.Subunit
					  INNER JOIN tcd.ResourceKeyValue AS rkv ON rkv.KeyName = rkm.KeyName
				 WHERE duk.UsageKey = gtm.UsageKey
				   AND dud.UnitSystemId = (
			 SELECT
					 p.UOMId FROM TCD.Plant AS p WHERE p.EcolabAccountNumber = @Ecolabaccountnumber))AS UOM_Code, 
			UOM_Desc
		FROM TCD.GasoilTypeMaster AS gtm
			 INNER JOIN TCD.GasOilTypeMapping AS gotm ON gotm.GasOilId = gtm.GasoilId
		WHERE gotm.RegionId = (SELECT
									   p.RegionId FROM TCD.Plant AS p WHERE p.EcolabAccountNumber = @Ecolabaccountnumber)
SET NOCOUNT OFF;
END