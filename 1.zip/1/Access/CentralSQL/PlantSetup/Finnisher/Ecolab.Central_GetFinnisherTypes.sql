
BEGIN
	SET NOCOUNT ON;

	SELECT
			FinnisherTypeId, 
			Name FROM TCD.FinnisherType WHERE Is_Deleted = 'FALSE'


	SET NOCOUNT OFF;
END