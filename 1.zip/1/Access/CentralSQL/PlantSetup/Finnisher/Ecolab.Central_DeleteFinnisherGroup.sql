
BEGIN        

		
SET NOCOUNT ON

	DECLARE @Output VARCHAR(100) = ''

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL

		
				

	--Proceed to soft-delete, since it's either a local call or Synch. call with synch. time matching
	UPDATE TCD.MachineGroup SET
			is_deleted = 1, 
			LastModifiedByUserId = @Userid,	 
			LastModifiedTime = @Currentutctime
		WHERE EcolabAccountNumber = @Ecolabaccountnumber
		  AND Id = @Grouptypeid

	UPDATE TCD.Finnishers SET
			is_deleted = 1, 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Currentutctime
		WHERE EcolabAccountNumber = @Ecolabaccountnumber
			  AND FinnisherGroupId = @Grouptypeid

	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()
	--RETURN @Returnvalue
END