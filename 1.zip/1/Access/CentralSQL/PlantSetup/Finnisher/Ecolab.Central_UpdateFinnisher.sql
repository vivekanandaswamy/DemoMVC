
BEGIN

SET NOCOUNT ON    

BEGIN    

		DECLARE @Output VARCHAR(100) = ''

		DECLARE @Returnvalue INT = 0, 
				@Currentutctime DATETIME = GETUTCDATE()

		DECLARE @Outputlist AS TABLE(
				FinisherId INT, 
				LastModifiedTimestamp DATETIME)
		DECLARE @Errornumber INT = 0, 
				@Errormessage NVARCHAR(2048) = NULL, 
				@Errorseverity INT = NULL, 
				@Errorprocedure SYSNAME = NULL, 
				@Messagestring NVARCHAR(2500) = NULL

		SET @Scope = ISNULL(@Scope, NULL)

		IF NOT EXISTS(SELECT
							  1
						  FROM TCD.Finnishers AS F
						  WHERE F.EcolabAccountNumber = @Ecolabaccountnumber
							AND F.FinnisherId != @Finnisherid
							AND FinnisherNo = @Finnisherno
							AND Is_Deleted = 0)
				BEGIN    
				IF NOT EXISTS(SELECT
									  1
								  FROM TCD.Finnishers AS F
								  WHERE F.EcolabAccountNumber = @Ecolabaccountnumber
									AND F.FinnisherId != @Finnisherid
									AND Name = @Name
									AND Is_Deleted = 0)
														BEGIN
												BEGIN
							UPDATE TCD.Finnishers SET
									Name = @Name, 
									FinnisherTypeId = @Finnishertypeid, 
									LastModifiedByUserId = @Userid, 
									FinnisherNo = @Finnisherno, 
									LastModifiedTime = @Currentutctime
								FROM TCD.Finnishers F
								WHERE
									F.EcolabAccountNumber = @Ecolabaccountnumber
								AND F.FinnisherId = @Finnisherid
												END


						SET @Output = '102'
						SET @Scope = @Output
						SELECT
								@Scope
										END    
						ELSE    
										BEGIN    
						SET @Output = '301'
						SET @Scope = @Output
						SELECT
								@Scope
										END    
				END    
ELSE    
				BEGIN    
				SET @Output = '302'
				IF EXISTS(SELECT
								  1
							  FROM TCD.Finnishers
							  WHERE Name = @Name
								AND FinnisherId != @Finnisherid
								AND IS_DELETED = 0)
					BEGIN
						SET @Output = '303'
					END
				SET @Scope = @Output
				SELECT
						@Scope
				END    


--set at-least the datetime output param to limit the impact in service layer
		SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()


		--RETURN @Returnvalue


END
END