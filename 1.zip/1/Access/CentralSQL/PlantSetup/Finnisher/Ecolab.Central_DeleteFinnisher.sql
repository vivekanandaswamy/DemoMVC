
BEGIN        


SET NOCOUNT ON;        

	DECLARE @Output VARCHAR(100) = ''

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL

	SET @Scope = ISNULL(@Scope, NULL)			

--IF	NOT EXISTS	(	SELECT 1
--					FROM	METER M
--					JOIN	TCD.MachineGroup GT
--						on		M.EcolabAccountNumber			=		GT.EcolabAccountNumber
--						AND		M.GroupId = GT.Id 
--					WHERE	M.EcolabAccountNumber			=		@EcolabAccountNumber
--						AND M.MachineCompartment = @FinnisherId 
--						AND GT.EcolabAccountNumber =@EcolabAccountNumber 
--						AND GT.GroupTypeId = 4 
--						AND M.Is_deleted = 0
--				)        
--				BEGIN        

	UPDATE TCD.Finnishers SET
			Is_Deleted = 'TRUE', 
			LastModifiedByUserId = @Userid, 
			LastModifiedTime = @Currentutctime
		WHERE EcolabAccountNumber = @Ecolabaccountnumber
		  AND FinnisherId = @Finnisherid
										
--				END        
--ELSE        
--				BEGIN        
--						SET		@OutPut	=	'501'        
--						SELECT	@Scope	=	@OutPut		SELECT @Scope        
--				END        


--set at-least the datetime output param to limit the impact in service layer
	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()
	--RETURN @Returnvalue
END