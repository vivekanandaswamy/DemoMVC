
BEGIN  
	SET NOCOUNT ON
	;WITH CTE
		AS (SELECT
FinnisherId,  
Name,  
FinnisherGroupId,  
FinnisherTypeId,
					FinnisherNo, 
					LastModifiedTime
				FROM TCD.Finnishers AS F
				WHERE F.IS_DELETED <> 1
				  AND EcolabAccountNumber = @Ecolabaccountnumber)
		SELECT
				G.Id, 
				F.FinnisherId, 
				F.Name, 
				G.GroupDescription, 
				G.EcolabAccountNumber, 
				FT.FinnisherTypeId, 
				F.FinnisherNo, 
				FT.Name AS FinnisherTypeName, 
				G.LastModifiedTime AS FinisherGroupLastModifiedTime, 
				F.LastModifiedTime AS FinisherLastModifiedTime, 
				G.Is_Deleted AS IsDeleted
			FROM TCD.MachineGroup AS G
				 LEFT OUTER JOIN CTE AS F ON G.Id = F.FinnisherGROUPID
				 LEFT JOIN TCD.FinnisherType AS FT ON FT.FinnisherTypeId = F.FinnisherTypeId
			WHERE G.EcolabAccountNumber = @Ecolabaccountnumber
--AND G.IS_DELETED <> 1  
AND G.GroupTypeId = 4
			ORDER BY
				G.Id DESC

END