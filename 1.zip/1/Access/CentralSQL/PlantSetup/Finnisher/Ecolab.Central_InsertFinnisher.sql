
BEGIN    
    
SET NOCOUNT ON   
 
	DECLARE @Output VARCHAR(100) = ''

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Finisherid INT = NULL


	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.Finnishers AS F
					  WHERE F.EcolabAccountNumber = @Ecolabaccountnumber
						AND F.FinnisherNo = @Finnisherno
						AND Is_Deleted = 'FALSE')
				BEGIN    
			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.Finnishers AS F
							  WHERE F.EcolabAccountNumber = @Ecolabaccountnumber
								AND F.Name = @Name
								AND Is_Deleted = 'FALSE')
										BEGIN
												
														--Generate new Id for the Finsher being created
					SET @Finisherid = (SELECT
											   ISNULL(MAX(F.FinnisherId), 0) + 1
										   FROM TCD.Finnishers AS F
										   WHERE F.EcolabAccountNumber = @Ecolabaccountnumber)

					INSERT INTO TCD.Finnishers(
							FinnisherId, 
							EcolabAccountNumber, 
							FinnisherGroupId, 
							Name, 
							FinnisherNo, 
							FinnisherTypeId, 
							LastModifiedByUserId, 
							LastModifiedTime)
						VALUES
							   (
								@Finisherid, 
								@Ecolabaccountnumber, 
								@Finnishergroupid, 
								@Name, 
								@Finnisherno, 
								@Finnishertypeid, 
								@Userid, 
								@Currentutctime)

					SET @Output = '101'
					SET @Scope = @Output
					SELECT
							@Scope
												
				END 
ELSE    
				BEGIN
					SET @Output = '301'
					SET @Scope = @Output
					SELECT
							@Scope
				END

	END
ELSE
	BEGIN
			SET @Output = '302'
			IF EXISTS(SELECT
							  1 FROM TCD.Finnishers WHERE Name = @Name
													  AND IS_DELETED = 0)
				BEGIN
					SET @Output = '303'
				END
			SET @Scope = @Output
			SELECT
					@Scope
				END
--set at-least the datetime output param to limit the impact in service layer
	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()
	--RETURN @Returnvalue


END