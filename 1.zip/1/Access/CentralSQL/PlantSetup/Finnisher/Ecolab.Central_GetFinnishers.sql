
BEGIN
	SET NOCOUNT ON;

	SELECT
			f.FinnisherGroupId, 
			f.FinnisherId, 
			f.FinnisherNo, 
			f.Name, 
			f.LastModifiedTime, 
			f.EcolabAccountNumber, 
			f.FinnisherTypeId, 
			f.Is_deleted, 
			GT.GroupDescription
		FROM TCD.Finnishers AS f
			 INNER JOIN TCD.MachineGroup AS gt ON f.FinnisherGroupId = gt.Id
		WHERE gt.GroupTypeId = 4
END