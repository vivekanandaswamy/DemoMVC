
BEGIN


	SET NOCOUNT ON

	DECLARE @Output VARCHAR(100) = ''

	DECLARE @Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Finishergroupid INT = NULL



	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.MachineGroup
					  WHERE GroupDescription = @Groupdescription
						AND GroupTypeId = 4
						AND EcolabAccountNumber = @Ecolabaccountnumber
						AND IS_DELETED <> 1)
		BEGIN	 
			--Generate new Id for the group being created
			SET @Finishergroupid = (SELECT
											ISNULL(MAX(GT.Id), 0) + 1
										FROM TCD.MachineGroup AS GT
										WHERE GT.EcolabAccountNumber = @Ecolabaccountnumber)

			INSERT INTO TCD.MachineGroup(
					Id, 
					GroupDescription, 
					EcolabAccountNumber, 
					GroupTypeId, 
					LastModifiedByUserId, 
					LastModifiedTime)
				VALUES
					   (
						@Finishergroupid, 
						@Groupdescription, 
						@Ecolabaccountnumber, 
						4, 
						@Userid, 
						@Currentutctime)

			SET @Output = '101'
			SET @Scope = @Output
			SELECT
					@Scope
		END
	ELSE
		BEGIN
			SET @Output = '301'
			SET @Scope = @Output
			SELECT
					@Scope
		END	   


	--set at-least the datetime output param to limit the impact in service layer
	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()


	--RETURN @Returnvalue


END
