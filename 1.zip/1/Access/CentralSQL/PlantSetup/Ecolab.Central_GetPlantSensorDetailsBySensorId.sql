
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT
			S.SensorId AS SensorId, 
			S.Description AS Description, 
			S.SensorType AS SensorType, 
			S.GroupId AS GroupId, 
			S.MachineCompartment AS MachineCompartment, 
			S.EcolabAccountNumber AS EcolabAccountNumber, 
			S.ControllerID AS ControllerID, 
			S.OutputType AS OutputType, 
			S.Calibration4mA AS Calibration4mA, 
			S.AnalogueInputNumber AS AnalogueInputNumber, 
			S.ChemicalforChart AS ChemicalforChart, 
			S.UOM AS UOM, 
			S.DashboardActualValue AS DashboardActualValue, 
			S.Is_deleted AS Is_deleted, 
			S.Id AS Id, 
			S.LastModifiedByUserId AS LastModifiedByUserId, 
			S.IsPlant AS IsPlant, 
			S.IsPress AS IsPress, 
			S.Calibration20mA AS Calibration20mA, 
			S.LastSyncTime AS LastSyncTime, 
			S.LastModifiedTime AS LastModifiedTime,
			s.SensorNum,
			s.AlarmEnable,
			s.MinimumAlarmValue,
			s.MaximumAlarmValue,
			s.AnalogueInputNumber,
			CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel
		FROM TCD.Sensor AS S
		LEFT JOIN TCD.ControllerSetupData csd 
		ON csd.ControllerId = S.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = S.EcolabAccountNumber
		WHERE S.SensorId = ISNULL(@Sensorid, S.SensorId)
		  AND S.EcolabAccountNumber = @Ecolabaccountnumber

END
