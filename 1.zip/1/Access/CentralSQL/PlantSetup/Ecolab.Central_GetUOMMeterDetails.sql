
	BEGIN 
	SET NOCOUNT ON;

	DECLARE @Name VARCHAR(100) = '', 
			@Usagekey VARCHAR(100) = NULL
	IF @Utilitytype = 12
		BEGIN
			SET @Name = 'pieces'
		END

	SELECT
			@Name = Name FROM TCD.utilitymaster WHERE ResourceID = @Utilitytype

	SET @Usagekey = CASE
				WHEN @Name LIKE 'Gas' THEN 'Gas_TCD'
				WHEN @Name LIKE 'Water' THEN 'Volume_TCD'
				WHEN @Name LIKE 'Oil' THEN 'Volume_TCD'
				WHEN @Name LIKE 'pieces' THEN 'Count_TCD'
				WHEN @Name LIKE '%Electric%' THEN 'Electricity_TCD'
				WHEN @Name LIKE 'Counter' THEN 'Count_TCD'
				WHEN @Name LIKE 'Level' THEN 'Count_TCD'
				WHEN @Name LIKE 'Time' THEN 'Time_TCD'
				WHEN @Name LIKE 'Temperature' THEN 'Temparature_TCD'
				WHEN @Name LIKE 'Hardness' THEN 'Hardness_TCD'
				WHEN @Name LIKE 'Flow%' THEN 'VolumeRate_TCD'
				WHEN @Name LIKE 'Steam%' THEN 'Steam_TCD'
				--WHEN @Name = 'Totalizer' THEN ''
		 END

	   SELECT
			ddu.Unit, 
            ddu.Subunit
		FROM TCD.DimensionalDisplayUnits AS ddu
			 INNER JOIN TCD.DimensionalUsageKey AS duk ON duk.DisplayUnitID = ddu.DisplayUnitID
		WHERE duk.UsageKey = @Usagekey
		ORDER BY ddu.Unit, ddu.OrderID;
	SET NOCOUNT OFF;
  END
