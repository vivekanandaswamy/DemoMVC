
BEGIN
	SET NOCOUNT ON;

	DECLARE @Output VARCHAR(100) = '', 
			@Returnvalue INT = 0, 
			@Errorid INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Newplantcustomeridtobeinserted INT
	DECLARE @Outputlist AS TABLE(
			PlantCustomerId INT, 
			LastModifiedTimestamp DATETIME)

	SET @Scope = ISNULL(@Scope, NULL)
	SET @Outputplantcustomerid = ISNULL(@Outputplantcustomerid, NULL)


	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.PlantCustomer
					  WHERE Id = @Id
						AND EcolabAccountNumber = @Ecolabaccountnumber)
		BEGIN
			IF EXISTS(SELECT
							  1
						  FROM TCD.PlantCustomer
						  WHERE CustomerId = @Customer_Id AND Is_Deleted = 0
							AND EcolabAccountNumber = @Ecolabaccountnumber)
				BEGIN
					SET @Output = '301'
					SET @Scope = @Output
					SELECT
							@Scope
				END
			ELSE
				BEGIN
					IF EXISTS(SELECT
									  1
								  FROM TCD.PlantCustomer
								  WHERE CustomerId = @Customer_Id
									AND Is_Deleted = 1
									AND EcolabAccountNumber = @Ecolabaccountnumber)
						BEGIN 
							--UPDATE
							--Proceed to update, since it's a disconnected scenario	

							UPDATE P SET
									P.CustomerName = @Customer_Name, 
									P.CustomerId = @Customer_Id, 
									P.LastModifiedByUserId = @Userid, 
									P.LastModifiedTime = @Currentutctime, 
									P.Is_Deleted = 0
							OUTPUT
									inserted.ID AS Id, 
									inserted.LastModifiedTime AS LastModifiedTimestamp
								   INTO @Outputlist(
									PlantCustomerId, 
									LastModifiedTimestamp)
								FROM TCD.PlantCustomer P
								WHERE
									CustomerId = @Customer_Id
								AND EcolabAccountNumber = @Ecolabaccountnumber
						END
					ELSE
						BEGIN
							--INSERT here
							--Generate id using Max

							SET @Newplantcustomeridtobeinserted = (SELECT
																		   ISNULL(MAX(PC.ID), 0) + 1
																	   FROM TCD.PlantCustomer AS PC
																	   WHERE PC.EcolabAccountNumber = @Ecolabaccountnumber)
							--INSERT

							INSERT INTO TCD.PlantCustomer(
									Id, 
									CustomerId, 
									CustomerName, 
									EcolabAccountNumber, 
									LastModifiedByUserId)
							OUTPUT
									inserted.ID AS Id, 
									inserted.LastModifiedTime AS LastModifiedTimestamp
								   INTO @Outputlist(
									PlantCustomerId, 
									LastModifiedTimestamp)
								VALUES
									   (
										@Newplantcustomeridtobeinserted, 
										@Customer_Id, 
										@Customer_Name, 
										@Ecolabaccountnumber, 
										@Userid)
						END
				END
		END
	ELSE
		BEGIN

			IF EXISTS(SELECT
							  1
						  FROM TCD.PlantCustomer
						  WHERE CustomerId = @Customer_Id
							AND Is_Deleted = 0
							AND EcolabAccountNumber = @Ecolabaccountnumber
							AND Id <> @Id)
				BEGIN
					SET @Output = '301'
					SET @Scope = @Output
					SELECT
							@Scope
				END
			ELSE
				BEGIN

					UPDATE P SET
							P.CustomerName = @Customer_Name, 
							P.CustomerId = @Customer_Id, 
							P.LastModifiedByUserId = @Userid, 
							P.LastModifiedTime = @Currentutctime
					OUTPUT
							inserted.ID AS Id, 
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							PlantCustomerId, 
							LastModifiedTimestamp)
						FROM TCD.PlantCustomer P
						WHERE
							Id = @Id
						AND EcolabAccountNumber = @Ecolabaccountnumber

				END
		END
	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputplantcustomerid = O.PlantCustomerId
		FROM @Outputlist AS O


	--RETURN @Returnvalue
  
--SET NOCOUNT OFF; 
END	 

  /* TEST CASES 
	  
  SELECT * FROM AUDITCOLUMNS

  SELECT * FROM AUDITCOLUMNSDETAILS_NEW

  SELECT * FROM PLANTCUSTOMER ORDER BY ID

  [dbo].[usp_savePlantcustomer] NULL,555,'PREMCHAND',1,NULL

  DELETE FROM PLANTCUSTOMER WHERE CUSTOMERID = 555

  */

  /* TEST CASES 
	  
  SELECT * FROM AUDITCOLUMNS

  SELECT * FROM AUDITCOLUMNSDETAILS_NEW

  SELECT * FROM PLANTCUSTOMER ORDER BY ID

  [dbo].[usp_savePlantcustomer] NULL,555,'PREMCHAND',1,NULL

  DELETE FROM PLANTCUSTOMER WHERE CUSTOMERID = 555

  */