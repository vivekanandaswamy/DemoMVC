
BEGIN

	SET NOCOUNT ON;

	DECLARE @Sqlquery AS NVARCHAR(500);

	DECLARE @Parmdefinition NVARCHAR(500);

	IF @Tablename = 'TCD.ConduitController'
		BEGIN
			SET @Sqlquery = 'SELECT count(*) FROM ' + @Tablename + ' WHERE ControllerId!=0 AND EcoalabAccountNumber =CAST(''' + @Ecolabaccountnumber + ''' AS NVARCHAR(1000))';
		END
	ELSE
		BEGIN
			IF @Tablename = 'TCD.TankSetup'
				BEGIN
					SET @Sqlquery = 'SELECT count(*) FROM ' + @Tablename + ' WHERE EcoalabAccountNumber =CAST(''' + @Ecolabaccountnumber + ''' AS NVARCHAR(1000))';
				END
			ELSE
				BEGIN
					SET @Sqlquery = 'SELECT count(*) FROM ' + @Tablename + ' WHERE EcolabAccountNumber =CAST(''' + @Ecolabaccountnumber + ''' AS NVARCHAR(1000))';
				END
		END
	BEGIN
		SET @Sqlquery = @Sqlquery
	END


	SET @Parmdefinition = N'@EcolabAccountNumber NVARCHAR(1000)';
	EXECUTE sp_executesql @Sqlquery, @Parmdefinition, @Ecolabaccountnumber;


END