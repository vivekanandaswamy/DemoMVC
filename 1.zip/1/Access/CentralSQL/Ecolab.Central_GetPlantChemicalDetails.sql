
BEGIN
	SET NOCOUNT ON;

	DECLARE @Regionid INT = NULL
	DECLARE @Is_Deleted BIT = 'FALSE'

	SELECT
			@Regionid = regionid
		FROM TCD.plant
		WHERE ecolabaccountnumber = @Ecolabaccountnumber

	SELECT
			PD.ID, 
			PD.ProductID, 
			PM.sku, 
			PM.NAME, 
			CASE
				WHEN pm.sku IN(SELECT
									   sku
								   FROM TCD.productdatamapping AS M
								   WHERE M.sku = PM.sku
									 AND ecolabaccountnumber = @Ecolabaccountnumber
									 AND (M.is_deleted = 'False'
									   OR M.is_deleted = @Is_Deleted))THEN(SELECT TOP 1
																				   M.cost
																			   FROM TCD.productdatamapping AS M
																			   WHERE M.sku = PM.sku
																				 AND ecolabaccountnumber = @Ecolabaccountnumber
																				 AND (M.is_deleted = 'False'
																				   OR M.is_deleted = @Is_Deleted)
																			   ORDER BY
																				   lastmodifiedtime DESC)
				ELSE PM.cost
			END AS Cost, 
			PM.densityfactor, 
			PM.accepteddeviation, 
			PM.productcategoryid, 
			PM.type, 
			PM.supplier, 
			PD.includeci, 
			PM.packagingsize, 
			PM.weight, 
			PM.volume, 
			pc.NAME AS ProductCategoryName, 
			PD.ecolabaccountnumber, 
			PD.lastmodifiedtime, 
			PD.lastsynctime, 
			PM.MyServiceProdId, 
			PD.InventoryExpense, 
			PS.UnitPerPackage, 
			PS.UnitWeightVolume, 
			PS.PackageSizeWeightUOMCode, 
			PD.is_deleted
		FROM TCD.productmaster AS PM
			 INNER JOIN TCD.productdatamapping AS PD ON PM.productid = PD.productid
			 LEFT JOIN TCD.productcategory AS pc ON PM.productcategoryid = PC.categoryid
			 LEFT JOIN TCD.PackageSize AS PS ON PM.PackageSizeId = PS.packagesizeid
		WHERE PD.ecolabaccountnumber = @Ecolabaccountnumber
		  AND PM.regionid = @Regionid
		  AND (PD.is_deleted = 'False'
			OR PD.is_deleted = @Is_Deleted)
		  AND PD.SKU NOT IN('0', '-1')
	SET NOCOUNT OFF;
END