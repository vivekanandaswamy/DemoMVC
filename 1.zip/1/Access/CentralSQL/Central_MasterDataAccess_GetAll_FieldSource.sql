﻿/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
BEGIN
	SET NOCOUNT ON
	BEGIN
		SELECT
				DataSourceId, 
				Name, 
				[Value] FROM TCD.FieldSource
	END
END