
  BEGIN 
      SET NOCOUNT ON; 

      SELECT 
			ID, 
			CustomerId, 
			CustomerName, 
			IS_Deleted, 
			EcolabAccountNumber, 
			LastModifiedTime
		FROM TCD.PlantCustomer
		WHERE Is_Deleted = 0
		  AND EcolabAccountNumber = @Ecolabaccountnumber
  
  SET NOCOUNT OFF;
  END