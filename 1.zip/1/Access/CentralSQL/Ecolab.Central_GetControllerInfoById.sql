/*
	History-
	Feb. 2016		sidrameshwar@allianceglobalservice.com		Created a prepared statement
	*/
BEGIN
	SET NOCOUNT ON;

	DECLARE @Controllermodelid INT = (SELECT
											  ControllerModelId
										  FROM TCD.ConduitController
										  WHERE ControllerId = @Controllerid
											AND EcoalabAccountNumber = ISNULL(@Ecolabaccountnumber, EcoalabAccountNumber));

	DECLARE @Controllertypeid INT = (SELECT
											 ControllerTypeId
										 FROM TCD.ConduitController
										 WHERE ControllerId = @Controllerid
										   AND EcoalabAccountNumber = ISNULL(@Ecolabaccountnumber, EcoalabAccountNumber));
	DECLARE @Fieldid INT = NULL;

	IF @Controllertypeid = 1
		BEGIN
			 SELECT
					CC.ControllerId, 
					CC.TopicName, 
					CC.ControllerTypeId, 
					CT.Name AS ControllerType, 
					CC.ControllerModelId, 
					CM.Name AS ControllerModel, 
					CSD.Value
				FROM TCD.ConduitController AS CC
					 INNER JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
					 INNER JOIN TCD.ControllerModel AS CM ON CM.Id = CC.ControllerModelId
					 LEFT JOIN TCD.ControllerSetupData AS CSD ON CC.ControllerId = CSD.ControllerId
				WHERE CC.ControllerId = @Controllerid
				  AND CSD.FieldId = 11
				  AND CC.EcoalabAccountNumber = ISNULL(@Ecolabaccountnumber, EcoalabAccountNumber);

		END;
	ELSE
		BEGIN
			IF @Controllertypeid = 2
				BEGIN
					SELECT
							CC.ControllerId, 
							CC.TopicName, 
 
 
 
							CC.ControllerTypeId, 
							CT.Name AS ControllerType, 
 
 
 
 
 
							CC.ControllerModelId, 
							CM.Name AS ControllerModel, 
							CSD.Value
						FROM TCD.ConduitController AS CC
							 INNER JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
							 INNER JOIN TCD.ControllerModel AS CM ON CM.Id = CC.ControllerModelId
							 LEFT JOIN TCD.ControllerSetupData AS CSD ON CC.ControllerId = CSD.ControllerId
						WHERE CC.ControllerId = @Controllerid
						  AND CSD.FieldId = 21
						  AND EcoalabAccountNumber = ISNULL(@Ecolabaccountnumber, EcoalabAccountNumber);

				END;
		END

	IF @Controllermodelid = 7
		BEGIN
			IF @Controllertypeid = 2
				BEGIN
					SET @Fieldid = 150
				END;
		END
	ELSE
		BEGIN
			IF @Controllermodelid = 8
				BEGIN
					IF @Controllertypeid = 6
						BEGIN
							SET @Fieldid = 387
						END;
					ELSE
						BEGIN
							IF @Controllertypeid = 7
								BEGIN
									SET @Fieldid = 400
								END;
						END
				END
			ELSE
				BEGIN
					IF @Controllermodelid = 9
						BEGIN
							IF @Controllertypeid = 8
								BEGIN
									SET @Fieldid = 414
								END;
							ELSE
								BEGIN
									IF @Controllertypeid = 10
										BEGIN
											SET @Fieldid = 426
										END;
								END
						END
					ELSE
						BEGIN
							IF @Controllermodelid = 10
								BEGIN
									IF @Controllertypeid = 6
										BEGIN
											SET @Fieldid = 460
										END;
								END
							ELSE
								BEGIN
									IF @Controllermodelid = 11
										BEGIN
											IF @Controllertypeid = 12
												BEGIN
													SET @Fieldid = 348
												END;
											ELSE
												BEGIN
													IF @Controllertypeid = 13
														BEGIN
															SET @Fieldid = 309
														END;
													ELSE
														BEGIN
															IF @Controllertypeid = 14
																BEGIN
																	SET @Fieldid = 269
																END;
														END
												END
										END
									ELSE
										BEGIN
											IF @Controllermodelid = 14
												BEGIN
													IF @Controllertypeid = 9
														BEGIN
															SET @Fieldid = 438
														END;
													ELSE
														BEGIN
															IF @Controllertypeid = 11
																BEGIN
																	SET @Fieldid = 449
																END;
														END
												END
										END
								END
						END
				END
		END

	SELECT
			CC.ControllerId, 
			CC.TopicName, 
			CC.ControllerTypeId, 
			CT.NAME AS ControllerType, 
			CC.ControllerModelId, 
			CM.NAME AS ControllerModel, 
			CSD.Value AS OpcServer
		FROM TCD.ConduitController AS CC
			 INNER JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
			 INNER JOIN TCD.ControllerModel AS CM ON CM.Id = CC.ControllerModelId
			 LEFT JOIN TCD.ControllerSetupData AS CSD ON CC.ControllerId = CSD.ControllerId
		WHERE CC.ControllerId = @Controllerid
		  AND CSD.FieldId = @Fieldid
		  AND EcoalabAccountNumber = ISNULL(@Ecolabaccountnumber, EcoalabAccountNumber);

	SET NOCOUNT OFF;
END;