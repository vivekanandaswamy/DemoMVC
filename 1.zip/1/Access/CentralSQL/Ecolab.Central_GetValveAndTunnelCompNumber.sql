﻿DECLARE @ControllerId int 
SET @ControllerId = (SELECT ces.ControllerId FROM tcd.ControllerEquipmentSetup ces WHERE ces.ControllerEquipmentSetupId = @ControllerEquipmentSetUpId AND ces.WasherGroupNumber = @WasherGroupNumber AND ces.EcoLabAccountNumber = @EcolabAccNumber)
SET @ControllerEquipmentTypeId = (SELECT ces.ControllerEquipmentTypeId FROM tcd.ControllerEquipmentSetup ces WHERE ces.ControllerEquipmentSetupId = @ControllerEquipmentSetUpId AND ces.EcoLabAccountNumber = @EcolabAccNumber )

SELECT 
    TCEVM.valveNumber,
    TCEVM.CompartmentNumber,
	TCEVM.ControllerEquipmentSetupID,
	@ControllerEquipmentTypeId
    FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
    WHERE TCEVM.ControllerEquipmentSetUpId IN ( SELECT ces.ControllerEquipmentSetupId FROM tcd.ControllerEquipmentSetup ces WHERE ces.ControllerId = @ControllerId AND ces.WasherGroupNumber = @WasherGroupNumber AND ces.ControllerEquipmentTypeId = @ControllerEquipmentTypeId AND ces.EcoLabAccountNumber = @EcolabAccNumber)
    AND TCEVM.EcolabAccountNumber = @EcolabAccNumber;