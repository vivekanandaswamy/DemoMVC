
BEGIN
    SET NOCOUNT ON;

    BEGIN

        DECLARE
           @Output varchar( 100
                          ) = '' , 
           @ReturnValue int = 0 , 
           @ErrorId int = 0 , 
           @ErrorMessage nvarchar( 4000
                                 ) = N'' , 
           @CurrentUTCTime datetime = GETUTCDATE(
                                                ) , 
           @NewStandardPriceId int = 0,
			@PlantId INT

	   SELECT @PlantId = p.PlantId FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber

        DECLARE
           @OutputList AS TABLE(
                StandardPriceId int , 
                LastModifiedTimestamp datetime
                               );

        SET @OutputLastModifiedTimestampAtLocal = ISNULL( @OutputLastModifiedTimestampAtLocal , NULL
                                                        );			--SQLEnlight
        SET @OutputStandardPriceId = ISNULL( @OutputStandardPriceId , NULL
                                           );								--SQLEnlight


        IF EXISTS( SELECT
                           1
                     FROM TCD.ProductStandardPrice
                     WHERE ProductID = @ProductId
                       AND EcolabAccountNumber = @EcolabAccountNumber
                 )
            BEGIN


                UPDATE TCD.ProductStandardPrice SET
                        ListPrice = @ListPrice , 
                        ContractPrice = @ContractPrice , 
                        CountryPrice = @CountryPrice , 
                        LastModifiedByUserId = @UserID , 
                        LastModifiedTime = @CurrentUTCTime,
						PlantId = @PlantId
                OUTPUT
                        inserted.Id AS StandardPriceId , 
                        inserted.LastModifiedTime AS LastModifiedTimestamp
                       INTO @OutputList(
                        StandardPriceId , 
                        LastModifiedTimestamp
                                       )
                  WHERE
                        ProductID = @ProductId
                    AND EcolabAccountNumber = @EcolabAccountNumber;
            END;
        ELSE
            BEGIN
                IF NOT EXISTS( SELECT
                                       1
                                 FROM TCD.ProductStandardPrice
                                 WHERE ProductID = @ProductId
                                   AND EcolabAccountNumber = @EcolabAccountNumber
                             )
                    BEGIN

                        SELECT
                                @NewStandardPriceId = ISNULL(Max( Id) , 0
                                                            ) + 1
                          FROM TCD.ProductStandardPrice
                          WHERE EcolabAccountNumber = @EcolabAccountNumber;

                        INSERT INTO TCD.ProductStandardPrice(
                                Id , 
                                EcolabAccountNumber , 
                                ProductId , 
                                ListPrice , 
                                ContractPrice , 
                                CountryPrice , 
                                LastModifiedByUserId,
								PlantId
                                                            )
                        OUTPUT
                                inserted.Id AS StandardPriceId , 
                                inserted.LastModifiedTime AS LastModifiedTimestamp
                               INTO @OutputList(
                                StandardPriceId , 
                                LastModifiedTimestamp
                                               )
                        VALUES( @NewStandardPriceId , 
                                @EcolabAccountNumber , 
                                @ProductId , 
                                @ListPrice , 
                                @ContractPrice , 
                                @CountryPrice , 
                                @UserID,
								@PlantId
                              );

                    END;
            END;

        SELECT TOP 1
                @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp , 
                @OutputStandardPriceId = O.StandardPriceId
          FROM @OutputList O;


       -- RETURN @ReturnValue;

    --SET NOCOUNT OFF;
    END;
END;