
BEGIN
	IF NOT EXISTS(SELECT
						  1 FROM TCD.ResourceKeyMaster WHERE KeyName = @Key)
		BEGIN
			INSERT INTO TCD.ResourceKeyMaster(
					KeyName)
				VALUES
					   (
						@Key)
		END

	IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue rkv WHERE rkv.KeyName = @Key AND rkv.languageID = 1)
		BEGIN
			INSERT INTO TCD.ResourceKeyValue(
					KeyName, 
					Value, 
					languageID)
				VALUES
					   (
						@Key, 
						@English, 
						1)
		END

			IF @Spanish IS NOT NULL
				BEGIN
				IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue rkv WHERE rkv.KeyName = @Key AND rkv.languageID = 3)
				BEGIN
					INSERT INTO TCD.ResourceKeyValue(
							KeyName, 
							Value, 
							languageID)
						VALUES
							   (
								@Key, 
								@Spanish, 
								3)
				END
				END

			IF @Norweign IS NOT NULL
				BEGIN
				IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue rkv WHERE rkv.KeyName = @Key AND rkv.languageID = 13)
				BEGIN
					INSERT INTO TCD.ResourceKeyValue(
							KeyName, 
							Value, 
							languageID)
						VALUES
							   (
								@Key, 
								@Norweign, 
								13)
				END
				END

			IF @Dutch IS NOT NULL
				BEGIN
				IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue rkv WHERE rkv.KeyName = @Key AND rkv.languageID = 2)
				BEGIN
					INSERT INTO TCD.ResourceKeyValue(
							KeyName, 
							Value, 
							languageID)
						VALUES
							   (
								@Key, 
								@Dutch, 
								2)
				END
				END
END