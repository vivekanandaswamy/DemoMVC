/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
BEGIN
	SET NOCOUNT ON
	BEGIN
		SELECT
				Roleid, 
				RoleName, 
				Code FROM TCD.UserRoles
	END
END