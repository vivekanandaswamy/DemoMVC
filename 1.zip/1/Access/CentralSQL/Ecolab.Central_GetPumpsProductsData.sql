SELECT cpm.Id,
cpm.ControllerId,
cpm.ChemicalNumber,
cpm.ProductId,
pm.Name,
cpm.LowLevelAlarm,
cpm.WeightControlledDosage
FROM TCD.ControllerProductMapping cpm
INNER JOIN tcd.ProductMaster pm ON pm.ProductID = cpm.ProductId
WHERE cpm.ControllerId = @ControllerId
AND cpm.EcolabAccountNumber = @EcolabAccountNumber