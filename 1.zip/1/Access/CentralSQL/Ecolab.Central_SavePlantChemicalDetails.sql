
BEGIN
SET NOCOUNT ON
	DECLARE --@Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Newidtobeinserted INT = NULL, 
			@Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL
  
	DECLARE @Outputlist AS TABLE(
			PlantChemicalId INT, 
			LastModifiedTimestamp DATETIME)
	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)
	SET @Outputchemicalid = ISNULL(@Outputchemicalid, NULL)
	

	IF EXISTS(SELECT
					  1
				  FROM TCD.ProductdataMapping
				  WHERE ProductID = @Productid
					AND EcolabAccountNumber = @Ecolabaccountnumber)
		BEGIN
			UPDATE TCD.ProductdataMapping SET
					Cost = @Cost, 
					IncludeCI = @Includeci, 
					InventoryExpense = @Inventoryexpense, 
					LastModifiedByUserId = @Userid, 
					Is_Deleted = @Isdeleted, 
					LastModifiedTime = @Currentutctime
							OUTPUT
					inserted.ID AS Id, 
					inserted.LastModifiedTime AS LastModifiedTimestamp
				   INTO @Outputlist(
					PlantChemicalId, 
					LastModifiedTimestamp)
							WHERE 
					ProductID = @Productid
				AND EcolabAccountNumber = @Ecolabaccountnumber
		END
	ELSE
		BEGIN
			IF NOT EXISTS(SELECT
								  1
							  FROM TCD.ProductdataMapping
							  WHERE ProductID = @Productid
								AND Is_Deleted = 0
								AND EcolabAccountNumber = @Ecolabaccountnumber)
		BEGIN
			
			--INSERT here
				--Generate id using Max
							
					SET @Newidtobeinserted = (SELECT
													  ISNULL(MAX(PDM.ID), 0) + 1
												  FROM TCD.ProductdataMapping AS PDM
												  WHERE PDM.EcolabAccountNumber = @Ecolabaccountnumber)
					INSERT INTO TCD.ProductdataMapping(
							Id, 
							ProductID, 
							SKU, 
							Cost, 
							IncludeCI, 
							InventoryExpense, 
							EcolabAccountNumber, 
							LastModifiedByUserId, 
							Is_Deleted)
			OUTPUT
							inserted.ID AS Id, 
							inserted.LastModifiedTime AS LastModifiedTimestamp
						   INTO @Outputlist(
							PlantChemicalId, 
							LastModifiedTimestamp)
						SELECT
								@Newidtobeinserted, 
								ProductId, 
								SKU, 
								@Cost, 
								@Includeci, 
								@Inventoryexpense, 
								@Ecolabaccountnumber, 
								@Userid, 
								@Isdeleted
						FROM TCD.ProductMaster
						WHERE ProductId = @Productid
			

		END
		END

	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputchemicalid = O.PlantChemicalId
		FROM @Outputlist AS O

	--RETURN @Returnvalue

--SET NOCOUNT OFF;
END