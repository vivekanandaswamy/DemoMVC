
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @Regionid INT = NULL, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Packagesizeid INT = NULL

	DECLARE @SourceSystemId  INT 
	
	
	DECLARE @Outputlist AS TABLE(
			ProductId INT)

	SET @SourceSystemId = (SELECT 
									ss.Id 
								FROM TCD.SourceSystem ss 
								WHERE ss.Code = @SourceSystemCode)

	SELECT
			@Regionid = RegionId
		FROM TCD.RegionMaster
		WHERE MyServiceRegionCode = @Regioncode

	SELECT
			@Packagesizeid = ps.PackageSizeId
		FROM TCD.PackageSize AS ps
		WHERE ps.MyServicePkgSzId = @Myservicepackagesizeid

	IF NOT EXISTS(SELECT
						  1 FROM TCD.ProductMaster WHERE MyServiceProdId = @Myserviceprodid)
	BEGIN
			INSERT INTO TCD.ProductMaster(
					SKU, 
					Name, 
					Cost, 
					DensityFactor, 
					AcceptedDeviation, 
					--ProductCategoryId, 
					Type, 
					Supplier, 
					IncludeinCI, 
					PackagingSize, 
					Weight, 
					Volume, 
					Is_Deleted, 
					--ProductcategoryName, 
					RegionId, 
					Country, 
					MyServiceProdId, 
					MyServiceLastSynchTime, 
					PackageSizeId,
					SourceSystemId)
		   OUTPUT
					inserted.ProductId AS ProductId
				   INTO @Outputlist(
					ProductId)
		SELECT
						@Sku, 
						@Name, 
						@Cost, 
						@Densityfactor, 
						@Accepteddeviation, 
						--@Productcategoryid, 
						@Type, 
						@Supplier, 
						@Includeinci, 
						@Packagingsize, 
						@Weight, 
						@Volume, 
						@Isdelete, 
						--@Productcategoryname, 
						@Regionid, 
						@Country, 
						@Myserviceprodid, 
						@Currentutctime, 
						@Packagesizeid,
						@SourceSystemId
	END
ELSE
	BEGIN
			UPDATE TCD.ProductMaster SET
					SKU = @Sku, 
					Name = @Name, 
					Cost = @Cost, 
					DensityFactor = @Densityfactor, 
					AcceptedDeviation = @Accepteddeviation, 
					--ProductCategoryId = @Productcategoryid, 
					Type = @Type, 
					Supplier = @Supplier, 
					IncludeinCI = @Includeinci, 
					PackagingSize = @Packagingsize, 
					Weight = @Weight, 
					Volume = @Volume, 
					Is_Deleted = @Isdelete, 
					--ProductcategoryName = @Productcategoryname, 
					RegionId = @Regionid, 
					Country = @Country, 
					MyServiceLastSynchTime = @Currentutctime, 
					PackageSizeId = @Packagesizeid,
					SourceSystemId = @SourceSystemId
		  OUTPUT
					inserted.ProductId AS ProductId
				   INTO @Outputlist(
					ProductId)
				WHERE MyServiceProdId = @Myserviceprodid
	END
	SELECT TOP 1
			@Outputproductid = O.ProductId FROM @Outputlist AS O
END

