
BEGIN
    SET NOCOUNT ON	
    DECLARE @Returnvalue INT = 0, 
            @Currentutctime DATETIME = GETUTCDATE()

    DECLARE @Errornumber INT = 0, 
            @Errormessage NVARCHAR(2048) = NULL, 
            @Errorseverity INT = NULL, 
            @Errorprocedure SYSNAME = NULL, 
            @Messagestring NVARCHAR(2500) = NULL,
			@Weight_Display DECIMAL = @Weight;

    IF NOT EXISTS(SELECT
                          1
                      FROM TCD.ProgramMaster AS PM
                      WHERE PM.EcolabAccountNumber = @Ecolabaccountnumber
                        AND PM.ProgramId = @Programid				--Service layer sends this as 0
    )
		BEGIN
            IF EXISTS(SELECT
                              1
                          FROM TCD.ProgramMaster AS PM
                          WHERE PM.EcolabAccountNumber = @Ecolabaccountnumber
                            AND PM.Name = @Name
                            AND Is_Deleted = 0)
					BEGIN
                    SET @Errormessage = '303 - Formula Name already exists.'
                    RAISERROR(@Errormessage, 16, 1)
						RETURN
					END 
		
				--Now, set the ProgramId based on last ProgramId for the Plant
            SELECT
                    @Programid = ISNULL(MAX(ProgramId), 0) + 1
                FROM TCD.ProgramMaster AS PM
                WHERE PM.EcolabAccountNumber = @Ecolabaccountnumber
		
				/*Insert record if program not exists */

            IF(@PlantChainId > 0)
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
				ProgramId,
				Name,
				Pieces,
				Rewash,
				[Weight],
				EcolabSaturationId,
				EcolabAccountNumber,
				FormulaSegmentId,
				PlantProgramId,
				CustomerId,
				LastModifiedByUserId,
				Weight_Display,
				LastModifiedTime
			 )
			 VALUES
			 (
			 @ProgramId,
			 @Name,
			 @Pieces,
			 @Rewash,
			 @Weight,
			 @EcolabSaturationId,
			 @EcolabAccountNumber,
			 @FormulaSegmentId,
			 @PlantProgramId,
			 @CustomerId,
			 @UserId,
			 @Weight_Display,
			 GETUTCDATE()
			 )

		  END
	   ELSE
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
			     ProgramId,
			     Name,
			     Pieces,
			     EcolabTextileCategoryId,
			     FormulaSegmentId,
			     Rewash,
			     [Weight],
			     EcolabSaturationId,
			     EcolabAccountNumber,
			     CustomerId,
			     LastModifiedByUserId,
			     Weight_Display,
				LastModifiedTime
			 )
			 VALUES
			 (
			      @ProgramId,
				 @Name,
				 @Pieces,
				 @FormulaCategoryId,
				 @FormulaSegmentId,
				 @Rewash,
				 @Weight,
				 @EcolabSaturationId,
				 @EcolabAccountNumber,
				 @CustomerId,
				 @UserID,
				 @Weight_Display,
				 GETUTCDATE()
			 )
		  END

		END
ELSE
		BEGIN
		
		/*Update record if program exists */

            IF EXISTS(SELECT
                              1
                          FROM TCD.ProgramMaster AS PM
                          WHERE PM.EcolabAccountNumber = @Ecolabaccountnumber
                            AND PM.Name = @Name
                            AND ProgramId != @Programid
                            AND Is_Deleted = 0)
						BEGIN
                    SET @Errormessage = '303 - Formula Name already exists.'
                    RAISERROR(@Errormessage, 16, 1)
								RETURN
						END

							--Proceed to update, since it's a disconnected scenario
            IF (@PlantChainId > 0)
				    BEGIN
				    UPDATE TCD.ProgramMaster
				    SET
				        Name = @Name, 
				        Pieces = @Pieces,
				        Rewash = @Rewash, 
				        [Weight] = @Weight,
				        PlantProgramId = @PlantProgramId,
					    FormulaSegmentId = @FormulaSegmentId,
					    EcolabSaturationId = @EcolabSaturationId,
				        CustomerId = @CustomerId, 
				        LastModifiedByUserId = @UserID, 
				        Weight_Display = @Weight_Display 
				    WHERE 
					   ProgramId  = @ProgramId 
					  AND 
					   EcolabAccountNumber  = @EcolabAccountNumber
				    END
				ELSE
				    BEGIN
					   UPDATE TCD.ProgramMaster
					   SET
					       Name = @Name,
					       Pieces = @Pieces, 
					       EcolabTextileCategoryId = @FormulaCategoryId, 
					       FormulaSegmentId = @FormulaSegmentId, 
					       Rewash = @Rewash, 
					       [Weight] = @Weight, 
					       EcolabSaturationId = @EcolabSaturationId, 
					       CustomerId = @CustomerId,
					       LastModifiedByUserId = @UserID, 
					       Weight_Display = @Weight 
					   WHERE 
						  ProgramId = @ProgramId
					   AND
						  EcolabAccountNumber = @EcolabAccountNumber
				    END

		END

				--Proceed to update, since it's either a local call or Synch. call with synch. time matching
				
				/* Updating the value of plant details */   

--set at-least the datetime output param to limit the impact in service layer
    SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()


    --RETURN @Returnvalue


  END 






