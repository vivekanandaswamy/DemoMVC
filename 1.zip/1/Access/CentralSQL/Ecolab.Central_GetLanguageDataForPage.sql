/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
BEGIN
	SET NOCOUNT ON
	SELECT DISTINCT
			KeyMaster.[keyName], 
			ValueMaster.value
		FROM TCD.ResourceKeyPageMapping AS KeyMaster
			 INNER JOIN TCD.ResourceKeyValue AS ValueMaster ON KeyMaster.KeyName = ValueMaster.KeyName
			 INNER JOIN TCD.Plant AS plant ON plant.LanguageId = ValueMaster.languageID
			 INNER JOIN TCD.PageMaster AS PG ON PG.PageId = KeyMaster.PageId
		WHERE Plant.EcolabAccountNumber = @Plantid
			AND PG.PageName = @Pagename
	SET NOCOUNT OFF
END