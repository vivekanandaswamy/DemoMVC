/*
History-
Feb. 2016		mrayalla@allianceglobalservice.com		created prepared statement
*/

BEGIN
    SET NOCOUNT ON

	DECLARE @Errormessage NVARCHAR(4000), 
			@Pumpvalvecount TINYINT, 
			@Mecount TINYINT, 
			@Controllerequipmenttypeid_Pumpvalve TINYINT, 
			@Controllerequipmenttypeid_Me TINYINT, 
			@Returnvalue INT = 0, 
			@Tagtypelfs VARCHAR(100) = 'Tag_NML', 
			@Tagtypekfactor VARCHAR(100) = 'Tag_PPOL', 
			@Tagtypecalibration VARCHAR(100) = 'Tag_OPSL',
			@Controllerequipmentid TINYINT = NULL
			,@ControllerModelId        INT  ,
			@ControllerTypeId INT
  SELECT @ControllerModelId = CC.ControllerModelId                    
  FROM TCD.ConduitController CC                    
  WHERE CC.ControllerId = @ControllerId AND EcoalabAccountNumber = @Ecolabaccountnumber
  SET @ControllerTypeId = (SELECT top 1 ControllerTypeid              
       FROM TCD.ConduitController CC              
       WHERE CC.ControllerId = @ControllerId AND EcoalabAccountNumber = @Ecolabaccountnumber);    
	CREATE TABLE #Equipment(
			ControllerEquipmentId INT IDENTITY(1, 1), 
			ControllerEquipmentTypeId TINYINT NOT NULL, 
			IsActive BIT NOT NULL
						 DEFAULT 'FALSE', 
			ProductId INT NULL, 
			ProductName NVARCHAR(255)NULL, 
			PumpCalibration DECIMAL(18, 3)NULL, 
			FlowMeterSwitchFlag BIT NULL, 
			FlowMeterCalibration INT NULL, 
			MaximumDosingTime SMALLINT NULL, 
			FlowSwitchTimeOut SMALLINT NULL, 
			ControllerEquipmentSetupId SMALLINT NULL, 
			LfsChemicalName NVARCHAR(200)NULL, 
			FlushTime        SMALLINT   NULL ,                   
			PumpingTime       SMALLINT   NULL ,                   
			PreFlushTime       SMALLINT   NULL ,                   
			NightFlushPauseTime      SMALLINT   NULL ,      
			NightFlushTime       SMALLINT   NULL  ,                  
			AcceptedDeviation      SMALLINT   NULL ,
			LineNumber    tinyint NULL DEFAULT 0 ,
			KFactor DECIMAL(18, 2)NULL, 
			TunnelHold BIT NULL, 
			FlowDetectorType INT NULL, 
			FlowSwitchAlarm BIT NULL, 
			FlowMeterAlarm BIT NULL, 
			FlowMeterType INT NULL, 
			FlowAlarmDelay DECIMAL(18, 2) NULL, 
			FlowMeterPumpDelay DECIMAL(18, 2) NULL, 
			FlowMeterAlarmDelay DECIMAL(18, 2) NULL, 
			LastModifiedTime DATETIME NULL, 
			LastSyncTime DATETIME NULL,
			ControllerEquipmentTypeModelID    INT    NULL,
			ConventionalWasherGroupConnection BIT,
			 DirectDosingFlag      BIT    NULL  DEFAULT   'FALSE' ,
			 DirectDosingMachineInternalId    INT    NULL,
			 DirectDosingTunnelCompartmentId   INT    NULL,
			WasherGroupTypeId     INT    NULL,
			NumberOfCompartments INT NULL,
			WasherGroupNumber INT NULL)


	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.ConduitController AS CC
					  WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
						AND CC.ControllerId = @Controllerid)
		BEGIN
			SET @Errormessage = 'Invalid Plant/Controller combination specified'
			RAISERROR(@Errormessage, 16, 1)
			SET @Returnvalue = -1
			--RETURN @Returnvalue
		END

	SELECT
			@Controllerequipmenttypeid_Pumpvalve = CASE
													   WHEN CET.ControllerEquipmentTypeName = 'Pump/Valve' THEN CET.ControllerEquipmentTypeId
													   ELSE @Controllerequipmenttypeid_Pumpvalve
												   END, 
			@Controllerequipmenttypeid_Me = CASE
												WHEN CET.ControllerEquipmentTypeName = 'ME' THEN CET.ControllerEquipmentTypeId
												ELSE @Controllerequipmenttypeid_Me
											END
		FROM TCD.ControllerEquipmentType AS CET
		WHERE CET.ControllerEquipmentTypeName IN('Pump/Valve', 'ME')

	 IF (@ControllerModelId <> 7 AND @ControllerModelId  <> 8 AND @ControllerModelId <> 9 AND @ControllerModelId <> 11        
    AND @ControllerModelId <> 10 AND @ControllerModelId <> 14)                  
    BEGIN                    
    SELECT @PumpValveCount = ISNULL(CSD.Value, 0)                    
      FROM TCD.ConduitController CC                    
       JOIN                    
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                    
       JOIN                    
       TCD.ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId                    
          AND CC.ControllerTypeId = CMCTM.ControllerTypeId                    
       JOIN                    
       TCD.FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId                    
        AND FG.ControllerTypeId = CC.ControllerTypeId                    
        AND FG.TabId = 3                    
       INNER JOIN                    
       TCD.FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id                    
       INNER JOIN              
       TCD.Field F ON F.Id = FGM.FieldId                    
      AND CSD.FieldId = f.Id                    
      WHERE CC.ControllerId = @ControllerId                    
    AND F.ResourceKey = 'No._of_Chemical_Valves'                    
    AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;                    
    SELECT @MECount = ISNULL(CMCTM.MECount, 0)                    
      FROM TCD.ConduitController CC                    
       JOIN                    
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                    
             AND CC.ControllerTypeId = CMCTM.ControllerTypeId                    
      WHERE CC.ControllerId = @ControllerId;                    
    END;           
    ELSE IF(@ControllerModelId = 11)                  
    BEGIN                  
    SELECT @PumpValveCount = CMCTM.PumpValveCount                  
     , @MECount = CMCTM.MECount                  
      FROM TCD.ControllerModelControllerTypeMapping CMCTM                  
      WHERE CMCTM.ControllerModelId = @ControllerModelId;                  
    END;                  
  ELSE IF(@ControllerModelId = 7 OR @ControllerModelId = 8 OR @ControllerModelId = 9 OR @ControllerModelId = 10  OR @ControllerModelId = 14)                  
  BEGIN                  
    SELECT @PumpValveCount = CMCTM.PumpValveCount                
 , @MECount = CMCTM.MECount              
  FROM TCD.ControllerModelControllerTypeMapping CMCTM              
  WHERE CMCTM.ControllerModelId = @ControllerModelId              
    AND CMCTM.ControllerTypeId = @ControllerTypeId;                  
    END;    
	--SELECT
	--		@Mecount = ISNULL(CMCTM.MECount, 0)
	--	FROM TCD.ConduitController AS CC
	--		 JOIN TCD.ControllerModelControllerTypeMapping AS CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
	--															   AND CC.ControllerTypeId = CMCTM.ControllerTypeId
	--	WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
	--	  AND CC.ControllerId = @Controllerid

	IF(SELECT
			   ISNULL(@Pumpvalvecount, 0) + ISNULL(@Mecount, 0)) = 0
		BEGIN
			--Return EMPTY result set
			SELECT	--*	--Change this
					T.ControllerEquipmentId AS ControllerEquipmentId, 
					T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId, 
					T.IsActive AS IsActive, 
					T.ProductId AS ProductId, 
					T.ProductName AS ProductName, 
					T.PumpCalibration AS PumpCalibration, 
					T.FlowMeterSwitchFlag AS FlowMeterSwitchFlag, 
					T.FlowMeterCalibration AS FlowMeterCalibration, 
					T.MaximumDosingTime AS MaximumDosingTime, 
					T.FlowSwitchTimeOut AS FlowSwitchTimeOut, 
					T.ControllerEquipmentSetupId AS ControllerEquipmentSetupId, 
					@Ecolabaccountnumber AS EcoLabAccountNumber, 
					@Controllerid AS ControllerId, 
					CC.TopicName AS ControllerName, 
					CC.ControllerTypeId AS ControllerTypeId, 
					T.LfsChemicalName AS LfsChemicalName, 
					T.FlushTime   ,                 
					T.PumpingTime  ,                  
					T.PreFlushTime ,                   
					T.NightFlushPauseTime    ,                
					T.NightFlushTime  ,                  
					T.AcceptedDeviation ,
					T.LineNumber ,
					T.KFactor AS KFactor, 
					T.TunnelHold AS TunnelHold, 
					T.FlowDetectorType AS FlowDetectorType, 
					T.FlowSwitchAlarm AS FlowSwitchAlarm, 
					T.FlowMeterAlarm AS FlowMeterAlarm, 
					T.FlowMeterType AS FlowMeterType, 
					T.FlowAlarmDelay AS FlowAlarmDelay, 
					 T.ControllerEquipmentTypeModelID,
					 T.ConventionalWasherGroupConnection,
					 T.DirectDosingFlag,
					 T.DirectDosingMachineInternalId ,	
					 T.DirectDosingTunnelCompartmentId ,				 
					T.FlowMeterPumpDelay AS FlowMeterPumpDelay, 
					T.FlowMeterAlarmDelay AS FlowMeterAlarmDelay, 
					(SELECT
							 MTS.TagAddress
						 FROM TCD.ModuleTags AS MTS
						 WHERE EcolabAccountNumber = @Ecolabaccountnumber
						   AND MTS.TagType = @Tagtypelfs
						   AND MTS.ModuleID = ControllerEquipmentSetupId
						   AND MTS.ModuleTypeId = 4
						   AND MTS.Active = 1)AS LfsChemicalNameTag, 
					(SELECT
							 MTS.TagAddress
						 FROM TCD.ModuleTags AS MTS
						 WHERE EcolabAccountNumber = @Ecolabaccountnumber
						   AND MTS.TagType = @Tagtypekfactor
						   AND MTS.ModuleID = ControllerEquipmentSetupId
						   AND MTS.ModuleTypeId = 4
						   AND MTS.Active = 1)AS KfactorTag, 
					(SELECT
							 MTS.TagAddress
						 FROM TCD.ModuleTags AS MTS
						 WHERE EcolabAccountNumber = @Ecolabaccountnumber
						   AND MTS.TagType = @Tagtypecalibration
						   AND MTS.ModuleID = ControllerEquipmentSetupId
						   AND MTS.ModuleTypeId = 4
						   AND MTS.Active = 1)AS CalibrationTag, 
					T.LastModifiedTime AS LastModifiedTime, 
					T.LastSyncTime AS LastSyncTime,
					T.WasherGroupTypeId,
				     T.NumberOfCompartments	
				FROM #Equipment AS T
					 JOIN TCD.ConduitController AS CC ON CC.ControllerId = @Controllerid
				WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
				  AND T.IsActive = ISNULL(@Isactive, T.IsActive)
				  AND T.ControllerEquipmentId = ISNULL(@Controllerequipmentid, T.ControllerEquipmentId)

			--RETURN @Returnvalue
		END

IF (@ControllerModelId = 11)
BEGIN
	IF ISNULL(@Pumpvalvecount, 0) <> 0
		BEGIN
			;WITH NumCTE(
					N)
				AS(SELECT
						   '*' AS N
				   UNION ALL
				   SELECT
						   '*' AS N)
				INSERT #Equipment(
						ControllerEquipmentTypeId)
				SELECT TOP (@Pumpvalvecount)
						@Controllerequipmenttypeid_Pumpvalve
					FROM NumCTE AS N1, NumCTE AS N2, NumCTE AS N3, NumCTE AS N4, NumCTE AS N5
		END


	IF ISNULL(@Mecount, 0) <> 0
		BEGIN
			;WITH NumCTE(
					N)
				AS(SELECT
						   '*' AS N
				   UNION ALL
				   SELECT
						   '*' AS N)
				INSERT #Equipment(
						ControllerEquipmentTypeId)
				SELECT TOP (@Mecount)
						@Controllerequipmenttypeid_Me
					FROM NumCTE AS N1, NumCTE AS N2, NumCTE AS N3, NumCTE AS N4, NumCTE AS N5
		END

		IF ISNULL(@Pumpvalvecount, 0) <> 0
		BEGIN
			;WITH NumCTE(
					N)
				AS(SELECT
						   '*' AS N
				   UNION ALL
				   SELECT
						   '*' AS N)
				INSERT #Equipment(
						ControllerEquipmentTypeId)
				SELECT TOP (@Pumpvalvecount)
						@Controllerequipmenttypeid_Pumpvalve
					FROM NumCTE AS N1, NumCTE AS N2, NumCTE AS N3, NumCTE AS N4, NumCTE AS N5
		END


	IF ISNULL(@Mecount, 0) <> 0
		BEGIN
			;WITH NumCTE(
					N)
				AS(SELECT
						   '*' AS N
				   UNION ALL
				   SELECT
						   '*' AS N)
				INSERT #Equipment(
						ControllerEquipmentTypeId)
				SELECT TOP (@Mecount)
						@Controllerequipmenttypeid_Me
					FROM NumCTE AS N1, NumCTE AS N2, NumCTE AS N3, NumCTE AS N4, NumCTE AS N5
		END
END
ELSE
BEGIN
	IF ISNULL(@Pumpvalvecount, 0) <> 0
		BEGIN
			;WITH NumCTE(
					N)
				AS(SELECT
						   '*' AS N
				   UNION ALL
				   SELECT
						   '*' AS N)
				INSERT #Equipment(
						ControllerEquipmentTypeId)
				SELECT TOP (@Pumpvalvecount)
						@Controllerequipmenttypeid_Pumpvalve
					FROM NumCTE AS N1, NumCTE AS N2, NumCTE AS N3, NumCTE AS N4, NumCTE AS N5
		END


	IF ISNULL(@Mecount, 0) <> 0
		BEGIN
			;WITH NumCTE(
					N)
				AS(SELECT
						   '*' AS N
				   UNION ALL
				   SELECT
						   '*' AS N)
				INSERT #Equipment(
						ControllerEquipmentTypeId)
				SELECT TOP (@Mecount)
						@Controllerequipmenttypeid_Me
					FROM NumCTE AS N1, NumCTE AS N2, NumCTE AS N3, NumCTE AS N4, NumCTE AS N5
		END
END

	UPDATE U SET
			U.IsActive = CES.IsActive, 
			U.ProductId = CES.ProductId, 
			U.ProductName = PM.Name, 
			U.PumpCalibration = CES.PumpCalibration, 
			U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag, 
			U.FlowMeterCalibration = CES.FlowMeterCalibration, 
			U.MaximumDosingTime = CES.MaximumDosingTime, 
			U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut, 
			U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId, 
			U.LfsChemicalName = CES.LfsChemicalName, 
			U.FlushTime = CES.FlushTime   ,                 
			 U.PumpingTime = CES.PumpingTime  ,                  
			 U.PreFlushTime = CES.PreFlushTime    ,                
			U.NightFlushPauseTime = CES.NightFlushPauseTime    ,                
			U.NightFlushTime = CES.NightFlushTime    ,                
			U.AcceptedDeviation = CES.AcceptedDeviation,
		 U.LineNumber = CES.LineNumber ,
			U.KFactor = CES.KFactor, 
			U.TunnelHold = CES.TunnelHold, 
			U.FlowDetectorType = CES.FlowDetectorType, 
			U.FlowSwitchAlarm = CES.FlowSwitchAlarm, 
			U.FlowMeterAlarm = CES.FlowMeterAlarm, 
			U.FlowMeterType = CES.FlowMeterType, 
			U.FlowAlarmDelay = CES.FlowAlarmDelay, 
			U.ControllerEquipmentTypeModelID = CES.ControllerEquipmentTypeModelID  ,
			U.ConventionalWasherGroupConnection = CES.ConventionalWasherGroupConnection,
			U.DirectDosingFlag = TCEVM.DirectDosingFlag,
			U.DirectDosingMachineInternalId = TCEVM.TunnelNumber,
			U.DirectDosingTunnelCompartmentId = TCEVM.CompartmentNumber,
			U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay, 
			U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay, 
			U.LastModifiedTime = CES.LastModifiedTime, 
			U.LastSyncTime = CES.LastSyncTime,
			U.WasherGroupNumber = CES.WasherGroupNumber			
		FROM #Equipment U
			 JOIN TCD.ControllerEquipmentSetup CES ON U.ControllerEquipmentId = CES.ControllerEquipmentId
												  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId
												              
			JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId  AND CES.EcoLabAccountNumber = CC.EcoalabAccountNumber               
			LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId AND TCEVM.EcolabAccountNumber = CES.EcoLabAccountNumber          
			LEFT JOIN TCD.ProductMaster PM ON CES.ProductId = PM.ProductId
		WHERE CES.EcoLabAccountNumber = @Ecolabaccountnumber
		  AND CES.ControllerId = @Controllerid

		IF(@ControllerModelId = 11)                
		   BEGIN
		   	 
		 UPDATE U             
		   SET U.WasherGroupTypeId = CASE @ControllerTypeId WHEN 14 THEN 2 ELSE 1 END--(SELECT MIN(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId AND WG.EcolabAccountNumber = @EcolabAccountNumber)            
			FROM #Equipment U WHERE                  
			U.ControllerEquipmentId IN (select top 14 V.ControllerEquipmentId FROM  #Equipment V )			
			
		 UPDATE U             
		   SET U.WasherGroupTypeId = CASE @ControllerTypeId WHEN 12 THEN 1 ELSE 2 END--(SELECT MAX(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId AND WG.EcolabAccountNumber = @EcolabAccountNumber)            
			FROM #Equipment U WHERE 
			U.ControllerEquipmentId IN (select  V.ControllerEquipmentId FROM #Equipment V WHERE 		             
			V.ControllerEquipmentId BETWEEN 15 AND 28 )        

		   UPDATE U SET U.NumberOfCompartments = ms.NumberOfComp        
		   FROM #Equipment U        
		   INNER JOIN TCD.ControllerEquipmentSetup ces        
		   ON u.ControllerEquipmentId = ces.ControllerEquipmentId         
		   INNER JOIN TCD.WasherGroup wg ON ces.ControllerId = WG.ControllerId AND WG.EcolabAccountNumber = CES.EcoLabAccountNumber       
		   INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.GroupId = WG.WasherGroupId  AND MS.EcoalabAccountNumber = CES.EcoLabAccountNumber       
		   WHERE ces.ControllerId = @ControllerId AND U.WasherGroupTypeId = 2  AND ms.IsTunnel = 1 AND WG.WasherDosingNumber = U.WasherGroupNumber 
		   AND CES.EcoLabAccountNumber = @EcoLabAccountNumber
		          
		   END        


	ExitModule:

	--Return result set
	SELECT	--*	--Change this
			T.ControllerEquipmentId AS ControllerEquipmentId, 
			T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId, 
			T.IsActive AS IsActive, 
			T.ProductId AS ProductId, 
			T.ProductName AS ProductName, 
			T.PumpCalibration AS PumpCalibration, 
			T.FlowMeterSwitchFlag AS FlowMeterSwitchFlag, 
			T.FlowMeterCalibration AS FlowMeterCalibration, 
			T.MaximumDosingTime AS MaximumDosingTime, 
			T.FlowSwitchTimeOut AS FlowSwitchTimeOut, 
			T.ControllerEquipmentSetupId AS ControllerEquipmentSetupId, 
			@Ecolabaccountnumber AS EcoLabAccountNumber, 
			@Controllerid AS ControllerId, 
			CC.TopicName AS ControllerName, 
			CC.ControllerTypeId AS ControllerTypeId, 
			T.LfsChemicalName AS LfsChemicalName, 
			T.FlushTime   ,                 
			T.PumpingTime    ,                
			 T.PreFlushTime   ,                 
			 T.NightFlushPauseTime     ,               
			 T.NightFlushTime     ,               
			 T.AcceptedDeviation,
			T.LineNumber AS LineNumber,
			T.KFactor AS KFactor, 
			T.TunnelHold AS TunnelHold, 
			T.FlowDetectorType AS FlowDetectorType, 
			T.FlowSwitchAlarm AS FlowSwitchAlarm, 
			T.FlowMeterAlarm AS FlowMeterAlarm, 
			T.FlowMeterType AS FlowMeterType, 
			T.FlowAlarmDelay AS FlowAlarmDelay, 
			T.ControllerEquipmentTypeModelID,
			T.ConventionalWasherGroupConnection,
			T.DirectDosingFlag,
			T.DirectDosingMachineInternalId,
			T.DirectDosingTunnelCompartmentId,
			T.FlowMeterPumpDelay AS FlowMeterPumpDelay, 
			T.FlowMeterAlarmDelay AS FlowMeterAlarmDelay, 
			(SELECT
					 MTS.TagAddress
				 FROM TCD.ModuleTags AS MTS
				 WHERE EcolabAccountNumber = @Ecolabaccountnumber
				   AND MTS.TagType = @Tagtypelfs
				   AND MTS.ModuleID = ControllerEquipmentSetupId
				   AND MTS.ModuleTypeId = 4
				   AND MTS.Active = 1)AS LfsChemicalNameTag, 
			(SELECT
					 MTS.TagAddress
				 FROM TCD.ModuleTags AS MTS
				 WHERE EcolabAccountNumber = @Ecolabaccountnumber
				   AND MTS.TagType = @Tagtypekfactor
				   AND MTS.ModuleID = ControllerEquipmentSetupId
				   AND MTS.ModuleTypeId = 4
				   AND MTS.Active = 1)AS KfactorTag, 
			(SELECT
					 MTS.TagAddress
				 FROM TCD.ModuleTags AS MTS
				 WHERE EcolabAccountNumber = @Ecolabaccountnumber
				   AND MTS.TagType = @Tagtypecalibration
				   AND MTS.ModuleID = ControllerEquipmentSetupId
				   AND MTS.ModuleTypeId = 4
				   AND MTS.Active = 1)AS CalibrationTag, 
			T.LastModifiedTime AS LastModifiedTime, 
			T.LastSyncTime AS LastSyncTime,
			T.WasherGroupTypeId,
			T.NumberOfCompartments,
			T.WasherGroupNumber		
		FROM #Equipment AS T
			 JOIN TCD.ConduitController AS CC ON CC.ControllerId = @Controllerid
		WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
		  AND T.IsActive = ISNULL(@Isactive, T.IsActive)
		  AND T.ControllerEquipmentId = ISNULL(@Controllerequipmentid, T.ControllerEquipmentId)
	SET NOCOUNT OFF
	--RETURN @Returnvalue

END