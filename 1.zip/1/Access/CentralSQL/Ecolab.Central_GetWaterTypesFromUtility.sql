
BEGIN
SET NOCOUNT ON;
	DECLARE @Count INT

	SELECT
			@Count = COUNT(1)FROM TCD.WaterUtilityDetails

	IF @Count > 0
		BEGIN
			SELECT
					wt.Id, 
					wt.Name
				FROM TCD.WaterUtilityDetails AS wud
					 JOIN TCD.WaterType AS wt ON wt.Id = wud.WaterFactorTypeId
				WHERE wud.EcolabAccountNumber = @Ecolabaccountnumber 
				AND wt.Id <> 2

		END
	ELSE
		BEGIN
			SELECT
					Id, 
					Name
				FROM TCD.WaterType AS wt
				WHERE MyServiceUtilTypeCode = 'S'
				  AND RegionID = @Regionid
				  AND wt.Id <> 2
		END
END

