/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
	BEGIN

		SET NOCOUNT ON;
		DECLARE @CurrencySymbol nvarchar(10) ='$'

		IF @EcolabAccountNumber IS NULL OR @EcolabAccountNumber = ''
		BEGIN
			SELECT top(1) @CurrencySymbol = cs.CurrencySymbol  FROM dbo.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT Top(1) p.CurrencyCode FROM TCD.Plant p)
		END
		ELSE
		BEGIN
			SELECT top(1) @CurrencySymbol = cs.CurrencySymbol  FROM dbo.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT Top(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)
		END

		SELECT DISTINCT
				KeyMaster.KeyName, 
				REPLACE(ValueMaster.[Value], '#currency#',@CurrencySymbol) AS [Value]
			FROM TCD.ResourceKeyMaster AS KeyMaster
				 INNER JOIN TCD.ResourceKeyValue AS ValueMaster ON KeyMaster.KeyName = ValueMaster.KeyName
				 INNER JOIN TCD.LanguageMaster AS lm ON lm.LanguageId = ValueMaster.LanguageId
			WHERE lm.Locale = @Locale;
	END;