
BEGIN 


	SET NOCOUNT ON;

	DECLARE @Outputlist AS TABLE(
			LastModifiedTimestamp DATETIME)

	SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL)			--SQLEnlight SA0121

	DECLARE --@Returnvalue INT = 0, 
			@Currentutctime DATETIME = GETUTCDATE(), 
			@Errornumber INT = 0, 
			@Errormessage NVARCHAR(2048) = NULL, 
			@Errorseverity INT = NULL, 
			@Errorprocedure SYSNAME = NULL, 
			@Messagestring NVARCHAR(2500) = NULL


	IF EXISTS(SELECT
					  1
				  FROM TCD.ProgramMaster AS PM
				  WHERE PM.EcolabAccountNumber = @Ecolabaccountnumber
					AND ProgramId = @Programid)
		BEGIN
				

			UPDATE TCD.ProgramMaster SET
					Is_Deleted = 'TRUE', 
					LastModifiedByUserId = @Userid, 
					LastModifiedTime = @Currentutctime
				WHERE EcolabAccountNumber = @Ecolabaccountnumber
					  AND ProgramId = @Programid
				
		END


	--set at-least the datetime output param to limit the impact in service layer
	SET @Outputlastmodifiedtimestampatlocal = GETUTCDATE()


	--RETURN @Returnvalue

	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp
		FROM @Outputlist AS O

END