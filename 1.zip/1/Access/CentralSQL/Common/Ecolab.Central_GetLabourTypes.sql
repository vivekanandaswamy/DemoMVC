/*
	History-
	Feb. 2016		sidrameshwar@allianceglobalservice.com		Created a prepared statement
	*/
BEGIN
	SET NOCOUNT ON;
	SELECT
			LT.LaborTypeId, 
			LT.Description FROM TCD.LaborType AS LT
	SET NOCOUNT OFF;
END