
BEGIN

	SET NOCOUNT ON


	SELECT
			MT.EcolabAccountNumber AS EcolabAccountNumber, 
			MT.ModuleTagId AS ModuleTagId, 
			MT.TagType AS TagType, 
			MT.TagAddress AS TagAddress, 
			MT.ModuleTypeId AS ModuleTypeId, 
			MT.ModuleId AS ModuleId, 
			MT.DeadBand AS DeadBand, 
			MT.Active AS Active
		FROM TCD.ModuleTags AS MT
		WHERE MT.EcolabAccountNumber = @Ecolabaccountnumber
		  AND MT.ModuleId = ISNULL(@Moduleid, MT.ModuleId)
		  AND MT.ModuleTagId = ISNULL(@Moduletagid, MT.ModuleTagId)
		  AND MT.ModuleTypeId = ISNULL(@Moduletypeid, MT.ModuleTypeId)
		ORDER BY MT.ModuleTagId DESC
	RETURN 0
END
