
  BEGIN 
	SET NOCOUNT ON;
	BEGIN
		DECLARE @Regionid INT = NULL
	 SELECT 
				@Regionid = RegionId
			FROM TCD.Plant
			WHERE EcolabAccountNumber = @Ecolabaccountnumber
		;WITH CTE(
				Id, 
				ItemName, 
				COU, 
				UOM)
			AS (SELECT
	 RF.Id,
						RF.ItemName, 
						IT.COU, 
						CASE @Regionid
							WHEN 1 THEN UOMNA
							WHEN 2 THEN UOMEurope
						END AS UOM
					FROM TCD.RedFlagItemList AS RF
						 LEFT OUTER JOIN(SELECT
												 COUNT(1)AS COU, 
												 Item AS Id
											 FROM TCD.RedFlag AS PRF
												  INNER JOIN TCD.MachineGroup AS GT ON PRF.Location = GT.Id
											 GROUP BY
												 ITEM)AS IT ON rf.Id = it.Id)
			SELECT
					Id, 
					ItemName, 
					UOM
				FROM CTE
				WHERE COU < (SELECT
									 COUNT(1)FROM TCD.MachineGroup WHERE Id <> 0
																	 AND Is_Deleted = 0)
				   OR COU IS NULL
				   OR ID = @Itemid
		SET NOCOUNT OFF;
	END
  END