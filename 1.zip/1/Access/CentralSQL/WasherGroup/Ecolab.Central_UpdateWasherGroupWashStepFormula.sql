	BEGIN

		SET NOCOUNT ON;

		DECLARE @Returnvalue INT = 0, 
				@Errorid INT = 0, 
				@Errormessage NVARCHAR(4000) = N'', 
				@Currentutctime DATETIME = GETUTCDATE(), 
				@Errornumber INT = 0, 
				@Errorseverity INT = NULL, 
				@Errorprocedure SYSNAME = NULL, 
				@Messagestring NVARCHAR(2500) = NULL, 
				@Totalruntime INT, 
				@Totalsteps INT,
				@ControllerModelId INT,
				@WasherGroupId INT,
				@ControllerID INT, 
				@Outputlastmodifiedtimestampatlocal DATETIME = NULL,
				@PRODUCTISDELETE BIT,
				@PRODUCTEXIST BIT;

		DECLARE @Outputlist AS TABLE(
				OutputDosingSetupId INT, 
				LastModifiedTimestamp DATETIME);
		--Set flag for WashStep type...

			SELECT	@WasherGroupId				=			WasherGroupId
		,@ControllerID				=			ControllerID
FROM [TCD].WasherProgramSetup 
WHERE WasherProgramSetupId = @ProgramSetupId
AND   EcolabAccountNumber = @EcoLabAccountNumber

SELECT	@ControllerModelId		=		cc.ControllerModelId
	FROM	TCD.ConduitController	cc
	WHERE	cc.ControllerId			=		@ControllerID
	AND		cc.EcoalabAccountNumber =		@EcoLabAccountNumber 


		--UPDATE the new record
		UPDATE WDS SET
				StepTypeId = @Steptypeid, 
				StepRunTime = @Stepruntime, 
				StepNumber = @Stepnumber, 
				Temperature = @Temperature, 
				WaterType = @Watertype, 
				WaterLevel = @Waterlevel, 
				DrainDestinationId = CASE
										 WHEN @Draindestinationid = 0 THEN NULL
										 ELSE @Draindestinationid
									 END, 
				pHLevel = @Phlevel, 
				Note = @Note, 
				LastModifiedByuserId = @Userid,
				TrackAsDosingStep = @trackAsDosingStep
			FROM TCD.WasherDosingSetup WDS
			WHERE
				WDS.EcoLabAccountNumber = @Ecolabaccountnumber
			AND WDS.WasherDosingSetupId = @Dosingsetupid;
			
			 SET @PRODUCTEXIST = (SELECT PM.Is_Deleted FROM TCD.PRODUCTMASTER PM WHERE PM.ProductId= 1 AND PM.Name LIKE '%DUMMY PRODUCT%');
			  IF(@PRODUCTEXIST = 1)
				   BEGIN
				   UPDATE TCD.PRODUCTMASTER SET Is_Deleted= 0 WHERE  ProductId= 1 AND Name LIKE '%DUMMY PRODUCT%'
				   END

			SET @PRODUCTEXIST = (SELECT Is_Deleted FROM TCD.ProductdataMapping WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1);

		IF(@PRODUCTEXIST IS NULL )
			BEGIN
			insert into TCD.ProductdataMapping(Id,EcolabAccountNumber,ProductId,SKU,Cost,Is_Deleted,IncludeCI,InventoryExpense,LastModifiedByUserId,LastModifiedTime,LastSyncTime) values ((select max(id) from TCD.ProductdataMapping)+1,@EcoLabAccountNumber,1,'0',0,0,0,0,0,getdate(),GETDATE())
			END
		IF(@PRODUCTEXIST = 1)
			BEGIN
			UPDATE TCD.ProductdataMapping SET Is_Deleted = 0 WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1
			END

			SELECT @PRODUCTISDELETE = IsDeleted FROM TCD.WasherDosingProductMapping WDP WHERE WDP.ProductId=1 AND WDP.WasherDosingSetupId = @DosingSetupId AND WDP.EcoLabAccountNumber = @EcoLabAccountNumber

	IF(@trackAsDosingStep = 1 AND @PRODUCTISDELETE IS NULL)
		BEGIN
			INSERT INTO  [TCD].WasherDosingProductMapping (
				WasherDosingProductMappingId,
				EcoLabAccountNumber
				, WasherDosingSetupId
				, InjectionNumber
				, ProductId
				, Quantity
				, LastModifiedByuserId
				, MyServiceFrmulaStpDsgDvcGuid
				, IsDeleted
				, [Delay])
				VALUES(
				(SELECT ISNULL(MAX(WasherDosingProductMappingId),0)+1 FROM [TCD].WasherDosingProductMapping WHERE EcoLabAccountNumber = @EcoLabAccountNumber),
				@EcoLabAccountNumber
				, @DosingSetupId
				, 1
				, 1
				, 0
				, @UserId
				,@MyServiceCustFrmulaStpGUID
				, 0
				, 0)
		END

	IF (@trackAsDosingStep = 1 AND @PRODUCTISDELETE = 1)
		BEGIN
		UPDATE [TCD].WasherDosingProductMapping SET IsDeleted= 0 WHERE ProductId=1 AND WasherDosingSetupId = @DosingSetupId AND EcoLabAccountNumber = @EcoLabAccountNumber
		END
	IF (@trackAsDosingStep = 0 AND @PRODUCTISDELETE = 0)
		BEGIN
		UPDATE [TCD].WasherDosingProductMapping SET IsDeleted= 1 WHERE ProductId=1 AND WasherDosingSetupId = @DosingSetupId AND EcoLabAccountNumber = @EcoLabAccountNumber
		END
		IF (@trackAsDosingStep = 1 AND @PRODUCTISDELETE = 0)
		BEGIN
		UPDATE [TCD].WasherDosingProductMapping SET IsDeleted= 0 WHERE ProductId=1 AND WasherDosingSetupId = @DosingSetupId AND EcoLabAccountNumber = @EcoLabAccountNumber
		END
		IF (@trackAsDosingStep = 0 AND @PRODUCTISDELETE = 1)
		BEGIN
		UPDATE [TCD].WasherDosingProductMapping SET IsDeleted= 1 WHERE ProductId=1 AND WasherDosingSetupId = @DosingSetupId AND EcoLabAccountNumber = @EcoLabAccountNumber
		END




		SELECT
				@Totalruntime = SUM(wds.StepRunTime), 
				@Totalsteps = COUNT(*)
			FROM TCD.WasherDosingSetup AS wds
			WHERE WasherProgramSetupId = @Programsetupid
				AND wds.EcoLabAccountNumber = @Ecolabaccountnumber
				AND wds.Is_Deleted = 0;

			UPDATE TCD.WasherProgramSetup SET
				TotalSteps = @Totalsteps, 
				LastModifiedTime = @Currentutctime
		OUTPUT
				inserted.LastModifiedTime AS LastModifiedTimestamp
				INTO @Outputlist(
				LastModifiedTimestamp)
			WHERE
				WasherProgramSetupId = @Programsetupid
			AND EcolabAccountNumber = @Ecolabaccountnumber;

		  IF @ControllerModelId  > 2 AND @ControllerModelId IS NOT NULL
		  BEGIN
			 UPDATE TCD.WasherProgramSetup SET
				    TotalRunTime = @Totalruntime, 
				    LastModifiedTime = @Currentutctime
			 OUTPUT
				    inserted.LastModifiedTime AS LastModifiedTimestamp
				    INTO @Outputlist(
				    LastModifiedTimestamp)
			    WHERE
				    WasherProgramSetupId = @Programsetupid
			    AND EcolabAccountNumber = @Ecolabaccountnumber;
		  END
		--check for any error
		SET @Errorid = @@Error;

		IF @Errorid <> 0
			BEGIN
				SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) + N' Error occurred updating formula wash step.';
				RAISERROR(@Errormessage, 16, 1);
				SET @Returnvalue = -1;
			END;

		SELECT TOP 1
				@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
				@Outputdosingsetupid = O.OutputDosingSetupId
			FROM @Outputlist AS O;

		SET NOCOUNT OFF;

	END;