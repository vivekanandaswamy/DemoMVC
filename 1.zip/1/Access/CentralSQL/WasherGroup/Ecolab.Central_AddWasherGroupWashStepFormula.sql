	BEGIN

		SET NOCOUNT ON;

		DECLARE @Washergroupid INT = NULL, 
				@Programnumber SMALLINT = NULL, 
				@Returnvalue INT = 0, 
				@Errorid INT = 0, 
				@Errormessage NVARCHAR(4000) = N'', 
				@Currentutctime DATETIME = GETUTCDATE(), 
				@Totalruntime INT, 
				@Totalsteps INT, 
				@Newidtobeinserted INT = NULL, 
				@Errornumber INT = 0, 
				@Errorseverity INT = NULL, 
				@Errorprocedure SYSNAME = NULL, 
				@Messagestring NVARCHAR(2500) = NULL, 
				@Controllermodelid INT = NULL, 
				@Maxwashstep INT = NULL, 
				@Controllerid INT = NULL, 
				@Outputlastmodifiedtimestampatlocal DATETIME = NULL,
				@PRODUCTEXIST BIT;
		
		DECLARE @Outputlist AS TABLE(
				OutputDosingSetupId INT, 
				LastModifiedTimestamp DATETIME);

		SET @Dosingsetupid = ISNULL(@Dosingsetupid, NULL);
		SET @Outputlastmodifiedtimestampatlocal = ISNULL(@Outputlastmodifiedtimestampatlocal, NULL);


		SELECT
				@Washergroupid = WasherGroupId, 
				@Programnumber = ProgramNumber, 
				@Controllerid = ControllerID
			FROM TCD.WasherProgramSetup
			WHERE WasherProgramSetupId = @Programsetupid
				AND EcolabAccountNumber = @Ecolabaccountnumber;

		IF @Controllerid IS NULL
			BEGIN
				SELECT
						@Controllerid = wg.ControllerId
					FROM TCD.WasherGroup AS wg
					WHERE wg.WasherGroupId = @Washergroupid;
			END;

		SELECT
				@Controllermodelid = cc.ControllerModelId
			FROM TCD.ConduitController AS cc
			WHERE cc.ControllerId = @Controllerid
				AND cc.EcoalabAccountNumber = @Ecolabaccountnumber;

		IF @Controllermodelid > 6
		AND @Controllermodelid NOT IN(12, 13)
			BEGIN
				SELECT
						@Totalsteps = COUNT(1)
					FROM TCD.WasherDosingSetup AS wds
					WHERE wds.WasherProgramSetupId = @Programsetupid
						AND wds.EcoLabAccountNumber = @Ecolabaccountnumber;
				SET @Maxwashstep = 25;

				IF @Totalsteps = @Maxwashstep
					BEGIN
						SET @Errorid = 51000;
						SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) +
	N' Maximum Number of washstep that can be associated to a program already defined... Aborting.';
						--GOTO	ErrorHandler
						RAISERROR(@Errormessage, 16, 1);
						SET @Returnvalue = -1;
					END;
			END;


		IF EXISTS(SELECT
							1
						FROM TCD.WasherDosingSetup AS WDS
						WHERE WDS.EcolabAccountNumber = @Ecolabaccountnumber
						AND WDS.WasherProgramSetupId = @Programsetupid
						AND WDS.StepNumber = @Stepnumber
						AND WDS.Is_Deleted = 0)
			BEGIN
				SET @Errorid = 51000;
				SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) + N' Specified WasherStep already exists for the plant.';

				RAISERROR(@Errormessage, 16, 1);
				SET @Returnvalue = -1;
			END;

		IF @Isdrain = 'TRUE'
			BEGIN
				SELECT TOP 1
						@Steptypeid = StepId
					FROM TCD.WashStep
					WHERE StepName = 'Drain'
						AND RegionId = @Regionid
						AND IsActive = 'TRUE';

				SELECT TOP 1
						@Draindestinationid = DrainDestinationId
					FROM TCD.DrainDestination
					WHERE DrainDestinationName = 'Sewer';

			END;



		SET @Newidtobeinserted = (SELECT
											ISNULL(MAX(WDS.WasherDosingSetupId), 0) + 1
										FROM TCD.WasherDosingSetup AS WDS
										WHERE WDS.EcolabAccountNumber = @Ecolabaccountnumber);

		INSERT TCD.WasherDosingSetup(
				WasherDosingSetupId, 
				EcolabAccountNumber, 
				GroupId, 
				ProgramNumber, 
				StepNumber, 
				StepTypeId, 
				StepRunTime, 
				Temperature, 
				WaterType, 
				WaterLevel, 
				DrainDestinationId, 
				pHLevel, 
				Note, 
				WasherProgramSetupId, 
				LastModifiedByuserId, 
				MyServiceCustFrmulaStpGUID, 
				TrackAsDosingStep,
				ControllerID)
		VALUES
				(
				@Newidtobeinserted, 
				@Ecolabaccountnumber, 
				CASE
					WHEN @Controllermodelid = 7 THEN NULL
					ELSE @Washergroupid
				END, 
				@Programnumber, 
				@Stepnumber, 
				@Steptypeid, 
				@Stepruntime, 
				@Temperature, 
				@Watertype, 
				@Waterlevel, 
				CASE
					WHEN @Draindestinationid = 0 THEN NULL
					ELSE @Draindestinationid
				END, 
				@Phlevel, 
				@Note, 
				@Programsetupid, 
				@Userid, 
				@Myservicecustfrmulastpguid, 
				@trackAsDosingStep,
				CASE WHEN @Controllermodelid = 7 THEN @Controllerid	ELSE NULL END);
			
		--check for any error
		SET @Errorid = @@Error;

		IF @Errorid <> 0
			BEGIN
				SET @Errormessage = N'ErrorId: ' + CAST(@Errorid AS NVARCHAR(10)) + N' Error occurred associating formula wash step.';
				--GOTO	ErrorHandler
				RAISERROR(@Errormessage, 16, 1);
				SET @Returnvalue = -1;
			END;

		SET @PRODUCTEXIST = (SELECT PM.Is_Deleted FROM TCD.PRODUCTMASTER PM WHERE PM.ProductId= 1 AND PM.Name LIKE '%DUMMY PRODUCT%');
   IF(@PRODUCTEXIST = 1)
	   BEGIN
	   UPDATE TCD.PRODUCTMASTER SET Is_Deleted= 0 WHERE  ProductId= 1 AND Name LIKE '%DUMMY PRODUCT%'
	   END

		SET @Dosingsetupid = @Newidtobeinserted;
		SET @PRODUCTEXIST = (SELECT Is_Deleted FROM TCD.ProductdataMapping WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1);

		IF(@PRODUCTEXIST IS NULL )
			BEGIN
			insert into TCD.ProductdataMapping(Id,EcolabAccountNumber,ProductId,SKU,Cost,Is_Deleted,IncludeCI,InventoryExpense,LastModifiedByUserId,LastModifiedTime,LastSyncTime) values ((select max(id) from TCD.ProductdataMapping)+1,@EcoLabAccountNumber,1,'0',0,0,0,0,0,getdate(),GETDATE())
			END
		IF(@PRODUCTEXIST = 1)
			BEGIN
			UPDATE TCD.ProductdataMapping SET Is_Deleted = 0 WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1
			END


		IF (@IsDrain = 'FALSE' AND @trackAsDosingStep = 'TRUE')
		BEGIN
			INSERT INTO  [TCD].WasherDosingProductMapping (
				WasherDosingProductMappingId,
				EcoLabAccountNumber
				, WasherDosingSetupId
				, InjectionNumber
				, ProductId
				, Quantity
				, LastModifiedByuserId
				, MyServiceFrmulaStpDsgDvcGuid
				, IsDeleted
				, [Delay])
				VALUES(
				(SELECT ISNULL(MAX(WasherDosingProductMappingId),0)+1 FROM [TCD].WasherDosingProductMapping WHERE EcoLabAccountNumber = @EcoLabAccountNumber),
				@EcoLabAccountNumber
				, @DosingSetupId
				, 1
				, 1
				, 0
				, @UserId
				,@MyServiceCustFrmulaStpGUID
				, 0
				, 0)
		END

		SELECT
				@Totalruntime = SUM(wds.StepRunTime), 
				@Totalsteps = COUNT(*)
			FROM TCD.WasherDosingSetup AS wds
			WHERE WasherProgramSetupId = @Programsetupid
				AND wds.EcoLabAccountNumber = @Ecolabaccountnumber
				AND wds.Is_Deleted = 0;

	UPDATE TCD.WasherProgramSetup SET
			TotalSteps = @Totalsteps,
			LastModifiedTime = @Currentutctime
	OUTPUT
			inserted.LastModifiedTime AS LastModifiedTimestamp
			INTO @Outputlist(
			LastModifiedTimestamp)
		WHERE
			WasherProgramSetupId = @Programsetupid
		AND EcolabAccountNumber = @Ecolabaccountnumber;

			IF @ControllerModelId  > 2 AND @ControllerModelId IS NOT NULL
    BEGIN

		UPDATE TCD.WasherProgramSetup SET
			TotalRunTime = @Totalruntime,
			LastModifiedTime = @Currentutctime
	OUTPUT
			inserted.LastModifiedTime AS LastModifiedTimestamp
			INTO @Outputlist(
			LastModifiedTimestamp)
		WHERE
			WasherProgramSetupId = @Programsetupid
		AND EcolabAccountNumber = @Ecolabaccountnumber;
		END

		SELECT TOP 1
				@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp
			FROM @Outputlist AS O;

		SET NOCOUNT OFF;


	END;