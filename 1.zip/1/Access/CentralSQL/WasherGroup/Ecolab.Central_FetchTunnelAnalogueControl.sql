
DECLARE @PlantId INT = (SELECT p.PlantId FROM tcd.Plant p WHERE EcolabAccountNumber = @EcolabAccountNumber)
	SELECT 
		tts.DesiredTemperature,
		tts.MinTime,
		tts.StartDelay,
		tts.AcceptDelay,
		tts.ProductCheck,
		tps.pHRegulationLevel,
		tps.pHMonitoringLevel,
		tps.pHMinimum,
		tps.pHMaximum,
		tps.DelayTime,
		tps.MeasuringTime,
		tcss.ConductivityRegulationLevel,
		tcss.ConductivityMininum,
		tcss.ConductivityMaximum,
		tcss.ConductivityDelayTime,
		tcss.ConductivityMeasuringTime,
		@TunnelProgramSetupId,
		@CompartmentNumber,
		@EcolabAccountNumber
		FROM  TCD.TunnelDosingSetup tds 
		INNER JOIN TCD.TunnelTempSetup tts   ON tds.TunnelProgramSetupId = tts.TunnelProgramSetupId  AND tds.CompartmentNumber = tts.CompartmentNumber and tts.PlantId=@PlantId
		INNER JOIN TCD.TunnelpHSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId  AND tps.CompartmentNumber = tds.CompartmentNumber  and tps.EcolabAccountNumber=tds.EcolabAccountNumber
		INNER JOIN TCD.TunnelConductivitySetup tcss ON tcss.TunnelProgramSetupId = tds.TunnelProgramSetupId  AND tcss.CompartmentNumber = tds.CompartmentNumber  and tcss.EcolabAccountNumber= tds.EcolabAccountNumber

		WHERE 
		tts.PlantId = @PlantId		
		AND tds.EcolabAccountNumber = @EcolabAccountNumber 
		AND tds.TunnelProgramSetupId = @TunnelProgramSetupId
		AND tds.CompartmentNumber = @CompartmentNumber