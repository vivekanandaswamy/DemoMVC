﻿BEGIN 
      DECLARE @ResultTable TABLE 
        ( 
           stepNumber           Int, 
           InjectionNumber      int, 
           WasherProgramSetupId int, 
           WasherDosingSetupId  int 
        ) 

      INSERT @ResultTable 
             (stepNumber, 
              InjectionNumber, 
              WasherProgramSetupId, 
              WasherDosingSetupId) 
      SELECT wds.StepNumber, 
             DENSE_RANK() 
               OVER( 
                 ORDER BY wds.StepNumber), 
             wds.WasherProgramSetupId, 
             wds.WasherDosingSetupId 
      FROM   TCD.WasherDosingProductMapping wdpm 
             INNER JOIN TCD.WasherDosingSetup wds 
                     ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId 
                        AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber 
      WHERE  wds.WasherProgramSetupId = @ProgramSetupId 
             AND wds.Is_Deleted = 0 
             AND wdpm.IsDeleted = 0 
      ORDER  BY wds.StepNumber 

      UPDATE wdpm 
      SET    wdpm.InjectionNumber = rt.InjectionNumber 
      FROM   TCD.WasherDosingProductMapping wdpm 
             INNER JOIN TCD.WasherDosingSetup wds 
                     ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId 
             INNER JOIN (SELECT DISTINCT R.WasherDosingSetupId, 
                                         R.WasherProgramSetupId, 
                                         R.InjectionNumber 
                         FROM   @ResultTable R) rt 
                     ON wds.WasherDosingSetupId = rt.WasherDosingSetupId 
                        AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber 
      WHERE  rt.WasherProgramSetupId = @ProgramSetupId 
             AND wds.Is_Deleted = 0 
             AND wdpm.IsDeleted = 0 
             AND wdpm.EcoLabAccountNumber = @EcoLabAccountNumber 
  END