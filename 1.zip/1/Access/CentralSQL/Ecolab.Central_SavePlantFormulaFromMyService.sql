
BEGIN
SET NOCOUNT ON
	DECLARE @Ecolabtextileid INT, 
			@Programid INT, 
			@Saturationid INT, 
			@Errorid INT, 
			@Regioncode NVARCHAR(100), 
			@Regionid INT

	DECLARE @Returnvalue INT = 0, 
			@Errormessage NVARCHAR(4000) = N'', 
			@Currentutctime DATETIME = GETUTCDATE()

	DECLARE @Outputlist AS TABLE(
			ProgramId INT, 
			LastModifiedTimestamp DATETIME)

	SET @Outputlastmodifiedtimestampatlocal = @Currentutctime


	SELECT
			@Regioncode = MyServiceRegionCode
		FROM TCD.RegionMaster
		WHERE RegionId = (SELECT
								  RegionId FROM TCD.Plant WHERE EcolabAccountNumber = @Ecolabaccountnumber)

	IF @Regioncode = 'EMEA'
	BEGIN
			SELECT
					@Ecolabtextileid = ISNULL(TextileId, 0)
				FROM TCD.EcolabTextileCategory
				WHERE MyServiceMstrLnnTypId = @Myserviceecolabtextilecategory
			SET @Saturationid = NULL
	END
	ELSE
	BEGIN
			IF @Regioncode = 'NA'
				BEGIN
					SELECT
							@Saturationid = ISNULL(EcolabSaturationId, 0)
						FROM TCD.EcolabSaturation
						WHERE MyServiceMstrLnnTypId = @Myserviceecolabtextilecategory
					SET @Ecolabtextileid = NULL
	END
		END

	SELECT
			@Programid = ISNULL(MAX(ProgramId), 0) + 1
		FROM TCD.ProgramMaster
		WHERE EcolabAccountNumber = @Ecolabaccountnumber
	IF NOT EXISTS(SELECT
						  1
					  FROM TCD.ProgramMaster
					  WHERE EcolabAccountNumber = @Ecolabaccountnumber
						AND NAME = @Name)
		
BEGIN

			INSERT INTO TCD.ProgramMaster(
					EcolabAccountNumber, 
					ProgramId, 
					Name, 
					Pieces, 
					EcolabTextileCategoryId, 
					Rewash, 
					Weight, 
					EcolabSaturationId, 
					PlantProgramId, 
					ChainTextileId, 
					CustomerId, 
					Is_Deleted, 
					LastModifiedByUserId, 
					LastModifiedTime)
		OUTPUT
					@Programid AS Id, 
					inserted.LastModifiedTime AS LastModifiedTimestamp
				   INTO @Outputlist(
					ProgramId, 
					LastModifiedTimestamp)
		VALUES
					(
						@Ecolabaccountnumber, 
						@Programid, 
						@Name, 
						@Pieces, 
						@Ecolabtextileid, 
						@Rewash, 
						@Weight, 
						@Saturationid, 
						@Plantprogramid, 
						@Chaintextileid, 
						@Customerid, 
						'false', 
						@Userid, 
						@Outputlastmodifiedtimestampatlocal)
			SET @Errorid = @@Error 
--SELECT	@OutputFormulaId	=	SCOPE_IDENTITY()
END
--ELSE
--BEGIN
--	--UPDATE [TCD].ProgramMaster  
--	--SET
--	--					  Name							=		@Name
--	--				,	  Pieces						=		@Pieces
--	--				,	  EcolabTextileCategoryId		=		@EcolabTextileId
--	--				,	  Rewash						=		@Rewash
--	--				,	  [Weight]						=		@Weight
--	--				,	  EcolabSaturationId			=		@SaturationId
--	--				,	  PlantProgramId				=		@PlantProgramId
--	--				,	  ChainTextileId				=		@ChainTextileId
--	--				,	  CustomerId					=		@CustomerId
--	--				,	  Is_Deleted					=		'FALSE'
--	--				,	  LastModifiedByUserId			=		@UserId
--	--				,	  LastModifiedTime				=		CURRENT_TIMESTAMP
--	--WHERE
	--	--	EcolabAccountNumber = @EcolabAccountNumber
--	--AND
	--	--	ProgramId = @ProgramId

--	SET @ErrorId = @@ERROR
--END
	SELECT TOP 1
			@Outputlastmodifiedtimestampatlocal = O.LastModifiedTimestamp, 
			@Outputprogramid = O.ProgramId
		FROM @Outputlist AS O
SET NOCOUNT OFF
	--RETURN @Errorid

END