
BEGIN

	SET NOCOUNT ON;

	DECLARE @Sqlquery AS NVARCHAR(500);

	DECLARE @Parmdefinition NVARCHAR(500);

	SET @Sqlquery ='SELECT count(*) FROM TCD.MachineGroup WHERE EcolabAccountNumber = @EcolabAccountNumber and GroupTypeId = (select Id from TCD.MachineGroupType where GroupType = @GroupMainType)';

	BEGIN
		SET @Sqlquery = @Sqlquery
	END


	SET @Parmdefinition = N'@EcolabAccountNumber NVARCHAR(1000),	@GroupMainType NVARCHAR(1000)';
	EXECUTE sp_executesql @Sqlquery, @Parmdefinition, @Ecolabaccountnumber, @Groupmaintype;


END