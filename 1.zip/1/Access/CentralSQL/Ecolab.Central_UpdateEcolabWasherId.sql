IF EXISTS (SELECT 1 FROM TCD.WASHER WHERE EcoLabAccountNumber = @EcoLabAccountNumber AND WasherId = @WasherId)
	BEGIN
		UPDATE TCD.WASHER
			SET EcolabWasherId = @EcolabWasherId
		WHERE
			EcoLabAccountNumber = @EcoLabAccountNumber AND WasherId = @WasherId
	END