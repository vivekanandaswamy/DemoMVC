/*
History-
Feb. 2016		sidrameshwar@allianceglobalservice.com		created a prepared statement
*/
	BEGIN
		SET NOCOUNT ON;
		BEGIN
			DECLARE @Uom INT, 
					@Languageid INT, 
					@Currencycode VARCHAR(20),
					@CurrencySymbol nvarchar(10) ='$';
			SELECT
					@Uom = UOMId
				FROM TCD.UserMaster
				WHERE TCD.UserMaster.EcolabAccountNumber = @Ecolabaccountnumber
					AND UserId = @Userid;
			SELECT
					@Currencycode = P.CurrencyCode
				FROM TCD.PLANT AS P
				WHERE EcolabAccountNumber = @Ecolabaccountnumber;
			SELECT
					@Languageid = ISNULL(UM.LanguageId, (SELECT
																 LanguageId FROM TCD.Plant WHERE EcolabAccountNumber = @Ecolabaccountnumber))
				FROM TCD.UserMaster AS UM
				WHERE UM.UserId = @Userid
					AND EcolabAccountNumber = @Ecolabaccountnumber;
			SELECT 
					TOP(1) @CurrencySymbol = cs.CurrencySymbol  
				FROM dbo.CurrencySymbol cs 
				WHERE cs.CurrencyCode = ( SELECT TOP(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)

			DECLARE @Unitsystem TABLE(
					UnitSystemId INT, 
					Unit NVARCHAR(200), 
					Subunit NVARCHAR(200), 
					UsageKey NVARCHAR(200), 
					KeyName NVARCHAR(200), 
					Value NVARCHAR(800), 
					languageID INT);

			INSERT INTO @Unitsystem(
					UnitSystemId, 
					Unit, 
					Subunit, 
					UsageKey, 
					KeyName, 
					Value, 
					languageID)
			SELECT
					UnitSystemId, 
					Unit, 
					Subunit, 
					UsageKey, 
					RKM.KeyName, 
					RKV.Value, 
					RKV.languageID
				FROM TCD.DimensionalUnitsDefaults AS DM
					 LEFT OUTER JOIN TCD.ResourceKeyMaster AS RKM ON DM.Subunit = RKM.KeyName
					 LEFT OUTER JOIN TCD.ResourceKeyValue AS RKV ON RKM.KeyName = RKV.KeyName
				WHERE UnitSystemId = @Uom
					AND rkv.languageID = @Languageid;

			SELECT
					UnitSystemId, 
					Unit, 
					Subunit, 
					UsageKey, 
					KeyName, 
					REPLACE(Value ,'#currency#', @CurrencySymbol), 
					languageID
				FROM @Unitsystem;
		END;
	END;