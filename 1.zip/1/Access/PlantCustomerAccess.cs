﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Customer Access </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Data.SqlTypes;
    using System.Linq;
    using System.Text.RegularExpressions;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class PlantCustomerAccess
    /// </summary>
    public class PlantCustomerAccess
    {
        /// <summary>
        ///     Get the PlanrCustomer list
        /// </summary>
        /// <param name="ecolabAccountNumber"> Ecolab Account Number. </param>
        /// <returns>The list of plantCustomers</returns>
        public static List<PlantCustomer> GetPlantCustomerList(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<PlantCustomer>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPlantcustomerlist : Resources.Ecolab_GetPlantcustomerlist, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }

        /// <summary>
        /// Save/Update PlantCustomer details.
        /// </summary>
        /// <param name="plantCust">PlantCustomer object</param>
        /// <param name="userId">Plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>
        /// Returns Paramter Values
        /// </returns>
        public static int SavePlantCustomer(PlantCustomer plantCust, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.UtcNow;
            SqlParameter param = new SqlParameter();
            param.ParameterName = "Scope";
            param.SqlDbType = SqlDbType.Int;
            param.Direction = ParameterDirection.Output;

            SqlParameter paramCustomerId = new SqlParameter { ParameterName = "OutputPlantCustomerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SavePlantCustomer : Resources.Ecolab_SavePlantcustomer, delegate (DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantCust.EcoalabAccountNumber);
                        cmd.AddParameter("ID", plantCust.Id);
                        cmd.AddParameter("Customer_ID", plantCust.CustomerId);
                        cmd.AddParameter("Customer_Name", DbType.String, 250, plantCust.CustomerName);
                        cmd.AddParameter("UserID", userId);
                        if (plantCust.LastModifiedTimestampAtCentral.HasValue)
                        {
                            if (plantCust.LastModifiedTimestampAtCentral.Value == DateTime.MinValue || plantCust.LastModifiedTimestampAtCentral.Value == DateTime.MaxValue)
                            {
                                plantCust.LastModifiedTimestampAtCentral = null;
                            }
                            else
                            {
                                cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, plantCust.LastModifiedTimestampAtCentral.Value);
                            }
                        }
                        cmd.Parameters.Add(param);
                        cmd.Parameters.Add(paramCustomerId);
                        cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    });
            int status = 0;
            status = int.TryParse(param.Value.ToString(), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = Convert.IsDBNull(paramCustomerId.Value) ? 0 : (int)paramCustomerId.Value;
            returnValue = status > 0 ? status : returnValue;

            return returnValue;
        }

        /// <summary>
        /// Delete parameter Customer
        /// </summary>
        /// <param name="plantCust">The plantCust</param>
        /// <param name="userId">The plant User ID</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>
        /// The integer value
        /// </returns>
        public static int DeletePlantCustomer(PlantCustomer plantCust, int userId, out DateTime lastModifiedTimestamp)
        {
            int returnValue = 0;
            lastModifiedTimestamp = DateTime.Now;
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_DeletePlantCustomer : Resources.Ecolab_DeletePlantcustomer, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantCust.EcoalabAccountNumber);
                        cmd.AddParameter("ID", plantCust.Id);
                        cmd.AddParameter("UserID", userId);
                        cmd.Parameters.Add(paramLastModifiedTimeStamp);
                    });
                lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.Now : (DateTime)paramLastModifiedTimeStamp.Value;
            returnValue = plantCust.Id.HasValue ? plantCust.Id.Value : 0;
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("TableName", DbType.String, 1000, "TCD.PlantCustomer");
                });
        }

        /// <summary>
        ///     validate customer for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateCustomerSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            try
            {
                returnValue = DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_ValidateCustomerSave : Resources.Ecolab_ValidateCustomerSave, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            }
            catch(Exception ex)
            {
                returnValue = Int32.Parse(Regex.Match(ex.Message, @"\d+").Value);
            }
            return returnValue;
        }

        /// <summary>
        /// Saves the plant customer for first time synchronize.
        /// </summary>
        /// <param name="plantCust">The plant customer.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SavePlantCustomerForFirstTimeSync(PlantCustomer plantCust, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePlantCustomerForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, plantCust.EcoalabAccountNumber);
                cmd.AddParameter("Id", plantCust.Id);
                cmd.AddParameter("CustomerId", plantCust.CustomerId);
                cmd.AddParameter("CustomerName", DbType.String, 250, plantCust.CustomerName);
                cmd.AddParameter("UserID", userId);
                cmd.AddParameter("LastModifiedTimeStamp", DbType.DateTime, plantCust.LastModifiedTimestamp);
                cmd.AddParameter("IsDelete", plantCust.IsDeleted);
            });
        }
    }
}