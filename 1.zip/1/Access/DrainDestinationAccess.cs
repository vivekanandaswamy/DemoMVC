﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationAccess.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Drain Destination Access class.</summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using Entities;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class DrainDestinationAccess
    /// </summary>
    public class DrainDestinationAccess
    {
        /// <summary>
        ///     Save or update myservice drain destination details
        /// </summary>
        /// <param name="myserviceDrainDestinationDetails">myserviceDrainDestinationDetails</param>
        public static int SaveMyServiceDrainDestinationDetails(DrainDestination myserviceDrainDestinationDetails)
        {
            int returnValue = 0;

            var paramDrainDestinationId = new SqlParameter
            {
                ParameterName = "OutputDrainDestinationId",
                SqlDbType = SqlDbType.Int,
                Direction = ParameterDirection.Output
            };

            DbClient.ExecuteNonQuery(
                Resources.Ecolab_UpdateMyServiceDrainDestinationDetails,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("DrainDestinationId", myserviceDrainDestinationDetails.DrainDestinationId);
                    cmd.AddParameter("DrainDestinationName", DbType.String, 252, myserviceDrainDestinationDetails.DrainDestinationName);
                    cmd.AddParameter("IsDeleted", myserviceDrainDestinationDetails.IsDeleted);
                    cmd.AddParameter("MyServiceDrainTypeId", myserviceDrainDestinationDetails.MyServiceDrainTypeId);
                    cmd.Parameters.Add(paramDrainDestinationId);
                });

            returnValue = Convert.IsDBNull(paramDrainDestinationId.Value) ? 0 : (int)paramDrainDestinationId.Value;
            return returnValue;
        }

        /// <summary>
        ///     Save or update myservice drain destination locale details
        /// </summary>
        /// <param name="myserviceDrainDestinationDetails">myserviceDrainDestinationDetails</param>
        public static void SaveMyServiceDrainDestinationLocaleDetails(DrainDestination myserviceDrainDestinationDetails)
        {
            DbClient.ExecuteNonQuery(
                Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_SaveMyserviceLocale : Resources.Ecolab_SaveMyserviceLocale,
                delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("Key", DbType.String, 252, "FIELD_" + myserviceDrainDestinationDetails.DrainDestinationName.ToUpper(CultureInfo.InvariantCulture).Replace(" ", string.Empty));
                    cmd.AddParameter("English", DbType.String, 252, myserviceDrainDestinationDetails.DrainDestinationName);
                    cmd.AddParameter("Spanish", DbType.String, 252, myserviceDrainDestinationDetails.sp_SP);
                    cmd.AddParameter("Norweign", DbType.String, 252, myserviceDrainDestinationDetails.nr_NR);
                    cmd.AddParameter("Dutch", DbType.String, 252, myserviceDrainDestinationDetails.nl_BE);
                });
        }
    }
}
