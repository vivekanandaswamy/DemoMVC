﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceManualProductionAccess.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The MyServiceManualProductionAccess  class </summary>
// -----------------------------------------------------------------------

namespace Access
{
    using System;
    using System.Data;
    using System.Data.Common;
    using Entities;
	using Nalco.Data.Common;
	using Properties;

	/// <summary>
	/// MyServiceWashFloorDataAccess class
	/// </summary>
	public class MyServiceManualProductionAccess
	{
        /// <summary>
        /// Save the Meter Details
        /// </summary>
        /// <param name="manualProduction">Manual Production</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="isDisconnected">Is Disconnected</param>
        /// <returns>Returns integer value</returns>
		public static int SaveMeterDetails(MyServiceManualProduction manualProduction, string ecolabAccountNumber, bool isDisconnected)
		{
			return DbClient.ExecuteScalar<int>(Resources.Ecolab_SaveMyServiceMeterDetails, delegate (DbCommand cmd, DbContext context)
			{
				cmd.AddParameter("MeterId", manualProduction.MeterId);
				cmd.AddParameter("MeterDescription", DbType.String, 1000, manualProduction.MeterDescription);
				cmd.AddParameter("UtilityType", DbType.String, 1000, manualProduction.UtilityType);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				cmd.AddParameter("MyServiceMeterGuid", manualProduction.MyServiceMeterGuid);
				cmd.AddParameter("MeterTickUnit", DbType.String, 1000, manualProduction.MeterTickUnit);
				cmd.AddParameter("IsDisconnected", isDisconnected);
			});
		}

        /// <summary>
        /// Save MyService Manual Meter Details
        /// </summary>
        /// <param name="manualProduction">Manual Production</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="isDisconnected">Is Disconnected</param>
        /// <returns>Returns integer value</returns>
		public static int SaveMyServiceManualMeterDetails(MyServiceManualProduction manualProduction, string ecolabAccountNumber, bool isDisconnected)
		{
			return DbClient.ExecuteScalar<int>(Resources.Ecolab_SaveMyServiceManualMeterDetails, delegate (DbCommand cmd, DbContext context)
			{
				cmd.AddParameter("MeterId", manualProduction.MeterId);
				cmd.AddParameter("UtilityId", manualProduction.UtilityId);
				cmd.AddParameter("Value", manualProduction.MeterReading);
				cmd.AddParameter("Usage", manualProduction.Usage);
				cmd.AddParameter("RecordedDate", DbType.DateTime, manualProduction.StartDateTime);
				cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
				cmd.AddParameter("MyServiceManualUtilitityGuid", manualProduction.MyServiceManualUtilitityGuid);
				cmd.AddParameter("IsDisconnected", isDisconnected);
			});
		}
	}
}