﻿// -----------------------------------------------------------------------
// <copyright file="PumpsAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Pumps Access </summary>
// -----------------------------------------------------------------------

namespace Access.ControllerSetup.Pumps
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities.Common;
    using Entities.ControllerSetup.Pumps;
    using Nalco.Data.Common;
    using Properties;
    using Entities;

    /// <summary>
    ///     Class PumpsAccess.
    /// </summary>
    public class PumpsAccess
    {
        /// <summary>
        ///     Getting All Pumps based on Controller id and Ecolab AccountNumber
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="controlNumber">Control Number</param>
        /// <param name="showOption">Option value(Active/Inactive)</param>
        /// <returns>Returns Pumps List</returns>
        public static List<PumpsMetaData> GetPumps(string ecolabAccountNumber, int controlNumber, string showOption)
        {
            List<PumpsMetaData> list = DbClient.ExecuteReader<PumpsMetaData>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPumpsDetails : Resources.Ecolab_GetPumpsData, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("ControllerId", controlNumber);
                if (!string.IsNullOrEmpty(showOption))
                {
                    cmd.AddParameter("IsActive", showOption == "Active");
                }
                else
                {
                    cmd.AddParameter("IsActive", DbType.String, null);
                }
            }).ToList();

            return list;
        }

        /// <summary>
        /// Getting All Pumps based on Controller id and Ecolab AccountNumber
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="controlNumber">Control Number</param>
        /// <param name="FormulaId">The formula identifier.</param>
        /// <param name="showOption">Option value(Active/Inactive)</param>
        /// <returns>
        /// Returns Pumps List
        /// </returns>
        public static List<PumpsMetaData> GetCompareFormulaPumps(string ecolabAccountNumber, int controlNumber, int formulaId, string showOption)
        {
            List<PumpsMetaData> list = DbClient.ExecuteReader<PumpsMetaData>("[TCD].[GetCompareFormulaPumpsList]", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("ControllerId", controlNumber);
                cmd.AddParameter("WasherProgramSetupId", formulaId);
                if (!string.IsNullOrEmpty(showOption))
                {
                    cmd.AddParameter("IsActive", showOption == "Active");
                }
            }).ToList();
            return list;
        }

        /// <summary>
        ///     To Get the Product List
        /// </summary>
        /// <param name="ecolabAccountNumber">The eco lab account number.</param>
        /// <returns>Returns Product List</returns>
        public static List<ProductModel> GetProductList(string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ProductModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetProductData : Resources.Ecolab_GetProductData, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        ///     Updating Pump Details
        /// </summary>
        /// <param name="pumpData">Pump Data To Update</param>
        /// <param name="userId">The user identifier.</param>
        /// <returns>Returns Success</returns>
        public static int UpdatePump(PumpsMetaData pumpData, int userId, out DateTime lastModifiedTimestamp, out int errorCode, DateTime? lastModifiedTimestampAtCentral = null)
        {
            errorCode = 0;

            SqlParameter paramControllerEquipmentSetupId = new SqlParameter { ParameterName = "OutputControllerEquipmentSetupId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_UpdatePump : Resources.Ecolab_UpdatePump, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, pumpData.EcolabAccountNumber);
                cmd.AddParameter("ControllerId", pumpData.ControllerId);
                cmd.AddParameter("ControllerEquipmentId", pumpData.ControllerEquipmentId);
                cmd.AddParameter("ControllerEquipmentTypeId", pumpData.ControllerEquipmentTypeId);
                cmd.AddParameter("ProductId", pumpData.ProductId);
                cmd.AddParameter("PumpCalibration", pumpData.PumpCalibration);
                cmd.AddParameter("LfsChemicalName", DbType.String, 200, pumpData.LfsChemicalName);
                cmd.AddParameter("KFactor", pumpData.KFactor);
                cmd.AddParameter("TunnelHold", pumpData.TunnelHold);
                cmd.AddParameter("FlowDetectorType", pumpData.FlowDetectorType);
                cmd.AddParameter("FlowSwitchNumber", pumpData.FlowSwitchNumber);
                cmd.AddParameter("FlowSwitchAlarm", pumpData.FlowSwitchAlarm);
                cmd.AddParameter("FlowMeterAlarm", pumpData.FlowMeterAlarm);
                cmd.AddParameter("FlowMeterType", pumpData.FlowMeterType);
                cmd.AddParameter("FlowAlarmDelay", pumpData.FlowAlarmDelay);
                cmd.AddParameter("FlowMeterPumpDelay", pumpData.FlowMeterPumpDelay);
                cmd.AddParameter("FlowMeterAlarmDelay", pumpData.FlowMeterAlarmDelay);
                cmd.AddParameter("LfsChemicalNameTag", DbType.String, 200, pumpData.LfsChemicalNametag);
                cmd.AddParameter("KfactorTag", DbType.String, 200, pumpData.KfactorTag);
                cmd.AddParameter("CalibrationTag", DbType.String, 200, pumpData.CalibrationTag);
                cmd.AddParameter("ControllerEquipmentTypeModelId", pumpData.ControllerEquipmentTypeModelId);
                cmd.AddParameter("ConventionalWasherGroupConnection", pumpData.ConventionalWasherGroupConnection);
                cmd.AddParameter("AxillaryPumpCalibration", pumpData.AxillaryPumpCalibration);
                cmd.AddParameter("FlowmeterSwitchActivated", pumpData.FlowmeterSwitchActivated);
                cmd.AddParameter("FlushWhileDosing", pumpData.FlushWhileDosing);
                cmd.AddParameter("WeightControlledDosage", pumpData.WeightControlledDosage);
                cmd.AddParameter("EquipmentDoseAlone", pumpData.EquipmentDoseAlone);
                cmd.AddParameter("LowLevelAlarm", pumpData.LowLevelAlarm);
                cmd.AddParameter("LeakageAlarm", pumpData.LeakageAlarm);
                cmd.AddParameter("FlushTime", pumpData.FlushTime);
                cmd.AddParameter("PumpingTime", pumpData.PumpingTime);
                cmd.AddParameter("PreFlushTime", pumpData.PreFlushTime);
                cmd.AddParameter("NightFlushPauseTime", pumpData.NightFlushPauseTime);
                cmd.AddParameter("NightFlushTime", pumpData.NightFlushTime);
                cmd.AddParameter("AcceptedDeviation", pumpData.AcceptedDeviation);
                cmd.AddParameter("LineNumber", pumpData.LineNumber);
                cmd.AddParameter("MaximumDosingTime", pumpData.MaximumDosingTime);
                cmd.AddParameter("FlowSwitchTimeOut", pumpData.FlowSwitchTimeout);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("FlushValveNumber", pumpData.FlushValveNumber);
                cmd.AddParameter("CalibrationConductSS_Tank", pumpData.CalibrationConductSS_Tank);
                cmd.AddParameter("BackFlowControl", pumpData.BackflowControl);
                cmd.AddParameter("FactorFM_B_FM", pumpData.FactorFM_B_FM);
                cmd.AddParameter("AcceptedDeviationRingLine", pumpData.AcceptedDeviationRingLine);
                cmd.AddParameter("UsePumpOfGroup1ForTunnel", pumpData.UsePumpOfGroup1ForTunnel);
                cmd.AddParameter("pHSensorEnabled", pumpData.pHSensorEnabled);
                cmd.AddParameter("FlushTimeForFlushValve", pumpData.FlushTimeForFlushValve);
                cmd.AddParameter("ValveOutputAsTom", pumpData.ValveOutputAsTom);
                cmd.AddParameter("MinimumFlowRate", pumpData.MinimumFlowRate);
                cmd.AddParameter("ProductDensity", pumpData.ProductDensity);
                cmd.AddParameter("MaximumConcentration", pumpData.MaximumConcentration);
                cmd.AddParameter("Deadband ", pumpData.StockSolutionDeadEnd);
                cmd.AddParameter("Concentration", pumpData.Concentration);

                if (lastModifiedTimestampAtCentral != null && lastModifiedTimestampAtCentral != DateTime.MinValue)
                {
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                }
                cmd.Parameters.Add(paramControllerEquipmentSetupId);
                cmd.Parameters.Add(paramLastModifiedTimeStamp);
            });

            int status;
            status = int.TryParse(paramControllerEquipmentSetupId.Value.ToString(), out status) ? status : 0;
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;

            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            int returnValue = Convert.IsDBNull(paramControllerEquipmentSetupId.Value) ? 0 : (int)paramControllerEquipmentSetupId.Value;
            returnValue = status > 0 && status != 102 ? status : returnValue;

            return returnValue;
        }

        public static int UpdateLineCompartmentMappings(DataTable lineCompartmentMappings, PumpsMetaData pumpData, int userId)
        {
            return DbClient.ExecuteNonQuery(Resources.Ecolab_SaveTunnelCompartmentEquipmentValveMapping, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameterUnsafe("lineCompartmentMappings", lineCompartmentMappings);
                cmd.AddParameter("ControllerEquipmentId", pumpData.ControllerEquipmentId);
                cmd.AddParameter("ControllerId", pumpData.ControllerId);
                cmd.AddParameter("LineNumber", pumpData.LineNumber);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, pumpData.EcolabAccountNumber);
            });
        }

        /// <summary>
        ///     Updating Pump Details
        /// </summary>
        /// <param name="pumpData">Pump Data To Update</param>
        /// <param name="userId">The user identifier.</param>
        public static void UpdatePumpTags(PumpsMetaData pumpData, int userId, out string errorCode)
        {
            SqlParameter param = new SqlParameter { ParameterName = "Scope", SqlDbType = SqlDbType.VarChar, Size = 100, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdatePumpTags, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, pumpData.EcolabAccountNumber);
                cmd.AddParameter("ControllerId", pumpData.ControllerId);
                cmd.AddParameter("ControllerEquipmentId", pumpData.ControllerEquipmentId);
                cmd.AddParameter("ProductId", pumpData.ProductId);
                cmd.AddParameter("LfsChemicalNameTag", DbType.String, 200, pumpData.LfsChemicalNametag);
                cmd.AddParameter("KfactorTag", DbType.String, 200, pumpData.KfactorTag);
                cmd.AddParameter("CalibrationTag", DbType.String, 200, pumpData.CalibrationTag);
                cmd.AddParameter("UserId", userId);
                cmd.Parameters.Add(param);
            });
            errorCode = param.Value.ToString();
        }

        public static List<ModuleTagsModel> GetModuleTagsDetails(int moduleId, int moduleTypeId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ModuleTagsModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetModuleTagsDetails : Resources.Ecolab_GetModuleTagsDetails, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ModuleId", moduleId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("ModuleTypeId", moduleTypeId);
            }).ToList();
        }

        public static List<PumpsMetaData> GetPumpsForResync(string ecolabAccountNumber, int? controllerId = null, int? controllerEquipmentSetupId = null)
        {
            List<PumpsMetaData> list = DbClient.ExecuteReader<PumpsMetaData>("TCD.GetPumpsResync", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("ControllerEquipmentSetupId", controllerEquipmentSetupId);
            }).ToList();
            return list;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TableName", DbType.String, 1000, "TCD.ControllerEquipmentSetup");
            });
        }

        public static int ValidatePumpSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidatePumpSave, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
            });
            return returnValue;
        }

        /// <summary>
        ///     Get the Tag Types.
        /// </summary>
        /// <returns>The TagType.</returns>
        public static List<TagTypes> GetTagTypes()
        {
            return DbClient.ExecuteReader<TagTypes>(Resources.Ecolab_GetActiveTagTypes, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            }).ToList();
        }

        /// <summary>
        ///     Get the Pump Models.
        /// </summary>
        /// <returns>The PumpModelsModel.</returns>
        public static IEnumerable<PumpModels> GetPumpModels()
        {
            return DbClient.ExecuteReader<PumpModels>(Resources.Ecolab_GetEquipmentTypeModels, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
            });
        }

        /// <summary>
        ///     Get the Line Data.
        /// </summary>
        /// <returns>The LineCompartmentMapping.</returns>
        /// <param name="lineNo">The Line Number</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="equipmentId">The Equipment Id</param>
        public static IEnumerable<LineCompartmentMapping> GetLineData(int lineNo, int controllerId, int equipmentId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<LineCompartmentMapping>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetEquipmentLineCompartmentMapping : Resources.Ecolab_GetEquipmentLineCompartmentMapping, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("LineNumber", lineNo);
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EquipmentId", equipmentId);
                cmd.AddParameterUnsafe("EcolabAccountNumber", ecolabAccountNumber);
            });
        }

        /// <summary>
        ///     Get the Controller Data.
        /// </summary>
        /// <returns>The ControllerData.</returns>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="ecolabAccountNumber">The Ecolab Account Number</param>
        public static IEnumerable<ControllerData> GetControllerData(int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ControllerData>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetControllerDataForEquipmentSetup : Resources.Ecolab_GetControllerDataForEquipmentSetup, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            });
        }

        /// <summary>
        /// GetCompartmentValveData
        /// </summary>
        /// <param name="controllerEquipSetupId"></param>
        /// <returns></returns>
        public static List<LineCompartmentMapping> GetCompartmentValveData(int controllerEquipSetupId, int washerGroupNumber, int controllerEquipmentTypeId, string ecolabAccNumber)
        {
            return DbClient.ExecuteReader<LineCompartmentMapping>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetValveAndTunnelCompNumber : "TCD.GetValveAndTunnelCompNumber", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ControllerEquipmentSetUpId", controllerEquipSetupId);
                cmd.AddParameter("WasherGroupNumber", washerGroupNumber);
                cmd.AddParameter("ControllerEquipmentTypeId", controllerEquipmentTypeId);
                if(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central)
                {
                    cmd.AddParameter("EcolabAccNumber", DbType.String, 200, ecolabAccNumber); 
                }
            }).ToList();
        }

        public static int UpdateValveCompartmentMappings(DataTable valveCompartmentMapping, PumpsMetaData pumpData, int userId)
        {
            return DbClient.ExecuteNonQuery("TCD.SaveTunnelCompartmentEquipmentValveMapping_XL", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameterUnsafe("ValveCompartmentMappings", valveCompartmentMapping);
                cmd.AddParameter("ControllerEquipmentId", pumpData.ControllerEquipmentId);
                cmd.AddParameter("ControllerId", pumpData.ControllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, pumpData.EcolabAccountNumber);
                cmd.AddParameter("UserId", userId);
            });
        }

        public static List<LineCompartmentMapping> GetLineDataForResync(int controllerEquipmentSetupId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<LineCompartmentMapping>(Resources.Ecolab_GetPumpsTunnelCompartmentEquipmentValveMappingResync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("@EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("@ControllerEquipmentSetupId", controllerEquipmentSetupId);
            }).ToList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="controllerId"></param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns></returns>
        public static List<ProductModel> GetPumpsProductData(int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ProductModel>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetPumpsProductsData : "TCD.GetPumpsProductsData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        public static void SavePumpsProducts(DataTable pumpProductTable, int controllerId, string ecolabAccountNumber)
        {
            DbClient.ExecuteNonQuery("TCD.SavePumpsProducts", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameterUnsafe("PumpProducts", pumpProductTable);
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            });
        }

        public static int UpdateWasherCompartmentMappings(DataTable washerCompartmentMappings, PumpsMetaData pumpData, int userId)
        {
            return DbClient.ExecuteNonQuery("[TCD].[SaveTunnelCompartmentEquipmentValveMapping_DECentral]", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameterUnsafe("WasherCompartmentMappings", washerCompartmentMappings);
                cmd.AddParameter("ControllerEquipmentId", pumpData.ControllerEquipmentId);
                cmd.AddParameter("ControllerId", pumpData.ControllerId);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, pumpData.EcolabAccountNumber);
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="controllerId"></param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns></returns>
        public static List<MixingVesselsModel> GetMixingVesselsData(int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<MixingVesselsModel>("TCD.GetMixingVesselsData", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        public static void SaveMixingVessels(DataTable mixingVesselsTable, int controllerId, string ecolabAccountNumber)
        {
            DbClient.ExecuteNonQuery("TCD.SaveMixingVessels", delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameterUnsafe("MixingVessels", mixingVesselsTable);
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            });
        }

        /// <summary>
        /// Saves the controller equipment for first time synchronize.
        /// </summary>
        /// <param name="pumpData">The pump data.</param>
        public static void SaveControllerEquipmentForFirstTimeSync(PumpsMetaData pumpData, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveControllerEquipmentForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ControllerEquipmentSetupId", pumpData.ControllerEquipmentSetupId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, pumpData.EcolabAccountNumber);
                cmd.AddParameter("ControllerId", pumpData.ControllerId);
                cmd.AddParameter("ControllerEquipmentId", pumpData.ControllerEquipmentId);
                cmd.AddParameter("ControllerEquipmentTypeId", pumpData.ControllerEquipmentTypeId);
                cmd.AddParameter("IsActive", pumpData.IsActive);
                cmd.AddParameter("ProductId", pumpData.ProductId);
                cmd.AddParameter("PumpCalibration", pumpData.PumpCalibration);
                cmd.AddParameter("FlowMeterSwitchFlag", pumpData.FlowMeterSwitchFlag);
                cmd.AddParameter("FlowMeterCalibration", pumpData.FlowMeterCalibration);
                cmd.AddParameter("MaximumDosingTime", pumpData.MaximumDosingTime);
                cmd.AddParameter("FlowSwitchTimeOut", pumpData.FlowSwitchTimeout);
                cmd.AddParameter("LastModifiedByUserId", userId);
                cmd.AddParameter("KFactor", pumpData.KFactor);
                cmd.AddParameter("TunnelHold", pumpData.TunnelHold);
                cmd.AddParameter("FlowSwitchAlarm", pumpData.FlowSwitchAlarm);
                cmd.AddParameter("FlowMeterAlarm", pumpData.FlowMeterAlarm);
                cmd.AddParameter("FlowMeterType", pumpData.FlowMeterType);
                cmd.AddParameter("FlowAlarmDelay", pumpData.FlowAlarmDelay);
                cmd.AddParameter("FlowMeterPumpDelay", pumpData.FlowMeterPumpDelay);
                cmd.AddParameter("FlowMeterAlarmDelay", pumpData.FlowMeterAlarmDelay);
                cmd.AddParameter("LfsChemicalName", DbType.String, 200, pumpData.LfsChemicalName);
                cmd.AddParameter("FlowDetectorType", pumpData.FlowDetectorType);
                cmd.AddParameter("WasherGroupNumber", pumpData.WasherGroupNumber);
                cmd.AddParameter("ControllerEquipmentTypeModelID", pumpData.ControllerEquipmentTypeModelId);
                cmd.AddParameter("LineNumber", pumpData.LineNumber);
                cmd.AddParameter("ConventionalWasherGroupConnection", pumpData.ConventionalWasherGroupConnection);
                cmd.AddParameter("AxillaryPumpCalibration", pumpData.AxillaryPumpCalibration);
                cmd.AddParameter("FlowmeterSwitchActivated", pumpData.FlowmeterSwitchActivated);
                cmd.AddParameter("FlushWhileDosing", pumpData.FlushWhileDosing);
                cmd.AddParameter("WeightControlledDosage", pumpData.WeightControlledDosage);
                cmd.AddParameter("EquipmentDoseAlone", pumpData.EquipmentDoseAlone);
                cmd.AddParameter("LowLevelAlarm", pumpData.LowLevelAlarm);
                cmd.AddParameter("LeakageAlarm", pumpData.LeakageAlarm);
                cmd.AddParameter("FlushTime", pumpData.FlushTime);
                cmd.AddParameter("PumpingTime", pumpData.PumpingTime);
                cmd.AddParameter("PreFlushTime", pumpData.PreFlushTime);
                cmd.AddParameter("NightFlushPauseTime", pumpData.NightFlushPauseTime);
                cmd.AddParameter("NightFlushTime", pumpData.NightFlushTime);
                cmd.AddParameter("AcceptedDeviation", pumpData.AcceptedDeviation);
                cmd.AddParameter("FlushValveNumber", pumpData.FlushValveNumber);
                cmd.AddParameter("CalibrationConductSS_Tank", pumpData.CalibrationConductSS_Tank);
                cmd.AddParameter("BackFlowControl", pumpData.BackflowControl);
                cmd.AddParameter("FactorFM_B_FM", pumpData.FactorFM_B_FM);
                cmd.AddParameter("AcceptedDeviationRingLine", pumpData.AcceptedDeviationRingLine);
                cmd.AddParameter("UsePumpOfGroup1ForTunnel", pumpData.UsePumpOfGroup1ForTunnel);
                cmd.AddParameter("pHSensorEnabled", pumpData.pHSensorEnabled);
                cmd.AddParameter("ValveOutputAsTom", pumpData.ValveOutputAsTom);
                cmd.AddParameter("Concentration", pumpData.Concentration);
                cmd.AddParameter("Deadband", pumpData.StockSolutionDeadEnd);
                cmd.AddParameter("FlowSwitchnumber", pumpData.FlowSwitchNumber);
                cmd.AddParameter("FlushTimeForFlushValve", pumpData.FlushTimeForFlushValve);
                cmd.AddParameter("MinimumFlowRate", pumpData.MinimumFlowRate);
                cmd.AddParameter("ProductDensity", pumpData.ProductDensity);
                cmd.AddParameter("MaximumConcentration", pumpData.MaximumConcentration);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, pumpData.LastModifiedTimestamp);
            });
        }

        /// <summary>
        /// Get the setUp dosing line
        /// </summary>
        /// <param name="LineNumber">The line number.</param>
        /// <param name="controllerid">The controller id.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <returns>Setup Dosing Line Model</returns>
        public static List<SetupDosingLineModel> GetAuxiliaryPumpData(int lineNumber, int controllerid,string ecolabAccountNumber)
        {
            string Tag_DLM = "Tag_DLM"+ lineNumber;
            string Tag_EAP = "Tag_EAP" + lineNumber;
            return DbClient.ExecuteReader<SetupDosingLineModel>(Resources.Ecolab_GetSetupDosingLines, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("Tag_DLM", DbType.String,255, Tag_DLM);
                cmd.AddParameter("Tag_EAP", DbType.String, 255, Tag_EAP);
                cmd.AddParameter("controllerid", controllerid);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            }).ToList();
        }

        /// <summary>
        /// Saves the pumps asscications for first time synchronize.
        /// </summary>
        /// <param name="lineMappings">The line mappings.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        public static void SavePumpsAsscicationsForFirstTimeSync(LineCompartmentMapping lineMappings, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveTunnelCompartmentLineMappingForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ControllerEquipmentSetupId", lineMappings.ControllerEquipmentSetupId);
                //cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TunnelCompartmentEquipmentValveMappingID", lineMappings.TunnelCompartmentEquipmentValveMappingId);
                cmd.AddParameter("PlantID", lineMappings.PlantId);
                cmd.AddParameter("TunnelNumber", lineMappings.TunnelNumber);
                cmd.AddParameter("DosingPointNumber", lineMappings.DosingPointNumber);
                cmd.AddParameter("ValveNumber", lineMappings.ValveNumber);
                cmd.AddParameter("CompartmentNumber", lineMappings.CompartmentNumber);
                cmd.AddParameter("DirectDosingFlag", lineMappings.DirectDosingFlag);
                cmd.AddParameter("LastModifiedByUserId", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, lineMappings.LastModifiedDate);
            });
        }

        /// <summary>
        /// Saves the pumps asscications for migration.
        /// </summary>
        /// <param name="lineMappings">The line mappings.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        public static void SavePumpsAsscicationsForMigration(LineCompartmentMapping lineMappings, int userId, string ecolabAccountNumber)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePumpsAsscicationsForMigration, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.Text;
                cmd.AddParameter("ControllerEquipmentSetupId", lineMappings.ControllerEquipmentSetupId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("TunnelNumber", lineMappings.TunnelNumber);
                cmd.AddParameter("DosingPointNumber", lineMappings.DosingPointNumber);
                cmd.AddParameter("ValveNumber", lineMappings.ValveNumber);
                cmd.AddParameter("CompartmentNumber", lineMappings.CompartmentNumber);
                cmd.AddParameter("DirectDosingFlag", lineMappings.DirectDosingFlag);
                cmd.AddParameter("LastModifiedByUserId", userId);
            });
        }
    }
}