﻿// -----------------------------------------------------------------------
// <copyright file="TagManagementAccess.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Tag Management Access </summary>
// -----------------------------------------------------------------------

namespace Access
{

    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Globalization;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Access.Properties;
    using Entities;
    using Nalco.Data.Common;

    /// <summary>
    /// Tag Management class
    /// </summary>
    public class TagManagementAccess
    {
        /// <summary>
        /// Gets the tag deails based on dispenserId
        /// </summary>
        /// <param name="dispenserId">The dispenser identifier.</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber of the plant.</param>
        /// <param name="userId">Logged user</param>
        /// <returns>
        /// fetched data of tag details.
        /// </returns>
        public static List<TagManagement> GetTagManagementDetails(int dispenserId, string ecolabAccountNumber, int userId)
        {
            return DbClient.ExecuteReader<TagManagement>(Resources.Ecolab_GetTagManamenetDetails, delegate (DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.AddParameter("ControllerId", dispenserId);
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }
        /// <summary>
        /// Saves the PLC data to database.
        /// </summary>
        /// <param name="lstTagManagement">The LST tag management.</param>
        public static void SavePlcDataToDatabase(List<TagManagement> lstTagManagement)
        {
            string tableName = string.Empty;
            string columnName = string.Empty;
            string query = string.Empty;
            string primaryKeyCoulmn = string.Empty;
            string value = string.Empty;
            int id = 0;
            foreach (TagManagement item in lstTagManagement)
            {
                tableName = item.EntityType;
                columnName = item.OriginalColumnName;
                value = item.PLCValue.Trim();
                if (columnName.Trim() == "FlowDetectorType") { value = value.ToLower(CultureInfo.InvariantCulture).Trim() == "true" ? "1" : "0"; }
                id = Convert.ToInt32(item.Id);

                switch (item.EntityType)
                {
                    case "[TCD].[Washer]":
                        primaryKeyCoulmn = "WasherId";
                        query += string.Format("{0} {1} {2} {3} {4} {5}{6}{7} {8} {9} {10} {11} {12}", "Update", tableName, "SET", columnName, "=", "'", value, "',LastModifiedTime=getutcdate()",
                            "Where", primaryKeyCoulmn, "=", id, "\n");

                        break;
                    case "[TCD].[Meter]":
                        primaryKeyCoulmn = "MeterId";
                        query += string.Format("{0} {1} {2} {3} {4} {5}{6}{7} {8} {9} {10} {11} {12}", "Update", tableName, "SET", columnName, "=", "'", value, "',LastModifiedTime=getutcdate()",
                           "Where", primaryKeyCoulmn, "=", id, "\n");
                        break;
                    case "[TCD].[ControllerEquipmentSetup]":
                        primaryKeyCoulmn = "ControllerEquipmentSetupId";
                        query += string.Format("{0} {1} {2} {3} {4} {5}{6}{7} {8} {9} {10} {11} {12}", "Update", tableName, "SET", columnName, "=", "'", value, "',LastModifiedTime=getutcdate()",
                           "Where", primaryKeyCoulmn, "=", id, "\n");
                        break;
                    case "[TCD].[Sensor]":
                        primaryKeyCoulmn = "SensorId";
                        query += string.Format("{0} {1} {2} {3} {4} {5}{6}{7} {8} {9} {10} {11} {12}", "Update", tableName, "SET", columnName, "=", "'", value, "',LastModifiedTime=getutcdate()",
                           "Where", primaryKeyCoulmn, "=", id, "\n");
                        break;

                    case "[TCD].[TankSetup]":
                        primaryKeyCoulmn = "TankId";

                        string column = columnName.Split(new char[] { '-' })[0];
                        string displayColumn = columnName.Split(new char[] { '-' })[1];

                        query += string.Format("{0} {1} {2} {3} {4} {5}{6}{7} {8} {9} {10} {11} {12} {13} {14} {15} {16}", "Update", tableName, "SET", column, "=", "'", value, "',LastModifiedTime=getutcdate()",
                           ",", displayColumn, "=", value, "Where", primaryKeyCoulmn, "=", id, "\n");
                        break;
                    case "[TCD].[ControllerSetupData]":
                        primaryKeyCoulmn = "ControllerId";
                        string fieldid = columnName.Split(new char[] { '-' })[1];
                        int fieldId = Convert.ToInt32(fieldid);
                        columnName = columnName.Split(new char[] { '-' })[0];
                        query += string.Format("{0} {1} {2} {3} {4} {5}{6}{7} {8} {9} {10} {11} {12} {13} {14} {15} {16}", "Update", tableName, "SET", columnName, "=", "'", value, "'",
                           "Where", primaryKeyCoulmn, "=", id, "And", "FieldId", "=", fieldId, "\n");
                        break;

                    default:
                        break;
                }
            }
            DbClient.ExecuteNonQuery(Resources.Ecolab_SavePLCValuesToDatabase, delegate (DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("Query", DbType.String, 100000, query);

            });
        }
    }
}
