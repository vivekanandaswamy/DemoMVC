﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupAccess.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Setup Access </summary>
// -----------------------------------------------------------------------

namespace Access.ControllerSetup
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using Entities.ControllerSetup;
    using Nalco.Data.Common;
    using Properties;

    /// <summary>
    ///     class ControllerSetupAccess
    /// </summary>
    public static class ControllerSetupAccess
    {
        /// <summary>
        ///     Get ControllerSetup Meta Data.
        /// </summary>
        /// <param name="tabId">The Parameter Tab Identifier</param>
        /// <param name="controllerModelId">Controller Model Id</param>
        /// <param name="controllerTypeId">Controller Type Id</param>
        /// <param name="roleId">Role of the current user.</param>
        /// <returns>List of Controller Setup MetaData</returns>
        public static List<ControllerSetupMetaData> GetControllerSetupMetadata(int tabId, int controllerModelId, int controllerTypeId, int roleId)
        {
            return DbClient.ExecuteReader<ControllerSetupMetaData>(Resources.Ecolab_GetControllerSetupMetaData, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("TabId", tabId);
                    cmd.AddParameter("ControllerModelId", controllerModelId);
                    cmd.AddParameter("ControllerTypeId", controllerTypeId);
                    cmd.AddParameter("RoleId", roleId);
                }).ToList();
        }

        /// <summary>
        ///     Get ControllerSetup Meta Data with values.
        /// </summary>
        /// <param name="tabId">tab Identifier</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="ecolabAccountNumber">The Ecolab Account Number</param>
        /// <param name="roleId">Role of the current user.</param>
        /// <returns>List of Controller Setup MetaData</returns>
        public static List<ControllerSetupMetaData> GetControllerSetupMetadataWithValues(int tabId, int controllerId, string ecolabAccountNumber, int roleId)
        {
            return DbClient.ExecuteReader<ControllerSetupMetaData>(Resources.Ecolab_GetControllerSetupMetaDataWithValues, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.AddParameter("TabId", tabId);
                        cmd.AddParameter("ControllerId", controllerId);
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                        cmd.AddParameter("RoleId", roleId);
                    }).ToList();
        }

        /// <summary>
        ///     Get ControllerSetupAdvance Meta Data.
        /// </summary>
        /// <param name="tabId">The Parameter Tab Identifier</param>
        /// <param name="controllerId">ControllerId</param>
        /// <param name="ecolabAccountNumber">The Ecolab Account Number</param>
        /// <returns>Returns Controller Setup Advance MetaData</returns>
        public static List<ControllerSetupMetaData> GetControllerSetupAdvanceMetadata(int tabId, int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ControllerSetupMetaData>(Resources.Ecolab_GetControllerSetupAdvanceMetaData, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("TabId", tabId);
                    cmd.AddParameter("ControllerId", controllerId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).ToList();
        }

        /// <summary>
        ///     Get ControllerSetupAdvance Meta data with values.
        /// </summary>
        /// <param name="tabId">Tab Identifier</param>
        /// <param name="controllerId">The Parameter ControllerId</param>
        /// <param name="ecolabAccountNumber">The Ecolab Account Number</param>
        /// <returns>Returns Controller Setup Advance MetaData with Values</returns>
        public static List<ControllerSetupMetaData> GetControllerSetupAdvanceMetadataWithValues(int tabId, int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<ControllerSetupMetaData>(Resources.Ecolab_GetControllerSetupAdvanceMetaDataWithValues, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.AddParameter("TabId", tabId);
                        cmd.AddParameter("ControllerId", controllerId);
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    }).ToList();
        }

        /// <summary>
        /// Get Controller Details.
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="canControlTunnel">The Parameter CanControlTunnel</param>
        /// <param name="isDelete">IsDelete</param>
        /// <returns>
        /// Controller Details
        /// </returns>
        public static IList<Controller> GetControllerDetails(string ecolabAccountNumber, bool? canControlTunnel = null, bool? isDelete = null)
        {
            return DbClient.ExecuteReader<Controller>(Resources.Ecolab_GetControllerDetails, delegate(DbCommand cmd, DbContext context)
                {
                    if (canControlTunnel != null)
                    {
                        cmd.AddParameter("CanControlTunnel", canControlTunnel);
                    }
                    if (isDelete != null)
                    {
                        cmd.AddParameter("IsDelete", isDelete);
                    }
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.CommandType = CommandType.StoredProcedure;
                }).ToList();
        }

        /// <summary>
        ///     Get Controller Details By Id.
        /// </summary>
        /// <param name="controllerId">The Parameter ControllerId</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <returns>Controller Details By Id</returns>
        public static Controller GetControllerDetailById(int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteReader<Controller>(Resources.Ecolab_GetControllerDetailsById, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("ControllerId", controllerId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                }).FirstOrDefault();
        }

        /// <summary>
        ///     Get Controller Model Details.
        /// </summary>
        /// <param name="regionId">Region Id Parameter</param>
        /// <returns>Controller Model Details</returns>
        public static IList<ControllerModel> GetControllerModelsDetails(int regionId)
        {
            return DbClient.ExecuteReader<ControllerModel>(Resources.Ecolab_GetControllerModelDetails, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("RegionId", regionId);
                }).ToList();
        }

        /// <summary>
        ///     Get Controller Type Details.
        /// </summary>
        /// <param name="controllerModelId">Controller Model Id</param>
        /// <returns>Controller Type Details</returns>
        public static IList<ControllerType> GetControllerTypesDetails(int controllerModelId)
        {
            return DbClient.ExecuteReader<ControllerType>(Resources.Ecolab_GetControllerTypeDetail, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("ControllerModelId", controllerModelId);
                }).ToList();
        }

        /// <summary>
        ///     Save the controller list data
        /// </summary>
        /// <param name="controller"> the controller </param>
        /// <param name="userId">The Parameter  user id </param>
        /// <param name="ecolabAccountNumber"> Ecolab Account Number.</param>
        /// <param name="lastModifiedTimestamp"> Last Modified TimeStamp.</param>
        public static void UpdateControllerListData(Controller controller, int userId, string ecolabAccountNumber, out DateTime lastModifiedTimestamp, DateTime? lastModifiedTimestampAtCentral = null)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            controller.InstallDate = ConvertIntoDatetime(controller.InstallDateAsString);
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateControllerListDetails, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameter("ControllerId", controller.ControllerId);
                    cmd.AddParameter("InstallDate", DbType.DateTime, controller.InstallDate);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
        }

        /// <summary>
        ///     Save Controller Setup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData</param>
        /// <param name="userId">The Parameter  current userid.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <returns>Returns Controller Id</returns>
        public static int SaveControllerSetupData(string controllerSetupData, int userId, out DateTime lastModifiedTimestamp)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            int controllerId = 0;
            SqlParameter param = new SqlParameter { ParameterName = "ControllerId", SqlDbType = SqlDbType.Int, Direction = ParameterDirection.Output };

            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteScalar<int>(Resources.Ecolab_SaveControllerSetupData, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameter("ControllerSetupData", DbType.String, controllerSetupData.Length, controllerSetupData);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            controllerId = Convert.IsDBNull(param.Value) ? 0 : Convert.ToInt32(param.Value);
            return controllerId;
        }

        /// <summary>
        ///     Update Controller Setup Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData</param>
        /// <param name="userId">The Parameter  current userid.</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        public static void UpdateControllerSetupData(string controllerSetupData, int userId, out DateTime lastModifiedTimestamp, DateTime? lastModifiedTimestampAtCentral = null)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateControllerSetupData, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameter("ControllerSetupData", DbType.String, 4000, controllerSetupData);
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
        }

        /// <summary>
        ///     Delete Controller List Details
        /// </summary>
        /// <param name="controllerId">controller Id</param>
        /// <param name="userId">The Parameter  userId</param>
        /// <param name="ecolabAccountNumber"> Ecolab Account Number.</param>
        /// <param name="lastModifiedTimestamp"> Last Modified TimeStamp.</param>
        /// <returns>Returns Boolean value</returns>
        public static bool DeleteControllerListData(int controllerId, int userId, string ecolabAccountNumber, out DateTime lastModifiedTimestamp, DateTime? lastModifiedTimestampAtCentral = null)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_DeleteControllerDetails, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("ControllerId", controllerId);
                    cmd.AddParameter("UserID", userId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
            return true;
        }

        /// <summary>
        ///     Check if Controller Setup Advance Data Exist
        /// </summary>
        /// <param name="tabId">The Parameter tab Id</param>
        /// <param name="controllerId">the controllerId</param>
        /// <param name="ecolabAccountNumber"> Ecolab Account Number.</param>
        /// <returns>Returns Boolean value</returns>
        public static bool IsSetupAdvanceDataExist(int tabId, int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<bool>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_IsControllerSetupAdvanceDataExist : Resources.Ecolab_IsControllerSetupAdvanceDataExist, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("tabId", tabId);
                    cmd.AddParameter("ControllerId", controllerId);
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                });
        }

        /// <summary>
        ///     Save Controller Setup Advance Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData</param>
        /// <param name="userId">The Parameter  current userid.</param>
        /// <param name="lastModifiedTimestamp"> Last Modified TimeStamp.</param>
        public static void SaveControllerSetupAdvanceData(string controllerSetupData, int userId, out DateTime lastModifiedTimestamp)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };

            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveControllerSetupAdvanceData, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameterUnsafe("ControllerSetupData",controllerSetupData);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
        }

        /// <summary>
        ///     Update Controller Setup Advance Data
        /// </summary>
        /// <param name="controllerSetupData">controllerSetupData</param>
        /// <param name="userId"> current userid.</param>
        /// <param name="lastModifiedTimestamp"> Last Modified TimeStamp.</param>
        public static void UpdateControllerSetupAdvanceData(string controllerSetupData, int userId, out DateTime lastModifiedTimestamp, DateTime? lastModifiedTimestampAtCentral = null)
        {
            lastModifiedTimestamp = DateTime.UtcNow;
            SqlParameter paramLastModifiedTimeStamp = new SqlParameter { ParameterName = "OutputLastModifiedTimestampAtLocal", SqlDbType = SqlDbType.DateTime, Direction = ParameterDirection.Output };
            DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateControllerSetupAdvanceData, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.AddParameter("UserId", userId);
                    cmd.AddParameterUnsafe("ControllerSetupData",controllerSetupData);
                    cmd.AddParameter("LastModifiedTimestampAtCentral", DbType.DateTime, lastModifiedTimestampAtCentral);
                    cmd.Parameters.Add(paramLastModifiedTimeStamp);
                });
            lastModifiedTimestamp = Convert.IsDBNull(paramLastModifiedTimeStamp.Value) ? DateTime.UtcNow : (DateTime)paramLastModifiedTimeStamp.Value;
        }

        /// <summary>
        ///     Inserting or updatin the tags in the COntroller Tags
        /// </summary>
        /// <param name="controllerId">Tags for a controller Id.</param>
        /// <param name="fieldTagValue">Type of tag for the field.</param>
        /// <param name="fieldTagAddress">Tag Address for the field.</param>
        /// <param name="ecolabAccountNumber"> Ecolab Account Number.</param>
        public static void SaveTagsControllerData(int controllerId, string fieldTagValue, string fieldTagAddress, string ecolabAccountNumber)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveControllerTagsData, delegate(DbCommand cmd, DbContext context)
               {
                   cmd.CommandType = CommandType.StoredProcedure;
                   cmd.AddParameter("ControllerId", controllerId);
                   cmd.AddParameter("FieldTagValue", DbType.String, 100, fieldTagValue);
                   cmd.AddParameter("FieldTagAddress", DbType.String, 100, fieldTagAddress);
                   cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
               });
        }

        /// <summary>
        ///     Convert string into datetime
        /// </summary>
        /// <param name="date">Date Parameter</param>
        /// <returns>Returns DateTime value</returns>
        private static DateTime ConvertIntoDatetime(string date)
        {            
            DateTime dateTimeObj;
            dateTimeObj = DateTime.TryParse(date, out dateTimeObj) ? dateTimeObj : dateTimeObj;
            return dateTimeObj;
        }

        /// <summary>
        ///     validate controller for sync.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="maxNumberOfRecords">Max Number Of Records</param>
        /// <returns>success/failure</returns>
        public static int ValidateControllerSave(string ecolabAccountNumber, int maxNumberOfRecords)
        {
            int returnValue;
            returnValue = DbClient.ExecuteScalar<int>(Resources.Ecolab_ValidateControllerSave, delegate(DbCommand cmd, DbContext context)
                 {
                     cmd.CommandType = CommandType.StoredProcedure;
                     cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                     cmd.AddParameter("MaxNoOfRec", maxNumberOfRecords);
                 });
            return returnValue;
        }

        /// <summary>
        ///     Get Max Number Of Records.
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <returns>Max Record Count</returns>
        public static int GetMaxNumberOfRecords(string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>(Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? Resources.Ecolab_Central_GetMaxNumberOfRecords : Resources.Ecolab_GetMaxNumberOfRecords, delegate(DbCommand cmd, DbContext context)
                {
                    cmd.CommandType = Ecolab.Data.Access.Database.ApplicationMode == Entities.ApplicationMode.Central ? CommandType.Text : CommandType.StoredProcedure;
                    cmd.AddParameter("EcolabAccountNumber", DbType.String, 1000, ecolabAccountNumber);
                    cmd.AddParameter("TableName", DbType.String, 25, "TCD.ConduitController");
                });
        }

        /// <summary>
        /// Create default controller for while migration
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        public static void CreateDefaultController(string ecolabAccountNumber)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_InsertDefaultController, delegate(DbCommand cmd, DbContext context)
           {
               cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
           });
        }

        /// <summary>
        /// Create default controller for while migration
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolab Account Number</param>
        public static WasherField GetWasherFieldsForTags(string ecolabAccountNumber, int dispenserId)
        {
            return DbClient.ExecuteReader<WasherField>(Resources.Ecolab_GetAWEandRatioDosing, delegate(DbCommand cmd, DbContext context)
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.AddParameter("ControllerId", dispenserId);
                        cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                    }).FirstOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="controllerId"></param>
        /// <param name="ecolabAccountNumber"></param>
        /// <returns></returns>
        public static int GetMaxInjectionClassesCount(int controllerId, string ecolabAccountNumber)
        {
            return DbClient.ExecuteScalar<int>("[TCD].[GetMaxInjectionClass]", delegate(DbCommand cmd, DbContext context)
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
            });
        }

        /// <summary>
        /// Saves the controller setup data for first time synchronize.
        /// </summary>
        /// <param name="controllerSetupData">The controller setup data.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        public static void SaveControllerSetupDataForFirstTimeSync(string controllerSetupData, int controllerId, DateTime lastModifiedTime, string ecolabAccountNumber, int userId, bool isDelete)
        {
            DbClient.ExecuteScalar<int>(Resources.Ecolab_SaveControllerSetupDataForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ControllerSetupData", DbType.Xml, controllerSetupData.Length, controllerSetupData);
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, lastModifiedTime);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("IsDelete", isDelete);
            });
        }

        /// <summary>
        /// Saves the controller setup advance data for first time synchronize.
        /// </summary>
        /// <param name="controllerSetupData">The controller setup data.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="userId">The user identifier.</param>
        public static void SaveControllerSetupAdvanceDataForFirstTimeSync(string controllerSetupData, int controllerId, int controllerModelId, int controllerTypeId, DateTime lastModifiedTime, string ecolabAccountNumber, int userId)
        {
            DbClient.ExecuteNonQuery(Resources.Ecolab_SaveControllerSetupAdvanceDataForFirstTimeSync, delegate (DbCommand cmd, DbContext context)
            {
                cmd.AddParameter("ControllerSetupData", DbType.Xml, controllerSetupData.Length, controllerSetupData);
                cmd.AddParameter("ControllerId", controllerId);
                cmd.AddParameter("UserId", userId);
                cmd.AddParameter("LastModifiedTime", DbType.DateTime, lastModifiedTime);
                cmd.AddParameter("EcolabAccountNumber", DbType.String, 25, ecolabAccountNumber);
                cmd.AddParameter("ControllerModelId", controllerModelId);
                cmd.AddParameter("ControllerTypeId", controllerTypeId);
            });
        }

		/// <summary>
		/// UpdateMaxInjectionValueForMigratedController
		/// </summary>
		/// <param name="controllerid">The Controller Id</param>
		public static void UpdateMaxInjectionValueForMigratedController(int controllerid)
		{
			DbClient.ExecuteNonQuery(Resources.Ecolab_UpdateMaxInjectionValueForMigratedController, delegate (DbCommand cmd, DbContext context)
			{
				cmd.AddParameter("ControllerId", controllerid);
			});
		}
	}
}