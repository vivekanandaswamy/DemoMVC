﻿--Role Management

/*GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('1', N'Territory Manager : Basic', N'TMB', 6)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('2', N'Territory Manager : Advanced', N'TMA', 7)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('3', N'Engineer', N'ENG', 8)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('4', N'Adminstrator', N'ADM', 9)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('5', N'Temporary Role for Ecolab', N'TRE', 8)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('6', N'Business Development Manager', N'BDM', 5)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('7', N'CAM', N'CAM', 5)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('8', N'Temporary Role for Customer', N'TRC', 7)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('9', N'Plant Manager', N'PM', 4)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('10', N'Plant Engineer', N'PE', 3)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('11', N'Operator', N'OPE', 2)
GO
INSERT [tcd].[UserRoles] ( [RoleId],[RoleName], [code], [LevelId]) VALUES ('12', N'ALL', N'ALL', 1)
GO
*/

SET IDENTITY_INSERT [TCD].[UserMaster] ON 
INSERT INTO [TCD].[UserMaster] -- Updated
           ([UserId]
           ,[FirstName]
           ,[LastName]
           ,[FullName]
           ,[LoginName]
           ,[Password]
           ,[Phone]
           ,[LanguageId]	
           ,[UOMId]
           ,[Email]
           ,[IsActive]
           ,[LastLoggedIn]
           ,[LastModifiedByUserId]
           ,[EcolabAccountNumber]
           ,[Title]
           ,[ContactId])
     VALUES
 (1, N'sravan', N'kumar', N'sravan', N'test', N'test', N'123456', 3, 1, N'sponnuru@allianceglobalservices.com', 1, CAST(0x0000A3AB00263AAB AS DateTime),1,1,'Mr',1),
 (2, N'testfirst', N'testlast', N'testfirstlast', N'tcd', N'tcd', N'123456', 1, 1, N'tcd@allianceglobalservices.com', 1, CAST(0x0000A3AA00F29121 AS DateTime),1,1,'Mr',1),
 (3, N'TCD', N'TCD', N'Textile', N'tcd', N'tcd', N'12345', 1, 1, N'tcd@gmail.com', 1, CAST(0x0000A3AA00FBCEFF AS DateTime),1,1,'Mr',1),
 (4, N'demo1', N'demo1', N'demo1', N'demo1', N'demo', N'123456', 3, 1, N'demo1@allianceglobalservices.com', 1, CAST(0x0000A3AA00F9F607 AS DateTime),1,1,'Mr',1),
 (5, N'demo2', N'demo2', N'demo2', N'demo2', N'demo', N'123456', 3, 1, N'demo2@allianceglobalservices.com', 1, CAST(0x0000A3A300699A9E AS DateTime),1,1,'Mr',1),
 (6, N'demo3', N'demo3', N'demo3', N'demo3', N'demo', N'123456', 3, 1, N'demo3@allianceglobalservices.com', 1, CAST(0x0000A3AA00F9D7AF AS DateTime),1,1,'Mr',1),
 (7, N'demo4', N'demo4', N'demo4', N'demo4', N'demo', N'123456', 3, 1, N'demo4@allianceglobalservices.com', 1, CAST(0x0000A3A90008F923 AS DateTime),1,1,'Mr',1),
 (8, N'TestTeam', N'Testteam', N'Fulltest', N'test1', N'test1', N'321456', 3, 1, N'test@gmail.com', 1, CAST(0x0000A3AA00BB92F6 AS DateTime),1,1,'Mr',1),
 (9, N'AutoTestAdmin', N'AutoTestAdmin', N'AutoTestAdmin AutoTestAdmin', N'AutoTestAdmin', N'test', N'9848230919', 1, NULL, N'AutoTestAdmin@gmail.com', 1, CAST(0x0000A3ED013B03FA AS DateTime), 1, N'1', NULL, NULL),
 (10, N'AutoTestPM', N'AutoTestPM', N'AutoTestPM AutoTestPM', N'AutoTestPM', N'test', N'123456789', 1, NULL, N'AutoTestPM@ags.com', 1, CAST(0x0000A3E1014A1CD1 AS DateTime), 13, N'1', NULL, NULL),
 (11, N'AutoTestTmBasic', N'AutoTestTmBasic', N'AutoTestTmBasic AutoTestTmBasic', N'AutoTestTmBasic', N'test', N'123456789', 1, NULL, N'AutoTestTmBasic@ags.com', 1, CAST(0x0000A3E9013F1DB1 AS DateTime), 13, N'1', NULL, NULL ),
 (12, N'AutoTestTMAdvance', N'AutoTestTMAdvance', N'AutoTestTMAdvance AutoTestTMAdvance', N'AutoTestTMAdvance', N'test', N'123456789', 1, NULL, N'AutoTestTMAdvance@ags.com', 1, CAST(0x0000A3E1015678F6 AS DateTime), 13, N'1', NULL, NULL ),
 (13, N'AutoTestPE', N'AutoTestPE', N'AutoTestPE AutoTestPE', N'AutoTestPE', N'test', N'123456789', 1, NULL, N'AutoTestPE@ags.com', 1, CAST(0x0000A3E10147B0E3 AS DateTime), 13, N'1', NULL, NULL ),
 (14, N'AutoTestEng', N'AutoTestEng', N'AutoTestEng AutoTestEng', N'AutoTestEng', N'test', N'123456789', 1, NULL, N'AutoTestEng@ags.com', 1, NULL, 13, N'1', NULL, NULL),
 (15, N'AutoTestCAM', N'AutoTestCAM', N'AutoTestCAM AutoTestCAM', N'AutoTestCAM', N'test', N'147852369', 1, NULL, N'AutoTestCAM@ags.com', 1, CAST(0x0000A3E10147AD6A AS DateTime), 13, N'1', NULL, NULL ),
 (16, N'AutoTestBDM', N'AutoTestBDM', N'AutoTestBDM AutoTestBDM', N'AutoTestBDM', N'test', N'145623789', 1, NULL, N'AutoTestBDM@ags.com', 1, CAST(0x0000A3ED013B74C7 AS DateTime), 13, N'1', NULL, NULL),
 (17, N'AutoTestOperator', N'AutoTestOperator', N'AutoTestOperator AutoTestOperator', N'AutoTestOperator', N'test', N'145623789', 1, NULL, N'AutoTestOperator@ags.com', 1, CAST(0x0000A3ED013B74C7 AS DateTime), 13, N'1', NULL, NULL);
SET IDENTITY_INSERT [TCD].[UserMaster] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [tcd].[UserInRole] (EcoLabAccountNumber,UserId,RoleId,IsDeleted,LastModifiedByUserId) VALUES 
(1,1, 4,0,1),(1,2, 10,0,1),(1,3, 8,0,1),(1,4, 3,0,1),(1,5, 9,0,1),(1,6, 5,0,1),(1,7, 6,0,1),(1,8, 1,0,1),(1,9,4,0,1),(1,10,9,0,1),(1,11,1,0,1),(1,12,2,0,1),(1,13,10,0,1),(1,14,3,0,1),(1,15,7,0,1),(1,16,6,0,1),
(1,17,11,0,1)

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

GO
INSERT [tcd].[UserProfile] ( [UserId], [EcolabAccountNumber],[LastModifiedByUserId]) VALUES ( 1,1,1),( 2,1,1),( 3,1,1)( 4,1,1),( 5,1,1),( 6,1,1),( 7,1,1),( 8,1,1),( 9,1,1),( 10,1,1),( 11,1,1),( 12,1,1),( 13,1,1),(14,1,1),(15,1,1),(16,1,1),(17,1,1)

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

GO
INSERT [tcd].[Plant] ([EcolabAccountNumber], [Name], [DataLiveTime], [BudgetCustomer], [ExportPath], [LanguageId], [UOMId], [CurrencyCode], [WasteWaterPercentage], [WasteWaterCostPerGallon], [PlantCategoryId], [AcutalIsTarget], [RegionId], [PlantChainId], [PlantChainName], [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy], [TMName], [TMPhoneNumber], [DMName], [DMPhoneNumber], [Chain], [ChainUnitNumber], [ChainRegions], [CensusPriceKg], [Remarks], [Rate], [Is_Deleted], [LastModifiedByUserId], [AllowManualRewash],[LastModifiedTime],[LastSyncTime])
 VALUES (N'1', N'Ecolab Corporation', 3, 0, N'D:\Test', 1, 2, N'USD', NULL, NULL, 2, 1, 2, 1, N'BCVPS789001', CAST(0x0000A37100F65BD2 AS DateTime), NULL, CAST(0x0000A37100F65BD2 AS DateTime), NULL, N'James Cameron', N'789-300-0001', N'Richard David, Jr.', N'789-300-1111', N'BCVPS7890001', N'123456', N'123', N'CensusPriceKg', N'Remarks', 0, 0, 1, 1,'2015-01-05 12:01:32.333',NULL)
GO

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

INSERT [tcd].[PlantCustAddress] ([EcolabAccountNumber], [BillingAddr1], [BillingAddr2], [City], [Country], [Zip], [ShippingAddr1], [ShippingAddr2], [Shippingcity], [Shippingcountry], [Shippingzip]) VALUES (N'1', N'123 East Avenue', N'New Northen Highway', N'New Jersy', N'BillingCountry', N'88250', N'shippingAddr1', N'shippingAddr2', N'City', N'shippingCountry', N'52070')
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

Insert into TCD.PlantContact(EcolabAccountNumber,ContactFirstName,ContactTitle,ContactLastName,ContactPositionId,ContactEMail,ContactOfficePhone,ContactMobilePhone,ContactFaxNumber,
LastModifiedByUserId,Is_Deleted,LastModifiedTime,LastSyncTime)
values
(1,'Sravan','Mr','Kumar',1,'sravan@gmail.com',123456789,9848022338,123321,1,0,'2015-01-05 12:01:32.333',NULL),
(1,'Engineer IN','Mr','Test',1,'Tester@gmail.com',123456789,9848022338,123321,1,0,'2015-01-05 12:01:32.333',NULL);

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

GO
INSERT [tcd].[Shift] ([ShiftName], [EcolabAccountNumber],  [LastModifiedByUserId]) VALUES (N'ShiftA', N'1',  1)


-----------Get the ShiftID from above script

---Update the shiftdata and shiftbreak data with shift ID that we got from shift table before executing below scripts


---Insert for Shiftdata


GO
SET IDENTITY_INSERT [TCD].[ShiftData] ON
INSERT INTO [TCD].[ShiftData] ([ShiftId],[ShiftName], [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [TargetProduction],[LastModifiedByUserId],[Is_Deleted],[LastModifiedTime],[LastSyncTime]) Values 
(1,'Shift A',2, CAST(0x070010ACD1530000 AS Time), CAST(0x07002058A3A70000 AS Time), N'1',  CAST(12.00 AS Decimal(18, 2)), 1,0,'2015-01-02 14:09:21.057',NULL);
INSERT INTO [TCD].[ShiftData] ([ShiftId],[ShiftName], [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [TargetProduction],[LastModifiedByUserId],[Is_Deleted],[LastModifiedTime],[LastSyncTime]) Values 
( 2,'Shift A',3, CAST(0x070010ACD1530000 AS Time), CAST(0x07002058A3A70000 AS Time), N'1',  CAST(12.00 AS Decimal(18, 2)),  1,0,'2015-01-02 14:09:21.057',NULL);
INSERT INTO [TCD].[ShiftData] ([ShiftId],[ShiftName], [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [TargetProduction],[LastModifiedByUserId],[Is_Deleted],[LastModifiedTime],[LastSyncTime]) Values 
( 3,'Shift A',4, CAST(0x070010ACD1530000 AS Time), CAST(0x07002058A3A70000 AS Time), N'1',  CAST(12.00 AS Decimal(18, 2)),  1,0,'2015-01-02 14:09:21.057',NULL);
INSERT INTO [TCD].[ShiftData] ([ShiftId],[ShiftName], [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [TargetProduction],[LastModifiedByUserId],[Is_Deleted],[LastModifiedTime],[LastSyncTime]) Values 
( 4,'Shift A',5, CAST(0x070010ACD1530000 AS Time), CAST(0x07002058A3A70000 AS Time), N'1',  CAST(12.00 AS Decimal(18, 2)),  1,0,'2015-01-02 14:09:21.057',NULL);
INSERT INTO [TCD].[ShiftData] ([ShiftId],[ShiftName], [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [TargetProduction],[LastModifiedByUserId],[Is_Deleted],[LastModifiedTime],[LastSyncTime]) Values 
( 5,'Shift A',6, CAST(0x070010ACD1530000 AS Time), CAST(0x07002058A3A70000 AS Time), N'1',  CAST(12.00 AS Decimal(18, 2)),  1,0,'2015-01-02 14:09:21.057',NULL);



---Insert for shift breakdata

GO
INSERT [tcd].[ShiftBreakData] ([ShiftId],  [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [LastModifiedByUserId],[IS_Deleted]) VALUES ( 1, 2, CAST(0x07007870335C0000 AS Time), CAST(0x0700E03495640000 AS Time), N'1',1,0)
GO
INSERT [tcd].[ShiftBreakData] ([ShiftId],  [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [LastModifiedByUserId],[IS_Deleted]) VALUES ( 1, 2, CAST(0x07007870335C0000 AS Time), CAST(0x0700E03495640000 AS Time), N'1',1,0)
GO
INSERT [tcd].[ShiftBreakData] ([ShiftId],  [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [LastModifiedByUserId],[IS_Deleted]) VALUES ( 1, 3, CAST(0x07007870335C0000 AS Time), CAST(0x0700E03495640000 AS Time), N'1', 1,0)
GO
INSERT [tcd].[ShiftBreakData] ([ShiftId], [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [LastModifiedByUserId],[IS_Deleted])VALUES ( 1, 4, CAST(0x07007870335C0000 AS Time), CAST(0x0700E03495640000 AS Time), N'1',1,0)
GO
INSERT [tcd].[ShiftBreakData] ([ShiftId],  [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [LastModifiedByUserId],[IS_Deleted]) VALUES ( 1, 5, CAST(0x07007870335C0000 AS Time), CAST(0x0700E03495640000 AS Time), N'1', 1,0)
GO
INSERT [tcd].[ShiftBreakData] ([ShiftId], [DayId], [StartTime], [EndTime], [EcolabAccountNumber],  [LastModifiedByUserId],[IS_Deleted]) VALUES ( 1, 6, CAST(0x07007870335C0000 AS Time), CAST(0x0700E03495640000 AS Time), N'1', 1,0)

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

Go
insert tcd.ShiftLaborData (ShiftId,DayId,LaborHours,PricePerHr,LaborTypeId,LocationId,LastModifiedByUserId)values(1,2,5,5,1,1,1)
Go
insert tcd.ShiftLaborData(ShiftId,DayId,LaborHours,PricePerHr,LaborTypeId,LocationId,LastModifiedByUserId)values(1,3,5,5,1,2,1)
Go
insert tcd.ShiftLaborData(ShiftId,DayId,LaborHours,PricePerHr,LaborTypeId,LocationId,LastModifiedByUserId)values(1,4,5,5,1,2,1)
Go
insert tcd.ShiftLaborData(ShiftId,DayId,LaborHours,PricePerHr,LaborTypeId,LocationId,LastModifiedByUserId)values(1,5,5,5,1,3,1)
Go
insert tcd.ShiftLaborData(ShiftId,DayId,LaborHours,PricePerHr,LaborTypeId,LocationId,LastModifiedByUserId)values(1,6,5,5,1,3,1)


--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

insert into [TCD].laborcost(LaborTypeId,Cost,EcolabAccountNumber,LastModifiedByUserId,LastModifiedTime,LastSyncTime)values(1,10,1,1'2015-01-05 12:01:32.333',NULL),(2,11,1,1'2015-01-05 12:01:32.333',NULL),(3,12,1,1'2015-01-05 12:01:32.333',NULL),(4,13,1,1'2015-01-05 12:01:32.333',NULL);

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [TCD].[ProductdataMapping] ( [ProductID], [SKU], [Cost], [Is_Deleted], [IncludeCI], [EcolabAccountNumber], [IsMigrated], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime]) VALUES 
( 1, N'CHEM1', 12, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09CB AS DateTime), NULL)
,( 4, N'CHEM14', 456, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09D4 AS DateTime), NULL)
 ,( 6, N'CHEM16', 7898, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09D4 AS DateTime), NULL)
 ,( 3, N'CHEM13', 0, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09D4 AS DateTime), NULL)
 ,( 5, N'CHEM15         ', 2334, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09D9 AS DateTime), NULL)
 ,( 41, N'CHEM63         ', 123.45, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09DD AS DateTime), NULL)
 ,( 17, N'CHEM36         ', 47, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09DD AS DateTime), NULL)
 ,( 8, N'CHEM28         ', 2467, 0, 1, N'1', NULL, 1, CAST(0x0000A419006A09E2 AS DateTime), NULL)
 ,( 10, N'CHEM3          ', 53, 0, 0, N'1', NULL, 1, CAST(0x0000A419006A09E2 AS DateTime), NULL)
 ,( 2, N'CHEM12         ', 124, 0, 0, N'1', NULL, 1, CAST(0x0000A419006A09E2 AS DateTime), NULL)



--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [TCD].[PlantCustomer] ( [CustomerId], [CustomerName], [Is_Deleted], [LastModifiedByUserId], [EcolabAccountNumber], [LastModifiedTime], [LastSyncTime]) VALUES ( 1, N'SyamBenegal', 0, 1, N'1', CAST(0x0000A41900671133 AS DateTime), NULL)

,( 2, N'RamBenegal', 0, 1, N'1', CAST(0x0000A41900671138 AS DateTime), NULL)


--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

insert into tcd.GroupType(GroupDescription,GroupMaintype,EcolabAccountNumber,Is_Deleted,LastModifiedByUserId,LastModifiedTime,LastSyncTime)values('Plant','Plant',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('WasherExtractor1','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('WasherExtractor2','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('WasherExtractor(Automated)','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('Tunnel Washer1','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('Tunnel Washer2','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('Tunnel Washer3','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('Tunnel Washer4','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)

,('Washer Group1','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('Washer Group2','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)
,('Washer Group3','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)

,('WasherGroup4','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)

,('Washergroup5','WasherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)

,('DryerGroup3','DryerGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)

,('Finisher Group1','FinnisherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)

('Finisher Group2','FinnisherGroup',1,0,1,'2015-01-05 12:14:20.000',NULL)


--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

INSERT [TCD].[WasherGroup] ([WasherGroupId], [ControllerId], [WasherGroupTypeId], [WasherGroupName], [WasherGroupNumber], [LastModifiedByUserId]) VALUES (1, 1, 1, N'Plant', N'1', 1)
 
 ,(2, 1, 1, N'WasherExtractor1', N'2', 1)
 
 ,(3, 1, 1, N'WasherExtractor2', N'2', 1)
 
 ,(4, 1, 1, N'WasherExtractor(Automated)', N'2', 1)
 
,(5, 1, 2, N'TunnelWasher1', N'2', 1)
 
 ,(6, 1, 2, N'TunnelWasher2', N'2', 1)
 
,(7, 1, 2, N'TunnelWasher3', N'2', 1)
 
 ,(8, 1, 2, N'TunnelWasher4', N'2', 1)
 
,(9, 1, 1, N'Washergroup1', N'1', 1)
 
(10, NULL, 1, N'125 WASHEX', N'4', 1)
,(11, NULL, 1, N'425 LAVATEC', N'5', 1)
,(12, NULL, 1, N'450 BRIM ROWS 5 & 6', N'6', 1)
,(13, NULL, 2, N'250 MILNOR CBW', N'7', 1)

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------



DECLARE @ProgNo INT = 1
WHILE(@ProgNo < = 8)
BEGIN
INSERT INTO TCD.WasherProgramSetup(EcolabAccountNumber,WasherGroupId,ProgramNumber,ProgramId,NominalLoad,TotalRunTime,TotalSteps,LoadsPerMonth,LastModifiedByUserId)
SELECT 1,10,@ProgNo,@ProgNo,150,7200,4,100,1
SET @ProgNo = @ProgNo + 1
END

GO
DECLARE @ProgNo INT = 9
WHILE(@ProgNo < = 18)
BEGIN
INSERT INTO TCD.WasherProgramSetup(EcolabAccountNumber,WasherGroupId,ProgramNumber,ProgramId,NominalLoad,TotalRunTime,TotalSteps,LoadsPerMonth,LastModifiedByUserId)
SELECT 1,11,@ProgNo,@ProgNo,150,7200,4,100,1
SET @ProgNo = @ProgNo + 1
END

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

INSERT INTO TCD.WasherDosingSetup(EcoLabAccountNumber,WasherProgramSetupId,GroupId,ProgramNumber,StepNumber,StepRunTime,LastModifiedByUserId)
SELECT 1,1,10,1,1,1800,1 UNION ALL
SELECT 1,1,10,1,2,1800,1 UNION ALL
SELECT 1,1,10,1,3,1800,1 UNION ALL
SELECT 1,1,10,1,4,1800,1 
UNION ALL
SELECT 1,2,10,1,1,1800,1 UNION ALL
SELECT 1,2,10,1,2,1800,1 UNION ALL
SELECT 1,2,10,1,3,1800,1 UNION ALL
SELECT 1,2,10,1,4,1800,1 
UNION ALL
SELECT 1,3,10,1,1,1800,1 UNION ALL
SELECT 1,3,10,1,2,1800,1 UNION ALL
SELECT 1,3,10,1,3,1800,1 UNION ALL
SELECT 1,3,10,1,4,1800,1 
UNION ALL
SELECT 1,4,10,1,1,1800,1 UNION ALL
SELECT 1,4,10,1,2,1800,1 UNION ALL
SELECT 1,4,10,1,3,1800,1 UNION ALL
SELECT 1,4,10,1,4,1800,1 
UNION ALL
SELECT 1,5,10,1,1,1800,1 UNION ALL
SELECT 1,5,10,1,2,1800,1 UNION ALL
SELECT 1,5,10,1,3,1800,1 UNION ALL
SELECT 1,5,10,1,4,1800,1 
UNION ALL
SELECT 1,6,11,1,1,1800,1 UNION ALL
SELECT 1,6,11,1,2,1800,1 UNION ALL
SELECT 1,6,11,1,3,1800,1 UNION ALL
SELECT 1,6,11,1,4,1800,1 
UNION ALL
SELECT 1,7,11,1,1,1800,1 UNION ALL
SELECT 1,7,11,1,2,1800,1 UNION ALL
SELECT 1,7,11,1,3,1800,1 UNION ALL
SELECT 1,7,11,1,4,1800,1 
UNION ALL
SELECT 1,8,11,1,1,1800,1 UNION ALL
SELECT 1,8,11,1,2,1800,1 UNION ALL
SELECT 1,8,11,1,3,1800,1 UNION ALL
SELECT 1,8,11,1,4,1800,1 
UNION ALL
SELECT 1,9,11,1,1,1800,1 UNION ALL
SELECT 1,9,11,1,2,1800,1 UNION ALL
SELECT 1,9,11,1,3,1800,1 UNION ALL
SELECT 1,9,11,1,4,1800,1 
UNION ALL
SELECT 1,10,11,1,1,1800,1 UNION ALL
SELECT 1,10,11,1,2,1800,1 UNION ALL
SELECT 1,10,11,1,3,1800,1 UNION ALL
SELECT 1,10,11,1,4,1800,1 

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

INSERT INTO TCD.WasherDosingProductMapping(EcoLabAccountNumber,WasherDosingSetupId,InjectionNumber,ProductId,Quantity,LastModifiedByUserId)
SELECT 1,3,1,2,3.00,1
UNION ALL
SELECT 1,4,1,2,4.00,1
UNION ALL
SELECT 1,5,1,4,5.00,1
UNION ALL
SELECT 1,6,1,5,2.00,1
UNION ALL
SELECT 1,7,1,6,4.00,1
UNION ALL
SELECT 1,8,1,8,3.00,1
UNION ALL
SELECT 1,9,1,8,6.00,1
UNION ALL
SELECT 1,10,1,1,2.00,1
UNION ALL
SELECT 1,11,1,10,1.00,1
UNION ALL
SELECT 1,12,1,3,4.00,1
UNION ALL
SELECT 1,13,1,4,5.00,1
UNION ALL
SELECT 1,14,1,5,2.00,1
UNION ALL
SELECT 1,15,1,6,4.00,1
UNION ALL
SELECT 1,16,1,8,3.00,1
UNION ALL
SELECT 1,17,1,8,6.00,1
UNION ALL
SELECT 1,18,1,1,2.00,1
UNION ALL
SELECT 1,19,1,10,1.00,1
UNION ALL
SELECT 1,20,1,10,1.00,1
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT INTO TCD.TunnelDosingProductMapping(EcoLabAccountNumber,TunnelDosingSetupId,InjectionNumber,ProductId,Quantity,LastModifiedByUserId)
SELECT 1,3,1,1,3.00,1
UNION ALL
SELECT 1,4,1,2,4.00,1
UNION ALL
SELECT 1,5,1,3,5.00,1
UNION ALL
SELECT 1,6,1,4,2.00,1
UNION ALL
SELECT 1,7,1,5,4.00,1
UNION ALL
SELECT 1,8,1,6,3.00,1
UNION ALL
SELECT 1,9,1,8,6.00,1
UNION ALL
SELECT 1,10,1,10,2.00,1
UNION ALL
SELECT 1,11,1,17,1.00,1
UNION ALL
SELECT 1,12,1,41,4.00,1

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

SET IDENTITY_INSERT [TCD].[ConduitController] ON
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(1, N'1', N'UNIT3', 4001, 1, 1, NULL, NULL, N'Dober Ultrax System #3', N'4001 (Ultrax 6/12/16- Allen Bradley)', 0, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(2, N'1', N'UNIT4', 4002, 1, 1, NULL, NULL, N'Dober Ultrax System #4', N'4002 (Ultrax 6/12/16- Allen Bradley)', 0, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(3, N'1', N'UNIT5', 4003, 1, 1, NULL, NULL, N'Dober Ultrax System #5', N'4003 (Ultrax 6/12/16- Allen Bradley)', 1, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(4, N'1', N'UNIT7', 4004, 1, 1, NULL, NULL, N'Dober Ultrax System #7', N'4004 (Ultrax 6/12/16- Allen Bradley)', 1, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(5, N'1', N'UNIT6', 4005, 1, 1, NULL, NULL, N'Dober Ultrax System #6', N'4005 (Ultrax 6/12/16- Allen Bradley)', 1, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(6, N'1', N'TANKS', 4006, 5, 1, NULL, NULL, N'Tank Levels', N'4006 (Utilitty logger- Allen Bradley)', 1, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(7, N'1', N'OPTRAX', 4007, 5, 1, NULL, NULL, N'OPTRAX', N'4007 (Utilitty logger- Allen Bradley)', 1, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(8, N'1', N'UNIT10', 4008, 1, 1, NULL, NULL, N'TDi System #1', N'4008 (Ultrax 6/12/16- Allen Bradley)', 1, 0, NULL, 1)
INSERT [TCD].[ConduitController] ([ControllerId], [EcoalabAccountNumber], [TopicName], [ControllerNumber], [ControllerModelId], [ControllerTypeId], [ControllerVersion], [InstallDate], [Description], [Name], [Active], [IsDeleted], [LastConnectedTime], [LastModifiedByUserId] ) VALUES 
(9, N'1', N'UNIT9', 4009, 13, 1, NULL, NULL, N'Dober Ultrax System #9', N'4009 (Ultrax TDi- Allen Bradley)', 1, 0, NULL, 1)
SET IDENTITY_INSERT [TCD].[ConduitController] OFF




--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
SET IDENTITY_INSERT [TCD].[ControllerSetupData] ON
INSERT [TCD].[ControllerSetupData] (  [ControllerId], [FieldGroupId], [FieldId], [Value], [FieldTagValue], [ControllerModelId], [LastModifiedByUserId]) VALUES 
 ( 1, 7, 69, N'99', NULL, 1, 1)
,( 1, 7, 70, N'6', NULL, 1, 1)
,( 1, 7, 71, N'10', NULL, 1, 1)
,( 1, 7, 12, N'10', NULL, 1, 1)
,( 1, 7, 15, N'30', NULL, 1, 1)
,(1, 5, 19, N'30-12-1899 00:00:00', NULL, 1, 1)
,( 1, 5, 68, N'1', NULL, 1, 1)
,( 1, 5, 66, N'10.000', NULL, 1, 1)
,( 1, 5, 67, N'10.000', NULL, 1, 1)
,( 1, 5, 11, N'RSLinx OPC Server', NULL, 1, 1)
,( 1, 5, 72, N'false', NULL, 1, 1)
, ( 1, 5, 73, N'', NULL, 1, 1)
,( 1, 5, 74, N'', NULL, 1, 1)
,( 1, 5, 75, N'', NULL, 1, 1)
,( 2, 7, 69, N'99', NULL, 1, 1)
,( 2, 7, 70, N'6', NULL, 1, 1)
,( 2, 7, 71, N'10', NULL, 1, 1)
,( 2, 7, 12, N'10', NULL, 1, 1)
,( 2, 7, 15, N'30', NULL, 1, 1)
,( 2, 5, 19, N'30-12-1899 00:00:00', NULL, 1, 1)
,( 2, 5, 68, N'1', NULL, 1, 1)
,( 2, 5, 66, N'10.000', NULL, 1, 1)
,( 2, 5, 67, N'10.000', NULL, 1, 1)
,( 2, 5, 11, N'RSLinx OPC Server', NULL, 1, 1)
,( 2, 5, 72, N'false', NULL, 1, 1)
,( 2, 5, 73, N'', NULL, 1, 1)
,( 2, 5, 74, N'', NULL, 1, 1)
,( 2, 5, 75, N'', NULL, 1, 1)
,( 3, 7, 69, N'99', NULL, 1, 1)
,( 3, 7, 70, N'6', NULL, 1, 1)
,( 3, 7, 71, N'10', NULL, 1, 1)
,( 3, 7, 12, N'10', NULL, 1, 1)
,( 3, 7, 15, N'30', NULL, 1, 1)
,( 3, 5, 19, N'30-12-1899 00:00:00', NULL, 1, 1)
,( 3, 5, 68, N'1', NULL, 1, 1)
,( 3, 5, 66, N'10.000', NULL, 1, 1)
,( 3, 5, 67, N'10.000', NULL, 1, 1)
,( 3, 5, 11, N'Matrikon.OPC.Simulation.1', NULL, 1, 1)
,( 3, 5, 73, N'ftp://localhost/webportfiles1/', NULL, 1, 1)
,( 3, 5, 74, N'hyellinedi', NULL, 1, 1)
,( 3, 5, 75, N'mango123$', NULL, 1, 1)
,( 4, 7, 69, N'99', NULL, 1, 1)
,( 4, 7, 70, N'6', NULL, 1, 1)
,( 4, 7, 71, N'10', NULL, 1, 1)
,( 4, 7, 12, N'10', NULL, 1, 1)
,( 4, 7, 15, N'30', NULL, 1, 1)
,( 4, 5, 19, N'30-12-1899 00:00:00', NULL, 1, 1)
,( 4, 5, 68, N'1', NULL, 1, 1)
,( 4, 5, 66, N'10.000', NULL, 1, 1)
,( 4, 5, 67, N'10.000', NULL, 1, 1)
,( 4, 5, 11, N'Matrikon.OPC.Simulation.1', NULL, 1, 1)
,( 4, 5, 72, N'True', NULL, 1, 1)
,( 4, 5, 73, N'ftp://localhost/webportfiles1/', NULL, 1, 1)
,( 4, 5, 74, N'hyellinedi', NULL, 1, 1)
, ( 4, 5, 75, N'mango123$', NULL, 1, 1)
,( 5, 7, 69, N'99', NULL, 1, 1)
,( 5, 7, 70, N'6', NULL, 1, 1)
,( 5, 7, 71, N'10', NULL, 1, 1)
,( 5, 7, 12, N'10', NULL, 1, 1)
,( 5, 7, 15, N'30', NULL, 1, 1)
,( 5, 5, 19, N'30-12-1899 00:00:00', NULL, 1, 1)
, ( 5, 5, 68, N'1', NULL, 1, 1)
,( 5, 5, 66, N'10.000', NULL, 1, 1)
,( 5, 5, 67, N'10.000', NULL, 1, 1)
,( 5, 5, 11, N'Matrikon.OPC.Simulation.1', NULL, 1, 1)
,( 5, 5, 72, N'False', NULL, 1, 1)
, ( 5, 5, 73, N'ftp://localhost/webportfiles1/', NULL, 1, 1)
,( 5, 5, 74, N'hyellinedi', NULL, 1, 1)
,( 5, 5, 75, N'mango123$', NULL, 1, 1)
,(6, 7, 69, N'1', NULL, 5, 1)
,( 6, 7, 70, N'1', NULL, 5, 1)
,( 6, 7, 71, N'0', NULL, 5, 1)
,( 6, 7, 12, N'10', NULL, 5, 1)
,( 6, 7, 15, N'30', NULL, 5, 1)
,( 6, 5, 19, N'14-01-2010 09:04:02', NULL, 5, 1)
,( 6, 5, 68, N'1', NULL, 5, 1)
, ( 6, 5, 66, N'10.000', NULL, 5, 1)
, ( 6, 5, 67, N'10.000', NULL, 5, 1)
, ( 6, 5, 11, N'Matrikon.OPC.Simulation.1', NULL, 5, 1)
, ( 6, 5, 72, N'false', NULL, 5, 1)
,( 6, 5, 73, N'', NULL, 5, 1)
,( 6, 5, 74, N'', NULL, 5, 1)
, ( 6, 5, 75, N'', NULL, 5, 1)
, ( 7, 7, 69, N'1', NULL, 5, 1)
,( 7, 7, 70, N'1', NULL, 5, 1)
,( 7, 7, 71, N'0', NULL, 5, 1)
, ( 7, 7, 12, N'10', NULL, 5, 1)
,( 7, 7, 15, N'30', NULL, 5, 1)
, ( 7, 5, 19, N'05-01-2011 13:05:17', NULL, 5, 1)
,( 7, 5, 68, N'1', NULL, 5, 1)
,( 7, 5, 66, N'10.000', NULL, 5, 1)
,( 7, 5, 67, N'10.000', NULL, 5, 1)
, ( 7, 5, 11, N'Matrikon.OPC.Simulation.1', NULL, 5, 1)
, ( 7, 5, 72, N'false', NULL, 5, 1)
, ( 7, 5, 73, N'', NULL, 5, 1)
,( 7, 5, 74, N'', NULL, 5, 1)
, ( 7, 5, 75, N'', NULL, 5, 1)
,( 8, 7, 69, N'99', NULL, 1, 1)
,( 8, 7, 70, N'6', NULL, 1, 1)
SET IDENTITY_INSERT [TCD].[ControllerSetupData] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
SET IDENTITY_INSERT [TCD].[Washer] ON
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (1, N'1', NULL, 41, 910, 1, 250, 0, 99, NULL, 0, 1, 1, NULL, 1, NULL, 0, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (2, N'1', NULL, 37, 488, 1, 125, 0, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 40, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (3, N'1', NULL, 38, 488, 1, 125, 0, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 40, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (4, N'1', NULL, 39, 488, 1, 125, 0, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 40, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (5, N'1', NULL, 40, 488, 1, 125, 0, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 40, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (6, N'1', NULL, 1, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (7, N'1', NULL, 2, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (8, N'1', NULL, 3, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (9, N'1', NULL, 4, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (10, N'1', NULL, 5, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (11, N'1', NULL, 6, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (12, N'1', NULL, 7, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (13, N'1', NULL, 8, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (14, N'1', NULL, 9, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (15, N'1', NULL, 10, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (16, N'1', NULL, 11, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (17, N'1', NULL, 12, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (18, N'1', NULL, 13, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (19, N'1', NULL, 14, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (20, N'1', NULL, 15, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (21, N'1', NULL, 16, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (22, N'1', NULL, 17, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (23, N'1', NULL, 18, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (24, N'1', NULL, 19, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (25, N'1', NULL, 20, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (26, N'1', NULL, 21, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (27, N'1', NULL, 22, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (28, N'1', NULL, 23, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (29, N'1', NULL, 24, 585, 1, 425, 1, 99, N'', 0, NULL, NULL, 0, 1, 0, 0, 1, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (30, N'1', NULL, 25, 365, 1, 450, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 70, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (31, N'1', NULL, 26, 365, 1, 450, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 70, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (32, N'1', NULL, 27, 365, 1, 450, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 70, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (33, N'1', NULL, 28, 365, 1, 450, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 70, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (34, N'1', NULL, 29, 365, 1, 450, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 70, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (35, N'1', NULL, 30, 365, 1, 450, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 70, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (36, N'1', NULL, 31, 585, 1, 425, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 60, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (37, N'1', NULL, 32, 585, 1, 425, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 60, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (38, N'1', NULL, 33, 585, 1, 425, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 60, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (39, N'1', NULL, 34, 585, 1, 425, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 60, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (40, N'1', NULL, 35, 585, 1, 425, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 80, 0, 1)
INSERT [TCD].[Washer] ([WasherId], [EcoLabAccountNumber], [EcolabWasherId], [PlantWasherNumber], [ModelId], [WasherMode], [MaxLoad], [AWEActive], [EndOfFormula], [Description], [NumberOfTanks], [TransferType], [PressExtractor], [HoldSignal], [HoldDelay], [TargetTurnTime], [WaterFlushTime], [Is_Deleted], [LastModifiedByUserId]) VALUES (41, N'1', NULL, 36, 585, 1, 425, 1, 99, NULL, NULL, NULL, NULL, 0, 1, 0, 60, 0, 1)
SET IDENTITY_INSERT [TCD].[Washer] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

INSERT [TCD].[MachineSetup] ([WasherId], [GroupId], [MachineInternalId], [EcoalabAccountNumber], [ControllerId], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress], [IsDeleted], [LastModifiedByUserId]) VALUES 
  (1, 2, 1, N'1', 1, NULL, N'R 1 W 4 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(2, 2, 2, N'1', 1, NULL, N'R 1 W 5 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(3, 2, 3, N'1', 1, NULL, N'R 1 W 6 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(4, 2, 4, N'1', 1, NULL, N'R 2 W 1 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(5, 2, 5, N'1', 1, NULL, N'R 2 W 2 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(6, 3, 1, N'1', 2, NULL, N'R 2 W 3 Lavatec 421 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(7, 3, 2, N'1', 2, NULL, N'R 2 W 4 Lavatec 421 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(8, 3, 3, N'1', 2, NULL, N'R 2 W 5 Lavatec 421 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(9, 3, 4, N'1', 2, NULL, N'R 2 W 6 Lavatec 421 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(10, 3, 5, N'1', 2, NULL, N'R 3 W 1 Lavatec 421 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(11, 4, 1, N'1', 2, NULL, N'R 3 W 2 Lavatec 426 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(12, 4, 2, N'1', 2, NULL, N'R 3 W 3 Lavatec 426 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(13, 4, 3, N'1', 2, NULL, N'R 3 W 4 Lavatec 426 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(14, 4, 4, N'1', 2, NULL, N'R 3 W 5 Lavatec 426 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(15, 4, 5, N'1', 2, NULL, N'R 3 W 6 Lavatec 426 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(16, 5, 1, N'1', 3, NULL, N'PONY #4 Washex 125 MP', 16, NULL, NULL, N'WASHEX', NULL, 0, 1, NULL, 0, 1)
 ,(17, 6, 1, N'1', 4, NULL, N'R1 W 1 Lavatec 425 Lavatec', 15, NULL, NULL, N'LAVATEC', NULL, 0, 1, NULL, 0, 1)
 ,(18, 7, 1, N'1', 5, NULL, N'R 1 W 2 Lavatec 425 Lavatec', 14, NULL, NULL, N'LAVATEC', NULL, 0, 1, NULL, 0, 1)
 ,(19, 8, 1, N'1', 6, NULL, N'R 1 W 3 Lavatec 425 Lavatec', 13, NULL, NULL, N'LAVATEC', NULL, 0, 1, NULL, 0, 1)
 ,(20, 9, 1, N'1', 1, NULL, N'R 5 W 1 Brim 450 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(21, 9, 2, N'1', 1, NULL, N'R 5 W 2 Brim 450 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(22, 9, 3, N'1', 1, NULL, N'R 5 W 3 Brim 450 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(23, 9, 4, N'1', 1, NULL, N'R 5 W 4 Brim 450 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(24, 9, 5, N'1', 1, NULL, N'R 5 W 5 Brim 450 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(25, 9, 6, N'1', 1, NULL, N'R 5 W 6 Brim 450 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(26, 10, 1, N'1', 7, NULL, N'PONY #1 Washex 125 MP', 0, NULL, NULL, N'WASHEX', NULL, 0, 0, NULL, 0, 1)
 ,(27, 10, 2, N'1', 7, NULL, N'PONY #2 Washex 125 MP', 0, NULL, NULL, N'WASHEX', NULL, 0, 0, NULL, 0, 1)
 ,(28, 10, 3, N'1', 7, NULL, N'PONY #3 Washex 125 MP', 0, NULL, NULL, N'WASHEX', NULL, 0, 0, NULL, 0, 1)
 ,(29, 11, 1, N'1', 7, NULL, N'R 4 W 1 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(30, 11, 2, N'1', 7, NULL, N'R 4 W 2 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(31, 11, 3, N'1', 7, NULL, N'R 4 W 3 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(32, 11, 4, N'1', 7, NULL, N'R 4 W 4 Lavatec 425 Lavatec', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(33, 12, 2, N'1', 8, NULL, N'R 5 W 2 Brim 412 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(34, 12, 3, N'1', 8, NULL, N'R 5 W 3 Brim 412 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(35, 12, 4, N'1', 8, NULL, N'R 5 W 4 Brim 412 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(36, 12, 5, N'1', 8, NULL, N'R 5 W 5 Brim 412 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(37, 12, 6, N'1', 8, NULL, N'R 5 W 6 Brim 412 Brim', 0, NULL, NULL, N'LAVATEC', NULL, 0, 0, NULL, 0, 1)
 ,(38, 13, 1, N'1', 9, NULL, N'MILNOR CBW', 10, NULL, NULL, N'WASHEX', NULL, 0, 1, NULL, 0, 1)

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

SET IDENTITY_INSERT [TCD].[Meter] ON
INSERT [TCD].[Meter] ( [Description], [UtilityType], [GroupId], [EcolabAccountNumber], [MaxValueLimit], [MeterTickUnit], [UsageFactor], [ControllerID], [Parent], [Calibration], [DigitalInputNumber], [AllowManualentry], [Is_deleted], [MachineCompartment], [Id], [CWMeterId], [LastModifiedByUserId], [LastSyncTime], [IsPlant], [IsPress]) VALUES ( N'WaterMeter1', N'2', 5, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 1, 0, 1, NULL, NULL, 1, NULL, NULL, NULL)
 
 ,( N'WaterMeter2', N'2', 5, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 0, 0, 2, NULL, NULL, 1, NULL, NULL, NULL)
 
 ,( N'WaterMeter3', N'2', 5, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 0, 0, 3, NULL, NULL, 1, NULL, NULL, NULL)
 
,( N'WaterMeter4', N'2', 5, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 0, 0, 4, NULL, NULL, 1, NULL, NULL, NULL)
 
 ,( N'WaterMeter5', N'2', 5, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 0, 0, 5, NULL, NULL, 1, NULL, NULL, NULL)
 
,( N'WaterMeter6', N'2', 5, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 0, 0, 6, NULL, NULL, 1, NULL, NULL, NULL)
 
 ,( N'WasherConMeter1', N'2', 2, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 0, 0, 1, NULL, NULL, 1, NULL, NULL, NULL)
 
 ,( N'WasherConMeter2', N'2', 2, N'1', 10000, N'gallon_per_minute', CAST(1.00 AS Decimal(18, 2)), 1, NULL, CAST(0.00000 AS Numeric(10, 5)), 1, 0, 0, 2, NULL, NULL, 1, NULL, NULL, NULL)

SET IDENTITY_INSERT [TCD].[Meter] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

SET IDENTITY_INSERT [TCD].[TankSetup] ON
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (1, N'Tank 1', N'1', N'CHEM1', CAST(250 AS Decimal(18, 0)), CAST(428 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(5000 AS Decimal(18, 0)), CAST(10 AS Decimal(18, 0)), CAST(3738 AS Decimal(18, 0)), 6, 1, NULL, 0, 1)
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (2, N'Tank 2', N'1', N'CHEM14', CAST(250 AS Decimal(18, 0)), CAST(802 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(5000 AS Decimal(18, 0)), CAST(10 AS Decimal(18, 0)), CAST(2888 AS Decimal(18, 0)), 6, 1, NULL, 0, 1)
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (3, N'Tank 3', N'1', N'CHEM16', CAST(213 AS Decimal(18, 0)), CAST(987 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(3000 AS Decimal(18, 0)), CAST(10 AS Decimal(18, 0)), CAST(2295 AS Decimal(18, 0)), 6, 1, NULL, 0, 1)
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (4, N'Tank 4', N'1', N'CHEM13', CAST(97 AS Decimal(18, 0)), CAST(138 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(1000 AS Decimal(18, 0)), CAST(10 AS Decimal(18, 0)), CAST(132 AS Decimal(18, 0)), 6, 1, NULL, 0, 1)
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (5, N'Tank 5', N'1', N'CHEM15', CAST(0 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(0 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), 6, 0, NULL, 0, 1)
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (6, N'Tank 6', N'1', N'CHEM14', CAST(0 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(250 AS Decimal(18, 0)), CAST(10 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), 6, 0, NULL, 0, 1)
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (7, N'Tank 7', N'1', N'CHEM16', CAST(0 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(250 AS Decimal(18, 0)), CAST(10 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), 6, 0, NULL, 0, 1)
INSERT [TCD].[TankSetup] ([TankId], [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES (8, N'Tank 8', N'1', N'CHEM1', CAST(0 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), NULL, NULL, NULL, CAST(250 AS Decimal(18, 0)), CAST(10 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), 6, 0, NULL, 0, 1)
SET IDENTITY_INSERT [TCD].[TankSetup] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

SET IDENTITY_INSERT [TCD].[Sensor] ON
INSERT [TCD].[Sensor] ( [Description], [SensorType], [GroupId], [MachineCompartment], [EcolabAccountNumber], [ControllerID], [OutputType], [Calibration4mA], [AnalogueInputNumber], [ChemicalforChart], [UOM], [DashboardActualValue], [Is_deleted], [Id], [LastModifiedByUserId], [IsPlant], [IsPress], [Calibration20mA]) VALUES ( N'T1', 1, 5, 1, N'1', 1, N'4-20mA', CAST(1.00 AS Decimal(18, 2)), 0, 1, N'Celsius', 0, 0, NULL, 1, 0, 0, CAST(1.00 AS Decimal(18, 2)))
 
 ,( N'T2', 1, 5, 2, N'1', 1, N'0-20mA', CAST(2.00 AS Decimal(18, 2)), 0, NULL, N'Celsius', 0, 0, NULL, 1, 0, 0, CAST(1.00 AS Decimal(18, 2)))
 
 ,( N'T3', 1, 5, 3, N'1', 1, N'0-20mA', CAST(3.00 AS Decimal(18, 2)), 0, 1, N'Celsius', 0, 0, NULL, 1, 0, 0, CAST(1.00 AS Decimal(18, 2)))
 
 ,( N'T4', 1, 5, 4, N'1', 1, N'0-20mA', CAST(4.00 AS Decimal(18, 2)), 0, 2, N'Celsius', 0, 0, NULL, 1, 0, 0, CAST(2.00 AS Decimal(18, 2)))
 
 ,( N'T5', 1, 5, 5, N'1', 1, N'4-20mA', CAST(4.00 AS Decimal(18, 2)), 0, 1, N'Celsius', 0, 0, NULL, 1, 0, 0, CAST(3.00 AS Decimal(18, 2)))
 
 ,( N'T6', 1, 5, 6, N'1', 1, N'4-20mA', CAST(4.00 AS Decimal(18, 2)), 0, 1, N'Celsius', 0, 0, NULL, 1, 0, 0, CAST(4.00 AS Decimal(18, 2)))
 
 ,( N'PH1', 2, 5, 1, N'1', 1, N'4-20mA', CAST(1.00 AS Decimal(18, 2)), 0, 1, N'pH', 0, 0, NULL, 1, 0, 0, CAST(5.00 AS Decimal(18, 2)))
 
 ,( N'PH2', 2, 5, 2, N'1', 1, N'0-20mA', CAST(2.00 AS Decimal(18, 2)), 0, NULL, N'pH', 0, 0, NULL, 1, 0, 0, CAST(6.00 AS Decimal(18, 2)))
 
,( N'Weight', 5, 5, 1, N'1', 1, N'0-20mA', CAST(1.00 AS Decimal(18, 2)), 0, 1, N'centigram', 0, 0, NULL, 1, 0, 0, CAST(7.00 AS Decimal(18, 2)))
 
 ,( N'Conductivity', 4, 5, 1, N'1', 1, N'4-20mA', CAST(2.00 AS Decimal(18, 2)), 0, 1, N'Btu_IT_per_Fahrenheit', 0, 0, NULL, 1, 0, 0, CAST(8.00 AS Decimal(18, 2)))
SET IDENTITY_INSERT [TCD].[Sensor] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
Set IDENTITY_INSERT [TCD].[WaterAndEnergy] ON
insert into tcd.WaterAndEnergy(DeviceNumber,DeviceName,GroupId,DeviceTypeId,DeviceModelId,DeviceNote,EcolabAccountNumber,Comment,InstallDate,Is_deleted,LastModifiedByUserId)values(1,'Device2',12,5,1,'Heat Reclaimer/Energy Optimiser',1,'Test',2014-11-03,0,1)
Set IDENTITY_INSERT [TCD].[WaterAndEnergy] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

INSERT [TCD].[RedFlag] ( [Item], [MaximumRange], [MinimumRange], [Location], [Is_Deleted], [EcolabAccountNumber], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime]) VALUES
 ( 2, 25, 20, 1, 0, N'1', 1, CAST(0x0000A419006F90D0 AS DateTime), NULL)
, ( 3, 20, 15, 2, 0, N'1', 1, CAST(0x0000A419006F90D0 AS DateTime), NULL)
, ( 4, 25, 20, 5, 0, N'1', 1, CAST(0x0000A419006F90D0 AS DateTime), NULL)
, ( 5, 25, 20, 2, 0, N'1', 1, CAST(0x0000A419006F90D0 AS DateTime), NULL)
, ( 6, 25, 20, 5, 0, N'1', 1, CAST(0x0000A419006F90D0 AS DateTime), NULL)

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [TCD].[RedFlagMappingData] ( [MappingId], [MachineId], [Is_Deleted], [EcolabAccountNumber], [LastModifiedByUserId]) VALUES 
( 1, 1, 0, N'1', 1)
,( 2, 2, 0, N'1', 1)
,( 3, 3, 0, N'1', 1)
,( 4, 4, 0, N'1', 1)
,( 5, 5, 0, N'1', 1)
,( 2, 1, 0, N'1', 1)
,( 3, 1, 0, N'1', 1)
,( 3, 2, 0, N'1', 1)
,( 4, 1, 0, N'1', 1)
,( 5, 4, 0, N'1', 1)
	

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [TCD].[Dryers] ( [DryerGroupId], [DryerNo], [Description], [Manufacturer], [Model], [Capacity], [BTU_Hour], [GasModule], [Burner_Mod], [Gas_Meter], [Burner_Met], [Consumption], [CustomerId], [EmpId], [SoilId], [EcolabAccountNumber], [Is_deleted], [DryerTypeId], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime]) VALUES ( 14, 1, N'Dryer-01', NULL, NULL, CAST(120 AS Decimal(18, 0)), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', 0, 2, 1, CAST(0x0000A41900739AD5 AS DateTime), NULL)

, ( 15, 1, N'Dryer-02', NULL, NULL, CAST(110 AS Decimal(18, 0)), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', 0, 2, 1, CAST(0x0000A41900739AD5 AS DateTime), NULL)


--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
SET IDENTITY_INSERT [TCD].[Finnishers] ON 
INSERT [TCD].[Finnishers] ([FinnisherGroupId], [FinnisherId], [FinnisherNo], [Name], [FinnisherTypeId], [EcolabAccountNumber], [Is_deleted], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime]) VALUES (16, 1, 1, N'Finisher-01', 2, N'1', 0, 1, CAST(0x0000A41900739AD5 AS DateTime), NULL)
SET IDENTITY_INSERT [TCD].[Finnishers] OFF

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
Insert into tcd.PlantUtilityFactor ([UtilityId],UtilityType, FactorType, Temparature, EnergyContent, Price, Location, FreeType,LastModifiedByUserId,
	LastSyncTime,EcolabAccountNumber,[LastModifiedTime],[EnergyContentUnit],[EnergyPriceUnit],[ElectricPriceUnit] ) values
	(1,'2', 'Cold', '27', '0', '16', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'ColdSoft', '19', '0', '10', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'ColdHard', '20', '0', '9', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'HotSoft', '25', '0', '11', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'HotHard', '31', '0', '8', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'Hot', '22', '0', '12', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'Tempered', '35', '0', '13', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'Waste', '23', '0', '14', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'Reuse', '27', '0', '7', '1', '1', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'Recycled', '33', '0', '10', '1', '2', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'2', 'Rinse', '17', '0', '20', '1', '3', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'1', 'Coal Brown', '0', '62', '21', '1', '4', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50'),
	(1,'1', 'Electricity', '0', '0', '22', '1', '0', '1',1,1,'2015-01-05 12:14:20.000',0,'50','50');

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [TCD].[TankSetup] ( [TankName], [EcoalabAccountNumber], [SKU], [LowAlarmLevel], [PurchaseLevel], [EmptyLevel], [CalibrationLevel], [InputType], [Size], [LevelDeviation], [CurrentLevel], [ControllerId], [Active], [MENumber], [Is_Deleted], [LastModifiedByUserId]) VALUES ( N'Tank 1', N'1', N'CHEM16', 250 , 428 , 2 , 0 , N'', 5000 , 10 , 3738 , 6, 1, NULL, 0, 1)
 ,( N'Tank 2', N'1', N'CHEM63', 97 , 138 , 0, 0 , N'', 100 , 10 , 132 , 6, 1, NULL, 0, 1)

 --------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [TCD].[AlarmData] ( [EcoalabAccountNumber], [AlarmCode], [ControllerId], [StartDate], [GroupId], [MachineNumber], [MENumber], [BatchId], [Valve], [DesiredQuatity], [MeasuredQuantity], [ProgramId], [TempStatus], [ProbeNumber], [IsActive], [UserId], [EndDate], [InjectionNumber], [MachineId]) VALUES ( N'1', 2, 5, '2014-12-29 12:17:39.337', NULL, 8, NULL, NULL, 0, NULL, NULL, 12, NULL, NULL, 0, NULL, '2014-12-29 12:18:40.337', NULL, NULL)
INSERT [TCD].[AlarmData] ( [EcoalabAccountNumber], [AlarmCode], [ControllerId], [StartDate], [GroupId], [MachineNumber], [MENumber], [BatchId], [Valve], [DesiredQuatity], [MeasuredQuantity], [ProgramId], [TempStatus], [ProbeNumber], [IsActive], [UserId], [EndDate], [InjectionNumber], [MachineId]) VALUES ( N'1', 2, 5, '2014-12-12 12:17:39.337', NULL, 8, NULL, NULL, 0, NULL, NULL, 13, NULL, NULL, 0, NULL,'2014-12-12 12:18:39.337', NULL, NULL)
INSERT [TCD].[AlarmData] ( [EcoalabAccountNumber], [AlarmCode], [ControllerId], [StartDate], [GroupId], [MachineNumber], [MENumber], [BatchId], [Valve], [DesiredQuatity], [MeasuredQuantity], [ProgramId], [TempStatus], [ProbeNumber], [IsActive], [UserId], [EndDate], [InjectionNumber], [MachineId]) VALUES ( N'1', 2, 5,'2014-11-05 12:17:39.337', NULL, 8, NULL, NULL, 0, NULL, NULL, 12, NULL, NULL, 0, NULL, '2014-11-05 12:18:40.111', NULL, NULL)
INSERT [TCD].[AlarmData] ( [EcoalabAccountNumber], [AlarmCode], [ControllerId], [StartDate], [GroupId], [MachineNumber], [MENumber], [BatchId], [Valve], [DesiredQuatity], [MeasuredQuantity], [ProgramId], [TempStatus], [ProbeNumber], [IsActive], [UserId], [EndDate], [InjectionNumber], [MachineId]) VALUES ( N'1', 2, 5, '2014-11-02 12:20:39.337', NULL, 8, NULL, NULL, 0, NULL, NULL, 12, NULL, NULL, 0, NULL,'2014-11-02 12:21:41.337', NULL, NULL)
INSERT [TCD].[AlarmData] ( [EcoalabAccountNumber], [AlarmCode], [ControllerId], [StartDate], [GroupId], [MachineNumber], [MENumber], [BatchId], [Valve], [DesiredQuatity], [MeasuredQuantity], [ProgramId], [TempStatus], [ProbeNumber], [IsActive], [UserId], [EndDate], [InjectionNumber], [MachineId]) VALUES ( N'1', 2, 5, '2014-09-02 11:15:39.337', NULL, 8, NULL, NULL, 0, NULL, NULL, 45, NULL, NULL, 0, NULL, '2014-09-02 11:16:41.337', NULL, NULL)
INSERT [TCD].[AlarmData] ( [EcoalabAccountNumber], [AlarmCode], [ControllerId], [StartDate], [GroupId], [MachineNumber], [MENumber], [BatchId], [Valve], [DesiredQuatity], [MeasuredQuantity], [ProgramId], [TempStatus], [ProbeNumber], [IsActive], [UserId], [EndDate], [InjectionNumber], [MachineId]) VALUES ( N'1', 2, 5, '2014-11-02 10:17:39.337', NULL, 8, NULL, NULL, 0, NULL, NULL, 29, NULL, NULL, 0, NULL, '2014-11-02 10:18:41.337', NULL, NULL)
INSERT [TCD].[AlarmData] ( [EcoalabAccountNumber], [AlarmCode], [ControllerId], [StartDate], [GroupId], [MachineNumber], [MENumber], [BatchId], [Valve], [DesiredQuatity], [MeasuredQuantity], [ProgramId], [TempStatus], [ProbeNumber], [IsActive], [UserId], [EndDate], [InjectionNumber], [MachineId]) VALUES ( N'1', 2, 5, '2014-10-11 12:11:39.337', NULL, 8, NULL, NULL, 0, NULL, NULL, 23, NULL, NULL, 0, NULL, '2014-10-11 12:12:41.337', NULL, NULL)
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
INSERT [TCD].[ProgramMaster] ([ProgramId], [Name], [ProgramTargetCost], [Pieces], [DepreciationCost], [TargetChemicalCost], [TargetWaterCost], [TargetEnergeyCost], [EcolabTextileCategoryId], [Rewash], [Weight], [PieceWeight], [EcolabSaturationId], [EcolabAccountNumber], [PlantProgramId], [ChainTextileId], [CustomerId], [Is_Deleted], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime]) 
VALUES (1, N'Aprons', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, CAST(400 AS Decimal(18, 0)), NULL, 1, N'1', 1, 1, NULL, 1, 1, CAST(0x0000A41400E6E3C6 AS DateTime), NULL)
 
, (2, N'Food', NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, CAST(100 AS Decimal(18, 0)), NULL, 2, N'1', 2, 2, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(3, N'Barrier Garments', NULL, NULL, NULL, NULL, NULL, NULL, 3, 0, CAST(200 AS Decimal(18, 0)), NULL, 2, N'1', 3, 3, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
 ,(4, N'Blanket-Thermal', NULL, NULL, NULL, NULL, NULL, NULL, 4, 0, CAST(300 AS Decimal(18, 0)), NULL, 3, N'1', 4, 4, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(5, N'Coats/Smocks', NULL, NULL, NULL, NULL, NULL, NULL, 5, 1, CAST(400 AS Decimal(18, 0)), NULL, 4, N'1', 5, 5, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(6, N'Coveralls', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(7, N'CRT', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(8, N'Fender Covers', NULL, 5, NULL, NULL, NULL, NULL, 5, 1, CAST(5 AS Decimal(18, 0)), NULL, 5, N'1', 5, 1, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(9, N'Special Processing  1234', NULL, 96, NULL, NULL, NULL, NULL, 5, 0, CAST(96 AS Decimal(18, 0)), NULL, 4, N'1', 4, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(10, N'Special Processing', NULL, 96, NULL, NULL, NULL, NULL, 3, 0, CAST(96 AS Decimal(18, 0)), NULL, 3, N'1', 3, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(11, N' wns', NULL, 9, NULL, NULL, NULL, NULL, 5, 1, CAST(9 AS Decimal(18, 0)), NULL, 4, N'1', 3, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(12, N'Grill Pads', NULL, 4, NULL, NULL, NULL, NULL, 5, 0, CAST(4 AS Decimal(18, 0)), NULL, 0, N'1', 0, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(13, N'IC Pads', NULL, 4, NULL, NULL, NULL, NULL, 2, 0, CAST(4 AS Decimal(18, 0)), NULL, 2, N'1', 2, 3, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(14, N'Jackets', NULL, 5, NULL, NULL, NULL, NULL, 3, 0, CAST(67 AS Decimal(18, 0)), NULL, 3, N'1', 2, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(15, N'Linen', NULL, 6, NULL, NULL, NULL, NULL, 1, 0, CAST(10 AS Decimal(18, 0)), NULL, 1, N'1', 1, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(16, N'Mats', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(17, N'Mops', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(18, N'Mops(Wet)', NULL, 4, NULL, NULL, NULL, NULL, 5, 0, CAST(4 AS Decimal(18, 0)), NULL, 4, N'1', 4, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(19, N'Napkins', NULL, 3, NULL, NULL, NULL, NULL, 3, 0, CAST(3 AS Decimal(18, 0)), NULL, 3, N'1', 3, 0, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(20, N'Scrubs', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(21, N'Pants', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(22, N'Pants (Exec)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(23, N'Sheets', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(24, N'Shirts', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(25, N'Shirts (Exec)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
, (26, N'Pillow Cases', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(27, N'Blood', NULL, 41, NULL, NULL, NULL, NULL, 1, 0, CAST(0 AS Decimal(18, 0)), NULL, 1, N'1', 1, 1, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(28, N'Table Tops', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(29, N'Bar Towels', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(30, N'Terry Towels', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(31, N'Massage/Beauty Towel', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(32, N'Towels (Dish)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(33, N'Mildew', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(34, N'Towels (Furniture)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(35, N'Towels (Glass)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(36, N'Towels (Massage)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(37, N'Towels (Print)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(38, N'Towels', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(39, N'Towels (Shop, New)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(40, N'Washcloths', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(41, N'Gloves', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(42, N'Stain', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(43, N'Baby Linen', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(44, N'New Linen', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(45, N'Towels (OR)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(46, N'Garments', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(47, N'TBD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(48, N'Dust', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(49, N'Wipers', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)
 
,(50, N'not used', N'0         ', 1, CAST(0.00 AS Decimal(18, 2)), NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1', NULL, NULL, NULL, 1, 0, CAST(0x0000A4100076E720 AS DateTime), NULL)

--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive], [SortOrder]) VALUES (1,  N'pH', NULL, 1,1, 2)
GO
INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive], [SortOrder]) VALUES (2,N'Temperature', NULL, 1,1, 3)
GO
INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive], [SortOrder]) VALUES (3,N'Conductivity', NULL, 1,1, 4)
GO
INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive], [SortOrder]) VALUES (4,N'Customer', NULL, 0,0, 1)
GO
INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive], [SortOrder]) VALUES (5,N'Formula Number', NULL, 0,1, 5)
GO
INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive], [SortOrder]) VALUES (6,N'Transfer Signal', NULL, 0,0, 6)
GO
INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive], [SortOrder]) VALUES (7, N'Weight', NULL, 0,1, 7)
GO
INSERT [TCD].[ConduitParameters] ([Id],[Name], [Description], [MandatoryCol],[IsActive],[SortOrder]) VALUES (8, N'DosingAmount', NULL, 0,1, 8)


--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

UPDATE TCD.ProgramMaster SET EcolabAccountNumber = 1