﻿--To populate Dimension* master set of tables

RAISERROR	('Starting DimensionalUnit MasterData script execution...', 0, 1)

DECLARE		@TableName			SYSNAME			--To hold name of the table currently being populated

IF	OBJECT_ID('tempdb..#Errors_DimensionalUnitMasterDataSetup')	IS	NULL
	BEGIN
			CREATE	TABLE	#Errors_DimensionalUnitMasterDataSetup	(
							Id					INT					IDENTITY(1, 1)
						,	TableName			SYSNAME				NOT	NULL
						,	ErrorNumber			INT					NOT	NULL
						,	ErrorMessage		NVARCHAR(2048)		NOT	NULL
						,	ErrorSeverity		INT					NOT	NULL
						,	ErrorState			INT					NULL
						,	ErrorProcedure		SYSNAME				NULL
						,	ErrorLine			INT					NULL
						)
	END
ELSE
	BEGIN
			TRUNCATE	TABLE	#Errors_DimensionalUnitMasterDataSetup
	END





BEGIN	TRY
/*	DimensionalUnitSystems

PRIMARY KEY: UnitSystemId
FK:	NONE 
Table is referenced by foreign key:
	 DimensionalUnitsDefaults: FK_DimensionalUnitsDefaults_DimensionalUnitSystems


*/
	BEGIN
		SET			@TableName				=			'DimensionalUnitSystems'
		RAISERROR	(@TableName, 0, 1)

		--Declare temp table variable to hold input data
		DECLARE	@tempDimensionalUnitSystems	TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	UnitSystemId				INT				PRIMARY	KEY
			,	UnitSystem					NVARCHAR(100)
			)

		--Populate temp table variable with the input data
		INSERT	@tempDimensionalUnitSystems	(
				UnitSystemId,		UnitSystem	)
		VALUES	(0	,N'DB Storage'		)
			,	(1	,N'US Default'		)
			,	(2	,N'Metrics Default'	)


		MERGE	[TCD].DimensionalUnitSystems			AS TARGET
		USING	@tempDimensionalUnitSystems		AS SOURCE
			ON	TARGET.UnitSystemId		=			SOURCE.UnitSystemId
		WHEN	NOT MATCHED		THEN
				INSERT	(UnitSystemId			,UnitSystem			)
				VALUES	(SOURCE.UnitSystemId	,SOURCE.UnitSystem	);
	END





/*	DimensionalUnits

PRIMARY KEY: Unit
FK:	NONE 
Table is referenced by foreign key:
	ConduitLocal.dbo.DimensionalSubunits: FK_DimensionalSubunits_DimensionalUnits
	ConduitLocal.dbo.DimensionalUsageKey: FK_DimensionalUsageKey_DimensionalUnits



*/
	BEGIN
		SET			@TableName				=			'DimensionalUnits'
		RAISERROR	(@TableName, 0, 1)

		--Declare temp table variable to hold input data
		DECLARE	@tempDimensionalUnits	TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	Unit						NVARCHAR(100)
			)

		--Populate temp table variable with the input data
		INSERT	@tempDimensionalUnits	(
				Unit					)
		VALUES	(	N'Acceleration'				)
			,	(	N'Area'						)
			,	(	N'AvailableEnergy'			)
			,	(	N'ConductivityElectrolytic'	)
			,	(	N'Density'					)
			,	(	N'Efficiency'				)
			,	(	N'ElectricCurrent'			)
			,	(	N'ElectricPotentialDifference'	)
			,	(	N'ElectricTariff'			)
			,	(	N'Energy'					)
			,	(	N'Entropy'					)
			,	(	N'Force'					)
			,	(	N'Fraction'					)
			,	(	N'Frequency'				)
			,	(	N'HeatDensity'				)
			,	(	N'HeatTransferCoefficient'	)
			,	(	N'Length'					)
			,	(	N'Mass'						)
			,	(	N'MassRate'					)
			,	(	N'MolarEntropy'				)
			,	(	N'MolarMass'				)
			,	(	N'NormalizedVolumeRate'		)
			,	(	N'pH'						)
			,	(	N'Power'					)
			,	(	N'Pressure'					)
			,	(	N'Price'					)
			,	(	N'ReciprocalLength'			)
			,	(	N'RelativeHumidity'			)
			,	(	N'SpecificHumidity'			)
			,	(	N'SpecificVolume'			)	
			,	(	N'Temperature'				)
			,	(	N'TemperatureInterval'		)
			,	(	N'TemperatureLapseRate'		)
			,	(	N'ThermalInsulance'			)
			,	(	N'Time'						)
			,	(	N'TimePerMass'				)
			,	(	N'Turbidity'				)
			,	(	N'Velocity'					)
			,	(	N'Viscosity'				)
			,	(	N'Volume'					)
			,	(	N'VolumeFlux'				)
			,	(	N'VolumeRate'				)
			,	(	N'VolumeRatioRate'			)
			,	(	N'Weight'					)
			,	(	N'Count'					)
			,	(	N'ElectricConsumption'		)
			,	(	N'Hardness'					)
			,	(	N'WaterHardness'			)



		MERGE	[TCD].DimensionalUnits			AS TARGET
		USING	@tempDimensionalUnits		AS SOURCE
			ON	TARGET.Unit					=			SOURCE.Unit
		WHEN	NOT MATCHED		THEN
				INSERT	(Unit			)
				VALUES	(SOURCE.Unit	);
	END





/*	DimensionalSubunits

PRIMARY KEY: Unit
FK:	REFERENCES DimensionalUnits (Unit) 
Table is referenced by foreign key:
	ConduitLocal.dbo.DimensionalSubunits: FK_DimensionalSubunits_DimensionalUnits
	ConduitLocal.dbo.DimensionalUsageKey: FK_DimensionalUsageKey_DimensionalUnits



*/
	BEGIN
		SET			@TableName				=			'DimensionalSubunits'
		RAISERROR	(@TableName, 0, 1)

		--Declare temp table variable to hold input data
		DECLARE	@tempDimensionalSubunits	TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	Unit						NVARCHAR(100)
			,	Subunit						NVARCHAR(100)
			)

		--Populate temp table variable with the input data
		INSERT	@tempDimensionalSubunits	(
				Unit	,Subunit				)
		VALUES	(	N'Acceleration'	,N'acceleration_of_free_fall_standard'	)
			,	(	N'Acceleration'	,N'attometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'centimeter_per_second_squared'	)
			,	(	N'Acceleration'	,N'decameter_per_second_squared'	)
			,	(	N'Acceleration'	,N'decimeter_per_second_squared'	)
			,	(	N'Acceleration'	,N'exameter_per_second_squared'	)
			,	(	N'Acceleration'	,N'femtometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'foot_per_second_squared'	)
			,	(	N'Acceleration'	,N'gal'	)
			,	(	N'Acceleration'	,N'gigameter_per_second_squared'	)
			,	(	N'Acceleration'	,N'hectometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'inch_per_second_squared'	)
			,	(	N'Acceleration'	,N'kilometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'megameter_per_second_squared'	)
			,	(	N'Acceleration'	,N'meter_per_second_squared'	)
			,	(	N'Acceleration'	,N'micrometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'millimeter_per_second_squared'	)
			,	(	N'Acceleration'	,N'nanometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'petameter_per_second_squared'	)
			,	(	N'Acceleration'	,N'picometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'terameter_per_second_squared'	)
			,	(	N'Acceleration'	,N'yoctometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'yottameter_per_second_squared'	)
			,	(	N'Acceleration'	,N'zeptometer_per_second_squared'	)
			,	(	N'Acceleration'	,N'zettameter_per_second_squared'	)
			,	(	N'Area'	,N'acre'	)
			,	(	N'Area'	,N'hectare'	)
			,	(	N'Area'	,N'square_attometer'	)
			,	(	N'Area'	,N'square_centimeter'	)
			,	(	N'Area'	,N'square_decameter'	)
			,	(	N'Area'	,N'square_decimeter'	)
			,	(	N'Area'	,N'square_exameter'	)
			,	(	N'Area'	,N'square_femtometer'	)
			,	(	N'Area'	,N'square_foot'	)
			,	(	N'Area'	,N'square_gigameter'	)
			,	(	N'Area'	,N'square_hectometer'	)
			,	(	N'Area'	,N'square_inch'	)
			,	(	N'Area'	,N'square_kilometer'	)
			,	(	N'Area'	,N'square_megameter'	)
			,	(	N'Area'	,N'square_meter'	)
			,	(	N'Area'	,N'square_micrometer'	)
			,	(	N'Area'	,N'square_mile'	)
			,	(	N'Area'	,N'square_millimeter'	)
			,	(	N'Area'	,N'square_nanometer'	)
			,	(	N'Area'	,N'square_petameter'	)
			,	(	N'Area'	,N'square_picometer'	)
			,	(	N'Area'	,N'square_terameter'	)
			,	(	N'Area'	,N'square_yard'	)
			,	(	N'Area'	,N'square_yoctometer'	)
			,	(	N'Area'	,N'square_yottameter'	)
			,	(	N'Area'	,N'square_zeptometer'	)
			,	(	N'Area'	,N'square_zettameter'	)
			,	(	N'AvailableEnergy'	,N'Btu_IT_per_pound'	)
			,	(	N'AvailableEnergy'	,N'Btu_th_per_pound'	)
			,	(	N'AvailableEnergy'	,N'calorie_IT_per_gram'	)
			,	(	N'AvailableEnergy'	,N'calorie_th_per_gram'	)
			,	(	N'AvailableEnergy'	,N'joule_per_kilogram'	)
			,	(	N'AvailableEnergy'	,N'kilojoule_per_kilogram'	)
			,	(	N'ConductivityElectrolytic'	,N'microSiemens_per_centimeter'	)
			,	(	N'ConductivityElectrolytic'	,N'microSiemens_per_meter'	)
			,	(	N'ConductivityElectrolytic'	,N'milliSiemens_per_centimeter'	)
			,	(	N'ConductivityElectrolytic'	,N'milliSiemens_per_meter'	)
			,	(	N'ConductivityElectrolytic'	,N'Siemens_per_centimeter'	)
			,	(	N'ConductivityElectrolytic'	,N'Siemens_per_meter'	)
			,	(	N'Count'	,N'each'	)
			,	(	N'Density'	,N'attogram_per_cubic_meter'	)
			,	(	N'Density'	,N'centigram_per_cubic_meter'	)
			,	(	N'Density'	,N'decagram_per_cubic_meter'	)
			,	(	N'Density'	,N'decigram_per_cubic_meter'	)
			,	(	N'Density'	,N'exagram_per_cubic_meter'	)
			,	(	N'Density'	,N'femtogram_per_cubic_meter'	)
			,	(	N'Density'	,N'gigagram_per_cubic_meter'	)
			,	(	N'Density'	,N'grain_per_cubic_foot'	)
			,	(	N'Density'	,N'grain_per_gallon'	)
			,	(	N'Density'	,N'gram_per_cubic_centimeter'	)
			,	(	N'Density'	,N'gram_per_cubic_meter'	)
			,	(	N'Density'	,N'gram_per_liter'	)
			,	(	N'Density'	,N'hectogram_per_cubic_meter'	)
			,	(	N'Density'	,N'kilogram_per_cubic_meter'	)
			,	(	N'Density'	,N'megagram_per_cubic_meter'	)
			,	(	N'Density'	,N'microgram_per_cubic_meter'	)
			,	(	N'Density'	,N'milligram_per_cubic_meter'	)
			,	(	N'Density'	,N'milligram_per_liter'	)
			,	(	N'Density'	,N'nanogram_per_cubic_meter'	)
			,	(	N'Density'	,N'ounce_per_cubic_inch'	)
			,	(	N'Density'	,N'ounce_per_gallon'	)
			,	(	N'Density'	,N'ounce_per_gallon_imperial'	)
			,	(	N'Density'	,N'petagram_per_cubic_meter'	)
			,	(	N'Density'	,N'picogram_per_cubic_meter'	)
			,	(	N'Density'	,N'pound_per_cubic_foot'	)
			,	(	N'Density'	,N'pound_per_cubic_inch'	)
			,	(	N'Density'	,N'pound_per_cubic_yard'	)
			,	(	N'Density'	,N'pound_per_gallon'	)
			,	(	N'Density'	,N'pound_per_gallon_imperial'	)
			,	(	N'Density'	,N'slug_per_cubic_foot'	)
			,	(	N'Density'	,N'stone_per_cubic_light_year'	)
			,	(	N'Density'	,N'teragram_per_cubic_meter'	)
			,	(	N'Density'	,N'ton_per_cubic_yard'	)
			,	(	N'Density'	,N'yoctogram_per_cubic_meter'	)
			,	(	N'Density'	,N'yottagram_per_cubic_meter'	)
			,	(	N'Density'	,N'zeptogram_per_cubic_meter'	)
			,	(	N'Density'	,N'zettagram_per_cubic_meter'	)
			,	(	N'Efficiency'	,N'Btu_IT_per_kilowatt_hour'	)
			,	(	N'Efficiency'	,N'joule_per_joule'	)
			,	(	N'Efficiency'	,N'kilojoule_per_kilowatt_hour'	)
			,	(	N'ElectricCurrent'	,N'amp'	)
			,	(	N'ElectricCurrent'	,N'kiloamp'	)
			,	(	N'ElectricCurrent'	,N'megaamp'	)
			,	(	N'ElectricCurrent'	,N'microamp'	)
			,	(	N'ElectricCurrent'	,N'milliamp'	)
			,	(	N'ElectricPotentialDifference'	,N'kilovolt'	)
			,	(	N'ElectricPotentialDifference'	,N'megavolt'	)
			,	(	N'ElectricPotentialDifference'	,N'microvolt'	)
			,	(	N'ElectricPotentialDifference'	,N'millivolt'	)
			,	(	N'ElectricPotentialDifference'	,N'volt'	)
			,	(	N'ElectricTariff'	,N'dollar_per_unit'	)
			,	(	N'ElectricTariff'	,N'euro_per_unit'	)
			,	(	N'ElectricTariff'	,N'kilo_watt_hour_cubic_meter'	)
			,	(	N'ElectricTariff'	,N'kilo_watt_hour_kilogram'	)
			,	(	N'ElectricTariff'	,N'kilo_watt_hour_litre'	)
			,	(	N'Energy'	,N'Btu_IT'	)
			,	(	N'Energy'	,N'Btu_th'	)
			,	(	N'Energy'	,N'calorie_IT'	)
			,	(	N'Energy'	,N'calorie_th'	)
			,	(	N'Energy'	,N'joule'	)
			,	(	N'Energy'	,N'kilojoule'	)
			,	(	N'Energy'	,N'kilowatt_hour'	)
			,	(	N'Energy'	,N'megajoule'	)
			,	(	N'Energy'	,N'microjoule'	)
			,	(	N'Energy'	,N'millijoule'	)
			,	(	N'Entropy'	,N'Btu_IT_per_Fahrenheit'	)
			,	(	N'Entropy'	,N'Btu_IT_per_Rankine'	)
			,	(	N'Entropy'	,N'Btu_th_per_Fahrenheit'	)
			,	(	N'Entropy'	,N'Btu_th_per_Rankine'	)
			,	(	N'Entropy'	,N'joule_per_Kelvin'	)
			,	(	N'Force'	,N'attonewton'	)
			,	(	N'Force'	,N'centinewton'	)
			,	(	N'Force'	,N'decanewton'	)
			,	(	N'Force'	,N'decinewton'	)
			,	(	N'Force'	,N'dyne'	)
			,	(	N'Force'	,N'exanewton'	)
			,	(	N'Force'	,N'femtonewton'	)
			,	(	N'Force'	,N'giganewton'	)
			,	(	N'Force'	,N'hectonewton'	)
			,	(	N'Force'	,N'kilogram_force'	)
			,	(	N'Force'	,N'kilonewton'	)
			,	(	N'Force'	,N'kilopond'	)
			,	(	N'Force'	,N'kip'	)
			,	(	N'Force'	,N'meganewton'	)
			,	(	N'Force'	,N'micronewton'	)
			,	(	N'Force'	,N'millinewton'	)
			,	(	N'Force'	,N'nanonewton'	)
			,	(	N'Force'	,N'newton'	)
			,	(	N'Force'	,N'ounce_force'	)
			,	(	N'Force'	,N'petanewton'	)
			,	(	N'Force'	,N'piconewton'	)
			,	(	N'Force'	,N'pound_force'	)
			,	(	N'Force'	,N'poundal'	)
			,	(	N'Force'	,N'teranewton'	)
			,	(	N'Force'	,N'ton_force'	)
			,	(	N'Force'	,N'yoctonewton'	)
			,	(	N'Force'	,N'yottanewton'	)
			,	(	N'Force'	,N'zeptonewton'	)
			,	(	N'Force'	,N'zettanewton'	)
			,	(	N'Fraction'	,N'decimal'	)
			,	(	N'Fraction'	,N'part_per_billion'	)
			,	(	N'Fraction'	,N'part_per_million'	)
			,	(	N'Fraction'	,N'percent'	)
			,	(	N'Frequency'	,N'attohertz'	)
			,	(	N'Frequency'	,N'centihertz'	)
			,	(	N'Frequency'	,N'cycles_per_day'	)
			,	(	N'Frequency'	,N'cycles_per_hour'	)
			,	(	N'Frequency'	,N'cycles_per_minute'	)
			,	(	N'Frequency'	,N'cycles_per_year'	)
			,	(	N'Frequency'	,N'decahertz'	)
			,	(	N'Frequency'	,N'decihertz'	)
			,	(	N'Frequency'	,N'exahertz'	)
			,	(	N'Frequency'	,N'femtohertz'	)
			,	(	N'Frequency'	,N'gigahertz'	)
			,	(	N'Frequency'	,N'hectohertz'	)
			,	(	N'Frequency'	,N'hertz'	)
			,	(	N'Frequency'	,N'kilohertz'	)
			,	(	N'Frequency'	,N'megahertz'	)
			,	(	N'Frequency'	,N'microhertz'	)
			,	(	N'Frequency'	,N'millihertz'	)
			,	(	N'Frequency'	,N'nanohertz'	)
			,	(	N'Frequency'	,N'petahertz'	)
			,	(	N'Frequency'	,N'picohertz'	)
			,	(	N'Frequency'	,N'terahertz'	)
			,	(	N'Frequency'	,N'yoctohertz'	)
			,	(	N'Frequency'	,N'yottahertz'	)
			,	(	N'Frequency'	,N'zeptohertz'	)
			,	(	N'Frequency'	,N'zettahertz'	)
			,	(	N'Hardness'		,N'grain'	)
			,	(	N'Hardness'		,N'parts_per_million'	)
			,	(	N'HeatDensity'	,N'attojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'Btu_IT_per_square_foot'	)
			,	(	N'HeatDensity'	,N'Btu_th_per_square_foot'	)
			,	(	N'HeatDensity'	,N'calorie_IT_per_square_centimeter'	)
			,	(	N'HeatDensity'	,N'calorie_th_per_square_centimeter'	)
			,	(	N'HeatDensity'	,N'centijoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'decajoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'decijoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'exajoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'femtojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'gigajoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'hectojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'joule_per_square_centimeter'	)
			,	(	N'HeatDensity'	,N'joule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'kilojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'langley'	)
			,	(	N'HeatDensity'	,N'megajoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'microjoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'millijoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'nanojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'petajoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'picojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'terajoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'yoctojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'yottajoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'zeptojoule_per_square_meter'	)
			,	(	N'HeatDensity'	,N'zettajoule_per_square_meter'	)
			,	(	N'HeatTransferCoefficient'	,N'Btu_IT_per_hour_square_foot_Fahrenheit'	)
			,	(	N'HeatTransferCoefficient'	,N'kilowatt_per_square_meter_Celsius'	)
			,	(	N'HeatTransferCoefficient'	,N'watt_per_square_meter_Celsius'	)
			,	(	N'HeatTransferCoefficient'	,N'watt_per_square_meter_kelvin'	)
			,	(	N'Length'	,N'Angstrom'	)
			,	(	N'Length'	,N'astronomica_unit'	)
			,	(	N'Length'	,N'attometer'	)
			,	(	N'Length'	,N'centimeter'	)
			,	(	N'Length'	,N'chain'	)
			,	(	N'Length'	,N'decameter'	)
			,	(	N'Length'	,N'decimeter'	)
			,	(	N'Length'	,N'exameter'	)
			,	(	N'Length'	,N'fathom'	)
			,	(	N'Length'	,N'femtometer'	)
			,	(	N'Length'	,N'foot'	)
			,	(	N'Length'	,N'gigameter'	)
			,	(	N'Length'	,N'hectometer'	)
			,	(	N'Length'	,N'inch'	)
			,	(	N'Length'	,N'kilometer'	)
			,	(	N'Length'	,N'light_year'	)
			,	(	N'Length'	,N'megameter'	)
			,	(	N'Length'	,N'meter'	)
			,	(	N'Length'	,N'microinch'	)
			,	(	N'Length'	,N'micrometer'	)
			,	(	N'Length'	,N'mil'	)
			,	(	N'Length'	,N'mile'	)
			,	(	N'Length'	,N'millimeter'	)
			,	(	N'Length'	,N'nanometer'	)
			,	(	N'Length'	,N'nautical_mile'	)
			,	(	N'Length'	,N'parsec'	)
			,	(	N'Length'	,N'petameter'	)
			,	(	N'Length'	,N'pica_computer'	)
			,	(	N'Length'	,N'pica_print'	)
			,	(	N'Length'	,N'picometer'	)
			,	(	N'Length'	,N'point_computer'	)
			,	(	N'Length'	,N'point_print'	)
			,	(	N'Length'	,N'rod'	)
			,	(	N'Length'	,N'terameter'	)
			,	(	N'Length'	,N'yard'	)
			,	(	N'Length'	,N'yoctometer'	)
			,	(	N'Length'	,N'yottameter'	)
			,	(	N'Length'	,N'zeptometer'	)
			,	(	N'Length'	,N'zettameter'	)
			,	(	N'Mass'	,N'attogram'	)
			,	(	N'Mass'	,N'carat'	)
			,	(	N'Mass'	,N'centigram'	)
			,	(	N'Mass'	,N'decagram'	)
			,	(	N'Mass'	,N'decigram'	)
			,	(	N'Mass'	,N'exagram'	)
			,	(	N'Mass'	,N'femtogram'	)
			,	(	N'Mass'	,N'gigagram'	)
			,	(	N'Mass'	,N'grain'	)
			,	(	N'Mass'	,N'gram'	)
			,	(	N'Mass'	,N'hectogram'	)
			,	(	N'Mass'	,N'kilogram'	)
			,	(	N'Mass'	,N'megagram'	)
			,	(	N'Mass'	,N'microgram'	)
			,	(	N'Mass'	,N'milligram'	)
			,	(	N'Mass'	,N'nanogram'	)
			,	(	N'Mass'	,N'ounce'	)
			,	(	N'Mass'	,N'ounce_troy'	)
			,	(	N'Mass'	,N'petagram'	)
			,	(	N'Mass'	,N'picogram'	)
			,	(	N'Mass'	,N'pound'	)
			,	(	N'Mass'	,N'pound_troy'	)
			,	(	N'Mass'	,N'teragram'	)
			,	(	N'Mass'	,N'ton'	)
			,	(	N'Mass'	,N'ton_assay'	)
			,	(	N'Mass'	,N'ton_metric'	)
			,	(	N'Mass'	,N'yoctogram'	)
			,	(	N'Mass'	,N'yottagram'	)
			,	(	N'Mass'	,N'zeptogram'	)
			,	(	N'Mass'	,N'zettagram'	)
			,	(	N'MassRate'	,N'attogram_per_second'	)
			,	(	N'MassRate'	,N'centigram_per_second'	)
			,	(	N'MassRate'	,N'decagram_per_second'	)
			,	(	N'MassRate'	,N'decigram_per_second'	)
			,	(	N'MassRate'	,N'exagram_per_second'	)
			,	(	N'MassRate'	,N'femtogram_per_second'	)
			,	(	N'MassRate'	,N'gigagram_per_second'	)
			,	(	N'MassRate'	,N'gram_per_second'	)
			,	(	N'MassRate'	,N'hectogram_per_second'	)
			,	(	N'MassRate'	,N'kilogram_per_day'	)
			,	(	N'MassRate'	,N'kilogram_per_hour'	)
			,	(	N'MassRate'	,N'kilogram_per_minute'	)
			,	(	N'MassRate'	,N'kilogram_per_second'	)
			,	(	N'MassRate'	,N'megagram_per_second'	)
			,	(	N'MassRate'	,N'microgram_per_second'	)
			,	(	N'MassRate'	,N'milligram_per_second'	)
			,	(	N'MassRate'	,N'million_pounds_per_hour'	)
			,	(	N'MassRate'	,N'nanogram_per_second'	)
			,	(	N'MassRate'	,N'petagram_per_second'	)
			,	(	N'MassRate'	,N'picogram_per_second'	)
			,	(	N'MassRate'	,N'pound_per_day'	)
			,	(	N'MassRate'	,N'pound_per_hour'	)
			,	(	N'MassRate'	,N'pound_per_minute'	)
			,	(	N'MassRate'	,N'pound_per_second'	)
			,	(	N'MassRate'	,N'teragram_per_second'	)
			,	(	N'MassRate'	,N'thousand_pounds_per_hour'	)
			,	(	N'MassRate'	,N'ton_per_day'	)
			,	(	N'MassRate'	,N'ton_per_day_metric'	)
			,	(	N'MassRate'	,N'ton_per_hour'	)
			,	(	N'MassRate'	,N'ton_per_hour_metric'	)
			,	(	N'MassRate'	,N'yoctogram_per_second'	)
			,	(	N'MassRate'	,N'yottagram_per_second'	)
			,	(	N'MassRate'	,N'zeptogram_per_second'	)
			,	(	N'MassRate'	,N'zettagram_per_second'	)
			,	(	N'MolarEntropy'	,N'joule_per_mole_Kelvin'	)
			,	(	N'MolarMass'	,N'gram_per_mole'	)
			,	(	N'MolarMass'	,N'kilogram_per_mole'	)
			,	(	N'NormalizedVolumeRate'	,N'normal_cubic_meter_per_second_20C_1atm_dry'	)
			,	(	N'NormalizedVolumeRate'	,N'standard_cubic_feet_per_minute_68F_1atm_dry'	)
			,	(	N'pH'	,N'pH'	)
			,	(	N'pH'	,N's.u'	)
			,	(	N'Power'	,N'Btu_IT_per_hour'	)
			,	(	N'Power'	,N'Btu_IT_per_second'	)
			,	(	N'Power'	,N'Btu_th_per_hour'	)
			,	(	N'Power'	,N'Btu_th_per_minute'	)
			,	(	N'Power'	,N'Btu_th_per_second'	)
			,	(	N'Power'	,N'calorie_th_per_minute'	)
			,	(	N'Power'	,N'calorie_th_per_second'	)
			,	(	N'Power'	,N'erg_per_second'	)
			,	(	N'Power'	,N'foot_pound_force_per_hour'	)
			,	(	N'Power'	,N'foot_pound_force_per_minute'	)
			,	(	N'Power'	,N'foot_pound_force_per_second'	)
			,	(	N'Power'	,N'gigajoule_per_hour'	)
			,	(	N'Power'	,N'gigawatt'	)
			,	(	N'Power'	,N'horsepower'	)
			,	(	N'Power'	,N'horsepower_boiler'	)
			,	(	N'Power'	,N'horsepower_electric'	)
			,	(	N'Power'	,N'horsepower_metric'	)
			,	(	N'Power'	,N'horsepower_uk'	)
			,	(	N'Power'	,N'horsepower_water'	)
			,	(	N'Power'	,N'kilocalorie_th_per_minute'	)
			,	(	N'Power'	,N'kilocalorie_th_per_second'	)
			,	(	N'Power'	,N'kilojoule_per_hour'	)
			,	(	N'Power'	,N'kilowatt'	)
			,	(	N'Power'	,N'megawatt'	)
			,	(	N'Power'	,N'MillionBtu_IT_per_hour'	)
			,	(	N'Power'	,N'MillionBtu_th_per_hour'	)
			,	(	N'Power'	,N'ton_of_refridgeration'	)
			,	(	N'Power'	,N'watt'	)
			,	(	N'Pressure'	,N'atmosphere'	)
			,	(	N'Pressure'	,N'attopascal'	)
			,	(	N'Pressure'	,N'bar'	)
			,	(	N'Pressure'	,N'centipascal'	)
			,	(	N'Pressure'	,N'decapascal'	)
			,	(	N'Pressure'	,N'decipascal'	)
			,	(	N'Pressure'	,N'exapascal'	)
			,	(	N'Pressure'	,N'femtopascal'	)
			,	(	N'Pressure'	,N'foot_of_water_20C'	)
			,	(	N'Pressure'	,N'gigapascal'	)
			,	(	N'Pressure'	,N'hectopascal'	)
			,	(	N'Pressure'	,N'inch_of_mercury'	)
			,	(	N'Pressure'	,N'inch_of_water_20C'	)
			,	(	N'Pressure'	,N'kilopascal'	)
			,	(	N'Pressure'	,N'megapascal'	)
			,	(	N'Pressure'	,N'micropascal'	)
			,	(	N'Pressure'	,N'millipascal'	)
			,	(	N'Pressure'	,N'nanopascal'	)
			,	(	N'Pressure'	,N'pascal'	)
			,	(	N'Pressure'	,N'petapascal'	)
			,	(	N'Pressure'	,N'picopascal'	)
			,	(	N'Pressure'	,N'pound_per_square_inch'	)
			,	(	N'Pressure'	,N'pound_per_square_inch_a'	)
			,	(	N'Pressure'	,N'pound_per_square_inch_g'	)
			,	(	N'Pressure'	,N'terapascal'	)
			,	(	N'Pressure'	,N'yoctopascal'	)
			,	(	N'Pressure'	,N'yottapascal'	)
			,	(	N'Pressure'	,N'zeptopascal'	)
			,	(	N'Pressure'	,N'zettapascal'	)
			,	(	N'Price'	,N'dollar'	)
			,	(	N'Price'	,N'dollar_per_kilo_watt_hour'	)
			,	(	N'Price'	,N'euro'	)
			,	(	N'Price'	,N'euro_per_kilo_watt_hour'	)
			,	(	N'Price'	,N'euro_per_kilogram'	)
			,	(	N'Price'	,N'euro_per_lbs'	)
			,	(	N'Price'	,N'euro_per_litre'	)
			,	(	N'Price'	,N'euro_per_unit'	)
			,	(	N'ReciprocalLength'	,N'reciprocal_centimeter'	)
			,	(	N'ReciprocalLength'	,N'reciprocal_foot'	)
			,	(	N'ReciprocalLength'	,N'reciprocal_inch'	)
			,	(	N'ReciprocalLength'	,N'reciprocal_meter'	)
			,	(	N'RelativeHumidity'	,N'pascal_per_pascal'	)
			,	(	N'RelativeHumidity'	,N'pound_per_square_inch_a_per_pound_per_square_inch_a'	)
			,	(	N'RelativeHumidity'	,N'pound_per_square_inch_g_per_pound_per_square_inch_g'	)
			,	(	N'SpecificHumidity'	,N'grain_per_pound'	)
			,	(	N'SpecificHumidity'	,N'gram_per_kilogram'	)
			,	(	N'SpecificHumidity'	,N'kilogram_per_kilogram'	)
			,	(	N'SpecificHumidity'	,N'pound_per_pound'	)
			,	(	N'SpecificVolume'	,N'cubic_centimeter_per_gram'	)
			,	(	N'SpecificVolume'	,N'cubic_foot_per_grain'	)
			,	(	N'SpecificVolume'	,N'cubic_foot_per_pound'	)
			,	(	N'SpecificVolume'	,N'cubic_foot_per_slug'	)
			,	(	N'SpecificVolume'	,N'cubic_inch_per_ounce'	)
			,	(	N'SpecificVolume'	,N'cubic_inch_per_pound'	)
			,	(	N'SpecificVolume'	,N'cubic_meter_per_gram'	)
			,	(	N'SpecificVolume'	,N'cubic_meter_per_kilogram'	)
			,	(	N'SpecificVolume'	,N'cubic_yard_per_pound'	)
			,	(	N'SpecificVolume'	,N'cubic_yard_per_ton'	)
			,	(	N'SpecificVolume'	,N'gallon_imperial_per_ounce'	)
			,	(	N'SpecificVolume'	,N'gallon_imperial_per_pound'	)
			,	(	N'SpecificVolume'	,N'gallon_per_grain'	)
			,	(	N'SpecificVolume'	,N'gallon_per_ounce'	)
			,	(	N'SpecificVolume'	,N'gallon_per_pound'	)
			,	(	N'SpecificVolume'	,N'liter_per_gram'	)
			,	(	N'SpecificVolume'	,N'liter_per_milligram'	)
			,	(	N'Temperature'	,N'Celsius'	)
			,	(	N'Temperature'	,N'Fahrenheit'	)
			,	(	N'Temperature'	,N'kelvin'	)
			,	(	N'Temperature'	,N'Rankine'	)
			,	(	N'TemperatureInterval'	,N'Celsius'	)
			,	(	N'TemperatureInterval'	,N'Fahrenheit'	)
			,	(	N'TemperatureInterval'	,N'kelvin'	)
			,	(	N'TemperatureInterval'	,N'Rankine'	)
			,	(	N'TemperatureLapseRate'	,N'Celsius_per_kilometer'	)
			,	(	N'TemperatureLapseRate'	,N'Celsius_per_meter'	)
			,	(	N'TemperatureLapseRate'	,N'Fahrenheit_per_foot'	)
			,	(	N'TemperatureLapseRate'	,N'Fahrenheit_per_mile'	)
			,	(	N'TemperatureLapseRate'	,N'kelvin_per_kilometer'	)
			,	(	N'TemperatureLapseRate'	,N'kelvin_per_meter'	)
			,	(	N'TemperatureLapseRate'	,N'Rankine_per_kilometer'	)
			,	(	N'TemperatureLapseRate'	,N'Rankine_per_meter'	)
			,	(	N'ThermalInsulance'	,N'Fahrenheit_hour_square_foot_per_Btu_IT'	)
			,	(	N'ThermalInsulance'	,N'square_meter_Celsius_per_kilowatt'	)
			,	(	N'ThermalInsulance'	,N'square_meter_kelvin_per_watt'	)
			,	(	N'Time'	,N'attosecond'	)
			,	(	N'Time'	,N'centisecond'	)
			,	(	N'Time'	,N'day'	)
			,	(	N'Time'	,N'decasecond'	)
			,	(	N'Time'	,N'decisecond'	)
			,	(	N'Time'	,N'exasecond'	)
			,	(	N'Time'	,N'femtosecond'	)
			,	(	N'Time'	,N'gigasecond'	)
			,	(	N'Time'	,N'hectosecond'	)
			,	(	N'Time'	,N'hour'	)
			,	(	N'Time'	,N'kilosecond'	)
			,	(	N'Time'	,N'megasecond'	)
			,	(	N'Time'	,N'microsecond'	)
			,	(	N'Time'	,N'millisecond'	)
			,	(	N'Time'	,N'minute'	)
			,	(	N'Time'	,N'nanosecond'	)
			,	(	N'Time'	,N'petasecond'	)
			,	(	N'Time'	,N'picosecond'	)
			,	(	N'Time'	,N'second'	)
			,	(	N'Time'	,N'terasecond'	)
			,	(	N'Time'	,N'year'	)
			,	(	N'Time'	,N'yoctosecond'	)
			,	(	N'Time'	,N'yottasecond'	)
			,	(	N'Time'	,N'zeptosecond'	)
			,	(	N'Time'	,N'zettasecond'	)
			,	(	N'TimePerMass'	,N'day_per_kilogram'	)
			,	(	N'TimePerMass'	,N'day_per_pound'	)
			,	(	N'TimePerMass'	,N'day_per_ton'	)
			,	(	N'TimePerMass'	,N'hour_per_kilogram'	)
			,	(	N'TimePerMass'	,N'hour_per_megagram'	)
			,	(	N'TimePerMass'	,N'hour_per_pound'	)
			,	(	N'TimePerMass'	,N'hour_per_ton'	)
			,	(	N'TimePerMass'	,N'minute_per_kilogram'	)
			,	(	N'TimePerMass'	,N'minute_per_pound'	)
			,	(	N'TimePerMass'	,N'minute_per_ton'	)
			,	(	N'TimePerMass'	,N'second_per_kilogram'	)
			,	(	N'TimePerMass'	,N'second_per_pound'	)
			,	(	N'TimePerMass'	,N'second_per_ton'	)
			,	(	N'Turbidity'	,N'nephelometric_turbidity_unit'	)
			,	(	N'Velocity'	,N'attometer_per_second'	)
			,	(	N'Velocity'	,N'centimeter_per_day'	)
			,	(	N'Velocity'	,N'centimeter_per_second'	)
			,	(	N'Velocity'	,N'centimeter_per_year'	)
			,	(	N'Velocity'	,N'decameter_per_second'	)
			,	(	N'Velocity'	,N'decimeter_per_second'	)
			,	(	N'Velocity'	,N'exameter_per_second'	)
			,	(	N'Velocity'	,N'femtometer_per_second'	)
			,	(	N'Velocity'	,N'foot_per_hour'	)
			,	(	N'Velocity'	,N'foot_per_minute'	)
			,	(	N'Velocity'	,N'foot_per_second'	)
			,	(	N'Velocity'	,N'gigameter_per_second'	)
			,	(	N'Velocity'	,N'hectometer_per_second'	)
			,	(	N'Velocity'	,N'inch_per_day'	)
			,	(	N'Velocity'	,N'inch_per_second'	)
			,	(	N'Velocity'	,N'inch_per_year'	)
			,	(	N'Velocity'	,N'kilometer_per_hour'	)
			,	(	N'Velocity'	,N'kilometer_per_second'	)
			,	(	N'Velocity'	,N'knot'	)
			,	(	N'Velocity'	,N'megameter_per_second'	)
			,	(	N'Velocity'	,N'meter_per_minute'	)
			,	(	N'Velocity'	,N'meter_per_second'	)
			,	(	N'Velocity'	,N'micrometer_per_second'	)
			,	(	N'Velocity'	,N'mile_per_day'	)
			,	(	N'Velocity'	,N'mile_per_hour'	)
			,	(	N'Velocity'	,N'mile_per_minute'	)
			,	(	N'Velocity'	,N'mile_per_second'	)
			,	(	N'Velocity'	,N'millimeter_per_second'	)
			,	(	N'Velocity'	,N'nanometer_per_second'	)
			,	(	N'Velocity'	,N'petameter_per_second'	)
			,	(	N'Velocity'	,N'picometer_per_second'	)
			,	(	N'Velocity'	,N'terameter_per_second'	)
			,	(	N'Velocity'	,N'yoctometer_per_second'	)
			,	(	N'Velocity'	,N'yottameter_per_second'	)
			,	(	N'Velocity'	,N'zeptometer_per_second'	)
			,	(	N'Velocity'	,N'zettameter_per_second'	)
			,	(	N'Viscosity'	,N'centipoise'	)
			,	(	N'Viscosity'	,N'millipascal_second'	)
			,	(	N'Viscosity'	,N'pascal_second'	)
			,	(	N'Viscosity'	,N'poise'	)
			,	(	N'Volume'	,N'bushel'	)
			,	(	N'Volume'	,N'cord'	)
			,	(	N'Volume'	,N'cubic_attometer'	)
			,	(	N'Volume'	,N'cubic_centimeter'	)
			,	(	N'Volume'	,N'cubic_decameter'	)
			,	(	N'Volume'	,N'cubic_decimeter'	)
			,	(	N'Volume'	,N'cubic_exameter'	)
			,	(	N'Volume'	,N'cubic_femtometer'	)
			,	(	N'Volume'	,N'cubic_foot'	)
			,	(	N'Volume'	,N'cubic_gigameter'	)
			,	(	N'Volume'	,N'cubic_hectometer'	)
			,	(	N'Volume'	,N'cubic_inch'	)
			,	(	N'Volume'	,N'cubic_kilometer'	)
			,	(	N'Volume'	,N'cubic_megameter'	)
			,	(	N'Volume'	,N'cubic_meter'	)
			,	(	N'Volume'	,N'cubic_micrometer'	)
			,	(	N'Volume'	,N'cubic_mile'	)
			,	(	N'Volume'	,N'cubic_millimeter'	)
			,	(	N'Volume'	,N'cubic_nanometer'	)
			,	(	N'Volume'	,N'cubic_petameter'	)
			,	(	N'Volume'	,N'cubic_picometer'	)
			,	(	N'Volume'	,N'cubic_terameter'	)
			,	(	N'Volume'	,N'cubic_yard'	)
			,	(	N'Volume'	,N'cubic_yoctometer'	)
			,	(	N'Volume'	,N'cubic_yottameter'	)
			,	(	N'Volume'	,N'cubic_zeptometer'	)
			,	(	N'Volume'	,N'cubic_zettameter'	)
			,	(	N'Volume'	,N'cup'	)
			,	(	N'Volume'	,N'fluid_ounce'	)
			,	(	N'Volume'	,N'fluid_ounce_imperial'	)
			,	(	N'Volume'	,N'gallon'	)
			,	(	N'Volume'	,N'gallon_imperial'	)
			,	(	N'Volume'	,N'liter'	)
			,	(	N'Volume'	,N'oil_barrel'	)
			,	(	N'Volume'	,N'peck'	)
			,	(	N'Volume'	,N'pint_dry'	)
			,	(	N'Volume'	,N'pint_liquid'	)
			,	(	N'Volume'	,N'quart_dry'	)
			,	(	N'Volume'	,N'quart_liquid'	)
			,	(	N'Volume'	,N'tablespoon'	)
			,	(	N'Volume'	,N'teaspoon'	)
			,	(	N'VolumeFlux'	,N'cubic_meter_per_hour_per_square_meter'	)
			,	(	N'VolumeFlux'	,N'cubic_meter_per_second_per_square_meter'	)
			,	(	N'VolumeFlux'	,N'gallon_per_day_per_square_foot'	)
			,	(	N'VolumeFlux'	,N'gallon_per_minute_per_square_foot'	)
			,	(	N'VolumeFlux'	,N'liter_per_hour_per_square_meter'	)
			,	(	N'VolumeRate'	,N'cubic_attometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_centimeter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_decameter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_decimeter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_exameter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_femtometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_foot_per_hour'	)
			,	(	N'VolumeRate'	,N'cubic_foot_per_minute'	)
			,	(	N'VolumeRate'	,N'cubic_foot_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_gigameter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_hectometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_inch_per_minute'	)
			,	(	N'VolumeRate'	,N'cubic_kilometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_megameter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_meter_per_day'	)
			,	(	N'VolumeRate'	,N'cubic_meter_per_hour'	)
			,	(	N'VolumeRate'	,N'cubic_meter_per_minute'	)
			,	(	N'VolumeRate'	,N'cubic_meter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_micrometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_millimeter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_nanometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_petameter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_picometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_terameter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_yard_per_minute'	)
			,	(	N'VolumeRate'	,N'cubic_yoctometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_yottameter_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_zeptometer_per_second'	)
			,	(	N'VolumeRate'	,N'cubic_zettameter_per_second'	)
			,	(	N'VolumeRate'	,N'gallon_per_day'	)
			,	(	N'VolumeRate'	,N'gallon_per_minute'	)
			,	(	N'VolumeRate'	,N'liter_per_hour'	)
			,	(	N'VolumeRate'	,N'oil_barrels_per_day'	)
			,	(	N'VolumeRatioRate'	,N'cubic_meter_per_hour_per_cubic_meter'	)
			,	(	N'VolumeRatioRate'	,N'cubic_meter_per_second_per_cubic_meter'	)
			,	(	N'VolumeRatioRate'	,N'gallon_per_minute_per_cubic_foot'	)
			,	(	N'Weight'	,N'kilogram'	)
			,	(	N'Weight'	,N'pound'	)
			,	(	N'WaterHardness'	,N'grains_per_gallon'	)


		MERGE	[TCD].DimensionalSubunits			AS TARGET
		USING	@tempDimensionalSubunits	AS SOURCE
			ON	TARGET.Unit					=			SOURCE.Unit
			AND	TARGET.Subunit				=			SOURCE.Subunit
		WHEN	NOT MATCHED		THEN
				INSERT	(Unit			,Subunit		)
				VALUES	(SOURCE.Unit	,SOURCE.Subunit	);
	END





/*	DimensionalUnitsDefaults

PRIMARY KEY: UnitSystemId, UsageKey
FK:		REFERENCES ConduitLocal.dbo.DimensionalSubunits (Unit, Subunit)
	 ,	REFERENCES ConduitLocal.dbo.DimensionalUnitSystems (UnitSystemId)

No foreign keys reference table 'DimensionalUnitsDefaults', or you do not have permissions on referencing tables.



*/
	BEGIN
		SET			@TableName				=			'DimensionalUnitsDefaults'
		RAISERROR	(@TableName, 0, 1)

		--Declare temp table variable to hold input data
		DECLARE	@tempDimensionalUnitsDefaults	TABLE	(
				TempId							INT				IDENTITY(1, 1)
			,	UnitSystemId					INT				NOT	NULL
			,	UsageKey						NVARCHAR(100)	NOT	NULL
			,	Unit							NVARCHAR(100)	NOT	NULL
			,	Subunit							NVARCHAR(100)	NOT	NULL
			)

		--Populate temp table variable with the input data
		INSERT	@tempDimensionalUnitsDefaults	(
				UnitSystemId	,UsageKey	,Unit	,Subunit	)
		VALUES	(1	,N'Area_Condensers'	,N'Area'	,N'square_foot'	)
			,	(1	,N'AvailableEnergy_Condensers'	,N'AvailableEnergy'	,N'Btu_IT_per_pound'	)
			,	(1	,N'ConductivityElectrolytic_CommonUse'	,N'ConductivityElectrolytic'	,N'microSiemens_per_centimeter'	)
			,	(1	,N'Efficiency_Condensers'	,N'Efficiency'	,N'Btu_IT_per_kilowatt_hour'	)
			,	(1	,N'ElectricCurrent_Condensers'	,N'ElectricCurrent'	,N'amp'	)
			,	(1	,N'ElectricPotentialDifference_Condensers'	,N'ElectricPotentialDifference'	,N'millivolt'	)
			,	(1	,N'Energy_Content_TCD'	,N'ElectricTariff'	,N'kilo_watt_hour_cubic_meter'	)
			,	(1	,N'EnergyCost_unit_Tcd'	,N'Price'	,N'dollar_per_kilo_watt_hour'	)
			,	(1	,N'Fraction_Concentration'	,N'Fraction'	,N'part_per_billion'	)
			,	(1	,N'Fraction_Concentration_ppmDefault'	,N'Fraction'	,N'part_per_million'	)
			,	(1	,N'Fraction_Decimal'	,N'Fraction'	,N'percent'	)
			,	(1	,N'HeatTransferCoefficient'	,N'HeatTransferCoefficient'	,N'Btu_IT_per_hour_square_foot_Fahrenheit'	)
			,	(1	,N'Length_TubeDiameter'	,N'Length'	,N'inch'	)
			,	(1	,N'Length_TubeLength'	,N'Length'	,N'foot'	)
			,	(1	,N'MassRate_Condensers'	,N'MassRate'	,N'pound_per_hour'	)
			,	(1	,N'MassRate_Condensers_Solids'	,N'MassRate'	,N'ton_per_hour'	)
			,	(1	,N'NormalizedVolumeRate_Condensers'	,N'NormalizedVolumeRate'	,N'standard_cubic_feet_per_minute_68F_1atm_dry'	)
			,	(1	,N'Power_Condensers_Duty_BtuDefault'	,N'Power'	,N'Btu_IT_per_hour'	)
			,	(1	,N'Power_Condensers_Duty_MMBtuDefault'	,N'Power'	,N'MillionBtu_IT_per_hour'	)
			,	(1	,N'Power_Condensers_Load'	,N'Power'	,N'megawatt'	)
			,	(1	,N'Power_HX'	,N'Power'	,N'Btu_IT_per_hour'	)
			,	(1	,N'Pressure_Condensers_inHgDefault'	,N'Pressure'	,N'inch_of_mercury'	)
			,	(1	,N'Pressure_Condensers_psiaDefault'	,N'Pressure'	,N'pound_per_square_inch_a'	)
			,	(1	,N'Price_Electric_Tariff_Tcd'	,N'Price'	,N'dollar_per_kilo_watt_hour'	)
			,	(1	,N'Price_Tcd'	,N'Price'	,N'dollar'	)
			,	(1	,N'Temperature_CandF'	,N'Temperature'	,N'Fahrenheit'	)
			,	(1	,N'TemperatureInterval_CandF'	,N'TemperatureInterval'	,N'Fahrenheit'	)
			,	(1	,N'ThermalInsulance_CommonUse'	,N'ThermalInsulance'	,N'Fahrenheit_hour_square_foot_per_Btu_IT'	)
			,	(1	,N'Turbidity_CommonUse'	,N'Turbidity'	,N'nephelometric_turbidity_unit'	)
			,	(1	,N'Velocity_Condensers'	,N'Velocity'	,N'foot_per_second'	)
			,	(1	,N'VolumeRate_Condensers'	,N'VolumeRate'	,N'gallon_per_minute'	)
			,	(1	,N'VolumeRate_HX'	,N'VolumeRate'	,N'gallon_per_minute'	)
			,	(1	,N'Weight_lbs'	,N'Weight'	,N'pound'	)
			,	(2	,N'Area_Condensers'	,N'Area'	,N'square_meter'	)
			,	(2	,N'AvailableEnergy_Condensers'	,N'AvailableEnergy'	,N'joule_per_kilogram'	)
			,	(2	,N'ConductivityElectrolytic_CommonUse'	,N'ConductivityElectrolytic'	,N'microSiemens_per_centimeter'	)
			,	(2	,N'Efficiency_Condensers'	,N'Efficiency'	,N'kilojoule_per_kilowatt_hour'	)
			,	(2	,N'ElectricCurrent_Condensers'	,N'ElectricCurrent'	,N'amp'	)
			,	(2	,N'Energy_Content_Kg_TCD'	,N'ElectricTariff'	,N'kilo_watt_hour_kilogram'	)
			,	(2	,N'Energy_Content_L_TCD'	,N'ElectricTariff'	,N'kilo_watt_hour_litre'	)
			,	(2	,N'Energy_Content_TCD'	,N'ElectricTariff'	,N'kilo_watt_hour_cubic_meter'	)
			,	(2	,N'Fraction_Concentration'	,N'Fraction'	,N'part_per_billion'	)
			,	(2	,N'Fraction_Concentration_ppmDefault'	,N'Fraction'	,N'part_per_million'	)
			,	(2	,N'Fraction_Decimal'	,N'Fraction'	,N'percent'	)
			,	(2	,N'HeatTransferCoefficient'	,N'HeatTransferCoefficient'	,N'kilowatt_per_square_meter_Celsius'	)
			,	(2	,N'Length_TubeDiameter'	,N'Length'	,N'millimeter'	)
			,	(2	,N'Length_TubeLength'	,N'Length'	,N'meter'	)
			,	(2	,N'MassRate_Condensers'	,N'MassRate'	,N'kilogram_per_hour'	)
			,	(2	,N'MassRate_Condensers_Solids'	,N'MassRate'	,N'ton_per_hour_metric'	)
			,	(2	,N'NormalizedVolumeRate_Condensers'	,N'NormalizedVolumeRate'	,N'normal_cubic_meter_per_second_20C_1atm_dry'	)
			,	(2	,N'Power_Condensers_Duty_BtuDefault'	,N'Power'	,N'kilojoule_per_hour'	)
			,	(2	,N'Power_Condensers_Duty_MMBtuDefault'	,N'Power'	,N'kilojoule_per_hour'	)
			,	(2	,N'Power_Condensers_Load'	,N'Power'	,N'megawatt'	)
			,	(2	,N'Power_HX'	,N'Power'	,N'kilowatt'	)
			,	(2	,N'Pressure_Condensers_inHgDefault'	,N'Pressure'	,N'kilopascal'	)
			,	(2	,N'Pressure_Condensers_psiaDefault'	,N'Pressure'	,N'kilopascal'	)
			,	(2	,N'Pressure_Condensers_psigDefault'	,N'Pressure'	,N'kilopascal'	)
			,	(2	,N'Pressure_HX'	,N'Pressure'	,N'kilopascal'	)
			,	(2	,N'Price_Electric_Tariff_Tcd'	,N'Price'	,N'euro_per_kilo_watt_hour'	)
			,	(2	,N'Price_euro_per_Kg_TCD'	,N'Price'	,N'euro_per_kilogram'	)
			,	(2	,N'Price_euro_per_kwh_TCD'	,N'Price'	,N'euro_per_kilo_watt_hour'	)
			,	(2	,N'Price_euro_per_litre_TCD'	,N'Price'	,N'euro_per_litre'	)
			,	(2	,N'Price_GasOil_Tcd'	,N'Price'	,N'euro_per_lbs'	)
			,	(2	,N'Price_Tcd'	,N'Price'	,N'euro'	)
			,	(2	,N'Temperature_CandF'	,N'Temperature'	,N'Celsius'	)
			,	(2	,N'TemperatureInterval_CandF'	,N'TemperatureInterval'	,N'Celsius'	)
			,	(2	,N'ThermalInsulance_CommonUse'	,N'ThermalInsulance'	,N'square_meter_Celsius_per_kilowatt'	)
			,	(2	,N'Turbidity_CommonUse'	,N'Turbidity'	,N'nephelometric_turbidity_unit'	)
			,	(2	,N'Velocity_Condensers'	,N'Velocity'	,N'meter_per_second'	)
			,	(2	,N'VolumeRate_Condensers'	,N'VolumeRate'	,N'cubic_meter_per_second'	)
			,	(2	,N'VolumeRate_HX'	,N'VolumeRate'	,N'cubic_meter_per_hour'	)
			,	(2	,N'Weight_kgs'	,N'Weight'	,N'kilogram'	)


		MERGE	[TCD].DimensionalUnitsDefaults			AS			TARGET
		USING	@tempDimensionalUnitsDefaults		AS			SOURCE
			ON	TARGET.UnitSystemId					=			SOURCE.UnitSystemId
			AND	TARGET.UsageKey						=			SOURCE.UsageKey
		WHEN	NOT MATCHED		THEN
				INSERT	(UnitSystemId			,UsageKey			,Unit			,Subunit			)
				VALUES	(SOURCE.UnitSystemId	,SOURCE.UsageKey	,SOURCE.Unit	,SOURCE.Subunit		);
	END





/*	DimensionalDisplayUnits

PRIMARY KEY: DisplayUnitID, Unit, Subunit
FK:		REFERENCES ConduitLocal.dbo.DimensionalSubunits (Unit, Subunit)

No foreign keys reference table 'DimensionalUnitsDefaults', or you do not have permissions on referencing tables.



*/
	BEGIN
		SET			@TableName				=			'DimensionalDisplayUnits'
		RAISERROR	(@TableName, 0, 1)

		--Declare temp table variable to hold input data
		DECLARE	@tempDimensionalDisplayUnits	TABLE	(
				TempId							INT				IDENTITY(1, 1)
			,	DisplayUnitID					INT				NOT	NULL
			,	Unit							NVARCHAR(100)	NOT	NULL
			,	Subunit							NVARCHAR(100)	NOT	NULL
			,	OrderId							INT				NOT	NULL
			)

		--Populate temp table variable with the input data
		INSERT	@tempDimensionalDisplayUnits	(
				DisplayUnitID	,Unit	,Subunit	,OrderId	)
		VALUES	(1	,N'Temperature'	,N'Celsius'	,1	)
			,	(1	,N'Temperature'	,N'Fahrenheit'	,2	)
			,	(2	,N'Area'	,N'square_centimeter'	,2	)
			,	(2	,N'Area'	,N'square_foot'	,3	)
			,	(2	,N'Area'	,N'square_inch'	,4	)
			,	(2	,N'Area'	,N'square_meter'	,1	)
			,	(3	,N'AvailableEnergy'	,N'Btu_IT_per_pound'	,2	)
			,	(3	,N'AvailableEnergy'	,N'joule_per_kilogram'	,1	)
			,	(5	,N'MassRate'	,N'kilogram_per_hour'	,4	)
			,	(5	,N'MassRate'	,N'kilogram_per_minute'	,7	)
			,	(5	,N'MassRate'	,N'kilogram_per_second'	,8	)
			,	(5	,N'MassRate'	,N'million_pounds_per_hour'	,3	)
			,	(5	,N'MassRate'	,N'pound_per_hour'	,1	)
			,	(5	,N'MassRate'	,N'pound_per_minute'	,5	)
			,	(5	,N'MassRate'	,N'pound_per_second'	,6	)
			,	(5	,N'MassRate'	,N'thousand_pounds_per_hour'	,2	)
			,	(6	,N'Power'	,N'kilowatt'	,2	)
			,	(6	,N'Power'	,N'megawatt'	,1	)
			,	(7	,N'Pressure'	,N'foot_of_water_20C'	,3	)
			,	(7	,N'Pressure'	,N'inch_of_mercury'	,1	)
			,	(7	,N'Pressure'	,N'inch_of_water_20C'	,2	)
			,	(7	,N'Pressure'	,N'kilopascal'	,4	)
			,	(7	,N'Pressure'	,N'pound_per_square_inch_a'	,5	)
			,	(8	,N'TemperatureInterval'	,N'Celsius'	,1	)
			,	(8	,N'TemperatureInterval'	,N'Fahrenheit'	,2	)
			,	(9	,N'Velocity'	,N'foot_per_second'	,2	)
			,	(9	,N'Velocity'	,N'meter_per_second'	,1	)
			,	(10	,N'VolumeRate'	,N'cubic_meter_per_minute'	,2	)
			,	(10	,N'VolumeRate'	,N'cubic_meter_per_second'	,1	)
			,	(10	,N'VolumeRate'	,N'gallon_per_minute'	,3	)
			,	(11	,N'ElectricCurrent'	,N'amp'	,1	)
			,	(12	,N'Length'	,N'centimeter'	,3	)
			,	(12	,N'Length'	,N'inch'	,1	)
			,	(12	,N'Length'	,N'millimeter'	,2	)
			,	(13	,N'Length'	,N'foot'	,1	)
			,	(13	,N'Length'	,N'meter'	,2	)
			,	(14	,N'Power'	,N'Btu_IT_per_hour'	,1	)
			,	(14	,N'Power'	,N'kilojoule_per_hour'	,5	)
			,	(14	,N'Power'	,N'kilowatt'	,3	)
			,	(14	,N'Power'	,N'megawatt'	,4	)
			,	(14	,N'Power'	,N'MillionBtu_th_per_hour'	,2	)
			,	(15	,N'Pressure'	,N'atmosphere'	,5	)
			,	(15	,N'Pressure'	,N'bar'	,8	)
			,	(15	,N'Pressure'	,N'inch_of_mercury'	,4	)
			,	(15	,N'Pressure'	,N'kilopascal'	,7	)
			,	(15	,N'Pressure'	,N'pascal'	,6	)
			,	(15	,N'Pressure'	,N'pound_per_square_inch'	,3	)
			,	(15	,N'Pressure'	,N'pound_per_square_inch_a'	,2	)
			,	(15	,N'Pressure'	,N'pound_per_square_inch_g'	,1	)
			,	(16	,N'VolumeRate'	,N'cubic_foot_per_hour'	,3	)
			,	(16	,N'VolumeRate'	,N'cubic_meter_per_day'	,7	)
			,	(16	,N'VolumeRate'	,N'cubic_meter_per_hour'	,4	)
			,	(16	,N'VolumeRate'	,N'cubic_meter_per_minute'	,6	)
			,	(16	,N'VolumeRate'	,N'cubic_meter_per_second'	,5	)
			,	(16	,N'VolumeRate'	,N'gallon_per_day'	,2	)
			,	(16	,N'VolumeRate'	,N'gallon_per_minute'	,1	)
			,	(16	,N'VolumeRate'	,N'liter_per_hour'	,8	)
			,	(17	,N'Power'	,N'Btu_IT_per_hour'	,2	)
			,	(17	,N'Power'	,N'kilojoule_per_hour'	,3	)
			,	(17	,N'Power'	,N'MillionBtu_IT_per_hour'	,1	)
			,	(18	,N'HeatTransferCoefficient'	,N'Btu_IT_per_hour_square_foot_Fahrenheit'	,1	)
			,	(18	,N'HeatTransferCoefficient'	,N'kilowatt_per_square_meter_Celsius'	,2	)
			,	(18	,N'HeatTransferCoefficient'	,N'watt_per_square_meter_Celsius'	,3	)
			,	(19	,N'ConductivityElectrolytic'	,N'microSiemens_per_centimeter'	,1	)
			,	(20	,N'ThermalInsulance'	,N'Fahrenheit_hour_square_foot_per_Btu_IT'	,1	)
			,	(20	,N'ThermalInsulance'	,N'square_meter_Celsius_per_kilowatt'	,2	)
			,	(21	,N'Fraction'	,N'decimal'	,2	)
			,	(21	,N'Fraction'	,N'percent'	,1	)
			,	(22	,N'Fraction'	,N'part_per_billion'	,2	)
			,	(22	,N'Fraction'	,N'part_per_million'	,1	)
			,	(23	,N'Efficiency'	,N'Btu_IT_per_kilowatt_hour'	,1	)
			,	(23	,N'Efficiency'	,N'kilojoule_per_kilowatt_hour'	,2	)
			,	(24	,N'Power'	,N'Btu_IT_per_hour'	,1	)
			,	(24	,N'Power'	,N'kilojoule_per_hour'	,2	)
			,	(24	,N'Power'	,N'MillionBtu_IT_per_hour'	,3	)
			,	(25	,N'Pressure'	,N'inch_of_mercury'	,3	)
			,	(25	,N'Pressure'	,N'inch_of_water_20C'	,4	)
			,	(25	,N'Pressure'	,N'kilopascal'	,2	)
			,	(25	,N'Pressure'	,N'pound_per_square_inch_g'	,1	)
			,	(26	,N'Pressure'	,N'inch_of_mercury'	,3	)
			,	(26	,N'Pressure'	,N'inch_of_water_20C'	,4	)
			,	(26	,N'Pressure'	,N'kilopascal'	,2	)
			,	(26	,N'Pressure'	,N'pound_per_square_inch_a'	,1	)
			,	(27	,N'NormalizedVolumeRate'	,N'normal_cubic_meter_per_second_20C_1atm_dry'	,2	)
			,	(27	,N'NormalizedVolumeRate'	,N'standard_cubic_feet_per_minute_68F_1atm_dry'	,1	)
			,	(28	,N'MassRate'	,N'kilogram_per_hour'	,5	)
			,	(28	,N'MassRate'	,N'pound_per_hour'	,3	)
			,	(28	,N'MassRate'	,N'thousand_pounds_per_hour'	,2	)
			,	(28	,N'MassRate'	,N'ton_per_hour'	,1	)
			,	(28	,N'MassRate'	,N'ton_per_hour_metric'	,4	)
			,	(29	,N'Fraction'	,N'part_per_billion'	,2	)
			,	(29	,N'Fraction'	,N'part_per_million'	,1	)
			,	(30	,N'ElectricPotentialDifference'	,N'millivolt'	,1	)
			,	(31	,N'Turbidity'	,N'nephelometric_turbidity_unit'	,1	)
			,	(32	,N'pH'	,N'pH'	,1	)
			,	(32	,N'pH'	,N's.u'	,2	)
			,	(33	,N'Entropy'	,N'Btu_IT_per_Fahrenheit'	,1	)
			,	(33	,N'Entropy'	,N'Btu_IT_per_Rankine'	,2	)
			,	(33	,N'Entropy'	,N'Btu_th_per_Fahrenheit'	,3	)
			,	(33	,N'Entropy'	,N'Btu_th_per_Rankine'	,4	)
			,	(33	,N'Entropy'	,N'joule_per_Kelvin'	,5	)
			,	(34	,N'Mass'	,N'attogram'	,1	)
			,	(34	,N'Mass'	,N'carat'	,2	)
			,	(34	,N'Mass'	,N'centigram'	,3	)
			,	(34	,N'Mass'	,N'decagram'	,4	)
			,	(34	,N'Mass'	,N'decigram'	,5	)
			,	(34	,N'Mass'	,N'exagram'	,6	)
			,	(34	,N'Mass'	,N'femtogram'	,7	)
			,	(34	,N'Mass'	,N'gigagram'	,8	)
			,	(34	,N'Mass'	,N'grain'	,9	)
			,	(34	,N'Mass'	,N'gram'	,10	)
			,	(34	,N'Mass'	,N'hectogram'	,11	)
			,	(34	,N'Mass'	,N'kilogram'	,12	)
			,	(34	,N'Mass'	,N'megagram'	,13	)
			,	(34	,N'Mass'	,N'microgram'	,14	)
			,	(34	,N'Mass'	,N'milligram'	,15	)
			,	(34	,N'Mass'	,N'nanogram'	,16	)
			,	(34	,N'Mass'	,N'ounce'	,17	)
			,	(34	,N'Mass'	,N'ounce_troy'	,18	)
			,	(34	,N'Mass'	,N'petagram'	,19	)
			,	(34	,N'Mass'	,N'picogram'	,20	)
			,	(34	,N'Mass'	,N'pound'	,21	)
			,	(34	,N'Mass'	,N'pound_troy'	,22	)
			,	(34	,N'Mass'	,N'teragram'	,23	)
			,	(34	,N'Mass'	,N'ton'	,24	)
			,	(34	,N'Mass'	,N'ton_assay'	,25	)
			,	(34	,N'Mass'	,N'ton_metric'	,26	)
			,	(34	,N'Mass'	,N'yoctogram'	,27	)
			,	(34	,N'Mass'	,N'yottagram'	,28	)
			,	(34	,N'Mass'	,N'zeptogram'	,29	)
			,	(34	,N'Mass'	,N'zettagram'	,30	)
			,	(35	,N'ElectricTariff'	,N'kilo_watt_hour_cubic_meter'	,1	)
			,	(35	,N'ElectricTariff'	,N'kilo_watt_hour_kilogram'	,2	)
			,	(35	,N'ElectricTariff'	,N'kilo_watt_hour_litre'	,3	)
			,	(36	,N'Price'	,N'dollar'	,1	)
			,	(36	,N'Price'	,N'dollar_per_kilo_watt_hour'	,3	)
			,	(36	,N'Price'	,N'euro'	,2	)
			,	(36	,N'Price'	,N'euro_per_kilo_watt_hour'	,6	)
			,	(36	,N'Price'	,N'euro_per_kilogram'	,7	)
			,	(36	,N'Price'	,N'euro_per_lbs'	,4	)
			,	(36	,N'Price'	,N'euro_per_litre'	,8	)
			,	(36	,N'Price'	,N'euro_per_unit'	,5	)
			,	(37	,N'Weight'	,N'kilogram'	,1	)
			,	(38, N'Volume'	,N'gallon'	,1	)
			--,	(38, N'Volume'	,N'kilo_gallon'	,2	)						--missing reference in TCD.DimensionalSubunits
			,	(38, N'Volume'	,N'cubic_foot'	,3	)
			,	(38, N'Volume'	,N'cubic_meter'	,4	)
			,	(38, N'Volume'	,N'liter'	,	5	)
			--,	(39, N'ElectricConsumption'	,N'kilo_watt_hour'	,1	)		--missing reference in TCD.DimensionalSubunits
			--,	(40, N'Volume'	,N'therm'	,1	)							--missing reference in TCD.DimensionalSubunits
			--,	(40, N'Volume'	,N'deca_therm'	,2	)						--missing reference in TCD.DimensionalSubunits
			,	(40, N'Volume'	,N'cubic_foot'	,3	)
			--,	(40, N'Volume'	,N'btu'	,4	)								--missing reference in TCD.DimensionalSubunits
			,	(40, N'Volume'	,N'cubic_meter'	,5	)
			,	(41, N'Time'	,N'hour'	,1	)
			,	(41, N'Time'	,N'minute'	,2	)
			,	(42, N'Count'	,N'each'	,1	)
			,	(43, N'Hardness',N'grain'	,1	)
			,	(43, N'Hardness',N'parts_per_million'	,2	)
			,	(44, N'WaterHardness',N'grains_per_gallon'	,1	)
			,	(45, N'Weight',N'kilogram'	,1	)
			,	(45, N'Weight',N'pound'	,2	)


		MERGE	[TCD].DimensionalDisplayUnits	AS			TARGET
		USING	@tempDimensionalDisplayUnits	AS			SOURCE
			ON	TARGET.DisplayUnitId			=			SOURCE.DisplayUnitId
			AND	TARGET.Unit						=			SOURCE.Unit
			AND	TARGET.Subunit					=			SOURCE.Subunit
		WHEN	NOT MATCHED		THEN
				INSERT	(DisplayUnitID			,Unit			,Subunit			,OrderId			)
				VALUES	(SOURCE.DisplayUnitID	,SOURCE.Unit	,SOURCE.Subunit		,SOURCE.OrderId		);
	END




/*	DimensionalUsageKey

PRIMARY KEY: UsageKey
FK:		REFERENCES ConduitLocal.dbo.DimensionalUnits (Unit)

No foreign keys reference table 'DimensionalUnitsDefaults', or you do not have permissions on referencing tables.



*/
	BEGIN
		SET			@TableName				=			'DimensionalUsageKey'
		RAISERROR	(@TableName, 0, 1)

		--Declare temp table variable to hold input data
		DECLARE	@tempDimensionalUsageKey	TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	UsageKey					NVARCHAR(100)	NOT	NULL
			,	Unit						NVARCHAR(100)	NOT	NULL
			,	DisplayUnitId				INT				NOT	NULL
			)

		--Populate temp table variable with the input data
		INSERT	@tempDimensionalUsageKey	(
				UsageKey	,Unit	,DisplayUnitId	)
		VALUES	(	N'Area_Condensers'	,N'Area'	,2	)
			,	(	N'AvailableEnergy_Condensers'	,N'AvailableEnergy'	,3	)
			,	(	N'Conductivity_TCD'	,N'Entropy'	,33	)
			,	(	N'ConductivityElectrolytic_CommonUse'	,N'ConductivityElectrolytic'	,19	)
			,	(	N'Count_TCD'	,N'Count'	,42	)
			,	(	N'Efficiency_Condensers'	,N'Efficiency'	,23	)
			,	(	N'ElectricCurrent_Condensers'	,N'ElectricCurrent'	,11	)
			,	(	N'ElectricPotentialDifference_Condensers'	,N'ElectricPotentialDifference'	,30	)
			,	(	N'Energy_Content_Kg_TCD'	,N'ElectricTariff'	,35	)
			,	(	N'Energy_Content_L_TCD'	,N'ElectricTariff'	,35	)
			,	(	N'Energy_Content_TCD'	,N'ElectricTariff'	,35	)
			,	(	N'EnergyCost_btu_Tcd'	,N'Price'	,36	)
			,	(	N'EnergyCost_ccf_Tcd'	,N'Price'	,36	)
			,	(	N'EnergyCost_gal_Tcd'	,N'Price'	,36	)
			,	(	N'EnergyCost_mcf_Tcd'	,N'Price'	,36	)
			,	(	N'EnergyCost_Tcd'	,N'Price'	,36	)
			,	(	N'EnergyCost_thm_Tcd'	,N'Price'	,36	)
			,	(	N'EnergyCost_unit_Tcd'	,N'Price'	,36	)
			,	(	N'Electricity_TCD'	,N'ElectricConsumption'	,39	)
			,	(	N'Fraction_Concentration'	,N'Fraction'	,22	)
			,	(	N'Fraction_Concentration_ppmDefault'	,N'Fraction'	,29	)
			,	(	N'Fraction_Decimal'	,N'Fraction'	,21	)
			,	(	N'Gas_TCD'	,N'Volume'	,40	)
			,	(	N'Hardness_TCD'	,N'Hardness'	,43	)
			,	(	N'HeatTransferCoefficient'	,N'HeatTransferCoefficient'	,18	)
			,	(	N'Length_TubeDiameter'	,N'Length'	,12	)
			,	(	N'Length_TubeLength'	,N'Length'	,13	)
			,	(	N'MassRate_Condensers'	,N'MassRate'	,5	)
			,	(	N'MassRate_Condensers_Solids'	,N'MassRate'	,28	)
			,	(	N'NormalizedVolumeRate_Condensers'	,N'NormalizedVolumeRate'	,27	)
			,	(	N'pH_TCD'	,N'pH'	,32	)
			,	(	N'Power_Condensers_Duty_BtuDefault'	,N'Power'	,24	)
			,	(	N'Power_Condensers_Duty_MMBtuDefault'	,N'Power'	,17	)
			,	(	N'Power_Condensers_Load'	,N'Power'	,6	)
			,	(	N'Power_HX'	,N'Power'	,14	)
			,	(	N'Pressure_Condensers_inHgDefault'	,N'Pressure'	,7	)
			,	(	N'Pressure_Condensers_psiaDefault'	,N'Pressure'	,26	)
			,	(	N'Pressure_Condensers_psigDefault'	,N'Pressure'	,25	)
			,	(	N'Pressure_HX'	,N'Pressure'	,15	)
			,	(	N'Price_Electric_Tariff_Tcd'	,N'Price'	,36	)
			,	(	N'Price_euro_per_Kg_TCD'	,N'Price'	,36	)
			,	(	N'Price_euro_per_kwh_TCD'	,N'Price'	,36	)
			,	(	N'Price_euro_per_litre_TCD'	,N'Price'	,36	)
			,	(	N'Price_GasOil_Tcd'	,N'Price'	,36	)
			,	(	N'Price_Tcd'	,N'Price'	,36	)
			,	(	N'Redox_TCD'	,N'ElectricPotentialDifference'	,30	)
			,	(	N'Temparature_TCD'	,N'Temperature'	,1	)
			,	(	N'Temperature_CandF'	,N'Temperature'	,1	)
			,	(	N'TemperatureInterval_CandF'	,N'TemperatureInterval'	,8	)
			,	(	N'ThermalInsulance_CommonUse'	,N'ThermalInsulance'	,20	)
			,	(	N'Turbidity_CommonUse'	,N'Turbidity'	,31	)
			,	(	N'Time_TCD'	,N'Time'	,41	)
			,	(	N'Velocity_Condensers'	,N'Velocity'	,9	)
			,	(	N'VolumeRate_Condensers'	,N'VolumeRate'	,10	)
			,	(	N'VolumeRate_HX'	,N'VolumeRate'	,16	)
			,	(	N'VolumeRate_TCD'	,N'VolumeRate'	,16	)
			,	(	N'Volume_TCD'	,N'Volume'	,38	)
			,	(	N'Weight_kgs'	,N'Weight'	,37	)
			,	(	N'Weight_lbs'	,N'Weight'	,37	)
			,	(	N'Weight_TCD'	,N'Weight'	,45	)
			,	(	N'Weight_TCD_Kgs'	,N'Weight'	,37	)
			,	(	N'Weight_TCD_Lbs'	,N'Weight'	,37	)
			,	(	N'WaterHardness_TCD'	,N'WaterHardness'	,44	)


		MERGE	[TCD].DimensionalUsageKey			AS			TARGET
		USING	@tempDimensionalUsageKey	AS			SOURCE
			ON	TARGET.UsageKey				=			SOURCE.UsageKey
		WHEN	NOT MATCHED		THEN
				INSERT	(UsageKey			,Unit			,DisplayUnitId			)
				VALUES	(SOURCE.UsageKey	,SOURCE.Unit	,SOURCE.DisplayUnitId	);
	END








END	TRY
BEGIN	CATCH
		INSERT	#Errors_DimensionalUnitMasterDataSetup
		SELECT	@TableName			AS			TableName
			,	ERROR_NUMBER()		AS			ErrorNumber
			,	ERROR_MESSAGE()		AS			ErrorMessage
			,	ERROR_SEVERITY()	AS			ErrorSeverity
			,	ERROR_STATE()		AS			ErrorState
			,	ERROR_PROCEDURE()	AS			ErrorProcedure
			,	ERROR_LINE()		AS			ErrorLine
END	CATCH





ExitScript_DimensionalUnitMasterData:
--Select out errors, if any...
SELECT	*
FROM	#Errors_DimensionalUnitMasterDataSetup

--drop	temp	table...
IF	OBJECT_ID('tempdb..#Errors_DimensionalUnitMasterDataSetup')	IS NOT	NULL
	DROP	TABLE	#Errors_DimensionalUnitMasterDataSetup


RAISERROR	('Exiting DimensionalUnitMasterData script execution...', 0, 1)

