﻿/// <summary>
/// This is a selector for JQuery. It searches for text in the elements (similar to the 'contains' selector, but case insensitive)
/// </summary>
;(function($) {
    $.expr[":"].containsNoCase = function(el, i, m) {
        var search = m[3];
        if (!search) return false;
        return eval("/" + search + "/i").test($(el).text());
    };  
})(jQuery);


String.prototype.startsWith = function(str) 
{return (this.match("^"+str)==str)}

String.prototype.endsWith = function(str) 
{return (this.match(str+"$")==str)}
