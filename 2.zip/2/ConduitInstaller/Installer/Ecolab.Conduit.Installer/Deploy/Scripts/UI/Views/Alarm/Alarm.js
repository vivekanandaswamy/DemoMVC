﻿Ecolab.Views.Alarm = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'Alarm',
        templateUri: '/Scripts/UI/Views/Alarm/Alarm.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.Alarm.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('#alarmModal').modal('show');
    },

    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);

        function centerModal() {
            $("#alarmModal").css('display', 'block');
            var $dialog = $("#alarmModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });

        $('.modal-body').css('max-height', $(window).height() * 0.7);
    },
}