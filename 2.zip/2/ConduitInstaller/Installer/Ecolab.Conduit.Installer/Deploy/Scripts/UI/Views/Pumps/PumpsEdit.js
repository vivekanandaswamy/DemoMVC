Ecolab.Views.PumpsEdit = function(options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.selectedValue = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Pumps/PumpsEdit.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: {
            onRendered: function() {
                _this.onRendered();
            }
        }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.PumpsEdit.prototype = {
    setData: function(data) {
        this.data = data;
        if (data.data.ProductId == null)
            data.data = this.resetData(data.data);
        this.tm.Render(data, this);
    },
    resetData: function(data) {
        return {
            ControllerEquipmentId: '',
            ProductName: '',
            PumpCalibration: '',
            FlowMeterSwitchFlag: '',
            FlowMeterCalibration: '',
            MaximumDosingTime: '',
            ProductId: '',
            FlowSwitchTimeOut: '',
            ControllerEquipmentTypeId: data.ControllerEquipmentTypeId,
            EcolabAccountNumber: data.EcolabAccountNumber,
            ControllerId: data.ControllerId,
            ControllerTypeId: data.ControllerTypeId,
            ControllerTopicName: data.ControllerTopicName,
            LfsChemicalName: '',
            KFactor: '',
            TunnelHold: false,
            FlowDetectorType: '',
            FlowSwitchAlarm: false,
            FlowMeterAlarm: false,
            FlowMeterType: '',
            FlowAlarmDelay: '',
            FlowMeterPumpDelay: '',
            FlowMeterAlarmDelay: '',
            LfsChemicalNameTag: '',
            KfactorTag: '',
            CalibrationTag: ''
        };
    },
    onRendered: function() {
        var _this = this;
        this.attachEvents();

        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".k-tooltip").parent(".k-animation-container").hide();
        $(".custom-select").each(function() {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function() {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function() {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $('#ddlMeterSwitchFlag').trigger("change");
        $('#btnSavePump').attr("disabled", "disabled");
        _this.upDateIsDirty();
    },
    attachEvents: function() {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find("#btnSavePump").click(function() {
            _this.clearStatusMessage();
            if (_this.validate()) {
                _this.onPumpsEditClicked(_this.getPumpData());
            }
        });

        container.find("#btnCancel").click(function() {
            _this.onClancelClicked();
        });
        container.find("#back").click(function() {
            _this.onClancelClicked();
        });
        container.find('#ddlProducts').change(function() {
            var selected = $(this).find(':selected');
            var lfsName = $('#txtLfsChemicalName');
            lfsName.val(selected.val() != '' ? selected.text() : '');

            if ($(this).val() != "") {
                var maxDosage = container.find('#txtMaxDosingTime').val();
                if (maxDosage == null || !(parseInt(maxDosage) > 99 && parseInt(maxDosage) <= 250)) {
                    container.find('#txtMaxDosingTime').val(200);
                }
            }
        });
        container.find("#ddlMeterSwitchFlag").change(function() {
            if ($(this).val() == 'true') {
                var fsTimeOut = container.find('#txtflowSwitchTimeOut').val();
                if (fsTimeOut == 0) {
                    container.find('#txtflowSwitchTimeOut').val(2);
                }
            }
        });
        container.find("#ddlMeterSwitchFlag").change(function() {
            var flag = $(this).val();
            if (flag == 'false') {
                container.find("#divSwitchTimeOut").addClass('hide');
                container.find("#divMeterCalibration").removeClass('hide');
            } else if (flag == 'true') {
                container.find("#divSwitchTimeOut").removeClass('hide');
                container.find("#divMeterCalibration").addClass('hide');
            } else {
                container.find("#divSwitchTimeOut").addClass('hide');
                container.find("#divMeterCalibration").addClass('hide');
            }
        });
    },
    getPumpData: function() {
        var container = $(this.options.containerSelector);
        var products = container.find('#ddlProducts').val();
        var productId = products == 0 ? null : parseInt(products);
        return {
            ControllerEquipmentId: container.find('#hControllerEquipmentId').val(),
            ControllerEquipmentTypeId: container.find('#hControllerEquipmentTypeId').val(),

            //FlowMeterSwitchFlag: container.find('#ddlMeterSwitchFlag').val(),
            //FlowMeterCalibration: container.find('#txtflowMeterCalibration').val(),
            //MaximumDosingTime: container.find('#txtMaxDosingTime').val(),
            EcolabAccountNumber: container.find('#hEcoLabAccountNumber').val(),
            ControllerId: container.find('#hControllerId').val(),
            ProductId: productId,
            //FlowSwitchTimeOut: container.find('#txtflowSwitchTimeOut').val(),
            ControllerTypeId: container.find('#hControllerTypeId').val(),
            ControllerTopicName: container.find('#hControllerTopicName').val(),

            LfsChemicalName: container.find('#txtLfsChemicalName').val(),
            KFactor: container.find('#txtKfactor').val(),
            PumpCalibration: container.find('#txtPumpCalibration').val(),

            LfsChemicalNameTag: container.find('#txtLfsChemicalNameTag').val(),
            KfactorTag: container.find('#txtKfactorTag').val(),
            CalibrationTag: container.find('#txtPumpCalibrationTag').val(),

            TunnelHold: container.find('#cbTunnelHold').is(":checked"),
            FlowDetectorType: container.find('#ddlFlowDetectorType').val(),
            FlowSwitchAlarm: container.find('#cbFlowSwitchAlarm').is(":checked"),
            FlowMeterAlarm: container.find('#cbFlowMeterAlarm').is(":checked"),
            FlowMeterType: container.find('#ddlFlowMeterType').val(),
            FlowAlarmDelay: container.find('#txtFlowAlarmDelay').val(),
            FlowMeterPumpDelay: container.find('#txtFlowMeterPumpDelay').val(),
            FlowMeterAlarmDelay: container.find('#txtFlowMeterAlarmDelay').val(),
        };
    },
    onPumpsEditClicked: function() {
        if (this.options.eventHandlers.savePage)
            this.options.eventHandlers.savePage();
    },
    clearStatusMessage: function() {
        var _this = this;
        var container = $(_this.options.containerSelector);
        var messageDiv = container.find("#massage");
        messageDiv.text('');
    },

    validate: function() {
        var container = $(this.options.containerSelector);
        var decimalPattern = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;

        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            $.GetLocaleKeyValue('FIELD_PLEASECHECKYOURINPUT', 'Please check your input.')
        );
        container.find('#frmPumpEdit').validate({
            rules: {
                txtPumpCalibration: {
                    min: 0,
                    max: 10000,
                    required: container.find('#ddlProducts').val() != '' ? true : false,
                    regex: decimalPattern
                },
                txtMaxDosingTime: {
                    min: 100,
                    max: 250,
                    required: container.find('#ddlProducts').val() != '' ? true : false,
                    regex: decimalPattern
                },
                txtflowSwitchTimeOut: {
                    min: 0,
                    max: 999,
                    required: container.find('#ddlProducts').val() != '' ? true : false,
                    regex: decimalPattern
                },
                txtflowMeterCalibration: {
                    min: 0,
                    max: 1000,
                    required: container.find('#ddlProducts').val() != '' ? true : false,
                    regex: decimalPattern
                },
                txtLfsChemicalName: {
                    maxlength: 30
                },
            },
            messages: {
                txtPumpCalibration: {
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO10000', 'Please enter between 0 to 10000'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO10000', 'Please enter in between 0 to 10000'),
                    regex: $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', 'Enter only numerics'),
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERPUMPCALIBRATION', 'Please enter Pump Calibration')
                },
                txtMaxDosingTime: {
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN100TO250', 'Please enter between 100 to 250'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN100TO250', 'Please enter between 100 to 250'),
                    regex: $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', 'Enter only numerics'),
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERMAXDOSINGTIME', 'Please enter Max Dosing Time')
                },
                txtflowSwitchTimeOut: {
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO999', 'Please enter between 0 to 999'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO999', 'Please enter between 0 to 999'),
                    regex: $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', 'Enter only numerics'),
                    required: $.GetLocaleKeyValue('FIELD_PLEASENETERFLOWSWITCHTIMEOUT', 'Please enter Flow Switch TimeOut')
                },
                txtflowMeterCalibration: {
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO1000', 'Please enter between 0 to 1000'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO1000', 'Please enter between 0 to 1000'),
                    regex: $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', 'Enter only numerics'),
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERFLOWMETERCALIBRATION', 'Please enter Flow Meter Calibration')
                },
                txtLfsChemicalName: {
                    maxlength: $.GetLocaleKeyValue('FIELD_PLEASEENTERNOMORETHAN30CHARACTERS', 'Please enter no more than 30 characters'),
                }
            },
            onfocusout: function(element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function(error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));

                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
            }
        });
        var v2 = container.find('#frmPumpEdit').valid();
        return v2;
    },
    onClancelClicked: function() {
        if (this.options.eventHandlers.onClancelClicked) {
            this.options.eventHandlers.onClancelClicked();
        }
    },
    redirectToPumpsList: function(controllerId, controllerModelId, controllerTypeId) {
        var retVal = this.options.eventHandlers.onRedirection('./Pumps?ControllerId=' + controllerId + '&ControllerModelId=' + controllerModelId + '&ControllerTypeId=' + controllerTypeId);
        return retVal;
    },
    upDateIsDirty: function() {
        if (this.options.eventHandlers.upDateIsDirty) {
            this.options.eventHandlers.upDateIsDirty();
        }
    },
    showMessage: function(control) {
        var container = $(this.options.containerSelector);
        container.find("#massage").html(control);
    }
};