Ecolab.Views.NewCustomer = function (options) {
    var _this = this;

    var defaults = {
        eventHandlers: {
            onRendered: null
        },
        containerSelector: '',
        modalTemplate: null,
        blockUI: true,
        headerText: ''
    };

    this.settings = $.extend(defaults, options);
    this.mode = 'new';

    var selector = this.settings.containerSelector;

    if (this.settings.modalTemplate != null) {

        this.settings.modalTemplate.applyTemplate(selector, { Header: this.settings.headerText });
        selector = $(selector).css("cursor", "default");
        selector = selector.find('.PopUp_Content_Area');
    }

    this.tmpl = new TemplateManager({
        templateName: 'NewCustomer',
        templateUri: './Scripts/UI/Views/Customer/NewCustomer.html',
        parameters: [],
        containerElement: selector,
        eventHandlers: {
            onRendered: function () { _this.onRendered(); }
        }
    });


};

Ecolab.Views.NewCustomer.prototype = {

    setData: function (data, mode) {
        this.mode = mode;
        this.tmpl.Render(data,this);
    },

    getData: function () {
        var container = $(this.settings.containerSelector);

        var Customer = {
            CustomerId: container.find("#txtCustomerId").val(),
            CustomerName: container.find("#txtCustomerName").val()
        };

        return Customer;
    },

    onRendered: function () {
        var _this = this;
        var container = $(this.settings.containerSelector);
        if (this.mode == 'edit')
            $('.PopUp_Header').text('Edit Customer');
       
        if (this.settings.eventHandlers.onRendered)
            this.settings.eventHandlers.onRendered(this.mode);
    },

    validate: function () {
        this.resetErrors();     
        var v1 = $('#frmNewCustomer').validate({
            rules: {
                txtCustomerName: {
                    required: true
                },
                txtCustomerId: {
                    required: true,
                    digits: true
                }
            },
            messages: {
                txtCustomerName: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERTHENAME", "Please enter the Name")
                },
                txtCustomerId: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERCUSTOMERID", "Please enter the Customer Id"),
                    digits: $.GetLocaleKeyValue("FIELD_PLEASEENTERONLYNUMBERS", "Please enter only numbers")
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = $('#frmNewCustomer').valid();
        return v2;
    },

    resetErrors: function () {
        var container = $(this.settings.containerSelector);
        container.find("span.error").text("");
        container.find('#errorCon').hide();
    },

    showServerError: function (error) {

        var container = $(this.settings.containerSelector);

        if ($.isArray(error)) {
            switch (error[0].Code) {
                case '210':
                    container.find('#txtCustomerName').parent().find("span.errorMsg").html(error[0].Message);
                    break;
            }
        }
        else {
            container.find('#errorCon').text($.GetLocaleKeyValue("FIELD_UNKNOWNERROR", 'Unknown error occurred. Please try again later!')).show();
        }
    },
    showLoading: function () {
        var container = $(this.settings.containerSelector);
        this.wait = true;
        container.find(".footer .loading").show();
    },
    hideLoading: function () {
        var container = $(this.settings.containerSelector);
        this.wait = false;
        container.find(".footer .loading").hide();
    },
    showError: function (error) {
        var container = $(this.options.containerSelector);
        container.find(".errorCon").show().css('display', 'block').css('color', 'red').append(error);
    },
};