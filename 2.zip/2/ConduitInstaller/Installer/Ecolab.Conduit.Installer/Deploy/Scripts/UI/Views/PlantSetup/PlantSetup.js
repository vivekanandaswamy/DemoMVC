Ecolab.Views.PlantSetup = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRendered: function () { },
            onCancelPage: function () { },
            onRedirection: function () { },
            onSavePage: function () { }
        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'PlantSetupList',
        templateUri: './Scripts/UI/Views/PlantSetup/PlantSetupList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });

    this.initValidator();
};

Ecolab.Views.PlantSetup.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        $(this.tm.options.containerElement).html('');
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling by venkat
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });

    },
    initValidator: function () {
        $.validator.addMethod(
                "regex",
                function (value, element, regexp) {
                    var check = false;
                    var re = new RegExp(regexp);
                    return this.optional(element) || re.test(value);
                },
                "Please check your input."
        );
    },
    validate: function () {
        this.resetErrors();
        var pattern = /^([A-Za-z]:)(\\[A-Za-z_\-\s0-9\.]+)+$/;
        var pattern1 = /^[0-9]*$/;
        var pattern3 = /^([Jj][Pp][Gg]|\.[Gg][Ii][Ff]|\.[Jj][Pp][Ee][Gg]|\.[Pp][Nn][Gg])/
        var v1 = $('#frmPlantSetupDetails').validate({
            rules: {
                txtexportpath: {
                    required: true,
                    regex: pattern
                },
                txtDataLiveTime: {
                    required: true,
                    regex: pattern1
                },
                uploadimage: {
                    required: function () {

                        if ($('#thumbnail img').attr('src').length > 0) {
                            return false;
                        }
                        return true;
                    },
                    regex: pattern3
                }
            },
            messages: {
                txtexportpath: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERDATABASEEXPORTPATH", "Please enter the database export path"),
                    regex: $.GetLocaleKeyValue("FIELD_INVALIDDATABASEEXPORTPATH", "Invalid database export path")
                },
                txtDataLiveTime: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERONLYNUMBERS", "Please enter only numbers"),
                    regex: $.GetLocaleKeyValue("FIELD_INVALIDVALUESENTERONLYNUMBERS", "Invalid values, Enter only numbers")
                },
                uploadimage: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEIMPORTVALIDLOGO", "Please import valid Logo. Supported formats jpeg/png/gif"),
                        regex: $.GetLocaleKeyValue("FIELD_PLEASEIMPORTVALIDLOGO", "Please import valid Logo. Supported formats jpeg/png/gif")
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = $('#frmPlantSetupDetails').valid();
        return v2;
    },
    resetErrors: function () {
        var container = $(this.options.containerSelector);
        container.find("span.error").text("");
        container.find('#errorCon').hide();
    },
    verifyChanges: function (isRedirect) {
        var retVal = this.options.eventHandlers.onRedirection('./Home');
        return retVal;
    },
    saveChanges: function (isRedirect) {
        var _this = this;
        _this.onSaveClicked($(this).parent().attr('ruleId'), isRedirect);
    },
    attachEvents: function () {

        $("#tabSetupContainer").addClass("active");
        $("#tabGeneral").parent("li").addClass("active");
        $("#tabPlantSetup").parent("li").addClass("active");

        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        $('#top-mainmenu-container').find('.main-menu-item-Setup').addClass('active');

        container.find("#chkAllowManualRewash").kendoMobileSwitch({
            onLabel: "YES", offLabel: "NO",
            change: function () {
                // _this.isDirty = true;
                _this.clearMeassage();
                container.find('#btnSave').removeAttr('disabled');
                container.find('#btnCancel').removeAttr('disabled');
            }
        });

        $('#btnCancel').click(function () {
            _this.clearMeassage();
            _this.verifyChanges();
        });

        //container.find('.trackChange').change(function () {
        //    _this.isDirty = true;
        //    container.find('#btnSave').removeAttr('disabled');
        //    container.find('#btnCancel').removeAttr('disabled');
        //});

        container.find('.trackField').change(function () {
            _this.clearMeassage();
        });
        
        container.find('#btnSave').unbind("click");
        container.find('#btnSave').click(function () {
            _this.saveChanges();
        });

        container.find('.drop-area').click(function () {
            _this.clearMeassage();
            _this.onImageClicked($(this).parent().attr('ruleId'));
        });
        container.find('.deleteImg').click(function () {
            _this.clearMeassage();
            cleatImage();
            container.find('#btnSave').removeAttr('disabled');
            container.find('#btnCancel').removeAttr('disabled');
            $(this).toggle();
        });


        var fileDiv = document.getElementById("upload");
        var fileInput = document.getElementById("uploadimage");
        fileInput.addEventListener("change", function(e) {
            var files = this.files
            showThumbnail(files)

        }, false);

        fileDiv.addEventListener("click", function(e) {
            _this.clearMeassage();
            $(fileInput).show().focus().click().hide();
            e.preventDefault();
        }, false);

        function delayer() {
            window.location = "./Home";
        }
        function cleatImage() {
            container.find('#thumbnail img').attr('src', '').hide();
            container.find('#thumbnail').hide();
            container.find('#uploadimage').remove();
            container.find('#fileErrMsg').remove();

            container.find('#upload').after('<input type="file" style="display:none" id="uploadimage" name="uploadimage" class="common_upload">&nbsp;<span class="errorMsg" id="fileErrMsg" style="color:red"></span>');
            fileInput = $(_this.options.containerSelector).find('#uploadimage')[0];
            fileInput.addEventListener("change", function(e) {
                var files = this.files;
                showThumbnail(files);

            }, false);
        }

        function showThumbnail(files) {
            container.find('.deleteImg').hide();
            container.find('#resultMsg').text("");
            for (var i = 0; i < files.length; i++) {
                var file = files[i]

                var imageType = /image.*/
                if (!file.type.match(imageType)) {
                    cleatImage();
                    container.find('#resultMsg').text($.GetLocaleKeyValue("FIELD_INVALIDIMAGEFORMAT", "Invalid image format"));
                    return;
                }

                if (file.size > 500000) {
                    cleatImage();
                    container.find('#resultMsg').text($.GetLocaleKeyValue("FIELD_IMAGESIZESHOULDNOTEXCEEDMB", "Image Size should not exceed 0.5 MB"));
                    return;
                }
                container.find('.deleteImg').show();
                container.find('#thumbnail').show();
                container.find('#thumbnail img').remove()
                var image = document.createElement("img");
                var thumbnail = document.getElementById("thumbnail");
                image.file = file;
                $(thumbnail).empty();
                thumbnail.appendChild(image)

                var reader = new FileReader()
                reader.onload = (function (aImg) {
                    return function (e) {
                        aImg.src = e.target.result;
                    };
                }(image))
                var ret = reader.readAsDataURL(file);
                var canvas = document.createElement("canvas");
                ctx = canvas.getContext("2d");
                image.onload = function () {
                    ctx.drawImage(image, 100, 100);
                }
            }
        }
    },
    getData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var plant = {};
        plant.EcoalabAccountNumber = container.find('#hdnEANum').val();
        plant.CurrencyCode = container.find('#ddlCurrencyCodes').val().trim();
        plant.LanguageId = container.find('#ddlLanguages').val().trim();
        plant.UOMId = container.find('#ddlUoms').val().trim();
        plant.ExportPath = container.find('#txtexportpath').val().trim();
        plant.DataLiveTime = container.find('#txtDataLiveTime').val().trim();
        plant.BudgetCustomer = container.find('#ddlBudgetCustomer').val().trim();
        plant.Logo = container.find('#thumbnail img').attr('src');
        plant.AllowManualRewash = container.find('#chkAllowManualRewash').is(':checked');

        return plant;
    },
    onSaveClicked: function (id, isRedirect) {
        this.clearMeassage();
        var _this = this;
         sessionStorage.localizeData ='';
            window.localeData='';
        this.options.eventHandlers.onSavePage();
    },

    onImageClicked: function (id, linkTo) {
        this.clearMeassage();
        if (this.options.eventHandlers.onImageClicked)
            this.options.eventHandlers.onImageClicked(id, linkTo);
    },
    onPlantDataSaved: function () {
        var container = $(this.options.containerSelector);
        container.find('#successMsg').text($.GetLocaleKeyValue("FIELD_SAVEDSUCCESSFULLY", "Saved successfully")).removeClass('k-error-message').addClass('k-success-message');
    },
    onPlantDataSavedFailed: function (data, exception) {
        var container = $(this.options.containerSelector);
        if (exception == "The specified Export path does not exists.Please provide a valid path") {
            container.find('#successMsg').text($.GetLocaleKeyValue("FIELD_PLEASEADDPLANTLOGO", "Please upload a logo for the plant")).removeClass('k-success-message').addClass('k-error-message');
        }
        else if (exception == "Invalid Path") {
            container.find('#successMsg').text($.GetLocaleKeyValue("FIELD_INVALIDDATABASEEXPORTPATH", "Invalid database export path")).removeClass('k-success-message').addClass('k-error-message');
        }
        else {
            container.find('#successMsg').text($.GetLocaleKeyValue("FIELD_ERRORINSAVINGPLANTDETAILS", "Error in saving plant details")).removeClass('k-success-message').addClass('k-error-message');
        }
    },

    clearMeassage: function () {
        var container = $(this.options.containerSelector);
        container.find('#successMsg').text('');
    }
};