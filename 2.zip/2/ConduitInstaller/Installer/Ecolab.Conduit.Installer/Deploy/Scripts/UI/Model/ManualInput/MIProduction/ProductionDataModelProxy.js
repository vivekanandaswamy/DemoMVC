Ecolab.Model.ProductionDataModelProxy = function () {
};

Ecolab.Model.ProductionDataModelProxy.prototype =
{
    loadProductData: function (callBack, errorCallBack) {
        var url = "/Api/ManualProductionDataEntry/FetchMiWasherGroups";
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    FetchWasherFormulaByWasherGroup: function (id, callBack, errorCallBack) {
        var url = "/Api/ManualProductionDataEntry/FetchWasherFormulaByWasherGroup/{id}";
        var requestData = { "id": id };
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    FetchProductionData: function (manualProductionViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualProductionDataEntry/FetchProductionData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualProductionViewModel);
    },

    deleteProductData: function (manualProductionViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualProductionDataEntry/DeleteManualProduction";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualProductionViewModel);
    },

    updateProductData: function (manualProductionViewModel, callBack, errorCallBack) {
        var url = "/Api/ManualProductionDataEntry/SaveManualProduction";
        this.ServerRequest("Post", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualProductionViewModel);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ProductionDataModelProxy.prototype = $.extend({}, Ecolab.Model.ProductionDataModelProxy.prototype, base);
Ecolab.Model.ProductionDataModelProxy.prototype.base = base;