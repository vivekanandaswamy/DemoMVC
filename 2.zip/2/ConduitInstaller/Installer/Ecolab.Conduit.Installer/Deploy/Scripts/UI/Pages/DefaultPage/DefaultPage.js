﻿Ecolab.Presenters.DefaultPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    var globalData = null;
};
Ecolab.Presenters.DefaultPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initListView();
        this.initPortletConfigurationView();
        //Load homeView(show selected dashboards before login) only when MenuSections is null i.e, user is not logged in
        if (this.settings.accountInfo.MenuSections == null) {
            this.initHomeView();
        }
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onDashboardDataLoaded: function (data) { _this.onDashboardDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); },
            onHomeDataLoaded: function (data) { _this.onHomeDataLoaded(data); },
            onUserPortletDataLoaded: function (data) { _this.onUserPortletDataLoaded(data); },
            onUserPortletDataSaved: function (data) { _this.onUserPortletDataSaved(data); },
            chartDataRendered: function (id, data) { _this.onchartDataRendered(id, data); },
            chartDataRenderFailed: function (id, data) { _this.chartDataRenderFailed(id, data); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        if (this.settings.accountInfo.MenuSections == null) {
            this.Model.loadDashboardData();
        }
        this.onPageRendered();
        if (this.settings.accountInfo.MenuSections == null) {
            this.loadHomeData();
        }
        this.loadUserPortletData();
    },

    initListView: function () {
        var _this = this;
        if (!this.Views.DefaultView) {
            this.Views.DefaultView = new Ecolab.Views.Default(
                        {
                            containerSelector: '#pageContainer',
                            selectedMenuItem: _this.settings.accountInfo.SelectedMenuItem,
                            maxLevel:_this.settings.accountInfo.MaxLevel,
                            eventHandlers: {
                                onRendered: function () { },
                                onRuleClicked: function (id) { _this.navigateToConfigPage(id); },
                                onPortletConfigureClicked: function () { _this.onPortletConfigureClicked(); },
                                renderChart: function (id) { _this.renderChart(id); }
                            }
                        });
        }
    },

    initHomeView: function () {
        var _this = this;
        if (!this.Views.HomeView) {
            this.Views.HomeView = new Ecolab.Views.Home({
                containerSelector: '#myCarousel',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                }
            });
        }
    },

    initPortletConfigurationView: function () {
        var _this = this;
        if (!this.Views.PortletConfigurationView) {
            this.Views.PortletConfigurationView = new Ecolab.Views.PortletConfiguration({
                containerSelector: '#popupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRendered: function () { _this.onPortletRendered(); },
                    onUserPortletDataSaveClicked: function (userPortletData) { _this.onUserPortletDataSaveClicked(userPortletData); },
                }
            });
        }
    },

    onPageRendered: function () {
        if (this.settings.accountInfo.SelectedMenuItem == "Reports") {
            var breadCrumbData = {};
            breadCrumbData.name = $.GetLocaleKeyValue('FIELD_REPORTS', 'Reports');
            breadCrumbData.url = "";
            this.showPlantBreadCrumb("Report", breadCrumbData);
        }
        else if (this.settings.accountInfo.SelectedMenuItem != "Visualizations")
            $('#breadCrumbContainer').hide();
        if(this.settings.accountInfo.SelectedMenuItem == "Home")
        {
            $("#topnav").css({ "box-shadow": "0 0 2px rgba(113, 114, 117, 0.75)", "margin-bottom": "2px" });
        }
    },

    navigateToConfigPage: function (id) {
    },
    loadDashboardDataData: function () {

        this.Model.loadDashboardData();
    },
    onDashboardDataLoaded: function (data) {
        if (this.settings.accountInfo.Portlets)
        this.Views.DefaultView.setData(this.settings.accountInfo);
    },

    loadHomeData: function () {
        this.Model.loadHomeData();
    },

    onHomeDataLoaded: function (data) {
        this.Views.HomeView.setData(data);
    },

    loadUserPortletData: function () {
        this.Model.loadUserPortletData();
    },
    onUserPortletDataLoaded: function (data) {
        this.globalData = null;
        this.globalData = data;
        this.Views.DefaultView.setData(data);
    },
    onPortletConfigureClicked: function () {
        this.Views.PortletConfigurationView.setData(this.globalData);
    },
    onPortletRendered: function () {
        $('#portletModal').modal('show');
    },
    onUserPortletDataSaveClicked: function (userPortletData) {
        this.Model.saveUserPortletData(userPortletData);
    },
    onUserPortletDataSaved: function (data) {
        $('#portletModal').modal('hide');
        $("#portletModal").removeClass('fade');
        $(".modal-backdrop").remove();
        this.loadUserPortletData();
        this.Views.DefaultView.showMessage(data);
        
    },
    renderChart: function (id) {
        this.Model.renderChartData(id);
    },
    onchartDataRendered: function (id, data) {
        this.Views.DefaultView.chartDataRendered(id, data);
    },
    //chartDataRenderFailed: function (id, data) {
    //    this.Views.DefaultView.chartDataRendered(id, data);
    //}
};