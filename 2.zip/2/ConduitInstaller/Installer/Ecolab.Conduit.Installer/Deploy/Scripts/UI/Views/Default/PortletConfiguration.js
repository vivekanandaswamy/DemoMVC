Ecolab.Views.PortletConfiguration = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onPortletConfigureClicked: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/Default/PortletConfiguration.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.PortletConfiguration.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (_this.options.eventHandlers.onRendered)
            _this.options.eventHandlers.onRendered();
        $(".sortable").sortable({
            items: "li:not(:first-child)",
            change: function () {
                $('#btnSavePortletData').removeAttr('disabled');
            }
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        function centerModal() {
            $("#portletModal").css('display', 'block');
            var $dialog = $("#portletModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
        $('body').on('hidden.bs.modal', '.modal', function () {
            $(this).removeData('bs.modal');
        });

        container.find('#btnSavePortletData').click(function () {
            if (_this.validate()) {
                _this.onSaveClicked();
            }
            else {
                var messageDiv = $('#successMsg');
                messageDiv.html('At least one report needs to be enabled.');
                return false;
            }
        });
    },
    onSaveClicked: function () {
        var _this = this;
        var userPortletData = _this.getUserPortletData()
        if (this.options.eventHandlers.onUserPortletDataSaveClicked) {
            this.options.eventHandlers.onUserPortletDataSaveClicked(userPortletData);
        }
    },
    getUserPortletData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var userPortlets = [];

        var count = 0;
        container.find('.userPortLets').each(function (index, value) {
            count++;

            var id = $(this).attr("title");
            var email = $(this).val();

            portlet = {}
            portlet["PortletId"] = $(this).attr("attr-portletid");
            portlet["IsEnabled"] = $(this).find('input[name=chkPortlet]').is(":checked");
            portlet["DisplayOrder"] = count;

            userPortlets.push(portlet);
        });

        return userPortlets;
    },
    validate: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var checkedCount = container.find("input[name=chkPortlet]:checked").length;
        if (checkedCount == 0)
            return false;
        else
            return true;
    }
}
