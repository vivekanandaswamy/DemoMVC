Ecolab.Presenters.ContactPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ContactPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onPositionDataLoaded: function (data) { _this.onPositionDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.ContactView) {
            this.Views.ContactView = new Ecolab.Views.Contact(
                        {
                            containerSelector: '#tabContactsContainer',
                            accountInfo : _this.settings.accountInfo,
                            eventHandlers: {
                                rendered: function () { _this.loadPositionData(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
            this.Views.ContactView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup')
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
      
    },
    navigateToConfigPage: function (id) {
    },
    loadPositionData: function () {
        //if (this.Views.ContactView.positionData)
        this.Model.loadPositionData();
    },
    onPositionDataLoaded: function (data) {
        //debugger
        this.Views.ContactView.setPositionData(data);
    }
};