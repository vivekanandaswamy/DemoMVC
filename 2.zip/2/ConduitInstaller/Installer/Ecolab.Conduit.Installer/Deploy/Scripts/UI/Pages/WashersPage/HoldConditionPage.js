// JavaScript source code
Ecolab.Presenters.HoldConditionPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.message = "";
    this.ControllerModelId = 0;
    this.MachineNumber = 0;
    this.AlaramInputData = [];
};
Ecolab.Presenters.HoldConditionPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherTabsView();
        this.initHoldConditionView();

    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetAlarmData: function (data) { _this.onGetAlarmData(data); },
            onAlarmDataSaved: function (data) { _this.onAlarmDataSaved(data); },
            onAlarmDataSavingFailed: function (error, description) { _this.onAlarmDataSavingFailed(error, description); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initWasherTabsView: function () {
        var _this = this;
        if (!this.Views.WasherTabsView) {
            this.Views.WasherTabsView = new Ecolab.Views.WasherTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () {
                        _this.onTabsRendered();
                    },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    ontabFormulaClicked: function () { _this.ontabFormulaClicked(); },

                }
            });
        }
        this.Views.WasherTabsView.setData(this.settings.accountInfo);
    },
    initHoldConditionView: function () {
        var _this = this;
        if (!this.Views.HoldConditionView) {
            this.Views.HoldConditionView = new Ecolab.Views.HoldConditions({
                containerSelector: '#tabHoldConditionContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onSavePage: function () { _this.savePage(); },
                }
            });
        }
        // this.getAlarmData(this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.MachineNumber);

    },

    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHERGROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    //Getting Alarm Details
    getAlarmData: function (controllerModelId, machineNumber) {

        this.Model.getAlarmData(this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId, this.settings.accountInfo.MachineNumber, this.settings.accountInfo.WashergroupId, this.settings.accountInfo.EcolabAccountNumber);
    },
    ontabFormulaClicked: function () {
        var WasherGroupId = this.settings.accountInfo.WashergroupId;
        this.RedirectLocation('./WasherGroupFormula?' + 'id=' + WasherGroupId);
    },
    onGetAlarmData: function (data) {
        dr = [];
        dr.data = data;
        dr.TunnelId = this.settings.accountInfo.TunnelId
        dr.WashergroupId = this.settings.accountInfo.WashergroupId
        dr.NoofCompartments = this.settings.accountInfo.NoofCompartments
        dr.ControllerModelId = this.settings.accountInfo.ControllerModelId
        dr.ControllerTypeId = this.settings.accountInfo.ControllerTypeId
        dr.ControllerId = this.settings.accountInfo.ControllerId
        
        dr.message = this.message;
        this.Views.HoldConditionView.setData(dr);
       // this.Views.HoldConditionView.loadData(dr);
    },

    onTabsRendered: function () {
        this.getAlarmData(this.settings.accountInfo.ControllerModelId,this.settings.accountInfo.MachineNumber);
        this.Views.HoldConditionView.setData(0);
    },
    //Save Method
    savePage: function () {
        var view = this.Views.HoldConditionView;
        if (view) {
            var AlarmData = this.Views.HoldConditionView.getAlarmData();
        }

        AlarmData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        AlarmData.ControllerTypelId = this.settings.accountInfo.ControllerTypeId;
        AlarmData.MachineNumber = this.settings.accountInfo.MachineNumber;


        AlarmData.WashergroupId = this.settings.accountInfo.WashergroupId;
        AlarmData.WashergroupTypeId = this.settings.accountInfo.WashergroupTypeId;
        AlarmData.WasherName = this.settings.accountInfo.WasherName;
        AlarmData.NoofCompartments = this.settings.accountInfo.NoofCompartments;
        AlarmData.TunnelId = this.settings.accountInfo.TunnelId;
        AlarmData.WasherGroupTypeName = this.settings.accountInfo.WasherGroupTypeName;
        
        AlarmData.Active = 1;
        this.Model.saveAlarmData(AlarmData);

    },
    onAlarmDataSaved: function (data) {
        controllerModelId = this.ControllerModelId;
        machineNumber = this.MachineNumber;
        this.message = $.GetLocaleKeyValue('FIELD_ALARMSSAVEDSUCCESSFULLY','Alarms Saved Successfully');
        this.getAlarmData(this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.MachineNumber);
    },
    onAlarmDataSavingFailed: function (AlarmData, description) {
        this.message = '<label data-localize ="FIELD_ERROROCCUREDOVERWRITINGALARMDATA" class="k-error-message">' + description + '</label>';
        this.getAlarmData(this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.MachineNumber);
    },



}