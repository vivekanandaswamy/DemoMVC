﻿Ecolab.Model.VisualizationModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDashboardDataLoad: null,
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.VisualizationModelProxy = new Ecolab.Model.VisualizationModelProxy();
};

Ecolab.Model.VisualizationModel.prototype = {
    init: function () {
    },
    loadDashboardData: function (dashboardId) {
        var _this = this;
        this.VisualizationModelProxy.loadDashboardData(dashboardId,function (dashboardData) {
            _this.settings.eventHandlers.onDashboardDataLoad(dashboardData);
        });
    },
};

