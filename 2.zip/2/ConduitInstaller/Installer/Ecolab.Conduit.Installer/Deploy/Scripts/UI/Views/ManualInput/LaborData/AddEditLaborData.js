﻿Ecolab.Views.AddEditLaborData = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.cost = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/ManualInput/LaborData/AddEditLaborData.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.AddEditLaborData.prototype = {
    setData: function (data) {
        this.data = data;

        if (this.data.length>0 && this.data[0].StartDate != null && this.data[0].StartDate != null) {
            data[0].StartDate = (new Date(this.data[0].StartDate)).format("MM/dd/yyyy");
            data[0].EndDate = (new Date(this.data[0].EndDate)).format("MM/dd/yyyy");
        }
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find('.datetimepicker').datetimepicker({
            pickTime: false,
            defaultDate: new Date()
            
        });
        //container.find('.datetimepicker').data("DateTimePicker").setMaxDate(container.find(".dateTime").val());
      
        container.find('.datetimepicker').live('dp.show', function () {
            var _cal = this;
            container.find('.datetimepicker').each(function () {
                if (this !== _cal) {
                    $(this).data("DateTimePicker").hide()
                }
            });
        });
        container.find('#btnDelete').click(function () {
            _this.onDeleteClicked();
        });
    },
    onDeleteClicked: function () {
        // this.clearMessage();
        if (this.options.eventHandlers.onDeleteClicked)
            this.options.eventHandlers.onDeleteClicked();
    },
}