// JavaScript source code
Ecolab.Views.TunnelGeneral = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onDropDownChange: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.selectedValue = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Washers/Tunnel/TunnelGeneral.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: {
            onRendered: function () {
                _this.onRendered();
            }
        }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.TunnelGeneral.prototype = {
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;

        this.tm.Render(data, this);

        if (data.Mode == "Edit") {
            $("#ddlController").trigger('change');
            $('#txtNoOfCompartments').attr('disabled', 'disabled');
            $('#btnSaveTunnel').attr('disabled', 'disabled');
        }
        if (data.Mode == "Error") {
            $("#ddlController").trigger('change');
            $('#btnSaveTunnel').attr('disabled', 'disabled');
            $('#txtNoOfCompartments').attr('disabled', 'disabled');
            this.updateMode();
        }
        this.updateFlag();
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        this.disableTabs();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function () {
        var _this = this;
        _this.allowEdit = (this.options.accountInfo.MaxLevel >= 6);
        var container = $(this.options.containerSelector);

        container.find("#btnSaveTunnel").click(function () {
            _this.clearMassage();
            _this.onSaveClicked();
        });
        container.find("#ddlModel").change(function () {
            _this.clearMassage();
            $('#txtName').val($(this).val());
            $('#txtName').parent().find('span').empty();
            //$(id).parent().find(".ui-btn-text")
        });
        $('#btnCancel').click(function () {
            _this.clearMassage();
            _this.onCancelClick();
        });
        container.find("#ddlController").change(function () {
            if ($(this).val() != '') {
                _this.getWasherMode($(this).val());
            } else {
                var ddlWasherMode = $("#ddlWasherMode");
                ddlWasherMode.empty();
                ddlWasherMode.append('<option value="">-- Select --</option>');
                var selectedOption = $('#ddlWasherMode').find(":selected").text();
                $('#ddlWasherMode').next(".holder").text(selectedOption);
            }
        });
        container.find('#btnTunnelGeneralPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.data.EcoLabAccountNumber,
                WasherGroupId: _this.data.WasherGroupId,
                PageTitle: "Tunnel General",
                WasherId: _this.data.Id == null ? 0 : _this.data.Id,
                ControllerId: _this.data.ControllerId == null ? 0 : _this.data.ControllerId,
                RegionId: _this.data.RegionId,
                NumberOfCompartments: _this.data.NoofCompartments == null ? 0 : _this.data.NoofCompartments,
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });
    },

    getTunnelData: function () {
        var container = $(this.options.containerSelector);
        var maxLevel=this.options.accountInfo.MaxLevel;
        var tags = [];
        var plcTagValues = [];
        $(".upperCase").each(function (index, element) {

            var tagId = element.attributes['id'].value;
            var tagAddress = tagId.replace('txt', '');
            var tagNextValue = $('#' + tagId).parent().prev().find('input').val();
            var tagValue = $('#' + tagId).val();
            if (tagValue) {
                tags.push({
                    TagDescription: tagAddress,
                    TagAddress: tagValue,
                });
                plcTagValues.push({
                    Address: tagValue,
                    Topic: "ULTRAX1",
                    TagType: tagAddress,
                    IsValidTag: false,
                    Value: tagNextValue
                });
            }
        });
        if (tags.length>0) {
            tags.push({
                TagDescription: 'WasherNumberTag',
                TagAddress: "N148:" + $('#txtPlantWasher').val(),
            });
        }
        return {
            WasherModelName: container.find('#ddlModel').val(),
            ControllerId: container.find('#ddlController').val(),
            Size: container.find('#ddlSize').val(),
            Name: container.find('#txtName').val(),
            PlantWasherNumber: container.find('#txtPlantWasher').val(),
            Description: container.find('#txtDescription').val(),
            MaxLoad: container.find('#txtMaxLoad').val(),
            WasherMode: container.find('#ddlWasherMode').val(),
            AweActive: container.find('#chkAWE').is(":checked") ? true : false,
            NoofCompartments: container.find('#txtNoOfCompartments').val(),
            NoofTanks: container.find('#txtNoOfTanks').val(),
            PressExtractor: container.find('#ddlPress').val(),
            TransferType: container.find('#ddlTransferType').val(),
            ProgramNumber: container.find('#txtProgramNo').val(),
            Id: container.find('#hTunnelId').val(),
            EcolabAccountNumber: container.find('#hEcoLabAccountNumber').val(),
            WasherGroupId: container.find('#hWashergroupId').val(),
            RegionId: container.find('#hRegionId').val(),
            Role:maxLevel,
            //Tags Data
            TunnelTags: null,
            TunnelTagsList: tags,
            PlcTunnelTagModelTags: plcTagValues

        };
    },
    LoadSizeDropDown: function (data) {
        var container = $(this.options.containerSelector);
        var ddlSize = container.find("#ddlSize");
        ddlSize.empty();
        ddlSize.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlSize.append('<option value="' + this.WasherSize + '">' + this.WasherSize + '</option>');
        });
    },
    getWasherMode: function (controllerId) {
        if (this.options.eventHandlers.getWasherMode)
            this.options.eventHandlers.getWasherMode(controllerId);
    },
    updateMode: function () {
        if (this.options.eventHandlers.updateMode)
            this.options.eventHandlers.updateMode();
    },
    updateModeId: function (id) {
        $("#ddlWasherMode").val(id)
    },
    LoadWasherModeDropDown: function (data, Id) {
        var container = $(this.options.containerSelector);
        var ddlWasherMode = container.find("#ddlWasherMode");
        ddlWasherMode.empty();
        ddlWasherMode.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlWasherMode.append('<option value="' + this.Id + '">' + this.Name + '</option>');
        });

        if (Id != null) {
            $("#ddlWasherMode").val(Id)
            var selectedOption = $('#ddlWasherMode').find(":selected").text();
            $('#ddlWasherMode').next(".holder").text(selectedOption);
        }
        else {
            $('select[name=ddlWasherMode] option:eq(1)').attr('selected', 'selected');
            var selectedOption = $('#ddlWasherMode').find(":selected").text();
            $('#ddlWasherMode').next(".holder").text(selectedOption);
        }
    },
    updateFlag: function () {
        if (this.options.eventHandlers.updateFlag)
            this.options.eventHandlers.updateFlag();
    },
    validate: function () {
        _this = this;
        var container = $(this.options.containerSelector);

        var v1 = container.find('#frmTunnelGen').validate({
            rules: {
                txtName: { required: true, },
                ddlModel: {
                    required: true,
                },
                ddlController: {
                    required: true,
                },
                txtPlantWasher: {
                    required: true,
                    number: true,
                    min: 1,
                    max: 99999,
                },
                ddlWasherMode: {
                    required: true,
                },
                txtMaxLoad: {
                    required: true,
                    min: 1,
                    max: 999,
                    number: true
                },
                txtNoOfTanks: {
                    required: true,
                    number: true
                },
                txtNoOfCompartments: {
                    required: true,
                    min: 10,
                    max: 25,
                    number: true
                },
                ddlTransferType: {
                    required: true,
                },
                ddlPress: {
                    required: true,
                },
                txtProgramNo: {
                    required: true,
                    min: 0,
                    max: 127,
                    number: true
                },
            },
            messages: {
                txtName: { required: $.GetLocaleKeyValue('FIELD_PLEASEENTERNAME', 'Please enter Name'), },

                ddlModel: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTMODEL', 'Please select Model'),
                },
                ddlController: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTCONTROLLER', 'Please select Controller'),
                },
                txtPlantWasher: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERPLANTWASHERNUMBER', 'Please enter Plant Washer Number'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO99999', 'Please enter between 1 to 99999.'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO99999', 'Please enter between 1 to 99999.'),
                },
                ddlWasherMode: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWASHERMODE', 'Please select Washer Mode'),
                },
                txtMaxLoad: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERMAXIMUMLOAD', 'Please enter Maximum Load'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO999', 'Please enter in between 1 to 999'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO999', 'Please enter in between 1 to 999'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                txtNoOfTanks: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMBEROFTANKS', 'Please enter Number of Tanks'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                txtNoOfCompartments: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMBEROFCOMPARTMENTS', 'Please enter Number of Compartments'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN10TO25', 'Please enter in between 10 to 25'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN10TO25', 'Please enter in between 10 to 25'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                ddlTransferType: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTTRANSFERTYPE', 'Please select Transfer Type'),
                },
                ddlPress: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTPRESSEXTRACTOR', 'Please select Press/Extractor'),
                },
                txtProgramNo: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERPROGRAMNUMBER', 'Please enter Program Number'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO127', 'Please enter in between 0 to 127'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO127', 'Please enter in between 0 to 127'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });
        var v2 = container.find('#frmTunnelGen').valid();
        return v2;
    },
    onSaveClicked: function () {
        if (this.options.eventHandlers.savePage)
            this.options.eventHandlers.savePage();
    },
    getSize: function (model) {
        if (this.options.eventHandlers.getSize)
            this.options.eventHandlers.getSize(model);
    },
    onCancelClick: function () {
        var retval = this.options.eventHandlers.onRedirection('./WasherGroupFormula?' + 'id=' + this.options.accountInfo.WasherGroupId+"&data=Cancel");
        return retval;
       
    },
    clearMassage: function () {
        $('#massage').empty();
    },
    disableTabs: function () {
        var container = $(this.options.containerSelector);
        var TunnelId = container.find('#hTunnelId').val();
        if (TunnelId == '') {
            $('.sub-tabs li').not('.active, .backto-group').addClass('disabled');
            $('.sub-tabs li').not('.active').find('a').removeAttr("data-toggle");
            $('.sub-tabs li.disabled').children('a').click(function (e) {
                e.preventDefault();
            });
        }
    },
    enableTabs: function () {
        $('.sub-tabs li').not('.active').removeClass('disabled');
        $('.sub-tabs li').not('.active').find('a').attr("data-toggle", "tab");
    },
    showMessage: function (message) {
        this.clearMassage();
        var _this = this;
        $("#massage").html('');
        var messageDiv = $("#massage");
        messageDiv.html(message);

    },
}