﻿Ecolab.Presenters.MainHeaderPage = function (options) {

    this.Views = {};
    this.settings = $.extend(this.defaultSettings, options);
    this.settings = $.extend(this.defaults, options);
    this.init = function () {
        this.showMainHeader();
    };
};

Ecolab.Presenters.MainHeaderPage.prototype = {
    /************************************************************************/
    //ACCOUNT HEADER
    /************************************************************************/

    showMainHeader: function () {
        var _this = this;

        if (!this.Views.MainHeader) {
            this.Views.MainHeader = new Ecolab.Views.MainHeader({
                eventHandlers: {

                    logoutClicked: function () { _this.onLogoutClicked(); },
                    helpClicked: function () { _this.onHelpClicked(); },
                    plantSetupClicked: function () { _this.onPlantSetupClicked(); },
                    controllerSetupClicked: function () { _this.onControllerSetupClicked(); },
                    StorageTanksClicked: function () { _this.onStorageTanksClicked(); },
                    myProfileClicked: function () { _this.myProfileClicked(); },
                    mainMenuHomeLinkClicked: function () { _this.onMainMenuHomeLinkClicked(); },
                    mainMenuDashboardsLinkClicked: function () { _this.onMainMenuDashboardsLinkClicked(); }
                },
                containerSelector: '#topnav',
                templateName: 'MainHeader'
            });
        }
        this.Views.MainHeader.setData(this.settings.accountInfo);
    },

    onLogoutClicked: function () {
        window.location = '/LogOut.aspx';
    },

    onHelpClicked: function () {
        window.location = '/MyQuestions.aspx';
    },
    onMainMenuHomeLinkClicked: function () {
        window.location = '/Home';
    },
    onMainMenuDashboardsLinkClicked: function () {
        window.location = '/Dashboard';
    },
};
