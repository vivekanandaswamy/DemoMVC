Ecolab.Presenters.PlantUtilitySetupPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};

Ecolab.Presenters.PlantUtilitySetupPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initPlantUtilitySetupView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onPlantUtilitySetupDataLoaded: function (data) { _this.onPlantUtilitySetupDataLoaded(data); },
            onSaved: function () { _this.onSaved(); },
            onSaveFailed: function (data, exception) { _this.onSaveFailed(data, exception); },
            onPlantUtilityDataSaved: function () { _this.onPlantUtilityDataSaved(); },
            onPlantUtilityDataSavedFailed: function (data, exception) { _this.onPlantUtilityDataSavedFailed(data, exception); },
            setEnergyContentData: function (data) { return _this.setEnergyContentData(data); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupView) {
            this.Views.PlantSetupView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function () { _this.onTabRendered(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); }
                }
            });
        }
        this.Views.PlantSetupView.setData(this.settings.accountInfo);
    },
    initPlantUtilitySetupView: function () {
        var _this = this;
        if (!this.Views.PlantUtilitySetupView) {
            this.Views.PlantUtilitySetupView = new Ecolab.Views.PlantUtilitySetup({
                containerSelector: '#tabUtilitiesSetupContainer',
                accountInfo : _this.settings.accountInfo,
                eventHandlers: {
                    onRedirection: function (url) {return _this.RedirectLocation(url); },
                    onSavePage: function () { _this.savePage(); },
                    onCancelPage: function () { return _this.cancelPage(); },
                    getEnergyContent: function (gasTypeId) { return _this.getEnergyContent(gasTypeId); }
                   
                }
            });
        }
        
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = "PlantSetup";
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabRendered: function () {
        this.loadPlantUtilitySetupData();
    },
    loadPlantUtilitySetupData: function () { 
       this.Model.loadPlantUtilitySetupData();
    },
    onPlantUtilitySetupDataLoaded: function (data) {
        this.Views.PlantUtilitySetupView.setData(data);
    },
    savePage: function (data) {
        var view = this.Views.PlantUtilitySetupView;
        if (view) {
            if (view.validate()) {
                var plantUtility = view.getData();
                this.Model.savePlantutilityData(plantUtility);
                this.isDirty = false;
            }
            else {
                return false;
                //this.cancelPage();
            }
        }
    },
    onSaved: function () {
        $("#successMsg").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue('FIELD_SAVEDSUCCESSFULLY', 'Saved Successfully.'));
    },
    onSaveFailed: function (error) {
        this.Views.PlantUtilitySetupView.showErrorMessage(error);
    },
    onPlantUtilityDataSaved: function () {
       this.onSaved();
        //show sucess message in view.
    },
    onPlantUtilityDataSavedFailed: function (data, exception) {
        //bind exception to view
    },
    cancelPage: function () {
        return this.onBeforeNavigate();
    },
    getEnergyContent: function (gasTypeId) {
        return this.Model.getEnergyContent(gasTypeId)
    },
    setEnergyContentData: function (data) {
        this.Views.PlantUtilitySetupView.setEnergydata(data);
    }

};