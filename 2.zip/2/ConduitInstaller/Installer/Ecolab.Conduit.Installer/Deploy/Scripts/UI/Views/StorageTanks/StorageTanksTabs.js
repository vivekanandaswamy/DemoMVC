Ecolab.Views.StorageTanksTabs = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'StorageTanksTabs',
        templateUri: './Scripts/UI/Views/StorageTanks/StorageTanksTabs.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.StorageTanksTabs.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    resetGrids: function () {
        var container = $(this.options.containerSelector);
        /*Handle Controller Setup List grid*/
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        $('#top-mainmenu-container').find('.main-menu-item-Setup').addClass('active');
        container.find('#tabGeneral').click(function () {
            container.find('.ControllerSetupdtls_tabs,.tab-pane').removeClass('active');
            container.find('#tabGeneralContainer').html('').addClass('in active');

            _this.onGeneralTabClicked();
        });



        //var isInRole = false;
        //if (_this.data != null) {
        //    if (_this.data.Roles.indexOf("TMA") > -1)
        //        isInRole = true;
        //}
      
            
    },

    onGeneralTabClicked: function () {
        if (this.options.eventHandlers.generalTabClicked)
            this.options.eventHandlers.generalTabClicked();
    },
    onCustomerTabClicked: function () {
        if (this.options.eventHandlers.customerTabClicked)
            this.options.eventHandlers.customerTabClicked();
    }
};
function localize() {
    var opts = { language: "en-EN", pathPrefix: "Miscellaneous/GetLocalizationData" };
    $("[data-localize]").localize("local", opts);
}

//container.find('select').kendoDropDownList();
//container.find("#Input_Control_4_18, #Input_Control_4_20").kendoMobileSwitch({ onLabel: "YES", offLabel: "NO" });