// JavaScript source code
Ecolab.Model.PumpsModelProxy = function () {
};

Ecolab.Model.PumpsModelProxy.prototype =
{
    loadPumpsData: function (ecoLabAccountNumber, controlNumber, option, callBack, errorCallBack) {
        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber, "controlNumber": controlNumber, "showOption": option };
        var url = "/Api/Pumps/GetPumps";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadProducts: function (callBack, errorCallBack) {
        var requestData = { "ecoLabAccountNumber": 1 };
        var url = "/Api/Pumps/GetProductList";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updatePump: function (requestData, callBack, errorCallBack) {
        var url = "/Api/Pumps/UpdatePump";

        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    getControllerName: function (ecoLabAccountNumber, controlNumber, callBack, errorCallBack) {
        var requestData = { "ecolabAccountNumber": ecoLabAccountNumber, "controllerId": controlNumber };
        var url = "/Api/ControllerSetup/GetControllerDetailById";
        this.ApiRead("Pumps", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    validateTags: function (requestData, callBack, errorCallBack) {
        var url = "/api/Pumps/ValidateTags";
        return this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
}
var base = new Ecolab.Model.Common();
Ecolab.Model.PumpsModelProxy.prototype = $.extend({}, Ecolab.Model.PumpsModelProxy.prototype, base);
Ecolab.Model.PumpsModelProxy.prototype.base = base;