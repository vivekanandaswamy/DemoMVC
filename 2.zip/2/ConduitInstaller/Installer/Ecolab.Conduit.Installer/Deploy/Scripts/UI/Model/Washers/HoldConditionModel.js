// JavaScript source code
Ecolab.Model.HoldConditionModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onGetAlarmData: null,
            onAlarmDataSaved: null,
            onAlarmDataSavingFailed:null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.HoldConditionModelProxy = new Ecolab.Model.HoldConditionModelProxy();
};

Ecolab.Model.HoldConditionModel.prototype = {
    init: function () {
    },
    //getting alarm data
    getAlarmData: function (controllerModelId, controllerTypelId, machineNumber, washerGroupId, ecoLabAccountNumber) {
        var _this = this;
        this.HoldConditionModelProxy.getAlarmData(controllerModelId, controllerTypelId, machineNumber, washerGroupId, ecoLabAccountNumber, function (data) {
            _this.onGetAlarmData(data);
        });
    },
    onGetAlarmData: function (data) {
        var _this = this;
        _this.settings.eventHandlers.onGetAlarmData(data);
    },
    //Saving Alarm Data
    saveAlarmData: function (alarmData) {
        var _this = this;
        this.HoldConditionModelProxy.saveAlarmData(alarmData, function (data) {
            _this.settings.eventHandlers.onAlarmDataSaved(data);
        }, function (error, description) { _this.settings.eventHandlers.onAlarmDataSavingFailed(error, description); });
    },
   


}