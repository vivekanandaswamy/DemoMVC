Ecolab.Model.UtilityModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDeviceDataLoaded: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.UtilityModelProxy = new Ecolab.Model.UtilityModelProxy();
};

Ecolab.Model.UtilityModel.prototype = {
    init: function () {
    },
    loadDeviceData: function (callBackData) {        
        var _this = this;
        this.UtilityModelProxy.loadDeviceData(function (dData) {
            _this.settings.eventHandlers.onDeviceDataLoaded(dData, callBackData);
        });
    },
    loadDeviceType: function (callBackData) {
        var _this = this;
        this.UtilityModelProxy.loadDeviceType(function (deviceTypeData) {
            _this.settings.eventHandlers.onloadDeviceTypeLoaded(deviceTypeData, callBackData);
        });
    },
    loadDeviceModelByDeviceTypeId: function (DeviceTypeId, callBackData) {
        var _this = this;
        this.UtilityModelProxy.loadDeviceModelByDeviceTypeId(DeviceTypeId, function (deviceModelData) {
            _this.settings.eventHandlers.onloadDeviceModelByDeviceTypeIdLoaded(deviceModelData, callBackData);
        });
    },
    loadUtilityOnAddNewPopupLoad: function (callBackData) {       
        var _this = this;
        this.UtilityModelProxy.loadUtilityOnAddNewPopupLoad(function (parentData) {
            _this.settings.eventHandlers.onloadUtilityOnAddNewPopupDataLoaded(parentData, callBackData);
        });
    },
    LoadUtilityEdit: function (id, callBackData) {
        var _this = this;
        this.UtilityModelProxy.LoadUtilityEditProxy(id, function (parentData) {
            _this.settings.eventHandlers.onLoadUtilityEditLoaded(parentData, callBackData);
        });
    }
};

