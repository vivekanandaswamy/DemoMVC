// JavaScript source code
Ecolab.Presenters.WasherPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.message = "";
};
Ecolab.Presenters.WasherPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetWasherDetailsReceived: function (data) { _this.onGetWasherDetailsReceived(data); },
            onWasherDeleted: function (Data) { _this.onWasherDeleted(Data); },
            onWasherDeletionFailed: function (Data) { _this.onWasherDeletionFailed(Data); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },

    initWasherView: function () {
        var _this = this;
        if (!this.Views.WasherViews) {
            this.Views.WasherViews = new Ecolab.Views.WasherList({
                containerSelector: '#tabContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onWasherDeleteClicked: function (isTunnel, id) { return _this.onWasherDeleteClicked(isTunnel, id) },
                    onWasherDeletionFailed: function (error, description) { _this.onWasherDeletionFailed(error, description); },
                }
            });
        }
        _this.getWasherDetails();
    },

    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHERS', 'Washers')
        breadCrumbData.url = "/Washers";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },

    //getting grid data
    getWasherDetails: function () {
        this.Model.getWasherDetails(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
    },
    onGetWasherDetailsReceived: function (data) {
        if (this.settings.accountInfo.Massage != '') {
            if (this.settings.accountInfo.Massage == 'TunnelSaved') {
                this.message = '<label data-localize ="FIELD_TUNNELDETAILSSAVEDSUCCESSFULLY" class="k-success-message">Tunnel Details Saved successfully.</label>';
            }
            if (this.settings.accountInfo.Massage == 'TunnelUpdated') {
                this.message = '<label data-localize ="FIELD_TUNNELDETAILSUPDATEDSUCCESSFULLY" class="k-success-message">Tunnel Details Updated successfully.</label>';
            }
        }
        dr = {};
        dr.data = data;
        dr.Count = data.length;
        dr.message = this.message;
        this.Views.WasherViews.setData(dr);
    },

    //delete functionality
    onWasherDeleteClicked: function (isTunnel, id) {
       this.DeleteConformation(isTunnel, id)
    },
    onWasherDeleted: function (WasherGroupData) {
        this.settings.accountInfo.Massage = "";
        this.message = '<label data-localize ="FIELD_WASHERDELETEDSUCCESSFULLY" class="k-success-message">Washer deleted successfully.</label>';
        //this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">Formula deleted successfully.</label>');
        this.loadNavigationMenuListView();
        this.getWasherDetails();
    },
    onWasherDeletionFailed: function (error, description) {
        this.message = '<label data-localize ="FIELD_WASHERDELETIONFAILED" class="k-error-message">Washer deletion failed.</label>';
        //this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">Formula deleted successfully.</label>');
        this.getWasherDetails();
    },
    DeleteConformation: function (isTunnel, id) {
        var _this = this;

        var returnVale = false;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHER', 'Are you sure you want to delete this Washer?'),
            Buttons: {
                Ok: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Model.onDeleteWasher(isTunnel, id, _this.settings.accountInfo.EcolabAccountNumber);

                    },
                    CallbackParameters: null
                },
                Cancel: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        returnVale = false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return returnVale;
    },
}