Ecolab.Views.ControllerSetup = function (options) {
    var defaults = {
        containerSelector: null,
        dynamicHTMLSelector: null,
        metaData:null,
        eventHandlers: {
            rendered: function () { },
            dynamicRendered: function () { },
            onControllerModelSelected: null,
            onControllerTypeSelected: null,
            onSaveClicked: function () { },
            onCancelClicked: function () { },
            onRedirection: function () { },
            onSavePage: function() {}

        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'ControllerSetup',
        templateUri: './Scripts/UI/Views/ControllerSetup/ControllerSetup.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.dynamicTm = new TemplateManager({
        templateName: 'DynamicTM',
        templateUri: './Scripts/UI/Views/ControllerSetup/Dynamic.html',
        parameters: [],
        containerElement: this.options.dynamicHTMLSelector,
        eventHandlers: { onRendered: function () { _this.onDynamicUIRendered(); } }
    });
    //this.isDirty = false;
    this.dataList = {};
};
Ecolab.Views.ControllerSetup.prototype = {
    setData: function (data) {
        this.data = data;
        this.dataList.ControllerModel = data;
        data = this.dataList;
        if (this.options.accountInfo.ControllerId != "-1" && this.options.accountInfo.ControllerModelId != "-1") {
            data.ControllerModelId = this.options.accountInfo.ControllerModelId;
        }
        else {
            data.ControllerModelId = -1;
        }
        this.tm.Render(data, this);
    },
    setControllerTypeData: function (data) {
        this.data = data;
        this.dataList.ControllerType = data;
        data = this.dataList;
        if (this.options.accountInfo.ControllerId != "-1" && this.options.accountInfo.ControllerModelId != "-1" && this.options.accountInfo.ControllerTypeId != "-1") {
            data.ControllerModelId = this.options.accountInfo.ControllerModelId;
            data.ControllerTypeId = this.options.accountInfo.ControllerTypeId;
        }
        else {
            data.ControllerModelId = -1;
            data.ControllerTypeId = -1;
        }
        this.tm.Render(data, this);
    },
    setDynamicUI: function (metaData) {
        if (this.options.accountInfo.MaxLevel > 6)
            metaData.Mode = "Edit";
        else if (this.options.accountInfo.MaxLevel > 5)
            metaData.Mode = "View";
        if (this.options.accountInfo.ControllerId != "-1") {
            metaData.ControllerId = this.options.accountInfo.ControllerId;
        }
        else {
            metaData.ControllerId = -1;
        }
        metaData.MaxLevel = this.options.accountInfo.MaxLevel;
        $.each(metaData[0].FieldGroupInfo, function (index, value) {
            if (metaData[0].FieldGroupInfo[index].FieldLabel.indexOf("Multiplier") != -1 && metaData[0].FieldGroupInfo[index].ControllerTypeId==2) {
                metaData[0].FieldGroupInfo[index].NoEdit = false;
            }
            else
                metaData[0].FieldGroupInfo[index].NoEdit = true;
        });
        this.metaData = metaData;
        this.dynamicTm.Render(metaData, this);
    },
    onRendered: function () {
        $('#btnContainer').addClass("hide");
        this.disableTabs();
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    onDynamicUIRendered: function () {
        $('#btnContainer').removeClass("hide");
        var _this = this;
        this.attachDynamicEvents();
        if (this.options.eventHandlers.dynamicRendered)
            this.options.eventHandlers.dynamicRendered();
        if (_this.dataList.ModelSelectedVal == 5 || this.options.accountInfo.ControllerModelId == 5) {
            $('.new_tabs li.tab').not('.active').addClass('disabled');
            $('.new_tabs li.tab').not('.active').find('a').removeAttr("data-toggle");
        }
        else {
            $('.new_tabs li.tab').not('.active').removeClass('disabled');
            $('.new_tabs li.tab').not('.active').find('a').attr("data-toggle", "tab");
        }
        this.enableFields();
    },    
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find('#ddlControllerModel').change(function () {
            _this.dataList.ModelSelectedVal = $(this).val();
          
            _this.onControllerModelSelected($(this).val());
        });
        container.find('#ddlControllerType').change(function () {
            _this.dataList.TypeSelectedVal = $(this).val();
            _this.onControllerTypeSelected(_this.dataList.ModelSelectedVal, $(this).val());
        });
        $('.checkBoxChecked').live('change', (function () {
           
                 _this.enableFields();
        }));
       
        container.find('#btnCancel').click(function () { _this.onCancelClicked(); });
        container.find('#btnSave').click(function () { return _this.onSaveClicked(); });
        container.find('select').kendoDropDownList();
    },
    onCancelClicked: function () {
        //if (this.isDirty) {
        //    if (confirm("Do you want to save changes?")) {
        //        this.onSaveClicked();
        //    }
        //    window.location = './ControllerSetupList';
        //}
        //else {
        //    window.location = './ControllerSetupList';
        //}
        var retVal = this.options.eventHandlers.onRedirection('/ControllerSetupList');
        return retVal;
    },
    getData:function() {
        var ControllerId = 0;
        if (this.options.accountInfo.ControllerId != "-1") {
            ControllerId = this.options.accountInfo.ControllerId;
        }
        var container = $(this.options.dynamicHTMLSelector);
        var dataArr = [];
        var maxLevel = this.options.accountInfo.MaxLevel;
        var controllerModelId = parseInt($('#ddlControllerModel').val());
        var controllerTypeId = parseInt($('#ddlControllerType').val());
        for (i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            for (j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var controller = {};
                var field = fieldGroup.FieldGroupInfo[j];
                controller.ControllerId = ControllerId;
                controller.EcolabAccountNumber = this.options.accountInfo.EcolabAccountNumber;
                controller.ControllerModelId = controllerModelId;
                controller.ControllerTypeId = controllerTypeId;
                controller.FieldGroupId = field.FieldGroupId;
                controller.FieldId = field.FieldId;
                controller.FieldName = field.FieldName;
                if (field.FieldType == "CHECKBOX")
                    controller.Value = String($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is(':checked'));
                else if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is("label"))
                    controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).text();
                else if (maxLevel != 8 && field.AccessToRole == 8)
                    controller.Value = field.FieldDefaultValue;
                else
                    controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();

                dataArr.push(controller);
            }
        }
        return dataArr;
    },
    onSaveClicked: function () {
        return this.options.eventHandlers.onSavePage();
    },
    validate: function () {
        //$('#frmControllerSetupDetails').validate({
        //    // your other plugin options
        //});

        //$('.requiredField').each(function () {
        //    $(this).rules('add', {
        //        required: true,
        //        messages: {
        //            required: "Field cannot be empty."
        //        }
        //    });
        //});

        //var v2 = $('#frmControllerSetupDetails').validate();
        var validator = $("#frmControllerSetupDetails").kendoValidator().data("kendoValidator");
        return validator.validate();
    },

       attachDynamicEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $(".k-datetimepicker").kendoDatePicker({ format: "MM/dd/yyyy" });
        $(".k-datetimepicker input").prop("readonly", true);
        $(".k-numerictextbox").kendoNumericTextBox({
            format: "{0:n0}",
            min: 0,
            decimals: 0
        });
        //$('.k-checkbox').kendoMobileSwitch({
        //    onLabel: "YES",
        //    offLabel: "NO",
        //    change: function (e) {
        //        //_this.isDirty = true;
        //        $('#btnSave').removeAttr('disabled');
        //        $('#btnCancel').removeAttr('disabled');
        //    }
        //});
        
        container.find('select').kendoDropDownList();
        //container.find(".tooltip-wanter").tooltip({ selector: ".tooltip-info", placement: "top" });

        //$(".k-formatted-value").hover(function () {
        //    var originaltitle = $(this).next(".tooltip-info").attr("data-original-title");
        //    $(this).attr("data-original-title", originaltitle);
        //});
    },
    onControllerModelSelected: function (controllerId) {
        if (this.options.eventHandlers.onControllerModelChange) {
            this.options.eventHandlers.onControllerModelChange(controllerId);
        }
    },
    onControllerTypeSelected: function (controllerModelId, controllerTypeId) {
        if (this.options.eventHandlers.onControllerTypeChange) {
            this.options.eventHandlers.onControllerTypeChange(controllerModelId, controllerTypeId);
        }
    },
    onMetaDataSaved: function (data, tabView) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERSAVEDSUCCESSFULLY", 'Controller Saved Successfully'));
        if (data && tabView) {
            var cData = {};
            cData.ControllerId = data;
            var controllerModelId = parseInt($('#ddlControllerModel').val());
            var controllerTypeId = parseInt($('#ddlControllerType').val());
            cData.ControllerModelId = controllerModelId;
            cData.ControllerTypeId = controllerTypeId;
            tabView.setController(cData);
        }
    },
    onMetaDataSavedFailed: function (data, exception) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append(exception);
    },
    disableTabs: function () {
            $('.new_tabs li.tab').not('.active').addClass('disabled');
            $('.new_tabs li.tab').not('.active').find('a').removeAttr("data-toggle");
            $('.new_tabs li.disabled').children('a').click(function (e) {
                e.preventDefault();
            });
    },
    enableFields: function () {
        $("#Input_Control_5_73,#Input_Control_5_74,#Input_Control_5_75,#Input_Control_11_111,#Input_Control_11_112,#Input_Control_11_113").parent().parent().addClass('clear');
        $("#Input_Control_13_142,#Input_Control_13_143,#Input_Control_13_144,#Input_Control_13_145").parent().parent().addClass('clear');
        var input = $("#Input_Control_5_73,#Input_Control_5_74,#Input_Control_5_75,#Input_Control_11_111,#Input_Control_11_112,#Input_Control_11_113,#Input_Control_13_143,#Input_Control_13_144,#Input_Control_13_145");

        if ($("#Input_Control_5_72,#Input_Control_11_110,#Input_Control_13_142").attr('checked')) {
            input.removeAttr("disabled", "disabled");
        }
        else {
            input.attr("disabled", "disabled");
            input.siblings('.k-tooltip-validation').remove();
        }
    }
};