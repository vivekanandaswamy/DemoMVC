Ecolab.Model.TunnelCompartmentModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDropDownDataLoaded: null,
            onSaved: function () { },
            onSaveFailed: function () { },
            onComaprtmentsLoad: function () { },
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.TunnelCompartmentModelProxy = new Ecolab.Model.TunnelCompartmentModelProxy();
};
Ecolab.Model.TunnelCompartmentModel.prototype = {
    init: function () {
    },
    loadDropDownsData: function (ecoLabAccountNumber, regionId, controllerId, tunnelId, washerGroupId) {
        var _this = this;
        _this.TunnelCompartmentModelProxy.loadDropDownsData(ecoLabAccountNumber, regionId, controllerId, tunnelId,washerGroupId, function (data) {
            _this.settings.eventHandlers.onDropDownDataLoaded(data);
        });
    },
    save: function (tunnelData) {
        var _this = this;
        var tunnelDataOriginal = tunnelData;
        _this.TunnelCompartmentModelProxy.saveTunnelData(tunnelData, function (data) {
            _this.settings.eventHandlers.onSaved(tunnelDataOriginal);
        },
        function (error, description) {
            _this.settings.eventHandlers.onSaveFailed(description, tunnelDataOriginal);
        });
    },
    loadCompartmentsModelData: function (ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber) {
        var _this = this;
        _this.TunnelCompartmentModelProxy.loadCompartmentsModelData(ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, function (data) {
            _this.settings.eventHandlers.onComaprtmentsLoad(data);
        });
    },
}