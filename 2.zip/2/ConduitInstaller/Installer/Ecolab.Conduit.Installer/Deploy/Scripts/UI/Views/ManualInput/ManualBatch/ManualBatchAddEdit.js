﻿Ecolab.Views.ManualBatchAddEdit = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
          
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ManualInput/ManualBatch/ManualBatchAddEdit.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.ManualBatchAddEdit.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },


    onRendered: function () {
        var _this = this;
        this.attachEvents();
        //if (this.options.eventHandlers.rendered)
        //    this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        //Resetting validation messages
        container.find("#btnCancel").click(function () {
            $("#frmProductionData").validate().resetForm();
        });


       

    },



  


}