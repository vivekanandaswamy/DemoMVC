﻿Ecolab.Model.DefaultModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            chartDataRendered: null,
            chartDataRenderFailed: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.DefaultModelProxy = new Ecolab.Model.DefaultModelProxy();
};

Ecolab.Model.DefaultModel.prototype = {
    init: function () {
    },
    loadDashboardData: function (pageIndex, callBackData) {
        var _this = this;
        _this.onDataLoaded("data", true);
    },
    onDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onDashboardDataLoaded(data, callBackData);
    },
    loadHomeData: function () {
        var _this = this;
        _this.DefaultModelProxy.loadHomeData(function (data, callBackData) {
            _this.settings.eventHandlers.onHomeDataLoaded(data, callBackData);
        });
    },
    loadUserPortletData: function () {
        var _this = this;
        _this.DefaultModelProxy.loadUserPortletData(function (data, callBackData) {
            _this.settings.eventHandlers.onUserPortletDataLoaded(data, callBackData);
        });
    },
    saveUserPortletData: function (userPortletData) {
        var _this = this;
        this.DefaultModelProxy.saveUserPortletData(userPortletData, function (data) {
            _this.settings.eventHandlers.onUserPortletDataSaved(data);
        });
    },
    renderChartData: function (id) {
        var _this = this;
        this.DefaultModelProxy.renderChartData(id,
            function (data) { _this.settings.eventHandlers.chartDataRendered(id,data) },
            function (data, exception) { _this.settings.eventHandlers.chartDataRenderFailed(data, exception) })
    }
}

