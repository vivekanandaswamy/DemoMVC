Ecolab.Views.Dashboard = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/Dashboard/Dashboard.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.Dashboard.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    onRendered: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        var ddlDashboards = container.find('#ddlDashboards');
        var dashboardId = ddlDashboards.val();
        var typeId = ddlDashboards.find('option:selected', this).attr('data-typeid');
        _this.setIframe(dashboardId, typeId);

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
        // main - menu - item - Dashboards

        container.find('#ddlDashboards').change(function () {
            var dashboardId = $(this).val();
            if (dashboardId > 0) {
                var typeId = $(this).find('option:selected', this).attr('data-typeid');
                _this.setIframe(dashboardId, typeId);
            }
        });

    },
    setIframe: function (dashboardId, typeId) {
        var _this = this;
        if (dashboardId > 0 && typeId > 0) {
            var container = $(this.options.containerSelector);
            var url = _this.options.accountInfo.VisualizationUrl;
            container.find('#iframeDashboard').attr('src', url + 'visualization/Index?id=' + dashboardId + '&typeId=' + typeId + '');
            container.find('#iframeDashboard').height($(window).height());
        }
    }
};