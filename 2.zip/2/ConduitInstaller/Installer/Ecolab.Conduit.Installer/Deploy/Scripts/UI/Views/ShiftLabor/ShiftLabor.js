﻿Ecolab.Views.ShiftLabor = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            onAddShiftClicked: null,
            onDeleteShiftClicked: null,
            onEditShiftClicked: null,
            onDeleteBreakClicked: null,
            onAddLaborClicked: null,
            onDeleteLaborClicked: null,
            onEditLaborClicked: null,
            rendered: null,
            onCancelClicked: null,
            onEditLaborInlineClicked: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/ShiftLabor/ShiftLabor.html',
        paraShiftLabors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};
Ecolab.Views.ShiftLabor.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },
    showSucessMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var messageDiv = container.find("#message");
        messageDiv.html(message);
    },
    showShiftSucessMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var messageDiv = container.find("#message");
        messageDiv.html(message);
    },
    showErrorMessage: function (data, message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var messageDiv = container.find("#message");
        messageDiv.html(message);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        $("#tabGeneralContainer").addClass("active");
        $("#tabGeneral").parent("li").addClass("active");
        var _this = this;
        var container = $(this.options.containerSelector);
        //Event for adding a shift
        container.find("#addShift").click(function () {
            _this.onAddShiftClicked();
        })

        //Event for deleting a shift
        container.find("a#deleteShift").click(function () {
            _this.clearMessage();
            var shiftId = this.attributes["data-shiftid"].value;
            var dayId = this.attributes["data-dayid"].value;
            _this.options.eventHandlers.DeleteConformationShift(shiftId, dayId);

        })

        //Event for editing a shift
        container.find("a#editShift").click(function () {
            _this.clearMessage();
            this.attributes["data-isedit"].value = true;
            var shiftId = this.attributes["data-shiftid"].value;
            var dayId = this.attributes["data-dayid"].value;
            _this.onEditShiftClicked(shiftId, dayId);
        })

        //Event for deleting a break
        container.find("a#deleteBreak").click(function () {
            _this.clearMessage();
            var shiftId = this.attributes["data-shiftid"].value;
            var dayId = this.attributes["data-dayid"].value;
            var breakId = this.attributes["data-breakid"].value;
                _this.onDeleteBreakClicked(shiftId, dayId, breakId);
        }),

        //Event for adding labor
        container.find(".btnAddLabor").click(function () {
            var shiftId = this.attributes["data-shiftid"].value;
            var dayId = this.attributes["data-dayid"].value;
            _this.onAddLaborClicked(shiftId, dayId);
        })

        //Event for deleting labor
        container.find(".deleteLabor").unbind('click');
        container.find(".deleteLabor").click(function () {
            _this.clearMessage();
            var laborId = this.attributes["data-laborid"].value;
            _this.options.eventHandlers.DeleteConformation(laborId);
        })

        //Event for updating labor
        container.find(".updateLabor").unbind('click');
        container.find(".updateLabor").click(function () {
            var laborModel = {};
            laborModel.DayId = this.attributes["data-dayid"].value;
            laborModel.ShiftId = this.attributes["data-shiftid"].value;
            laborModel.LaborId = this.attributes["data-laborid"].value;
            laborModel.LaborTypeId = this.attributes["data-labortypeid"].value;
            laborModel.LaborTypeName = this.attributes["data-labortype"].value;
            laborModel.LocationId = this.attributes["data-laborlocid"].value;
            laborModel.LoactionName = this.attributes["data-location"].value;
            laborModel.LaborHours = this.attributes["data-laborhours"].value;
            laborModel.PricePerHr = this.attributes["data-laborprice"].value;
            _this.onEditLaborClicked(laborModel);
        });

        //Event for inline editing labor
        container.find(".editLaborInline").unbind('click');
        container.find(".editLaborInline").click(function () {
            _this.clearMessage();
            var tr = $(this).parents('.trEditable').first();
            tr.find(".noneditable").hide();
            tr.find(".editable").show();
        });

        //Event to check update on inline clicked
        container.find(".updateLaborInline").click(function () {
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            if (_this.validate() == true) {
                _this.isDirty = false;
                _this.onEditLaborInlineClicked(_this.getInlineLaborData($(this), tr));
            } else {
                return false;
            }

        });

        //Event to inline cancel
        container.find(".cancelLaborInline").click(function () {
            container.find(".noneditable").show();
            container.find(".editable").hide();
            $(this).parents('.trEditable').first().removeClass('dirty');
            container.find('span.errorMsg').text("");
            var tr = $(this).parents('.trEditable').first()
            _this.restoreData(tr);
        });
    },
    restoreData: function (tr) {
        var laborType = ($(tr).find("#lbrType").text()).trim();
        var laborLocation = $(tr).find("#lbrLocation").text().trim();
        //$(tr).find(".ddlLaborType  option:contains(" + laborType + ")").attr('selected', 'selected');
        $(tr).find(".ddlLaborLocation  option:contains(" + laborLocation + ")").attr('selected', 'selected');
        $(tr).find(".txtManHours").val($(tr).find("#lbrLaborHours").text().trim());
        $(tr).find(".txtAvgPricePerHour").val($(tr).find("#lbrLaborPrice").text().trim());
    },
    inlineEditSuccess: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var tr = container.find('.trEditable').filter('.dirty');
        tr.find(".noneditable").show();
        tr.find(".editable").hide();
    },
    inlineEditFailed: function () {
        var container = $(this.options.containerSelector);
        container.find('message').html('Update failed');
    },
    getInlineLaborData: function (e, tr) {
        var laborModel = {};
        laborModel.DayId = $(e).attr("data-dayid"),
        laborModel.ShiftId = $(e).attr("data-shiftid"),
        laborModel.LaborId = $(e).attr("data-laborid"),
        laborModel.LaborTypeId = parseInt($(tr).find('.ddlLaborTypeId').text());
        laborModel.LaborTypeName = $(tr).find('.ddlLaborType').text().trim();
        laborModel.LocationId = $(tr).find('.ddlLaborLocation').val();
        laborModel.LoactionName = $(tr).find('.ddlLaborLocation option:selected').text().trim();
        laborModel.LaborHours = $(tr).find('.txtManHours').val();
        laborModel.PricePerHr = $(tr).find('.txtAvgPricePerHour').val();
        return laborModel;
    },
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        //Validation for Target production
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "*"
       );

        var v1 = container.find('#formShiftLabor').validate({
            rules: {
                ManHours: {
                    required: true,
                    regex: pattern1
                },
                AvgPricePerHr: {
                    required: true,
                    regex: pattern1
                },
                Location: {
                    required: function () {
                        if ($('#ddlLaborLocation').val() == "Select") {
                            return false;
                        }
                        return true;
                    },
                }
            },
            messages: {
                ManHours: {
                    required: "*",
                    regex: "*"
                },
                AvgPricePerHr: {
                    required: "*",
                    regex: "*"
                },
                Location: {
                    required: "*",
                }
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });
        var v2 = container.find('#formShiftLabor').valid();
        return v2;
    },
    onAddShiftClicked: function () {
        this.clearMessage();
        if (this.options.eventHandlers.onAddShiftClicked)
            this.options.eventHandlers.onAddShiftClicked();
    },
    onDeleteShiftClicked: function (shiftId, dayId) {
        this.clearMessage();
        if (this.options.eventHandlers.onDeleteShiftClicked)
            this.options.eventHandlers.onDeleteShiftClicked(shiftId, dayId);
    },
    onEditShiftClicked: function (shiftId, dayId) {
        this.clearMessage();
        if (this.options.eventHandlers.onEditShiftClicked) {
            this.options.eventHandlers.onEditShiftClicked(shiftId, dayId);
        }
    },
    onDeleteBreakClicked: function (shiftId, dayId, breakId) {
        this.clearMessage();
        if (this.options.eventHandlers.onDeleteBreakClicked) {
            this.options.eventHandlers.onDeleteBreakClicked(shiftId, dayId, breakId);
        }
    },
    onAddLaborClicked: function (shiftId, dayId) {
        this.clearMessage();
        if (this.options.eventHandlers.onAddLaborClicked)
            this.options.eventHandlers.onAddLaborClicked(shiftId, dayId);
    },
    onDeleteLaborClicked: function (laborId) {
        this.clearMessage();
        if (this.options.eventHandlers.onDeleteLaborClicked)
            this.options.eventHandlers.onDeleteLaborClicked(laborId);
    },
    getLaborData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

    },
    onEditLaborClicked: function (laborModel) {
        this.clearMessage();
        if (this.options.eventHandlers.onEditLaborClicked)
            this.options.eventHandlers.onEditLaborClicked(laborModel);
    },
    onCancelClicked: function () {
        this.clearMessage();
        if (this.options.eventHandlers.onCancelClicked)
            this.options.eventHandlers.onCancelClicked();
    },

    onEditLaborInlineClicked: function (laborModel) {
        this.clearMessage();
        if (this.options.eventHandlers.onEditLaborInlineClicked)
            this.options.eventHandlers.onEditLaborInlineClicked(laborModel);
    },
    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find("#message").html('');
    },
    onConform: function (laborId) {
        _this = this;
        _this.onDeleteLaborClicked(laborId);
    },

    onShiftDeletConform: function (shiftId, dayId) {
        _this = this;
        _this.onDeleteShiftClicked(shiftId, dayId);
    },
}