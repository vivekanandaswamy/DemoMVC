Ecolab.Views.Contact = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Contact/ContactList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.positionData = null;
    this.allowEdit = false;
};

Ecolab.Views.Contact.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
    },
    setPositionData: function (data) {
        var _this = this;
        this.positionData = data;
    },

    attachEvents: function () {

        $("#tabGeneralContainer").addClass("active");
        $("#tabGeneral").parent("li").addClass("active");

        var _this = this;
        _this.allowEdit = (this.data.MaxLevel >= 6);
        var container = $(this.options.containerSelector);

        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Contact/GetContact",
                    dataType: "json",
                },
                create: {
                    url: "/api/Contact/CreateContact",
                    dataType: "json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTADDEDSUCCESSFULLY" class="k-success-message">Contact Added Successfully</label>');
                            if (grid && grid.dataSource) {
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTADDITIONFAILED" class="k-error-message">Contact Addition Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    url: "/api/Contact/Put",
                    dataType: "json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTUPDATEDSUCCESSFULLY" class="k-success-message">Contact Updated Successfully</label>');
                            if (grid && grid.dataSource) {
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTUPDATIONFAILED" class="k-error-message">Contact Updation Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/Contact/DeleteContact",
                    dataType: "json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTDELETEDSUCCESSFULLY" class="k-success-message">Contact Deleted Successfully</label>');
                        }
                        else {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTDELETIONFAILED" class="k-error-message">Contact Deletion Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                }
            },
            pageSize: 12,
            schema: {
                model: {
                    id: "Id",
                    fields: {
                        Id: { editable: false, type: "number" },
                        ContactFirstName: {},
                        ContactLastName: {},
                        ContactTitle: {},
                        Name: { editable: false },
                        ContactEmailAdresss: {},
                        ContactOfficePhone: { type: "text", spinners: false },
                        ContactMobilePhone: {
                            type: "text", validation: {
                                maxlength: function (input) {
                                    if (input.is("[name='ContactFirstName']") || input.is("[name='ContactPosition']") || input.is("[name='ContactTitle']") || input.is("[name='ContactLastName']")) {
                                        if (input.val().trim() == "") {
                                            return false;
                                        }
                                        else {
                                            return true;
                                        }
                                    }
                                    return true;
                                },
                            },
                        }
                    }
                }
            }
        });
        var addNew;
        if (_this.allowEdit) {           
            addNew = [{ text: "<span data-localize='FIELD_ADDCONTACT'>Add Contact</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
            Command = [
                //define the commands here
                {
                    name: "edit",
                    text: { edit: "", cancel: "", update: "" }, click: onEdit
                }, { name: "destroy", text: " " }, { name: "update", text: " ", click: showDetails }]
        }
        else {
            Command = [{ name: "view", text: "" }];
        }


        function onDataBound(arg) {
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            _this.tm.Localize();
        }

        if (container.find('#gridContact').data().kendoGrid)
            container.find('#gridContact').data().kendoGrid.destroy();

        container.find("#gridContact").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            dataBound: onDataBound,
            toolbar: addNew,
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            columns: [
            { command: Command, width: "90px", attributes: { "class": "align-center" } },
            {field: "ContactFirstName", template: "#: ContactLastName #, #: ContactFirstName #", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "15%",
                editor: function (container, options) { container.append(options.model.ContactLastName +', ' + options.model.ContactFirstName); }
            },
            { field: "ContactPositionName", title: "<span data-localize='FIELD_POSITION'>Position</span>", editor: positionDropDownEditor, width: "20%" },
            { field: "ContactOfficePhone", title: "<span data-localize='FIELD_OFFICEPHONE'>Office Phone</span>", format: "{0:0}", headerAttributes: { "class": "align-right" }, attributes: { "class": "align-right" }, width: "12%" },
            { field: "ContactMobilePhone", title: "<span data-localize='FIELD_MOBILEPHONE'>Mobile Phone</span>", format: "{0:0}", headerAttributes: { "class": "align-right" }, attributes: { "class": "align-right" }, width: "12%" },
            { field: "ContactEmailAdresss", title: "<span data-localize='FIELD_EMAIL'>E-mail</span>", },
            { field: "", title: "", headerAttributes: { "class": "left-no_border" }, attributes: { "class": "left-no_border" }, width: "12%" }
            ],
            editable: "inline",
        });
        function onEdit() { clearStatusMessage(); }
        wnd = $("#details")
                       .kendoWindow({
                           title: $.GetLocaleKeyValue("FIELD_EDITCONTACT", 'Edit Contact'),
                           modal: true,
                           visible: false,
                           resizable: false,
                           width: "373px",
                           height: "auto",
                           activate: function (e) {
                               _this.tm.Localize();
                           }
                       }).data("kendoWindow").center();
        detailsTemplate = kendo.template($("#editContact").html());

        function showDetails(e) {
            clearStatusMessage();
            e.preventDefault();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            dataItem.PositionData = _this.positionData;
            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator")
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSource.fetch(function () {
                    var Contact = dataSource.get(uid);
                    Contact.set("ContactFirstName", $("#txtContactFirstName").val().trim());
                    Contact.set("ContactTitle", $("#txtContactTitle").val().trim());
                    Contact.set("ContactLastName", $("#txtContactLastName").val().trim());
                    Contact.set("ContactPositionId", $("#ddlPosition").val().trim());
                    Contact.set("ContactPositionName", $("#ddlPosition option:selected").text().trim());
                    Contact.set("ContactEmailAdresss", $("#txtContactEmailAdresss").val().trim());
                    Contact.set("ContactOfficePhone", $("#txtContactOfficePhone").val().trim());
                    Contact.set("ContactMobilePhone", $("#txtContactMobilePhone").val().trim());
                    Contact.set("ContactFaxNumber", $("#txtContactFaxNumber").val().trim());
                    // dataSource.sync();
                });
                grid = $("#gridContact").data("kendoGrid");
                grid.saveChanges();
                wnd.close();
            }
            else {
                return false;
            }
        });
        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
        });

        var grid;
        $("#gridContact a.grid-add-new-record").unbind("click");
        $("#gridContact a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            var dataSource = $("#gridContact").data("kendoGrid").dataSource;
            var window = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                    title: $.GetLocaleKeyValue("FIELD_ADDCONTACT", 'Add Contact'),
                    modal: true,
                    resizable: false,
                    width: "373px",
                    height: "auto",
                    close: onClose,
                    visible: false,
                    activate: function (e) {
                        _this.tm.Localize();
                    }
                    //content: {
                    //    //sets window template

                    //    template: kendo.template($("#newContact").html())
                    //}
                })
                .data("kendoWindow").open();

            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});
            var data = {};
            data.PositionData = _this.positionData;
            detailsTemplate1 = kendo.template($("#newContact").html());
            window.content(detailsTemplate1(data));
            //binds the editing window to the form
            kendo.bind(window.element, model);
            window.center();
            //initialize the validator
            var validator = $(window.element).kendoValidator().data("kendoValidator")
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function (e) {
                if (validator.validate() == true) {
                    var contactPos = $("#ddlPosition").val().trim();
                    dataSource._data[0].ContactPositionId = contactPos;
                    dataSource.sync(); //sync changes
                    window.close();
                    window.element.remove();
                    grid = $("#gridContact").data("kendoGrid");
                }
                else {
                    return false;
                }

            });
            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function (e) {
                dataSource.cancelChanges(model); //cancel changes
                window.close();
                window.element.remove();
            });
            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                window.element.remove();
            }


        });
        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
        function positionDropDownEditor(container, options) {
            $('<input required data-text-field="PositionName" data-value-field="Id" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: _this.positionData,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("ContactPositionName", dataItem.PositionName);
                 options.model.set("ContactPositionId", dataItem.Id);
             }
         });
        }
    }
};