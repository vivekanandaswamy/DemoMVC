﻿Ecolab.Views.Sensor = function(options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onUtilityTypeChange: null,
            onUtilityLocationChange: null,
            onMachineChange: null,
            onSensorPopupLoad: null,
            onAddNewSensorPopupLoad: null,
            onEditSensorPopupLoad: null,
            checkDuplicates: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Sensor/Sensor.html',
        paraSensors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function() { _this.onRendered(); } }
    });
    this.initValidator();
    this.SensorData = null;
    this.isEdit = null;
    this.allowEdit = false;
    this.controllerCount = 0;
    this.isView = true;
    this.controllerId = null;
    this.ControllerType = null;
};

Ecolab.Views.Sensor.prototype = {
    setData: function(data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function() {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
    },
    setSensorData: function(data) {
        var _this = this;
        this.SensorData = data;
    },
    SetDefaultData: function(data) {
        var _this = this;

        //Dropdown Sensor type
        var ddlSensorType = $('#ddlSensorTypeName');
        ddlSensorType.empty();
        ddlSensorType.append(' <option value="">-- Select --</option>');
        $.each(data.SensorType, function() {
            ddlSensorType.append('<option value="' + this.SensorTypeId + '">' + this.Description + '</option>');
        });

        //Dropdown Sensor location
        var ddlSensorLocation = $('#ddlSensorLocation');
        ddlSensorLocation.empty();
        ddlSensorLocation.append(' <option value="">-- Select --</option>');
        $.each(data.SensorLocation, function() {
            ddlSensorLocation.append('<option value="' + this.GroupTypeId + '" data-type="' + this.GroupMainType + '" data-istunnel="' + this.IsTunnel + '">' + this.GroupDescription + '</option>');
        });

        //Dropdown Sensor controller
        var ddlSensorController = $('#ddlSensorController');

        //Dropdown Machine
        var ddlMachineName = $('#ddlMachineName');
        ddlMachineName.empty();
        ddlMachineName.append(' <option value="">-- Select --</option>');
        $.each(data.MachineList, function() {
            ddlMachineName.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
        });

        //Dropdown Chemical
        var ddlChemicalForChart = $('#ddlChemicalForChart');
        ddlChemicalForChart.empty();
        ddlChemicalForChart.append(' <option value="">-- Select --</option>');
        $.each(data.ChemicalList, function() {
            ddlChemicalForChart.append('<option value="' + this.Id + '">' + this.Description + '</option>');
        });

        //Dropdown for UoM
        var ddlAddUoM = $('#ddlUoM');
        ddlAddUoM.empty();
        ddlAddUoM.append('<option value="">-- Select --</option>');
        if (data.UoMList.length > 0) {
            $.each(data.UoMList, function() {
                ddlAddUoM.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
            });
            ddlAddUoM.prop("required", true);
        } else {
            ddlAddUoM.removeAttr('required');
        }

        if (data.Sensor != null) {
            ddlSensorType.val(data.Sensor.SensorType);
            ddlSensorLocation.val(data.Sensor.SensorLocationId);
            ddlSensorController.text(data.Sensor.ControllerName);
            ddlMachineName.val(data.Sensor.MachineId);
            $("#ddlOutPutType").val(data.Sensor.OutputType);
            if (data.Sensor.SensorLocationId == null && data.Sensor.MachineId == null) {
                //ddlSensorController.text("UtilityLogger");
                $(".divChemical").attr("style", "display:none");
                $(".analog").attr("style", "display:block");
                //$("#txtAnalogueImputNumber").attr("required", "required");
                $("#txtAnalogueImputNumber").val('');

            } else {
                $(".divChemical").attr("style", "display:block");
                ddlSensorController.text(data.Sensor.ControllerName);
                ddlChemicalForChart.val(data.Sensor.ChemicalforChartId);
                $(".analog").attr("style", "display:none");
                //$("#txtAnalogueImputNumber").removeAttr("required");
            }
            if (data.Sensor.ControllerModelId != null) {
                if (data.Sensor.ControllerModelId == 7) {
                    $(".analog").attr("style", "display:none");
                    //$("#txtAnalogueImputNumber").removeAttr("required");
                } else {
                    $(".analog").attr("style", "display:block");
                    //$("#txtAnalogueImputNumber").attr("required", "required");
                    $("#txtAnalogueImputNumber").val(data.Sensor.AnalogueImputNumber);
                }
            }
            $("#ddlDashboard").prop('checked', data.Sensor.DashboardActualValue);
            //$("#ddlDashboard").val(data.Sensor.DashboardActualValue);
            $("#ddlUoM").val(data.Sensor.UOM);
            controllerId = data.Sensor.ControllerId;
            controllerType = data.Sensor.ControllerType;
        }
    },

    //Setting values of dropdowns on Addon Popup
    SetDefaultDataOnAdd: function(data) {
        var _this = this;
        //Dropdown Sensor type
        var ddlSensorType = $('#ddlAddSensorTypeName');
        ddlSensorType.empty();
        ddlSensorType.append(' <option value="">-- Select --</option>');
        $.each(data.SensorType, function() {
            ddlSensorType.append('<option value="' + this.SensorTypeId + '">' + this.Description + '</option>');
        });


        //Dropdown Sensor location
        var ddlSensorLocation = $('#ddlAddSensorLocation');
        ddlSensorLocation.empty();
        ddlSensorLocation.append(' <option value="">-- Select --</option>');
        $.each(data.SensorLocation, function() {
            ddlSensorLocation.append('<option value="' + this.GroupTypeId + '" data-type="' + this.GroupMainType + '" data-istunnel="' + this.IsTunnel + '">' + this.GroupDescription + '</option>');
        });


        // Dropdown Sensor controller
        var ddlSensorController = $('#ddlAddSensorController');
        ddlSensorController.empty();
        ddlSensorController.append(' <option value="">-- Select --</option>');
        $.each(data.SensorController, function() {
            ddlSensorController.append('<option value="' + this.ControllerId + '"data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '">' + this.Name + '</option>');
        });

        //Dropdown Chemical
        var ddlChemicalForChart = $('#ddlAddChemicalForChart');
        ddlChemicalForChart.empty();
        ddlChemicalForChart.append(' <option value="">-- Select --</option>');
        $.each(data.ChemicalList, function() {
            ddlChemicalForChart.append('<option value="' + this.Id + '">' + this.Description + '</option>');
        });
    },

    //Setting cascading data for Machine/compartment,Controller basing on Sensor Location
    SetMachineCompartmentData: function(data) {
        var _this = this;
        if (_this.isEdit == true) {
            var ddlSensorController = $('#ddlSensorController');
            ddlSensorController.text(data.Controller[0].Name);
            if (data.Controller[0].Name != null) {
                if (data.Controller[0].ControllerId == "3") {
                    $(".analog").attr("style", "display:block");
                } else {
                    $(".analog").attr("style", "display:none");
                }
            }

            if (data.Machine.length > 0) {
                var _this = this;
                var ddlMachineCompartment = $('#ddlMachineName');
                ddlMachineCompartment.empty();
                ddlMachineCompartment.append('<option value="">-- Select --</option>');
                $.each(data.Machine, function() {
                    ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
                });
                var lblMachineCompartment = $('#lblMachineCompartment');

                var ddlLocation = $("#ddlSensorLocation option:selected");
                if (ddlLocation.data('type') == "WasherGroup" && ddlLocation.data('istunnel') == true) {
                    lblMachineCompartment.text('Compartment');
                    lblMachineCompartment.attr('data-localize', 'FIELD_COMPARTMENT');
                } else {
                    lblMachineCompartment.text('Machine');
                    lblMachineCompartment.attr('data-localize', 'FIELD_MACHINE');
                }

            } else {
                alert($.GetLocaleKeyValue('FIELD_NOMACHINEDATAFINDFORSENSERLOCATION', 'No Machine data found for the Sensor Loaction'));
                $('#ddlMachineName').empty();
            }
        } else if (this.isEdit == false) {
            var ddlSensorController = $('#ddlAddSensorController');
            ddlSensorController.empty();
            ddlSensorController.append('<option value="">-- Select --</option>');
            $.each(data.Controller, function() {
                ddlSensorController.append('<option value="' + this.ControllerId + '"data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '">' + this.Name + '</option>');

                //if (this.Name != null) {
                //    if (this.Name.trim().toLowerCase() != "utilitylogger") {
                //        $(".analogAdd").attr("style", "display:none");
                //    }
                //    else {
                //        $(".analogAdd").attr("style", "display:block");
                //    }
                //}
                //else
                {
                    $(".analogAdd").attr("style", "display:none");
                }
            });


            if (data.Machine.length > 0) {
                var _this = this;
                var ddlMachineCompartment = $('#ddlAddMachineName');
                ddlMachineCompartment.empty();
                ddlMachineCompartment.append('<option value="">-- Select --</option>');
                $.each(data.Machine, function() {
                    ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
                });
                var lblMachineCompartment = $('#lblAddMachineCompartment');

                var ddlLocation = $("#ddlAddSensorLocation option:selected");
                if (ddlLocation.data('type') == "WasherGroup" && ddlLocation.data('istunnel') == true) {
                    lblMachineCompartment.text('Compartment');
                    lblMachineCompartment.attr('data-localize', 'FIELD_COMPARTMENT');
                } else {
                    lblMachineCompartment.text('Machine');
                    lblMachineCompartment.attr('data-localize', 'FIELD_MACHINE');
                }

            } else {
                alert($.GetLocaleKeyValue('FIELD_NOMACHINEDATAFINDFORSENSERLOCATION', 'No Machine data found for the Sensor Loaction'));
                $('#ddlMachineName').empty();
            }

        }


    },

    //Setting Chemical for chart dropdown values
    SetChemicalforChart: function(data) {
        if (data.length > 0) {
            var _this = this;
            if (_this.isEdit == true) {
                var ddlChemicalForChart = $('#ddlChemicalForChart');
                ddlChemicalForChart.empty();
                ddlChemicalForChart.append('<option value="">-- Select --</option>');
                $.each(data, function() {
                    ddlChemicalForChart.append('<option value="' + this.Id + '">' + this.Description + '</option>');
                });
            } else if (_this.isEdit == false) {
                var ddlAddChemicalForChart = $('#ddlAddChemicalForChart');
                ddlAddChemicalForChart.empty();
                ddlAddChemicalForChart.append('<option value="">-- Select --</option>');
                $.each(data, function() {
                    ddlAddChemicalForChart.append('<option value="' + this.Id + '">' + this.Description + '</option>');

                });
            }
        } else {
            //alert($.GetLocaleKeyValue('FIELD_NODATARECIEVED', 'No Data Received'));
        }

    },

    //Setting UoM dropdown values
    SetUoMData: function(data) {
        var _this = this;
        if (_this.isEdit == true) {
            var ddlUoM = $('#ddlUoM');
            ddlUoM.empty();
            ddlUoM.append('<option value="">-- Select --</option>');
            if (data.UoM.length > 0) {
                $.each(data.UoM, function() {
                    ddlUoM.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
                });
                ddlUoM.prop("required", true);
            } else {
                ddlUoM.removeAttr('required');
            }
        } else if (_this.isEdit == false) {
            var ddlAddUoM = $('#ddlAddUoM');
            ddlAddUoM.empty();
            ddlAddUoM.append('<option value="">-- Select --</option>');
            if (data.UoM.length > 0) {
                $.each(data.UoM, function() {
                    ddlAddUoM.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
                });
            } else {
                ddlAddUoM.removeAttr('required');
            }
        }


    },

    initValidator: function() {
        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var check = false;
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Please check your input."
        );
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    attachEvents: function() {

        $("#tabUtilitiesContainer").addClass("active");
        $("#tabUtilities").parent("li").addClass("active");

        //  $("#frmSensor").kendoValidator();
        var _this = this;
        var wnd;
        var kendoWindow;
        var detailsTemplate;
        var trIndex = null;
        var container = $(this.options.containerSelector);
        _this.controllerCount = this.data.ControllerCount;
        //Set allow edit on role level
        _this.allowEdit = (this.data.MaxLevel >= 8);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');

        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Sensor/GetSensor",
                    dataType: "json"
                },
                create: {
                    url: "/api/Sensor/CreateSensor",
                    dataType: "json",
                    type: "POST",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            //window.location = "./Sensor";
                            $("#errorDiv").html('<label class="k-success-message" data-localize ="FIELD_SENSORADDEDSUCCESSFULLY">Sensor Added Successfully</label>');
                            kendoWindow.close();
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        } else {
                            var code = JSON.parse(jqXhr.responseText).split(",");
                            var errorMessage;
                            var errorMessageAdd = $('#errorMessageAdd');
                            var a;
                            if (parseInt(code[0]) == 101 || parseInt(code[0]) == 201 || parseInt(code[0]) == 301 || parseInt(code[0]) == 401 || parseInt(code[0]) == 501
                                || parseInt(code[0]) == 601 || parseInt(code[0]) == 602 || parseInt(code[0]) == 603 || parseInt(code[0]) == 701) {
                                errorMessage = '';
                                for (a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (code[a] == 101) {
                                        errorMessage = '<span data-localize ="FIELD_MAXIMUM1WEIGHTSENSORCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 1 Weight sensor can be connected to the same Washter-Tunnel</span>';
                                    } else if (code[a] == 201) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUM1CONDUCTIVITYSENSORCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel</span> ';
                                    } else if (code[a] == 301) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUM2PHSENSORSCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 2 pH sensors can be connected to the same Washter-Tunnel</span>';
                                    } else if (code[a] == 401) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUM6TEMPERATURESSENSORCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 6 Temperatures sensor can be connected to the same Washter-Tunnel</span>';
                                    } else if (code[a] == 501) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMONESENSORWITHTHESAMETYPECANBECONNECTEDTOONEMACHINE/COMPARTEMENT">Maximum one Sensor with the same type can be connected to one machine/Compartement</span>';
                                    } else if (parseInt(code[a]) == 601) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONTROLLERCANNOTBEEMPTYWHENSENSORLOCATIONISSELECTED">Controller can not be empty when Sensor Location is selected</span>';
                                    } else if (parseInt(code[a]) == 602) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MACHINE/COMPARTMENTCANNOTBEEMPTYWHENSENSORLOCATIONISSELECTED">Machine/Compartment can not be empty when Sensor Location is selected</span>';
                                    } else if (parseInt(code[a]) == 603) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_SENSORLOCATION&MACHINE/COMPARTMENTCANNOTBEEMPTYWHENCONTROLLERISSELECTED">Sensor Location & Machine/Compartment can not be empty when Controller is selected</span>';
                                    } else if (parseInt(code[a]) == 701) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONTROLLEROFTYPEUTILITYLOGGERISUNAVAILABLE">Controller of type UtilityLogger is unavailable</span>';
                                    }
                                }
                                errorMessageAdd.show();
                                errorMessageAdd.html('');
                                errorMessageAdd.html(errorMessage);
                            } else if (parseInt(code[0]) == 801 || parseInt(code[0]) == 802 || parseInt(code[0]) == 803
                                || parseInt(code[0]) == 804 || parseInt(code[0]) == 805 || parseInt(code[0]) == 806) {
                                errorMessage = '';
                                for (a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (parseInt(code[a]) == 801) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDSENSORTAG">Invalid Sensor Tag</span>';
                                    } else if (parseInt(code[a]) == 802) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDTAGADDRESSFORCALIBRATION(0/4MA)">Invalid Tag address for Calibration (0/4mA)</span>';
                                    } else if (parseInt(code[a]) == 803) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDTAGADDRESSFORCALIBRATION(20MA)">Invalid Tag address for Calibration (20mA)</span>';
                                    } else if (parseInt(code[a]) == 804) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_SENSORTAGALREADYEXISTS">Sensor Tag already exists</span>';
                                    } else if (parseInt(code[a]) == 805) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_TAGADDRESSFORCALIBRATION(0/4MA)ALREADYEXISTS">Tag address for Calibration (0/4mA) already exists</span>';
                                    } else if (parseInt(code[a]) == 806) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_TAGADDRESSFORCALIBRATION(20MA)ALREADYEXISTS">Tag address for Calibration (20mA) already exists</span>';
                                    }
                                }
                                errorMessageAdd.show();
                                errorMessageAdd.html('');
                                errorMessageAdd.html(errorMessage);
                            } else if (jqXhr.status == 300) {
                                if (confirm(JSON.parse(jqXhr.responseText))) {
                                    dataSource._data[0].OverridePlcValues = true;
                                    dataSource.sync();
                                } else {

                                }
                                errorMessageAdd.hide();
                                errorMessageAdd.html('');
                            } else {
                                $("#errorDiv").html('<label class="k-error-message" data-localize ="FIELD_SENSORADDITIONFAILED">Sensor Addition Failed</label>');
                                dataSource.cancelChanges();
                                kendoWindow.close();
                            }
                        }
                        _this.tm.Localize();
                    }

                },
                update: {
                    url: "/api/Sensor/put",
                    dataType: "json",
                    type: "PUT",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            //window.location = "./Sensor";
                            $("#errorDiv").html('<label class="k-success-message" data-localize ="FIELD_SENSORUPDATEDSUCCESSFULLY">Sensor Updated Successfully</label>');
                            wnd.close();
                            if (grid) {
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                        } else {
                            var code = JSON.parse(jqXhr.responseText).split(",");
                            var errorMessageDiv = $('#errorMessage');
                            if (parseInt(code[0]) == 201 || parseInt(code[0]) == 301 || parseInt(code[0]) == 101 || parseInt(code[0]) == 401 || parseInt(code[0]) == 501) {
                                var errorMessage = '';
                                for (var a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (code[a] == 101) {
                                        errorMessage = '<span data-localize ="FIELD_MAXIMUM1WEIGHTSENSORCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 1 Weight sensor can be connected to the same Washter-Tunnel<span/>';
                                    } else if (code[a] == 201) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUM1CONDUCTIVITYSENSORCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel </span>';
                                    } else if (code[a] == 301) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUM2PHSENSORSCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 2 pH sensors can be connected to the same Washter-Tunnel</span>';
                                    } else if (code[a] == 401) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUM6TEMPERATURESSENSORCANBECONNECTEDTOTHESAMEWASHTERTUNNEL">Maximum 6 Temperature sensors can be connected to the same Washter-Tunnel</span>';
                                    } else if (code[a] == 501) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMONESENSORWITHTHESAMETYPECANBECONNECTEDTOONEMACHINE/COMPARTEMENT">Maximum one Sensor with the same type can be connected to one machine/Compartement</span>';
                                    }
                                }
                                errorMessageDiv.show();
                                errorMessageDiv.html('');
                                errorMessageDiv.html(errorMessage);
                                code = null;
                            } else if (parseInt(code[0]) == 801 || parseInt(code[0]) == 802 || parseInt(code[0]) == 803
                                || parseInt(code[0]) == 804 || parseInt(code[0]) == 805 || parseInt(code[0]) == 806) {
                                errorMessage = '';
                                for (a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (parseInt(code[a]) == 801) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDSENSORTAG">Invalid Sensor Tag</span>';
                                    } else if (parseInt(code[a]) == 802) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDTAGADDRESSFORCALIBRATION(0/4MA)">Invalid Tag address for Calibration (0/4mA)</span>';
                                    } else if (parseInt(code[a]) == 803) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_INVALIDTAGADDRESSFORCALIBRATION(20MA)">Invalid Tag address for Calibration (20mA)</span>';
                                    } else if (parseInt(code[a]) == 804) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_SENSORTAGALREADYEXISTS">Sensor Tag already exists</span>';
                                    } else if (parseInt(code[a]) == 805) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_TAGADDRESSFORCALIBRATION(0/4MA)ALREADYEXISTS">Tag address for Calibration (0/4mA) already exists</span>';
                                    } else if (parseInt(code[a]) == 806) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_TAGADDRESSFORCALIBRATION(20MA)ALREADYEXISTS">Tag address for Calibration (20mA) already exists</span>';
                                    }
                                }
                                errorMessageDiv.show();
                                errorMessageDiv.html(errorMessage);
                            } else if (jqXhr.status == 300) {
                                if (confirm(JSON.parse(jqXhr.responseText))) {
                                    dataSource._data[0].OverridePlcValues = true;
                                    dataSource.sync();
                                } else {

                                }
                                errorMessageDiv.hide();
                                errorMessageDiv.html('');
                            } else {
                                $("#errorDiv").html('<label class="k-error-message" data-localize ="FIELD_SENSORUPDATIONFAILED">Sensor Updation Failed</label>');
                                dataSource.cancelChanges();
                                kendoWindow.close();
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/Sensor/DeleteSensor",
                    dataType: "json",
                    type: "DELETE",
                    complete: function(jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label class="k-success-message" data-localize ="FIELD_SENSORDELETEDSUCCESSFULLY">Sensor Deleted Successfully</label>');
                        } else {
                            $("#errorDiv").html('<label class="k-error-message" data-localize ="FIELD_SENSORDELETIONFAILED">Sensor Deletion Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                },
            },
            change: function(e) {

            },
            requestStart: function(e) {
                var gridSensor = $("#gridSensor");
                gridSensor.data("kendoGrid").hideColumn("ControllerName");
                gridSensor.data("kendoGrid").hideColumn("AnalogueImputNumber");
                gridSensor.data("kendoGrid").hideColumn("DashboardActualValue");
                gridSensor.data("kendoGrid").hideColumn("OutputType");
            },
            pageSize: 12,
            schema: {
                model: {
                    id: "SensorNumber",
                    fields: {
                        SensorNumber: { editable: false, type: "number" },
                        SensorName: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_NAME", 'Name') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        SensorTypeName: { editable: false, validation: { required: true } },
                        SensorLocation: { editable: false, validation: { required: true } },
                        MachineName: { editable: false, validation: { required: true } },
                        OutputType: { editable: false, validation: { required: true } },
                        CalibrationValue4: {
                            editable: true,
                            validation: {
                                required: false,
                                validationMessage: "Value for 20mA is required",
                                maxlength: function(input) {
                                    if (input.is("[name='Calibration']") && input.val() != "") {
                                        input.attr("data-maxlength-msg", "Should be a number with maximum 3 decimal places");
                                        var pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,3})?$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        } else {
                                            return false;
                                        }
                                        return true;
                                    }
                                    return true;

                                }

                            }
                        },
                        UOM: { editable: true },
                        ControllerName: { editable: true },
                        AnalogueImputNumber: { editable: true },
                        ChemicalforChart: { editable: true },
                        DashboardActualValue: { editable: true },

                    }
                }
            }
        });

        //Set basing on roles Here
        var addNew, commands, editTitle, customWidth = "135px";
        if (_this.controllerCount > 0) {
            if (_this.allowEdit) {
                _this.isView = false;
                commands = [
                    {
                        name: "edit",
                        text: { edit: "", cancel: "", update: "" },
                        click: onEdit
                    }, { name: "destroy", text: " " }, { name: "update", text: " ", click: showDetails }
                ];
                addNew = [{ text: "<span data-localize='FIELD_ADDSENSOR'>Add Sensor</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
                editTitle = $.GetLocaleKeyValue("FIELD_EDITSENSOR", 'Edit Sensor');
            } else {
                _this.isView = true;
                commands = [{ name: "view", text: " ", click: showDetails }];
                addNew = "";
                customWidth = "55px";
                editTitle = "View Sensor";
            }
        } else {
            addNew = '<div class="grid-add-new-record">Please add a Controller before adding a sensor.</div>';
        }

        function onDataBound(arg) {
            $('.grid-add-new-record').removeClass('k-button k-button-icontext');
            $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            _this.tm.Localize();
        }

        function onEdit(e) { clearStatusMessage(); }

        if (container.find('#gridSensor').data().kendoGrid)
            container.find('#gridSensor').data().kendoGrid.destroy();

        container.find("#gridSensor").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                { command: commands, width: "87px", attributes: { "class": "align-center" } },
                { field: "SensorNumber", title: "<span data-localize='FIELD_NUMBER'>Number</span>", format: "{0:0}", width: "110px", attributes: { "class": "align-center" }, headerAttributes: { "class": "align-center" } },
                { field: "SensorName", title: "<span data-localize='FIELD_NAME'>Name</span>" },
                { field: "SensorTypeName", title: "<span data-localize='FIELD_SENSORTYPE'>Sensor-Type</span>" },
                { field: "SensorLocation", title: "<span data-localize='FIELD_SENSORLOCATION'>Sensor Location</span>" },
                { field: "MachineName", title: "<span data-localize='FIELD_MACHINECOMPARTMENT'>Machine/Compartment</span>" },
                { field: "OutputType", title: "OutPut Type", hidden: true, headerAttributes: { "data-localize": "FIELD_SENSOROUTPUT" } },
                { field: "CalibrationValue4", hidden: true, title: "<span data-localize='FIELD_CALIBRATION'>Calibration</span>", width: "100px", attributes: { "class": "align-right" }, headerAttributes: { "class": "align-right" } },
                {
                    field: "UOM",
                    title: "<span data-localize='FIELD_UOM'>UOM</span>",
                    template: function (data) { return data.UOM != null ? $.GetLocaleKeyValue(data.UOM, data.UOM) : ''; },
                    editor: function(container, options) { container.append($.GetLocaleKeyValue(options.model.UOM, options.model.UOM)); }
                },
                { field: "ControllerName", title: "Controller", hidden: true, headerAttributes: { "data-localize": "FIELD_CONTROLLER" } },
                { field: "AnalogueImputNumber", title: "Analog Input No", hidden: true, headerAttributes: { "data-localize": "FIELD_SENSORANALOGINPUTNUMBER" } },
                { field: "ChemicalforChart", title: "Chemical for Chart", hidden: true, headerAttributes: { "data-localize": "FIELD_SENSORCHEMICALFORCHART" } },
                { field: "DashboardActualValue", title: "Display In DashBoard", hidden: true, headerAttributes: { "data-localize": "FIELD_SENSORDISPLAYINDASHBOARD" } }
            ],
            editable: "inline",

        });

        wnd = $("#details")
            .kendoWindow({
                title: editTitle,
                modal: true,
                visible: false,
                resizable: false,
                width: "373px",
                height: "auto",
                open: onOpen,
                activate: function(e) {
                    _this.tm.Localize();
                }
            }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editSensor").html());
        detailsTemplateView = kendo.template($("#editSensorView").html());
        var dataItem = null;

        //Impliment Cascading population of dropdowns here
        function onOpen(e) {
            if (_this.options.eventHandlers.onEditSensorPopupLoad) {
                _this.options.eventHandlers.onEditSensorPopupLoad(dataItem.SensorNumber);
            }
            if (!_this.isView) {
                cascadeEdit();
            }
        }

        //Dropdowns to cascade on Edit popup
        function cascadeEdit() {
            var lblanalog = $('.analog');
            if ($('#ddlSensorController').val().trim().toLowerCase() != "utilitylogger") {
                lblanalog.attr("style", "display:none");
                //$("#txtAnalogueImputNumber").removeAttr("required");
            } else {
                //$("#txtAnalogueImputNumber").attr("required", "required");
                lblanalog.attr("style", "display:block");
            }

            ////Cascading data for Machine/Compartment basing on Utility Location
            $('#ddlSensorLocation').change(function() {
                _this.isEdit = true;
                $('#ddlMachineName').html('<option value="">-- Select --</option>');
                $('#ddlChemicalForChart').html('<option value="">-- Select --</option>');
                if ($(this).val() != "") {
                    if (_this.options.eventHandlers.onUtilityLocationChange)
                        _this.options.eventHandlers.onUtilityLocationChange($(this).val());
                }
            });

            ////Cascading data for ChemicalForChart basing on Utility Location
            $('#ddlMachineName').change(function() {
                $('#ddlChemicalForChart').html('<option value="">-- Select --</option>');
                _this.isEdit = true;
                if ($('#ddlMachineName').val() != "") {
                    if (_this.options.eventHandlers.onMachineChange)
                        _this.options.eventHandlers.onMachineChange($(this).val());
                }
            });

            $("#ddlSensorTypeName").change(function() {
                _this.isEdit = true;
                if ($('#ddlSensorTypeName').val() != "") {
                    if (_this.options.eventHandlers.onUtilityTypeChange)
                        _this.options.eventHandlers.onUtilityTypeChange($(this).val());
                }
            });
        }

        //Dropdowns to cascade on Add popup
        function cascadeAdd() {
            var lblanalog = $('.analogAdd');
            // var _this = this;
            $('#ddlAddSensorController').change(function() {
                _this.isEdit = false;
                if ($('#ddlAddSensorController option:selected').text().trim().toLowerCase() == "mycontrol") {

                    lblanalog.attr("style", "display:none");
                    $("#txtAddAnalogueImputNumber").val("0");
                    //$("#txtAddAnalogueImputNumber").removeAttr("required");
                } else {
                    //$("#txtAddAnalogueImputNumber").attr("required", "required");
                    lblanalog.attr("style", "display:block");
                }

            });
            $('#ddlAddMachineName').change(function() {
                var controllerAdd = $('#ddlAddSensorController');
                controllerAdd.val($(this).find('option:selected').attr('data-controllerid'));
                controllerAdd.trigger('change');
            });
            //if ($('#ddlAddSensorController').val().trim().toLowerCase() != "utilitylogger") {
            //    lblanalog.attr("style", "display:none");
            //}
            //else
            //    lblanalog.attr("style", "display:block");

            ////Cascading data for Machine/Compartment basing on Utility Location
            $('#ddlAddSensorLocation').change(function() {
                _this.isEdit = false;
                $('#ddlAddMachineName').html('<option value="">-- Select --</option>');
                $('#ddlAddChemicalForChart').html('<option value="">-- Select --</option>');
                if ($('#ddlAddSensorLocation').val() != "") {
                    if (_this.options.eventHandlers.onUtilityLocationChange)
                        _this.options.eventHandlers.onUtilityLocationChange($(this).val());
                }
            });

            ////Cascading data for ChemicalForChart basing on Utility Location
            $('#ddlAddMachineName').change(function() {
                _this.isEdit = false;
                $('#ddlAddChemicalForChart').html('<option value="">-- Select --</option>');
                if ($('#ddlAddMachineName').val() != "") {
                    if (_this.options.eventHandlers.onMachineChange)
                        _this.options.eventHandlers.onMachineChange($(this).val());
                }
            });

            $("#ddlAddSensorTypeName").change(function() {
                _this.isEdit = false;
                if ($('#ddlAddSensorTypeName').val() != "") {
                    if (_this.options.eventHandlers.onUtilityTypeChange)
                        _this.options.eventHandlers.onUtilityTypeChange($(this).val());
                }
            });

        }

        var grid;

        //Method to show default values on edit popup
        function showDetails(e) {
            clearStatusMessage();
            e.preventDefault();
            dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            //var data = getSensors(dataItem.SensorNumber);
            dataItem.SensorDataToLoadDropdown = _this.SensorData;
            dataItem.maxRole = _this.data.MaxLevel;
            //RoleBased editing 
            if (_this.allowEdit) {
                wnd.content(detailsTemplate(dataItem));
            } else {
                wnd.content(detailsTemplateView(dataItem));
            }
            wnd.center().open();
        }

        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function() {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator");
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                if (_this.options.eventHandlers.checkDuplicates)
                    if (_this.options.eventHandlers.checkDuplicates()) {
                        var errorMessageDiv = $('#errorMessage');
                        errorMessageDiv.html('<span>' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</span>');
                        errorMessageDiv.show();
                        return false;
                    }
                var sensor;
                dataSource.fetch(function() {
                    sensor = dataSource.get(uid);
                    sensor.set("SensorName", $("#txtSensorName").val());
                    sensor.set("SensorTypeName", $("#ddlSensorTypeName option:selected").text().trim());
                    sensor.set("SensorLocation", $("#ddlSensorLocation option:selected").text().trim());
                    sensor.set("MachineName", $("#ddlMachineName option:selected").text().trim());
                    sensor.set("Calibration", $("#txtCalibration").val());
                    sensor.set("UOMName", $("#ddlUoM option:selected").text().trim());
                    //sensor.set("UOM", $("#ddlUoM").val());
                    sensor.set("UOM", $("#ddlUoM option:selected").text().trim());
                    sensor.set("ControllerName", $("#ddlSensorController option:selected").text().trim());
                    sensor.set("ControllerName", $("#ddlSensorController").val());
                    sensor.set("ControllerType", controllerType);
                    sensor.set("ControllerId", controllerId);
                    sensor.set("AnalogueImputNumber", $("#txtAnalogueImputNumber").val());
                    sensor.set("ChemicalforChart", $("#ddlChemicalForChart option:selected").text().trim());
                    sensor.set("DashboardActualValue", $("#ddlDashboard").is(':checked'));
                    sensor.set("SensorType", $("#ddlSensorTypeName").val());
                    sensor.set("SensorLocationId", $("#ddlSensorLocation").val());
                    sensor.set("MachineId", $("#ddlMachineName").val());
                    sensor.set("ChemicalforChartId", $("#ddlChemicalForChart").val());
                    sensor.OutputType = $("#ddlOutPutType").val();
                    //sensor.set("OutputType", $("#ddlOutPutType").val());
                    if ($('#txtAddCalibration4').hasClass('display-label')) {
                        sensor.set("CalibrationValue4", $("#txtAddCalibration4").text());
                        sensor.set("CalibrationValue20", $("#txtAddCalibration20").text());
                        sensor.set("CalibrationTag4", $("#txtAddTagAddress4").text());
                        sensor.set("CalibrationTag20", $("#txtAddTagAddress20").text());
                        if ($("#txtAddTagAddress4").text() == " – ") {
                            sensor.set("CalibrationTag4", '');
                        }
                        if ($("#txtAddTagAddress20").text() == " – ") {
                            sensor.set("CalibrationTag20", '');
                        }
                    } else {
                        sensor.set("CalibrationValue4", $("#txtAddCalibration4").val());
                        sensor.set("CalibrationValue20", $("#txtAddCalibration20").val());
                        sensor.set("CalibrationTag4", $("#txtAddTagAddress4").val());
                        sensor.set("CalibrationTag20", $("#txtAddTagAddress20").val());
                    }
                    sensor.set("OverridePlcValues", false);
                });
                grid = $("#gridSensor").data("kendoGrid");
                grid.saveChanges();
                grid.dataSource._destroyed = [];
                grid.dataSource.read();

            } else {
                return false;
            }
        });

        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function() {
            wnd.close();
            if (grid != undefined) {
                grid.dataSource._destroyed = [];
                grid.dataSource.read();
            }
        });
        window.userMaxRole = _this.data.MaxLevel;
        $("#gridSensor a.grid-add-new-record").unbind("click");
        $("#gridSensor a.grid-add-new-record").on("click", function(e) {
            clearStatusMessage();
            var dataSource = $("#gridSensor").data("kendoGrid").dataSource;
            kendoWindow = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                    title: $.GetLocaleKeyValue("FIELD_ADDSENSOR", 'Add Sensor'),
                    modal: true,
                    resizable: false,
                    visible: false,
                    width: "438px",
                    height: "auto",
                    top: "185px",
                    open: onAddNewOpen,
                    close: onClose,
                    content: {
                        //sets window template
                        template: kendo.template($("#newSensor").html())
                    },
                    activate: function(e) {
                        _this.tm.Localize();
                    }
                })
                .data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {

            });
            //binds the editing window to the form
            kendo.bind(kendoWindow.element, model);

            //initialize the validator
            var validator = $(kendoWindow.element).kendoValidator().data("kendoValidator");
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function(e) {
                if (validator.validate() == true) {
                    if (_this.options.eventHandlers.checkDuplicates)
                        if (_this.options.eventHandlers.checkDuplicates()) {
                            var errorMessageDiv = $('#errorMessageAdd');
                            errorMessageDiv.html('<span>' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</span>');
                            errorMessageDiv.show();
                            return false;
                        }
                    dataSource._data[0].SensorName = $("#txtAddSensorName").val();
                    dataSource._data[0].SensorTypeName = $("#ddlAddSensorTypeName option:selected").text().trim();
                    dataSource._data[0].SensorLocation = $("#ddlAddSensorLocation option:selected").text().trim();
                    dataSource._data[0].MachineName = $("#ddlAddMachineName option:selected").text().trim();
                    dataSource._data[0].Calibration = $("#txtAddCalibration").val();
                    dataSource._data[0].UOMName = $("#ddlAddUoM option:selected").text().trim();
                    dataSource._data[0].UOM = $("#ddlAddUoM").val();
                    dataSource._data[0].ControllerName = $("#ddlSensorController option:selected").text().trim();
                    dataSource._data[0].AnalogueImputNumber = $("#txtAddAnalogueImputNumber").val();
                    dataSource._data[0].ChemicalforChart = $("#ddlAddChemicalForChart option:selected").text().trim();
                    dataSource._data[0].DashboardActualValue = $("#ddlAddDashboard").is(':checked');
                    dataSource._data[0].SensorType = $("#ddlAddSensorTypeName").val();
                    dataSource._data[0].SensorLocationId = $("#ddlAddSensorLocation").val();
                    dataSource._data[0].MachineId = $("#ddlAddMachineName").val();
                    dataSource._data[0].ControllerId = parseInt($("#ddlAddSensorController").val());
                    dataSource._data[0].OverridePlcValues = false;
                    if ($("#ddlAddSensorController option:selected").val() != "")
                        dataSource._data[0].ControllerType = $("#ddlAddSensorController option:selected").attr('data-type').trim();
                    else
                        dataSource._data[0].ControllerType = '';
                    dataSource._data[0].ChemicalforChartId = $("#ddlAddChemicalForChart").val();
                    dataSource._data[0].OutputType = $("#ddlAddOutPutType").val();

                    dataSource.sync(); //sync changes
                    // window.close();
                    //window.element.remove();
                    grid = $("#gridSensor").data("kendoGrid");
                } else {
                    return false;
                }
            });

            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function(e) {
                dataSource.cancelChanges(model); //cancel changes
                kendoWindow.close();
                kendoWindow.element.remove();
            });

            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                kendoWindow.element.remove();
            }

        });

        function onAddNewOpen() {
            if (_this.options.eventHandlers.onAddNewSensorPopupLoad)
                _this.options.eventHandlers.onAddNewSensorPopupLoad();
            cascadeAdd();

            //$("#cbRewash").kendoMobileSwitch({ onLabel: "YES", offLabel: "NO" });
            //$('select').kendoDropDownList();
        }

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
    }
};