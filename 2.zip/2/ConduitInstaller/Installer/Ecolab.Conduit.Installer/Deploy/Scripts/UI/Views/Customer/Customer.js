Ecolab.Views.Customer = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Customer/CustomerList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.initValidator();
    this.allowEdit = false;
};

Ecolab.Views.Customer.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        _this.tm.Localize();
    },
    initValidator: function () {
        $.validator.addMethod(
                "regex",
                function (value, element, regexp) {
                    //debugger;
                    var check = false;
                    var re = new RegExp(regexp);
                    return this.optional(element) || re.test(value);
                },
                $.GetLocaleKeyValue("FIELD_PLEASECHECKYOURINPUT", "Please check your input.")
        );
    },

    validate: function () {
        //this.resetErrors();
        var pattern1 = /^[0-9]*$/;
        var v1 = $('#frmCustomer').validate({
            rules: {
                txtCustomerId: {
                    required: true,
                    regex: pattern1
                }
            },
            messages: {
                txtCustomerId: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERCUSTOMERID", "Please enter the Customer Id"),
                    regex: $.GetLocaleKeyValue("FIELD_PLEASEENTERONLYNUMBERS", "Please enter only numbers")
                },

            }

        });
        //var v2 = $('#frmCustomer').valid();
        //return v2;


        /******************************************************************************************
        Event handling
        ******************************************************************************************/
    },
    attachEvents: function () {

        $("#frmCustomer").kendoValidator();
        var _this = this;
        //debugger
        var wnd, detailsTemplate;
        var trIndex = null;
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel == 4 || this.data.MaxLevel > 5);
        var container = $(this.options.containerSelector);

        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Customer/GetCustomer",
                    dataType: "json"
                },
                create: {
                    url: "/api/Customer/CreateCustomer",
                    dataType: "json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            if (jqXhr.responseText == '301') {
                                $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERALREADYEXISTS" class="k-error-message">Customer Id Already Exists</label>');
                                 grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                            else {
                                $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERADDEDSUCCESSFULLY" class="k-success-message">Customer Added Successfully</label>');
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERADDITIONFAILED" class="k-error-message">Customer Addition Failed</label>');
                           
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    url: "/api/Customer/Put",
                    dataType: "json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERUPDATEDSUCCESSFULLY" class="k-success-message">Customer Updated Successfully</label>');
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERALREADYEXIST" class="k-error-message">Customer Id already exists. Please try again.</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/Customer/DeleteCustomer",
                    dataType: "json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERDELETEDSUCCESSFULLY" class="k-success-message">Customer Deleted Successfully</label>');
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERDELETIONFAILED" class="k-error-message">Customer Deletion Failed</label>');
                        }
                        _this.tm.Localize();
                    }
                   
                },
            },
            pageSize: 12,
            schema: {
                model: {
                    id: "Id",
                    fields: {
                        Id: { editable: false, type: "number" },
                        CustomerId: {
                            editable: true, type: "text", validation: {
                                required: true, min: "1",
                                onlyDigits: function (input) {
                                    //debugger;
                                    if (input.is("[name='CustomerId']")) {
                                        input.attr("data-onlyDigits-msg", $.GetLocaleKeyValue("FIELD_CUSTOMERIDISNOTVALID", "CustomerId is not valid"));
                                        var pattern = new RegExp("^[0-9]+$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        }
                                        else {
                                            return false;
                                        }
                                    }
                                    return true;

                                }
                            },
                        }, 
                        CustomerName: { validation: { required: true } }
                    }
                }
            }
        });

        //Set basing on roles Here
        var addNew, commands, editTitle, customWidth = "135px";
            if (_this.allowEdit) {
                _this.isView = false;
                commands = [
                    {
                        name: "edit",
                        text: { edit: "", cancel: "", update: "" },
                        click: onEdit
                    }, { name: "destroy", text: " " }, { name: "update", text: " ", click: showDetails }
                ];
                addNew = [{ text: "<span data-localize='FIELD_ADDCUSTOMER'>Add Customer</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
                editTitle = $.GetLocaleKeyValue("FIELD_EDITCUSTOMER", 'Edit Customer');
            } else {
                _this.isView = true;
                commands = [{ name: "view", text: " "}];
                addNew = "";
                customWidth = "55px";
                editTitle = "View Customer";
            }

        function onDataBound(arg) {
            $('.grid-add-new-record').removeClass('k-button k-button-icontext');
            $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            _this.tm.Localize();
        }

        if (container.find('#gridCustomer').data().kendoGrid)
            container.find('#gridCustomer').data().kendoGrid.destroy();

    var gridCustomer= container.find("#gridCustomer").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                  { command: commands, width: "87px", attributes: { "class": "align-center" } },
                  { field: "CustomerId", title: "<span data-localize='FIELD_NUMBER'>Number</span>", format: "{0:0}", attributes: { "class": "align-center" }, headerAttributes: { "class": "align-center" }, width: "12%" },
                  { field: "CustomerName", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "20%" },
                  { field: "", title: "", headerAttributes: { "class": "left-no_border" }, attributes: { "class": "left-no_border" }, width: "60%" }
            ],
            editable: "inline",
        });
        function onEdit() { clearStatusMessage(); }
        wnd = $("#details")
                        .kendoWindow({
                            title: $.GetLocaleKeyValue("FIELD_EDITCUSTOMER", 'Edit Customer'),
                            modal: true,
                            visible: false,
                            resizable: false,
                            width: "373px",
                            height: "auto",
                            activate:function(e){
                                _this.tm.Localize();
                           }
                        }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editCustomer").html());


        function showDetails(e) {
            clearStatusMessage();
            e.preventDefault();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator")
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSource.fetch(function () {
                    var customer = dataSource.get(uid);
                    customer.set("CustomerId", $("#txtCustomerId").val());
                    customer.set("CustomerName", $("#txtCustomerName").val());
                    dataSource.sync();
                });
                var grid = $("#gridCustomer").data("kendoGrid");
                grid.saveChanges()
                wnd.close();
                //$("#errorDiv").html('Updated Successfully');
            }
            else {
                //$("#errorDiv").html('Updation failed');
                return false;
            }
        });
        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
        });

        var grid;
        $("#gridCustomer a.grid-add-new-record").unbind("click");
        $("#gridCustomer a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            var dataSource = $("#gridCustomer").data("kendoGrid").dataSource;
            var window = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({ 
                    title: $.GetLocaleKeyValue("FIELD_ADDCUSTOMER", 'Add Customer'),
                    modal: true,
					resizable: false,
                    width: "373px",
                    height: "auto",
                    close: onClose,                    
                    content: {
                        //sets window template
                        template: kendo.template($("#newCustomer").html())
                    },
                    activate: function (e) {
                        _this.tm.Localize();
                    }
                })
                .data("kendoWindow")
                .center();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});


            //binds the editing window to the form
            kendo.bind(window.element, model);

            //determines at what position to insert the record (needed for pageable grids)

            //initialize the validator
            var validator = $(window.element).kendoValidator().data("kendoValidator")
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function (e) {
                if (validator.validate() == true) {
                    dataSource.sync(); //sync changes
                    window.close();
                    window.element.remove();
                    grid = $("#gridCustomer").data("kendoGrid");
                }
                else {
                    return false;
                }

            });
            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function (e) {
                dataSource.cancelChanges(model); //cancel changes
                window.close();
                window.element.remove();
            });
            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                window.element.remove();
            }

        });
        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
    }
}


