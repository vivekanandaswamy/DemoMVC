// JavaScript source code
Ecolab.Views.Pumps = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onDropDownChange: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.selectedValue = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Pumps/Pumps.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: {
            onRendered: function () {
                _this.onRendered();
            }
        }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.Pumps.prototype = {
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        
        if (this.selectedValue != null) {
            data.selectedValue = this.selectedValue;
        }
        else {
            data.selectedValue = "All";
        }
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();

        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });

        $('#tblPumpsList').tablesorter({
            headers: {
                0: {
                    sorter: false
                }
                
            }
        });

    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find("#ddlSort").change(function () {
            _this.clearStatusMessage();
            _this.selectedValue = $(this).val();
            _this.onDropDownChange($(this).val());
        });
        container.find(".lnkUpdatePump").click(function () {
            _this.clearStatusMessage();
            _this.onEditClicked(_this.getPumpData(this));
        });

        container.find(".editPumpInline").click(function () {
            _this.clearStatusMessage();
            container.find(".noneditable").show();
            container.find(".editable").hide();
            var pumpData = _this.getPumpData(this);
            _this.onEditPumpClicked(this, pumpData);
        });

        container.find(".updatePumpInline").click(function () {
            _this.clearStatusMessage();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            if (_this.validate(tr)) {
                _this.selectedValue = "All";
                _this.onPumpsInlineEditClicked(_this.getInlinePumpData(this, tr));
            }
        });

        container.find(".ddlProducts").change(function() {
            var id = this.id.split('_')[1];
            var maxDosage = container.find('#maximumDosingTime_' + id).val();
            if (maxDosage == null || !(parseInt(maxDosage) > 99 && parseInt(maxDosage) < 250)) {
                container.find('#maximumDosingTime_' + id).val(200);
            }
        });
        container.find(".cancelPumpInline").click(function () {
            _this.clearStatusMessage();
            container.find(".noneditable").show();
            container.find(".editable").hide();
            container.find(".k-error-message").text('');
            $(this).parents('.trEditable').first().removeClass('dirty');
            var tr = $(this).parents('.trEditable').first();
            _this.restoreData(tr);
        });
    },
    showEditOnInlineEditLink: function (e, prouducts, data) {
        var tr = $(e).parents('.trEditable').first();
        var ddlProduct = $(tr).find('.ddlProducts');
        ddlProduct.empty();
        ddlProduct.append('<option value="">-- Select --</option>');
        $.each(prouducts, function () {
            ddlProduct.append('<option value="' + this.Id + '">' + this.Name + '</option>');
        });

        //$(tr).find('.txtName').val(data.Name),
        //$(tr).find('.txtNominalload').val(data.Nominalload),
        if (data != null)
            ddlProduct.val(data.ProductId);

        tr.find(".noneditable").hide();
        tr.find(".editable").show();
    },
    getPumpData: function (element) {
        return {
            ControllerEquipmentId: $(element).attr('control-eqpid'),
            ProductName: $(element).attr('pump-productname'),
            PumpCalibration: $(element).attr('pump-pumpcalibration'),
            FlowMeterSwitchFlag: $(element).attr('pump-flowmeterswitchflag'),
            FlowMeterCalibration: $(element).attr('pump-flowmetercalibration'),
            MaximumDosingTime: $(element).attr('pump-maximumdosingtime'),
            ProductId: $(element).attr('product-id'),
            FlowSwitchTimeOut: $(element).attr('pump-flowswitchtimeout'),
            ControllerEquipmentTypeId: $(element).attr('control-eqptypeid'),
            EcolabAccountNumber: $(element).attr('ecolabaccountno'),
            ControllerId: $(element).attr('controlid'),
            ControllerTypeId: $(element).attr('pump-controllertypeid'),
            ControllerTopicName: $(element).attr('pump-controllertopicname'),
            LfsChemicalName: $(element).attr('pump-lfschemicalname'),
            KFactor: $(element).attr('pump-kfactor'),
            TunnelHold: $(element).attr('pump-tunnelhold'),
            FlowDetectorType: $(element).attr('pump-flowdetectortype'),
            FlowSwitchAlarm: $(element).attr('pump-flowswitchalarm'),
            FlowMeterAlarm: $(element).attr('pump-flowmeteralarm'),
            FlowMeterType: $(element).attr('pump-flowmetertype'),
            FlowAlarmDelay: $(element).attr('pump-flowalarmdelay'),
            FlowMeterPumpDelay: $(element).attr('pump-flowmeterpumpdelay'),
            FlowMeterAlarmDelay: $(element).attr('pump-flowmeteralarmdelay'),
            LfsChemicalNameTag: $(element).attr('pump-lfschemicalnametag'),
            KfactorTag: $(element).attr('pump-kfactortag'),
            CalibrationTag: $(element).attr('pump-calibrationtag')
        };
    },
    getInlinePumpData: function (element, tr) {
        return {
            ControllerEquipmentId: $(element).attr('control-eqpid'),
            ControllerEquipmentTypeId: $(element).attr('control-eqptypeid'),
            PumpCalibration: $(tr).find('.pumpCalibration').val(),
            //FlowMeterSwitchFlag: $(tr).find('.ddlMeterSwitchFlag').val(),
            //FlowMeterCalibration: $(tr).find('.flowMeterCalibration').val(),
            //MaximumDosingTime: $(tr).find('.maximumDosingTime').val(),
            EcolabAccountNumber: $(element).attr('ecolabaccountno'),
            ControllerId: $(element).attr('controlid'),
            ProductId: $(tr).find('.ddlProducts').val() == 0 ? null:$(tr).find('.ddlProducts').val(),
            //FlowSwitchTimeOut: $(tr).find('.flowSwitchTimeOut').val(),
            
            ControllerTypeId: $(element).attr('pump-controllertypeid'),
            ControllerTopicName: $(element).attr('pump-controllertopicname'),
            LfsChemicalName: $(element).attr('pump-lfschemicalname'),
            KFactor:$(tr).find('.kFactor').val(),
            TunnelHold: $(element).attr('pump-tunnelhold'),
            FlowDetectorType: $(element).attr('pump-flowdetectortype'),
            FlowSwitchAlarm: $(element).attr('pump-flowswitchalarm'),
            FlowMeterAlarm: $(element).attr('pump-flowmeteralarm'),
            FlowMeterType: $(element).attr('pump-flowmetertype'),
            FlowAlarmDelay: $(element).attr('pump-flowalarmdelay'),
            LfsChemicalNameTag: $(element).attr('pump-lfschemicalnametag'),
            KfactorTag: $(element).attr('pump-kfactortag'),
            CalibrationTag: $(element).attr('pump-calibrationtag')
        };
    },
    onDropDownChange: function (option) {
        this.options.eventHandlers.onDropDownChange(option);
    },
    onPumpsInlineEditClicked: function (data) {
        if (this.options.eventHandlers.onPumpsInlineEditClicked)
            this.options.eventHandlers.onPumpsInlineEditClicked(data, true);
    },
    onEditPumpClicked: function (e, data) {
        if (this.options.eventHandlers.onEditPumpClicked)
            this.options.eventHandlers.onEditPumpClicked(e, data);
    },
    clearStatusMessage: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        var messageDiv = container.find("#massage");
        messageDiv.text('');
    },

    onEditClicked: function (data) {
        if (this.options.eventHandlers.onEditClicked)
            this.options.eventHandlers.onEditClicked(data);
    },
    restoreData: function (tr) {

        $(tr).find(".pumpCalibration").val($(tr).find("#divpumpCalibration").text().trim());
        $(tr).find(".maximumDosingTime").val($(tr).find("#divmaximumDosingTime").text().trim());
    },

    validate: function () {
        var container = $(this.options.containerSelector);
        var decimalPattern = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;

        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "*"
       );
        container.find('#frmPump').validate({
            rules: {
                txtpumpCalibration: {
                    min: 0,
                    max: 10000,
                    required: true,
                    regex: decimalPattern
                },
                txtmaximumDosingTime: {
                    min: 100,
                    max: 250,
                    required: true,
                    regex: decimalPattern
                },
                txtKfactor: {
                    min: 0,
                    max: 10000,
                    required: true,
                    regex: decimalPattern
                },
            },
            messages: {
                txtpumpCalibration: {
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO10000', 'Please enter in between 0 to 10000'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO10000', 'Please enter in between 0 to 10000'),
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERPUMPCALIBRATION', 'Please enter Pump Calibration')
                },
                txtKfactor: {
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO10000', 'Please enter in between 0 to 10000'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERINBETWEEN0TO10000', 'Please enter in between 0 to 10000'),
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERKFACTOR', 'Please enter K-Factor')
                },
                txtmaximumDosingTime: {
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN100TO250','Please enter in between 100 to 250'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN100TO250','Please enter in between 100 to 250'),
                        required: $.GetLocaleKeyValue('FIELD_PLEASEENTERMAXDOSINGTIME','Please enter Max Dosing Time')
                },
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });
        var v2 = container.find('#frmPump').valid();
        return v2;
    },
}