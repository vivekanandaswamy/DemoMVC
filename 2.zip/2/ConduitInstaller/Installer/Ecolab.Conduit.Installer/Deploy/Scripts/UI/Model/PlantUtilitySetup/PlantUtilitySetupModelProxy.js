Ecolab.Model.PlantUtilitySetupModelProxy = function () {
};

Ecolab.Model.PlantUtilitySetupModelProxy.prototype =
{
    loadPlantUtilitySetupData: function (callBack) {
        var url = "Api/PlantUtilitySetup/Get";
        this.ApiRead("PlantUtilitySetup", url, function (response) { callBack(response); }, null, null, null);
    },
    savePlantutilityData: function (data, callBack, errorCallBack) {
        var url = "Api/PlantUtilitySetup/Save";
        this.ApiCreate("PlantUtilitySetup", url, function (response) { callBack(response); }, function (callBack, exception) { errorCallBack(callBack, exception); }, null, data);
        
    },
    getEnergyContent: function (gasTypeId,callBack) {
        var url = "Api/PlantUtilitySetup/GasTypeDetails/{id}";
        var requestData = { "id": gasTypeId };
        this.ApiRead("PlantUtilitySetup", url, function (response) { callBack(response); }, function (callBack, exception) { errorCallBack(callBack, exception); }, null, requestData);
    }

};

var base = new Ecolab.Model.Common();
Ecolab.Model.PlantUtilitySetupModelProxy.prototype = $.extend({}, Ecolab.Model.PlantUtilitySetupModelProxy.prototype, base);
Ecolab.Model.PlantUtilitySetupModelProxy.prototype.base = base;