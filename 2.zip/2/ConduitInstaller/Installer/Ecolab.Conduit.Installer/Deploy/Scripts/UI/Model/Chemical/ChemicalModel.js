Ecolab.Model.ChemicalModel = function (options) {
    var defaultOptions = {
        eventHandlers: {

        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ChemicalModelProxy = new Ecolab.Model.ChemicalModelProxy();
};

Ecolab.Model.ChemicalModel.prototype = {
    init: function () {
    },
    loadChemicalData: function (pageIndex, callBackData) {
        var _this = this;
        _this.onDataLoaded("data", true);
    },
    onDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onChemicalDataLoaded(data, callBackData);
    },
    loadChemicals: function (request, callBack) {
        this.ChemicalModelProxy.loadChemicals(request, callBack);
    },
};

