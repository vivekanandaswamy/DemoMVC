﻿Ecolab.Views.ManualBatch = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
            onWasherGroupChange: null,
            onFormulaChange: null,
            fetchWasherGroup: null,
            onWasherOrFormulaChange: null,
            onBatchChange: null
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ManualInput/ManualBatch/ManualBatch.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.ManualBatch.prototype = {
    setData: function (data) {
        this.data = data;
        if (this.data.StartDate != null) {
            data.StartDate = (new Date(this.data.StartDate)).format("MM/dd/yyyy");
        } else {
            data.StartDate = (new Date()).format("MM/dd/yyyy");
        }
        this.tm.Render(data, this);
    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "401":
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('.divErrorMsg');
        messageDiv.html(errLabel);
    },
    onRendered: function () {
        var _this = this;
        $('.tabManualBatch').addClass('active');
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        this.fetchWasherGroup(this.data.StartDate);
        //$("#txtDate").datepicker();
        //$("#txtDate").datepicker("setDate", new Date());
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find('.datetimepicker').datetimepicker({
            pickTime: false,
        });

        container.find('.datetimepicker').change(function () {
            _this.resetDropdowns();
            _this.resetWasherGroup();
            if (container.find('.recordingDate').val().trim() != "")
                _this.fetchWasherGroup(container.find('.recordingDate').val());
        });

        container.find("#btnCancel").click(function () {
            //_this.clearMessage();
            // _this.cancelClicked();
            window.location = '/ManualBatch';
        })

        container.find(".btnSave").click(function () {
            _this.onSaveClicked();
        });


        container.find(".ddlWasherGroup").change(function () {
            _this.resetDropdowns();
            if (container.find(".ddlWasherGroup").val().trim() != "") {
                _this.onWasherGroupChange(container.find(".ddlWasherGroup").val());
            }
        });

        //Event to bind data on washer change
        container.find(".ddlWasher").change(function () {
            if (container.find(".ddlWasher").val() == "") {
                _this.resetBatch();
            }
            //load recording data
            if (container.find(".ddlFormula").val() != "" && container.find(".ddlWasher").val() != "")
                _this.onWasherOrFormulaChange();
        });

        //Event to bind data on formula change
        container.find(".ddlFormula").change(function () {
            if (container.find(".ddlFormula").val() == "") {
                _this.resetBatch();
            }
            //load recording data
            if (container.find(".ddlWasher").val() != "" && container.find(".ddlFormula").val() != "")
                _this.onWasherOrFormulaChange();
        });

        container.find(".ddlBatch").change(function () {
            if (container.find(".ddlBatch").val().trim() != "" && container.find(".ddlWasher").val() != "" && container.find(".ddlFormula").val() != "") {
                _this.onBatchChange();
            }
            if (container.find(".ddlBatch").val().trim() == "") {
                _this.resetContainer();
            }

        });
    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "Enter only numbers"
       );
        var v1 = container.find('#frmManualBatch').validate({
            rules: {
                recordingValue: {
                    regex: pattern1
                },
                ddlWasherGroup: {
                    required: true
                },
                ddlWasher: {
                    required: true
                },
                ddlFormula: {
                    required: true
                },
                ddlBatch: {
                    required: true
                },
                txtDate: {
                    required: true
                }
            },
            messages: {
                ddlWasherGroup: {
                    required: "Please select WasherGroup",
                },
                ddlWasher: {
                    required: "Please select Washer",
                },
                ddlFormula: {
                    required: "Please select Formula",
                },
                ddlBatch: {
                    required: "Please select Batch",
                },
                txtDate: {
                    regex: "Enter only numbers"
                }

            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parents('div').first().find("span.errorMsg"));
                if (element.hasClass('recordingValue')) {
                    error.appendTo(element.parent().next('span.errorMsg'));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select") || element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().next("span.errorMsg"));
                }
            }
        });

        var v2 = container.find('#frmManualBatch').valid();
        return v2;
    },

    fetchWasherGroup: function (date) {
        this.clearMessage();
        if (this.options.eventHandlers.fetchWasherGroup)
            this.options.eventHandlers.fetchWasherGroup(date);
    },

    LoadWasherGroups: function (data) {
        this.clearMessage();
        var container = $(this.options.containerSelector);
        var ddlWasherGroup = $(container).find('.ddlWasherGroup');
        this.resetWasherGroup();
        $.each(data, function () {
            ddlWasherGroup.append('<option value="' + this.GroupTypeId + '">' + this.GroupDescription + '</option>');
        });
    },

    resetWasherGroup: function () {
        var container = $(this.options.containerSelector);
        var ddlWasherGroup = $(container).find('.ddlWasherGroup');
        ddlWasherGroup.empty();
        ddlWasherGroup.append('<option value="">-- Select --</option>');
        ddlWasherGroup.next('.holder').html('-- select --');
    },

    LoadBatch: function (data) {
        this.clearMessage();
        var container = $(this.options.containerSelector);
        var ddlBatch = $(container).find('.ddlBatch');
        ddlBatch.empty();
        ddlBatch.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlBatch.append('<option value="' + this.Id + '">' + 'Batch ' + this.Id + '(' + new Date('01/01/2001 ' + this.StartTime.split('.')[0] + ' /').toLocaleTimeString() + ') ' + '</option>');
        });
    },

    onSaveClicked: function () {
        var _this = this;
        this.clearMessage();
        if (this.options.eventHandlers.onSaveClicked) {
            if (_this.validate() == true) {
                this.options.eventHandlers.onSaveClicked(this.getIdsToLoadBatchData());
            }
            else {
                return false;
            }
        }
    },

    onWasherGroupChange: function (groupId) {
        if (this.options.eventHandlers.onWasherGroupChange) {
            this.options.eventHandlers.onWasherGroupChange(groupId);
        }
    },

    resetDropdowns: function () {
        var container = $(this.options.containerSelector);
        $(container).find('.ddlWasher').empty();
        $(container).find('.ddlFormula').empty();
        container.find('#ManualBatchDataContainer').empty();
        container.find(".ddlWasher").append('<option value="">-- Select --</option>');
        container.find(".ddlWasher").next('.holder').html('-- select --');
        container.find(".ddlFormula").append('<option value="">-- Select --</option>');
        container.find(".ddlFormula").next('.holder').html('-- select --');
        this.resetBatch();
    },

    resetBatch: function () {
        var container = $(this.options.containerSelector);
        this.clearMessage();
        $(container).find('.ddlBatch').empty();
        container.find(".ddlBatch").append('<option value="">-- Select --</option>');
        container.find(".ddlBatch").next('.holder').html('-- select --');
        container.find('#manualBatchDataContainer').empty();
    },

    resetContainer:function(){
        var container = $(this.options.containerSelector);
        container.find('#manualBatchDataContainer').empty();
    },

    onWasherOrFormulaChange: function () {
        this.clearMessage();
        this.resetBatch();
        var container = $(this.options.containerSelector);
        container.find('#ManualBatchDataContainer').empty();
        if (this.options.eventHandlers.onWasherOrFormulaChange) {
            this.options.eventHandlers.onWasherOrFormulaChange(this.getIdsToLoadBatchData());
        }
    },

    bindFormulaAndWasherData: function (data) {
        var container = $(this.options.containerSelector);
        var ddlFormula = $(container).find('.ddlFormula');
        ddlFormula.empty();
        ddlFormula.append('<option value="">-- Select --</option>');
        $.each(data.Formulas, function () {
            ddlFormula.append('<option value="' + this.ProgramNumber + '">' + this.Description + '</option>');
        });
        var ddlWasher = $(container).find('.ddlWasher');
        ddlWasher.empty();
        ddlWasher.append('<option value="">-- Select --</option>');
        $.each(data.Washers, function () {
            ddlWasher.append('<option value="' + this.MachineID + '">' + this.MachineName + '</option>');
        });
    },

    onBatchChange: function () {
        this.clearMessage();
        var container = $(this.options.containerSelector);
        container.find('#ManualBatchDataContainer').empty();
        if (this.options.eventHandlers.onBatchChange) {
            this.options.eventHandlers.onBatchChange(this.getIdsToLoadBatchData());
        }
    },

    getIdsToLoadBatchData: function () {
        var container = $(this.options.containerSelector);
        var objManualBatch = {};
        objManualBatch.WasherGroupId = container.find(".ddlWasherGroup").val();
        objManualBatch.WasherId = container.find(".ddlWasher").val();
        objManualBatch.FormulaId = container.find(".ddlFormula").val();
        objManualBatch.Id = container.find(".ddlBatch").val();
        objManualBatch.RecordingValue = container.find(".recordingValue").val();
        objManualBatch.StartDate = container.find(".recordingDate").val();
        return objManualBatch;
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('.divErrorMsg').html('');
    },

    cancelClicked:function()
    {
        var retVal = this.options.eventHandlers.onRedirection('/ManualBatch');
        return retVal;
    },
}