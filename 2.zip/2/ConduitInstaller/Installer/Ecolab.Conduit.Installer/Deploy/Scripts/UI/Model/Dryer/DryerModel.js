// JavaScript source code
Ecolab.Model.DryerModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDryerGroupDataLoaded: null,
            onDryerTypesLoaded: null,
            onDryerGroupCreated: null,
            onDryerGroupCreationFailed: null,
            onDryerGroupUpdated: null,
            onDryerGroupUpdationFailed: null,
            onDryerGroupDeleted: null,
            onDryerGroupDeletionFailed: null,
            onDryerCreated: null,
            onDryerCreationFailed: null,
            onDryerUpdated: null,
            onDryerUpdationFailed: null,
            onDryerDeleted: null,
            onDryerDeletionFailed: null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.DryerModelProxy = new Ecolab.Model.DryerModelProxy();
};

Ecolab.Model.DryerModel.prototype = {
    init: function () {
    },
    addNewDryerGroup: function () {
        return {
            DryerGroupId: -1,
            DryerGroupName: ''
        };
    },
    addNewDryer: function (groupId, units, dryerTypes) {
        return {
            GroupId: groupId,
            Id:-1,
            Number: '',
            Name: '',
            Nominalload: '',
            DryerTypeId: -1,
            DryerTypeName: '',
            DryerTypes: dryerTypes,
            DesiredUnits: units
        };
    },
    loadDryerGroupData: function () {
        var _this = this;
        _this.DryerModelProxy.loadDryerGroupData(function (DryerGroupData) {
            _this.settings.eventHandlers.onDryerGroupDataLoaded(DryerGroupData);
        });
    },
    loadDryerTypes: function () {
        var _this = this;
        _this.DryerModelProxy.loadDryerTypes(function (DryerTypes) {
            _this.settings.eventHandlers.onDryerTypesLoaded(DryerTypes);
        });
    },
    createDryerGroup: function (dryerGroupData) {
        var _this = this;
        this.DryerModelProxy.createDryerGroup(dryerGroupData, function (data) {
            _this.settings.eventHandlers.onDryerGroupCreated(data);
        }, function (error, description) { _this.settings.eventHandlers.onDryerGroupCreationFailed(error, description); });
    },
    updateDryerGroup: function (dryerGroupData) {
        var _this = this;
        this.DryerModelProxy.updateDryerGroup(dryerGroupData, function (data) {
            _this.settings.eventHandlers.onDryerGroupUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onDryerGroupUpdationFailed(error, description); });
    },
    deleteDryerGroup: function (dryerGroupData) {
        var _this = this;
        this.DryerModelProxy.deleteDryerGroup(dryerGroupData, function (data) {
            _this.settings.eventHandlers.onDryerGroupDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onDryerGroupDeletionFailed(error, description); });
    },
    createDryer: function (dryerData) {
        var _this = this;
        this.DryerModelProxy.createDryer(dryerData, function (data) {
            _this.settings.eventHandlers.onDryerCreated(data);
        }, function (error, description) { _this.settings.eventHandlers.onDryerCreationFailed(error, description); });
    },
    updateDryer: function (dryerData, isInline) {
        var _this = this;
        this.DryerModelProxy.updateDryer(dryerData, function (data) {
            _this.settings.eventHandlers.onDryerUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onDryerUpdationFailed(error, description, isInline); });
    },
    deleteDryer: function (dryerData) {
        var _this = this;
        this.DryerModelProxy.deleteDryer(dryerData, function (data) {
            _this.settings.eventHandlers.onDryerDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onDryerDeletionFailed(error, description); });
    },
}