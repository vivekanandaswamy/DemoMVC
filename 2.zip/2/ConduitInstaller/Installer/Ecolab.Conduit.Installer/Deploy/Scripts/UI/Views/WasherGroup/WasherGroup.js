Ecolab.Views.WasherGroup = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { },
            onEditClicked: function () { },
            onDeleteWasherGroupClicked: function () { },
            onAddEditWasherGroupClicked: function () { },
            showEditOnInlineEditLink: function () { },
            rendered: function () { },
            onInlineWasherGroupUpdate: function () { }
          
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'WasherGroup',
        templateUri: '/Scripts/UI/Views/WasherGroup/WasherGroup.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
var numberofpages = 0;
Ecolab.Views.WasherGroup.prototype = {

    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $('#tblWasherGroups').tablesorter({
            headers: {
                0: {
                    sorter: false
                },
                4: {
                    sorter: false
                }
            }
        });
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find('#btnWasherGroupPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                PageTitle: "Washer Group"
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });

        // click event for inline editing for washer groups.
        container.find('.editWasherGroup').click(function () {
            container.find(".noneditable").show();
            container.find(".editable").hide();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            $(tr).find("#txtGroupName").val($(tr).find("#lblGroupName").text().trim());
            tr.find(".noneditable").hide();
            tr.find(".editable").show();
          
        });

        // Click event to delete the washer group from the grid.
        container.find('.deleteWasherGroup').click(function () {
            $("#divMessage").empty();
            _this.onDeleteWasherGroupClicked($(this).attr('Washer-groupid'));
        });

        // Click event for Add the washer group in new form.
        container.find('.btnAddWasherGroup').click(function () { _this.onAddEditWasherGroupClicked(0); });

        // Click event for Update the washer group in the new form.
        container.find(".updateWasherGroup").click(function () {
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            var data = _this.getInlineWasherGroupData(this, tr);
            if (data != null) {
                _this.onAddEditWasherGroupClicked(data.WasherGroupId);
            }
        });

        container.find(".updateWasherGroupInline").click(function () {
            _this.onSaveTrClicked();
        });

        // Click event for cancel the inline edit and shows the grid.
        container.find(".cancelWasherGroupInline").click(function () {
            container.find(".noneditable").show();
            container.find(".k-error-message").text('');
            container.find(".editable").hide();
            var tr = $(this).parents('.trEditable').first().removeClass('dirty');
            $(tr).find("#txtGroupName").val($(tr).find("#lblGroupName").text().trim());
        });
       
        container.find(".viewWasherGroupDetails").click(function () {
            _this.onAddEditWasherGroupClicked($(this).attr('Washer-groupid'));
        });
    },
    onSaveTrClicked: function () {
        var _this = this;
        var tr = $('.table-striped').find('.dirty');
        var washerGroupData = _this.getInlineWasherGroupData($(tr).find('.updateWasherGroupInline'), tr);
        if (washerGroupData != null && _this.validate()) {
            _this.onInlineWasherGroupUpdate(washerGroupData);
        }
    },
    //gets the data entered in the inline textboxes in grid.
    getInlineWasherGroupData: function (ele, tr) {
        var container = $(this.options.containerSelector);
        return {
            WasherGroupId: $(ele).attr('washer-groupid'),
            WasherGroupNumber: $(ele).attr('washer-number'),
            WasherGroupName: $(tr).find("#txtGroupName").val(),
            WasherGroupTypeId: $(ele).attr('washer-grouptypeid'),
            EcolabAccountNumber: this.options.accountInfo.EcolabAccountNumber
        };
    },

    //Validates the controls in the washer group grid.
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmWasherGroup').validate({
            rules: { txtGroupName: { required: true }, },
            messages: { txtGroupName: { required: $.GetLocaleKeyValue('FIELD_GROUPNAMECANNOTBEEMPTY', 'GroupName cannot be Empty.') } },
           errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.k-error-message"));
                    if (element.hasClass("custom-select")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                }
        });

        var v2 = container.find('#frmWasherGroup').valid();
        return v2;
    },

    // Event is for redirecting to Add/Edit washer group.
    onAddEditWasherGroupClicked: function (groupId) {
        if (this.options.eventHandlers.onAddEditWasherGroupLoad)
            this.options.eventHandlers.onAddEditWasherGroupLoad(groupId);
    },

    // Event is for redirecting to Add/Edit washer group.
    onInlineWasherGroupUpdate: function (washerGroupData) {
        if (this.options.eventHandlers.onInlineWasherGroupUpdate)
            this.options.eventHandlers.onInlineWasherGroupUpdate(washerGroupData);
    },

    //Event is for deleting the washer group from the grid.
    onDeleteWasherGroupClicked: function (washergroupId) {
        if (this.options.eventHandlers.onDeleteWasherGroupClicked)
            this.options.eventHandlers.onDeleteWasherGroupClicked(washergroupId);
    },
    showMessage: function (message) {
        var _this = this;
        var messageDiv = $("#divMessage");
        messageDiv.html(message);

    }
   
   
    
}