﻿Ecolab.Views.AddEditUserManagement = function(options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onAddUserManagementClicked: null,
            onContactChange: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AddEditUserManagement',
        templateUri: '/Scripts/UI/Views/UserManagement/AddEditUserManagement.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function() { _this.onRendered(); } }
    });
};
Ecolab.Views.AddEditUserManagement.prototype = {
    setData: function(data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function() {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('#myModal').modal('show');

        $(".custom-select").each(function() {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function() {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function() {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function() {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find('#btnSaveUser').click(function() {
            _this.clearStatusMessage();
            _this.onAddUserManagementClicked();
        });

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function() {
            $('.modal:visible').each(centerModal);
        });
        $("#divChoseContact").hide();
        container.find('input:radio[name="addType"]').change(
            function () {
                $(this).closest("li").addClass("active").siblings().removeClass("active");
                var div = container.find('#divChoseContact');
                var input = $(div).find('input');
                input.attr('required');
                if ($(this).val() == 'choose') {
                    div.show();
                } else {
                    div.hide();
                    input.val('');
                    input.removeAttr('data-contactid');
                }
            });

        container.find('#txtFirstName,#txtLastName').change(function() {
            var txtFirstName = container.find('#txtFirstName');
            if (txtFirstName.attr('data-userid') == '-1') {
                container.find('#txtUserId').val(txtFirstName.val().substring(0, 5) + container.find('#txtLastName').val().substring(0, 2));
            }
        });

        $('#txtContact').autocomplete({
            autoFocus: true,
            minLength: 1,
            delay: 500,
            appendTo: "#details-container",
            open: function() { $('.ui-autocomplete').width($("#txtContact").width()); },
            source:
                function(request, response) {
                    if (_this.options.eventHandlers.onContactChange)
                        _this.options.eventHandlers.onContactChange(request, contactsLoaded);

                    function contactsLoaded(data) {
                        response($.map(data, function(item) {
                            return { label: item.ContactFirstName + ', ' + item.ContactLastName, contactId: item.Id, firstName: item.ContactFirstName, lastName: item.ContactLastName, mobile: item.ContactMobilePhone, email: item.ContactEmailAdresss };
                        }));
                    }
                },
            select: function(event, ui) {
                container.find("#txtContact").attr("data-contactid", ui.item.contactId);
                container.find("#txtFirstName").val(ui.item.firstName);
                container.find("#txtLastName").val(ui.item.lastName);
                container.find("#txtEmail").val(ui.item.email);
                container.find("#txtContactNo").val(ui.item.mobile);
            },
            focus: function(e, ui) {
                return false;
            },
            close: function() {
                container.find("#txtContact").select();
            }

        }).autocomplete("widget").addClass("autoComplete");

    },
    getUserManagementData: function() {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            ContactId: container.find("#txtContact").attr("data-contactid"),
            UserNumber: container.find("#txtFirstName").attr("data-userid"),
            FirstName: container.find("#txtFirstName").val(),
            LastName: container.find("#txtLastName").val(),
            LoginName: container.find("#txtUserId").val(),
            Password: container.find("#txtPassword").val(),
            Email: container.find("#txtEmail").val(),
            ContactNo: container.find("#txtContactNo").val(),
            LevelId: container.find("#ddlUserRole").val()
        };
    },
    validateUserManagement: function() {
        _this = this;
        var container = $(this.options.containerSelector);
        $.validator.addMethod(
           "checkAttr",
           function (value, element, attribute) {
               var check = $(element).attr(attribute);
               return this.optional(element) || check;
           },
           "Please check your input."
       );

        var v1 = container.find('#frmAddEditUser').validate({
            rules: {
                txtContact: {
                    required: true,
                    checkAttr: 'data-contactid'
                },
                txtFirstName: {
                    required: true,
                },
                txtLastName: {
                    required: true,
                },
                txtUserId: {
                    required: true,
                },
                txtEmail: {
                    email: true
                },
                txtPassword: {
                    required: true,
                },
                ddlUserRole: {
                    required: function() {
                        if ($('#ddlUserRole').val() == "-1") {
                            return false;
                        }
                        return true;
                    },
                }
            },
            messages: {
                txtContact: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASECHOOSECONTACT', "Please choose contact"),
                    checkAttr: $.GetLocaleKeyValue('FIELD_PLEASECHOOSEPROPERCONTACT', "Please choose proper contact")
                },
                txtFirstName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERFIRSTNAME', "Please enter first name")
                },
                txtLastName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERLASTNAME', "Please enter last name")
                },
                txtUserId: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERUSERID', "Please enter user id")
                },
                txtEmail: {
                    email: $.GetLocaleKeyValue('FIELD_PLEASEENTERVALIDEMAIL', "Please enter valid email")
                },
                txtPassword: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERPASSWORD', "Please enter password")
                },
                ddlUserRole: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTUSERROLE', "Please select user role")
                }
            },
            onfocusout: function(element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                element.is('select.custom-select')?
                error.appendTo(element.parent().parent().find("span.errorMsg")):
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#frmAddEditUser').valid();
        return v2;
    },
    onAddUserManagementClicked: function() {
        var _this = this;
        if (_this.validateUserManagement()) {
            var userData = _this.getUserManagementData();
            if (userData.UserNumber > 0) {
                if (this.options.eventHandlers.onUserManagementUpdateClicked)
                    this.options.eventHandlers.onUserManagementUpdateClicked(userData, false);
            } else {
                if (this.options.eventHandlers.onUserManagementSaveClicked) {
                    this.options.eventHandlers.onUserManagementSaveClicked(userData);
                }
            }
        }
    },
    clearStatusMessage: function() {
        $("#dryerErrorMsg").html('');
    }
};