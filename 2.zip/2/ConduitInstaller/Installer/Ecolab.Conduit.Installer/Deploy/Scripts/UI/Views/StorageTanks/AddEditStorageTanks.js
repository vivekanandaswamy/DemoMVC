﻿Ecolab.Views.AddEditStorageTanks = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { },
            rendered: function () { },
        },
        maxlevel: null

    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AddEditStorageTanks',
        templateUri: './Scripts/UI/Views/StorageTanks/AddEditStorageTanks.html',
        paraShiftLabors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};
Ecolab.Views.AddEditStorageTanks.prototype = {
    setData: function (data) {
        this.data = data;
        maxlevel = this.options.accountInfo;

        this.tm.Render(data, maxlevel, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();

        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".k-tooltip").parent(".k-animation-container").hide();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });


    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);

        container.find('#btnSaveStorageTank').click(function () {
            _this.onSaveStorageClicked();
        });
        container.find("#bckbutton").click(function () {
            _this.onBackButtonClicked();
        });
        container.find("#btnCancel").click(function () {
            _this.onBackButtonClicked();
        });
        container.find('#btnAddEditStorageTankPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                StorageTankId: _this.data[0].TankId,
                PageTitle: "Storage Tank"

            };
            var json = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + json);
            return retVal;
        });
    },
    getStorageTanksData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            TankId: container.find("#txtTankName").attr("storage-tankid"),
            TankName: container.find("#txtTankName").val(),
            ControllerId: container.find("#ddlControllerName").val(),
            ProductId: container.find("#ddlProductName").val(),
            Emptylevel: container.find("#txtEmptyLevel").val(),
            LowLevel: container.find("#txtLowLevel").val(),
            CallibrationLevel: container.find("#txtCallibrationLevel").val(),
            LevelDeviation: container.find("#txtLevelDeviation").val(),
            Size: container.find("#txtSize").val(),
            InputType: container.find("#ddlInputType").val(),
            EcolabAccountNumber: this.options.accountInfo.EcolabAccountNumber,
            SizeTag: container.find("#txtSizeTag").val(),
            LevelDeviationTag: container.find("#txtDeviationTag").val(),
            CurrentLevel: container.find("#txtCurrentLevel").val(),
            CurrentLevelTag: container.find("#txtCurrentLevelTag").val()
        };
    },
    validateStorageTanks: function () {
        _this = this;
        var container = $(this.options.containerSelector);


        var v1 = container.find('#frmAddEditStorageTanks').validate({
            rules: {
                txtTankName: {
                    required: true,
                },
                ddlControllerName: {
                    required: true,
                },
                ddlProductName: {
                    required: true,
                },
                txtEmptyLevel: {
                    required: true, digits: true,
                },
                txtLowLevel: {
                    required: true, digits: true,
                },
                txtCallibrationLevel: {
                    required: true, digits: true,
                },
                txtLevelDeviation: {
                    required: true, digits: true,
                },
                txtSize: {
                    required: true, digits: true,
                },
                txtInputType: {
                    required: true,
                },
            },
            messages: {
                txtTankName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERSTORAGETANKNAME', 'Please enter Storage Tank Name'),
                },
                ddlControllerName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERCONTROLLERNAME', 'Please enter Controller Name'),
                },
                ddlProductName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERPRODUCTNAME', 'Please enter Product Name'),
                },
                txtEmptyLevel: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTEREMPTYLEVEL', 'Please enter Empty Level'),
                },
                txtLowLevel: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERLOWLEVEL', 'Please enter Low Level'),
                },
                txtCallibrationLevel: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERCALLIBRATIONLEVEL', 'Please enter Calibration Level'),
                },
                txtLevelDeviation: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERDEVIATIONLEVEL', 'Please enter Deviation Level'),
                },
                txtSize: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERSIZE', 'Please enter Size'),
                },
                txtInputType: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERINPUTTYPE', 'Please enter Input Type'),
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));

                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select") || element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().next("span.errorMsg"));
                }
            }
        });

        var v2 = container.find('#frmAddEditStorageTanks').valid();
        return v2;
    },
    onSaveStorageClicked: function () {
        return this.options.eventHandlers.onSavePage();

    },
    onBackButtonClicked: function () {
        this.options.eventHandlers.onBackButtonClick();
    },
    showMessage: function (message) {
        var _this = this;
        var messageDiv = $("#errordiv");
        messageDiv.html(message);
    },
    clearStatusMessage: function () {
        $("#errordiv").html('');
    }
};
