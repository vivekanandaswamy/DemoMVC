﻿Ecolab.Model.ShiftLaborModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onShiftLaborDataLoaded: null,
            onShiftCreated: null,
            onShiftCreationFailed: null,
            onShiftDeleted: null,
            onShiftDeletionFailed: null,
            onShiftUpdated: null,
            onShiftUpdateFailed: null,
            onLaborCreated: null,
            onLaborCreateFailed: null,
            onLaborDeleted: null,
            onLaborDeleteFailed: null,
            onLaborUpdated: null,
            onLaborUpdateFailed: null,
            onShiftToEditGet: null,
            onShiftToEditGetFailed: null,
            onBreakDeleted: null,
            onDeleteBreakFailed: null,
            onAddLaborDataLoaded: null,
            onAddLaborDataLoadFailed: null,
            onLaborCostLoaded: null,
            onTargetProductionDetailsFetched:null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.isInline = 'false';
    this.ShiftLaborModelProxy = new Ecolab.Model.ShiftLaborModelProxy();
};
Ecolab.Model.ShiftLaborModel.prototype = {
    init: function () {
    },
    loadShiftLaborData: function (plantId) {
        var _this = this;
        this.ShiftLaborModelProxy.loadShiftLaborData(function (ShiftLaborData) {
            _this.settings.eventHandlers.onShiftLaborDataLoaded(ShiftLaborData);
        });
    },
    addNewShift: function () {
        return {
            day:
                [{
                    ShiftId:'0',
                    ShiftName: '',
                    StartTime: '10:00 AM',
                    EndTime: '08:00 PM',
                    IsMonday: true,
                    IsTuesday: true,
                    IsWednesday: true,
                    IsThursday: true,
                    IsFriday: true,
                    IsSaturday: false,
                    IsSunday: false,
                   
                    ShiftBreaks: [
                    ]
                }]
        };
    },
    createShift: function (shiftData) {
        var _this = this;
        this.ShiftLaborModelProxy.createShift(shiftData, function (data) {
            _this.settings.eventHandlers.onShiftCreated(data);
        }, function (error, description) { _this.settings.eventHandlers.onShiftCreationFailed(error, description); });
    },
    deleteShift: function (shiftId, dayId) {
        var _this = this;
        this.ShiftLaborModelProxy.deleteShift(shiftId, dayId, function () {
            _this.settings.eventHandlers.onShiftDeleted();
        }, function (error, description) { _this.settings.eventHandlers.onShiftDeletionFailed(error, description); });
    },
    updateShift: function (shiftData) {
        var _this = this;
        this.ShiftLaborModelProxy.updateShift(shiftData, function () {
            _this.settings.eventHandlers.onShiftUpdated();
        }, function (error, description) { _this.settings.eventHandlers.onShiftUpdateFailed(error, description); });
    },
    GetShiftToEdit: function (shiftId, dayId) {
        var _this = this;
        this.ShiftLaborModelProxy.GetShiftToEdit(shiftId, dayId, function (data) {
            _this.settings.eventHandlers.onShiftToEditGet(data);
        }, function (error, description) { _this.settings.eventHandlers.onShiftToEditGetFailed(error, description); });
    },
    deleteBreak: function (shiftId, dayId, breakId) {
        var _this = this;
        this.ShiftLaborModelProxy.deleteBreak(shiftId, dayId, breakId, function () {
            _this.settings.eventHandlers.onBreakDeleted();
        }, function (error, description) { _this.settings.eventHandlers.onDeleteBreakFailed(error, description); });
    },
    createLabor: function (laborData,inline) {
        var _this = this;
        var inline = inline;
        this.isInline = inline;
        this.ShiftLaborModelProxy.createLabor(laborData, function (data) {
            _this.settings.eventHandlers.onLaborCreated(data,inline);
        }, function (error, description) {
            _this.settings.eventHandlers.onLaborCreateFailed(error, description, _this.isInline);
        });
    },
    deleteLabor: function (laborId) {
        var _this = this;
        this.ShiftLaborModelProxy.deleteLabor(laborId, function () {
            _this.settings.eventHandlers.onLaborDeleted();
        }, function (error, description) { _this.settings.eventHandlers.onLaborDeleteFailed(error, description); });
    },
    updateLabor: function (laborData) {
        var _this = this;
        this.ShiftLaborModelProxy.updateLabor(laborData, function () {
            _this.settings.eventHandlers.onLaborUpdated();
        }, function (error, description) { _this.settings.eventHandlers.onLaborUpdateFailed(error, description); });
    },
    getLaborTypeAndLocation: function (laborModel) {
        var _this = this;
        this.ShiftLaborModelProxy.getLaborTypeAndLocation(function (data) {
            laborModel.labor[0].LaborTypes = data.LaborTypes;
            laborModel.labor[0].Locations = data.Locations;
            _this.settings.eventHandlers.onAddLaborDataLoaded(laborModel);
        }, function (error, description) { _this.settings.eventHandlers.onAddLaborDataLoadFailed(error, description); });
    },
    addNewLabor: function (shiftId,dayId) {
        return {
            labor:
                [{
                    ShiftId: shiftId,
                    LaborTypeId: '-1',
                    LocationId: '-1',
                    DayId: dayId,
                    LaborHours: '',
                    PricePerHr: '',
                    LaborId:'0',
                    LaborTypes: [],
                    Locations:[]
                }]
        };
    },
    loadLaborCost: function (id) {
        var _this = this;
        this.ShiftLaborModelProxy.loadLaborCost(id, function (cost) {
            _this.settings.eventHandlers.onLaborCostLoaded(cost);
        });
    },
    FetchTargetProductionDetails: function () {
        var _this = this;
        this.ShiftLaborModelProxy.FetchTargetProductionDetails(function(data) {
            _this.settings.eventHandlers.onTargetProductionDetailsFetched(data);
        });
    }

};

