// JavaScript source code
Ecolab.Model.UserManagementModelProxy = function () {
};

Ecolab.Model.UserManagementModelProxy.prototype =
{
    loadUserManagementData: function (callBack, errorCallBack) {
        var url = "/Api/UserManagement/Fetch";
        this.ApiRead("", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadUserRoles: function (callBack, errorCallBack) {
        var url = "/Api/UserManagement/FetchUserRoles";
        this.ApiRead("", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    createUserManagement: function (requestData, callBack, errorCallBack) {
        var url = "/Api/UserManagement/Create";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateUserManagement: function (requestData, callBack, errorCallBack) {
        var url = "/Api/UserManagement/Put";
        this.ServerRequest("PUT", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteUserManagement: function (requestData, callBack, errorCallBack) {
        var url = "/Api/UserManagement/Delete";
        this.ServerRequest("DELETE", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadContacts: function (request, callBack, errorCallBack) {
        var url = "/api/Contact/GetContactList";
        this.ApiRead("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, request);
    }

}
var base = new Ecolab.Model.Common();
Ecolab.Model.UserManagementModelProxy.prototype = $.extend({}, Ecolab.Model.UserManagementModelProxy.prototype, base);
Ecolab.Model.UserManagementModelProxy.prototype.base = base;