Ecolab.Model.ProductionChartModelProxy = function () {
};

Ecolab.Model.ProductionChartModelProxy.prototype =
{
    loadTunnelData: function (callBack, errorCallBack) {
        var url = "/Api/TrendingChart/GetTunnelDetails";
        this.ApiRead("TrendingChart", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadParametersData: function (id, chartId,callBack, errorCallBack) {
        var url = "/Api/TrendingChart/GetParametersByTunnelId";
        var requestData = { "id": id, "chartId": chartId };
        this.ApiRead("TrendingChart", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadByFilters: function (filters, callBack,current, errorCallBack) {
        var url = "/Api/TrendingChart/GetByFilters";
        this.ApiRead("TrendingChart", url, function (response) { callBack(response, current); }, function (data, exception) { errorCallBack(data, exception); }, null, filters);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ProductionChartModelProxy.prototype = $.extend({}, Ecolab.Model.ProductionChartModelProxy.prototype, base);
Ecolab.Model.ProductionChartModelProxy.prototype.base = base;