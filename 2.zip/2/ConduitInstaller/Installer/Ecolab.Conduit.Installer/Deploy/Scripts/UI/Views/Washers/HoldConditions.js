Ecolab.Views.HoldConditions = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: { onRedirection: function () { } },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'HoldConditions',
        templateUri: '/Scripts/UI/Views/Washers/HoldConditions.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.HoldConditions.prototype = {
    // sets the tunnel compartments data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);

        this.loadData(data);
    },
    onRendered: function () {
        var _this = this;

        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $('#allAlarmConditions').pickList({
            beforePopulate: function () {
                $(".pickList_addAll, .pickList_removeAll").hide();
            },
            sourceListLabel: ($.GetLocaleKeyValue('FIELD_ALLHOLDCONDITIONS', 'All Hold Conditions')),
            targetListLabel: ($.GetLocaleKeyValue('FIELD_ACTIVECONDITIONS', 'Active Conditions'))
        });
        $(".pickList_add, .pickList_remove").click(function () {
            // $("#btnSaveAlarm").removeAttr("disabled");
            $("#massage").text('');
        });
        $(".pickList_list").css("height", $(window).height() - 476);
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find("#btnSaveAlarm").click(function () {
            _this.onWasherSaveClicked();
        });
       
        container.find('#btnHoldConditionPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                WasherId: _this.options.accountInfo.TunnelId,
                ControllerId: _this.options.accountInfo.ControllerId == null ? 0 : _this.options.accountInfo.ControllerId,
                ControllerTypeId: _this.options.accountInfo.ControllerTypeId,
                ControllerModelId: _this.options.accountInfo.ControllerModelId,
                WasherGroupId: _this.options.accountInfo.WashergroupId,
                WasherGroupTypeId: _this.options.accountInfo.WasherGroupTypeId,
                RegionId: _this.options.accountInfo.RegionId,
                MachineNumber: _this.options.accountInfo.MachineNumber,
                NumberOfCompartments: _this.options.accountInfo.NoofCompartments == null ? 0 : _this.options.accountInfo.NoofCompartments,
                PageTitle: _this.options.accountInfo.WasherGroupTypeId == 1 ? "ConventionalGeneral" : "Tunnel General"
            };
          
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });
    },
    onWasherSaveClicked: function () {
        this.clearStatusMessage();
        return this.options.eventHandlers.onSavePage();
    },
    loadData: function (data) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var target = container.find(".pickList_targetList");
        target.empty();
        var source = container.find(".pickList_sourceList");
        source.empty();
        $.each(data.data.AlarmsModel, function (key, value) {

            if (value.Active) {

                target.append(' <li class="pickList_listItem" label="' + value.Description + '" data-value="' + value.AlarmMachineMappingId + '">' + value.Description + '</li>');
            } else {
                source.append('  <li class="pickList_listItem" label="' + value.Description + '" data-value="' + value.AlarmMachineMappingId + '">' + value.Description + '</li>');
            }
        });
        container.find("#massage").text(data.message);
    },
    getAlarmData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var ids = [];
        $('.pickList_targetList').each(function () {
            $(this).find('li').each(function () {
                // cache jquery object
                var current = $(this).attr('data-value');
                ids.push(current);
            });
        })
        return {
            AlarmMachineMappingIds: ids,
            EcolabAccountNumber: this.options.accountInfo.EcolabAccountNumber
        };
    },
    clearStatusMessage: function () {
        $("#massage").html('');
    },
}