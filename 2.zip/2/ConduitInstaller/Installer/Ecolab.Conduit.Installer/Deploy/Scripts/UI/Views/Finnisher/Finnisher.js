// JavaScript source code
Ecolab.Views.Finnisher = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onAddFinnisherGroupClicked: null,
            onEditFinnisherGroupClicked: null,
            onDeleteFinnisherGroupClicked: null,
            onEditFinnisherClicked: null,
            onDeleteFinnisherClicked: null,
            onInlineEditFinnisherLinkClicked: null,
            onInlineEditFinnisherClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Finnisher/Finnisher.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.Finnisher.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        $('.tblFinnishers').tablesorter({
            headers: {
                0: {
                    sorter: false
                }
            }
        });

        $('.tabFinnisherGroup').addClass('active');
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find("#addFinnisherGroup").click(function () {
            _this.clearStatusMessage();
            _this.onAddFinnisherGroupClicked();
        });

        container.find(".editFinnisherGroup").click(function () {
            _this.clearStatusMessage();
            _this.onEditFinnisherGroupClicked(_this.getFinnisherGroupData(this));
        });

        container.find(".deleteFinnisherGroup").click(function () {
            _this.clearStatusMessage();
            var finnisherGroupData = _this.getFinnisherGroupData(this);
            _this.onDeleteFinnisherGroupClicked($(this).attr('Finnisher-groupid'), finnisherGroupData);
        });

        container.find(".btnAddFinnisher").click(function () {
            _this.clearStatusMessage();
            _this.onAddFinnisherClicked($(this).attr('Finnisher-groupid'));
        });

        container.find(".lnkUpdateFinnisher").click(function () {
            _this.clearStatusMessage();
            _this.onEditFinnisherClicked(_this.getFinnisherData(this));
        });

        container.find(".lnkDeleteFinnisher").click(function () {
            _this.clearStatusMessage();
            var finnisherData = _this.getFinnisherData(this);
            _this.onDeleteFinnisherClicked($(this).attr('Finnisher-id'), finnisherData);
        });

        container.find(".editFinnisherInline").click(function () {
            _this.clearStatusMessage();
            container.find(".noneditable").show();
            container.find(".editable").hide();
            var FinnisherData = _this.getFinnisherData(this);
            _this.onInlineEditFinnisherLinkClicked(this, FinnisherData);
        });

        container.find(".updateFinnisherInline").click(function () {
           // _this.onSaveTrClicked(this);
            _this.clearStatusMessage();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            if (_this.validate()) {
                _this.onInlineEditFinnisherClicked(_this.getInlineFinnisherData(this, tr));
            }
        });

        container.find(".cancelFinnisherInline").click(function () {
            _this.clearStatusMessage();
            $('span.errorMsg').text('');
            container.find(".noneditable").show();
            container.find(".editable").hide();
            $(this).parents('.trEditable').first().removeClass('dirty');
        });

    },
    onSaveTrClicked: function (element) {
        var _this = this;
        _this.clearStatusMessage();
        var tr = $('.table-striped').find('dirty');
        if (_this.validate()) {
            _this.onInlineEditFinnisherClicked(_this.getInlineFinnisherData(element, tr));
        }
    },
    showEditOnInlineEditLink: function (e, FinnisherTypes, data) {
        var tr = $(e).parents('.trEditable').first();
        var ddlType = $(tr).find('.ddlType');
        ddlType.empty();
        ddlType.append('<option value="">-- Select --</option>');
        $.each(FinnisherTypes, function () {
            ddlType.append('<option value="' + this.Id + '">' + this.Name + '</option>');
        });

        $(tr).find('.txtName').val(data.Name),
        ddlType.val(data.FinnisherTypeId)

        tr.find(".noneditable").hide();
        tr.find(".editable").show();
    },
    inlineEditFailed: function () {
        $('finnisherErrorMsgDiv').html('Update failed');
    },
    getInlineFinnisherData: function (ele, tr) {
        return {
            GroupId: $(ele).attr('Finnisher-groupid'),
            FinisherId: $(ele).attr('finnisher-id'),
            Number:$(tr).find('.txtNumber').val(),
            Name: $(tr).find('.txtName').val(),
            FinnisherType: {
                Id: $(tr).find('.ddlType').val()
            }
        };
    },
    showSucessMessage: function (message) {
        var _this = this;
        var messageDiv = $("#finnisherErrorMsgDiv");
        messageDiv.html('<label class="k-success-message">' + message + '</label>');
    },
    showErrorMessage: function (message) {
        var _this = this;
        var messageDiv = $("#finnisherErrorMsg");
        messageDiv.html('<label class="k-error-message">' + message + '</label>');
    },
    showHomePageErrorMessage: function (message) {
        var _this = this;
        var messageDiv = $("#finnisherErrorMsgDiv");
        messageDiv.html('<label class="k-error-message">' + message + '</label>');
    },
    getFinnisherGroupData: function (element) {
        return {
            FinnisherGroupId: $(element).attr('Finnisher-groupid'),
            FinnisherGroupName: $(element).attr('Finnisher-groupname')
        };
    },
    getFinnisherData: function (element) {
        return {
            GroupId: $(element).attr('Finnisher-groupid'),
            FinisherId: $(element).attr('Finnisher-id'),
            Name: $(element).attr('Finnisher-name'),
            FinnisherTypeId: $(element).attr('Finnisher-type'),
            Number:$(element).attr('Finisher-number')
        };
    },
    onAddFinnisherGroupClicked: function () {
        if (this.options.eventHandlers.onAddFinnisherGroupClicked)
            this.options.eventHandlers.onAddFinnisherGroupClicked();
    },
    onEditFinnisherGroupClicked: function (data) {
        if (this.options.eventHandlers.onEditFinnisherGroupClicked)
            this.options.eventHandlers.onEditFinnisherGroupClicked(data);
    },
    onDeleteFinnisherGroupClicked: function (id, finnisherGroupData) {
        if (this.options.eventHandlers.onDeleteFinnisherGroupClicked)
            this.options.eventHandlers.onDeleteFinnisherGroupClicked(id, finnisherGroupData);
    },
    onAddFinnisherClicked: function (id) {
        if (this.options.eventHandlers.onAddFinnisherClicked)
            this.options.eventHandlers.onAddFinnisherClicked(id);
    },
    onEditFinnisherClicked: function (data) {
        if (this.options.eventHandlers.onEditFinnisherClicked)
            this.options.eventHandlers.onEditFinnisherClicked(data);
    },
    onDeleteFinnisherClicked: function (id, finnisherData) {
        if (this.options.eventHandlers.onDeleteFinnisherClicked)
            this.options.eventHandlers.onDeleteFinnisherClicked(id, finnisherData);
    },
    onInlineEditFinnisherClicked: function (data) {
        if (this.options.eventHandlers.onInlineEditFinnisherClicked)
            this.options.eventHandlers.onInlineEditFinnisherClicked(data, true);
    },
    onInlineEditFinnisherLinkClicked: function (e, data) {
        if (this.options.eventHandlers.onInlineEditFinnisherLinkClicked)
            this.options.eventHandlers.onInlineEditFinnisherLinkClicked(e, data);
    },
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmFinnisher').validate({
            rules: {
                txtNumber: {
                    required: true,
                    number:true
                },
                txtName: {
                    required: true,
                },
                ddlFinnisherType: {
                    required: function () {
                        if ($('#ddlFinnisherType').val() == "Select") {
                            return false;
                        }
                        return true;
                    },
                },

            },
            messages: {
                txtNumber: {
                    required: "*",
                    number:"*"
                },
                txtName: {
                    required: "*",
                },
                ddlFinnisherType: {
                    required: "*",
                },
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#frmFinnisher').valid();
        return v2;
    },
    clearStatusMessage: function () {
        $("#finnisherErrorMsgDiv").html('');
    }
}