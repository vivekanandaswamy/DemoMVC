﻿Ecolab.Views.Paging = function (options) {
    var _this = this;

    var defaultSettings = {
        containerSelector: null,
        numberOfPageSelectors: 5,
        sizeOfPage: 50,
        eventHandlers: {
            rendered: function () { },
            pageRequested: function (pageIndex) { }
        }
    };

    this.numberOfItems = null;
    this.selectedIndex = null;
    this.pagingIndex = null;
    this.createPagingOnRender = false;

    this.settings = $.extend(defaultSettings, options);

    this.tm = new TemplateManager({
        templateName: 'Paging',
        templateUri: '/Scripts/UI/Views/Paging/Paging.html',
        parameters: [],
        containerElement: this.settings.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.Paging.prototype = {
    show: function () {
        this.tm.Render({}, this);
    },

    setPagingData: function (numberOfItems) {
        this.numberOfItems = numberOfItems;
        this.selectedIndex = 0;
        this.pagingIndex = 0;

        if (this.isRendered())
            this.createPaging();
        else {
            this.createPagingOnRender = true;
            this.tm.Render({}, this);
        }
    },

    changeNumberOfItems: function (numberOfItems) {
        if (!this.isRendered())
            this.setPagingData(numberOfItems);

        if (this.numberOfItems == numberOfItems)
            return;

        this.numberOfItems = numberOfItems;

        var numberOfPages = this.getNumberOfPages();

        if (this.selectedIndex >= numberOfPages)
            this.selectedIndex = numberOfPages - 1;

        var numberOfPageSets = this.getNumberOfPagesets();

        if (this.pagingIndex >= numberOfPageSets)
            this.pagingIndex = numberOfPageSets - 1;

        this.createPaging();
    },

    createPaging: function () {
        var _this = this;
        var container = $(this.settings.containerSelector + ' .paging');
        var numberOfPages = this.getNumberOfPages();

        container.empty();

        if (numberOfPages < 2)
            return;

        //navigation buttons at the begining of the page list
        if (this.pagingIndex != 0) {
            var goToFirst = $('<span class="gotoFirstPageSet">&nbsp;<<&nbsp;</span>');
            container.append(goToFirst);
            container.find('.gotoFirstPageSet').bind('click', function () { _this.onGoToFirstPageset(); });

            var goToPrevious = $('<span class="gotoPreviousPage">&nbsp;<&nbsp;</span>');
            container.append(goToPrevious);
            container.find('.gotoPreviousPage').bind('click', function () { _this.onGoToPreviousPageset(); });

        }

        var startIndex = this.pagingIndex * this.settings.numberOfPageSelectors;

        if (numberOfPages > startIndex + this.settings.numberOfPageSelectors)
            displayNumber = startIndex + this.settings.numberOfPageSelectors;
        else
            displayNumber = numberOfPages;

        //page buttons in the page list
        for (var i = startIndex; i < displayNumber; i++) {
            container.append('<span pageindex="' + i + '">' + (i + 1) + '</span>');
        }

        //navigation buttons at the end of the page list
        if (this.pagingIndex != this.getNumberOfPagesets() - 1) {
            var goToNext = $('<span class="goToNextPageSet">&nbsp;>&nbsp;</span>');
            container.append(goToNext);
            container.find('.goToNextPageSet').bind('click', function () { _this.onGoToNextPageset(); });

            var goToLast = $('<span class="gotoLastPage">&nbsp;>>&nbsp;</span>');
            container.append(goToLast);
            container.find('.gotoLastPage').bind('click', function () { _this.onGoToLastPageset(); });
        }

        container.find('span[pageindex=' + this.selectedIndex + ']').addClass('selected');
        container.find('span:not(.selected,.goToNextPageSet,.gotoLastPage,.gotoFirstPageSet,.gotoPreviousPage)').click(function () { _this.onPageClicked(parseInt($(this).attr('pageindex'))); });
    },

    onRendered: function () {

        if (this.createPagingOnRender == true) {
            this.createPagingOnRender = false;
            this.createPaging();
        }

        if (this.settings.eventHandlers.rendered)
            this.settings.eventHandlers.rendered();
    },

    onPageClicked: function (index) {
        this.selectedIndex = index;
        this.createPaging();

        if (this.settings.eventHandlers.pageRequested)
            this.settings.eventHandlers.pageRequested(index);
    },

    onGoToFirstPageset: function () {
        this.pagingIndex = 0;
        this.createPaging();
    },

    onGoToLastPageset: function () {
        this.pagingIndex = this.getNumberOfPagesets() - 1;
        this.createPaging();
    },

    onGoToPreviousPageset: function () {
        this.pagingIndex--;
        this.createPaging();
    },

    onGoToNextPageset: function () {
        this.pagingIndex++;
        this.createPaging();
    },

    getNumberOfPages: function () {
        return Math.ceil(this.numberOfItems / this.settings.sizeOfPage);
    },

    getNumberOfPagesets: function () {
        return Math.ceil(this.getNumberOfPages() / this.settings.numberOfPageSelectors);
    },

    isRendered: function () {
        return $(this.settings.containerSelector).find('.paging').length != 0
    }
};