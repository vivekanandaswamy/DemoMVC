Ecolab.Model.MeterModelProxy = function () {
};

Ecolab.Model.MeterModelProxy.prototype =
{
    loadMeterData: function (callBack, errorCallBack) {
        //var url = "/Api/Meter/GetMeterOnAdd";
        //this.ApiRead("Meter", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    loadOnUtilityLocationChange: function (id, callBack, errorCallBack) {
        var url = "/Api/Meter/GeOnUtilityLocationChange/{id}";
        var requestData = { "id": id };
        this.ApiRead("Meter", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    loadMeterOnAddNewPopupLoad: function (callBack, errorCallBack) {
        var url = "/Api/Meter/GetMeterOnAdd";
        this.ApiRead("Meter", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    //For UOM Dropdown
    loadUOMByUtilityTypeId: function (id, callBack, errorCallBack) {
        var url = "/Api/Meter/GetUOM/{id}"; var requestData = { "id": id };
        this.ApiRead("Meter", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadMeterOnEditPopupLoad: function (id, callBack, errorCallBack) {
        var url = "/Api/Meter/GetMeterOnEdit/{id}";
        var requestData = { "id": id };
        this.ApiRead("Meter", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }


};

var base = new Ecolab.Model.Common();
Ecolab.Model.MeterModelProxy.prototype = $.extend({}, Ecolab.Model.MeterModelProxy.prototype, base);
Ecolab.Model.MeterModelProxy.prototype.base = base;