﻿Ecolab.Views.WasherList = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'WasherList',
        templateUri: '/Scripts/UI/Views/Washers/WasherList.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.WasherList.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".k-tooltip").parent(".k-animation-container").hide();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $('#tblWashers').tablesorter({
            headers: {
                0: {
                    sorter: false
                }
            }
        });
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find(".deleteWashers").click(function () {
            $('#errordiv').text('');
            _this.onWasherDeleteClicked($(this).attr('washertype'), $(this).attr('washers-id'));
        });

        container.find(".updateWashers").click(function () {
            $('#errordiv').text('');
            _this.redirect($(this).attr('washertype'), $(this).attr('washers-id'), $(this).attr('washergroup-id'));
        });

        container.find('#btnWasherListPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                PageTitle: "Washer List"
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });

    },
    onWasherDeleteClicked: function (isTunnel, id) {
        if (this.options.eventHandlers.onWasherDeleteClicked)
            this.options.eventHandlers.onWasherDeleteClicked(isTunnel, id);
    },
    redirect: function (washerType, washersId, washergroupId) {
        if (washerType == 'true') {
            var retval = this.options.eventHandlers.onRedirection('./TunnelGeneral?WasherId=' + washersId + '&WasherGroupId=' + washergroupId + '&WasherGroupTypeId=2');
            return retval;
        }
        else {
            var retval = this.options.eventHandlers.onRedirection('./ConventionalGeneral?WasherId=' + washersId + '&WasherGroupId=' + washergroupId);
            return retval;
        }
    },
    
}