// JavaScript source code
Ecolab.Views.UserManagement = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onAddUserManagementClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/UserManagement/UserManagement.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.UserManagement.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        $('#tblUserManagement').tablesorter({
            headers: {
                0: {
                    sorter: false
                }
            }
        });

        $('.tabUserManagementGroup').addClass('active');
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find(".btnAddUser").click(function () {
            _this.clearStatusMessage();
            _this.onAddUserManagementClicked();
        });

        container.find(".lnkUpdateUser").click(function () {
            _this.clearStatusMessage();
            $('span.errorMsg').text('');
            container.find(".noneditable").show();
            container.find(".editable").hide();
            _this.onEditUserManagementClicked(_this.getUserManagementData(this));
        });

        container.find(".lnkDeleteUser").click(function () {
            _this.clearStatusMessage();
            $('span.errorMsg').text('');
            container.find(".noneditable").show();
            container.find(".editable").hide();
            _this.onDeleteUserManagementClicked(_this.getUserManagementData(this));
        });

        container.find(".editUserInline").click(function () {
            _this.clearStatusMessage();
            $('span.errorMsg').text('');
            container.find(".noneditable").show();
            container.find(".editable").hide();
            _this.onInlineEditUserManagementLinkClicked(this, _this.getUserManagementData(this));
        });

        container.find(".updateUserInline").click(function () {
            _this.clearStatusMessage();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            if (_this.validate()) {
                _this.onInlineUpdateUserManagementClicked(_this.getUpdatedUserManagementData(this));
            }
        });

        container.find(".cancelUserInline").click(function () {
            $('span.errorMsg').text('');
            _this.clearStatusMessage();
            container.find(".noneditable").show();
            container.find(".editable").hide();
            $(this).parents('.trEditable').first().removeClass('dirty');
        });
    },
    showEditOnInlineEditLink: function (e, roles, data) {
        var tr = $(e).parents('.trEditable').first();
        var ddlUserRole = $(tr).find('.ddlUserRole');
        ddlUserRole.empty();
        ddlUserRole.append('<option value="">-- Select --</option>');
        $.each(roles, function () {
            ddlUserRole.append('<option value="' + this.RoleId + '">' + this.RoleName + '</option>');
        });

        $(tr).find("#txtFirstName").val(data.FirstName),
        $(tr).find("#txtLastName").val(data.LastName),
        $(tr).find("#txtUserId").val(data.LoginName),
        $(tr).find("#txtEmail").val(data.Email),
        ddlUserRole.val(data.LevelId)

        tr.find(".noneditable").hide();
        tr.find(".editable").show();
    },
    inlineEditFailed: function () {
        $('UserManagementErrorMsgDiv').html('Update failed');
    },
    //getInlineUserManagementData: function (ele, tr) {
    //    return {
    //        GroupId: $(ele).attr('dryer-groupid'),
    //        Number: $(ele).attr('dryer-number'),
    //        Name: $(tr).find('.txtName').val(),
    //        Nominalload: $(tr).find('.txtNominalload').val(),
    //        DryerType: {
    //            Id: $(tr).find('.ddlType').val()
    //        }
    //    };
    //},
    showSucessMessage: function (message) {
        var _this = this;
        var messageDiv = $("#userManagementErrorMsgDiv");
        messageDiv.html(message);
    },
    showErrorMessage: function (message) {
        var _this = this;
        var messageDiv = $("#userManagementErrorMsgDiv");
        messageDiv.html(message);
    },
    showPopupErrorMessage: function (message) {
        var _this = this;
        var messageDiv = $("#userErrorMsg");
        messageDiv.html(message);
    },
    onAddUserManagementClicked: function () {
        if (this.options.eventHandlers.onAddUserManagementClicked)
            this.options.eventHandlers.onAddUserManagementClicked();
    },
    onEditUserManagementClicked: function (data) {
        if (this.options.eventHandlers.onEditUserManagementClicked)
            this.options.eventHandlers.onEditUserManagementClicked(data);
    },
    onDeleteUserManagementClicked: function (id) {
        if (this.options.eventHandlers.onDeleteUserManagementClicked)
            this.options.eventHandlers.onDeleteUserManagementClicked(id);
    },
    onInlineUpdateUserManagementClicked: function (data) {
        if (this.options.eventHandlers.onInlineEditUserManagementClicked)
            this.options.eventHandlers.onInlineEditUserManagementClicked(data, true);
    },
    onInlineEditUserManagementLinkClicked: function (e, data) {
        if (this.options.eventHandlers.onInlineEditUserManagementLinkClicked)
            this.options.eventHandlers.onInlineEditUserManagementLinkClicked(e, data);
    },
    getUserManagementData: function (element) {
        var tr = $(element).parents('.trEditable').first();
        return {
            ContactId: tr.attr('data-contactid'),
            UserNumber: tr.attr('data-userid'),
            FirstName: tr.attr('data-userfirstname'),
            LastName: tr.attr('data-userlastname'),
            LoginName: tr.attr('data-userloginname'),
            Password: tr.attr('data-userpassword'),
            Email: tr.attr('data-useremail'),
            ContactNo: tr.attr('data-usercontactno'),
            LevelId: tr.attr('data-userlevelid'),
            Roles: []
        };
    },
    getUpdatedUserManagementData: function (element) {
        _this = this
        var tr = $(element).parents('.trEditable').first();
        var user = _this.getUserManagementData(element);
        user.ContactId = $(tr).attr("data-contactid");
        user.FirstName = $(tr).find("#txtFirstName").val();
        user.LastName = $(tr).find("#txtLastName").val();
        user.LoginName = $(tr).find("#txtUserId").val();
        user.Email = $(tr).find("#txtEmail").val();
        user.LevelId = $(tr).find("#ddlUserRole").val();

        return user;
    },
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var v1 = container.find('#formUserManagement').validate({
            rules: {
                txtFirstName: {
                    required: true,
                },
                txtLastName: {
                    required: true,
                },
                txtUserId: {
                    required: true,
                },
                txtEmail: {
                    required: true,
                    email: true
                },
                ddlUserRole: {
                    required: function () {
                        if ($('#ddlUserRole').val() == "-1") {
                            return false;
                        }
                        return true;
                    },
                }

            },
            messages: {
                txtFirstName: {
                    required: "*"
                },
                txtLastName: {
                    required: "*"
                },
                txtUserId: {
                    required: "*"
                },
                txtEmail: {
                    required: "*",
                    email: "*"
                },
                ddlUserRole: {
                    required: "*"
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#formUserManagement').valid();
        return v2;
    },
    clearStatusMessage: function () {
        $("#userManagementErrorMsgDiv").html('');
        $("#userErrorMsg").html('');
    }
}