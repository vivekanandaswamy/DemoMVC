Ecolab.Views.ManualInputTabs = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { },
            onRedirection: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'ManualInputTabsList',
        templateUri: './Scripts/UI/Views/ManualInput/ManualInputTabs.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.ManualInputTabs.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling by venkat
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        if (_this.data != null) {
            $('#' + _this.data.TabToSelect).parent().addClass('active');
            $('#' + _this.data.TabToSelect + 'Container').addClass('active');
        }

        container.find('#tabUtility').click(function () {
            return _this.options.eventHandlers.onRedirection('/ManualUtility');
        });
        container.find('#tabProductionData,#tabProduction').click(function () {
            return _this.options.eventHandlers.onRedirection('/MIProduction');
        });
        container.find('#tabManualRewash').click(function () {
            return _this.options.eventHandlers.onRedirection('/ManualRewash');
        });
        container.find('#tabBatchData').click(function () {
            return _this.options.eventHandlers.onRedirection('/ManualBatch');
        });
        container.find('#tabLabour').click(function () {
            return _this.options.eventHandlers.onRedirection('/ManualInputLabor');
        });
    },

    onGeneralTabClicked: function () {
        if (this.options.eventHandlers.generalTabClicked)
            this.options.eventHandlers.generalTabClicked();
    },
    onCustomerTabClicked: function () {
        if (this.options.eventHandlers.customerTabClicked)
            this.options.eventHandlers.customerTabClicked();
    }
};