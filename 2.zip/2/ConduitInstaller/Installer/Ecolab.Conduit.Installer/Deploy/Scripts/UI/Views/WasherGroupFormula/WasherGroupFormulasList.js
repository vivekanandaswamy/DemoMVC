Ecolab.Views.WasherGroupFormulasList = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'WasherGroupFormulasList',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/WasherGroupFormulasList.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.WasherGroupFormulasList.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $('#tblWasherGroupsFormulas').tablesorter({
            headers: {
                0: {
                    sorter: false
                }
            }
        });
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find('.deleteFormulaList').click(function () {
            _this.clearStatusMessage();
            _this.onDeleteFormulaListClicked($(this).attr('formula-id'));
        });

        //Print Button
        container.find('#btnFormulaListPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                WasherGroupId: _this.options.accountInfo.WasherGroupId,
                PageTitle: "Formula List",
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });

        // click event for inline editing for washer groups.
        container.find('.editFormulaList').click(function () {
            container.find(".noneditable").show();
            container.find(".editable").hide();
            _this.clearStatusMessage();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            $(tr).find("#txtNominalLoad").val($(tr).find("#lblNominalLoad").text().trim());
            tr.find(".noneditable").hide();
            tr.find(".editable").show();

        });

        // Click event for cancel the inline edit and shows the grid.
        container.find(".cancelInlineFormulaList").click(function () {
            _this.clearStatusMessage();
            container.find(".noneditable").show();

            container.find(".error").text('');
            container.find(".editable").hide();
            var tr = $(this).parents('.trEditable').first().removeClass('dirty');
            $(tr).find("#txtNominalLoad").val($(tr).find("#lblNominalLoad").text().trim());
            $(tr).find("#txtLoadsperMonth").val($(tr).find("#lblLoadsperMonth").text().trim());
        });
        //updateInlineFormulaList
        //cancelInlineFormulaList

        container.find(".updateInlineFormulaList").click(function () {
            _this.clearStatusMessage();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            var FormulaData = _this.GetFormulaData(this, tr);
            var Id = _this.getFormulaListData(this, tr);
            var id = Id.Id;
            FormulaData.Id = id;
            if (_this.validateFormula()) {
                _this.UpdateInlineClicked(FormulaData);
            }

        });

        container.find("#btnAddFormula").click(function () {
            _this.clearStatusMessage();
            _this.clearStatusMessage();
            _this.onAddEditFormulaClicked();
        });

        container.find(".updateFormulaList").click(function () {
            _this.clearStatusMessage();
            _this.clearStatusMessage();
            var tr = $(this).parents('.trEditable').first();
            var Id = _this.getFormulaListData(this, tr);
            var id = Id.Id;
            _this.onEditFormulaClicked(id);
        });
        container.find(".viewFormulaDetails").click(function () {
            _this.onEditFormulaClicked($(this).attr('formula-id'));
        });

    },
    //Event is for deleting the washer group from the grid.
    onDeleteWasherGroupClicked: function (washergroupId) {
        if (this.options.eventHandlers.onDeleteWasherGroupClicked)
            this.options.eventHandlers.onDeleteWasherGroupClicked(washergroupId);
    },

    //Event is for going on the add/edit formula page.
    onAddEditFormulaClicked: function () {

        if (this.options.eventHandlers.onAddEditFormulaClicked)
            this.options.eventHandlers.onAddEditFormulaClicked();
    },

    onDeleteFormulaListClicked: function (Id) {
        if (this.options.eventHandlers.onDeleteFormulaListClicked)
            this.options.eventHandlers.onDeleteFormulaListClicked(Id);
    },
    getFormulaListData: function (element, tr) {
        return {
            Id: $(element).attr('formula-id'),

        };
    },
    onEditFormulaClicked: function (id) {
        if (this.options.eventHandlers.onEditFormulaClicked)
            this.options.eventHandlers.onEditFormulaClicked(id);
    },
    //Event for updating the formula inline
    UpdateInlineClicked: function (FormulaData) {
        return this.options.eventHandlers.onFormulaInlineUpdateClicked(FormulaData);
    },

    GetFormulaData: function (ele, tr) {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            Id: $(tr).find("#txtNominalLoad").attr('formula-id'),
            NominalLoad: $(tr).find("#txtNominalLoad").val(),
            LoadsPerMonth: $(tr).find("#txtLoadsperMonth").val(),
            ExtraTime: $(tr).find("#txtExtraTime").val(),
        };
    },
    validateFormula: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var groupType = container.find("#hWasherGroupTypeId").val();
        var minValue = (25 / 100) * this.options.accountInfo.Maxload;
        var maxValue = (200 / 100) * this.options.accountInfo.Maxload;
        var v1 = container.find('#frmWasherGroupFormulaList').validate({
            rules: {
                txtNominalLoad: {
                    required: true,
                    max: groupType == 1 ? 100 : maxValue,
                    min: groupType == 1 ? 25 : minValue,
                },
                txtLoadsperMonth: { required: true },
                txtExtraTime: {
                    required: true,
                    max: 10000
                }
               
            },
            messages: {
                txtNominalLoad: {
                    required: $.GetLocaleKeyValue('FIELD_NOMINALLOADCANNOTBEEMPTY', 'Nominal Load cannot be Empty.'),
                    max: groupType == 1 ? $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN25TO100', 'Please enter between 25 to 100.') : $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN25TO125OFMAXLOAD', 'Please Enter between 25% to 200% of MaxLoad.'),
                    min: groupType == 1 ? $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN25TO100', 'Please enter between 25 to 100.') : $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN25TO125OFMAXLOAD', 'Please Enter between 25% to 200% of MaxLoad.'),
                },
                txtLoadsperMonth: { required: $.GetLocaleKeyValue('FIELD_LOADSPERMONTHCANNOTBEEMPTY', 'Loads per month cannot be Empty.') },
                txtExtraTime: {
                    required: $.GetLocaleKeyValue('FIELD_EXTRATIMECANNOTBEEMPTY', 'Extra time cannot be Empty.'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERAVALUELESSTHANOREQUALTO10000', 'Please enter a value less than or equal to 10000.'),
                }
            }
        });

        var v2 = container.find('#frmWasherGroupFormulaList').valid();
        return v2;
    },
    clearStatusMessage: function () {
        $("#divMessage").html('');
    },
    showMessage: function (message) {
        var _this = this;
        var messageDiv = $("#divMessage");
        messageDiv.html(message);
    },

    getInlineData: function () {
        this.clearStatusMessage();
        var tr = $('.table-striped').find('.dirty');
        var data = this.GetFormulaData($(tr).find('.updateInlineFormulaList'), tr);

        this.UpdateInlineClicked(data);
    }
}