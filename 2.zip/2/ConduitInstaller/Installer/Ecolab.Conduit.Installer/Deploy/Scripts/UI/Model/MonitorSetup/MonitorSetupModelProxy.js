Ecolab.Model.MonitorSetupModelProxy = function () {
};

Ecolab.Model.MonitorSetupModelProxy.prototype =
{
    fetchWasherGroup: function (data, callBack, errorCallBack) {
        var url = "/Api/MonitorSetup/FetchWasherGroups/?data={data}";
        var requestData = { "data": data};
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    fetchDataonDashboardTypeChange: function (id, callBack, errorCallBack) {
        var url = "/Api/MonitorSetup/FetchMachinesForWasherGroupType/{id}";
        var requestData = { "id": id };
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    loadMonitorSetup: function (callBack, errorCallBack) {
        var url = "/Api/MonitorSetup/FetchMonitorSetUpForAdd";
        this.ServerRequest("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    fetchMonitorSetUpDetails: function (callBack, errorCallBack) {
        var url = "/Api/MonitorSetup/FetchMonitorSetUpDetails";
        this.ServerRequest("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    updateMonitorSetup: function (manualProductionViewModel, callBack, errorCallBack) {
        var url = "/Api/MonitorSetup/SaveMonitorSetup";
        this.ServerRequest("Post", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, manualProductionViewModel);
    },

    fetchMonitorDetailsToEdit: function (id,callBack,errorCallBack) {
        var url = "/Api/MonitorSetup/FetchMonitorDetailsToEdit/{id}";
        var requestData = { "id": id };
        this.ApiRead("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    FetchMonitors: function (callBack, errorCallBack) {
        var url = "/Api/MonitorSetup/FetchMonitors/";
        this.ApiRead("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },

    deleteMonitorSetup: function (id, callBack, errorCallBack) {
        var url = "/Api/MonitorSetup/DeleteMonitorSetup/{id}";
        var requestData = { "id": id };
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
};

var base = new Ecolab.Model.Common();
Ecolab.Model.MonitorSetupModelProxy.prototype = $.extend({}, Ecolab.Model.MonitorSetupModelProxy.prototype, base);
Ecolab.Model.MonitorSetupModelProxy.prototype.base = base;