﻿Ecolab.Views.ManualRewash = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
            onDeleteClicked: null,
            onWasherGroupChange: null,
            onFormulaChange: null
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ManualInput/ManualRewash/ManualRewash.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.ManualRewash.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "101":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "301":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEDSUCCESS', 'Deleted successfully') + '</label>';
                break;
            case "401":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEFAILED', 'Deletion failed') + '</label>';
                break;
            case "501":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('.divErrorMsg');
        messageDiv.html(errLabel);
    },
    onRendered: function () {
        var _this = this;
        $('.tabManualRewash').addClass('active');
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find("#btnCancel").click(function () {
            // _this.clearMessage();
            window.location = '/ManualRewash';
            //_this.cancelClicked();
        })

        container.find(".btnSave").click(function () {
            _this.onSaveClicked();
        });

        container.find(".btnDelete").click(function () {
            _this.onDeleteClicked();
        });

        container.find(".ddlWasherGroup").change(function () {
            if (container.find(".ddlWasherGroup").val().trim() == "") {
                _this.onWasherGroupChange(-1);
            } else {
                _this.onWasherGroupChange(container.find(".ddlWasherGroup").val());
            }
        });

        container.find(".ddlRewashReason").change(function () {
            _this.onFormulaChange();
        });

        container.find(".ddlFormula").change(function () {
            _this.onFormulaChange();
        });

    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "Please check your input."
       );
        var v1 = container.find('#frmManualRewash').validate({
            rules: {
                txtLastValue: {
                    required: true,
                    regex: pattern1
                },
                txtNewValue: {
                    regex: pattern1
                },
                ddlWasherGroup: {
                    required: true
                },
                ddlRewashReason: {
                    required: true
                },
                ddlFormula: {
                    required: true
                },
            },
            messages: {
                ddlWasherGroup: {
                    required: "Please select WasherGroup",
                },
                ddlRewashReason: {
                    required: "Please select Rewash Reason",
                },
                ddlFormula: {
                    required: "Please select Formula",
                },
                txtLastValue: {
                    required: "*",
                    regex: "*"
                },
                txtNewValue: {
                    regex: "*"
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parents('div').first().find("span.errorMsg"));
                if (element.hasClass('recordingValue')) {
                    error.appendTo(element.parent().next('span.errorMsg'));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select") || element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().next("span.errorMsg"));
                }
            }
        });

        var v2 = container.find('#frmManualRewash').valid();
        return v2;
    },

    onDeleteClicked: function () {
        this.clearMessage();
        if (this.options.eventHandlers.onDeleteClicked)
            this.options.eventHandlers.onDeleteClicked(this.getIdsToLoadProductData());
    },

    onSaveClicked: function () {
        var _this = this;
        this.clearMessage();
        if (this.options.eventHandlers.onSaveClicked) {
            if (_this.validate() == true) {
                this.options.eventHandlers.onSaveClicked(this.getIdsToLoadProductData());
            }
            else {
                return false;
            }
        }
    },
    onWasherGroupChange: function (groupId) {
        this.clearMessage();
        this.disableButtons();
        var container = $(this.options.containerSelector);
        $(container).find('.ddlFormula').empty();
        container.find('#manualRewashDataContainer').empty();
        // container.find(".ddlFormula").val('');
        container.find(".ddlFormula").next('.holder').html('-- select --');

        if (this.options.eventHandlers.onWasherGroupChange) {
            this.options.eventHandlers.onWasherGroupChange(groupId);
        }
    },
    onFormulaChange: function () {
        this.clearMessage();
        this.disableButtons();
        var container = $(this.options.containerSelector);
        container.find('#manualRewashDataContainer').empty();
        if (container.find(".ddlRewashReason").val() != "" && container.find(".ddlFormula").val() != "") {
            if (this.options.eventHandlers.onWasherOrFormulaChange) {
                this.options.eventHandlers.onWasherOrFormulaChange(this.getIdsToLoadRewashData());
            }
        }
    },

    bindFormulaData: function (data) {
        var container = $(this.options.containerSelector);
        var ddlFormula = $(container).find('.ddlFormula');
        ddlFormula.empty();
        ddlFormula.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlFormula.append('<option value="' + this.ProgramNumber + '">' + this.Description + '</option>');
        });
    },

    disableButtons: function () {
        var container = $(this.options.containerSelector);
        container.find('#btnCancel').attr('disabled', 'disabled');
        container.find('#btnSave').attr('disabled', 'disabled');

    },

    getIdsToLoadRewashData: function () {
        var container = $(this.options.containerSelector);
        var objManualProductionModel = {};
        objManualProductionModel.WasherGroupId = container.find(".ddlWasherGroup").val();
        objManualProductionModel.RewashReasonId = container.find(".ddlRewashReason").val();
        objManualProductionModel.FormulaId = container.find(".ddlFormula").val();

        return objManualProductionModel;
    },
    getIdsToLoadProductData: function () {
        var container = $(this.options.containerSelector);
        var ManualRewashViewModel = {};
        var Rewash = [];
        for (var i = 0; i < container.find("tr.recording").length ; i++) {
            var ManualRewash = {};
            ManualRewash.WasherGroupId = container.find(".ddlWasherGroup").val();
            ManualRewash.RewashReasonId = container.find(".ddlRewashReason").val();
            ManualRewash.FormulaId = container.find(".ddlFormula").val();
            ManualRewash.RecordedDate = container.find(".recordingDate")[i].value;
            ManualRewash.Value = container.find(".recordingValue")[i].value;
            ManualRewash.id = container.find("tr.recording")[i].attributes["data-id"].value;
            Rewash.push(ManualRewash);
        }
        ManualRewashViewModel.Rewash = Rewash;
        return ManualRewashViewModel;
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('.divErrorMsg').html('');
    },

    cancelClicked: function () {
        var retVal = this.options.eventHandlers.onRedirection('/ManualRewash');
        return retVal;
    },
}