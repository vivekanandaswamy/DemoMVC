Ecolab.Model.LaborCostModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onLaborCostDataLoaded: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.LaborCostModelProxy = new Ecolab.Model.LaborCostModelProxy();
};

Ecolab.Model.LaborCostModel.prototype = {
    init: function () {
    },
    loadLaborCostData: function (callBackData) {
        var _this = this;
        this.LaborCostModelProxy.loadLaborCostData(function (positionData) {
            _this.settings.eventHandlers.onLaborCostDataLoaded(positionData, callBackData);
        });
    },
    updateLaborCostData: function (laborCostViewModel) {
        var _this = this;
        this.LaborCostModelProxy.updateLaborCostData(laborCostViewModel, function (data) {
            _this.settings.eventHandlers.onLaborCostDataUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onLaborCostDataUpdationFailed(error, description); });
    }
};

