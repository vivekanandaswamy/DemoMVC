﻿Ecolab.Views.Default = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onPortletConfigureClicked: null,
            renderChart: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.totalPortlets = [];

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/Default/Default.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.Default.prototype = {
    setData: function (data) {
        var _this = this;
        var year=new Date().getFullYear();
        var month = new Date().getMonthName();
        _this.totalPortlets = [];
        $.each(data.Portlets, function (index, value) {
            this.Year = year;
            this.Month = month;
            if (this.IsEnabled) {
                _this.totalPortlets.push(index);
            }
        })
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.options != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.options.selectedMenuItem).addClass('active');

        //container.find('.btnSave').die('click');
        container.find('.btnSave').click(function () {
            _this.onRuleClicked($(this).parent().attr('ruleId'));
        });

        //container.find('.configure').die('click');
        container.find('.configure').click(function () {
            _this.onPortletConfigureClicked();
        });
        $.each(container.find('.chart'), function (index, value) {
            _this.renderChart($(this).attr('attr-ReportId'));
        });

        var portletsLength = _this.totalPortlets.length;
        var chartHt = $(window).height() - $("#topnav").height() - $(".plant-details").height() - $(".page-title").height() - $("#footerContainer").height() - 130;

        if (portletsLength == 1) {
            $(".chartmaindiv").parent().removeAttr("class").addClass("col-xs-12");
            $(".landing-portlets .chart").css("height", chartHt);
        }
        if ($(window).width() < 1050) {
            if (portletsLength >= 3) {
                $(".landing-portlets .chart").css("height", chartHt / 1.8);
            }
        }
        if ($(window).width() < 1200) {
            if (portletsLength >= 3) {
                $(".landing-portlets .chart").css("height", chartHt / 2 - 20);
            }
        }
        if ($(window).width() > 1250 && $(window).width() <= 1280) {
            if (portletsLength == 2) {
                $(".landing-portlets .chart").css("height", chartHt / 2 + 90);
            }
            if (portletsLength >= 3) {
                chartHt = chartHt / 1.8
                $(".landing-portlets .chart").css("height", chartHt);
            }
        }
        else if ($(window).width() > 1250) {
            if (portletsLength == 2) {
                $(".landing-portlets .chart").css("height", chartHt / 2 + 90);
            }
            if (portletsLength == 3) {
                $(".chartmaindiv").parent().removeAttr("class").addClass("col-xs-4");
                $(".landing-portlets .chart").css("height", chartHt / 2 + 60);
            }
            if (portletsLength > 3) {
                $(".chartmaindiv").parent().removeAttr("class").addClass("col-xs-6");
                chartHt = chartHt / 1.5
                $(".landing-portlets .chart").css("height", chartHt);
            }
        }
        if ($(window).width() > 1400) {
            if (portletsLength == 3) {
                $(".chartmaindiv").parent().removeAttr("class").addClass("col-xs-4");
                $(".landing-portlets .chart").css("height", chartHt / 2);
            }
        }
    },

    onRuleClicked: function (id, linkTo) {
        if (this.options.eventHandlers.onRuleClicked)
            this.options.eventHandlers.onRuleClicked(id, linkTo);
    },
    onPortletConfigureClicked: function () {
        if (this.options.eventHandlers.onPortletConfigureClicked)
            this.options.eventHandlers.onPortletConfigureClicked();
    },
    renderChart: function (id) {
        if (this.options.eventHandlers.renderChart)
            this.options.eventHandlers.renderChart(id);
    },
    chartDataRendered: function (id, details) {
        var _this = this;

        var details = details.toString();
        details = details.replace(/chartdiv/g, "chart_" + id);
        details = details.replace(/marginRight/, "margin");
        details = details.replace(/250/, "[20,180,40,90]");
        //details = details.replace(/enabled:true/, "enabled:false");
        details = details.replace(/pointer/g, "default");
        var container = $(this.options.containerSelector);
        container.find('#chart_' + id).html(details);
        //container.find('#chart_' + id).find('.highcharts-legend').hide();
        $('svg').off();
        if (_this.options.maxLevel > 4) {
            $('svg').on('click', function () {
               // _this.redirectToChart($(this).parents('.chart').attr('attr-reportid'));
            });
            $('.chart-detailedview').on('click', function () {
                _this.redirectToChart($(this).attr('attr-reportid'));
            });
        }
        else {
            $('svg').on('click', function () {
                return false;
            });
        }
        onChartClick = function (e) {
            return true;
        };
        onPieChartClick = function (e) {
            return true;
        };
        $('svg').css('cursor', 'auto');
        $('#dummy_' + id).html(details);
        var title = $('#dummy_' + id).find('#title').html();
        title = title.replace(/"/g, "");
        $('#title_' + id).html(title);
        container.find('.highcharts-title').hide();
    },

    redirectToChart: function (id) {
        window.location = '/Report/Index/' + id;
    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "101":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "301":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEDSUCCESS', 'Deleted successfully') + '</label>';
                break;
            case "401":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEFAILED', 'Deletion failed') + '</label>';
                break;
            case "501":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('#userErrorMsg');
        messageDiv.html(errLabel);
    },
    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('.userErrorMsg').html('');
    },
};