// JavaScript source code
Ecolab.Views.MyProfile = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onAddMyProfileClicked: null,
            onSaveClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/MyProfile/MyProfile.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.MyProfile.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find("#ddlTitle option:contains(" + this.data.UserManagement.Title + ")").attr('selected', 'selected');
        this.attachEvents();
        //if (this.options.eventHandlers.rendered)
        //    _this.options.eventHandlers.rendered();
    },
    attachEvents: function () {
        var _this = this;
        if (_this.data != null)
            $('.navbar-right').find('.' + _this.options.accountInfo.SelectedMenuItem).addClass('active');
        var container = $(this.options.containerSelector);

        container.find("#lnkChangePwd").click(function () {
            _this.onChangePasswordClicked();
        });

        container.find("#btnSave").click(function () {
            _this.onSaveClicked();
        });

        $(".custom-select").each(function () {
            $(this).wrap("<span class='select-wrapper'></span>");
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });

        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });

        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });

        $(".trackChange").on("keydown change click", function () {
            $(".buttonTrack").prop('disabled', false);
            $('#btnCancel').prop('disabled', false);
        });

        container.find('#btnCancel').click(function () {
            _this.CancelClicked();
        });
    },

    CancelClicked: function () {
        var retVal = this.options.eventHandlers.onRedirection('/MyProfile');
        return retVal;
    },

    validateMyProfile: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmMyProfile').validate({
            rules: {
                txtFirstName: {
                    required: true,
                },
                txtLastName: {
                    required: true,
                },
                ddlLanguages: {
                    required: true,
                },
            },
            messages: {
                txtFirstName: {
                    required: "Please enter first name"
                },
                txtLastName: {
                    required: "Please enter last name"
                },
                ddlLanguages: {
                    required: "Please select language"
                },
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                if (element.hasClass('ddlLanguages')) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                else {
                    element.parent().find("span.k-error-message").text = '';
                    error.appendTo(element.parent().find("span.k-error-message"));
                }
            }
        });

        var v2 = container.find('#frmMyProfile').valid();
        return v2;
    },
    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "201":
                errLabel = '<label class="k-success-message" data-localize ="FIELD_SAVEDSUCCESS">Saved successfully</label>';
                break;
            case "501":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('.divErrorMsg');
        messageDiv.html(errLabel);
    },

    onChangePasswordClicked: function () {
        this.clearMessage()
        if (this.options.eventHandlers.onChangePasswordClicked)
            this.options.eventHandlers.onChangePasswordClicked(this.getPopupData());
    },

    onSaveClicked: function () {
        this.clearMessage();
        if (this.options.eventHandlers.onSaveClicked)
            if (this.validateMyProfile()) {
                this.options.eventHandlers.onSaveClicked(this.getProfileData());
            }
            else {
                return false;
            }
    },

    getProfileData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            Title: container.find("#ddlTitle  option:selected").text().trim(),
            FirstName: container.find("#txtFirstName").val(),
            LastName: container.find("#txtLastName").val(),
            RoleName: container.find("#lblUserProfile").text(),
            LanguageId: container.find("#ddlLanguages").val(),
            LanguageName: $("#ddlLanguages option:selected").text().trim(),
            Email: container.find("#txtEmail").val(),
            ContactNo: container.find("#txtOfficePhone").val(),
            Mobile: container.find("#txMobilePhone").val(),
            Fax: container.find("#txtFaxNo").val(),

        };
    },

    getPopupData: function () {
        return {
            Password: this.data.UserManagement.Password,
        }
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('.divErrorMsg').html('');
    },

}