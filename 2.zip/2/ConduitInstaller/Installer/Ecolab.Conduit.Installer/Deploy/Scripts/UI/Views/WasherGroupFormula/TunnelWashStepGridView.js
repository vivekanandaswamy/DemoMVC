Ecolab.Views.TunnelWashStepGridView = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { }
        },
        accountInfo: null
    };

    this.productData = null;
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'TunnelWashStepGridView',
        templateUri: '/Scripts/UI/Views/WasherGroupFormula/TunnelWashStepGridView.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });

};

Ecolab.Views.TunnelWashStepGridView.prototype = {
    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".k-tooltip").parent(".k-animation-container").hide();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            $(this).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });

        $("body").css("overflow-x", "hidden");

        equalHeight($(".eq_height"));

        $(function () {
            var $table = $('.addformula-group');
            //Make a clone of our table
            var $fixedColumn = $table.clone().insertBefore($table).addClass('fixed-column').removeAttr("id");
            //Remove everything except for first column
            $fixedColumn.find('th:not(:first-child),td:not(:first-child)').remove();

            //Match the height of the rows to that of the original table's
            $fixedColumn.find('tbody tr tr').each(function (i, elem) {
                $(this).height($("#TunnelDataTable_1").find('tr:eq(' + i + ')').height());
            });

            $("#tunneltable #labelTable").find('tr').each(function (i, elem) {
                $(this).height($("#TunnelDataTable_1").find('tr:eq(' + i + ')').height());
            });

            $("#tunneltable #labelTable").width($fixedColumn.width());
        });
        $('.washOperation').trigger('change');
        if (this.options.eventHandlers.madeChangeFalse) {
            this.options.eventHandlers.madeChangeFalse();

        }
        $(".RequiredRunTimeValidation").mask("00:00");
        $(".buttonTrack").attr("disabled", "disabled");
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find("#back").click(function () {
            _this.clearStatusMessage();
            _this.onBackToFormulasClicked("Back");
        });
        container.find("#btnSaveWashStep").click(function () {
            _this.clearStatusMessage();
            if (_this.validateWasherStep()) {
                _this.saveTunnelWashStepGrid();
            }
        });
        container.find("#btnCancel").click(function () {
            _this.clearStatusMessage();
            _this.onCancelclicked();
        });
        container.find("#lnkFormView").click(function () {
            _this.clearStatusMessage();
            _this.swapView();
        });
        container.find(".washOperation").change(function () {
            _this.clearStatusMessage();
            var Id = $(this).attr('wgddlid');
            if ($('#ddlWashOperation_' + Id + ' option:not(.empty):selected').text() == "Drain") {
                $('#ddlWaterTypes_' + Id).attr("disabled", "disabled");
                $('#ddlWaterTypes_' + Id).addClass("disabled");
                $('#ddlWaterTypes_' + Id).parent(".select-wrapper").addClass("disabled");
                $('#ulProductsList_'+Id).hide();
            }
            else {
                $('#ddlWaterTypes_' + Id).removeAttr("disabled");
                $('#ddlWaterTypes_' + Id).removeClass("disabled");
                $('#ddlWaterTypes_' + Id).parent(".select-wrapper").removeClass("disabled");
                $('#ulProductsList_'+Id).show();
            }
        });

        //Print Button
        container.find('#btnFormulaWashStepPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.options.accountInfo.EcolabAccountNumber,
                WasherGroupId: _this.options.accountInfo.WasherGroupId,
                PageTitle: "Tunnel Compartment List",
                ProgramSetupId: _this.data.WasherGroupFormulaDetails[0].Id,
                CompartmentNumber: 1 ,
                RegionId: _this.data.accountInfo.RegionId,
                NumberOfCompartments: _this.options.accountInfo.Compartments == null ? 0 : _this.options.accountInfo.NoofCompartments
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });

        container.find(".viewChange").click(function () {
            _this.clearStatusMessage();
            var dosingId = $(this).attr("dosingid");
            var compNo = $(this).attr("compartmentnumber");
            _this.getProductsList(dosingId, compNo);
        });
        container.find(".madeChange").change(function () {
            _this.onValueChange();
           //

        });
        container.find("#btnCancel").click(function () {
            _this.clearStatusMessage();
        });

    },
    onValueChange: function () {
        if (this.options.eventHandlers.onValueChange)
            this.options.eventHandlers.onValueChange();
    },
    onBackToFormulasClicked: function (redirect) {
        if (this.options.eventHandlers.onFormulaTabClick) {
            this.options.eventHandlers.onFormulaTabClick(redirect);
        }
    },
    getTunnelWashStepGridData: function () {
        var container = $(this.options.containerSelector);
        var compartmentLengths = $("table[id*=TunnelDataTable]").length;

        var mainTable = $("#tunneltable tbody");

        var tablearr = [];
        var productsList = [];
        var formulaId = this.data.WasherGroupFormulaDetails[0].Id;
        var groupId = this.data.WasherGroupDetails[0].WasherGroupId;
        var _this = this;
        var RunTime = 0;
        for (var i = 1; i <= compartmentLengths; i++) {
            var loopTableBody = $("#TunnelDataTable_" + i + " tbody");
            var trLength = loopTableBody.find('tr').length;
            CompartmentNo = 'Compartment' + i;
            var trCount = 0;
            var Id = this.data.TunnelWashStepsModel[i - 1].Id;
            loopTableBody.find('tr').each(function (c, el) {
                var $tds = $(this).find('td');

                switch (c) {
                    case 0:
                        WashOperation = $tds.eq(0).find('.washOperation option:selected').val();
                        break;
                    case 1:
                        Temperature = $tds.eq(0).find('input[type=text]').val();
                        break;
                    case 2:
                        WaterInletDrain = $tds.eq(0).find('.select-wrapper .inletDrain option:selected').val();
                        break;
                    case 3:
                        WaterType = $tds.eq(0).find('.select-wrapper .waterType option:selected').val();
                        break;
                    case 4:
                        WaterLevel = $tds.eq(0).find('input[type=text]').val();
                        break;
                    case 5:
                        RunTime = $tds.eq(0).find('input[type=text]').val();
                        var runtime = RunTime;
                        var times = []; var minutes = 0; var seconds = 0; var runTimeFormat = 0;
                        times = runtime.split(':');
                        minutes = parseInt(times[0] * 60);
                        seconds = parseInt(times[1]);
                        runTimeFormat = minutes + seconds;
                        RunTime = runTimeFormat;
                        break;
                    case 6:
                        Product = 2;
                        break;
                    case 7:
                        Note = $tds.eq(0).find('textarea').val();
                        break;
                }
                if (c == trLength - 1) {
                    tablearr.push({
                        CompartmentNumber: CompartmentNo,
                        TunnelDosingSetupId: Id,
                        TunnelProgramSetupId: formulaId,
                        GroupId: groupId,
                        StepTypeId: WashOperation,
                        Temperature: Temperature,
                        WaterInletDrain: WaterInletDrain,
                        WaterType: WaterType,
                        WaterLevel: WaterLevel,
                        StepRunTime: RunTime,
                        Notes: Note,
                        PHLevel: 2,
                        EcolabAccountNumber: 1,//this.options.accountInfo.EcolabAccountNumber,
                        ProductsList: productsList

                    });
                }
            });

        }

        var WasherFormulaTunnelWashGridModel = tablearr;

        return WasherFormulaTunnelWashGridModel;
    },
    saveTunnelWashStepGrid: function (flag) {
        if (this.options.eventHandlers.saveTunnelWashStepGrid)
            this.options.eventHandlers.saveTunnelWashStepGrid(flag);
    },

    validateWasherStep: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $(".tooltip-wanter").tooltip({ selector: ".tooltip-info", placement: "left" });
        var v1 = container.find('#frmTunnelGridView').validate({
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));

                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });

        var v2 = container.find('#frmTunnelGridView').valid();
        return v2;
    },
    onWashStepCreationSuccess: function (data) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_WASHSTEPSSAVEDSUCCESSFULLY", 'WashSteps Saved Successfully'));
    },
    onWashStepCreationFailed: function (exception) {
        $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append($.GetLocaleKeyValue("FIELD_WASHSTEPSSAVEFAILED", 'WashSteps Save Failed'));
    },
    GetNextStep: function () {
        var id = $('#ddlTunnelStep option:selected').next('option').val();
        if (id) {
            this.GetCompartmentDetails(id);
        }
    },
    GetPrevStep: function () {
        var id = $('#ddlTunnelStep option:selected').prev('option').val();
        if (id) {
            this.GetCompartmentDetails(id);
        }
    },
    GetCompartmentDetails: function (compId) {
        if (compId) {
            var washergroupId = this.data.WasherGroupDetails[0].WasherGroupId;
            var formulaId = this.data.WasherGroupFormulaDetails[0].Id;
            if (this.options.eventHandlers.GetCompartmentDetails)
                this.options.eventHandlers.GetCompartmentDetails(formulaId, compId, washergroupId);
        }
    },
    onFormViewClicked: function () {
        if (this.options.eventHandlers.onFormViewClicked)
            this.options.eventHandlers.onFormViewClicked(this.data.WasherGroupFormulaDetails[0].Id);
    },
    onCancelclicked: function () {
        if (this.options.eventHandlers.onCancelclicked)
            this.options.eventHandlers.onCancelclicked('Cancel');
    },
    getProductsList: function (dosingId, compNo) {
        if (this.options.eventHandlers.getProductsList) {
            
            this.options.eventHandlers.getProductsList(this.data.TunnelWashStepsModel[compNo - 1].ProductsList,dosingId);
        }
    },
    swapView: function () {
        if (this.options.eventHandlers.swapView)
            this.options.eventHandlers.swapView();
    },
    clearStatusMessage: function () {
        if (this.options.eventHandlers.clearMessage)
            this.options.eventHandlers.clearMessage();
    },

}
$.validator.addMethod("TempRequiredFields", function (value, element) {
    if (value == '') {
        var ele = element.parentNode.nextElementSibling;
        ele.attributes['title'].value = '';
        ele.attributes['data-original-title'].value = '';
        ele.attributes['data-original-title'].value = 'Required';
        ele.attributes['title'].value = 'Required';
        return false
    } else {
        return true
    }
}, "*");
$.validator.addMethod("TempRequiredFieldsNumber", function (value, element) {
    if (!($.isNumeric(value))) {
        var ele = element.parentNode.nextElementSibling;
        ele.attributes['title'].value = '';
        ele.attributes['data-original-title'].value = '';
        ele.attributes['data-original-title'].value = 'Input digits';
        ele.attributes['title'].value = '';
        return false
    }
    else if (($.isNumeric(value)) && value > 200) {
        var ele = element.parentNode.nextElementSibling;
        ele.attributes['title'].value = '';
        ele.attributes['data-original-title'].value = '';
        ele.attributes['data-original-title'].value = 'Temperature not greater than 200';
        ele.attributes['title'].value = '';
        return false
    }
    else {
        return true
    }
}, "*");
$.validator.addClassRules("TempRequiredFieldValidation", { TempRequiredFields: true, TempRequiredFieldsNumber: true });

$.validator.addMethod("WaterRequiredFields", function (value, element) {
    if (value == '') {
        var ele = element.parentNode.nextElementSibling;
        ele.attributes['title'].value = '';
        ele.attributes['data-original-title'].value = '';
        ele.attributes['data-original-title'].value = 'Required';
        ele.attributes['title'].value = '';
        return false
    } else {
        return true
    }
}, "*");
$.validator.addMethod("WaterRequiredFieldsNumber", function (value, element) {
    if (!($.isNumeric(value))) {
        var ele = element.parentNode.nextElementSibling;
        ele.attributes['title'].value = '';
        ele.attributes['data-original-title'].value = '';
        ele.attributes['data-original-title'].value = 'Input digits';
        ele.attributes['title'].value = '';
        return false
    }
    else {
        return true
    }
}, "*");
$.validator.addClassRules("RequiredWaterLevelValidation", { WaterRequiredFields: true, WaterRequiredFieldsNumber: true });
var timeFormat = /^(?:[0-9]?[0-9]):[0-9]?[0-9]$/;
$.validator.addMethod("RuntimeRequiredFields", function (value, element) {
    if (value == '') {
        var ele = element.parentNode.nextElementSibling;
        ele.attributes['title'].value = '';
        ele.attributes['data-original-title'].value = '';
        ele.attributes['data-original-title'].value = 'Required';
        ele.attributes['title'].value = '';
        return false
    } else {
        return true
    }
}, "*");
$.validator.addMethod("RuntimeRequiredFieldsNumber", function (value, element, regExp) {
    var ele = element.parentNode.nextElementSibling;
    if (value != '') {
        
        var checkRegExp = new RegExp(regExp);
        if (!checkRegExp.test(value)) {
            ele.attributes['title'].value = '';
            ele.attributes['data-original-title'].value = '';
            ele.attributes['data-original-title'].value = 'Enter runtime in mm:ss format';
            ele.attributes['title'].value = '';
            return false;
        }
        else {
            return true;
        }
    }
}, "*");

$.validator.addClassRules("RequiredRunTimeValidation", { RuntimeRequiredFields: true, RuntimeRequiredFieldsNumber: timeFormat, regex: timeFormat });

$.validator.addMethod("WaterTypeRequiredFields", function (value, element) {
    //var id = element.id;
    //id= $('#'+id+' option:selected').text()
    if (value=="") {
        var ele = element.parentNode.nextElementSibling;
        ele.attributes['title'].value = '';
        ele.attributes['data-original-title'].value = '';
        ele.attributes['data-original-title'].value = 'Required';
        ele.attributes['title'].value = '';
        return false
    } else {
        return true
    }
}, "*");
$.validator.addClassRules("waterTypeRequired", { WaterTypeRequiredFields: true });





function equalHeight(group) {
    tallest = 0;
    group.each(function () {
        thisHeight = $(this).height();
        if (thisHeight > tallest) {
            tallest = thisHeight;
        }
    });
    group.height(tallest);
}

