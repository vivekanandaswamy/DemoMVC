﻿Ecolab.Views.MonitorSetup = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onAddMonitorClicked: null,
            onEditClicked: null,
            onDeleteClicked: null
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/MonitorSetup/MonitorSetup.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.MonitorSetup.prototype = {
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        //this.data.DashboardData = data;
        //this.data = data;
        this.tm.Render(data, this);
    },
   
    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        if (message == "301") {
            errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEDSUCCESS', 'Deleted successfully') + '</label>';
        }
        else if (message == "701") {
            container.find("#txtDashboardName").val(container.find("#lblDashboardName").text().trim());
            errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DASHBOARDNAMEALREADYEXISTS', 'Dashboard name already exists') + '</label>';
        }
        else if (message > 0) {
            errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
        }
        else {
            errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
        }
        var messageDiv = $('.divErrorMsg');
        messageDiv.html(errLabel);
    },

    onRendered: function () {
        var _this = this;
        $('.tabMonitorSetup').addClass('active');
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        $('#tblMonitorSetUp').tablesorter({
            headers: {
                0: {
                    sorter: false
                }
            }
        });

    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmMonitorSetup').validate({
            rules: {
                txtDashboardName: {
                    required: function () {
                        if ($('#txtDashboardName').val() == "") {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                },
            },
            messages: {
                txtDashboardName: {
                    required: "*"
                },
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#frmMonitorSetup').valid();
        return v2;
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find("#btnAddMonitor").click(function () {
            _this.clearMessage();
            _this.onAddMonitorClicked();
        });

       // container.find("#updateMonitor").die('click');
        container.find(".updateMonitor").click(function () {
            _this.clearMessage();
            var_this = this;
            var id = $(this).parents('.trEditable').first().attr('data-dashboardid');
            _this.onEditClicked(id);
        });

        //container.find("#deleteMonitor").die('click');
        container.find(".deleteMonitor").click(function () {
            _this.clearMessage();
            var_this = this;
            var id = $(this).parents('.trEditable').first().attr('data-dashboardid');
            _this.onDeleteClicked(id);
        });

        //container.find("#editMonitorInline ").die('click');
        container.find(".editMonitorInline").click(function () {
            _this.clearMessage();
            var tr = $(this).parents('.trEditable').first();
            tr.find(".noneditable").hide();
            tr.find(".editable").show();
        });

        //Event to inline cancel
        container.find(".cancelMonitorInline").click(function () {
            _this.clearMessage();
            $(this).parents('.trEditable').first().removeClass('dirty');
            container.find('span.errorMsg').text("");
            var tr = $(this).parents('.trEditable').first()
            _this.restoreData(tr);
        });

        //Event to check update on inline clicked
        container.find(".updateMonitorInline").click(function () {
            _this.clearMessage();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            if (_this.validate() == true) {
                _this.isDirty = false;
                _this.onUpdateMonitorInlineClicked(_this.getInlineMonitorData($(this), tr));
            } else {
                return false;
            }

        });

       
    },
    getInlineMonitorData: function (e, tr) {
        var lstMonitorSetupModel = [];
        var monitorSetupModel = {};
        monitorSetupModel.IsEdit = true;
        monitorSetupModel.DashboardName = tr.find('#txtDashboardName').val();
        monitorSetupModel.DashboardId = tr.attr('data-dashboardid');
        monitorSetupModel.IsDeleteMapping = false;
        monitorSetupModel.Customer = tr.find('#cbCustomer').is(':checked');
        monitorSetupModel.Formula = tr.find('#cbFormula').is(':checked');
        monitorSetupModel.Load = tr.find('#cbLoad').is(':checked');
        monitorSetupModel.DisplayOnLogin = tr.find('#cbDisplayonLogin').is(':checked');
        lstMonitorSetupModel.push(monitorSetupModel);
        return lstMonitorSetupModel;
    },

    restoreData: function (tr) {
        $(tr).find("#txtDashboardName").val($(tr).find("#lblDashboardName").text().trim());
        $(tr).find("#cbCustomer").attr('checked', $(tr).find("#cbCustomer_NE").is(':checked'));
        $(tr).find("#cbFormula").attr('checked', $(tr).find("#cbFormula_NE").is(':checked'));
        $(tr).find("#cbLoad").attr('checked', $(tr).find("#cbLoad_NE").is(':checked'));
        $(tr).find("#cbDisplayonLogin").attr('checked', $(tr).find("#cbDisplayonLogin_NE").is(':checked'));
    },

    onAddMonitorClicked: function () {
        if (this.options.eventHandlers.onAddMonitorClicked)
            this.options.eventHandlers.onAddMonitorClicked();
    },

    onEditClicked: function (id) {
        if (this.options.eventHandlers.onEditClicked)
            this.options.eventHandlers.onEditClicked(id);
    },

    onDeleteClicked: function (id) {
        if (this.options.eventHandlers.onDeleteClicked)
            this.options.eventHandlers.onDeleteClicked(id);
    },

    onUpdateMonitorInlineClicked: function (data) {
        if (this.options.eventHandlers.onUpdateMonitorInlineClicked)
            this.options.eventHandlers.onUpdateMonitorInlineClicked(data);
    },


    clearMessage: function () {
        var container = $(this.options.containerSelector);
        $('.divErrorMsg').html('');
        container.find(".noneditable").show();
        container.find(".editable").hide();
    },

  
}