﻿Ecolab.Views.Formula = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null
        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Formula/Formula.html',
        paraFormula: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.positionData = null;
    this.allowEdit = false;

    this.tmEdit = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Formula/Formula.html',
        paraFormula: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.FormulaData = null;
};

Ecolab.Views.Formula.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },
    setFormulaData: function (data) {
        var _this = this;
        this.FormulaData = data;
    },


    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {

        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span').addClass('k-icon k-addbtn');
    },

    initValidator: function () {
        $.validator.addMethod(
                "regex",
                function (value, element, regexp) {
                    var check = false;
                    var re = new RegExp(regexp);
                    return this.optional(element) || re.test(value);
                },
                $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS','Enter only numerics')
        );
    },

    validate: function () {
        this.resetErrors();
        var pattern1 = /^[0-9]*$/;
        var v1 = $('#frmFormula').validate({
            rules: {
                txtFormulaName:
                    {
                        required: true
                    },
                txtcopyFormulaName: {
                    required: true
                },
                txtNumberofweightedPieces: {
                    required: true,
                    regex: pattern1
                },
                txtWeight: {
                    required: true,
                    regex: pattern1
                },
                ddlEcolabTextileCategoryAdd: {
                    required: true,
                },
                ddlEcolabSaturationAdd: {
                    required: true,
                },
                ddlChainFormulaAdd: {
                    required: true,
                },
                ddlChainTextileCategoryAdd: {
                    required: true,
                }
            },

            messages: {
                txtFormulaName: {
                    required: $.GetLocaleKeyValue('FIELD_FORMULANAMEREQUIRED','Formula name required')
                },
                txtcopyFormulaName: {
                    required: $.GetLocaleKeyValue('FIELD_FORMULANAMEREQUIRED', 'Formula name required')
                },
                ddlEcolabTextileCategoryAdd: {
                    required: $.GetLocaleKeyValue('FIELD_ECOLABTEXTILEREQUIRED','Ecolab Textile required')
                },
                ddlEcolabSaturationAdd: {
                    required: $.GetLocaleKeyValue('FIELD_ECOLABSATURATIONREQUIRED','Ecolab Saturation required')
                },
                ddlChainFormulaAdd: {
                    required: $.GetLocaleKeyValue('FIELD_CHAINFORMULAREQUIRED','Chain Formula required')
                },
                ddlChainTextileCategoryAdd: {
                    required: $.GetLocaleKeyValue('FIELD_CHAINTEXTILEREQUIRED','Chain Textile required')
                },
                txtNumberofweightedPieces: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERONLYNUMBERS','Please enter only numbers'),
                    regex: $.GetLocaleKeyValue('FIELD_INVALIDVALUESENTERONLYNUMBERS','Invalid values , Enter only numbers')
                },
                txtWeight: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERONLYNUMBERS', 'Please enter only numbers'),
                    regex: $.GetLocaleKeyValue('FIELD_INVALIDVALUESENTERONLYNUMBERS', 'Invalid values , Enter only numbers')
                },
                onsubmit: true,
                onkeyup: false,
                focusInvalid: false,
                errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.errorMsg"));
                }
            }
        });
        var v2 = $('#frmFormula').valid();
        return v2;
    },

    setPositionData: function (data) {
        var _this = this;
        this.positionData = data;
    },

    setFormulaOnAddNewPopupLoadData: function (data) {
        var _this = this;
        this.FormulaData = data;
    },

    attachEvents: function () {
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel > 5);
        $("#frmFormula").kendoValidator();
        var wnd, detailsTemplate;
        var trIndex = null;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');

        var dataSrc = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/PlantFormula/GetFormula",
                    dataType: "json",
                },

                update: {
                    url: "/api/PlantFormula/Put",
                    dataType: "json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append('Formula Updated Successfully');
                            //grid.dataSource._destroyed = [];
                            //grid.dataSource.read();
                            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                            var grid = $("#gridFormula").data("kendoGrid");
                            grid.dataSource._destroyed = [];
                            //dataSource.cancelChanges();
                            grid.dataSource.read();
                            wnd.close();
                        }
                        else {
                            //alert(JSON.parse(jqXhr.responseText));
                            alert($.GetLocaleKeyValue("FIELD_FORMULANAMEALREADYEXISTS", "Formula Name Already Exists"));
                            //$("#errorDiv").empty().removeClass().append(JSON.parse(jqXhr.responseText));
                        }
                    }
                },
                destroy: {
                    url: "/api/PlantFormula/DeleteFormula",
                    dataType: "json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_FORMULADELETEDSUCCESSFULLY", 'Formula Deleted Sucessfully'));
                        }
                        else {
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_FORMULADELETEDSUCCESSFULLY", 'Formula Deleted Sucessfully'));
                        }
                    }
                },
            },

            error: function (e) {
                if (($('.k-edit-form-container').find('div.k-edit-buttons.k-state-default'))) {
                    var error = '<div class= "errorMessageModal"><label>' + $.parseJSON(e.xhr.responseText) + '</label></div>';
                    var buttons = $('.k-edit-form-container').find('div.k-edit-buttons.k-state-default');
                    $('.k-edit-form-container').find('.errorMessageModal').remove();
                    buttons.before(error);
                } else {
                    $("#TmContactStatus").empty().removeClass().addClass('errorMessage').append('<label>' + e.xhr.responseText + '</label>');
                }
            },
            pageSize: 12,
            schema: {
                data: function (data) {
                    return data.Items;
                },
                total: function (data) {
                    return data.TotalCount;
                },
                model: {
                    id: "ProgramId",
                    fields: {
                        ProgramId: { editable: false, type: "number", nullable: false },
                        Name: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_FORMULANAMEREQUIRED", "Formula name required") } },
                        CategoryName: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_CATEGORYNAMEREQUIRED", "Category name required") } },
                        EcolabSaturationName: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_SATURATIONNAMEREQUIRED", "Saturation name required") } },
                        PlantProgramName: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_PLANTPROGRAMNAMEREQUIRED", "Plant Program name required") } },
                        ChainTextileCategory: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_CHAINPLANTTEXTIELCATEGORYNAMEREQUIRED", "Chain Plant Textile Category name required") } },
                        Rewash: { editable: true, type: "boolean" },
                        Pieces: {
                            editable: true,
                            validation: {
                                min: "1",
                                onlyDigits: function (input) {
                                    if (input.is("[name='Pieces']")) {
                                        input.attr("data-onlyDigits-msg", $.GetLocaleKeyValue("FIELD_PIECESISNOTVALID", "Pieces is not valid"));
                                        var pattern = new RegExp("^[0-9]+$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        }
                                        else {
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            },
                            validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_PIECESREQUIRED", "Pieces required") }
                        },
                        Weight: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_WEIGHTREQUIRED", "Weight required") } },
                        PieceWeight: { editable: false }
                    }
                }
            },
            serverPaging: true,
        });

        //Set basing on roles Here
        var addNew, commands, editTitle, customWidth = "135px";
        if (_this.allowEdit) {
            _this.isView = false;
            commands = [
                { name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit },
                { name: "destroy", text: " " },
                { name: "update", text: " ", click: showDetails },
                { name: 'copy', text: "", click: copyRecord }
            ];
            
            addNew = [{ text: $.GetLocaleKeyValue('FIELD_ADDFORMULA' , 'Add Formula') , className: "btn btn-sm btn-primary grid-add-new-record" }];
            editTitle = $.GetLocaleKeyValue("FIELD_EDITFORMULA", 'Edit Formula');
        } else {
            _this.isView = true;
            commands = [{ name: "view", text: " ", click: showDetails }];
            addNew = "";
            customWidth = "55px";
            editTitle = "View Customer";
        }

        function onDataBound(arg) {
            $('.k-button-icontext.k-grid-copy').find('span').addClass('k-icon k-custom-copy');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
        }

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
        //  alert(this.data.accountInfo.RegionId);
        if (container.find('#gridFormula').data().kendoGrid)
            container.find('#gridFormula').data().kendoGrid.destroy();
        var weightForRegion = regionWeight();
        container.find("#gridFormula").kendoGrid({
            dataSource: dataSrc,
            pageable: true,
            sortable: true,

            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                  { command: commands, width: "98px", attributes: { "class": "align-center" } },
                { field: "Name", title: "Name", headerAttributes: { "data-localize": "FIELD_FORMULANAME" }, width: "15%" },
                { field: "EcolabSaturationName", title: "Textile Saturation", headerAttributes: { "data-localize": "FIELD_ECOLABSATURATION" }, editor: saturationDropDownEditor, width: "14%" },
                { field: "ChainTextileCategory", title: "Textile Category", headerAttributes: { "data-localize": "FIELD_TEXTILECATEGORY" }, editor: chainTextileDropDownEditor, width: "16%" },
                { field: "CategoryName", title: "Textile Category Ecolab", headerAttributes: { "data-localize": "FIELD_TEXTILECATEGORYECOLAB" }, editor: categoryDropDownEditor, width: "16%" },
                { field: "Rewash", title: "Rewash Formula", headerAttributes: { "data-localize": "FIELD_REWASHFORMULA" }, width: "12%" },
                { field: "PieceWeight", title: "Piece per("+weightForRegion+")", headerAttributes: { "data-localize": "FIELD_PIECEWEIGHT"+"("+weightForRegion+")", "class": "align-right" }, attributes: { "class": "align-right" }, width: "10%" }

            ],
            // toolbar: kendo.template($("#TmNewFormula").html()),
            editable: "inline",


            cancel: function (e) {
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                //dataSource.cancelChanges();
                grid.dataSource.read();
            },
            
        });

        function regionWeight() {
            var wght;
            if (_this.data.accountInfo.RegionId == 2)
            { wght = "Kgs" }
            else
            { wght = "Lbs" }
            return wght;
        }
        function onEdit() { clearStatusMessage(); }
        wnd = $("#details")
                       .kendoWindow({
                           title: $.GetLocaleKeyValue("FIELD_EDITFORMULA", "Edit Formula"),
                           modal: true,
                           visible: false,
                           resizable: false,
                           width: "373px",
                           height: "auto",
                           open: function () {
                               $('#spnWeightEdit').text('(' + _this.FormulaData.units[0].UsageKey + ')');

                               $('#spnPieceWeightEdit').text('(' + _this.FormulaData.units[0].UsageKey + ')');
                             
                               $("#cbRewash").kendoMobileSwitch({
                                   onLabel: "YES",
                                   offLabel: "NO",
                                   change: function (e) {
                                       enable();
                                   }
                               });
                               $('select').kendoDropDownList();
                               editCalPieceWeight();
                           }
                       }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editFormula").html());


        function showDetails(e) {
            clearStatusMessage();
            e.preventDefault();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            dataItem.FormulaDataToLoadDropdown = _this.FormulaData;
            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator")
            var popupContainer = $(this).closest('#details-container');
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSrc.fetch(function () {
                    var formula = dataSrc.get(uid);
                    formula.set("Name", popupContainer.find("#txtFormulaName").val());
                    formula.set("TextileId", popupContainer.find("#ddlEcolabTextileCategory").val());
                    formula.set("CategoryName", popupContainer.find("#ddlEcolabTextileCategory option:selected").text());
                    formula.set("EcolabSaturationId", popupContainer.find("#ddlEcolabSaturation").val());
                    formula.set("EcolabSaturationName", popupContainer.find("#ddlEcolabSaturation option:selected").text());
                    formula.set("PlantProgramId", popupContainer.find("#ddlChainFormula").val());
                    formula.set("PlantProgramName", popupContainer.find("#ddlChainFormula option:selected").text());
                    formula.set("ChainTextileId", popupContainer.find("#ddlChainTextileCategory").val());
                    formula.set("ChainTextileCategory", popupContainer.find("#ddlChainTextileCategory option:selected").text());
                    formula.set("Rewash", popupContainer.find("#cbRewash").is(":checked"));
                    formula.set("Pieces", popupContainer.find("#txtNumberofweightedPieces").val());
                    formula.set("Weight", popupContainer.find("#txtWeight").val());
                    formula.set("PieceWeight", popupContainer.find("#txtPieceWeight").val());
                    formula.set("CustomerId", popupContainer.find("#ddlCustomer option:selected").val());
                    dataSrc.sync();
                });

                var grid = $("#gridFormula").data("kendoGrid");
                grid.saveChanges();
                grid.dataSource.read();
                //wnd.close();

                //$("#errorDiv").empty().removeClass().addClass('k-success-message').append('Formula Updated Successfully');

            }
            else {
                return false;
            }
        });

        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
            var grid = $("#gridFormula").data("kendoGrid");
            grid.dataSource._destroyed = [];
            //dataSource.cancelChanges();
            grid.dataSource.read();
        });

        var grid;
        $("#gridFormula a.grid-add-new-record").unbind("click");
        $("#gridFormula a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();

            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
            var window = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                    title: $.GetLocaleKeyValue("FIELD_ADDFORMULA", "Add Formula"),
                    modal: true,
                    width: "373px",
                    height: "auto",
                    visible: false, /*don't show it yet*/
                    open: onAddNewOpen,
                    close: onClose,
                    content: {
                        //sets window template
                        template: kendo.template($("#newFormula").html())
                    }
                })
                .data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }

            function onClose(e) {
                dataSource.cancelChanges(); //cancel changes
                window.element.remove();
            }

            function onAddNewOpen(e) {
                var ddlEcolabTextileCategoryAdd = $('#ddlEcolabTextileCategoryAdd');
                ddlEcolabTextileCategoryAdd.empty();
                ddlEcolabTextileCategoryAdd.append('<option value="">Select</option>');
                $.each(_this.FormulaData.ecolabTextileCategory, function () {
                    ddlEcolabTextileCategoryAdd.append('<option value="' + this.TextileId + '">' + this.CategoryName + '</option>');
                });

                $('#spnWeightAdd').text('(' + _this.FormulaData.units[0].UsageKey + ')');

                $('#spnPieceWeightAdd').text('(' + _this.FormulaData.units[0].UsageKey + ')');

                var ddlEcolabSaturationAdd = $('#ddlEcolabSaturationAdd');
                ddlEcolabSaturationAdd.empty();
                ddlEcolabSaturationAdd.append('<option value="">Select</option>');
                $.each(_this.FormulaData.ecolabSaturation, function () {
                    ddlEcolabSaturationAdd.append('<option value="' + this.EcolabSaturationId + '">' + this.EcolabSaturationName + '</option>');
                });

                var ddlChainFormulaAdd = $('#ddlChainFormulaAdd');
                ddlChainFormulaAdd.empty();
                ddlChainFormulaAdd.append('<option value="">Select</option>');
                $.each(_this.FormulaData.plantChainProgram, function () { 
                    ddlChainFormulaAdd.append('<option value="' + this.PlantProgramId + '">' +this.PlantProgramName + '</option>');
                });
                

                var ddlChainTextileCategoryAdd = $('#ddlChainTextileCategoryAdd');
                ddlChainTextileCategoryAdd.empty();
                ddlChainTextileCategoryAdd.append('<option value="">Select</option>');
                $.each(_this.FormulaData.chainTextileCategory, function () {
                    ddlChainTextileCategoryAdd.append('<option value="' +this.TextileId + '">' +this.Name + '</option>');
                });

                var ddlCustomer = $("#ddlCustomerAdd");
                ddlCustomer.empty();
                ddlCustomer.append('<option value="-1">All</option>');
                $.each(_this.FormulaData.CustomerList, function () {
                    ddlCustomer.append('<option value="' + this.CustomerId + '">' + this.CustomerName + '</option>');
                });

                $("#chkRewashFormulaAdd").kendoMobileSwitch({
                    onLabel: "YES", offLabel: "NO", change: function (e) {
                        enable1();
                    }
                });
                $('select').kendoDropDownList();
                calPieceWeightforAdd();

            }
            dataSource.sync();
            grid = $("#gridFormula").data("kendoGrid");
            grid.saveChanges()
            wnd.close();
            //wnd.destroy();
            grid.dataSource._destroyed = [];
            grid.dataSource.read();

            detailsTemplate1 = kendo.template($("#newFormula").html());
            window.content();
            $(".cancelAddRowPopup, .k-window-action .k-icon .k-i-close").unbind("click");
            $(document).on("click", ".cancelAddRowPopup, .k-icon .k-i-close", function () {
                window.destroy();
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                //dataSource.cancelChanges();
                grid.dataSource.read();
            });

            //binds the editing window to the form
            kendo.bind(window.element);

            //determines at what position to insert the record (needed for pageable grids)

            //initialize the validator
            var validator = $(window.element).kendoValidator().data("kendoValidator");
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function (e) {
                if (validator.validate() == true) {
                    dataSource._data = [];
                    var popupContainer = $(this).closest('#details-container');
                    var ddlEcolabTextileCategoryAdd = popupContainer.find("#ddlEcolabTextileCategoryAdd").val().trim();
                    var ddlEcolabSaturationAdd = popupContainer.find("#ddlEcolabSaturationAdd").val().trim();
                    var ddlChainFormulaAdd = popupContainer.find("#ddlChainFormulaAdd").val().trim();
                    var ddlChainTextileCategoryAdd = popupContainer.find("#ddlChainTextileCategoryAdd").val().trim();
                    var txtFormulaName = popupContainer.find("#txtFormulaNameAdd").val().trim();
                    var txtRewashFormula = popupContainer.find("#chkRewashFormulaAdd").is(":checked");
                    var txtNumberofweightedPieces = popupContainer.find("#txtaddNumberofweightedPiecesAdd").val().trim();
                    var txtWeight = popupContainer.find("#txtaddWeight").val().trim();
                    var txtPieceWeight = popupContainer.find("#txtPieceWeightAdd").val().trim();

                    dataSource._data.push({
                        TextileId: ddlEcolabTextileCategoryAdd,
                        EcolabSaturationId : ddlEcolabSaturationAdd,
                        PlantProgramId: ddlChainFormulaAdd,
                        ChainTextileId : ddlChainTextileCategoryAdd,
                        Name : txtFormulaName,
                        ProgramId : 0,
                        Rewash : txtRewashFormula,
                        Pieces : txtNumberofweightedPieces,
                        Weight : txtWeight,
                        PieceWeight : txtPieceWeight,
                        CustomerId : $("#ddlCustomerAdd option:selected").val(),
                });
                   // dataSource.sync(); //sync changes
                    var grid = $("#gridFormula").data("kendoGrid");
                    $.ajax({
                        type: "POST",
                        url: "/api/PlantFormula/CreateFormula",
                        data: JSON.stringify(dataSource._data[0]),
                        contentType: "application/json; charset=utf-8",
                        dataType: "Json",
                        error: function (error) {
                            alert($.GetLocaleKeyValue("FIELD_FORMULANAMEALREADYEXISTS", "Formula Name Already Exists"));
                            //alert(JSON.parse(error.responseText));
                        },
                        success: function () {
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                            //$('#gridFormula').data('kendoGrid').dataSource.read();
                            //$('#gridFormula').data('kendoGrid').refresh();                           
                            window.close();
                            window.destroy();
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_NEWFORMULADDEDSUCCESSFULLY", 'New formula added Successfully'));
                        }
                    });
                }
                else {
                    return false;
                }
            });
            $(".cancelRowPopup").unbind("click");
            $(document).on("click", ".cancelRowPopup", function () {
                wnd.close();
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                //dataSource.cancelChanges();
                grid.dataSource.read();
            });

        });

        function copyRecord(e) {
            var wnd, detailsTemplate;
            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            dataItem.FormulaDataToLoadDropdown = _this.FormulaData;
            wnd = $("#popup_edit")
                            .kendoWindow({
                                title: "Copy",
                                modal: true,
                                visible: false,
                                resizable: false,
                                width: "373px",
                                open: function () {

                                    $('#spnWeightCopy').text('(' + _this.FormulaData.units[0].UsageKey + ')');

                                    $('#spnPieceWeightCopy').text('(' + _this.FormulaData.units[0].UsageKey + ')');


                                    $("#cbRewashCopy").kendoMobileSwitch({
                                        onLabel: "YES",
                                        offLabel: "NO",
                                        change: function (e) {
                                            enable2();
                                        }
                                    });
                                    $('select').kendoDropDownList();
                                    copyCalPieceWeight();
                                },
                                content: {
                                    //sets window template
                                    template: kendo.template($("#newFormula").html())
                                }
                            }).data("kendoWindow");
            detailsTemplate = kendo.template($("#popup_editor_copy").html());


            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();

            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            var validator = $(wnd.element).kendoValidator().data("kendoValidator");
            $("#btnUpdatecopy").unbind("click");
            $("#btnUpdatecopy").on("click", function (e) {
                if (validator.validate() == true) {
                    var popupContainer = $(this).closest('.label-width');
                    dataSource._data[0].Name = popupContainer.find("#txtcopyFormulaName").val().trim();
                    dataSource._data[0].TextileId = popupContainer.find("#ddlEcolabTextileCategory").val().trim();
                    dataSource._data[0].EcolabSaturationId = popupContainer.find("#ddlEcolabSaturation").val().trim();
                    dataSource._data[0].PlantProgramId = popupContainer.find("#ddlChainFormula").val().trim();
                    dataSource._data[0].ProgramId = 0;
                    dataSource._data[0].ChainTextileId = popupContainer.find("#ddlChainTextileCategory").val().trim();
                    dataSource._data[0].Rewash = popupContainer.find('#cbRewashCopy').is(":checked");
                    dataSource._data[0].Pieces = popupContainer.find("#txtNumberofweightedPieces").val().trim();
                    dataSource._data[0].Weight = popupContainer.find("#txtWeight").val().trim();
                    dataSource._data[0].PieceWeight = popupContainer.find("#txtPieceWeight").val().trim();
                    dataSource.sync();
                    var grid = $("#gridFormula").data("kendoGrid");
                    grid.saveChanges();
                    grid.dataSource.read();

                    $.ajax({
                        type: "POST",
                        url: "/api/PlantFormula/CreateFormula",
                        data: JSON.stringify(dataSource._data[0].toJSON()),
                        contentType: "application/json; charset=utf-8",
                        dataType: "Json",
                        error: function (error) {
                            alert($.GetLocaleKeyValue("FIELD_FORMULANAMEALREADYEXISTS", "Formula Name Already Exists"));
                            //alert(JSON.parse(error.responseText));
                        },
                        success: function () {
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_FORMULAADDEDSUCCESSFULLYFROMCOPY", 'Formula Added Successfully from copy'));
                            wnd.close();
                        }
                    });
                }
                else {
                    return false;
                }

            });

            $("#btnCancel").on("click", function (e) {
                wnd.close();
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                grid.dataSource.read();
            });

        }

        var formulasData;
        $.ajax({
            type: "GET",
            url: "/api/PlantFormula/GetCategories",
            contentType: "application/json; charset=utf-8",
            dataType: "Json",
            error: function () {
            },
            success: function (data) {
                formulasData = data.Data;

            }
        });



        function categoryDropDownEditor(container, options) {
            $('<input required data-text-field="CategoryName" data-value-field="TextileId" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: formulasData.TextileCategory,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("CategoryName", dataItem.CategoryName);
                 options.model.set("TextileId", dataItem.TextileId);
             }
         });

        }

        function saturationDropDownEditor(container, options) {
            $('<input required data-text-field="EcolabSaturationName" data-value-field="EcolabSaturationId" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: formulasData.Saturation,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("EcolabSaturationName", dataItem.EcolabSaturationName);
                 options.model.set("EcolabSaturationId", dataItem.EcolabSaturationId);
             }
         });

        }

        function plantProgramDropDownEditor(container, options) {
            $('<input required data-text-field="PlantProgramName" data-value-field="PlantProgramId" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: formulasData.ChainProgram,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("PlantProgramName", dataItem.PlantProgramName);
                 options.model.set("PlantProgramId", dataItem.PlantProgramId);
             }
         });

        }

        function chainTextileDropDownEditor(container, options) {
            $('<input required data-text-field="Name" data-value-field="TextileId" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: formulasData.ChainTextileCategory,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("ChainTextileCategory", dataItem.Name);
                 options.model.set("ChainTextileId", dataItem.TextileId);
             }
         });

        }
    }
};