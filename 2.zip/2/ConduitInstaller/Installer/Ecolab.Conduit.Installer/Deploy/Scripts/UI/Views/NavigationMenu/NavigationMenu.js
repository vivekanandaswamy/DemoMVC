// JavaScript source code
Ecolab.Views.NavigationMenu = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/NavigationMenu/NavigationMenu.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
    this.isEdit = null;

};
var searchData = [];
var availableTags = [];
Ecolab.Views.NavigationMenu.prototype = {
    setData: function (data) {
        this.data = data;
        $.each(data.NavigationMenuModelList, function (item, value) {
            searchData.push(value);
        });
        $.each(searchData, function (item, data) {
            availableTags.push({ label: data.Hierarchy, value: data.Name, id: data.Id, typename: data.TypeName, parentid: data.ParentId, controllertypeid: data.ControllerTypeId, controllermodelid: data.ControllerModelId, washergroupid: data.WasherGroupId, washertypeflag: data.WasherTypeFlag, washergrouptypeid: data.WasherGroupTypeId });
        });

        var formulas = [];
        var washers = [];
        $.each(data.NavigationMenuViewModelList, function (index, value) {
            $.each(this.Menus, function (index, value) {
                $.each(this.SubMenus, function (index, value) {
                    if (this.SubMenu.TypeName == "Washer") {
                        washers.push(this);
                    }
                    if (this.SubMenu.TypeName == "Formula") {
                        formulas.push(this);
                    }
                });
            });
        });
        var listData = {};
        listData.Data = data.NavigationMenuViewModelList;
        listData.Washers = washers;
        listData.Formulas = formulas;

        this.tm.Render(listData, this);

    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        _this.resotreCurrentNavigationPath();

        $(".page-content").css("margin-left", "50px");
        $("#breadCrumbContainer").insertBefore(".page-title");
        $("footer").css("margin-left", "25px");

        var docHt = $(document).height() - $("#topnav").height();
        $(".page-content").css("min-height", docHt);
        
        $(".leftmenu-item").parent().hover(function () {
            var menuHt = $(window).height() - $(this).offset().top - 57;
            $(this).find(".show-menu > li > ul").css({ "max-height": menuHt, "overflow-y": "scroll" });
        });
        
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find('.show-menu ul li.has-sub>a').on('click', function () {
            $(this).removeAttr('href');
            var element = $(this).parent('li');
            if (element.hasClass('open')) {
                element.removeClass('open');
                element.find('li').removeClass('open');
                element.find('ul').slideUp();
            }
            else {
                element.addClass('open');
                element.children('ul').slideDown();
                element.siblings('li').children('ul').slideUp();
                element.siblings('li').removeClass('open');
                element.siblings('li').find('li').removeClass('open');
                element.siblings('li').find('ul').slideUp();
            }
        });
        //container.find('ul>li.has-sub>a').append('<span class="leftnav-itemholder"></span>');


        container.find('.show-menu ul li.has-sub .menu-dropper').on('click', function () {
            var element = $(this).parent('li');
            if (element.hasClass('open')) {
                element.removeClass('open');
                element.find('li').removeClass('open');
                element.find('ul').slideUp();
            }
            else {
                element.addClass('open');
                element.children('ul').slideDown();
                element.siblings('li').children('ul').slideUp();
                element.siblings('li').removeClass('open');
                element.siblings('li').find('li').removeClass('open');
                element.siblings('li').find('ul').slideUp();
            }
        });

        container.find('.aMenu').click(function () {
            var id = $(this).attr('Id');
            var parentId = $(this).attr('parentId');
            var typename = $(this).attr('typename');
            var controllerModelId = $(this).attr('controllerModelId');
            var ControllerTypeId = $(this).attr('ControllerTypeId');
            var washerType = $(this).attr('washertypeflag');
            var washergroupId = $(this).attr('washergroupId');
            var washergrouptypeid = $(this).attr('washergrouptypeid');
            var context = $(this);
            _this.redirectPage(id, parentId, typename, ControllerTypeId, controllerModelId, washerType, washergroupId, washergrouptypeid,context);
        });
        container.find('#txtFilter').autocomplete({
            autoFocus: true,
            minLength: 2,
            delay: 500,
            appendTo: '#search-box',
            open: function () { $('.ui-autocomplete').width($(".ui-autocomplete-input").width() + 10); },
            source: function (request, response) {
                var matcher = new RegExp($.ui.autocomplete.escapeRegex(request.term), "i");
                response($.grep(availableTags, function (item) {
                    return matcher.test(item.value);
                }));
            },
            select: function (event, ui) {
                _this.redirectPage(ui.item.id, ui.item.parentid, ui.item.typename, ui.item.controllertypeid, ui.item.controllermodelid, ui.item.washertype, ui.item.washergroupid, ui.item.washergrouptypeid);
            },
            focus: function (e, ui) {
                return false;
            },
            close: function () {
                $("#txtFilter").select();
            }

        }).autocomplete("widget").addClass("autoComplete");

        $("ul.show-menu").hover(function () {
            $(this).prev("a").addClass("hover");
        }, function () {
            $(this).prev("a").removeClass("hover");
        });
    },
    redirectPage: function (id, parentId, typename, ControllerTypeId, controllerModelId, washerType, washergroupId, washergrouptypeid, context) {
        var container = $(this.options.containerSelector);
        container.find("#txtFilter").text("");
        switch (typename) {
            case 'Controllers':
                if (id > 0) {
                    window.location = '/' + "ControllerSetup" + '?ControllerId=' + id + '&ControllerTypeId=' + ControllerTypeId + '&ControllerModelId=' + controllerModelId;
                }
                else
                    window.location = '/' + "ControllerSetupList";
                break;
            case 'Pumps':
                if (id > 0) {
                   
                    window.location = '/' + "Pumps" + '?ControllerId=' + parentId + '&ControllerTypeId=' + ControllerTypeId + '&ControllerModelId=' + controllerModelId + '&PumpId=' + id;
                }
                break;
            case 'PumpsList':
                if (id > 0) {
                    var parent = $(context).parent().parent().parent().find('a[typename=Controllers]').attr('id');
                    window.location = '/' + "Pumps" + '?ControllerId=' + parent + '&ControllerModelId=' + controllerModelId + '&ControllerTypeId=' + ControllerTypeId ;
                }
                break;
            case 'Washer Groups':
            case 'WasherGroupWashers':
                if (id > 0) {
                    window.location = '/' + "WasherGroupFormula?id=" + id;
                }
                else
                    window.location = '/' + "WasherGroup";

                break;
            case 'Formulas':
                if (id > 0) {
                    window.location = '/' + "WasherGroupFormula?id=" + id + '&type=Formulas';
                }
                break;
            case 'Washers':
                if (id > 0) {
                    if (washerType == 'true') {
                        window.location = '/' + "TunnelGeneral" + '?WasherId=' + id + '&WasherGroupId=' + washergroupId + '&WasherGroupTypeId=' + washergrouptypeid;
                    }
                    else {
                        window.location = '/' + "ConventionalGeneral" + '?WasherId=' + id + '&WasherGroupId=' + washergroupId;
                    }
                }
                else
                    window.location = '/' + "Washer";
                break;

            case 'Washer':
                if (id > 0) {
                    if (washerType == 'true') {
                        window.location = '/' + "TunnelGeneral" + '?WasherId=' + id + '&WasherGroupId=' + washergroupId + '&WasherGroupTypeId=' + washergrouptypeid + '&type=WasherGroup';
                    }
                    else {
                        window.location = '/' + "ConventionalGeneral" + '?WasherId=' + id + '&WasherGroupId=' + washergroupId + '&type=WasherGroup';
                    }
                }
                else
                    window.location = '/' + "Washer";
                break;
            case 'Storage Tanks':
                if (id > 0) {
                    window.location = '/' + "StorageTanks" + '?tankId=' + id;
                }
                else
                    window.location = '/' + "StorageTanks";
                break;
            case 'Formula':
                if (id > 0) {
                    window.location = '/' + "WasherGroupFormula" + '?formulaId=' + id + '&id=' + parentId;
                }
                break;
        }
    },
    resotreCurrentNavigationPath: function () {
        var _this = this;
        var url = _this.getLocationPath().replace('/', '');
        switch (url) {
            case 'ControllerSetupList':
            case 'ControllerSetup':
            case 'ControllerSetupAdvance':
            case 'Pumps':
                _this.openCurrentNav('Controllers', '0');
                break;
            case 'WasherGroup':
            case 'WasherGroupFormula':
                _this.openCurrentNav('Washer Groups', '0');
                break;
            case 'Washer':
            case 'ConventionalGeneral':
            case 'TunnelGeneral':
                var type = _this.getQueryStringByName('type');
                if (type == "WasherGroup") {
                    _this.openCurrentNav('Washer Groups', '0');
                }
                else
                    _this.openCurrentNav('Washers', '0');
                break;
            case 'StorageTanks':
                _this.openCurrentNav('Storage Tanks', '0');
                break;
        }
    },
    openCurrentNav: function (typeName, id) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + ']');
        if (element.length == 0)
            element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + ']');

        element.parent('li').parent('ul').siblings('a').addClass('active');
    },
    getLocationPath: function () {
        var location = window.location;
        var pathName = location.pathname;

        return pathName;
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    
}