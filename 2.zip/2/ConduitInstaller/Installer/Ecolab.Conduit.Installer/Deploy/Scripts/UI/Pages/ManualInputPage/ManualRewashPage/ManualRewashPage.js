﻿Ecolab.Presenters.ManualRewashPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ManualRewashPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initManualRewashView();
        this.initManualRewashAddEditView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onManualRewashLoaded: function (data) { _this.onManualRewashLoaded(data); },
            onManualRewashDeleted: function (data) { _this.onManualRewashDeleted(data) },
            onManualRewashDeletionFailed: function (error, description) { _this.onManualRewashDeletionFailed(error, description); },
            onManualRewashUpdated: function (data) { _this.onManualRewashUpdated(data) },
            onManualRewashUpdationFailed: function (error, description) { _this.onManualRewashUpdationFailed(error, description); },
            onFormulaLoaded: function (data) { _this.onFormulaLoaded(data); },
            onManualRewashFetched: function (data) { _this.onManualRewashFetched(data); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();

    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.ManualInputTabsView) {
            this.Views.ManualInputTabsView = new Ecolab.Views.ManualInputTabs(
                        {
                            containerSelector: '#tabContainer',
                            eventHandlers: {
                                rendered: function () {
                                    _this.loadManualRewash();
                                    //_this.onManualRewashLoaded({});
                                },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
        }
        this.Views.ManualInputTabsView.setData(this.settings.accountInfo);
    },
    initManualRewashView: function () {
        var _this = this;
        if (!this.Views.ManualRewashView) {
            this.Views.ManualRewashView = new Ecolab.Views.ManualRewash({
                containerSelector: '#divManualRewashContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onCancelClicked: function () { _this.onCancelClicked(); },
                    onSaveClicked: function (manualProductionViewModel) { _this.onSaveClicked(manualProductionViewModel); },
                    //onDeleteClicked: function () { _this.onDeleteClicked(); },
                    onWasherGroupChange: function (groupId) { _this.onWasherGroupChange(groupId); },
                    onWasherOrFormulaChange: function (manualProductionViewModel) { _this.onWasherOrFormulaChange(manualProductionViewModel) },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
    },

    initManualRewashAddEditView: function () {
        var _this = this;
        if (!this.Views.ManualRewashAddEditView) {
            this.Views.ManualRewashAddEditView = new Ecolab.Views.ManualRewashAddEdit({
                containerSelector: '#manualRewashDataContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onDeleteClicked: function () { _this.onDeleteClicked(); },
                }
            });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_MANUALINPUT', 'Manual Input');
        breadCrumbData.url = "/ManualUtility";
        this.showPlantBreadCrumb("manualInput", breadCrumbData);
    },

    loadManualRewash: function () {
        this.Model.loadManualRewash();
    },

    onManualRewashLoaded: function (data) {
        data.hasData = false;
        var allowEdit = false;
        var level = this.settings.accountInfo.MaxLevel
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        var utilityData = {};
        data.AllowEdit = allowEdit;
        this.Views.ManualRewashView.setData(data);
    },

    onDeleteClicked: function () {
        var _this = this
        var data = _this.Views.ManualRewashView.getIdsToLoadProductData();
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Ok: {
                    Callback: function () {
                        _this.Model.deleteManualRewash(data)
                        $('#ConfirmDialog').hide();
                    }
                },

                Cancel: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
              , blockSelector: 'body'
        });

    },

    onManualRewashDeleted: function (data) {
        this.Views.ManualRewashView.setData(data);
        this.Views.ManualRewashView.showMessage(data.Result);
    },

    onManualRewashDeletionFailed: function (data) {
        this.Views.ManualRewashView.showMessage("301");
    },

    onSaveClicked: function (manualProductionViewModel) {
        this.Model.updateManualRewash(manualProductionViewModel)
    },

    onManualRewashUpdated: function (data) {
        this.Views.ManualRewashView.setData(data);
        this.Views.ManualRewashView.showMessage(data.Result);
    },

    onManualRewashUpdationFailed: function (data, description) {
        this.Views.ManualRewashView.showMessage("301");
    },

    onWasherGroupChange: function (groupId) {
        this.Model.FetchFormulaByWasherGroup(groupId)
    },

    onFormulaLoaded: function (data) {
        this.Views.ManualRewashView.bindFormulaData(data);
    },

    onWasherOrFormulaChange: function (manualProductionViewModel) {
        this.Model.FetchManualRewash(manualProductionViewModel)
    },

    onManualRewashFetched: function (data) {
        data.hasData = true;
        this.Views.ManualRewashView.showMessage(data[0].Result);
        var allowEdit = false;
        var level = this.settings.accountInfo.MaxLevel
        if (level == 3 || level == 4 || level == 6 || level == 7 || level == 8 || level == 9) {
            allowEdit = true;
        }
        data.AllowEdit = allowEdit;
        this.Views.ManualRewashAddEditView.setData(data);
    },
    savePage: function () {
        var view = this.Views.ManualRewashView;
        if (view) {
            view.clearMessage();
            if (view.validate()) {
                view.onSaveClicked();
                this.isDirty = false;
            }
        }
    }
};