Ecolab.Model.VisualizationModelProxy = function () {
};

Ecolab.Model.VisualizationModelProxy.prototype =
{
    loadDashboardData: function (dashboardId, callBack, errorCallBack) {
        debugger;
        var url = "/Api/Visualization/GetVisualizationData/{dashboardId}";
        var requestData = { "dashboardId": dashboardId };
        this.ApiRead("", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.VisualizationModelProxy.prototype = $.extend({}, Ecolab.Model.VisualizationModelProxy.prototype, base);
Ecolab.Model.VisualizationModelProxy.prototype.base = base;