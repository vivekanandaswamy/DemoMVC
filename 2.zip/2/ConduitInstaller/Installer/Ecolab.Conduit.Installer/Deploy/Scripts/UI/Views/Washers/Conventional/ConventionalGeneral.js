// JavaScript source code
Ecolab.Views.ConventionalGeneral = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onDropDownChange: null,
            
        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.selectedValue = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Washers/Conventional/General.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: {
            onRendered: function () {
                _this.onRendered();
            }
        }
    });
    this.allowEdit = false;
    this.isEdit = null;
};

Ecolab.Views.ConventionalGeneral.prototype = {
    setData: function (data) {
        
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        if (data.Id == null) data.Mode = "Add";
        this.tm.Render(data, this);
        if (data.Mode == "Edit") {
            $('#txtName').val(data.Name);
        }
      
        if (data.accountInfo.MaxLevel == 8) {
            data.allowEdit = true;
        }
        else
            data.allowEdit = false;
        //if (data.Mode == "Edit") {
        //    $('#txtName').attr("disabled", "disabled");
        //    $('#txtPlantWasher').attr("disabled", "disabled");
        //}

    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        this.disableTabs();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });

        $("#ddlController").trigger('change');
        $("#ddlModel").trigger('change');
        $('.btn').attr("disabled", "disabled");

        if (this.options.eventHandlers.madeChangeFalse)
            _this.options.eventHandlers.madeChangeFalse();
        if (!this.data.Id) {
            $('.new_tabs li.tab').not('.active').addClass('disabled');
            $('.new_tabs li.tab').not('.active').find('a').removeAttr("data-toggle");
            $('.new_tabs li.disabled').children('a').click(function (e) {
                e.preventDefault();
            });
        }
        
    },
    attachEvents: function () {
        var _this = this;
        _this.allowEdit = this.options.accountInfo.MaxLevel >= 6;
        var container = $(this.options.containerSelector);

        container.find("#btnSaveConventionalGeneral").click(function () {
             _this.clearStatusMessage();
            _this.onSaveClicked();
        });
        container.find("#ddlModel").change(function () {
            $('#txtName').val($(this).val());
            $('#txtName').parent().find('span').empty();
            _this.getSize($(this).val())
        });
        container.find("#ddlController").change(function () {
            _this.getWasherMode($(this).val());
            _this.getLfsWasher($(this).val());
        });

        container.find('#ddlLfsWasher').change(function () {
            if (_this.data.Id == null && _this.data.accountInfo.MaxLevel == 8)
                _this.setConventionalTags($(this).find(":selected").text());
        });

       
        container.find('#btnConventionalGeneralPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.data.EcoLabAccountNumber,
                WasherGroupId: _this.data.WasherGroupId,
                PageTitle: "Conventional General",
                WasherId: _this.data.Id == null ? 0 : _this.data.Id,
                ControllerId: _this.data.ControllerId == null ? 0 : _this.data.ControllerId,
                RegionId: _this.data.RegionId,
                MachineNumber: _this.data.LfsWasher == null ? 0 : _this.data.LfsWasher,
            };
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.options.accountInfo.PrintAction + "?data=" + data);
            return retVal;
        });
        $('#btnCancel').click(function () {
            _this.onCancelClick();

        });
    },
    getSize: function (model) {
        if (this.options.eventHandlers.getSize)
            this.options.eventHandlers.getSize(model);
    },
    getLfsWasher: function (controllerId) {
        if (this.options.eventHandlers.getLfsWasher)
            this.options.eventHandlers.getLfsWasher(controllerId);
    },
    getWasherMode: function (controllerId) {
        if (this.options.eventHandlers.getWasherMode)
            this.options.eventHandlers.getWasherMode(controllerId);
    },
    LoadSizeDropDown: function (data , ModelId) {
        var container = $(this.options.containerSelector);
        var ddlSize = container.find("#ddlSize");
        ddlSize.empty();
        ddlSize.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlSize.append('<option value="' + this.WasherModelId + '">' + this.WasherSize + '</option>');
        });

        if (ModelId != null) {
            $("#ddlSize").val(ModelId)
            var selectedOption = $('#ddlSize').find(":selected").text();
            $('#ddlSize').next(".holder").text(selectedOption);
        }

    },
    LoadLfsWasherDropDown: function (data , LfsWasher) {
        var container = $(this.options.containerSelector);
        var ddlLfsWasher = container.find("#ddlLfsWasher");
        ddlLfsWasher.empty();
        ddlLfsWasher.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlLfsWasher.append('<option value="' + this + '">' + this + '</option>');
        });

        if (LfsWasher != null) {
            $("#ddlLfsWasher").val(LfsWasher)
            var selectedOption = $('#ddlLfsWasher').find(":selected").text();
            $('#ddlLfsWasher').next(".holder").text(selectedOption);
        }

    },
    LoadWasherModeDropDown: function (data, ModeId) {
        var container = $(this.options.containerSelector);
        var ddlWasherMode = container.find("#ddlWasherMode");
        ddlWasherMode.empty();
        ddlWasherMode.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlWasherMode.append('<option value="' + this.Id + '">' + this.Name + '</option>');
        });

        if (ModeId != null) {
            $("#ddlWasherMode").val(ModeId)
            var selectedOption = $('#ddlWasherMode').find(":selected").text();
            $('#ddlWasherMode').next(".holder").text(selectedOption);
        }

    },
    clearStatusMessage: function () {
        $("#message").html('');
    },
    onSaveClicked: function (data) {
        this.getConventionalData();
        if (this.options.eventHandlers.savePage)
            this.options.eventHandlers.savePage();
    },
    getConventionalData: function () {
        var container = $(this.options.containerSelector);
        var maxLevel=this.options.accountInfo.MaxLevel;
        var washerTags = [];
        var tagValues = {}; var plcTagValues = [];
       // var obj = [];
        $(".upperCase").each(function (index, element) {
            var tagId = element.attributes['id'].value;
            var tagAddress = tagId.replace('txt', '');
            var tagValue = $('#' + tagId).val();
            if (tagValue) {
                var tagNextValue = $('#' + tagId).parent().prev().find('input').val();
                if (tagNextValue == undefined)
                    tagNextValue = null;

                washerTags.push({
                    TagDescription: tagAddress,
                    TagAddress:tagValue,
                });

                plcTagValues.push({
                    Address: tagValue,
                    TagType: tagAddress,
                    IsValidTag: false,
                    Value: tagNextValue
                });
            }
        });
        if (washerTags.length > 0) {

            washerTags.push({
                TagDescription: 'WasherNumberTag',
                TagAddress: "N148:" + $('#ddlLfsWasher').val(),
            });
        }


        return {
            Name: container.find('#txtName').val(),
            ControllerId: container.find('#ddlController').val(),
            WasherModelId: container.find('#ddlSize').val(),
            LfsWasher : container.find('#ddlLfsWasher').val(),
            WasherModeId: container.find('#ddlWasherMode').val(),
            EndOfFormula: container.find('#txtEndOfFormula').val(),
            AweActive: container.find('#chkAWE').is(":checked") ? true : false,
            PlantWasherNumber: container.find('#txtPlantWasherNumber').val(),
            MaxLoad: container.find('#txtMaxLoad').val(),
            HoldSignal: container.find('#chkHoldSignal').is(":checked") ? true : false,
            HoldDelay: container.find('#txtHoldDelay').val(),
            TargetTurnTime: container.find('#txtTargetTurnTime').val(),
            WaterFlushTime: container.find('#txtWaterFlushTime').val(),
            Description: container.find('#txtDescription').val(),
            Id: container.find('#hConventionalId').val(),
            EcolabAccountNumber: container.find('#hEcoLabAccountNumber').val(),
            WasherGroupId: container.find('#hWashergroupId').val(),
            RegionId: container.find('#hRegionId').val(),
            ConventionalWasherTagList: washerTags,
            PlcWasherTagModelTags: plcTagValues,
            Role:maxLevel
        };
    },
  
    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var decimalPattern = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;

        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "*"
       );
        var v1 = container.find('#frmConventionalGen').validate({
            rules: {
                txtName: { required: true, },
                ddlModel: {
                    required: true,
                },
                ddlSize: {
                    required: true,
                },
                ddlController: {
                    required: true,
                },
                ddlLfsWasher: {
                    required: true,
                },
                ddlWasherMode: {
                    required: true,
                },
                txtEndOfFormula: {
                    required: true,
                    min: 1,
                    max:127
                },
                
                txtPlantWasherNumber: {
                    required: true,
                    min: 1,
                    max: 99999,
                    number: true
                },
                txtMaxLoad: {
                    required: true,
                    number: true,
                    CheckOnNumbers: true,
                    digits :true,
                    min: 1,
                    max: 999
                },
                txtHoldDelay: {
                    required: true,
                    number: true,
                    CheckOnNumbers: true,
                    digits: true,
                },
                txtTargetTurnTime: {
                    required: true,
                    number: true,
                    CheckOnNumbers: true,
                    min: 0,
                    max: 999,
                    digits: true,
                },
                txtWaterFlushTime: {
                    required: true,
                    number: true,
                    CheckOnNumbers: true,
                    min: 0,
                    max: 999,
                    digits: true,
                },
               
            },
            messages: {

                txtName: { required: $.GetLocaleKeyValue('FIELD_PLEASEENTERNAME', 'Please enter Name'), },

                ddlSize: {
                            required: $.GetLocaleKeyValue('FIELD_PLEASEENTERSIZE','Please enter Size'),
                },

                ddlModel: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTMODEL','Please select Model'),
                },
                ddlSize: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTSIZE','Please select Size'),
                },
                ddlController: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTCONTROLLER','Please select Controller'),
                },
                ddlLfsWasher: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTLFSWASHERNUMBER','Please select Lfs Washer Number'),
                },
                ddlWasherMode: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWASHERMODE','Please select Washer Mode'),
                },
                
                txtEndOfFormula: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERENDOFFORMULA','Please enter End of Formula'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO127', 'Please enter between 1 to 127.'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO127', 'Please enter between 1 to 127.'),
                },
                txtPlantWasherNumber: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERPLANTWASHERNUMBER','Please enter Plant Washer Number'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO99999', 'Please enter between 1 to 99999.'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO99999', 'Please enter between 1 to 99999.'),
                },
                txtMaxLoad: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERMAXIMUMLOAD','Please enter Max Load'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO999', 'Please enter between 1 to 999.'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO999', 'Please enter between 1 to 999.'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                    digits: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                
                txtHoldDelay: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERHOLDDELAY','Please enter Hold Delay'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                    digits: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                txtTargetTurnTime: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERTARGETTURNTIME','Please enter Target Turn Time'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO999', 'Please enter between 1 to 999.'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN1TO999', 'Please enter between 1 to 999.'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                    digits: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
                txtWaterFlushTime: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERWATERFLUSHTIME','Please enter Water Flush Time'),
                    min: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO999', 'Please enter between 0 to 999.'),
                    max: $.GetLocaleKeyValue('FIELD_PLEASEENTERBETWEEN0TO999', 'Please enter between 0 to 999.'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                    digits: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
               
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });
        var v2 = container.find('#frmConventionalGen').valid();
        return v2;
    },
    
    onCancelClick: function () {
        var retval = this.options.eventHandlers.onRedirection('./WasherGroupFormula?' + 'id=' + this.options.accountInfo.WasherGroupId + "&data=Cancel");
        return retval;
        //if (this.options.eventHandlers.onCancel)

            //this.options.eventHandlers.onCancel();
    },
    showMessage: function (message) {
        var _this = this;
        $("#message").html('');
        var messageDiv = $("#message");
        if (message.indexOf('tags') != -1)
            messageDiv.attr("title", message);
        messageDiv.html(message);

    },
    showTagMessage: function (message,description) {
        $("#message").html('');
        var messageDiv = $("#message");
        messageDiv.attr("title", description);

        messageDiv.html(message);
    },
    enableTabs: function () {
        $('.sub-tabs li').removeClass('disabled');
        $('.sub-tabs li').not('.active').find('a').attr("data-toggle", "tab");
    },
    disableTabs: function () {
        var container = $(this.options.containerSelector);
        var ConventionalId = container.find('#hConventionalId').val();
        if (ConventionalId == '') {
            $('.sub-tabs li').not('.active, .backto-group').addClass('disabled');
            $('.sub-tabs li').not('.active').find('a').removeAttr("data-toggle");
            $('.sub-tabs li.disabled').children('a').click(function (e) {
                e.preventDefault();
            });
        }
    },
    setConventionalTags: function (lfsWashernumber) {
        if (lfsWashernumber.indexOf("-- Select --") == -1) {
            var value = 0;
            value = parseInt(lfsWashernumber);
            var EOF = 100 + (value - 1);
            var InjectionClass = (value * 10) - 5;
            var CF = (value - 1) * 10;
            var AWEF = 120 + (6 * (value - 1));
            var CINJ = (value * 10) - 9;
            var COPC = (value * 10) - 8;
            var RDP = 80 + (value - 1);
            var INJR = 50 + (value - 1);
            var HD = (13 * 10) + (value - 1);
            var FT = 40 + (2 * (value - 1));
            $("#txtEndOfFormulaTag").val("N10:" + EOF);
            $("#WasherModeTag").val("N7:240" + (value - 1));
            $("#AWEActiveTag").val("B3:17/" + value);
            $("#txtHoldDelayTag").val("T4:" + HD + ".PRE");
            $("#txtHoldSignalTag").val("O:6/" + (value - 1));
            $("#txtFlushTimeTag").val("C5:"+FT);
            $("#txtCurrentFormulaTag").val("N7:" + CF);
            $("#txtAutoWeightEntryFormulaTag").val("N10:" + AWEF);
            $("#txtInjectionClassTag").val("N7:" + InjectionClass);
            $("#txtCurrentInjectionTag").val("N7:" + CINJ);
            $("#txtCurrentOperationCounterTag").val("N7:" + COPC);
            $("#txtInjectionRatioTag").val("N10:" + INJR);
            $("#txtRatioDosingActiveTag").val("B3:10/" + value);
            $("#txtRatioDosingPercentageTag").val("N10:" + RDP);
        }
        else {
            $(".upperCase").val('');
        }
    }
}
jQuery.validator.addMethod("CheckOnNumbers", function (value, element) {
    return this.optional(element) || (parseInt(value) > 1) || (parseInt(value) < 999);
}, $.GetLocaleKeyValue('FIELD_ENTERBETWEEN1AND999', 'Please enter value between 1 and 999'));