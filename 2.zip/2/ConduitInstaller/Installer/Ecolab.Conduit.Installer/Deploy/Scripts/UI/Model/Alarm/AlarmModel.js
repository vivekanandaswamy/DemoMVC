// JavaScript source code
Ecolab.Model.AlarmModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            loadAlarmData: null,
            onAlarmDataLoaded: null,
            onAlarmCountLoaded:null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.AlarmModelProxy = new Ecolab.Model.AlarmModelProxy();
};

Ecolab.Model.AlarmModel.prototype = {
    init: function () {
    },
    loadAlarmData: function () {
        var _this = this;
        _this.AlarmModelProxy.loadAlarmData(function (AlarmData) {
            _this.settings.eventHandlers.onAlarmDataLoaded(AlarmData);
        });
    },
    loadAlarmCount: function () {
    var _this = this;
    _this.AlarmModelProxy.loadAlarmCount(function (AlarmData) {
        _this.settings.eventHandlers.onAlarmCountLoaded(AlarmData);
    });
}

}