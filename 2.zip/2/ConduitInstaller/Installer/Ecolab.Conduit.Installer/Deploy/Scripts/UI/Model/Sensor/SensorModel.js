﻿Ecolab.Model.SensorModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onSensorDataLoaded: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.SensorModelProxy = new Ecolab.Model.SensorModelProxy();
};

Ecolab.Model.SensorModel.prototype = {
    init: function () {
    },

    loadSensorData: function (callBackData) {
        var _this = this;
        this.SensorModelProxy.loadSensorData(function (SensorData) {
            _this.settings.eventHandlers.onSensorDataLoaded(SensorData, callBackData);
        });
    },

    loadUoMModel: function (UtilityId, callBackData) {
        var _this = this;
        this.SensorModelProxy.loadUoMProxy(UtilityId, function (SensorData) {
            _this.settings.eventHandlers.loadUoMCallBack(SensorData, callBackData);
        });
    },

    loadMachineCompartmentByUtilityLocationId: function (UtilityLocationId, callBackData) {
        var _this = this;
        this.SensorModelProxy.loadMachineCompartmentByUtilityLocationId(UtilityLocationId, function (machineCompartmentData) {
            _this.settings.eventHandlers.onloadMachineCompartmentByUtilityLocationIdLoaded(machineCompartmentData, callBackData);
        });
    },

    loadDefaultData: function (SensorId, callBackData) {
        var _this = this;
        this.SensorModelProxy.loadDefaultData(SensorId, function (parentData) {
            _this.settings.eventHandlers.loadDefaultDataLoaded(parentData, callBackData);
        });
    },
    loadChemicalforChart: function (MachineId, callBackData) {
        var _this = this;
        this.SensorModelProxy.loadChemicalforChart(MachineId, function (parentData) {
            _this.settings.eventHandlers.loadChemicalforChartLoaded(parentData, callBackData);
        });
    },
    
    loadSensorOnAddNewPopupLoad: function (callBackData) {
        var _this = this;
        this.SensorModelProxy.loadSensorOnAddNewPopupLoad(function (parentData) {
            _this.settings.eventHandlers.onloadSensorOnAddNewPopupDataLoaded(parentData, callBackData);
        });
    }
};

