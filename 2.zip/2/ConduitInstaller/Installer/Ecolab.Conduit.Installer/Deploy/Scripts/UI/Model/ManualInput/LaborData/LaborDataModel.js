﻿Ecolab.Model.LaborDataModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onTypeAndLocationLoaded: null,
            onSaved: null,
            onSaveFailed: null,
            onLaborCostLoad:null,
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.LaborDataModelProxy = new Ecolab.Model.LaborDataModelProxy();
};
Ecolab.Model.LaborDataModel.prototype = {
    init: function () {
    },
    getLaborTypeAndLocation: function () {
        var _this = this;
        _this.LaborDataModelProxy.getLaborTypeAndLocation(function (labordata) {

            _this.settings.eventHandlers.onTypeAndLocationLoaded(labordata);
        })
    },
    SavelaborData: function (data) {
        var _this = this;
        _this.LaborDataModelProxy.SavelaborData(data, function (data) {

            _this.settings.eventHandlers.onSaved(data);
        },
          function (error, description) {
              _this.settings.eventHandlers.onSaveFailed(error, description);
          });

    },
    GetLaborCost: function (ecolabAccountNumber, locationId, manHourTypeId) {
        var _this = this;
        _this.LaborDataModelProxy.GetLaborCost(ecolabAccountNumber, locationId, manHourTypeId, function (data) {

            _this.settings.eventHandlers.onLaborCostLoad(data);
        });
    },
    deleteManualLabor: function (data) {
        var _this = this;
        _this.LaborDataModelProxy.deleteManualLabor(data, function (data) {
            _this.settings.eventHandlers.onManualLaborFetched(data);
        }, function (error, description) { _this.settings.eventHandlers.onProductDataDeletionFailed(error, description); });
    },
};

