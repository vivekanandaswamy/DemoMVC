﻿Ecolab.Views.ProductionChart = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            loadParameters: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ProductionChart/ProductionChart.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });

    var start;
    var end;
    var startDateIni;
    var endDateIni;
    var seriesdata = {};
    var tunnels = {};
    var chart;
    var doTrend = false;
    var timer = 0;
    var additionalHours;
};

Ecolab.Views.ProductionChart.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.changeChartTitle();
        _this.start = container.find("#fromDate").kendoDateTimePicker({
            value: _this.getDateByHour(1),
            // change: startChange,
            parseFormats: ["MM/dd/yyyy"],
            open: function (e) {
                $('#fromDate').data('kendoDateTimePicker').options.opened = true;
            },
            close: function (e) {
                $('#fromDate').data('kendoDateTimePicker').options.opened = false;
            }
        }).data("kendoDateTimePicker");
        container.find("#fromDate").bind("focus", function () {
            var obj = $(this).data('kendoDateTimePicker');
            if (typeof (obj.options.opened) == 'undefined' || !obj.options.opened) {
                obj.open();
            }
        });

        container.find("#ddlWasherOrTunnel").change(function () {
            _this.loadWashersAndParameters();
        });

        additionalHours = container.find("#ddltoHours").val();
        _this.end = new Date(_this.start.value()).add('h', additionalHours);

        container.find("#btnGo").click(function () {
            _this.doTrend = false;
            if (_this.timer) {
                clearTimeout(_this.timer);
                _this.timer = 0;
            }

            additionalHours = container.find("#ddltoHours").val();
            _this.end = new Date(_this.start.value()).add('h', additionalHours);

            _this.startTrending();
        });

        container.find("#btnClear").click(function () {
            _this.start.value(_this.getDateByHour(1));
            container.find("#ddltoHours").val(1);
            _this.end = new Date(_this.start.value()).add('h', 1);
            if (_this.timer) {
                clearTimeout(_this.timer);
                _this.timer = 0;
            }
            _this.doTrend = true;
            _this.startTrending();
        });

    },
    changeChartTitle: function () {
        var _this = this;
        $('.titleChartType').addClass("hide");
        $('#titleChartType' + _this.getChartTypeId()).removeClass("hide");
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    bindTunnelData: function (tunnels) {
        var _this = this;
        var container = $(this.options.containerSelector);
        var divError = container.find('#divError').hide();
        if (tunnels.length > 0) {
            $.each(tunnels, function (i, tunnel) {
                container.find("#ddlWasherOrTunnel").append('<option value="' + tunnel.GroupId + '"number="' + tunnel.NumberOfcompartmentals + '"MachineType="' + tunnel.MachineType + '"MachineId="' + tunnel.MachineInternalId + '">' +
                     tunnel.MachineName + '</option>');
            });
            container.find('#ddlWasherOrTunnel').find('option:first').attr('selected', 'selected');
            _this.loadWashersAndParameters();
        }
        else {
            divError.show();
        }
    },
    getChartTypeId: function () {
        var _this = this;
        var chartType = 1;
        if (_this.getQueryStringByName('type')) {
            chartType = _this.getQueryStringByName('type');
        }

        return chartType;
    },
    loadWashersAndParameters: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find("#ddlCompartment").empty();
        var groupId = container.find('#ddlWasherOrTunnel').val();
        var selectedOption = container.find('#ddlWasherOrTunnel').find(":selected").text();
        container.find('#ddlWasherOrTunnel').next(".holder").text(selectedOption);

        if (this.options.eventHandlers.loadParameters)
            this.options.eventHandlers.loadParameters(groupId, _this.getChartTypeId());
    },
    bindParameterData: function (data) {
        var _this = this;
        var container = $(this.options.containerSelector);

        if (data.length > 0) {
            $.each(data, function () {
                container.find("#ddlCompartment").append('<option value="' + this.MappedCompartment + '" ParameterID="' + this.ParameterID + '" WasherId="' + this.WasherId + '">' +
                     this.ParameterName + '</option>');
            });
        }
        container.find('#ddlCompartment').find('option:first').attr('selected', 'selected');
        var selectedOption = container.find('#ddlCompartment').find(":selected").text();
        container.find('#ddlCompartment').next(".holder").text(selectedOption);
    },
    getDateByHour: function (hr) {
        var today = new Date();
        var day = today.getDate();
        var month = today.getMonth();
        var year = today.getFullYear();
        var hrs = today.getHours();
        var mins = today.getMinutes();

        return new Date(year, month, day, hrs - hr, mins);
    },
    startTrending: function () {
        var _this = this;
        _this.startDateIni = kendo.format("{0:MM/dd/yyyy hh:mm:ss tt}", _this.start.value());
        var appendTime = new Date(_this.start.value()).add('h', additionalHours);
        _this.endDateIni = kendo.format("{0:MM/dd/yyyy hh:mm:ss tt}", _this.end);
        _this.TrendingChart();
    },
    getFiltersForProductionChart: function () {
        var _this = this;
        var compOrMachineId = 0;
        var parameterId = -1;
        if (_this.getChartTypeId() == 1) {
            if ($("#ddlWasherOrTunnel option:selected").attr("machinetype") == "Washer") {
                compOrMachineId = $("#ddlWasherOrTunnel option:selected").attr("machineid");
                parameterId = $("#ddlCompartment option:selected").attr("parameterid");
            }
            else {
                compOrMachineId = $('#ddlCompartment').val();
            }
        }

        if (_this.getChartTypeId() == 2) {
            if ($("#ddlWasherOrTunnel option:selected").attr("machinetype") == "Washer") {
                compOrMachineId = $("#ddlWasherOrTunnel option:selected").attr("machineid");
                parameterId = $("#ddlCompartment option:selected").attr("parameterid");
            }
            else {
                compOrMachineId = $("#ddlCompartment option:selected").attr("parameterid");
            }
        }

        return {
            chartId: _this.getChartTypeId(),
            washerId: $("#ddlCompartment option:selected").attr("WasherId"),
            compId: compOrMachineId,
            parameterId: parameterId,
            startDate: kendo.format("{0:MM/dd/yyyy hh:mm:ss tt}", _this.startDateIni),
            endDate: kendo.format("{0:MM/dd/yyyy hh:mm:ss tt}", _this.endDateIni)
        }
    },
    getFiltersForTrendingProductionChart: function () {
        var _this = this;
        _this.startDateIni = _this.end;
        _this.end = new Date();
        _this.endDateIni = new Date();

        return _this.getFiltersForProductionChart();
    },
    TrendingChart: function () {
        var _this = this;
        $('#container').empty();
        _this.seriesdata = {};
        _this.tunnels = {};
        if (this.options.eventHandlers.loadByFilters)
            this.options.eventHandlers.loadByFilters(_this.getFiltersForProductionChart(), _this.onloadByFiltersLoaded, _this);
    },
    onloadByFiltersLoaded: function (data, current) {
        var _this = current;
        $('#divError').hide();
        _this.setGraphData(data);
        _this.generateChart();
        if (data.length == 0)
            $('#divError').show();
    },
    generateChart: function () {
        var _this = this;
        var yAxis = [];
        var yAxisTopindex = 0;
        var noOfSeries = 0;
        var eachWeriesHeight = 0;
        $.each(_this.seriesdata, function (index, value) {
            if (value.length != 0 && value[0][2].indexOf('Standard') == -1) {
                noOfSeries = noOfSeries + 1;
            }
        });

        eachWeriesHeight = 100 / noOfSeries;
        var firstChartHeight = 0;

        $.each(_this.seriesdata, function (index, value) {
            if (value.length != 0 && value[0][2].indexOf('Standard') == -1) {
                if (index != 0) {
                    yAxisTopindex = yAxisTopindex + 1;
                    firstChartHeight = 2;
                }
                else
                    firstChartHeight = 0;

                var yAxisData = {
                    title: {
                        text: value[0][2],
                        margin: 70,
                        rotation: 0,
                        style: {
                            fontFamily: 'Arial',
                            fontSize: '12pt'
                        }
                    },
                    lineWidth: 2,
                    showEmpty: false,
                    opposite: false,
                    top: (eachWeriesHeight * yAxisTopindex) + firstChartHeight + '%',
                    height: eachWeriesHeight - firstChartHeight + '%',
                    offset: 1
                };

                yAxis.push(yAxisData);
            }
        });

        var seriesData = [];
        var yaxisIndex = 0;
        $.each(_this.seriesdata, function (index, value) {
            yId = index;
            if (value.length != 0 && value[0][2].indexOf('Standard') == -1) {
                if (index != 0)
                    yaxisIndex = yaxisIndex + 1;
            }
            var series = {
                name: value[0][2],
                data: value,
                type: 'line',
                id: yaxisIndex,
                lineWidth: 1,
                step: 'right',
                yAxis: parseInt(yaxisIndex),
                tooltip: {
                    formatter: function () {
                        return '<b>' + this.series.name + '</b><br/>' +
                            Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', this.x) + '<br/>' +
                            Highcharts.numberFormat(this.y, 2);
                    }
                },
                legend: {
                    enabled: false
                },
                exporting: {
                    enabled: false,
                    //valueDecimals: 2
                },
                connectNulls: false
            };
            seriesData.push(series);
        });

        var chartHeight = yAxis.length * 180;
        if (yAxis.length > 6) {
            chartHeight = yAxis.length * 100;
        }

        _this.chart = new Highcharts.StockChart({
            chart: {
                renderTo: 'container',
                type: 'spline',
                zoomType: 'x',
                height: chartHeight,
                animation: Highcharts.svg, // don't animate in old IE
                options3d: {
                    enabled: false,
                },
                events: {
                    load: function () {
                        if (_this.doTrend) {
                            var thisGraph = this;
                            _this.refreshGraph(thisGraph);
                        }
                    }
                }
            },
            plotOptions: {
                line: {
                    events: {
                        hide: function () {
                            _this.resizeChart();
                        },
                        show: function () {
                            _this.resizeChart();
                        }
                    }
                }
            },
            credits: {
                enabled: false
            },
            legend: {
                enabled: true,
                backgroundColor: '#EEEEEE',
                layout: 'horizontal',
                verticalAlign: 'top',
                itemStyle: {
                    font: '10pt Arial',
                    color: '#666666'
                },
                itemHoverStyle: {
                    color: '#333333'
                },
                style: {
                    font: 'bold 12px Arial',
                }
            },
            exporting: {
                enabled: false
            },
            navigator: {
                enabled: false
            },
            rangeSelector: {
                enabled: false
            },
            scrollbar: {
                enabled: false
            },
            yAxis: yAxis,
            xAxis: {
                type: 'datetime',
                tickPixelInterval: 100,
                offset: 8,
                labels: {
                    maxStaggerLines: 1,
                    format: '{value:%H:%M}',
                    align: 'left',
                    dateTimeLabelFormats: {
                        hour: '%H:%M',
                        day: '%e. %b',
                        week: '%e. %b',
                        month: '%b \'%y',
                        year: '%Y'
                    }
                }
            },
            series: seriesData
        });
        _this.resizeChart();
    },
    resizeChart: function () {
        var _this = this;
        var visibleAxis = 0;
        for (var i = 0; i < _this.chart.yAxis.length; i++) {
            if (_this.chart.yAxis[i].showAxis)
                visibleAxis = visibleAxis + 1;
        }

        var plotHeisPer = 100 / visibleAxis;
        var vheight = 0;
        var firstChartHt = 0;
        for (var i = 0; i < _this.chart.yAxis.length; i++) {
            if (_this.chart.yAxis[i].showAxis) {
                if (vheight != 0)
                    firstChartHt = 2;
                else
                    firstChartHt = 0;

                _this.chart.yAxis[i].update({
                    height: plotHeisPer - firstChartHt + '%',
                    top: (plotHeisPer * vheight) + firstChartHt + '%'
                });

                vheight = vheight + 1;
            }
        }
    },
    refreshGraph: function (thisGraph) {
        var _this = this;
        (function poll() {
            _this.timer = setTimeout(function () {
                $.ajax({
                    url: "/api/TrendingChart/GetByFilters",
                    data: _this.getFiltersForTrendingProductionChart(),
                    async: true,
                    success: function (data) {
                        if (data.length > 0) {
                           // debugger;
                            //var recievedData = eval(data);
                            _this.setGraphData(data);
                            $.each(_this.seriesdata, function (j, yData) {
                                for (var i = 0; i < yData.length; i++) {
                                    var x = yData[i][0];
                                    var y = yData[i][1];
                                    // var test = new Date(x);
                                    if (_this.chart.series[parseInt(j)])
                                        _this.chart.series[parseInt(j)].addPoint([x, y], true, false);
                                }
                            });
                        }
                    },
                    complete: poll,
                    error: function () { }
                });
            }, 5000);
        })();
    },
    setGraphData: function (data) {
        var _this = this;
        _this.seriesdata = {};
        $.each(data, function (index, value) {
            _this.seriesdata[index] = _this.convertDate(value);
        });
    },
    convertDate: function (data) {
        var _this = this;
        newData = [];
        for (var i = 0; i < data.data.length; i++) {
            var splitTime = data.data[i][0].split('.');
            var test = new Date(splitTime[0]);
            newData.push([test.getTime() + (window.ServerTimeZoneOffset * 60 * 60), parseInt(data.data[i][1]), data.name]);
        }
        return newData;
    }
};