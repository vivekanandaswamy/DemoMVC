Ecolab.Model.ChemicalModelProxy = function () {
};

Ecolab.Model.ChemicalModelProxy.prototype =
{
    ChemicalModelProxy: function (id, callBack, errorCallBack) {
        var url = "PlantChemicalController/{id}";
        var requestData = { "id": id };
        this.ApiRead("Chemical", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    loadChemicals: function (request, callBack, errorCallBack) {
        var url = "/api/PlantChemical/GetChemicalList";
        this.ApiRead("Chemical", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, request);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.ChemicalModelProxy.prototype = $.extend({}, Ecolab.Model.ChemicalModelProxy.prototype, base);
Ecolab.Model.ChemicalModelProxy.prototype.base = base;