Ecolab.Model.WasherGroupModelProxy = function () {
};

Ecolab.Model.WasherGroupModelProxy.prototype = {

    // event is for getting the washer groups from API controller.
    loadWasherGroupModelData: function (accountNumber, callBack) {
        var url = "Api/WasherGroup/GetWasherGroupDetails";

        // Passing parameter  to Api .
        var requestData = { "washergroupId":-1,"ecolabAccountNumber": accountNumber ,"pageNumber":1,"numberOfRecordsPerpage":12,"sortColumn":''};
        
        this.ApiRead("WasherGroup", url, function (response) { callBack(response); }, null, null, requestData);
    },

    //Event for calling the Api method for deleting the washergroup based on the requested id.
    onDeleteWasherGroupClicked: function (washerGroupData, callBack, errorCallBack) {

        // Api Url for deletion method.
        var url = "Api/WasherGroup/DeleteWasherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerGroupData);
    },

    loadAddEditWasherGroupModelData: function (washergroupId, accountNumber,callBack) {
        // Api Url for retrive data.
        var url = "Api/WasherGroup/GetWasherGroupDetails";

        // assigning the required data to the Api.
        var requestData = { "washergroupId": washergroupId, "ecolabAccountNumber": accountNumber,"pageNumber":0,"numberOfRecordsPerpage":0,"sortColumn":'' };

        this.ApiRead("WasherGroup", url, function (response) { callBack(response); }, null, null, requestData);
    },

    // Event for Api to create a new washer group
    createWasherGroup: function (washerGroupWebData, callBack) {
        var url = "/Api/WasherGroup/CreateWasherGroup";
        //var requestData = {washerGroupWebData,'1' };
        this.ServerRequest("POST", url, function (response) { callBack(response); }, null, null, washerGroupWebData);
    },

    // Event for Api to update the washer group details.
    updateWasherGroup: function (washerGroupWebData, accountNumber, callBack) {
        var url = "/Api/WasherGroup/UpdateWasherGroup";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, null, null, washerGroupWebData);
    },




}

var base = new Ecolab.Model.Common();
Ecolab.Model.WasherGroupModelProxy.prototype = $.extend({}, Ecolab.Model.WasherGroupModelProxy.prototype, base);
Ecolab.Model.WasherGroupModelProxy.prototype.base = base;
