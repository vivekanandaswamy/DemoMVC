﻿Ecolab.Views.Washer = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/Visualization/ConventionalWasher/Washer.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.Washer.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();

        var washerRowBottomMargin = 0;
        var washersCount = $(".washer-row").length;        

        if (washersCount > 0 && washersCount < 7) {
            washerRowBottomMargin = 35;
        } else if (washersCount >= 7 && washersCount < 12) {            
            var washerRowBottomPadding = parseInt($(".washer-row:first").css("padding-bottom"));
            var washerRowHeight = $(".washer-row:first").height() + washerRowBottomPadding;

            washerRowBottomMargin = (_this.data.WasherContainerHeight - (washersCount * washerRowHeight)) / washersCount;
        }

        $(".washer-row").css({ "margin-bottom": washerRowBottomMargin + "px"});
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
    }
};

