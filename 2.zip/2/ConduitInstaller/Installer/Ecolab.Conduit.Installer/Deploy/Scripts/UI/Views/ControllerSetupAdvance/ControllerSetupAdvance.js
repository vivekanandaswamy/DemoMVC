Ecolab.Views.ControllerSetupAdvance = function(options) {
    var defaults = {
        containerSelector: null,
        dynamicHTMLSelector: null,
        metaData: null,
        eventHandlers: {
            rendered: function() {},
            dynamicRendered: function() {},
            onSaveClicked: function() {},
            onCancelClicked: function() {},
            onRedirection: function() {},
            onSavePage: function() {}

        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'ControllerSetupAdvance',
        templateUri: './Scripts/UI/Views/ControllerSetupAdvance/ControllerSetupAdvance.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function() { _this.onRendered(); } }
    });
    this.dynamicTm = new TemplateManager({
        templateName: 'DynamicTM',
        templateUri: './Scripts/UI/Views/ControllerSetupAdvance/Dynamic.html',
        parameters: [],
        containerElement: this.options.dynamicHTMLSelector,
        eventHandlers: { onRendered: function() { _this.onDynamicUIRendered(); } }
    });
    //this.isDirty = false;
    this.dataList = {};
};
Ecolab.Views.ControllerSetupAdvance.prototype = {
    setData: function(data) {
        this.data = data;
        if (data.length > 0) {
            this.tm.Render(data[0].FieldGroupInfo[0], this);
        }
    },
    setDynamicUI: function(metaData) {
        if (this.options.accountInfo.MaxLevel > 7)
            metaData.Mode = "Edit";
        if (this.options.accountInfo.ControllerId != "-1") {
            metaData.ControllerId = this.options.accountInfo.ControllerId;
        } else {
            metaData.ControllerId = -1;
        }
        $.each(metaData[0].FieldGroupInfo, function(index, value) {
            if (metaData[0].FieldGroupInfo[index].FieldLabel == "Set PLC Time" || metaData[0].FieldGroupInfo[index].FieldLabel == "SetPLCTime") {
                metaData.DisplayOrder = metaData[0].FieldGroupInfo[index].FieldDO;
            }
        });

        // alert(metaData.DisplayOrder);
        metaData.MaxLevel = this.options.accountInfo.MaxLevel;
        this.metaData = metaData;
        this.dynamicTm.Render(metaData, this);
    },
    onRendered: function() {
        $('#btnContainer').addClass("hide");
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    onDynamicUIRendered: function() {
        $('#btnContainer').removeClass("hide");
        this.attachDynamicEvents();
        if (this.options.eventHandlers.dynamicRendered)
            this.options.eventHandlers.dynamicRendered();

        var flag = $(".tagsCheck").attr("checked");
        if (flag) {
            $(".tagsFields").attr("enabled", "enabled");
        } else {
            $(".tagsFields").attr("disabled", "disabled");
        }
        $(".tagsCheck, .tagsFields").parent().parent(".col-xs-10").appendTo("#generate_clmn");
        $("#generate_clmn").find(".col-lg-4.col-md-4.nopadding.marg_btm10").hide();
        $("#generate_clmn").find(".col-lg-3.col-md-3.marg_btm10").css("padding-left", "0");
    },
    attachEvents: function() {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find('#btnCancel').click(function() { _this.onCancelClicked(); });
        container.find('#btnSave').click(function() { return _this.onSaveClicked(); });
    },
    onCancelClicked: function() {
        //if (this.isDirty) {
        //    if (confirm("Do you want to save changes?")) {
        //        this.onSaveClicked();
        //    }
        //    window.location = './ControllerSetupList';
        //}
        //else {
        //    window.location = './ControllerSetupList';
        //}
        var retVal = this.options.eventHandlers.onRedirection('/ControllerSetupList');
        return retVal;
    },

    checkConfirmation: function() {
        var message = '';
        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var field = fieldGroup.FieldGroupInfo[j];
                if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue') != undefined) {
                    var initialValue = parseInt($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue'));
                    var textValue = parseInt($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val());
                    if (initialValue > textValue && field.FieldLabel != 'Preflush Time(sec)' && field.FieldLabel != 'Postflush Time(sec)') {
                        if (field.FieldLabel != 'No. of Chemical Valves')
                            message = message + '<strong>' + field.FieldLabel + '</Strong><br/>';
                        else
                            message = message + '<strong>' + field.FieldLabel + '</Strong>';

                    }
                }
            }
        }
        if (message) message += ' Value(s) are decreased do you want to continue?';
        return message;
    },

    cancelConfirmation: function () {
        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var field = fieldGroup.FieldGroupInfo[j];
                if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue') != undefined) {
                    var initialValue = parseInt($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue'));
                    var numerictextbox = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).data("kendoNumericTextBox");
                    numerictextbox.value(initialValue);
                }
            }
        }
    },


    getData: function() {
        var controllerId = 0;
        var controllerModelId = 0;
        var controllerTypeId = 0;
        var maxLevel = this.options.accountInfo.MaxLevel;
        if (this.options.accountInfo.ControllerId != "-1") {
            controllerId = this.options.accountInfo.ControllerId;
            controllerModelId = this.options.accountInfo.ControllerModelId;
            controllerTypeId = this.options.accountInfo.ControllerTypeId;
        }
        var dataArr = [];
        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var controller = {};
                var field = fieldGroup.FieldGroupInfo[j];
                controller.ControllerId = controllerId;
                controller.TabId = 3;
                controller.EcolabAccountNumber = this.options.accountInfo.EcolabAccountNumber;
                controller.ControllerModelId = controllerModelId;
                controller.ControllerTypeId = controllerTypeId;
                controller.FieldGroupId = field.FieldGroupId;
                controller.FieldId = field.FieldId;
                controller.FieldName = field.FieldName;
                if (field.FieldType == "CHECKBOX")
                    controller.Value = String($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is(':checked'));
                else if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is("label"))
                    controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).text();
                else
                    controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();

                controller.FieldTagValue = field.HasFieldTag;
                controller.FieldTagAddress = $("#Tag_Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();
                controller.Role = maxLevel;
                dataArr.push(controller);
            }
        }
        dataArr[0].PlcTagModelTags = this.getTagData();
        return dataArr;
    },

    getTagData: function() {
        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            var tags = [];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var field = fieldGroup.FieldGroupInfo[j];
                var tagAddress = $("#Tag_Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();
                var tagValues = {};
                var fieldTagId = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();
                tagValues.Address = tagAddress;
                tagValues.Value = fieldTagId;
                tagValues.IsValidTag = false;
                tagValues.Topic = "ULTRAX1";
                tagValues.TagType = field.FieldName;
                tags.push(tagValues);
            }
        }
        tags.ControllerId = this.options.accountInfo.ControllerId;
        var controllerType;
        if (this.options.accountInfo.ControllerTypeId == 1) {
            controllerType = "Allen Bradley";
        } else {
            controllerType = "Beckhoff";
        }
        tags.ControllerType = controllerType;
        return tags;
    },
    onSaveClicked: function() {
        //var arr = this.getTagData();
        return this.options.eventHandlers.onSavePage(this.checkConfirmation());
    },
    validate: function() {
        //$('#frmControllerSetupDetails').validate({
        //    // your other plugin options
        //});

        //$('.requiredField').each(function () {
        //    $(this).rules('add', {
        //        required: true,
        //        messages: {
        //            required: "Field cannot be empty."
        //        }
        //    });
        //});

        //var v2 = $('#frmControllerSetupDetails').validate();
        var validator = $("#frmControllerSetupDetails").kendoValidator().data("kendoValidator");
        return validator.validate();
    },

    attachDynamicEvents: function() {
        var container = $(this.options.containerSelector);
        $(".k-datetimepicker").kendoDatePicker({ format: "MM/dd/yyyy" });
        $(".k-datetimepicker input").prop("readonly", true);
        $(".k-numerictextbox").kendoNumericTextBox({
            format: "{0:n0}",
            min: 0,
            decimals: 0
        });
        $('.k-checkbox').kendoMobileSwitch({
            onLabel: "YES",
            offLabel: "NO",
            change: function(e) {
                $('#btnSave').removeAttr('disabled');
                $('#btnCancel').removeAttr('disabled');
            }
        });

        container.find('select').kendoDropDownList();
        container.find(".tooltip-wanter").tooltip({ selector: ".tooltip-info", placement: "top" });
        container.find(".tagsCheck").change(function() {
            var flag = $(".tagsCheck").attr("checked");
            if (flag) {
                $(".tagsFields").removeAttr("disabled", "disabled");
            } else {
                $(".tagsFields").attr("disabled", "disabled");
            }
        });
        $(".k-formatted-value").hover(function() {
            var originaltitle = $(this).next(".tooltip-info").attr("data-original-title");
            $(this).attr("data-original-title", originaltitle);
        });
    },

    onMetaDataSaved: function() {
        $("#errorDiv_msg").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERSAVEDSUCCESSFULLY", 'Controller Saved Successfully'));
    },

    onMetaDataSavedFailed: function(data, exception) {
        if (jQuery.type(exception) != "object") {

            $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append(exception);
        } else {
            if (exception.status == 300) {
                $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append(exception.message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXISTINTHEMACHINE', 'tags already exists in the Machine'));
            } else if (exception.status == 400) {
                $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append(exception.message + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'is / are invalid'));
            } else if (exception.status == 406) {
                $("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append($.GetLocaleKeyValue('FIELD_INVALIDSERVERDETAILS', 'Invalid Server Details'));
            }
        }
    },
    showMessage: function(message, isSuccess) {
        isSuccess ?
            $("#errorDiv_msg").attr('class', 'k-success-message').html(message)
            : $("#errorDiv_msg").attr('class', 'k-error-message').html(message);
    }
};