﻿Ecolab.Presenters.BasePresenter = function (options) {
    this.openDialogs = [];
    var defaults = {
        mainHeaderTemplate: 'MainHeader'
    };
    this.settings = $.extend(defaults, options);
    this.isDirty = false;
};

Ecolab.Presenters.BasePresenter.prototype = {
    /*** init *********************************************************/
    init: function () {
        this.initModel();
        this.initViews();
        this.afterInit();
    },

    initModel: function () {
        var _this = this;
        var factory = new Ecolab.Common.Factory();
        var eventHandlers = {};
        var alarmEventHandlers = {};
        this.addModelEventHandlers(eventHandlers);

        var modelOptions = {
            eventHandlers: eventHandlers,
            envInfo: this.settings.envInfo
        };

        this.addModelOptions(modelOptions);
        this.Model = factory.createModel(this.settings.model, modelOptions);
        this.AlarmModel = factory.createModel('AlarmModel', modelOptions);
        if (_this.settings.displayNavigation == true) {
            this.NavigationMenuModel = factory.createModel('NavigationMenuModel', modelOptions);
        }
    },
    initViews: function () {
        var _this = this;
        var blockUiDefaultsOverrides = {
            border: '',
            backgroundColor: '',
            width: '',
            top: '',
            left: '',
            'text-align': 'left',
            cursor: 'default'
        };
        if (!this.Views) {
            this.Views = {};
        }
        $.extend($.blockUI.defaults.css, blockUiDefaultsOverrides);
        $.blockUI.defaults.fadeOut = 0;
        $.blockUI.defaults.fadeIn = 0;
        this.Views.ModalPopUpTM = new TemplateManager({
            templateName: 'ModalPopUp',
            templateUri: '/Scripts/UI/CommonTemplates/ModelPopUp.html'
        });

        this.initCommonViews();

    },

    initCommonViews: function () {
        var _this = this;

        var blockUiDefaultsOverrides = {
            border: '',
            backgroundColor: '',
            width: '',
            top: '',
            left: '',
            'text-align': 'left'
        };

        $.extend($.blockUI.defaults.css, blockUiDefaultsOverrides);
        $.blockUI.defaults.fadeOut = 0;
        $.blockUI.defaults.fadeIn = 0;

        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
        this.showAlarmView();
        this.showAlarmCountView();
        if (_this.settings.displayNavigation == true)
            this.showLeftNavigationView();
        //Ecolab.Common.Utils.stretchLayout();

    },

    addModelEventHandlers: function (eventHandlers) {
        var _this = this;
        eventHandlers.onServerRequestError = function (data, errors) {
            _this.onServerRequestError(data, errors);
        };
        eventHandlers.onAlarmDataLoaded = function (data) {
            _this.onAlarmDataLoaded(data);
        };
        eventHandlers.onAlarmCountLoaded = function (data) {
            _this.onAlarmCountLoaded(data);
        };
        if (_this.settings.displayNavigation == true)
            eventHandlers.onNavigationMenuListLoaded = function (data) {
                _this.onNavigationMenuListLoaded(data);
            };
    },

    addModelOptions: function (modelOptions) {
    },

    afterInit: function () {
        var _this = this;
        this.trackChanges();
        this.loadAlarmCountView();
        if (_this.settings.displayNavigation == true)
            this.loadNavigationMenuListView();

        var tabContainerHt = $(window).height() - 215;
        $("#tabContainer").css("min-height", tabContainerHt)
    },

    /************************************************************************************************/
    //  Main Header
    /************************************************************************************************/
    showMainHeader: function () {
        var _this = this;


        this.Views.MainHeader = new Ecolab.Views.MainHeader({
            eventHandlers: {
                logoutClicked: function () {
                    _this.onLogoutClicked();
                },
                mainMenuHomeLinkClicked: function () {
                    _this.onMainMenuHomeLinkClicked();
                },
                mainMenuDashboardsLinkClicked: function () {
                    _this.onMainMenuDashboardsLinkClicked();
                },
                plantSetupClicked: function () {
                    _this.onPlantSetupClicked();
                },
                controllerSetupClicked: function () {
                    _this.onControllerSetupClicked();
                },

                onWasherGroupClicked: function () {
                    _this.onWasherGroupClicked();
                },
                storageTanksClicked: function () {
                    _this.onStorageTanksClicked();
                },
                visualizationsSetupClicked: function () {
                    _this.onVisualizationsSetupClicked();
                },
                onWasherClicked: function () {
                    _this.onWasherClicked();
                },
                onMainMenulnkProductionClicked: function () { _this.onMainMenulnkProductionClicked(); },
                onMainMenulnkChemicalLinkClicked: function () { _this.onMainMenulnkChemicalLinkClicked(); },
                onManualInputLinkClicked: function () { _this.onManualInputLinkClicked(); },
                myProfileClicked: function () { _this.myProfileClicked(); },
                onAlarmClicked: function () { _this.onAlarmClicked(); },
                onReportClicked: function () { _this.onReportClicked(); }
            },

            containerSelector: '#top-mainmenu-container',
            templateName: this.settings.mainHeaderTemplate
        });


        this.Views.MainHeader.setData(this.settings.accountInfo);


    },
    /**********************************************************************
    BreadCrumb
    **********************************************************************/
    showBreadCrumb: function (data) {
        var _this = this;

        if (!this.Views.BreadCrumb) {
            this.Views.BreadCrumb = new Ecolab.Views.BreadCrumb({
                eventHandlers: {
                    breadCrumbLinkClicked: function (navigateURL) {
                        _this.checkDirtyFormForNavigation(_this.prepareSaveAlertCallbackDataMap(navigateURL, null, null)); /* _this.checkDirtyFormForNavigateURL(navigateURL); */
                    }
                },
                containerSelector: '#breadCrumbContainer'
            });
        }

        this.Views.BreadCrumb.setData(data);
    },
    showPlantBreadCrumb: function (currentLocation, data) {
        var locations = [];
        //locations.push({ name: 'Set', url: '/Home' });
        switch (currentLocation) {
            case "plantSets":
                locations.push({
                    name: "Setup", url: '/PlantSetup'
                });
                locations.push({
                    name: data.name, url: data.url
                });
                break;
            case "Dashboards":
                locations.push({ name: data.name, url: data.url })
                break;
            case "Visualization":
                locations.push({
                    name: "Visualizations", url: data.url
                });
                locations.push({
                    name: data.name, url: data.url
                });
                break;
            case "manualInput":
                locations.push({
                    name: data.name, url: data.url
                });
                break;
            case "Home":
                locations.push({
                    name: data.name, url: data.url
                });
                break;
            case "Report":
                locations.push({ name: data.name, url: data.url })
        }
        this.showBreadCrumb(locations);
    },
    /************************************************************************************************/
    //  progress indicator
    /************************************************************************************************/

    showProgress: function (timeOut) {
        var _this = this;
        var progressContainer = $('#divProgressIndicator');
        var visibleArea = $('body');
        var top = (visibleArea.height() - progressContainer.height()) / 2;
        var left = (visibleArea.width() - progressContainer.width()) / 2;

        if (this.progressRequestCount == 0) {
            this.progressRequestCount++;

            this.progressTimeOutId = setTimeout(function () {
                _this.progressTimeOutId = null;

                if (_this.progressRequestCount != 0) {
                    if (_this.openDialogs.length > 0)
                        _this.openDialogs[_this.openDialogs.length - 1].block({
                            message: progressContainer, css: {
                                top: top, left: left
                            }
                        });
                    else
                        $.blockUI({
                            message: progressContainer, css: {
                                top: top, left: left
                            }
                        });
                }
            }, !timeOut ? 500 : timeOut);
        }
        else {
            this.progressRequestCount++;
        }
    },

    hideProgress: function () {
        if (this.progressRequestCount > 0)
            this.progressRequestCount--;

        if (this.progressRequestCount != 0)
            return;

        if (this.progressTimeOutId == null) {   //progress shown already
            if (this.openDialogs.length > 0)
                this.openDialogs[this.openDialogs.length - 1].unblock();
            else
                $.unblockUI();
        } else {  //still waiting for timeout to show progress
            clearTimeout(this.progressTimeOutId);
            this.progressTimeOutId = null;
        }
    },

    /************************************************************************************************/
    //  blockUI
    /************************************************************************************************/
    showModalDialog: function (options) {
        var _this = this;
        var container = $(options.ContainerSelector);

        this.openDialogs.push(container);
        container.css(options.css);
        var left = ($('body').width() - container.width()) / 2;
        var top = ($('body').height() - container.height()) / 2;

        options.css.left = left + 'px';
        options.css.top = top + 'px';

        var oneCallback = function (test, button, callback) {
            if (test() == true)
                button.unbind();

            callback();
        };

        if (this.openDialogs.length > 1)
            this.openDialogs[this.openDialogs.length - 2].block({
                message: container, css: options.css
            });
        else
            $.blockUI({
                message: container, css: options.css
            });

        if (options.EventHandlers.CancelClicked)
            container.find('.imbCancel, .cancel').unbind().bind("click", options.EventHandlers.CancelClicked).show();
        else
            container.find('.imbCancel').hide();

        if (options.EventHandlers.SaveClicked) {
            if (options.EventHandlers.SaveClicked.one)
                container.find('.imbSave').unbind().bind("click", function () {
                    oneCallback(options.EventHandlers.SaveClicked.one, container.find('.imbSave'), options.EventHandlers.SaveClicked);
                }).show();
            else
                container.find('.imbSave').unbind().bind("click", options.EventHandlers.SaveClicked).show();
        }
        else
            container.find('.imbSave').hide();

        if (options.EventHandlers.CloseClicked)
            container.find('.imbClose').unbind().bind("click", options.EventHandlers.CloseClicked).show();
        else
            container.find('.imbClose').hide();

        if (options.EventHandlers.SendClicked) {
            if (options.EventHandlers.SendClicked.one)
                container.find('.imbSend, .send').unbind().bind("click", function () {
                    oneCallback(options.EventHandlers.SendClicked.one, container.find('.imbSend, .send'), options.EventHandlers.SendClicked);
                });
            else
                container.find('.imbSend, .send').unbind().bind("click", options.EventHandlers.SendClicked);
        }
        else
            container.find('.imbSend').hide();
    },

    hideModalDialog: function () {
        if (this.openDialogs.length > 0)
            this.openDialogs.pop();

        if (this.openDialogs.length > 0)
            this.openDialogs[this.openDialogs.length - 1].unblock();
        else
            $.unblockUI();
    },

    showAlarmView: function (data) {
        var _this = this;
        if (!this.Views.Alarm) {
            this.Views.AlarmView = new Ecolab.Views.Alarm({
                eventHandlers: {
                },
                containerSelector: '#AlarmContainer'
            });
        }
    },

    showAlarmCountView: function (data) {
        var _this = this;
        if (!this.Views.AlarmCount) {
            this.Views.AlarmCountView = new Ecolab.Views.AlarmCount({
                eventHandlers: {
                },
                containerSelector: '#divAlarmCountContainer'
            });
        }
    },

    loadAlarmCountView: function () {
        var _this = this;
        _this.AlarmModel.loadAlarmCount();
        (function poll() {
            _this.timer = setTimeout(function () {
                _this.AlarmModel.loadAlarmCount();
                poll();
            }, 7000);
        })();
    },

    showLeftNavigationView: function (data) {
        var _this = this;
        if (!this.Views.NavigationMenu) {
            this.Views.NavigationMenuView = new Ecolab.Views.NavigationMenu({
                eventHandlers: {
                },
                containerSelector: '#divNavigationMenuContainer',
            });
        }
    },

    loadNavigationMenuListView: function () {
        var _this = this;
        _this.NavigationMenuModel.loadNavigationMenuList();
    },

    onPlantSetupClicked: function () {
        this.RedirectLocation('/PlantSetup');
    },

    onControllerSetupClicked: function () {
        this.RedirectLocation('/ControllerSetupList');
    },

    onWasherGroupClicked: function () {
        this.RedirectLocation('/WasherGroup');
    },
    onWasherGroupFormulaClicked: function () {
        this.RedirectLocation('/WasherGroupFormula');
    },
    onStorageTanksClicked: function () {
        this.RedirectLocation('/StorageTanks');
    },
    onWasherClicked: function () {
        this.RedirectLocation('/Washer');
    },
    onMainMenuHomeLinkClicked: function () {
        this.RedirectLocation('/Home');
    },
    onMainMenuDashboardsLinkClicked: function () {
        this.RedirectLocation('/Dashboard');
    },

    onMainMenulnkProductionClicked: function () {
        this.RedirectLocation('/TrendingChart/index?type=1');
    },

    onMainMenulnkChemicalLinkClicked: function () {
        this.RedirectLocation('/TrendingChart/index?type=2');
    },

    onManualInputLinkClicked: function () {
        this.RedirectLocation('/ManualUtility');
    },

    myProfileClicked: function () {
        window.location = '/MyProfile';
    },

    onAlarmClicked: function () {
        // window.location = '/Alarm';
        this.AlarmModel.loadAlarmData();
    },

    onReportClicked: function () {
        this.RedirectLocation('/Report');
    },


    /************************************************************************************************/
    //  Error Message
    /************************************************************************************************/
    onServerRequestError: function (data, errors) {
        var _this = this;
        var logout = false;
        var divErrorContainer = this.createErrorContainer();
        var options = {
            EventHandlers: {
                CancelClicked: function () {
                    _this.onErrorMessageCancelClicked(logout);
                }
            },
            ContainerSelector: '#divErrorContainer',
            css: {
                height: '220px', width: '332px', top: '0', left: '0'
            }
        };

        if (errors.status == 401) {
            divErrorContainer.find('#errorMessageText').text($.GetLocaleKeyValue('FIELD_SESSIONEXPIRED', 'Your session has been expired!! Please re-login'));
            logout = true;
            this.showModalDialog(options);
        }
        else {
            divErrorContainer.find('#errorMessageText').text($.GetLocaleKeyValue('FIELD_UNKNOWNERROR', 'Unknown error occurred. Please try again later!'));
            this.showModalDialog(options);
        }
    },

    onErrorMessageCancelClicked: function (logout) {
        if (logout) {
            document.location.reload();
            return;
        }
        this.hideModalDialog();
    },

    onAlarmDataLoaded: function (data) {
        this.Views.AlarmView.setData(data);
    },

    onAlarmCountLoaded: function (data) {
        this.Views.AlarmCountView.setData(data);
    },

    onNavigationMenuListLoaded: function (data) {
        this.Views.NavigationMenuView.setData(data);
    },

    //Creating the error message html dynamicall and adding it to body element
    //shoud a separate tpl be created ?
    createErrorContainer: function () {
        if ($('#divErrorContainer').length == 0) {
            var divErrorContainer = $("<div id='divErrorContainer'/>");
            var divErrorMessageHeader = $("<div class='errorMessageHeader popup_topborder roundCorenrTop5'><span>Error</span></div>");
            var divErrorMessageContainer = $("<div class='errorMessageContent'><span id='errorMessageText'></span></div>");
            var divErrorMessageFooter = $("<div class='errorMessageFooter popup_bottomborder roundCorenrBottom5'><a href='javascript:;' class='imbCancel button active'>OK</a></div>");
            divErrorContainer.append(divErrorMessageHeader)
                        .append(divErrorMessageContainer)
                        .append(divErrorMessageFooter)
                        .hide()
                        .appendTo('body');
        }
        return $('#divErrorContainer');
    },
    showPageFooter: function () {
        var _this = this;
    },
    convertToShortDateUS: function (dateObject) {
        return dateObject.format('MM/dd/yyyy');
    },
    formatCurrency: function (num) {
        return '"' + $.formatNumber(new String(num), {
            format: '$ #,###.00'
        }) + '"';
    },
    formatNumber: function (num) {
        return '"' + $.formatNumber(new String(num), {
            format: "#,##0"
        }) + '"';
    },
    /************************************************************************************************/
    //  Redirection and Track changes
    /************************************************************************************************/
    trackChanges: function () {
        var _this = this;
        $(document).on("change keypress", ".trackChange", function () {
            $(document).find('.buttonTrack').removeAttr('disabled');
            _this.isDirty = true;
        });
        $(document).on("click", ".cancelInlineEdit", function () {
            _this.isDirty = false;
        });
        $(document).on("click", ".buttonTrack", function () {
            _this.isDirty = false;
        });
        $(document).on("keyup", ".upperCase", function () {
            this.value = this.value.toLocaleUpperCase();
        });
    },
    RedirectLocation: function (url) {
        var _this = this;
        if (this.isDirty) {
            var Cdialog = $('#ConfirmDialog');
            Cdialog.removeClass('hide');
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue('FIELD_PENDINGCHANGES', 'Pending Changes'),
                BodyMessage: $.GetLocaleKeyValue('FIELD_DOYOUWANTTOSAVECHANGES', 'Do you want to save changes?'),
                Buttons: {
                    Yes: {
                        Callback: function () {
                            // _this.isDirty = false;

                            if (_this.savePage) {
                                _this.savePage();
                            }

                            Cdialog.addClass('hide');
                        },


                        CallbackParameters: null
                    },
                    No: {
                        Callback: function () {
                            window.location = url;
                        },
                        CallbackParameters: null
                    }


                }

            };
            this.Views.confirmDialog.setData(dialogOptions);
        } else {
            window.location = url;
        }
        return false;
    },
    HasDuplicateTags: function () {
        var tagsList = [];
        $(".tagfield").each(function () {
            var addr = $(this).val().trim();
            if (addr.length > 0)
                tagsList.push(addr);
        });

        //console.log(tagsList.arrHasDupes());
        return tagsList.arrHasDupes();
    }
};