Ecolab.Model.ControllerSetupListModel = function (options) {
    var defaultOptions = {
        eventHandlers: {

        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ControllerSetupListModelProxy = new Ecolab.Model.ControllerSetupListModelProxy();
};

Ecolab.Model.ControllerSetupListModel.prototype = {
    init: function () {
    },
    loadControllerSetupListData: function (pageIndex, callBackData) {
        var _this = this;
        _this.onDataLoaded("data", true);
    },
    onDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onControllerSetupListDataLoaded(data, callBackData);
    }
};

