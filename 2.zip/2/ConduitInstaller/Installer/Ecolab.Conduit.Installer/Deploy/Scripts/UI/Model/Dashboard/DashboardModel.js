Ecolab.Model.DashboardModel = function (options) {
    var defaultOptions = {
        eventHandlers: {

        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.DashboardModelProxy = new Ecolab.Model.DashboardModelProxy();
};
Ecolab.Model.DashboardModel.prototype = {
    init: function () {
    },

    loadDashboardList: function () {
        var _this = this;
        _this.DashboardModelProxy.loadDashboardList(function (data, callBackData) {
            _this.settings.eventHandlers.onDashboardListLoaded(data, callBackData);
        });
    },

};