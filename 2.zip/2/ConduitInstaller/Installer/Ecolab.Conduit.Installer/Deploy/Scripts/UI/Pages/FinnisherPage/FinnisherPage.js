
// JavaScript source code
Ecolab.Presenters.FinnisherPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.FinnisherTypes = null;
};
Ecolab.Presenters.FinnisherPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
        this.initAddEditFinnisherGroupView();
        this.initAddEditFinnisherView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onFinnisherGroupDataLoaded: function (data) { _this.onFinnisherGroupDataLoaded(data); },
            onFinnisherTypesLoaded: function (data) { _this.onFinnisherTypesLoaded(data); },
            onFinnisherGroupCreated: function (data) { _this.onFinnisherGroupCreated(data) },
            onFinnisherGroupCreationFailed: function (error, description) { _this.onFinnisherGroupCreationFailed(error, description); },
            onFinnisherGroupUpdated: function () { _this.onFinnisherGroupUpdated() },
            onFinnisherGroupUpdationFailed: function (error, description) { _this.onFinnisherGroupUpdationFailed(error, description); },
            onFinnisherGroupDeleted: function (data) { _this.onFinnisherGroupDeleted(data) },
            onFinnisherGroupDeletionFailed: function (error, description) { _this.onFinnisherGroupDeletionFailed(error, description); },
            onFinnisherCreated: function (data) { _this.onFinnisherCreated(data) },
            onFinnisherCreationFailed: function (error, description) { _this.onFinnisherCreationFailed(error, description); },
            onFinnisherUpdated: function (data,isInline) { _this.onFinnisherUpdated(data,isInline) },
            onFinnisherUpdationFailed: function (error, description, isInline) { _this.onFinnisherUpdationFailed(error, description, isInline); },
            onFinnisherDeleted: function (data) { _this.onFinnisherDeleted(data) },
            onFinnisherDeletionFailed: function (error, description) { _this.onFinnisherDeletionFailed(error, description); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function () { _this.onTabsRendered(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.FinnisherView) {
            this.Views.FinnisherView = new Ecolab.Views.Finnisher({
                containerSelector: '#divFinnisherContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { _this.onFinnisherRendered(); },
                    onAddFinnisherGroupClicked: function (data) { _this.onAddFinnisherGroupClicked(data); },
                    onEditFinnisherGroupClicked: function (data) { _this.onEditFinnisherGroupClicked(data); },
                    onDeleteFinnisherGroupClicked: function (data, finnisherGroupData) { _this.onDeleteFinnisherGroupClicked(data, finnisherGroupData); },
                    onAddFinnisherClicked: function (groupId) { _this.onAddFinnisherClicked(groupId); },
                    onEditFinnisherClicked: function (data) { _this.onEditFinnisherClicked(data); },
                    onDeleteFinnisherClicked: function (data, finnisherData) { _this.onDeleteFinnisherClicked(data, finnisherData); },
                    onInlineEditFinnisherClicked: function (data, isInline) { _this.onFinnisherUpdateClicked(data, isInline); },
                    onInlineEditFinnisherLinkClicked: function (e, data) { _this.onInlineEditFinnisherLinkClicked(e, data); },
                }
            });
        }
    },
    initAddEditFinnisherGroupView: function () {
        var _this = this;
        if (!this.Views.AddEditFinnisherGroupView) {
            this.Views.AddEditFinnisherGroupView = new Ecolab.Views.AddEditFinnisherGroup({
                containerSelector: '#addEditFinnisherGroupPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onFinnisherGroupSaveClicked: function (FinnisherGroupData) { _this.onFinnisherGroupSaveClicked(FinnisherGroupData); },
                    onFinnisherGroupUpdateClicked: function (FinnisherGroupData) { _this.onFinnisherGroupUpdateClicked(FinnisherGroupData); },

                }
            });
        }
    },
    initAddEditFinnisherView: function () {
        var _this = this;
        if (!this.Views.AddEditFinnisher) {
            this.Views.AddEditFinnisher = new Ecolab.Views.AddEditFinnisher({
                containerSelector: '#addEditFinnisherGroupPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onFinnisherSaveClicked: function (FinnisherData) { _this.onFinnisherSaveClicked(FinnisherData); },
                    onFinnisherUpdateClicked: function (FinnisherData) { _this.onFinnisherUpdateClicked(FinnisherData); },
                }
            });
        }
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup')
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabsRendered: function () {
        this.loadFinnisherGroupData();
    },
    onFinnisherRendered: function () {
        if (!this.FinnisherTypes)
            this.loadFinnisherTypes();
    },
    onAddFinnisherGroupClicked: function () {
        var data = this.Model.addNewFinnisherGroup();
        this.Views.AddEditFinnisherGroupView.setData(data);
    },
    onEditFinnisherGroupClicked: function (data) {
        this.Views.AddEditFinnisherGroupView.setData(data);
    },
    loadFinnisherGroupData: function () {
        this.Model.loadFinnisherGroupData();
    },
    loadFinnisherTypes: function () {
        this.Model.loadFinnisherTypes();
    },
    onFinnisherGroupDataLoaded: function (data) {
        var drData = {};
        drData.allowEdit = (this.settings.accountInfo.MaxLevel >= 7);
        drData.data = data;
        this.Views.FinnisherView.setData(drData);
    },
    onFinnisherTypesLoaded: function (FinnisherTypes) {
        var _this = this;
        this.FinnisherTypes = FinnisherTypes;
    },
    //Create Finnisher Group
    onFinnisherGroupSaveClicked: function (FinnisherGroupData) {
        this.Model.createFinnisherGroup(FinnisherGroupData);
    },
    createFinnisherGroup: function (FinnisherGroupData) {
        this.Model.createFinnisherGroup(FinnisherGroupData);
    },
    onFinnisherGroupCreated: function (FinnisherGroupData) {
        $('#myModal').modal('hide');
        this.Views.FinnisherView.showSucessMessage($.GetLocaleKeyValue('FIELD_RECORDADDEDSUCCESSFULLY','Record added successfully'));
        this.loadFinnisherGroupData();
    },
    onFinnisherGroupCreationFailed: function (FinnisherGroupData, description) {
        if (description == 301) {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_NAMEALREADYEXIST','Name already exists'));
        }
        else if (description == 302) {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_RECORDDOESNOTEXIST','Record does not exist'));
        }
        else {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_RECORDADDITIONFAILED','Record addition failed'));
        }
    },

    //Update Finnisher Group
    onFinnisherGroupUpdateClicked: function (FinnisherGroupData) {
        this.Model.updateFinnisherGroup(FinnisherGroupData);
    },
    onFinnisherGroupUpdated: function (FinnisherData) {
        $('#myModal').modal('hide');
        this.Views.FinnisherView.showSucessMessage($.GetLocaleKeyValue('FIELD_RECORDUPDATEDSUCCESSFULLY', 'Record updated successfully'));
        this.loadFinnisherGroupData();
    },
    onFinnisherGroupUpdationFailed: function (FinnisherData, description) {
        if (description == 301) {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_NAMEALREADYEXIST', 'Name already exists'));
        }
        else if (description == 302) {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_RECORDDOESNOTEXIST', 'Record does not exist'));
        }
        else {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_RECORDUPDATIONFAILED','Record updation failed'));
        }
    },

    //Delete Finnisher Group
    onDeleteFinnisherGroupClicked: function (id, finnisherGroupData) {
        var FinnisherGroup = finnisherGroupData;
        FinnisherGroup.Id = id;
        FinnisherGroup.Name = finnisherGroupData.FinnisherGroupName;
        var _this = this;
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Yes: {
                    Callback: function () {
                        _this.Model.deleteFinnisherGroup(FinnisherGroup);
                        $('#ConfirmDialog').hide();
                    }
                },

                No: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
               , blockSelector: 'body'
        });
    },
    onFinnisherGroupDeleted: function (FinnisherGroupData) {
        this.Views.FinnisherView.showSucessMessage($.GetLocaleKeyValue('FIELD_RECORDDELETEDSUCCESSFULLY','Record deleted successfully'));
        this.loadFinnisherGroupData();
    },
    onFinnisherGroupDeletionFailed: function (FinnisherGroupData, description) {
        if (description == 501 || description.status == 500) {
            this.Views.FinnisherView.showHomePageErrorMessage($.GetLocaleKeyValue('FIELD_METERASSOCIATED', 'It is not possible to delete as the group/machine connected with meters.'));
        }
        else {

            this.Views.FinnisherView.showHomePageErrorMessage($.GetLocaleKeyValue('FIELD_RECORDDELETIONFAILED', 'Record deletion failed'));
        }
    },

    /////////////Finnisher////////////////
    onAddFinnisherClicked: function (groupId) {
        var data = this.Model.addNewFinnisher(groupId, this.FinnisherTypes);
        this.Views.AddEditFinnisher.setData(data);
    },

    //Create Finnisher
    onFinnisherSaveClicked: function (FinnisherData) {
        this.Model.createFinnisher(FinnisherData);
    },
    onFinnisherCreated: function (FinnisherData) {
        $('#myModal').modal('hide');
        this.Views.FinnisherView.showSucessMessage($.GetLocaleKeyValue('FIELD_RECORDADDEDSUCCESSFULLY', 'Record added successfully'));
        this.loadFinnisherGroupData();
    },
    onFinnisherCreationFailed: function (FinnisherGroupData, description) {
        if (description == 301) {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_NAMEALREADYEXIST', 'Name already exists'));
        }
        else if (description == 302) {
            this.Views.FinnisherView.showErrorMessage('<label data-localize ="FIELD_NUMBERALREADYEXIST" class="k-error-message">Number already exists.Please use a different number</label>');
        }
        else {
            this.Views.FinnisherView.showErrorMessage($.GetLocaleKeyValue('FIELD_RECORDADDITIONFAILED', 'Record addition failed'));
        }
    },
    onInlineEditFinnisherLinkClicked: function (e, data) {
        this.Views.FinnisherView.showEditOnInlineEditLink(e, this.FinnisherTypes, data);
    },

    //update Finnisher
    onEditFinnisherClicked: function (data) {
        data.FinnisherTypes = this.FinnisherTypes;
        this.Views.AddEditFinnisher.setData(data);
    },

    onFinnisherUpdateClicked: function (FinnisherData, isInline) {
        this.Model.updateFinnisher(FinnisherData, isInline);
    },
    onFinnisherUpdated: function (FinnisherData) {
        $('#myModal').modal('hide');
        this.Views.FinnisherView.showSucessMessage($.GetLocaleKeyValue('FIELD_RECORDUPDATEDSUCCESSFULLY','Record updated successfully'));
        this.loadFinnisherGroupData();
    },
    onFinnisherUpdationFailed: function (FinnisherData, description, isInline) {
        if (description == 301) {
            if(isInline)
                this.Views.FinnisherView.showHomePageErrorMessage('<label data-localize ="FIELD_NAMEALREADYEXIST" class="k-error-message">Name already exists.Please use a different name</label>');
            else
                this.Views.FinnisherView.showErrorMessage('<label data-localize ="FIELD_NAMEALREADYEXIST" class="k-error-message">Name already exists.Please use a different name</label>');
        }
        else if (description == 302) {
            if (isInline)
                this.Views.FinnisherView.showHomePageErrorMessage('<label data-localize ="FIELD_NUMBERALREADYEXIST" class="k-error-message">Number already exists.Please use a different number</label>');
            else
                this.Views.FinnisherView.showErrorMessage('<label data-localize ="FIELD_NUMBERALREADYEXIST" class="k-error-message">Number already exists.Please use a different number</label>');
        }
        else {
            this.Views.FinnisherView.showErrorMessage('<label data-localize ="FIELD_RECORDUPDATIONFAILED" class="k-error-message">Record updation failed</label>');
        }
    },

    //Delete Finnisher
    onDeleteFinnisherClicked: function (FinnisherNumber, finnisherData) {
        var Finnisher = {};
        Finnisher.FinnisherType = {};
        Finnisher.GroupId = finnisherData.GroupId;
        Finnisher.FinisherId = finnisherData.FinisherId;
        Finnisher.Name = finnisherData.Name;
        Finnisher.FinnisherType.Id = finnisherData.FinnisherTypeId;
        var _this = this;
        Finnisher.Number = FinnisherNumber;
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', "Confirmation"),
            BodyMessage: $.GetLocaleKeyValue('FIELD_DELETECONFIRMATION', "Are you sure you want to delete?"),
            Buttons: {
                Yes: {
                    Callback: function () {
                        _this.Model.deleteFinnisher(Finnisher);
                        $('#ConfirmDialog').hide();
                    }
                },

                No: {
                    Callback: function () {
                        $('#ConfirmDialog').hide();
                    }
                }
            }
                , blockSelector: 'body'
        });
    },
    onFinnisherDeleted: function () {
        this.Views.FinnisherView.showSucessMessage($.GetLocaleKeyValue('FIELD_RECORDDELETEDSUCCESSFULLY', 'Record deleted successfully'));
        this.loadFinnisherGroupData();
    },
    onFinnisherDeletionFailed: function (FinnisherData, description) {
        if (description == 501) {
            this.Views.FinnisherView.showHomePageErrorMessage($.GetLocaleKeyValue('FIELD_METERASSOCIATED', 'It is not possible to delete as the group/machine connected with meters.'));
        }
        else {

            this.Views.FinnisherView.showHomePageErrorMessage($.GetLocaleKeyValue('FIELD_RECORDDELETIONFAILED','Record deletion failed'));
        }
    },
    savePage: function () {
        var view = this.Views.FinnisherView;
        if (view) {
            view.clearStatusMessage();
            if (view.validate()) {
                view.onSaveTrClicked();
                this.isDirty = false;
            }
        }
    },
}