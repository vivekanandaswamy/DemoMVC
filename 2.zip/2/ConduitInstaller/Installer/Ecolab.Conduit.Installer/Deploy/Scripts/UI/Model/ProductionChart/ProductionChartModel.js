﻿Ecolab.Model.ProductionChartModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onTunnelDataLoad: null,
            onParametersDataLoad:null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ProductionChartModelProxy = new Ecolab.Model.ProductionChartModelProxy();
};

Ecolab.Model.ProductionChartModel.prototype = {
    init: function () {
    },
    loadTunnelData: function () {
        var _this = this;
        this.ProductionChartModelProxy.loadTunnelData(function (tunnelData) {
            _this.settings.eventHandlers.onTunnelDataLoad(tunnelData);
        });
    },
    loadParametersData: function (id, chartId) {
        var _this = this;
        this.ProductionChartModelProxy.loadParametersData(id,chartId,function (data) {
            _this.settings.eventHandlers.onParametersDataLoad(data);
        });
    },
    loadByFilters: function (filters, callBack,current) {
        var _this = this;
        this.ProductionChartModelProxy.loadByFilters(filters, callBack, current
        //    function (data) {
        //    _this.settings.eventHandlers.onloadByFiltersLoad(data);
        //}
        );
    }
};

