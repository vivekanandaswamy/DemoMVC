Ecolab.Model.ControllerSetupAdvanceModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onGetMetaDataReceived: null,
            onMetaDataSaved: null,
            onMetaDataSavedFailed : null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.ControllerSetupAdvanceModelProxy = new Ecolab.Model.ControllerSetupAdvanceModelProxy();
};

Ecolab.Model.ControllerSetupAdvanceModel.prototype = {
    init: function () {
    },
    getMetaData: function (tabId, controllerId) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.getMetaData(tabId, controllerId, function (metaData) {
            _this.onGetMetaDataReceived(metaData);
        });
    },
    getMetaDataWithValues: function (controllerId, tab) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.getMetaDataWithValues(controllerId, tab, function (metaData) {
            _this.onGetMetaDataWithValuesReceived(metaData);
        });
    },
    saveMetaData: function (metaDatatoSave) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.saveMetaData(metaDatatoSave,
            function (data) { _this.onMetaDataSaved(data); },
            function (data, exception) { _this.onMetaDataSavedFailed(data, exception); });
    },
    updateMetaData: function (metaDatatoSave) {
        var _this = this;
        this.ControllerSetupAdvanceModelProxy.updateMetaData(metaDatatoSave,
            function () { _this.onMetaDataSaved(); },
            function (data, exception) { _this.onMetaDataSavedFailed(data, exception); });
    },
    getControllerUIData:function(controllerId, callBackData){
        var _this=this;
        this.ControllerSetupAdvanceModelProxy.getControllerUIData(controllerId, function (ControllerSetupData) {
            _this.onUIDataLoaded(ControllerSetupData, callBackData);
        });
    },
    onGetMetaDataReceived: function (metadata) {
        var _this = this;
        _this.settings.eventHandlers.onGetMetaDataReceived(metadata);
    },
    onGetMetaDataWithValuesReceived: function (metadata) {
        var _this = this;
        _this.settings.eventHandlers.onGetMetaDataWithValuesReceived(metadata);
    },
    onMetaDataSaved: function (data) {
        var _this = this;
        _this.settings.eventHandlers.onMetaDataSaved(data);
    },
    onMetaDataSavedFailed: function (data, exception) {
        var _this = this;
        _this.settings.eventHandlers.onMetaDataSavedFailed(data, exception);
    }
};

