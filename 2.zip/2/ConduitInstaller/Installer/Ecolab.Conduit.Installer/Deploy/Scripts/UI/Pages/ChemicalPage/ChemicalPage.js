Ecolab.Presenters.ChemicalPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ChemicalPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onChemicalDataLoaded: function (data) { _this.onChemicalDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.Model.loadChemicalData();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.ChemicalView) {
            this.Views.ChemicalView = new Ecolab.Views.Chemical(
                        {
                            containerSelector: '#tabChemicalsContainer',
                            eventHandlers: {
                                onRendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onChemicalNameChange: function (request, callBack) { _this.loadChemicals(request, callBack); },
                                onRuleClicked: function (id) { _this.navigateToConfigPage(id); }
                            }
                        });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANTSETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadChemicalDataData: function () {

        this.Model.loadChemicalData();
    },
    onChemicalDataLoaded: function (data) {
        this.Views.ChemicalView.setData(this.settings.accountInfo);
    },
    loadChemicals: function (request, callBack) {

        this.Model.loadChemicals(request, callBack);
    }
};