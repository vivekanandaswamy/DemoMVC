Ecolab.Views.WasherGroupTabs = function (options) {
var defaults = {
    containerSelector: null,
    eventHandlers: {
        onRedirection: function () { }        
    },
    accountInfo: null
};

this.options = $.extend(defaults, options);
var _this = this;
this.data = null;

this.tm = new TemplateManager({
    templateName: 'WasherGroup',
    templateUri: '/Scripts/UI/Views/WasherGroup/WasherGroupTabs.html',
    containerElement: this.options.containerSelector,
    eventHandlers: { onRendered: function () { _this.onRendered(); } }
});
};
Ecolab.Views.WasherGroupTabs.prototype = {

    // sets the washer group data from presenter js.
    setData: function (data) {
       // data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find('#tabWashergroup').click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/WasherGroup');
            return retVal;
        });
    }    
}
