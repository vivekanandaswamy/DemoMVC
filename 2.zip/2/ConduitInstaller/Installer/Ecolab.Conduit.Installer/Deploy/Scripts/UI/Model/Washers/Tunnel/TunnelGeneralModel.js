// JavaScript source code
Ecolab.Model.TunnelGeneralModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDropDownDataLoaded: null,
            onSaved: function () { },
            onSizeListLoaded: function () { },
            onSaveFailed: function () { },
            onTunnelDataLoaded: function (data) { },
            onUpdate: function () { },
            onUpdateFailed: function () { },
            onWasherModeListLoaded: function () { },
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.TunnelGeneralModelProxy = new Ecolab.Model.TunnelGeneralModelProxy();
};

Ecolab.Model.TunnelGeneralModel.prototype = {
    init: function () {
    },
    loadDropDownsData: function (ecoLabAccountNumber, regionId, washerGroupId) {
        var _this = this;
        _this.TunnelGeneralModelProxy.loadDropDownsData(ecoLabAccountNumber, regionId, washerGroupId, function (data) {
            _this.settings.eventHandlers.onDropDownDataLoaded(data);
        });
    },
    getWasherModeList: function (controllerId, ecoLabAccountNumber) {
        var _this = this;
        _this.TunnelGeneralModelProxy.getWasherModeList(controllerId, ecoLabAccountNumber, function (data) {
            _this.settings.eventHandlers.onWasherModeListLoaded(data);
        });
    },
    save: function (tunnelData) {
        var _this = this;
        var tunnelDataOriginal = tunnelData;
        _this.TunnelGeneralModelProxy.saveTunnelData(tunnelData, function (data) {
            _this.settings.eventHandlers.onSaved(data, tunnelDataOriginal);
        },
        function (error, description) {
            _this.settings.eventHandlers.onSaveFailed(description, tunnelDataOriginal);
        });
    },
    update: function (tunnelData) {
        var _this = this;
        var tunnelDataOriginal = tunnelData;
        _this.TunnelGeneralModelProxy.updateTunnelData(tunnelData, function (data) {
            _this.settings.eventHandlers.onUpdate(tunnelDataOriginal);
        },
        function (error, description) {
            _this.settings.eventHandlers.onUpdateFailed(description, tunnelData);
        });
    },
    getSizeList: function (model) {
        var _this = this;
        _this.TunnelGeneralModelProxy.getSizeList(model, function (data) {
            _this.settings.eventHandlers.onSizeListLoaded(data);
        });
    },
    getTunnelData: function (id, washerGroupId, ecoLabAccountNo, regionId) {
        var _this = this;
        _this.TunnelGeneralModelProxy.getTunnelData(id, washerGroupId, ecoLabAccountNo, regionId, function (data) {
            _this.settings.eventHandlers.onTunnelDataLoaded(data);
        });
    },
}