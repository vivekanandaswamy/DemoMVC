﻿Ecolab.Views.ManualUtility = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null,
            onDeleteClicked: null,
            onWasherGroupChange: null,
            onFormulaChange: null,
            onEditManualUtilityClicked: null,
            onUpdateInlineClicked: null
        }
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: '/Scripts/UI/Views/ManualInput/ManualUtility/ManualUtility.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};

Ecolab.Views.ManualUtility.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "101":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESS', 'Saved successfully') + '</label>';
                break;
            case "301":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEDSUCCESS', 'Deleted successfully') + '</label>';
                break;
            case "401":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_DELETEFAILED', 'Deletion failed') + '</label>';
                break;
            case "501":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save Failed') + '</label>';
                break;
        }
        var messageDiv = container.find('.divErrorMsg');
        messageDiv.html(errLabel);
    },
    onRendered: function () {
        var _this = this;
        $('.main-menu-item').removeClass('active');
        $('.main-menu-item-Manual').addClass('active');
        $('.tabManualUtility').addClass('active');
        this.attachEvents();
        $('#tblManualUtility').tablesorter({
            headers: {
                0: {
                    sorter: false
                }
            }
        });
       

        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find(".btnCancel").click(function () {
            _this.clearMessage();
        });

        container.find(".btnSave").click(function () {
            _this.onSaveClicked();
        });

        //When edit inline button is clicked
        container.find(".editUserInline").click(function () {
            _this.clearMessage();
            var tr = $(this).parents('.trEditable').first().addClass('dirty');;
            tr.find(".noneditable").hide();
            tr.find(".editable").show();
        });

        //Event to inline cancel
        container.find(".cancelUserInline").click(function () {
            container.find(".noneditable").show();
            container.find(".editable").hide();
            $(this).parents('.trEditable').first().removeClass('dirty');
            container.find('span.errorMsg').text("");
            var tr = $(this).parents('.trEditable').first()
            _this.restoreData(tr);
        });

        //Event to check update on inline clicked
        container.find(".updateUserInline").click(function () {
            _this.onSaveTrClicked();
            //var tr = $(this).parents('.trEditable').first().addClass('dirty');
            //_this.onUpdateInlineClicked(_this.getRowUtility(tr));
        });
        //for popup updation
        container.find(".lnkUpdateUser").click(function () {
            var tr = $(this).parents('.trEditable').first().addClass('dirty');
            _this.onEditManualUtilityClicked(tr);
        });


        container.find(".btnDelete").click(function () {
            _this.onDeleteClicked();
        });

        container.find(".txtNewValue").keyup(function () {
            var tr = $(this).parents('.trEditable').first();
            _this.calculateUsage(tr);
        })
    },

    onSaveTrClicked: function () {
        _this = this
        var tr = $('#tblManualUtility').find('.dirty');
        _this.onUpdateInlineClicked(_this.getRowUtility(tr));
    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "*"
       );

         $.validator.addMethod(
                "maxLimit",
                function (value, element, regexp) {
                    var check = false;
                    //var settings = $('#formManualUtility').validate().settings;
                    //settings.errorContainer = container.find('#errorMaxLimit')
                    value = parseInt(value)
                    var maxLimit = parseInt(container.find('.trEditable').attr('data-maxvaluelimit'))
                    if (!isNaN(value)) {
                        if (value < maxLimit)
                            return true;
                        else
                            return false;
                    }
                    else
                        return true;
                },
                "*"
        );
        var v1 = container.find('#formManualUtility').validate({
            rules: {
                txtNewValue: {
                    required: true,
                    regex: pattern1,
                    maxLimit: true,
                }
            },
            messages: {
                txtNewValue: {
                    required: "*",
                    regex: "*",
                    maxLimit: "*",
                },
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#formManualUtility').valid();
        return v2;
    },

    onUpdateInlineClicked: function (data) {
        var _this = this;
        this.clearMessage();
        if (this.options.eventHandlers.onSaveClicked) {
            if (_this.validate() == true) {
                this.options.eventHandlers.onSaveClicked(data);
            }
            else {
                return false;
            }
        }
    },

    onEditManualUtilityClicked: function (tr) {
        var _this = this;
        this.clearMessage();
        if (this.options.eventHandlers.onEditManualUtilityClicked) {
            this.options.eventHandlers.onEditManualUtilityClicked(this.getUtilityForPopup(tr));
        }
    },

    restoreData: function (tr) {
        $(tr).find("#txtNewRecordingDate").val($(tr).find(".date_1").text().trim());
        $(tr).find("#txtNewValue").val($(tr).find(".value_1").text().trim());
        $(tr).find("#txtNewUsage").val($(tr).find(".usage_1").text().trim());
        $(tr).find(".usage_1").text($(tr).find(".hdnusage_1").text().trim());
    },


    //getting tr values to save inline
    getRowUtility: function (tr) {
        var container = $(this.options.containerSelector);
        var ManualUtilityViewModel = {};
        var Utility = [];
        var objManualUtilityModel = {};
        objManualUtilityModel.RecordedDate = $(tr).find(".date_1").text();
        objManualUtilityModel.Value = $(tr).find("#txtNewValue").val();
        objManualUtilityModel.id = $(tr).find("#txtNewValue").attr("data-id");
        if ($(tr).find(".date_0").text() == "") {
            objManualUtilityModel.Usage = $(tr).find("#txtNewValue").val();
        }
        else {
            objManualUtilityModel.Usage = $(tr).find(".usage_1").text();
        }
        Utility.push(objManualUtilityModel);
        ManualUtilityViewModel.Utility = Utility;
        return ManualUtilityViewModel;
    },

    getUtilityForPopup: function (tr) {
        var container = $(this.options.containerSelector);
        var ManualUtilityViewModel = {};
        var Utility = [];
        ManualUtilityViewModel.Description = $(tr).find('.meterName').text();
        ManualUtilityViewModel.MeterTickUnit = $(tr).find('.uom').text();
        ManualUtilityViewModel.UtilityTypeName = $(tr).find('.utilitytype').text();
        ManualUtilityViewModel.LocationName = $(tr).find('.location').text();
        ManualUtilityViewModel.MeterId = $(tr).find("#txtNewValue").attr("data-meterid");
        ManualUtilityViewModel.MaxValueLimit = $(tr).attr("data-maxvaluelimit");
        for (var i = 0; i < 2; i++) {
            var objManualUtilityModel = {};
            objManualUtilityModel.RecordedDate = $(tr).find(".date_" + i).text();
            objManualUtilityModel.Value = $(tr).find(".value_" + i).text();
            objManualUtilityModel.Usage = $(tr).find(".usage_" + i).text();
            objManualUtilityModel.Id = $(tr).find("#txtNewValue").attr("data-id");
            Utility.push(objManualUtilityModel);
        }
        ManualUtilityViewModel.Utility = Utility;
        return ManualUtilityViewModel;
    },


    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('.divErrorMsg').html('');
    },

    calculateUsage: function (tr) {
        var container = $(this.options.containerSelector);
        //var tr = container.find('.trrecording')
        var maxVal = $(tr).attr('data-maxvaluelimit')
        var currentUsage = 0;
        var prevUsage = 0;
        var currValue = 0;
        var prevValue = 0;
        var usage = 0;
        currentUsage = parseInt($(tr).find(".usage_1").text());
        currValue = parseInt($(tr).find(".txtNewValue").val());

        if (currValue > maxVal)
        {
            var length = maxVal.toString().length;
            $(tr).find(".txtNewValue").attr("maxlength",length);
        }

        prevUsage = parseInt($(tr).attr("data-prevusage"));
        prevValue = parseInt($(tr).attr("data-prevvalue"));

        if (currValue < prevValue) {
            usage = (maxVal - prevValue) + currValue;
        }
        else {
            usage = currValue - prevValue;
        }

        if (!isNaN(usage)) {
            if (currValue >= 0)
                $(tr).find('.usage_1').text(usage);
        }
        else {
            $(tr).find('.usage_1').text(currValue);
        }

    },

}