Ecolab.Model.ShiftLaborModelProxy = function () {
};

Ecolab.Model.ShiftLaborModelProxy.prototype =
{
    loadShiftLaborData: function (callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/Get";
        this.ApiRead("ShiftLabor", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    createShift: function (requestData, callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/CreateShift";
        this.ServerRequest("POST", url, function (response) { callBack( response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteShift: function (shiftId, dayId, callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/DeleteShift/{dayId}?shiftId={shiftId}";
        var requestData = { "dayId": dayId, "shiftId": shiftId };
        this.ApiRead("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateShift: function (callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/EditShiftLabor/{shiftLaborData}";
        var requestData = { "shiftLaborData": shiftLaborData };
        this.ApiRead("ShiftLabor", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    GetShiftToEdit: function (shiftId, dayId, callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/GetShiftToEdit/{dayId}?shiftId={shiftId}";
        var requestData = { "dayId": dayId, "shiftId": shiftId };
        this.ApiRead("GET", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteBreak: function (shiftId, dayId, breakId, callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/DeleteBreak/{shiftId}?dayId={dayId}&breakId={breakId}";
        var requestData = { "shiftId": shiftId, "dayId": dayId, "breakId": breakId };
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    createLabor: function (requestData, callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/CreateLabor";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    deleteLabor: function (id,callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/DeleteLabor/{id}";
        var requestData = { "id": id };
        this.ApiRead("ShiftLabor", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    updateLabor: function (callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/EditLabor/{laborData}";
        var requestData = { "laborData": laborData };
        this.ApiRead("ShiftLabor", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },
    getLaborTypeAndLocation: function (callBack,errorCallBack) {
        var url = "/Api/ShiftLabor/GetLaborTypeAndLocation";
        this.ApiRead("ShiftLabor", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadLaborCost: function (id, callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/FetchLaborCost/{id}";
        var requestData = { "id": id };
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (cost, exception) { errorCallBack(cost, exception); }, null, requestData);
    },
    FetchTargetProductionDetails: function (callBack, errorCallBack) {
        var url = "/Api/ShiftLabor/FetchTargetProductionDetails";
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (cost, exception) { errorCallBack(cost, exception); }, null, null);
    }

};

var base = new Ecolab.Model.Common();
Ecolab.Model.ShiftLaborModelProxy.prototype = $.extend({}, Ecolab.Model.ShiftLaborModelProxy.prototype, base);
Ecolab.Model.ShiftLaborModelProxy.prototype.base = base;