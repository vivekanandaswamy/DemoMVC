﻿Ecolab.Presenters.ConventionalWasherPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.dashboardData = null;
};
Ecolab.Presenters.ConventionalWasherPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initDashboardView();
        this.initWasherView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onDashboardDataLoad: function (data) { _this.onDashboardDataLoaded(data); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.loadDashboardData();
    },
    initDashboardView: function () {
        var _this = this;
        if (!this.Views.ConventionalWasherView) {
            this.Views.ConventionalWasherView = new Ecolab.Views.ConventionalWasher(
                        {
                            containerSelector: '#visualizationContainer',
                            eventHandlers: {
                                rendered: function () { _this.onDashboardRendered(); },
                                reload: function () { _this.loadDashboardData(data); },
                            }
                        });
        }
    },
    initWasherView: function () {
        var _this = this;
        if (!this.Views.WasherView) {
            this.Views.WasherView = new Ecolab.Views.Washer(
                        {
                            containerSelector: '#divWasherBatchContainer',
                            eventHandlers: {
                                rendered: function () { }
                            }
                        });
        }
    },
    loadDashboardData: function (
        ) {
        var _this = this;
        var data = this.getParams();
        _this.Model.loadDashboardData(data);
        (function poll() {
            _this.timer = setTimeout(function () {
                _this.Model.loadDashboardData(data);
                poll();
            }, 2000);
        })();
    },
    getParams: function () {
        var _this = this;
        var data = {};
        if (_this.getQueryStringByName('id')) {
            data.Id = _this.getQueryStringByName('id');
        }
        if (_this.getQueryStringByName('typeId')) {
            data.TypeId = _this.getQueryStringByName('typeId');
        }
        return data;
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    onDashboardDataLoaded: function (data) {
        this.dashboardData = data;
        this.Views.ConventionalWasherView.setData(data);
    },
    onDashboardRendered: function () {
        var _this = this;
        var viewPortWidth = $(window).width();
        var washerRowMiddleWidth = $('#washer-row-middle').width() - 3;
        var washerRowLeftWidth = $('#washer-row-left').width();
        var divWasherBatchContainerHeight = $("#divWasherBatchContainer").height();
        var minutesToDispaly = this.dashboardData.HoursToDisplay * 60;
        var pixelPerMinute = washerRowMiddleWidth / minutesToDispaly;
        $(".half-hr-time-line, .hr-time-line").css({ width: 30 * pixelPerMinute });
        $(".hr-time:not(:last)").css({ width: 60 * pixelPerMinute });
        var pixelPerSecond = washerRowMiddleWidth / (minutesToDispaly * 60);
        this.dashboardData.Pixel = pixelPerSecond;
        this.dashboardData.LeftWidth = washerRowLeftWidth;
        this.dashboardData.WasherContainerHeight = divWasherBatchContainerHeight;
        this.Views.WasherView.setData(this.dashboardData);
    }
};