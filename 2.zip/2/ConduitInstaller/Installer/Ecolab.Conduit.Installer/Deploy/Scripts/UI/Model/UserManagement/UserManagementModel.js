// JavaScript source code
Ecolab.Model.UserManagementModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onUserManagementDataLoaded: null,
            onUserRolesLoaded: null,
            onUserManagementCreated: null,
            onUserManagementCreationFailed: null,
            onUserManagementUpdated: null,
            onUserManagementUpdationFailed: null,
            onUserManagementDeleted: null,
            onUserManagementDeletionFailed: null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.UserManagementModelProxy = new Ecolab.Model.UserManagementModelProxy();
};

Ecolab.Model.UserManagementModel.prototype = {
    init: function () {
    },
    addNewUserManagement: function () {
        return {
            UserNumber: -1,
            FirstName: "",
            LastName: "",
            LoginName: "",
            Password: "",
            Email: "",
            ContactNo: "",
            LevelId: -1,
            RoleName: "",
            Roles: []
        };
    },
    loadUserManagementData: function () {
        var _this = this;
        _this.UserManagementModelProxy.loadUserManagementData(function (UserManagementData) {
            _this.settings.eventHandlers.onUserManagementDataLoaded(UserManagementData);
        });
    },
    loadUserRoles: function () {
        var _this = this;
        _this.UserManagementModelProxy.loadUserRoles(function (userRoles) {
            _this.settings.eventHandlers.onUserRolesLoaded(userRoles);
        });
    },
    createUserManagement: function (userData) {
        var _this = this;
        this.UserManagementModelProxy.createUserManagement(userData, function (data) {
            _this.settings.eventHandlers.onUserManagementCreated(data);
        }, function (error, description) { _this.settings.eventHandlers.onUserManagementCreationFailed(error, description); });
    },
    updateUserManagement: function (userData, isInline) {
        var _this = this;
        this.UserManagementModelProxy.updateUserManagement(userData, function (data) {
            _this.settings.eventHandlers.onUserManagementUpdated(data);
        }, function (error, description) { _this.settings.eventHandlers.onUserManagementUpdationFailed(error, description, isInline); });
    },
    deleteUserManagement: function (id) {
        var _this = this;
        this.UserManagementModelProxy.deleteUserManagement(id, function (data) {
            _this.settings.eventHandlers.onUserManagementDeleted(data);
        }, function (error, description) { _this.settings.eventHandlers.onUserManagementDeletionFailed(error, description); });
    },
    loadContacts: function (request, callBack) {
        this.UserManagementModelProxy.loadContacts(request, callBack);
    }
}