Ecolab.Views.TunnelCompartment = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: { onRedirection: function () { } },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.products = [];

    this.tm = new TemplateManager({
        templateName: 'TunnelCompartment',
        templateUri: '/Scripts/UI/Views/Washers/Tunnel/Compartment.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.TunnelCompartment.prototype = {
    // sets the tunnel compartments data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);

        var table = $("#pumpTable tbody");
        var tablearr = [];
        var _this = this;
        table.find('tr').each(function (i, el) {
            var Id = $(this).attr('id');
            if (Id != undefined) {
                $("#ddlPumps option[value=" + Id + "]").remove();
            }
        });
        $('#ddlWaterInlet').trigger('change');
        this.updateFlag();
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();
        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        container.find("#btnSaveCompatment").click(function () {
            _this.clearMassage();
            _this.onSaveClicked();
        });

        container.find('#btnCompartmentGeneralPrint').click(function () {
            var data = {
                EcolabAccountNumber: _this.data.EcoLabAccountNumber,
                WasherGroupId: _this.data.WasherGroupId,
                PageTitle: "Tunnel General",
                WasherId: _this.data.Id,
                ControllerId: _this.data.ControllerId,
                RegionId: _this.data.RegionId,
                NumberOfCompartments: _this.options.accountInfo.Compartments,
            };
            var data = JSON.stringify(data);
            var retVal = _this.CompartmentPrint(data);
            return retVal;
        });

        $('#ddlCompatment').change(function () {
            _this.clearMassage();
            _this.onCompartmentChange(parseInt($(this).val()))
        });
        $('#lnkPrev').click(function () {
            _this.clearMassage();
            var compartmentId = parseInt($('#ddlCompatment').val());
            if (compartmentId > 1) {
                var setId = compartmentId - 1;
                $('#ddlCompatment').val(setId)
                $('#ddlCompatment').trigger('change');
            }
        });
        $('#lnkNext').click(function () {
            _this.clearMassage();
            var compartmentId = parseInt($('#ddlCompatment').val());
            var totalCompartments = parseInt($('#hNoofCompartments').val());
            var setId = compartmentId + 1;
            if (setId <= totalCompartments) {
                $('#ddlCompatment').val(setId)
                $('#ddlCompatment').trigger('change');
            }
        });
        $('.cmprt-click').click(function () {
            _this.clearMassage();
            var compartmentId = $(this).attr('id');
            $('#ddlCompatment').val(compartmentId)
            $('#ddlCompatment').trigger('change');
        });
        container.find("#btnAddPump").click(function () {
            _this.clearMassage();
            var val = $('#ddlPumps').val();
            var eqpid = $('#ddlPumps').find('option:selected').attr('eqp-id');
            var product = $('#ddlPumps').find('option:selected').attr('product').trim().replace(' ', '_');
            if (val != '') {
                _this.AddPump(val, product, eqpid)
            }
            else {
            }
        });
        $('#ddlWashZone, #ddlWaterFlow').change(function () {
            _this.clearMassage();
        });
        $('#ddlWaterInlet').change(function () {
            _this.clearMassage();
            var val = $(this).val();
            if (val == 2) {
                $('#ddlWashZone').val('');
                var selectedOption = $('#ddlWashZone').find(":selected").text();
                $('#ddlWashZone').next(".holder").text(selectedOption);
                $('#ddlWashZone').attr('disabled', 'disabled');
                $('#ddlWashZone').parent('.select-wrapper').addClass('disabled');
                $('#divChemical').hide();
            }
            else {
                $('#ddlWashZone').removeAttr('disabled');
                $('#ddlWashZone').parent('.select-wrapper').removeClass('disabled');
                $('#divChemical').show();
            }
        });
        $('#btnCancel').click(function () {
            _this.clearMassage();
            _this.onCancleClick();
        });
        $('.deleteWashStep').live('click', function () {
            _this.clearMassage();
            if (_this.options.eventHandlers.deleteConformation)
                var procced = _this.options.eventHandlers.deleteConformation($(this));
        });
    },
    AddPump: function (val, product, eqpid) {
        var row = '"<tr id=' + val + '><td class="tableRows align-center"> <a class="deleteWashStep" val=' + val + ' eqpid=' + eqpid + ' product=' + product + ' href="javascript:void(0);"><span class="k-icon k-delete noneditable"></span></a></td>' +
                                        '<td class="tableRows"> <span> P/V' + eqpid + '</span></td>' +
                                        '<td class="tableRows"><span>' + product.replace('_', ' ') + '</span></td></tr>'

        $("#pumpTable tbody").append(row);
        $("#ddlPumps option[value=" + val + "]").remove();
        $('#ddlPumps').val(' ');
        var selectedOption = $('#ddlPumps').find(":selected").text();
        $('#ddlPumps').next(".holder").text(selectedOption);
        //$('#chkDosagePoint').attr('checked', true);
    },
    getData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        var table = $("#pumpTable tbody");
        var tablearr = [];
        var _this = this;
        table.find('tr').each(function (i, el) {
            var Id = $(this).attr('id');
            if (Id != undefined) {
                tablearr.push({
                    ControllerEquipmentSetupId: Id,
                    IsDeleted: 0
                });
            }
        });

        var deletedProducts = this.products;
        $.each(deletedProducts, function (key, value) {
            var Id = value.Id;

            tablearr.push({
                ControllerEquipmentSetupId: Id,
                IsDeleted: 1
            });
        });

        if ($('#ddlWaterInlet').val() == 2) {
            $.each(tablearr, function (key, value) {
                value.IsDeleted = 1;
            });
        }

        return {
            Id: container.find('#hTunnelId').val(),
            CompartmentNumber: container.find('#ddlCompatment').val(),
            WashStepId: container.find('#ddlWashZone').val(),
            WaterinletDrainId: container.find('#ddlWaterInlet').val(),
            WaterFlowId: container.find('#ddlWaterFlow').val(),
            WaterLevel: container.find('#txtWaterLevel').val(),
            TemperatureControlByPMR: container.find('#chkTempControl').is(":checked") ? true : false,
            UsePressExtractWater: container.find('#chkPressExtract').is(":checked") ? true : false,
            SplitCompartment: container.find('#chkSpilCompartment').is(":checked") ? true : false,
            RecycledWaterInlet: container.find('#chkRecycledWater').is(":checked") ? true : false,
            Steam: container.find('#chkStream').is(":checked") ? true : false,
            EcolabAccountNumber: container.find('#hEcoLabAccountNumber').val(),
            WasherGroupId: container.find('#hWashergroupId').val(),
            PumpAssociationList: tablearr,
        }
    },
    updateFlag: function () {
        if (this.options.eventHandlers.updateFlag)
            this.options.eventHandlers.updateFlag();
    },
    validate: function () {
        _this = this;
        var container = $(this.options.containerSelector);

        var v1 = container.find('#frmTunnelCompartments').validate({
            rules: {
                ddlWashZone: {
                    required: true,
                },
                ddlWaterInlet: {
                    required: true,
                },
                ddlWaterFlow: {
                    required: true,
                },
                txtWaterLevel: {
                    required: true,
                    number: true
                },
            },
            messages: {
                ddlWashZone: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWASHZONE', 'Please select Wash Zone'),
                },
                ddlWaterInlet: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWATERINLETDRAIN', 'Please select Water Inlet/Drain'),
                },
                ddlWaterFlow: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASESELECTWATERFLOW', 'Please select Water Flow'),
                },
                txtWaterLevel: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERWATERLEVEL', 'Please enter Water Level'),
                    number: $.GetLocaleKeyValue('FIELD_PLEASEENTERNUMERICSONLY', 'Please Enter numerics only'),
                },
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.k-error-message"));
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.k-error-message"));
                }
            }
        });
        var v2 = container.find('#frmTunnelCompartments').valid();
        return v2;
    },
    onSaveClicked: function () {
        if (this.options.eventHandlers.savePage)
            this.options.eventHandlers.savePage();
    },
    onCompartmentChange: function (id) {
        if (this.options.eventHandlers.onCompartmentChange)
            this.options.eventHandlers.onCompartmentChange(id);
    },
    onSaved: function (massage) {
        $('#massage').html('');
        $('#massage').html(massage);
        $('#tabCompartmentsContainer').addClass('in active');
        $('#tabCompartments').parent().addClass('active');
        $('#tabGeneralContainer, #tabHoldConditionContainer').removeClass('in active');
        $('#tabGeneral, #tabHoldCondition').parent().removeClass('active');
    },
    onCancleClick: function () {
        var retval = this.options.eventHandlers.onRedirection('/WasherGroup');
        return retval;
    },
    onConform: function (ddl) {
        _this = this;
        $('#btnSaveCompatment').removeAttr('disabled');
        var val = ddl.attr('val');
        var eqpid = ddl.attr('eqpid');
        var product = ddl.attr('product');
        _this.products.push({ Id: val });
        var objProdut = product.split('_')
        if (objProdut.length > 1) {
            var finalProduct = objProdut[0] + ' ' + objProdut[1];
        }
        else {
            var finalProduct = product;
        }

        var exists = false;
        $('#ddlPumps option').each(function () {
            if (this.value == val) {
                exists = true;
                return false;
            }
        });
        if (!exists) {
            $('#ddlPumps').append('<option eqp-id = ' + eqpid + ' product = ' + product + ' value=' + val + '>' + "P/V" + eqpid + "(" + finalProduct + ")" + '</option>');
        }
        ddl.parent().parent().remove();
    },
    clearMassage: function () {
        $('#massage').empty();
    },
    updateDosagePoint: function (obg) {
        if (obg) {
            $('#chkDosagePoint').attr('checked', true);
        }
        else {
            $('#chkDosagePoint').attr('checked', false);
        }
    },
    CompartmentPrint: function (data) {
        if (this.options.eventHandlers.CompartmentPrint)
            this.options.eventHandlers.CompartmentPrint(this.options.accountInfo.PrintAction + "?data=" + data);
    }
}