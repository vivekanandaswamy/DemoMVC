Ecolab.Model.DefaultModelProxy = function () {
};

Ecolab.Model.DefaultModelProxy.prototype =
{
    DefaultModelProxy: function (id, callBack, errorCallBack) {
        var url = "DashboardController/{id}";
        var requestData = { "id": id };
        this.ApiRead("Default", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },

    loadHomeData: function (callBack, errorCallBack) {
        var url = "/Api/Home/FetchDashboardsForHome";
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadUserPortletData: function (callBack, errorCallBack) {
        var url = "/Api/Default/FetchUserPortletData";
        this.ApiRead("Get", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    saveUserPortletData: function (userPortletData, callBack, errorCallBack) {
        var url = "/Api/Default/CreateUserPortletData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, userPortletData);
    },
    renderChartData: function (id,callBack,errorCallBack) {
        $.get("/Report/GetPortlets/" + id, function (data) {
            callBack(data)
        });
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.DefaultModelProxy.prototype = $.extend({}, Ecolab.Model.DefaultModelProxy.prototype, base);
Ecolab.Model.DefaultModelProxy.prototype.base = base;