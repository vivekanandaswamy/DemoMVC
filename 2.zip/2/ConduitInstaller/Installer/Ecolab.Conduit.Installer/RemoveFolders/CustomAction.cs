﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Deployment.WindowsInstaller;
using FileAttributes = Microsoft.Deployment.WindowsInstaller.FileAttributes;

namespace RemoveFolders
{
    public class CustomActions
    {
        [CustomAction]
        public static ActionResult Remove(Session session)
        {
            session.Log("Begin CustomAction1");
            try
            {
                var dir = new DirectoryInfo(@"C:\Ecolab");
                dir.Delete(true);
            }
            catch (Exception ex)
            {
                //StreamWriter sw = new StreamWriter(@"D:\Ecolab.txt", true);
                //sw.WriteLine(ex.Message);
                //sw.Flush();
                //sw.Close();
            }
            return ActionResult.Success;
        }
    }
}
