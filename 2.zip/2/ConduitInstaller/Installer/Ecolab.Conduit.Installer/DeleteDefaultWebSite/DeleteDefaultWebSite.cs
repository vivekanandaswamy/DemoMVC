﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Deployment.WindowsInstaller;
using System.Linq;
using Microsoft.Web.Administration;

namespace DeleteDefaultWebSite
{
    public class CustomActions
    {
        [CustomAction]
        public static ActionResult DeleteWebSite(Session session)
        {
            session.Log("Begin CustomAction1");
            try
            {
                ServerManager serverMgr = new ServerManager();
                foreach (Microsoft.Web.Administration.Site site in serverMgr.Sites.ToList())
                {
                    if (site.Name == "Default Web Site")
                    {
                        serverMgr.Sites.Remove(site);
                        serverMgr.CommitChanges();
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return ActionResult.Success;
        }
    }
}
