﻿using Microsoft.Deployment.WindowsInstaller;
using Microsoft.Win32.TaskScheduler;
using System;
using System.IO;

namespace TaskSchedular
{
    public class Schedular
    {
        [CustomAction]
        public static ActionResult AddTask(Session session)
        {
            try
            {
                using (var ts = new TaskService())
                {
                    TaskDefinition td = ts.NewTask();
                    td.RegistrationInfo.Description = "ChemicalInventory";
                    var trigger = new TimeTrigger { StartBoundary = DateTime.Now };
                    trigger.Repetition.Interval = TimeSpan.FromMinutes(15);

                    //to hide the command window on every run.
                    td.Settings.Hidden = true;
                    
                    td.Triggers.Add(trigger);
                    td.Actions.Add(new ExecAction(@"C:\Ecolab\envision\ChemicalInventrySch\ChemicalInventoryRollUp.bat"));
                    //ts.RootFolder.RegisterTaskDefinition("ChemicalInventory", td);

                    //Added params to allow job to run whether user is logged on or not.
                    ts.RootFolder.RegisterTaskDefinition("ChemicalInventory", td, TaskCreation.CreateOrUpdate, null, null, TaskLogonType.S4U, null);

                }
            }
            catch (Exception ex)
            {
                //var sw = new StreamWriter(@"D:\task.txt", true);
                //sw.WriteLine(ex.Message);
                //sw.Flush();
                //sw.Close();
            }

            return ActionResult.Success;
        }

        [CustomAction]
        public static ActionResult DeleteTask(Session session)
        {
            try
            {
                var sw = new StreamWriter(@"D:\task1.txt", true);

                using (var ts = new TaskService())
                {
                    if (ts.GetTask("ChemicalInventory") != null)
                    {
                        sw.WriteLine("Found");
                        ts.RootFolder.DeleteTask("ChemicalInventory");
                    }
                }
            }
            catch (Exception ex)
            {
                //var sw = new StreamWriter(@"D:\task.txt", true);
                //sw.WriteLine(ex.Message);
                //sw.Flush();
                //sw.Close();
            }
            return ActionResult.Success;
        }
    }
}