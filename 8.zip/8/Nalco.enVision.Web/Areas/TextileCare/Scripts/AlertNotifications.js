﻿var AlertNotifications = {
    func: {},
    Ctrls: {},
    Variables: {}
};

var usersInfo = null;

GetPlantDetails = function () {
    var dataSrc = [];

    var i = 0;
    $.ajax({
        url: AlertNotifications.Variables.PlantDetailsUrl,
        data: { plantSrchString: $("#PlantName").val() },
        dataType: "json",
        type: "GET",
        success: function (data, textStatus, xhr) {
            $.each(data, function () {
                var obj = { label: data[i].EcolabAccNumber, value: data[i].PlantId };
                dataSrc.push(obj);
                i++;
            });
            $("#PlantName").autocomplete({
                source: dataSrc,
                select: function (event, ui) {
                    $('#PlantName').val(ui.item.label);
                    $("#PlantName").attr("data-PlantId", ui.item.value);

                    usersInfo = null;
                    $.ajax({
                        url: AlertNotifications.Variables.UserInfoUrl,
                        data: { plantId: $("#PlantName").attr("data-plantid") },
                        dataType: "json",
                        type: "GET",
                        success: function (data, textStatus, xhr) {
                            usersInfo = data;
                        }
                    });

                    return false;
                }
            });
        }
    });
}

RedFlagDetails = function () {
    var i = 0;
    if ($("#PlantName").val() == "" || $("#PlantName").val() == null) {
        $("#PlantName").attr("data-plantid", "");
        $("#RedFlag").empty();
        $("#RedFlag").html("<option value=''>--Select--</option>");
        $("#RedFlag").next("span").html("--Select--");

    }
    if ($("#PlantName").attr("data-plantid") == "" || $("#PlantName").attr("data-plantid") == null) {
        return false;
    }
    $.ajax({
        url: AlertNotifications.Variables.RedFlagDetailsUrl,
        data: { plantId: $("#PlantName").attr("data-plantid") },
        dataType: "json",
        type: "GET",
        success: function (data, textStatus, xhr) {
            $("#RedFlag").empty();
            $("#RedFlag").html("<option value=''>--Select--</option>");
            $("#RedFlag").next("span").html("--Select--");
            if (data.Message == "Selected plant doesn't have redflag setup data.") {
                if ($("#redflagMessage").hasClass("message-hide k-error-message")) {
                    $("#redflagMessage").removeClass("message-hide k-error-message");
                }
                $("#redflagMessage").addClass("message-hide k-success-message");
                $("#redflagMessage").html(data.Message);
            }
            else {
                $.each(data, function () {
                    $("#RedFlag").append("<option value=" + data[i].RedFlagId + ">" + data[i].ItemName + "</option>");
                    i++;
                });
            }
        }
    });
}

GetNotificationType = function () {
    var i = 0;
    $.ajax({
        url: AlertNotifications.Variables.AlertNotificationUrl,
        dataType: "json",
        type: "GET",
        success: function (data, textStatus, xhr) {
            $.each(data, function () {
                $("#AlertType").append("<option value=" + data[i].AlertNotificationTypeId + ">" + data[i].NotificationType + "</option>");
                i++;
            });
        }
    });
}

GetDispenser = function () {
    var i = 0;

    if ($("#PlantName").attr("data-plantid") == "" || $("#PlantName").attr("data-plantid") == null) {
        return false;
    }

    $.ajax({
        url: AlertNotifications.Variables.GetDispenserInfo,
        data: { plantId: $("#PlantName").attr("data-plantid") },
        dataType: "json",
        type: "GET",
        success: function (data, textStatus, xhr) {
            $("#Dispenser").empty();
            $("#Dispenser").html("<option value=''>--Select--</option>");
            $("#Dispenser").next("span").html("--Select--");
            $.each(data, function () {
                $("#Dispenser").append("<option value=" + data[i].ControllerTypeModelId + '_' + data[i].ControllerId + ">" + data[i].DispenserName + "</option>");
                i++;
            });
        }
    });
}

GetAlarmGroupMaster = function () {
    var i = 0;
    $.ajax({
        url: AlertNotifications.Variables.GetAlarmGroupMaster,
        data: { dispenserId: $("#Dispenser").val().split('_')[0] },
        dataType: "json",
        type: "GET",
        success: function (data, textStatus, xhr) {
            $("#AlarmDescription").empty();
            $("#AlarmDescription").html("<option value=''>--Select--</option>");
            $("#AlarmDescription").next("span").html("--Select--");
            $.each(data, function () {
                $("#AlarmDescription").append("<option value=" + data[i].AlarmGroupId + ">" + data[i].AlarmGroupDescription + "</option>");
                i++;
            });
        }
    });
}

GetUserInfo = function (flag) {
    var dataSrc = [];
    var i = 0;
    var sendToEmailIds = $('#copyMail').val();
    var sendToEmailValue = $('#copyMail').val();
    var phoneNumber = $('#PhoneNumber').val();
    var phoneNumberValue = $('#PhoneNumber').attr("data-phoneNumber");
    var escalationEmailIds = $('#sendMailEscalation').val();
    var escalationEmailValues = $('#sendMailEscalation').val();
    $.ajax({
        url: AlertNotifications.Variables.UserInfoUrl,
        data: { plantId: $("#PlantName").attr("data-plantid") },
        dataType: "json",
        type: "GET",
        success: function (data, textStatus, xhr) {
            if (flag == "phone") {
                $.each(data, function () {
                    var obj = { label: data[i].PhoneNumber, value: data[i].UserId };
                    if (data[i].PhoneNumber != null && data[i].PhoneNumber != "" && data[i].PhoneNumber != 'null') {
                        dataSrc.push(obj);
                    }
                    i++;
                });
            }
            else {
                $.each(data, function () {
                    var obj = { label: data[i].UserDetail, value: data[i].EmailAddress };
                    dataSrc.push(obj);
                    i++;
                });
            }

            if (flag == "SendTo") {
                $("#sendMail").autocomplete({
                    source: dataSrc,
                    select: function (event, ui) {
                        $('#sendMail').val(ui.item.value);
                        $("#sendMail").attr("data-sendMail", ui.item.value);
                        return false;
                    }
                });
            }
            else if (flag == "CopyTo") {
                $("#CopyTo").autocomplete({
                    source: dataSrc,
                    select: function (event, ui) {
                        $("#CopyTo").val("");
                        sendToEmailIds = sendToEmailIds + ui.item.label + ";";
                        sendToEmailValue = sendToEmailValue + ui.item.value + ";";
                        $('#copyMail').val(sendToEmailValue);
                        $("#copyMail").attr("data-copyMail", sendToEmailValue);
                        return false;
                    }
                });
            }
            else if (flag == "sendToEscalation") {
                $("#CopyToEscalation").autocomplete({
                    source: dataSrc,
                    select: function (event, ui) {
                        $("#CopyToEscalation").val("");
                        escalationEmailIds = escalationEmailIds + ui.item.label + ";";
                        escalationEmailValues = escalationEmailValues + ui.item.value + ";";
                        $('#sendMailEscalation').val(escalationEmailValues);
                        $("#sendMailEscalation").attr("data-sendMailEscalation", escalationEmailValues);
                        return false;
                    }
                });
            }
            else if (flag == "phone") {
                $("#copyPhoneNumber").autocomplete({
                    source: dataSrc,
                    select: function (event, ui) {
                        $("#copyPhoneNumber").val("");
                        phoneNumber = phoneNumber + ui.item.label + ";";
                        phoneNumberValue = phoneNumberValue + ui.item.value + ";";
                        $('#PhoneNumber').val(phoneNumber);
                        $("#PhoneNumber").attr("data-phoneNumber", phoneNumber);
                        return false;
                    }
                });
            }
        }
    });
}

SaveAlertNotification = function () {
    ResetErrorFields();
    var validation_err = 0;

    var dataObject =
        {
            PlantId: $('#PlantName').attr('data-plantid'),
            RedFlagId: $('#RedFlag').find("option:selected").val(),
            AlarmGroupMasterId: $("#AlarmDescription").val(),
            DispenserId: $("#Dispenser").find("option:selected").val().split('_')[1],
            AlertNotificationTypeId: $("#AlertType").val(),
            PhoneNumber: $("#PhoneNumber").val(),
            EmailTo: $("#sendMail").val(),
            EmailCc: $("#copyMail").val(),
            EscalationThreshold: $("#attempts").val(),
            EscalationThresholdRedFlag: $("#EscalationThresholdPeriod").val(),
            EscalationThresholdAlarm: $("#alarmCount").val(),
            EscalationThresholdPeriod: $("#periodDuration").val(),
            EscalationEmailTo: $("#sendMailEscalation").val(),
            LastModifiedTime: "",
            LastModifiedByUserID: 1
        };

    if (dataObject.EmailTo == "") {
        dataObject.EmailTo = " ";
    }

    if (dataObject.EscalationEmailTo == "") {
        dataObject.EscalationEmailTo = " ";
    }

    if ($("#RedFlagRadio").is(":checked")) {
        dataObject.AlarmGroupMasterId = null;

        if ($("#PlantName").attr("data-plantid") == "" || $("#PlantName").attr("data-plantid") == null) {
            $(".txtPlant").show();
            validation_err = 1;
        }

        if ($('#RedFlag').find("option:selected").val() == null || $('#RedFlag').find("option:selected").val() == "") {
            $(".txtRedFlag").show();
            validation_err = 1;
        }

        if ($("#AlertType").find("option:selected").val() == "" || $("#AlertType").find("option:selected").val() == "--Select--") {
            $(".txtAlertType").show();
            validation_err = 1;
        }

    }

    if ($("#Alarms").is(":checked")) {
        dataObject.RedFlagId = null;
        dataObject.EscalationThresholdPeriod = "";

        if ($("#PlantName").attr("data-plantid") == "" || $("#PlantName").attr("data-plantid") == null) {
            $(".txtPlant").show();
            validation_err = 1;
        }

        if ($('#Dispenser').find("option:selected").val() == "" || $('#Dispenser').find("option:selected").val() == "--Select--") {
            $(".txtDispenser").show();
            validation_err = 1;
        }

        if ($("#AlarmDescription").find("option:selected").val() == "" || $("#AlarmDescription").find("option:selected").val() == "--Select--") {
            $(".txtDescription").show();
            validation_err = 1;
        }

        if ($("#alarmCount").val() == "" || $("#alarmCount").val() == null) {
            $(".txtAlarmsRaised").show();
            validation_err = 1;
        }

        if ($("#periodEscalation").val() == "" || $("#periodEscalation").val() == null) {
            $(".txtEscalation").show();
            validation_err = 1;
        }
        else {
            dataObject.EscalationThresholdPeriod = $("#periodEscalation").val();
        }
    }

    if ($("#AlertType").find("option:selected").text() == "--Select--") {
        $(".txtAlertType").show();
    }

    if ($("#AlertType").find("option:selected").text() == "Email") {
        if ($("#sendMail").val() == "" || $("#sendMail").val() == null) {
            $(".txtemail").show();
            validation_err = 1;
        }
        else {
            if (!IsEmailFormatValid($("#sendMail").val())) {
                $(".txtemailInValidFormat").show();
                validation_err = 1;
            }
            else {
                if (usersInfo != null) {
                    var flag = false;
                    $.each(usersInfo, function (index, user) {
                        if (user.EmailAddress.toUpperCase() == $("#sendMail").val().toUpperCase()) {
                            flag = true;
                            return false;
                        }
                    });
                    if (!flag) {
                        $(".txtemailInValidAddress").show();
                        validation_err = 1;
                    }
                }
            }
        }

        if ($("#copyMail").val() != null && $("#copyMail").val() != '') {
            var flag = true;
            var copyEmails = $("#copyMail").val().split(';');

            $.each(copyEmails, function (index, email) {
                if (email != null && email != '') {
                    if (!IsEmailFormatValid(email)) {
                        flag = false;
                        return false;
                    }
                }
            });

            if (!flag) {
                $(".copyMailInValidFormat").show();
                validation_err = 1;
            }
            else {
                if (usersInfo != null) {
                    $.each(copyEmails, function (index, email) {
                        if (email != null && email != '') {
                            var flag = false;
                            $.each(usersInfo, function (index, user) {
                                if (user.EmailAddress.toUpperCase() == email.toUpperCase()) {
                                    flag = true;
                                    return false;
                                }
                            });
                            if (!flag) {
                                $(".copyMailInValidAddress").show();
                                validation_err = 1;
                                return false;
                            }
                        }
                    });
                }
            }
        }
    } 

    if ($("#AlertType").find("option:selected").text() == "Phone") {
        if ($("#PhoneNumber").val() == "" || $("#PhoneNumber").val() == null) {
            $(".txtPhoneNumber").show();
            validation_err = 1;
        }
        else {
            var phoneNumbers = $("#PhoneNumber").val().split(';');
            if (usersInfo != null) {
                $.each(phoneNumbers, function (index, phoneNumber) {
                    if (phoneNumber != null && phoneNumber != '') {
                        var flag = false;
                        $.each(usersInfo, function (index, user) {
                            if (user.PhoneNumber == phoneNumber) {
                                flag = true;
                                return false;
                            }
                        });
                        if (!flag) {
                            $(".txtPhoneNumberInValid").show();
                            validation_err = 1;
                            return false;
                        }
                    }
                });
            }
        }
    }

    if ($("#AlertType").find("option:selected").text() == "Both") {
        if ($("#sendMail").val() == "" || $("#sendMail").val() == null) {
            $(".txtemail").show();
            validation_err = 1;
        }
        else {
            if (!IsEmailFormatValid($("#sendMail").val())) {
                $(".txtemailInValidFormat").show();
                validation_err = 1;
            }
            else {
                if (usersInfo != null) {
                    var flag = false;
                    $.each(usersInfo, function (index, user) {
                        if (user.EmailAddress.toUpperCase() == $("#sendMail").val().toUpperCase()) {
                            flag = true;
                            return false;
                        }
                    });
                    if (!flag) {
                        $(".txtemailInValidAddress").show();
                        validation_err = 1;
                    }
                }
            }
        }

        if ($("#copyMail").val() != null && $("#copyMail").val() != '') {
            var flag = true;
            var copyEmails = $("#copyMail").val().split(';');

            $.each(copyEmails, function (index, email) {
                if (email != null && email != '') {
                    if (!IsEmailFormatValid(email)) {
                        flag = false;
                        return false;
                    }
                }
            });

            if (!flag) {
                $(".copyMailInValidFormat").show();
                validation_err = 1;
            }
            else {
                if (usersInfo != null) {
                    $.each(copyEmails, function (index, email) {
                        if (email != null && email != '') {
                            var flag = false;
                            $.each(usersInfo, function (index, user) {
                                if (user.EmailAddress.toUpperCase() == email.toUpperCase()) {
                                    flag = true;
                                    return false;
                                }
                            });
                            if (!flag) {
                                $(".copyMailInValidAddress").show();
                                validation_err = 1;
                                return false;
                            }
                        }
                    });
                }
            }
        }

        if ($("#PhoneNumber").val() == "" || $("#PhoneNumber").val() == null) {
            $(".txtPhoneNumber").show();
            validation_err = 1;
        }
        else {
            var phoneNumbers = $("#PhoneNumber").val().split(';');
            if (usersInfo != null) {
                $.each(phoneNumbers, function (index, phoneNumber) {
                    if (phoneNumber != null && phoneNumber != '') {
                        var flag = false;
                        $.each(usersInfo, function (index, user) {
                            if (user.PhoneNumber == phoneNumber) {
                                flag = true;
                                return false;
                            }
                        });
                        if (!flag) {
                            $(".txtPhoneNumberInValid").show();
                            validation_err = 1;
                            return false;
                        }
                    }
                });
            }
        }
    }

    if ($("#sendMailEscalation").val() != null && $("#sendMailEscalation").val() != '') {
        var flag = true;
        var sendMailEscalationEmails = $("#sendMailEscalation").val().split(';');

        $.each(sendMailEscalationEmails, function (index, email) {
            if (email != null && email != '') {
                if (!IsEmailFormatValid(email)) {
                    flag = false;
                    return false;
                }
            }
        });

        if (!flag) {
            $(".sendMailEscalationInValidFormat").show();
            validation_err = 1;
        }
        else {
            if (usersInfo != null) {
                $.each(sendMailEscalationEmails, function (index, email) {
                    if (email != null && email != '') {
                        var flag = false;
                        $.each(usersInfo, function (index, user) {
                            if (user.EmailAddress.toUpperCase() == email.toUpperCase()) {
                                flag = true;
                                return false;
                            }
                        });
                        if (!flag) {
                            $(".sendMailEscalationInValidAddress").show();
                            validation_err = 1;
                            return false;
                        }
                    }
                });
            }
        }
    }

    if (validation_err == 1) {
        return false;
    }

    $.ajax({
        url: AlertNotifications.Variables.SaveAlertInfo,
        type: 'POST',
        data: dataObject,
        dataType: "json",
        success: function (data, textStatus, xhr) {
            if (data.Message == "Setup alert data saved successfully.") {
                if ($("#statusMessage").hasClass("message-hide k-error-message")) {
                    $("#statusMessage").removeClass("message-hide k-error-message");
                }
                $("#statusMessage").addClass("message-hide k-success-message");
                $("#statusMessage").html(data.Message);
            }
            else {
                if ($("#statusMessage").hasClass("message-hide k-success-message")) {
                    $("#statusMessage").removeClass("message-hide k-success-message");
                }
                $("#statusMessage").addClass("message-hide k-error-message");
                $("#statusMessage").html(data.Message);
            }
        },
    });
    DisplayAlerts.func.RefreshGrid();
}

showSetUpFields = function (AlertType) {
    if (AlertType == "Alarms") {
        $(".AlarmDescription").show();
        $(".alarmCount").show();
        $(".periodEscalation").show();
        $(".EscalationSettings").show();
        $(".AlertsSettings").hide();
        $(".RedFlag").hide();
        $(".RedFlagEscalation").hide();
        $(".attempts").hide();
        $(".Period").hide();
        $(".sendMailEscalation").hide();
        $(".Dispenser").show();
    }
    else {
        $(".AlarmDescription").hide();
        $(".alarmCount").hide();
        $(".periodEscalation").hide();
        $(".EscalationSettings").hide();
        $(".AlertsSettings").show();
        $(".RedFlag").show();
        $(".RedFlagEscalation").show();
        $(".attempts").show();
        $(".Period").show();
        $(".sendMailEscalation").show();
        $(".Dispenser").hide();
    }
}

ResetFields = function () {
    $("#PlantName").val("");
    $("#RedFlag").next("span").html("--Select--");
    $("#AlertType").next("span").html("--Select--");
    $("#sendMail").val("");
    $("#copyMail").val("");
    $("#PhoneNumber").val("");
    $("#attempts").val("");
    $("#EscalationThresholdPeriod").next("span").html("---Select-");
    $("#periodDuration").val("");
    $("#sendMailEscalation").val("");
    $("#Dispenser").empty();
    $("#Dispenser").html("<option>--Select--</option>");
    $("#Dispenser").next("span").html("--Select--");
    $("#AlarmDescription").empty();
    $("#AlarmDescription").html("<option>--Select--</option>");
    $("#AlarmDescription").next("span").html("--Select--");
    $("#alarmCount").val("");
    $("#periodEscalation").val("");
    $(".txtAlertType").hide();
    $(".txtemail").hide();
    $(".txtPhoneNumber").hide();
    $(".txtPlant").hide();
    $(".txtRedFlag").hide();
    $(".txtDispenser").hide();
    $(".txtDescription").hide();
    $(".txtAlarmsRaised").hide();
    $(".txtEscalation").hide();
    $(".copyMailInValidFormat").hide();
    $(".copyMailInValidAddress").hide();
    $(".sendMailEscalationInValidFormat").hide();
    $(".sendMailEscalationInValidAddress").hide();
    $(".txtPhoneNumberInValid").hide();
}

ResetErrorFields = function () {
    $(".txtAlertType").hide();
    $(".txtemail").hide();
    $(".txtemailInValidFormat").hide();
    $(".txtemailInValidAddress").hide();
    $(".txtPhoneNumber").hide();
    $(".txtPlant").hide();
    $(".txtRedFlag").hide();
    $(".txtDispenser").hide();
    $(".txtDescription").hide();
    $(".txtAlarmsRaised").hide();
    $(".txtEscalation").hide();
    $(".copyMailInValidFormat").hide();
    $(".copyMailInValidAddress").hide();
    $(".sendMailEscalationInValidFormat").hide();
    $(".sendMailEscalationInValidAddress").hide();
    $(".txtPhoneNumberInValid").hide();
}

IsEmailFormatValid = function (email) {
    var regularExpression = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (regularExpression.test(email)) {
        return true;
    }
    else {
        return false;
    }
}