﻿// -----------------------------------------------------------------------
// <copyright file="DimensionalUnitSystems.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dimensional Unit Systems object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     class for DimensionalUnitSystems
    /// </summary>
    public class DimensionalUnitSystems
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="DimensionalUnitSystems" /> class.
        /// </summary>
        public DimensionalUnitSystems()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="DimensionalUnitSystems" /> class.
        /// </summary>
        /// <param name="unitSystemId">The unit System ID</param>
        /// <param name="unitSystem">The unit System</param>
        public DimensionalUnitSystems(int unitSystemId, string unitSystem)
        {
            this.UnitSystemId = unitSystemId;
            this.UnitSystem = unitSystem;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the UnitSystemId.
        /// </summary>
        /// <value>The Unit System Id.</value>
        public int UnitSystemId { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystem.
        /// </summary>
        /// <value>The Unit System.</value>
        public string UnitSystem { get; set; }

        #endregion
    }
}