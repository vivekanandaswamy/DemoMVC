﻿// -----------------------------------------------------------------------
// <copyright file="MetaData.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MetaData object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     Meta data class to get the database values
    /// </summary>
    public class MetaData
    {
        /// <summary>
        ///     Constrcuter for the meta data
        /// </summary>
        /// <param name="fieldGroupName">The field Group Name</param>
        /// <param name="fieldGroupImageUrl">The field Group Image Url</param>
        /// <param name="fieldGroupHelpText">The field Group Help Text</param>
        /// <param name="fieldGroupTypeName">The field Group Type Name</param>
        /// <param name="fieldId">The field Id</param>
        /// <param name="fieldType">The field Type</param>
        /// <param name="fieldLabel">The field Label</param>
        /// <param name="fieldMinValue">The field Minimum Value</param>
        /// <param name="fieldMaxValue">The field Max Value</param>
        /// <param name="fieldIsMandatory">The field Is Mandatory</param>
        /// <param name="fieldHelpText">The field Help Text</param>
        /// <param name="fieldHelpUrl">The field Help Url</param>
        /// <param name="tabIndex">The tab Index</param>
        /// <param name="controlType">The control Type</param>
        /// <param name="dataSourceId">The data Source Id</param>
        /// <param name="dataCategoryId">The data Category Id</param>
        /// <param name="fieldDefaultValue">The field Default Value</param>
        /// <param name="fieldCurrencyCode">The field Currency Code</param>
        /// <param name="fieldResourceKey">The field Resource Key </param>
        /// <param name="fieldGroupResourceKey">The field Group Resource Key</param>
        /// <param name="fieldGroupDo">The field Group DO</param>
        /// <param name="fieldDo">The field DO</param>
        public MetaData(string fieldGroupName, string fieldGroupImageUrl, string fieldGroupHelpText, string fieldGroupTypeName, int fieldId, string fieldType, string fieldLabel, string fieldMinValue, string fieldMaxValue, bool fieldIsMandatory, string fieldHelpText, string fieldHelpUrl, int tabIndex, string controlType, int dataSourceId, int dataCategoryId, string fieldDefaultValue, string fieldCurrencyCode, string fieldResourceKey, string fieldGroupResourceKey, int fieldGroupDo, int fieldDo)
        {
            this.FieldGroupName = fieldGroupName;
            this.FieldGroupImageUrl = fieldGroupImageUrl;
            this.FieldGroupHelpText = fieldGroupHelpText;
            this.FieldGroupTypeName = fieldGroupTypeName;
            this.FieldId = fieldId;
            this.FieldType = fieldType;
            this.FieldLabel = fieldLabel;
            this.FieldMinValue = fieldMinValue;
            this.FieldMaxValue = fieldMaxValue;
            this.FieldIsMandatory = fieldIsMandatory;
            this.FieldHelpText = fieldHelpText;
            this.FieldHelpUrl = fieldHelpUrl;
            this.TabIndex = tabIndex;
            this.ControlType = controlType;
            this.DataSourceId = dataSourceId;
            this.DataCategoryId = dataCategoryId;
            this.FieldDefaultValue = fieldDefaultValue;
            this.FieldCurrencyCode = fieldCurrencyCode;
            this.FieldResourceKey = fieldResourceKey;
            this.FieldGroupResourceKey = fieldGroupResourceKey;
            this.FieldGroupDo = fieldGroupDo;
            this.FieldDo = fieldDo;
        }

        /// <summary>
        ///     Gets and sets the Field Group Name
        /// </summary>
        /// <value>The Parameter Field Group Name</value>
        public string FieldGroupName { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Image Url
        /// </summary>
        /// <value>The Parameter Field Group Image Url</value>
        public string FieldGroupImageUrl { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Help Text
        /// </summary>
        /// <value>The Parameter Field Group Help Text</value>
        public string FieldGroupHelpText { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Type Name
        /// </summary>
        /// <value>The Parameter Field Group Type Name</value>
        public string FieldGroupTypeName { get; set; }

        /// <summary>
        ///     Gets and sets the Field Id
        /// </summary>
        /// <value>The Parameter Field Id</value>
        public int FieldId { get; set; }

        /// <summary>
        ///     Gets and sets the Field Type
        /// </summary>
        /// <value>The Parameter Field Type</value>
        public string FieldType { get; set; }

        /// <summary>
        ///     Gets and sets the Field Label
        /// </summary>
        /// <value>The Parameter Field Label</value>
        public string FieldLabel { get; set; }

        /// <summary>
        ///     Gets and sets the Field Minimum Value
        /// </summary>
        /// <value>The Parameter Field Min Value</value>
        public string FieldMinValue { get; set; }

        /// <summary>
        ///     Gets and sets the Field Maximum Value
        /// </summary>
        /// <value>The Parameter Field Max Value</value>
        public string FieldMaxValue { get; set; }

        /// <summary>
        ///     Gets and sets the Field Is Mandatory or not
        /// </summary>
        /// <value>The Parameter Field Is Mandatory</value>
        public bool FieldIsMandatory { get; set; }

        /// <summary>
        ///     Gets and sets the Field Help Text
        /// </summary>
        /// <value>The Parameter Field Help Text</value>
        public string FieldHelpText { get; set; }

        /// <summary>
        ///     Gets and sets the Field Help Url
        /// </summary>
        /// <value>The Parameter Field Help Url</value>
        public string FieldHelpUrl { get; set; }

        /// <summary>
        ///     Gets and sets the Tab Index
        /// </summary>
        /// <value>The Parameter Tab Index</value>
        public int TabIndex { get; set; }

        /// <summary>
        ///     Gets and sets the Control Type
        /// </summary>
        /// <value>The Parameter Control Type</value>
        public string ControlType { get; set; }

        /// <summary>
        ///     Gets and sets the Data Source Id
        /// </summary>
        /// <value>The Parameter Data Source Id</value>
        public int DataSourceId { get; set; }

        /// <summary>
        ///     Gets and sets the Data Category Id
        /// </summary>
        /// <value>The Parameter Data Category Id</value>
        public int DataCategoryId { get; set; }

        /// <summary>
        ///     Gets and sets the Field Default Value
        /// </summary>
        /// <value>The Parameter Field Default Value</value>
        public string FieldDefaultValue { get; set; }

        /// <summary>
        ///     Gets and sets the Field Currency Code
        /// </summary>
        /// <value>The Parameter Field Currency Code</value>
        public string FieldCurrencyCode { get; set; }

        /// <summary>
        ///     Gets and sets the Field Resource Key
        /// </summary>
        /// <value>The Parameter Field Resource Key</value>
        public string FieldResourceKey { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Resource Key
        /// </summary>
        /// <value>The Parameter Field Group Resource Key</value>
        public string FieldGroupResourceKey { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group DO
        /// </summary>
        /// <value>The Parameter Field Group DO</value>
        public int FieldGroupDo { get; set; }

        /// <summary>
        ///     Gets and sets the Field DO
        /// </summary>
        /// <value>The Parameter field DO</value>
        public int FieldDo { get; set; }
    }
}