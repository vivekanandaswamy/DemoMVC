﻿// <copyright file="FormulaCategory.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>The FormulaCategory object</summary>

namespace Entities
{
    using System;
    public class FormulaCategory
    {
        #region "Constructor"       

        /// <summary>
        ///     default constructor FormulaCategory
        /// </summary>
        public FormulaCategory()
        {
        }

        /// <summary>
        /// parameterised Formula Category Constructor
        /// </summary>
        /// <param name="textileId">The textile identifier.</param>
        /// <param name="categoryName">Name of the category.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceMstrLnnTypId">My service MSTR LNN typ identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="regionId">The region identifier.</param>
        public FormulaCategory(int textileId, string categoryName, bool isDeleted, int myServiceMstrLnnTypId, DateTime myServiceLastSynchTime,
            DateTime lastModifiedTime, short regionId)
        {
            this.TextileId = textileId;
            this.CategoryName = categoryName;
            this.IsDeleted = isDeleted;
            this.MyServiceMstrLnnTypId = myServiceMstrLnnTypId;
            this.MyServiceLastSynchTime = myServiceLastSynchTime;
            this.LastModifiedTime = lastModifiedTime;
            this.RegionId = regionId;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets TextileID
        /// </summary>
        /// <value>Textile ID for Formula .</value>
        public int TextileId { get; set; }

        /// <summary>
        ///     Gets or sets CategoryName
        /// </summary>
        /// <value>Category Name.</value>
        public string CategoryName { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value>IsDeleted for Formula .</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the RegionId
        /// </summary>
        /// <value>The Parameter RegionId</value>
        public short RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>The Parameter LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceMstrLnnTypId
        /// </summary>
        /// <value>MyServiceMstrLnnTypId.</value>
        public int MyServiceMstrLnnTypId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}