﻿// -----------------------------------------------------------------------
// <copyright file="ShippingAddress.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Shipping Address object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    /// class for Shipping Address
    /// </summary>
    public class ShippingAddress
    {
        /// <summary>
        /// Gets or sets the shipping addr1.
        /// </summary>
        /// <value>
        /// The shipping addr1.
        /// </value>
        public string ShippingAddr1 { get; set; }
        /// <summary>
        /// Gets or sets the shipping addr2.
        /// </summary>
        /// <value>
        /// The shipping addr2.
        /// </value>
        public string ShippingAddr2 { get; set; }
        /// <summary>
        /// Gets or sets the shippingcity.
        /// </summary>
        /// <value>
        /// The shippingcity.
        /// </value>
        public string Shippingcity { get; set; }
        /// <summary>
        /// Gets or sets the shippingcountry.
        /// </summary>
        /// <value>
        /// The shippingcountry.
        /// </value>
        public string Shippingcountry { get; set; }
        /// <summary>
        /// Gets or sets the shippingzip.
        /// </summary>
        /// <value>
        /// The shippingzip.
        /// </value>
        public string Shippingzip { get; set; }
    }
}
