﻿// -----------------------------------------------------------------------
// <copyright file="LanguageMaster.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LanguageMaster object</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities
{
    /// <summary>
    ///     class LanguageMaster
    /// </summary>
    public class LanguageMaster
    {
        #region "Constructor"

        /// <summary>
        ///     constructor LanguageMaster
        /// </summary>
        public LanguageMaster(int languageId, string name, string locale)
        {
            this.LanguageId = languageId;
            this.Name = name;
            this.Locale = locale;
        }

        /// <summary>
        ///   parametrized  constructor LanguageMaster
        /// </summary>
        public LanguageMaster(int languageId, string name, string locale, bool isActive, DateTime lastModifiedTime)
        {
            this.LanguageId = languageId;
            this.Name = name;
            this.Locale = locale;
            this.IsActive = isActive;
            this.LastModifiedTime = lastModifiedTime;
        }
        /// <summary>
        ///     default constructor LanguageMaster
        /// </summary>
        public LanguageMaster()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets LanguageId
        /// </summary>
        /// <value>LanguageId .</value>
        public int LanguageId { get; set; }

        /// <summary>
        ///     Gets or sets Name
        /// </summary>
        /// <value>Language Name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets Locale
        /// </summary>
        /// <value>Parameter Locale</value>
        public string Locale { get; set; }

        /// <summary>
        ///     Gets or sets the IsActive.
        /// </summary>
        /// <value> IsActive </value>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        #endregion
    }
}