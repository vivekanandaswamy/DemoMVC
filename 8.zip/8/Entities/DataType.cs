// -----------------------------------------------------------------------
// <copyright file="DataType.cs" company="Ecolab">
// �2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DataType object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System.Collections.Generic;

    /// <summary>
    ///     Class DataType
    /// </summary>
    public class DataType
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="DataType" /> class.
        /// </summary>
        public DataType()
        {
            this.Fields = new List<Field>();
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="DataType" /> class.
        /// </summary>
        /// <param name="id">The id. field</param>
        /// <param name="name">The name. field</param>
        public DataType(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }

        /// <summary>
        ///     Gets or sets the id.
        /// </summary>
        /// <value>The id. field</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the fields.
        /// </summary>
        /// <value>The fields.</value>
        public List<Field> Fields { get; set; }
    }
}