﻿// -----------------------------------------------------------------------
// <copyright file="ResourceKeyPageMapping.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Resource Values object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///     Entity class for AlarmMaster
    /// </summary>
    public class ResourceKeyPageMapping : BaseEntity
    {
        /// <summary>
        /// Parametrized Constructor
        /// </summary>
        public ResourceKeyPageMapping(int id, int resourceId ,int pageId)
        {
            this.Id = id;
            this.ResourceId = resourceId;
            this.PageId = pageId;
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ResourceKeyPageMapping()
        {

        }
        
        /// <summary>
        /// ResourceId
        /// </summary>
        public int ResourceId { get; set; }
       
        /// <summary>
        /// LanguageId
        /// </summary>
        public int PageId { get; set; }

    }
}
