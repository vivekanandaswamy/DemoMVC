﻿// -----------------------------------------------------------------------
// <copyright file="SyncConfigSettings.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SyncConfigSettings </summary>
// -----------------------------------------------------------------------

namespace Entities.SyncConfigSettings
{
    public class SyncConfigSettings
    {
        public SyncConfigSettings()
        {
        }

        public SyncConfigSettings(string keyName, string value)
        {
            this.KeyName = keyName;
            this.Value = value;
        }

        public string KeyName { get; set; }
        public string Value { get; set; }
    }
}