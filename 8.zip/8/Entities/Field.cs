// -----------------------------------------------------------------------
// <copyright file="Field.cs" company="Ecolab">
// �2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Field object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     Class Field
    /// </summary>
    public class Field
    {
        /// <summary>
        ///     Gets or sets the id.
        /// </summary>
        /// <value>The id. field</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the type id.
        /// </summary>
        /// <value>The type id.</value>
        public int TypeId { get; set; }

        /// <summary>
        ///     Gets or sets the label.
        /// </summary>
        /// <value>The label. field</value>
        public string Label { get; set; }

        /// <summary>
        ///     Gets or sets the minimum.
        /// </summary>
        /// <value>The minimum. field</value>
        public string Min { get; set; }

        /// <summary>
        ///     Gets or sets the maximum.
        /// </summary>
        /// <value>The maximum. field</value>
        public string Max { get; set; }

        /// <summary>
        ///     Gets or sets the biz driver id.
        /// </summary>
        /// <value>The biz driver id.</value>
        public int? BizDriverId { get; set; }

        /// <summary>
        ///     Gets or sets the field group id.
        /// </summary>
        /// <value>The field group id.</value>
        public int? FieldGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the data source id.
        /// </summary>
        /// <value>The data source id.</value>
        public int? DataSourceId { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this instance is mandatory.
        /// </summary>
        /// <value><c>null</c> if [is mandatory] contains no value, <c>true</c> if [is mandatory]; otherwise, <c>false</c>.</value>
        public bool? IsMandatory { get; set; }

        /// <summary>
        ///     Gets or sets the help text.
        /// </summary>
        /// <value>The help text.</value>
        public string HelpText { get; set; }

        /// <summary>
        ///     Gets or sets the help text URL.
        /// </summary>
        /// <value>The help text URL.</value>
        public string HelpTextUrl { get; set; }

        /// <summary>
        ///     Gets or sets the data type id.
        /// </summary>
        /// <value>The data type id.</value>
        public int? DataTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the unit id.
        /// </summary>
        /// <value>The unit id.</value>
        public int? UnitId { get; set; }

        /// <summary>
        ///     Gets or sets the currency id.
        /// </summary>
        /// <value>The currency id.</value>
        public string CurrencyId { get; set; }

        /// <summary>
        ///     Gets or sets the display order.
        /// </summary>
        /// <value>The display order.</value>
        public int? DisplayOrder { get; set; }
    }
}