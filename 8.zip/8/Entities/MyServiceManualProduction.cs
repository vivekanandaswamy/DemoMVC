﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceManualProduction.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyService Manual Production object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
	using System;

	/// <summary>
	/// Class for Myservice data
	/// </summary>
	public class MyServiceManualProduction
	{
        /// <summary>
        /// Initializes a new instance of the <see cref="MyServiceManualProduction"/> class.
        /// </summary>
        /// <param name="myServiceMeterGuid">My service meter unique identifier.</param>
        /// <param name="meterDescription">The meter description.</param>
        /// <param name="utilityType">Type of the utility.</param>
        /// <param name="meterReading">The meter reading.</param>
        /// <param name="startDateTime">The start date time.</param>
        /// <param name="meterTickUnit">The meter tick unit.</param>
        /// <param name="myServiceManualUtilitityGuid">My service manual utilitity unique identifier.</param>
        /// <param name="usage">The usage Value.</param>
        public MyServiceManualProduction(Guid myServiceMeterGuid, string meterDescription, int utilityType, decimal meterReading, DateTime? startDateTime, string meterTickUnit, Guid myServiceManualUtilitityGuid, decimal usage)
		{
			this.MyServiceMeterGuid = myServiceMeterGuid;
			this.MeterDescription = meterDescription;
			this.UtilityType = utilityType.ToString();
			this.MeterReading = meterReading;
			this.StartDateTime = startDateTime;
			this.MeterTickUnit = meterTickUnit;
			this.MyServiceManualUtilitityGuid = myServiceManualUtilitityGuid;
			this.Usage = usage;
        }

        /// <summary>
        /// Get or sets MeterId
        /// </summary>
        /// <value>
        /// The meter identifier.
        /// </value>
        public int MeterId { get; set; }

        /// <summary>
        /// Get or sets UtilityId
        /// </summary>
        /// <value>
        /// The utility identifier.
        /// </value>
        public int UtilityId { get; set; }

        /// <summary>
        /// Get or sets MeterTickUnit
        /// </summary>
        /// <value>
        /// The meter tick unit.
        /// </value>
        public string MeterTickUnit { get; set; }

        /// <summary>
        /// Get or sets StartDateTime
        /// </summary>
        /// <value>
        /// The start date time.
        /// </value>
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// Get or sets MeterReading
        /// </summary>
        /// <value>
        /// The meter reading.
        /// </value>
        public decimal MeterReading { get; set; }

        /// <summary>
        /// Get or sets UtilityType
        /// </summary>
        /// <value>
        /// The type of the utility.
        /// </value>
        public string UtilityType { get; set; }

        /// <summary>
        /// Get or sets MeterDescription
        /// </summary>
        /// <value>
        /// The meter description.
        /// </value>
        public string MeterDescription { get; set; }

        /// <summary>
        /// Get or sets MyServiceMeterGuid
        /// </summary>
        /// <value>
        /// My service meter unique identifier.
        /// </value>
        public Guid MyServiceMeterGuid { get; set; }

        /// <summary>
        /// Get or sets MyServiceManualUtilitityGuid
        /// </summary>
        /// <value>
        /// My service manual utilitity unique identifier.
        /// </value>
        public Guid MyServiceManualUtilitityGuid { get; set; }

        /// <summary>
        /// Gets or sets EcolabAccountNumber
        /// </summary>
        /// <value>
        /// The ecolab account number.
        /// </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Get or sets MeterReading
        /// </summary>
        /// <value>
        /// The usage Value.
        /// </value>
        public decimal Usage { get; set; }
	}
}