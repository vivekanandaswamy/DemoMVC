﻿// -----------------------------------------------------------------------
// <copyright file="WasherFlushTime.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WasherFlushTime is for get and set the data.</summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.Washers
{
    /// <summary>
    ///     class Alarms
    /// </summary>
    public class WasherFlushTime : BaseEntity
    {
        /// <summary>
        ///     Deafault Constructor for WasherFlushTime
        /// </summary>
        public WasherFlushTime()
        {
        }

        /// <summary>
        /// washer flush time
        /// </summary>
        /// <param name="washerId">the washer id</param>
        /// <param name="lineNumber">line number.</param>
        /// <param name="washerFlushTypeId">washer flush type id</param>
        /// <param name="flushTime">washer flush time</param>
        /// <param name="lastModifiedTime">LastModifiedTime</param>
        /// Int32, Byte, Int32, Int32, DateTime, Int32
        public WasherFlushTime(int washerId, byte lineNumber, int washerFlushTypeId, int flushTime, DateTime lastModifiedTime, int plantId, bool isDeleted)
	    {
			this.WasherId = washerId;
		    this.LineNumber = lineNumber;
		    WasherFlushTypeId = (WasherFlushType)washerFlushTypeId;
		    this.FlushTime = flushTime;
			this.LastModifiedTime = lastModifiedTime;
			this.PlantId = plantId;
            this.IsDeleted = isDeleted;
	    }

		/// <summary>
		/// Parameterized constructor for WasherFlushTime in Get SP
		/// </summary>
		/// <param name="pumpCount">the pump Count.</param>
		/// <param name="meterCount">the ME Count.</param>
		/// <param name="waterCount">the water Count.</param>
		/// <param name="airCount">the air Count.</param>
		public WasherFlushTime(byte pumpCount, byte meterCount, int waterCount, int airCount)
		{
			this.PumpCount = pumpCount;
			this.MeCount = meterCount;
			this.WaterCount = waterCount;
			this.AirCount = airCount;
		}

		/// <summary>
		///     Gets or sets the signalNumber
		/// </summary>
		/// <value>The Signal Number</value>
		public int WasherId { get; set; }

		/// <summary>
		///     Gets or sets the signalNumber
		/// </summary>
		/// <value>The Signal Number</value>
		public byte LineNumber { get; set; }

		/// <summary>
		///     Gets or sets the equipmentNumber
		/// </summary>
		/// <value>The Equipment Number</value>
		public int FlushTime { get; set; }

		/// <summary>
		///     Gets or sets the LastModifiedTime
		/// </summary>
		/// <value>The Last Modified Time</value>
		public DateTime LastModifiedTime { get; set; }

		/// <summary>
		///     Gets or sets the WasherFlushTypeId
		/// </summary>
		/// <value>The Washer Flush Type Id</value>
		public WasherFlushType WasherFlushTypeId { get; set; }

		/// <summary>
		///     Gets or sets the PumpCount
		/// </summary>
		/// <value>The PumpCount</value>
		public int PumpCount { get; set; }

		/// <summary>
		///     Gets or sets the MeCount
		/// </summary>
		/// <value>The MeCount</value>
		public int MeCount { get; set; }
		
		/// <summary>
		///     Gets or sets the WaterCount
		/// </summary>
		/// <value>The WaterCount</value>
		public int WaterCount { get; set; }
		
		/// <summary>
		///     Gets or sets the AirCount
		/// </summary>
		/// <value>The AirCount</value>
		public int AirCount { get; set; }
    }

	public enum WasherFlushType
	{
		Pump = 3,
		MainEquipment = 4,
		Air = 2,
		Water = 1
	}
}