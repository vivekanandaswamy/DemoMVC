﻿// -----------------------------------------------------------------------
// <copyright file="LfsWasherNumber.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LfsWasherNumber object</summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Conventional
{
    using System;

    public class LfsWasherNumber
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="LfsWasherNumber" /> class.
        /// </summary>
        /// <param name="maximumWasherExtractorCount">Maximum Washer Extractor Count</param>
        public LfsWasherNumber(Int16 maximumWasherExtractorCount)
        {
            this.LfsWasherMaxNumber = maximumWasherExtractorCount;
        }

        #endregion "Constructor"

        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public Int16 LfsWasherMaxNumber { get; set; }
    }
}