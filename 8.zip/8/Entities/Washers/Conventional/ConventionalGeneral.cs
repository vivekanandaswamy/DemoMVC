﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalGeneral.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Conventional General Entity </summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Conventional
{
    using System;
    using System.Collections.Generic;
    using System.Security.Cryptography;
    using Entities.WasherGroup;

    /// <summary>
    ///     Class ConventionalGeneral.
    /// </summary>
    public class ConventionalGeneral : BaseEntity
    {
        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="ConventionalGeneral" /> class.
        /// </summary>
        public ConventionalGeneral()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConventionalGeneral" /> class.
        /// </summary>
        /// <param name="plantWasherNumber">The Plant Washer Number</param>
        /// <param name="name">The Plant Washer Name</param>
        /// <param name="washerType">Parameter washer type.</param>
        /// <param name="washerTypeFlg">washer type flag</param>
        /// <param name="modelName">The Model Name</param>
        /// <param name="washerModelId">washer model id.</param>
        /// <param name="washerSize">Parameter washer size.</param>
        /// <param name="controllerName">The controller Name</param>
        /// <param name="id">The Parameter Plant Id.</param>
        /// <param name="washerGroupId">washer group id.</param>
        /// <param name="washerGroupName">washer group name</param>
        /// <param name="controllerId">The controller Id</param>
        /// <param name="description">The Description</param>
        /// <param name="maxLoad">The Plant Max Load.</param>
        /// <param name="washerModeId">The Washer Mode Id</param>
        /// <param name="aweActive">Parameter AWE Active Value</param>
        /// <param name="numberOfComp">number of comp.</param>
        /// <param name="numberOfTanks">number of tanks.</param>
        /// <param name="pressExtractor">Press extractor.</param>
        /// <param name="transferType">Parameter transfer type</param>
        /// <param name="endOfFormula">End Of Formula</param>
        /// <param name="holdSignal">The Hold Signal Value</param>
        /// <param name="holdDelay">The Hold Delay</param>
        /// <param name="targetTurnTime">The Target Turn Time</param>
        /// <param name="waterFlushTime">The Water Flush Time&gt;</param>
        /// <param name="machineInternalId">machine internal Id.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="formulaCount">The formula count.</param>
        /// <param name="myServiceCustMchGrpGuid">My service customer MCH GRP unique identifier.</param>
        /// <param name="myServiceCustMchGuid">My service customer MCH unique identifier.</param>
        /// <param name="myServiceMCHId">My service MCH identifier.</param>
        /// <param name="pressExtractorName">Name of the press extractor.</param>
        /// <param name="transferTypeName">Name of the transfer type.</param>
        /// <param name="ratioDosingActive">if set to <c>true</c> [ratio dosing active].</param>
        /// <param name="ecolabWasherNumber">The ecolab washer number.</param>
        /// <param name="endOfFormulaNumber">The end of formula number.</param>
        /// <param name="myserviceLastSyncTime">The myservice last synchronize time.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <param name="controllerType">Type of the controller.</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <param name="controllerModel">The controller model.</param>
        /// <param name="numberOfCompartmentsConveyorBelt">The number of compartments conveyor belt.</param>
        /// <param name="minMachineLoad">The minimum machine load.</param>
        /// <param name="maxMachineLoad">The maximum machine load.</param>
        /// <param name="programSelectionByTime">if set to <c>true</c> [program selection by time].</param>
        /// <param name="weightSelectionByTime">if set to <c>true</c> [weight selection by time].</param>
        /// <param name="weightSelectionByAnalogInput">if set to <c>true</c> [weight selection by analog input].</param>
        /// <param name="tunInTomMode">if set to <c>true</c> [tun in tom mode].</param>
        /// <param name="signalStopTunActive">if set to <c>true</c> [signal stop tun active].</param>
        /// <param name="signalEjectionTunActive">if set to <c>true</c> [signal ejection tun active].</param>
        /// <param name="delayTimeForTunWashingPrograms">if set to <c>true</c> [delay time for tun washing programs].</param>
        /// <param name="kannegiesserPressSpecialMode">if set to <c>true</c> [kannegiesser press special mode].</param>
        /// <param name="valveOutputsUsedAsTomSignal">if set to <c>true</c> [valve outputs used as tom signal].</param>
        /// <param name="extendedClockOrDataProtocol">if set to <c>true</c> [extended clock or data protocol].</param>
        /// <param name="weightCorrectionFcc">if set to <c>true</c> [weight correction FCC].</param>
        /// <param name="flowSwitchNumber">The flow switch number.</param>
        /// <param name="washerStopExternalSignal">if set to <c>true</c> [washer stop external signal].</param>
        /// <param name="onHoldWESignalActive">if set to <c>true</c> [on hold we signal active].</param>
        /// <param name="washerOnHoldSignalDelay">The washer on hold signal delay.</param>
        /// <param name="weInTomMode">if set to <c>true</c> [we in tom mode].</param>
        /// <param name="manifoldFlushTime">The manifold flush time.</param>
        /// <param name="l1">if set to <c>true</c> [l1].</param>
        /// <param name="l2">if set to <c>true</c> [l2].</param>
        /// <param name="l3">if set to <c>true</c> [l3].</param>
        /// <param name="l4">if set to <c>true</c> [l4].</param>
        /// <param name="l5">if set to <c>true</c> [l5].</param>
        /// <param name="l6">if set to <c>true</c> [l6].</param>
        /// <param name="l7">if set to <c>true</c> [l7].</param>
        /// <param name="l8">if set to <c>true</c> [l8].</param>
        /// <param name="l9">if set to <c>true</c> [l9].</param>
        /// <param name="l10">if set to <c>true</c> [L10].</param>
        /// <param name="l11">if set to <c>true</c> [L11].</param>
        /// <param name="l12">if set to <c>true</c> [L12].</param>
        /// <param name="isPony">if set to <c>true</c> [is pony].</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="useMe1OfGroup">The use me1 of group.</param>
        /// <param name="useMe2OfGroup">The use me2 of group.</param>
        /// <param name="usePumpOfGroup">The use pump of group.</param>
        /// <param name="washerStopUseFinalExtracting">The washer stop use final extracting.</param>
        /// <param name="temperatureAlarmYesNo">The temperature alarm yes no.</param>
        /// <param name="phProbe">The ph probe.</param>
        /// <param name="weightCell">The weight cell.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="waterCounter">The water counter.</param>
        /// <param name="dateAndTimeWhenBatchEjects">The date and time when batch ejects.</param>
        /// <param name="autoRinseDesamixAfter">The automatic rinse desamix after.</param>
        /// <param name="autoRinseDesamix1For">The automatic rinse desamix1 for.</param>
        /// <param name="autoRinseDesamix2For">The automatic rinse desamix2 for.</param>
        /// <param name="temperatureAlarmProbe1">The temperature alarm probe1.</param>
        /// <param name="temperatureAlarmProbe2">The temperature alarm probe2.</param>
        /// <param name="temperatureAlarmProbe3">The temperature alarm probe3.</param>
        /// <param name="DefaultIdleTime">The default idle time.</param>
        /// <param name="etechwashernumber">The etechwashernumber.</param>
        /// <param name="signalAcceptanceTime">The signal acceptance time.</param>
        /// <param name="kannegiesserDosageInPreparationTankMode">if set to <c>true</c> [kannegiesser dosage in preparation tank mode].</param>
        /// <param name="batchOk">if set to <c>true</c> [batch ok].</param>
        /// <param name="extractTimeForEOFSignal">if set to <c>true</c> [extract time for EOF signal].</param>
        /// <param name="transferPerHour">The transfer per hour.</param>
	    public ConventionalGeneral(
		    Int16 plantWasherNumber,
                                   string name,
                                   string washerType,
                                   bool washerTypeFlg,
                                   string modelName,
                                   short washerModelId,
                                   string washerSize,
                                   string controllerName,
                                   int id,
                                   int washerGroupId,
                                   string washerGroupName,
                                   int controllerId,
                                   string description,
                                   short maxLoad,
                                   short washerModeId,
                                   bool aweActive,
                                   int numberOfComp,
                                   short numberOfTanks,
                                   short pressExtractor,
                                   short transferType,
                                   short endOfFormula,
                                   bool holdSignal,
                                   int holdDelay,
                                   int targetTurnTime,
                                   int waterFlushTime,
                                   int? machineInternalId,
                                   DateTime lastModifiedTime,
                                   DateTime lastSyncTime,
                                   bool isDeleted,
                                   string ecolabAccountNumber,
                                   int formulaCount,
                                   Guid myServiceCustMchGrpGuid,
                                   Guid myServiceCustMchGuid,
                                   int myServiceMCHId,
                                   string pressExtractorName,
                                   string transferTypeName,
                                   bool ratioDosingActive,
                                   int ecolabWasherNumber,
                                   short endOfFormulaNumber,
                                   DateTime? myserviceLastSyncTime,
		    int controllerTypeId,
		    string controllerType,
		    int controllerModelId,
		    string controllerModel,
		    //int lfsWasher,
		    short numberOfCompartmentsConveyorBelt,
		    short minMachineLoad,
		    short maxMachineLoad,
		    bool programSelectionByTime,
		    bool weightSelectionByTime,
		    bool weightSelectionByAnalogInput,
		    bool tunInTomMode,
		    bool signalStopTunActive,
		    bool signalEjectionTunActive,
		    bool delayTimeForTunWashingPrograms,
		    bool kannegiesserPressSpecialMode,
		    bool valveOutputsUsedAsTomSignal,
		    bool extendedClockOrDataProtocol,
		    bool weightCorrectionFcc,
			int flowSwitchNumber,
			bool washerStopExternalSignal,
			bool onHoldWESignalActive,
			int washerOnHoldSignalDelay,
			bool weInTomMode,
			int manifoldFlushTime,
			bool l1,
			bool l2,
			bool l3,
			bool l4,
			bool l5,
			bool l6,
			bool l7,
			bool l8,
			bool l9,
			bool l10,
			bool l11,
			bool l12,
            bool isPony,
			int plantId,
			byte? useMe1OfGroup,
			byte? useMe2OfGroup,
			byte? usePumpOfGroup,
			bool? washerStopUseFinalExtracting,
			bool? temperatureAlarmYesNo,
			bool? phProbe,
			bool? weightCell,
			bool? temperature,
            bool? waterCounter,
            bool? dateAndTimeWhenBatchEjects,
            short? autoRinseDesamixAfter,
            short? autoRinseDesamix1For,
            short? autoRinseDesamix2For,
            bool? temperatureAlarmProbe1,
            bool? temperatureAlarmProbe2,
            bool? temperatureAlarmProbe3,
            int DefaultIdleTime,
            int etechwashernumber,
            int signalAcceptanceTime,
            bool kannegiesserDosageInPreparationTankMode,
            bool batchOk,
            bool extractTimeForEOFSignal,
            int transferPerHour
            )
		    : base(ecolabAccountNumber, plantId)
        {
		    this.Id = id;
		    this.Name = name;
		    this.ModelName = modelName;
		    this.WasherTypeName = washerType;
		    this.WasherTypeFlag = washerTypeFlg;
		    this.WasherModelId = washerModelId;
		    this.WasherGroupId = washerGroupId;
		    this.WasherGroupName = washerGroupName;
		    this.Size = washerSize;
		    this.ControllerId = controllerId;
		    this.ControllerName = controllerName;
		    this.WasherModeId = washerModeId;
		    this.LfsWasher = machineInternalId;
		    this.MaxLoad = maxLoad;
		    this.EndOfFormula = endOfFormula;
		    this.AweActive = aweActive;
		    this.HoldSignal = holdSignal;
		    this.HoldDelay = holdDelay;
		    this.TargetTurnTime = targetTurnTime;
		    this.PlantWasherNumber = plantWasherNumber;
		    this.WaterFlushTime = waterFlushTime;
		    this.Description = description;
		    this.LastModifiedTimestamp = lastModifiedTime;
		    this.LastSyncTime = lastSyncTime;
		    this.IsDelete = isDeleted;
            this.FormulaCount = formulaCount;
		    this.MyServiceCustMchGrpGuid = myServiceCustMchGrpGuid;
		    this.MyServiceCustMchGuid = myServiceCustMchGuid;
		    this.MyServiceMCHId = myServiceMCHId;
		    this.RatioDosingActive = ratioDosingActive;
		    this.EcolabWasherNumber = ecolabWasherNumber;
		    this.MyServiceModTime = myserviceLastSyncTime;
            this.IsPony = isPony;
		    this.ControllerModelId = controllerModelId;
            this.ControllerTypeId = controllerTypeId;
			this.FlowSwitchNumber = flowSwitchNumber;
			this.WasherStopExternalSignal = washerStopExternalSignal;
			this.OnHoldWESignalActive = onHoldWESignalActive;
			this.WasherOnHoldSignalDelay = washerOnHoldSignalDelay;
			this.ValveOutputsUsedAsTomSignal = valveOutputsUsedAsTomSignal;
			this.WeInTomMode = weInTomMode;
			this.ManifoldFlushTime = manifoldFlushTime;
			this.L1 = l1;
			this.L2 = l2;
			this.L3 = l3;
			this.L4 = l4;
			this.L5 = l5;
			this.L6 = l6;
			this.L7 = l7;
			this.L8 = l8;
			this.L9 = l9;
			this.L10 = l10;
			this.L11 = l11;
			this.L12 = l12;
		    this.MaxMachineLoad = maxMachineLoad;
		    this.MinMachineLoad = minMachineLoad;
		    this.ProgramSelectionByTime = programSelectionByTime;
			this.UseMe1OfGroup = useMe1OfGroup;
			this.UseMe2OfGroup = useMe2OfGroup;
			this.UsePumpOfGroup = usePumpOfGroup;
			this.WasherStopUseFinalExtracting = washerStopUseFinalExtracting;
			this.TemperatureAlarmYesNo = temperatureAlarmYesNo;
			this.PhProbe = phProbe;
			this.WeightCell = weightCell;
			this.Temperature = temperature;
			this.WaterCounter = waterCounter;

            this.DateAndTimeWhenBatchEjects = dateAndTimeWhenBatchEjects;
            this.AutoRinseDesamixAfter = autoRinseDesamixAfter;
            this.AutoRinseDesamix1For = autoRinseDesamix1For;
            this.AutoRinseDesamix2For = autoRinseDesamix2For;
            this.TemperatureAlarmProbe1 = temperatureAlarmProbe1;
            this.TemperatureAlarmProbe2 = temperatureAlarmProbe2;
            this.TemperatureAlarmProbe3 = temperatureAlarmProbe3;
            this.DefaultIdleTime = DefaultIdleTime;
            this.ETechWasherNumber = etechwashernumber;
            this.ControllerModel = controllerModel;
            this.ControllerType = controllerType;
            this.DelayTimeForTunWashingPrograms = delayTimeForTunWashingPrograms;
            this.EndOfFormula = endOfFormulaNumber;
            this.ExtendedClockOrDataProtocol = extendedClockOrDataProtocol;
            this.KannegiesserPressSpecialMode = kannegiesserPressSpecialMode;
            this.NoofCompartments = numberOfComp;
            this.NumberOfCompartmentsConveyorBelt = numberOfCompartmentsConveyorBelt;
            this.PressExtractor = pressExtractor;
            this.PressExtractorName = pressExtractorName;
            this.TransferType = transferType;
            this.TransferTypeName = transferTypeName;
            this.NoofTanks = numberOfTanks;
            this.SignalEjectionTunActive = signalEjectionTunActive;
            this.SignalStopTunActive = signalStopTunActive;
            this.TunInTomMode = tunInTomMode;
            this.WeightCorrectionFcc = weightCorrectionFcc;
            this.WeightSelectionByAnalogInput = weightSelectionByAnalogInput;
            this.WeightSelectionByTime = weightSelectionByTime;
            this.SignalAcceptanceTime = signalAcceptanceTime;
            this.KannegiesserPressSpecialMode = kannegiesserDosageInPreparationTankMode;
            this.BatchOk = batchOk;
            this.ExtractTimeForEOFSignal = extractTimeForEOFSignal;
            this.TransferPerHour = transferPerHour;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConventionalGeneral"/> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="myServiceWasherGroupGuid">My service washer group unique identifier.</param>
        /// <param name="machineName">Name of the machine.</param>
        /// <param name="modelName">Name of the model.</param>
        /// <param name="size">The size of Conventional General.</param>
        /// <param name="is_Tunnel">The is_ tunnel.</param>
        /// <param name="plantWasherNumber">The plant washer number.</param>
        /// <param name="modelId">The model identifier.</param>
        /// <param name="maxLoad">The maximum load.</param>
        /// <param name="maxLoad_UOMCode">The maximum load_ uom code.</param>
        /// <param name="description">The description.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceMachineGuid">My service machine unique identifier.</param>
        /// <param name="myServiceModTime">My service mod time.</param>
        /// <param name="regionId">The region identifier.</param>
        public ConventionalGeneral(string ecolabAccountNumber, Guid myServiceWasherGroupGuid, string machineName,
            string modelName, string size, string is_Tunnel, short plantWasherNumber, 
            int modelId, int maxLoad, string maxLoad_UOMCode, string description, bool isDeleted, Guid myServiceMachineGuid, DateTime myServiceModTime, int regionId
           )
        {
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.MyServiceCustMchGrpGuid = myServiceWasherGroupGuid;
            this.Name = machineName;
            this.ModelName = modelName;
            this.Size = size;
            this.Is_Tunnel = is_Tunnel;
            this.PlantWasherNumber = plantWasherNumber;
            this.MyServiceMCHId = (short)modelId;
            this.MaxLoad = (short)maxLoad;
            this.MaxLoad_UOMCode = maxLoad_UOMCode;
            this.Description = description;
            this.IsDelete = isDeleted;
            this.MyServiceCustMchGuid = myServiceMachineGuid;
            this.MyServiceModTime = myServiceModTime;
            this.RegionId = regionId;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The Parameter The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the modelName.
        /// </summary>
        /// <value>
        /// The Parameter The modelName.
        /// </value>
        public string ModelName { get; set; }

        /// <summary>
        /// Gets or sets the sizeId.
        /// </summary>
        /// <value>
        /// The Parameter The sizeId.
        /// </value>
        public int SizeId { get; set; }

        /// <summary>
        /// Gets or sets the size.
        /// </summary>
        /// <value>
        /// The Parameter The size.
        /// </value>
        public string Size { get; set; }

        /// <summary>
        /// Gets or sets the controller.
        /// </summary>
        /// <value>
        /// The Parameter The controller.
        /// </value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the name of the controller.
        /// </summary>
        /// <value>
        /// The Parameter The name of the controller.
        /// </value>
        public string ControllerName { get; set; }

        /// <summary>
        /// Gets or sets the WasherModeId.
        /// </summary>
        /// <value>
        /// The Parameter The WasherModeId.
        /// </value>
        public Int16 WasherModeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the WasherMode.
        /// </summary>
        /// <value>
        /// The name of the WasherMode.
        /// </value>
        public string WasherModeName { get; set; }

        /// <summary>
        /// Gets or sets the WasherModelId.
        /// </summary>
        /// <value>
        /// The WasherModelId.
        /// </value>
        public Int16 WasherModelId { get; set; }

        /// <summary>
        /// Gets or sets a WasherMode Tag.
        /// </summary>
        /// <value>
        /// The Parameter name.
        /// </value>
        public string WasherModeTag { get; set; }

        /// <summary>
        /// Gets or sets the name of the washer model.
        /// </summary>
        /// <value>
        /// The name of the washer model.
        /// </value>
        public string WasherModelName { get; set; }

        /// <summary>
        /// Gets or sets the LfsWasher.
        /// </summary>
        /// <value>
        /// The Parameter  LfsWasher.
        /// </value>
        public int? LfsWasher { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The Parameter  name.
        /// </value>
        public Int16 EndOfFormula { get; set; }

        /// <summary>
        /// Gets or sets the EndOfFormula Tag.
        /// </summary>
        /// <value>
        /// The Parameter  name.
        /// </value>
        public string EndOfFormulaTag { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool AweActive { get; set; }

        /// <summary>
        /// Gets or sets a AweActive Tag.
        /// </summary>
        /// <value>
        /// The Parameter name.
        /// </value>
        public string AweActiveTag { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [Hold signal].
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool HoldSignal { get; set; }

        /// <summary>
        /// Gets or sets the Hold Delay.
        /// </summary>
        /// <value>
        /// The Hold Delay.
        /// </value>
        public int HoldDelay { get; set; }

        /// <summary>
        /// Gets or sets a HoldDelay Tag.
        /// </summary>
        /// <value>
        /// The Parameter name.
        /// </value>
        public string HoldDelayTag { get; set; }

        /// <summary>
        /// Gets or sets the TargetTurnTime.
        /// </summary>
        /// <value>
        /// The TargetTurnTime.
        /// </value>
        public int TargetTurnTime { get; set; }

        /// <summary>
        /// Gets or sets the PlantWasherNumber.
        /// </summary>
        /// <value>
        /// The PlantWasherNumber.
        /// </value>
        public Int16 PlantWasherNumber { get; set; }

        /// <summary>
        /// Gets or sets the MaxLoad.
        /// </summary>
        /// <value>
        /// The Parameter  MaxLoad.
        /// </value>
        public Int16 MaxLoad { get; set; }

        /// <summary>
        /// Gets or sets the WaterFlushTime.
        /// </summary>
        /// <value>
        /// The Parameter WaterFlushTime.
        /// </value>
        public int WaterFlushTime { get; set; }

        /// <summary>
        /// InjectionRatio
        /// </summary>
        /// <value>
        /// The injection ratio.
        /// </value>
        public decimal InjectionRatio { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The Parameter  description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the washer group identifier.
        /// </summary>
        /// <value>
        /// The washer group identifier.
        /// </value>
        public int WasherGroupId { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the washer group identifier new.
        /// </summary>
        /// <value>
        /// The washer group identifier new.
        /// </value>
        public int WasherGroupIdNew { get; set; }

        /// <summary>
        /// Gets or sets the name of the washer group.
        /// </summary>
        /// <value>
        /// The name of the washer group.
        /// </value>
        public string WasherGroupName { get; set; }

        /// <summary>
        /// Gets or sets the name of the washer type.
        /// </summary>
        /// <value>
        /// The name of the washer type.
        /// </value>
        public string WasherTypeName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        /// Gets or sets the region identifier.
        /// </summary>
        /// <value>
        /// The region identifier.
        /// </value>
        public int RegionId { get; set; }

        /// <summary>
        /// Gets or sets the tags list for conventional.
        /// </summary>
        /// <value>
        /// Returns the list of tags.
        /// </value>
        public List<ConventionalTags> ConventionalWasherTagList { get; set; }

        /// <summary>
        /// Gets or sets the LastSyncTime
        /// </summary>
        /// <value>
        /// Last Sync Time
        /// </value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        /// Gets or sets Max Number Of Records
        /// </summary>
        /// <value>
        /// Max Number Of Records
        /// </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>
        /// LastModifiedTimeStamp
        /// </value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        /// Gets or sets the Is Delete
        /// </summary>
        /// <value>
        /// Is Delete Value
        /// </value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets the role.
        /// </summary>
        /// <value>
        /// The role of logged user.
        /// </value>
        public int Role { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustMchGrpGuid
        /// </summary>
        /// <value>
        /// MyServiceCustMchGrpGuid
        /// </value>
        public Guid MyServiceCustMchGrpGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustMchGuid
        /// </summary>
        /// <value>
        /// MyServiceCustMchGuid
        /// </value>
        public Guid MyServiceCustMchGuid { get; set; }

        /// <summary>
        /// Gets or sets the MyService Id.
        /// </summary>
        /// <value>
        /// The MyService Id..
        /// </value>
        public int MyServiceMCHId { get; set; }

        /// <summary>
        /// Gets or sets is_tunnel
        /// </summary>
        /// <value>
        /// Is_Tunnel Value
        /// </value>
        public string Is_Tunnel { get; set; }

        /// <summary>
        /// Gets or sets MaxLoad_UOMCode
        /// </summary>
        /// <value>
        /// MaxLoad_UOMCode
        /// </value>
        public string MaxLoad_UOMCode { get; set; }

        /// <summary>
        /// Gets or sets MyServiceModTime
        /// </summary>
        /// <value>
        /// MyServiceModTime
        /// </value>
        public DateTime? MyServiceModTime { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>
        /// LastModifiedTimestampAtCentral
        /// </value>
        public DateTime LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        /// Gets or sets FormulaCount
        /// </summary>
        /// <value>
        /// The formula count.
        /// </value>
        public int FormulaCount { get; set; }

        /// <summary>
        /// Gets or sets InjectionData
        /// </summary>
        /// <value>
        /// Injection Data
        /// </value>
        public List<Entities.WasherGroup.InjectionData> InjectionData { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [RatioDosingActive].
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool RatioDosingActive { get; set; }

        /// <summary>
        /// Gets or sets a value EcolabWasherNumber
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public int EcolabWasherNumber { get; set; }

        /// <summary>
        /// Gets or sets the Min Machine Load
        /// </summary>
        /// <value>
        /// Min Machine Load
        /// </value>
		public short MinMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets the Max Machine Load
        /// </summary>
        /// <value>
        /// Max Machine Load
        /// </value>
        public short MaxMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets the Program Selection By Time
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool ProgramSelectionByTime { get; set; }

        /// <summary>
        /// Gets or sets FlowSwitchNumber
        /// </summary>
        /// <value>
        /// Flow Switch Number
        /// </value>
        public int FlowSwitchNumber { get; set; }

        /// <summary>
        /// Gets or sets washerStopExternalSignal
        /// </summary>
        /// <value>
        /// washerStopExternalSignal
        /// </value>
        public bool WasherStopExternalSignal { get; set; }

        /// <summary>
        /// Gets or sets the WasherOnHoldSignalDelay
        /// </summary>
        /// <value>
        /// Washer on hold signal delay
        /// </value>
        public int WasherOnHoldSignalDelay { get; set; }

        /// <summary>
        /// Gets or sets the Value Outputs Used As TOM Signal
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool ValveOutputsUsedAsTomSignal { get; set; }

        /// <summary>
        /// Gets or sets the WE In TOM Mode
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool WeInTomMode { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L1
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L1 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L2
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L2 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L3
		/// </summary>
		/// <value>true/false</value>
		public bool L3 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L4
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L4 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L5
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L5 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L6
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L6 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L7
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L7 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L8
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L8 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L9
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L9 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L10
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L10 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L11
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L11 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L12
        /// </summary>
        /// <value>
        /// Returns true/false
        /// </value>
        public bool L12 { get; set; }

        /// <summary>
        /// Gets or sets the ManiFold Flush Time
        /// </summary>
        /// <value>
        /// Mani fold flush time
        /// </value>
        public int ManifoldFlushTime { get; set; }

        /// <summary>
        /// Gets or sets OnHoldWESignalActive
        /// </summary>
        /// <value>
        /// OnHoldWESignalActive
        /// </value>
        public bool OnHoldWESignalActive { get; set; }

        /// <summary>
        /// Gets or sets the controller model id
        /// </summary>
        /// <value>
        /// Controller model id
        /// </value>
        public int ControllerModelId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Pony Wahser or not.
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool IsPony { get; set; }

        /// <summary>
        /// Gets or sets the controller type id
        /// </summary>
        /// <value>
        /// Controller type id
        /// </value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or sets UseMe1OfGroup
        /// </summary>
        /// <value>
        /// The use me1 of group.
        /// </value>
        public byte? UseMe1OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UseMe2OfGroup
        /// </summary>
        /// <value>
        /// The use me2 of group.
        /// </value>
        public byte? UseMe2OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UsePumpOfGroup
        /// </summary>
        /// <value>
        /// The use pump of group.
        /// </value>
        public byte? UsePumpOfGroup { get; set; }

        /// <summary>
        /// Gets or sets WasherStopUseFinalExtracting
        /// </summary>
        /// <value>
        /// The washer stop use final extracting.
        /// </value>
        public bool? WasherStopUseFinalExtracting { get; set; }

        /// <summary>
        /// Gets or sets TemperatureAlarmYesNo
        /// </summary>
        /// <value>
        /// The temperature alarm yes no.
        /// </value>
        public bool? TemperatureAlarmYesNo { get; set; }

        /// <summary>
        /// Gets or sets PhProbe
        /// </summary>
        /// <value>
        /// The ph probe.
        /// </value>
        public bool? PhProbe { get; set; }

        /// <summary>
        /// Gets or sets WeightCell
        /// </summary>
        /// <value>
        /// The weight cell.
        /// </value>
        public bool? WeightCell { get; set; }

        /// <summary>
        /// Gets or sets Temperature
        /// </summary>
        /// <value>
        /// The temperature.
        /// </value>
        public bool? Temperature { get; set; }

        /// <summary>
        /// Gets or sets WaterCounter
        /// </summary>
        /// <value>
        /// The water counter.
        /// </value>
        public bool? WaterCounter { get; set; }

        /// <summary>
        /// Gets or sets the Date And Time When Batch Ejects
        /// </summary>
        /// <value>
        /// DateAndTimeWhenBatchEjects
        /// </value>
        public bool? DateAndTimeWhenBatchEjects { get; set; }

        /// <summary>
        /// Gets or sets the Auto Rinse Desamix After
        /// </summary>
        /// <value>
        /// Auto Rinse Desamix After
        /// </value>
        public short? AutoRinseDesamixAfter { get; set; }

        /// <summary>
        /// Gets or sets the Auto Rinse Desamix 1 For
        /// </summary>
        /// <value>
        /// Auto Rinse Desamix 1 For
        /// </value>
        public short? AutoRinseDesamix1For { get; set; }

        /// <summary>
        /// Gets or sets the Auto Rinse Desamix 2 For
        /// </summary>
        /// <value>
        /// Auto Rinse Desamix 2 For
        /// </value>
        public short? AutoRinseDesamix2For { get; set; }

        /// <summary>
        /// Gets or sets the Temperature Alarm Probe 1
        /// </summary>
        /// <value>
        /// Temperature Alarm Probe 1
        /// </value>
        public bool? TemperatureAlarmProbe1 { get; set; }

        /// <summary>
        /// Gets or sets the Temperature Alarm Probe 2
        /// </summary>
        /// <value>
        /// Temperature Alarm Probe 2
        /// </value>
        public bool? TemperatureAlarmProbe2 { get; set; }

        /// <summary>
        /// Gets or sets the Temperature Alarm Probe 3
        /// </summary>
        /// <value>
        /// Temperature Alarm Probe 3
        /// </value>
        public bool? TemperatureAlarmProbe3 { get; set; }

        /// <summary>
        /// Gets or sets the default idle time.
        /// </summary>
        /// <value>
        /// The default idle time.
        /// </value>
        public int DefaultIdleTime { get; set; }
        /// <summary>
        /// Gets or sets the Delay Time For TUN Washing Programs
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
		public bool DelayTimeForTunWashingPrograms { get; set; }

        /// <summary>
        /// Gets or sets the Kannegiesser Press Special Mode
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool KannegiesserPressSpecialMode { get; set; }

        /// <summary>
        /// Gets or sets the Extended Clock Or Data Protocol
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
		public bool ExtendedClockOrDataProtocol { get; set; }

        /// <summary>
        /// Gets or sets the no of compartments.
        /// </summary>
        /// <value>
        /// no of compartments.
        /// </value>
        public int NoofCompartments { get; set; }

        /// <summary>
        /// Gets or sets the Number Of Compartments Conveyor Belt
        /// </summary>
        /// <value>
        /// Number Of Compartments Conveyor Belt
        /// </value>
		public short NumberOfCompartmentsConveyorBelt { get; set; }

        /// <summary>
        /// Gets or sets the no of tanks.
        /// </summary>
        /// <value>
        /// The no of tanks.
        /// </value>
        public short? NoofTanks { get; set; }

        /// <summary>
        /// Gets or sets the press/extractor.
        /// </summary>
        /// <value>
        /// The press extractor.
        /// </value>
        public short? PressExtractor { get; set; }

        /// <summary>
        /// Gets or sets the type of the transfer.
        /// </summary>
        /// <value>
        /// The type of the transfer.
        /// </value>
        public short? TransferType { get; set; }
        /// <summary>
        /// Gets or sets the PressExtractorName.
        /// </summary>
        /// <value>
        /// The Press Extractor Name.
        /// </value>
        public string PressExtractorName { get; set; }

        /// <summary>
        /// Gets or sets the name of the transfer.
        /// </summary>
        /// <value>
        /// The name of the transfer.
        /// </value>
        public string TransferTypeName { get; set; }
        /// <summary>
        /// Gets or sets the Signal Ejection TUN Active
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
		public bool SignalEjectionTunActive { get; set; }
        /// <summary>
        /// Gets or sets the Signal Stop TUN Active
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
		public bool SignalStopTunActive { get; set; }
        /// <summary>
        /// Gets or sets the TUN In TOM Mode
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
		public bool TunInTomMode { get; set; }
        /// <summary>
        /// Gets or sets the Weight Correction (F.C.C)
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
		public bool WeightCorrectionFcc { get; set; }

        /// <summary>
        /// Gets or sets the Weight Selection By Time
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool WeightSelectionByTime { get; set; }

        /// <summary>
        /// Gets or sets the Weight Selection By Analog Input
        /// </summary>
        /// <value>
        ///   <c>true/false</c>.
        /// </value>
        public bool WeightSelectionByAnalogInput { get; set; }
        /// <summary>
        /// Gets or sets the name of the controller model.
        /// </summary>
        /// <value>
        /// The name of the controller model.
        /// </value>
		public string ControllerModel { get; set; }
        /// <summary>
        /// Gets or sets the name of the controller type.
        /// </summary>
        /// <value>
        /// The name of the controller type.
        /// </value>
		public string ControllerType { get; set; }

        /// <summary>
        /// Gets or sets the ETechWasherNumber
        /// </summary>
        /// <value>
        /// ETechWasherNumber
        /// </value>
        public int ETechWasherNumber { get; set; }

        /// <summary>
        /// Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>
        /// SignalAcceptanceTime
        /// </value>
        public int SignalAcceptanceTime { get; set; }

        /// <summary>
        /// Gets or sets the KannegiesserDosageInPreparationTankMode
        /// </summary>
        /// <value>
        /// KannegiesserDosageInPreparationTankMode
        /// </value>
        public bool KannegiesserDosageInPreparationTankMode { get; set; }

        /// <summary>
        /// Gets or sets the BatchOk
        /// </summary>
        /// <value>
        /// BatchOk Value
        /// </value>
        public bool BatchOk { get; set; }

        /// <summary>
        /// Gets or sets the Add Extracting Time To EOF Signal.
        /// </summary>
        /// <value>
        /// The name of the Add Extracting Time To EOF Signal.
        /// </value>
        public bool ExtractTimeForEOFSignal { get; set; }

        /// <summary>
        /// Gets or sets the transfer per hour.
        /// </summary>
        /// <value>
        /// The transfer per hour.
        /// </value>
        public int TransferPerHour { get; set; }

        #endregion Properties
    }
}
