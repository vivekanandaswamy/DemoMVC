﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSize.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModelSize for Getting WasherModelSize List .</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Washers.Conventional
{
    /// <summary>
    ///     Class WasherModelSize.
    /// </summary>
    public class WasherModelSize : BaseEntity
    {
        #region "Constructor"

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherModelSize" /> class.
        /// </summary>
        /// <param name="washerModelId">Washer Model Id</param>
        /// <param name="washerModelName">Washer Model Name</param>
        /// <param name="washerSize">Size of the washer.</param>
        /// <param name="myServiceMCHId">myServiceMCHId</param>
        public WasherModelSize(short washerModelId, string washerModelName, string washerSize, int myServiceMCHId)
        {
            this.WasherModelId = washerModelId;
            this.WasherModelName = washerModelName;
            this.WasherSize = washerSize;
            this.MyServiceMCHId = myServiceMCHId;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherModelSize" /> class for MyService .
        /// </summary>
        /// <param name="myServiceMCHId">my Service Id</param>
        /// <param name="washerModelName">Washer Model Name</param>
        /// <param name="modelTypeId">model Type Id of washer.</param>
        /// <param name="regionCode">region Code.</param>
        /// <param name="washerSize">Size of the washer.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceModDtTm">Last Synch time.</param>
        public WasherModelSize(int myServiceMCHId, string washerModelName, Int16 modelTypeId, string regionCode, string washerSize, bool isDeleted, DateTime myServiceModDtTm)
        {
            MyServiceMCHId = myServiceMCHId;
            WasherModelName = washerModelName;
            ModelTypeId = modelTypeId;
            RegionCode = regionCode;
            WasherSize = washerSize;
            IsDeleted = isDeleted;
            MyServiceModDtTm = myServiceModDtTm;
        }
        #endregion "Constructor"

        /// <summary>
        ///     Gets or sets the size of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public short WasherModelId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public string WasherModelName { get; set; }

        /// <summary>
        ///     Gets or sets the size of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public string WasherSize { get; set; }

        /// <summary>
        ///     Gets or sets the Model Type Id of the washer.
        /// </summary>
        /// <value>The Model Type Id of the washer.</value>
        public Int16 ModelTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the MyService Id.
        /// </summary>
        /// <value>The MyService Id..</value>
        public int MyServiceMCHId { get; set; }

        /// <summary>
        ///     Gets or sets the Region Code.
        /// </summary>
        /// <value>The Region Code.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the last synch time.
        /// </summary>
        /// <value>The last synch time.</value>
        public DateTime MyServiceModDtTm { get; set; }
    }
}