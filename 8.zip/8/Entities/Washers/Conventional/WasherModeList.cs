﻿// -----------------------------------------------------------------------
// <copyright file="WasherModeList.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModeList object</summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Conventional
{
    /// <summary>
    ///     Class WasherModeList.
    /// </summary>
    public class WasherModeList : BaseEntity
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="WasherModeList" /> class.
        /// </summary>
        /// <param name="id">The Parameter identifier.</param>
        /// <param name="name">The Parameter name.</param>
        /// <param name="resourceKey">The Resource Key.</param>
        public WasherModeList(int id, string name, string resourceKey)
        {
            this.Id = id;
            this.Name = name;
            this.ResourceKey = resourceKey;
        }

        public WasherModeList(int id, string name, string resourceKey,string washerModeNumber)
        {
            this.Id = id;
            this.Name = name;
            this.ResourceKey = resourceKey;
            this.WasherModeNumber = washerModeNumber;
        }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The Parameter name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the ResourceKey.
        /// </summary>
        /// <value>The Parameter Resource Key.</value>
        public string ResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets the WasherModeNumber.
        /// </summary>
        /// <value>The Parameter WasherModeNumber.</value>
        public string WasherModeNumber { get; set; }

    }
}