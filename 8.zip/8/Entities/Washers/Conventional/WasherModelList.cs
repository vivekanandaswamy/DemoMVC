﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelList.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Washers object</summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Conventional
{
    /// <summary>
    ///     Class WasherModelList
    /// </summary>
    public class WasherModelList
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="WasherModelList" /> class.
        /// </summary>
        /// <param name="washerModelName">Name of the washer model.</param>
        public WasherModelList(string washerModelName)
        {
            this.WasherModelName = washerModelName;
        }

        #endregion "Constructor"

        #region Properties

        /// <summary>
        ///     Gets or sets the name of the washer model.
        /// </summary>
        /// <value>The name of the washer model.</value>
        public string WasherModelName { get; set; }

        #endregion Properties
    }
}