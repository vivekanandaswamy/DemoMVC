﻿// ***********************************************************************
// <copyright file="PumpsProductList.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>The Pumps Product List</summary>
// ***********************************************************************

namespace Entities.Washers.Conventional
{
    /// <summary>
    ///     Class PumpsProductList.
    /// </summary>
    public class PumpsProductList
    {
        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="PumpsProductList" /> class.
        /// </summary>
        public PumpsProductList()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PumpsProductList" /> class.
        /// </summary>
        /// <param name="controllerEquipmentSetupId">Controller Equipment Setup Id</param>
        /// <param name="controllerEquipmentId">Controller Equipment Id</param>
        /// <param name="controllerEquipmentSetupIdName">Controller Equipment SetupId Name</param>
        /// <param name="controllerEquipmentTypeId">Controller Equipment Type Id</param>
        /// <param name="productName">Product Name</param>
        public PumpsProductList(short controllerEquipmentSetupId, byte controllerEquipmentId, string controllerEquipmentSetupIdName, byte controllerEquipmentTypeId, string productName)
        {
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ControllerEquipmentId = controllerEquipmentId;
            this.ControllerEquipmentSetupIdName = controllerEquipmentSetupIdName;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
            this.ProductName = productName;
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        ///     Gets or sets the controller equipment setup identifier.
        /// </summary>
        /// <value>The controller equipment setup identifier.</value>
        public short ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>The controller equipment identifier.</value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment type identifier.
        /// </summary>
        /// <value>The controller equipment type identifier.</value>
        public byte ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller equipment setup identifier.
        /// </summary>
        /// <value>The name of the controller equipment setup identifier.</value>
        public string ControllerEquipmentSetupIdName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }

        #endregion Properties
    }
}