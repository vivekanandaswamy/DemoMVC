﻿// -----------------------------------------------------------------------
// <copyright file="PumpsAndMECount.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PumpsAndMECount </summary>
// -----------------------------------------------------------------------

namespace Entities.Washers
{
    /// <summary>
    ///     The PumpsAndMECount Class
    /// </summary>
    public class PumpsAndMECount : BaseEntity
    {
        public PumpsAndMECount(byte pumpsCount, byte meCount)
        {
            this.PumpsCount = pumpsCount;
            this.MECount = meCount;
        }

        /// <summary>
        ///     gets the ID
        /// </summary>
        /// <value>The WasherProductDeviationID.</value>
        public int PumpsCount { get; set; }

        /// <summary>
        ///     gets the MECount 
        /// </summary>
        /// <value>The MECount.</value>
        public int MECount { get; set; }
    }
}
