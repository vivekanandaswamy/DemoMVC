﻿// -----------------------------------------------------------------------
// <copyright file="Washers.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The Washers is for get and set the data.</summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.Washers
{
    /// <summary>
    ///     class Washers
    /// </summary>
    public class Washers : BaseEntity
    {
        /// <summary>
        /// Default Constructor for Washers
        /// </summary>
        public Washers()
        {
        }

        /// <summary>
        /// Constructor for Washers
        /// </summary>
        /// <param name="washerNumber">The washerNumber</param>
        /// <param name="washerName">The washerName</param>
        /// <param name="washerType">The washerType</param>
        /// <param name="washerTypeFlag">if set to <c>true</c> [washer type flag].</param>
        /// <param name="washerModel">The washerModel</param>
        /// <param name="modelId">The model identifier.</param>
        /// <param name="size">The Parameter size</param>
        /// <param name="controllerName">The controller Name</param>
        /// <param name="washerId">The Parameter washerId</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="washerGroupName">Name of the washer group.</param>
        /// <param name="washerControllerId">The washer controller identifier.</param>
        /// <param name="description">The Parameter description.</param>
        /// <param name="maxLoad">The maximum load.</param>
        /// <param name="washerMode">The washer mode.</param>
        /// <param name="aweActive">if set to <c>true</c> [awe active].</param>
        /// <param name="noOfCompartments">The no of compartments.</param>
        /// <param name="noOfTanks">The no of tanks.</param>
        /// <param name="pressExtractor">The press extractor.</param>
        /// <param name="transferType">Type of the transfer.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="holdSignal">The hold signal.</param>
        /// <param name="holdDelay">if set to <c>true</c> [hold delay].</param>
        /// <param name="targetTurnTime">The target turn time.</param>
        /// <param name="waterFlushTime">The water flush time.</param>
        /// <param name="lfsWasher">The LFS washer.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="formulaCount">The formula count.</param>
        /// <param name="myServiceWasherGroupGuid">My service washer group unique identifier.</param>
        /// <param name="myServiceWashersGuid">My service washers unique identifier.</param>
        /// <param name="myServiceMCHId">My service MCH identifier.</param>
        /// <param name="pressExtractorName">Name of the press extractor.</param>
        /// <param name="transferTypeName">Name of the transfer type.</param>
        /// <param name="ratioDosingActive">The Ratio Dosing Active.</param>
        /// <param name="ecolabWasherNumber">The ecolab washer number.</param>
        /// <param name="endOfFormula">The end of formula.</param>
        /// <param name="myServiceLastSyncTime">My service last synchronize time.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <param name="controllerType">Type of the controller.</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <param name="controllerModel">The controller model.</param>
        /// <param name="numberOfCompartmentsConveyorBelt">The number of compartments conveyor belt.</param>
        /// <param name="minMachineLoad">The minimum machine load.</param>
        /// <param name="maxMachineLoad">The maximum machine load.</param>
        /// <param name="programSelectionByTime">if set to <c>true</c> [program selection by time].</param>
        /// <param name="weightSelectionByTime">if set to <c>true</c> [weight selection by time].</param>
        /// <param name="weightSelectionByAnalogInput">if set to <c>true</c> [weight selection by analog input].</param>
        /// <param name="tunInTomMode">if set to <c>true</c> [tun in tom mode].</param>
        /// <param name="signalStopTunActive">if set to <c>true</c> [signal stop tun active].</param>
        /// <param name="signalEjectionTunActive">if set to <c>true</c> [signal ejection tun active].</param>
        /// <param name="delayTimeForTunWashingPrograms">if set to <c>true</c> [delay time for tun washing programs].</param>
        /// <param name="kannegiesserPressSpecialMode">if set to <c>true</c> [kannegiesser press special mode].</param>
        /// <param name="valueOutputsUsedAsTomSignal">if set to <c>true</c> [value outputs used as tom signal].</param>
        /// <param name="extendedClockOrDataProtocol">if set to <c>true</c> [extended clock or data protocol].</param>
        /// <param name="weightCorrectionFcc">if set to <c>true</c> [weight correction FCC].</param>
        /// <param name="flowSwitchNumber">The flow switch number.</param>
        /// <param name="washerStopExternalSignal">if set to <c>true</c> [washer stop external signal].</param>
        /// <param name="onHoldWESignalActive">if set to <c>true</c> [on hold we signal active].</param>
        /// <param name="washerOnHoldSignalDelay">The washer on hold signal delay.</param>
        /// <param name="weInTomMode">if set to <c>true</c> [we in tom mode].</param>
        /// <param name="manifoldFlushTime">The manifold flush time.</param>
        /// <param name="l1">if set to <c>true</c> [l1].</param>
        /// <param name="l2">if set to <c>true</c> [l2].</param>
        /// <param name="l3">if set to <c>true</c> [l3].</param>
        /// <param name="l4">if set to <c>true</c> [l4].</param>
        /// <param name="l5">if set to <c>true</c> [l5].</param>
        /// <param name="l6">if set to <c>true</c> [l6].</param>
        /// <param name="l7">if set to <c>true</c> [l7].</param>
        /// <param name="l8">if set to <c>true</c> [l8].</param>
        /// <param name="l9">if set to <c>true</c> [l9].</param>
        /// <param name="l10">if set to <c>true</c> [L10].</param>
        /// <param name="l11">if set to <c>true</c> [L11].</param>
        /// <param name="l12">if set to <c>true</c> [L12].</param>
        /// <param name="isPony">if set to <c>true</c> [is pony].</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="useMe1OfGroup">The use me1 of group.</param>
        /// <param name="useMe2OfGroup">The use me2 of group.</param>
        /// <param name="usePumpOfGroup">The use pump of group.</param>
        /// <param name="washerStopUseFinalExtracting">The washer stop use final extracting.</param>
        /// <param name="temperatureAlarmYesNo">The temperature alarm yes no.</param>
        /// <param name="phProbe">The ph probe.</param>
        /// <param name="weightCell">The weight cell.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="waterCounter">The water counter.</param>
        /// <param name="dateAndTimeWhenBatchEjects">The date and time when batch ejects.</param>
        /// <param name="autoRinseDesamixAfter">The automatic rinse desamix after.</param>
        /// <param name="autoRinseDesamix1For">The automatic rinse desamix1 for.</param>
        /// <param name="autoRinseDesamix2For">The automatic rinse desamix2 for.</param>
        /// <param name="temperatureAlarmProbe1">The temperature alarm probe1.</param>
        /// <param name="temperatureAlarmProbe2">The temperature alarm probe2.</param>
        /// <param name="temperatureAlarmProbe3">The temperature alarm probe3.</param>
        /// <param name="DefaultIdleTime">The default idle time.</param>
        /// <param name="etechwashernumber">The etechwashernumber.</param>
        /// <param name="signalAcceptanceTime">The signal acceptance time.</param>
        /// <param name="kannegiesserDosageInPreparationTankMode">if set to <c>true</c> [kannegiesser dosage in preparation tank mode].</param>
        /// <param name="batchOk">if set to <c>true</c> [batch ok].</param>
        /// <param name="extractTimeForEOFSignal">if set to <c>true</c> [Add Extracting Time To EOF Signal].</param>
        /// <param name="transferPerHour">The transfer per hour.</param>
        public Washers(
            short washerNumber,
            string washerName,
            string washerType,
            bool washerTypeFlag,
            string washerModel,
            short modelId,
            string size,
            string controllerName,
            int washerId,
            int washerGroupId,
            string washerGroupName,
            int washerControllerId,
            string description,
            short maxLoad,
            short washerMode,
            bool aweActive,
            int noOfCompartments,
            short noOfTanks,
            short pressExtractor,
            short transferType,
            short programNumber,
            bool holdSignal,
            int holdDelay,
            int targetTurnTime,
            int waterFlushTime,
            int lfsWasher,
            DateTime lastModifiedTime,
            DateTime lastSyncTime,
            bool isDeleted,
            string ecolabAccountNumber,
            int formulaCount,
            Guid myServiceWasherGroupGuid,
            Guid myServiceWashersGuid,
            int myServiceMCHId,
            string pressExtractorName,
            string transferTypeName,
            bool ratioDosingActive,
            int ecolabWasherNumber,
            short endOfFormula,
            DateTime? myServiceLastSyncTime,
            int controllerTypeId,
            string controllerType,
            int controllerModelId,
            string controllerModel,
            short numberOfCompartmentsConveyorBelt,
            short minMachineLoad,
            short maxMachineLoad,
            bool programSelectionByTime,
            bool weightSelectionByTime,
            bool weightSelectionByAnalogInput,
            bool tunInTomMode,
            bool signalStopTunActive,
            bool signalEjectionTunActive,
            bool delayTimeForTunWashingPrograms,
            bool kannegiesserPressSpecialMode,
            bool valueOutputsUsedAsTomSignal,
            bool extendedClockOrDataProtocol,
            bool weightCorrectionFcc,
            //bool isActive,
            int flowSwitchNumber,
            bool washerStopExternalSignal,
            bool onHoldWESignalActive,
            int washerOnHoldSignalDelay,
            bool weInTomMode,
            int manifoldFlushTime,
            bool l1,
            bool l2,
            bool l3,
            bool l4,
            bool l5,
            bool l6,
            bool l7,
            bool l8,
            bool l9,
            bool l10,
            bool l11,
            bool l12,
            bool isPony,
            int plantId,
            byte? useMe1OfGroup,
            byte? useMe2OfGroup,
            byte? usePumpOfGroup,
            bool? washerStopUseFinalExtracting,
            bool? temperatureAlarmYesNo,
            bool? phProbe,
            bool? weightCell,
            bool? temperature,
            bool? waterCounter,
            bool? dateAndTimeWhenBatchEjects,
            short? autoRinseDesamixAfter,
            short? autoRinseDesamix1For,
            short? autoRinseDesamix2For,
            bool? temperatureAlarmProbe1,
            bool? temperatureAlarmProbe2,
            bool? temperatureAlarmProbe3,
            int DefaultIdleTime,
            int etechwashernumber,
            int signalAcceptanceTime,
            bool kannegiesserDosageInPreparationTankMode,
            bool batchOk,
            bool extractTimeForEOFSignal,
            int transferPerHour
            )
        {
            this.Id = washerId;
            this.WasherNumber = washerNumber;
            this.WasherName = washerName;
            this.WasherType = washerType;
            this.WasherModel = washerModel;
            this.Size = size;
            this.ControllerName = controllerName;
            this.WasherGroupId = washerGroupId;
            this.WasherGroupName = washerGroupName;
            this.WasherControllerId = washerControllerId;
            this.WasherTypeFlag = washerTypeFlag;
            this.Maxload = maxLoad;
            this.LastModifiedTimeStamp = lastModifiedTime;
            this.LastSyncTime = lastSyncTime;
            this.IsDelete = isDeleted;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.MyServiceCustMchGrpGuid = myServiceWasherGroupGuid;
            this.MyServiceCustMchGuid = myServiceWashersGuid;
            this.RatioDosingActive = ratioDosingActive;
            this.EcolabWasherNumber = ecolabWasherNumber;
            this.MyServiceLastSyncTime = myServiceLastSyncTime;
            this.IsPony = isPony;
            this.ControllerTypeId = controllerTypeId;
            this.ControllerType = controllerType;
            this.ControllerModelId = controllerModelId;
            this.ControllerModel = controllerModel;
            this.NumberOfCompartmentsConveyorBelt = numberOfCompartmentsConveyorBelt;
            this.MinMachineLoad = minMachineLoad;
            this.MaxMachineLoad = maxMachineLoad;
            this.ProgramSelectionByTime = programSelectionByTime;
            this.WeightSelectionByTime = weightSelectionByTime;
            this.WeightSelectionByAnalogInput = weightSelectionByAnalogInput;
            this.TunInTomMode = tunInTomMode;
            this.SignalStopTunActive = signalStopTunActive;
            this.SignalEjectionTunActive = signalEjectionTunActive;
            this.DelayTimeForTunWashingPrograms = delayTimeForTunWashingPrograms;
            this.KannegiesserPressSpecialMode = kannegiesserPressSpecialMode;
            this.ValueOutputsUsedAsTomSignal = valueOutputsUsedAsTomSignal;
            this.ExtendedClockOrDataProtocol = extendedClockOrDataProtocol;
            this.WeightCorrectionFcc = weightCorrectionFcc;
            this.PlantId = plantId;
            this.UseMe1OfGroup = useMe1OfGroup;
            this.UseMe2OfGroup = useMe2OfGroup;
            this.UsePumpOfGroup = usePumpOfGroup;
            this.WasherStopUseFinalExtracting = washerStopUseFinalExtracting;
            this.TemperatureAlarmYesNo = temperatureAlarmYesNo;
            this.PhProbe = phProbe;
            this.WeightCell = weightCell;
            this.Temperature = temperature;
            this.WaterCounter = waterCounter;
            this.DateAndTimeWhenBatchEjects = dateAndTimeWhenBatchEjects;
            this.AutoRinseDesamixAfter = autoRinseDesamixAfter;
            this.AutoRinseDesamix1For = autoRinseDesamix1For;
            this.AutoRinseDesamix2For = autoRinseDesamix2For;
            this.TemperatureAlarmProbe1 = temperatureAlarmProbe1;
            this.TemperatureAlarmProbe2 = temperatureAlarmProbe2;
            this.TemperatureAlarmProbe3 = temperatureAlarmProbe3;
            this.DefaultIdleTime = DefaultIdleTime;
            this.AweActive = aweActive;
            this.Description = description;
            this.EndOfFormula = endOfFormula;
            this.FlowSwitchNumber = FlowSwitchNumber;
            this.FormulaCount = formulaCount;
            this.HoldDelay = holdDelay;
            this.HoldSignal = holdSignal;
            this.L1 = l1;
            this.L2 = l2;
            this.L3 = l3;
            this.L4 = l4;
            this.L5 = l5;
            this.L6 = l6;
            this.L7 = l7;
            this.L8 = l8;
            this.L9 = l9;
            this.L10 = l10;
            this.L11 = l11;
            this.L12 = l12;
            this.LfsWasher = lfsWasher;
            this.ManifoldFlushTime = manifoldFlushTime;
            this.WasherModelId = modelId;
            this.MyServiceMCHId = myServiceMCHId;
            this.NoofCompartments = noOfCompartments;
            this.NoofTanks = noOfTanks;
            this.PressExtractor = pressExtractor;
            this.PressExtractorName = pressExtractorName;
            this.TransferType = transferType;
            this.TransferTypeName = transferTypeName;
            this.ProgramNumber = programNumber;
            this.WasherOnHoldSignalDelay = washerOnHoldSignalDelay;
            this.OnHoldWESignalActive = onHoldWESignalActive;
            this.TargetTurnTime = targetTurnTime;
            this.WasherMode = washerMode;
            this.WasherStopExternalSignal = washerStopExternalSignal;
            this.WaterFlushTime = waterFlushTime;
            this.WeInTomMode = weInTomMode;
            this.ETechWasherNumber = etechwashernumber;
            this.SignalAcceptanceTime = signalAcceptanceTime;
            this.KannegiesserPressSpecialMode = kannegiesserDosageInPreparationTankMode;
            this.BatchOk = batchOk;
            this.ExtractTimeForEOFSignal = extractTimeForEOFSignal;
            this.TransferPerHour = transferPerHour;
        }

        /// <summary>
        ///     Gets or sets the WasherNumber
        /// </summary>
        /// <value>The washer number.</value>
        public short WasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the WasherName
        /// </summary>
        /// <value>The name of the washer.</value>
        public string WasherName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherType
        /// </summary>
        /// <value>The type of the washer.</value>
        public string WasherType { get; set; }

        /// <summary>
        ///     Gets or sets the WasherModel
        /// </summary>
        /// <value>The washer model.</value>
        public string WasherModel { get; set; }

        /// <summary>
        ///     Gets or sets the Size
        /// </summary>
        /// <value>The size.</value>
        public string Size { get; set; }

        /// <summary>
        ///     Gets or sets the Controller
        /// </summary>
        /// <value>The name of the controller.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the controller Type Id.
        /// </summary>
        /// <value>The Parameter controller Type id.</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller type.
        /// </summary>
        /// <value>The name of the controller type.</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the controller Model Id.
        /// </summary>
        /// <value>The Parameter controller Model id.</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller model.
        /// </summary>
        /// <value>The name of the controller model.</value>
        public string ControllerModel { get; set; }

        /// <summary>
        ///     Gets or sets the washer group identifier.
        /// </summary>
        /// <value>The washer group identifier.</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the washer controller identifier.
        /// </summary>
        /// <value>The washer controller identifier.</value>
        public int WasherControllerId { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        ///     Gets or sets the Maxload
        /// </summary>
        /// <value>The Max load.</value>
        public short Maxload { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Formula Count
        /// </summary>
        /// <value>FormulaCount</value>
        public int FormulaCount { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceCustMchGrpGuid
        /// </summary>
        /// <value>MyServiceCustMchGrpGuid</value>
        public Guid MyServiceCustMchGrpGuid { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceCustMchGuid
        /// </summary>
        /// <value>MyServiceCustMchGuid</value>
        public Guid MyServiceCustMchGuid { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [RatioDosingActive].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool RatioDosingActive { get; set; }

        /// <summary>
        ///     Gets or sets EcolabWasherNumber
        /// </summary>
        /// <value>EcolabWasherNumber</value>
        public int EcolabWasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceLastSyncTime
        /// </summary>
        public DateTime? MyServiceLastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public int LfsWasher { get; set; }

        /// <summary>
        ///     Gets or sets the Number Of Compartments Conveyor Belt
        /// </summary>
        /// <value>Number Of Compartments Conveyor Belt</value>
        public short NumberOfCompartmentsConveyorBelt { get; set; }

        /// <summary>
        ///     Gets or sets the Min Machine Load
        /// </summary>
        /// <value>Min Machine Load</value>
        public short MinMachineLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Max Machine Load
        /// </summary>
        /// <value>Max Machine Load</value>
        public short MaxMachineLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Program Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ProgramSelectionByTime { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightSelectionByTime { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Selection By Analog Input
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightSelectionByAnalogInput { get; set; }

        /// <summary>
        ///     Gets or sets the TUN In TOM Mode
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool TunInTomMode { get; set; }

        /// <summary>
        ///     Gets or sets the Signal Stop TUN Active
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool SignalStopTunActive { get; set; }

        /// <summary>
        ///     Gets or sets the Signal Ejection TUN Active
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool SignalEjectionTunActive { get; set; }

        /// <summary>
        ///     Gets or sets the Delay Time For TUN Washing Programs
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool DelayTimeForTunWashingPrograms { get; set; }

        /// <summary>
        ///     Gets or sets the Kannegiesser Press Special Mode
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool KannegiesserPressSpecialMode { get; set; }

        /// <summary>
        ///     Gets or sets the Value Outputs Used As TOM Signal
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ValueOutputsUsedAsTomSignal { get; set; }

        /// <summary>
        ///     Gets or sets the Extended Clock Or Data Protocol
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ExtendedClockOrDataProtocol { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Correction (F.C.C)
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightCorrectionFcc { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether Pony Wahser or not.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool IsPony { get; set; }

        /// <summary>
        /// Gets or sets UseMe1OfGroup
        /// </summary>
        public byte? UseMe1OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UseMe2OfGroup
        /// </summary>
        public byte? UseMe2OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UsePumpOfGroup
        /// </summary>
        public byte? UsePumpOfGroup { get; set; }

        /// <summary>
        /// Gets or sets WasherStopUseFinalExtracting
        /// </summary>
        public bool? WasherStopUseFinalExtracting { get; set; }

        /// <summary>
        /// Gets or sets TemperatureAlarmYesNo
        /// </summary>
        public bool? TemperatureAlarmYesNo { get; set; }

        /// <summary>
        /// Gets or sets PhProbe
        /// </summary>
        public bool? PhProbe { get; set; }

        /// <summary>
        /// Gets or sets WeightCell
        /// </summary>
        public bool? WeightCell { get; set; }

        /// <summary>
        /// Gets or sets Temperature
        /// </summary>
        public bool? Temperature { get; set; }

        /// <summary>
        /// Gets or sets WaterCounter
        /// </summary>
        public bool? WaterCounter { get; set; }

        /// <summary>
        ///     Gets or sets the Date And Time When Batch Ejects
        /// </summary>
        /// <value>DateAndTimeWhenBatchEjects</value>
        public bool? DateAndTimeWhenBatchEjects { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix After
        /// </summary>
        /// <value>Auto Rinse Desamix After</value>
        public short? AutoRinseDesamixAfter { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 1 For
        /// </summary>
        /// <value>Auto Rinse Desamix 1 For</value>
        public short? AutoRinseDesamix1For { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 2 For
        /// </summary>
        /// <value>Auto Rinse Desamix 2 For</value>
        public short? AutoRinseDesamix2For { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 1
        /// </summary>
        /// <value>Temperature Alarm Probe 1</value>
        public bool? TemperatureAlarmProbe1 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 2
        /// </summary>
        /// <value>Temperature Alarm Probe 2</value>
        public bool? TemperatureAlarmProbe2 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 3
        /// </summary>
        /// <value>Temperature Alarm Probe 3</value>
        public bool? TemperatureAlarmProbe3 { get; set; }

        /// <summary>
        /// Gets or sets the default idle time.
        /// </summary>
        /// <value>The default idle time.</value>
        public int DefaultIdleTime { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool AweActive { get; set; }
        /// <summary>
        ///     Gets or sets the description.
        /// </summary>
        /// <value>The Parameter  description.</value>
        public string Description { get; set; }
        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The Parameter  name.</value>
        public Int16 EndOfFormula { get; set; }
        /// <summary>
		/// Gets or sets FlowSwitchNumber
		/// </summary>
		/// <value>Flow Switch Number</value>
		public int FlowSwitchNumber { get; set; }
        /// <summary>
        ///     Gets or sets the Hold Delay.
        /// </summary>
        /// <value>The Hold Delay.</value>
        public int HoldDelay { get; set; }
        /// <summary>
        ///     Gets or sets a value indicating whether [Hold signal].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool HoldSignal { get; set; }
        /// <summary>
		/// Gets or sets the Lines Connected to Manifold L1
		/// </summary>
		/// <value>true/false</value>
		public bool L1 { get; set; }
        /// <summary>
		/// Gets or sets the Lines Connected to Manifold L2
		/// </summary>
		/// <value>true/false</value>
		public bool L2 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L3
        /// </summary>
        /// <value>true/false</value>
        public bool L3 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L4
        /// </summary>
        /// <value>true/false</value>
        public bool L4 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L5
        /// </summary>
        /// <value>true/false</value>
        public bool L5 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L6
        /// </summary>
        /// <value>true/false</value>
        public bool L6 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L7
        /// </summary>
        /// <value>true/false</value>
        public bool L7 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L8
        /// </summary>
        /// <value>true/false</value>
        public bool L8 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L9
        /// </summary>
        /// <value>true/false</value>
        public bool L9 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L10
        /// </summary>
        /// <value>true/false</value>
        public bool L10 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L11
        /// </summary>
        /// <value>true/false</value>
        public bool L11 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L12
        /// </summary>
        /// <value>true/false</value>
        public bool L12 { get; set; }

        /// <summary>
        /// Gets or sets the ManiFold Flush Time
        /// </summary>
        /// <value>Mani fold flush time</value>
        public int ManifoldFlushTime { get; set; }
        /// <summary>
        ///     Gets or sets the WasherModelId.
        /// </summary>
        /// <value>The WasherModelId.</value>
        public Int16 WasherModelId { get; set; }
        /// <summary>
        ///     Gets or sets the MyService Id.
        /// </summary>
        /// <value>The MyService Id..</value>
        public int MyServiceMCHId { get; set; }
        /// <summary>
        ///     Gets or sets the no of compartments.
        /// </summary>
        /// <value>no of compartments.</value>
        public int NoofCompartments { get; set; }
        /// <summary>
        ///     Gets or sets the no of tanks.
        /// </summary>
        /// <value>The no of tanks.</value>
        public short? NoofTanks { get; set; }

        /// <summary>
        ///     Gets or sets the press/extractor.
        /// </summary>
        /// <value>The press extractor.</value>
        public short? PressExtractor { get; set; }

        /// <summary>
        ///     Gets or sets the PressExtractorName.
        /// </summary>
        /// <value>The Press Extractor Name.</value>
        public string PressExtractorName { get; set; }

        /// <summary>
        ///     Gets or sets the type of the transfer.
        /// </summary>
        /// <value>The type of the transfer.</value>
        public short? TransferType { get; set; }

        /// <summary>
        ///     Gets or sets the program number.
        /// </summary>
        /// <value>The program number.</value>
        public short ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the TargetTurnTime.
        /// </summary>
        /// <value>The TargetTurnTime.</value>
        public int TargetTurnTime { get; set; }
        /// <summary>
        ///     Gets or sets the name of the transfer.
        /// </summary>
        /// <value>The name of the transfer.</value>
        public string TransferTypeName { get; set; }
        /// <summary>
        ///     Gets or sets the washer mode.
        /// </summary>
        /// <value>The washer mode.</value>
        public short WasherMode { get; set; }
        /// <summary>
		/// Gets or sets washerStopExternalSignal
		/// </summary>
		/// <value>washerStopExternalSignal</value>
		public bool WasherStopExternalSignal { get; set; }

        /// <summary>
        /// Gets or sets the WasherOnHoldSignalDelay
        /// </summary>
        /// <value>Washer on hold signal delay</value>
        public int WasherOnHoldSignalDelay { get; set; }
        /// <summary>
        ///     Gets or sets the WaterFlushTime.
        /// </summary>
        /// <value>The Parameter WaterFlushTime.</value>
        public int WaterFlushTime { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [we in tom mode].
        /// </summary>
        /// <value><c>true</c> if [we in tom mode]; otherwise, <c>false</c>.</value>
        public bool WeInTomMode { get; set; }

        /// <summary>
		/// Gets or sets OnHoldWESignalActive
		/// </summary>
		/// <value>OnHoldWESignalActive</value>
		public bool OnHoldWESignalActive { get; set; }

        /// <summary>
        ///     Gets or sets the ETechWasherNumber
        /// </summary>
        /// <value>ETechWasherNumber</value>
        public int ETechWasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>SignalAcceptanceTime</value>
        public int SignalAcceptanceTime { get; set; }

        /// <summary>
        ///     Gets or sets the KannegiesserDosageInPreparationTankMode
        /// </summary>
        /// <value>KannegiesserDosageInPreparationTankMode</value>
        public bool KannegiesserDosageInPreparationTankMode { get; set; }

        /// <summary>
        ///     Gets or sets the BatchOk
        /// </summary>
        /// <value>BatchOk</value>
        public bool BatchOk { get; set; }

        /// <summary>
        /// Gets or sets the Add Extracting Time To EOF Signal.
        /// </summary>
        /// <value>
        /// The name of the Add Extracting Time To EOF Signal.
        /// </value>
        public bool ExtractTimeForEOFSignal { get; set; }

        /// <summary>
        /// Gets or sets the transfer per hour.
        /// </summary>
        /// <value>
        /// The transfer per hour.
        /// </value>
        public int TransferPerHour { get; set; }
    }
}