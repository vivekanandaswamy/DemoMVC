﻿// <copyright file="PumpAssociation.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>The Pump Association</summary>
// ***********************************************************************

using System;
namespace Entities.Washers.Tunnel
{
    /// <summary>
    ///     Class PumpAssociation.
    /// </summary>
    public class PumpAssociation : BaseEntity
    {
        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="PumpAssociation" /> class.
        /// </summary>
        public PumpAssociation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PumpAssociation" /> class.
        /// </summary>
        /// <param name="controllerEquipmentSetupId">Value of controller Equipment Setup Identifier.</param>
        /// <param name="controllerEquipmentId">Value of controller Equipment Identifier.</param>
        /// <param name="controllerEquipmentSetupIdName">Value of controlle rEquipment Setup Identifier Name.</param>
        /// <param name="controllerEquipmentTypeId">Value of controlle rEquipment Type Identifier.</param>
        /// <param name="productName">Value of Product name.</param>
        public PumpAssociation(short controllerEquipmentSetupId, byte controllerEquipmentId, string controllerEquipmentSetupIdName, byte controllerEquipmentTypeId, string productName)
        {
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ControllerEquipmentId = controllerEquipmentId;
            this.ControllerEquipmentSetupIdName = controllerEquipmentSetupIdName;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
            this.ProductName = productName;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PumpAssociation" /> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">value of Ecolab Account number</param>
        /// <param name="controllerEquipmentSetupId">Value of controller Equipment Setup Identifier.</param>
        /// <param name="isDeleted">falg  value for is delte.</param>
        public PumpAssociation(string ecolabAccountNumber, short controllerEquipmentSetupId, bool isDeleted)
        {
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.IsDeleted = isDeleted;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PumpAssociation" /> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">value of Ecolab Account number</param>
        /// <param name="controllerEquipmentSetupId">Value of controller Equipment Setup Identifier.</param>
        /// <param name="isDeleted">falg  value for is delte.</param>
        /// <param name="formulaAssociated">Formulas Associated to the washers.</param>
        public PumpAssociation(string ecolabAccountNumber, short controllerEquipmentSetupId, bool isDeleted, int formulaAssociated)
        {
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.IsDeleted = isDeleted;
            this.FormulaAssociated = formulaAssociated;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PumpAssociation" /> class.
        /// </summary>
        /// <param name="myServiceProdId">My service product identifier.</param>
        /// <param name="myServiceWasherGuid">My service washer unique identifier.</param>
        /// <param name="compartmentNumber">The compartment number.</param>
        /// <param name="myServiceCmpmtDsgDvcguid">My service CMPMT DSG dvcguid.</param>
        public PumpAssociation(int myServiceProdId, Guid myServiceWasherGuid, byte compartmentNumber, Guid myServiceCmpmtDsgDvcguid)
        {
            MyServiceProdId = myServiceProdId;
            MyServiceWasherGuid = myServiceWasherGuid;
            CompartmentNumber = compartmentNumber;
            MyServiceCmpmtDsgDvcGuid = myServiceCmpmtDsgDvcguid;
        }
        #endregion Constructor

        #region Properties

        /// <summary>
        ///     Gets or sets the controller equipment setup identifier.
        /// </summary>
        /// <value>The controller equipment setup identifier.</value>
        public short ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>The controller equipment identifier.</value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment type identifier.
        /// </summary>
        /// <value>The controller equipment type identifier.</value>
        public byte ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller equipment setup identifier.
        /// </summary>
        /// <value>The name of the controller equipment setup identifier.</value>
        public string ControllerEquipmentSetupIdName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool Is_Deleted { get; set; }

        /// <summary>
        ///     Gets or sets the Formulas Associated.
        /// </summary>
        public int FormulaAssociated { get; set; }

        /// <summary>
        /// Gets or sets MyServiceProdId
        /// </summary>
        public int MyServiceProdId { get; set; }

        /// <summary>
        /// Gets or sets MyServiceWasherGuid
        /// </summary>
        public Guid MyServiceWasherGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCmpmtDsgDvcguid
        /// </summary>
        public Guid? MyServiceCmpmtDsgDvcGuid { get; set; }

        /// <summary>
        /// Gets or sets CompartmentNumber
        /// </summary>
        public byte CompartmentNumber { get; set; }
        #endregion Properties
    }
}