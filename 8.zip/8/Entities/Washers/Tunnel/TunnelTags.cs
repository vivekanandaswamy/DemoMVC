﻿// -----------------------------------------------------------------------
// <copyright file="TunnelTags.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelTags </summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Tunnel
{
    public class TunnelTags : BaseEntity
    {
        #region "Constructor"

        /// <summary>
        ///     Default Constructor for TunnelTags
        /// </summary>
        public TunnelTags()
        {
        }

        /// <summary>
        ///     Default Constructor for TunnelTags
        /// </summary>
        public TunnelTags(string currentFormula, string currentInjection, string currentOperationCounter, string autoWeightEntryFormula, string eofSignal, string mode, string flushTime, string injectionClass, string injectionRatio, string onHold, string autoWeightEntryActive, string holdDelay, string ratioDosingActive, string ratioDosingPercentage, string autoWeightEntryWeight)
        {
            this.CurrentFormulaTag = !string.IsNullOrEmpty(currentFormula) ? currentFormula : string.Empty;
            this.CurrentInjectionTag = !string.IsNullOrEmpty(currentInjection) ? currentInjection : string.Empty;
            this.CurrentOperationCounterTag = !string.IsNullOrEmpty(currentOperationCounter) ? currentOperationCounter : string.Empty;
            this.AutoWeightEntryFormulaTag = !string.IsNullOrEmpty(autoWeightEntryFormula) ? autoWeightEntryFormula : string.Empty;
            this.EndOfFormulaTag = !string.IsNullOrEmpty(eofSignal) ? eofSignal : string.Empty;
            this.WasherModeTag = !string.IsNullOrEmpty(mode) ? mode : string.Empty;
            this.WaterFlushTimeTag = !string.IsNullOrEmpty(flushTime) ? flushTime : string.Empty;
            this.InjectionClassTag = !string.IsNullOrEmpty(injectionClass) ? injectionClass : string.Empty;
            this.InjectionRatioTag = !string.IsNullOrEmpty(injectionRatio) ? injectionRatio : string.Empty;
            this.HoldSignalTag = !string.IsNullOrEmpty(onHold) ? onHold : string.Empty;
            this.AutoWeightEntryActiveTag = !string.IsNullOrEmpty(autoWeightEntryActive) ? autoWeightEntryActive : string.Empty;
            this.HoldDelayTag = !string.IsNullOrEmpty(holdDelay) ? holdDelay : string.Empty;
            this.RatioDosingActiveTag = !string.IsNullOrEmpty(ratioDosingActive) ? ratioDosingActive : string.Empty;
            this.RatioDosingPercentageTag = !string.IsNullOrEmpty(ratioDosingPercentage) ? ratioDosingPercentage : string.Empty;
            this.AutoWeightEntryWeightTag = !string.IsNullOrEmpty(autoWeightEntryWeight) ? autoWeightEntryWeight : string.Empty;
        }

        /// <summary>
        ///     Constructor for getting washer tag list
        /// </summary>
        /// <param name="washerTagId">Washer tag Id</param>
        /// <param name="tagType">tag Type</param>
        /// <param name="tagAddress">Tag Address</param>
        /// <param name="active">Active</param>
        public TunnelTags(int washerTagId, string tagType, string tagAddress, bool active)
        {
            this.WasherTagId = washerTagId;
            this.TagType = tagType;
            this.TagAddress = tagAddress;
            this.Active = active;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the name of the WasherMode.
        /// </summary>
        /// <value>The name of the WasherMode.</value>
        public string WasherModeTag { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentFormula.
        /// </summary>
        /// <value>The CurrentFormula.</value>
        public string CurrentFormulaTag { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentInjection.
        /// </summary>
        /// <value>The CurrentInjection.</value>
        public string CurrentInjectionTag { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentOperationCounter.
        /// </summary>
        /// <value>The CurrentOperationCounter.</value>
        public string CurrentOperationCounterTag { get; set; }

        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public string WasherNumberTag { get; set; }

        /// <summary>
        ///     Gets or sets the EndOfFormula .
        /// </summary>
        /// <value> End of Formula.</value>
        public string EndOfFormulaTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public string AutoWeightEntryActiveTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [Hold signal].
        /// </summary>
        /// <value>true/false.</value>
        public string HoldSignalTag { get; set; }

        /// <summary>
        ///     Gets or sets the Hold Delay.
        /// </summary>
        /// <value>The Hold Delay.</value>
        public string HoldDelayTag { get; set; }

        /// <summary>
        ///     Gets or sets the WaterFlushTime.
        /// </summary>
        /// <value>WaterFlushTime.</value>
        public string WaterFlushTimeTag { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string InjectionRatioTag { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer type.
        /// </summary>
        /// <value>The name of the washer type.</value>
        public string InjectionClassTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public string RatioDosingActiveTag { get; set; }

        /// <summary>
        ///     Gets or sets the region identifier.
        /// </summary>
        /// <value>The region identifier.</value>
        public string RatioDosingPercentageTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe formula].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public string AutoWeightEntryFormulaTag { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [awe weight].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public string AutoWeightEntryWeightTag { get; set; }

        /// <summary>
        ///     Gets or sets TagDescription.
        /// </summary>
        /// <value>TagDescription.</value>
        public string TagDescription { get; set; }

        /// <summary>
        ///     Gets or sets a value for TagAddress.
        /// </summary>
        /// <value>TagAddress.</value>
        public string TagAddress { get; set; }

        /// <summary>
        ///     Gets or sets TagType
        /// </summary>
        public string TagType { get; set; }

        /// <summary>
        ///     Gets or sets WasherTagId
        /// </summary>
        public int WasherTagId { get; set; }

        /// <summary>
        ///     Gets or sets Active
        /// </summary>
        public bool Active { get; set; }

        #endregion
    }
}