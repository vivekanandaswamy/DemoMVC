﻿// <copyright file="TunnelCompartment.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>The Tunnel Compartment Class</summary>
// ***********************************************************************

namespace Entities.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Class TunnelCompartment.
    /// </summary>
    public class TunnelCompartment : BaseEntity
    {
        public TunnelCompartment(int washStepId, byte waterinletDrainId, short waterFlowId, int waterLevel, bool temperatureControlByPmr, bool usePressExtractWater, bool splitCompartment, bool recycledWaterInlet, bool steam, int tunnelId, byte compartmentNumber, List<PumpAssociation> pumpAssociationList, int role, int tunnelCompartmentId, bool iterationpoint, Guid myServiceWasherId, int myServiceDrainLookupId, int myServiceWaterFlowtypeId, bool temperature, bool phProbe, bool conductivity, bool redox)
        {
            this.Id = tunnelId;
            this.CompartmentNumber = compartmentNumber;
            this.WashStepId = washStepId;
            this.WaterinletDrainId = waterinletDrainId;
            this.WaterFlowId = waterFlowId;
            this.WaterLevel = waterLevel;
            this.TemperatureControlByPmr = temperatureControlByPmr;
            this.UsePressExtractWater = usePressExtractWater;
            this.SplitCompartment = splitCompartment;
            this.RecycledWaterInlet = recycledWaterInlet;
            this.Steam = steam;
            this.PumpAssociationList = pumpAssociationList;
            this.Role = role;
            this.TunnelCompartmentId = tunnelCompartmentId;
            this.Iterationpoint = iterationpoint;
            this.MyServiceWasherId = myServiceWasherId;
            this.MyServiceDrainLookupId = myServiceDrainLookupId;
            this.MyServiceTunnelWaterFlowTypeId = myServiceWaterFlowtypeId;
            this.Temperature = temperature;
            this.PhProbe = phProbe;
            this.Conductivity = conductivity;
            this.Redox = redox;
        }

        public TunnelCompartment()
        {
        }
        //Byte, Guid, Int16, Decimal, Boolean, Boolean, Boolean, Int16, Int16, Boolean, Boolean, Boolean
        public TunnelCompartment(byte compartmentNumber, Guid myServiceWasherId, Int16 waterinletDrainId, decimal waterLevel, bool usePressExtractWater, bool splitCompartment, bool steam, Int16 washZone, Int16 waterFlowId, bool temperatureControlByPmr, bool dosagePoint, bool recycledWaterInlet, bool iterationpoint)
        {
            CompartmentNumber = compartmentNumber;
            MyServiceWasherId = myServiceWasherId;
            WaterinletDrainId = waterinletDrainId;
            WaterLevel = waterLevel;
            UsePressExtractWater = usePressExtractWater;
            SplitCompartment = splitCompartment;
            Steam = steam;
            WaterFlowId = waterFlowId;
            TemperatureControlByPmr = temperatureControlByPmr;
            DosagePoint = dosagePoint;
            RecycledWaterInlet = recycledWaterInlet;
            Iterationpoint = iterationpoint;
            WashStepId = washZone;
        }

        public TunnelCompartment(byte compartmentNumber, Int16 tunnelCompartmentId)
        {
            this.CompartmentNumber = compartmentNumber;
            this.TunnelCompartmentId = tunnelCompartmentId;
        }
        #region Properties

        /// <summary>
        ///     Gets or sets the compartment number.
        /// </summary>
        /// <value>The compartment number.</value>
        public byte CompartmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the compartment number.
        /// </summary>
        /// <value>The compartment number.</value>
        public int TunnelCompartmentId { get; set; }

        /// <summary>
        ///     Gets or sets the wash step identifier.
        /// </summary>
        /// <value>The wash step identifier.</value>
        public int WashStepId { get; set; }

        /// <summary>
        ///     Gets or sets the waterinlet drain identifier.
        /// </summary>
        /// <value>The waterinlet drain identifier.</value>
        public Int16 WaterinletDrainId { get; set; }

        /// <summary>
        ///     Gets or sets the water flow identifier.
        /// </summary>
        /// <value>The water flow identifier.</value>
        public short WaterFlowId { get; set; }

        /// <summary>
        ///     Gets or sets the water level.
        /// </summary>
        /// <value>The water level.</value>
        public Decimal WaterLevel { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [temperature control by PMR].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool TemperatureControlByPmr { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [use press extract water].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool UsePressExtractWater { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [split compartment].
        /// </summary>
        /// <value>
        ///     <value><c>true/false</c>.</value>
        /// </value>
        public bool SplitCompartment { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [recycled water inlet].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool RecycledWaterInlet { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this <see cref="TunnelCompartmentModel" /> is steam.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool Steam { get; set; }

        /// <summary>
        ///     Gets or sets the pump association list.
        /// </summary>
        /// <value>The pump association list.</value>
        public List<PumpAssociation> PumpAssociationList { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the role of the logged user.
        /// </summary>
        public int Role { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp at central
        /// </summary>
        /// <value>LastModifiedTimeStampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets a value is iteration point.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool Iterationpoint { get; set; }

        /// <summary>
        ///     Gets or sets a value MyServiceWasherId.
        /// </summary>
        public Guid MyServiceWasherId { get; set; }

        /// <summary>
        /// Gets or sets the MyServiceDrainLookUpId
        /// </summary>
        /// <value>MyServiceDrainLookUpId</value>
        public int MyServiceDrainLookupId { get; set; }

        /// <summary>
        /// Gets or sets the MyServiceTunnelWaterFlowTypeId
        /// </summary>
        /// <value>MyServiceTunnelWaterFlowTypeId</value>
        public int MyServiceTunnelWaterFlowTypeId { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this <see cref="TunnelCompartmentModel" /> is DosagePoint.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool DosagePoint { get; set; }

        /// <summary>
        /// Gets or sets the pH Probe
        /// </summary>
        /// <value> true/false </value>
        public bool PhProbe { get; set; }

        /// <summary>
        /// Gets or sets the Conductivity
        /// </summary>
        /// <value> true/false </value>
        public bool Conductivity { get; set; }

        /// <summary>
        /// Gets or sets the Temperature
        /// </summary>
        /// <value> true/false </value>
        public bool Temperature { get; set; }

        /// <summary>
        /// Gets or sets the Redox
        /// </summary>
        /// <value> true/false </value>
        public bool Redox { get; set; }

        /// <summary>
        /// ControllerEquipmentSetupId
        /// </summary>
        public int ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the compartment number.
        /// </summary>
        /// <value>The compartment number.</value>
        public byte NewCompartmentNumber { get; set; }

        /// <summary>
        /// WasherGroupId
        /// </summary>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the New Tunnel Compartment Id.
        /// </summary>
        /// <value>The New Tunnel Compartment Id.</value>
        public int NewTunnelCompartmentId { get; set; }

        #endregion Properties
    }
}