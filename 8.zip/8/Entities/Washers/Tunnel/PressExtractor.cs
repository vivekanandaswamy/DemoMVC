﻿// -----------------------------------------------------------------------
// <copyright file="PressExtractor.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PressExtractor object</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Washers.Tunnel
{
    /// <summary>
    ///     Class PressExtractor.
    /// </summary>
    public class PressExtractor : BaseEntity
    {
        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="PressExtractor" /> class.
        /// </summary>
        /// <param name="name">The Parameter name.</param>
        /// <param name="id">The Parameter identifier.</param>
        public PressExtractor(string name, int id)
        {
            this.Name = name;
            this.Id = id;
        }

        /// <summary>
        /// My Service Constructor
        /// </summary>
        /// <param name="name">Name column</param>
        /// <param name="regionCode"> region Code to get region id</param>
        /// <param name="isDeleted">id Deleted parameter</param>
        /// <param name="myServicePropId">My service prop ID</param>
        /// <param name="myServiceModDtTm">My service Mod date time</param>
        public PressExtractor(string name, string regionCode, bool isDeleted, Int16 myServicePropId, DateTime myServiceModDtTm, string spSp, string nrNR, string nlBE)
        {
            Name = name;
            RegionCode = regionCode;
            IsDeleted = isDeleted;
            MyServicePropId = myServicePropId;
            MyServiceModDtTm = myServiceModDtTm;
            sp_SP = spSp;
            nr_NR = nrNR;
            nl_BE = nlBE;
        }

        public PressExtractor()
        {
            // TODO: Complete member initialization
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The Parameter name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or Sets Region Code
        /// </summary>
        /// <value>Region Code</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        /// Gets or Sets MyServicePropId
        /// </summary>
        /// <value>MyServicePropId</value>
        public Int16 MyServicePropId { get; set; }

        /// <summary>
        /// Gets or Sets MyServiceModDtTm
        /// </summary>
        /// <value>MyServiceModDtTm</value>
        public DateTime MyServiceModDtTm { get; set; }

        #endregion Properties
    }
}