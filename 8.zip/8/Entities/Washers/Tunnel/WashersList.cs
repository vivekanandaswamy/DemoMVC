﻿// -----------------------------------------------------------------------
// <copyright file="WashersList.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Washers object</summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Tunnel
{
    /// <summary>
    ///     Class WashersList
    /// </summary>
    public class WashersList : BaseEntity
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="WashersList" /> class.
        /// </summary>
        /// <param name="washerModelName">Name of the washer model.</param>
        public WashersList(string washerModelName)
        {
            this.WasherModelName = washerModelName;
        }

        #endregion "Constructor"

        #region Properties

        /// <summary>
        ///     Gets or sets the name of the washer model.
        /// </summary>
        /// <value>The name of the washer model.</value>
        public string WasherModelName { get; set; }

        #endregion Properties
    }
}