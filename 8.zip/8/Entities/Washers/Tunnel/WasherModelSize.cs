﻿// -----------------------------------------------------------------------
// <copyright file="WasherModelSize.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherModelSize for Getting WasherModelSize List .</summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Tunnel
{
    /// <summary>
    ///     Class WasherModelSize.
    /// </summary>
    public class WasherModelSize
    {
        #region "Constructor"

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherModelSize" /> class.
        /// </summary>
        /// <param name="washerSize">Size of the washer.</param>
        public WasherModelSize(string washerSize)
        {
            this.WasherSize = washerSize;
        }

        #endregion "Constructor"

        /// <summary>
        ///     Gets or sets the size of the washer.
        /// </summary>
        /// <value>The size of the washer.</value>
        public string WasherSize { get; set; }
    }
}