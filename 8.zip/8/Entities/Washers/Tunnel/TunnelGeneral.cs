﻿// -----------------------------------------------------------------------
// <copyright file="TunnelGeneral.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Tunnel General Entity </summary>
// -----------------------------------------------------------------------

namespace Entities.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Class TunnelGeneral.
    /// </summary>
    public class TunnelGeneral : BaseEntity
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="TunnelGeneral" /> class.
        /// </summary>
        public TunnelGeneral()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TunnelGeneral" /> class.
        /// </summary>
        /// <param name="plantWasherNumber">The plant washer number.</param>
        /// <param name="name">The name value.</param>
        /// <param name="washerType">Type of the washer.</param>
        /// <param name="washerTypeFlg">if set to <c>true</c> [washer type FLG].</param>
        /// <param name="washerModel">The washer model.</param>
        /// <param name="modelId">The model identifier.</param>
        /// <param name="size">The Parameter size.</param>
        /// <param name="controllerName">Name of the controller.</param>
        /// <param name="id">The identifier.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="washerGroupName">Name of the washer group.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="description">The description.</param>
        /// <param name="maxLoad">The maximum load.</param>
        /// <param name="washerMode">The washer mode.</param>
        /// <param name="aweActive">if set to <c>true</c> [awe active].</param>
        /// <param name="noOfCompartments">The no of compartments.</param>
        /// <param name="noOfTanks">The no of tanks.</param>
        /// <param name="pressExtractor">The press extractor.</param>
        /// <param name="transferType">Type of the transfer.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="holdSignal">The hold signal.</param>
        /// <param name="holdDelay">if set to <c>true</c> [hold delay].</param>
        /// <param name="targetTurnTime">The target turn time.</param>
        /// <param name="waterFlushTime">The water flush time.</param>
        /// <param name="lfsWasher">The LFS washer.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="formulaCount">The formula count.</param>
        /// <param name="myServiceWasherGroupGuid">My service washer group unique identifier.</param>
        /// <param name="myServiceWashersGuid">My service washers unique identifier.</param>
        /// <param name="myServiceMCHId">My service MCH identifier.</param>
        /// <param name="pressExtractorName">Name of the press extractor.</param>
        /// <param name="transferTypeName">Name of the transfer type.</param>
        /// <param name="ratioDosingActive">The Ratio Dosing Active.</param>
        /// <param name="ecolabWasherNumber">The ecolab washer number.</param>
        /// <param name="endOfFormula">The end of formula.</param>
        /// <param name="myserviceLastSyncTime">The myservice last synchronize time.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <param name="controllerType">Type of the controller.</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <param name="controllerModel">The controller model.</param>
        /// <param name="numberOfCompartmentsConveyorBelt">The number of compartments conveyor belt.</param>
        /// <param name="minMachineLoad">The minimum machine load.</param>
        /// <param name="maxMachineLoad">The maximum machine load.</param>
        /// <param name="programSelectionByTime">if set to <c>true</c> [program selection by time].</param>
        /// <param name="weightSelectionByTime">if set to <c>true</c> [weight selection by time].</param>
        /// <param name="weightSelectionByAnalogInput">if set to <c>true</c> [weight selection by analog input].</param>
        /// <param name="tunInTomMode">if set to <c>true</c> [tun in tom mode].</param>
        /// <param name="signalStopTunActive">if set to <c>true</c> [signal stop tun active].</param>
        /// <param name="signalEjectionTunActive">if set to <c>true</c> [signal ejection tun active].</param>
        /// <param name="delayTimeForTunWashingPrograms">if set to <c>true</c> [delay time for tun washing programs].</param>
        /// <param name="kannegiesserPressSpecialMode">if set to <c>true</c> [kannegiesser press special mode].</param>
        /// <param name="valveOutputsUsedAsTomSignal">if set to <c>true</c> [valve outputs used as tom signal].</param>
        /// <param name="extendedClockOrDataProtocol">if set to <c>true</c> [extended clock or data protocol].</param>
        /// <param name="weightCorrectionFcc">if set to <c>true</c> [weight correction FCC].</param>
        /// <param name="flowSwitchNumber">The flow switch number.</param>
        /// <param name="washerStopExternalSignal">if set to <c>true</c> [washer stop external signal].</param>
        /// <param name="onHoldWESignalActive">if set to <c>true</c> [on hold we signal active].</param>
        /// <param name="washerOnHoldSignalDelay">The washer on hold signal delay.</param>
        /// <param name="weInTomMode">if set to <c>true</c> [we in tom mode].</param>
        /// <param name="manifoldFlushTime">The manifold flush time.</param>
        /// <param name="l1">if set to <c>true</c> [l1].</param>
        /// <param name="l2">if set to <c>true</c> [l2].</param>
        /// <param name="l3">if set to <c>true</c> [l3].</param>
        /// <param name="l4">if set to <c>true</c> [l4].</param>
        /// <param name="l5">if set to <c>true</c> [l5].</param>
        /// <param name="l6">if set to <c>true</c> [l6].</param>
        /// <param name="l7">if set to <c>true</c> [l7].</param>
        /// <param name="l8">if set to <c>true</c> [l8].</param>
        /// <param name="l9">if set to <c>true</c> [l9].</param>
        /// <param name="l10">if set to <c>true</c> [L10].</param>
        /// <param name="l11">if set to <c>true</c> [L11].</param>
        /// <param name="l12">if set to <c>true</c> [L12].</param>
        /// <param name="isPony">if set to <c>true</c> [is pony].</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="useMe1OfGroup">The use me1 of group.</param>
        /// <param name="useMe2OfGroup">The use me2 of group.</param>
        /// <param name="usePumpOfGroup">The use pump of group.</param>
        /// <param name="washerStopUseFinalExtracting">The washer stop use final extracting.</param>
        /// <param name="temperatureAlarmYesNo">The temperature alarm yes no.</param>
        /// <param name="phProbe">The ph probe.</param>
        /// <param name="weightCell">The weight cell.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="waterCounter">The water counter.</param>
        /// <param name="dateAndTimeWhenBatchEjects">The date and time when batch ejects.</param>
        /// <param name="autoRinseDesamixAfter">The automatic rinse desamix after.</param>
        /// <param name="autoRinseDesamix1For">The automatic rinse desamix1 for.</param>
        /// <param name="autoRinseDesamix2For">The automatic rinse desamix2 for.</param>
        /// <param name="temperatureAlarmProbe1">The temperature alarm probe1.</param>
        /// <param name="temperatureAlarmProbe2">The temperature alarm probe2.</param>
        /// <param name="temperatureAlarmProbe3">The temperature alarm probe3.</param>
        /// <param name="DefaultIdleTime">The default idle time.</param>
        /// <param name="etechwashernumber">The etechwashernumber.</param>
        /// <param name="signalAcceptanceTime">The signal acceptance time.</param>
        /// <param name="kannegiesserDosageInPreparationTankMode">if set to <c>true</c> [kannegiesser dosage in preparation tank mode].</param>
        /// <param name="batchOk">if set to <c>true</c> [batch ok].</param>
        /// <param name="extractTimeForEOFSignal">if set to <c>true</c> [extract Time For EOF Signal].</param>
        /// <param name="transferPerHour">The transfer per hour.</param>
        public TunnelGeneral(
                              short plantWasherNumber,
                              string name,
                              string washerType,
                              bool washerTypeFlg,
                              string washerModel,
                              short modelId,
                              string size,
                              string controllerName,
                              int id,
                              int washerGroupId,
                              string washerGroupName,
                              int controllerId,
                              string description,
                              short maxLoad,
                              short washerMode,
                              bool aweActive,
                              int noOfCompartments,
                              short? noOfTanks,
                              short? pressExtractor,
                              short? transferType,
                              short programNumber,
                              bool holdSignal,
                              int holdDelay,
                              int targetTurnTime,
                              int waterFlushTime,
                              int lfsWasher,
                              DateTime lastModifiedTime,
                              DateTime lastSyncTime,
                              bool isDeleted,
                              string ecolabAccountNumber,
                              int formulaCount,
                              Guid myServiceWasherGroupGuid,
                              Guid myServiceWashersGuid,
                              int myServiceMCHId,
                              string pressExtractorName,
                              string transferTypeName,
                              bool ratioDosingActive,
                              int ecolabWasherNumber,
                              short endOfFormula,
                              DateTime? myserviceLastSyncTime,
			                    int controllerTypeId,
			                    string controllerType,
			                    int controllerModelId,
			                    string controllerModel,
			                    short numberOfCompartmentsConveyorBelt,
			                    short minMachineLoad,
			                    short maxMachineLoad,
			                    bool programSelectionByTime,
			                    bool weightSelectionByTime,
			                    bool weightSelectionByAnalogInput,
			                    bool tunInTomMode,
			                    bool signalStopTunActive,
			                    bool signalEjectionTunActive,
			                    bool delayTimeForTunWashingPrograms,
			                    bool kannegiesserPressSpecialMode,
			                    bool valveOutputsUsedAsTomSignal,
			                    bool extendedClockOrDataProtocol,
			                    bool weightCorrectionFcc,
			                    //bool isActive,
			                    int flowSwitchNumber,
			                    bool washerStopExternalSignal,
			                    bool onHoldWESignalActive,
			                    int washerOnHoldSignalDelay,
			                    bool weInTomMode,
			                    int manifoldFlushTime,
			                    bool l1,
			                    bool l2,
			                    bool l3,
			                    bool l4,
			                    bool l5,
			                    bool l6,
			                    bool l7,
			                    bool l8,
			                    bool l9,
			                    bool l10,
			                    bool l11,
			                    bool l12,
			                    bool isPony,
			                    int plantId,
			                    byte? useMe1OfGroup,
			                    byte? useMe2OfGroup,
			                    byte? usePumpOfGroup,
			                    bool? washerStopUseFinalExtracting,
			                    bool? temperatureAlarmYesNo,
			                    bool? phProbe,
			                    bool? weightCell,
			                    bool? temperature,
			                    bool? waterCounter,
                                bool? dateAndTimeWhenBatchEjects,
                                short? autoRinseDesamixAfter,
                                short? autoRinseDesamix1For,
                                short? autoRinseDesamix2For,
                                bool? temperatureAlarmProbe1,
                                bool? temperatureAlarmProbe2,
                                bool? temperatureAlarmProbe3,
                                int DefaultIdleTime,
                                int etechwashernumber,
                                int signalAcceptanceTime,
                                bool kannegiesserDosageInPreparationTankMode,
                                bool batchOk,
                                bool extractTimeForEOFSignal, // Not required for tunnel
                                int transferPerHour
                              )
			: base(ecolabAccountNumber, plantId)
        {
            ControllerId = controllerId;
            ControllerName = controllerName;
            Size = size;
            Name = name;
            PlantWasherNumber = plantWasherNumber;
            Description = description;
            MaxLoad = maxLoad;
            WasherMode = washerMode;
            AweActive = aweActive;
            NoofCompartments = noOfCompartments;
            NoofTanks = noOfTanks;
            PressExtractor = pressExtractor;
            TransferType = transferType;
            ProgramNumber = programNumber;
            WasherTypeFlag = washerTypeFlg;
            Id = id;
            WasherGroupId = washerGroupId;
            WasherGroupName = washerGroupName;
            ModelId = modelId;
            WasherModelName = washerModel;
            WasherTypeName = washerType;
            LastModifiedTimestamp = lastModifiedTime;
            LastSyncTime = lastSyncTime;
            IsDelete = isDeleted;
            FormulaCount = formulaCount;
            MyServiceWasherGroupGuid = myServiceWasherGroupGuid;
            MyServiceWashersGuid = myServiceWashersGuid;
            MyServiceMCHId = myServiceMCHId;
            PressExtractorName = pressExtractorName;
            TransferTypeName = transferTypeName;
            RatioDosingActive = ratioDosingActive;
            EcolabWasherNumber = ecolabWasherNumber;
            EndOfFormula = endOfFormula;
            MyServiceModTime = myserviceLastSyncTime;
            IsPony = isPony;
			ControllerTypeId = controllerTypeId;
			ControllerType = controllerType;
			ControllerModelId = controllerModelId;
			ControllerModel = controllerModel;
			LfsWasher = lfsWasher;
			NumberOfCompartmentsConveyorBelt = numberOfCompartmentsConveyorBelt;
			MinMachineLoad = minMachineLoad;
			MaxMachineLoad = maxMachineLoad;
			ProgramSelectionByTime = programSelectionByTime;
			WeightSelectionByTime = weightSelectionByTime;
			WeightSelectionByAnalogInput = weightSelectionByAnalogInput;
			TunInTomMode = tunInTomMode;
			SignalStopTunActive = signalStopTunActive;
			SignalEjectionTunActive = signalEjectionTunActive;
			DelayTimeForTunWashingPrograms = delayTimeForTunWashingPrograms;
            KannegiesserPressSpecialMode = kannegiesserPressSpecialMode;
			ValveOutputsUsedAsTomSignal = valveOutputsUsedAsTomSignal;
			ExtendedClockOrDataProtocol = extendedClockOrDataProtocol;
			WeightCorrectionFcc = weightCorrectionFcc;
			this.UseMe1OfGroup = useMe1OfGroup;
			this.UseMe2OfGroup = useMe2OfGroup;
			this.UsePumpOfGroup = usePumpOfGroup;
			this.WasherStopUseFinalExtracting = washerStopUseFinalExtracting;
			this.TemperatureAlarmYesNo = temperatureAlarmYesNo;
			this.PhProbe = phProbe;
			this.WeightCell = weightCell;
			this.Temperature = temperature;
			this.WaterCounter = waterCounter;

            this.DateAndTimeWhenBatchEjects = dateAndTimeWhenBatchEjects;
            this.AutoRinseDesamixAfter = autoRinseDesamixAfter;
            this.AutoRinseDesamix1For = autoRinseDesamix1For;
            this.AutoRinseDesamix2For = autoRinseDesamix2For;
            this.TemperatureAlarmProbe1 = temperatureAlarmProbe1;
            this.TemperatureAlarmProbe2 = temperatureAlarmProbe2;
            this.TemperatureAlarmProbe3 = temperatureAlarmProbe3;
            this.DefaultIdleTime = DefaultIdleTime;
            this.FlowSwitchNumber = flowSwitchNumber;
            this.HoldDelay = holdDelay;
            this.HoldSignal = holdSignal;
            this.L1 = l1;
            this.L2 = l2;
            this.L3 = l3;
            this.L4 = l4;
            this.L5 = l5;
            this.L6 = l6;
            this.L7 = l7;
            this.L8 = l8;
            this.L9 = l9;
            this.L10 = l10;
            this.L11 = l11;
            this.L12 = l12;
            this.ManifoldFlushTime = manifoldFlushTime;
            this.OnHoldWESignalActive = onHoldWESignalActive;
            this.TargetTurnTime = targetTurnTime;
            this.WasherStopExternalSignal = washerStopExternalSignal;
            this.WaterFlushTime = waterFlushTime;
            this.WeInTomMode = weInTomMode; 
            this.ETechWasherNumber = etechwashernumber;
            this.SignalAcceptanceTime = signalAcceptanceTime;
            this.KannegiesserDosageInPreparationTankMode = kannegiesserDosageInPreparationTankMode;
            this.BatchOk = batchOk;
            this.TransferPerHour = transferPerHour;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TunnelGeneral" /> class for MyService.
        /// </summary>
        /// <param name="myServiceWasherGroupId">My service washer group identifier.</param>
        /// <param name="myServiceWasherId">My service washer identifier.</param>
        /// <param name="washerName">Name of the washer.</param>
        /// <param name="myServiceModelId">My service model identifier.</param>
        /// <param name="modelName">Name of the model.</param>
        /// <param name="maxLoad">The maximum load.</param>
        /// <param name="plantWasherNumber">The plant washer number.</param>
        /// <param name="noOftanks">The no oftanks.</param>
        /// <param name="noOfCmpmt">The no of CMPMT.</param>
        /// <param name="transferTypeId">The transfer type identifier.</param>
        /// <param name="pressExtractorId">The press extractor identifier.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="regionCode">The region code.</param>
        /// <param name="maxLoad_UOMCode">The maximum load_ uom code.</param>
        public TunnelGeneral(Guid myServiceWasherGroupId, Guid myServiceWasherId, string washerName, int myServiceModelId, string modelName, int maxLoad,
                                Int16 plantWasherNumber, Int16? noOftanks, Int16 noOfCmpmt, Int16? transferTypeId, Int16? pressExtractorId, bool isDeleted, string regionCode, string maxLoad_UOMCode)
        {
            MyServiceWasherGroupGuid = myServiceWasherGroupId;
            MyServiceWashersGuid = myServiceWasherId;
            Name = washerName;
            MyServiceModelId = myServiceModelId;
            WasherModelName = modelName;
            MyServiceMaxLoad = maxLoad;
            PlantWasherNumber = plantWasherNumber;
            NoofCompartments = noOfCmpmt;
            NoofTanks = noOftanks;
            TransferType = transferTypeId;
            PressExtractor = pressExtractorId;
            IsDelete = isDeleted;
            RegionCode = regionCode;
            MaxLoad_UOMCode = maxLoad_UOMCode;
        }

        #endregion Constructor

        #region Properties

        /// <summary>
        ///     Gets or sets the model.
        /// </summary>
        /// <value>The Parameter model.</value>
        public short ModelId { get; set; }

        /// <summary>
        ///     Gets or sets the controller.
        /// </summary>
        /// <value>The Parameter controller.</value>
        public int ControllerId { get; set; }

		/// <summary>
		///     Gets or sets the controller Type Id.
		/// </summary>
		/// <value>The Parameter controller Type id.</value>
		public int ControllerTypeId { get; set; }

		/// <summary>
		///     Gets or sets the name of the controller type.
		/// </summary>
		/// <value>The name of the controller type.</value>
		public string ControllerType { get; set; }

		/// <summary>
		///     Gets or sets the controller Model Id.
		/// </summary>
		/// <value>The Parameter controller Model id.</value>
		public int ControllerModelId { get; set; }

		/// <summary>
		///     Gets or sets the name of the controller model.
		/// </summary>
		/// <value>The name of the controller model.</value>
		public string ControllerModel { get; set; }

		/// <summary>
        ///     Gets or sets the type of the washer.
        /// </summary>
        /// <value>The type of the washer.</value>
        public string WasherType { get; set; }

        /// <summary>
        ///     Gets or sets the size.
        /// </summary>
        /// <value>The Parameter size.</value>
        public string Size { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The Parameter name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller.
        /// </summary>
        /// <value>The name of the controller.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the plant washer number.
        /// </summary>
        /// <value>The plant washer number.</value>
        public short PlantWasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the washer capacity.
        /// </summary>
        /// <value>The washer capacity.</value>
        public short MaxLoad { get; set; }

        /// <summary>
        ///     Gets or sets the washer mode.
        /// </summary>
        /// <value>The washer mode.</value>
        public short WasherMode { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool AweActive { get; set; }

        /// <summary>
        ///     Gets or sets the no of compartments.
        /// </summary>
        /// <value>no of compartments.</value>
        public int NoofCompartments { get; set; }

        /// <summary>
        ///     Gets or sets the no of tanks.
        /// </summary>
        /// <value>The no of tanks.</value>
        public short? NoofTanks { get; set; }

        /// <summary>
        ///     Gets or sets the press/extractor.
        /// </summary>
        /// <value>The press extractor.</value>
        public short? PressExtractor { get; set; }

        /// <summary>
        ///     Gets or sets the type of the transfer.
        /// </summary>
        /// <value>The type of the transfer.</value>
        public short? TransferType { get; set; }

        /// <summary>
        ///     Gets or sets the program number.
        /// </summary>
        /// <value>The program number.</value>
        public short ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the EndOfFormula.
        /// </summary>
        /// <value>The EndOfFormula.</value>
        public short EndOfFormula { get; set; }

        /// <summary>
        ///     Gets or sets the washer group identifier.
        /// </summary>
        /// <value>The washer group identifier.</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer model.
        /// </summary>
        /// <value>The name of the washer model.</value>
        public string WasherModelName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer type.
        /// </summary>
        /// <value>The name of the washer type.</value>
        public string WasherTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the region identifier.
        /// </summary>
        /// <value>The region identifier.</value>
        public int RegionId { get; set; }

        /// <summary>
        ///     gets or sets the list of tunnel tags.
        /// </summary>
        public List<TunnelTags> TunnelTagsList { get; set; }

        /// <summary>
        ///     Gets or sets the tunnel tags.
        /// </summary>
        public TunnelTags TunnelTags { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Formula Count
        /// </summary>
        /// <value> FormulaCount</value>
        public int FormulaCount { get; set; }

        /// <summary>
        /// Gets or sets MyServiceWasherGroupGuid
        /// </summary>
        public Guid MyServiceWasherGroupGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceWasherGroupGuid
        /// </summary>
        public Guid MyServiceWashersGuid { get; set; }

        /// <summary>
        ///     Gets or sets the MyService Id.
        /// </summary>
        /// <value>The MyService Id..</value>
        public int MyServiceMCHId { get; set; }

        /// <summary>
        ///     Gets or sets the PressExtractorName.
        /// </summary>
        /// <value>The Press Extractor Name.</value>
        public string PressExtractorName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the transfer.
        /// </summary>
        /// <value>The name of the transfer.</value>
        public string TransferTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the RegionCode.
        /// </summary>
        /// <value>The name of the RegionCode.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the Model Type Id of the washer.
        /// </summary>
        /// <value>The Model Type Id of the washer.</value>
        public int MyServiceModelId { get; set; }

        /// <summary>
        ///     Gets or sets the MyService washer capacity.
        /// </summary>
        /// <value>The MyService washer capacity.</value>
        public int MyServiceMaxLoad { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [RatioDosingActive].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool RatioDosingActive { get; set; }

        /// <summary>
        ///     Gets or sets a value EcolabWasherNumber
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public int EcolabWasherNumber { get; set; }

        /// <summary>
        /// Gets or sets MyServiceModTime
        /// </summary>
        public DateTime? MyServiceModTime { get; set; }

        /// <summary>
		///     Gets or sets the LfsWasher.
		/// </summary>
		/// <value>The LfsWasher.</value>
		public int LfsWasher { get; set; }

		/// <summary>
		///     Gets or sets the Number Of Compartments Conveyor Belt
		/// </summary>
		/// <value>Number Of Compartments Conveyor Belt</value>
		public short NumberOfCompartmentsConveyorBelt { get; set; }

		/// <summary>
		///     Gets or sets the Min Machine Load
		/// </summary>
		/// <value>Min Machine Load</value>
		public short MinMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets the Max Machine Load
        /// </summary>
        /// <value>Max Machine Load</value>
        public short MaxMachineLoad { get; set; }

        /// <summary>
        /// Gets or sets the Program Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ProgramSelectionByTime { get; set; }

        /// <summary>
        /// Gets or sets the Weight Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightSelectionByTime { get; set; }

		/// <summary>
		///     Gets or sets the Weight Selection By Analog Input
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool WeightSelectionByAnalogInput { get; set; }

		/// <summary>
		///     Gets or sets the TUN In TOM Mode
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool TunInTomMode { get; set; }

		/// <summary>
		///     Gets or sets the Signal Stop TUN Active
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool SignalStopTunActive { get; set; }

		/// <summary>
		///     Gets or sets the Signal Ejection TUN Active
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool SignalEjectionTunActive { get; set; }

		/// <summary>
		///     Gets or sets the Delay Time For TUN Washing Programs
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool DelayTimeForTunWashingPrograms { get; set; }

		/// <summary>
		///     Gets or sets the Kannegiesser Press Special Mode
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool KannegiesserPressSpecialMode { get; set; }

		/// <summary>
		///     Gets or sets the Value Outputs Used As TOM Signal
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool ValveOutputsUsedAsTomSignal { get; set; }

		/// <summary>
		///     Gets or sets the Extended Clock Or Data Protocol
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool ExtendedClockOrDataProtocol { get; set; }

		/// <summary>
		///     Gets or sets the Weight Correction (F.C.C)
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool WeightCorrectionFcc { get; set; }

		/// <summary>
        ///     Gets or sets a value indicating whether Pony Wahser or not.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool IsPony { get; set; }

        /// <summary>
        /// Gets or sets UseMe1OfGroup
        /// </summary>
        /// <value>
        /// The use me1 of group.
        /// </value>
        public byte? UseMe1OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UseMe2OfGroup
        /// </summary>
        /// <value>
        /// The use me2 of group.
        /// </value>
        public byte? UseMe2OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UsePumpOfGroup
        /// </summary>
        /// <value>
        /// The use pump of group.
        /// </value>
        public byte? UsePumpOfGroup { get; set; }

        /// <summary>
        /// Gets or sets WasherStopUseFinalExtracting
        /// </summary>
        /// <value>
        /// The washer stop use final extracting.
        /// </value>
        public bool? WasherStopUseFinalExtracting { get; set; }

        /// <summary>
        /// Gets or sets TemperatureAlarmYesNo
        /// </summary>
        /// <value>
        /// The temperature alarm yes no.
        /// </value>
        public bool? TemperatureAlarmYesNo { get; set; }

        /// <summary>
        /// Gets or sets PhProbe
        /// </summary>
        /// <value>
        /// The ph probe.
        /// </value>
        public bool? PhProbe { get; set; }

        /// <summary>
        /// Gets or sets WeightCell
        /// </summary>
        /// <value>
        /// The weight cell.
        /// </value>
        public bool? WeightCell { get; set; }

        /// <summary>
        /// Gets or sets Temperature
        /// </summary>
        /// <value>
        /// The temperature.
        /// </value>
        public bool? Temperature { get; set; }

        /// <summary>
        /// Gets or sets WaterCounter
        /// </summary>
        /// <value>
        /// The water counter.
        /// </value>
        public bool? WaterCounter { get; set; }

        /// <summary>
        /// Gets or sets the Date And Time When Batch Ejects
        /// </summary>
        /// <value>
        /// DateAndTimeWhenBatchEjects
        /// </value>
        public bool? DateAndTimeWhenBatchEjects { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix After
        /// </summary>
        /// <value>Auto Rinse Desamix After</value>
        public short? AutoRinseDesamixAfter { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 1 For
        /// </summary>
        /// <value>Auto Rinse Desamix 1 For</value>
        public short? AutoRinseDesamix1For { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 2 For
        /// </summary>
        /// <value>Auto Rinse Desamix 2 For</value>
        public short? AutoRinseDesamix2For { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 1
        /// </summary>
        /// <value>Temperature Alarm Probe 1</value>
        public bool? TemperatureAlarmProbe1 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 2
        /// </summary>
        /// <value>Temperature Alarm Probe 2</value>
        public bool? TemperatureAlarmProbe2 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 3
        /// </summary>
        /// <value>Temperature Alarm Probe 3</value>
        public bool? TemperatureAlarmProbe3 { get; set; }

        /// <summary>
        /// Gets or sets the default idle time.
        /// </summary>
        /// <value>The default idle time.</value>
        public int DefaultIdleTime { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [we in tom mode].
        /// </summary>
        /// <value><c>true</c> if [we in tom mode]; otherwise, <c>false</c>.</value>
        public bool WeInTomMode { get; set; }
        /// <summary>
		/// Gets or sets FlowSwitchNumber
		/// </summary>
		/// <value>Flow Switch Number</value>
		public int FlowSwitchNumber { get; set; }
        /// <summary>
        ///     Gets or sets the Hold Delay.
        /// </summary>
        /// <value>The Hold Delay.</value>
        public int HoldDelay { get; set; }
        /// <summary>
        ///     Gets or sets a value indicating whether [Hold signal].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool HoldSignal { get; set; }
        /// <summary>
		/// Gets or sets the Lines Connected to Manifold L1
		/// </summary>
		/// <value>true/false</value>
		public bool L1 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L2
        /// </summary>
        /// <value>true/false</value>
        public bool L2 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L3
        /// </summary>
        /// <value>true/false</value>
        public bool L3 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L4
        /// </summary>
        /// <value>true/false</value>
        public bool L4 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L5
        /// </summary>
        /// <value>true/false</value>
        public bool L5 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L6
        /// </summary>
        /// <value>true/false</value>
        public bool L6 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L7
        /// </summary>
        /// <value>true/false</value>
        public bool L7 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L8
        /// </summary>
        /// <value>true/false</value>
        public bool L8 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L9
        /// </summary>
        /// <value>true/false</value>
        public bool L9 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L10
        /// </summary>
        /// <value>true/false</value>
        public bool L10 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L11
        /// </summary>
        /// <value>true/false</value>
        public bool L11 { get; set; }

        /// <summary>
        /// Gets or sets the Lines Connected to Manifold L12
        /// </summary>
        /// <value>true/false</value>
        public bool L12 { get; set; }
        /// <summary>
		/// Gets or sets the ManiFold Flush Time
		/// </summary>
		/// <value>Mani fold flush time</value>
		public int ManifoldFlushTime { get; set; }

        /// <summary>
        /// Gets or sets OnHoldWESignalActive
        /// </summary>
        /// <value>OnHoldWESignalActive</value>
        public bool OnHoldWESignalActive { get; set; }
        /// <summary>
        ///     Gets or sets the TargetTurnTime.
        /// </summary>
        /// <value>The TargetTurnTime.</value>
        public int TargetTurnTime { get; set; }
        /// <summary>
		/// Gets or sets washerStopExternalSignal
		/// </summary>
		/// <value>washerStopExternalSignal</value>
		public bool WasherStopExternalSignal { get; set; }

        /// <summary>
        /// Gets or sets the WasherOnHoldSignalDelay
        /// </summary>
        /// <value>Washer on hold signal delay</value>
        public int WasherOnHoldSignalDelay { get; set; }
        /// <summary>
        ///     Gets or sets the WaterFlushTime.
        /// </summary>
        /// <value>The Parameter WaterFlushTime.</value>
        public int WaterFlushTime { get; set; }

        /// <summary>
		/// Gets or sets MaxLoad_UOMCode
		/// </summary>
		/// <value>MaxLoad_UOMCode</value>
		public string MaxLoad_UOMCode { get; set; }

        /// <summary>
        /// Gets or sets ETechWasherNumber
        /// </summary>
        /// <value>ETechWasherNumber</value>
        public int ETechWasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>SignalAcceptanceTime</value>
        public int SignalAcceptanceTime { get; set; }

        /// <summary>
        ///     Gets or sets the KannegiesserDosageInPreparationTankMode
        /// </summary>
        /// <value>KannegiesserDosageInPreparationTankMode</value>
        public bool KannegiesserDosageInPreparationTankMode { get; set; }

        /// <summary>
        /// Gets or sets the BatchOk
        /// </summary>
        /// <value>
        /// BatchOk value
        /// </value>
        public bool BatchOk { get; set; }

        /// <summary>
        /// Gets or sets the transfer per hour.
        /// </summary>
        /// <value>
        /// The transfer per hour.
        /// </value>
        public int TransferPerHour { get; set; }

        #endregion Properties
    }
}