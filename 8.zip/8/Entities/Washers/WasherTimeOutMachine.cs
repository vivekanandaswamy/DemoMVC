﻿// -----------------------------------------------------------------------
// <copyright file="WasherTimeOutMachine.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WasherTimeOutMachine is for get and set the data.</summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.Washers
{
    /// <summary>
    ///     class Alarms
    /// </summary>
    public class WasherTimeOutMachine : BaseEntity
    {
        /// <summary>
        ///     Deafault Constructor for WasherTimeOutMachine
        /// </summary>
        public WasherTimeOutMachine()
        {
        }

        /// <summary>
        /// The Parameterised Constructor for WasherTimeOutMachine
        /// </summary>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="signalNumber">The Signal Number</param>
        /// <param name="equipmentNumber">The Equipment Number</param>
        /// <param name="dosingPointNumber">The Dosing Point Number</param>
        /// <param name="plantId">The Plant Id</param>
        /// <param name="lastModifiedTime">The lasr modified Time</param>
        public WasherTimeOutMachine(int washerId, byte signalNumber, int equipmentNumber, int dosingPointNumber, int plantId, DateTime lastModifiedTime)
        {
			this.WasherId = washerId;
			this.SignalNumber = signalNumber;
			this.EquipmentNumber = equipmentNumber;
			this.DosingPointNumber = dosingPointNumber;
			this.PlantId = plantId;
			this.LastModifiedTime = lastModifiedTime;
        }

        /// <summary>
        /// parameterised condtructor in case data is empty in TOM
        /// </summary>
        /// <param name="equipmentCount">equipmentCount</param>
        /// <param name="dosingPointCount">dosingPointCount</param>
        public WasherTimeOutMachine(byte equipmentCount, byte dosingPointCount)
	    {
		    this.EquipmentCount = equipmentCount;
		    this.DosingPointCount = dosingPointCount;
	    }

        /// <summary>
        /// The Parameterised Constructor for WasherTimeOutMachine
        /// </summary>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="plantId">The Plant Id</param>
        /// <param name="signalNumber">The Signal Number</param>
        /// <param name="equipmentNumber">The Equipment Number</param>
        /// <param name="dosingPointNumber">The Dosing Point Number</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="lastModifiedTime">The lasr modified Time</param>
        public WasherTimeOutMachine(int washerId, int plantId, byte signalNumber, int equipmentNumber, int dosingPointNumber, bool isDelete, DateTime lastModifiedTime)
        {
			this.WasherId = washerId;
			this.SignalNumber = signalNumber;
			this.EquipmentNumber = equipmentNumber;
			this.DosingPointNumber = dosingPointNumber;
            this.IsDeleted = isDelete;
			this.PlantId = plantId;
			this.LastModifiedTime = lastModifiedTime;
        }

        /// <summary>
        ///     Gets or sets the washerId
        /// </summary>
        /// <value>The washer Id</value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the signalNumber
        /// </summary>
        /// <value>The Signal Number</value>
        public byte SignalNumber { get; set; }

        /// <summary>
        ///     Gets or sets the equipmentNumber
        /// </summary>
        /// <value>The Equipment Number</value>
        public int EquipmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        /// <value>The Parameter Controller Type Id</value>
        public int ControllerTypelId { get; set; }

        /// <summary>
        ///     Gets or sets the dosingPointNumber
        /// </summary>
        /// <value>The Dosing Point Number</value>
        public int DosingPointNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>The Last Modified Time</value>
        public DateTime LastModifiedTime { get; set; }

		/// <summary>
		///  Gets or sets EquipmentCount
		/// </summary>
		/// <value>EquipmentCount</value>
		public byte EquipmentCount { get; set; }

		/// <summary>
		///  Gets or sets DosingPointCount
		/// </summary>
		/// <value>DosingPointCount</value>
		public byte DosingPointCount { get; set; }
    }
}