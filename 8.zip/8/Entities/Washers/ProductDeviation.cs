﻿// -----------------------------------------------------------------------
// <copyright file="ProductDeviation.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductDeviation </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Washers
{
    /// <summary>
    ///     The Product Deviation Class
    /// </summary>
    public class ProductDeviation : BaseEntity
    {
        /// <summary>
        /// The Default constructor
        /// </summary>
        /// <param name="washerProductDeviationID">The washer product deviation identifier.</param>
        /// <param name="controllerEquipmentID">The controller equipment identifier.</param>
        /// <param name="productName">Name of the product.</param>
        /// <param name="productDeviation">The product deviation.</param>
        /// <param name="ConventionalWasherGroupConnection">if set to <c>true</c> [conventional washer group connection].</param>
        /// <param name="EnvisionDisplayName">Display name of the envision.</param>
        public ProductDeviation(int washerProductDeviationID, byte controllerEquipmentID, string productName, int productDeviation, bool ConventionalWasherGroupConnection, string EnvisionDisplayName)
        {
            this.Id = washerProductDeviationID;
            this.ControllerEquipmentID = controllerEquipmentID;
            this.ProductName = productName;
            this.ProductDeviationValue = productDeviation;
            this.ConventionalWasherGroupConnection = ConventionalWasherGroupConnection;
            this.EnvisionDisplayName = EnvisionDisplayName;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductDeviation"/> class.
        /// </summary>
        /// <param name="washerProductDeviationID">washerProductDeviationID</param>
        /// <param name="washerId">washerId</param>
        /// <param name="controllerEquipmentID">The controller equipment identifier.</param>
        /// <param name="controllerID">The controller identifier.</param>
        /// <param name="productDeviation">The product deviation.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="plantId">The plant identifier.</param>
        public ProductDeviation(Int32 washerProductDeviationID, Int32 washerId, byte controllerEquipmentID, Int32 controllerID, Int16 productDeviation, DateTime lastModifiedTime, Int32 plantId)
        {
            this.Id = washerProductDeviationID;
            this.WasherId = washerId;
            this.ControllerEquipmentID = controllerEquipmentID;
            this.ControllerID = controllerID;
            this.ProductDeviationValue = productDeviation;
            this.LastModifiedTime = lastModifiedTime;
            this.PlantId = plantId;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductDeviation"/> class.
        /// </summary>
        public ProductDeviation()
        {
        }

        /// <summary>
        ///     gets or sets the ControllerID 
        /// </summary>
        /// <value>The ControllerID.</value>
        public int ControllerID { get; set; }

        /// <summary>
        ///     gets or sets the Controller Equipment SetupID
        /// </summary>
        /// <value>The ControllerEquipmentSetupID.</value>
        public int ControllerEquipmentSetupID { get; set; }

        /// <summary>
        ///     gets or sets the Controller Equipment ID
        /// </summary>
        /// <value>The ControllerEquipmentID.</value>
        public int ControllerEquipmentID { get; set; }

        /// <summary>
        ///     gets or sets the Controller Equipment TypeId
        /// </summary>
        /// <value>The ControllerEquipmentTypeId.</value>
        public int ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     gets or sets the WasherId
        /// </summary>
        /// <value>The WasherId.</value>
        public int WasherId { get; set; }

        /// <summary>
        ///     gets or sets the Product Name
        /// </summary>
        /// <value>The Product Name.</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     gets or sets the Product Deviation Value
        /// </summary>
        /// <value>The Product Deviation Value.</value>
        public int ProductDeviationValue { get; set; }

        /// <summary>
        ///     gets or sets the Last ModifiedTime Value
        /// </summary>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     gets or sets the ConventionalWasherGroupConnection Value
        /// </summary>
        /// <value>The ConventionalWasherGroupConnection Value.</value>
        public bool ConventionalWasherGroupConnection { get; set; }
        /// <summary>
        /// get set EnvisionDisplayName
        /// </summary>
        public string EnvisionDisplayName { get; set; }

    }
}
