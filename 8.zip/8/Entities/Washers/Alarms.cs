﻿// -----------------------------------------------------------------------
// <copyright file="Alarms.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The Alarms is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Entities.Washers
{
	using System;
	using System.Collections.Generic;

    /// <summary>
    ///     class Alarms
    /// </summary>
    public class Alarms : BaseEntity
    {
        /// <summary>
        ///     Deafault Constructor for Alarms
        /// </summary>
        public Alarms()
        {
        }

        /// <summary>
        ///     Constructor for Alarms
        /// </summary>
        /// <param name="alarmCode">The alarmCode</param>
        /// <param name="description">The description</param>
        /// <param name="alarmMachineMappingId">The alarmMachineMappingId</param>
        /// <param name="displayOrder">The displayOrder</param>
        /// <param name="isDefault">The isDefault</param>
        /// <param name="active">The active</param>
        /// <param name="resourceKey">The resourceKey</param>
        public Alarms(int alarmCode, string description, int alarmMachineMappingId, short displayOrder, bool isDefault, bool active, string resourceKey)
        {
            this.Id = alarmCode;
            this.Description = description;
            this.AlarmMachineMappingId = alarmMachineMappingId;
            this.DisplayOrder = displayOrder;
            this.IsDefault = isDefault;
            this.Active = active;
            this.ResourceKey = resourceKey;
        }

		/// <summary>
		/// Initializes the Alarms object 
		/// </summary>
		/// <param name="id">The primary key Id from database</param>
		/// <param name="controllerModelId">The Controller Model Id</param>
		/// <param name="description">The Description</param>
		/// <param name="isActive">The IsActive Condition</param>
		public Alarms(int id, int controllerModelId, string description, bool isActive, DateTime? lastModifiedTimestamp)
		{
			this.AlarmMachineMappingId = id;
			this.ControllerModelId = controllerModelId;
			this.Description = description;
			this.Active = isActive;
			this.LastModifiedTimestamp = lastModifiedTimestamp;
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="alarmMachineMappingId"></param>
        /// <param name="active"></param>
        /// <param name="machineNumber"></param>
        /// <param name="lastModifiedTimestamp"></param>
        /// <param name="tunnelId"></param>
        /// <param name="ecolabAccNumb"></param>
        public Alarms(int id, int alarmMachineMappingId, bool active, int machineNumber, DateTime? lastModifiedTimestamp, int tunnelId, string ecolabAccNumb)
        {
            this.Id = id;
            this.AlarmMachineMappingId = alarmMachineMappingId;
            this.Active = active;
            this.MachineNumber = machineNumber;
            this.LastModifiedTimestamp = lastModifiedTimestamp;
            this.TunnelId = tunnelId;
            this.EcolabAccountNumber = ecolabAccNumb;
        }

        public Alarms(int id, int washerId, int plantId, DateTime lastModifiedTime)
        {
            this.AlarmMachineMappingId = id;
            this.TunnelId = washerId;
            this.PlantId = plantId;
            this.LastModifiedTimestamp = lastModifiedTime;
        }

        /// <summary>
        /// Initializes the Alarm object for Batch eject condition resync
        /// </summary>
        /// <param name="id"></param>
        /// <param name="washerId"></param>
        /// <param name="plantId"></param>
        /// <param name="lastModifiedUserId"></param>
        /// <param name="lastModifiedTime"></param>
        /// <param name="ecolabAccNumber"></param>
        public Alarms(int id, int washerId, int plantId, int lastModifiedUserId, DateTime lastModifiedTime, string ecolabAccNumber)
        {
            this.AlarmMachineMappingId = id;
            this.TunnelId = washerId;
            this.PlantId = plantId;
            this.LastModifiedByUserId = lastModifiedUserId;
            this.LastModifiedTimestamp = lastModifiedTime;
            this.EcolabAccountNumber = ecolabAccNumber;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Alarms"/> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="alarmMachineMappingId">The alarm machine mapping identifier.</param>
        /// <param name="active">if set to <c>true</c> [active].</param>
        /// <param name="lastModifiedUserId">The last modified user identifier.</param>
        /// <param name="machineNumber">The machine number.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="ecolabAccNumber">The ecolab acc number.</param>
        /// <param name="washerId">The washer identifier.</param>
        public Alarms(int id, int alarmMachineMappingId, bool active, int lastModifiedUserId, int machineNumber, DateTime lastModifiedTime, string ecolabAccNumber, int washerId)
        {
            this.Id = id;
            this.AlarmMachineMappingId = alarmMachineMappingId;
            this.Active = active;
            this.LastModifiedByUserId = lastModifiedUserId;
            this.MachineNumber = machineNumber;
            this.LastModifiedTimestamp = lastModifiedTime;            
            this.EcolabAccountNumber = ecolabAccNumber;
            this.TunnelId = washerId;
        }
       
        /// <summary>
        ///     Gets or sets the Description
        /// </summary>
        /// <value>The Parameter Description</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmMachineMappingId
        /// </summary>
        /// <value>The Parameter Alarm Machine Mapping Id</value>
        public int AlarmMachineMappingId { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmMachineMappingIds
        /// </summary>
        /// <value>The Parameter Alarm Machine Mapping Id</value>
        public List<int> AlarmMachineMappingIds { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOrder
        /// </summary>
        /// <value>The Parameter display Order</value>
        public short DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the IsDefault
        /// </summary>
        /// <value>The Parameter Is Default</value>
        public bool IsDefault { get; set; }

        /// <summary>
        ///     Gets or sets the Active
        /// </summary>
        /// <value>The Parameter Active</value>
        public bool Active { get; set; }

        /// <summary>
        ///     Gets or sets the ResourceKey
        /// </summary>
        /// <value>The Parameter Resource Key</value>
        public string ResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId
        /// </summary>
        /// <value>The Parameter Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        /// <value>The Parameter Controller Type Id</value>
        public int ControllerTypelId { get; set; }

        /// <summary>
        ///     Gets or sets the Machine Number
        /// </summary>
        /// <value>The Parameter Machine Number</value>
        public int MachineNumber { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

		/// <summary>
		/// Gets or Sets the Machine Id
		/// </summary>
		/// <value> The machine Identifier</value>
		public int TunnelId { get; set; }

		/// <summary>
		/// Gets or Sets the IsBatchEjectCondition
		/// </summary>
		/// <value> Is Batch Eject Condition</value>
		public bool IsBatchEjectCondition { get; set; }
		/// <summary>
		///     Gets or sets the Last Modified Time Stamp
		/// </summary>
		/// <value>LastModifiedTimeStamp</value>
		public DateTime? LastModifiedTimestamp { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime LastModifiedTimeBatchEjectionCentral { get; set; }

        /// <summary>
        /// Gets or Sets the LastModifiedByUserId
        /// </summary>
        /// <value>The Last Modified By User Id</value>
        public int LastModifiedByUserId { get; set; }
    }
}