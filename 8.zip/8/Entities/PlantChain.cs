﻿// -----------------------------------------------------------------------
// <copyright file="PlantChain.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Chain </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities
{
    /// <summary>
    ///     class Plant Chain Program
    /// </summary>
    public class PlantChain
    {
        #region "Constructor"
        /// <summary>
        /// Default constructor PlantChain
        /// </summary>
        public PlantChain()
        {
           
        }

        /// <summary>
        /// parametrized constructor PlantChain
        /// </summary>
        /// <param name="plantChainName">ChainName</param>
        /// <param name="isDelete">IsDelete</param>
        /// <param name="myServiceChnId">MyServiceChainId</param>
        /// <param name="myServiceLastSynchTime">MyServiceLastSynchTime</param>
        public PlantChain(string plantChainName,
                          bool isDelete,
                          int myServiceChnId,
                          DateTime myServiceLastSynchTime)
        {
            PlantChainName = plantChainName;
            Is_Deleted = isDelete;
            MyServiceChnId = myServiceChnId;
            MyServiceLastSynchTime = myServiceLastSynchTime;
        }

        /// <summary>
        /// parametrized constructor PlantChain
        /// </summary>
        /// <param name="plantChainId">ChainId</param>
        /// <param name="plantChainName">ChainName</param>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="isDelete">IsDelete</param>
        /// <param name="myServiceChnId">MyServiceChainId</param>
        /// <param name="myServiceLastSynchTime">MyServiceLastSynchTime</param>
        public PlantChain(int plantChainId,
                          string plantChainName,
                          short regionId,
                          bool isDelete,
                          int myServiceChnId,
                          DateTime myServiceLastSynchTime)
        {
            PlantChainId = plantChainId;
            PlantChainName = plantChainName;
            RegionId = regionId;
            Is_Deleted = isDelete;
            MyServiceChnId = myServiceChnId;
            MyServiceLastSynchTime = myServiceLastSynchTime;
        }

        #endregion

        #region "Properties"
        /// <summary>
        /// Gets or sets PlantChainId
        /// </summary>
        public int PlantChainId { get; set; }

        /// <summary>
        /// Gets or sets PlantChainName
        /// </summary>
        public string PlantChainName { get; set; }

        /// <summary>
        /// Gets or sets RegionId
        /// </summary>
        public int RegionId { get; set; }

        /// <summary>
        /// Gets or sets RegionCode 
        /// This property is used only for my service to get the region code and based of that we will get region id and  region name from conduict
        /// </summary>
        public string RegionCode { get; set; }

        /// <summary>
        /// Gets or sets Is_Deleted
        /// </summary>
        public bool Is_Deleted { get; set; }

        /// <summary>
        /// Gets or sets MyServiceChnId
        /// </summary>
        public int MyServiceChnId { get; set; }

        /// <summary>
        /// Gets or sets MyServiceLastSynchTime
        /// </summary>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}