﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceSyncLog.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyServiceSyncLog object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    /// <summary>
    ///     Class for User Roles
    /// </summary>
    public class MyServiceSyncLog
    {
        /// <summary>
        ///     Fetches the sync log
        /// </summary>
        /// <param name="ecolabAccountNumber">The parameter Role ID</param>
        /// <param name="entity">The parameter Role name</param>
        /// <param name="status">The parameter Code</param>
        /// <param name="lastSyncTime">Last Sync Time</param>
        public MyServiceSyncLog(string ecolabAccountNumber, string entity, string status, DateTime lastSyncTime)
        {
            EcolabAccountNumber = ecolabAccountNumber;
            Entity = entity;
            Status = status;
            MyServiceLastSynchTime = lastSyncTime;
        }

        /// <summary>
        ///    Gets or sets the Id.
        /// </summary>
        /// <value>
        ///    Parameter Id.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value>
        ///    Parameter  EcolabAccountNumber.
        /// </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Entity.
        /// </summary>
        /// <value>
        ///    Parameter  Entity.
        /// </value>
        public string Entity { get; set; }

        /// <summary>
        ///     Gets or sets the Status.
        /// </summary>
        /// <value>
        ///    Parameter  Status.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        ///     Gets or sets the Active.
        /// </summary>
        /// <value>
        ///    Parameter  Active.
        /// </value>
        public bool Active { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime.
        /// </summary>
        /// <value>
        ///    Parameter  MyServiceLastSynchTime.
        /// </value>
        public DateTime MyServiceLastSynchTime { get; set; }
    }
}