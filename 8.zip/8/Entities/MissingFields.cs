﻿// -----------------------------------------------------------------------
// <copyright file="MissingFields.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MissingFields </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Entities
{
	public class MissingFields
	{
		/// <summary>
		/// Creates the instance of the Missing Fields
		/// </summary>
		public MissingFields (string pathName, string fieldName)
		{
			this.PathName = pathName;
			this.FieldName = fieldName;
		}

		/// <summary>
		/// Gets or Sets the Page Name
		/// </summary>
		/// <value>
		/// The Page Name
		/// </value>
		public string PathName  { get; set; }

		/// <summary>
		/// Gets or Sets the Field Name
		/// </summary>
		/// <value>
		/// The Field Name
		/// </value>
		public string FieldName { get; set; }
	}
}