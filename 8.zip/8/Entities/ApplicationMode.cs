﻿// -----------------------------------------------------------------------
// <copyright file="ApplicationMode.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ApplicationMode </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public enum ApplicationMode
    {
        Local = 0,
        Central = 1
    }
}
