﻿// -----------------------------------------------------------------------
// <copyright file="CopyFormulaContainer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The CopyFormulaContainer </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Entities.PlantSetup.Chemical;
namespace Entities.WasherGroup
{
	public class CopyFormulaContainer : BaseEntity
	{
		/// <summary>
		/// Default Constructor
		/// </summary>
		public CopyFormulaContainer()
		{
		}

		/// <summary>
		/// Gets or sets the FromWasherGroupId identifier.
		/// </summary>
		/// <value>
		/// The FromWasherGroupId identifier.
		/// </value>
		public List<CopyFormula> FormulaList { get; set; }

		/// <summary>
		/// Gets or sets the FromWasherGroupId identifier.
		/// </summary>
		/// <value>
		/// The FromWasherGroupId identifier.
		/// </value>
		public List<SubstituteChemical> MissingChemicalList { get; set; }

		/// <summary>
		///     Gets or sets the LastModifiedTimestampAtCentral
		/// </summary>
		/// <value>LastModifiedTimestampAtCentral</value>
		public DateTime? LastModifiedTimestampAtCentral { get; set; }

		/// <summary>
		/// Gets or sets MaxNumberOfRecords
		/// </summary>
		public int MaxNumberOfRecords { get; set; }
	}
}