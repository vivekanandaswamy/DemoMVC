﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaConventionalAnalogueControl.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherFormulaConventionalAnalogueControl </summary>
// -----------------------------------------------------------------------
namespace Entities.WasherGroup
{
    /// <summary>
    /// Washer Formula Conventional Analogue Control
    /// </summary>
    public class WasherFormulaConventionalAnalogueControl : BaseEntity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WasherFormulaConventionalAnalogueControl"/> class.
        /// </summary>
        public WasherFormulaConventionalAnalogueControl()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherFormulaConventionalAnalogueControl"/> class.
        /// </summary>
        /// <param name="washerDosingNumber">The washer dosing number.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="stepNumber">The step number.</param>
        /// <param name="washerDosingSetupId">The washer dosing setup identifier.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="minimumTime">The minimum time.</param>
        /// <param name="startDelay">The start delay.</param>
        /// <param name="acceptedDelay">The accepted delay.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="setPointTemperature">The set point temperature.</param>
        /// <param name="phControlDuringDrain">if set to <c>true</c> [ph control during drain].</param>
        /// <param name="phDelayTime">The ph delay time.</param>
        /// <param name="phMeasuringTime">The ph measuring time.</param>
        /// <param name="phMaximum">The ph maximum.</param>
        /// <param name="phMininum">The ph mininum.</param>
        /// <param name="sensorNum">The sensor number.</param>
        /// <param name="sensorType">Type of the sensor.</param>
        public WasherFormulaConventionalAnalogueControl(int washerDosingNumber, short programNumber, int stepNumber, int washerDosingSetupId, byte controllerEquipmentId,
                short minimumTime, short startDelay, short acceptedDelay, int productId, decimal setPointTemperature,
                bool phControlDuringDrain, short phDelayTime, short phMeasuringTime, decimal phMaximum, decimal phMininum, int sensorNum, int sensorType)
        {
            WasherDosingNumber = washerDosingNumber;
            ProgramNumber = programNumber;
            StepNumber = stepNumber;
            WasherDosingSetupId = washerDosingSetupId;
            EquipmentNumber = controllerEquipmentId;
            MinimumTime = minimumTime;
            StartDelay = startDelay;
            AcceptedDelay = acceptedDelay;
            ProductId = productId;
            SetPointTemperature = setPointTemperature;
            PhControlDuringDrain = phControlDuringDrain;
            PhDelayTime = phDelayTime;
            PhMeasuringTime = phMeasuringTime;
            PhMaximum = phMaximum;
            PhMininum = phMininum;
            SensorNum = sensorNum;
            SensorType = sensorType;
        }

        /// <summary>
        /// Gets the washer dosing number.
        /// </summary>
        /// <value>
        /// The washer dosing number.
        /// </value>
        public int WasherDosingNumber { get; private set; }

        /// <summary>
        /// Gets or sets the program number.
        /// </summary>
        /// <value>
        /// The program number.
        /// </value>
        public short ProgramNumber { get; set; }

        /// <summary>
        /// Gets or sets the Step Number
        /// </summary>
        /// <value>
        /// The step number.
        /// </value>
        public int StepNumber { get; set; }

        /// <summary>
        /// Gets or sets the Washer Dosing Setup Id
        /// </summary>
        /// <value>
        /// The washer dosing setup identifier.
        /// </value>
        public int WasherDosingSetupId { get; set; }

        /// <summary>
        /// Gets or sets the Equipment Number
        /// </summary>
        /// <value>
        /// The equipment number.
        /// </value>
        public byte EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the Minimum Time
        /// </summary>
        /// <value>
        /// The minimum time.
        /// </value>
        public short MinimumTime { get; set; }

        /// <summary>
        /// Gets or sets the Start Delay
        /// </summary>
        /// <value>
        /// The start delay.
        /// </value>
        public short StartDelay { get; set; }

        /// <summary>
        /// Gets or sets the Accepted Delay
        /// </summary>
        /// <value>
        /// The accepted delay.
        /// </value>
        public short AcceptedDelay { get; set; }

        /// <summary>
        /// Gets or sets the Product Id
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets the Set Point Temperature
        /// </summary>
        /// <value>
        /// The set point temperature.
        /// </value>
        public decimal SetPointTemperature { get; set; }

        /// <summary>
        /// Gets or sets the Ph control during drain
        /// </summary>
        /// <value>
        /// <c>true</c> if [ph control during drain]; otherwise, <c>false</c>.
        /// </value>
        public bool PhControlDuringDrain { get; set; }

        /// <summary>
        /// Gets or sets the Phdelaytime
        /// </summary>
        /// <value>
        /// The ph delay time.
        /// </value>
        public short PhDelayTime { get; set; }

        /// <summary>
        /// Gets or sets the Phmeasuringtime
        /// </summary>
        /// <value>
        /// The ph measuring time.
        /// </value>
        public short PhMeasuringTime { get; set; }

        /// <summary>
        /// Gets or sets the Ph maximum
        /// </summary>
        /// <value>
        /// The ph maximum.
        /// </value>
        public decimal PhMaximum { get; set; }

        /// <summary>
        /// Gets or sets the Ph mininum
        /// </summary>
        /// <value>
        /// The ph mininum.
        /// </value>
        public decimal PhMininum { get; set; }

        /// <summary>
        /// Gets or sets the Product Check
        /// </summary>
        /// <value>
        ///   <c>true</c> if [product check]; otherwise, <c>false</c>.
        /// </value>
        public bool ProductCheck { get; set; }

        /// <summary>
        /// Gets or sets the Sensor Number
        /// </summary>
        /// <value>
        /// The sensor number.
        /// </value>
        public int SensorNum { get; set; }

        /// <summary>
        /// Gets or sets the Sensor Type
        /// </summary>
        /// <value>
        /// The type of the sensor.
        /// </value>
        public int SensorType { get; set; }
    }
}
