﻿// -----------------------------------------------------------------------
// <copyright file="TunnelAnalogueControl.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelAnalogueControl </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.WasherGroup
{
	public class TunnelAnalogueControl : BaseEntity
	{
        /// <summary>
        /// Initializes the Tunnel Analogue Control
        /// </summary>
        /// <param name="tempSetPoint">The Temp Set Point</param>
        /// <param name="minTime">The Min Time of TunnelAnalogueControl</param>
        /// <param name="startDelay">The Start Delay of TunnelAnalogueControl</param>
        /// <param name="acceptedDelay">The Accepted Delay</param>
        /// <param name="productCheck">The Product Check</param>
        /// <param name="phRegulationLevel">The PH Regulation Level</param>
        /// <param name="pHMonitoringLevel">The p h monitoring level.</param>
        /// <param name="pHMinimum">The p h minimum of of .</param>
        /// <param name="pHMaximum">The p h maximum  of TunnelAnalogueControl.</param>
        /// <param name="DelayTime">The delay time of TunnelAnalogueControl.</param>
        /// <param name="MeasuringTime">The measuring time.</param>
        /// <param name="conductivityRegulationLevel">The Conductivity Reg Level</param>
        /// <param name="ConductivityMininum">The conductivity mininum.</param>
        /// <param name="ConductivityMaximum">The conductivity maximum.</param>
        /// <param name="ConductivityDelayTime">The conductivity delay time.</param>
        /// <param name="ConductivityMeasuringTime">The conductivity measuring time.</param>
        /// <param name="tunnelprogramSetupId">The Tunnel Program Setup Id</param>
        /// <param name="tunnelCompartmentNumber">The Tunnel Compartment Number</param>
        /// <param name="ecolabAccNumber">The ecolab acc number.</param>
        public TunnelAnalogueControl(double tempSetPoint, int minTime, int startDelay, int acceptedDelay, bool? productCheck, int? phRegulationLevel, int pHMonitoringLevel,decimal pHMinimum, decimal pHMaximum, int DelayTime,int MeasuringTime, int? conductivityRegulationLevel,decimal ConductivityMininum, decimal ConductivityMaximum, int ConductivityDelayTime, int ConductivityMeasuringTime, int tunnelprogramSetupId, int tunnelCompartmentNumber, string ecolabAccNumber)
        {
            this.TempSetPoint = tempSetPoint;
            this.MinTime = minTime;
            this.StartDelay = startDelay;
            this.AcceptedDelay = acceptedDelay;
            this.ProductCheck = productCheck;
            this.PhRegulationLevel = phRegulationLevel;
            this.MonitoringLevel = pHMonitoringLevel;
            this.pHMin = pHMinimum;
            this.pHMax = pHMaximum;
            this.pHStartDelay = DelayTime;
            this.pHMeasTime = MeasuringTime;
            this.ConductivityRegulationLevel = conductivityRegulationLevel;
            this.ConductivityMin = ConductivityMininum;
            this.ConductivityMax = ConductivityMaximum;
            this.ConductivityDelayTime = ConductivityDelayTime;
            this.ConductivityMeasTime = ConductivityMeasuringTime;
            this.TunnelprogramSetupId = tunnelprogramSetupId;
            this.TunnelCompartmentNumber = tunnelCompartmentNumber;
            this.EcolabAccountNumber = ecolabAccNumber;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="TunnelAnalogueControl"/> class.
        /// </summary>
        public TunnelAnalogueControl()
        {

        }
        /// <summary>
        /// Gets or Sets the Temperature Set Point
        /// </summary>
        /// <value>The Temperature Set Point</value>
        public double TempSetPoint { get; set; }
        /// <summary>
        /// Gets or Sets the Minnimum Time
        /// </summary>
        /// <value>The Minimum Time</value>
        public int MinTime { get; set; }
        /// <summary>
        /// Gets or Sets the Start Delay
        /// </summary>
        /// <value>The Start Delay</value>
        public int StartDelay { get; set; }
        /// <summary>
        /// Gets or Sets the Accepted Delay
        /// </summary>
        /// <value>The Accepted Delay</value>
        public int AcceptedDelay { get; set; }
        /// <summary>
        /// Gets or Sets the Product Check
        /// </summary>
        /// <value>The Product Check</value>
        public bool? ProductCheck { get; set; }
        /// <summary>
        /// The PH Regulation Level
        /// </summary>
        /// <value>The PH Regulation Level</value>
        public int? PhRegulationLevel { get; set; }
        /// <summary>
        /// The Monitoring Level
        /// </summary>
        /// <value>The Monitoring Level</value>
        public int? MonitoringLevel { get; set; }
        /// <summary>
        /// The Conductivity Regulation Level
        /// </summary>
        /// <value>The Conductivity Regulation Level</value>
        public int? ConductivityRegulationLevel { get; set; }
        /// <summary>
        /// Gets or Sets the Tunnel Program Setup Id
        /// </summary>
        /// <value>The Tunnel Program Setup Id</value>
        public int TunnelprogramSetupId { get; set; }
        /// <summary>
        /// Gets or Sets the Tunnel Compartment Number
        /// </summary>
        /// <value>The Tunnel Compartment Number</value>
        public int TunnelCompartmentNumber { get; set; }
        /// <summary>
        /// Gets or Sets the Tunnel Washer Id
        /// </summary>
        /// <value>The Tunnel Washer Id</value>
        public int TunnelWasherId { get; set; }

        /// <summary>
        /// pH Min
        /// </summary>
        public decimal pHMin { get; set; }

        /// <summary>
        /// pH Max
        /// </summary>
        public decimal pHMax { get; set; }

        /// <summary>
        /// pH Start Delay
        /// </summary>
        public int pHStartDelay { get; set; }

        /// <summary>
        /// pH Measuring Time
        /// </summary>
        public int pHMeasTime { get; set; }

        /// <summary>
        /// Conductivity Min
        /// </summary>
        public decimal ConductivityMin { get; set; }

        /// <summary>
        /// Conductivity Max
        /// </summary>
        public decimal ConductivityMax { get; set; }

        /// <summary>
        /// Conductivity Delay Time
        /// </summary>
        public int ConductivityDelayTime { get; set; }

        /// <summary>
        /// Conductivity Measuring Time
        /// </summary>
        public int ConductivityMeasTime { get; set; }

    }
}