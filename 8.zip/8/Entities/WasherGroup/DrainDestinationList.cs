﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationList.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Gets or sets the types of drain destination List values.</summary>
// -----------------------------------------------------------------------
namespace Entities.WasherGroup
{
    using System;

    /// <summary>
    /// class for getting the drain destination values.
    /// </summary>
    public class DrainDestinationList : BaseEntity
    {
        /// <summary>
        ///     Deafault Constructor for DrainDestination
        /// </summary>
        public DrainDestinationList()
        {

        }

        /// <summary>
        ///  Deafault Constructor for DrainDestination
        /// <param name="drainDestinationId">Gets drainDestinationId value</param>
        /// <param name="drainDestinationName">Gets drainDestinationName value</param>
        /// </summary>
        public DrainDestinationList(Int16 drainDestinationId, string drainDestinationName)
        {
            this.DrainDestinationId = drainDestinationId;
            this.DrainDestinationName = drainDestinationName;
        }

        #region Properties

        /// <summary>
        ///     Gets or sets DrainDestinationId
        /// </summary>
        /// <value> Parameter DrainDestinationId</value>
        public int DrainDestinationId { get; set; }

        /// <summary>
        ///     Gets or sets DrainDestinationName
        /// </summary>
        /// <value> Parameter DrainDestinationName</value>
        public string DrainDestinationName { get; set; }

        #endregion
    }
}
