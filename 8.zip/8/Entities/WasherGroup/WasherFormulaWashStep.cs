﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaWashStep.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WasherFormulaWashStep is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Entities.WasherGroup
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     class WasherFormulaWashStep
    /// </summary>
    public class WasherFormulaWashStep : BaseEntity
    {
        /// <summary>
        ///     Deafault Constructor for WasherFormulaWashStep
        /// </summary>
        public WasherFormulaWashStep()
        {
        }
        /// <summary>
        /// Constructor for WasherFormulaWashStep
        /// </summary>
        /// <param name="dosingSetupId">The dosingSetupId</param>
        /// <param name="washerProgramSetupId">The washer program setup identifier.</param>
        /// <param name="programNumber">The ProgramNumber</param>
        /// <param name="washerGroupId">The washerGroupId</param>
        /// <param name="stepNumber">The Parameter stepNumber</param>
        /// <param name="washOperationId">The washOperationId</param>
        /// <param name="washOperation">The washOperation</param>
        /// <param name="runtime">The Parameter runTime</param>
        /// <param name="temperature">The Parameter temperature</param>
        /// <param name="waterType">The Parameter waterType</param>
        /// <param name="waterLevel">The water level.</param>
        /// <param name="drainDestinationId">The drainDestinationId</param>
        /// <param name="drainDestination">The drainDestination</param>
        /// <param name="pHLevel">The Parameter pHLevel</param>
        /// <param name="note">The Parameter note</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="myServiceCusrFrmulaStpGuid">My service cusr frmula STP unique identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        public WasherFormulaWashStep(int dosingSetupId, int washerProgramSetupId, short programNumber, int washerGroupId, int stepNumber, int washOperationId, string washOperation, int runtime, int temperature, string waterType, decimal waterLevel, short? drainDestinationId, string drainDestination, short pHLevel, string note, string ecolabAccountNumber, Guid myServiceCusrFrmulaStpGuid, DateTime myServiceLastSynchTime)
        {
            this.Id = dosingSetupId;
            this.ProgramSetupId = washerProgramSetupId;
            this.ProgramNumber = programNumber;
            this.WasherGroupId = washerGroupId;
            this.StepNumber = stepNumber;
            this.WashOperationId = washOperationId;
            this.WashOperation = washOperation;
            this.Runtime = runtime;
            this.Temperature = temperature;
            this.WaterType = waterType;
            this.WaterLevel = waterLevel;
            this.DrainDestinationId = drainDestinationId;
            this.DrainDestination = drainDestination;
            this.PhLevel = pHLevel;
            this.Note = note;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.MyServiceCusrFrmulaStpGuid = myServiceCusrFrmulaStpGuid;
            this.MyServiceModDtTm = myServiceLastSynchTime;
        }

        /// <summary>
        /// Constructor for WasherFormulaWashStep
        /// </summary>
        /// <param name="dosingSetupId">The dosingSetupId</param>
        /// <param name="programNumber">The ProgramNumber</param>
        /// <param name="washerGroupId">The washerGroupId</param>
        /// <param name="stepNumber">The Parameter stepNumber</param>
        /// <param name="washOperationId">The washOperationId</param>
        /// <param name="washOperation">The washOperation</param>
        /// <param name="runtime">The Parameter runTime</param>
        /// <param name="temperature">The Parameter temperature</param>
        /// <param name="waterType">The Parameter waterType</param>
        /// <param name="waterLevel">The water level.</param>
        /// <param name="drainDestinationId">The drainDestinationId</param>
        /// <param name="drainDestination">The drainDestination</param>
        /// <param name="pHLevel">The Parameter pHLevel</param>
        /// <param name="note">The Parameter note</param>
        /// <param name="myServiceWshOpId">My service WSH op identifier.</param>
        /// <param name="myServiceUtilId">My service utility identifier.</param>
        /// <param name="myServiceDrainTypId">My service drain typ identifier.</param>
        /// <param name="isdelete">if set to <c>true</c> [isdelete].</param>
        /// <param name="myServiceCusrFrmulaStpGuid">My service cusr frmula STP unique identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="washerProgramSetupId">The washer program setup identifier.</param>
        public WasherFormulaWashStep(int dosingSetupId, short programNumber, int washerGroupId, int stepNumber, int washOperationId, string washOperation, int runtime, int temperature, string waterType, 
            decimal waterLevel, short drainDestinationId, string drainDestination, short pHLevel, string note, short myServiceWshOpId, short myServiceUtilId, short myServiceDrainTypId, 
            bool isdelete, Guid myServiceCusrFrmulaStpGuid, DateTime myServiceLastSynchTime, int washerProgramSetupId, bool Trackasdosingstep, string sensorAttached)
        {
            this.Id = dosingSetupId;
            this.ProgramNumber = programNumber;
            this.WasherGroupId = washerGroupId;
            this.StepNumber = stepNumber;
            this.WashOperationId = washOperationId;
            this.WashOperation = washOperation;
            this.Runtime = runtime;
            this.Temperature = temperature;
            this.WaterType = waterType;
            this.WaterLevel = waterLevel;
            this.DrainDestinationId = drainDestinationId;
            this.DrainDestination = drainDestination;
            this.PhLevel = pHLevel;
            this.Note = note;
            this.MyServiceWshOpId = myServiceWshOpId;
            this.MyServiceUtilId = myServiceUtilId;
            this.MyServiceDrainTypId = myServiceDrainTypId;
            this.IsDelete = isdelete;
            this.MyServiceCusrFrmulaStpGuid = myServiceCusrFrmulaStpGuid;
            this.MyServiceModDtTm = myServiceLastSynchTime;
            this.ProgramSetupId = washerProgramSetupId;
            this.SensorAttached = sensorAttached;
            this.Trackasdosingstep = Trackasdosingstep;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherFormulaWashStep"/> class.
        /// </summary>
        /// <param name="stepNumber">The step number.</param>
        /// <param name="myServiceStepTypeId">My service step type identifier.</param>
        /// <param name="runtime">The run time.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="temUomCode">The tem uom code.</param>
        /// <param name="myServiceWaterType">Type of my service water.</param>
        /// <param name="waterLevel">The water level.</param>
        /// <param name="waterLevUomCode">The water lev uom code.</param>
        /// <param name="myServiceDrainDestinationId">My service drain destination identifier.</param>
        /// <param name="note">The note.</param>
        /// <param name="isdelete">if set to <c>true</c> [isdelete].</param>
        /// <param name="myServiceCustFrmulaStpGUID">My service customer frmula STP unique identifier.</param>
        /// <param name="myServiceModDtTm">My service mod dt tm.</param>
        public WasherFormulaWashStep(Int16 stepNumber, Int16 myServiceStepTypeId, int runtime, int temperature, string temUomCode, int myServiceWaterType, decimal waterLevel, string waterLevUomCode, Int16 myServiceDrainDestinationId, string note, bool isdelete, Guid myServiceCustFrmulaStpGUID, DateTime myServiceModDtTm)
        {
            this.StepNumber = stepNumber;
            this.MyServiceWshOpId = myServiceStepTypeId;
            this.Runtime = runtime;
            this.Temperature = temperature;
            this.MyServiceUtilId = myServiceWaterType;
            this.WaterLevel = waterLevel;
            this.MyServiceDrainTypId = myServiceDrainDestinationId;
            this.Note = note;
            this.IsDelete = isdelete;
            this.MyServiceCusrFrmulaStpGuid = myServiceCustFrmulaStpGUID;
            this.MyServiceModDtTm = myServiceModDtTm;
            this.TemUomCode = temUomCode;
            this.WaterLevUomCode = waterLevUomCode;
        }

        /// <summary>
        ///     Gets or sets the ProgramNumber
        /// </summary>
        /// <value> Parameter Program Number</value>
        public int ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramSetupId
        /// </summary>
        /// \
        /// <value> Parameter Program Setup Id</value>
        public int ProgramSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupId
        /// </summary>
        /// <value> Parameter Washer Group Id</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the StepNumber
        /// </summary>
        /// <value> Parameter Step Number</value>
        public int StepNumber { get; set; }

        /// <summary>
        ///     Gets or sets the WashOperationId
        /// </summary>
        /// <value> Parameter Wash Operation Id</value>
        public int WashOperationId { get; set; }

        /// <summary>
        ///     Gets or sets the WashOperation
        /// </summary>
        /// <value> Parameter Wash Operation</value>
        public string WashOperation { get; set; }

        /// <summary>
        ///     Gets or sets the RunTime
        /// </summary>
        /// <value> Parameter RunTime</value>
        public int Runtime { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature
        /// </summary>
        /// <value> Parameter Temperature</value>
        public int Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the WaterType
        /// </summary>
        /// <value> Parameter Water Type</value>
        public string WaterType { get; set; }

        /// <summary>
        ///     Gets or sets the WaterLevel
        /// </summary>
        /// <value> Parameter Water Level</value>
        public decimal WaterLevel { get; set; }

        /// <summary>
        ///     Gets or sets the DrainDestinationId
        /// </summary>
        /// <value> Parameter Drain Destination Id</value>
        public short? DrainDestinationId { get; set; }

        /// <summary>
        ///     Gets or sets the DrainDestination
        /// </summary>
        /// <value> Parameter Drain Destination</value>
        public string DrainDestination { get; set; }

        /// <summary>
        ///     Gets or sets the pHLevel
        /// </summary>
        /// <value> Parameter pHLevel</value>
        public short PhLevel { get; set; }

        /// <summary>
        ///     Gets and sets the RegionId
        /// </summary>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the Note
        /// </summary>
        /// <value> Parameter Note</value>
        public string Note { get; set; }

        /// <summary>
        ///     Gets or sets WasherDosingProductModel
        /// </summary>
        /// <value> Parameter Washer Dosing Product Modelk</value>
        public List<WasherDosingProduct> WasherDosingProducts { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceWshOpId
        /// </summary>
        /// <value>MyServiceWshOpId</value>
        public int MyServiceWshOpId { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceUtilId
        /// </summary>
        /// <value> MyServiceUtilId</value>
        public int MyServiceUtilId { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceDrainTypId
        /// </summary>
        /// <value> MyServiceDrainTypId</value>
        public int MyServiceDrainTypId { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCusrFrmulaStpGuid
        /// </summary>
        /// <value> MyServiceCusrFrmulaStpGuid</value>
        public Guid MyServiceCusrFrmulaStpGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceModDtTm
        /// </summary>
        /// <value> MyServiceModDtTm</value>
        public DateTime MyServiceModDtTm { get; set; }

        /// <summary>
        /// Gets or sets MyServiceModDtTm
        /// </summary>
        /// <value> MyServiceModDtTm</value>
        public int CurrentWashStep { get; set; }
        /// <summary>
        /// Quantity
        /// </summary>
        public decimal Quantity { get; set; }
        /// <summary>
        /// Delay
        /// </summary>
        public int Delay { get; set; }
        /// <summary>
        /// ResourceDetailId
        /// </summary>
        public int ResourceDetailId { get; set; }
        /// <summary>
        /// MENumber
        /// </summary>
        public int MENumber { get; set; }
        /// <summary>
        /// StandardWeight
        /// </summary>
        public int StandardWeight { get; set; }
        /// <summary>
        /// StandardWaterUsage
        /// </summary>
        public int StandardWaterUsage { get; set; }

        /// <summary>
        /// Gets or sets the tem uom code.
        /// </summary>
        /// <value>The tem uom code.</value>
        public string TemUomCode { get; set; }
        /// <summary>
        /// Gets or sets the water lev uom code.
        /// </summary>
        /// <value>The water lev uom code.</value>
        public string WaterLevUomCode { get; set; }

        /// <summary>
        /// Gets or sets theSensorAttached.
        /// </summary>
        /// <value>The SensorAttached.</value>
        public string SensorAttached { get; set; }

        /// <summary>
        /// Gets or sets Trackasdosingstep.
        /// </summary>
        /// <value>The Trackasdosingstep.</value>
        public bool Trackasdosingstep { get; set; }
    }
}