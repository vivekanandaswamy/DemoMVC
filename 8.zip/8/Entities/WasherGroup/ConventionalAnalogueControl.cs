﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalAnalogueControl.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionalAnalogueControl </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.WasherGroup
{
    /// <summary>
    /// Class for Conventional Analogue Control
    /// </summary>
    /// <seealso cref="Entities.BaseEntity" />
    public class ConventionalAnalogueControl : BaseEntity
    {
        /// <summary>
        /// Initializes the Tunnel Analogue Control
        /// </summary>
        /// <param name="washerDosingAnalogControllerMappingId">The washer dosing analog controller mapping identifier.</param>
        /// <param name="washerDosingSetupId">The washer dosing setup identifier.</param>
        /// <param name="tempSetPoint">The Temp Set Point</param>
        /// <param name="minTime">The Min Time of ConventionalAnalogueControl</param>
        /// <param name="startDelay">The Start Delay of ConventionalAnalogueControl</param>
        /// <param name="acceptedDelay">The Accepted Delay</param>
        /// <param name="productCheck">The Product Check</param>
        /// <param name="phControlDuringDrain">if set to <c>true</c> [ph control during drain].</param>
        /// <param name="phDelayTime">The ph delay time of ConventionalAnalogueControl.</param>
        /// <param name="phMeasuringTime">The ph measuring time.</param>
        /// <param name="phMininum">The ph mininum of ConventionalAnalogueControl.</param>
        /// <param name="phMaximum">The ph maximum of ConventionalAnalogueControl.</param>
        /// <param name="stepNumber">The step number of ConventionalAnalogueControl.</param>
        public ConventionalAnalogueControl(int washerDosingAnalogControllerMappingId,int washerDosingSetupId, decimal tempSetPoint, int minTime, int startDelay, int acceptedDelay, int productCheck, bool phControlDuringDrain,
            int? phDelayTime, int? phMeasuringTime, decimal phMininum, decimal phMaximum, int stepNumber)
        {
            this.WasherDosingAnalogControllerMappingId = washerDosingAnalogControllerMappingId;
            this.WasherDosingSetupId = washerDosingSetupId;
            this.TempSetPoint = tempSetPoint;
            this.MinTime = minTime;
            this.StartDelay = startDelay;
            this.AcceptedDelay = acceptedDelay;
            this.ProductCheck = productCheck;
            this.PhControlDuringDrain = phControlDuringDrain;
            this.PhDelayTime = phDelayTime;
            this.PhMeasuringTime = phMeasuringTime;
            this.PhMininum = phMininum;
            this.PhMaximum = phMaximum;
            this.StepNumber = stepNumber;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConventionalAnalogueControl" /> class.
        /// </summary>
        public ConventionalAnalogueControl()
        {
            
        }

        /// <summary>
        /// Gets or Sets the Washer Dosing Analog Controller Mapping Id
        /// </summary>
        /// <value>
        /// The Washer Dosing Analog Controller Mapping Id
        /// </value>
        public int WasherDosingAnalogControllerMappingId { get; set; }

        /// <summary>
        /// Gets or Sets the Washer Dosing Setup Id
        /// </summary>
        /// <value>
        /// The Washer Dosing Setup Id
        /// </value>
        public int WasherDosingSetupId { get; set; }
        /// <summary>
        /// Gets or Sets the Temperature Set Point
        /// </summary>
        /// <value>
        /// The Temperature Set Point
        /// </value>
        public decimal TempSetPoint { get; set; }
        /// <summary>
        /// Gets or Sets the Minnimum Time
        /// </summary>
        /// <value>
        /// The Minimum Time
        /// </value>
        public int MinTime { get; set; }
        /// <summary>
        /// Gets or Sets the Start Delay
        /// </summary>
        /// <value>
        /// The Start Delay
        /// </value>
        public int StartDelay { get; set; }
        /// <summary>
        /// Gets or Sets the Accepted Delay
        /// </summary>
        /// <value>
        /// The Accepted Delay
        /// </value>
        public int AcceptedDelay { get; set; }
        /// <summary>
        /// Gets or Sets the Product Check
        /// </summary>
        /// <value>
        /// The Product Check
        /// </value>
        public int ProductCheck { get; set; }

        /// <summary>
        /// Gets or Sets the PhControl During Drain
        /// </summary>
        /// <value>
        /// The Product Check
        /// </value>
        public bool? PhControlDuringDrain { get; set; }

        /// <summary>
        /// Gets or Sets the PhDelay Time
        /// </summary>
        /// <value>
        /// The PhDelay Time
        /// </value>
        public int? PhDelayTime { get; set; }

        /// <summary>
        /// Gets or Sets the PhMeasuring Time
        /// </summary>
        /// <value>
        /// The PhMeasuring Time
        /// </value>
        public int? PhMeasuringTime { get; set; }

        /// <summary>
        /// Gets or Sets the PhMininum
        /// </summary>
        /// <value>
        /// The Product Check
        /// </value>
        public decimal PhMininum { get; set; }

        /// <summary>
        /// Gets or Sets the PhMaximum
        /// </summary>
        /// <value>
        /// The PhMaximum
        /// </value>
        public decimal PhMaximum { get; set; }
        /// <summary>
        /// Gets or Sets the Conventional Washer Id
        /// </summary>
        /// <value>
        /// The Conventional Washer Id
        /// </value>
        public int StepNumber { get; set; }
    }
}