﻿// -----------------------------------------------------------------------
// <copyright file="WasherDosingProduct.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherDosingProduct is for get and set the data.</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.WasherGroup
{
    /// <summary>
    ///     WasherDosingProduct class
    /// </summary>
    public class WasherDosingProduct : BaseEntity
    {
        /// <summary>
        ///     Deafault Constructor for WasherDosingProduct
        /// </summary>
        public WasherDosingProduct()
        {
        }

        /// <summary>
        /// Constructor for WasherDosingProduct
        /// </summary>
        /// <param name="washerDosingProductMappingId">The washer dosing product mapping identifier.</param>
        /// <param name="washerDosingSetupId">Parameter WasherDosingSetup</param>
        /// <param name="injectionNumber">Parameter InjectionNumber</param>
        /// <param name="productId">Parameter ProductId</param>
        /// <param name="productName">Parameter ProductName</param>
        /// <param name="quantity">Parameter Quantity</param>
        /// <param name="myServiceFrmulaStpDsgDvcGuid">My service frmula STP DSG DVC unique identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="priceInOunce">The price in ounce.</param>
		public WasherDosingProduct(int washerDosingProductMappingId, int washerDosingSetupId, short injectionNumber, int productId, string productName, decimal quantity, Guid myServiceFrmulaStpDsgDvcGuid, DateTime myServiceLastSynchTime, bool isDeleted, short priceInOunce)
        {
            this.Id = washerDosingProductMappingId;
            this.WasherDosingSetupId = washerDosingSetupId;
            this.InjectionNumber = injectionNumber;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
            this.MyServiceModDtTm = myServiceLastSynchTime;
	        this.IsDeleted = isDeleted;
			this.PriceInOunce = priceInOunce;
        }

        public WasherDosingProduct(int washerDosingProductMappingId, int washerDosingSetupId, short injectionNumber, int productId, string productName, decimal quantity, short delay, Guid myServiceFrmulaStpDsgDvcGuid, DateTime myServiceLastSynchTime, bool isDeleted, double priceInOunce)
        {
            this.Id = washerDosingProductMappingId;
            this.WasherDosingSetupId = washerDosingSetupId;
            this.InjectionNumber = injectionNumber;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
            this.MyServiceModDtTm = myServiceLastSynchTime;
            this.IsDeleted = isDeleted;
            this.PriceInOunce = priceInOunce;
            this.Delay = delay;
        }

        /// <summary>
        /// Constructor for WasherDosingProduct
        /// </summary>
        /// <param name="washerDosingProductMappingId">The washer dosing product mapping identifier.</param>
        /// <param name="washerDosingSetupId">Parameter WasherDosingSetup</param>
        /// <param name="injectionNumber">Parameter InjectionNumber</param>
        /// <param name="productId">Parameter ProductId</param>
        /// <param name="productName">Parameter ProductName</param>
        /// <param name="quantity">Parameter Quantity</param>
        /// <param name="myServiceFrmulaStpDsgDvcGuid">My service frmula STP DSG DVC unique identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="delay">The delay.</param>
		public WasherDosingProduct(int washerDosingProductMappingId, int washerDosingSetupId, short injectionNumber, int productId, string productName, decimal quantity, Guid myServiceFrmulaStpDsgDvcGuid, DateTime myServiceLastSynchTime, bool isDeleted, short delay, short? controllerEquipmentSetupId, byte? controllerEquipmentId)
        {
            this.Id = washerDosingProductMappingId;
            this.WasherDosingSetupId = washerDosingSetupId;
            this.InjectionNumber = injectionNumber;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
            this.MyServiceModDtTm = myServiceLastSynchTime;
            this.IsDeleted = isDeleted;
            this.Delay = delay;
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ControllerEquipmentId = controllerEquipmentId;
        }

        public WasherDosingProduct(int washerDosingProductMappingId, int washerDosingSetupId, short injectionNumber, int productId, string productName, decimal quantity,short delay, Guid myServiceFrmulaStpDsgDvcGuid, DateTime myServiceLastSynchTime, bool isDeleted, double price, short? controllerEquipmentSetupId, byte? controllerEquipmentId)
        {
            this.Id = washerDosingProductMappingId;
            this.WasherDosingSetupId = washerDosingSetupId;
            this.InjectionNumber = injectionNumber;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.Delay = delay;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
            this.MyServiceModDtTm = myServiceLastSynchTime;
            this.IsDeleted = isDeleted;
            
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ControllerEquipmentId = controllerEquipmentId;
        }

        public WasherDosingProduct(int washerDosingProductMappingId, int washerDosingSetupId, short injectionNumber, int productId, string productName, decimal quantity, Guid myServiceFrmulaStpDsgDvcGuid, DateTime myServiceLastSynchTime, bool isDeleted, double delay, short? controllerEquipmentSetupId, byte? controllerEquipmentId)
        {
            this.Id = washerDosingProductMappingId;
            this.WasherDosingSetupId = washerDosingSetupId;
            this.InjectionNumber = injectionNumber;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
            this.MyServiceModDtTm = myServiceLastSynchTime;
            this.IsDeleted = isDeleted;
            this.Delay = Convert.ToInt16(delay);
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ControllerEquipmentId = controllerEquipmentId;
        }

        /// <summary>
        /// Constructor for WasherDosingProduct
        /// </summary>
        /// <param name="myServiceProductId">My service product identifier.</param>
        /// <param name="dosingWeight">The dosing weight.</param>
        /// <param name="dosingWeightUOMCode">The dosing weight uom code.</param>
        /// <param name="dosingVolume">The dosing volume.</param>
        /// <param name="dosingVolumeUOMCode">The dosing volume uom code.</param>
        /// <param name="myServiceFrmulaStpDsgDvcGUID">My service frmula STP DSG DVC unique identifier.</param>
        /// <param name="myServiceModDtTm">My service mod dt tm.</param>
        public WasherDosingProduct(int myServiceProductId, decimal dosingWeight, string dosingWeightUOMCode, decimal dosingVolume, string dosingVolumeUOMCode, Guid myServiceFrmulaStpDsgDvcGUID, DateTime myServiceModDtTm)
        {
            this.MyServiceProductId = myServiceProductId;
            this.Quantity = dosingVolume;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGUID;
            this.MyServiceModDtTm = myServiceModDtTm;
            this.UOMCode = dosingVolumeUOMCode;
            this.DosingWeight = dosingWeight;
            this.DosingWeightUOMCode = dosingWeightUOMCode;
        }

        /// <summary>
        ///     Gets or sets WasherDosingSetupId
        /// </summary>
        /// <value> Parameter Washer Dosing Setup Id</value>
        public int WasherDosingSetupId { get; set; }

        /// <summary>
        ///     Gets or sets InjectionNumber
        /// </summary>
        /// <value> Parameter Injection Number</value>
        public short InjectionNumber { get; set; }

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> Parameter Product Id</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> Parameter Product Id</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets Quantity
        /// </summary>
        /// <value> Parameter Quantity</value>
        public decimal Quantity { get; set; }

        /// <summary>
        ///     Gets or sets DeleteFlag
        /// </summary>
        /// <value> Parameter Delete Flag</value>
        public bool DeleteFlag { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceFrmulaStpDsgDvcGUID
        /// </summary>
        /// <value> Parameter MyServiceFrmulaStpDsgDvcGUID</value>
        public Guid MyServiceFrmulaStpDsgDvcGUID { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceModDtTm
        /// </summary>
        /// <value> Parameter MyServiceModDtTm</value>
        public DateTime MyServiceModDtTm { get; set; }

        /// <summary>
        ///     Gets or sets DosingVolumeUOMCode
        /// </summary>
        /// <value> Parameter DosingVolumeUOMCode</value>
        public string UOMCode { get; set; }

        /// <summary>
        ///     Gets or sets myServiceProductId
        /// </summary>
        /// <value> Parameter myServiceProductId</value>
        public int MyServiceProductId { get; set; }

		/// <summary>
		/// Gets or sets Price
		/// </summary>
		public double PriceInOunce { get; set; }

        /// <summary>
        ///     Gets or sets Delay
        /// </summary>
        /// <value> Parameter Delay</value>
        public short Delay { get; set; }
        /// <summary>
        /// Gets or sets the dosing weight.
        /// </summary>
        /// <value>The dosing weight.</value>
        public decimal DosingWeight { get; set; }

        /// <summary>
        /// Gets or sets the dosing weight uom code.
        /// </summary>
        /// <value>The dosing weight uom code.</value>
        public string DosingWeightUOMCode { get; set; }

        /// <summary>
        /// Gets or sets the last modified time.
        /// </summary>
        /// <value>The last modified time.</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        /// Gets or sets the ControllerEquipmentSetupId
        /// </summary>
        /// <value>The ControllerEquipmentSetupId</value>
        public short? ControllerEquipmentSetupId { get; set; }
        /// <summary>
        /// Gets or sets the ControllerEquipmentSetupId
        /// </summary>
        /// <value>The ControllerEquipmentSetupId</value>
        public byte? ControllerEquipmentId { get; set; }
    }
}