﻿// -----------------------------------------------------------------------
// <copyright file="InjectionData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The InjectionData </summary>
// -----------------------------------------------------------------------

namespace Entities.WasherGroup
{
    public class InjectionData : BaseEntity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionData" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="washerId">The washer identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="injectionClass">The injection class.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="referenceLoad">The reference load.</param>
        /// <param name="capacity">The capacity.</param>
        /// <param name="ecolabAccntNumber">The ecolab accnt number.</param>
        /// <param name="injectionClassTag">The injection class tag.</param>
        /// <param name="injectionRatioTag">The injection ratio tag.</param>
        public InjectionData(int id, int washerId, string washerGroupNumber, string injectionClass, int controllerId,
            int referenceLoad, short capacity, string ecolabAccntNumber, string injectionClassTag, string injectionRatioTag )
        {
            Id = id;
            WasherId = washerId;
            WasherGroupNumber = washerGroupNumber;
            InjectionClass = injectionClass;
            ControllerId = controllerId;
            ReferenceLoad = referenceLoad;
            Capacity = capacity;
            InjectionClassTag = injectionClassTag;
            InjectionRatioTag = injectionRatioTag;
            EcolabAccountNumber = ecolabAccntNumber;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionData" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="washerId">The washer identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="injectionClass">The injection class.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="referenceLoad">The reference load.</param>
        /// <param name="capacity">The capacity.</param>
        /// <param name="ecolabAccntNumber">The ecolab accnt number.</param>
        /// <param name="injectionClassTag">The injection class tag.</param>
        /// <param name="injectionRatioTag">The injection ratio tag.</param>
        /// <param name="isdeleted">if set to <c>true</c> [isdeleted].</param>
        public InjectionData(int id, int washerId, string washerGroupNumber, string injectionClass, int controllerId,
            int referenceLoad, short capacity, string ecolabAccntNumber, string injectionClassTag, string injectionRatioTag, bool isdeleted)
        {
            Id = id;
            WasherId = washerId;
            WasherGroupNumber = washerGroupNumber;
            InjectionClass = injectionClass;
            ControllerId = controllerId;
            ReferenceLoad = referenceLoad;
            Capacity = capacity;
            InjectionClassTag = injectionClassTag;
            InjectionRatioTag = injectionRatioTag;
            EcolabAccountNumber = ecolabAccntNumber;
            IsDeleted = isdeleted;
        }

        public InjectionData()
        {
                
        }
        /// <summary>
        /// Gets or sets the washer identifier.
        /// </summary>
        /// <value>
        /// The washer identifier.
        /// </value>
        public int WasherId { get; set; }

        /// <summary>
        /// Gets or sets the washer group number.
        /// </summary>
        /// <value>
        /// The washer group number.
        /// </value>
        public string WasherGroupNumber { get; set; }

        /// <summary>
        /// Gets or sets the injection class.
        /// </summary>
        /// <value>
        /// The injection class.
        /// </value>
        public string InjectionClass { get; set; }

        /// <summary>
        /// Gets or sets the controller identifier.
        /// </summary>
        /// <value>
        /// The controller identifier.
        /// </value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the reference load.
        /// </summary>
        /// <value>
        /// The reference load.
        /// </value>
        public int ReferenceLoad { get; set; }

        /// <summary>
        /// Gets or sets the injection class tag.
        /// </summary>
        /// <value>
        /// The injection class tag.
        /// </value>
        public string InjectionClassTag { get; set; }

        /// <summary>
        /// Gets or sets the injection ratio tag.
        /// </summary>
        /// <value>
        /// The injection ratio tag.
        /// </value>
        public string InjectionRatioTag { get; set; }

        /// <summary>
        /// Gets or sets the capacity.
        /// </summary>
        /// <value>
        /// The capacity.
        /// </value>
        public short Capacity { get; set; }
    }
}