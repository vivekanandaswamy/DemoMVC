﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroup.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The washer group is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Entities.WasherGroup
{
	using System;

    /// <summary>
    /// Washer group class consists of all entities washer group.
    /// </summary>
    /// <seealso cref="Entities.BaseEntity" />
    public class WasherGroup : BaseEntity
	{
        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroup" /> class.
        /// </summary>
        public WasherGroup()
		{
		}
        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroup" /> class.
        /// </summary>
        /// <param name="washerGroupId">Gets the Washer Group Id</param>
        /// <param name="washerGroupNumber">Gets the group number of the washer group.</param>
        /// <param name="washerGroupName">Gets the group name of the washer group.</param>
        /// <param name="washerGroupTypeId">Gets the group type of the washer group.</param>
        /// <param name="washerGroupTypeName">Gets the washer Group Type name</param>
        /// <param name="rowTotalCount">Gets the total row Count</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceWasherGroupGuid">My service washer group unique identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <param name="washerDosingNumber">The washer dosing number.</param>
        /// <param name="washerCount">The washer count.</param>
        public WasherGroup(
                            int washerGroupId,
                            string washerGroupNumber,
                            string washerGroupName,
                            byte washerGroupTypeId,
                            string washerGroupTypeName,
                            int rowTotalCount,
                            DateTime lastModifiedTime,
                            DateTime lastSyncTime,
                            string ecolabAccountNumber,
                            bool isDeleted,
                            Guid myServiceWasherGroupGuid,
                            int controllerId,
                            int controllerModelId,
                            int controllerTypeId,
                            int washerDosingNumber,
                            int washerCount
                            )
            : base(ecolabAccountNumber)
        {
            WasherGroupId = washerGroupId;
            WasherGroupNumber = washerGroupNumber;
            WasherGroupName = washerGroupName;
            WasherGroupTypeId = washerGroupTypeId;
            WasherGroupTypeName = washerGroupTypeName;
            RowTotalCount = rowTotalCount;
            LastModifiedTimestamp = lastModifiedTime;
            LastSyncTime = lastSyncTime;
            IsDelete = isDeleted;
            MyServiceWasherGroupGuid = myServiceWasherGroupGuid;
            ControllerId = controllerId;
            ControllerModelId = controllerModelId;
            ControllerTypeId = controllerTypeId;
            WasherDosingNumber = washerDosingNumber;
            WasherCount = washerCount;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroup" /> class.
        /// </summary>
        /// <param name="washerGroupId">Gets the Washer Group Id</param>
        /// <param name="washerGroupNumber">Gets the group number of the washer group.</param>
        /// <param name="washerGroupName">Gets the group name of the washer group.</param>
        /// <param name="washerGroupTypeId">Gets the group type of the washer group.</param>
        /// <param name="washerGroupTypeName">Gets the washer Group Type name</param>
        /// <param name="rowTotalCount">Gets the total row Count</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceWasherGroupGuid">My service washer group unique identifier.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <param name="controllerTypeId">The controller type identifier.</param>
        /// <param name="washerDosingNumber">The washer dosing number.</param>
        /// <param name="useGroup1Formulas">if set to <c>true</c> [use group1 formulas].</param>
        /// <param name="washerCount">The washer count.</param>
        public WasherGroup(
							int washerGroupId,
							string washerGroupNumber,
							string washerGroupName,
							byte washerGroupTypeId,
							string washerGroupTypeName,
							int rowTotalCount,
							DateTime lastModifiedTime,
							DateTime lastSyncTime,
							string ecolabAccountNumber,
							bool isDeleted,
							Guid myServiceWasherGroupGuid,
							int controllerId,
							int controllerModelId,
							int controllerTypeId,
							int washerDosingNumber,
                            bool useGroup1Formulas,
							int washerCount
							)
			: base(ecolabAccountNumber)
		{
			WasherGroupId = washerGroupId;
			WasherGroupNumber = washerGroupNumber;
			WasherGroupName = washerGroupName;
			WasherGroupTypeId = washerGroupTypeId;
			WasherGroupTypeName = washerGroupTypeName;
			RowTotalCount = rowTotalCount;
			LastModifiedTimestamp = lastModifiedTime;
			LastSyncTime = lastSyncTime;
			IsDelete = isDeleted;
			MyServiceWasherGroupGuid = myServiceWasherGroupGuid;
			ControllerId = controllerId;
			ControllerModelId = controllerModelId;
			ControllerTypeId = controllerTypeId;
			WasherDosingNumber = washerDosingNumber;
            UseGroup1Formulas = useGroup1Formulas;
			WasherCount = washerCount;
		}

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroup" /> for MyService.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="washerGroupDescription">The washer group description.</param>
        /// <param name="isDeleted">Gets the isDeleted.</param>
        /// <param name="washerGroupTypeId">Gets the washerGroupTypeId.</param>
        /// <param name="washerGroupName">Gets the washerGroupName</param>
        /// <param name="myServiceWasherGroupNumber">Gets myServiceWasherGroupNumber.</param>
        /// <param name="myServiceWasherGroupGuid">Gets the myServiceWasherGroupGuid</param>
        /// <param name="myServiceLastModifiedTime">Gets the myServiceLastModifiedTime</param>
        public WasherGroup(string ecolabAccountNumber, string washerGroupDescription, bool isDeleted, byte washerGroupTypeId, string washerGroupName, Int16 myServiceWasherGroupNumber, Guid myServiceWasherGroupGuid, DateTime myServiceLastModifiedTime)
		{
			EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
			WasherGroupDescription = washerGroupDescription;
			WasherGroupName = washerGroupName;
			MyServiceWasherGroupNumber = myServiceWasherGroupNumber;
			WasherGroupTypeId = washerGroupTypeId;
			IsDeleted = isDeleted;
			MyServiceWasherGroupGuid = myServiceWasherGroupGuid;
			MyServiceLastModifiedTime = myServiceLastModifiedTime;
		}

		/// <summary>
		///     Gets or sets the row number value for the washer groups.
		/// </summary>
		/// <value>Gets Row Number value.</value>
		public int RowNumber { get; set; }

		/// <summary>
		///     Gets or sets the Washer GroupId value for the washer groups.
		/// </summary>
		/// <value>Gets Washer GroupId value.</value>
		public int WasherGroupId { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Number value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Number value.</value>
		public string WasherGroupNumber { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Type Id value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Type Id value.</value>
		public byte WasherGroupTypeId { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Type Name value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Type Name value.  </value>
		public string WasherGroupTypeName { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Description value for the washer groups.
		/// </summary>
		/// <value> Washer Group Description value.</value>
		public string WasherGroupDescription { get; set; }
		/// <summary>
		///     Gets or sets the Washer Group Name value for the washer groups.
		/// </summary>
		/// <value> Washer Group Name value.</value>
		public string WasherGroupName { get; set; }

		/// <summary>
		///     Gets or sets the Row Total Count value for the washer groups.
		/// </summary>
		/// <value> Row Total Count value.</value>
		public int RowTotalCount { get; set; }

		/// <summary>
		///     Gets or sets the LastSyncTime
		/// </summary>
		/// <value>LastSyncTime</value>
		public DateTime LastSyncTime { get; set; }

		/// <summary>
		///     Gets or sets Max Number Of Records
		/// </summary>
		/// <value> Max Number Of Records </value>
		public int MaxNumberOfRecords { get; set; }

		/// <summary>
		///     Gets or sets the Last Modified Time Stamp
		/// </summary>
		/// <value>LastModifiedTimeStamp</value>
		public DateTime LastModifiedTimestamp { get; set; }

		/// <summary>
		///     Gets or sets the Is Delete
		/// </summary>
		/// <value>IsDelete</value>
		public bool IsDelete { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Number value from MyService.
		/// </summary>
		/// <value>Gets Washer Group Number value from MyService.</value>
		public Int16 MyServiceWasherGroupNumber { get; set; }

		/// <summary>
		/// Gets or sets MyServiceWasherGroupGuid
		/// </summary>
		public Guid MyServiceWasherGroupGuid { get; set; }

		/// <summary>
		///     Gets or sets the My Service Last Modified Time
		/// </summary>
		/// <value>MyServiceLastModifiedTime</value>
		public DateTime MyServiceLastModifiedTime { get; set; }

		/// <summary>
		/// Gets or sets ControllerId
		/// </summary>
		public int ControllerId { get; set; }

		/// <summary>
		/// Gets or sets ControllerModelId
		/// </summary>
		public int ControllerModelId { get; set; }

		/// <summary>
		/// Gets or sets ControllerTypeId
		/// </summary>
		public int ControllerTypeId { get; set; }

		/// <summary>
		/// Gets or sets WasherDosingNumber
		/// </summary>
		public int WasherDosingNumber { get; set; }

		/// <summary>
		/// Gets or sets WasherCounts
		/// </summary>
		public int WasherCount { get; set; }

        /// <summary>
        /// get or set UseFormulaFromGroupOne
        /// </summary>
        public bool UseGroup1Formulas { get; set; }
	}
}