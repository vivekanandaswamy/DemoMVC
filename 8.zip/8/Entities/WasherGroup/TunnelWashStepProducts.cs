﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWashStepProducts.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelWashStepProducts </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.WasherGroup
{
    /// <summary>
    ///     TunnelWashStepProductsModel class.
    /// </summary>
    public class TunnelWashStepProducts : BaseEntity
    {
        /// <summary>
        ///     Tunnel WashStep Products Constructor
        /// </summary>
        public TunnelWashStepProducts()
        {
        }

        /// <summary>
        /// Parameterized Constructor
        /// </summary>
        /// <param name="tunnelDosingProductMappingId">The TunneldosingProductMappingId</param>
        /// <param name="ecolabAccountNumber">The EcolabAccountNumber</param>
        /// <param name="controllerEquipmentSetupId">The Controller Equipment Setup Id</param>
        /// <param name="productId">The Product Id</param>
        /// <param name="productName">The Product Name</param>
        /// <param name="quantity">The Quantity</param>
        /// <param name="delayTime">The DelayTime</param>
        /// <param name="compartmentNumber">The Compartment Number</param>
        /// <param name="groupId">The GroupId</param>
        /// <param name="lastModifiedTime">Last Modified time</param>
        /// <param name="myServiceFrmulaStpDsgDvcGuid">myservice frmula stp dosing device guid</param>
        /// <param name="priceInOunce">The price in ounce.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        public TunnelWashStepProducts(int tunnelDosingProductMappingId, string ecolabAccountNumber, short controllerEquipmentSetupId, int productId, string productName, decimal quantity, int delayTime, int compartmentNumber, int groupId, DateTime? lastModifiedTime, Guid? myServiceFrmulaStpDsgDvcGuid, double priceInOunce, DateTime myServiceLastSynchTime)
        {
            this.TunnelDosingProductMappingId = tunnelDosingProductMappingId;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.DelayTime = delayTime;
            this.CompartmentNumber = compartmentNumber;
            this.GroupId = groupId;
            this.LastModifiedTime = lastModifiedTime;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
			this.PriceInOunce = priceInOunce;
            this.MyServiceModDtTm = myServiceLastSynchTime;
        }

        /// <summary>
        /// Parameterized Constructor
        /// </summary>
        /// <param name="tunnelDosingSetupId">The Tunnel Dosing Setup Id</param>
        /// <param name="compartmentNumber">The Compartment Number</param>
        /// <param name="groupId">The Group Id</param>
        /// <param name="totalInjections">The Total Injections</param>
        public TunnelWashStepProducts(int tunnelDosingSetupId, int compartmentNumber, int groupId, int totalInjections)
        {
            this.TunnelDosingSetupId = tunnelDosingSetupId;
            this.CompartmentNumber = compartmentNumber;
            this.GroupId = groupId;
            this.TotalInjections = totalInjections;
        }

        /// <summary>
        /// Parameterized Constructor
        /// </summary>
        /// <param name="compartmentNumber">The Compartment Number</param>
        /// <param name="dosingWeight">The dosing weight.</param>
        /// <param name="dosingWeightUOMCode">The dosing weight uom code.</param>
        /// <param name="dosingVolume">The dosing volume.</param>
        /// <param name="dosingVolumeUOMCode">The dosing volume uom code.</param>
        /// <param name="myServiceFrmulaStpDsgDvcGUID">My service frmula STP DSG DVC unique identifier.</param>
        /// <param name="myServiceModDtTm">My service mod dt tm.</param>
        /// <param name="myServiceCmpmtDsgDvcguid">My service CMPMT DSG dvcguid.</param>
        public TunnelWashStepProducts(byte compartmentNumber, decimal dosingWeight, string dosingWeightUOMCode, decimal dosingVolume, string dosingVolumeUOMCode, Guid myServiceFrmulaStpDsgDvcGUID, DateTime myServiceModDtTm, Guid myServiceCmpmtDsgDvcguid)
        {
            this.CompartmentNumber = compartmentNumber;
            this.Quantity = dosingVolume;
            this.UOMCode = dosingVolumeUOMCode;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGUID;
            this.MyServiceModDtTm = myServiceModDtTm;
            this.MyServiceCmpmtDsgDvcguid = myServiceCmpmtDsgDvcguid;
            this.DosingWeight = dosingWeight;
            this.DosingWeightUOMCode = dosingWeightUOMCode;
        }

        /// <summary>
        /// Parameterized Constructor
        /// </summary>
        /// <param name="tunnelDosingProductMappingId">The TunneldosingProductMappingId</param>
        /// <param name="ecolabAccountNumber">The EcolabAccountNumber</param>
        /// <param name="controllerEquipmentSetupId">The Controller Equipment Setup Id</param>
        /// <param name="productId">The Product Id</param>
        /// <param name="productName">The Product Name</param>
        /// <param name="quantity">The Quantity</param>
        /// <param name="delayTime">The DelayTime</param>
        /// <param name="compartmentNumber">The Compartment Number</param>
        /// <param name="groupId">The GroupId</param>
        /// <param name="lastModifiedTime">Last Modified time</param>
        /// <param name="myServiceFrmulaStpDsgDvcGuid">myservice frmula stp dosing device guid</param>
        /// <param name="priceInOunce">The price in ounce.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        public TunnelWashStepProducts(int tunnelDosingProductMappingId, string ecolabAccountNumber, short controllerEquipmentSetupId, int productId, string productName, decimal quantity, int delayTime, int compartmentNumber, int groupId, DateTime? lastModifiedTime, Guid? myServiceFrmulaStpDsgDvcGuid, double priceInOunce, DateTime myServiceLastSynchTime, int controllerEquipmentType, byte? controllerEquipmentId)
        {
            this.TunnelDosingProductMappingId = tunnelDosingProductMappingId;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.DelayTime = delayTime;
            this.CompartmentNumber = compartmentNumber;
            this.GroupId = groupId;
            this.LastModifiedTime = lastModifiedTime;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
            this.PriceInOunce = priceInOunce;
            this.MyServiceModDtTm = myServiceLastSynchTime;
            this.ControllerEquipmentType = controllerEquipmentType;
            this.ControllerEquipmentId = controllerEquipmentId;
        }

        public TunnelWashStepProducts(int tunnelDosingProductMappingId, string ecolabAccountNumber, int tunnelDosingSetupId,
            short controllerEquipmentSetupId, int productId, string productName,
            decimal quantity, int delayTime, int compartmentNumber, int groupId, 
            DateTime? lastModifiedTime, Guid? myServiceFrmulaStpDsgDvcGuid)
        {
            this.TunnelDosingProductMappingId = tunnelDosingProductMappingId;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.TunnelDosingSetupId = tunnelDosingSetupId;
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.DelayTime = delayTime;
            this.CompartmentNumber = compartmentNumber;
            this.GroupId = groupId;
            this.LastModifiedTime = lastModifiedTime;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
        }

        /// <summary>
        /// Initializes a new instance of the for Migration <see cref="TunnelWashStepProducts"/> class.
        /// </summary>
        /// <param name="tunnelDosingProductMappingId">The tunnel dosing product mapping identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="controllerEquipmentSetupId">The controller equipment setup identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="productName">Name of the product.</param>
        /// <param name="quantity">The quantity.</param>
        /// <param name="delayTime">The delay time.</param>
        /// <param name="compartmentNumber">The compartment number.</param>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="myServiceFrmulaStpDsgDvcGuid">My service frmula STP DSG DVC unique identifier.</param>
        /// <param name="priceInOunce">The price in ounce.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="controllerEquipmentType">Type of the controller equipment.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        public TunnelWashStepProducts(int tunnelDosingProductMappingId, string ecolabAccountNumber, short controllerEquipmentSetupId, int productId, string productName, decimal quantity, int delayTime, int compartmentNumber, int groupId, Guid? myServiceFrmulaStpDsgDvcGuid, double priceInOunce, DateTime myServiceLastSynchTime, int controllerEquipmentType, byte? controllerEquipmentId)
        {
            this.TunnelDosingProductMappingId = tunnelDosingProductMappingId;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ProductId = productId;
            this.ProductName = productName;
            this.Quantity = quantity;
            this.DelayTime = delayTime;
            this.CompartmentNumber = compartmentNumber;
            this.GroupId = groupId;
            this.MyServiceFrmulaStpDsgDvcGUID = myServiceFrmulaStpDsgDvcGuid;
            this.PriceInOunce = priceInOunce;
            this.MyServiceModDtTm = myServiceLastSynchTime;
            this.ControllerEquipmentType = controllerEquipmentType;
            this.ControllerEquipmentId = controllerEquipmentId;
        }

        /// <summary>
        ///     Gets or sets TunnelDosingProductMappingId
        /// </summary>
        /// <value>The Parameter Tunnel Dosing Product Mapping Id</value>
        public int TunnelDosingProductMappingId { get; set; }

        /// <summary>
        ///     Gets or sets ControllerEquipmentSetupId
        /// </summary>
        /// <value>The Parameter Controller Equipment Setup Id</value>
        public short ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets Tunnel Dosing Setup Id
        /// </summary>
        /// <value>The Parameter Tunnel Dosing Setup Id</value>
        public int TunnelDosingSetupId { get; set; }

        /// <summary>
        ///     Gets or sets InjectionNumber
        /// </summary>
        /// <value>The Parameter Injection Number</value>
        public short InjectionNumber { get; set; }

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value>The Parameter Product Id</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets ProductName
        /// </summary>
        /// <value>The Parameter Product Name</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets Quantity
        /// </summary>
        /// <value>The Parameter Quantity</value>
        public decimal Quantity { get; set; }

        /// <summary>
        ///     Gets or sets DelayTime
        /// </summary>
        /// <value>The Parameter Delay Time</value>
        public int DelayTime { get; set; }

        /// <summary>
        ///     Gets or sets CompartmentNumber
        /// </summary>
        /// <value>The Parameter Compartment Number</value>
        public int CompartmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets GroupId
        /// </summary>
        /// <value>The Parameter Group Id</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets TotalInjections
        /// </summary>
        /// <value>The Parameter Total Injections</value>
        public int TotalInjections { get; set; }

        /// <summary>
        ///     Gets or sets DeleteFlag
        /// </summary>
        /// <value>The Parameter Delete Flag</value>
        public bool DeleteFlag { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceFrmulaStpDsgDvcGUID
        /// </summary>
        /// <value> Parameter MyServiceFrmulaStpDsgDvcGUID</value>
        public Guid? MyServiceFrmulaStpDsgDvcGUID { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceModDtTm
        /// </summary>
        /// <value> Parameter MyServiceModDtTm</value>
        public DateTime MyServiceModDtTm { get; set; }

        /// <summary>
        ///     Gets or sets DosingVolumeUOMCode
        /// </summary>
        /// <value> Parameter DosingVolumeUOMCode</value>
        public string UOMCode { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceCmpmtDsgDvcguid
        /// </summary>
        /// <value> Parameter MyServiceCmpmtDsgDvcguid</value>
        public Guid? MyServiceCmpmtDsgDvcguid { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceCusrFrmulaStpGuid
        /// </summary>
        /// <value> Parameter MyServiceCusrFrmulaStpGuid</value>
        public Guid? MyServiceCusrFrmulaStpGuid { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedTime
        /// </summary>
        /// <value> Parameter LastModifiedTime</value>
        public DateTime? LastModifiedTime { get; set; }

		/// <summary>
		/// Gets or sets PriceInOunce
		/// </summary>
		public double PriceInOunce { get; set; }
        /// <summary>
        /// Gets or sets the dosing weight.
        /// </summary>
        /// <value>The dosing weight.</value>
        public decimal DosingWeight { get; set; }

        /// <summary>
        /// Gets or sets the dosing weight uom code.
        /// </summary>
        /// <value>The dosing weight uom code.</value>
        public string DosingWeightUOMCode { get; set; }
        /// <summary>
        /// Gets or Sets The Controller Equipment Type
        /// </summary>
        /// <value>The Controlller Equipment Type</value>
        public int ControllerEquipmentType { get; set; }
        /// <summary>
        /// Gets or sets the ControllerEquipmentSetupId
        /// </summary>
        /// <value>The ControllerEquipmentSetupId</value>
        public byte? ControllerEquipmentId { get; set; }
    }
}