﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupFormula.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WasherGroupFormula is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Entities.WasherGroup
{
    using System;

    /// <summary>
    ///     class WasherGroupFormula
    /// </summary>
    public class WasherGroupFormula : BaseEntity
    {
        /// <summary>
        ///     Default Constructor for WasherGroupFormula
        /// </summary>
        public WasherGroupFormula()
        {
        }

        /// <summary>
        /// Constructor for WasherGroupFormula
        /// </summary>
        /// <param name="washerGroupNumber">The washerGroupNumber</param>
        /// <param name="washerGroupName">The washerGroupName</param>
        /// <param name="washerGroupTypeName">The washerGroupTypeName</param>
        /// <param name="programSetupId">The programSetupId</param>
        /// <param name="programNumber">The programNumber</param>
        /// <param name="productId">The Product Id</param>
        /// <param name="productName">The productName</param>
        /// <param name="nominalLoad">The nominalLoad</param>
        /// <param name="totalRuntime">The totalRunTime</param>
        /// <param name="extraTime">The extraTime</param>
        /// <param name="loadsPerMonth">The loadsPerMonth</param>
        /// <param name="nextAvailableStepNo">The nextAvailableStepNo</param>
        /// <param name="lastModifiedTime">The Last modified time</param>
        /// <param name="lastSyncTime">the last sync time</param>
        /// <param name="ecolabAccountNumber">Ecolab Account number of the plant.</param>
        /// <param name="washerGroupId">The washer group identifier.</param>
        /// <param name="nextAvailableFormulaNo">Default and next vailable formula number.</param>
        /// <param name="myServiceCustFrmulaMchGrpGuid">My service customer frmula MCH GRP unique identifier.</param>
        /// <param name="isDelete">is delete</param>
        /// <param name="myServiceMstrLnnTypId">My service MSTR LNN typ identifier.</param>
        /// <param name="myServiceMchGrpGuid">My service MCH GRP unique identifier.</param>
        /// <param name="maxInjectionsCount">Maximum injections for the formula.</param>
        /// <param name="canAddInjections">Can able to add injections or not</param>
        /// <param name="myServiceLastSyncTime">My service last synchronize time.</param>
        /// <param name="referenceLoad">Max load in the group.</param>
        /// <param name="washstepcount">The washstepcount.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerModelId">The controller model identifier.</param>
        /// <param name="myServiceSaturationTypeId">My service saturation type identifier.</param>
        /// <param name="coolDownStep">Cool Down Step</param>
        public WasherGroupFormula(string washerGroupNumber, string washerGroupName, string washerGroupTypeName, int programSetupId, short programNumber,
             int productId, string productName, short nominalLoad, int totalRuntime, int extraTime, short loadsPerMonth, int nextAvailableStepNo,
             DateTime lastModifiedTime, DateTime lastSyncTime, string ecolabAccountNumber, int washerGroupId, int nextAvailableFormulaNo,
			Guid myServiceCustFrmulaMchGrpGuid, bool isDelete, int myServiceMstrLnnTypId, Guid myServiceMchGrpGuid, int maxInjectionsCount,
			bool canAddInjections, DateTime myServiceLastSyncTime, int referenceLoad, int washstepcount, int controllerId, int controllerModelId, int myServiceSaturationTypeId, int coolDownStep, int expectedRunTime)
        {
            this.Id = programSetupId;
            this.WasherGroupNumber = washerGroupNumber;
            this.WasherGroupName = washerGroupName;
            this.WasherGroupTypeName = washerGroupTypeName;
            this.ProgramNumber = programNumber;
            this.ProgramId = productId;
            this.ProductName = productName;
            this.NominalLoad = nominalLoad;
            this.TotalRuntime = totalRuntime;
            this.ExtraTime = extraTime;
            this.LoadsPerMonth = loadsPerMonth;
            this.NextAvailableStepNo = nextAvailableStepNo;
            this.LastModifiedTime = lastModifiedTime;
            this.LastSyncTime = lastSyncTime;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.WasherGroupId = washerGroupId;
            this.NextAvailableFormulaNo = nextAvailableFormulaNo;
            this.MyServiceCustFrmulaMchGrpGUID = myServiceCustFrmulaMchGrpGuid;
            this.IsDelete = isDelete;
            this.MyServiceMstrLnnTypId = myServiceMstrLnnTypId;
            this.MyServiceMchGrpGuid = myServiceMchGrpGuid;
            this.MaxInjectionsCount = maxInjectionsCount;
            this.CanAddInjections = canAddInjections;
            this.MyServiceLastSynchTime = myServiceLastSyncTime;
            this.ReferenceLoad = referenceLoad;
			this.FormulaNumberWithName = this.ProgramNumber + " - " + this.ProductName;
            this.WashStepCount = washstepcount;
			this.ControllerId = controllerId;
			this.ControllerModelId = controllerModelId;
            this.MyServiceSaturationTypeId = myServiceSaturationTypeId;
            this.CoolDownStep = coolDownStep;
            this.ExpectedRunTime = expectedRunTime;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroupFormula"/> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="nominalLoad">The nominal load.</param>
        /// <param name="loadPerMonth">The load per month.</param>
        /// <param name="totalRuntime">The total run time.</param>
        /// <param name="totalSteps">The total steps.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceCustFrmulaMchGrpGUID">My service customer frmula MCH GRP unique identifier.</param>
        /// <param name="myServiceModDtTm">My service mod dt tm.</param>
        /// <param name="myServiceMchGrpGuid">My service MCH GRP unique identifier.</param>
        /// <param name="formulaName">Name of the formula.</param>
        /// <param name="formulaTypeCode">The formula type code.</param>
        public WasherGroupFormula(string ecolabAccountNumber, int programNumber, decimal nominalLoad, int loadPerMonth, int totalRuntime, int totalSteps, bool isDeleted,
            Guid myServiceCustFrmulaMchGrpGUID, DateTime myServiceModDtTm, Guid myServiceMchGrpGuid, string formulaName, string formulaTypeCode)
        {
            EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            ProgramNumber = Convert.ToInt16(programNumber);
            NominalLoad = Convert.ToInt16(nominalLoad);
            LoadsPerMonth = Convert.ToInt16(loadPerMonth);
            TotalRuntime = totalRuntime;
            TotalSteps = totalSteps;
            IsDelete = isDeleted;
            MyServiceCustFrmulaMchGrpGUID = myServiceCustFrmulaMchGrpGUID;
            MyServiceLastSynchTime = myServiceModDtTm;
            MyServiceMchGrpGuid = myServiceMchGrpGuid;
            ProductName = formulaName;
            FormulaTypeCode = formulaTypeCode;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroupFormula"/> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="nominalLoad">The nominal load.</param>
        /// <param name="nominalLoadUOMCode">The nominal load uom code.</param>
        /// <param name="loadPerMonth">The load per month.</param>
        /// <param name="totalRuntime">The total run time.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceCustFrmulaMchGrpGUID">My service customer frmula MCH GRP unique identifier.</param>
        /// <param name="myServiceModDtTm">My service mod dt tm.</param>
        /// <param name="myServiceMchGrpGuid">My service MCH GRP unique identifier.</param>
        /// <param name="formulaName">Name of the formula.</param>
        /// <param name="formulaTypeCode">The formula type code.</param>
        public WasherGroupFormula(string ecolabAccountNumber, int programNumber, decimal nominalLoad, string nominalLoadUOMCode, int loadPerMonth, int totalRuntime, bool isDeleted,
            Guid myServiceCustFrmulaMchGrpGUID, DateTime myServiceModDtTm, Guid myServiceMchGrpGuid, string formulaName, string formulaTypeCode)
        {
            EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            ProgramNumber = Convert.ToInt16(programNumber);
            NominalLoad = Convert.ToInt16(nominalLoad);
            LoadsPerMonth = Convert.ToInt16(loadPerMonth);
            TotalRuntime = totalRuntime;
            IsDelete = isDeleted;
            MyServiceCustFrmulaMchGrpGUID = myServiceCustFrmulaMchGrpGUID;
            MyServiceLastSynchTime = myServiceModDtTm;
            MyServiceMchGrpGuid = myServiceMchGrpGuid;
            ProductName = formulaName;
            FormulaTypeCode = formulaTypeCode;
            NominalLoadUomCode = nominalLoadUOMCode;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherGroupFormula"/> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="nominalLoad">The nominal load.</param>        
        /// <param name="totalRuntime">The total run time.</param>
        /// <param name="totalSteps">The total steps.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceCustFrmulaMchGrpGUID">My service customer frmula MCH GRP unique identifier.</param>
        /// <param name="myServiceModDtTm">My service mod dt tm.</param>
        /// <param name="myServiceMchGrpGuid">My service MCH GRP unique identifier.</param>
        /// <param name="formulaName">Name of the formula.</param>
        /// <param name="formulaTypeCode">The formula type code.</param>
        public WasherGroupFormula(string ecolabAccountNumber, int programNumber, decimal nominalLoad, int totalRuntime, int totalSteps, bool isDeleted,
            Guid myServiceCustFrmulaMchGrpGUID, DateTime myServiceModDtTm, Guid myServiceMchGrpGuid, string formulaName, string formulaTypeCode)
        {
            EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            ProgramNumber = Convert.ToInt16(programNumber);
            NominalLoad = Convert.ToInt16(nominalLoad);            
            TotalRuntime = totalRuntime;
            TotalSteps = totalSteps;
            IsDelete = isDeleted;
            MyServiceCustFrmulaMchGrpGUID = myServiceCustFrmulaMchGrpGUID;
            MyServiceLastSynchTime = myServiceModDtTm;
            MyServiceMchGrpGuid = myServiceMchGrpGuid;
            ProductName = formulaName;
            FormulaTypeCode = formulaTypeCode;
        }

        /// <summary>
        ///     Gets or sets the WasherGroupNumber
        /// </summary>
        /// <value>The Parameter Washer Group Number</value>
        public string WasherGroupNumber { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupName
        /// </summary>
        /// <value>The Parameter Washer Group Name</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeName
        /// </summary>
        /// <value>The Parameter Washer Group Type Name</value>
        public string WasherGroupTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramNumber
        /// </summary>
        /// <value>The Parameter Program Number</value>
        public short ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ProductName
        /// </summary>
        /// <value>The Parameter Product Name</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets the NominalLoad
        /// </summary>
        /// <value>The Parameter Nominal Load</value>
        public short NominalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the TotalRunTime
        /// </summary>
        /// <value>The Parameter Total run Time</value>
        public int TotalRuntime { get; set; }

        /// <summary>
        ///     Gets or sets the ExtraTime
        /// </summary>
        /// <value>The Parameter Extra Time</value>
        public int ExtraTime { get; set; }

        /// <summary>
        ///     Gets or sets the LoadsPerMonth
        /// </summary>
        /// <value>The Parameter Loads Per Month</value>
        public short LoadsPerMonth { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupId
        /// </summary>
        /// <value>The Parameter Washer Group Id</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramId
        /// </summary>
        /// <value>The Parameter Program Id</value>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the NextAvailableStepNo
        /// </summary>
        /// <value>The Parameter Next Available Step No</value>
        public int NextAvailableStepNo { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the available formula number.
        /// </summary>
        /// <value>Next Available Formula No value.</value>
        public int NextAvailableFormulaNo { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustFrmulaMchGrpGUID
        /// </summary>
        /// <value>MyServiceCustFrmulaMchGrpGUID</value> 
        public Guid? MyServiceCustFrmulaMchGrpGUID { get; set; } 	

        /// <summary>
        /// Gets or sets MyServiceLastSynchTime
        /// </summary>
        /// <value>MyServiceLastSynchTime</value> 
        public DateTime MyServiceLastSynchTime { get; set; }

        /// <summary>
        /// Gets or sets Reference Load
        /// </summary>
        /// <value>Reference Load</value> 
        public int ReferenceLoad { get; set; }

        /// <summary>
        /// Gets or sets MyServiceMstrLnnTypId
        /// </summary>
        /// <value>MyServiceMstrLnnTypId</value> 
        public int MyServiceMstrLnnTypId { get; set; }

        /// <summary>
        /// Gets or sets MyServiceMchGrpGuid
        /// </summary>
        /// <value>MyServiceMchGrpGuid</value> 
        public Guid? MyServiceMchGrpGuid { get; set; }

        /// <summary>
        /// Gets or sets TotalSteps
        /// It is used only for getting myservice
        /// </summary>
        /// <value>TotalSteps</value>
        public int TotalSteps { get; set; }

        /// <summary>
        /// Gets or sets FormulaTypeCode
        /// It is get from myService and used to make formula porposed or current on the basis of code
        /// </summary>
        public string FormulaTypeCode { get; set; }

        /// <summary>
        /// Gets or sets nominalLoadUOMCode
        /// It is used to converting nominalload into conduit uom using nominalLoadUOMCode
        /// </summary>
        public string NominalLoadUomCode { get; set; }

        /// <summary>
        /// Gets or sets the max injections count
        /// </summary>
        public int MaxInjectionsCount { get; set; }

        /// <summary>
        /// Gets or sets the can add injections status
        /// </summary>
        public bool CanAddInjections { get; set; }

		/// <summary>
		///     Gets or sets the Washer steps
		/// </summary>
		/// <value>The WashStepCount</value>
		public int WashStepCount { get; set; }

        /// <summary>
		/// Gets or sets ControllerId
        /// </summary>
		public int? ControllerId { get; set; }

		/// <summary>
		///     Gets or sets the StandardRunTime
        /// </summary>
		/// <value>The StandardRunTime</value>
		public int StandardRuntime { get; set; }

        /// <summary>
        /// CoolDownStep
        /// </summary>
        public int CoolDownStep { get; set; }

        /// <summary>
        /// FinalExtractingTime
        /// </summary>
        public int FinalExtractingTime { get; set; }

        /// <summary>
        /// PlantProgramNumber
        /// </summary>
        public int PlantProgramNumber { get; set; }

        /// <summary>
        /// NumberOfDrains
        /// </summary>
        public int NumberOfDrains { get; set; }

        /// <summary>
        /// DrainTime
        /// </summary>
        public int DrainTime { get; set; }

        /// <summary>
        /// Rewash
        /// </summary>
        public bool Rewash { get; set; }

        /// <summary>
        /// CleanWt
        /// </summary>
        public decimal CleanWt { get; set; }

        /// <summary>
        /// CleanAw
        /// </summary>
        public decimal CleanAw { get; set; }

        /// <summary>
        /// Gets or sets ControllerModelId
        /// </summary>
        public int ControllerModelId { get; set; }
		/// <summary>
		/// Gets or sets FormulaNumberWithName
		/// </summary>
		public string FormulaNumberWithName { get; set; }
        /// <summary>
		/// Gets or sets MyServiceSaturationTypeId
		/// </summary>
		/// <value>MyServiceSaturationTypeId</value> 
		public int MyServiceSaturationTypeId { get; set; }

        /// <summary>
        /// Gets or sets the expected run time.
        /// </summary>
        /// <value>
        /// The expected run time.
        /// </value>
        public int ExpectedRunTime { get; set; }
    }
}