﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWashStep.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelWashStep Model is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Entities.WasherGroup
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Class Tunnel
    /// </summary>
    public class TunnelWashStep : BaseEntity
    {
        /// <summary>
        ///     Contructor for TunnelWashStep
        /// </summary>
        public TunnelWashStep()
        {
        }

        /// <summary>
        ///     Parameterized Constructor for TunnelWashStep
        /// </summary>
        /// <param name="programNumber">The Program Number</param>
        /// <param name="groupId">The Group Id</param>
        /// <param name="ecolabAccountNumber">The EcolabAccountNumber</param>
        /// <param name="stepTypeId">The StepType Id</param>
        /// <param name="stepRuntime">The StepRun Time</param>
        /// <param name="compartmentNumber">The Compartment Number</param>
        /// <param name="temperature">The Temperature</param>
        /// <param name="tunnelDosingStepId">The Tunnel Dosing Step Id</param>
        /// <param name="waterType">The Water Type</param>
        /// <param name="waterLevel">The Water Level</param>
        /// <param name="waterInletDrain">The Water Inlet Drain</param>
        /// <param name="notes">The notes string</param>
        /// <param name="tunnelProgramSetupId">The tunnel Program Setup Id</param>
        /// <param name="waterFlow">The name of Water flow</param>
        public TunnelWashStep(int programNumber, int groupId, string ecolabAccountNumber, int stepTypeId, int stepRuntime, int compartmentNumber, int temperature, int tunnelDosingStepId, string waterType, decimal? waterLevel, string waterInletDrain, string notes, int tunnelProgramSetupId, string waterFlow)
        {
            this.Id = tunnelDosingStepId;
            this.ProgramNumber = programNumber;
            this.GroupId = groupId;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            this.StepTypeId = stepTypeId;
            this.StepRuntime = stepRuntime;
            this.CompartmentNumber = compartmentNumber;
            this.Temperature = temperature;
            this.WaterType = waterType;
            this.WaterLevel = waterLevel;
            this.WaterInletDrain = waterInletDrain;
            this.Notes = notes;
            this.TunnelProgramSetupId = tunnelProgramSetupId;
            this.TunnelDosingSetupId = tunnelDosingStepId;
            this.WaterFlow = waterFlow;
        }

        /// <summary>
        ///     Parameterized Constructor for TunnelWashStep
        /// </summary>
        /// <param name="programNumber">The Program Number</param>
        /// <param name="groupId">The Group Id</param>
        /// <param name="ecolabAccountNumber">The EcolabAccountNumber</param>
        /// <param name="stepTypeId">The StepType Id</param>
        /// <param name="stepRuntime">The StepRun Time</param>
        /// <param name="compartmentNumber">The Compartment Number</param>
        /// <param name="temperature">The Temperature</param>
        /// <param name="tunnelDosingStepId">The Tunnel Dosing Step Id</param>
        /// <param name="waterType">The Water Type</param>
        /// <param name="waterLevel">The Water Level</param>
        /// <param name="waterInletDrain">The Water Inlet Drain</param>
        /// <param name="notes">The notes string</param>
        /// <param name="tunnelProgramSetupId">The tunnel Program Setup Id</param>
        /// <param name="waterFlow">The name of Water flow</param>
        /// <param name="phSensorNumber">ph Sensor Number</param>
        public TunnelWashStep(int programNumber, int groupId, string ecolabAccountNumber, int stepTypeId, int stepRuntime, int compartmentNumber, int temperature, int tunnelDosingStepId, string waterType, decimal? waterLevel, string waterInletDrain, string notes, int tunnelProgramSetupId, string waterFlow, short myServiceWshOpId, short myServiceUtilId, short myServiceDrainTypId, bool isdelete, Guid myServiceCusrFrmulaStpGuid, string sensorTypeAttached, int Probenumber, int phSensorNumber)
        {
            this.Id = tunnelDosingStepId;
            this.ProgramNumber = programNumber;
            this.GroupId = groupId;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.StepTypeId = stepTypeId;
            this.StepRuntime = stepRuntime;
            this.CompartmentNumber = compartmentNumber;
            this.Temperature = temperature;
            this.WaterType = waterType;
            this.WaterLevel = waterLevel;
            this.WaterInletDrain = waterInletDrain;
            this.Notes = notes;
            this.TunnelProgramSetupId = tunnelProgramSetupId;
            this.TunnelDosingSetupId = tunnelDosingStepId;
            this.WaterFlow = waterFlow;
            this.MyServiceWshOpId = myServiceWshOpId;
            this.MyServiceUtilId = myServiceUtilId;
            this.MyServiceDrainTypId = myServiceDrainTypId;
            this.IsDelete = isdelete;
            this.MyServiceCusrFrmulaStpGuid = myServiceCusrFrmulaStpGuid;
            this.SensorTypeAttached = sensorTypeAttached;
            this.Probenumber = Probenumber;
            this.PhSensorNumber = phSensorNumber;
        }

        public TunnelWashStep(Int16 myServiceStepTypeId, int stepRuntime, Int16 compartmentNumber, int temperature, string tempUomCode, int myServiceWaterType, int waterLevel, string waterLevUomCode, short myServiceDrainDestinationId, int waterInletDrain, string note, bool isdelete, Guid myServiceCustFrmulaStpGUID, DateTime myServiceModDtTm)
        {
            this.CompartmentNumber = compartmentNumber;
            this.MyServiceWshOpId = myServiceStepTypeId;
            this.StepRuntime = stepRuntime;
            this.Temperature = temperature;
            this.MyServiceUtilId = myServiceWaterType;
            this.WaterLevel = waterLevel;
            this.MyServiceDrainTypId = myServiceDrainDestinationId;
            this.Notes = note;
            this.IsDelete = isdelete;
            this.MyServiceCusrFrmulaStpGuid = myServiceCustFrmulaStpGUID;
            this.MyServiceModDtTm = myServiceModDtTm;
            this.WaterInletDrain = Convert.ToString(waterInletDrain);
            this.TempUomCode = tempUomCode;
            this.WaterLevUomCode = waterLevUomCode;
        }

        /// <summary>
        ///     Gets or sets the Program Number
        /// </summary>
        /// <value>The Parameter Program Number</value>
        public int ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Group Id
        /// </summary>
        /// <value>The Parameter Group Id</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Step Type Id
        /// </summary>
        /// <value>The Parameter Step Type Id</value>
        public int StepTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Step RunTime
        /// </summary>
        /// <value>The Parameter Step Run Time</value>
        public int StepRuntime { get; set; }

        /// <summary>
        ///     Gets or sets the Compartment Number
        /// </summary>
        /// <value>The Parameter Compartment Number</value>
        public int CompartmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature
        /// </summary>
        /// <v>The Parameter Temperature</v>
        public int Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the TunnelDosing SetupId
        /// </summary>
        /// <value>The Parameter Tunnel Dosing Setup Id</value>
        public int TunnelDosingSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the Water Type
        /// </summary>
        /// <value>The Parameter Water Type</value>
        public string WaterType { get; set; }

        /// <summary>
        ///     Gets or sets the Water Level
        /// </summary>
        /// <value>The Parameter Water Level</value>
        public decimal? WaterLevel { get; set; }

        /// <summary>
        ///     Gets or sets the WaterInlet/Drain
        /// </summary>
        /// <value>The Parameter Water Inlet / Drain</value>
        public string WaterInletDrain { get; set; }

        /// <summary>
        ///     Gets or sets the Note
        /// </summary>
        /// <value>The Parameter Note</value>
        public string Notes { get; set; }

        /// <summary>
        ///     Gets or sets the Tunnel Program SetupId
        /// </summary>
        /// <value>The Parameter Tunnel Program Setup Id</value>
        public int TunnelProgramSetupId { get; set; }

        /// <summary>
        ///     Gets or sets ProductsList
        /// </summary>
        /// <value>The Parameter Products List</value>
        public List<TunnelWashStepProducts> ProductsList { get; set; }

        /// <summary>
        /// Gets or sets the Water flow value.
        /// </summary>
        /// <value>The parameter value of Waterflow.</value>
        public string WaterFlow { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceWshOpId
        /// </summary>
        /// <value>MyServiceWshOpId</value>
        public int MyServiceWshOpId { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceUtilId
        /// </summary>
        /// <value> MyServiceUtilId</value>
        public int MyServiceUtilId { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceDrainTypId
        /// </summary>
        /// <value> MyServiceDrainTypId</value>
        public int MyServiceDrainTypId { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCusrFrmulaStpGuid
        /// </summary>
        /// <value> MyServiceCusrFrmulaStpGuid</value>
        public Guid? MyServiceCusrFrmulaStpGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceModDtTm
        /// </summary>
        /// <value> MyServiceModDtTm</value>
        public DateTime MyServiceModDtTm { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustFrmulaMchGrpGuid
        /// </summary>
        /// <value> MyServiceCustFrmulaMchGrpGuid</value>
        public Guid? MyServiceCustFrmulaMchGrpGuid { get; set; }

        /// <summary>
        /// Gets or sets the temporary uom code.
        /// </summary>
        /// <value>The temporary uom code.</value>
        public string TempUomCode { get; set; }
        /// <summary>
        /// Gets or sets the water lev uom code.
        /// </summary>
        /// <value>The water lev uom code.</value>
        public string WaterLevUomCode { get; set; }
        /// <summary>
        /// Gets or Sets the Tunnel Analogue Control
        /// </summary>
        /// <value>The Tunnel Analogue Control</value>
        public TunnelAnalogueControl TunnelAnalogueControl { get; set; }
        /// <summary>
        /// Gets or Sets sensor types attached to the particular tunnel Compartment
        /// </summary>
        /// <value>Sensor types attached to the particular compartment</value>
        public string SensorTypeAttached { get; set; }
        /// <summary>
        /// Gets or Sets Probe number attached to the particular tunnel Compartment
        /// </summary>
        /// <value>Probe number attached to the particular compartment</value>
        public int Probenumber { get; set; }
        /// <summary>
        /// Gets or Sets Ph Sensor number attached to the particular tunnel Compartment
        /// </summary>
        /// <value>Ph Sensor number number attached to the particular compartment</value>
        public int PhSensorNumber { get; set; }
    }
}