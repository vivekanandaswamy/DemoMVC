﻿// -----------------------------------------------------------------------
// <copyright file="WasherFormulaTunnelAnalogueControl.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherFormulaTunnelAnalogueControl </summary>
// -----------------------------------------------------------------------

namespace Entities.WasherGroup
{
    /// <summary>
    /// Washer Formula Tunnel Analogue Control
    /// </summary>
    public class WasherFormulaTunnelAnalogueControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WasherFormulaTunnelAnalogueControl"/> class.
        /// </summary>
        public WasherFormulaTunnelAnalogueControl()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WasherFormulaTunnelAnalogueControl"/> class.
        /// </summary>
        /// <param name="washerDosingNumber">The washer dosing number.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="probeNumber">The probe number.</param>
        /// <param name="compartmentNumber">The compartment number.</param>
        /// <param name="machineCompartment">The machine compartment.</param>
        /// <param name="setPointTemparature">The set point temparature.</param>
        /// <param name="minimumTime">The minimum time.</param>
        /// <param name="startDelay">The start delay.</param>
        /// <param name="acceptedDelay">The accepted delay.</param>
        /// <param name="productCheck">if set to <c>true</c> [product check].</param>
        /// <param name="pHRegulationLevel">The p h regulation level.</param>
        /// <param name="pHMonitoringLevel">The p h monitoring level.</param>
        /// <param name="pHMinimum">The p h minimum.</param>
        /// <param name="pHMaximum">The p h maximum.</param>
        /// <param name="delayTime">The delay time.</param>
        /// <param name="measuringTime">The measuring time.</param>
        /// <param name="conductivityRegulationLevel">The conductivity regulation level.</param>
        /// <param name="conductivityMininum">The conductivity mininum.</param>
        /// <param name="conductivityMaximum">The conductivity maximum.</param>
        /// <param name="conductivityDelayTime">The conductivity delay time.</param>
        /// <param name="conductivityMeasuringTime">The conductivity measuring time.</param>
        /// <param name="sensorType">Type of the sensor.</param>
        public WasherFormulaTunnelAnalogueControl(int washerDosingNumber, int programNumber, int probeNumber, int compartmentNumber,
                int machineCompartment, double setPointTemparature, int minimumTime, int startDelay, int acceptedDelay, 
                bool productCheck, int pHRegulationLevel, int pHMonitoringLevel, decimal pHMinimum, decimal pHMaximum, int delayTime, int measuringTime,
                int conductivityRegulationLevel, decimal conductivityMininum, decimal conductivityMaximum, int conductivityDelayTime, int conductivityMeasuringTime,
                int sensorType)
        {
            WasherDosingNumber = washerDosingNumber;
            ProgramNumber = programNumber;
            ProbeNumber = probeNumber;
            CompartmentNumber = compartmentNumber;
            MachineCompartment = machineCompartment;
            SetPointTemparature = setPointTemparature;
            MinimumTime = minimumTime;
            StartDelay = startDelay;
            AcceptedDelay = acceptedDelay;
            ProductCheck = productCheck;
            PHRegulationLevel = pHRegulationLevel;
            PHMonitoringLevel = pHMonitoringLevel;
            PHMinimum = pHMinimum;
            PHMaximum = pHMaximum;
            DelayTime = delayTime;
            MeasuringTime = measuringTime;
            ConductivityRegulationLevel = conductivityRegulationLevel;
            ConductivityMininum = conductivityMininum;
            ConductivityMaximum = conductivityMaximum;
            ConductivityDelayTime = conductivityDelayTime;
            ConductivityMeasuringTime = conductivityMeasuringTime;
            SensorType = sensorType;
        }

        /// <summary>
        /// Gets or sets the washer dosing number.
        /// </summary>
        /// <value>
        /// The washer dosing number.
        /// </value>
        public int WasherDosingNumber { get; set; }

        /// <summary>
        /// Gets or sets the program number.
        /// </summary>
        /// <value>
        /// The program number.
        /// </value>
        public int ProgramNumber { get; set; }

        /// <summary>
        /// Gets or sets the probe number.
        /// </summary>
        /// <value>
        /// The probe number.
        /// </value>
        public int ProbeNumber { get; set; }

        /// <summary>
        /// Gets or sets the compartment number.
        /// </summary>
        /// <value>
        /// The compartment number.
        /// </value>
        public int CompartmentNumber { get; set; }

        /// <summary>
        /// Gets or sets the machine compartment.
        /// </summary>
        /// <value>
        /// The machine compartment.
        /// </value>
        public int MachineCompartment { get; set; }

        /// <summary>
        /// Gets or sets the set point temparature.
        /// </summary>
        /// <value>
        /// The set point temparature.
        /// </value>
        public double SetPointTemparature { get; set; }

        /// <summary>
        /// Gets or sets the minimum time.
        /// </summary>
        /// <value>
        /// The minimum time.
        /// </value>
        public int MinimumTime { get; set; }

        /// <summary>
        /// Gets or sets the start delay.
        /// </summary>
        /// <value>
        /// The start delay.
        /// </value>
        public int StartDelay { get; set; }

        /// <summary>
        /// Gets or sets the accepted delay.
        /// </summary>
        /// <value>
        /// The accepted delay.
        /// </value>
        public int AcceptedDelay { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [product check].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [product check]; otherwise, <c>false</c>.
        /// </value>
        public bool ProductCheck { get; set; }

        /// <summary>
        /// Gets or sets the ph regulation level.
        /// </summary>
        /// <value>
        /// The ph regulation level.
        /// </value>
        public int PHRegulationLevel { get; set; }

        /// <summary>
        /// Gets or sets the ph monitoring level.
        /// </summary>
        /// <value>
        /// The ph monitoring level.
        /// </value>
        public int PHMonitoringLevel { get; set; }

        /// <summary>
        /// Gets or sets the ph minimum.
        /// </summary>
        /// <value>
        /// The ph minimum.
        /// </value>
        public decimal PHMinimum { get; set; }

        /// <summary>
        /// Gets or sets the ph maximum.
        /// </summary>
        /// <value>
        /// The ph maximum.
        /// </value>
        public decimal PHMaximum { get; set; }

        /// <summary>
        /// Gets or sets the delay time.
        /// </summary>
        /// <value>
        /// The delay time.
        /// </value>
        public int DelayTime { get; set; }

        /// <summary>
        /// Gets or sets the measuring time.
        /// </summary>
        /// <value>
        /// The measuring time.
        /// </value>
        public int MeasuringTime { get; set; }

        /// <summary>
        /// Gets or sets the conductivity regulation level.
        /// </summary>
        /// <value>
        /// The conductivity regulation level.
        /// </value>
        public int ConductivityRegulationLevel { get; set; }

        /// <summary>
        /// Gets or sets the conductivity mininum.
        /// </summary>
        /// <value>
        /// The conductivity mininum.
        /// </value>
        public decimal ConductivityMininum { get; set; }

        /// <summary>
        /// Gets or sets the conductivity maximum.
        /// </summary>
        /// <value>
        /// The conductivity maximum.
        /// </value>
        public decimal ConductivityMaximum { get; set; }

        /// <summary>
        /// Gets or sets the conductivity delay time.
        /// </summary>
        /// <value>
        /// The conductivity delay time.
        /// </value>
        public int ConductivityDelayTime { get; set; }

        /// <summary>
        /// Gets or sets the conductivity measuring time.
        /// </summary>
        /// <value>
        /// The conductivity measuring time.
        /// </value>
        public int ConductivityMeasuringTime { get; set; }

        /// <summary>
        /// Gets or sets the type of the sensor.
        /// </summary>
        /// <value>
        /// The type of the sensor.
        /// </value>
        public int SensorType { get; set; }
    }
}
