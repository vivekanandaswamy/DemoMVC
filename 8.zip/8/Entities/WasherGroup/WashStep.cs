﻿// -----------------------------------------------------------------------
// <copyright file="WashStep.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WashStep is for get and set the data.</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.WasherGroup
{
    /// <summary>
    ///     WashStep class consists of all entities WashStep.
    /// </summary>
    public class WashStep
    {
        #region "Constructor"

        /// <summary>
        /// Initializes a new instance of the <see cref="WashStep" /> class.
        /// </summary>
        /// <param name="stepId">Gets the step Id of the Wash Step.</param>
        /// <param name="stepName">Gets the step Name of the Wash Step.</param>
        public WashStep(int stepId, string stepName)
        {
            this.StepId = stepId;
            this.StepName = stepName;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WashStep" /> class.
        /// </summary>
        /// <param name="regionCode">The region code.</param>
        /// <param name="stepName">Gets the step Name of the Wash Step.</param>
        /// <param name="isTunnel">if set to <c>true</c> [is tunnel].</param>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="myServiceWshOpTypCd">My service WSH op typ cd.</param>
        /// <param name="myServiceWshOpId">My service WSH op identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="spSp">The sp sp.</param>
        /// <param name="nrNR">The nr nr.</param>
        /// <param name="nlBE">The nl be.</param>
        public WashStep(string regionCode, string stepName, bool isTunnel, bool isActive, string myServiceWshOpTypCd, Int16 myServiceWshOpId, DateTime myServiceLastSynchTime, string spSp, string nrNR, string nlBE)
        {
            StepName = stepName;
            RegionCode = regionCode;
            IsTunnel = isTunnel;
            IsActive = isActive;
            MyServiceWshOpTypCd = myServiceWshOpTypCd;
            MyServiceWshOpId = myServiceWshOpId;
            MyServiceLastSynchTime = myServiceLastSynchTime;
            sp_SP = spSp;
            nr_NR = nrNR;
            nl_BE = nlBE;
        }

        public WashStep()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Step Id
        /// </summary>
        /// <value>The Parameter Step Id</value>
        public int StepId { get; set; }

        /// <summary>
        ///     Gets or sets the Step Name
        /// </summary>
        /// <value>The Parameter Step Name</value>
        public string StepName { get; set; }

        /// <summary>
        ///     Gets or sets the RegionCode
        /// </summary>
        /// <value>The Parameter RegionCode</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the IsTunnel
        /// </summary>
        /// <value>The Parameter IsTunnel</value>
        public bool IsTunnel { get; set; }

        /// <summary>
        ///     Gets or sets the IsActive
        /// </summary>
        /// <value>The Parameter IsActive</value>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceWshOpTypCd
        /// </summary>
        /// <value>The Parameter MyServiceWshOpTypCd</value>
        public string MyServiceWshOpTypCd { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceWshOpId
        /// </summary>
        /// <value>The Parameter MyServiceWshOpId</value>
        public Int16 MyServiceWshOpId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}