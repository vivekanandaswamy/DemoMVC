﻿// -----------------------------------------------------------------------
// <copyright file="InjectionDetails.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The InjectionDetails </summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.WasherGroup
{
    public class InjectionDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionDetails" /> class.
        /// </summary>
        /// <param name="washerDosingSetupId">The washer dosing setup identifier.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="quantity">The quantity Value.</param>
        /// <param name="referenceLoad">The reference load.</param>
        /// <param name="injectionClass">The injection class.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerType">Type of the controller.</param>
        /// <param name="nominalLoad">The nominal load.</param>
        public InjectionDetails(int washerDosingSetupId, int programId, string washerGroupNumber, short injectionNumber, byte controllerEquipmentId, int productId, decimal quantity, int referenceLoad, string injectionClass, int controllerId, int controllerType, short nominalLoad)
        {
            WasherDosingSetupId = washerDosingSetupId;
            ProgramId = programId;
            WasherGroupNumber = washerGroupNumber;
            InjectionNumber = injectionNumber;
            ControllerEquipmentId = controllerEquipmentId;
            ProductId = productId;
            Quantity = quantity;
            ReferenceLoad = referenceLoad;
            InjectionClass = injectionClass;
            ControllerType = controllerType;
            ControllerId = controllerId;
            NominalLoad = nominalLoad;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionDetails" /> class.
        /// </summary>
        /// <param name="washerDosingSetupId">The washer dosing setup identifier.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="quantity">The quantity.</param>
        /// <param name="referenceLoad">The reference load.</param>
        /// <param name="stepNumber">The step number.</param>
        /// <param name="washOperationId">The wash operation identifier.</param>
        /// <param name="washOperation">The wash operation.</param>
        /// <param name="injectionClass">The injection class.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerType">Type of the controller.</param>        
        public InjectionDetails(int washerDosingSetupId, int programId, string washerGroupNumber, short injectionNumber, byte controllerEquipmentId, int productId, string name, decimal quantity, int referenceLoad, int stepNumber, int washOperationId, string washOperation, string injectionClass, int controllerId, int controllerType)
        {
            WasherDosingSetupId = washerDosingSetupId;
            ProgramId = (int)programId;
            WasherGroupNumber = washerGroupNumber;
            InjectionNumber = injectionNumber;
            ControllerEquipmentId = controllerEquipmentId;
            ProductId = productId;
            Name = name;
            Quantity = quantity;
            ReferenceLoad = referenceLoad;
            StepNumber = stepNumber;
            WashOperationId = washOperationId;
            WashOperation = washOperation;
            InjectionClass = injectionClass;
            ControllerType = controllerType;
            ControllerId = controllerId;            
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionDetails" /> class.
        /// </summary>
        /// <param name="washerDosingSetupId">The washer dosing setup identifier.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="quantity">The quantity.</param>
        /// <param name="referenceLoad">The reference load.</param>
        /// <param name="stepNumber">The step number.</param>
        /// <param name="washOperationId">The wash operation identifier.</param>
        /// <param name="washOperation">The wash operation.</param>
        /// <param name="injectionClass">The injection class.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerType">Type of the controller.</param>
        /// <param name="nominalLoad">The nominal load.</param>
        public InjectionDetails(int washerDosingSetupId, short programId, string washerGroupNumber, short injectionNumber, byte controllerEquipmentId, int productId, string name, decimal quantity, int referenceLoad, int stepNumber, int washOperationId, string washOperation, string injectionClass, int controllerId, int controllerType, short nominalLoad)
        {
            WasherDosingSetupId = washerDosingSetupId;
            ProgramId = (int)programId;
            WasherGroupNumber = washerGroupNumber;
            InjectionNumber = injectionNumber;
            ControllerEquipmentId = controllerEquipmentId;
            ProductId = productId;
            Name = name;
            Quantity = quantity;
            ReferenceLoad = referenceLoad;
            StepNumber = stepNumber;
            WashOperationId = washOperationId;
            WashOperation = washOperation;
            InjectionClass = injectionClass;
            ControllerType = controllerType;
            ControllerId = controllerId;
            NominalLoad = nominalLoad;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionDetails" /> class.
        /// </summary>
        /// <param name="washerDosingSetupId">The washer dosing setup identifier.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="quantity">The quantity.</param>
        /// <param name="referenceLoad">The reference load.</param>
        /// <param name="stepNumber">The step number.</param>
        /// <param name="washOperationId">The wash operation identifier.</param>
        /// <param name="washOperation">The wash operation.</param>
        /// <param name="injectionClass">The injection class.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerType">Type of the controller.</param>
        /// <param name="nominalLoad">The nominal load.</param>
        /// <param name="washerProgramSetupId">The washer program setup identifier.</param>
        public InjectionDetails(int washerDosingSetupId, short programId, string washerGroupNumber, short injectionNumber, byte controllerEquipmentId, int productId, string name, decimal quantity, int referenceLoad, int stepNumber, int washOperationId, string washOperation, string injectionClass, int controllerId, int controllerType, short nominalLoad, int washerProgramSetupId)
        {
            WasherDosingSetupId = washerDosingSetupId;
            ProgramId = (int)programId;
            WasherGroupNumber = washerGroupNumber;
            InjectionNumber = injectionNumber;
            ControllerEquipmentId = controllerEquipmentId;
            ProductId = productId;
            Name = name;
            Quantity = quantity;
            ReferenceLoad = referenceLoad;
            StepNumber = stepNumber;
            WashOperationId = washOperationId;
            WashOperation = washOperation;
            InjectionClass = injectionClass;
            ControllerType = controllerType;
            ControllerId = controllerId;
            NominalLoad = nominalLoad;
            WasherProgramSetupId = washerProgramSetupId;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionDetails"/> class.
        /// </summary>
        /// <param name="programId">The program identifier.</param>
        /// <param name="washerDosingSetupId">The washer dosing setup identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="washergroupName">Name of the washergroup.</param>
        /// <param name="nominalLoad">The nominal load.</param>
        /// <param name="Loadspermonth">The loadspermonth.</param>
        /// <param name="TotalrunTtme">The totalrun ttme.</param>
        /// <param name="runtime">The run time.</param>
        /// <param name="drainDestination">The drain destination.</param>
        /// <param name="Extratime">The extratime.</param>
        /// <param name="Noofwashsteps">The noofwashsteps.</param>
        /// <param name="Cooldownstep">The cooldownstep.</param>
        /// <param name="Ecolabtextilecategoryid">The ecolabtextilecategoryid.</param>
        /// <param name="Washstepnumber">The washstepnumber.</param>
        /// <param name="Injectionnumber">The injectionnumber.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="quantity">The quantity.</param>
        /// <param name="delay">The delay time.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="productName">Name of the product.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="washerProgramSetupId">The washer program setup identifier.</param>
        /// <param name="waterType">Type of the water.</param>
        /// <param name="waterLevel">The water level.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="washerDosingProductMappingId">The washer dosing product mapping identifier.</param>
        /// <param name="washerDosingNumber">The washer dosing number.</param>
        public InjectionDetails(int programId, int washerDosingSetupId, string washerGroupNumber, string washergroupName, short nominalLoad,
                                short Loadspermonth, int TotalrunTtme, int runtime, short drainDestination, int Extratime,
                                int Noofwashsteps, int Cooldownstep, int Ecolabtextilecategoryid, int Washstepnumber, short Injectionnumber,
                                int temperature, decimal quantity, short delay, int productId, string productName,
                                short programNumber, int washerProgramSetupId, string waterType, decimal waterLevel, int controllerId,
                                byte controllerEquipmentId, int washerDosingProductMappingId, int washerDosingNumber)
        {
            ProgramId = programId;
            WasherDosingSetupId = washerDosingSetupId;
            WasherGroupNumber = washerGroupNumber;
            WasherGroupName = washergroupName;
            NominalLoad = nominalLoad;
            LoadsPerMonth = Loadspermonth;
            TotalRuntime = TotalrunTtme;
            Runtime = runtime;
            DrainDestination = drainDestination;
            ExtraTime = Extratime;
            NoOfWashSteps = Noofwashsteps;
            CoolDownStep = Cooldownstep;
            EcolabTextileCategoryID = Ecolabtextilecategoryid;
            StepNumber = Washstepnumber;
            InjectionNumber = Injectionnumber;
            Temperature = temperature;
            Quantity = quantity;
            Delay = delay;
            ProductId = productId;
            ProductName = productName;
            ProgramNumber = programNumber;
            WasherProgramSetupId = washerProgramSetupId;
            WaterType = waterType;
            WaterLevel = waterLevel;
            ControllerId = controllerId;
            ControllerEquipmentId = controllerEquipmentId;
            WasherDosingProductMappingId = washerDosingProductMappingId;
            WasherDosingNumber = washerDosingNumber;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InjectionDetails"/> class.
        /// </summary>
        /// <param name="programId">The program identifier.</param>
        /// <param name="tunneldosingsetupId">The tunneldosingsetup identifier.</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="washergroupName">Name of the washergroup.</param>
        /// <param name="nominalLoad">The nominal load.</param>
        /// <param name="Loadspermonth">The loadspermonth.</param>
        /// <param name="Totalruntime">The totalrun time.</param>
        /// <param name="Extratime">The extratime.</param>
        /// <param name="Ecolabtextilecategoryid">The ecolabtextilecategoryid.</param>
        /// <param name="Washstepnumber">The washstepnumber.</param>
        /// <param name="Injectionnumber">The injectionnumber.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="quantity">The quantity.</param>
        /// <param name="delay">The delay time.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="productName">Name of the product.</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="washerProgramSetupId">The washer program setup identifier.</param>
        /// <param name="waterType">Type of the water.</param>
        /// <param name="waterLevel">The water level.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="washerDosingNumber">The washer dosing number.</param>
        /// <param name="dosingPointNumber">The dosing point number.</param>
        /// <param name="valveNumber">The valve number.</param>
        /// <param name="isDirectDosing">if set to <c>true</c> [is direct dosing].</param>
        public InjectionDetails(int programId, int tunneldosingsetupId, string washerGroupNumber, string washergroupName, short nominalLoad, short Loadspermonth,
                    int Totalruntime, int Extratime, int Ecolabtextilecategoryid, int Washstepnumber, short Injectionnumber,
                    int temperature, decimal quantity, int delay, int productId,
                    string productName, short programNumber, int washerProgramSetupId, string waterType, decimal waterLevel, int controllerId, byte controllerEquipmentId,
                    int washerDosingNumber, byte dosingPointNumber, byte valveNumber, bool isDirectDosing)
        {
            ProgramId = programId;
            TunnelDosingSetupId = tunneldosingsetupId;
            WasherGroupNumber = washerGroupNumber;
            WasherGroupName = washergroupName;
            NominalLoad = nominalLoad;
            LoadsPerMonth = Loadspermonth;
            TotalRuntime = Totalruntime;
            ExtraTime = Extratime;
            EcolabTextileCategoryID = Ecolabtextilecategoryid;
            StepNumber = Washstepnumber;
            InjectionNumber = Injectionnumber;
            Temperature = temperature;
            Quantity = quantity;
            Delay = Convert.ToInt16(delay);
            ProductId = productId;
            ProductName = productName;
            ProgramNumber = programNumber;
            WasherProgramSetupId = washerProgramSetupId;
            WaterType = waterType;
            WaterLevel = waterLevel;
            ControllerId = controllerId;
            ControllerEquipmentId = controllerEquipmentId;
            WasherDosingNumber = washerDosingNumber;
            DosingPointNumber = dosingPointNumber;
            ValveNumber = valveNumber;
            IsDirectDosing = isDirectDosing;
        }

        /// <summary>
        /// Gets or sets the washer dosing setup identifier.
        /// </summary>
        /// <value>
        /// The washer dosing setup identifier.
        /// </value>
        public short NominalLoad { get; set; }

        /// <summary>
        /// Gets or sets the washer dosing setup identifier.
        /// </summary>
        /// <value>
        /// The washer dosing setup identifier.
        /// </value>
        public int WasherDosingSetupId { get; set; }

        /// <summary>
        /// Gets or sets the program identifier.
        /// </summary>
        /// <value>
        /// The program identifier.
        /// </value>
        public int ProgramId { get; set; }

        /// <summary>
        /// Gets or sets the washer group number.
        /// </summary>
        /// <value>
        /// The washer group number.
        /// </value>
        public string WasherGroupNumber { get; set; }

        /// <summary>
        /// Gets or sets the injection number.
        /// </summary>
        /// <value>
        /// The injection number.
        /// </value>
        public short InjectionNumber { get; set; }

        /// <summary>
        /// Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>
        /// The controller equipment identifier.
        /// </value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>
        /// The product identifier.
        /// </value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name of Injection.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>
        /// The quantity.
        /// </value>
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets the reference load.
        /// </summary>
        /// <value>
        /// The reference load.
        /// </value>
        public int ReferenceLoad { get; set; }

        /// <summary>
        /// Gets or sets the step number.
        /// </summary>
        /// <value>
        /// The step number.
        /// </value>
        public int StepNumber { get; set; }

        /// <summary>
        /// Gets or sets the wash operation identifier.
        /// </summary>
        /// <value>
        /// The wash operation identifier.
        /// </value>
        public int WashOperationId { get; set; }

        /// <summary>
        /// Gets or sets the wash operation.
        /// </summary>
        /// <value>
        /// The wash operation.
        /// </value>
        public string WashOperation { get; set; }

        /// <summary>
        /// Gets or sets the injection class.
        /// </summary>
        /// <value>
        /// The injection class.
        /// </value>
        public string InjectionClass { get; set; }

        /// <summary>
        /// Gets or sets the type of the controller.
        /// </summary>
        /// <value>
        /// The type of the controller.
        /// </value>
        public int ControllerType { get; set; }

        /// <summary>
        /// Gets or sets the controller identifier.
        /// </summary>
        /// <value>
        /// The controller identifier.
        /// </value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the washer program setup identifier.
        /// </summary>
        /// <value>
        /// The washer program setup identifier.
        /// </value>
        public int WasherProgramSetupId { get; set; }

        /// <summary>
        /// Gets or sets CoolDownStep
        /// </summary>
        /// <value>
        /// The cool down step.
        /// </value>
        public int CoolDownStep { get; set; }

        /// <summary>
        /// Gets or sets the Water Type
        /// </summary>
        /// <value>
        /// The type of the water.
        /// </value>
        public string WaterType { get; set; }

        /// <summary>
        /// Gets or sets the Water Level
        /// </summary>
        /// <value>
        /// The water level.
        /// </value>
        public decimal? WaterLevel { get; set; }

        /// <summary>
        /// Gets or sets the WaterInlet/Drain
        /// </summary>
        /// <value>
        /// The water inlet drain.
        /// </value>
        public string WaterInletDrain { get; set; }

        /// <summary>
        /// Gets or sets the Temperature
        /// </summary>
        /// <value>
        /// The temperature.
        /// </value>
        public int Temperature { get; set; }

        /// <summary>
        /// Gets or sets the TotalRunTime
        /// </summary>
        /// <value>
        /// The total run time.
        /// </value>
        public int TotalRuntime { get; set; }

        /// <summary>
        /// Gets or sets the ExtraTime
        /// </summary>
        /// <value>
        /// The extra time.
        /// </value>
        public int ExtraTime { get; set; }

        /// <summary>
        /// Gets or sets the name of the washer group.
        /// </summary>
        /// <value>
        /// The name of the washer group.
        /// </value>
        public string WasherGroupName { get; set; }

        /// <summary>
        /// Gets or sets WashStepNumber
        /// </summary>
        /// <value>
        /// The wash step number.
        /// </value>
		public int WashStepNumber { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public int EcolabTextileCategoryID { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public short Delay { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public int NoOfWashSteps { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// The Ecolab Textile Category Id.
        /// </value>
        public short LoadsPerMonth { get; set; }

        /// <summary>
        /// Gets or sets the TunnelDosing SetupId
        /// </summary>
        /// <value>
        /// The tunnel dosing setup identifier.
        /// </value>
        public int TunnelDosingSetupId { get; set; }

        /// <summary>
        /// Gets or sets the Product Name
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the Program Number
        /// </summary>
        /// <value>
        /// The program number.
        /// </value>
        public short ProgramNumber { get; set; }

        /// <summary>
        /// Gets or sets the RunTime of Injection
        /// </summary>
        /// <value>
        /// The run time.
        /// </value>
        public int Runtime { get; set; }

        /// <summary>
        /// Gets or sets the Drain Destination
        /// </summary>
        /// <value>
        /// The drain destination.
        /// </value>
        public int DrainDestination { get; set; }

        /// <summary>
        /// Gets or sets the Washer Dosing Number
        /// </summary>
        /// <value>
        /// The washer dosing number.
        /// </value>
        public int WasherDosingNumber { get; set; }

        /// <summary>
        /// Gets or sets the Washer Dosing Product Mapping Id
        /// </summary>
        /// <value>
        /// The washer dosing product mapping identifier.
        /// </value>
        public int WasherDosingProductMappingId { get; set; }

        /// <summary>
        /// Gets or sets the Dosing Point Number
        /// </summary>
        /// <value>
        /// The dosing point number.
        /// </value>
        public byte DosingPointNumber { get; set; }

        /// <summary>
        /// Gets or sets the Valve Number
        /// </summary>
        /// <value>
        /// The valve number.
        /// </value>
        public byte ValveNumber { get; set; }

        /// <summary>
        /// Gets or sets the Is Direct Dosing
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is direct dosing; otherwise, <c>false</c>.
        /// </value>
        public bool IsDirectDosing { get; set; }
    }
}