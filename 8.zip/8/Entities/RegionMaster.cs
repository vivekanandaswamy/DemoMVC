﻿// -----------------------------------------------------------------------
// <copyright file="RegionMaster.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>The Region Master </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities
{
    /// <summary>
    ///     class Region Master
    /// </summary>
    public class RegionMaster
    {
        #region "Constructor"
        /// <summary>
        /// Default constructor RegionMaster
        /// </summary>
        public RegionMaster()
        {

        }

        /// <summary>
        /// parametrized constructor RegionMaster
        /// </summary>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="regionName">Name of the region.</param>
        /// <param name="myServiceRegionCode">My service region code.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        public RegionMaster(Int16 regionId, string regionName, string myServiceRegionCode, DateTime lastModifiedTime)
        {
            this.RegionId = regionId;
            this.RegionName = regionName;
            this.MyServiceRegionCode = myServiceRegionCode;
            this.LastModifiedTime = lastModifiedTime;
        }

        #endregion

        #region "Properties"
        /// <summary>
        /// Gets or sets RegionId
        /// </summary>
        public short RegionId { get; set; }

        /// <summary>
        /// Gets or sets RegionName
        /// </summary>
        public string RegionName { get; set; }

        /// <summary>
        /// Gets or sets MyServiceRegionCode
        /// </summary>
        public string MyServiceRegionCode { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTime
        /// </summary>
        public DateTime LastModifiedTime { get; set; }

        #endregion
    }
}