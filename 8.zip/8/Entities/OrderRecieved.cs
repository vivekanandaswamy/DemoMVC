﻿// -----------------------------------------------------------------------
// <copyright file="OrderRecieved.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The OrderRecieved </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class OrderRecieved : BaseEntity
    {
        public OrderRecieved(Guid myserviceInventaryId, int prodId, string ecolabAccountNumber, DateTime inventoryDate, string unitSize,
                         Decimal openingQty, Decimal adjustableQty, Decimal purchaseQty, Decimal closingQty, Decimal usedQty)
        {
            MyServiceInventoryId = myserviceInventaryId;
            ProductId = prodId;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            InventoryDate = inventoryDate;
            UnitSize = unitSize;
            OpeningQuantity = openingQty;
            AdjustedQuantity = adjustableQty;
            PurcharsedQuantity = purchaseQty;
            ClosingQuantity = closingQty;
            UsedQuantity = usedQty;

        }

        public OrderRecieved(int id, string ecolabAccountNumber, int prodId, DateTime inventoryDate, string unitSize,
                         Decimal openingQty, Decimal adjustableQty, Decimal purchaseQty, Decimal closingQty, Decimal usedQty, Guid myserviceInventaryId)
        {
            Id = id;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            MyServiceInventoryId = myserviceInventaryId;
            ProductId = prodId;
            InventoryDate = inventoryDate;
            UnitSize = unitSize;
            OpeningQuantity = openingQty;
            AdjustedQuantity = adjustableQty;
            PurcharsedQuantity = purchaseQty;
            ClosingQuantity = closingQty;
            UsedQuantity = usedQty;
        }

        public OrderRecieved()
        {

        }

        public int ProductId { get; set; }

        public DateTime InventoryDate { get; set; }

        public string UnitSize { get; set; }

        public Decimal OpeningQuantity { get; set; }

        public Decimal AdjustedQuantity { get; set; }

        public Decimal PurcharsedQuantity { get; set; }

        public Decimal ClosingQuantity { get; set; }

        public Decimal UsedQuantity { get; set; }

        public Guid MyServiceInventoryId { get; set; }
    }
}
