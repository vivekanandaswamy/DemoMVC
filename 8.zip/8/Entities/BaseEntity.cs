﻿// -----------------------------------------------------------------------
// <copyright file="BaseEntity.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The BaseEntity object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
	/// <summary>
	///     Base Entity Class
	/// </summary>
	public class BaseEntity
	{

		public BaseEntity(string ecolabAccountNumber)
		{
			EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
		}

		public BaseEntity(string ecolabAccountNumber, int plantId)
		{
			EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
			PlantId = plantId;
		}

		public BaseEntity()
		{
			
		}

		/// <summary>
		///     Gets or sets the id.
		/// </summary>
		/// <value>The id. field</value>
		public int Id { get; set; }

		/// <summary>
		///     Gets or sets the EcolabAccountNumber.
		/// </summary>
		/// <value> Ecolab Account Number. </value>
		public string EcolabAccountNumber { get; set; }

		/// <summary>
		///     Gets or sets the IsDeleted.
		/// </summary>
		/// <value> Is Deleted. </value>
		public bool IsDeleted { get; set; }

		/// <summary>
		///     Gets or sets the PlantId
		/// </summary>
		/// <value>The Plant Id</value>
		public int PlantId { get; set; }
	}
}