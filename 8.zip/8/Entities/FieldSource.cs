// -----------------------------------------------------------------------
// <copyright file="FieldSource.cs" company="Ecolab">
// �2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FieldSource object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     Class FieldSource
    /// </summary>
    public class FieldSource
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="FieldSource" /> class.
        /// </summary>
        /// <param name="dataSourceId">The data source id.</param>
        /// <param name="name">The name.</param>
        /// <param name="value">The value.</param>
        public FieldSource(int dataSourceId, string name, string value)
        {
            this.DataSourceId = dataSourceId;
            this.Name = name;
            this.Value = value;
        }

        /// <summary>
        ///     Gets or sets the data source id.
        /// </summary>
        /// <value>The data source id.</value>
        public int DataSourceId { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public string Value { get; set; }
    }
}