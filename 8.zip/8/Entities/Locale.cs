﻿// -----------------------------------------------------------------------
// <copyright file="Locale.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Locale object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     class Locale
    /// </summary>
    public class Locale
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="Locale" /> class.
        /// </summary>
        /// <param name="key">The key value</param>
        /// <param name="value">the value of the language</param>
        public Locale(string key, string value)
        {
            this.Key = key;
            this.Value = value;
        }

        public Locale(int unitSystemId,string unit,string subunit,string usageKey,string key,string value,int languageID)
        {
            this.Key = key;
            this.Key = usageKey;
            this.Value = value;
            this.UnitSystemId = unitSystemId;
            this.Unit = unit;
            this.Subunit = subunit;
            this.LanguageId = languageID;
        }

        #endregion

        /// <summary>
        ///     Gets or sets the Key.
        /// </summary>
        /// <value>The Key. field</value>
        public string Key { get; set; }

        /// <summary>
        ///     Gets or sets the Value.
        /// </summary>
        /// <value>The Value. field</value>
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets the unit system identifier.
        /// </summary>
        /// <value>The unit system identifier.</value>
        public int UnitSystemId { get; set; }
        /// <summary>
        /// Gets or sets the unit.
        /// </summary>
        /// <value>The unit.</value>
        public string Unit { get; set; }
        /// <summary>
        /// Gets or sets the subunit.
        /// </summary>
        /// <value>The subunit.</value>
        public string Subunit { get; set; }
        /// <summary>
        /// Gets or sets the language identifier.
        /// </summary>
        /// <value>The language identifier.</value>
        public int LanguageId { get; set; }
    }
}