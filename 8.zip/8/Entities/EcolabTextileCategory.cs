﻿// <copyright file="EcolabTextileCategory.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The EcolabTextileCategory object</summary>

namespace Entities
{
    using System;
    public class EcolabTextileCategory
    {
        #region "Constructor"

        /// <summary>
        /// Ecolab Textile Category
        /// </summary>
        /// <param name="textileId">The textile Id .</param>
        /// <param name="categoryName">The category Name.</param>
        public EcolabTextileCategory(int textileId, string categoryName)
        {
            this.TextileId = textileId;
            this.CategoryName = categoryName;
        }

        /// <summary>
        /// Ecolab Textile Category
        /// </summary>
        /// <param name="categoryName">The category Name.</param>
        /// <param name="regionCode">The Region Code</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceMstrLnnTypId">My service MSTR LNN typ identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="spSp">The sp sp.</param>
        /// <param name="nrNR">The nr nr.</param>
        /// <param name="nlBE">The nl be.</param>
        public EcolabTextileCategory(string categoryName, string regionCode, bool isDeleted, int myServiceMstrLnnTypId, DateTime myServiceLastSynchTime, string spSp, string nrNR, string nlBE)
        {
            this.CategoryName = categoryName;
            this.RegionCode = regionCode;
            this.IsDeleted = isDeleted;
            this.MyServiceMstrLnnTypId = myServiceMstrLnnTypId;
            this.MyServiceLastSynchTime = myServiceLastSynchTime;
            sp_SP = spSp;
            nr_NR = nrNR;
            nl_BE = nlBE;
        }

        /// <summary>
        ///     default constructor EcolabTextileCategory
        /// </summary>
        public EcolabTextileCategory()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets TextileID
        /// </summary>
        /// <value>TextileID .</value>
        public int TextileId { get; set; }

        /// <summary>
        ///     Gets or sets CategoryName
        /// </summary>
        /// <value>Category Name.</value>
        public string CategoryName { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value>IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceMstrLnnTypId
        /// </summary>
        /// <value>MyServiceMstrLnnTypId.</value>
        public int MyServiceMstrLnnTypId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        /// <summary>
        ///     Gets or sets the RegionCode
        /// </summary>
        /// <value>The Parameter RegionCode</value>
        public string RegionCode { get; set; }

        #endregion
    }
}