﻿// -----------------------------------------------------------------------
// <copyright file="ReportRibbonOptions.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Ribbon Options class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    ///     Entity class for ReportRibbonOptions
    /// </summary>
    public class ReportRibbonOptions : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="isChartDisplay">is Chart Display</param>
        /// <param name="columnId">Column Id</param>
        /// <param name="columnName">Column Name</param>
        /// <param name="reportId">Report id</param>
        /// <param name="displayOrder">Display Order</param>
        /// <param name="viewModeId">The view mode identifier.</param>
        /// <param name="viewModeName">Name of the view mode.</param>
        /// <param name="isVisible">if set to <c>true</c> [is visible].</param>
        /// <param name="subViewName">Name of the sub view.</param>
        /// <param name="chartType">Type of the chart.</param>
        /// <param name="isDefault">if set to <c>true</c> [is default].</param>
        /// <param name="hasGroupBy">if set to <c>true</c> [Show GroupBy]</param>
        /// <param name="subViewId">The sub view identifier.</param>
        public ReportRibbonOptions(
            bool isChartDisplay,
            int columnId,
            string columnName,
            int reportId,
            int displayOrder,
            int viewModeId,
            string viewModeName,
            bool isVisible,
            string subViewName,
            string chartType,
            bool isDefault,
            bool hasGroupBy,
            int subViewId
            )
        {
            this.IsChartDisplay = isChartDisplay;
            this.ColumnId = columnId;
            this.ColumnName = columnName;
            this.ReportId = reportId;
            this.DisplayOrder = displayOrder;
            this.ViewModeId = viewModeId;
            this.ViewModeName = viewModeName;
            this.IsVisible = isVisible;
            this.SubViewName = subViewName;
            this.ChartType = chartType;
            this.IsDefault = isDefault;
            this.HasGroupBy = hasGroupBy;
            this.SubViewId = subViewId;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ReportRibbonOptions()
        {
        }

        /// <summary>
        ///     Get or Set the IsChartDisplay
        /// </summary>
        /// <value> Is Chart Display value </value>
        public bool IsChartDisplay { get; set; }

        /// <summary>
        ///     Get or Set the SwitchModeId
        /// </summary>
        /// <value> Switch ModeId value </value>
        public int SwitchModeId { get; set; }

        /// <summary>
        ///     Get or Set the SwitchName
        /// </summary>
        /// <value> SwitchName value </value>
        public string SwitchName { get; set; }

        /// <summary>
        ///     Get or Set the ColumnId
        /// </summary>
        /// <value> ColumnId value </value>
        public int ColumnId { get; set; }

        /// <summary>
        ///     Get or Set the ColumnName
        /// </summary>
        /// <value> ColumnName value </value>
        public string ColumnName { get; set; }

        /// <summary>
        ///     Get or Set the ReportFilterId
        /// </summary>
        /// <value> ReportFilterId value </value>
        public int ReportFilterId { get; set; }

        /// <summary>
        ///     Get or Set the FilterName
        /// </summary>
        /// <value> FilterName value </value>
        public string FilterName { get; set; }

        /// <summary>
        ///     Get or Set the ReportId
        /// </summary>
        /// <value> Report Id value </value>
        public int ReportId { get; set; }

        /// <summary>
        ///     Get or Set the DisplayOrder
        /// </summary>
        /// <value> DisplayOrder value </value>
        public int DisplayOrder { get; set; }

        /// <summary>
        ///     Get or Set the ViewModeId
        /// </summary>
        /// <value> ViewModeId value </value>
        public int ViewModeId { get; set; }

        /// <summary>
        ///     Get or Set the ViewModeName
        /// </summary>
        /// <value> ViewModeName value </value>
        public string ViewModeName { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>IsVisible value.</value>
        public bool IsVisible { get; set; }

        /// <summary>
        ///     Get or Set the SubViewName
        /// </summary>
        /// <value> SubViewName value </value>
        public string SubViewName { get; set; }

        /// <summary>
        ///     Get or Set the ChartType
        /// </summary>
        /// <value> ChartType value </value>
        public string ChartType { get; set; }

        /// <summary>
        ///     Get or Set the IsDefault
        /// </summary>
        /// <value> IsDefault value </value>
        public bool IsDefault { get; set; }

        /// <summary>
        ///     Gets or Sets HasGroupBy
        /// </summary>
        /// <value>Has GeoupBy value</value>
        public bool HasGroupBy { get; set; }

        /// <summary>
        ///     Get or Set the SubViewId
        /// </summary>
        /// <value> SubViewId value </value>
        public int SubViewId { get; set; }
    }
}