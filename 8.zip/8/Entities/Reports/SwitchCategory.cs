﻿// -----------------------------------------------------------------------
// <copyright file="SwitchCategory.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Ribbon Option class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    ///     Entity class for RibbonOption
    /// </summary>
    public class SwitchCategory : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="id">Switch category id.</param>
        /// <param name="switchName">Switch category name.</param>
        public SwitchCategory(int id, string switchName)
        {
            this.Id = id;
            this.SwitchName = switchName;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public SwitchCategory()
        {
        }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value>Switch category name.</value>
        public string SwitchName { get; set; }
    }
}