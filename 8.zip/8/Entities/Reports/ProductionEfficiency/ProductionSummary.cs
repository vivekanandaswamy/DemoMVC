﻿// -----------------------------------------------------------------------
// <copyright file="ProductionSummary.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductionSummary </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports.ProductionEfficiency
{
    /// <summary>
    ///     Entity class for ProductionSummary
    /// </summary>
    public class ProductionSummary
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="period">The period.</param>
        /// <param name="actualProduction">total load value</param>
        /// <param name="washerEfficiency">The washer efficiency.</param>
        /// <param name="targetProduction">target load value</param>
        /// <param name="noOfLoads">number Of batches</param>
        /// <param name="actualRuntime">The actual run time.</param>
        /// <param name="targetRuntime">The target run time.</param>
        /// <param name="viewType">Type of the view.</param>
        /// <param name="subview">The subview.</param>
        /// <param name="id">The identifier.</param>
        /// <param name="shiftId">The Shift Id</param>
        public ProductionSummary(string period, decimal actualProduction, decimal washerEfficiency, decimal targetProduction, int noOfLoads, decimal actualRuntime, decimal targetRuntime, string viewType, string subview, int id, int shiftId, decimal correctionFactor,decimal maxshiftruntime, int sortOrder)
        {
            if (viewType == "1")
            {
                Period = period;
            }
            else if (viewType == "2")
            {
                if (subview == "9")
                {
                    MachineGroup = period;
                }
                else
                {
                    Machine = period;
                }
            }

            ActualProduction = actualProduction;
            TargetProduction = targetProduction;
            NoOfLoads = noOfLoads;
            WasherEfficiency = washerEfficiency;
            ActualRuntime = actualRuntime;
            TargetRuntime = targetRuntime;
            ViewType = viewType;
            SubView = subview;
            Id = id;
            ShiftId = shiftId;
            CorrectionFactor = correctionFactor;
            Maxshiftruntime = System.Convert.ToDouble(maxshiftruntime);
            SortOrder = sortOrder;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ProductionSummary()
        {
        }

        /// <summary>
        ///     Get or Sets the Period
        /// </summary>
        /// <value> Period value</value>
        public string Period { get; set; }

        /// <summary>
        ///     Get or Sets the TotalLoad
        /// </summary>
        /// <value> TotalLoad value</value>
        public decimal ActualProduction { get; set; }

        /// <summary>
        ///     Get or Sets the TotalLoad
        /// </summary>
        /// <value> TotalLoad value</value>
        public decimal TargetProduction { get; set; }

        /// <summary>
        ///     Get or Sets the NumberOfBatches
        /// </summary>
        /// <value> NumberOfBatches value</value>
        public int NoOfLoads { get; set; }

        /// <summary>
        ///     Get or Sets the LoadPerHour
        /// </summary>
        /// <value> LoadPerHour value</value>
        public decimal Actualproductionhour { get; set; }

        /// <summary>
        ///     Get or Sets the LoadPerHour
        /// </summary>
        /// <value> LoadPerHour value</value>
        public decimal Targetproductionhour { get; set; }

        /// <summary>
        ///     Get or Sets the MachineGroup
        /// </summary>
        /// <value> MachineGroup value</value>
        public string MachineGroup { get; set; }

        /// <summary>
        ///     Get or Sets the Machines
        /// </summary>
        /// <value> Machines value</value>
        public string Machine { get; set; }

        /// <summary>
        ///     Gets or sets the washer group identifier.
        /// </summary>
        /// <value>
        ///     The washer group identifier.
        /// </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Get or Sets the Runtime
        /// </summary>
        /// <value> Runtime value</value>
        public decimal Runtime { get; set; }

        /// <summary>
        /// Gets or sets the washer efficiency.
        /// </summary>
        /// <value>
        /// The washer efficiency.
        /// </value>
        public decimal WasherEfficiency { get; set; }

        /// <summary>
        /// Gets or sets the actual run time.
        /// </summary>
        /// <value>
        /// The actual run time.
        /// </value>
        public decimal ActualRuntime { get; set; }

        /// <summary>
        /// Gets or sets the target run time.
        /// </summary>
        /// <value>
        /// The target run time.
        /// </value>
        public decimal TargetRuntime { get; set; }

        /// <summary>
        /// Gets or sets the type of the view.
        /// </summary>
        /// <value>
        /// The type of the view.
        /// </value>
        public string ViewType { get; set; }

        /// <summary>
        /// Gets or sets the sub view.
        /// </summary>
        /// <value>
        /// The sub view.
        /// </value>
        public string SubView { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the shift identifier.
        /// </summary>
        /// <value>
        /// The shift identifier.
        /// </value>
        public int ShiftId { get; set; }

        /// <summary>
        /// Gets or sets the correction factor.
        /// </summary>
        /// <value>
        /// The correction factor.
        /// </value>
        public decimal CorrectionFactor { get; set; }

        /// <summary>
        /// Gets or sets the maxshiftruntime.
        /// </summary>
        /// <value>
        /// The maxshiftruntime.
        /// </value>
        public double Maxshiftruntime { get; set; }

        public int SortOrder { get; set; }
    }
}