﻿// -----------------------------------------------------------------------
// <copyright file="ProductionMix.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductionMix </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports.ProductionEfficiency
{
    using System;
    /// <summary>
    ///     Entity class for ProductionMix
    /// </summary>
    public class ProductionMix
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="shiftId">The shift identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="actualProduction">total Load</param>
        /// <param name="washerEfficiency">The washer efficiency.</param>
        /// <param name="targetProduction">targetLoad</param>
        /// <param name="standardLoad">The standard load.</param>
        /// <param name="noOfLoads">numberOfLoads</param>
        /// <param name="actualRuntime">The actual run time.</param>
        /// <param name="targetRuntime">The target run time.</param>
        /// <param name="numberOfPieces">numberOfPieces</param>
        /// <param name="rewash">rewash</param>
        /// <param name="viewType">Type of the view.</param>
        /// <param name="subview">The subview.</param>
        /// <param name="id">The identifier.</param>
        public ProductionMix(int shiftId, string name, decimal actualProduction, decimal washerEfficiency, decimal targetProduction, decimal standardLoad, int noOfLoads, 
                            decimal actualRuntime, decimal targetRuntime, int numberOfPieces, decimal rewash, string viewType, string subview, int id, decimal correctionFactor, 
                            decimal maxshiftruntime, int sortOrder, double loadEfficiencyMaxCap)
        {
            if (viewType == "1")
            {
                Interval = name;
            }
            else if (viewType == "2")
            {
                Location = name;
            }
            else if (viewType == "3")
            {
                if (subview == "12")
                { TextileCategoryEcolab = name; }
                else
                { Formula = name; }
            }
            else if (viewType == "4")
            {
                if (subview == "15")
                { TextileCategory = name; }
                else
                { Formula = name; }
            }
            else if (viewType == "5")
            {
                if (subview == "16")
                { ChainCategory = name; }
                else
                { Formula = name; }
            }
            else if (viewType == "6")
            {
                if (name == null)
                {
                    Customer = "Not assigned";
                }
                else
                {
                    Customer = name;
                }
            }
            else if (viewType == "7" || viewType == "8")
            {
                Formula = name;
            }

            ActualProduction = actualProduction;
            TargetProduction = targetProduction;
            NoOfLoads = noOfLoads;
            NumberOfPieces = numberOfPieces;
            RewashLoad = rewash;
            ShiftId = shiftId;
            WasherEfficiency = washerEfficiency;
            StandardLoad = standardLoad;
            ActualRuntime = Convert.ToDouble(actualRuntime);
            TargetRuntime = Convert.ToDouble(targetRuntime);
            ViewType = viewType;
            SubView = subview;
            Id = id;
            CorrectionFactor = correctionFactor;
            Maxshiftruntime = Convert.ToDouble(maxshiftruntime);
            SortOrder = sortOrder;
            LoadEfficiencyMaxCap = loadEfficiencyMaxCap;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ProductionMix()
        {
        }

        /// <summary>
        ///     Get or Sets the FormulaName
        /// </summary>
        /// <value> FormulaName value</value>
        public string FormulaName { get; set; }

        /// <summary>
        ///     Get or Sets the TotalLoad
        /// </summary>
        /// <value> TotalLoad value</value>
        public decimal ActualProduction { get; set; }

        /// <summary>
        ///     Get or Sets the TotalLoad
        /// </summary>
        /// <value> TotalLoad value</value>
        public decimal TargetProduction { get; set; }

        /// <summary>
        ///     Get or Sets the TotalLoad
        /// </summary>
        /// <value> TotalLoad value</value>
        public decimal ProductionDiff { get; set; }

        /// <summary>
        ///     Get or Sets the TotalLoad
        /// </summary>
        /// <value> TotalLoad value</value>
        public decimal LoadEfficiency { get; set; }

        /// <summary>
        ///     Get or Sets the ProductionMixValue
        /// </summary>
        /// <value> ProductionMixValue value</value>
        public decimal ProductionMixValue { get; set; }

        /// <summary>
        ///     Get or Sets the ActualProductionperhour
        /// </summary>
        /// <value> ActualProductionperhour value</value>
        public decimal Actualproductionhour { get; set; }

        /// <summary>
        ///     Get or Sets the TargetProductionperhour
        /// </summary>
        /// <value> TargetProductionperhour value</value>
        public decimal Targetproductionhour { get; set; }

        /// <summary>
        ///     Get or Sets the NumberOfLoads
        /// </summary>
        /// <value> NumberOfLoads value</value>
        public int NoOfLoads { get; set; }

        /// <summary>
        ///     Get or Sets the NumberOfPieces
        /// </summary>
        /// <value> NumberOfPieces value</value>
        public int NumberOfPieces { get; set; }

        /// <summary>
        ///     Get or Sets the Rewash
        /// </summary>
        /// <value> Rewash value</value>
        public decimal RewashLoad { get; set; }

        /// <summary>
        ///     Get or Sets the SwitchModeName
        /// </summary>
        /// <value> SwitchModeName value</value>
        public string SwitchModeName { get; set; }

        /// <summary>
        ///     Get or Sets the TextileCategoryEcolab
        /// </summary>
        /// <value> Textile Category Ecolab value</value>
        public string TextileCategoryEcolab { get; set; }

        /// <summary>
        ///     Get or Sets the TextileCategoryCustomer
        /// </summary>
        /// <value> Textile Category Customer value</value>
        public string TextileCategoryCustomer { get; set; }

        /// <summary>
        ///     Get or Sets the ChainFormula
        /// </summary>
        /// <value> Chain Formula value</value>
        public string ChainFormula { get; set; }

        /// <summary>
        ///     Gets or sets the program identifier.
        /// </summary>
        /// <value>
        ///     The program identifier.
        /// </value>
        public int? ProgramId { get; set; }

        /// <summary>
        /// Gets or sets the DateRange.
        /// </summary>
        /// <value>
        /// The DateRange value.
        /// </value>
        public string Interval { get; set; }

        /// <summary>
        ///     Get or Sets the RecordDate
        /// </summary>
        /// <value> RecordDate value</value>
        public string Period { get; set; }

        /// <summary>
        ///     Get or Sets the Runtime
        /// </summary>
        /// <value> Runtime value</value>
        public decimal Runtime { get; set; }

        /// <summary>
        /// Gets or sets the washer efficiency.
        /// </summary>
        /// <value>
        /// The washer efficiency.
        /// </value>
        public decimal WasherEfficiency { get; set; }

        /// <summary>
        /// Gets or sets the actual run time.
        /// </summary>
        /// <value>
        /// The actual run time.
        /// </value>
        public double ActualRuntime { get; set; }

        /// <summary>
        /// Gets or sets the target run time.
        /// </summary>
        /// <value>
        /// The target run time.
        /// </value>
        public double TargetRuntime { get; set; }

        /// <summary>
        /// Gets or sets the type of the view.
        /// </summary>
        /// <value>
        /// The type of the view.
        /// </value>
        public string ViewType { get; set; }

        /// <summary>
        /// Gets or sets the sub view.
        /// </summary>
        /// <value>
        /// The sub view.
        /// </value>
        public string SubView { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the shift identifier.
        /// </summary>
        /// <value>
        /// The shift identifier.
        /// </value>
        public int ShiftId { get; set; }

        /// <summary>
        /// Gets or sets the standard load.
        /// </summary>
        /// <value>
        /// The standard load.
        /// </value>
        public decimal StandardLoad { get; set; }

        /// <summary>
        /// Get or Sets the FormulaName
        /// </summary>
        /// <value> FormulaName value</value>
        public string Location { get; set; }

        /// <summary>
        /// Get or Sets the FormulaName
        /// </summary>
        /// <value> FormulaName value</value>
        public string Formula { get; set; }

        /// <summary>
        /// Get or Sets the TextileCategoryCustomer
        /// </summary>
        /// <value> Textile Category Customer value</value>
        public string TextileCategory { get; set; }

        /// <summary>
        /// Get or Sets the ChainFormula
        /// </summary>
        /// <value> Chain Formula value</value>
        public string ChainCategory { get; set; }

        /// <summary>
        /// Get or Sets the CustomerName
        /// </summary>
        /// <value> Chain Formula value</value>
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets the correction factor.
        /// </summary>
        /// <value>
        /// The correction factor.
        /// </value>
        public decimal CorrectionFactor { get; set; }

        /// <summary>
        /// Gets or sets the correction factor.
        /// </summary>
        /// <value>
        /// The correction factor.
        /// </value>
        public double Maxshiftruntime { get; set; }

        public int SortOrder { get; set; }

        /// <summary>
        /// Gets or sets the Load Efficiency Max Cap.
        /// </summary>
        /// <value>
        /// The Load Efficiency Max Cap.
        /// </value>
        public double LoadEfficiencyMaxCap { get; set; }
    }
}