﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalInventory.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemical Inventory Access </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports.ResourcesUtilization
{
    /// <summary>
    ///     Entity class for ChemicalInventory
    /// </summary>
    public class ChemicalInventory
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="chemicalName"></param>
        /// <param name="inventoryDateRange"></param>
        /// <param name="lastInventory"></param>
        /// <param name="inventoryBasedConsumption"></param>
        /// <param name="dispencerBasedConsumption"></param>
        /// <param name="todayEstimateInventory"></param>
        /// <param name="avgDailyNeeds"></param>
        /// <param name="avgDailyCost"></param>
        /// <param name="avgDailyCostPerLoad"></param>
        /// <param name="avgDailyNeedsLy"></param>
        /// <param name="dayBeforeOutOfStock"></param>
        /// <param name="unitSize"></param>
        /// <param name="avgDailyNeedsForInventoryPeriod"></param>
        public ChemicalInventory(int productId, string chemicalName, string inventoryDateRange, decimal lastInventory, decimal inventoryBasedConsumption, decimal dispencerBasedConsumption, decimal todayEstimateInventory, decimal avgDailyNeeds, decimal avgDailyCost, decimal avgDailyCostPerLoad, decimal avgDailyNeedsLy, int dayBeforeOutOfStock, string unitSize, decimal avgDailyNeedsForInventoryPeriod)
        {
            ProductId = productId; 
            this.ChemicalName = chemicalName;
            this.InventoryDateRange = inventoryDateRange;
            this.LastInventory = lastInventory;
            this.InventoryBasedConsumption = inventoryBasedConsumption;
            this.DispencerBasedConsumption = dispencerBasedConsumption;
            this.TodayEstimateInventory = todayEstimateInventory;
            this.AvgDailyNeeds = avgDailyNeeds;
            this.AvgDailyCost =System.Convert.ToDecimal( avgDailyCost);
            this.AvgDailyCostPerLoad = System.Convert.ToDecimal(avgDailyCostPerLoad);
            this.AvgDailyNeedsLy = avgDailyNeedsLy;
            this.DayBeforeOutOfStock = dayBeforeOutOfStock;
            this.UnitSize = unitSize;
            this.AvgDailyNeedsForInventoryPeriod = avgDailyNeedsForInventoryPeriod;
            
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ChemicalInventory()
        {
        }

        /// <summary>
        /// Get or Sets the ProductId        
        /// </summary>
        /// <value>Product Id value</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Get or Sets the ChemicalName
        /// </summary>
        /// <value>Chemical Name value</value>
        public string ChemicalName { get; set; }

        /// <summary>
        ///     Get or Sets the InventoryDateRange
        /// </summary>
        /// <value>InventoryDateRange  value</value>
        public string InventoryDateRange { get; set; }

        /// <summary>
        ///     Get or Sets the LastActualInventory
        /// </summary>
        /// <value>Last Actual Inventory value</value>
        public decimal LastInventory { get; set; }

        /// <summary>
        ///     Get or Sets the LastInventoryDate
        /// </summary>
        /// <value>Last Inventory Date value</value>
        public decimal InventoryBasedConsumption { get; set; }

        /// <summary>
        ///     Get or Sets the OrdersReceived
        /// </summary>
        /// <value>Orders Received value</value>
        public decimal DispencerBasedConsumption { get; set; }

        /// <summary>
        ///     Get or Sets Today Estimate Inventory
        /// </summary>
        /// <value>Today Estimate Inventory value</value>
        public decimal TodayEstimateInventory { get; set; }

        /// <summary>
        ///     Get or Sets the AvgDailyNeeds
        /// </summary>
        /// <value>AvgDailyNeeds value</value>
        public decimal AvgDailyNeeds { get; set; }

        /// <summary>
        ///     Get or Sets the AvgDailyCost
        /// </summary>
        /// <value>AvgDaily Cost value</value>
        public decimal AvgDailyCost { get; set; }

        /// <summary>
        ///     Get or Sets the AvgDailyCostPerLoad
        /// </summary>
        /// <value>AvgDailyCost Per Load value</value>
        public decimal AvgDailyCostPerLoad { get; set; }

        /// <summary>
        ///     Get or Sets the AvgDailyNeedsLY
        /// </summary>
        /// <value>AvgDaily Needs Last Year value</value>
        public decimal AvgDailyNeedsLy { get; set; }

        /// <summary>
        ///     Get or Sets the ProductId
        /// </summary>
        /// <value>Product Id value</value>
        public int DayBeforeOutOfStock { get; set; }

        /// <summary>
        ///     Get or Sets the UnitSize
        /// </summary>
        /// <value>Unit Size value</value>
        public string UnitSize { get; set; }

        /// <summary>
        ///     Get or Sets the AvgDaily NeedsFor InventoryPeriod
        /// </summary>
        /// <value>AvgDailyNeeds For Inventory Period</value>
        public decimal AvgDailyNeedsForInventoryPeriod { get; set; }
    }
}