﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalConsumption.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ChemicalConsumption </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports.ResourcesUtilization
{
    public class ChemicalConsumption
    {
        public ChemicalConsumption()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="ChemicalConsumption" /> class.
        /// </summary>
        /// <param name="chemicalName">Name of the chemical.</param>
        /// <param name="totalConsumption">The actual Consumption.</param>
        /// <param name="targetConsumption">The target consumption.</param>
        /// <param name="programCount">The program Count.</param>
        /// <param name="noOfLoads">The number of loads.</param>
        /// <param name="noOfDays">The no of days.</param>
        /// <param name="cost">The cost.</param>
        /// <param name="targetCost">The target cost</param>
        /// <param name="totalConsumptionMetrics">The total Consumption metrics </param>
        public ChemicalConsumption(string chemicalName, decimal totalConsumption, decimal targetConsumption, int programCount, decimal noOfLoads, int noOfDays, decimal cost, decimal targetCost, decimal totalConsumptionMetrics, string uom, int viewType)
        {
            if (viewType == 10)
            {
                this.ChemicalName = chemicalName;
                this.CategoryName = "0";
                this.Cost = cost;
            }
            else if (viewType == 11)
            {
                this.ChemicalName = "0";
                this.CategoryName = chemicalName;
                this.CategoryCost = cost;
            }            
            this.TotalConsumption = totalConsumption;
            this.TargetConsumption = targetConsumption;
            this.ProgramCount = programCount;
            this.NoOfDays = noOfDays;
            this.NoOfLoads = noOfLoads;
            
            this.TargetCost = targetCost;
            this.TotalConsumptionMetrics = totalConsumptionMetrics;
            this.ViewType = viewType;
            this.UOM = uom;
        }

        /// <summary>
        ///     Gets or sets the name of the chemical.
        /// </summary>
        /// <value>
        ///     The name of the chemical.
        /// </value>
        public string ChemicalName { get; set; }

        /// <summary>
        ///     Gets or sets the total consumption.
        /// </summary>
        /// <value>
        ///     The total consumption.
        /// </value>
        public decimal TotalConsumption { get; set; }

        /// <summary>
        ///     Gets or sets the target consumption.
        /// </summary>
        /// <value>
        ///     The target consumption.
        /// </value>
        public decimal TargetConsumption { get; set; }

        /// <summary>
        ///     Gets or sets the program Count.
        /// </summary>
        /// <value>
        ///     The program Count.
        /// </value>
        public int ProgramCount { get; set; }

        /// <summary>
        ///     Gets or sets the NoOfPrograms.
        /// </summary>
        /// <value>
        ///     The NoOfPrograms value.
        /// </value>
        public decimal NoOfLoads { get; set; }

        /// <summary>
        ///     Gets or sets the NoOfDays.
        /// </summary>
        /// <value>
        ///     The NoOfDays value.
        /// </value>
        public int NoOfDays { get; set; }

        /// <summary>
        ///     Gets or sets the acttual cost.
        /// </summary>
        /// <value>
        ///     The actual cost.
        /// </value>
        public decimal Cost { get; set; }

        /// <summary>
        ///     Gets or sets the Target Cost.
        /// </summary>
        /// <value>
        ///     The Target Cost value.
        /// </value>
        public decimal TargetCost { get; set; }

        /// <summary>
        /// Gets or sets the Total Consumption Metrics.
        /// </summary>
        /// <value>
        /// The Total Consumption Metrics value.
        /// </value>
        public decimal TotalConsumptionMetrics { get; set; }

        /// <summary>
        ///     Gets or sets the value of the UOM.
        /// </summary>
        /// <value>
        ///     The value of the UOM.
        /// </value>
        public string UOM { get; set; }

        /// <summary>
        /// Gets or sets the type of the view.
        /// </summary>
        /// <value>
        /// The type of the view.
        /// </value>
        public int ViewType { get; set; }

        /// <summary>
        /// gets or sets Chemical Category
        /// </summary>
        public string CategoryName { get; set; }

        public decimal CategoryCost { get; set; }
        public decimal ActualCategoryCost { get; set; }
    }
}