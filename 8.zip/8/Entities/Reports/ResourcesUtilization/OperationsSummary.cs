﻿// -----------------------------------------------------------------------
// <copyright file="OperationsSummary.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The OperationsSummary class</summary>
// -----------------------------------------------------------------------

using System;
using System.Net.NetworkInformation;

namespace Entities.Reports.ResourcesUtilization
{
    public class OperationsSummary
    {
        public OperationsSummary()
        {
        }

        public OperationsSummary(int shiftId, string dateRange, decimal totalLoad, int numberofbatches, decimal actualChemicalConsumption,
                                  decimal targetChemicalConsumption, decimal actualEnergyConsumption, decimal targetEnergyConsumption, decimal actualWaterConsumption, decimal targetWaterConsumption, decimal actualChemicalCost, decimal actualWaterCost, decimal actualEnergyCost, string viewType, string subview, int id, decimal actualProductionMetrics, int sortOrder)
        {
            switch (viewType)
            {
                case "1":
                    Interval = dateRange;
                    break;
                case null:
                    Interval = dateRange;
                    break;
                case "2":
                    Location = dateRange;
                    break;

                case "3":
                    switch (subview)
                    {
                        case "12":
                            TextileCategoryEcolab = dateRange;
                            break;

                        default:
                            Formula = dateRange;
                            break;
                    }
                    break;

                case "4":
                    switch (subview)
                    {
                        case "15":
                            TextileCategory = dateRange;
                            break;

                        default:
                            Formula = dateRange;
                            break;
                    }
                    break;

                case "5":
                    switch (subview)
                    {
                        case "16":
                            ChainCategory = dateRange;
                            break;

                        default:
                            Formula = dateRange;
                            break;
                    }
                    break;
                case "8":
                  
                            Formula = dateRange;
                            break;

               
            }

            ActualChemicalusage = actualChemicalConsumption;
            TargetChemicalConsumption = targetChemicalConsumption;
            ActualEnergy = actualEnergyConsumption;
            ActualWaterConsumption = actualWaterConsumption;
            TargetEnergyConsumption = targetEnergyConsumption;
            TargetWaterConsumption = targetWaterConsumption;
            ActualEnergyCost = actualEnergyCost;
            ActualWaterCost = actualWaterCost;
            AactualChemicalCost = actualChemicalCost;
            NoOfLoads = numberofbatches;
            ShiftId = shiftId;
            ActualProduction = totalLoad;
            ViewType = viewType;
            SubView = subview;
            Id = id;
            ActualProductionMetrics = actualProductionMetrics;
            SortOrder = sortOrder;
        }

        /// <summary>
        ///     Get or Sets the ShiftId
        /// </summary>
        /// <value> ShiftId value</value>
        public int ShiftId { get; set; }

        /// <summary>
        ///     Get or Sets the ActualChemicalConsumption
        /// </summary>
        /// <value> ActualChemicalConsumption value</value>
        public decimal ActualChemicalusage { get; set; }

        /// <summary>
        ///     Get or Sets the TargetChemicalConsumption
        /// </summary>
        /// <value> TargetChemicalConsumption value</value>
        public decimal TargetChemicalConsumption { get; set; }

        /// <summary>
        /// Get or Sets the ActualChemicalConsumption
        /// </summary>
        /// <value>
        /// ActualChemicalConsumption value
        /// </value>
        public decimal ActualEnergy { get; set; }

        /// <summary>
        /// Get or Sets the TargetChemicalConsumption
        /// </summary>
        /// <value>
        /// TargetChemicalConsumption value
        /// </value>
        public decimal TargetEnergyConsumption { get; set; }

        /// <summary>
        /// Get or Sets the ActualChemicalConsumption
        /// </summary>
        /// <value>
        /// ActualChemicalConsumption value
        /// </value>
        public decimal ActualWaterConsumption { get; set; }

        /// <summary>
        /// Get or Sets the AactualChemicalCost
        /// </summary>
        /// <value>
        /// AactualChemicalCost value
        /// </value>
        public decimal AactualChemicalCost { get; set; }

        /// <summary>
        /// Get or Sets the ActualWaterCost
        /// </summary>
        /// <value>
        /// ActualWaterCost value
        /// </value>
        public decimal ActualWaterCost { get; set; }

        /// <summary>
        /// Get or Sets the ActualEnergyCost
        /// </summary>
        /// <value>
        /// ActualEnergyCost value
        /// </value>
        public decimal ActualEnergyCost { get; set; }

        /// <summary>
        ///     Get or Sets the TargetChemicalConsumption
        /// </summary>
        /// <value> TargetChemicalConsumption value</value>
        public decimal TargetWaterConsumption { get; set; }

        /// <summary>
        /// Get or Sets the Number of batches
        /// </summary>
        /// <value>
        /// Number of batches value
        /// </value>
        public decimal NoOfLoads { get; set; }

        /// <summary>
        ///     Get or Sets the ActualProduction
        /// </summary>
        /// <value> ActualProduction value</value>
        public decimal ActualProduction { get; set; }

        /// <summary>
        /// Gets or sets the type of the view.
        /// </summary>
        /// <value>
        /// The type of the view.
        /// </value>
        public string ViewType { get; set; }

        /// <summary>
        /// Gets or sets the sub view.
        /// </summary>
        /// <value>
        /// The sub view.
        /// </value>
        public string SubView { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the DateRange.
        /// </summary>
        /// <value>
        /// The DateRange value.
        /// </value>
        public string Interval { get; set; }

        /// <summary>
        /// Get or Sets the FormulaName
        /// </summary>
        /// <value> FormulaName value</value>
        public string Location { get; set; }

        /// <summary>
        /// Get or Sets the FormulaName
        /// </summary>
        /// <value> FormulaName value</value>
        public string Formula { get; set; }

        /// <summary>
        /// Get or Sets the TextileCategoryCustomer
        /// </summary>
        /// <value> Textile Category Customer value</value>
        public string TextileCategory { get; set; }

        /// <summary>
        /// Get or Sets the ChainFormula
        /// </summary>
        /// <value> Chain Formula value</value>
        public string ChainCategory { get; set; }

        /// <summary>
        ///     Get or Sets the TextileCategoryEcolab
        /// </summary>
        /// <value> Textile Category Ecolab value</value>
        public string TextileCategoryEcolab { get; set; }

        /// <summary>
        /// Gets or sets the actual production metrics.
        /// </summary>
        /// <value>
        /// The actual production metrics.
        /// </value>
        public decimal ActualProductionMetrics { get; set; }
        public int SortOrder { get; set; }
    }
}