﻿// -----------------------------------------------------------------------
// <copyright file="ReportSettings.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The ReportSettings class </summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;

namespace Entities.Reports
{
    using System;

    /// <summary>
    ///     Entity class for ReportSettings
    /// </summary>
    public class ReportSettings : BaseEntity
    {
        /// <summary>
        ///     Get or Sets the Corporate
        /// </summary>
        /// <value> Corporate value</value>
        public string Corporate { get; set; }

        /// <summary>
        ///     Get or Sets the Country
        /// </summary>
        /// <value> Country value</value>
        public string Country { get; set; }

        /// <summary>
        ///     Get or Sets the Region
        /// </summary>
        /// <value> Region value</value>
        public string Region { get; set; }

        /// <summary>
        ///     Get or Sets the Controller
        /// </summary>
        /// <value> Controller value</value>
        public string Controller { get; set; }

        /// <summary>
        ///     Get or Sets the Machine
        /// </summary>
        /// <value> Machine value</value>
        public string Machine { get; set; }

        /// <summary>
        ///     Get or Sets the MachineGroup
        /// </summary>
        /// <value> MachineGroup value</value>
        public string MachineGroup { get; set; }

        /// <summary>
        ///     Get or Sets the Formula
        /// </summary>
        /// <value> Formula value</value>
        public string Formula { get; set; }

        /// <summary>
        ///     Get or Sets the MachineType
        /// </summary>
        /// <value> MachineType value</value>
        public string MachineType { get; set; }

        /// <summary>
        ///     Get or Sets the Alarm
        /// </summary>
        /// <value> Alarm value</value>
        public string Alarm { get; set; }

        /// <summary>
        ///     Get or Sets the FromDate
        /// </summary>
        /// <value> FromDate value</value>
        public DateTime FromDate { get; set; }

        /// <summary>
        ///     Get or Sets the ToDate
        /// </summary>
        /// <value> ToDate value</value>
        public DateTime ToDate { get; set; }

        /// <summary>
        ///     Get or Sets the FromDate UTC
        /// </summary>
        /// <value> FromDate UTC value</value>
        public DateTime FromDateUTC { get; set; }

        /// <summary>
        ///     Get or Sets the ToDate UTC
        /// </summary>
        /// <value> ToDate UTC value</value>
        public DateTime ToDateUTC { get; set; }

        /// <summary>
        ///     Get or Sets the GroupId
        /// </summary>
        /// <value> GroupId value</value>
        public string GroupId { get; set; }

        /// <summary>
        ///     Get or Sets the MachineInternalId
        /// </summary>
        /// <value> MachineInternalId value</value>
        public string MachineInternalId { get; set; }

        /// <summary>
        ///     Get or Sets the Category
        /// </summary>
        /// <value> Category value</value>
        public string Category { get; set; }

        /// <summary>
        ///     Get or Sets the Customer
        /// </summary>
        /// <value> Customer value</value>
        public string Customer { get; set; }

        /// <summary>
        ///     Get or Sets the DayWise
        /// </summary>
        /// <value> DayWise value</value>
        public bool IsDayWise { get; set; }

        /// <summary>
        ///     Get or Sets the WeekWise
        /// </summary>
        /// <value> WeekWise value</value>
        public bool IsWeekWise { get; set; }

        /// <summary>
        ///     Get or Sets the MonthWise
        /// </summary>
        /// <value> MonthWise value</value>
        public bool IsMonthWise { get; set; }

        /// <summary>
        ///     Get or Sets the QuarterWise
        /// </summary>
        /// <value> QuarterWise value</value>
        public bool IsQuarterWise { get; set; }

        /// <summary>
        ///     Get or Sets the IsYear
        /// </summary>
        /// <value> IsYear value</value>
        public bool IsYearWise { get; set; }

        /// <summary>
        ///     Get or Sets the FormulaWise
        /// </summary>
        /// <value> FormulaWise value</value>
        public bool IsFormulaWise { get; set; }

        /// <summary>
        ///     Get or Sets the EcolabTextileWise
        /// </summary>
        /// <value> EcolabTextileWise value</value>
        public bool IsEcolabTextileWise { get; set; }

        /// <summary>
        ///     Get or Sets the PlantTextileWise
        /// </summary>
        /// <value> PlantTextileWise value</value>
        public bool IsPlantTextileWise { get; set; }

        /// <summary>
        ///     Get or Sets the PlantFormulaWise
        /// </summary>
        /// <value> PlantFormulaWise value</value>
        public bool IsPlantFormulaWise { get; set; }

        /// <summary>
        ///     Get or Sets the IsViewByPlantWise
        /// </summary>
        /// <value> IsViewByPlantWise value</value>
        public bool IsViewByPlantWise { get; set; }

        /// <summary>
        ///     Get or Sets the DrillDownMachineGroupId
        /// </summary>
        /// <value> DrillDownMachineGroupId value</value>
        public int DrilldownMachineGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the users.
        /// </summary>
        /// <value> The users </value>
        public string Users { get; set; }

        /// <summary>
        ///     Get or Sets the UserId
        /// </summary>
        /// <value> Login UserId value</value>
        public int UserId { get; set; }

        /// <summary>
        ///     Get or Sets the SortColumnId
        /// </summary>
        /// <value> SortColumnId value</value>
        public int SortColumnId { get; set; }

        /// <summary>
        ///     Get or Sets the SortDirection
        /// </summary>
        /// <value> SortDirection value</value>
        public string SortDirection { get; set; }

        /// <summary>
        ///     Get or Sets the PageSize
        /// </summary>
        /// <value> PageSize value</value>
        public int PageSize { get; set; }

        /// <summary>
        ///     Get or Sets the PageCount
        /// </summary>
        /// <value> PageCount value</value>
        public int PageCount { get; set; }

        /// <summary>
        ///     Get or Sets the CurrentPageIndex
        /// </summary>
        /// <value> CurrentPageIndex value</value>
        public int CurrentPageIndex { get; set; }

        /// <summary>
        ///     Gets or sets the production mix identifier.
        /// </summary>
        /// <value>
        ///     The production mix identifier.
        /// </value>
        public int? ProductionMixId { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this instance is drill down.
        /// </summary>
        /// <value>
        ///     <c>true</c> if this instance is drill down; otherwise, <c>false</c>.
        /// </value>
        public bool IsDrilldown { get; set; }

        /// <summary>
        ///     Get or Sets the ActionType
        /// </summary>
        /// <value> Action Type value</value>
        public string ActionType { get; set; }

        /// <summary>
        ///     Gets or sets the switch mode identifier.
        /// </summary>
        /// <value>
        ///     The switch mode identifier.
        /// </value>
        public int SwitchModeId { get; set; }

        /// <summary>
        ///     Get or Sets ReportName
        /// </summary>
        /// <value>This Contains ReportId</value>
        public int ReportId { get; set; }

        /// <summary>
        ///     Get or Sets TextileCareCustomerWise
        /// </summary>
        /// <value>This Contains TextileCareCustomerWise</value>
        public int IsTextileCareCustomerWise { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this instance is first level.
        /// </summary>
        /// <value>
        ///     <c>true</c> if this instance is first level; otherwise, <c>false</c>.
        /// </value>
        public bool IsFirstLevel { get; set; }

        /// <summary>
        ///     Gets or sets the selected item.
        /// </summary>
        /// <value>
        ///     The selected item.
        /// </value>
        public string SelectedItem { get; set; }

        /// <summary>
        ///     Get or Sets the ViewModeId
        /// </summary>
        /// <value> ViewModeId value</value>
        public int ViewModeId { get; set; }

        /// <summary>
        ///     Get or Sets the Roleld
        /// </summary>
        /// <value> Role ld value</value>
        public int RoleId { get; set; }

        /// <summary>
        ///     Gets or sets the NeedCurrent.
        /// </summary>
        /// <value>
        ///     NeedCurrent value .
        /// </value>
        public bool NeedCurrent { get; set; }

        /// <summary>
        /// Gets or sets the UserLanguageId.
        /// </summary>
        /// <value>
        /// UserLanguageId value .
        /// </value>
        public int UserLanguageId { get; set; }

        /// <summary>
        /// Gets or sets the ViewType.
        /// </summary>
        /// <value>
        /// ViewType value .
        /// </value>
        public string ViewType { get; set; }

        /// <summary>
        /// Gets or sets the Subview.
        /// </summary>
        /// <value>
        /// Subview value .
        /// </value>
        public string SubView { get; set; }

        /// <summary>
        /// Gets or sets the DrillValue.
        /// </summary>
        /// <value>
        /// DrillValue value .
        /// </value>
        public string DrillValue { get; set; }

        /// <summary>
        /// Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value>
        /// Subview value .
        /// </value>
        public int EcolabTextileCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the IsTextileCategoryWise.
        /// </summary>
        /// <value>
        /// Subview value .
        /// </value>
        public bool IsTextileCategoryWise { get; set; }

        /// <summary>
        /// Gets or sets the TextileCategoryId.
        /// </summary>
        /// <value>
        /// Subview value .
        /// </value>
        public int TextileCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the DrillDownId.
        /// </summary>
        /// <value>
        /// DrillDownId value .
        /// </value>
        public int DrilldownId { get; set; }

        public string Plant { get; set; }

        /// <summary>
        /// Gets or sets the UserRegion.
        /// </summary>
        /// <value>
        /// UserRegion value .
        /// </value>
        public int UserRegion { get; set; }

        /// <summary>
        /// Gets or sets the UserType.
        /// </summary>
        /// <value>
        /// UserType value .
        /// </value>
        public string UserType { get; set; }

        /// <summary>
        /// Gets or sets the UserCountry.
        /// </summary>
        /// <value>
        /// UserCountry value .
        /// </value>
        public int UserCountry { get; set; }

        /// <summary>
        /// Gets or sets the UserCulture.
        /// </summary>
        /// <value>
        /// UserCulture value .
        /// </value>
        public string UserCulture { get; set; }
     
        /// <summary>
        /// Gets or sets the UserCurrency.
        /// </summary>
        /// <value>
        /// UserCurrency value .
        /// </value>
        public string UserCurrency { get; set; }

        /// <summary>
        /// Gets or sets the plants.
        /// </summary>
        /// <value>
        /// The plants.
        /// </value>
        public List<string> Plants { get; set; }

        /// <summary>
        /// Gets or sets the ecolab category.
        /// </summary>
        /// <value>
        /// The ecolab category.
        /// </value>
        public string EcolabCategory { get; set; }
        /// <summary>
        /// Gets or sets the chain category.
        /// </summary>
        /// <value>
        /// The chain category.
        /// </value>
        public string ChainCategory { get; set; }
        /// <summary>
        /// Gets or sets the chain formula.
        /// </summary>
        /// <value>
        /// The chain formula.
        /// </value>
        public string ChainFormula { get; set; }
        /// <summary>
        /// Gets or sets the plant formula.
        /// </summary>
        /// <value>
        /// The plant formula.
        /// </value>
        public string PlantFormula { get; set; }
        /// <summary>
        /// Gets or sets the sub view identifier.
        /// </summary>
        /// <value>
        /// The sub view identifier.
        /// </value>
        public int SubViewId { get; set; }
    }
}