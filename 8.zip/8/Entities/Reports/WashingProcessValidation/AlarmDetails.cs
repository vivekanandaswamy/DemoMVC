﻿// -----------------------------------------------------------------------
// <copyright file="AlarmDetails.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The AlarmDetails class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports.WashingProcessValidation
{
    using System;

    /// <summary>
    ///     Entity class for AlarmDetails
    /// </summary>
    public class AlarmDetails
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="alarmCode">The alarm code.</param>
        /// <param name="alarmDescription">alarm description</param>
        /// <param name="startDate">alarm startDate</param>
        /// <param name="endDate">alarm endDate</param>
        /// <param name="alarmDuration">alarm duration</param>
        /// <param name="controller">associated controller</param>
        /// <param name="washerNumber">washer number</param>
        /// <param name="batchId">The batch identifier.</param>
        /// <param name="valueNumber">value number</param>
        /// <param name="chemicalName">chemical name</param>
        /// <param name="injectionNumber">injection Number</param>
        /// <param name="formulaNumber">formula Number</param>
        /// <param name="formulaName">formula Name</param>
        /// <param name="desiredValue">desired Value</param>
        /// <param name="measuredValue">measuredValue</param>
        /// <param name="isActiveStatus">is active status</param>
        /// <param name="totalCount">The total count.</param>
        /// <param name="rowNo">The row no.</param>
        public AlarmDetails(int alarmCode, string alarmDescription, DateTime startDate, DateTime endDate, string alarmDuration, string controller, int? washerNumber, int? batchId, int? valueNumber, string chemicalName, int? injectionNumber, int? formulaNumber, string formulaName, decimal desiredValue, decimal measuredValue, bool isActiveStatus, int totalCount, Int64 rowNo)
        {
            this.AlarmCode = alarmCode;
            this.AlarmDescription = alarmDescription;
            this.StartDate = startDate.ToLocalTime();
            this.EndDate = endDate.ToLocalTime();
            this.AlarmDuration = alarmDuration;
            this.Controller = controller;
            this.WasherNumber = washerNumber != 0 ? washerNumber : null;
            this.BatchId = batchId != 0 ? batchId : null;
            this.ValueNumber = valueNumber != 0 ? valueNumber : null;
            this.ChemicalName = chemicalName;
            this.InjectionNumber = injectionNumber != 0 ? injectionNumber : null;
            this.FormulaNumber = formulaNumber != 0 ? formulaNumber : null;
            this.FormulaName = formulaName;
            this.DesiredValue = desiredValue;
            this.MeasuredValue = measuredValue;
            this.IsActiveStatus = isActiveStatus;
            this.TotalCount = totalCount;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public AlarmDetails()
        {
        }

        /// <summary>
        ///     Get or Set the AlarmCode
        /// </summary>
        /// <value>Alarm code value</value>
        public int AlarmCode { get; set; }

        /// <summary>
        ///     Get or Set the AlarmDescription
        /// </summary>
        /// <value>Alarm Description</value>
        public string AlarmDescription { get; set; }

        /// <summary>
        ///     Get or Set the StartDate
        /// </summary>
        /// <value>Alarm StartDate</value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Get or Set the EndDate
        /// </summary>
        /// <value>Alarm EndDate</value>
        public DateTime EndDate { get; set; }

        /// <summary>
        ///     Get or Set the SubCategoryName
        /// </summary>
        /// <value>Report Sub Category Name</value>
        public string AlarmDuration { get; set; }

        /// <summary>
        ///     Get or Set the Controller
        /// </summary>
        /// <value>Controller associated to alarm</value>
        public string Controller { get; set; }

        /// <summary>
        ///     Get or Set the WasherNumber
        /// </summary>
        /// <value>Washer Number value</value>
        public int? WasherNumber { get; set; }

        /// <summary>
        ///     Get or Set the BatchID
        /// </summary>
        /// <value>Batch ID value</value>
        public int? BatchId { get; set; }

        /// <summary>
        ///     Get or Set the ValueNumber
        /// </summary>
        /// <value>Value Number value</value>
        public int? ValueNumber { get; set; }

        /// <summary>
        ///     Get or Set the ChemicalName
        /// </summary>
        /// <value>Chemical Name value</value>
        public string ChemicalName { get; set; }

        /// <summary>
        ///     Get or Set the InjectionNumber
        /// </summary>
        /// <value>Injection Number value</value>
        public int? InjectionNumber { get; set; }

        /// <summary>
        ///     Get or Set the FormulaNumber
        /// </summary>
        /// <value>Formula number value</value>
        public int? FormulaNumber { get; set; }

        /// <summary>
        ///     Get or Set the FormulaName
        /// </summary>
        /// <value>Formula Name value</value>
        public string FormulaName { get; set; }

        /// <summary>
        ///     Get or Set the DesiredValue
        /// </summary>
        /// <value>Desired Value value</value>
        public decimal DesiredValue { get; set; }

        /// <summary>
        ///     Get or Set the MeasuredValue
        /// </summary>
        /// <value>MeasuredValue value</value>
        public decimal MeasuredValue { get; set; }

        /// <summary>
        ///     Get or Set the IsActiveStatus
        /// </summary>
        /// <value>IsActive Status value</value>
        public bool IsActiveStatus { get; set; }

        /// <summary>
        ///     Gets or sets the TotalCount
        /// </summary>
        /// <value>Total Count value.</value>
        public int TotalCount { get; set; }

        /// <summary>
        ///     Gets or sets the RowNo
        /// </summary>
        /// <value>Row Number value.</value>
        public int RowNo { get; set; }
    }
}