﻿// -----------------------------------------------------------------------
// <copyright file="AlarmSummary.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The AlarmSummary class</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Reports.WashingProcessValidation
{
    /// <summary>
    ///     Entity class for Alarm
    /// </summary>
    public class AlarmSummary
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="alarmCode">The alarm code.</param>
        /// <param name="alarmDescription">alarm description</param>
        /// <param name="numberOfAlarms">count of alarms</param>
        /// <param name="alarmDuration">alarm duration</param>
        /// <param name="controller">associated controller</param>
        /// <param name="totalCount">The total count.</param>
        /// <param name="rowNo">The row no.</param>
        /// <param name="linkedId">The linked Id.</param>
        /// <param name="alarmGroupMasterId">The alarm Group Master Id.</param>
        public AlarmSummary(int alarmCode, string alarmDescription, int numberOfAlarms, string alarmDuration, string controller, int totalCount, Int64 rowNo, int linkedId, int alarmGroupMasterId)
        {
            this.AlarmCode = alarmCode;
            this.AlarmDescription = alarmDescription;
            this.NumberOfAlarms = numberOfAlarms;
            this.AlarmDuration = alarmDuration;
            this.Controller = controller;
            this.TotalCount = totalCount;
            this.RowNo = Convert.ToInt32(rowNo);
            this.LinkedId = linkedId.ToString();
            this.AlarmGroupMasterId = alarmGroupMasterId;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public AlarmSummary()
        {
        }

        /// <summary>
        ///     Get or Set the AlarmCode
        /// </summary>
        /// <value>Alarm code value</value>
        public int AlarmCode { get; set; }

        /// <summary>
        ///     Get or Set the AlarmDescription
        /// </summary>
        /// <value>Alarm Description</value>
        public string AlarmDescription { get; set; }

        /// <summary>
        ///     Get or Set the NumberOfAlarms
        /// </summary>
        /// <value>count of Alarms</value>
        public int NumberOfAlarms { get; set; }

        /// <summary>
        ///     Get or Set the SubCategoryName
        /// </summary>
        /// <value>Report Sub Category Name</value>
        public string AlarmDuration { get; set; }

        /// <summary>
        ///     Get or Set the Controller
        /// </summary>
        /// <value>Controller associated to alarm</value>
        public string Controller { get; set; }

        /// <summary>
        ///     Gets or sets the TotalCount
        /// </summary>
        /// <value>Total Count value.</value>
        public int TotalCount { get; set; }

        /// <summary>
        ///     Gets or sets the RowNo
        /// </summary>
        /// <value>Row Number value.</value>
        public int RowNo { get; set; }
        /// <summary>
        /// Gets or Sets LinkedId
        /// </summary>
        /// <value>Contians LinkedId Value </value>
        public string LinkedId { get; set; }

        /// <summary>
        /// Gets or Sets AlarmGroupMasterId
        /// </summary>
        /// <value>Contians AlarmGroupMasterId Value </value>
        public int AlarmGroupMasterId { get; set; }
    }
}