﻿// -----------------------------------------------------------------------
// <copyright file="ReportLocalization.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportLocalization </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    /// Entity model for ReportLocalization
    /// </summary>
    public class ReportLocalization
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="value"></param>
        public ReportLocalization(int id , string value)
        {
            Id = id;
            Value = value;
        }

        /// <summary>
        /// default constructor
        /// </summary>
        public ReportLocalization()
        {
        }

        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        /// <value>Ribbon option id.</value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        /// <value>Ribbon option name.</value>
        public string Value { get; set; }
    }
}
