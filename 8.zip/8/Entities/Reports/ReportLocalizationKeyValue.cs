﻿// -----------------------------------------------------------------------
// <copyright file="ReportLocalizationKeyValue.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportLocalizationKeyValue </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    /// Entity model for ReportLocalizationKeyValue
    /// </summary>
    public class ReportLocalizationKeyValue
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="key">localized key value</param>
        /// <param name="value">localized value for a key</param>
        public ReportLocalizationKeyValue(string key, string value)
        {
            this.Key = key;
            this.Value = value;
        }

        /// <summary>
        /// localized key value
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// localized value for a key
        /// </summary>
        public string Value { get; set; }
    }
}
