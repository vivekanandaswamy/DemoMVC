﻿// -----------------------------------------------------------------------
// <copyright file="ReportFilterList.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Filter List class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    ///     Entity class for ReportFilterList
    /// </summary>
    public class ReportFilterList : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="id">report filter id.</param>
        /// <param name="filterName">report filter name.</param>
        public ReportFilterList(int id, string filterName)
        {
            this.Id = id;
            this.FilterName = filterName;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ReportFilterList()
        {
        }

        /// <summary>
        ///     Gets or sets the FilterName
        /// </summary>
        /// <value>Filter Name.</value>
        public string FilterName { get; set; }
    }
}