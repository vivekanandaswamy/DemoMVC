﻿// -----------------------------------------------------------------------
// <copyright file="ReportAllColumns.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Report AllColumns access </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    ///     Entity class for ReportAllColumns
    /// </summary>
    public class ReportAllColumns : BaseEntity
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="id">ribbon option id.</param>
        /// <param name="columnName">report column name.</param>
        /// <param name="displayOrder">The display order.</param>
        /// <param name="isSortable">if set to <c>true</c> [is sortable].</param>
        /// <param name="viewById">The view by identifier.</param>
        /// <param name="switchModeId">The switch mode identifier.</param>
        /// <param name="isVisible">if set to <c>true</c> [is visible].</param>
        /// <param name="isChartDisplay">if set to <c>true</c> [is chart display].</param>
        /// <param name="localizedName">Name of the localized.</param>
        /// <param name="localizedUom">The Localized UOM</param>
        /// <param name="precision">The Decimal Count to be shown</param>
        public ReportAllColumns(int id, string columnName, int displayOrder, bool isSortable, int viewById, int switchModeId, bool isVisible, bool isChartDisplay, string localizedName, string localizedUom, int precision, bool isLinkable, int linkedReportId)
        {
            Id = id;
            ColumnName = columnName;
            DisplayOrder = displayOrder;
            IsSortable = isSortable;
            ViewModeId = viewById;
            SwitchModeId = switchModeId;
            IsVisible = isVisible;
            IsChartDisplay = isChartDisplay;
            LocalizedName = localizedName;
			LocalizedUom = string.IsNullOrEmpty(localizedUom) ? localizedUom : localizedUom.Contains("&#8364") ? localizedUom.Replace("&#8364", "€") : localizedUom; 
			Precision = precision;
            this.IsLinkable = isLinkable;
            this.LinkedReportId = linkedReportId;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ReportAllColumns()
        {
        }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>Report column name.</value>
        public string ColumnName { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOrder
        /// </summary>
        /// <value>DisplayOrder value.</value>
        public int DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>IsSortable value.</value>
        public bool IsSortable { get; set; }

        /// <summary>
        ///     Gets or sets the ViewModeId
        /// </summary>
        /// <value>ViewModeId value.</value>
        public int ViewModeId { get; set; }

        /// <summary>
        ///     Gets or sets the SwitchModeId
        /// </summary>
        /// <value>SwitchModeId value.</value>
        public int SwitchModeId { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>IsVisible value.</value>
        public bool IsVisible { get; set; }

        /// <summary>
        ///     Gets or sets the ColumnName
        /// </summary>
        /// <value>IsVisible value.</value>
        public bool IsChartDisplay { get; set; }

        /// <summary>
        /// Gets or sets the name of the localized.
        /// </summary>
        /// <value>
        /// The name of the localized.
        /// </value>
        public string LocalizedName { get; set;}

        /// <summary>
        /// Gets or sets the Localized UOM.
        /// </summary>
        /// <value>
        /// The localized UOM.
        /// </value>
        public string LocalizedUom { get; set;}

        /// <summary>
        /// Gets or Sets Precision
        /// </summary>
        /// <value>The Decimals to be shown</value>
        public int Precision { get; set; }
        /// <summary>
        /// Gets or Sets IsLinkable 
        /// </summary>
        /// <value>IsLinkable value</value>
        public bool IsLinkable { get; set; }
        /// <summary>
        /// Gets or Sets LinkedReportId 
        /// </summary>
        /// <value>LinkedReportId value</value>
        public int LinkedReportId { get; set; }
    }
}