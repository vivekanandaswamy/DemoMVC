﻿// -----------------------------------------------------------------------
// <copyright file="ReportSubView.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ReportSubView </summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    public class ReportSubView
    {
        public ReportSubView(int subviewId, string subViewName,string localizedName, int drillupSubViewId, int drilldownSubViewId,  bool isLast)
        {
            SubViewId = subviewId;
            SubViewName = subViewName;
            DrillupSubViewId = drillupSubViewId;
            DrilldownSubViewId = drilldownSubViewId;
            IsLast = isLast;
            LocalizedName = localizedName;

        }

        /// <summary>
        /// Gets or Sets SubViewId value
        /// </summary>
        /// <value>Contains SubViewId value</value>
        public int SubViewId { get; set; }

        /// <summary>
        /// Gets or Sets SubViewName value
        /// </summary>
        /// <value>Contains SubViewName value</value>
        public string SubViewName { get; set; }
        
        /// <summary>
        /// Gets or Sets DrilldownSubViewId value
        /// </summary>
        /// <value>Contains DrilldownSubViewId value</value>
        public int DrilldownSubViewId { get; set; }

        /// <summary>
        /// Gets or Sets DrillupSubViewId value
        /// </summary>
        /// <value>Contains DrillupSubViewId value</value>
        public int DrillupSubViewId { get; set; }

        /// <summary>
        /// Gets or Sets IsLast value
        /// </summary>
        /// <value>Contains IsLast value</value>
        public bool IsLast { get; set; }

        /// <summary>
        /// Gets or sets the name of the localized.
        /// </summary>
        /// <value>
        /// The name of the localized.
        /// </value>
        public string LocalizedName { get; set;}
    }
}
