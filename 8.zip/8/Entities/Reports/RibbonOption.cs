﻿// -----------------------------------------------------------------------
// <copyright file="RibbonOption.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Ribbon Option class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    ///     Entity class for RibbonOption
    /// </summary>
    public class RibbonOption : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="id">ribbon option id.</param>
        /// <param name="name">ribbon option name.</param>
        public RibbonOption(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public RibbonOption()
        {
        }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value>Ribbon option name.</value>
        public string Name { get; set; }
    }
}