﻿// -----------------------------------------------------------------------
// <copyright file="ReportFilter.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Filter class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    ///     Entity class for ReportFilter
    /// </summary>
    public class ReportFilter : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="id">report filter id.</param>
        /// <param name="filterName">report filter name.</param>
        public ReportFilter(int id, string filterName)
        {
            this.Id = id;
            this.FilterName = filterName;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ReportFilter()
        {
        }

        /// <summary>
        ///     Gets or sets the FilterName
        /// </summary>
        /// <value>Report Filter Name.</value>
        public string FilterName { get; set; }
    }
}