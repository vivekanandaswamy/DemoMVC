﻿// -----------------------------------------------------------------------
// <copyright file="UserLog.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Log class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports.EcolabInternal
{
    using System;

    /// <summary>
    ///     Entity class for UserLog
    /// </summary>
    public class UserLog : BaseEntity
    {
        public UserLog()
        {
        }

        public UserLog(string userName, DateTime dateandTime, string actionType, string actionDescription, int totalCount, int rowId)
        {
            this.UserName = userName;
            this.DateAndTime = dateandTime;
            this.ActionType = actionType;
            this.ActionDescription = actionDescription;
            this.TotalCount = totalCount;
            this.RowId = rowId;
        }

        /// <summary>
        ///     Gets or sets the UserName
        /// </summary>
        /// <value>User Name.</value>
        public string UserName { get; set; }

        /// <summary>
        ///     Gets or sets the DateAndTime
        /// </summary>
        /// <value>Date And Time.</value>
        public DateTime DateAndTime { get; set; }

        /// <summary>
        ///     Gets or sets the ActionType
        /// </summary>
        /// <value>Action Type.</value>
        public string ActionType { get; set; }

        /// <summary>
        ///     Gets or sets the ActionDescription
        /// </summary>
        /// <value>Action Description.</value>
        public string ActionDescription { get; set; }

        /// <summary>
        ///     Gets or sets the TotalCount
        /// </summary>
        /// <value>Total Count value.</value>
        public int TotalCount { get; set; }

        /// <summary>
        ///     Gets or sets the RowId
        /// </summary>
        /// <value>RowId for get row number.</value>
        public int RowId { get; set; }
    }
}