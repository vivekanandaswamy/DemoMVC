﻿// -----------------------------------------------------------------------
// <copyright file="Report.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Report Class</summary>
// -----------------------------------------------------------------------

namespace Entities.Reports
{
    /// <summary>
    ///     Entity class for Report
    /// </summary>
    public class Report : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="reportCategoryId">report category id</param>
        /// <param name="reportCategoryName">report category name</param>
        /// <param name="subcategoryId">report sub category id</param>
        /// <param name="subcategoryName">report sub category name</param>
        /// <param name="reportId">report id</param>
        /// <param name="reportName">report name</param>
        public Report(int reportCategoryId, string reportCategoryName, int subcategoryId, string subcategoryName, int reportId, string reportName, int displayTopRecordsCount, bool showOthers, bool showTotal, string chartType, bool isPaging, int pageSize)
        {
            this.ReportCategoryId = reportCategoryId;
            this.ReportCategoryName = reportCategoryName;
            this.SubcategoryId = subcategoryId;
            this.SubcategoryName = subcategoryName;
            this.ReportId = reportId;
            this.ReportName = reportName;
            this.DisplayTopRecordsCount = displayTopRecordsCount;
            this.ShowOthers = showOthers;
            this.ShowTotal = showTotal;
            this.ChartType = chartType;
            this.IsPaging = this.IsPaging;
            this.PageSize = pageSize;
        }

        public Report()
        {
        }

        /// <summary>
        ///     Get or Set the ReportCategoryId
        /// </summary>
        /// <value>Report Category Id</value>
        public int ReportCategoryId { get; set; }

        /// <summary>
        ///     Get or Set the ReportCategoryName
        /// </summary>
        /// <value>Report Category Name</value>
        public string ReportCategoryName { get; set; }

        /// <summary>
        ///     Get or Set the SubCategoryId
        /// </summary>
        /// <value>Report Sub Category Id</value>
        public int SubcategoryId { get; set; }

        /// <summary>
        ///     Get or Set the SubCategoryName
        /// </summary>
        /// <value>Report Sub Category Name</value>
        public string SubcategoryName { get; set; }

        /// <summary>
        ///     Get or Set the ReportId
        /// </summary>
        /// <value>parameter Report Id</value>
        public int ReportId { get; set; }

        /// <summary>
        ///     Get or Set the ReportName
        /// </summary>
        /// <value>parameter Report Name</value>
        public string ReportName { get; set; }

        /// <summary>
        ///     Get or Set the DisplayTopRecordsCount
        /// </summary>
        /// <value>DisplayTopRecordsCount value</value>
        public int DisplayTopRecordsCount { get; set; }

        /// <summary>
        ///     Get or Set the ShowOthers
        /// </summary>
        /// <value>ShowOthers value</value>
        public bool ShowOthers { get; set; }

        /// <summary>
        ///     Get or Set the ShowTotal
        /// </summary>
        /// <value>ShowTotal value</value>
        public bool ShowTotal { get; set; }

        /// <summary>
        ///     Get or Set the ChartType
        /// </summary>
        /// <value>ChartType Name</value>
        public string ChartType { get; set; }

        /// <summary>
        ///     Get or Set the isPaging
        /// </summary>
        /// <value>IsPaging value</value>
        public bool IsPaging { get; set; }

        /// <summary>
        ///     Get or Set the PageSize
        /// </summary>
        /// <value>PageSize value</value>
        public int PageSize { get; set; }
    }
}