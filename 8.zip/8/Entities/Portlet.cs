﻿// -----------------------------------------------------------------------
// <copyright file="Portlet.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Portlet object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     Class Portlet
    /// </summary>
    public class Portlet
    {
        /// <summary>
        /// The portlet to show on dashboard
        /// </summary>
        /// <param name="portletId">The portlet identifier.</param>
        /// <param name="name">The user name</param>
        /// <param name="displayOrder">The order of display</param>
        /// <param name="isEnabled">Is enabled or not</param>
        /// <param name="reportId">The report Id  value</param>
        public Portlet(int portletId, string name, int displayOrder, bool isEnabled, int reportId)
        {
            this.PortletId = portletId;
            this.Name = name;
            this.DisplayOrder = displayOrder;
            this.IsEnabled = isEnabled;
            this.ReportId = reportId;
        }

        /// <summary>
        ///     Gets or sets the PortletId.
        /// </summary>
        /// <value>The PortletId field</value>
        public int PortletId { get; set; }

        /// <summary>
        ///     Gets or sets the ReportId.
        /// </summary>
        /// <value>The ReportId field</value>
        public int ReportId { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value>The Name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOrder.
        /// </summary>
        /// <value>The DisplayOrder. field</value>
        public int DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the IsEnabled.
        /// </summary>
        /// <value>The IsEnabled. field</value>
        public bool IsEnabled { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }
    }
}