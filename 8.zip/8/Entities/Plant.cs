﻿// -----------------------------------------------------------------------
// <copyright file="Plant.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    ///     class for Plant
    /// </summary>
    public class Plant
    {
        /// <summary>
        ///     default constructor
        /// </summary>
        public Plant()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Plant"/> class.
        /// </summary>
        /// <param name="localTimeZone">The local time zone.</param>
        public Plant(string localTimeZone)
        {
            TimeZone = localTimeZone;
        }

        /// <summary>
        /// Plant parameterized constructor
        /// </summary>
        /// <param name="ecoalabAccountNumber">The parameter EcoalabAccountNumber</param>
        /// <param name="name">The parameter Name</param>
        /// <param name="tmName">The parameter Teritory Manager Name</param>
        /// <param name="tmPhoneNumber">The parameterTeritory Manager Phone Numner</param>
        /// <param name="dmName">The parameter DM Name</param>
        /// <param name="dmPhoneNumber">The parameter DM Phone Numner</param>
        /// <param name="chain">The parameter Chain</param>
        /// <param name="chainUnitNumber">The parameter ChainUnitNumber</param>
        /// <param name="chainRegions">The parameter ChainRegions</param>
        /// <param name="censusPriceKg">The parameter CensusPriceKg</param>
        /// <param name="remarks">The parameter Remarks</param>
        /// <param name="languageId">The parameter LanguageId</param>
        /// <param name="currencyCode">The parameter Currency Code</param>
        /// <param name="billingAddr1">The Billing address 1</param>
        /// <param name="billingAddr2">The Billing address 2</param>
        /// <param name="city">the plant city.</param>
        /// <param name="country">The plant country.</param>
        /// <param name="zip">The Parameter city zip.</param>
        /// <param name="shippingAddr1">The shipping address 1</param>
        /// <param name="shippingAddr2">The shipping address 2</param>
        /// <param name="shippingcity">The Shipping city.</param>
        /// <param name="shippingcountry">the shipping Country.</param>
        /// <param name="shippingzip">The shipping zip.</param>
        /// <param name="rate">The parameter Rate</param>
        /// <param name="exportPath">The parameter Export Path</param>
        /// <param name="allowManualRewash">allow manual rewash</param>
        /// <param name="dataLiveTime">The parameter Data Live Time</param>
        /// <param name="budgetCustomer">The parameter Budget Customer</param>
        /// <param name="uomId">The parameter UOM Id</param>
        /// <param name="logo">The parameter Logo</param>
        /// <param name="regionId">The Parameter region Id</param>
        /// <param name="regionName">The region Name</param>
        /// <param name="languageName">The language name.</param>
        /// <param name="currencyName">the currency name.</param>
        /// <param name="unitSystem">The Unit system.</param>
        /// <param name="lastModifiedTime">The Last Modified Time.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="lastServiceVisitDate">The last service visit date.</param>
        /// <param name="nextServiceVisitDate">The next service visit date.</param>
        /// <param name="lastArchiveDate">The last archive date.</param>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <param name="myserviceId">The myservice identifier.</param>
        /// <param name="plantStandardTurnTime">The plant standard turn time.</param>
        /// <param name="contractNo">The contract no.</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="dayId">The day identifier.</param>
        /// <param name="startTime">The start time.</param>
        /// <param name="endTime">The end time.</param>
        public Plant(
            string ecoalabAccountNumber,
            string name,
            string tmName,
            string tmPhoneNumber,
            string dmName,
            string dmPhoneNumber,
            string chain,
            string chainUnitNumber,
            string chainRegions,
            decimal censusPriceKg,
            string remarks,
            int languageId,
            string currencyCode,
            string billingAddr1,
            string billingAddr2,
            string city,
            string country,
            string zip,
            string shippingAddr1,
            string shippingAddr2,
            string shippingcity,
            string shippingcountry,
            string shippingzip,
            int rate,
            string exportPath,
            bool allowManualRewash,
            int dataLiveTime,
            bool budgetCustomer,
            int uomId,
            byte[] logo,
            short regionId,
            string regionName,
            string languageName,
            string currencyName,
            string unitSystem,
            DateTime lastModifiedTime,
            DateTime? myServiceLastSynchTime,
            DateTime? lastServiceVisitDate,
            DateTime? nextServiceVisitDate,
            DateTime? lastArchiveDate,
            int plantChainId,
            Guid myserviceId,
            int plantStandardTurnTime,
            string contractNo,
            int plantId,
            int dayId,
            TimeSpan startTime,
            TimeSpan endTime,
            bool isetechEnable,
            string etechIpAddresse,
            int sourceSystemId
            )
        {
            this.EcoalabAccountNumber = string.IsNullOrEmpty(ecoalabAccountNumber) ? ecoalabAccountNumber : ecoalabAccountNumber.Trim();
            this.Name = name;
            this.TmName = tmName;
            this.TmPhoneNumner = tmPhoneNumber;
            this.DmName = dmName;
            this.DmPhoneNumner = dmPhoneNumber;
            this.Chain = chain;
            this.ChainUnitNumber = chainUnitNumber;
            this.ChainRegions = chainRegions;
            this.CensusPriceKg = censusPriceKg;
            this.Remarks = remarks;
            this.LanguageId = languageId;
            this.CurrencyCode = currencyCode;
            this.Rate = rate;
            this.ExportPath = exportPath;
            this.DataLiveTime = dataLiveTime;
            this.BudgetCustomer = budgetCustomer;
            this.UomId = uomId;
            this.Logo = logo == null ? string.Empty : Convert.ToBase64String(logo);
            this.RegionId = regionId;
            this.RegionName = regionName;
            this.LanguageName = languageName;
            this.CurrencyName = currencyName;
            this.UnitSystem = unitSystem;
            this.AllowManualRewash = allowManualRewash;
            this.PlantCustAddr = new PlantCustAddress { BillingAddr1 = billingAddr1, BillingAddr2 = billingAddr2, City = city, Country = country, Zip = zip };
            this.ShippingAddr = new ShippingAddress { ShippingAddr1 = shippingAddr1, ShippingAddr2 = shippingAddr2, Shippingcity = shippingcity, Shippingcountry = shippingcountry, Shippingzip = shippingzip };
            LastModifiedTimestamp = lastModifiedTime;
            MyServiceModDtTm = myServiceLastSynchTime;
            this.LastServiceVisitDate = lastServiceVisitDate;
            this.NextServiceVisitDate = nextServiceVisitDate;
            this.LastArchiveDate = lastArchiveDate;
            PlantChainId = plantChainId;
            MyServiceCustGuid = myserviceId;
            this.PlantStandardTurnTime = plantStandardTurnTime;
            this.PlantContractNumber = contractNo;
            this.PlantId = plantId;
            this.DayId = dayId;
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.IsETechEnable = isetechEnable;
            this.EtechIpAddress = etechIpAddresse;
            this.SourceSystemId = sourceSystemId;
        }
        /// <summary>
        /// Plant parameterized constructor
        /// </summary>
        /// <param name="ecoalabAccountNumber">The parameter EcoalabAccountNumber</param>
        /// <param name="name">The parameter Name</param>
        /// <param name="chainName">Name of the chain.</param>
        /// <param name="tmName">The parameter Teritory Manager Name</param>
        /// <param name="tmPhoneNumber">The parameterTeritory Manager Phone Numner</param>
        /// <param name="dmName">The parameter DM Name</param>
        /// <param name="dmPhoneNumber">The parameter DM Phone Numner</param>
        /// <param name="chainUnitNumber">The parameter ChainUnitNumber</param>
        /// <param name="censusPriceKg">The parameter CensusPriceKg</param>
        /// <param name="censusPriceKgUom">The census price kg uom.</param>
        /// <param name="censusPriceKgCurrnecyCode">The census price kg currnecy code.</param>
        /// <param name="remarks">The parameter Remarks</param>
        /// <param name="languageId">The parameter LanguageId</param>
        /// <param name="languageCode">The language code.</param>
        /// <param name="currencyCode">The parameter Currency Code</param>
        /// <param name="regionCode">The region code.</param>
        /// <param name="uomDesc">The uom desc.</param>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="myServiceCustGuid">My service customer unique identifier.</param>
        /// <param name="myServiceModDtTm">My service mod dt tm.</param>
        /// <param name="salesDistrict">The sales district.</param>
        /// <param name="salesTerritory">The sales territory.</param>
        /// <param name="plantCountryCode">The plant country code.</param>
        /// <param name="logo">The parameter Logo</param>
        /// <param name="contractNo">The contract no.</param>
        public Plant(
            string ecoalabAccountNumber,
            string name,
            string chainName,
            string tmName,
            string tmPhoneNumber,
            string dmName,
            string dmPhoneNumber,
            string chainUnitNumber,
            decimal censusPriceKg,
            string censusPriceKgUom,
            string censusPriceKgCurrnecyCode,
            string remarks,
            Int16 languageId,
            string languageCode,
            string currencyCode,
            string regionCode,
            string uomDesc,
            int plantChainId,
            bool isDelete,
            Guid myServiceCustGuid,
            DateTime myServiceModDtTm,
            string salesDistrict,
            string salesTerritory,
            string plantCountryCode,
            Byte[] logo,
            string contractNo,
            DateTime? lastServiceVisitDate,
            DateTime? nextServiceVisitDate,
            string sourceSystemCode
            )
        {
            this.EcoalabAccountNumber = string.IsNullOrEmpty(ecoalabAccountNumber) ? ecoalabAccountNumber : ecoalabAccountNumber.Trim();
            Name = name;
            PlantChainName = chainName;
            TmName = tmName;
            TmPhoneNumner = tmPhoneNumber;
            DmName = dmName;
            DmPhoneNumner = dmPhoneNumber;
            ChainUnitNumber = chainUnitNumber;
            CensusPriceKg = censusPriceKg;
            Remarks = remarks;
            LanguageId = languageId;
            CurrencyCode = currencyCode;
            RegionCode = regionCode;
            UOMDesc = uomDesc;
            PlantChainId = plantChainId;
            IsDelete = isDelete;
            MyServiceCustGuid = myServiceCustGuid;
            MyServiceModDtTm = myServiceModDtTm;
            SalesDistrict = salesDistrict;
            SalesTerritory = salesTerritory;
            PlantCountryCode = plantCountryCode;
            CustLogo = logo != null ? logo.ToList() : null;
            this.MyServiceLanguageCode = languageCode;
            this.PlantContractNumber = contractNo;
            this.LastServiceVisitDate = lastServiceVisitDate;
            this.NextServiceVisitDate = nextServiceVisitDate;
            this.SourceSystemCode = sourceSystemCode;
        }

        public Plant(string ecolabAccountNumber,string name,bool etechEnable,string etechIPAddress,int etechTimeDiff)
        {
            this.EcoalabAccountNumber = ecolabAccountNumber;
            this.Name = name;
            this.IsETechEnable = etechEnable;
            this.EtechIpAddress = etechIPAddress;
            this.ETechTimeDiff = etechTimeDiff;
        }

        /// <summary>
        ///     Gets or sets the EcoalabAccountNumber.
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value> The Parameter Name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the DataLiveTime.
        /// </summary>
        /// <value> The Data Live Time.</value>
        public int DataLiveTime { get; set; }

        /// <summary>
        ///     Gets or sets the BudgetCustomer.
        /// </summary>
        /// <value> The Parameter Budget Customer.</value>
        public bool BudgetCustomer { get; set; }

        /// <summary>
        ///     Gets or sets the AllowManualRewash.
        /// </summary>
        /// <value> The Allow Manual Rewash.</value>
        public bool AllowManualRewash { get; set; }

        /// <summary>
        ///     Gets or sets the ExportPath.
        /// </summary>
        /// <value> The Parameter Export Path.</value>
        public string ExportPath { get; set; }

        /// <summary>
        ///     Gets or sets the LanguageId.
        /// </summary>
        /// <value> The Parameter Language Id.</value>
        public int LanguageId { get; set; }

        /// <summary>
        ///     Gets or sets the UOMId.
        /// </summary>
        /// <value> The Parameter UOM Id.</value>
        public int UomId { get; set; }

        /// <summary>
        ///     Gets or sets the CurrencyCode.
        /// </summary>
        /// <value> the Currency Code.</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets the WasteWaterPercentage.
        /// </summary>
        /// <value> The Waste Water Percentage.</value>
        public decimal WastewaterPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the WasteWaterCostPerGallon.
        /// </summary>
        /// <value> The Waste Water Cost Per Gallon.</value>
        public string WastewaterCostPerGallon { get; set; }

        /// <summary>
        ///     Gets or sets the PlantCategoryId.
        /// </summary>
        /// <value> The Plant Category Id.</value>
        public int PlantCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets the AcutalIsTarget.
        /// </summary>
        /// <value> The Acutal Is Target.</value>
        public bool AcutalIsTarget { get; set; }

        /// <summary>
        ///     Gets or sets the RegionId.
        /// </summary>
        /// <value> The Parameter Region Id.</value>
        public short RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the RegionName
        /// </summary>
        /// <value> Parameter Region Name</value>
        public string RegionName { get; set; }

        /// <summary>
        ///     Gets or sets the PlantChainId.
        /// </summary>
        /// <value> The Plant Chain Id.</value>
        public int PlantChainId { get; set; }

        /// <summary>
        ///     Gets or sets the PlantChainName.
        /// </summary>
        /// <value> The Plant Chain Name.</value>
        public string PlantChainName { get; set; }

        /// <summary>
        ///     Gets or sets the Logo.
        /// </summary>
        /// <value> The Parameter Logo.</value>
        public string Logo { get; set; }

        /// <summary>
        ///     Gets or sets the CreatedOn.
        /// </summary>
        /// <value> The Parameter CreatedOn.</value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        ///     Gets or sets the CreatedBy.
        /// </summary>
        /// <value> The Parameter Created By.</value>
        public int CreatedBy { get; set; }

        /// <summary>
        ///     Gets or sets the ModifiedOn.
        /// </summary>
        /// <value> The Parameter Modified On.</value>
        public DateTime ModifiedOn { get; set; }

        /// <summary>
        ///     Gets or sets the ModifiedBy.
        /// </summary>
        /// <value> The Parameter Modified By.</value>
        public string ModifiedBy { get; set; }

        /// <summary>
        ///     Gets or sets the TMName.
        /// </summary>
        /// <value> The Teritory Manager Name.</value>
        public string TmName { get; set; }

        /// <summary>
        ///     Gets or sets the TMPhoneNumner.
        /// </summary>
        /// <value> The Teritory Manager PhoneNumner.</value>
        public string TmPhoneNumner { get; set; }

        /// <summary>
        ///     Gets or sets the DMName.
        /// </summary>
        /// <value> The Parameter DM Name.</value>
        public string DmName { get; set; }

        /// <summary>
        ///     Gets or sets the DMPhoneNumner.
        /// </summary>
        /// <value> The DM PhoneNumner.</value>
        public string DmPhoneNumner { get; set; }

        /// <summary>
        ///     Gets or sets the HelmsNumber.
        /// </summary>
        /// <value> The Helms Numner.</value>
        public string HelmsNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Chain.
        /// </summary>
        /// <value> The Parameter Chain.</value>
        public string Chain { get; set; }

        /// <summary>
        ///     Gets or sets the ChainUnitNumber.
        /// </summary>
        /// <value> The Chain Unit Number.</value>
        public string ChainUnitNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ChainRegions.
        /// </summary>
        /// <value> The Chain Regions.</value>
        public string ChainRegions { get; set; }

        /// <summary>
        ///     Gets or sets the CensusPriceKg.
        /// </summary>
        /// <value> The Census Price Kg.</value>
        public decimal CensusPriceKg { get; set; }

        /// <summary>
        ///     Gets or sets the Remarks.
        /// </summary>
        /// <value> The Parameter Remarks.</value>
        public string Remarks { get; set; }

        /// <summary>
        ///     Gets or sets the Rate.
        /// </summary>
        /// <value> The Rate.</value>
        public int Rate { get; set; }

        /// <summary>
        ///     Gets or sets the PlantCustAddress
        /// </summary>
        /// <value> Parameter Plant Customer Address</value>
        public virtual PlantCustAddress PlantCustAddr { get; set; }

        /// <summary>
        ///     Gets or sets the ShippingAddress
        /// </summary>
        /// <value>Parameter Shipping Address</value>
        public virtual ShippingAddress ShippingAddr { get; set; }

        /// <summary>
        ///     Gets or sets the LanguageName
        /// </summary>
        /// <value> Parameter Language Name</value>
        public string LanguageName { get; set; }

        /// <summary>
        ///     Gets or sets the CurrencyName
        /// </summary>
        /// <value> Parameter Currency Name</value>
        public string CurrencyName { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystem
        /// </summary>
        /// <value> Parameter Unit System</value>
        public string UnitSystem { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the ID
        /// </summary>
        /// ///
        /// <value>Id</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the Last Service Visit Date
        /// </summary>
        /// <value>LastServiceVisitDate</value>
        public DateTime? LastServiceVisitDate { get; set; }

        /// <summary>
        ///     Gets or sets the Next Service Visit Date
        /// </summary>
        /// <value>NextServiceVisitDate</value>
        public DateTime? NextServiceVisitDate { get; set; }

        /// <summary>
        ///     Gets or sets the Last Archive Date
        /// </summary>
        /// <value>LastArchiveDate</value>
        public DateTime? LastArchiveDate { get; set; }

        /// <summary>
        ///     Gets or sets RegionCode
        ///     This property is used only for my service to get the region code and based of that we will get region id and
        ///     region name from conduict
        /// </summary>
        public string RegionCode { get; set; }

        /// <summary>
        /// Gets or Sets Is_Delete
        /// </summary>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustGuid
        /// </summary>
        public Guid MyServiceCustGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceLastSynchTime
        /// </summary>
        public DateTime? MyServiceModDtTm { get; set; }

        /// <summary>
        /// Gets or sets UOMDesc
        /// This property is used only for my service to get the uom desc and based of that we will get uom id from conduict
        /// </summary>
        public string UOMDesc { get; set; }

        /// <summary>
        /// This property is used to access for retireving the local time zone for a plant
        /// </summary>
        public string TimeZone { get; set; }

        /// <summary>
        /// Gets or sets SalesDistrict
        /// It is used to save in enVision db only and getting from myService
        /// </summary>
        public string SalesDistrict { get; set; }

        /// <summary>
        /// Gets or sets SalesDistrict
        /// It is used to save in enVision db only and getting from myService
        /// </summary>
        public string SalesTerritory { get; set; }

        /// <summary>
        /// Gets or sets PlantCountryCode
        /// It is used to save in enVision db only and getting from myService 
        /// </summary>
        public string PlantCountryCode { get; set; }

        /// <summary>
        /// Gets or sets Custlogo
        /// </summary>
        public List<byte> CustLogo { get; set; }

        /// <summary>
        /// Gets or sets PlantStandardTurnTime
        /// </summary>
        public int PlantStandardTurnTime { get; set; }

        /// <summary>
        /// Gets or sets MyServiceLanguageCode
        /// </summary>
        public string MyServiceLanguageCode { get; set; }

        /// <summary>
        /// Gets or sets PlantContractNumber
        /// </summary>
        public string PlantContractNumber { get; set; }

        /// <summary>
        /// Gets or sets PlantId
        /// </summary>
        public int PlantId { get; set; }

        /// <summary>
        /// Gets or sets DayId
        /// </summary>
        public int DayId { get; set; }

        /// <summary>
        /// Gets or sets Start Time
        /// </summary>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        /// Gets or sets End Time
        /// </summary>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the EtechEnable.
        /// </summary>
        /// <value> The EtechEnable.</value>
        public bool IsETechEnable { get; set; }

        /// <summary>
        ///     Gets or sets the EtechIpAddress.
        /// </summary>
        /// <value> The EtechEnable.</value>
        public string EtechIpAddress { get; set; }

        /// <summary>
        ///     Gets or sets the ETechTimeDiff.
        /// </summary>
        /// <value> The ETechTimeDiff.</value>
        public int ETechTimeDiff { get; set; }

        /// <summary>
        ///     Gets or sets the SourceSystemCode.
        /// </summary>
        /// <value> The SourceSystemCode.</value>
        public string SourceSystemCode { get; set; }

        /// <summary>
        ///     Gets or sets the SourceSystemId.
        /// </summary>
        /// <value> The SourceSystemId.</value>
        public int SourceSystemId { get; set; }
    }
}