﻿// -----------------------------------------------------------------------
// <copyright file="MyServiceWashFloor.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MyServiceWashFloor object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Class for Myservice data
    /// </summary>
    public class MyServiceWashFloor
    {
        /// <summary>
        /// costructor
        /// </summary>
        /// <param name="washerGuid">washer guid</param>
        /// <param name="groupGuid">myservice group guid</param>
        /// <param name="groupFormulaGuid">group formula guid</param>
        /// <param name="custGuid">customer guid</param>
		public MyServiceWashFloor(Guid washerGuid, Guid groupGuid, Guid groupFormulaGuid, Guid custGuid)
        {
            MachineGroupGuid = groupGuid;
            MachineGuid = washerGuid;
            WasherProgramGuid = groupFormulaGuid;
            CustGuid = custGuid;
        }

        /// <summary>
        /// Machine group guid
        /// </summary>
        public Guid MachineGroupGuid { get; set; }

        /// <summary>
        /// Machine Guid
        /// </summary>
        public Guid MachineGuid { get; set; }

        /// <summary>
        /// Washer group formula Guid
        /// </summary>
        public Guid WasherProgramGuid { get; set; }

        /// <summary>
        /// Plant guid
        /// </summary>
        public Guid CustGuid { get; set; }
    }
}
