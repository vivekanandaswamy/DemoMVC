﻿// -----------------------------------------------------------------------
// <copyright file="PackageSize.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PackageSize </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class PackageSize : BaseEntity
    {
        public PackageSize()
        {

        }

        public PackageSize(string packageSizeDescription, int unitPerPackage, decimal unitWeightVolume, short unitWeightVolumeUOMId, decimal packageSizeVolume, short packageSizeVolumeUOMId, decimal packageSizeWeight, short packageSizeWeightUOMId, decimal packageSizeDensity, short packageSizeDensityUOMId, string regionCode, bool isDeleted, int myServicePkgSzId, DateTime myServiceModDtTm, string packageSizeWeightUOMCode)
        {
            this.PackageSizeDescription = packageSizeDescription;
            this.UnitPerPackage = unitPerPackage;
            this.UnitWeightVolume = unitWeightVolume;
            this.UnitWeightVolumeUOMId = unitWeightVolumeUOMId;
            this.PackageSizeVolume = packageSizeVolume;
            this.PackageSizeVolumeUOMId = packageSizeVolumeUOMId;
            this.PackageSizeWeight = packageSizeWeight;
            this.PackageSizeWeightUOMId = packageSizeWeightUOMId;
            this.PackageSizeDensity = packageSizeDensity;
            this.PackageSizeDensityUOMId = packageSizeDensityUOMId;
            this.RegionCode = regionCode;
            this.IsDeleted = isDeleted;
            this.MyServicePkgSzId = myServicePkgSzId;
            this.MyServiceModDtTm = myServiceModDtTm;
            this.PackageSizeWeightUOMCode = packageSizeWeightUOMCode;
        }

        public string PackageSizeDescription { get; set; }

        public int UnitPerPackage { get; set; }

        public short UnitWeightVolumeUOMId { get; set; }

        public decimal UnitWeightVolume { get; set; }

        public decimal PackageSizeVolume { get; set; }

        public short PackageSizeVolumeUOMId { get; set; }

        public decimal PackageSizeWeight { get; set; }

        public short PackageSizeWeightUOMId { get; set; }

        public decimal PackageSizeDensity { get; set; }

        public short PackageSizeDensityUOMId { get; set; }

        public string RegionCode { get; set; }

        public int MyServicePkgSzId { get; set; }

        public DateTime MyServiceModDtTm { get; set; }

        public string PackageSizeWeightUOMCode { get; set; }
    }
}
