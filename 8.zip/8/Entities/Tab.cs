﻿// -----------------------------------------------------------------------
// <copyright file="Tab.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tab object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System.Collections.Generic;

    /// <summary>
    ///     Class for holding Tab
    /// </summary>
    public class Tab
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="Tab" /> class.
        /// </summary>
        public Tab()
        {
            this.FieldGroups = new List<FieldGroup>();
        }

        /// <summary>
        ///     Gets or sets the List of fields
        /// </summary>
        /// <value>The id. field</value>
        public short Id { get; set; }

        /// <summary>
        ///     Gets or sets the List of fields
        /// </summary>
        /// <value>The field groups.</value>
        public List<FieldGroup> FieldGroups { get; set; }

        /// <summary>
        ///     Gets or sets the Tab Name
        /// </summary>
        /// <value>The name of the tab.</value>
        public string TabName { get; set; }

        /// <summary>
        ///     Gets or sets the tab Resource Key.
        /// </summary>
        /// <value>The resource key.</value>
        public string ResourceKey { get; set; }
    }
}