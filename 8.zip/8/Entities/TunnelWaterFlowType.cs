﻿// <copyright file="TunnelWaterFlowType.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelWaterFlowType object</summary>

namespace Entities
{
    using System;

    /// <summary>
    /// Class TunnelWaterFlowType
    /// </summary>
    public class TunnelWaterFlowType
    {
        #region "Constructor"

        /// <summary>
        /// Constructor TunnelWaterFlowType
        /// </summary>
        /// <param name="regionCode">RegionCode</param>
        /// <param name="tunnelWaterFlowTypeName">TunnelWaterFlowTypeName</param>
        /// <param name="is_Deleted">IsDeleted</param>
        /// <param name="myservicePropId">MyServicePropId</param>
        /// <param name="myserviceModDtTm">MyServiceModDtTm</param>
        public TunnelWaterFlowType(string regionCode, string tunnelWaterFlowTypeName, bool is_Deleted, Int16 myservicePropId, DateTime myserviceModDtTm, string spSp, string nrNR, string nlBE)
        {
            RegionCode = regionCode;
            TunnelWaterFlowTypeName = tunnelWaterFlowTypeName;
            Is_Deleted = is_Deleted;
            MyServicePropId = myservicePropId;
            MyServiceModDtTm = myserviceModDtTm;
            sp_SP = spSp;
            nr_NR = nrNR;
            nl_BE = nlBE;
        }

        /// <summary>
        ///     default constructor TunnelWaterFlowType
        /// </summary>
        public TunnelWaterFlowType()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets TunnelWaterFlowTypeID
        /// </summary>
        /// <value>TunnelWaterFlowTypeID .</value>
        public int TunnelWaterFlowTypeID { get; set; }

        /// <summary>
        ///     Gets or sets MyServicePropId
        /// </summary>
        /// <value>MyServicePropId.</value>
        public int MyServicePropId { get; set; }

        /// <summary>
        ///     Gets or sets TunnelWaterFlowTypeName
        /// </summary>
        /// <value>TunnelWaterFlowTypeName.</value>
        public string TunnelWaterFlowTypeName { get; set; }

        /// <summary>
        ///     Gets or sets Is_Deleted
        /// </summary>
        /// <value>Is_Deleted.</value>
        public bool Is_Deleted { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        /// Gets or sets RegionCode
        /// </summary>
        /// <value>RegionCode.</value> 
        public string RegionCode { get; set; }

        /// <summary>
        /// Gets or sets MyServiceModDtTm
        /// </summary>
        /// <value>MyServiceModDtTm.</value> 
        public DateTime MyServiceModDtTm { get; set; }

        #endregion
    }
}