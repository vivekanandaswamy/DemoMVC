﻿// -----------------------------------------------------------------------
// <copyright file="PlantContact.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Contact </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    /// <summary>
    ///     class PlantContact
    /// </summary>
    [Serializable]
    public class PlantContact
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantContact" /> class.
        /// </summary>
        public PlantContact()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantContact" /> class.
        /// </summary>
        /// <param name="id">The parameter id .</param>
        /// <param name="ecoalabAccountNumber">The parameter Ecoalab Account Number</param>
        /// <param name="contactFirstName">The parameter Contact First Name</param>
        /// <param name="contactLastName">The parameter Contact Last Name</param>
        /// <param name="contactTitle">The parameter Contact Title</param>
        /// <param name="contactPositionId">The parameter Contact Position</param>
        /// <param name="contactPositionName">The parameter position name</param>
        /// <param name="contactEmailAdresss">The parameter Contact Email Adresss</param>
        /// <param name="contactOfficePhone">The parameter Contact Fax Number</param>
        /// <param name="contactMobilePhone">The parameter Contact Mobile Phone</param>
        /// <param name="contactFaxNumber">The parameter Contact Office Phone</param>
        /// <param name="lastModifiedTime">The parameter Last Modified Time</param>
        public PlantContact(int? id,
                            string ecoalabAccountNumber,
                            string contactFirstName,
                            string contactLastName,
                            string contactTitle,
                            int contactPositionId,
                            string contactPositionName,
                            string contactEmailAdresss,
                            string contactOfficePhone,
                            string contactMobilePhone,  
                            string contactFaxNumber,
                            DateTime lastModifiedTime,
                            DateTime lastSyncTime,
                            bool is_Deleted,
                            Guid myServiceCntctGuid,                
                            DateTime myServiceLastSynchTime,
                            Int16 myServiceContactPositionId
                            )
        {
            Id = id;
            EcoalabAccountNumber = string.IsNullOrEmpty(ecoalabAccountNumber) ? ecoalabAccountNumber : ecoalabAccountNumber.Trim();
            ContactFirstName = contactFirstName;
            ContactLastName = contactLastName;
            ContactTitle = contactTitle;
            ContactPositionId = contactPositionId;
            ContactPositionName = contactPositionName;
            ContactEmailAdresss = contactEmailAdresss;
            ContactOfficePhone = contactOfficePhone;
            ContactMobilePhone = contactMobilePhone;
            ContactFaxNumber = contactFaxNumber;
            LastModifiedTimestamp = lastModifiedTime;
            LastSyncTime = lastSyncTime;
            IsDelete = is_Deleted;
            MyServiceCntctGuid = myServiceCntctGuid;
            MyServiceLastSynchTime = myServiceLastSynchTime;
            MyServiceContactPositionId = myServiceContactPositionId;
        }

        public PlantContact(string ecoalabAccountNumber,
                            string contactFirstName,
                            string contactTitle,
                            string contactLastName,
                            Int16 myServiceContactPositionId,
                            string contactEmailAdresss,
                            string contactOfficePhone,
                            string contactMobilePhone,
                            string contactFaxNumber,
                            bool is_Deleted,
                            Guid myServicceCntctGuid,                
                            DateTime myServiceLastSynchTime
                            )
        {
            EcoalabAccountNumber = ecoalabAccountNumber;
            ContactFirstName = contactFirstName;
            ContactTitle = contactTitle;
            ContactLastName = contactLastName;
            MyServiceContactPositionId = myServiceContactPositionId;
            ContactEmailAdresss = contactEmailAdresss;
            ContactOfficePhone = contactOfficePhone;
            ContactMobilePhone = contactMobilePhone;
            ContactFaxNumber = contactFaxNumber;
            IsDelete = is_Deleted;
            MyServiceCntctGuid = myServicceCntctGuid;
            MyServiceLastSynchTime = myServiceLastSynchTime;
        }

        /// <summary>
        ///     Gets or sets Id
        /// </summary>
        /// <value> Plant contact Id.</value>
        public int? Id { get; set; }

        /// <summary>
        ///     Gets or sets EcoalabAccountNumber
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets  ContactFirstName
        /// </summary>
        /// <value> Contact First Name </value>
        public string ContactFirstName { get; set; }

        /// <summary>
        ///     Gets or sets ContactLastName
        /// </summary>
        /// <value> Contact Larst Name </value>
        public string ContactLastName { get; set; }

        /// <summary>
        ///     Gets or sets ContactTitle
        /// </summary>
        /// <value> Contact Title </value>
        public string ContactTitle { get; set; }

        /// <summary>
        ///     Gets or sets ContactPositionId
        /// </summary>
        /// <value> Contact Position </value>
        public int ContactPositionId { get; set; }

        /// <summary>
        ///     Gets or sets ContactPositionName
        /// </summary>
        /// <value> Contact PositionName </value>
        public string ContactPositionName { get; set; }

        /// <summary>
        ///     Gets or sets ContactEmailAdresss
        /// </summary>
        /// <value> Contact Email Adresss </value>
        public string ContactEmailAdresss { get; set; }

        /// <summary>
        ///     Gets or sets ContactOfficePhone
        /// </summary>
        /// <value> Contact Office Phone </value>
        public string ContactOfficePhone { get; set; }

        /// <summary>
        ///     Gets or sets ContactMobilePhone
        /// </summary>
        /// <value> Contact Mobile Phone </value>
        public string ContactMobilePhone { get; set; }

        /// <summary>
        ///     Gets or sets ContactFaxNumber
        /// </summary>
        /// <value> Contact Fax Number </value>
        public string ContactFaxNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCntctGuid
        /// </summary>
        public Guid MyServiceCntctGuid { get; set; }

        /// <summary>
        /// Gest or sets MyServiceLastSynchTime
        /// </summary>
        public DateTime MyServiceLastSynchTime { get; set; }

        /// <summary>
        /// Gets or sets MyServiceContactPositionId
        /// It is use to only get contact position id from contactPositiontable from Conduit
        /// </summary>
        public int MyServiceContactPositionId { get; set; }
    }
}