﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainProgram.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Chain Program</summary>
// -----------------------------------------------------------------------

using System;

namespace Entities
{
    /// <summary>
    ///     class Plant Chain Program
    /// </summary>
    public class PlantChainProgram
    {
        #region "Constructor"

        /// <summary>
        /// constructor Plant Chain Program for myservice get
        /// </summary>
        /// <param name="plantProgramId">The plant Program Id .</param>
        /// <param name="plantProgramName">The plant Program Name</param>
        public PlantChainProgram(int plantProgramId, string plantProgramName)
        {
            this.PlantProgramId = plantProgramId;
            this.PlantProgramName = plantProgramName;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PlantChainProgram" /> class.
        /// </summary>
        /// <param name="plantProgramId">The plant program identifier.</param>
        /// <param name="plantProgramName">Name of the plant program.</param>
        /// <param name="chainTextileCategoryId">The chain textile category identifier.</param>
        /// <param name="chainTextileCategoryName">Name of the chain textile category.</param>
        /// <param name="ecolabtextileCategoryId">The ecolabtextile category identifier.</param>
        /// <param name="ecolabTextileCatName">Name of the ecolab textile cat.</param>
        /// <param name="formulaSegmentId">The formula segment identifier.</param>
        /// <param name="formulaSegmentName">Name of the formula segment.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <param name="ecolabSaturationId">The ecolab saturation identifier.</param>
        /// <param name="ecolabSaturationName">Name of the ecolab saturation.</param>
        public PlantChainProgram(int plantProgramId, string plantProgramName, int? chainTextileCategoryId, string chainTextileCategoryName,
            int? ecolabtextileCategoryId,string ecolabTextileCatName, int formulaSegmentId, string formulaSegmentName, DateTime lastModifiedTime, bool isDeleted, 
            int plantChainId, int ecolabSaturationId, string ecolabSaturationName)
        {
            this.PlantProgramId = plantProgramId;
            this.PlantProgramName = plantProgramName;
            this.ChainTextileId = chainTextileCategoryId;
            this.ChainTextileCategoryName = chainTextileCategoryName;
            this.EcolabTextileId = ecolabtextileCategoryId;
            this.EcolabCategoryName = ecolabTextileCatName;
            this.FormulaSegmentId = formulaSegmentId;
            this.FormulaSegmentName = formulaSegmentName;
            this.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTime, DateTimeKind.Utc);
            this.IsDeleted = isDeleted;
            this.PlantChainId = plantChainId;
            this.EcolabSaturationId = ecolabSaturationId;
            this.EcolabSaturationName = ecolabSaturationName;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PlantChainProgram" /> class.
        /// </summary>
        /// <param name="plantProgramId">The plant program identifier.</param>
        /// <param name="plantProgramName">Name of the plant program.</param>
        /// <param name="formulaCatId">The formula cat identifier.</param>
        /// <param name="forCatName">Name of for cat.</param>
        /// <param name="formulaSegId">The formula seg identifier.</param>
        /// <param name="forSegmentName">Name of for segment.</param>
        /// <param name="saturationId">The saturation identifier.</param>
        /// <param name="saturationName">Name of the saturation.</param>
        public PlantChainProgram(int plantProgramId, string plantProgramName, int formulaCatId, string forCatName, int formulaSegId, string forSegmentName, int saturationId, string saturationName)
        {
            this.PlantProgramId = plantProgramId;
            this.PlantProgramName = plantProgramName;
            this.FormulaCategoryId = formulaCatId;
            this.FormulaCategoryName = forCatName;
            this.FormulaSegmentId = formulaSegId;
            this.FormulaSegmentName = forSegmentName;
            this.EcolabSaturationId = saturationId;
            this.EcolabSaturationName = saturationName;
        }
        /// <summary>
        ///     default constructor PlantChainProgram
        /// </summary>
        public PlantChainProgram()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets Plant Program Id
        /// </summary>
        /// <value>Plant Program Id .</value>
        public int PlantProgramId { get; set; }

        /// <summary>
        ///     Gets or sets Plant Program Name
        /// </summary>
        /// <value>Plant Program Name.</value>
        public string PlantProgramName { get; set; }

        /// <summary>
        /// Gets or sets the chain textile identifier.
        /// </summary>
        /// <value>The chain textile identifier.</value>
        public int FormulaCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the name of the chain textile.
        /// </summary>
        /// <value>The name of the chain textile.</value>
        public string FormulaCategoryName { get; set; }

        /// <summary>
        /// Gets or sets the formula segment identifier.
        /// </summary>
        /// <value>The formula segment identifier.</value>
        public int FormulaSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the name of the formula segment.
        /// </summary>
        /// <value>The name of the formula segment.</value>
        public string FormulaSegmentName { get; set; }

        /// <summary>
        /// Gets or sets the ecolab saturation identifier.
        /// </summary>
        /// <value>The ecolab saturation identifier.</value>
        public int EcolabSaturationId { get; set; }

        /// <summary>
        /// Gets or sets the name of the ecolab saturation.
        /// </summary>
        /// <value>The name of the ecolab saturation.</value>
        public string EcolabSaturationName { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value>if this instance is deleted</value>
        public bool IsDeleted { get; set; }
        /// <summary>
        ///     Gets or sets the Pieces.
        /// </summary>
        /// <value> The Pieces value.</value>
        public int? EcolabTextileId { get; set; }
        /// <summary>
        /// chainTextileCategoryName
        /// </summary>
        /// <value>
        /// The name of the ecolab category.
        /// </value>
        public string EcolabCategoryName { get; set; }
        /// <summary>
        /// Gets or sets the name of the LastModifiedTime
        /// </summary>
        /// <value>The name of the LastModifiedTime.</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets the TextileId.
        /// </summary>
        /// <value> The Textile Id.</value>
        public int? ChainTextileId { get; set; }

        /// <summary>
        /// chainTextileCategoryName
        /// </summary>
        /// <value>
        /// The name of the chain textile category.
        /// </value>
        public string ChainTextileCategoryName { get; set; }

        /// <summary>
        /// Gets or sets the plant chain identifier.
        /// </summary>
        /// <value>The plant chain identifier.</value>
        public int PlantChainId { get; set; }

        #endregion
    }
}