﻿// -----------------------------------------------------------------------
// <copyright file="GroupType.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The GroupType </summary>
// -----------------------------------------------------------------------

namespace Entities.Common
{
    /// <summary>
    ///     Entity class for group type
    /// </summary>
    public class GroupType
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="groupTypeId"> Utility location type id </param>
        /// <param name="groupDescription"> Utility location name </param>
        /// <param name="groupMainType"> Group Main Type</param>
        /// <param name="isTunnel">Parameter Is Tunnel</param>
        public GroupType(int groupTypeId, string groupDescription, int groupMainType, bool isTunnel, int controllerModelId)
        {
            this.GroupTypeId = groupTypeId;
            this.GroupDescription = groupDescription;
            this.GroupMainType = groupMainType;
            this.IsTunnel = isTunnel;
            this.ControllerModelId = controllerModelId;
        }

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="groupTypeId"> Utility location type id </param>
        /// <param name="groupDescription"> Utility location name </param>
        /// <param name="groupMainType"> Group Main Type</param>
        /// <param name="isTunnel">Parameter Is Tunnel</param>
        public GroupType(int groupTypeId, string groupDescription, int groupMainType, bool isTunnel)
        {
            this.GroupTypeId = groupTypeId;
            this.GroupDescription = groupDescription;
            this.GroupMainType = groupMainType;
            this.IsTunnel = isTunnel;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public GroupType()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the GroupTypeId.
        /// </summary>
        /// <value> Group Type Id.</value>
        public int GroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupDescription.
        /// </summary>
        /// <value> Group Description.</value>
        public string GroupDescription { get; set; }

        /// <summary>
        ///     Gets or sets the GroupMainType.
        /// </summary>
        /// <value> Group Main Type.</value>
        public int GroupMainType { get; set; }

        /// <summary>
        ///     Gets or sets the IsTunnel.
        /// </summary>
        /// <value>Is Tunnel.</value>
        public bool IsTunnel { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId.
        /// </summary>
        /// <value> ControllerModelId.</value>
        public int ControllerModelId { get; set; }

        #endregion
    }
}