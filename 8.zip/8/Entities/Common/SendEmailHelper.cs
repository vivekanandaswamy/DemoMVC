﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;

namespace Entities.Common
{
    public class SendEmailHelper
    {
        public void SendEmail(string tmName, int syncLapseTime, string senderName, string senderEmail, string subject, string body)
        {
            SendMail(senderEmail, senderName, body, subject, tmName);
        }

       

        private void SendMail(string senderEmail, string senderName, string body, string subject, string recipientEmail)
        {
            try
            {
                var mailClient = new SmtpClient();
                var mail = new MailMessage
                {
                    From = new MailAddress(senderEmail, senderName),
                    Subject = subject,
                    Body = body,
                    Priority = MailPriority.High,
                    IsBodyHtml = true
                };

                mail.To.Add(recipientEmail);
                mailClient.EnableSsl = true;
                System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                mailClient.UseDefaultCredentials = true;
                mailClient.Credentials = NetworkCred;
                mailClient.Port = 465;
                mailClient.Send(mail);
            }
            catch (Exception ex)
            {

                
            }
            
        }
    }
}
