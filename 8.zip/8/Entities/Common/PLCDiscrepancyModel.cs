﻿// -----------------------------------------------------------------------
// <copyright file="PLCDiscrepancyModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Sync Email Service Class </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Entities.Common
{
    public class PLCDiscrepancyModel
    {
        /// <summary>
        /// Initializes the PLCDiscrepancyModel class.
        /// </summary>
        public PLCDiscrepancyModel()
        {

        }
        /// <summary>
        /// Initializes the PLCDiscrepancyModel class.
        /// </summary>
        /// <param name="controllerNumber">The controllerNumber</param>
        /// <param name="controllerName">The controllerName</param>
        /// <param name="syncFromCentral">Is sync from central</param>
        /// <param name="parentEntityType">Parent Entity Type</param>
        /// <param name="entityType">The entity Type</param>
        /// <param name="parentEntityId">The parent Entity Id</param>
        /// <param name="entityId">The entityId</param>
        /// <param name="controllerId">The controllerId</param>
        /// <param name="parentEntityName">The parent Entity Name</param>
        /// <param name="entityName">The entity Name</param>
        /// <param name="washerGroupType">The washer Group Type</param>
        /// <param name="userName">The user Name</param>
        public PLCDiscrepancyModel(int controllerNumber, string controllerName, bool syncFromCentral,
            int parentEntityType, int entityType, int parentEntityId, int entityId, int controllerId, string parentEntityName, 
            string entityName, byte washerGroupType, string userName)
        {
            this.ControllerNumber = controllerNumber;
            this.ControllerName = controllerName;
            this.IsCentral = syncFromCentral;
            this.ParentEntity = parentEntityType;
            this.Entity = entityType;
            this.ParentEntityId = parentEntityId;
            this.EntityId = entityId;
            this.ControllerId = controllerId;
            this.ParentEntityName = parentEntityName;
            this.EntityName = entityName;
            this.WasherGroupType = washerGroupType;
            this.UserName = userName;            
        }

        /// <summary>
        ///     Gets or sets Parent Entity 
        /// </summary>
        /// <value>The ParentEntity .</value>
        public int ParentEntity { get; set; }

        /// <summary>
        ///     Gets or sets Entity 
        /// </summary>
        /// <value>The Entity .</value>
        public int Entity { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity Id
        /// </summary>
        /// <value>The ParentEntityId .</value>
        public int ParentEntityId { get; set; }

        /// <summary>
        ///     Gets or sets Entity Id
        /// </summary>
        /// <value>The EntityId .</value>
        public int EntityId { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity Name
        /// </summary>
        /// <value>The ParentEntityName .</value>
        public string ParentEntityName { get; set; }

        /// <summary>
        ///     Gets or sets Entity Name
        /// </summary>
        /// <value>The EntityName.</value>
        public string EntityName { get; set; }

        /// <summary>
        ///     Gets or sets Whether it is Central 
        /// </summary>
        /// <value>The IsCentral .</value>
        public bool IsCentral { get; set; }

        /// <summary>
        ///     Gets or sets Controller Id of the Entity
        /// </summary>
        /// <value>The ControllerId .</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets Controller number.
        /// </summary>
        /// <value>The ControllerNumber .</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets Controller number.
        /// </summary>
        /// <value>The ControllerNumber .</value>
        public int ControllerNumber { get; set; }

        /// <summary>
        ///     Gets or sets Whether it is an error from PLC 
        /// </summary>
        /// <value>The IsPLCError .</value>
        public bool IsPLCError { get; set; }

        /// <summary>
        ///     Gets or sets User Id
        /// </summary>
        /// <value>The UserId .</value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets User Name
        /// </summary>
        /// <value>The UserName.</value>
        public string UserName { get; set; }

        /// <summary>
        ///     Gets or sets Id of User performing sync on entities 
        /// </summary>
        /// <value>The ParentEntity .</value>
        public int LastModifiedUserId { get; set; }
        /// <summary>
        ///     Gets or Sets the washer group type
        /// </summary>
        public byte WasherGroupType { get; set; }
    }
}