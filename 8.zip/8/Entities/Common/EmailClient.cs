﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Common
{
    public class MailClient
    {
        public MailClient()
        {
            SenderEmail = ConfigurationManager.AppSettings["SenderEmail"];
            SenderName = ConfigurationManager.AppSettings["SenderName"];

        }

        public MailClient(string tmName, string plantName, string body)
        {
            SenderEmail = ConfigurationManager.AppSettings["SenderEmail"];
            SenderName = ConfigurationManager.AppSettings["SenderName"];
            Body = body;
        }

        public string SenderEmail { get; set; }

        public string SenderName { get; set; }

        public string RecipientName { get; set; }

        public string RecipientEmail { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }

        public string Host { get; set; }

        public string UserName { get; set; }

        public string PassWord { get; set; }

        public void SendMail()
        {
            var mailClient = new SmtpClient();
            var mail = new MailMessage
            {
                From = new MailAddress(SenderEmail, SenderName),
                Subject = Subject,
                Body = Body,
                Priority = MailPriority.High,
                IsBodyHtml = true
            };

            mail.To.Add(RecipientEmail);

            mailClient.Send(mail);
        }
    }
}
