﻿// -----------------------------------------------------------------------
// <copyright file="ModuleTagsModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ModuleTagsModel </summary>
// -----------------------------------------------------------------------

namespace Entities.Common
{
    public class ModuleTagsModel
    {
        #region Constructor

        /// <summary>
        /// Parametrized constructor
        /// </summary>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        /// <param name="moduleTagId">ModuleTagId</param>
        /// <param name="tagType">TagType</param>
        /// <param name="tagAddress">TagAddress</param>
        /// <param name="moduleTypeId">ModuleTypeId</param>
        /// <param name="moduleId">ModuleId</param>
        /// <param name="deadBand">The dead band.</param>
        /// <param name="active">Active</param>
        /// String, Int32, String, String, Int32, Int32, Double, Boolean
        public ModuleTagsModel(string ecolabAccountNumber, int moduleTagId, string tagType, string tagAddress, int moduleTypeId, int moduleId, double deadBand, bool active)
        {
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ModuleTagId = moduleTagId;
            this.TagType = tagType;
            this.TagAddress = tagAddress;
            this.ModuleTypeId = moduleTypeId;
            this.ModuleId = moduleId;
            this.DeadBand = deadBand;
            this.Active = active;
        }

        /// <summary>
        ///     Default Constructor
        /// </summary>
        public ModuleTagsModel()
        {
        }

        #endregion

        #region Properties

        /// <summary>
        ///     Gets or sets ModuleTagId
        /// </summary>
        public int ModuleTagId { get; set; }

        /// <summary>
        ///     Gets or sets EcolabAccountNumber
        /// </summary>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets TagType
        /// </summary>
        public string TagType { get; set; }

        /// <summary>
        ///     Gets or sets TagAddress
        /// </summary>
        public string TagAddress { get; set; }

        /// <summary>
        ///     Gets or sets ModuleTypeId
        /// </summary>
        public int ModuleTypeId { get; set; }

        /// <summary>
        ///     Gets or sets ModuleId
        /// </summary>
        public int ModuleId { get; set; }

        /// <summary>
        ///     Gets or sets DeadBand
        /// </summary>
        public double DeadBand { get; set; }

        /// <summary>
        ///     Gets or sets Active
        /// </summary>
        public bool Active { get; set; }

        #endregion
    }
}