﻿// -----------------------------------------------------------------------
// <copyright file="LaborType.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LaborType </summary>
// -----------------------------------------------------------------------

namespace Entities.Common
{
    /// <summary>
    ///     Entity class for LaborType
    /// </summary>
    public class LaborType
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor.
        /// </summary>
        /// <param name="laborTypeId"> Labor TypeId. </param>
        /// <param name="description"> Device type name. </param>
        public LaborType(int laborTypeId, string description)
        {
            this.LaborTypeId = laborTypeId;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor.
        /// </summary>
        public LaborType()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the LaborTypeId.
        /// </summary>
        /// <value> Labor TypeId.</value>
        public int LaborTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Labor type name.</value>
        public string Description { get; set; }

        #endregion
    }
}