﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactPosition.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantContactPosition </summary>
// -----------------------------------------------------------------------

namespace Entities.Common
{
    using System;

    /// <summary>
    ///     entity class for PlantContactPosition
    /// </summary>
    public class PlantContactPosition : BaseEntity
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="id">position id</param>
        /// <param name="positionName">position name</param>
        public PlantContactPosition(int id, string positionName)
        {
            Id = id;
            PositionName = positionName;
        }

        public PlantContactPosition(string positionName, bool isDeleted, short myServiceCntctPosnId, DateTime myServiceModDtTm, string sp, string nr, string nlbe)
        {
            PositionName = positionName;
            IsDeleted = isDeleted;
            MyServiceCntctPosnId = myServiceCntctPosnId;
            MyServiceModDtTm = myServiceModDtTm;
            sp_SP = sp;
            nr_NR = nr;
            nl_BE = nlbe;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public PlantContactPosition()
        {
        }

        /// <summary>
        ///     Gets or sets the PositionName
        /// </summary>
        /// <value>Position Name</value>
        public string PositionName { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        public short MyServiceCntctPosnId { get; set; }

        public DateTime MyServiceModDtTm { get; set; }
    }
}