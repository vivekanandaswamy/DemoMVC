﻿// -----------------------------------------------------------------------
// <copyright file="ResourceMaster.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Resource Master </summary>
// -----------------------------------------------------------------------

namespace Entities.Common
{
    /// <summary>
    /// </summary>
    public class ResourceMaster
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="resourceId">resource Id</param>
        /// <param name="name">resource name </param>
        public ResourceMaster(int resourceId, string name)
        {
            this.ResourceId = resourceId;
            this.Name = name;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ResourceMaster()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the ResourceId.
        /// </summary>
        /// <value> ResourceId.</value>
        public int ResourceId { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value> Name.</value>
        public string Name { get; set; }

        #endregion
    }
}