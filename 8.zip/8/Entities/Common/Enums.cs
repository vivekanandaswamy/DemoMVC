﻿// -----------------------------------------------------------------------
// <copyright file="Enums.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Enums class </summary>

namespace Entities.Common
{
    /// <summary>
    ///     Class for Enums which can be used commonly.
    /// </summary>
    public class Enums
    {
        /// <summary>
        ///     Enum for State of the compartment
        /// </summary>
        public enum CompartmentState
        {
            /// <summary>
            ///     Enum Empty
            /// </summary>
            Empty = 0,

            /// <summary>
            ///     Enum Processing
            /// </summary>
            Processing = 1,

            /// <summary>
            ///     Enum Transferring
            /// </summary>
            Transferring = 2,

            /// <summary>
            ///     Enum Stopped
            /// </summary>
            Stopped = 3
        }
    }
}