﻿// -----------------------------------------------------------------------
// <copyright file="ConduitController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Controller</summary>
// -----------------------------------------------------------------------

namespace Entities.Common
{
    /// <summary>
    ///     Entity class for ConduitController
    /// </summary>
    public class ConduitController
    {
        #region "Constructor"

        /// <summary>
        ///     Conduit Controller
        /// </summary>
        /// <param name="controllerId">controller ID</param>
        /// <param name="name">Controller name</param>
        /// <param name="controllerModelId">controller Model</param>
        /// <param name="controllerModelName">controller Model Name</param>
        /// <param name="regionId">region</param>
        /// <param name="controllerTypeId">controller Type Id</param>
        /// <param name="controllerType">controller Type</param>
        public ConduitController(int controllerId, string name, int controllerModelId, string controllerModelName, int regionId, int controllerTypeId, string controllerType)
        {
            this.ControllerId = controllerId;
            this.Name = name;
            this.ControllerModelId = controllerModelId;
            this.ControllerModelName = controllerModelName;
            this.RegionId = regionId;
            this.ControllerTypeId = controllerTypeId;
            this.ControllerType = controllerType;
        }
        /// <summary>
        ///     Conduit Controller
        /// </summary>
        /// <param name="controllerId">controller ID</param>
        /// <param name="name">Controller name</param>
        /// <param name="controllerModelId">controller Model</param>
        /// <param name="controllerModelName">controller Model Name</param>
        /// <param name="regionId">region</param>
        /// <param name="controllerTypeId">controller Type Id</param>
        /// <param name="controllerType">controller Type</param>
        public ConduitController(int controllerId, string name, int controllerModelId, string controllerModelName, int regionId, int controllerTypeId, string controllerType, bool iSWaterEnergyLogSel)
        {
            this.ControllerId = controllerId;
            this.Name = name;
            this.ControllerModelId = controllerModelId;
            this.ControllerModelName = controllerModelName;
            this.RegionId = regionId;
            this.ControllerTypeId = controllerTypeId;
            this.ControllerType = controllerType;
            this.ISWaterEnergyLogSel = iSWaterEnergyLogSel;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ConduitController()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the ControllerId
        /// </summary>
        /// <value> controller id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value> controller name</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value> Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Name
        /// </summary>
        /// <value> Controller Model Name</value>
        public string ControllerModelName { get; set; }

        /// <summary>
        ///     Gets or Sets the controller region Id
        /// </summary>
        /// <value>Controller Region Id</value>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type Id
        /// </summary>
        /// <value> Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type
        /// </summary>
        /// <value> Controller Type</value>
        public string ControllerType { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>The ISWaterEnergyLogSel value</value>
        public bool ISWaterEnergyLogSel { get; set; }

        #endregion
    }
}