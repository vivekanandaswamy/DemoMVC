﻿// -----------------------------------------------------------------------
// <copyright file="BatchParameterData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchParameterData </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Batch
{
    /// <summary>
    /// Class for BatchParameterData
    /// </summary>
    public class BatchParameterData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BatchParameterData"/> class.
        /// </summary>
        /// <param name="batchId">The batch identifier.</param>
        /// <param name="ecolabWasherId">The ecolab washer identifier.</param>
        /// <param name="parameterId">The parameter identifier.</param>
        /// <param name="parameterValue">The parameter value.</param>
        /// <param name="partitionOn">The partition on.</param>
        public BatchParameterData(int batchId, int ecolabWasherId, int parameterId, string parameterValue, DateTime partitionOn)
        {
            this.BatchId = batchId;
            this.EcolabWasherId = ecolabWasherId;
            this.ParameterId = parameterId;
            this.ParameterValue = parameterValue;
            this.PartitionOn = partitionOn;
        }

        /// <summary>
        /// Gets or sets the batch identifier.
        /// </summary>
        /// <value>
        /// The batch identifier.
        /// </value>
        public int BatchId { get; set; }

        /// <summary>
        /// Gets or sets the ecolab washer identifier.
        /// </summary>
        /// <value>
        /// The ecolab washer identifier.
        /// </value>
        public int EcolabWasherId { get; set; }

        /// <summary>
        /// Gets or sets the parameter identifier.
        /// </summary>
        /// <value>
        /// The parameter identifier.
        /// </value>
        public int ParameterId { get; set; }

        /// <summary>
        /// Gets or sets the parameter value.
        /// </summary>
        /// <value>
        /// The parameter value.
        /// </value>
        public string ParameterValue { get; set; }

        /// <summary>
        /// Gets or sets the partition on.
        /// </summary>
        /// <value>
        /// The partition on.
        /// </value>
        public DateTime PartitionOn { get; set; }
    }
}