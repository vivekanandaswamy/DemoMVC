﻿// -----------------------------------------------------------------------
// <copyright file="BatchData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchData </summary>
// -----------------------------------------------------------------------

namespace Entities.Batch
{
	using System;

	public class BatchData
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="BatchData"/> class.
		/// </summary>
		public BatchData()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="BatchData"/> class.
		/// </summary>
		/// <param name="batchId">The batch identifier.</param>
		/// <param name="controllerBatchId">The controller batch identifier.</param>
		/// <param name="ecolabWasherId">The ecolab washer identifier.</param>
		/// <param name="groupId">The group identifier.</param>
		/// <param name="machineInternalId">The machine internal identifier.</param>
		/// <param name="plantWasherNumber">The plant washer number.</param>
		/// <param name="startDate">The start date.</param>
		/// <param name="endDate">The end date.</param>
		/// <param name="programNumber">The program number.</param>
		/// <param name="programMasterId">The program master identifier.</param>
		/// <param name="machineId">The machine identifier.</param>
		/// <param name="actualWeight">The actual weight.</param>
		/// <param name="standardWeight">The standard weight.</param>
		/// <param name="currencyCode">The currency code.</param>
		/// <param name="lastSyncTime">The last synchronize time.</param>
		/// <param name="manualInputWeight">The manual input weight.</param>
		/// <param name="lastModifiedByUserId">The last modified by user identifier.</param>
		/// <param name="partitionOn">The partition on.</param>
		/// <param name="endDateFormula">The end date formula.</param>
		/// <param name="shiftId">The shift identifier.</param>
		/// <param name="targetTurnTime">The target turn time.</param>
		/// <param name="ecolabTextileCategoryId">The ecolab textile category identifier.</param>
		/// <param name="chainTextileCategoryId">The chain textile category identifier.</param>
		/// <param name="formulaSegmentId">The formula segment identifier.</param>
		/// <param name="ecolabSaturationId">The ecolab saturation identifier.</param>
		/// <param name="plantProgramId">The plant program identifier.</param>
		/// <param name="syncReady">if set to <c>true</c> [synchronize ready].</param>
		/// <param name="stdInjectionSteps">The standard injection steps.</param>
		/// <param name="stdWashSteps">The standard wash steps.</param>
		/// <param name="eTechlastDroppedTimestamp">The e techlast dropped time stamp.</param>
		public BatchData(int batchId,
			int controllerBatchId,
			int ecolabWasherId,
			int groupId,
			byte machineInternalId,
			Int16 plantWasherNumber,
			DateTime startDate,
			DateTime endDate,
			int programNumber,
			int programMasterId,
			int machineId,
			int actualWeight,
			int standardWeight,
			string currencyCode,
			DateTime lastSyncTime,
			int manualInputWeight,
			int lastModifiedByUserId,
			DateTime partitionOn,
			DateTime endDateFormula,
			int shiftId,
			int targetTurnTime,
			int ecolabTextileCategoryId,
			int chainTextileCategoryId,
			int formulaSegmentId,
			int ecolabSaturationId,
			int plantProgramId,
			bool syncReady,
			int stdInjectionSteps,
			int stdWashSteps,
			DateTime? eTechlastDroppedTimestamp
			)
		{
			this.BatchId = batchId;
			this.ControllerBatchId = controllerBatchId;
			this.EcolabWasherId = ecolabWasherId;
			this.GroupId = groupId;
			this.MachineInternalId = machineInternalId;
			this.PlantWasherNumber = plantWasherNumber;
			this.StartDate = startDate;
			this.EndDate = endDate;
			this.ProgramNumber = programNumber;
			this.ProgramMasterId = programMasterId;
			this.MachineId = machineId;
			this.ActualWeight = actualWeight;
			this.StandardWeight = standardWeight;
			this.CurrencyCode = currencyCode;
			this.LastSyncTime = lastSyncTime;
			this.ManualInputWeight = manualInputWeight;
			this.LastModifiedByUserId = lastModifiedByUserId;
			this.PartitionOn = partitionOn;
			this.EndDateFormula = endDateFormula;
			this.ShiftId = shiftId;
			this.TargetTurnTime = targetTurnTime;
			this.EcolabTextileCategoryId = ecolabTextileCategoryId;
			this.ChainTextileCategoryId = chainTextileCategoryId;
			this.FormulaSegmentId = formulaSegmentId;
			this.EcolabSaturationId = ecolabSaturationId;
			this.PlantProgramId = plantProgramId;
			this.SyncReady = syncReady;
			this.StdInjectionSteps = stdInjectionSteps;
			this.StdWashSteps = stdWashSteps;
			this.ETechlastDroppedTimestamp = eTechlastDroppedTimestamp;
		}

		/// <summary>
		/// Gets or sets the batch identifier.
		/// </summary>
		/// <value>
		/// The batch identifier.
		/// </value>
		public int BatchId { get; set; }

		/// <summary>
		/// Gets or sets the controller batch identifier.
		/// </summary>
		/// <value>
		/// The controller batch identifier.
		/// </value>
		public int ControllerBatchId { get; set; }

		/// <summary>
		/// Gets or sets the ecolab washer identifier.
		/// </summary>
		/// <value>
		/// The ecolab washer identifier.
		/// </value>
		public int EcolabWasherId { get; set; }

		/// <summary>
		/// Gets or sets the group identifier.
		/// </summary>
		/// <value>
		/// The group identifier.
		/// </value>
		public int GroupId { get; set; }

		/// <summary>
		/// Gets or sets the machine internal identifier.
		/// </summary>
		/// <value>
		/// The machine internal identifier.
		/// </value>
		public byte MachineInternalId { get; set; }

		/// <summary>
		/// Gets or sets the plant washer number.
		/// </summary>
		/// <value>
		/// The plant washer number.
		/// </value>
		public Int16 PlantWasherNumber { get; set; }

		/// <summary>
		/// Gets or sets the start date.
		/// </summary>
		/// <value>
		/// The start date.
		/// </value>
		public DateTime StartDate { get; set; }

		/// <summary>
		/// Gets or sets the end date.
		/// </summary>
		/// <value>
		/// The end date.
		/// </value>
		public DateTime EndDate { get; set; }

		/// <summary>
		/// Gets or sets the program number.
		/// </summary>
		/// <value>
		/// The program number.
		/// </value>
		public int ProgramNumber { get; set; }

		/// <summary>
		/// Gets or sets the program master identifier.
		/// </summary>
		/// <value>
		/// The program master identifier.
		/// </value>
		public int ProgramMasterId { get; set; }

		/// <summary>
		/// Gets or sets the machine identifier.
		/// </summary>
		/// <value>
		/// The machine identifier.
		/// </value>
		public int MachineId { get; set; }

		/// <summary>
		/// Gets or sets the actual weight.
		/// </summary>
		/// <value>
		/// The actual weight.
		/// </value>
		public int ActualWeight { get; set; }

		/// <summary>
		/// Gets or sets the standard weight.
		/// </summary>
		/// <value>
		/// The standard weight.
		/// </value>
		public int StandardWeight { get; set; }

		/// <summary>
		/// Gets or sets the currency code.
		/// </summary>
		/// <value>
		/// The currency code.
		/// </value>
		public string CurrencyCode { get; set; }

		/// <summary>
		/// Gets or sets the last synchronize time.
		/// </summary>
		/// <value>
		/// The last synchronize time.
		/// </value>
		public DateTime LastSyncTime { get; set; }

		/// <summary>
		/// Gets or sets the manual input weight.
		/// </summary>
		/// <value>
		/// The manual input weight.
		/// </value>
		public int ManualInputWeight { get; set; }

		/// <summary>
		/// Gets or sets the last modified by user identifier.
		/// </summary>
		/// <value>
		/// The last modified by user identifier.
		/// </value>
		public int LastModifiedByUserId { get; set; }

		/// <summary>
		/// Gets or sets the partition on.
		/// </summary>
		/// <value>
		/// The partition on.
		/// </value>
		public DateTime PartitionOn { get; set; }

		/// <summary>
		/// Gets or sets the end date formula.
		/// </summary>
		/// <value>
		/// The end date formula.
		/// </value>
		public DateTime EndDateFormula { get; set; }

		/// <summary>
		/// Gets or sets the shift identifier.
		/// </summary>
		/// <value>
		/// The shift identifier.
		/// </value>
		public int ShiftId { get; set; }

		/// <summary>
		/// Gets or sets the target turn time.
		/// </summary>
		/// <value>
		/// The target turn time.
		/// </value>
		public int TargetTurnTime { get; set; }

		/// <summary>
		/// Gets or sets the ecolab textile category identifier.
		/// </summary>
		/// <value>
		/// The ecolab textile category identifier.
		/// </value>
		public int EcolabTextileCategoryId { get; set; }

		/// <summary>
		/// Gets or sets the chain textile category identifier.
		/// </summary>
		/// <value>
		/// The chain textile category identifier.
		/// </value>
		public int ChainTextileCategoryId { get; set; }

		/// <summary>
		/// Gets or sets the formula segment identifier.
		/// </summary>
		/// <value>
		/// The formula segment identifier.
		/// </value>
		public int FormulaSegmentId { get; set; }

		/// <summary>
		/// Gets or sets the ecolab saturation identifier.
		/// </summary>
		/// <value>
		/// The ecolab saturation identifier.
		/// </value>
		public int EcolabSaturationId { get; set; }

		/// <summary>
		/// Gets or sets the plant program identifier.
		/// </summary>
		/// <value>
		/// The plant program identifier.
		/// </value>
		public int PlantProgramId { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether [synchronize ready].
		/// </summary>
		/// <value>
		///   <c>true</c> if [synchronize ready]; otherwise, <c>false</c>.
		/// </value>
		public bool SyncReady { get; set; }

		/// <summary>
		/// Gets the standard injection steps.
		/// </summary>
		/// <value>
		/// The standard injection steps.
		/// </value>
		public int StdInjectionSteps { get; set; }

		/// <summary>
		/// Gets the standard wash steps.
		/// </summary>
		/// <value>
		/// The standard wash steps.
		/// </value>
		public int StdWashSteps { get; set; }

		/// <summary>
		/// Gets the e techlast dropped time stamp.
		/// </summary>
		/// <value>
		/// The e techlast dropped time stamp.
		/// </value>
		public DateTime? ETechlastDroppedTimestamp { get; set; }
	}
}