﻿// -----------------------------------------------------------------------
// <copyright file="BatchWashStepData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchWashStepData </summary>
// -----------------------------------------------------------------------

namespace Entities.Batch
{
    using System;

    public class BatchWashStepData
    {
        public BatchWashStepData(int batchId, int stepCompartment, DateTime startTime, DateTime endTime, int ecolabWasherId, DateTime partitionOn)
        {
            this.BatchId = batchId;
            this.StepCompartment = stepCompartment;
            this.StartTime = startTime;
            this.EndTime = endTime; 
            this.EcolabWasherId = ecolabWasherId;
            this.PartitionOn = partitionOn;
        }

        public int BatchId { get; set; }
        public int StepCompartment { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int EcolabWasherId { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}