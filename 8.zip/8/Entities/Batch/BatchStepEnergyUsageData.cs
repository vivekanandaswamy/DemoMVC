﻿// -----------------------------------------------------------------------
// <copyright file="BatchStepEnergyUsageData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchStepEnergyUsageData </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Batch
{
    public class BatchStepEnergyUsageData
    {
        public BatchStepEnergyUsageData(int batchId, int stepCompartment, int gasoilTypeId, double actualQuantity, double standardQuantity, double price, int ecolabWasherId, DateTime partitionOn)
        {
            this.BatchId = batchId;
            this.StepCompartment = stepCompartment;
            this.GasoilTypeId = gasoilTypeId;
            this.ActualQuantity = actualQuantity;
            this.StandardQuantity = standardQuantity;
            this.Price = price;
            this.EcolabWasherId = ecolabWasherId;
            this.PartitionOn = partitionOn;
        }

        public int BatchId { get; set; }
        public int StepCompartment { get; set; }
        public int GasoilTypeId { get; set; }
        public double ActualQuantity { get; set; }
        public double StandardQuantity { get; set; }
        public double Price { get; set; }
        public int EcolabWasherId { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}