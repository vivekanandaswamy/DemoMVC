﻿// -----------------------------------------------------------------------
// <copyright file="BatchCollection.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchCollection </summary>
// -----------------------------------------------------------------------

namespace Entities.Batch
{
    public class BatchCollection : BaseEntity
    {
        //public BatchData batchData { get; set; }
        public int BatchId { get; set; }
    }
}