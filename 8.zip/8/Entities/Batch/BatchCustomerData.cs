﻿// -----------------------------------------------------------------------
// <copyright file="BatchCustomerData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchCustomerData </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Batch
{
    public class BatchCustomerData
    {
        public BatchCustomerData(int batchId, int customerId, double weightLbs, int piecesCount, int ecolabWasherId, DateTime partitionOn)
        {
            this.BatchId = batchId;
            this.CustomerId = customerId;
            this.WeightLbs = weightLbs;
            this.PiecesCount = piecesCount;
            this.EcolabWasherId = ecolabWasherId;
            this.PartitionOn = partitionOn;
        }

        public int BatchId { get; set; }
        public int EcolabWasherId { get; set; }
        public int CustomerId { get; set; }
        public double WeightLbs { get; set; }
        public int PiecesCount { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}