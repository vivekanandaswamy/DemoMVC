﻿// -----------------------------------------------------------------------
// <copyright file="BatchProductData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchProductData </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Batch
{
    public class BatchProductData
    {
        public BatchProductData(int batchId, int stepCompartment, double actualQuantity, double standardQuantity, double price, int ecolabWasherId, DateTime partitionOn, DateTime timestamp, int productId)
        {
            this.BatchId = batchId;
            this.StepCompartment = stepCompartment;
            this.ActualQuantity = actualQuantity;
            this.StandardQuantity = standardQuantity;
            this.Price = price;
            this.EcolabWasherId = ecolabWasherId;
            this.PartitionOn = partitionOn;
            this.TimeStamp = timestamp;
            this.ProductId = productId;
        }

        public int BatchId { get; set; }
        public int StepCompartment { get; set; }
        public double ActualQuantity { get; set; }
        public double StandardQuantity { get; set; }
        public double Price { get; set; }
        public int EcolabWasherId { get; set; }
        public DateTime PartitionOn { get; set; }
        public DateTime TimeStamp { get; set; }
        public int ProductId { get; set; }
    }
}