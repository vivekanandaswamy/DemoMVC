﻿// -----------------------------------------------------------------------
// <copyright file="BatchParameterTypes.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchParameterTypes </summary>
// -----------------------------------------------------------------------

namespace Entities.Batch
{
    using System;

    public class BatchParameterTypes
    {
        public BatchParameterTypes(int batchParameterTypeId, string parameterName, DateTime createdDate)
        {
            this.BatchParameterTypeId = batchParameterTypeId;
            this.ParameterName = parameterName;
            this.CreatedDate = createdDate;
        }

        public int BatchParameterTypeId { get; set; }
        public string ParameterName { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}