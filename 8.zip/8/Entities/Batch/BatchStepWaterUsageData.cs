﻿// -----------------------------------------------------------------------
// <copyright file="BatchStepWaterUsageData.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BatchStepWaterUsageData </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.Batch
{
    public class BatchStepWaterUsageData
    {
        public BatchStepWaterUsageData(int batchId, int stepCompartment, int waterTypeId, double actualQuantity, double standardQuantity, double price, int ecolabWasherId, DateTime partitionOn)
        {
            this.BatchId = batchId;
            this.StepCompartment = stepCompartment;
            this.WaterTypeId = waterTypeId;
            this.ActualQuantity = actualQuantity;
            this.StandardQuantity = standardQuantity;
            this.Price = price;
            this.EcolabWasherId = ecolabWasherId;
            this.PartitionOn = partitionOn;
        }

        public int BatchId { get; set; }
        public int StepCompartment { get; set; }
        public int WaterTypeId { get; set; }
        public double ActualQuantity { get; set; }
        public double StandardQuantity { get; set; }
        public double Price { get; set; }
        public int EcolabWasherId { get; set; }
        public DateTime PartitionOn { get; set; }
    }
}