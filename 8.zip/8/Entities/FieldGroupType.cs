// -----------------------------------------------------------------------
// <copyright file="FieldGroupType.cs" company="Ecolab">
// �2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FieldGroupType object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System.Collections.Generic;

    /// <summary>
    ///     Class FieldGroupType
    /// </summary>
    public class FieldGroupType
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="FieldGroupType" /> class.
        /// </summary>
        public FieldGroupType()
        {
            this.FieldGroups = new List<FieldGroup>();
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="FieldGroupType" /> class.
        /// </summary>
        /// <param name="id">The id. field</param>
        /// <param name="name">The name. field</param>
        public FieldGroupType(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }

        /// <summary>
        ///     Gets or sets the id.
        /// </summary>
        /// <value>The id. field</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the field groups.
        /// </summary>
        /// <value>The field groups.</value>
        public List<FieldGroup> FieldGroups { get; set; }
    }
}