﻿// -----------------------------------------------------------------------
// <copyright file="ChainFormula.cs" company="Ecolab">
//  ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>The Chain Formula </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities
{
    public class ChainFormula
    {

        /// <summary>
        ///     default constructor ChainFormula
        /// </summary>
        public ChainFormula()
        {
        }

        /// <summary>
        /// Chain Formula - Parameterised Constructor
        /// </summary>
        /// <param name="plantProgramId">The plant program identifier.</param>
        /// <param name="plantProgramName">Name of the plant program.</param>
        /// <param name="chainTextileCategoryId">The chain textile category identifier.</param>
        /// <param name="formulaSegmentId">The formula segment identifier.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastModifiedByUserId">The last modified by user identifier.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <param name="ecolabSaturationId">The ecolab saturation identifier.</param>
        /// <param name="resourceKey">The resource key.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        public ChainFormula(int plantProgramId, string plantProgramName, int chainTextileCategoryId, int formulaSegmentId, DateTime lastModifiedTime, int lastModifiedByUserId, bool isDeleted, int plantChainId, int ecolabSaturationId, string resourceKey, DateTime lastSyncTime)
        {
            this.PlantProgramId = plantProgramId;
            this.PlantProgramName = plantProgramName;
            this.ChainTextileCategoryId = chainTextileCategoryId;
            this.FormulaSegmentId = formulaSegmentId;
            this.LastModifiedTime = lastModifiedTime;
            this.LastModifiedByUserId = lastModifiedByUserId;
            this.IsDeleted = isDeleted;
            this.PlantChainId = plantChainId;
            this.EcolabSaturationId = ecolabSaturationId;
            this.ResourceKey = resourceKey;
            this.LastSyncTime = lastSyncTime;
        }

        /// <summary>
        ///     Gets or sets PlantProgram Id
        /// </summary>
        /// <value>The PlantProgram Id .</value>
        public int PlantProgramId { get; set; }

        /// <summary>
        ///     Gets or sets PlantProgramName
        /// </summary>
        /// <value>The PlantProgram Name .</value>
        public string PlantProgramName { get; set; }

        /// <summary>
        ///     Gets or sets ChainTextileCategoryId
        /// </summary>
        /// <value>The Parameter ChainTextileCategoryId.</value>
        public int ChainTextileCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets FormulaSegmentId
        /// </summary>
        /// <value>The Parameter FormulaSegmentId.</value>
        public int FormulaSegmentId { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedTime
        /// </summary>
        /// <value>The Parameter LastModifiedTime.</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedByUserId
        /// </summary>
        /// <value>The Parameter LastModifiedByUserId.</value>
        public int LastModifiedByUserId { get; set; }

        /// <summary>
        /// flag for reason deleted or not
        /// </summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets PlantChainId
        /// </summary>
        /// <value>The Parameter PlantChainId.</value>
        public int PlantChainId { get; set; }

        /// <summary>
        /// Gets or sets the EcolabSaturationid
        /// </summary>
        /// <value>EcolabSaturationId</value>
        public int EcolabSaturationId { get; set; }

        /// <summary>
        /// Gets or sets the ResourceKey
        /// </summary>
        /// <value>ResourceKey</value>
        public string ResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets LastSyncTime
        /// </summary>
        /// <value>The Parameter LastSyncTime.</value>
        public DateTime LastSyncTime { get; set; }
    }
}