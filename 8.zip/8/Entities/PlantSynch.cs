﻿// -----------------------------------------------------------------------
// <copyright file="PlantSynch.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Plant Synch Class </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
   public class PlantSynch
    {
        public PlantSynch()
        {

        }

        public PlantSynch(
           string ecoalabAccountNumber,
           string name,
           int plantId
           )
        {
            this.EcoalabAccountNumber = string.IsNullOrEmpty(ecoalabAccountNumber) ? ecoalabAccountNumber : ecoalabAccountNumber.Trim();
            this.Name = name;
            this.PlantId = plantId;
        }
        /// <summary>
        ///     Gets or sets the EcoalabAccountNumber.
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }
        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value> The Parameter Name.</value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets PlantId
        /// </summary>
        public int PlantId { get; set; }
    }
}
