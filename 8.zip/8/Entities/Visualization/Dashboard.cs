﻿// -----------------------------------------------------------------------
// <copyright file="Dashboard.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dashboard class </summary>

namespace Entities.Visualization
{
    using System.Collections.Generic;

    public class Dashboard
    {
        /// <summary>
        ///     Gets or sets the Dashboard Id.
        /// </summary>
        /// <value> Parameter DashboardId. </value>
        public int DashboardId { get; set; }

        /// <summary>
        ///     Gets or sets the List of Tunnels.
        /// </summary>
        /// <value> Parameter Tunnels. </value>
        public List<Tunnel> Tunnels { get; set; }

        /// <summary>
        ///     Gets or sets the Total Weight.
        /// </summary>
        /// <value> Parameter TotalWeight. </value>
        public double TotalWeight { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> Parameter DesiredUnits. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value> Parameter Efficiency. </value>
        public double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the Lost Weight.
        /// </summary>
        /// <value> Parameter LostWeight. </value>
        public double LostWeight { get; set; }
    }
}