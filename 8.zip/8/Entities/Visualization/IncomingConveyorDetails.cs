﻿// -----------------------------------------------------------------------
// <copyright file="IncomingConveyorDetails.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Incoming Conveyor Details class </summary>

namespace Entities.Visualization
{
    /// <summary>
    ///     IncomingConveyorDetails Class
    /// </summary>
    public class IncomingConveyorDetails
    {
        /// <summary>
        ///     Gets or sets the Customer Id.
        /// </summary>
        /// <value> CustomerId. </value>
        public string CustomerId { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaId.
        /// </summary>
        /// <value> FormulaId. </value>
        public string FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets the WeightLoaded.
        /// </summary>
        /// <value> WeightLoaded. </value>
        public double WeightLoaded { get; set; }
    }
}