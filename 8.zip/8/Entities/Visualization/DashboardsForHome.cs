﻿// -----------------------------------------------------------------------
// <copyright file="DashboardsForHome.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DashboardsForHome class </summary>

namespace Entities.Visualization
{
    /// <summary>
    ///     DashboardsForHome Class
    /// </summary>
    public class DashboardsForHome
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="dashboardId"> Parameter dashboard Id</param>
        /// <param name="typeId"> Parameter type Id </param>
        public DashboardsForHome(int dashboardId, int typeId)
        {
            this.DashboardId = dashboardId;
            this.TypeId = typeId;
        }

        /// <summary>
        ///     Gets or sets the DashboardId .
        /// </summary>
        /// <value>  Parameter DashboardId. </value>
        public int DashboardId { get; set; }

        /// <summary>
        ///     Gets or sets the TypeId.
        /// </summary>
        /// <value>  Parameter TypeId. </value>
        public int TypeId { get; set; }
    }
}