﻿// -----------------------------------------------------------------------
// <copyright file="Compartment.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Compartment class </summary>

namespace Entities.Visualization
{
    using System;

    /// <summary>
    ///     Compartment Class
    /// </summary>
    public class Compartment
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="customerId"> Parameter Customer Id</param>
        /// <param name="programId"> Parameter Program Id</param>
        /// <param name="actualLoad"> Parameter Actual Load</param>
        /// <param name="nominalLoad"> Parameter Nominal Load</param>
        /// <param name="groupId"> Parameter Group Id</param>
        /// <param name="compartmentId"> Parameter Compartment Id</param>
        public Compartment(int customerId, int programId, int actualLoad, int nominalLoad, int groupId, int compartmentId, decimal temperature, decimal conductivity, decimal ph)
        {
            this.CustomerId = customerId.ToString("00");
            this.ProgramId = programId.ToString("00");
            this.GroupId = groupId;
            this.CompartmentId = compartmentId.ToString("00");
            this.WeightLoaded = actualLoad;
            this.WeightExpected = nominalLoad;
            this.Temperature = Convert.ToDouble(temperature);
            this.Conductivity = Convert.ToDouble(conductivity);
            this.Ph = Convert.ToDouble(ph);
        }

        /// <summary>
        ///     Gets or sets the Compartment Id.
        /// </summary>
        /// <value> Parameter CompartmentId. </value>
        public string CompartmentId { get; set; }

        /// <summary>
        ///     Gets or sets the Customer Id.
        /// </summary>
        /// <value>  Parameter CustomerId. </value>
        public string CustomerId { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramId.
        /// </summary>
        /// <value>  Parameter ProgramId. </value>
        public string ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the WeightLoaded.
        /// </summary>
        /// <value>  Parameter WeightLoaded. </value>
        public double WeightLoaded { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Expected.
        /// </summary>
        /// <value>  Parameter WeightExpected. </value>
        public double WeightExpected { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value>  Parameter GroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature.
        /// </summary>
        /// <value>  Parameter Temperature. </value>
        public double Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the Conductivity.
        /// </summary>
        /// <value>  Parameter Conductivity. </value>
        public double Conductivity { get; set; }

        /// <summary>
        ///     Gets or sets the Ph.
        /// </summary>
        /// <value>  Parameter Ph. </value>
        public double Ph { get; set; }

        /// <summary>
        ///     Gets or sets the Status.
        /// </summary>
        /// <value>Parameter Status. </value>
        public int Status { get; set; }
    }
}