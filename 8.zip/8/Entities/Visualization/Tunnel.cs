﻿// -----------------------------------------------------------------------
// <copyright file="Tunnel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel class </summary>

namespace Entities.Visualization
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Tunnel Class
    /// </summary>
    public class Tunnel
    {
        /// <summary>
        /// Parameterised Constructor
        /// </summary>
        /// <param name="groupId">The Parameter Group Id</param>
        /// <param name="tunnelName">The Parameter Tunnel Name</param>
        /// <param name="nominalLoad">The Parameter Nominal Load</param>
        /// <param name="actualLoad">The Parameter Actual Load</param>
        /// <param name="loadEfficiency">The load efficiency.</param>
        /// <param name="efficiency">The Parameter Efficiency</param>
        /// <param name="lostWeight">The Parameter Lost Weight</param>
        /// <param name="transferPerHour">The Parameter Transfer per hour</param>
        /// <param name="signalStatus">The signal status.</param>
        /// <param name="emptyPockets">The Parameter  Empty Pockets</param>
        /// <param name="alarm">The Parameter Alarm</param>
        /// <param name="transferPercent">The Parameter Transfer Percent</param>
        /// <param name="endOfFormula">The EndOfFormula</param>
        /// <param name="displayCustomer">if set to <c>true</c> [display customer].</param>
        /// <param name="WasherNumber">The washer number.</param>
        public Tunnel(int groupId, string tunnelName, Double nominalLoad, Double actualLoad,Double loadEfficiency, Double efficiency, Double lostWeight, Double transferPerHour, int signalStatus, int emptyPockets, bool alarm, decimal transferPercent, int endOfFormula, bool displayCustomer, int WasherNumber)
        {
            this.TunnelId = groupId;
            this.TunnelName = tunnelName;
            this.EmptyPocketCount = emptyPockets;
            this.TransferRate = transferPerHour;
            this.SignalStatus = signalStatus;
            this.NominalLoad = nominalLoad;
            this.ActualLoad = actualLoad;
            this.Efficiency = efficiency;
            this.LostWeight = lostWeight;
            this.TransferPercent = Convert.ToDouble(transferPercent);
            this.Alarm = alarm;
            this.EndOfFormula = endOfFormula;
            this.DisplayCustomer = displayCustomer;
            this.WasherNumber = WasherNumber;
            this.LoadEfficiency = loadEfficiency;
        }

        /// <summary>
        /// Parameterised Constructor
        /// </summary>
        /// <param name="groupId">The Parameter Group Id</param>
        /// <param name="tunnelName">The Parameter Tunnel Name</param>
        /// <param name="nominalLoad">The Parameter Nominal Load</param>
        /// <param name="actualLoad">The Parameter Actual Load</param>
        /// <param name="loadEfficiency">The load efficiency.</param>
        /// <param name="efficiency">The Parameter Efficiency</param>
        /// <param name="lostWeight">The Parameter Lost Weight</param>
        /// <param name="transferPerHour">The Parameter Transfer per hour</param>
        /// <param name="signalStatus">The signal status.</param>
        /// <param name="emptyPockets">The Parameter  Empty Pockets</param>
        /// <param name="alarm">The Parameter Alarm</param>
        /// <param name="transferPercent">The Parameter Transfer Percent</param>
        /// <param name="endOfFormula">The EndOfFormula</param>
        /// <param name="displayCustomer">if set to <c>true</c> [display customer].</param>
        /// <param name="WasherNumber">The washer number.</param>
        /// <param name="isPLCConnected">if set to <c>true</c> [is PLC connected].</param>
        /// <param name="dispenserName">Name of the dispenser.</param>
        /// <param name="lostWeightInBatches">Lost Weight in Batches</param>
        public Tunnel(int groupId, string tunnelName, Double nominalLoad, Double actualLoad, Double loadEfficiency, Double efficiency, Double lostWeight, Double transferPerHour, int signalStatus, int emptyPockets, bool alarm, decimal transferPercent, int endOfFormula, bool displayCustomer, int WasherNumber, bool isPLCConnected, string dispenserName, decimal lostWeightInBatches, int averageEfficiency)
        {
            this.TunnelId = groupId;
            this.TunnelName = tunnelName;
            this.EmptyPocketCount = emptyPockets;
            this.TransferRate = transferPerHour;
            this.SignalStatus = signalStatus;
            this.NominalLoad = nominalLoad;
            this.ActualLoad = actualLoad;
            this.Efficiency = efficiency;
            this.LostWeight = lostWeight;
            this.TransferPercent = Convert.ToDouble(transferPercent);
            this.Alarm = alarm;
            this.EndOfFormula = endOfFormula;
            this.DisplayCustomer = displayCustomer;
            this.WasherNumber = WasherNumber;
            this.LoadEfficiency = loadEfficiency;
            this.IsPLCConnected = isPLCConnected;
            this.DispenserName = dispenserName;
            this.LostWeightInBatches = lostWeightInBatches;
            this.AverageEfficiency = averageEfficiency;
        }        

        /// <summary>
        ///     Gets or sets the Tunnel Id.
        /// </summary>
        /// <value> int TunnelId. </value>
        public int TunnelId { get; set; }

        /// <summary>
        ///     Gets or sets the Tunnel Name.
        /// </summary>
        /// <value>The Parameter  TunnelName. </value>
        public string TunnelName { get; set; }

        /// <summary>
        ///     Gets or sets the List of Compartments.
        /// </summary>
        /// <value> Compartments. </value>
        public List<Compartment> Compartments { get; set; }

        /// <summary>
        ///     Gets or sets the Empty Pocket Count.
        /// </summary>
        /// <value> EmptyPocketCount. </value>
        public int EmptyPocketCount { get; set; }

        /// <summary>
        ///     Gets or sets the Transfer Rate.
        /// </summary>
        /// <value> TransferRate. </value>
        public Double TransferRate { get; set; }

        /// <summary>
        ///     Gets or sets the SignalStatus.
        /// </summary>
        /// <value> SignalStatus. </value>
        public int SignalStatus { get; set; }

        /// <summary>
        ///     Gets or sets the Transfer Percent.
        /// </summary>
        /// <value> TransferPercent. </value>
        public double TransferPercent { get; set; }

        /// <summary>
        ///     Gets or sets the Nominal Load.
        /// </summary>
        /// <value>The Parameter  NominalLoad. </value>
        public double NominalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Actual Load.
        /// </summary>
        /// <value>The Parameter  ActualLoad. </value>
        public double ActualLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value>The Parameter  Efficiency. </value>
        public double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the LostWeight.
        /// </summary>
        /// <value>The Parameter  LostWeight. </value>
        public double LostWeight { get; set; }

        /// <summary>
        ///     Gets or sets the Alarm to True/False.
        /// </summary>
        /// <value>The Parameter  bool Alarm. </value>
        public bool Alarm { get; set; }

        /// <summary>
        ///     Gets or sets the EndOfFormula.
        /// </summary>
        /// <value> EndOfFormula. </value>
        public int EndOfFormula { get; set; }

        /// <summary>
        ///      Gets or sets the EndOfFormula.
        /// </summary>
        /// <value> DisplayCustomer. </value>
        public bool DisplayCustomer { get; set; }

        public int WasherNumber { get; set; }

        public Double LoadEfficiency { get; set; }
        /// <summary>
        /// Gets or Sets the IsPLCConnected
        /// </summary>
        /// <value>Flag shows whether PLC is Connected</value>
        public bool IsPLCConnected { get; set; }
        /// <summary>
        /// Gets or Sets The Dispenser Name
        /// </summary>
        public string DispenserName { get; set; }
        /// <summary>
        /// Get or Sets the LostWeightInBatches
        /// </summary>
        public decimal LostWeightInBatches { get; set; }

        /// <summary>
        /// Get or Sets the AverageEfficiency
        /// </summary>
        public int AverageEfficiency { get; set; }
    }
}