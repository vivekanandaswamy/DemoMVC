﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalWasher.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ConventionalWasher class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.ConventionalWasher
{
    using System;

    /// <summary>
    ///     ConventionalWasher
    /// </summary>
    public class ConventionalWasher
    {
        /// <summary>
        /// Parameterized constructor
        /// The data is binded from the procedure.
        /// </summary>
        /// <param name="groupId">The Group Id</param>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="washerName">The Washer Name</param>
        /// <param name="washerNumber">The washer number.</param>
        /// <param name="nominalLoad">The Nominal Load</param>
        /// <param name="actualLoad">The Actual Load</param>
        /// <param name="loadEfficiency">The Load Efficiency</param>
        /// <param name="timeEfficiency">The Time Efficiency</param>
        /// <param name="lostLoad">the Lost Load</param>
        /// <param name="alarm">The Alarm Parameter</param>
        /// <param name="alarmDescription">The alarm description.</param>
        /// <param name="washerStatus">The Washer Status Parameter</param>
        /// <param name="targetTurnTime">The target turn time.</param>
        /// <param name="defaultIdleTime">The default idle time.</param>
        public ConventionalWasher(int groupId, int washerId, string washerName, int washerNumber, Double nominalLoad, Double actualLoad, Double loadEfficiency, Double timeEfficiency, Double lostLoad, bool alarm, string alarmDescription, int washerStatus, int targetTurnTime, int defaultIdleTime)
        {
            this.GroupId = groupId;
            this.WasherId = washerId;
            this.WasherName = washerName;
            this.NominalLoad = Convert.ToDouble(nominalLoad);
            this.ActualLoad = Convert.ToDouble(actualLoad);
            this.LoadEfficiency = Convert.ToDouble(loadEfficiency);
            this.TimeEfficiency = Convert.ToDouble(timeEfficiency);
            this.LostLoad = Convert.ToDouble(lostLoad);
            this.Alarm = alarm;
            this.AlarmDescription = alarmDescription;
            this.Status = washerStatus;
            this.WasherNumber = washerNumber;
            this.TargetTurnTime = targetTurnTime;
            this.DefaultIdleTime = defaultIdleTime;
        }

        /// <summary>
        /// Parameterized constructor
        /// The data is binded from the procedure.
        /// </summary>
        /// <param name="groupId">The Group Id</param>
        /// <param name="washerId">The Washer Id</param>
        /// <param name="washerName">The Washer Name</param>
        /// <param name="washerNumber">The washer number.</param>
        /// <param name="nominalLoad">The Nominal Load</param>
        /// <param name="actualLoad">The Actual Load</param>
        /// <param name="loadEfficiency">The Load Efficiency</param>
        /// <param name="timeEfficiency">The Time Efficiency</param>
        /// <param name="lostLoad">the Lost Load</param>
        /// <param name="alarm">The Alarm Parameter</param>
        /// <param name="alarmDescription">The alarm description.</param>
        /// <param name="washerStatus">The Washer Status Parameter</param>
        /// <param name="targetTurnTime">The target turn time.</param>
        /// <param name="defaultIdleTime">The default idle time.</param>
        /// <param name="isPLCConnected">if set to <c>true</c> [is PLC connected].</param>
        /// <param name="dispenserName">Name of the dispenser.</param>
        /// <param name="lostWeightInBatches">The Lost Weight in BAtches</param>
        public ConventionalWasher(int groupId, int washerId, string washerName, int washerNumber, Double nominalLoad, Double actualLoad, Double loadEfficiency, Double timeEfficiency, Double lostLoad, bool alarm, string alarmDescription, int washerStatus, int targetTurnTime, int defaultIdleTime, bool isPLCConnected, string dispenserName, decimal lostWeightInBatches, int averageEfficiency, int currentBatchLoadEfficiency)
        {
            this.GroupId = groupId;
            this.WasherId = washerId;
            this.WasherName = washerName;
            this.NominalLoad = Convert.ToDouble(nominalLoad);
            this.ActualLoad = Convert.ToDouble(actualLoad);
            this.LoadEfficiency = Convert.ToDouble(loadEfficiency);
            this.TimeEfficiency = Convert.ToDouble(timeEfficiency);
            this.LostLoad = Convert.ToDouble(lostLoad);
            this.Alarm = alarm;
            this.AlarmDescription = alarmDescription;
            this.Status = washerStatus;
            this.WasherNumber = washerNumber;
            this.TargetTurnTime = targetTurnTime;
            this.DefaultIdleTime = defaultIdleTime;
            this.IsPLCConnected = isPLCConnected;
            this.DispenserName = dispenserName;
            this.LostWeightInBatches = lostWeightInBatches;
            this.AverageEfficiency = averageEfficiency;
            this.CurrentBatchLoadEfficiency = currentBatchLoadEfficiency;
        }        

        /// <summary>
        ///     Gets or sets the Group Id.
        /// </summary>
        /// <value> Parameter GroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Id.
        /// </summary>
        /// <value> Parameter WasherId. </value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Name.
        /// </summary>
        /// <value> Parameter WasherName. </value>
        public string WasherName { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Number.
        /// </summary>
        /// <value>The Parameter WasherNumber. </value>
        public int WasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Nominal Load.
        /// </summary>
        /// <value> Parameter NominalLoad. </value>
        public double NominalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Actual Load.
        /// </summary>
        /// <value> Parameter ActualLoad. </value>
        public double ActualLoad { get; set; }

        /// <summary>
        ///     Gets or sets the LoadEfficiency.
        /// </summary>
        /// <value> Parameter LoadEfficiency. </value>
        public double LoadEfficiency { get; set; }

        /// <summary>
        ///     Gets or sets the TimeEfficiency.
        /// </summary>
        /// <value> Parameter TimeEfficiency. </value>
        public double TimeEfficiency { get; set; }

        /// <summary>
        ///     Gets or sets the Lost Load.
        /// </summary>
        /// <value> Parameter LostLoad. </value>
        public double LostLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Alarm.
        /// </summary>
        /// <value> Parameter Alarm. </value>
        public bool Alarm { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmDescription.
        /// </summary>
        /// <value> Parameter AlarmDescription. </value>
        public string AlarmDescription { get; set; }

        /// <summary>
        ///     Gets or sets the Status.
        /// </summary>
        /// <value> Status. </value>
        public int Status { get; set; }

        public int TargetTurnTime { get; set; }
        public int DefaultIdleTime { get; set; }
        public bool IsPLCConnected  { get; set; }
        /// <summary>
        /// Gets or Sets The Dispenser Name
        /// </summary>
        public string DispenserName { get; set; }
        /// <summary>
        /// Get or Sets the LostWeightInBatches
        /// </summary>
        public decimal LostWeightInBatches { get; set; }

        /// <summary>
        /// Get or Sets AverageEfficiency
        /// </summary>
        public int AverageEfficiency { get; set; }

        /// <summary>
        /// Gets or Sets CurrentBatchLoadEfficiency
        /// </summary>
        public int CurrentBatchLoadEfficiency { get; set; }

    }
}