﻿// -----------------------------------------------------------------------
// <copyright file="BreakAndTimeline.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Break And Timeline Details Class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.ConventionalWasher
{
    /// <summary>
    ///     BreakAndTimeline
    /// </summary>
    public class BreakAndTimeline
    {
        /// <summary>
        ///     Parameterized constructor
        ///     The data is binded from the procedure.
        /// </summary>
        /// <param name="type"> Parameter Type</param>
        /// <param name="fromTimeInSeconds"> Parameter From Time in Seconds</param>
        /// <param name="toTimeInSeconds"> Parameter  To time in Seconds</param>
        public BreakAndTimeline(string type, int fromTimeInSeconds, int toTimeInSeconds)
        {
            this.Type = type;
            this.FromTimeInSeconds = fromTimeInSeconds;
            this.ToTimeInSeconds = toTimeInSeconds;
        }

        /// <summary>
        ///     Gets or sets the Type Break / Timeline.
        /// </summary>
        /// <value> Parameter  Type. </value>
        public string Type { get; set; }

        /// <summary>
        ///     Gets or sets the FromTime InSeconds.
        /// </summary>
        /// <value> Parameter  FromTime InSeconds. </value>
        public int FromTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the ToTime InSeconds.
        /// </summary>
        /// <value> Parameter  ToTimeInSeconds. </value>
        public int ToTimeInSeconds { get; set; }
    }
}