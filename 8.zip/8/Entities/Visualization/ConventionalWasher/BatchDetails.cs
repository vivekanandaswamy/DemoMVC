﻿// -----------------------------------------------------------------------
// <copyright file="BatchDetails.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Conventional Washer Batch Details Class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.ConventionalWasher
{
    using System;

    /// <summary>
    ///     ConventionalWasherBatchDetails
    /// </summary>
    public class BatchDetails
    {
        /// <summary>
        /// Parameterized constructor
        /// The data is binded from the procedure.
        /// </summary>
        /// <param name="groupId">The Parameter Group Id</param>
        /// <param name="machineId">The Parameter Machine Id</param>
        /// <param name="batchId">The Parameter Batch Id</param>
        /// <param name="programId">The Parameter Program Id</param>
        /// <param name="programName">The Parameter Program Name</param>
        /// <param name="batchStartTime">The Parameter Batch Start Time</param>
        /// <param name="batchStandardEndTimeInSeconds">The Parameter Batch Standard End Time in Seconds</param>
        /// <param name="batchActualEndTimeInSeconds">The Parameter Batch Actual End Time in Seconds</param>
        /// <param name="standardTurnTimeInSeconds">The Parameter Standard Turn Time In Seconds</param>
        /// <param name="runningStatus">The Parameter Washer running Status</param>
        /// <param name="displayFormula">The Parameter Display Formula</param>
        /// <param name="programNumber">The program number.</param>
        /// <param name="formulaDisplayType">Display type of the formula.</param>
        public BatchDetails(int groupId, int machineId, int batchId, int programId, string programName, int batchStartTime, int batchStandardEndTimeInSeconds, int batchActualEndTimeInSeconds, int standardTurnTimeInSeconds, int runningStatus, bool displayFormula, Int16 programNumber, int formulaDisplayType)
        {
            this.GroupId = groupId;
            this.MachineId = machineId;
            this.BatchId = batchId;
            this.ProgramId = programId;
            this.ProgramName = programName;
            this.BatchStartTimeInSeconds = batchStartTime;
            this.BatchStandardEndTimeInSeconds = batchStandardEndTimeInSeconds;
            this.BatchActualEndTimeInSeconds = batchActualEndTimeInSeconds;
            this.StandardTurnTimeInSeconds = standardTurnTimeInSeconds;
            this.RunningStatus = Convert.ToBoolean(runningStatus);
            this.DisplayFormula = displayFormula;
            this.ProgramNumber = Convert.ToInt32(programNumber);
            this.FormulaDisplayType = formulaDisplayType;
        }

        /// <summary>
        ///     Gets or sets the Group Id.
        /// </summary>
        /// <value>The Parameter GroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Machine Id.
        /// </summary>
        /// <value>The Parameter MachineId. </value>
        public int MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the Batch Id.
        /// </summary>
        /// <value>The Parameter BatchId. </value>
        public int BatchId { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramId.
        /// </summary>
        /// <value>The Parameter ProgramId. </value>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the Program Name.
        /// </summary>
        /// <value>The Parameter ProgramName. </value>
        public string ProgramName { get; set; }

        /// <summary>
        ///     Gets or sets the Batch StartTime InSeconds.
        /// </summary>
        /// <value>The Parameter BatchStartTimeInSeconds. </value>
        public int BatchStartTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Batch Standard EndTime InSeconds.
        /// </summary>
        /// <value>The Parameter BatchStandardEndTimeInSeconds. </value>
        public int BatchStandardEndTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Batch ActualEndTime InSeconds.
        /// </summary>
        /// <value>The Parameter BatchActualEndTimeInSeconds. </value>
        public int BatchActualEndTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Standard TurnTime InSeconds.
        /// </summary>
        /// <value>The Parameter StandardTurnTimeInSeconds. </value>
        public int StandardTurnTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Actual TurnTime InSeconds.
        /// </summary>
        /// <value>The Parameter ActualTurnTimeInSeconds. </value>
        public int ActualTurnTimeInSeconds { get; set; }

        /// <summary>
        ///     Gets or sets the Running Status.
        /// </summary>
        /// <value>The Parameter RunningStatus. </value>
        public bool RunningStatus { get; set; }

        /// <summary>
        ///     Gets or sets the Time Efficiency.
        /// </summary>
        /// <value>The Parameter TimeEfficiency. </value>
        public double TimeEfficiency { get; set; }

        /// <summary>
        ///     Gets or sets the IsLastBatch.
        /// </summary>
        /// <value>The Parameter IsLastBatch. </value>
        public bool IsLastBatch { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayFormula.
        /// </summary>
        /// <value>The Parameter DisplayFormula. </value>
        public bool DisplayFormula { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramNumber.
        /// </summary>
        /// <value>The Parameter ProgramNumber. </value>
        public int ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaDisplayType
        /// </summary>
        /// <value>FormulaDisplayType</value>
        public int FormulaDisplayType { get; set; }
    }
}