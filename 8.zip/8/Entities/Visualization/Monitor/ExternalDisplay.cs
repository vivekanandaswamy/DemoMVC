﻿// -----------------------------------------------------------------------
// <copyright file="ExternalDisplay.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The External Display class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.Monitor
{
    /// <summary>
    ///     Entity class for Screen Vs Dashboard Mapping Details
    /// </summary>
    public class ExternalDisplay
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="dashboardId">Dashboard Id</param>
        /// <param name="dashboardName">Dashboard Name</param>
        /// <param name="monitorName">Monitor Name</param>
        /// <param name="monitorId">The monitor identifier.</param>
        /// <param name="xBound">The x bound.</param>
        /// <param name="yBound">The y bound.</param>
        /// <param name="dashboardType">Dashboard Type</param>
        /// <param name="typeId">Type Id</param>
        /// <param name="ecolabAccountNumber">EcolabAccountNumber</param>
        public ExternalDisplay(int dashboardId, string dashboardName, string monitorName, string monitorId, int xBound, int yBound, string dashboardType, byte typeId, string ecolabAccountNumber)
        {
            this.DashboardId = dashboardId;
            this.DashboardName = dashboardName;
            this.MonitorName = monitorName;
            this.MonitorId = monitorId;
            this.DashboardType = dashboardType;
            this.TypeId = typeId;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.XBound = xBound;
            this.YBound = yBound;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExternalDisplay"/> class.
        /// </summary>
        /// <param name="dashboardId">The dash board identifier.</param>
        /// <param name="typeId">The type identifier.</param>
        public ExternalDisplay(int dashboardId, int typeId)
        {
            DashboardId = dashboardId;
            TypeId = (short)typeId;
        }

        public ExternalDisplay()
        {
        }

        /// <summary>
        ///     Gets or sets DashboardId
        /// </summary>
        /// <value>The Parameter DashBoard Id</value>
        public int DashboardId { get; set; }

        /// <summary>
        ///     Gets or sets the DashboardName
        /// </summary>
        /// <value>The Parameter Dash Board Name</value>
        public string DashboardName { get; set; }

        /// <summary>
        ///     Gets or sets the ScreenName
        /// </summary>
        /// <value>The Parameter Monitor Name</value>
        public string MonitorName { get; set; }

        /// <summary>
        ///     Gets or sets the DashboardType
        /// </summary>
        /// <value>The Parameter DashBoard Type</value>
        public string DashboardType { get; set; }

        /// <summary>
        ///     Gets or sets EcolabAccountNumber
        /// </summary>
        /// <value>The Parameter Ecolab Account Number</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Dashboard Type Id
        /// </summary>
        /// <value>The Parameter Dashboard Type Id</value>
        public short TypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Monitor Id
        /// </summary>
        /// <value>The Parameter Monitor Id</value>
        public string MonitorId { get; set; }

        /// <summary>
        ///     Gets or sets XBound
        /// </summary>
        /// <value>The Parameter XBound</value>
        public int XBound { get; set; }

        /// <summary>
        ///     Gets or sets YBound
        /// </summary>
        /// <value>The Parameter YBound</value>
        public int YBound { get; set; }
    }
}