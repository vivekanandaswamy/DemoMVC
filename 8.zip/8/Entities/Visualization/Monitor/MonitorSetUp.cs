﻿// -----------------------------------------------------------------------
// <copyright file="MonitorSetUp.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Monitor SetUp class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.Monitor
{
    /// <summary>
    ///     Entity class for MonitorSetUp
    /// </summary>
    public class MonitorSetUp : BaseEntity
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="id">Dashboard mapping id</param>
        /// <param name="dashboardId">The Dashboard Id</param>
        /// <param name="dashboardName">The DashBoard Name</param>
        /// <param name="washerId">The WasherId(Machine Id)</param>
        /// <param name="washerGroupTypeId">Washer GroupTypeId</param>
        /// <param name="washerGroupTypeName">The The Washer GroupType Name</param>
        /// <param name="machineName">Machine Name</param>
        /// <param name="monitorId">Monitor Id</param>
        /// <param name="isEnableParameter">is enable parameter</param>
        /// <param name="customer">customer</param>
        /// <param name="formula">formula</param>
        /// <param name="load">load</param>
        /// <param name="displayOnLogin">displayOnLogin</param>
        /// <param name="timelineHours">timelineHours</param>
        /// <param name="formulaDisplayType">formulaDisplayType</param>
        /// <param name="formulaDisplayTypeName">Name of the formula display type.</param>
        /// <param name="slideDuration">Duration of the slide.</param>
        /// <param name="efficiencyCalcType">efficiencyCalcType</param>
        /// <param name="efficiencyCalcTypeName">efficiencyCalcTypeName</param>
        /// <param name="MachineNameDispalyType">Type of the machine name dispaly.</param>
        public MonitorSetUp(int id, int dashboardId, string dashboardName, int washerId, byte washerGroupTypeId,
            string washerGroupTypeName, string machineName, string monitorId, bool isEnableParameter, bool customer, 
            bool formula, bool load, bool displayOnLogin, int timelineHours, int formulaDisplayType,
            string formulaDisplayTypeName, int slideDuration, int efficiencyCalcType, string efficiencyCalcTypeName, short MachineNameDispalyType)
        {
            this.Id = id;
            this.DashboardId = dashboardId;
            this.DashboardName = dashboardName;
            this.WasherId = washerId;
            this.WasherGroupTypeId = washerGroupTypeId;
            this.WasherGroupTypeName = washerGroupTypeName;
            this.MachineName = machineName;
            this.MonitorId = monitorId;
            this.IsEnableParameter = isEnableParameter;
            this.Customer = customer;
            this.Formula = formula;
            this.Load = load;
            this.DisplayOnLogin = displayOnLogin;
            this.TimelineHours = timelineHours;
            this.FormulaDisplayType = formulaDisplayType;
            this.FormulaDisplayTypeName = formulaDisplayTypeName;
            this.SlideDuration = slideDuration;
            this.EfficiencyCalcType = efficiencyCalcType;
            this.EfficiencyCalcTypeName = efficiencyCalcTypeName;
            this.MachineNameDispalyType = MachineNameDispalyType;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public MonitorSetUp()
        {
        }

        /// <summary>
        ///     Gets or sets the DashboardId
        /// </summary>
        /// <value>The Dashboard Id</value>
        public int DashboardId { get; set; }

        /// <summary>
        ///     Gets or sets the DashBoardName
        /// </summary>
        /// <value>The Dashboard Name</value>
        public string DashboardName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherId
        /// </summary>
        /// <value>The Washer Id(Machine Id) </value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeId
        /// </summary>
        /// <value>Washer GroupTypeId </value>
        public short WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeName
        /// </summary>
        /// <value>Washer GroupType Name </value>
        public string WasherGroupTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value>The Machine Name </value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets the MonitorId
        /// </summary>
        /// <value>The MonitorId</value>
        public string MonitorId { get; set; }

        /// <summary>
        ///     Gets or sets the IsEnableParameter
        /// </summary>
        /// <value>Is Enable Parameters </value>
        public bool IsEnableParameter { get; set; }

        /// <summary>
        ///     Gets or sets the IsEdit
        /// </summary>
        /// <value>Is Edit value</value>
        public bool IsEdit { get; set; }

        /// <summary>
        ///     Gets or sets the Customer
        /// </summary>
        /// <value>Customer value is enable or not</value>
        public bool Customer { get; set; }

        /// <summary>
        ///     Gets or sets the Formula
        /// </summary>
        /// <value>Formula value is enable or not</value>
        public bool Formula { get; set; }

        /// <summary>
        ///     Gets or sets the Load
        /// </summary>
        /// <value>Load value is enable or not</value>
        public bool Load { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOnLogin
        /// </summary>
        /// <value>DisplayOnLogin is enable or not</value>
        public bool DisplayOnLogin { get; set; }

        /// <summary>
        ///     Gets or sets the TimelineHours
        /// </summary>
        /// <value>No of hours to display on Timeline</value>
        public int TimelineHours { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaDisplayType
        /// </summary>
        /// <value>FormulaDisplayType</value>
        public int FormulaDisplayType { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaDisplayTypeName
        /// </summary>
        /// <value>FormulaDisplayTypeName</value>
        public string FormulaDisplayTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the SlideDuration
        /// </summary>
        /// <value>SlideDuration</value>
        public int SlideDuration { get; set; }

        /// <summary>
        ///     Gets or sets the EfficiencyCalcType
        /// </summary>
        /// <value>EfficiencyCalcType</value>
        public int EfficiencyCalcType { get; set; }

        /// <summary>
        ///     Gets or sets the EfficiencyCalcTypeName
        /// </summary>
        /// <value>EfficiencyCalcTypeName</value>
        public string EfficiencyCalcTypeName { get; set; }
        /// <summary>
        ///     Gets or sets the MachineNameDispalyType 
        /// </summary>
        /// <value>Machine Name Dispaly Type  </value>
        public short MachineNameDispalyType { get; set; }
    }
}