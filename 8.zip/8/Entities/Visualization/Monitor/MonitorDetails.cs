﻿// -----------------------------------------------------------------------
// <copyright file="MonitorDetails.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Monitor Details class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.Monitor
{
    /// <summary>
    ///     Entity class for MonitorDetails
    /// </summary>
    public class MonitorDetails : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        public MonitorDetails(string monitorId, string monitorName, int xBound, int yBound)
        {
            this.MonitorId = monitorId;
            this.MonitorName = monitorName;
            this.XBound = xBound;
            this.YBound = yBound;
        }

        public MonitorDetails(string monitorId, string monitorName, int xBound, int yBound, int width, int height)
        {
            this.XBound = xBound;
            this.YBound = yBound;
            this.Height = height;
            this.Width = width;
            this.MonitorId = monitorId;
            this.MonitorName = monitorName;
        }

        public MonitorDetails()
        {
        }

        /// <summary>
        ///     Gets or sets MonitorId
        /// </summary>
        /// <value>The Parameter Monitor Id</value>
        public string MonitorId { get; set; }

        /// <summary>
        ///     Gets or sets MonitorName
        /// </summary>
        /// <value>The Parameter Monitor Name</value>
        public string MonitorName { get; set; }

        /// <summary>
        ///     Gets or sets XBound
        /// </summary>
        /// <value>The Parameter XBound</value>
        public int XBound { get; set; }

        /// <summary>
        ///     Gets or sets YBound
        /// </summary>
        /// <value>The Parameter YBound</value>
        public int YBound { get; set; }

        /// <summary>
        /// Width of monitor
        /// </summary>
        public int Width { get; set; }

        /// <summary>
        /// Height of monitor
        /// </summary>
        public int Height { get; set; }
    }
}