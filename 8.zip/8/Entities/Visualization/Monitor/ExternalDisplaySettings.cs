﻿// -----------------------------------------------------------------------
// <copyright file="ExternalDisplaySettings.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The External Display class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.Monitor
{
    /// <summary>
    ///     ExternalDisplaySettings
    /// </summary>
    public class ExternalDisplaySettings
    {
        public ExternalDisplaySettings(int dashboardLoadInterval)
        {
            this.DashboardLoadInterval = dashboardLoadInterval;
        }

        /// <summary>
        ///     Gets or sets DashboardLoadInterval
        /// </summary>
        /// <value>The Parameter DashboardLoadInterval</value>
        public int DashboardLoadInterval { get; set; }
    }
}
