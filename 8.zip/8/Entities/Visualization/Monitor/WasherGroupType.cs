﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupType.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Washer Group Type class </summary>
// -----------------------------------------------------------------------

namespace Entities.Visualization.Monitor
{
    using System;

    /// <summary>
    ///     Entity class for  WasherGroupType
    /// </summary>
    public class WasherGroupType
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="washerGroupTypeId">Washer GroupType Id</param>
        /// <param name="washerGroupTypeName">Washer GroupType Name</param>
        public WasherGroupType(byte washerGroupTypeId, string washerGroupTypeName)
        {
            this.WasherGroupTypeId = Convert.ToInt16(washerGroupTypeId);
            this.WasherGroupTypeName = washerGroupTypeName;
        }

        /// <summary>
        ///     Gets or sets The Id of Washer Group Type
        /// </summary>
        /// <value>It contains the WasherGroupTypeId</value>
        public short WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets The Name of Washer Group Type
        /// </summary>
        /// <value>It contains the WasherGroupTypeName</value>
        public string WasherGroupTypeName { get; set; }
    }
}