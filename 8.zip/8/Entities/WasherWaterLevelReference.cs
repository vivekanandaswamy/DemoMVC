﻿// -----------------------------------------------------------------------
// <copyright file="WasherWaterLevelReference.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherWaterLevelReference </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    /// <summary>
    /// Class for Washer Water Level Reference
    /// </summary>
    /// <seealso cref="Entities.BaseEntity" />
    public class WasherWaterLevelReference : BaseEntity
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="WasherWaterLevelReference"/> class.
		/// </summary>
		/// <param name="mySerciceMchId">My sercice MCH identifier.</param>
		/// <param name="waterLevel">The water level.</param>
		/// <param name="waterLevelVolume">The water level volume.</param>
		/// <param name="uomCode">The uom code.</param>
		/// <param name="uomDescription">The uom description.</param>
		/// <param name="isDelete">if set to <c>true</c> [is delete].</param>
		public WasherWaterLevelReference(int mySerciceMchId, Int16 waterLevel, decimal waterLevelVolume, string uomCode, string uomDescription, bool isDelete)
		{
			this.MyServiceMchId = mySerciceMchId;
			this.WaterLevel = waterLevel;
			this.WaterLevelVolume = waterLevelVolume;
			this.UomCode = uomCode;
			this.UomDescription = uomDescription;
			this.IsDelete = isDelete;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="WasherWaterLevelReference"/> class.
		/// </summary>
		public WasherWaterLevelReference()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="WasherWaterLevelReference" /> class.
		/// </summary>
		/// <param name="washerModelId">The washer model identifier.</param>
		/// <param name="waterLevel">The water level.</param>
		/// <param name="waterLevelVolume">The water level volume.</param>
		public WasherWaterLevelReference(Int16 washerModelId, int waterLevel, decimal waterLevelVolume)
		{
			this.WasherModelId = washerModelId;
			this.WaterLevel = (short)waterLevel;
			this.WaterLevelVolume = waterLevelVolume;
		}

        /// <summary>
        /// Gets or sets the WasherModelId
        /// </summary>
        /// <value>
        /// The washer model identifier.
        /// </value>
        public int WasherModelId { get; set; }

        /// <summary>
        /// Gets or sets WaterLevel
        /// </summary>
        /// <value>
        /// The water level.
        /// </value>
        public Int16 WaterLevel { get; set; }

        /// <summary>
        /// Gets or sets the WaterLevelVolume
        /// </summary>
        /// <value>
        /// The water level volume.
        /// </value>
        public decimal WaterLevelVolume { get; set; }

        /// <summary>
        /// Gets or sets the UomCode
        /// </summary>
        /// <value>
        /// The uom code.
        /// </value>
        public string UomCode { get; set; }

        /// <summary>
        /// Gets or sets the UomDescription
        /// </summary>
        /// <value>
        /// The uom description.
        /// </value>
        public string UomDescription { get; set; }

        /// <summary>
        /// Gets or sets the IsDelete
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is delete; otherwise, <c>false</c>.
        /// </value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets the MyServiceMchId
        /// </summary>
        /// <value>
        /// My service MCH identifier.
        /// </value>
        public int MyServiceMchId { get; set; }
	}
}