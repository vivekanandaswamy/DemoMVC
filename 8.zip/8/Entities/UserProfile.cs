﻿// -----------------------------------------------------------------------
// <copyright file="UserProfile.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The UserProfile </summary>
// -----------------------------------------------------------------------

using System.Globalization;
using System.Linq;
namespace Entities
{
    public class UserProfile
    {
        /// <summary>
        ///     UserProfile Constructor.
        /// </summary>
        /// Without parameter
        public UserProfile()
        {
        }

        /// <summary>
        /// User Profile Constructor
        /// </summary>
        /// <param name="userId">The User Id Parameter</param>
        /// <param name="firstName">First Name</param>
        /// <param name="lastName">Last Name</param>
        /// <param name="fullName">Full Name Parameter</param>
        /// <param name="loginName">Login Name</param>
        /// <param name="languageId">Language Id</param>
        /// <param name="name">Name Parameter</param>
        /// <param name="phone">Parameter phone</param>
        /// <param name="uomId">Parameter UOM Id</param>
        /// <param name="email">Parameter Email</param>
        /// <param name="ecolabAccountNumber">Parameter Ecolab Account Number</param>
        /// <param name="regionId">Parameter Region Id</param>
        /// <param name="isActive">Parameter Is Active</param>
        /// <param name="errorMessage">Parameter Error Message</param>
        /// <param name="locale">Parameter locale</param>
        public UserProfile(int userId, string firstName, string lastName, string fullName, string loginName, int languageId, string name, string phone, int uomId, string email, string ecolabAccountNumber, short regionId, bool isActive, string errorMessage, string locale)
        {
            this.UserId = userId;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.FullName = fullName;
            this.LoginName = loginName;
            this.LanguageId = languageId;
            this.Name = name;
            this.Phone = phone;
            this.UomId = uomId;
            this.Email = email;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.RegionId = regionId;
            this.IsActive = isActive;
            this.ErrorMessage = errorMessage;
            this.Locale = locale;
            if (!CultureInfo.GetCultures(CultureTypes.AllCultures).Any(culture => culture.Name == locale))
            {
                this.Locale = CultureInfo.CurrentCulture.ToString();
            }
        }

        /// <summary>
        /// User Profile Constructor
        /// </summary>
        /// <param name="userId">The User Id Parameter</param>
        /// <param name="firstName">First Name</param>
        /// <param name="lastName">Last Name</param>
        /// <param name="fullName">Full Name Parameter</param>
        /// <param name="languageId">Language Id</param>
        /// <param name="email">Parameter Email</param>
        /// <param name="ecolabAccountNumber">Parameter Ecolab Account Number</param>
        /// <param name="countryName">Name of the country.</param>
        /// <param name="regionId">Country Name</param>
        /// <param name="regionName">Name of the region.</param>
        /// <param name="locale">Parameter locale</param>
        public UserProfile(int userId, string firstName, string lastName, string fullName, int languageId, string email, string ecolabAccountNumber,
            string countryName, short regionId, string regionName, string locale)
        {
            this.UserId = userId;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.LanguageId = languageId;
            this.LoginName = fullName;
            this.Name = fullName;
            this.CountryName = countryName;
            this.Email = email;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.RegionId = regionId;
            this.RegionName = regionName;
            this.Locale = locale;
            if (!CultureInfo.GetCultures(CultureTypes.AllCultures).Any(culture => culture.Name == locale))
            {
                this.Locale = CultureInfo.CurrentCulture.ToString();
            }
        }

        /// <summary>
        ///     Gets or sets the UserId.
        /// </summary>
        /// <value>
        ///     The User Identifier
        /// </value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets the FirstName.
        /// </summary>
        /// <value>
        ///     Field FirstName
        /// </value>
        public string FirstName { get; set; }

        /// <summary>
        ///     Gets or sets the LastName.
        /// </summary>
        /// <value>
        ///     Field LastName.
        /// </value>
        public string LastName { get; set; }

        /// <summary>
        ///     Gets or sets the FullName.
        /// </summary>
        /// <value>
        ///     Field FullName.
        /// </value>
        public string FullName { get; set; }

        /// <summary>
        ///     Gets or sets the LoginName.
        /// </summary>
        /// <value>
        ///     Field LoginName.
        /// </value>
        public string LoginName { get; set; }

        /// <summary>
        ///     Gets or sets the LanguageId.
        /// </summary>
        /// <value>
        ///     Field LanguageId.
        /// </value>
        public int LanguageId { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value>
        ///     Field Name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Phone.
        /// </summary>
        /// <value>
        ///     Field Phone.
        /// </value>
        public string Phone { get; set; }

        /// <summary>
        ///     Gets or sets the UOMId.
        /// </summary>
        /// <value>
        ///     Field UOMId.
        /// </value>
        public int UomId { get; set; }

        /// <summary>
        ///     Gets or sets the Email.
        /// </summary>
        /// <value>
        ///     Field Email.
        /// </value>
        public string Email { get; set; }

        /// <summary>
        ///     Gets or sets the IsActive.
        /// </summary>
        /// <value>
        ///     Boolean IsActive.
        /// </value>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the ErrorMessage.
        /// </summary>
        /// <value>
        ///     String ErrorMessage.
        /// </value>
        public string ErrorMessage { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value>
        ///     String EcolabAccountNumber.
        /// </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the RegionId.
        /// </summary>
        /// <value>
        ///     String RegionId.
        /// </value>
        public short RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the Locale
        /// </summary>
        /// <value>String Locale</value>
        public string Locale { get; set; }

        /// <summary>
        ///     Gets or sets the First Name.
        /// </summary>
        /// <value>The first name.</value>
        public string CountryName { get; set; }

        /// <summary>
        ///     Gets or sets the First Name.
        /// </summary>
        /// <value>The first name.</value>
        public string RegionName { get; set; }
    }
}