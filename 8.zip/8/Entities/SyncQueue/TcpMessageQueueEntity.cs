﻿// -----------------------------------------------------------------------
// <copyright file="TcpMessageQueueEntity.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TcpMessage Queue Entity object</summary>
// -----------------------------------------------------------------------

namespace Entities.TcpMessageQueue
{
    using System;

    /// <summary>
    ///     TcpMessage Queue Entity
    /// </summary>
    public class TcpMessageQueueEntity : BaseEntity
    {
        /// <summary>
        ///     TcpMessage Queue Entity
        /// </summary>
        public TcpMessageQueueEntity()
        {
        }

        /// <summary>
        /// TcpMessage Queue Entity
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="requestMessage">The request message.</param>
        /// <param name="entityType">Type of the entity.</param>
        /// <param name="messageId">The message identifier.</param>
        /// <param name="actionType">Type of the action.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="failureCount">The failure count.</param>
        public TcpMessageQueueEntity(int id, string requestMessage, string entityType, int messageId, int actionType, string ecolabAccountNumber, int userId, int failureCount)
        {
            this.Id = id;
            this.RequestMessage = requestMessage;
            this.EntityType = entityType;
            this.MessageId = messageId;
            this.ActionType = actionType;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.UserId = userId;
            this.FailureCount = failureCount;
        }

        /// <summary>
        ///     RequestMessage
        /// </summary>
        public string RequestMessage { get; set; }

        /// <summary>
        ///     EntityType
        /// </summary>
        public string EntityType { get; set; }

        /// <summary>
        ///     MessageId
        /// </summary>
        public int MessageId { get; set; }

        /// <summary>
        ///     ActionType
        /// </summary>
        public int ActionType { get; set; }

        /// <summary>
        ///     UserId
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        ///     CreatedDate
        /// </summary>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets FailureCount
        /// </summary>
        public int FailureCount { get; set; }
    }
}