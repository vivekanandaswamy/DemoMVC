﻿// -----------------------------------------------------------------------
// <copyright file="PlantSetting.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantSetting </summary>
// -----------------------------------------------------------------------

namespace Entities
{
	using System;

	public class PlantSetting
    {
        public PlantSetting()
        {
        }

		public PlantSetting(string ecolabAccountNumber, string ipAddress, string portNumber, string readTimeout, string plantVersion, DateTime? lastModifiedTime, DateTime? ftrLastModifiedTime, int nodeId)
        {
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.IpAddress = ipAddress;
            this.PortNumber = portNumber;
            this.ReadTimeout = readTimeout;
            this.PlantVersion = plantVersion;
	        this.LastModifiedTime = lastModifiedTime;
	        this.FtrLastModifiedTime = ftrLastModifiedTime;
			this.NodeId = nodeId;

        }

        public string EcolabAccountNumber { get; set; }
        public string IpAddress { get; set; }
        public string PortNumber { get; set; }
        public string ReadTimeout { get; set; }
        public string PlantVersion { get; set; }
		public DateTime? FtrLastModifiedTime { get; set; }
		public DateTime? LastModifiedTime { get; set; }
		/// <summary>
		/// Unique identifier generated in enVsion
		/// </summary>
		public int NodeId { get; set; }
    }
}