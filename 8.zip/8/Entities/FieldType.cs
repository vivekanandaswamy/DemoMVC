// -----------------------------------------------------------------------
// <copyright file="FieldType.cs" company="Ecolab">
// �2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FieldType object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System.Collections.Generic;

    /// <summary>
    ///     Class FieldType
    /// </summary>
    public class FieldType
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="FieldType" /> class.
        /// </summary>
        public FieldType()
        {
            this.Fields = new List<Field>();
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="FieldType" /> class.
        /// </summary>
        /// <param name="id">The id. field</param>
        /// <param name="name">The name. field</param>
        public FieldType(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }

        /// <summary>
        ///     Gets or sets the id.
        /// </summary>
        /// <value>The id. field</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the fields.
        /// </summary>
        /// <value>The fields.</value>
        public List<Field> Fields { get; set; }
    }
}