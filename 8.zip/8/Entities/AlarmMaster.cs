﻿// -----------------------------------------------------------------------
// <copyright file="AlarmMaster.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm Master object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///     Entity class for AlarmMaster
    /// </summary>
    public class AlarmMaster : BaseEntity
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public AlarmMaster()
        {

        }

        /// <summary>
        /// Parametrized Constructor for alarm master from central
        /// </summary>
        /// <param name="alarmCode">alarmCode</param>
        /// <param name="desc">description</param>
        /// <param name="controllerModelTypeId">controllerModelTypeId</param>
        /// <param name="resourceKey">resourceKey</param>
        /// <param name="isDefault">isDefault</param>
        /// <param name="isDelete">isDelete</param>
        /// <param name="alarmId">alarmId</param>
        /// <param name="alarmMachineMappingId">alarmMachineMappingId</param>
        /// <param name="machineNumber">machineNumber</param>
        /// <param name="controllerModelId">controllerModelId</param>
        /// <param name="controllerTypeId">controllerTypeId</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
		public AlarmMaster(int alarmCode, string desc, int controllerModelTypeId, string resourceKey, bool isDefault, bool isDelete, int alarmId, int alarmMachineMappingId, int? machineNumber, int controllerModelId, int controllerTypeId, DateTime lastModifiedTime, string washerType, bool isDeleteAlarmMapping, bool isHoldCondition, int? alarmNumber)
        {
            this.AlarmCode = alarmCode;
            this.Description = desc;
            this.ControllerModelTypeId = controllerModelTypeId;
            this.ResourceKey = resourceKey;
            this.IsDefault = isDefault;
            this.IsDeleted = isDelete;
            this.Id = alarmId;
            this.AlarmMaachineMappingId = alarmMachineMappingId;
            this.MachineNumber = machineNumber;
            this.ControllerModelId = controllerModelId;
            this.ControllerTypeId = controllerTypeId;
            this.LastModifiedTime = lastModifiedTime;
			this.WasherType = washerType;
			this.IsDeleteAlarmMapping = isDeleteAlarmMapping;
			this.IsHoldCondition = isHoldCondition;
			this.AlarmNumber = alarmNumber;
        }

        /// <summary>
        ///     Gets or sets the AlarmCode
        /// </summary>
        /// <value>Alarm Code</value>
        public int AlarmCode { get; set; }

        /// <summary>
        ///     Gets or sets the Description
        /// </summary>
        /// <value>Description</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelTypeId
        /// </summary>
        /// <value>ControllerModelTypeId</value>
        public int ControllerModelTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the ResourceKey
        /// </summary>
        /// <value>ResourceKey</value>
        public string ResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets the IsDefault
        /// </summary>
        /// <value>IsDefault</value>
        public bool IsDefault { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmMaachineMappingId
        /// </summary>
        /// <value>AlarmMaachineMappingId</value>
        public int AlarmMaachineMappingId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineNumber
        /// </summary>
        /// <value>MachineNumber</value>
        public int? MachineNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId
        /// </summary>
        /// <value>ControllerModelId</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        /// <value>ControllerTypeId</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }
		/// <summary>
		/// Gets or Sets the Washer type
		/// </summary>
		/// <value>The Washer Type</value>
		public string WasherType { get; set; }

		/// <summary>
		/// Gets or Sets the IsDeleteAlarmMapping
		/// </summary>
		/// <value>Is Delete Alarm Mapping</value>
		public bool IsDeleteAlarmMapping { get; set; }

		/// <summary>
		/// Gets or Sets MachineNumberMappingId
		/// </summary>
		/// <value>Machine Number Mapping Identifier</value>
		public int? MachineNumberMappingId { get; set; }
		/// <summary>
		/// Gets or Sets the Hold Condition
		/// </summary>
		/// <value>Specifies whether the alarm is hold condition or not</value>
		public bool IsHoldCondition { get; set; }
		/// <summary>
		/// Gets or Sets the AlarmNumber
		/// </summary>
		/// <value>The Alarm Number</value>
		public int? AlarmNumber { get; set; }
    }
}
