﻿// -----------------------------------------------------------------------
// <copyright file="UOMMeter.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The UOMMeter class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     entity for UOMMeter
    /// </summary>
    public class UomMeter
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="unit"> Parameter unit</param>
        /// <param name="subunit"> Parameter sub Unit </param>
        public UomMeter(string unit, string subunit)
        {
            this.Unit = unit;
            this.Subunit = subunit;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public UomMeter()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Unit.
        /// </summary>
        /// <value> Parameter Unit.</value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit.
        /// </summary>
        /// <value> Parameter SubUnit.</value>
        public string Subunit { get; set; }

        #endregion
    }
}