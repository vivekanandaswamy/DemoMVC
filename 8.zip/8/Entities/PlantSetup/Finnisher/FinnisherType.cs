﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherType.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FinnisherType class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.Finnisher
{
    public class FinnisherType
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="finnisherTypeId">The Parameter Finnisher Type Id</param>
        /// <param name="finnisherName">The Parameter Finnisher Name</param>
        public FinnisherType(int finnisherTypeId, string finnisherName)
        {
            this.Id = finnisherTypeId;
            this.Name = finnisherName;
        }

        public FinnisherType()
        {
        }

        /// <summary>
        ///     Gets or sets the Finnisher Type Id.
        /// </summary>
        /// <value> Finnisher Type Id. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Finnisher Type Name.
        /// </summary>
        /// <value> Finnisher Type Name. </value>
        public string Name { get; set; }
    }
}