﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherGroup.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FinnisherGroup class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.Finnisher
{
    using System;

    public class FinnisherGroup
    {
        /// <summary>
        /// Parameterized Constructor
        /// </summary>
        /// <param name="FinnisherGroupId">The finnisher group identifier.</param>
        /// <param name="FinnisherId">The finnisher identifier.</param>
        /// <param name="name">The Parameter name.</param>
        /// <param name="groupDescription">The Parameter group description.</param>
        /// <param name="EcolabAccountNumber">The ecolab account number.</param>
        /// <param name="FinnisherTypeId">The finnisher type identifier.</param>
        /// <param name="FinnisherNo">The finnisher no.</param>
        /// <param name="FinnisherTypeName">Name of the finnisher type.</param>
        /// <param name="lastModifiedTimeFinnisherGroup">The last modified time finnisher group.</param>
        /// <param name="lastModifiedTimeFinnisher">The last modified time finnisher.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        public FinnisherGroup(
                                int FinnisherGroupId, 
                                int FinnisherId, 
                                string name, 
                                string groupDescription, 
                                string EcolabAccountNumber, 
                                int FinnisherTypeId, 
                                int FinnisherNo, 
                                string FinnisherTypeName, 
                                DateTime lastModifiedTimeFinnisherGroup, 
                                DateTime lastModifiedTimeFinnisher,
                                bool isDeleted
                                )
        {
            Id = FinnisherGroupId;
            Finnisher = new Finnisher
            {
                Number = FinnisherNo,
                Name = name,
                EcolabAccountNumber = EcolabAccountNumber,
                FinnisherType = new FinnisherType
                {
                    Id = FinnisherTypeId,
                    Name = FinnisherTypeName
                },
                FinisherId = FinnisherId,
                LastModifiedTimestampFinnisher = lastModifiedTimeFinnisher
            };
            Name = groupDescription;
            this.EcolabAccountNumber = EcolabAccountNumber;
            LastModifiedTimestampFinnisherGroup = lastModifiedTimeFinnisherGroup;
            LastModifiedTimestampFinnisher = lastModifiedTimeFinnisher;
            IsDeleted = isDeleted;
        }

        /// <summary>
        ///     Default Constructor
        /// </summary>
        public FinnisherGroup()
        {
        }

        /// <summary>
        ///     Gets or sets the FinnisherGroupId.
        /// </summary>
        /// <value>The Parameter  FinnisherGroupId. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the FinnisherGroupName.
        /// </summary>
        /// <value>The Parameter  FinnisherGroupName. </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the Finnisher.
        /// </summary>
        /// <value> Finnisher. </value>
        public Finnisher Finnisher { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Finnisher Group
        /// </summary>
        /// <value>LastModifiedTimeStampFinnisherGroup</value>
        public DateTime LastModifiedTimestampFinnisherGroup { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Finnisher
        /// </summary>
        /// <value>LastModifiedTimeStampFinnisher</value>
        public DateTime LastModifiedTimestampFinnisher { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}