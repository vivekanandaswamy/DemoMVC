﻿// -----------------------------------------------------------------------
// <copyright file="SensorMachineSetup.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorMachineSetup class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Entity class for SensorMachineSetup
    /// </summary>
    public class SensorMachineSetup
    {
        #region "Constructor"

        /// <summary>
        ///     Paremeterized constructor
        /// </summary>
        /// <param name="machineId">The Parameter Machine Id</param>
        /// <param name="description">The Parameter Description</param>
        public SensorMachineSetup(int machineId, string description)
        {
            this.MachineId = machineId;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public SensorMachineSetup()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the MachineId.
        /// </summary>
        /// <value> Sensor Machine Id.</value>
        public int MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor Type Name.</value>
        public string Description { get; set; }

        #endregion
    }
}