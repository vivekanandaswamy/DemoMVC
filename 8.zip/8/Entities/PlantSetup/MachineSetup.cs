﻿// -----------------------------------------------------------------------
// <copyright file="MachineSetup.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machine Setup </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    /// <summary>
    ///     Entity class for MachineSetup
    /// </summary>
    public class MachineSetup
    {
        #region "Constructor"      

        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="machineId"> Machine Id </param>
        /// <param name="machineName"> Machine Name </param>
        /// <param name="controllerId">Controller Id</param>
        public MachineSetup(int machineId, string machineName, int controllerId = 0)
        {
            this.ControllerId = controllerId;
            this.MachineId = machineId;
            this.MachineName = machineName;			
        }

        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="machineId"> Machine Id </param>
        /// <param name="machineName"> Machine Name </param>
        /// <param name="controllerId">Controller Id</param>
        public MachineSetup(byte machineId, string machineName, int controllerId = 0)
        {
            this.ControllerId = controllerId;
            this.MachineId = Convert.ToInt32(machineId);
            this.MachineName = machineName;			
        }

		/// <summary>
		///     parameterized constructor
		/// </summary>
		/// <param name="machineId"> Machine Id </param>
		/// <param name="machineName"> Machine Name </param>
		/// <param name="controllerId">Controller Id</param>
		public MachineSetup(int machineId, string machineName, int controllerId = 0, int plantWasherNumber = 0)
		{
			this.ControllerId = controllerId;
			this.MachineId = Convert.ToInt32(machineId);
			this.MachineName = machineName;
			this.PlantWasherNumber = plantWasherNumber;
		}

        /// <summary>
        ///     default constructor
        /// </summary>
        public MachineSetup()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the MachineId
        /// </summary>
        /// <value> Machine Id</value>
        public int MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value> Machine Name </value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets Controller Id
        /// </summary>
        /// <value> Controller Id</value>
        public int ControllerId { get; set; }

		/// <summary>
		/// Gets or Sets the Plant Washer Number
		/// </summary>
		/// <value>
		/// The Plant Washer Number
		/// </value>
		public int PlantWasherNumber { get; set; }

        #endregion
    }
}