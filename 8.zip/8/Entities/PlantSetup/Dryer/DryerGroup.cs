﻿// -----------------------------------------------------------------------
// <copyright file="DryerGroup.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerGroup class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.Dryer
{
    using System;

    public class DryerGroup
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="dryerGroupId">Parameter Dryer Group Id</param>
        /// <param name="id">Parameter id</param>
        /// <param name="dryerNo">Parameter Dryer No</param>
        /// <param name="description">Parameter Description</param>
        /// <param name="capacity">Parameter Capacity</param>
        /// <param name="groupDescription">Parameter Group Description</param>
        /// <param name="ecolabAccountNumber">Parameter Ecolab Account Number</param>
        /// <param name="dryerTypeId">Parameter  Dryer Type Id</param>
        /// <param name="dryerTypeName">Parameter Dryer Type Name</param>
        public DryerGroup(
                            int dryerGroupId,
                            int id,
                            int dryerNo,
                            string description,
                            decimal capacity,
                            string groupDescription,
                            string ecolabAccountNumber,
                            int dryerTypeId,
                            string dryerTypeName,
                            DateTime lastModifiedTimeDryerGroup,
                            bool DryerGroupIsDeleted,
                            DateTime lastModifiedTimeDryer,
                            decimal convertedNominalload
                            )
        {
            Id = dryerGroupId;
            Dryer = new Dryer
            {
                Id = id,
                Number = dryerNo,
                Name = description,
                Nominalload = capacity,
                EcolabAccountNumber = ecolabAccountNumber,
                DryerType = new DryerType
                {
                    Id = dryerTypeId,
                    Name = dryerTypeName
                },
                LastModifiedTimestampDryer = lastModifiedTimeDryer,
                ConvertedNominalload = convertedNominalload
            };
            Name = groupDescription;
            IsDeleted = DryerGroupIsDeleted;
            EcolabAccountNumber = ecolabAccountNumber;
            LastModifiedTimestampDryerGroup = lastModifiedTimeDryerGroup;
            LastModifiedTimestampDryer = lastModifiedTimeDryer;
            
        }

        /// <summary>
        ///     Default Constructor
        /// </summary>
        public DryerGroup()
        {
        }

        /// <summary>
        ///     Gets or sets the DryerGroupId.
        /// </summary>
        /// <value>Parameter  DryerGroupId. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the DryerGroupName.
        /// </summary>
        /// <value>Parameter  DryerGroupName. </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value>Parameter  Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value>Parameter  IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer.
        /// </summary>
        /// <value>Parameter  Dryer. </value>
        public Dryer Dryer { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer Group
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimestampDryerGroup { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimestampDryer { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}