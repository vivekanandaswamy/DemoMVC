﻿// -----------------------------------------------------------------------
// <copyright file="DryerType.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerType class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.Dryer
{
    public class DryerType
    {
        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="dryerTypeId">The Parameter Dryer Type Id</param>
        /// <param name="dryerName">The Parameter Dryer Name</param>
        public DryerType(int dryerTypeId, string dryerName)
        {
            this.Id = dryerTypeId;
            this.Name = dryerName;
        }

        public DryerType()
        {
        }

        /// <summary>
        ///     Gets or sets the Dryer Type Id.
        /// </summary>
        /// <value> Dryer Type Id. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer Type Name.
        /// </summary>
        /// <value> Dryer Type Name. </value>
        public string Name { get; set; }
    }
}