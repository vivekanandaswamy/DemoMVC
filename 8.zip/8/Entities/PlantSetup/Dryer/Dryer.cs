﻿// -----------------------------------------------------------------------
// <copyright file="Dryer.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dryer class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.Dryer
{
    using System;

    /// <summary>
    ///     Entity class for Dryer Data
    /// </summary>
    public class Dryer
    {
        #region "Constructor"

        /// <summary>
        /// Parameterized Constructor
        /// </summary>
        /// <param name="DryerGroupId">Dryer Group Id.</param>
        /// <param name="Id">The identifier.</param>
        /// <param name="DryerNo">The dryer no.</param>
        /// <param name="DryerName">Name of the dryer.</param>
        /// <param name="Model">The model.</param>
        /// <param name="Capacity">The capacity.</param>
        /// <param name="LastModifiedTimestampDryer">The last modified time stamp dryer.</param>
        /// <param name="EcolabAccountNumber">The Parameter Ecolab account number.</param>
        /// <param name="DryerTypeId">The dryer type identifier.</param>
        /// <param name="IsDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="groupDescription">The Parameter group description.</param>
        /// <param name="convertedNominalload">The converted nominalload.</param>
        public Dryer(
                                int DryerGroupId,
                                int Id,
                                int DryerNo,
                                string DryerName,
                                string Model,
                                decimal Capacity,
                                DateTime LastModifiedTimestampDryer,
                                string EcolabAccountNumber,
                                int DryerTypeId,
                                bool IsDeleted,
                                string groupDescription,
            decimal convertedNominalload
                                )
        {
            GroupId = DryerGroupId;
            this.Id = Id;
            Number = DryerNo;
            Name = DryerName;
            Nominalload = Capacity;
            this.LastModifiedTimestampDryer = LastModifiedTimestampDryer;
            this.EcolabAccountNumber = EcolabAccountNumber;
            DryerType = new DryerType
            {
                Id = DryerTypeId
            };
            this.IsDeleted = IsDeleted;
            GroupName = groupDescription;
            ConvertedNominalload = convertedNominalload;
        }

        public Dryer()
        {

        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Dryer Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer Number.
        /// </summary>
        /// <value> DryerNumber. </value>
        public int Number { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer Name.
        /// </summary>
        /// <value> DryerName. </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Nominal load.
        /// </summary>
        /// <value> DryerNominalload. </value>
        public decimal Nominalload { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer GroupId.
        /// </summary>
        /// <value> DryerGroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer GroupName.
        /// </summary>
        /// <value> DryerGroupName. </value>
        public string GroupName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ActualUnits.
        /// </summary>
        /// <value> ActualUnits.</value>
        public string ActualUnits { get; set; }

        /// <summary>
        ///     Gets or sets the ActualUnits.
        /// </summary>
        /// <value> ActualUnits.</value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the ConvertedNominalload.
        /// </summary>
        /// <value> ConvertedNominalload.</value>
        public decimal ConvertedNominalload { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer Type.
        /// </summary>
        /// <value> DryerType. </value>
        public DryerType DryerType { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer Group
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimestampDryerGroup { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimestampDryer { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        #endregion
    }
}