﻿// -----------------------------------------------------------------------
// <copyright file="SensorChemicalChart.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorChemicalChart class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Entity class for SensorChemicalChart
    /// </summary>
    public class SensorChemicalChart
    {
        #region "Constructor"

        /// <summary>
        ///     Paremeterized constructor
        /// </summary>
        /// <param name="id">The Parameter Id</param>
        /// <param name="pumpNumber">pump number</param>
        /// <param name="pumpType">pump type</param>
        /// <param name="controllerModelId">controller model id</param>
        /// <param name="description">The Parameter Description</param>
        public SensorChemicalChart(int id, byte pumpNumber,byte pumpType,int controllerModelId, string description)
        {
            this.Id = id;
            this.Description = description;
            this.PumpNumber = pumpNumber;
            this.PumpType = pumpType;
            this.ControllerModelId = controllerModelId;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public SensorChemicalChart()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Sensor chemical chart Id.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor chemical chart Name.</value>
        public string Description { get; set; }
        
        /// <summary>
        /// Gets or Sets Pump Number
        /// </summary>
        /// <value>The Pump Number value</value>
        public byte PumpNumber { get; set; }

        /// <summary>
        /// Gets or Sets Pump Number
        /// </summary>
        /// <value>The Pump Number value</value>
        public byte PumpType { get; set; }

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Sensor chemical chart Id.</value>
        public int ControllerModelId { get; set; }

        #endregion
    }
}