﻿// -----------------------------------------------------------------------
// <copyright file="ProductMaster.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved. 
// </copyright>
// <summary>The Product Master </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.Chemical
{
    using System;

    /// <summary>
    ///     class for ProductMaster
    /// </summary>
    public class ProductMaster
    {
        #region "Constructor"

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductMaster" /> class.
        /// </summary>
        public ProductMaster()
        {
        }

        /// <summary>
        /// Product Category sync from central to local
        /// </summary>
        /// <param name="productCategoryID">The product category identifier.</param>
        /// <param name="productCategoryName">Name of the product category.</param>
        /// <param name="myServiceProdCatId">My service product cat identifier.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="LastModifiedTime">The last modified time.</param>
        public ProductMaster(int? productCategoryID, string productCategoryName, Int16 myServiceProdCatId, bool isDeleted, DateTime LastModifiedTime)
        {
            this.ProductCategoryId = productCategoryID;
            this.ProductcategoryName = productCategoryName;
            this.MyServiceProdCatId = myServiceProdCatId;
            this.IsDelete = isDeleted;
            this.LastModifiedTime = LastModifiedTime;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductMaster" /> class.
        /// </summary>
        /// <param name="productCategoryName">Name of the product category.</param>
        /// <param name="myServiceProdCatId">My service product cat identifier.</param>
        /// <param name="sourceSystemCode">The source system code.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="spSP">The sp sp value.</param>
        /// <param name="nrNR">The nr nr value.</param>
        /// <param name="nlBE">The nl be value.</param>
        public ProductMaster(
            string productCategoryName,
            Int16 myServiceProdCatId,
            string sourceSystemCode,
            bool isDeleted,
            DateTime myServiceLastSynchTime,
            string spSP,
            string nrNR,
            string nlBE
            )
        {
            this.ProductcategoryName = productCategoryName;
            this.MyServiceProdCatId = myServiceProdCatId;
            this.SourceSystemCode = sourceSystemCode;
            this.IsDelete = isDeleted;
            this.MyServiceLastSynchTime = myServiceLastSynchTime;
            this.sp_SP = spSP;
            this.nr_NR = nrNR;
            this.nl_BE = nlBE;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductMaster" /> class.
        /// </summary>
        /// <param name="id">The identification number</param>
        /// <param name="productId">Chemical Identifier</param>
        /// <param name="sku">SKU number for product</param>
        /// <param name="name">Parameter Name</param>
        /// <param name="cost">Parameter Cost</param>
        /// <param name="densityFactor">Parameter DensityFactor</param>
        /// <param name="acceptedDeviation">Aaccepted Deviation</param>
        /// <param name="productCategoryId">Product Category Id</param>
        /// <param name="type">Parameter Type</param>
        /// <param name="supplier">Parameter Supplier</param>
        /// <param name="includeinCI">Includein CI</param>
        /// <param name="packagingSize">Ppackaging Size</param>
        /// <param name="weight">Parameter Weight</param>
        /// <param name="volume">Parameter Volume</param>
        /// <param name="productcategoryName">Product Category Name</param>
        /// <param name="ecolabAccountNumber">Ecolab account number</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="lastSyncTime">Last Sync Time</param>
        /// <param name="myServiceProdId">myServiceProdId</param>
        /// <param name="inventoryExpense">inventoryExpense</param>
        /// <param name="unitPerPackage">The unit per package.</param>
        /// <param name="unitWeightVolume">The unit weight volume.</param>
        /// <param name="unitWeightVolumeUomCode">The unit weight volume uom code.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        public ProductMaster(
            int id,
            int productId,
            string sku,
            string name,
            double cost,
            decimal densityFactor,
            decimal acceptedDeviation,
            int? productCategoryId,
            string type,
            string supplier,
            bool includeinCI,
            string packagingSize,
            decimal weight,
            decimal volume,
            string productcategoryName,
            string ecolabAccountNumber,
            DateTime lastModifiedTimestamp,
            DateTime lastSyncTime,
            int myServiceProdId,
            string inventoryExpense,
            int? unitPerPackage,
            Decimal? unitWeightVolume,
            string unitWeightVolumeUomCode,
            bool isDeleted
            )
        {
            this.Id = id;
            this.ProductId = productId;
            this.Sku = sku;
            this.Name = name;
            this.Cost = cost;
            this.DensityFactor = densityFactor;
            this.AcceptedDeviation = acceptedDeviation;
            this.ProductCategoryId = productCategoryId;
            this.Type = type;
            this.Supplier = supplier;
            this.IncludeinCI = includeinCI;
            this.PackagingSize = packagingSize;
            this.Weight = weight;
            this.Volume = volume;
            this.ProductcategoryName = productcategoryName;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.LastModifiedTimestamp = lastModifiedTimestamp;
            this.LastSyncTime = lastSyncTime;
            this.MyServiceProdId = myServiceProdId;
            this.InventoryExpense = inventoryExpense;
            this.UnitPerPackage = unitPerPackage;
            this.UnitWeightVolume = unitWeightVolume;
            this.UnitWeightVolumeUOMCode = unitWeightVolumeUomCode;
            this.IsDelete = isDeleted;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductMaster" /> class.
        /// </summary>
        /// <param name="sku">The SKU number</param>
        /// <param name="name">Parameter Name</param>
        /// <param name="cost">Parameter Cost</param>
        /// <param name="densityFactor">Parameter DensityFactor</param>
        /// <param name="densityFactorUomId">densityFactorUOMId</param>
        /// <param name="densityFactorUom">The density factor uom.</param>
        /// <param name="acceptedDeviation">Aaccepted Deviation</param>
        /// <param name="productCategoryId">Product Category Id</param>
        /// <param name="type">Parameter Type</param>
        /// <param name="supplier">Parameter Supplier</param>
        /// <param name="includeinCI">The Includein CI</param>
        /// <param name="packagingSize">Ppackaging Size</param>
        /// <param name="weight">Parameter Weight</param>
        /// <param name="weight_UomId">The weight_ uom identifier.</param>
        /// <param name="weight_Uom">The weight_ uom.</param>
        /// <param name="volume">Parameter Volume</param>
        /// <param name="volume_Uomcd">The volume_ uomcd.</param>
        /// <param name="volume_Uom">The volume_ uom.</param>
        /// <param name="isdelete">if set to <c>true</c> [isdelete].</param>
        /// <param name="productcategoryName">Product Category Name</param>
        /// <param name="regionCode">The region code.</param>
        /// <param name="country">The country.</param>
        /// <param name="myServiceProdId">My service product identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="spSP">The sp sp of product.</param>
        /// <param name="nrNR">The nr nr of product.</param>
        /// <param name="nlBE">The nl be of product.</param>
        /// <param name="packageSizeId">The package size identifier.</param>
        /// <param name="sourceSystemCode">The source system code.</param>
        public ProductMaster(
            string sku,
            string name,
            double cost,
            decimal densityFactor,
            Int16 densityFactorUomId,
            string densityFactorUom,
            decimal acceptedDeviation,
            Int16? productCategoryId,
            string type,
            string supplier,
            bool includeinCI,
            string packagingSize,
            decimal weight,
            Int16 weight_UomId,
            string weight_Uom,
            decimal volume,
            Int16 volume_Uomcd,
            string volume_Uom,
            bool isdelete,
            string productcategoryName,
            string regionCode,
            string country,
            int myServiceProdId,
            DateTime myServiceLastSynchTime,
            string spSP,
            string nrNR,
            string nlBE,
            int? packageSizeId,
            string sourceSystemCode
            )
        {
            this.Sku = sku;
            this.Name = name;
            this.Cost = cost;
            this.DensityFactor = densityFactor;
            this.DensityFactorUOMId = densityFactorUomId;
            this.DensityFactorUOM = densityFactorUom;
            this.AcceptedDeviation = acceptedDeviation;
            this.ProductCategoryId = productCategoryId;
            this.Type = type;
            this.Supplier = supplier;
            this.IncludeinCI = includeinCI;
            this.PackagingSize = packagingSize;
            this.Weight = weight;
            this.Weight_UOMId = weight_UomId;
            this.Weight_UOM = weight_Uom;
            this.Volume = volume;
            this.Volume_UOMCD = volume_Uomcd;
            this.Volume_UOM = volume_Uom;
            this.IsDelete = isdelete;
            this.ProductcategoryName = productcategoryName;
            this.RegionCode = regionCode;
            this.Country = country;
            this.MyServiceProdId = myServiceProdId;
            this.MyServiceLastSynchTime = myServiceLastSynchTime;
            this.sp_SP = spSP;
            this.nr_NR = nrNR;
            this.nl_BE = nlBE;
            this.PackageSizeId = packageSizeId;
            this.SourceSystemCode = sourceSystemCode;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductMaster" /> class.
        /// </summary>
        /// <param name="productId">Chemical Identifier</param>
        /// <param name="sku">SKU number of product</param>
        /// <param name="name">Parameter Name</param>
        /// <param name="cost">Parameter Cost</param>
        /// <param name="densityFactor">Parameter DensityFactor</param>
        /// <param name="acceptedDeviation">Aaccepted Deviation</param>
        /// <param name="productCategoryId">Product Category Id</param>
        /// <param name="type">Parameter Type</param>
        /// <param name="supplier">Parameter Supplier</param>
        /// <param name="includeinCI">Includein CI</param>
        /// <param name="packagingSize">Ppackaging Size</param>
        /// <param name="weight">Parameter Weight</param>
        /// <param name="volume">Parameter Volume</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="productcategoryName">Product Category Name</param>
        /// <param name="regionCode">The region code.</param>
        /// <param name="country">The country of product.</param>
        /// <param name="myServiceProdId">My service product identifier.</param>
        public ProductMaster(
            int productId,
            string sku,
            string name,
            double cost,
            decimal densityFactor,
            decimal acceptedDeviation,
            int? productCategoryId,
            string type,
            string supplier,
            bool includeinCI,
            string packagingSize,
            decimal weight,
            decimal volume,
            bool isDelete,
            string productcategoryName,
            string regionCode,
            string country,
            int myServiceProdId
            )
        {
            this.ProductId = productId;
            this.Sku = sku;
            this.Name = name;
            this.Cost = cost;
            this.DensityFactor = densityFactor;
            this.AcceptedDeviation = acceptedDeviation;
            this.ProductCategoryId = productCategoryId;
            this.Type = type;
            this.Supplier = supplier;
            this.IncludeinCI = includeinCI;
            this.PackagingSize = packagingSize;
            this.Weight = weight;
            this.Volume = volume;
            this.IsDelete = isDelete;
            this.ProductcategoryName = productcategoryName;
            this.RegionCode = regionCode;
            this.Country = country;
            this.MyServiceProdId = myServiceProdId;
        }

        /// <summary>
        /// Constructor for ProductMaster
        /// </summary>
        /// <param name="productId">The product identifier.</param>
        /// <param name="sku">The sku of product.</param>
        /// <param name="name">The name of product.</param>
        /// <param name="cost">The cost of product.</param>
        /// <param name="densityFactor">The density factor.</param>
        /// <param name="acceptedDeviation">The accepted deviation.</param>
        /// <param name="productCategoryId">The product category identifier.</param>
        /// <param name="type">The type of product.</param>
        /// <param name="supplier">The supplier of product.</param>
        /// <param name="includeinCI">if set to <c>true</c> [includein ci].</param>
        /// <param name="packagingSize">Size of the packaging.</param>
        /// <param name="weight">The weight of product.</param>
        /// <param name="volume">The volume of product.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="productcategoryName">Name of the productcategory.</param>
        /// <param name="regionCode">The region code.</param>
        /// <param name="country">The country of product.</param>
        /// <param name="myServiceProdId">My service product identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="packageSizeId">The package size identifier.</param>
        /// <param name="envisionDisplayName">Display name of the envision.</param>
        /// <param name="sourceSystemid">The source systemid.</param>
        public ProductMaster(
         int productId,
         string sku,
         string name,
         double cost,
         decimal densityFactor,
         decimal acceptedDeviation,
         int? productCategoryId,
         string type,
         string supplier,
         bool includeinCI,
         string packagingSize,
         decimal weight,
         decimal volume,
         bool isDelete,
         string productcategoryName,
         int regionCode,
         string country,
         int myServiceProdId,
         DateTime myServiceLastSynchTime,
         int? packageSizeId,
         string envisionDisplayName,
         int sourceSystemid
         )
        {
            this.ProductId = productId;
            this.Sku = sku;
            this.Name = name;
            this.Cost = cost;
            this.DensityFactor = densityFactor;
            this.AcceptedDeviation = acceptedDeviation;
            this.ProductCategoryId = productCategoryId;
            this.Type = type;
            this.Supplier = supplier;
            this.IncludeinCI = includeinCI;
            this.PackagingSize = packagingSize;
            this.Weight = weight;
            this.Volume = volume;
            this.IsDelete = isDelete;
            this.ProductcategoryName = productcategoryName;
            this.RegionId = regionCode;
            this.Country = country;
            this.MyServiceProdId = myServiceProdId;
            this.MyServiceLastSynchTime = myServiceLastSynchTime;
            this.PackageSizeId = packageSizeId;
            this.EnvisionDisplayName = envisionDisplayName;
            this.SourceSystemId = sourceSystemid;
        }

        /// <summary>
        /// parameteried constructor for Plant Chemical Myservice
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="productId">productId of Product</param>
        /// <param name="cost">Cost of Product</param>
        /// <param name="includeinCI">includeinCi of Product</param>
        /// <param name="inventoryExpense">inventoryExpense</param>
        /// <param name="isDeleted">isDeleted of Product</param>
        /// <param name="myServiceLastModifiedTime">myServiceLastModifiedTime</param>
        public ProductMaster(string ecolabAccountNumber, int productId, decimal cost, bool includeinCI, string inventoryExpense, bool isDeleted,
            DateTime myServiceLastModifiedTime)
        {
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.MyServiceProdId = productId;
            this.Cost = Convert.ToDouble(cost);
            this.IncludeinCI = includeinCI;
            this.InventoryExpense = inventoryExpense;
            this.IsDelete = isDeleted;
            this.MyServiceLastSynchTime = myServiceLastModifiedTime;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductMaster" /> class.
        /// </summary>
        /// <param name="id">The identifier of Product.</param>
        /// <param name="productid">The productid of Product.</param>
        /// <param name="cost">The cost of Product.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="includeinCI">if set to <c>true</c> [includein ci].</param>
        /// <param name="inventoryExpense">The inventory expense.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="lastmodifiedtime">The lastmodifiedtime.</param>
        /// <param name="myServiceProdId">My service product identifier.</param>
        /// <param name="name">The name of Product.</param>
        /// <param name="sku">The sku of Product.</param>
        public ProductMaster(int id, int productid, double cost, bool isDeleted, bool includeinCI, string inventoryExpense, string ecolabAccountNumber, DateTime lastmodifiedtime, int myServiceProdId, string name, string sku)
        {
            this.Id = id;
            this.ProductId = productid;
            this.Cost = cost;
            this.IsDelete = isDeleted;
            this.IncludeinCI = includeinCI;
            this.InventoryExpense = inventoryExpense;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.LastModifiedTimestamp = lastmodifiedtime;
            this.MyServiceProdId = myServiceProdId;
            this.Name = name;
            this.Sku = sku;
        }

        /// <summary>
        /// Product Master constructor for sync
        /// </summary>
        /// <param name="productId">product Id of Product</param>
        /// <param name="myServiceProdId">my service prod id</param>
        /// <param name="envisionDisplayName">envision display name</param>
        public ProductMaster(int productId, int myServiceProdId, string envisionDisplayName)
        {
            this.ProductId = productId;
            this.MyServiceProdId = myServiceProdId;
            this.EnvisionDisplayName = envisionDisplayName;
        }

        /// <summary>
        /// ProductMaster
        /// </summary>
        /// <param name="productId">productId of Product</param>
        /// <param name="sku">The Sku of Product</param>
        public ProductMaster(int productId, string sku)
        {
            this.ProductId = productId;
            this.Sku = sku;
        }
        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> Parameter Product Id.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> Parameter Product Id.</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets SKU
        /// </summary>
        /// <value> Parameter SKU.</value>
        public string Sku { get; set; }

        /// <summary>
        ///     Gets or sets  Name
        /// </summary>
        /// <value> Parameter Name </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets Cost
        /// </summary>
        /// <value> Parameter Cost of chemical </value>
        public double Cost { get; set; }

        /// <summary>
        ///     Gets or sets DensityFactor
        /// </summary>
        /// <value> Parameter Density Factor </value>
        public decimal DensityFactor { get; set; }

        /// <summary>
        ///     Gets or sets AcceptedDeviation
        /// </summary>
        /// <value>Accepted Deviation </value>
        public decimal AcceptedDeviation { get; set; }

        /// <summary>
        ///     Gets or sets ProductCategoryId
        /// </summary>
        /// <value> Product Category Id </value>
        public int? ProductCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets ContactOfficePhone
        /// </summary>
        /// <value> Contact Office Phone </value>
        public string Type { get; set; }

        /// <summary>
        ///     Gets or sets Supplier
        /// </summary>
        /// <value> Supplier </value>
        public string Supplier { get; set; }

        /// <summary>
        ///     Gets or sets IncludeinCI
        /// </summary>
        /// <value> Includein CI </value>
        public bool IncludeinCI { get; set; }

        /// <summary>
        ///     Gets or sets Description
        /// </summary>
        /// <value> Parameter Description </value>
        public string PackagingSize { get; set; }

        /// <summary>
        ///     Gets or sets Weight
        /// </summary>
        /// <value> Parameter Weight </value>
        public decimal Weight { get; set; }

        /// <summary>
        ///     Gets or sets Volume
        /// </summary>
        /// <value> Parameter Volume </value>
        public decimal Volume { get; set; }

        /// <summary>
        ///     Gets or sets ProductcategoryName
        /// </summary>
        /// <value> Product Category Name </value>
        public string ProductcategoryName { get; set; }

        /// <summary>
        ///     Gets or sets IsSeleted
        /// </summary>
        /// <value> Is Seleted  of Product</value>
        public bool IsSelected { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete of Product</value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>
        /// LastModifiedTimestampAtCentral
        /// </value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        /// Gets or sets DensityFactorUOMId
        /// </summary>
        /// <value>
        /// The density factor uom identifier.
        /// </value>
        public int DensityFactorUOMId { get; set; }

        /// <summary>
        /// Gets or sets DensityFactorUOM
        /// </summary>
        /// <value>
        /// The density factor uom.
        /// </value>
        public string DensityFactorUOM { get; set; }

        /// <summary>
        /// Gets or sets Weight_UOMId
        /// </summary>
        /// <value>
        /// The weight_ uom identifier.
        /// </value>
        public int Weight_UOMId { get; set; }

        /// <summary>
        /// Gets or sets Weight_UOM
        /// </summary>
        /// <value>
        /// The weight_ uom.
        /// </value>
        public string Weight_UOM { get; set; }

        /// <summary>
        /// Gets or sets Volume_UOMCD
        /// </summary>
        /// <value>
        /// The volume_ uomcd.
        /// </value>
        public int Volume_UOMCD { get; set; }

        /// <summary>
        /// Gets or sets Volume_UOM
        /// </summary>
        /// <value>
        /// The volume_ uom.
        /// </value>
        public string Volume_UOM { get; set; }

        /// <summary>
        /// Gets or sets RegionCode
        /// This property is used only for my service to get the region code and based of that we will get region id and
        /// region name from conduict
        /// </summary>
        /// <value>
        /// The region code.
        /// </value>
        public string RegionCode { get; set; }

        /// <summary>
        /// Gets or Sets RegionId
        /// </summary>
        /// <value>
        /// The region identifier.
        /// </value>
        public int RegionId { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        /// <value>
        /// The country.
        /// </value>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets MyServiceProdId
        /// </summary>
        /// <value>
        /// My service product identifier.
        /// </value>
        public int MyServiceProdId { get; set; }

        /// <summary>
        /// Gets or sets the sp_SP
        /// </summary>
        /// <value>
        /// The Parameter sp_SP
        /// </value>
        public string sp_SP { get; set; }

        /// <summary>
        /// Gets or sets the nr_NR
        /// </summary>
        /// <value>
        /// The Parameter nr_NR
        /// </value>
        public string nr_NR { get; set; }

        /// <summary>
        /// Gets or sets the nl_BE
        /// </summary>
        /// <value>
        /// The Parameter nl_BE
        /// </value>
        public string nl_BE { get; set; }

        /// <summary>
        /// Gets or sets MyServiceLastSynchTime
        /// </summary>
        /// <value>
        /// My service last synch time.
        /// </value>
        public DateTime MyServiceLastSynchTime { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTime
        /// </summary>
        /// <value>
        /// The last modified time.
        /// </value>
        public DateTime LastModifiedTime { get; set; }
        /// <summary>
        /// Gets or sets MyServiceProdCatId
        /// </summary>
        /// <value>
        /// My service product cat identifier.
        /// </value>
        public Int16 MyServiceProdCatId { get; set; }

        /// <summary>
        /// Gets or Sets InventoryExpense
        /// </summary>
        /// <value>
        /// InventoryExpense
        /// </value>
        public string InventoryExpense { get; set; }

        /// <summary>
        /// Gets or sets PackageSizeId
        /// </summary>
        /// <value>PackageSizeId</value>
        public int? PackageSizeId { get; set; }

        /// <summary>
        ///     Gets or Sets UnitPerPackage
        /// </summary>
        /// <value>UnitPerPackage</value>
        public int? UnitPerPackage { get; set; }

        /// <summary>
        ///     Gets or Sets UnitWeightVolume
        /// </summary>
        /// <value>UnitWeightVolume</value>
        public Decimal? UnitWeightVolume { get; set; }

        /// <summary>
        ///     Gets or Sets UnitWeightVolumeUOMCode
        /// </summary>
        /// <value>UnitWeightVolumeUOMCode</value>
        public string UnitWeightVolumeUOMCode { get; set; }

        /// <summary>
        /// Gets or sets Envision Display name
        /// </summary>
        /// <value>envision display name</value>
        public string EnvisionDisplayName { get; set; }

        /// <summary>
        /// Gets or sets Source System Code
        /// </summary>
        /// <value>Source System Code</value>
        public string SourceSystemCode { get; set; }

        /// <summary>
        /// Gets or sets the source system identifier.
        /// </summary>
        /// <value>
        /// The source system identifier.
        /// </value>
        public int SourceSystemId { get; set; }

        #endregion
    }
}