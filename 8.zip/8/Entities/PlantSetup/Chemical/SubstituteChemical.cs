﻿// -----------------------------------------------------------------------
// <copyright file="SubstituteChemical.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SubstituteChemical object </summary>
// -----------------------------------------------------------------------

using System.Collections.Generic;
namespace Entities.PlantSetup.Chemical
{
	/// <summary>
	///     Entity for SubstituteChemical
	/// </summary>
	public class SubstituteChemical : BaseEntity
	{
		#region "Constructor"

		/// <summary>
		///     Parameterized constructor
		/// </summary>
		public SubstituteChemical()
		{
			
		}

		#endregion "Constructor"

		#region "Properties"

		/// <summary>
		///     Gets or sets the WasherGroupId.
		/// </summary>
		/// <value> Group WasherGroupId Id.</value>
		public int WasherGroupId { get; set; }

		/// <summary>
		///     Gets or sets the OldProductId.
		/// </summary>
		/// <value> Group OldProductId.</value>
		public int OldProductId { get; set; }

		/// <summary>
		///     Gets or sets the NewProductId.
		/// </summary>
		/// <value>The NewProductId value.</value>
		public int NewProductId { get; set; }

		/// <summary>
		///     Gets or sets ScalarOption
		/// </summary>
		public int ScalarOption { get; set; }

		/// <summary>
		///     Gets or sets the ScalarAmountPercent.
		/// </summary>
		/// <value> The ScalarAmountPercent.</value>
		public int ScalarAmountPercent { get; set; }

		/// <summary>
		/// Gets or sets the WasherGroupIds
		/// </summary>
		public List<int> WasherGroupIds { get; set; }

		#endregion "Properties"
	}
}