﻿// -----------------------------------------------------------------------
// <copyright file="Chemicals.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemicals object </summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.PlantSetup.Chemical
{
    /// <summary>
    ///     Entity for Chemicals
    /// </summary>
    public class Chemicals
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="productId"> Parameter Chemical Id</param>
        /// <param name="name">Chemical Name and SKU Number</param>
        /// <param name="cost">Cost of chemical</param>
        /// <param name="includeinCi"> Parameter Inclide in CI</param>
        public Chemicals(int productId, string name, double cost, bool includeinCi, int controllerEquipmentTypeId)
        {
            this.ProductId = productId;
            this.Name = name;
            this.Cost = cost;
            this.IncludeinCi = includeinCi;
			this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
        }

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="productId"> Parameter Chemical Id</param>
        /// <param name="name">Chemical Name and SKU Number</param>
        /// <param name="cost">Cost of chemical</param>
        /// <param name="includeinCi"> Parameter Inclide in CI</param>
        /// <param name="price"> Parameter Price</param>
        /// <param name="controllerEquipmentTypeId"> Parameter Controller Equipment Type Id</param>
        public Chemicals(int productId, string name, double cost, bool includeinCi, double price, int controllerEquipmentTypeId)
        {
            this.ProductId = productId;
            this.Name = name;
            this.Cost = cost;
            this.IncludeinCi = includeinCi;
            this.PriceInOunce = price;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
        }

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="productId"> Parameter Chemical Id</param>
        /// <param name="name">Chemical Name and SKU Number</param>
        /// <param name="cost">Cost of chemical</param>
        public Chemicals(int productId, string name, double cost, bool includeinCi)
        {
            this.ProductId = productId;
            this.Name = name;
            this.Cost = cost;
            this.IncludeinCi = includeinCi;
        }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="controllerEquipmentSetupId">The controller equipment setup identifier.</param>
        /// <param name="productId">Parameter Chemical Id</param>
        /// <param name="name">Chemical Name and SKU Number</param>
        /// <param name="cost">Cost of chemical</param>
        /// <param name="includeinCi">Parameter Inclide in CI</param>
        /// <param name="priceInOunce">priceInOunce of chemical</param>
        /// <param name="controllerEquipmentTypeId">The controller equipment type identifier.</param>
		public Chemicals(byte? controllerEquipmentId, Int16? controllerEquipmentSetupId, int productId, string name, double cost, bool includeinCi, double priceInOunce, int controllerEquipmentTypeId)
		{
            this.ControllerEquipmentId = controllerEquipmentId;
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ProductId = productId;
			this.Name = name;
			this.Cost = cost;
			this.IncludeinCi = includeinCi;
			this.PriceInOunce = priceInOunce;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Chemicals"/> class.
        /// </summary>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="controllerEquipmentSetupId">The controller equipment setup identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="name">The name of Chemicals.</param>
        /// <param name="cost">The cost of Chemicals.</param>
        /// <param name="includeinCi">if set to <c>true</c> [includein ci].</param>
        /// <param name="controllerEquipmentTypeId">The controller equipment type identifier.</param>
        public Chemicals(byte? controllerEquipmentId, Int16? controllerEquipmentSetupId, int productId, string name, double cost, bool includeinCi, int controllerEquipmentTypeId)
        {
            this.ControllerEquipmentId = controllerEquipmentId;
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.ProductId = productId;
            this.Name = name;
            this.Cost = cost;
            this.IncludeinCi = includeinCi;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public Chemicals()
        {
        }

		#endregion "Constructor"

        #region "Properties"

        /// <summary>
        ///     Gets or sets the GroupTypeId.
        /// </summary>
        /// <value> Group Type Id.</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupDescription.
        /// </summary>
        /// <value> Group Description.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Cost.
        /// </summary>
        /// <value> Parameter Cost.</value>
        public double Cost { get; set; }

        /// <summary>
        ///     Gets or sets IncludeinCI
        /// </summary>
        /// <value> Parameter Include in CI</value>
        public bool IncludeinCi { get; set; }
		/// <summary>
		/// Gets or Sets the Controller Equipment Type Id
		/// </summary>
		/// <value>The Controller Equipment Type Id</value>
		public int ControllerEquipmentTypeId { get; set; }
        /// <summary>
		/// Gets or Sets the Controller Equipment Id
		/// </summary>
		/// <value>The Controller Equipment Id</value>
		public byte? ControllerEquipmentId { get; set; }
        /// <summary>
		/// Gets or Sets the Controller Equipment Setup Id
		/// </summary>
		/// <value>The Controller Equipment Setup Id</value>
		public Int16? ControllerEquipmentSetupId { get; set; }

        /// <summary>
        /// Gets or sets PriceInOunce
        /// </summary>
        /// <value>
        /// The price in ounce.
        /// </value>
        public double PriceInOunce { get; set; }

		#endregion "Properties"
    }
}