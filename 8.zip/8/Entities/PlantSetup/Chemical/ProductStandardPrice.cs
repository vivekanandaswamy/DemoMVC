﻿// -----------------------------------------------------------------------
// <copyright file="ProductStandardPrice.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductStandardPrice </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.PlantSetup.Chemical
{
  public  class ProductStandardPrice
    {
        public ProductStandardPrice()
        {

        }
        public ProductStandardPrice(string ecolabAccountNumber,int productId,decimal listPrice ,decimal contractPrice,decimal countryPrice,DateTime myServiceLastSynchTime)
        {
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ProductId = productId;
            this.ListPrice = Convert.ToDouble( listPrice);
            this.ContractPrice = Convert.ToDouble(contractPrice);
            this.CountryPrice = Convert.ToDouble(countryPrice);
            this.MyServiceLastSynchTime = myServiceLastSynchTime;
        }
        /// <summary>
        /// gets or sets StandardPriceId
        /// </summary>
        /// <value>parameter of StandardPriceId</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }
        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> Parameter Product Id.</value>
        public int ProductId { get; set; }
        /// <summary>
        /// get or sets ListPrice 
        /// </summary>
        /// <value>parameter List Price </value>
        public double ListPrice { get; set; }
        /// <summary>
        /// get or sets ContractPrice 
        /// </summary>
        /// <value>parameter Contract Price </value>
        public double ContractPrice { get; set; }
        /// <summary>
        /// gets or sets CountryPrice 
        /// </summary>
        /// <value>paramer Country Price </value>
        public double CountryPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
        /// <summary>
        /// gets or sets MyServiceLastSynchTime
        /// </summary>
        /// <value>parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }
        /// <summary>
        /// gets or sets MaxNumberOfRecords
        /// </summary>
        /// <value>parameter MaxNumberOfRecords</value>
        public int MaxNumberOfRecords { get; set; }
    }
}
