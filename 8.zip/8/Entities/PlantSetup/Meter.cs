﻿// -----------------------------------------------------------------------
// <copyright file="Meter.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Meter Model</summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    /// <summary>
    ///     class for Meter
    /// </summary>
    public class Meter
    {
        #region "Constructor"

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="meterId">The meter Id.</param>
        /// <param name="description">The description.</param>
        /// <param name="meterType">The meter type.</param>
        /// <param name="meterTypeName">The meter type name.</param>
        /// <param name="ecolabAccountNumber">Ecolab account number.</param>
        /// <param name="maxValueLimit">maximum value limit.</param>
        /// <param name="meterTickUnit">meter tick unit.</param>
        /// <param name="usageFactor">usage factor.</param>
        /// <param name="machineId">the machine Id.</param>
        /// <param name="machinecompartmentName">machine compartment name</param>
        /// <param name="controllerId">controller Id.</param>
        /// <param name="controllerName">controller name.</param>
        /// <param name="controllerModelId">Controller Model Id</param>
        /// <param name="controllerRegionId">Controller Region Id</param>
        /// <param name="controllerTypeId">Controller Type Id</param>
        /// <param name="controllerType">Controller Type</param>
        /// <param name="parentId">The parent Id.</param>
        /// <param name="parentName">parent name.</param>
        /// <param name="calibration">The calibration.</param>
        /// <param name="digitalInputNumber">digital input number</param>
        /// <param name="allowManualentry">allow manual entry</param>
        /// <param name="utilityId">the utility id.</param>
        /// <param name="utilityLocation">utility location.</param>
        /// <param name="lastSyncTime">the last sync time.</param>
        /// <param name="lastModifiedTime">LastModifiedTime</param>
        /// <param name="myServiceMeterGuid">MyServiceMeterGuid</param>
        /// <param name="internalCounter">The internal counter.</param>
        /// <param name="counterUsage">if set to <c>true</c> [counter usage].</param>
        /// <param name="runningTimeUsage">if set to <c>true</c> [running time usage].</param>
        /// <param name="counterAlarmValue">The counter alarm value.</param>
        /// <param name="waterType">Type of the water.</param>
        /// <param name="waterTypeFromFormulaSetup">if set to <c>true</c> [water type from formula setup].</param>
        /// <param name="runningTimeAlarmValue">The running time alarm value.</param>
        /// <param name="isWaterEnergyLogSel">if set to <c>true</c> [is water energy log sel].</param>
        /// <param name="externalCounter">The external counter.</param>
        /// <param name="includeInOperationReport">Include In Operation Report</param>
        public Meter(int meterId, string description, string meterType, string meterTypeName, string ecolabAccountNumber, long maxValueLimit, string meterTickUnit, decimal usageFactor, int? machineId, string machinecompartmentName,
            int controllerId, string controllerName, int controllerModelId, int controllerRegionId, int controllerTypeId, string controllerType,
            int parentId, string parentName, decimal calibration, string digitalInputNumber, bool allowManualentry, int? utilityId,
            string utilityLocation, DateTime lastSyncTime, DateTime lastModifiedTime, Guid? myServiceMeterGuid, int internalCounter, bool counterUsage, bool runningTimeUsage, int counterAlarmValue, int waterType,
            bool waterTypeFromFormulaSetup, int runningTimeAlarmValue, bool isWaterEnergyLogSel, int externalCounter, bool includeInOperationReport)
        {
            this.MeterId = meterId;
            this.Description = description;
            this.MeterType = meterType;
            this.MeterTypeName = meterTypeName;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.MaxValueLimit = maxValueLimit;
            this.MeterTickUnit = meterTickUnit;
            this.UsageFactor = usageFactor;
            this.MachineId = machineId;
            this.MachinecompartmentName = machinecompartmentName;
            this.ControllerId = controllerId;
            this.ControllerName = controllerName;
            this.ControllerModelId = controllerModelId;
            this.ControllerRegionId = controllerRegionId;
            this.ControllerTypeId = controllerTypeId;
            this.ControllerType = controllerType;
            this.ParentId = parentId;
            this.ParentName = parentName;
            this.Calibration = calibration;
            this.DigitalInputNumber = digitalInputNumber;
            this.AllowManualEntry = allowManualentry;
            this.UtilityId = utilityId;
            this.UtilityLocation = utilityLocation;
            this.LastSyncTime = lastSyncTime;
            this.LastModifiedTime = lastModifiedTime;
            this.MyServiceMeterGuid = myServiceMeterGuid;
            this.CounterNum = internalCounter;
            this.CounterUsage = counterUsage;
            this.RunningTimeUsage = runningTimeUsage;
            this.CounterAlarmValue = counterAlarmValue;
            this.WaterType = waterType;
            this.WaterTypeFromFormulaSetup = waterTypeFromFormulaSetup;
            this.RunningTimeAlarmValue = runningTimeAlarmValue;
            this.ISWaterEnergyLogSel = isWaterEnergyLogSel;
            this.ExternalCounter = externalCounter;
            this.IncludeInOperationReport = includeInOperationReport;
        }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="meterId">The meter Id.</param>
        /// <param name="description">The description.</param>
        public Meter(int meterId, string description)
        {
            this.MeterId = meterId;
            this.Description = description;
        }
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="meterId">The meter Id.</param>
        /// <param name="description">The description.</param>
        /// <param name="meterTickUnit">The meter tick unit.</param>
        public Meter(int meterId, string description,string meterTickUnit)
        {
            this.MeterId = meterId;
            this.Description = description;
            this.MeterTickUnit = meterTickUnit;
        }
        /// <summary>
        ///     default constructor
        /// </summary>
        public Meter()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the MeterId.
        /// </summary>
        /// <value>The Parameter  Meter Id.</value>
        public int? MeterId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value>The Parameter  Meter Name.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the MeterType.
        /// </summary>
        /// <value>The Parameter  Uitiliy Type.</value>
        public string MeterType { get; set; }

        /// <summary>
        ///     Gets or sets the MeterTypeName.
        /// </summary>
        /// <value> Uitiliy Type Name.</value>
        public string MeterTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityId.
        /// </summary>
        /// <value>The Parameter  UtilityId.</value>
        public int? UtilityId { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityLocation.
        /// </summary>
        /// <value> UtilityLocation.</value>
        public string UtilityLocation { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value>The Parameter  Group Id.</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineID.
        /// </summary>
        /// <value>The Parameter  Machine ID.</value>
        public int? MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the MachinecompartmentName.
        /// </summary>
        /// <value> MachinecompartmentName.</value>
        public string MachinecompartmentName { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerId.
        /// </summary>
        /// <value>The Parameter  Controller Id.</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerName.
        /// </summary>
        /// <value> Controller Name.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value> Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Region Id
        /// </summary>
        /// <value> Controller Region Id</value>
        public int ControllerRegionId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type Id
        /// </summary>
        /// <value> Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type
        /// </summary>
        /// <value> Controller Type</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the Parent.
        /// </summary>
        /// <value>The Parameter  Parent.</value>
        public int? ParentId { get; set; }

        /// <summary>
        ///     Gets or sets the Parent.
        /// </summary>
        /// <value> Parent name value.</value>
        public string ParentName { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration.
        /// </summary>
        /// <value>The Parameter  Calibration.</value>
        public decimal Calibration { get; set; }

        /// <summary>
        ///     Gets or sets the MeterTickUnit.
        /// </summary>
        /// <value> UOF for Calibration.</value>
        public string MeterTickUnit { get; set; }

        /// <summary>
        ///     Gets or sets the MeterName.
        /// </summary>
        /// <value> Usage Factor.</value>
        public decimal UsageFactor { get; set; }

        /// <summary>
        ///     Gets or sets the DigitalInputNumber.
        /// </summary>
        /// <value> Digital Input Number.</value>
        public string DigitalInputNumber { get; set; }

        /// <summary>
        ///     Gets or sets the AllowManualentry.
        /// </summary>
        /// <value> Allow manual entry.</value>
        public bool AllowManualEntry { get; set; }

        /// <summary>
        ///     Gets or sets the MaxValueLimit.
        /// </summary>
        /// <value> Meter roll out point.</value>
        public long MaxValueLimit { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value>The Parameter  Is deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the UOM
        /// </summary>
        /// <value>The Parameter  UOM </value>
        public string Uom { get; set; }

        /// <summary>
        ///     Gets or sets the UOMName
        /// </summary>
        /// <value>The Parameter  UOMName </value>
        public string UomName { get; set; }

        /// <summary>
        ///     Gets or sets  LastSyncTime
        /// </summary>
        /// <value>lastsynctime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime LastModifiedTimestampAtCentral { get; set; }
        /// <summary>
        /// Gets or sets MyServiceMeterGuid
        /// </summary>
        /// <value>MyServiceMeterGuid</value>
        public Guid? MyServiceMeterGuid { get; set; }
        /// <summary>
        /// Gets or Sets the CounterNum
        /// </summary>
        /// <value>The CounterNum </value>
        public int CounterNum { get; set; }
        /// <summary>
        /// Gets or Sets the CounterUsage
        /// </summary>
        /// <value>The CounterUsage value</value>
        public bool CounterUsage { get; set; }
        /// <summary>
        /// Gets or Sets the RunningTimeUsage 
        /// </summary>
        /// <value>The RunningTimeUsage value</value>
        public bool RunningTimeUsage { get; set; }
        /// <summary>
        /// Gets or Sets the CounterAlarmValue
        /// </summary>
        /// <value>The CounterAlarmValue value</value>
        public int CounterAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets the WaterType
        /// </summary>
        /// <value>The WaterType value</value>
        public int? WaterType { get; set; }
        /// <summary>
        /// Gets or Sets the WaterTypeFromFormulaSetup Counter
        /// </summary>
        /// <value>The WaterTypeFromFormulaSetup Counter value</value>
        public bool WaterTypeFromFormulaSetup { get; set; }
        /// <summary>
        /// Gets or Sets the RunningTimeAlarmValue Counter
        /// </summary>
        /// <value>The RunningTimeAlarmValue Counter value</value>
        public int RunningTimeAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>The ISWaterEnergyLogSel value</value>
        public bool ISWaterEnergyLogSel { get; set; }
        /// <summary>
        /// Gets or Sets ExternalCounter
        /// </summary>
        /// <value>The ExternalCounter value</value>
        public int ExternalCounter { get; set; }

        /// <summary>
        /// Gets or Sets the Include In Operation Report
        /// </summary>
        /// <value>
        /// The Include In Operation Report
        /// </value>
        public bool IncludeInOperationReport { get; set; }
        #endregion
    }
}