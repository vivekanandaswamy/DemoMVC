﻿// -----------------------------------------------------------------------
// <copyright file="Sensor.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Sensor Class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    /// <summary>
    ///     Entity class for Sensor
    /// </summary>
    public class Sensor : BaseEntity
    {
        #region "Constructor"

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="sensorNumber">sensor number of Sensor</param>
        /// <param name="sensorName">sensor name of Sensor.</param>
        /// <param name="sensorType">sensor type of Sensor.</param>
        /// <param name="sensorTypeName">sensor type name</param>
        /// <param name="ecolabAccountNumber">Ecolab accoount number</param>
        /// <param name="machineId">Parameter machine Id.</param>
        /// <param name="machineName">machine name of Sensor.</param>
        /// <param name="controllerId">controller Id of Sensor.</param>
        /// <param name="controllerName">controller name of Sensor</param>
        /// <param name="controllerModelId">Controller Model Id</param>
        /// <param name="controllerRegionId">Controller Region Id</param>
        /// <param name="controllerTypeId">Controller Type Id</param>
        /// <param name="controllerType">Type of the controller.</param>
        /// <param name="outputType">output type of Sensor.</param>
        /// <param name="chemicalforChartId">chemical for chart id</param>
        /// <param name="chemicalforChart">chemical for chart</param>
        /// <param name="uom">The Parameter uom.</param>
        /// <param name="uomName">The Parameter uOMName.</param>
        /// <param name="dashboardActualValue">dashboard actual value</param>
        /// <param name="groupId">the Parameter group Id.</param>
        /// <param name="sensorLocation">sensor location of Sensor.</param>
        /// <param name="analogueImputNumber">analogue imput number</param>
        /// <param name="calibrationValue4">Value for Calibration 4mA</param>
        /// <param name="calibrationValue20">Value for Calibration 20mA</param>
        /// <param name="calibrationTag4">Tag address for Calibration 4mA</param>
        /// <param name="calibrationTag20">Tag address for Calibration 20mA</param>
        /// <param name="lastSyncTime">Last Sync Time of Sensor</param>
        /// <param name="lastModifiedTime">Last modified time</param>
        /// <param name="senorNum">The senor number.</param>
        /// <param name="alarmEnable">if set to <c>true</c> [alarm enable].</param>
        /// <param name="minimumAlarmValue">The minimum alarm value.</param>
        /// <param name="maximumAlarmValue">The maximum alarm value.</param>
        /// <param name="externalSensor">The external sensor.</param>
        /// <param name="LfsWasherNumber">Last modified time</param>
        /// <param name="isWaterEnergyLogSel">if set to <c>true</c> [is water energy log sel].</param>
        /// <param name="washerGroupTypeId">The washer group type identifier.</param>
        public Sensor(int sensorNumber, string sensorName, int? sensorType, string sensorTypeName, string ecolabAccountNumber, int? machineId, string machineName, int? controllerId, 
            string controllerName, int controllerModelId, int controllerRegionId, int controllerTypeId, string controllerType, string outputType, int? chemicalforChartId, 
            string chemicalforChart, string uom, string uomName, bool dashboardActualValue, int? groupId, string sensorLocation, string analogueImputNumber, 
            decimal calibrationValue4, decimal calibrationValue20, string calibrationTag4, string calibrationTag20, DateTime lastSyncTime, DateTime lastModifiedTime, int senorNum,
            bool alarmEnable, int minimumAlarmValue, int maximumAlarmValue, int externalSensor, int LfsWasherNumber, bool isWaterEnergyLogSel, byte washerGroupTypeId, int pumpNumber)
        {
            this.SensorNumber = sensorNumber;
            this.SensorName = sensorName;
            this.SensorType = sensorType;
            this.SensorTypeName = sensorTypeName;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.MachineId = machineId;
            this.MachineName = machineName;
            this.ControllerId = controllerId;
            this.ControllerName = controllerName;
            this.ControllerModelId = controllerModelId;
            this.ControllerRegionId = controllerRegionId;
            this.ControllerTypeId = controllerTypeId;
            this.ControllerType = controllerType;
            this.OutputType = outputType;
            this.ChemicalforChartId = chemicalforChartId;
            this.ChemicalforChart = chemicalforChart;
            this.Uom = uom;
            this.UomName = uomName;
            this.DashboardActualValue = dashboardActualValue;
            this.SensorLocationId = groupId;
            this.GroupId = groupId;
            this.SensorLocation = sensorLocation;
            this.AnalogueImputNumber = analogueImputNumber;
            this.CalibrationValue4 = calibrationValue4;
            this.CalibrationValue20 = calibrationValue20;
            this.CalibrationTag4 = calibrationTag4;
            this.CalibrationTag20 = calibrationTag20;
            this.LastSyncTime = lastSyncTime;
            this.LastModifiedTime = lastModifiedTime;
            this.SensorNum = senorNum;
            this.AlarmEnable = alarmEnable;
            this.MinimumAlarmValue = minimumAlarmValue;
            this.MaximumAlarmValue = maximumAlarmValue;
            this.ExternalSensor = externalSensor;
            this.ISWaterEnergyLogSel = isWaterEnergyLogSel;
            this.LfsWasherNumber = LfsWasherNumber;
            this.IsTunnel = washerGroupTypeId == 2 ? true : false;
            this.PumpNumber = pumpNumber;
        }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="sensorNumber">sensor number</param>
        /// <param name="sensorName">sensor name.</param>
        public Sensor(int sensorNumber, string sensorName)
        {
            this.SensorNumber = sensorNumber;
            this.SensorName = sensorName;
        }
        /// <summary>
        /// default constructor
        /// </summary>
        public Sensor()
        {
        }

        #endregion

        #region "Properties"
        /// <summary>
        /// Gets or sets the LfsWasherNumber
        /// </summary>
        /// <value>
        /// LfsWasherNumber
        /// </value>
        public int? LfsWasherNumber { get; set; }
        /// <summary>
        /// Gets or Sets Pump Number
        /// </summary>
        /// <value>The Pump Number value</value>
        public int PumpNumber { get; set; }
        /// <summary>
        /// Gets or sets the Sensor Number
        /// </summary>
        /// <value>
        /// Sensor Number
        /// </value>
        public int? SensorNumber { get; set; }

        /// <summary>
        /// Gets or sets the Sensor Name
        /// </summary>
        /// <value>
        /// Sensor Name
        /// </value>
        public string SensorName { get; set; }

        /// <summary>
        /// Gets or sets the Sensor Type
        /// </summary>
        /// <value>
        /// Sensor Type
        /// </value>
        public int? SensorType { get; set; }

        /// <summary>
        /// Gets or sets the Sensor Type Name
        /// </summary>
        /// <value>
        /// Sensor Name Type
        /// </value>
        public string SensorTypeName { get; set; }

        /// <summary>
        /// Gets or sets the Ecolab Account Number
        /// </summary>
        /// <value>
        /// Ecolab Account Number
        /// </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the Controller Id
        /// </summary>
        /// <value>
        /// Controller Id
        /// </value>
        public int? ControllerId { get; set; }

        /// <summary>
        /// Gets or sets the Controller Name
        /// </summary>
        /// <value>
        /// Controller Number
        /// </value>
        public string ControllerName { get; set; }

        /// <summary>
        /// Gets or sets the Controller Model Id
        /// </summary>
        /// <value>
        /// Controller Model Id
        /// </value>
        public int ControllerModelId { get; set; }

        /// <summary>
        /// Gets or sets the Controller Region Id
        /// </summary>
        /// <value>
        /// Controller Region Id
        /// </value>
        public int ControllerRegionId { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Type Id
        /// </summary>
        /// <value>
        /// Controller Type Id
        /// </value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Type
        /// </summary>
        /// <value>
        /// Controller Type
        /// </value>
        public string ControllerType { get; set; }

        /// <summary>
        /// Gets or sets the Sensor Location
        /// </summary>
        /// <value>
        /// Sensor Location
        /// </value>
        public int? SensorLocationId { get; set; }

        /// <summary>
        /// Gets or sets the Sensor Location
        /// </summary>
        /// <value>
        /// Sensor Location
        /// </value>
        public string SensorLocation { get; set; }

        /// <summary>
        /// Gets or sets the Machine Id
        /// </summary>
        /// <value>
        /// Machine Id Value
        /// </value>
        public int? MachineId { get; set; }

        /// <summary>
        /// Gets or sets the Machine Id
        /// </summary>
        /// <value>
        /// Machine Id Value
        /// </value>
        public string MachineName { get; set; }

        /// <summary>
        /// Gets or sets the Output Type
        /// </summary>
        /// <value>
        /// Output Type
        /// </value>
        public string OutputType { get; set; }

        /// <summary>
        /// Gets or sets the Chemical for Chart Id
        /// </summary>
        /// <value>
        /// Chemical for Chart
        /// </value>
        public int? ChemicalforChartId { get; set; }

        /// <summary>
        /// Gets or sets the Chemical for Chart
        /// </summary>
        /// <value>
        /// Chemical for Chart
        /// </value>
        public string ChemicalforChart { get; set; }

        /// <summary>
        /// Gets or sets the units of measure
        /// </summary>
        /// <value>
        /// Units of measure
        /// </value>
        public string Uom { get; set; }

        /// <summary>
        /// Gets or sets the UOM Name
        /// </summary>
        /// <value>
        /// The UOM Name.
        /// </value>
        public string UomName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the Dashboard Actual Value
        /// </summary>
        /// <value>
        /// Dashboard Actual Value
        /// </value>
        public bool DashboardActualValue { get; set; }

        /// <summary>
        /// Gets or sets the AnalogueImputNumber
        /// </summary>
        /// <value>
        /// AnalogueImputNumber
        /// </value>
        public string AnalogueImputNumber { get; set; }

        /// <summary>
        /// Gets or sets the Value for Calibration 4mA
        /// </summary>
        /// <value>
        /// CalibrationValue4
        /// </value>
        public decimal CalibrationValue4 { get; set; }

        /// <summary>
        /// Gets or sets the Value for Calibration 20mA
        /// </summary>
        /// <value>
        /// CalibrationValue20
        /// </value>
        public decimal CalibrationValue20 { get; set; }

        /// <summary>
        /// Gets or sets the Tag address for Calibration 4mA
        /// </summary>
        /// <value>
        /// CalibrationTag4
        /// </value>
        public string CalibrationTag4 { get; set; }

        /// <summary>
        /// Gets or sets the Tag address for Calibration 20mA
        /// </summary>
        /// <value>
        /// CalibrationTag20
        /// </value>
        public string CalibrationTag20 { get; set; }

        /// <summary>
        /// Gets or sets the LastSyncTime
        /// </summary>
        /// <value>
        /// LastSyncTime
        /// </value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        /// Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>
        /// LastModifiedTime
        /// </value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        /// Gets or sets MaxNumberOfRecords
        /// </summary>
        /// <value>
        /// The maximum number of records.
        /// </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>
        /// LastModifiedTimestampAtCentral
        /// </value>
        public DateTime LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        /// Gets or sets GroupId
        /// </summary>
        /// <value>
        /// The group identifier.
        /// </value>
        public int? GroupId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to update tags or not
        /// </summary>
        /// <value>
        /// UpdateTags Value
        /// </value>
        public bool UpdateTags { get; set; }
        /// <summary>
        /// Gets or Sets the SensorNum
        /// </summary>
        /// <value>
        /// The Sensor Num
        /// </value>
        public int SensorNum { get; set; }
        /// <summary>
        /// Gets or Sets the Alarm Enable
        /// </summary>
        /// <value>
        /// The Alarm Enable
        /// </value>
        public bool AlarmEnable { get; set; }
        /// <summary>
        /// Gets or Sets the Minimum Alarm Value
        /// </summary>
        /// <value>
        /// The Minimum Alarm Value
        /// </value>
        public int MinimumAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets the Maximum Alarm Value
        /// </summary>
        /// <value>
        /// The Maximum Alarm Value
        /// </value>
        public int MaximumAlarmValue { get; set; }
        /// <summary>
        /// Gets  or Sets The External Sensor
        /// </summary>
        /// <value>
        /// The External Sensor
        /// </value>
        public int ExternalSensor { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>
        /// The ISWaterEnergyLogSel value
        /// </value>
        public bool ISWaterEnergyLogSel { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is tunnel.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is tunnel; otherwise, <c>false</c>.
        /// </value>
        public bool IsTunnel { get; set; }
        #endregion
    }
}