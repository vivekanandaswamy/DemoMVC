﻿// -----------------------------------------------------------------------
// <copyright file="Utility.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Utility class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    /// <summary>
    ///     entity for WaterAndEnergy
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="deviceNumber">Device Number</param>
        /// <param name="deviceName">Device Name</param>
        /// <param name="deviceTypeId">Device Type Id</param>
        /// <param name="deviceTypeDesc">Device Type Description</param>
        /// <param name="deviceModelId">Device Model Id</param>
        /// <param name="deviceModelDesc">Device Model Description</param>
        /// <param name="deviceNoteDesc">Device Note Description</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="comment">ParameterComment</param>
        /// <param name="installDate">ParameterInstallDate</param>
        /// <param name="lastModifiedTimestamp">Last Modified Time Stamp</param>
        /// <param name="lastSyncTime">Last sync Time</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceCustWtrEnrgDvcGuid">My service customer WTR enrg DVC unique identifier.</param>
        public Utility(
            int id,
            int deviceNumber,
            string deviceName,
            int deviceTypeId,
            string deviceTypeDesc,
            int deviceModelId,
            string deviceModelDesc,
            string deviceNoteDesc,
            string ecolabAccountNumber,
            string comment,
            DateTime installDate,
            DateTime lastModifiedTimestamp,
            DateTime lastSyncTime,
            bool isDeleted,
            Guid myServiceCustWtrEnrgDvcGuid
            )
        {
            Id = id;
            DeviceNumber = deviceNumber;
            DeviceName = deviceName;
            DeviceTypeId = deviceTypeId;
            DeviceTypeDesc = deviceTypeDesc;
            DeviceModelId = deviceModelId;
            DeviceModelDesc = deviceModelDesc;
            DeviceNoteDesc = deviceNoteDesc;
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            Comment = comment;
            InstallDate = installDate;
            LastSyncTime = lastSyncTime;
            LastModifiedTimestamp = lastModifiedTimestamp;
            IsDeleted = isDeleted;
            MyServiceCustWtrEnrgDvcGUID = myServiceCustWtrEnrgDvcGuid;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Utility"/> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="deviceNumber">The device number.</param>
        /// <param name="deviceTypeId">The device type identifier.</param>
        /// <param name="deviceModelId">The device model identifier.</param>
        /// <param name="comment">The comment.</param>
        /// <param name="installDate">The install date.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceCustWtrEnrgDvcGuid">My service customer WTR enrg DVC unique identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        public Utility(
            string ecolabAccountNumber,
            Int16 deviceNumber,
            Int16 deviceTypeId,
            int deviceModelId,
            string comment,
            DateTime installDate,
            bool isDeleted,
            Guid myServiceCustWtrEnrgDvcGuid,
            DateTime myServiceLastSynchTime
            )
        {
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            DeviceNumber = deviceNumber;
            DeviceTypeId = deviceTypeId;
            DeviceModelId = deviceModelId;
            Comment = comment;
            InstallDate = installDate;
            IsDeleted = isDeleted;
            MyServiceCustWtrEnrgDvcGUID = myServiceCustWtrEnrgDvcGuid;
            LastModifiedTimestamp = myServiceLastSynchTime;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public Utility()
        {
        }

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Device Id.</value>
        public int? Id { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceNumber.
        /// </summary>
        /// <value> Device Number.</value>
        public int? DeviceNumber { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceName.
        /// </summary>
        /// <value> Device Name.</value>
        public string DeviceName { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceType.
        /// </summary>
        /// <value> Parameter Device Type.</value>
        public int DeviceTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceTypeDesc.
        /// </summary>
        /// <value> Device Type Name.</value>
        public string DeviceTypeDesc { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceModel.
        /// </summary>
        /// <value> Device Model.</value>
        public int DeviceModelId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceModelDesc.
        /// </summary>
        /// <value> Device Model Name.</value>
        public string DeviceModelDesc { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceNote.
        /// </summary>
        /// <value> Device Note.</value>
        public string DeviceNoteDesc { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Comment.
        /// </summary>
        /// <value> Comment.</value>
        public string Comment { get; set; }

        /// <summary>
        ///     Gets or sets the InstallDate.
        /// </summary>
        /// <value> Install Date.</value>
        public DateTime InstallDate { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> Is Deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustWtrEnrgDvcGUID
        /// </summary>
        /// <value>MyServiceCustWtrEnrgDvcGUID</value> 
        public Guid MyServiceCustWtrEnrgDvcGUID { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}