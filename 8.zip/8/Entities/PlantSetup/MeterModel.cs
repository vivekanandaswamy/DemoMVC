﻿// -----------------------------------------------------------------------
// <copyright file="MeterModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MeterModel </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    public class MeterModel
    {
        #region "Constructor"

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="meterId">The meter Id.</param>
        /// <param name="description">The description.</param>
        /// <param name="meterType">The meter type.</param>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="ecolabAccountNumber">Ecolab account number.</param>
        /// <param name="maxValueLimit">maximum value limit.</param>
        /// <param name="meterTickUnit">meter tick unit.</param>
        /// <param name="usageFactor">usage factor.</param>
        /// <param name="controllerId">controller Id.</param>
        /// <param name="parentId">The parent Id.</param>
        /// <param name="calibration">The calibration.</param>
        /// <param name="digitalInputNumber">digital input number</param>
        /// <param name="allowManualentry">allow manual entry</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="machineId">the machine Id.</param>
        /// <param name="id">The identifier.</param>
        /// <param name="lastModifiedByUserId">The last modified by user identifier.</param>
        /// <param name="lastSyncTime">the last sync time.</param>
        /// <param name="isPlant">The is plant.</param>
        /// <param name="isPress">The is press.</param>
        /// <param name="lastModifiedTime">LastModifiedTime</param>
        /// <param name="counterAlarmValue">The counter alarm value.</param>
        /// <param name="waterType">Type of the water.</param>
        /// <param name="waterTypeFromFormulaSetup">if set to <c>true</c> [water type from formula setup].</param>
        /// <param name="runningTimeAlarmValue">The running time alarm value.</param>
        /// <param name="iSWaterEnergyLogSel">if set to <c>true</c> [i s water energy log sel].</param>
        /// <param name="externalCounter">The external counter.</param>
        /// <param name="isCounterUsage">if set to <c>true</c> [is counter usage].</param>
        /// <param name="isRunningTimeUsage">if set to <c>true</c> [is running time usage].</param>
        /// <param name="counterNum">The counter number.</param>
        /// <param name="washerGroupTypeId">The washer group type identifier.</param>
        /// <param name="lfsWasherNumber">The LFS washer number.</param>
        /// <param name="includeInOperationReport">if set to <c>true</c> [include in operation report].</param>
        public MeterModel(int? meterId, string description, string meterType, int? groupId, string ecolabAccountNumber, long? maxValueLimit, string meterTickUnit, decimal? usageFactor, int? controllerId, int? parentId, decimal? calibration, int? digitalInputNumber, bool allowManualentry, bool isDeleted, int? machineId, int? id, int? lastModifiedByUserId, DateTime lastSyncTime, bool? isPlant, bool? isPress, DateTime lastModifiedTime, int counterAlarmValue, int? waterType,
            bool waterTypeFromFormulaSetup, int runningTimeAlarmValue, bool iSWaterEnergyLogSel, int externalCounter, bool isCounterUsage, bool isRunningTimeUsage, int counterNum, byte washerGroupTypeId, int lfsWasherNumber, bool includeInOperationReport)
        {
            this.MeterId = meterId;
            this.Description = description;
            this.MeterType = meterType;
            this.GroupId = groupId;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.MaxValueLimit = maxValueLimit;
            this.MeterTickUnit = meterTickUnit;
            this.UsageFactor = usageFactor;
            this.ControllerId = controllerId;
            this.ParentId = parentId;
            this.Calibration = calibration;
            this.MachineId = machineId;
            this.DigitalInputNumber = digitalInputNumber;
            this.AllowManualEntry = allowManualentry;
            this.IsDeleted = isDeleted;
            this.IsPlant = isPlant;
            this.IsPress = isPress;
            this.Id = id;
            this.LastSyncTime = lastSyncTime;
            this.LastModifiedTime = lastModifiedTime;
            this.LastModifiedByUserId = lastModifiedByUserId;
            this.CounterAlarmValue = counterAlarmValue;
            this.WaterType = waterType;
            this.WaterTypeFromFormulaSetup = waterTypeFromFormulaSetup;
            this.RunningTimeAlarmValue = runningTimeAlarmValue;
            this.ISWaterEnergyLogSel = iSWaterEnergyLogSel;
            this.ExternalCounter = externalCounter;
            this.CounterUsage = isCounterUsage;
            this.RunningTimeUsage = isRunningTimeUsage;
            this.CounterNum = counterNum;
            this.LfsWasherNumber = lfsWasherNumber;
            this.IsTunnel = washerGroupTypeId == 2 ? true : false;
            this.IncludeInOperationReport = includeInOperationReport;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public MeterModel()
        {
        }

        #endregion

        #region "Meter Table Properties"

        /// <summary>
        ///     Gets or sets the MeterId.
        /// </summary>
        /// <value>The Parameter  Meter Id.</value>
        public int? MeterId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value>The Parameter  Meter Name.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the MeterType.
        /// </summary>
        /// <value>The Parameter  Uitiliy Type.</value>
        public string MeterType { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value>The Parameter  Group Id.</value>
        public int? GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the MaxValueLimit.
        /// </summary>
        /// <value> Meter roll out point.</value>
        public long? MaxValueLimit { get; set; }

        /// <summary>
        ///     Gets or sets the MeterTickUnit.
        /// </summary>
        /// <value> UOF for Calibration.</value>
        public string MeterTickUnit { get; set; }

        /// <summary>
        ///     Gets or sets the MeterName.
        /// </summary>
        /// <value> Usage Factor.</value>
        public decimal? UsageFactor { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerId.
        /// </summary>
        /// <value>The Parameter  Controller Id.</value>
        public int? ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Parent.
        /// </summary>
        /// <value>The Parameter  Parent.</value>
        public int? ParentId { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration.
        /// </summary>
        /// <value>The Parameter  Calibration.</value>
        public decimal? Calibration { get; set; }

        /// <summary>
        ///     Gets or sets the DigitalInputNumber.
        /// </summary>
        /// <value> Digital Input Number.</value>
        public int? DigitalInputNumber { get; set; }

        /// <summary>
        ///     Gets or sets the AllowManualentry.
        /// </summary>
        /// <value> Allow manual entry.</value>
        public bool AllowManualEntry { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value>The Parameter  Is deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the MachineID.
        /// </summary>
        /// <value>The Parameter  Machine ID.</value>
        public int? MachineId { get; set; }

        /// <summary>
        /// Gets or sets Id
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedByUserId
        /// </summary>
        /// <value>
        /// The last modified by user identifier.
        /// </value>
        public int? LastModifiedByUserId { get; set; }

        /// <summary>
        /// Gets or sets  LastSyncTime
        /// </summary>
        /// <value>
        /// lastsynctime
        /// </value>
        public DateTime? LastSyncTime { get; set; }

        /// <summary>
        /// Gets or sets IsPlant
        /// </summary>
        /// <value>
        /// The is plant.
        /// </value>
        public bool? IsPlant { get; set; }

        /// <summary>
        /// Gets or sets IsPress
        /// </summary>
        /// <value>
        /// The is press.
        /// </value>
        public bool? IsPress { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        #endregion

        #region "Module Tag Properties"

        /// <summary>
        /// Gets or sets ModuleTagId
        /// </summary>
        /// <value>
        /// The module tag identifier.
        /// </value>
        public int ModuleTagId { get; set; }

        /// <summary>
        /// Gets or sets TagType
        /// </summary>
        /// <value>
        /// The type of the tag.
        /// </value>
        public string TagType { get; set; }

        /// <summary>
        /// Gets or sets TagAddress
        /// </summary>
        /// <value>
        /// The tag address.
        /// </value>
        public string TagAddress { get; set; }

        /// <summary>
        /// Gets or sets ModuleTypeId
        /// </summary>
        /// <value>
        /// The module type identifier.
        /// </value>
        public int ModuleTypeId { get; set; }

        /// <summary>
        /// Gets or sets ModuleId
        /// </summary>
        /// <value>
        /// The module identifier.
        /// </value>
        public int ModuleId { get; set; }

        /// <summary>
        /// Gets or sets Frequency
        /// </summary>
        /// <value>
        /// The frequency.
        /// </value>
        public string Frequency { get; set; }

        /// <summary>
        /// Gets or sets Active
        /// </summary>
        /// <value>
        ///   <c>true</c> if active; otherwise, <c>false</c>.
        /// </value>
        public bool Active { get; set; }

        /// <summary>
        /// Gets or Sets the CounterNum
        /// </summary>
        /// <value>
        /// The CounterNum
        /// </value>
        public int CounterNum { get; set; }

        /// <summary>
        /// Gets or Sets the CounterUsage
        /// </summary>
        /// <value>
        /// The CounterUsage value
        /// </value>
        public bool CounterUsage { get; set; }

        /// <summary>
        /// Gets or Sets the RunningTimeUsage
        /// </summary>
        /// <value>
        /// The RunningTimeUsage value
        /// </value>
        public bool RunningTimeUsage { get; set; }

        /// <summary>
        /// Gets or Sets the CounterAlarmValue
        /// </summary>
        /// <value>
        /// The CounterAlarmValue value
        /// </value>
        public int CounterAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets the WaterType
        /// </summary>
        /// <value>
        /// The WaterType value
        /// </value>
        public int? WaterType { get; set; }
        /// <summary>
        /// Gets or Sets the WaterTypeFromFormulaSetup Counter
        /// </summary>
        /// <value>
        /// The WaterTypeFromFormulaSetup Counter value
        /// </value>
        public bool WaterTypeFromFormulaSetup { get; set; }
        /// <summary>
        /// Gets or Sets the RunningTimeAlarmValue Counter
        /// </summary>
        /// <value>
        /// The RunningTimeAlarmValue Counter value
        /// </value>
        public int RunningTimeAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>
        /// The ISWaterEnergyLogSel value
        /// </value>
        public bool ISWaterEnergyLogSel { get; set; }
        /// <summary>
        /// Gets or Sets ExternalCounter
        /// </summary>
        /// <value>
        /// The ExternalCounter value
        /// </value>
        public int ExternalCounter { get; set; }
        /// <summary>
        /// Gets or Sets LfsWasherNumber
        /// </summary>
        /// <value>
        /// The LfsWasherNumber value
        /// </value>
        public int LfsWasherNumber { get; set; }
        /// <summary>
        /// Gets or Sets IsTunnel
        /// </summary>
        /// <value>
        /// The IsTunnel Value
        /// </value>
        public bool IsTunnel { get; set; }

        /// <summary>
        /// Gets or Sets the Include In Operation Report
        /// </summary>
        /// <value>
        /// The Include In Operation Report
        /// </value>
        public bool IncludeInOperationReport { get; set; }
        #endregion
    }
}