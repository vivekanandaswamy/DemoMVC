﻿// -----------------------------------------------------------------------
// <copyright file="ShiftBreak.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftBreak class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.ShiftLabor
{
    using System;

    /// <summary>
    ///     Entity class for ShiftBreakData
    /// </summary>
    public class ShiftBreak
    {
        /// <summary>
        ///     Gets or sets the BreakId.
        /// </summary>
        /// <value> Parameter Break Id. </value>
        public int BreakId { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value> Parameter Shift Id. </value>
        public short ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the DayId.
        /// </summary>
        /// <value> Day Id. </value>
        public int DayId { get; set; }

        /// <summary>
        ///     Gets or sets the BreakStartTime.
        /// </summary>
        /// <value> Parameter Id. </value>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the BreakEndTime.
        /// </summary>
        /// <value> Parameter Id. </value>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted </value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftBreakId.
        /// </summary>
        /// <value> ShiftBreak Id. </value>
        public int ShiftBreakId { get; set; }
    }
}