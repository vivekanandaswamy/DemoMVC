﻿// -----------------------------------------------------------------------
// <copyright file="Shift.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Shift class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.ShiftLabor
{
    using System;

    /// <summary>
    ///     Entity class for ShiftData
    /// </summary>
    public class Shift
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab account number</param>
        /// <param name="shiftId">The shift Id.</param>
        /// <param name="shiftName">The shift name.</param>
        /// <param name="dayId">The day Id.</param>
        /// <param name="dayName">The day Name.</param>
        /// <param name="startTime">The start time.</param>
        /// <param name="endTime">The end time.</param>
        /// <param name="breakId">The break Id.</param>
        /// <param name="breakShiftId">The break shift id.</param>
        /// <param name="breakDayId">The break day Id.</param>
        /// <param name="breakStartTime">The break start time.</param>
        /// <param name="breakEndTime">The break end time.</param>
        /// <param name="isBreakDeleted">if set to <c>true</c> [is break deleted].</param>
        /// <param name="targetProduction">the target production.</param>
        /// <param name="lastModifiedTime">the last modified time.</param>
        /// <param name="lastSyncTime">the last last sync time.</param>
        /// <param name="targetProductionDisplay">The target production display.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        public Shift(string ecolabAccountNumber, int? shiftId, string shiftName, int? dayId, string dayName, TimeSpan startTime, TimeSpan endTime, int breakId, short breakShiftId, int breakDayId, TimeSpan breakStartTime, TimeSpan breakEndTime, bool isBreakDeleted, decimal targetProduction, DateTime lastModifiedTime, DateTime lastSyncTime, decimal targetProductionDisplay, bool isDeleted)
        {
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ShiftId = shiftId;
            this.ShiftName = shiftName;
            this.DayId = dayId;
            this.DayName = dayName;
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.ShiftBreak = new ShiftBreak { BreakId = breakId, ShiftId = breakShiftId, DayId = breakDayId, StartTime = breakStartTime, EndTime = (breakEndTime == new TimeSpan(23, 59, 59)) ? new TimeSpan(00, 00, 00) : breakEndTime, IsDeleted = isBreakDeleted };
            this.TargetProduction = targetProduction;
            this.LastModifiedTimeStamp = lastModifiedTime;
            this.LastSyncTime = lastSyncTime;
            this.TargetProductionDisplay = targetProductionDisplay;
            this.IsDelete = isDeleted;
        }

        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="ecolabAccountNumber">Ecolab account number</param>
        /// <param name="shiftId">The shift Id.</param>
        /// <param name="shiftName">The shift name.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="lastModifiedTime">the last modified time.</param>
        /// <param name="dayId">The day Id.</param>
        /// <param name="startTime">The start time.</param>
        /// <param name="endTime">The end time.</param>
        /// <param name="targetProduction">the target production.</param>
        /// <param name="isShiftDataDeleted">if set to <c>true</c> [is shift data deleted].</param>
        /// <param name="shiftDataId">The shift data identifier.</param>
        /// <param name="breakId">The break Id.</param>
        /// <param name="breakStartTime">The break start time.</param>
        /// <param name="breakEndTime">The break end time.</param>
        /// <param name="isShiftBreakDataDeleted">if set to <c>true</c> [is shift break data deleted].</param>
        /// <param name="shiftBreakId">The shift break identifier.</param>
        /// <param name="targetProductionDisplay">The target production display.</param>
        public Shift(string ecolabAccountNumber, int? shiftId, string shiftName, Boolean isDelete, DateTime lastModifiedTime, int? dayId, TimeSpan startTime, TimeSpan endTime, decimal targetProduction, Boolean isShiftDataDeleted, int shiftDataId, int breakId, TimeSpan breakStartTime, TimeSpan breakEndTime, Boolean isShiftBreakDataDeleted, int shiftBreakId, decimal targetProductionDisplay)
        {
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ShiftId = shiftId;
            this.ShiftName = shiftName;
            this.IsDelete = isDelete;
            this.LastModifiedTimeStamp = lastModifiedTime;
            this.DayId = dayId;
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.ShiftDataId = shiftDataId;
            this.IsDeleteShiftData = isShiftDataDeleted;
            this.ShiftBreak = new ShiftBreak { BreakId = breakId, StartTime = breakStartTime, EndTime = breakEndTime, ShiftBreakId = shiftBreakId, IsDeleted = isShiftBreakDataDeleted };
            this.TargetProduction = targetProduction;
            this.TargetProductionDisplay = targetProductionDisplay;
        }

        /// <summary>
        /// parameterized constructor to get running shifts
        /// </summary>
        /// <param name="shiftName">The shift name.</param>
        /// <param name="startTime">The start time.</param>
        /// <param name="endTime">The end time.</param>
        public Shift(string shiftName, TimeSpan startTime, TimeSpan endTime)
        {
            this.ShiftName = shiftName;
            this.StartTime = startTime;
            this.EndTime = endTime;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public Shift()
        {
        }

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> The Identifier </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value> The Shift Id. </value>
        public int? ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftName.
        /// </summary>
        /// <value> The string Shift Name.</value>
        public string ShiftName { get; set; }

        /// <summary>
        ///     Gets or sets the DayId.
        /// </summary>
        /// <value> The integer Day Id.</value>
        public int? DayId { get; set; }

        /// <summary>
        ///     Gets or sets the DayName.
        /// </summary>
        /// <value> The string Day Name.</value>
        public string DayName { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime.
        /// </summary>
        /// <value> The Timespan Start Time.</value>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the EndTime.
        /// </summary>
        /// <value> The TimeSpan End Time.</value>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> The string Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProduction.
        /// </summary>
        /// <value> The decimal Target Production. </value>
        public decimal TargetProduction { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProductionDisplay.
        /// </summary>
        /// <value> The decimal TargetProductionDisplay. </value>
        public decimal TargetProductionDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the Count
        /// </summary>
        /// <value>The integer cpunt</value>
        public int Count { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftBreak
        /// </summary>
        /// <value>The ShiftBreak object</value>
        public virtual ShiftBreak ShiftBreak { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftLabor
        /// </summary>
        /// <value>The ShiftLabor object</value>
        public virtual ShiftLabor ShiftLabor { get; set; }

        /// <summary>
        ///     Gets or sets the IsMonday.
        /// </summary>
        /// <value> Boolean Is Monday.</value>
        public bool IsMonday { get; set; }

        /// <summary>
        ///     Gets or sets the IsTuesday.
        /// </summary>
        /// <value> Boolean Is Tuesday.</value>
        public bool IsTuesday { get; set; }

        /// <summary>
        ///     Gets or sets the IsWednesday.
        /// </summary>
        /// <value> Boolean Is Wednesday.</value>
        public bool IsWednesday { get; set; }

        /// <summary>
        ///     Gets or sets the IsThursday.
        /// </summary>
        /// <value> Boolean Is Thursday.</value>
        public bool IsThursday { get; set; }

        /// <summary>
        ///     Gets or sets the IsFriday.
        /// </summary>
        /// <value> Boolean Is Friday.</value>
        public bool IsFriday { get; set; }

        /// <summary>
        ///     Gets or sets the IsSaturday.
        /// </summary>
        /// <value> Boolean Is Saturday.</value>
        public bool IsSaturday { get; set; }

        /// <summary>
        ///     Gets or sets the IsSunday.
        /// </summary>
        /// <value> Boolean Is Sunday.</value>
        public bool IsSunday { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> Boolean Value. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete for ShiftData
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDeleteShiftData { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete for ShiftData
        /// </summary>
        /// <value>IsDelete</value>
        public int ShiftDataId { get; set; }
    }
}