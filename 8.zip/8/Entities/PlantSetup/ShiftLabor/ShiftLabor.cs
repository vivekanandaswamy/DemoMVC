﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLabor.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftLabor </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.ShiftLabor
{
    using System;

    /// <summary>
    ///     Entity class for ShiftLabor
    /// </summary>
    public class ShiftLabor : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="laborId">The labor id</param>
        /// <param name="shiftId">the shift Id . </param>
        /// <param name="dayId">the day id value.</param>
        /// <param name="laborTypeId">the labor Type Id</param>
        /// <param name="laborTypeName">the laborType Name </param>
        /// <param name="locationId">the labor locationId </param>
        /// <param name="loactionName">the labor loactionName</param>
        /// <param name="laborHours">the man hours</param>
        /// <param name="pricePerHr">the price per hour</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        /// <param name="lastSyncTime">lastSyncTime</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="isDeleted">isDeleted</param>
        public ShiftLabor(int laborId, short shiftId, int dayId, int laborTypeId, string laborTypeName, int locationId, string loactionName, int laborHours, decimal pricePerHr, DateTime lastModifiedTime, DateTime lastSyncTime, string ecolabAccountNumber, bool isDeleted)
        {
            this.LaborId = laborId;
            this.ShiftId = shiftId;
            this.DayId = dayId;
            this.LaborTypeId = laborTypeId;
            this.LaborTypeName = laborTypeName;
            this.LocationId = locationId;
            this.LoactionName = loactionName;
            this.LaborHours = laborHours;
            this.PricePerHr = pricePerHr;
            this.LastModifiedTimeStamp = lastModifiedTime;
            this.LastSyncTime = lastSyncTime;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.IsDelete = isDeleted;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ShiftLabor()
        {
        }

        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value> Parameter Shift Id. </value>
        public int? LaborId { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value> Parameter Shift Id. </value>
        public short ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the DayId.
        /// </summary>
        /// <value>The Day Id value.</value>
        public int DayId { get; set; }

        /// <summary>
        ///     Gets or sets the LaborTypeId.
        /// </summary>
        /// <value>The Labor Type Id value.</value>
        public int LaborTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the LaborTypeName.
        /// </summary>
        /// <value> Labor Type Name.</value>
        public string LaborTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the LocationId.
        /// </summary>
        /// <value> Parameter Location Id.</value>
        public int LocationId { get; set; }

        /// <summary>
        ///     Gets or sets the LoactionName.
        /// </summary>
        /// <value> Parameter Location Name.</value>
        public string LoactionName { get; set; }

        /// <summary>
        ///     Gets or sets the LaborHours.
        /// </summary>
        /// <value> Parameter Man hours.</value>
        public int LaborHours { get; set; }

        /// <summary>
        ///     Gets or sets the LaborCount.
        /// </summary>
        /// <value> Parameter Labor Count.</value>
        public int LaborCount { get; set; }

        /// <summary>
        ///     Gets or sets the PricePerHr.
        /// </summary>
        /// <value> Parameter PricePerHr. </value>
        public decimal PricePerHr { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }
    }
}