﻿// -----------------------------------------------------------------------
// <copyright file="LaborTypeCost.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The LaborTypeCost </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.ShiftLabor
{

	public class LaborTypeCost : BaseEntity
	{
		/// <summary>
		///     default constructor
		/// </summary>
		public LaborTypeCost()
		{
		}

		/// <summary>
		///     parameterized constructor
		/// </summary>
		/// <param name="laborTypeId"> Parameter labor Type Id</param>
		/// <param name="cost"> Parameter cost</param>
		public LaborTypeCost(int laborTypeId, decimal cost)
		{
			this.Id = laborTypeId;
			this.Cost = cost;
		}

		/// <summary>
		///     Gets or sets the Cost
		/// </summary>
		/// <value>The Cost Value</value>
		public decimal Cost { get; set; }
	}
}
