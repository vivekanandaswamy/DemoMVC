﻿// -----------------------------------------------------------------------
// <copyright file="ProductionShiftData.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Production Shift Data class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.ShiftLabor
{
	using System;

	public class ProductionShiftData
	{
		/// <summary>
		/// to fetch the production shift data
		/// </summary>
		/// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
		/// <param name="shiftId">the shift id.</param>
		/// <param name="shiftName">shift name.</param>
		/// <param name="startDate">start name.</param>
		/// <param name="endDate">end date.</param>
		/// <param name="targetProduction">target production</param>
		/// <param name="lastSyncTime">last sync time</param>
		public ProductionShiftData(string ecolabAccountNumber, int shiftId, string shiftName, DateTime startDate, DateTime endDate,
			decimal targetProduction, DateTime lastSyncTime)
		{
			this.EcolabAccountNumber = ecolabAccountNumber;
			this.ShiftId = shiftId;
			this.ShiftName = shiftName;
			this.StartDate = startDate;
			this.EndDate = endDate;
			this.TargetProdcution = targetProduction;
			this.LastSyncTime = lastSyncTime;
		}
		public ProductionShiftData()
		{
			
		}

		/// <summary>
		///     Gets or sets the ShiftId.
		/// </summary>
		/// <value> The Shift Id. </value>
		public string EcolabAccountNumber { get; set; }

		/// <summary>
		///     Gets or sets the ShiftId.
		/// </summary>
		/// <value> The Shift Id. </value>
		public int ShiftId { get; set; }

		/// <summary>
		///     Gets or sets the ShiftName.
		/// </summary>
		/// <value> The Shift Name </value>
		public string ShiftName { get; set; }

		/// <summary>
		///     Gets or sets the StartDate.
		/// </summary>
		/// <value> The Start Date </value>
		public DateTime StartDate { get; set; }

		/// <summary>
		///     Gets or sets the EndDate.
		/// </summary>
		/// <value> The End Date. </value>
		public DateTime EndDate { get; set; }

		/// <summary>
		///     Gets or sets the TargetProdcution.
		/// </summary>
		/// <value> The TargetProdcution. </value>
		public decimal TargetProdcution { get; set; }

		/// <summary>
		///     Gets or sets the LastSyncTime.
		/// </summary>
		/// <value> The LastSyncTime. </value>
		public DateTime LastSyncTime { get; set; }
	}
}
