﻿// -----------------------------------------------------------------------
// <copyright file="LaborCost.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The LaborCost class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.ShiftLabor
{
    using System;

    /// <summary>
    ///     Entity class for LaborCost
    /// </summary>
    public class LaborCost : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="laborCostId"> Parameter Labor CostId</param>
        /// <param name="laborTypeId"> Parameter labor TypeId</param>
        /// <param name="description"> Parameter Labor type name</param>
        /// <param name="cost"> Parameter labor cost</param>
        public LaborCost(int laborCostId, int laborTypeId, string description, decimal cost, string ecolabAccountNumber, DateTime lastModifiedTimestamp, DateTime lastSyncTime)
            : base(ecolabAccountNumber)
        {
            this.Id = laborCostId;
            this.LaborTypeId = laborTypeId;
            this.Description = description;
            this.Cost = cost;
            this.LastModifiedTimeStamp = lastModifiedTimestamp;
            this.LastSyncTime = lastSyncTime;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public LaborCost()
        {
        }

        /// <summary>
        ///     Gets or sets the LaborTypeId
        /// </summary>
        /// <value> Parameter Labor Type Id</value>
        public int LaborTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Description
        /// </summary>
        /// <value> Parameter Description</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the Cost
        /// </summary>
        /// <value> Parameter Cost</value>
        public decimal Cost { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}