﻿// -----------------------------------------------------------------------
// <copyright file="TargetProduction.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TargetProduction class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    /// <summary>
    ///     Entity class for TargetProduction
    /// </summary>
    public class TargetProduction : BaseEntity
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="shiftName">vlaue for  shiftName</param>
        /// <param name="shiftId">vlaue for shiftId</param>
        /// <param name="targetProduction">vlaue for targetProduction</param>
        /// <param name="dayId">vlaue for dayId</param>
        /// <param name="startTime">startTime</param>
        /// <param name="endTime">endTime</param>
        /// <param name="targetProductionDisplay">targetProductionDisplay</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        public TargetProduction(string shiftName, int shiftId, decimal targetProduction, int dayId,TimeSpan startTime, TimeSpan endTime, decimal targetProductionDisplay, DateTime lastModifiedTime)
        {
            this.DayId = dayId;
            this.ShiftName = shiftName;
            this.ShiftId = shiftId;
            this.TargetProd = Convert.ToDouble(targetProduction);
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.TargetProdDisplay = targetProduction;
            this.LastModifiedTime = lastModifiedTime;
        }

        /// <summary>
        /// Target production constructor for Sync
        /// </summary>
        /// <param name="id">id</param>
        /// <param name="shiftId">shiftId</param>
        /// <param name="dayId">dayId</param>
        /// <param name="recordedDate">recordedDate</param>
        /// <param name="targetProduction">targetProduction</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="targetProductionDisplay">targetProductionDisplay</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        public TargetProduction(int id, int shiftId, int dayId, DateTime recordedDate, decimal targetProduction, string ecolabAccountNumber, decimal targetProductionDisplay, DateTime lastModifiedTime)
        {
            this.Id = id;
            this.ShiftId = shiftId;
            this.DayId = dayId;
            this.RecordedDate = recordedDate;
            this.TargetProd = Convert.ToDouble(targetProduction);
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.TargetProdDisplay = targetProductionDisplay;
            this.LastModifiedTime = lastModifiedTime;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public TargetProduction()
        {
        }

        /// <summary>
        ///     Gets or sets the DayId
        /// </summary>
        /// <value> Parameter DayId</value>
        public int DayId { get; set; }

        /// <summary>
        ///     Gets or sets the DayName
        /// </summary>
        /// <value> Parameter DayName</value>
        public string DayName { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftName
        /// </summary>
        /// <value> Parameter ShiftName </value>
        public string ShiftName { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId
        /// </summary>
        /// <value> Parameter ShiftId </value>
        public int ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProd
        /// </summary>
        /// <value> Parameter TargetProd</value>
        public double TargetProd { get; set; }

        /// <summary>
        ///     Gets or sets the TargetProd
        /// </summary>
        /// <value> Parameter TargetProd</value>
        public decimal? TargetProdDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime
        /// </summary>
        /// <value> Parameter StartTime</value>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the EndTime
        /// </summary>
        /// <value> Parameter EndTime</value>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the RecordedDate
        /// </summary>
        /// <value> Parameter RecordedDate</value>
        public DateTime RecordedDate { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }
    }
}