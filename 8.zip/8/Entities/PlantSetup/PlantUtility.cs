﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtility.cs" company="Ecolab">
// Constructor and entities of the plantutility class.
// </copyright>
// <summary>The Utility class for entities.</summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    /// <summary>
    ///     class for Utility
    /// </summary>
    public class PlantUtility
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtility" /> class.
        /// </summary>
        public PlantUtility()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtility" /> class.
        /// </summary>
        /// <param name="utilityType">utilityType Value</param>
        /// <param name="location">location Value.</param>
        /// <param name="coldTemp">cold Temperature Value.</param>
        /// <param name="coldPrice">cold Price Value.</param>
        /// <param name="hotTemp">hot Temperature Value.</param>
        /// <param name="hotPrice">hot Price Value.</param>
        /// <param name="temperedTemp">tempered Temperature Value.</param>
        /// <param name="temperedPrice">tempered price Value.</param>
        /// <param name="wastewaterPrice">waste Water Price Value.</param>
        /// <param name="free1Temp">free1 Temperature Value.</param>
        /// <param name="free1Price">free1 Price Value.</param>
        /// <param name="free2Temp">free2 Temperature Value.</param>
        /// <param name="free2Price">free2 Price Value.</param>
        /// <param name="free3Temp">free3 Temperature Value.</param>
        /// <param name="free3Price">free3 Price Value.</param>
        /// <param name="energy">energy Value.</param>
        /// <param name="gasPrice">gas Oil Price Value.</param>
        /// <param name="electricityTarrif">electricity Price Value.</param>
        /// <param name="boilerSteam">boiler Steam Value.</param>
        /// <param name="boilerType">boiler Type Value.</param>
        /// <param name="steamPercentage">steam Percentage Value.</param>
        /// <param name="boilerPercentage">boiler Percentage Value.</param>
        /// <param name="stackPercentage">stack Percentage Value.</param>
        /// <param name="rewashFactor">rewash Factor Value.</param>
        /// <param name="coldSoftTemp">cold Soft Temperature Value.</param>
        /// <param name="coldSoftPrice">cold Soft Price Value.</param>
        /// <param name="coldHardTemp">cold Hard Temperature Value.</param>
        /// <param name="coldHardPrice">cold Hard Price Value.</param>
        /// <param name="hotHardTemp">hot Hard Temperature Value.</param>
        /// <param name="hotHardPrice">hot Hard Price Value.</param>
        /// <param name="hotSoftTemp">hot Soft Temperature Value.</param>
        /// <param name="hotSoftPrice">hot Soft Price Value.</param>
        /// <param name="free1FactorType">free1 Factor Type Value.</param>
        /// <param name="free2FactorType">free2 Factor Type Value.</param>
        /// <param name="free3FactorType">free3 Factor Type Value.</param>
        /// <param name="gasoilType">gas Oil Type Value.</param>
        public PlantUtility(int utilityType, string location, decimal coldTemp, decimal coldPrice, decimal hotTemp,
            decimal hotPrice, decimal temperedTemp, decimal temperedPrice, decimal wastewaterPrice, decimal free1Temp,
            decimal free1Price, decimal free2Temp, decimal free2Price, decimal free3Temp, decimal free3Price,
            decimal energy, decimal gasPrice, decimal electricityTarrif, bool boilerSteam, int boilerType,
            decimal steamPercentage, decimal boilerPercentage, decimal stackPercentage, decimal rewashFactor,
            decimal coldSoftTemp, decimal coldSoftPrice, decimal coldHardTemp, decimal coldHardPrice,
            decimal hotHardTemp, decimal hotHardPrice, decimal hotSoftTemp, decimal hotSoftPrice, string free1FactorType,
            string free2FactorType, string free3FactorType, string gasoilType, string energyContentUnit,
            string energyPriceUnit, decimal evaporationFactor, DateTime lastModifiedTime, DateTime lastSyncTime)
        {
            this.ColdTemp = coldTemp;
            this.ColdPrice = coldPrice;
            this.HotTemp = hotTemp;
            this.HotPrice = hotPrice;
            this.TemperedTemp = temperedTemp;
            this.TemperedPrice = temperedPrice;
            this.WastewaterPrice = wastewaterPrice;
            this.Free1Temp = free1Temp;
            this.Free1Price = free1Price;
            this.Free2Temp = free2Temp;
            this.Free2Price = free2Price;
            this.Free3Temp = free3Temp;
            this.Free3Price = free3Price;
            this.Energy = energy;
            this.GasPrice = gasPrice;
            this.ElectricityTarrif = electricityTarrif;
            this.RewashFactor = rewashFactor;
            this.SteamPercentage = steamPercentage;
            this.BoilerPercentage = boilerPercentage;
            this.StackPercentage = stackPercentage;
            this.BoilerSteam = boilerSteam;
            this.UtilityType = utilityType;
            this.Location = location;
            this.ColdSoftTemp = coldSoftTemp;
            this.ColdSoftPrice = coldSoftPrice;
            this.ColdHardTemp = coldHardTemp;
            this.ColdHardPrice = coldHardPrice;
            this.HotSoftTemp = hotSoftTemp;
            this.HotSoftPrice = hotSoftPrice;
            this.HotHardTemp = hotHardTemp;
            this.HotHardPrice = hotHardPrice;
            this.Free1FactorType = free1FactorType;
            this.Free2FactorType = free2FactorType;
            this.Free3FactorType = free3FactorType;
            this.GasoilType = gasoilType;
            this.EnergyContentUnit = energyContentUnit;
            this.EnergyPriceUnit = energyPriceUnit;
            this.EvaporationFactor = evaporationFactor;
            this.LastModifiedTimestamp = lastModifiedTime;
            this.LastSyncTime = lastSyncTime;
        }

        public PlantUtility(string factorType, int temperature, decimal price, string utilityTypeCode, string regionCode, int myServiceWatrFctrId)
        {
            this.FactorType = factorType;
            this.Temperature = temperature;
            this.Price = price;
            this.UtilityTypeCode = utilityTypeCode;
            this.RegionCode = regionCode;
            this.MyServiceWatrFctrId = myServiceWatrFctrId;
        }

        public PlantUtility(decimal rewashFactor, decimal evaporationFactor, string gasoilType, string myServiceEnergyPriceUom, decimal gasoilPrice)
        {
            this.RewashFactor = rewashFactor;
            this.EvaporationFactor = evaporationFactor;
            this.GasoilType = gasoilType;
            this.MyServiceEnergyPriceUom = myServiceEnergyPriceUom;
            this.GasPrice = gasoilPrice;
        }

        public PlantUtility(bool boilerSteam, decimal steamPercentage, decimal boilerPercentage, decimal stackPercentage, decimal electricTarif, int boilerType)
        {
            this.BoilerSteam = boilerSteam;
            this.SteamPercentage = steamPercentage;
            this.BoilerPercentage = boilerPercentage;
            this.StackPercentage = stackPercentage;
            this.ElectricityTarrif = electricTarif;
			this.BoilerType = boilerType;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Cold Temperature value for the plant utility.
        /// </summary>
        /// <value>Gets Cold Temperature value.</value>
        public decimal ColdTemp { get; set; }

        /// <summary>
        ///     Gets or sets the Cold Price value for the plant utility.
        /// </summary>
        /// <value> Cold price value.  </value>
        public decimal ColdPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Hot Temperature value for the plant utility.
        /// </summary>
        /// <value> Hot Temperature value.</value>
        public decimal HotTemp { get; set; }

        /// <summary>
        ///     Gets or sets the HotPrice value for the plant utility.
        /// </summary>
        /// <value>Hot Price Value.</value>
        public decimal HotPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Tempered Temperature for plant utility.
        /// </summary>
        /// <value>Tempered Temperature value.</value>
        public decimal TemperedTemp { get; set; }

        /// <summary>
        ///     Gets or sets the Tempered price for plant utility.
        /// </summary>
        /// <value>Tempered price value.</value>
        public decimal TemperedPrice { get; set; }

        /// <summary>
        ///     Gets or sets the waste water price for plant utility.
        /// </summary>
        /// <value>Waste water price value.</value>
        public decimal WastewaterPrice { get; set; }

        /// <summary>
        ///     Gets or sets the free1 water type temperature for plant utility.
        /// </summary>
        /// <value>Free1 water type temperature value.</value>
        public decimal Free1Temp { get; set; }

        /// <summary>
        ///     Gets or sets the free1 water type price for plant utility.
        /// </summary>
        /// <value>Free1 water type price value.</value>
        public decimal Free1Price { get; set; }

        /// <summary>
        ///     Gets or sets the Free2Temp for plant utility.
        /// </summary>
        /// <value>Free2 water type temperature.</value>
        public decimal Free2Temp { get; set; }

        /// <summary>
        ///     Gets or sets the Free2Price for plant utility.
        /// </summary>
        /// <value>Free2 water type price value.</value>
        public decimal Free2Price { get; set; }

        /// <summary>
        ///     Gets or sets the Free3Temp for plant utility.
        /// </summary>
        /// <value>Free3 water type temperature.</value>
        public decimal Free3Temp { get; set; }

        /// <summary>
        ///     Gets or sets the Free3Price for plant utility.
        /// </summary>
        /// <value>Free3 water type price value.</value>
        public decimal Free3Price { get; set; }

        /// <summary>
        ///     Gets or sets the Energy for plant utility.
        /// </summary>
        /// <value>Energy Value.</value>
        public decimal Energy { get; set; }

        /// <summary>
        ///     Gets or sets the GasPrice for plant utility.
        /// </summary>
        /// <value>Gas Price value.</value>
        public decimal GasPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Electricity price for plant utility.
        /// </summary>
        /// <value>Electricity Price value.</value>
        public decimal ElectricityTarrif { get; set; }

        /// <summary>
        ///     Gets or sets the Location for plant utility.
        /// </summary>
        /// <value>Location value.</value>
        public string Location { get; set; }

        /// <summary>
        ///     Gets or sets the ColdSoftTemp for plant utility.
        /// </summary>
        /// <value>Cold Soft Temperature value.</value>
        public decimal ColdSoftTemp { get; set; }

        /// <summary>
        ///     Gets or sets the ColdSoftPrice for plant utility.
        /// </summary>
        /// <value>Cold Soft Price value.</value>
        public decimal ColdSoftPrice { get; set; }

        /// <summary>
        ///     Gets or sets the HotSoftTemp for plant utility.
        /// </summary>
        /// <value>Hot soft temperature value.</value>
        public decimal HotSoftTemp { get; set; }

        /// <summary>
        ///     Gets or sets the HotSoftPrice for plant utility.
        /// </summary>
        /// <value>Hot Soft Price value.</value>
        public decimal HotSoftPrice { get; set; }

        /// <summary>
        ///     Gets or sets the ColdHardTemp for plant utility.
        /// </summary>
        /// <value>Cold Hard Temperature value.</value>
        public decimal ColdHardTemp { get; set; }

        /// <summary>
        ///     Gets or sets the ColdHardPrice for plant utility.
        /// </summary>
        /// <value>Cold Hard Price value.</value>
        public decimal ColdHardPrice { get; set; }

        /// <summary>
        ///     Gets or sets the HotHardTemp for plant utility.
        /// </summary>
        /// <value>Hot Hard Temperature value.</value>
        public decimal HotHardTemp { get; set; }

        /// <summary>
        ///     Gets or sets the HotHardPrice for plant utility.
        /// </summary>
        /// <value>Hot Hard Price value.</value>
        public decimal HotHardPrice { get; set; }

        /// <summary>
        ///     Gets or sets the Free1FactorType for plant utility.
        /// </summary>
        /// <value> The Free1 Factor Type value.</value>
        public string Free1FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Free2FactorType for plant utility.
        /// </summary>
        /// <value> The Free2 Factor type value.</value>
        public string Free2FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Free3FactorType for plant utility.
        /// </summary>
        /// <value> The Free3 factor type value.</value>
        public string Free3FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the GasOilType for plant utility.
        /// </summary>
        /// <value> The Gas Oil Type value.</value>
        public string GasoilType { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityType for plant utility.
        /// </summary>
        /// <value> The Utility Type.</value>
        public int UtilityType { get; set; }

        /// <summary>
        ///     Gets or sets the FactorType for plant utility.
        /// </summary>
        /// <value> The Factor Type.</value>
        public string FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature for plant utility.
        /// </summary>
        /// <value> The Temperature.</value>
        public decimal Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the Energy Content for plant utility.
        /// </summary>
        /// <value> The Energy content.</value>
        public decimal EnergyContent { get; set; }

        /// <summary>
        ///     Gets or sets the Price for plant utility.
        /// </summary>
        /// <value> The Price.</value>
        public decimal Price { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether the boiler steam is required or not.
        /// </summary>
        /// <value> The Boiler Steam.</value>
        public bool BoilerSteam { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType for plant utility.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public int BoilerType { get; set; }

        /// <summary>
        ///     Gets or sets the Steam for plant utility.
        /// </summary>
        /// <value> The Steam percentage.</value>
        public decimal SteamPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Boiler for plant utility.
        /// </summary>
        /// <value> The Boiler percentage.</value>
        public decimal BoilerPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Stack for plant utility.
        /// </summary>
        /// <value> The Stack percentage.</value>
        public decimal StackPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the RewashFactor for plant utility.
        /// </summary>
        /// <value> The Rewash Factor percentage.</value>
        public decimal RewashFactor { get; set; }

        /// <summary>
        ///     Gets or sets the energy content unit for plant utility.
        /// </summary>
        /// <value> The Energy Content Unit.</value>
        public string EnergyContentUnit { get; set; }

        /// <summary>
        ///     Gets or sets the energy price unit for plant utility.
        /// </summary>
        /// <value> The Energy Price Unit.</value>
        public string EnergyPriceUnit { get; set; }

        /// <summary>
        ///     Gets or sets the evaporation factor for plant utility.
        /// </summary>
        /// <value> The evaporation factor percentage.</value>
        public decimal EvaporationFactor { get; set; }

        /// <summary>
        ///     Gets or sets EcoalabAccountNumber
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or Sets the utility type code, needed for MyService Integration
        /// </summary>
        public string UtilityTypeCode { get; set; }

        /// <summary>
        ///     Gets or sets RegionCode
        /// </summary>
        /// <returns>RegionCode</returns>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceEnergyPriceUom
        /// </summary>
        /// <returns>MyServiceEnergyPriceUom</returns>
        public string MyServiceEnergyPriceUom { get; set; }

        /// <summary>
        /// Gets or sets MyServiceWatrFctrId
        /// </summary>
        public int MyServiceWatrFctrId { get; set; }

        #endregion
    }
}