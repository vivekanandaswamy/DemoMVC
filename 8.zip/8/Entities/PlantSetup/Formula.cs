﻿// -----------------------------------------------------------------------
// <copyright file="Formula.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Formula </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    /// <summary>
    ///     class Formula
    /// </summary>
    public class Formula
    {
        /// <summary>
        ///     default constructor
        /// </summary>
        public Formula()
        {
        }

        /// <summary>
        /// Parameterized Constructor.
        /// </summary>
        /// <param name="programId">The program Id</param>
        /// <param name="name">The formula name</param>
        /// <param name="pieces">The Parameter pieces</param>
        /// <param name="textileId">The Parameter  textile Id</param>
        /// <param name="categoryName">Parameter Category name.</param>
        /// <param name="ecolabSaturationId">The Ecolab Saturation Id</param>
        /// <param name="ecolabSaturationName">ecolab saturation name</param>
        /// <param name="plantProgramId">The plant Program Id</param>
        /// <param name="plantProgramName">plant program name</param>
        /// <param name="chainTextileId">chain textile id.</param>
        /// <param name="chainTextileCategory">chain textile category</param>
        /// <param name="formulaSegmentId">The formula segment identifier.</param>
        /// <param name="formulaSegmentName">Name of the formula segment.</param>
        /// <param name="rewash">The Parameter  rewash</param>
        /// <param name="weight">The Parameter  weight</param>
        /// <param name="totalCount">Parameter total count .</param>
        /// <param name="customerId">The Customer Id</param>
        /// <param name="customerName">Name of the customer.</param>
        /// <param name="lastModifiedTime">Last modified time</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="weightDisplay">The weight display.</param>
        public Formula(int programId,
                       string name,
                       int pieces,
                       int? textileId,
                       string categoryName,
                       int? ecolabSaturationId,
                       string ecolabSaturationName,
                       int? plantProgramId,
                       string plantProgramName,
                       int? chainTextileId,
                       string chainTextileCategory,
                       int? formulaSegmentId,
                       string formulaSegmentName,
                       bool rewash,
                       decimal weight,
                       int totalCount,
                       int customerId ,
                       string customerName,
                       DateTime lastModifiedTime,
                       string ecolabAccountNumber,
                       bool isDelete,
                       decimal weightDisplay
                       )
        {
            ProgramId = programId;
            Name = name;
            Pieces = pieces;
            EcolabTextileId = textileId;
            EcolabTextileCategoryName = categoryName;
            EcolabSaturationId = ecolabSaturationId;
            EcolabSaturationName = ecolabSaturationName;
            PlantProgramId = plantProgramId;
            PlantProgramName = plantProgramName;
            ChainTextileId = chainTextileId;
            ChainTextileCategory = chainTextileCategory;
            FormulaSegmentId = formulaSegmentId;
            FormulaSegmentName = formulaSegmentName;
            Rewash = rewash;
            Weight = weight;
            TotalCount = totalCount;
            CustomerId = customerId;
            this.CustomerName = customerName;
            LastModifiedTimestamp = lastModifiedTime;
            EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            IsDelete = isDelete;
            WeightDisplay = weightDisplay;
        }

        /// <summary>
        /// constructor for My service
        /// </summary>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="name">name</param>
        /// <param name="myServiceEcolabTextileCategory">EcolabTextileCategory</param>
        public Formula(string ecolabAccountNumber, string name, int myServiceEcolabTextileCategory)
        {
            EcolabAccountNumber = ecolabAccountNumber;
            Name = name;
            EcolabTextileId = myServiceEcolabTextileCategory;
        }

        /// <summary>
        /// constructor for RedFlag
        /// </summary>
        /// <param name="productId">productId</param>
        /// <param name="name">name</param>
        public Formula(int productId, string name)
        {
            this.ProgramId = productId;
            Name = name;
        }

        /// <summary>
        /// constructor for RedFlag
        /// </summary>
        /// <param name="productId">The product Id</param>
        /// <param name="name">The name of Formula</param>
        /// <param name="textileId">The Textile Category Id</param>
        /// <param name="categoryName">The Textile Category Name</param>
        public Formula(int productId, string name, int textileId, string categoryName)
        {
            this.ProgramId = productId;
            Name = name;
            EcolabTextileId = textileId;
            EcolabTextileCategoryName = categoryName;
        }

        /// <summary>
        /// constructor for RedFlag
        /// </summary>
        /// <param name="productId">productId</param>
        /// <param name="name">name</param>
        /// <param name="ecolabtextileId">The Ecolab Textile Category Id</param>
        /// <param name="ecolabTextileName">The Textile Category Name</param>
        /// <param name="chainTextileyId">The Chain Textile Category Id</param>
        /// <param name="chainTextileName">The Chain Textile Category Name</param>
        public Formula(int productId, string name, int ecolabtextileId, string ecolabTextileName, int chainTextileyId, string chainTextileName)
        {
            this.ProgramId = productId;
            Name = name;
            EcolabTextileId = ecolabtextileId;
            EcolabTextileCategoryName = ecolabTextileName;
            ChainTextileId = chainTextileyId;
            ChainTextileCategory = chainTextileName;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Formula"/> class for Sync of Formulas
        /// </summary>
        /// <param name="programId">The program identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="pieces">The pieces.</param>
        /// <param name="ecolabTextileCategoryId">The ecolab textile category identifier.</param>
        /// <param name="formulaSegmentId">The formula segment identifier.</param>
        /// <param name="rewash">if set to <c>true</c> [rewash].</param>
        /// <param name="weight">The weight.</param>
        /// <param name="ecolabSaturationId">The ecolab saturation identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="plantProgramId">The plant program identifier.</param>
        /// <param name="chainTextileId">The chain textile identifier.</param>
        /// <param name="customerId">The customer identifier.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="LastModifiedTime">The last modified time.</param>
        /// <param name="weightDisplay">The weight display.</param>
        public Formula(int programId, string name, int? pieces, int? ecolabTextileCategoryId, int? formulaSegmentId, bool rewash, decimal? weight, int? ecolabSaturationId, string ecolabAccountNumber, int? plantProgramId, int? chainTextileId, int? customerId, bool isDeleted, DateTime LastModifiedTime, decimal? weightDisplay)
        {
            this.ProgramId = programId;
            this.Name = name;
            this.Pieces = pieces;
            this.EcolabTextileId = ecolabTextileCategoryId;
            this.FormulaSegmentId = formulaSegmentId;
            this.Rewash = rewash;
            this.Weight = weight;
            this.EcolabSaturationId = ecolabSaturationId;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.PlantProgramId = plantProgramId;
            this.ChainTextileId = chainTextileId;
            this.CustomerId = customerId;
            this.IsDelete = isDeleted;
            this.LastModifiedTimestamp = LastModifiedTime;
            this.WeightDisplay = weightDisplay;
        }

        /// <summary>
        ///     Gets or sets the ProgramId.
        /// </summary>
        /// <value> Ecolab ProgramId.</value>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value> The Name value.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Pieces.
        /// </summary>
        /// <value> The Pieces.</value>
        public int? Pieces { get; set; }

        /// <summary>
        /// Gets or sets the plant chain identifier.
        /// </summary>
        /// <value>The plant chain identifier.</value>
        public int PlantChainId { get; set; }

        /// <summary>
        ///     Gets or sets the Pieces.
        /// </summary>
        /// <value> The Pieces.</value>
        public int? EcolabTextileId { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value> The Ecolab Textile Category Id.</value>
        public string EcolabTextileCategoryName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabTextileCategoryId.
        /// </summary>
        /// <value> The Ecolab Textile Category Id.</value>
        public int? EcolabSaturationId { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabSaturationId.
        /// </summary>
        /// <value> The Ecolab Saturation Id.</value>
        public string EcolabSaturationName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabSaturationId.
        /// </summary>
        /// <value> The Ecolab Saturation Id.</value>
        public int? PlantProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the PlantProgramId.
        /// </summary>
        /// <value> The Plant Program Id.</value>
        public string PlantProgramName { get; set; }

        /// <summary>
        ///     Gets or sets the TextileId.
        /// </summary>
        /// <value> The Textile Id.</value>
        public int? ChainTextileId { get; set; }

        /// <summary>
        ///     Gets or sets the TextileId.
        /// </summary>
        /// <value> The Textile Id.</value>
        public string ChainTextileCategory { get; set; }

        /// <summary>
        /// Gets or sets the formula segment identifier.
        /// </summary>
        /// <value>The formula segment identifier.</value>
        public int? FormulaSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the name of the formula segment.
        /// </summary>
        /// <value>The name of the formula segment.</value>
        public string FormulaSegmentName { get; set; }

        /// <summary>
        /// Gets or sets the formula category.
        /// </summary>
        /// <value>The formula category.</value>
        public int FormulaCategory { get; set; }
        /// <summary>
        /// Gets or sets the name of the formula category.
        /// </summary>
        /// <value>The name of the formula category.</value>
        public string FormulaCategoryName { get; set; }

        /// <summary>
        ///     Gets or sets the Rewash.
        /// </summary>
        /// <value> The Rewash.</value>
        public bool Rewash { get; set; }

        /// <summary>
        ///     Gets or sets the Weight.
        /// </summary>
        /// <value> The Weight.</value>
        public decimal? Weight { get; set; }

        /// <summary>
        ///     Gets or sets the Weight.
        /// </summary>
        /// <value> The Parameter  Weight.</value>
        public decimal? WeightDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the PieceWeight.
        /// </summary>
        /// <value> The Piece Weight.</value>
        public decimal PieceWeight { get; set; }

        /// <summary>
        ///     Gets or sets the PieceWeight.
        /// </summary>
        /// <value> The Piece Weight.</value>
        public string PieceWeightAsString { get; set; }

        /// <summary>
        ///     Gets or sets the UserId.
        /// </summary>
        /// <value> TheUserId.</value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets the TotalCount.
        /// </summary>
        /// <value> TotalCount</value>
        public int TotalCount { get; set; }

        /// <summary>
        ///     Gets or sets the CustomerId.
        /// </summary>
        /// <value> Parameter  CustomerId</value>
        public int? CustomerId { get; set; }

        /// <summary>
        ///     Gets or sets the CustomerId.
        /// </summary>
        /// <value> Parameter  CustomerId</value>
        public string CustomerName { get; set; }

        /// <summary>
        ///     Gets or sets EcolabAccountNumber
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}