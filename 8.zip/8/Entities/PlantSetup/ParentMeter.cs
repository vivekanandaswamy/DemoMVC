﻿// -----------------------------------------------------------------------
// <copyright file="ParentMeter.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ParentMeter </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Entity class for PlantMeter
    /// </summary>
    public class ParentMeter
    {
        #region "Constructor"

        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="meterId">The Parameter Meter Id</param>
        /// <param name="description">The Parameter Description</param>
        public ParentMeter(int meterId, string description)
        {
            this.MeterId = meterId;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ParentMeter()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the MeterID
        /// </summary>
        /// <value>Parent meter id</value>
        public int MeterId { get; set; }

        /// <summary>
        ///     Gets or sets the Description
        /// </summary>
        /// <value>Parent meter name</value>
        public string Description { get; set; }

        #endregion
    }
}