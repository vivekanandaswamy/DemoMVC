﻿// -----------------------------------------------------------------------
// <copyright file="SensorModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorModel </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    public class SensorModel
    {
        #region "Constructor"

        /// <summary>
        ///     SensorModel
        /// </summary>
        /// <param name="sensorId">sensorId</param>
        /// <param name="description">description</param>
        /// <param name="sensorType">sensorType</param>
        /// <param name="groupId">groupId</param>
        /// <param name="machineCompartment">machineCompartment</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="controllerId">controllerID</param>
        /// <param name="outputType">outputType</param>
        /// <param name="calibration4mA">calibration4mA</param>
        /// <param name="analogueInputNumber">analogueInputNumber</param>
        /// <param name="chemicalforChart">chemicalforChart</param>
        /// <param name="uom">uom</param>
        /// <param name="dashboardActualValue">dashboardActualValue</param>
        /// <param name="isDeleted">isDeleted</param>
        /// <param name="id">id</param>
        /// <param name="lastModifiedByUserId">lastModifiedByUserId</param>
        /// <param name="isPlant">isPlant</param>
        /// <param name="isPress">isPress</param>
        /// <param name="calibration20mA">calibration20mA</param>
        /// <param name="lastSyncTime">lastSyncTime</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        public SensorModel(int? sensorId, string description, int? sensorType, int groupId, int? machineCompartment, string ecolabAccountNumber, int? controllerId, string outputType, decimal calibration4mA, int? analogueInputNumber, int? chemicalforChart, string uom, bool dashboardActualValue, bool isDeleted, int id, int lastModifiedByUserId, bool isPlant, bool isPress, decimal calibration20mA, DateTime lastSyncTime, DateTime lastModifiedTime, int senorNum,
            bool alarmEnable, int minimumAlarmValue, int maximumAlarmValue, int externalSensor, bool isWaterEnergyLogSel, byte washerGroupTypeId, int lfsWasherNumber, byte pumpNumber)
        {
            this.SensorId = sensorId;
            this.Description = description;
            this.SensorType = sensorType;
            this.GroupId = groupId;
            this.MachineCompartment = machineCompartment;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ControllerId = controllerId;
            this.OutputType = outputType;
            this.Calibration4mA = calibration4mA;
            this.AnalogueInputNumber = analogueInputNumber;
            this.ChemicalforChart = chemicalforChart;
            this.Uom = uom;
            this.DashboardActualValue = dashboardActualValue;
            this.IsDeleted = isDeleted;
            this.Id = id;
            this.LastModifiedByUserId = lastModifiedByUserId;
            this.IsPlant = isPlant;
            this.IsPress = isPress;
            this.Calibration20mA = calibration20mA;
            this.LastSyncTime = lastSyncTime;
            this.LastModifiedTime = lastModifiedTime;
            this.SensorNum = senorNum;
            this.AlarmEnable = alarmEnable;
            this.MinimumAlarmValue = minimumAlarmValue;
            this.MaximumAlarmValue = maximumAlarmValue;
            this.ExternalSensor = externalSensor;
            this.ISWaterEnergyLogSel = isWaterEnergyLogSel;
            this.LfsWasherNumber = lfsWasherNumber;
            this.PumpNumber = pumpNumber;
            this.IsTunnel = washerGroupTypeId == 2 ? true : false;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public SensorModel()
        {
        }

        #endregion

        #region "sensor model"

        /// <summary>
        ///     Gets or sets the SensorId
        /// </summary>
        /// <value>SensorId</value>
        public int? SensorId { get; set; }

        /// <summary>
        ///     Gets or sets Description
        /// </summary>
        /// <value>Description</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets SensorType
        /// </summary>
        /// <value>SensorType</value>
        public int? SensorType { get; set; }

        /// <summary>
        ///     Gets or sets GroupId
        /// </summary>
        /// <value>GroupId</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets MachineCompartment
        /// </summary>
        /// <value>MachineCompartment</value>
        public int? MachineCompartment { get; set; }

        /// <summary>
        ///     Gets or sets EcolabAccountNumber
        /// </summary>
        /// <value>EcolabAccountNumber</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets ControllerID
        /// </summary>
        /// <value>ControllerID</value>
        public int? ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets OutputType
        /// </summary>
        /// <value>OutputType</value>
        public string OutputType { get; set; }

        /// <summary>
        ///     Gets or sets Calibration4mA
        /// </summary>
        /// <value>Calibration4mA</value>
        public decimal Calibration4mA { get; set; }

        /// <summary>
        ///     Gets or sets AnalogueInputNumber
        /// </summary>
        /// <value>AnalogueInputNumber</value>
        public int? AnalogueInputNumber { get; set; }

        /// <summary>
        ///     Gets or sets ChemicalforChart
        /// </summary>
        /// <value>ChemicalforChart</value>
        public int? ChemicalforChart { get; set; }

        /// <summary>
        ///     Gets or sets UOM
        /// </summary>
        /// <value>The UOM.</value>
        public string Uom { get; set; }

        /// <summary>
        ///     Gets or sets DashboardActualValue
        /// </summary>
        /// <value>DashboardActualValue</value>
        public bool DashboardActualValue { get; set; }

        /// <summary>
        ///     Gets or sets Is_deleted
        /// </summary>
        /// <value>Is_deleted</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets Id
        /// </summary>
        /// <value>Id.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedByUserId
        /// </summary>
        /// <value>LastModifiedByUserId</value>
        public int LastModifiedByUserId { get; set; }

        /// <summary>
        ///     Gets or sets IsPlant
        /// </summary>
        /// <value>IsPlant</value>
        public bool IsPlant { get; set; }

        /// <summary>
        ///     Gets or sets IsPress
        /// </summary>
        /// <value>IsPress</value>
        public bool IsPress { get; set; }

        /// <summary>
        ///     Gets or sets Calibration20mA
        /// </summary>
        /// <value>Calibration20mA</value>
        public decimal Calibration20mA { get; set; }

        /// <summary>
        ///     Gets or sets LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }
        /// <summary>
        /// Gets or Sets the SensorNum
        /// </summary>
        /// <value>The Sensor Num</value>
        public int SensorNum { get; set; }
        /// <summary>
        /// Gets or Sets the Alarm Enable
        /// </summary>
        /// <value>The Alarm Enable</value>
        public bool AlarmEnable { get; set; }
        /// <summary>
        /// Gets or Sets the Minimum Alarm Value
        /// </summary>
        /// <value>The Minimum Alarm Value</value>
        public int MinimumAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets the Maximum Alarm Value
        /// </summary>
        /// <value>The Maximum Alarm Value</value>
        public int MaximumAlarmValue { get; set; }
        /// <summary>
        /// Gets  or Sets The External Sensor
        /// </summary>
        /// <value>The External Sensor</value>
        public int ExternalSensor { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>The ISWaterEnergyLogSel value</value>
        public bool ISWaterEnergyLogSel { get; set; }
        /// <summary>
        /// Gets or Sets LfsWasherNumber
        /// </summary>
        /// <value>The LfsWasherNumber value</value>
        public int LfsWasherNumber { get; set; }
        /// <summary>
        /// Gets or Sets Pump Number
        /// </summary>
        /// <value>The Pump Number value</value>
        public byte PumpNumber { get; set; }
        /// <summary>
        /// Gets or Sets IsTunnel
        /// </summary>
        /// <value>The IsTunnel Value</value>
        public bool IsTunnel { get; set; }

        #endregion
    }
}