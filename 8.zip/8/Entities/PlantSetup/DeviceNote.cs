﻿// -----------------------------------------------------------------------
// <copyright file="DeviceNote.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Device Note </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     entity for DeviceNote
    /// </summary>
    public class DeviceNote
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor.
        /// </summary>
        /// <param name="deviceNotelId"> Device Note Id. </param>
        /// <param name="description"> Device model name. </param>
        public DeviceNote(int deviceNotelId, string description)
        {
            this.DeviceNoteId = deviceNotelId;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor.
        /// </summary>
        public DeviceNote()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the DeviceNoteId.
        /// </summary>
        /// <value> Device note id.</value>
        public int DeviceNoteId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Device note name.</value>
        public string Description { get; set; }

        #endregion
    }
}