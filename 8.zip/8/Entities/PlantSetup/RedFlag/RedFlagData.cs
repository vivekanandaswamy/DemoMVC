﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagData.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RedFlag Location </summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.PlantSetup.RedFlag
{
    /// <summary>
    ///     Entity class for RedFlagLocation
    /// </summary>
    public class RedFlagData
    {
        #region "Constructor"

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="redflagId">The redflag identifier.</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="shiftId">The shift identifier.</param>
        /// <param name="redFlagValue">The red flag value.</param>
        /// <param name="redFlagMinSetPoint">The red flag minimum set point.</param>
        /// <param name="redFlagMaxSetPoint">The red flag maximum set point.</param>
        /// <param name="partitionOn">The partition on.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        public RedFlagData(int redflagId, int plantId, int shiftId, decimal redFlagValue, decimal redFlagMinSetPoint, decimal redFlagMaxSetPoint, DateTime partitionOn, DateTime lastSyncTime)
        {
            this.RedFlagId = redflagId;
            this.PlantId = plantId;
            this.ShiftId = shiftId;
            this.RedFlagValue = redFlagValue;
            this.RedFlagMinSetPoint = redFlagMinSetPoint;
            this.RedFlagMaxSetPoint = redFlagMaxSetPoint;
            this.PartitionOn = partitionOn;
            this.LastSyncTime = lastSyncTime;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public RedFlagData()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the RedFlagId.
        /// </summary>
        /// <value> RedFlagId.</value>
        public int RedFlagId { get; set; }

        /// <summary>
        /// PlantId
        /// </summary>
        public int PlantId { get; set; }

        /// <summary>
        /// ShiftId
        /// </summary>
        public int ShiftId { get; set; }

        /// <summary>
        /// RedFlagValue
        /// </summary>
        public decimal RedFlagValue { get; set; }

        /// <summary>
        /// RedFlagMinSetPoint
        /// </summary>
        public decimal RedFlagMinSetPoint { get; set; }

        /// <summary>
        /// RedFlagMaxSetPoint
        /// </summary>
        public decimal RedFlagMaxSetPoint { get; set; }

        /// <summary>
        ///     Gets or sets the PatitionOn
        /// </summary>
        /// <value>PartitionOn</value>
        public DateTime PartitionOn { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        #endregion
    }
}