﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagMappingData.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Red Flag Mapping Data class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.RedFlag
{

	public class RedFlagMappingData : BaseEntity
	{
		public RedFlagMappingData(int id, int mappingId, int machineId, bool isDeleted)
		{
			this.Id = id;
			this.MappingId = mappingId;
			this.MachineId = machineId;
			this.IsDeleted = isDeleted;
		}

		/// <summary>
		/// Red Flag mapping data default contructor
		/// </summary>
		public RedFlagMappingData() { }
		
		/// <summary>
		/// Gets or sets MachineId
		/// </summary>
		/// <value>machine ID.</value>
		public int MachineId { get; set; }

        /// <summary>
        /// Gets or sets MappingId
        /// </summary>
        /// <value>Mapping Id</value>
        public int MappingId { get; set; }
    }
}
