﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagLocation.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RedFlag Location </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.RedFlag
{
    /// <summary>
    ///     Entity class for RedFlagLocation
    /// </summary>
    public class RedFlagLocation
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="groupTypeId"> Utility location type id </param>
        /// <param name="groupDescription"> Utility location name </param>
        /// <param name="groupMainType"> Group Main Type</param>
        public RedFlagLocation(int groupTypeId, string groupDescription, int groupMainType)
        {
            this.GroupTypeId = groupTypeId;
            this.GroupDescription = groupDescription;
            this.GroupMainType = groupMainType;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public RedFlagLocation()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the GroupTypeId.
        /// </summary>
        /// <value> Group Type Id.</value>
        public int GroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupDescription.
        /// </summary>
        /// <value> Group Description.</value>
        public string GroupDescription { get; set; }

        /// <summary>
        ///     Gets or sets the GroupMainType.
        /// </summary>
        /// <value> Group Main Type.</value>
        public int GroupMainType { get; set; }

        #endregion
    }
}