﻿// -----------------------------------------------------------------------
// <copyright file="RedFlag.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlag class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.RedFlag
{
    using System;
    using System.Collections.Generic;

	/// <summary>
    ///     entity class for RedFlag
    /// </summary>
    public class RedFlag : BaseEntity
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="id">The Parameter Id</param>
        /// <param name="itemId">The Parameter Item Id</param>
        /// <param name="itemName">The Parameter Item Name</param>
        /// <param name="minimumRange">The Parameter Minimum Range</param>
        /// <param name="maximumRange">The Parameter Maximum Range</param>
        /// <param name="uom">The Parameter UOM</param>
        /// <param name="locationId">The Parameter Location Id</param>
        /// <param name="locationName">The Parameter Location Name</param>
        /// <param name="ecolabAccountNumber">The Parameter Ecolab Account Number</param>
        /// <param name="machineID">The machine identifier.</param>
        /// <param name="machineName">The Parameter Machine Name</param>
        /// <param name="categoryId">The category identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="formulaName">Name of the formula.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="productName">Name of the product.</param>
        /// <param name="meterId">The meter identifier.</param>
        /// <param name="meterName">Name of the meter.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        public RedFlag(
                        int id, 
                        int itemId, 
                        string itemName,
                        decimal minimumRange, 
                        decimal maximumRange, 
                        string uom,
                        int locationId, 
                        string locationName, 
                        string ecolabAccountNumber, 
                        string machineID,
                        string machineName,
                        int categoryId,
                        int? formulaId,
                        string formulaName,
                        int? productId,
                        string productName,
                        int? meterId,
                        string meterName,
                        DateTime lastModifiedTime,
                        DateTime lastSyncTime,
                        bool isDelete
                        )
        {
            Id = id;
            ItemId = itemId;
            ItemName = itemName;
            MinimumRange = minimumRange;
            MaximumRange = maximumRange;
            Uom = uom;
            LocationId = locationId;
            LocationName = locationName;
            EcolabAccountNumber = ecolabAccountNumber;
            MachineIDs = machineID;
            MachineName = machineName;
            CategoryId = categoryId;
            FormulaId = formulaId;
            FormulaName = formulaName;
            ProductId = productId;
            ProductName = productName;
            MeterId = meterId;
            MeterName = meterName;
            LastModifiedTimestamp = lastModifiedTime;
            LastSyncTime = lastSyncTime;
            IsDelete = isDelete;
        }

        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="id">The Parameter Id</param>
        /// <param name="itemId">The Parameter Item Id</param>
        /// <param name="itemName">The Parameter Item Name</param>
        /// <param name="minimumRange">The Parameter Minimum Range</param>
        /// <param name="maximumRange">The Parameter Maximum Range</param>
        /// <param name="uom">The Parameter UOM</param>
        /// <param name="locationId">The Parameter Location Id</param>
        /// <param name="locationName">The Parameter Location Name</param>
        /// <param name="ecolabAccountNumber">The Parameter Ecolab Account Number</param>
        /// <param name="machineID">The machine identifier.</param>
        /// <param name="machineName">The Parameter Machine Name</param>
        /// <param name="categoryId">The category identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="formulaName">Name of the formula.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="productName">Name of the product.</param>
        /// <param name="meterId">The meter identifier.</param>
        /// <param name="meterName">Name of the meter.</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="sensorID">The Sensor Id</param>
        public RedFlag(
                        int id,
                        int itemId,
                        string itemName,
                        decimal minimumRange,
                        decimal maximumRange,
                        string uom,
                        int locationId,
                        string locationName,
                        string ecolabAccountNumber,
                        string machineID,
                        string machineName,
                        int categoryId,
                        int? formulaId,
                        string formulaName,
                        int? productId,
                        string productName,
                        int? meterId,
                        string meterName,
                        DateTime lastModifiedTime,
                        DateTime lastSyncTime,
                        bool isDelete,
                        int? sensorID
                        )
        {
            Id = id;
            ItemId = itemId;
            ItemName = itemName;
            MinimumRange = minimumRange;
            MaximumRange = maximumRange;
            Uom = uom;
            LocationId = locationId;
            LocationName = locationName;
            EcolabAccountNumber = ecolabAccountNumber;
            MachineIDs = machineID;
            MachineName = machineName;
            CategoryId = categoryId;
            FormulaId = formulaId;
            FormulaName = formulaName;
            ProductId = productId;
            ProductName = productName;
            MeterId = meterId;
            MeterName = meterName;
            LastModifiedTimestamp = lastModifiedTime;
            LastSyncTime = lastSyncTime;
            IsDelete = isDelete;
            this.SensorId = sensorID;
        }

        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="id">The Parameter Id</param>
        /// <param name="itemId">The Parameter Item Id</param>
        /// <param name="itemName">The Parameter Item Name</param>
        /// <param name="minimumRange">The Parameter Minimum Range</param>
        /// <param name="maximumRange">The Parameter Maximum Range</param>
        /// <param name="uom">The Parameter UOM</param>
        /// <param name="locationId">The Parameter Location Id</param>
        /// <param name="locationName">The Parameter Location Name</param>
        /// <param name="ecolabAccountNumber">The Parameter Ecolab Account Number</param>
        /// <param name="machineID">The machine identifier.</param>
        /// <param name="machineName">The Parameter Machine Name</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="isDelete">if set to <c>true</c> [is delete].</param>
        /// <param name="categoryId">The category identifier.</param>
        /// <param name="formulaCategoryId">The formula category identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="meterId">The meter identifier.</param>
        /// <param name="sensorId">The sensor identifier.</param>
        public RedFlag(
                        int id,
                        int itemId,
                        string itemName,
                        decimal minimumRange,
                        decimal maximumRange,
                        string uom,
                        int locationId,
                        string locationName,
                        string ecolabAccountNumber,
                        string machineID,
                        string machineName,
                        DateTime lastModifiedTime,
                        DateTime lastSyncTime,
                        bool isDelete,
                        int categoryId,
                        int formulaCategoryId,
                        int? formulaId,
                        int? productId,
                        int? meterId,
                        int? sensorId
                        )
        {
            Id = id;
            ItemId = itemId;
            ItemName = itemName;
            MinimumRange = minimumRange;
            MaximumRange = maximumRange;
            Uom = uom;
            LocationId = locationId;
            LocationName = locationName;
            EcolabAccountNumber = ecolabAccountNumber;
            MachineIDs = machineID;
            MachineName = machineName;
            LastModifiedTimestamp = lastModifiedTime;
            LastSyncTime = lastSyncTime;
            IsDelete = isDelete;
            CategoryId = CategoryId;
            FormulaCategoryId = formulaCategoryId;
            FormulaId = formulaId;
            ProductId = productId;
            MeterId = meterId;
            SensorId = sensorId;

        }

        /// <summary>
        /// RedFlag for sync
        /// </summary>
        /// <param name="id">red flag id</param>
        /// <param name="maximumRange">maximum value</param>
        /// <param name="locationId">location Id</param>
        /// <param name="itemId">Item ID</param>
        /// <param name="minimumRange">minimum value</param>
        /// <param name="isDeleted">is deleted.</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="categoryId">The category identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="meterId">The meter identifier.</param>
        /// <param name="sensorId">The sensor identifier.</param>
        public RedFlag(int id, decimal maximumRange, int locationId, int itemId, decimal minimumRange, bool isDeleted,
			DateTime lastModifiedTime, string ecolabAccountNumber, int categoryId, int? formulaId, int? productId,
                        int? meterId, int? sensorId)
		{
			this.Id = id;
			this.MaximumRange = maximumRange;
			this.LocationId = locationId;
			this.ItemId = itemId;
			this.MinimumRange = minimumRange;
			this.IsDelete = isDeleted;
			this.LastModifiedTimestamp = lastModifiedTime;
			this.EcolabAccountNumber = ecolabAccountNumber;
            this.CategoryId = categoryId;
            this.FormulaId = formulaId;
            this.ProductId = productId;
            this.MeterId = meterId;
            this.SensorId = sensorId;
		}

        /// <summary>
        ///     default constructor
        /// </summary>
        public RedFlag()
        {
        }

        /// <summary>
        ///     Gets or sets the ItemId.
        /// </summary>
        /// <value>The Parameter Item Id. </value>
        public int ItemId { get; set; }

        /// <summary>
        ///     Gets or sets the ItemName.
        /// </summary>
        /// <value>The Parameter Item Name. </value>
        public string ItemName { get; set; }

        /// <summary>
        ///     Gets or sets the UOM.
        /// </summary>
        /// <value>The Parameter UOM.</value>
        public string Uom { get; set; }

        /// <summary>
        ///     Gets or sets the MaximumRange.
        /// </summary>
        /// <value>The Parameter Maximum Range. </value>
        public decimal MaximumRange { get; set; }

        /// <summary>
        ///     Gets or sets the MinimumRange.
        /// </summary>
        /// <value>The Parameter Minimum Range </value>
        public decimal MinimumRange { get; set; }

        /// <summary>
        ///     Gets or sets the LocationId.
        /// </summary>
        /// <value>The Parameter Location Id. </value>
        public int LocationId { get; set; }

        /// <summary>
        ///     Gets or sets the Location.
        /// </summary>
        /// <value>The Parameter Location Name. </value>
        public string LocationName { get; set; }

        /// <summary>
        ///     Gets or sets the MachineIDs.
        /// </summary>
        /// <value>The Parameter Machine Id. </value>
        public string MachineIDs { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName.
        /// </summary>
        /// <value>The Parameter MachineName. </value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets the IsSelected.
        /// </summary>
        /// <value>The Parameter Is Selected. </value>
        public bool IsSelected { get; set; }

        /// <summary>
        ///     Gets or sets the MachineID.
        /// </summary>
        /// <value>The Parameter Machine Id. </value>
        public int? MachineId { get; set; }

        /// <summary>
        ///     Gets or sets IsDirty
        /// </summary>
        /// <value>The Parameter IsDirty</value>
        public bool IsDirty { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

		/// <summary>
		///     Gets or sets the Red Flag Mapping Data
		/// </summary>
		/// <value>Red Flag Mapping Data</value>
	    public List<RedFlagMappingData> RedFlagMappingData { get; set; }

        /// <summary>
        ///     Gets or sets RedFlag Category Id
        /// </summary>
        /// <value> Red Flag Category Id </value>
        public int CategoryId { get; set; }

        /// <summary>
        ///     Gets or sets FormulaCategoryId
        /// </summary>
        /// <value> FormulaCategoryId </value>
        public int FormulaCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets FormulaId
        /// </summary>
        /// <value> FormulaId </value>
        public int? FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets FormulaName
        /// </summary>
        /// <value> FormulaName </value>
        public string FormulaName { get; set; }
        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        /// <value> ProductId </value>
        public int? ProductId { get; set; }

        /// <summary>
        ///     Gets or sets ProductName
        /// </summary>
        /// <value> ProductName </value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets MeterId
        /// </summary>
        /// <value> MeterId </value>
        public int? MeterId { get; set; }

        /// <summary>
        ///     Gets or sets MeterName
        /// </summary>
        /// <value> MeterName </value>
        public string MeterName { get; set; }

        /// <summary>
        ///     Gets or sets SensorId
        /// </summary>
        /// <value> SensorId </value>
        public int? SensorId { get; set; }

    }
}