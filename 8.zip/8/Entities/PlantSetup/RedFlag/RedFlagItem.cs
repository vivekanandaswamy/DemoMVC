﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagItem.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlagItem class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup.RedFlag
{
    /// <summary>
    ///     entity class for RedFlagItem
    /// </summary>
    public class RedFlagItem
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="itemId"> Parameter item id</param>
        /// <param name="itemName">item name</param>
        /// <param name="uom">uom parameter</param>
        public RedFlagItem(int itemId, string itemName, string uom)
        {
            this.ItemId = itemId;
            this.ItemName = itemName;
            this.Uom = uom;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public RedFlagItem()
        {
        }

        /// <summary>
        ///     Gets or sets the ItemId.
        /// </summary>
        /// <value> Parameter Item Id. </value>
        public int ItemId { get; set; }

        /// <summary>
        ///     Gets or sets the ItemName.
        /// </summary>
        /// <value> Parameter Item Name. </value>
        public string ItemName { get; set; }

        /// <summary>
        ///     Gets or sets the UOM.
        /// </summary>
        /// <value> Parameter UOM. </value>
        public string Uom { get; set; }
    }
}