﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagCategory.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlag class </summary>
// -----------------------------------------------------------------------
namespace Entities.PlantSetup.RedFlag
{
    /// <summary>
    ///     Class for RedFlagCategory
    /// </summary>
    public class RedFlagCategory : BaseEntity
    {
        public RedFlagCategory(int RedFlagCategoryId, string Name)
        {
            this.RedFlagCategoryId = RedFlagCategoryId;
            this.Name = Name;
        }

        public RedFlagCategory()
        {
            
        }
        /// <summary>
        ///     Gets or sets the RedFlagCategoryId
        /// </summary>
        public int RedFlagCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        public string Name { get; set; }
    }
}
