﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityDimensionTypes.cs" company="Ecolab">
// This class intializes the plant utility dimension values.
// </copyright>
// <summary>The plant utility dimension values.</summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Class for entities and Constructor for plant dimension types.
    /// </summary>
    public class PlantUtilityDimensionTypes
    {
        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtilityDimensionTypes" /> class.
        /// </summary>
        public PlantUtilityDimensionTypes()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtilityDimensionTypes" /> class.
        /// </summary>
        /// <param name="price">Gets the price dimension value.</param>
        /// <param name="electricPrice">Gets the electric price unit value.</param>
        /// <param name="gasPrice">Gets the gasPrice unit value.</param>
        /// <param name="temperature">Gets the temperature unit value.</param>
        /// <param name="energyContent">Gets the energy content unit value.</param>
        public PlantUtilityDimensionTypes(string price, string electricPrice, string gasPrice, string temperature, string energyContent)
        {
            this.Price = price;
            this.ElectricPrice = electricPrice;
            this.GasPrice = gasPrice;
            this.Temperature = temperature;
            this.EnergyContent = energyContent;
        }

        #endregion

        #region Properties

        /// <summary>
        ///     Gets or sets the Unit.
        /// </summary>
        /// <value> The Parameter Unit.</value>
        public string Price { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit.
        /// </summary>
        /// <value> The Parameter  SubUnit.</value>
        public string ElectricPrice { get; set; }

        /// <summary>
        ///     Gets or sets the OrderID.
        /// </summary>
        /// <value> The Parameter  OrderID.</value>
        public string GasPrice { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystemId.
        /// </summary>
        /// <value> The Parameter  Unit System Id.</value>
        public string Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystemId.
        /// </summary>
        /// <value> The Parameter  Unit System Id.</value>
        public string EnergyContent { get; set; }

        #endregion
    }
}