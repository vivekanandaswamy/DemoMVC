﻿// -----------------------------------------------------------------------
// <copyright file="SensorLocationType.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorLocationType class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Entity class for SensorLocationType
    /// </summary>
    public class SensorLocationType
    {
        #region "Constructor"

        /// <summary>
        ///     Paremeterized constructor
        /// </summary>
        /// <param name="sensorTypeLocId">The Parameter Sensor Type Loc Id</param>
        /// <param name="description">The Parameter Description</param>
        public SensorLocationType(int sensorTypeLocId, string description)
        {
            this.SensorTypeLocId = sensorTypeLocId;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public SensorLocationType()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the SensorTypeId.
        /// </summary>
        /// <value> Sensor Type Id.</value>
        public int SensorTypeLocId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor Type Name.</value>
        public string Description { get; set; }

        #endregion
    }
}