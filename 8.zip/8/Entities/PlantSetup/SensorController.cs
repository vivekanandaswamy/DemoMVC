﻿// -----------------------------------------------------------------------
// <copyright file="SensorController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorController class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Entity class for SensorController
    /// </summary>
    public class SensorController
    {
        #region "Constructor"

        /// <summary>
        ///     Paremeterized constructor
        /// </summary>
        /// <param name="id">The Parameter Id</param>
        /// <param name="description">The Parameter Description</param>
        public SensorController(int id, string description)
        {
            this.Id = id;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public SensorController()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Sensor controller Id.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor controller Name.</value>
        public string Description { get; set; }

        #endregion
    }
}