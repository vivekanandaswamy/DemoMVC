﻿// -----------------------------------------------------------------------
// <copyright file="DeviceModel.cs" company="Ecolab">
// Copyright © Ecolab .
// </copyright>
// <summary>The Device Model </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.PlantSetup
{
    /// <summary>
    ///     entity for DeviceModel
    /// </summary>
    public class DeviceModel
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor.
        /// </summary>
        /// <param name="deviceModelId"> Device Model Id. </param>
        /// <param name="description"> Device model name. </param>
        public DeviceModel(int deviceModelId, string description)
        {
            this.DeviceModelId = deviceModelId;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor.
        /// </summary>
        public DeviceModel()
        {
        }

        public DeviceModel(short deviceTypeId, string description, string regionCode, bool isDeleted, int myServiceWtrEnrgDvcId, DateTime myServiceLastSynchTime)
        {
            DeviceTypeId = deviceTypeId;
            Description = description;
            RegionCode = regionCode;
            IsDeleted = isDeleted;
            MyServiceWtrEnrgDvcId = myServiceWtrEnrgDvcId;
            MyServiceLastSynchTime = myServiceLastSynchTime;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the DeviceModelId.
        /// </summary>
        /// <value> Device model id.</value>
        public int DeviceModelId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceType.
        /// </summary>
        /// <value> Device model name.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceTypeId.
        /// </summary>
        /// <value> Device type id.</value>
        public Int16 DeviceTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the RegionCode.
        /// </summary>
        /// <value> Region Code.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceWtrEnrgDvcId.
        /// </summary>
        /// <value> MyServiceWtrEnrgDvcId.</value>
        public int MyServiceWtrEnrgDvcId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}