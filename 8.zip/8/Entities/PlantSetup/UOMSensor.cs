﻿// -----------------------------------------------------------------------
// <copyright file="UOMSensor.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The UOMSensor class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Entity class for UOMSensor
    /// </summary>
    public class UomSensor
    {
        #region "Constructor"

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="unit"> Parameter unit</param>
        /// <param name="subunit"> Parameter sub Unit </param>
        public UomSensor(string unit, string subunit)
        {
            this.Unit = unit;
            this.Subunit = subunit;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public UomSensor()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Unit.
        /// </summary>
        /// <value> Parameter Unit.</value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit.
        /// </summary>
        /// <value> Parameter SubUnit.</value>
        public string Subunit { get; set; }

        #endregion
    }
}