﻿// -----------------------------------------------------------------------
// <copyright file="ModuleReadData.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Module Read Data </summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.PlantSetup.ModuleRead
{
	/// <summary>
	/// Entity class for ModuleRead
	/// </summary>
	public class ModuleReadData
	{
        #region "Constructor"

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="moduleId">The redflag identifier.</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="shiftId">The shift identifier.</param>
        /// <param name="moduleTypeId">The module type identifier.</param>
        /// <param name="Reading">The readin valuet.</param>
        /// <param name="usage">The usage of Module Read.</param>
        /// <param name="partitionOn">The partition on.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        public ModuleReadData(int moduleId, int plantId, int shiftId, int moduleTypeId, decimal Reading,  decimal usage, DateTime partitionOn, DateTime lastSyncTime)
        {
            this.ModuleId = moduleId;
            this.PlantId = plantId;
            this.ShiftId = shiftId;
            this.ModuleTypeId = moduleTypeId;
            this.Reading = Reading;
            this.Usage = usage;
            this.PartitionOn = partitionOn;
            this.LastSyncTime = lastSyncTime;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ModuleReadData()
        {
        }

		#endregion

		#region "Properties"

		/// <summary>
		/// Gets or sets the module identifier.
		/// </summary>
		/// <value>
		/// The module identifier.
		/// </value>
		public int ModuleId { get; set; }

		/// <summary>
		/// Gets or sets the plant identifier.
		/// </summary>
		/// <value>
		/// The plant identifier.
		/// </value>
		public int PlantId { get; set; }

		/// <summary>
		/// Gets or sets the shift identifier.
		/// </summary>
		/// <value>
		/// The shift identifier.
		/// </value>
		public int ShiftId { get; set; }

		/// <summary>
		/// Gets or sets the module type identifier.
		/// </summary>
		/// <value>
		/// The module type identifier.
		/// </value>
		public int ModuleTypeId { get; set; }

		/// <summary>
		/// Gets or sets the reading.
		/// </summary>
		/// <value>
		/// The reading.
		/// </value>
		public decimal Reading { get; set; }

		/// <summary>
		/// Gets or sets the usage.
		/// </summary>
		/// <value>
		/// The usage.
		/// </value>
		public decimal Usage { get; set; }

		/// <summary>
		/// Gets or sets the partition on.
		/// </summary>
		/// <value>
		/// The partition on.
		/// </value>
		public DateTime PartitionOn { get; set; }

		/// <summary>
		/// Gets or sets the last synchronize time.
		/// </summary>
		/// <value>
		/// The last synchronize time.
		/// </value>
		public DateTime LastSyncTime { get; set; }

		#endregion
	}
}
