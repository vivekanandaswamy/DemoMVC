﻿// -----------------------------------------------------------------------
// <copyright file="PlantutilityGasoilTypes.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The XAxis </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    public class PlantutilityGasoilTypes
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtility" /> class.
        /// </summary>
        /// <param name="gasoilTypeId">Gets the value of the gas/oil type identity id.</param>
        /// <param name="gasoilTypeName">Gets the value of the gas/oil type name.</param>
        /// <param name="defaultValue">Gets the value of the gas/oil type default value.</param>
        /// <param name="uomCode">Gets the value of the gas/oil type unit of measure code.</param>
        /// <param name="uomDescription">Gets the value of the gas/oil type unit of measure description for the code value.</param>
        public PlantutilityGasoilTypes(int gasoilTypeId, string gasoilTypeName, decimal defaultValue, string uomCode, string uomDescription)
        {
            this.GasoilTypeId = gasoilTypeId;
            this.GasoilTypeName = gasoilTypeName;
            this.DefaultValue = defaultValue;
            this.UomCode = uomCode;
            this.UomDescription = uomDescription;
        }

        public PlantutilityGasoilTypes(string name, decimal defaultValue, Int16 uomId, string uomCode, string uomDescription, string regionCode, bool isDeleted, int myServiceUtilId, DateTime myServiceLastSynchTime, string spSp, string nrNR, string nlBE)
        {
            this.GasoilTypeName = name;
            this.DefaultValue = defaultValue;
            this.UOMId = uomId;
            this.UomCode = uomCode;
            this.UomDescription = uomDescription;
            this.RegionCode = regionCode;
            this.IsDeleted = isDeleted;
            this.MyServiceUtilId = myServiceUtilId;
            this.MyServiceLastSynchTime = myServiceLastSynchTime;
            sp_SP = spSp;
            nr_NR = nrNR;
            nl_BE = nlBE;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtility" /> class.
        /// </summary>
        public PlantutilityGasoilTypes()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets WaterTypeId
        /// </summary>
        /// <value>Water Type Id.</value>
        public int GasoilTypeId { get; set; }

        /// <summary>
        ///     Gets or sets WaterTypeName
        /// </summary>
        /// <value>Water Type Name.</value>
        public string GasoilTypeName { get; set; }

        /// <summary>
        ///     Gets or sets DefaultValue
        /// </summary>
        /// <value>Default Value of gas/oil type.</value>
        public decimal DefaultValue { get; set; }

        /// <summary>
        ///     Gets or sets UOMCode
        /// </summary>
        /// <value>Unit of measure code for the gas/oil type.</value>
        public string UomCode { get; set; }

        /// <summary>
        ///     Gets or sets UOMDescription
        /// </summary>
        /// <value>Unit of measure description for the gas/oil type.</value>
        public string UomDescription { get; set; }

        /// <summary>
        /// Gets or sets The Region Id.
        /// </summary>
        /// <value>Region Id for myService</value>
        public Int16 RegionId { get; set; }

        /// <summary>
        /// Gets or sets the IsDeleted.
        /// </summary>
        /// <value>The IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets MyServiceUtilId
        /// </summary>
        /// <value>MyServiceUtilId</value>
        public int MyServiceUtilId { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        /// Gets or sets MyServiceLastSynchTime
        /// </summary>
        /// <value>MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        /// <summary>
        /// Gets or sets Region Code
        /// </summary>
        /// <value>RegionCode</value>
        public string RegionCode { get; set; }

        /// <summary>
        /// Gets or sets UOM ID.
        /// </summary>
        /// <value>The Uom Id.</value>
        public Int16 UOMId { get; set; }

        /// <summary>
        /// Gets or sets Usagekey
        /// </summary>
        /// <value>UsageKey</value>
        public string UsageKey { get; set; }

        /// <summary>
        /// Gets or sets Units
        /// </summary>
        /// <value>Units</value>
        public string Units { get; set; }
        #endregion
    }
}