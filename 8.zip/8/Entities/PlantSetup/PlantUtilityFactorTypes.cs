﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityFactorTypes.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Utility Factor Types model </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    using System;

    /// <summary>
    ///     This class is for entities of factor types for plant utility.
    /// </summary>
    public class PlantUtilityFactorTypes
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtilityFactorTypes" /> class.
        /// </summary>
        public PlantUtilityFactorTypes()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PlantUtilityFactorTypes" /> class.
        /// </summary>
        /// <param name="utilitiyId">Identity value of utility.</param>
        /// <param name="utilityType">The type of the plant utility.</param>
        /// <param name="factorType">Value of factor type.</param>
        /// <param name="temparature">Gets the value of the temperature.</param>
        /// <param name="energyContent">Value of the energy content.</param>
        /// <param name="price">Value of the price.</param>
        /// <param name="location">Value for which location the utility belongs.</param>
        /// <param name="boilerSteam">Value of boiler steam.</param>
        /// <param name="boilerType">Value of the boiler type.</param>
        /// <param name="boilerTypeName">Value of the boiler type name</param>
        /// <param name="steamPercentage">Value of the steam percentage.</param>
        /// <param name="boilerPercentage">Value of the boiler percentage.</param>
        /// <param name="stackPercentage">Value of the stack percentage.</param>
        /// <param name="rewashFactor">Value of the rewash factor.</param>
        /// <param name="freeType">Value of the free type number.</param>
        /// <param name="energyContentUnit">Value of the energy content unit.</param>
        /// <param name="energyPriceUnit">Value of the energy price unit.</param>
        /// <param name="evaporationFactor">Value of the evaporation factor.</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        /// <param name="lastsyncTime">lastsyncTime</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        public PlantUtilityFactorTypes(
                                        Int16 utilitiyId,
                                        int utilityType,
                                        string factorType,
                                        decimal temparature,
                                        decimal energyContent,
                                        decimal price,
                                        string location,
                                        bool boilerSteam,
                                        int boilerType,
                                        string boilerTypeName,
                                        decimal steamPercentage,
                                        decimal boilerPercentage,
                                        decimal stackPercentage,
                                        decimal rewashFactor,
                                        int freeType,
                                        string energyContentUnit,
                                        string energyPriceUnit,
                                        decimal evaporationFactor,
                                        DateTime lastModifiedTime,
                                        DateTime lastsyncTime,
                                        string ecolabAccountNumber

                                        )
        {
            UtilityId = utilitiyId;
            UtilityType = utilityType;
            FactorType = factorType;
            Temperature = temparature;
            EnergyContent = energyContent;
            Price = price;
            Location = location;
            BoilerSteam = boilerSteam;
            BoilerType = boilerType;
            BoilerTypeName = boilerTypeName;
            SteamPercentage = steamPercentage;
            BoilerPercentage = boilerPercentage;
            StackPercentage = stackPercentage;
            RewashFactor = rewashFactor;
            FreeType = freeType;
            EnergyContentUnit = energyContentUnit;
            EnergyPriceUnit = energyPriceUnit;
            EvaporationFactor = evaporationFactor;
            LastModifiedTime = lastModifiedTime;
            LastSyncTime = lastsyncTime;
            EcolabAccountNumber = ecolabAccountNumber;
            //IsFactorUsed = isFactorUsed;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PlantUtilityFactorTypes" /> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="waterFactorTypeId">The water factor type identifier.</param>
        /// <param name="factorType">Type of the factor.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="price">The price.</param>
        /// <param name="gasoilTypeId">The gas oil type identifier.</param>
        /// <param name="gasoilType">Type of the gas oil.</param>
        /// <param name="energyContent">Content of the energy.</param>
        /// <param name="energyContentUnit">The energy content unit.</param>
        /// <param name="energyPrice">The energy price.</param>
        /// <param name="energyPriceUnit">The energy price unit.</param>
        /// <param name="electricPrice">The electric price.</param>
        /// <param name="boilerSteam">if set to <c>true</c> [boiler steam].</param>
        /// <param name="boilerType">Type of the boiler.</param>
        /// <param name="steam">The steam.</param>
        /// <param name="boiler">The boiler.</param>
        /// <param name="stack">The stack.</param>
        /// <param name="rewashFactor">The rewash factor.</param>
        /// <param name="evaporationFactor">The evaporation factor.</param>
        /// <param name="freeType">Type of the free.</param>
        /// <param name="isFactorUsed">The is factor used.</param>
        /// <param name="lasModifiedTime">The las modified time.</param>
        /// <param name="myServiceWtrFctrId">My service WTR FCTR identifier.</param>
        /// <param name="myServiceLastSyncTime">My service last synchronize time.</param>
        public PlantUtilityFactorTypes(string ecolabAccountNumber, int waterFactorTypeId, string factorType, decimal temperature, decimal price, int gasoilTypeId, string gasoilType, decimal energyContent, string energyContentUnit, decimal energyPrice, string energyPriceUnit, decimal electricPrice, bool boilerSteam, int boilerType, decimal steam, decimal boiler, decimal stack, decimal rewashFactor, decimal evaporationFactor, string freeType, string isFactorUsed, DateTime lasModifiedTime, int myServiceWtrFctrId, DateTime? myServiceLastSyncTime)
        {
            EcolabAccountNumber = ecolabAccountNumber;
            WaterFactorTypeId = waterFactorTypeId;
            FactorType = factorType;
            Temperature = temperature;
            Price = price;
            GasoilTypeId = gasoilTypeId;
            GasoilType = gasoilType;
            EnergyContent = energyContent;
            EnergyContentUnit = energyContentUnit;
            EnergyPrice = energyPrice;
            EnergyPriceUnit = energyPriceUnit;
            ElectricPrice = electricPrice;
            BoilerSteam = boilerSteam;
            BoilerType = boilerType;
            SteamPercentage = steam;
            BoilerPercentage = boiler;
            StackPercentage = stack;
            RewashFactor = rewashFactor;
            EvaporationFactor = evaporationFactor;
            UtilityWaterType = freeType;
            UtilityType = 1;
            IsFactorUsed = isFactorUsed;
            LastModifiedTime = lasModifiedTime;
            MyServiceWatrFctrId = myServiceWtrFctrId;
            MyServiceLastSyncTime = myServiceLastSyncTime;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PlantUtilityFactorTypes" /> class.
        /// </summary>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="waterFactorTypeId">The water factor type identifier.</param>
        /// <param name="factorType">Type of the factor.</param>
        /// <param name="temperature">The temperature.</param>
        /// <param name="price">The price.</param>
        /// <param name="gasoilTypeId">The gas oil type identifier.</param>
        /// <param name="gasoilType">Type of the gas oil.</param>
        /// <param name="energyContent">Content of the energy.</param>
        /// <param name="energyContentUnit">The energy content unit.</param>
        /// <param name="energyPrice">The energy price.</param>
        /// <param name="energyPriceUnit">The energy price unit.</param>
        /// <param name="electricPrice">The electric price.</param>
        /// <param name="boilerSteam">if set to <c>true</c> [boiler steam].</param>
        /// <param name="boilerType">Type of the boiler.</param>
        /// <param name="steam">The steam.</param>
        /// <param name="boiler">The boiler.</param>
        /// <param name="stack">The stack.</param>
        /// <param name="rewashFactor">The rewash factor.</param>
        /// <param name="evaporationFactor">The evaporation factor.</param>
        /// <param name="freeType">Type of the free.</param>
        /// <param name="isFactorUsed">The is factor used.</param>
        /// <param name="lasModifiedTime">The las modified time.</param>
        /// <param name="myServiceWtrFctrId">My service WTR FCTR identifier.</param>
        /// <param name="myServiceLastSyncTime">My service last synchronize time.</param>
        /// <param name="washerUtilityDetailsId">The washer utility details identifier.</param>
        public PlantUtilityFactorTypes(string ecolabAccountNumber, int waterFactorTypeId, string factorType, decimal temperature, decimal price, int gasoilTypeId, string gasoilType, decimal energyContent, string energyContentUnit, decimal energyPrice, string energyPriceUnit, decimal electricPrice, bool boilerSteam, int boilerType, decimal steam, decimal boiler, decimal stack, decimal rewashFactor, decimal evaporationFactor, string freeType, string isFactorUsed, DateTime lasModifiedTime, int myServiceWtrFctrId, DateTime? myServiceLastSyncTime, int washerUtilityDetailsId)
        {
            EcolabAccountNumber = ecolabAccountNumber;
            WaterFactorTypeId = waterFactorTypeId;
            FactorType = factorType;
            Temperature = temperature;
            Price = price;
            GasoilTypeId = gasoilTypeId;
            GasoilType = gasoilType;
            EnergyContent = energyContent;
            EnergyContentUnit = energyContentUnit;
            EnergyPrice = energyPrice;
            EnergyPriceUnit = energyPriceUnit;
            ElectricPrice = electricPrice;
            BoilerSteam = boilerSteam;
            BoilerType = boilerType;
            SteamPercentage = steam;
            BoilerPercentage = boiler;
            StackPercentage = stack;
            RewashFactor = rewashFactor;
            EvaporationFactor = evaporationFactor;
            UtilityWaterType = freeType;
            UtilityType = 1;
            IsFactorUsed = isFactorUsed;
            LastModifiedTime = lasModifiedTime;
            MyServiceWatrFctrId = myServiceWtrFctrId;
            MyServiceLastSyncTime = myServiceLastSyncTime;
            this.WaterUtilityDetailsID = washerUtilityDetailsId;
        }

        #region "Properties"

        /// <summary>
        ///     Gets or sets the UtilityType.
        /// </summary>
        /// <value> The Utility Type.</value>
        public int UtilityId { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityType.
        /// </summary>
        /// <value> The Utility Type.</value>
        public int UtilityType { get; set; }

        /// <summary>
        ///     Gets or sets the FactorType.
        /// </summary>
        /// <value> The Factor Type.</value>
        public string FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature.
        /// </summary>
        /// <value> The Temperature.</value>
        public decimal Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the Energy.
        /// </summary>
        /// <value> The Energy.</value>
        public decimal EnergyContent { get; set; }

        /// <summary>
        ///     Gets or sets the Price.
        /// </summary>
        /// <value> The Price.</value>
        public decimal Price { get; set; }

        /// <summary>
        ///     Gets or sets the Location.
        /// </summary>
        /// <value> The Location.</value>
        public string Location { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether the boiler steam is required or not.
        /// </summary>
        /// <value> The Boiler Steam.</value>
        public bool BoilerSteam { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public int BoilerType { get; set; }

        /// <summary>
        ///     Gets or sets the Steam.
        /// </summary>
        /// <value> The Steam percentage.</value>
        public decimal SteamPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Boiler.
        /// </summary>
        /// <value> The Boiler percentage.</value>
        public decimal BoilerPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Stack.
        /// </summary>
        /// <value> The Stack percentage.</value>
        public decimal StackPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the RewashFactor.
        /// </summary>
        /// <value> The Rewash Factor percentage.</value>
        public decimal RewashFactor { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public int FreeType { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public string Subunit { get; set; }

        /// <summary>
        ///     Gets or sets the energy content unit for plant utility.
        /// </summary>
        /// <value> The Energy Content Unit.</value>
        public string EnergyContentUnit { get; set; }

        /// <summary>
        ///     Gets or sets the energy price unit for plant utility.
        /// </summary>
        /// <value> The Energy Price Unit.</value>
        public string EnergyPriceUnit { get; set; }

        /// <summary>
        ///     Gets or sets the evaporation factor for plant utility.
        /// </summary>
        /// <value> The evaporation factor.</value>
        public decimal EvaporationFactor { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerTypeName.
        /// </summary>
        /// <value>Boiler Type Name.</value>
        public string BoilerTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber
        /// </summary>
        /// <value>EcolabAccountNumber.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp Dryer Group
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets the IsFactorUsed
        /// </summary>
        /// <value>IsFactorUsed.</value>
        public string IsFactorUsed { get; set; }

        /// <summary>
        /// Gets or sets the WaterFactorTypeId
        /// </summary>
        public int WaterFactorTypeId { get; set; }

        /// <summary>
        /// Gets or sets the GasOilTypeId.
        /// </summary>
        public int GasoilTypeId { get; set; }

        /// <summary>
        /// Gets or sets the GasOilType.
        /// </summary>
        public string GasoilType { get; set; }

        /// <summary>
        /// Gets or sets the EnergyPrice.
        /// </summary>
        public decimal EnergyPrice { get; set; }

        /// <summary>
        /// Gets or sets the ElectricPrice.
        /// </summary>
        public decimal ElectricPrice { get; set; }

        /// <summary>
        /// Gets or sets the UtilityWaterType.
        /// </summary>
        public string UtilityWaterType { get; set; }

        /// <summary>
        /// Gets or sets the UtilityWaterType.
        /// </summary>
        public int RegionId { get; set; }

        /// <summary>
        /// Gets or sets MyServiceWatrFctrId
        /// </summary>
        public int MyServiceWatrFctrId { get; set; }

        /// <summary>
        /// Gets or sets MyServiceLastSyncTime
        /// </summary>
        public DateTime? MyServiceLastSyncTime { get; set; }

        /// <summary>
        /// Gets or Sets the Water Utility Details Id
        /// </summary>
        /// <value>The Water Utility Details Id</value>
        public int WaterUtilityDetailsID { get; set; }
        #endregion

    }
}