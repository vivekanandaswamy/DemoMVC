﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityWaterTypeMaster.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantUtilityWaterTypeMaster </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.PlantSetup
{
    public class PlantUtilityWaterTypeMaster
    {
        #region "Constructor"

        /// <summary>
        ///     constructor CurrencyMaster
        /// </summary>
        /// <param name="waterTypeId">The water type Id.</param>
        /// <param name="waterTypeName">The water type name.</param>
        public PlantUtilityWaterTypeMaster(int waterTypeId, string waterTypeName)
        {
            this.WaterTypeId = waterTypeId;
            this.WaterTypeName = waterTypeName;
        }

        /// <summary>
        ///     constructor CurrencyMaster
        /// </summary>
        /// <param name="waterTypeId">The water type Id.</param>
        /// <param name="waterTypeName">The water type name.</param>
        public PlantUtilityWaterTypeMaster(int waterTypeId, string waterTypeName, int regionId, string utilityTypeCode)
        {
            this.WaterTypeId = waterTypeId;
            this.WaterTypeName = waterTypeName;
            this.RegionCode = regionId.ToString();
            this.MyServiceUtilTypeCode = utilityTypeCode;
        }

        /// <summary>
        ///     default constructor CurrencyMaster
        /// </summary>
        public PlantUtilityWaterTypeMaster()
        {
        }

        public PlantUtilityWaterTypeMaster(string waterTypeName, string regionCode, bool isDeleted, Int32 myServiceUtilId, DateTime myServiceLastSynchTime, string myServiceUtilTypeCode, string spSp, string nrNR, string nlBE)
        {
            WaterTypeName = waterTypeName;
            RegionCode = regionCode;
            IsDeleted = isDeleted;
            MyServiceUtilId = myServiceUtilId;
            MyServiceLastSynchTime = myServiceLastSynchTime;
            MyServiceUtilTypeCode = myServiceUtilTypeCode;
            sp_SP = spSp;
            nr_NR = nrNR;
            nl_BE = nlBE;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets WaterTypeId
        /// </summary>
        /// <value>Water Type Id.</value>
        public int WaterTypeId { get; set; }

        /// <summary>
        ///     Gets or sets WaterTypeName
        /// </summary>
        /// <value>Water Type Name.</value>
        public string WaterTypeName { get; set; }

        /// <summary>
        ///     Gets or sets RegionCode
        /// </summary>
        /// <value>Region Code.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceUtilTypeCode
        /// </summary>
        /// <value>MyService UtilTypeCode.</value>
        public string MyServiceUtilTypeCode { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value>Is Deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceUtilId
        /// </summary>
        /// <value>MyServiceUtilId.</value>
        public Int32 MyServiceUtilId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}