﻿// -----------------------------------------------------------------------
// <copyright file="SensorType.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SensorType class </summary>
// -----------------------------------------------------------------------

namespace Entities.PlantSetup
{
    /// <summary>
    ///     Entity class for SensorType
    /// </summary>
    public class SensorType
    {
        #region "Constructor"

        /// <summary>
        ///     Paremeterized constructor
        /// </summary>
        /// <param name="sensorTypeId">The Parameter Sensor Type Id</param>
        /// <param name="description">The Parameter Description</param>
        public SensorType(int sensorTypeId, string description)
        {
            this.SensorTypeId = sensorTypeId;
            this.Description = description;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public SensorType()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the SensorTypeId.
        /// </summary>
        /// <value> Sensor Type Id.</value>
        public int SensorTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Sensor Type Name.</value>
        public string Description { get; set; }

        #endregion
    }
}