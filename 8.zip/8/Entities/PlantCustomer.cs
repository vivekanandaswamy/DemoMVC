﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomer.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Customer </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    /// <summary>
    ///     class PlantCustomer
    /// </summary>
    public class PlantCustomer
    {
        /// <summary>
        /// constructor PlantCustomer
        /// </summary>
        /// <param name="id">The Parameter id.</param>
        /// <param name="customerId">The PlantCustomer customerId .</param>
        /// <param name="customerName">The PlantCustomer customerName.</param>
        /// <param name="isDeleted">isDeleted indicate whether the PlantCustomer is deleted or not .</param>
        /// <param name="ecolabAccountNumber">The parameter Ecolab Account Number</param>
        /// <param name="lastModifiedTime">The parameter Last Modified Time</param>
        public PlantCustomer(int? id, int customerId, string customerName, bool isDeleted, string ecolabAccountNumber, DateTime lastModifiedTime)
        {
            this.Id = id;
            this.CustomerId = customerId;
            this.CustomerName = customerName;
            this.IsDeleted = isDeleted;
            this.EcoalabAccountNumber = ecolabAccountNumber;
            this.LastModifiedTimestamp = lastModifiedTime;
        }

        #region "properties"

        /// <summary>
        ///     constructor PlantCustomer
        /// </summary>
        public PlantCustomer()
        {
        }

        /// <summary>
        ///     Gets or sets CustomerId
        /// </summary>
        /// <value> Parameter Customer Id.</value>
        public int CustomerId { get; set; }

        /// <summary>
        ///     Gets or sets CustomerName
        /// </summary>
        /// <value> Parameter Customer Name.</value>
        public string CustomerName { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value> Parameter Is Deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets Id
        /// </summary>
        /// <value>the identifier field.</value>
        public int? Id { get; set; }

        /// <summary>
        ///     Gets or sets EcoalabAccountNumber
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp at central
        /// </summary>
        /// <value>LastModifiedTimeStampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        #endregion
    }
}