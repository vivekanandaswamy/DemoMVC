﻿// -----------------------------------------------------------------------
// <copyright file="MachineSetupTunnel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Machine Setup Tunnel object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     class for MachineSetupTunnel
    /// </summary>
    public class MachineSetupTunnel
    {
        /// <summary>
        ///     default constructor MachineSetupTunnel
        /// </summary>
        public MachineSetupTunnel()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="MachineSetupTunnel" /> class.
        /// </summary>
        /// <param name="groupId">The Parameter Group ID</param>
        /// <param name="machineInternalId">The machine Internal Id </param>
        /// <param name="machineName">the Parameter machineName</param>
        /// <param name="numberOfcompartmentals">The number Of compartmentals</param>
        public MachineSetupTunnel(int groupId, int machineInternalId, string machineName, int numberOfcompartmentals, string machineType)
        {
            this.GroupId = groupId;
            this.MachineInternalId = machineInternalId;
            this.MachineName = machineName;
            this.NumberOfcompartmentals = numberOfcompartmentals;
            this.MachineType = machineType;
        }

        /// <summary>
        ///     Gets or sets
        /// </summary>
        /// <value> Parameter GroupId </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets MachineInternalId
        /// </summary>
        /// <value> Parameter MachineInternalId </value>
        public int MachineInternalId { get; set; }

        /// <summary>
        ///     Gets or sets MachineName
        /// </summary>
        /// <value> Parameter MachineName </value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets NumberOfcompartmentals
        /// </summary>
        /// C
        /// <value> Parameter NumberOfcompartmentals </value>
        public int NumberOfcompartmentals { get; set; }

        /// <summary>
        ///     Gets or sets MachineType
        /// </summary>
        /// <value> Parameter Machine Type</value>
        public string MachineType { get; set; }
    }
}