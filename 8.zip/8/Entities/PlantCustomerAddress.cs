﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerAddress.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Customer Address object</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities
{
    /// <summary>
    ///  Class for Myservice plant Address
    /// </summary>
    public class PlantCustomerAddress
    {
        public PlantCustomerAddress()
        {

        }

        public PlantCustomerAddress(string ecolabAccountNumber, string billingAddr1, string billingAddr2, string city, string state, string country, string zip, string shippingAddr1, string shippingAddr2, string shippingcity, string shippingstate, string shippingcountry, string shippingzip, DateTime myServiceBillingAddressLasySynchTime, DateTime myServiceShippingAddressLasySynchTime)
        {
            EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            BillingAddr1 = billingAddr1;
            BillingAddr2 = billingAddr2;
            City = city;
            State = state;
            Country = country;
            Zip = zip;
            ShippingAddr1 = shippingAddr1;
            ShippingAddr2 = shippingAddr2;
            Shippingcity = shippingcity;
            Shippingcountry = shippingcountry;
            Shippingzip = shippingzip;
            MyServiceShippingAddressModDtTm = myServiceShippingAddressLasySynchTime;
            MyServiceBillingAddressModDtTm = myServiceBillingAddressLasySynchTime;
            Shippingstate = shippingstate;
        }

        public string EcolabAccountNumber { get; set; }
        public string BillingAddr1 { get; set; }
        public string BillingAddr2 { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
        public string State { get; set; }
        public string ShippingAddr1 { get; set; }
        public string ShippingAddr2 { get; set; }
        public string Shippingcity { get; set; }
        public string Shippingcountry { get; set; }
        public string Shippingzip { get; set; }
        public string Shippingstate { get; set; }
        public DateTime MyServiceBillingAddressModDtTm { get; set; }
        public DateTime MyServiceShippingAddressModDtTm { get; set; }
    }
}