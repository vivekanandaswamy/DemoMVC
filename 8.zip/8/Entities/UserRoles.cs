﻿// -----------------------------------------------------------------------
// <copyright file="UserRoles.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The UserRoles object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     Class for User Roles
    /// </summary>
    public class UserRoles
    {
        /// <summary>
        ///     Fetches the User Roles based on parameters
        /// </summary>
        /// <param name="roleId">The parameter Role ID</param>
        /// <param name="roleName">The parameter Role name</param>
        /// <param name="code">The parameter Code</param>
        public UserRoles(int roleId, string roleName, string code)
        {
            this.RoleId = roleId;
            this.RoleName = roleName;
            this.Code = code;
        }

        /// <summary>
        ///     Gets or sets the RoleId.
        /// </summary>
        /// <value>
        ///     Parameter RoleId.
        /// </value>
        public int RoleId { get; set; }

        /// <summary>
        ///     Gets or sets the Role name.
        /// </summary>
        /// <value>
        ///     Parameter  RoleName.
        /// </value>
        public string RoleName { get; set; }

        /// <summary>
        ///     Gets or sets the Code.
        /// </summary>
        /// <value>
        ///     Parameter  Code.
        /// </value>
        public string Code { get; set; }
    }
}