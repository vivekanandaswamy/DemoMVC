﻿// -----------------------------------------------------------------------
// <copyright file="ResourceKeyValue.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm Master object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///     Entity class for AlarmMaster
    /// </summary>
    public class ResourceKeyValue : BaseEntity
    {
        /// <summary>
        /// Parametrized Constructor
        /// </summary>
        public ResourceKeyValue(int resourceId, string key)
        {
            this.ResourceId = resourceId;
            this.Key = key;
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ResourceKeyValue()
        {

        }

        /// <summary>
        /// ResourceId
        /// </summary>
        public int ResourceId { get; set; }

        /// <summary>
        /// ResourceKeyValue
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// lstResourceValue
        /// </summary>
        public List<ResourceValues> lstResourceValue { get; set; }

        /// <summary>
        /// lstResourcePageMapping
        /// </summary>
        public List<ResourceKeyPageMapping> lstResourcePageMapping { get; set; }

    }
}
