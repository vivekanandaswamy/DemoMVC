﻿// <copyright file="FormulaSegment.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FormulaSegment object</summary>

namespace Entities
{
    using System;

    /// <summary>
    /// Class FormulaSegment.
    /// </summary>
    public class FormulaSegment
    {
        #region "Constructor"

        /// <summary>
        ///     default constructor EcolabSaturation
        /// </summary>
        public FormulaSegment()
        {
        }
        public FormulaSegment(int formulaSegmentId, string formulaSegmentName)
        {
            this.FormulaSegmentId = formulaSegmentId;
            this.FormulaSegmentName = formulaSegmentName;
        }

        public FormulaSegment(int formulaSegmentId, string formulaSegmentName, DateTime lastModifiedTime, bool isDeleted, DateTime lastSyncTime)
        {
            this.FormulaSegmentId = formulaSegmentId;
            this.FormulaSegmentName = formulaSegmentName;
            this.LastModified = lastModifiedTime;
            this.LastSync = lastSyncTime;
            this.IsDeleted = isDeleted;
        }
        #endregion

        #region "Properties"

        /// <summary>
        /// Gets or sets the formula segment identifier.
        /// </summary>
        /// <value>The formula segment identifier.</value>
        public int FormulaSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the name of the formula segment.
        /// </summary>
        /// <value>The name of the formula segment.</value>
        public string FormulaSegmentName { get; set; }

        /// <summary>
        /// Gets or sets IsDeleted
        /// </summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets LastModified
        /// </summary>
        public DateTime LastModified { get; set; }

        /// <summary>
        /// Gets or sets LastSync
        /// </summary>
        public DateTime? LastSync { get; set; }

        #endregion
    }
}