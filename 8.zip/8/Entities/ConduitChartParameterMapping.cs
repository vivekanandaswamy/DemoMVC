﻿// -----------------------------------------------------------------------
// <copyright file="ConduitChartParameterMapping.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Conduit Chart Parameter Mapping object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     class for ConduitChartParameterMapping
    /// </summary>
    public class ConduitChartParameterMapping
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConduitChartParameterMapping" /> class.
        /// </summary>
        /// <param name="parameterId">The parameterID .</param>
        /// <param name="parameterName">The parameterName .</param>
        /// <param name="groupId">The minimum Value</param>
        /// <param name="mappedCompartment">The mapped compartment</param>
        /// <param name="washerId">The washer identifier.</param>
        public ConduitChartParameterMapping(int parameterId, string parameterName, int groupId, int mappedCompartment, int washerId)
        {
            this.ParameterId = parameterId;
            this.ParameterName = parameterName;
            this.GroupId = groupId;
            this.MappedCompartment = mappedCompartment;
            this.WasherId = washerId;
        }

        /// <summary>
        ///     default constructor LanguageMaster
        /// </summary>
        public ConduitChartParameterMapping()
        {
        }

        /// <summary>
        ///     Gets or sets ParameterID
        /// </summary>
        /// <value> ParameterID .</value>
        public int ParameterId { get; set; }

        /// <summary>
        ///     Gets or sets ParameterName
        /// </summary>
        /// <value>Parameter Name.</value>
        public string ParameterName { get; set; }

        /// <summary>
        ///     Gets or sets MinValue
        /// </summary>
        /// <value> Min Value. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets Mapped Compartment
        /// </summary>
        /// <value>Mapped Comaprtment</value>
        public int MappedCompartment { get; set; }

        /// <summary>
        ///     Gets or sets Washer Id
        /// </summary>
        /// <value> Washer Id. </value>
        public int WasherId { get; set; }
    }
}