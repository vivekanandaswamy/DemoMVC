﻿// <copyright file="DrainDestination.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DrainDestination object</summary>

namespace Entities
{
    using System;

    /// <summary>
    ///     class DrainDestination
    /// </summary>
    public class DrainDestination
    {
        #region "Constructor"

        /// <summary>
        /// Default Constructor
        /// </summary>
        public DrainDestination()
        {

        }

        /// <summary>
        /// constructor DrainDestination
        /// </summary>
        /// <param name="myServiceDrainTypeId">My service drain type identifier.</param>
        /// <param name="drainDestinationName">Name of the drain destination.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="sp">The sp sp.</param>
        /// <param name="nr">The nr nr.</param>
        /// <param name="nlbe">The nl be.</param>
        public DrainDestination(Int16 myServiceDrainTypeId, string drainDestinationName, bool isDeleted, DateTime myServiceLastSynchTime, string sp, string nr, string nlbe)
        {
            MyServiceDrainTypeId = myServiceDrainTypeId;
            DrainDestinationName = drainDestinationName;
            IsDeleted = isDeleted;
            MyServiceLastSynchTime = myServiceLastSynchTime;
            sp_SP = sp;
            nr_NR = nr;
            nl_BE = nlbe;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets DrainDestinationId
        /// </summary>
        /// <value>Drain Destination Id .</value>
        public int DrainDestinationId { get; set; }

        /// <summary>
        ///     Gets or sets Drain Destination Name
        /// </summary>
        /// <value>Drain Destination Name.</value>
        public string DrainDestinationName { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value>IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceDrainTypeId
        /// </summary>
        /// <value>MyServiceDrainTypeId.</value>
        public Int16 MyServiceDrainTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}
