﻿// -----------------------------------------------------------------------
// <copyright file="ShiftSummary.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShiftSummary object</summary>
// -----------------------------------------------------------------------

namespace Entities.Default
{
    using System;

    /// <summary>
    ///     ShiftSummary class
    /// </summary>
    public class ShiftSummary
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="totalLoad">TotalLoad field</param>
        /// <param name="efficiency">LostLoad field</param>
        /// <param name="lostLoad">efficiency field</param>
        /// <param name="shiftName">shiftName field</param>
        public ShiftSummary(Double totalLoad, Double efficiency, Double lostLoad, string shiftName)
        {
            this.Efficiency = efficiency;
            this.LostLoad =lostLoad;
            this.TotalLoad = totalLoad;
            this.ShiftName = shiftName;
        }

        /// <summary>
        ///     Gets or sets the TotalLoad.
        /// </summary>
        /// <value>The TotalLoad field</value>
        public Double TotalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the LostLoad.
        /// </summary>
        /// <value>The LostLoad field</value>
        public Double LostLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Efficiency.
        /// </summary>
        /// <value>The Efficiency field</value>
        public Double Efficiency { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftName.
        /// </summary>
        /// <value>The ShiftName field</value>
        public string ShiftName { get; set; }
    }
}