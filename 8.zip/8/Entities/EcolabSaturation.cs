﻿// <copyright file="EcolabSaturation.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The EcolabSaturation object</summary>

namespace Entities
{
    using System;

    /// <summary>
    ///     class EcolabSaturation
    /// </summary>
    public class EcolabSaturation
    {
        #region "Constructor"

        /// <summary>
        /// Initializes a new instance of the <see cref="EcolabSaturation" /> class.
        /// </summary>
        /// <param name="ecolabSaturationId">The ecolab saturation identifier.</param>
        /// <param name="ecolabSaturationName">Name of the ecolab saturation.</param>
        /// <param name="absorbancyFactor">The absorbancy factor.</param>
        /// <param name="speedAbsorbancyFactor">The speed absorbancy factor.</param>
        /// <param name="lowAbsorbancyFactor">The low absorbancy factor.</param>
        /// <param name="intermediateAborbancyFactor">The intermediate aborbancy factor.</param>
        /// <param name="highAbsorbancyFactor">The high absorbancy factor.</param>
        /// <param name="myServiceMstrLnnTypId">My service MSTR LNN typ identifier.</param>
        public EcolabSaturation(int ecolabSaturationId, string ecolabSaturationName, decimal absorbancyFactor, decimal speedAbsorbancyFactor, decimal? lowAbsorbancyFactor, decimal intermediateAborbancyFactor, decimal? highAbsorbancyFactor, int myServiceMstrLnnTypId)
        {
            this.EcolabSaturationId = ecolabSaturationId;
            this.EcolabSaturationName = ecolabSaturationName;
			this.AbsorbancyFactor = absorbancyFactor;
			this.SpeedAbsorbancyFactor = speedAbsorbancyFactor;
			this.LowAbsorbancyFactor = lowAbsorbancyFactor;
			this.IntermediateAborbancyFactor = intermediateAborbancyFactor;
			this.HighAbsorbancyFactor = highAbsorbancyFactor;
			this.MyServiceMstrLnnTypId = myServiceMstrLnnTypId;
		}

        /// <summary>
        /// Initializes a new instance of the <see cref="EcolabSaturation" /> class.
        /// </summary>
        /// <param name="ecolabSaturationName">Name of the ecolab saturation.</param>
        /// <param name="absorbancyFactor">The absorbancy factor.</param>
        /// <param name="speedAbsorbancyFactor">The speed absorbancy factor.</param>
        /// <param name="lowAbsorbancyFactor">The low absorbancy factor.</param>
        /// <param name="intermediateAborbancyFactor">The intermediate aborbancy factor.</param>
        /// <param name="highAbsorbancyFactor">The high absorbancy factor.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="myServiceMstrLnnTypId">My service MSTR LNN typ identifier.</param>
        /// <param name="myServiceLastSynchTime">My service last synch time.</param>
        /// <param name="spSp">The sp sp of EcolabSaturation.</param>
        /// <param name="nrNR">The nr nr of EcolabSaturation.</param>
        /// <param name="nlBE">The nl be of EcolabSaturation.</param>
        public EcolabSaturation(string ecolabSaturationName, decimal absorbancyFactor, decimal speedAbsorbancyFactor, decimal? lowAbsorbancyFactor, decimal intermediateAborbancyFactor, decimal? highAbsorbancyFactor, bool isDeleted, int myServiceMstrLnnTypId, DateTime myServiceLastSynchTime, string spSp, string nrNR, string nlBE)
        {
            this.EcolabSaturationName = ecolabSaturationName;
            AbsorbancyFactor = absorbancyFactor;
            SpeedAbsorbancyFactor = speedAbsorbancyFactor;
            LowAbsorbancyFactor = lowAbsorbancyFactor;
            IntermediateAborbancyFactor = intermediateAborbancyFactor;
            HighAbsorbancyFactor = highAbsorbancyFactor;
            IsDeleted = isDeleted;
            MyServiceMstrLnnTypId = myServiceMstrLnnTypId;
            MyServiceLastSynchTime = myServiceLastSynchTime;
            sp_SP = spSp;
            nr_NR = nrNR;
            nl_BE = nlBE;
        }

        /// <summary>
        ///     default constructor EcolabSaturation
        /// </summary>
        public EcolabSaturation()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets EcolabSaturationId
        /// </summary>
        /// <value>Ecolab Saturation Id .</value>
        public int EcolabSaturationId { get; set; }

        /// <summary>
        ///     Gets or sets Ecolab Saturation Name
        /// </summary>
        /// <value>Ecolab Saturation Name.</value>
        public string EcolabSaturationName { get; set; }

        /// <summary>
        ///     Gets or sets Absorbancy Factor
        /// </summary>
        /// <value>Absorbancy Factor.</value>
        public decimal AbsorbancyFactor { get; set; }

        /// <summary>
        ///     Gets or sets Speed Absorbancy Factor
        /// </summary>
        /// <value>Speed Absorbancy Factor.</value>
        public decimal SpeedAbsorbancyFactor { get; set; }

        /// <summary>
        ///     Gets or sets Low Absorbancy Factor
        /// </summary>
        /// <value>Low Absorbancy Factor.</value>
        public decimal? LowAbsorbancyFactor { get; set; }

        /// <summary>
        ///     Gets or sets Intermediate Aborbancy Factor
        /// </summary>
        /// <value>Intermediate Aborbancy Factor.</value>
        public decimal IntermediateAborbancyFactor { get; set; }

        /// <summary>
        ///     Gets or sets High Absorbancy Factor
        /// </summary>
        /// <value>High Absorbancy Factor.</value>
        public decimal? HighAbsorbancyFactor { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value>IsDeleted of EcolabSaturation.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        ///     Gets or sets MyServiceMstrLnnTypId
        /// </summary>
        /// <value>MyServiceMstrLnnTypId.</value>
        public int MyServiceMstrLnnTypId { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceLastSynchTime
        /// </summary>
        /// <value>The Parameter MyServiceLastSynchTime</value>
        public DateTime MyServiceLastSynchTime { get; set; }

        #endregion
    }
}