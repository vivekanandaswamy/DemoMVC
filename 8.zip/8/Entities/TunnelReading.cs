﻿// -----------------------------------------------------------------------
// <copyright file="TunnelReading.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel Reading </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    /// <summary>
    ///     class for TunnelReading
    /// </summary>
    public class TunnelReading
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="TunnelReading" /> class.
        /// </summary>
        /// <param name="groupId"> the group id </param>
        /// <param name="compartmentId">the compartment id </param>
        /// <param name="timestamp">The Time Stamp</param>
        /// <param name="paramterName">the paramter name</param>
        /// <param name="actual">the actual value</param>
        /// <param name="desired">the desired value</param>
        public TunnelReading(int groupId, int compartmentId, DateTime timestamp, string paramterName, float actual, float desired)
        {
            this.GroupId = groupId;
            this.CompartmentId = compartmentId;
            this.Timestamp = timestamp;
            this.ParamterName = paramterName;
            this.Actual = actual;
            this.Desired = desired;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public TunnelReading()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the GroupId
        /// </summary>
        /// <value> Parameter GroupId </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the CompartmentId
        /// </summary>
        /// <value> Parameter CompartmentId </value>
        public int CompartmentId { get; set; }

        /// <summary>
        ///     Gets or sets the TimeStamp
        /// </summary>
        /// <value> Parameter TimeStamp </value>
        public DateTime Timestamp { get; set; }

        /// <summary>
        ///     Gets or sets the ParamterName
        /// </summary>
        /// <value> Paramter Name </value>
        public string ParamterName { get; set; }

        /// <summary>
        ///     Gets or sets the Actual
        /// </summary>
        /// <value> Parameter Actual </value>
        /// >
        public float Actual { get; set; }

        /// <summary>
        ///     Gets or sets the Desired
        /// </summary>
        /// <value> Parameter Desired </value>
        public float Desired { get; set; }

        #endregion
    }
}