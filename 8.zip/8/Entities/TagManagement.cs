﻿// -----------------------------------------------------------------------
// <copyright file="TagManagement.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tag Management </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    /// <summary>
    ///     class TagManagement
    /// </summary>
    public class TagManagement : BaseEntity
    {
        /// <summary>
        ///     Default Constructor
        /// </summary>
        public TagManagement()
        {

        }

        /// <summary>
        /// Parameterised Constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="tagAddress"></param>
        /// <param name="description"></param>
        /// <param name="value"></param>
        /// <param name="LastModifiedTime"></param>
        /// <param name="colName"></param>
        /// <param name="dataType"></param>
        public TagManagement(int id, string tagAddress, string description, string value, DateTime LastModifiedTime, string colName,
            string dataType, string originalColumnName, string entityType, string tagType, string sortingOrder, string controllerEquipmentSetupId, int plcParentEntityType, int plcEntityType, int plcParentEntityId, int plcEntityId)
        {
            this.Id = id;
            this.TagAddress = tagAddress;
            this.TagDescription = description;
            this.ConduitValue = value;
            this.ConduitTimestamp = LastModifiedTime;
            this.ColoumnName = colName;
            this.DataType = dataType;
            this.OriginalColumnName = originalColumnName;
            this.TagType = tagType;
            this.EntityType = entityType;
            this.SortingOrder = sortingOrder;
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.PlcParentEntityType = plcParentEntityType;
            this.PlcEntityType = plcEntityType;
            this.PlcParentEntityId = plcParentEntityId;
            this.PlcEntityId = plcEntityId;
        }

        /// <summary>
        ///     Gets or sets  Tag Address
        /// </summary>
        /// <value>Tag Address</value>
        public string TagAddress { get; set; }

        /// <summary>
        ///     Gets or sets  Tag Description
        /// </summary>
        /// <value>Tag Description</value>
        public string TagDescription { get; set; }

        /// <summary>
        ///     Gets or sets  Quality
        /// </summary>
        /// <value>Quality</value>
        public string Quality { get; set; }

        /// <summary>
        ///     Gets or sets  Conduit Value
        /// </summary>
        /// <value>Conduit Value</value>
        public string ConduitValue { get; set; }

        /// <summary>
        ///     Gets or sets  PLC Value
        /// </summary>
        /// <value>PLC Value</value>
        public string PLCValue { get; set; }

        /// <summary>
        ///     Gets or sets  Conduit TimeStamp
        /// </summary>
        /// <value>Conduit TimeStamp</value>
        public DateTime ConduitTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets  PLCTimeStamp
        /// </summary>
        /// <value>PLC TimeStamp</value>
        public DateTime PLCTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets  ColoumnName
        /// </summary>
        /// <value>ColoumnName</value>
        public string ColoumnName { get; set; }

        /// <summary>
        ///     Gets or sets  DataType
        /// </summary>
        /// <value>DataType</value>
        public string DataType { get; set; }

        /// <summary>
        /// Gets or sets the name of the original column.
        /// </summary>
        /// <value>
        /// The name of the original column.
        /// </value>
        public string OriginalColumnName { get; set; }

        /// <summary>
        /// Gets or sets the type of the entity.
        /// </summary>
        /// <value>
        /// The type of the entity.
        /// </value>
        public string EntityType { get; set; }

        /// <summary>
        /// Gets or sets the type of the tag.
        /// </summary>
        /// <value>
        /// The type of the tag.
        /// </value>
        public string TagType { get; set; }

        /// <summary>
        /// Gets or sets the Sorting Order.
        /// </summary>
        /// <value>
        /// The Sorting Order of the tag.
        /// </value>
        public string SortingOrder { get; set; }

        /// <summary>
        /// Gets or sets the ControllerEquipmentSetupId.
        /// </summary>
        /// <value>
        /// The ControllerEquipmentSetupId of the tag.
        /// </value>
        public string ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity 
        /// </summary>
        /// <value>The Entity .</value>
        public int PlcParentEntityType { get; set; }

        /// <summary>
        ///     Gets or sets Entity 
        /// </summary>
        /// <value>The Entity .</value>
        public int PlcEntityType { get; set; }

        /// <summary>
        ///     Gets or sets Parent Entity Id
        /// </summary>
        /// <value>The ParentEntityId .</value>
        public int PlcParentEntityId { get; set; }

        /// <summary>
        ///     Gets or sets Entity Id
        /// </summary>
        /// <value>The EntityId .</value>
        public int PlcEntityId { get; set; }

    }
}
