﻿// -----------------------------------------------------------------------
// <copyright file="Logs.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Logs </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Logs
    {
        public Logs(int id, DateTime date, string thread, string level, string logger, string msg, string exception, string source, string hostName)
        {
            Id = id;
            Date = date;
            Thread = thread;
            Level = level;
            Logger = logger;
            Message = msg;
            Exception = exception;
            Source = source;
            HostName = hostName;
        }
        public int Id { get; set; }

        public DateTime Date { get; set; }

        public string Thread { get; set; }

        public string Level { get; set; }

        public string Logger { get; set; }

        public string Message { get; set; }

        public string Exception { get; set; }

        public string Source { get; set; }

        public string HostName { get; set; }

    }
}
