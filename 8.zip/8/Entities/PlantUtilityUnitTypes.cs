﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityUnitTypes.cs" company="Ecolab">
// Constructor and entities of the plantutility class.
// </copyright>
// <summary>The Utility class for unit entities.</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     class for PlantUtilityUnitTypes
    /// </summary>
    public class PlantUtilityUnitTypes
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtilityUnitTypes" /> class.
        /// </summary>
        public PlantUtilityUnitTypes()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtilityUnitTypes" /> class.
        /// </summary>
        /// <param name="unit">Unit of the factor type Value.</param>
        /// <param name="subunit">Sub Unit of the factor type Value.</param>
        public PlantUtilityUnitTypes(string unit, string subunit, string usageKey)
        {
            this.Unit = unit;
            this.Subunit = subunit;
            this.UsageKey = usageKey;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the name of the Unit.
        /// </summary>
        /// <value> The unit name value.</value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the Sub unit.
        /// </summary>
        /// <value> The sub unit value.</value>
        public string Subunit { get; set; }

        /// <summary>
        ///     Gets or sets the unit Usage Key.
        /// </summary>
        /// <value> The unit usage key value.</value>
        public string UsageKey { get; set; }

        #endregion
    }
}