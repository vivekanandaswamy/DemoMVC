﻿// -----------------------------------------------------------------------
// <copyright file="OpenActionItems.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The OpenActionItems for Plants .</summary>
// -----------------------------------------------------------------------
using System;
namespace Entities
{
    /// <summary>
    ///     Class OpenActionItems.
    /// </summary>
    public class OpenActionItems : BaseEntity
    {
        #region "Constructor"

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenActionItems" /> class for MyService .
        /// </summary>
        /// <param name="createdDate">The created date.</param>
        /// <param name="itemDesc">itemDesc.</param>
        /// <param name="ecolabAccountNumber">ecolabAccountNumber</param>
        /// <param name="plantName">plantName.</param>
        /// <param name="inchargeId">inchargeId.</param>
        /// <param name="inchargeDesc">The incharge desc.</param>
        /// <param name="comment">comment.</param>
        /// <param name="myServiceOpenActionItemId">My service open action item identifier.</param>
        /// <param name="additionalDetails">The additional details.</param>
        public OpenActionItems(DateTime createdDate,string itemDesc ,string ecolabAccountNumber,  
            string plantName, int inchargeId, string inchargeDesc, string comment, Guid myServiceOpenActionItemId, string additionalDetails)
        {
            this.EcolabAccountNumber = string.IsNullOrEmpty(ecolabAccountNumber) ? ecolabAccountNumber : ecolabAccountNumber.Trim();
            ItemDescription = itemDesc;
            PlantName = plantName;
            InChargeId = inchargeId;
            InChargeDesc = inchargeDesc;
            Comment = comment;
            CreatedDate = createdDate;
            MyServiceOpenActionItemId = myServiceOpenActionItemId;
            AdditionalDetails = additionalDetails;
        }

        public OpenActionItems()
        {

        }
        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the ItemDescription.
        /// </summary>
        /// <value>The ItemDescription.</value>
        public string ItemDescription { get; set; }

        /// <summary>
        ///     Gets or sets the PlantName.
        /// </summary>
        /// <value>The PlantName.</value>
        public string PlantName { get; set; }

        /// <summary>
        ///     Gets or sets the InChargeId for OpenActionItem.
        /// </summary>
        /// <value>The InChargeId for OpenActionItem.</value>
        public int InChargeId { get; set; }

        /// <summary>
        ///     Gets or sets the InChargeDesc for OpenActionItem.
        /// </summary>
        /// <value>The InChargeDesc for OpenActionItem.</value>
        public string InChargeDesc { get; set; }

        /// <summary>
        ///     Gets or sets the Comment.
        /// </summary>
        /// <value>The Comment of the Item.</value>
        public string Comment { get; set; }

        /// <summary>
        ///     Gets or sets the CreatedDate.
        /// </summary>
        /// <value>The CreatedDate of the Item.</value>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        ///     Gets or sets the IsActive of Item.
        /// </summary>
        /// <value>The IsActive of Item.</value>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceOpenActionItemId of Item.
        /// </summary>
        /// <value>The MyServiceOpenActionItemId of Item.</value>
        public Guid MyServiceOpenActionItemId { get; set; }

        /// <summary>
        ///     Gets or sets the AdditionalDetails.
        /// </summary>
        /// <value>The AdditionalDetails of the Item.</value>
        public string AdditionalDetails { get; set; }

        #endregion
    }
}
