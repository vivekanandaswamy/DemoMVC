﻿// -----------------------------------------------------------------------
// <copyright file="ResourceValues.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Resource Values object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    ///     Entity class for AlarmMaster
    /// </summary>
    public class ResourceValues : BaseEntity
    {
        /// <summary>
        /// Parametrized Constructor
        /// </summary>
        public ResourceValues(int resourceId , string resourceValue, string locale, int languageId, DateTime lastModifiedTime, int id)
        {
            this.ResourceId = resourceId;
            this.ResourceValue = resourceValue;
            this.Locale = locale;
            this.LanguageId = languageId;
            this.LastModifiedTime = lastModifiedTime;
            this.Id = id;
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ResourceValues()
        {

        }
        
        /// <summary>
        /// ResourceId
        /// </summary>
        public int ResourceId { get; set; }

        /// <summary>
        /// ResourceValue
        /// </summary>
        public string ResourceValue { get; set; }

        /// <summary>
        /// Locale
        /// </summary>
        public string Locale { get; set; }

        /// <summary>
        /// LanguageId
        /// </summary>
        public int LanguageId { get; set; }

        /// <summary>
        /// LastModifiedTime
        /// </summary>
        public DateTime LastModifiedTime { get; set; }
        
    }
}
