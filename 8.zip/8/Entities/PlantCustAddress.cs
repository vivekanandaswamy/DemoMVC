﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustAddress.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Cust Address object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    /// Class for Billing Address
    /// </summary>
    public class PlantCustAddress
    {
        /// <summary>
        /// Gets or sets the billing addr1.
        /// </summary>
        /// <value>
        /// The billing addr1.
        /// </value>
        public string BillingAddr1 { get; set; }
        /// <summary>
        /// Gets or sets the billing addr2.
        /// </summary>
        /// <value>
        /// The billing addr2.
        /// </value>
        public string BillingAddr2 { get; set; }
        /// <summary>
        /// Gets or sets the city.
        /// </summary>
        /// <value>
        /// The city for PlantCustAddress.
        /// </value>
        public string City { get; set; }
        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country for PlantCustAddress.
        /// </value>
        public string Country { get; set; }
        /// <summary>
        /// Gets or sets the zip.
        /// </summary>
        /// <value>
        /// The zip for PlantCustAddress.
        /// </value>
        public string Zip { get; set; }
    }
}