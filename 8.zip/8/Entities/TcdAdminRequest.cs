﻿// -----------------------------------------------------------------------
// <copyright file="TcdAdminRequest.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TcdAdminRequest </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;

    [Serializable]
    public class TcdAdminRequest
    {
        public int ServiceType { get; set; } // move to header
        public string EntityType { get; set; }
        public string MessageDetails { get; set; }
        public int AppVersion { get; set; }
        public int PayloadSize { get; set; }
        public DateTime Timestamp { get; set; }
    }
}