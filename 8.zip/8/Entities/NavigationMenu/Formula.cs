﻿// -----------------------------------------------------------------------
// <copyright file="Formula.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Formula </summary>
// -----------------------------------------------------------------------

namespace Entities.NavigationMenu
{
    /// <summary>
    ///     Entity class for Formula
    /// </summary>
    public class Formula : BaseEntity
    {
        /// <summary>
        /// parameterized constructor
        /// </summary>
        /// <param name="programId">program Id</param>
        /// <param name="programName">program name</param>
        public Formula(int programId, string programName)
        {
            this.Id = programId;
            this.ProgramName = programName;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public Formula()
        {
        }

        /// <summary>
        ///     Gets or sets the ProgramName
        /// </summary>
        /// <value> Program Name </value>
        public string ProgramName { get; set; }
    }
}