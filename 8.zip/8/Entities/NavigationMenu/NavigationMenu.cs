﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenu.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationMenu</summary>
// -----------------------------------------------------------------------

namespace Entities.NavigationMenu
{
    using System;

    /// <summary>
    ///     The NavigationMenu class
    /// </summary>
    public class NavigationMenu
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="number"></param>
        /// <param name="name"></param>
        /// <param name="parentId"></param>
        /// <param name="typeId"></param>
        /// <param name="typeName"></param>
        public NavigationMenu(int id, int number, string name, int parentId, int typeId, string typeName, int controllerTypeId, int controllerModelId, int washerGroupId, bool washerTypeFlag, byte washerGroupTypeId, string hierarchy)
        {
            this.Id = id;
            this.Number = number;
            this.Name = name;
            this.ParentId = parentId;
            this.TypeId = typeId;
            this.TypeName = typeName;
            this.ControllerTypeId = controllerTypeId;
            this.ControllerModelId = controllerModelId;
            this.WasherGroupId = washerGroupId;
            this.WasherTypeFlag = washerTypeFlag;
            this.WasherGroupTypeId = Convert.ToInt16(washerGroupTypeId);
            this.Hierarchy = hierarchy;
        }

        /// <summary>
        ///     Gets or sets the Id
        /// </summary>
        /// <value> The Id of the menu item.</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Number
        /// </summary>
        /// <valuelue>Number of the Type</valuelue>
        public int Number { get; set; }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value> The Name of the menu item.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the ParentId
        /// </summary>
        /// <value> The Parent Id</value>
        public int ParentId { get; set; }

        /// <summary>
        ///     Gets or sets the TypeId
        /// </summary>
        /// <value> The TypeId for menu item.</value>
        public int TypeId { get; set; }

        /// <summary>
        ///     Gets or sets the TypeName
        /// </summary>
        /// <value> The Type Name.</value>
        public string TypeName { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        /// <value> The ControllerTypeId.</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId
        /// </summary>
        /// <value> The ControllerModelId.</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupId
        /// </summary>
        /// <value> The WasherGroupId.</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherTypeFlag
        /// </summary>
        /// <value> The WasherTypeFlag.</value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeId
        /// </summary>
        /// <value> The WasherGroupTypeId.</value>
        public int WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Hierarchy
        /// </summary>
        /// <value> The Hierarchy.</value>
        public string Hierarchy { get; set; }
    }
}