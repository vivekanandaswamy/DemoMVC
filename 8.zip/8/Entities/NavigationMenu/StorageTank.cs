﻿// -----------------------------------------------------------------------
// <copyright file="StorageTank.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Storage Tank </summary>
// -----------------------------------------------------------------------

namespace Entities.NavigationMenu
{
    /// <summary>
    ///     Entity class for StorageTank
    /// </summary>
    public class StorageTank : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="storageTankId"> storage tank Id </param>
        /// <param name="storageTankName"> storage tank name </param>
        public StorageTank(int storageTankId, string storageTankName)
        {
            this.Id = storageTankId;
            this.StorageTankName = storageTankName;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public StorageTank()
        {
        }

        /// <summary>
        ///     Gets or sets the storageTankName
        /// </summary>
        /// <value> storage Tank Name </value>
        public string StorageTankName { get; set; }
    }
}