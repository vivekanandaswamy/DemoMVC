﻿// -----------------------------------------------------------------------
// <copyright file="Washer.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The washer class.</summary>
// -----------------------------------------------------------------------

namespace Entities.NavigationMenu
{
    /// <summary>
    ///     Entity class for Washer
    /// </summary>
    public class Washer : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="machineId"> Machine Id </param>
        /// <param name="machineName"> Machine Name </param>
        public Washer(int machineId, string machineName)
        {
            this.Id = machineId;
            this.MachineName = machineName;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public Washer()
        {
        }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value> Machine Name </value>
        public string MachineName { get; set; }
    }
}