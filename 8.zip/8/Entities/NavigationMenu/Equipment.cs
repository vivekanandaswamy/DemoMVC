﻿// -----------------------------------------------------------------------
// <copyright file="Equipment.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Equipment is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Entities.NavigationMenu
{
    /// <summary>
    ///     Entity class for Equipment
    /// </summary>
    public class Equipment : BaseEntity
    {
        /// <summary>
        ///     parameterized constructor
        /// </summary>
        /// <param name="equipmentTypeId"> Machine Id </param>
        /// <param name="equipmentTypeName"> Machine Name </param>
        public Equipment(int equipmentTypeId, string equipmentTypeName)
        {
            this.Id = equipmentTypeId;
            this.EquipmentTypeName = equipmentTypeName;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public Equipment()
        {
        }

        /// <summary>
        ///     Gets or sets the EquipmentTypeName
        /// </summary>
        /// <value> Equipment Type Name</value>
        public string EquipmentTypeName { get; set; }
    }
}