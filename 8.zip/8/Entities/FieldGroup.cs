// -----------------------------------------------------------------------
// <copyright file="FieldGroup.cs" company="Ecolab">
// �2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FieldGroup object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System.Collections.Generic;

    /// <summary>
    ///     Class FieldGroup
    /// </summary>
    public class FieldGroup
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="FieldGroup" /> class.
        /// </summary>
        public FieldGroup()
        {
            this.Fields = new List<Field>();
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="FieldGroup" /> class.
        /// </summary>
        /// <param name="id">The id. field</param>
        /// <param name="name">The name. field</param>
        /// <param name="imageUrl">The image URL.</param>
        /// <param name="fieldGroupTypeId">The field group type id.</param>
        /// <param name="displayOrder">The display order.</param>
        /// <param name="helpText">The help text.</param>
        /// <param name="tabId">The tab id.</param>
        public FieldGroup(int id, string name, string imageUrl, int fieldGroupTypeId, int displayOrder, string helpText, int tabId)
        {
            this.Id = id;
            this.Name = name;
            this.ImageUrl = imageUrl;
            this.FieldGroupTypeId = fieldGroupTypeId;
            this.DisplayOrder = displayOrder;
            this.HelpText = helpText;
            this.TabId = tabId;
        }

        /// <summary>
        ///     Gets or sets the id.
        /// </summary>
        /// <value>The id. field</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the image_ URL.
        /// </summary>
        /// <value>The image URL.</value>
        public string ImageUrl { get; set; }

        /// <summary>
        ///     Gets or sets the field group type id.
        /// </summary>
        /// <value>The field group type id.</value>
        public int? FieldGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the display order.
        /// </summary>
        /// <value>The display order.</value>
        public int? DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the help text.
        /// </summary>
        /// <value>The help text.</value>
        public string HelpText { get; set; }

        /// <summary>
        ///     Gets or sets the tab id.
        /// </summary>
        /// <value>The tab id.</value>
        public int? TabId { get; set; }

        /// <summary>
        ///     Gets or sets the fields.
        /// </summary>
        /// <value>The fields.</value>
        public List<Field> Fields { get; set; }
    }
}