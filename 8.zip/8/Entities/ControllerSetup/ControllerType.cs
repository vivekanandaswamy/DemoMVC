﻿// -----------------------------------------------------------------------
// <copyright file="ControllerType.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Type object</summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup
{
    public class ControllerType
    {
        /// <summary>
        ///     Constructor for the meta data
        /// </summary>
        /// <param name="id">The Controller Id</param>
        /// <param name="name">The Controller Name</param>
        public ControllerType(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }

        /// <summary>
        ///     Gets and Sets the Controller Type Id
        /// </summary>
        /// <value>The Parameter Id</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets and Sets the Controller Name
        /// </summary>
        /// <value>The Parameter Controller Name</value>
        public string Name { get; set; }
    }
}