﻿// -----------------------------------------------------------------------
// <copyright file="ControllerModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerModel object</summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup
{
    using System;

    /// <summary>
    ///     class ControllerModel
    /// </summary>
    public class ControllerModel
    {
        #region "Constructor"

        /// <summary>
        ///     Constructor for the ControllerModel
        /// </summary>
        /// <param name="id">The Id</param>
        /// <param name="name">The Name</param>
        /// <param name="regionId">The RegionId</param>
        /// <param name="version">The Version</param>
        public ControllerModel(int id, string name, Int16 regionId, int version, int displayOrder)
        {
            this.Id = id;
            this.Name = name;
            this.RegionId = regionId;
            this.Version = version;
            this.DisplayOrder = displayOrder;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Id
        /// </summary>
        /// <value>The Parameter Id</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value>The Parameter Name</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the RegionId
        /// </summary>
        /// <value>The Parameter Region Id</value>
        public short RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the Version
        /// </summary>
        /// <value>The Parameter Version</value>
        public int Version { get; set; }

        /// <summary>
        ///  Gets or sets the Display Order
        /// </summary>
        /// /// <value>The Parameter Display Order</value>
        public int DisplayOrder { get; set; }

        #endregion
    }
}