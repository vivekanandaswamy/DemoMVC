﻿// -----------------------------------------------------------------------
// <copyright file="WasherField.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WasherField object</summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup
{
    using System;

    /// <summary>
    ///     class WasherField
    /// </summary>
    public class WasherField
    {
        /// <summary>
        /// Constructor for the WasherField
        /// </summary>
        /// <param name="ratioDosingActive">The ratio dosing active.</param>
        /// <param name="aweActive">a we active.</param>
        public WasherField(int ratioDosingActive,int aweActive)
        {
            this.AWEActive = aweActive >= 1 ? true : false;
            this.RatioDosingActive = ratioDosingActive >= 1 ? true : false;
        }

        public WasherField(int ratioDosingActive, int aweActive,int controllerTypeId)
        {
            this.AWEActive = aweActive >= 1 ? true : false;
            this.RatioDosingActive = ratioDosingActive >= 1 ? true : false;
            this.ControllerTypeId = controllerTypeId;
        }

        /// <summary>
        ///     Gets or sets the AWEActive 
        /// </summary>
        /// <value>The Parameter AWEActive</value>
        public bool AWEActive { get; set; }

        /// <summary>
        ///     Gets or sets the RatioDosingActiver
        /// </summary>
        /// <value>The Parameter RatioDosingActive</value>
        public bool RatioDosingActive { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        /// <value>The Parameter ControllerTypeId</value>
        public int ControllerTypeId { get; set; }

    }
}