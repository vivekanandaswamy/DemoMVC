﻿// -----------------------------------------------------------------------
// <copyright file="ControllerData.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Data object</summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup.Pumps
{
    /// <summary>
    ///     Controller Data
    /// </summary>
    public class ControllerData : BaseEntity
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerData" /> class.
        /// </summary>
        public ControllerData(int id, string label, int value)
        {
            this.Id = id;
            this.Label = label;
            this.Value = value;
        }

        /// <summary>
        /// gets or sets the label
        /// </summary>
        public string Label { get; set; }

        /// <summary>
        /// Gets or Sets the Value
        /// </summary>
        public int Value { get; set; }
    }
}