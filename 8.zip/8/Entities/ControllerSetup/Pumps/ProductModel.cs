﻿// -----------------------------------------------------------------------
// <copyright file="ProductModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ProductModel object</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.ControllerSetup.Pumps
{
    /// <summary>
    ///     Class ProductModel.
    /// </summary>
    public class ProductModel
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="ProductModel" /> class.
        /// </summary>
        /// <param name="productName">Name of the product.</param>
        /// <param name="productId">The product identifier.</param>
        public ProductModel(string productName, int productId)
        {
            this.Name = productName;
            this.Id = productId;
        }

        public ProductModel(int pumpsProductId, int controllerId, int chemicalNumber, int productId, string name, bool lowLevelAlarm, bool weightControlledDosage)
        {
            this.PumpsProductId = pumpsProductId;
            this.ControllerId = controllerId;
            this.ChemicalNumber = chemicalNumber;
            this.Id = productId;
            this.Name = name;
            this.LowLevelAlarm = lowLevelAlarm;
            this.WeightControlledDosage = weightControlledDosage;
        }

        #endregion "Constructor"

        #region Properties

        /// <summary>
        ///     Gets or sets the Product Id.
        /// </summary>
        /// <value>Product Id.</value>
        public int Id { get; set; }

        /// <summary>
        /// PumpsProductId
        /// </summary>
        public int PumpsProductId { get; set; }

        /// <summary>
        /// ControllerId
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        /// ChemicalNumber
        /// </summary>
        public int ChemicalNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Product Name.
        /// </summary>
        /// <value>Product Name.</value>
        public string Name { get; set; }

        /// <summary>
        /// LowLevelAlarm
        /// </summary>
        public bool LowLevelAlarm { get; set; }

        /// <summary>
        /// WeightControlledDosage
        /// </summary>
        public bool WeightControlledDosage { get; set; }

        /// <summary>
        /// ControllerEquipmentSetupId
        /// </summary>
        public int ControllerEquipmentSetupId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime LastModifiedTime { get; set; }

        #endregion Properties
    }
}