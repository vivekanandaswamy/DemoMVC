﻿// -----------------------------------------------------------------------
// <copyright file="LineCompartmentMapping.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Line Compartment Mapping object</summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.ControllerSetup.Pumps
{
	/// <summary>
	///     Line Compartment Mapping Class
	/// </summary>
	public class LineCompartmentMapping
	{
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductModel" /> class.
        /// </summary>
        /// <param name="tunnelCompartmentEquipmentValveMappingId">The Tunnel Compartment Equipment Valve Mapping Id</param>
        /// <param name="controllerEquipmentId">The Controller Equipment Id</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="tunnelNumber">The Machine Internal Id</param>
        /// <param name="lineNumber">The Line Number</param>
        /// <param name="dosingPointNumber">The Dosing Point Number</param>
        /// <param name="valveNumber">The Controller Equipment Valve Id</param>
        /// <param name="compartmentNumber">The Tunnel Compartment Id</param>
        /// <param name="directDosingFlag">The Direct Dosing Flag</param>
        /// <param name="washerNumber">The washer number.</param>
        /// <param name="lastModifiedDate">The Last Modified Date</param>
        public LineCompartmentMapping(int tunnelCompartmentEquipmentValveMappingId, byte controllerEquipmentId, int controllerId, int tunnelNumber, byte lineNumber, byte dosingPointNumber, byte valveNumber, byte compartmentNumber, bool directDosingFlag,int washerNumber, DateTime lastModifiedDate)
		{
			this.TunnelCompartmentEquipmentValveMappingId = tunnelCompartmentEquipmentValveMappingId;
			this.ControllerEquipmentId = controllerEquipmentId;
			this.ControllerId = controllerId;
			this.TunnelNumber = tunnelNumber;
			this.LineNumber = lineNumber;
			this.DosingPointNumber = dosingPointNumber;
			this.ValveNumber = valveNumber;
			this.CompartmentNumber = compartmentNumber;
			this.DirectDosingFlag = directDosingFlag;
            this.WasherNumber = washerNumber;
			this.LastModifiedDate = lastModifiedDate;
		}

        /// <summary>
        /// For PLC XL
        /// </summary>
        /// <param name="valveNum">The valve number.</param>
        /// <param name="tunnelCmptNum">The tunnel CMPT number.</param>
        /// <param name="controllerEquipmentSetupId">The controller equipment setup identifier.</param>
        /// <param name="controllerEquipmentTypeId">The controller equipment type identifier.</param>
        public LineCompartmentMapping(byte valveNum, byte tunnelCmptNum, Int16 controllerEquipmentSetupId, int controllerEquipmentTypeId)
		{
			this.ValveNumber = valveNum;
			this.TunnelCompartmentNumber = tunnelCmptNum;
			this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
			this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
		}

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductModel" /> class.
        /// </summary>
        /// <param name="tunnelCompartmentEquipmentValveMappingId">The Tunnel Compartment Equipment Valve Mapping Id</param>
        /// <param name="plantId">The plant identifier.</param>
        /// <param name="controllerEquipmentSetupID">The controller equipment setup identifier.</param>
        /// <param name="tunnelNumber">The Machine Internal Id</param>
        /// <param name="dosingPointNumber">The Dosing Point Number</param>
        /// <param name="valveNumber">The Controller Equipment Valve Id</param>
        /// <param name="compartmentNumber">The Tunnel Compartment Id</param>
        /// <param name="directDosingFlag">The Direct Dosing Flag</param>
        /// <param name="lastModifiedDate">The Last Modified Date</param>
        public LineCompartmentMapping(int tunnelCompartmentEquipmentValveMappingId,
										int plantId,
										short controllerEquipmentSetupID,
										int tunnelNumber,
										byte dosingPointNumber,
										byte valveNumber,
										byte compartmentNumber,
										bool directDosingFlag,
										DateTime lastModifiedDate)
		{
			this.TunnelCompartmentEquipmentValveMappingId = tunnelCompartmentEquipmentValveMappingId;
			this.PlantId = plantId;
			this.ControllerEquipmentSetupId = controllerEquipmentSetupID;
			this.TunnelNumber = tunnelNumber;
			this.DosingPointNumber = dosingPointNumber;
			this.ValveNumber = valveNumber;
			this.CompartmentNumber = compartmentNumber;
			this.DirectDosingFlag = directDosingFlag;
			this.LastModifiedDate = DateTime.SpecifyKind(lastModifiedDate, DateTimeKind.Utc);
		}

		/// <summary>
		///     Gets or sets the TunnelCompartmentEquipmentValveMappingId
		/// </summary>
		/// <value>The Tunnel Compartment Equipment Valve Mapping Id</value>
		public int TunnelCompartmentEquipmentValveMappingId { get; set; }

		/// <summary>
		///     Gets or sets the ControllerEquipmentId
		/// </summary>
		/// <value>The Controller Equipment Id</value>
		public byte ControllerEquipmentId { get; set; }

		/// <summary>
		///     Gets or sets the ControllerID
		/// </summary>
		/// <value>The Controller ID</value>
		public int ControllerId { get; set; }

		/// <summary>
		///     Gets or sets the MachineInternalId
		/// </summary>
		/// <value>The Machine Internal Id</value>
		public int TunnelNumber { get; set; }

		/// <summary>
		///     Gets or sets the LineNumber
		/// </summary>
		/// <value>The Line Number</value>
		public byte LineNumber { get; set; }

		/// <summary>
		///     Gets or sets the DosingPointNumber
		/// </summary>
		/// <value>The Dosing Point Number</value>
		public byte DosingPointNumber { get; set; }

		/// <summary>
		///     Gets or sets the ControllerEquipmentValveId
		/// </summary>
		/// <value>The Controller Equipment Valve Id</value>
		public byte ValveNumber { get; set; }

		/// <summary>
		///     Gets or sets the TunnelCompartmentId
		/// </summary>
		/// <value>The Tunnel Compartment Id</value>
		public byte CompartmentNumber { get; set; }

		/// <summary>
		/// Gets or Sets the DirectDosingFlag
		/// </summary>
		/// <value>The Direct Dosing Flag</value>
		public bool DirectDosingFlag { get; set; }

		/// <summary>
		/// TunnelCompartmentNumber
		/// </summary>
		public int TunnelCompartmentNumber { get; set; }

        /// <summary>
        /// WasherExtractorNumber
        /// </summary>
        public int WasherNumber { get; set; }

		/// <summary>
		/// ControllerEquipmentSetupId
		/// </summary>
		public Int16 ControllerEquipmentSetupId { get; set; }

		/// <summary>
		/// ControllerEquipmentTypeId
		/// </summary>
		public int ControllerEquipmentTypeId { get; set; }

		/// <summary>
		///     Gets or sets the LastModifiedDate
		/// </summary>
		/// <value>The Last Modified Date</value>
		public DateTime LastModifiedDate { get; set; }

		/// <summary>
		/// Gets or sets Plantid
		/// </summary>
		public int PlantId { get; set; }
	}
}