﻿// -----------------------------------------------------------------------
// <copyright file="PumpsMetaData.cs" company="Ecolab">
// Copyright © Ecolab.
// </copyright>
// <summary>The Pumps MetaData object</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;

namespace Entities.ControllerSetup.Pumps
{
    /// <summary>
    ///     Class PumpsMetaData.
    /// </summary>
    public class PumpsMetaData
    {
        /// <summary>
        ///     Default Constructor
        /// </summary>
        public PumpsMetaData()
        {
        }

        /// <summary>
        /// Constructor for Pump
        /// </summary>
        /// <param name="controllerEquipmentId">Controller Equipment Id</param>
        /// <param name="controllerEquipmentTypeId">Controller Equipment Type Id</param>
        /// <param name="isActive">IsActive Flag</param>
        /// <param name="productId">Product Id</param>
        /// <param name="productName">Product Name</param>
        /// <param name="pumpCalibration">Pump Calibration</param>
        /// <param name="flowMeterSwitchFlag">FlowMeter Switch Flag</param>
        /// <param name="maximumDosingTime">Maximum Dosing Time</param>
        /// <param name="flowSwitchTimeout">Flow Switch TimeOut</param>
        /// <param name="controllerEquipmentSetupId">Controller Equipment Setup Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="controllerId">Controller Id</param>
        /// <param name="controllerTopicName">The Controller Name</param>
        /// <param name="controllerTypeId">Controller type Id</param>
        /// <param name="lfsChemicalName">The Lfs Chemical Name</param>
        /// <param name="kFactor">The K-Factor value</param>
        /// <param name="tunnelHold">The tunnel hold</param>
        /// <param name="flowDetectorType">The Flow Detector Type</param>
        /// <param name="flowSwitchAlarm">The flowSwitch alarm</param>
        /// <param name="flowMeterAlarm">The flow meter alarm</param>
        /// <param name="flowMeterType">The flow meter type</param>
        /// <param name="flowAlarmDelay">The flow alarm delay</param>
        /// <param name="flowMeterPumpDelay">The flow meter pump delay</param>
        /// <param name="flowMeterAlarmDelay">The flow meter alarm delay</param>
        /// <param name="lfsChemicalNametag">The LFS Chemical Name Tag</param>
        /// <param name="kFactorTag">The K-Factor Tag</param>
        /// <param name="calibrationTag">The Calibration Tag</param>
        /// <param name="controllerEquipmentTypeModelId">The Controller Equipment Type Model Id</param>
        /// <param name="conventionalWasherGroupConnection">The Conventional Washer Group Connection</param>
        /// <param name="axillaryPumpCalibration">The Auxilary Pump Calibration</param>
        /// <param name="flowmeterSwitchActivated">The Flow Meter Activated</param>
        /// <param name="flushWhileDosing">The Flush While Dosing</param>
        /// <param name="weightControlledDosage">The Weight Controlled Dosage</param>
        /// <param name="equipmentDoseAlone">The Equipment Dose Alone</param>
        /// <param name="lowLevelAlarm">The Low Level Alarm</param>
        /// <param name="leakageAlarm">The Leakage Alarm</param>
        /// <param name="flushTime">The Flush Time</param>
        /// <param name="pumpingTime">The Pumping Time</param>
        /// <param name="preFlushTime">The Pre Flush Time</param>
        /// <param name="nightFlushPauseTime">The Night Flush Pause Time</param>
        /// <param name="nightFlushTime">The Night Flush Time</param>
        /// <param name="acceptedDeviation">The Accepted Deviation</param>
        /// <param name="lineNumber">The Line Number</param>
        /// <param name="directDosingFlag">The Direct Dosing Flag</param>
        /// <param name="directDosingMachineInternalId">The Direct Dosing Machine Internal Id</param>
        /// <param name="directDosingTunnelCompartmentId">The Direct Dosing Tunnel Compartment Id</param>
        /// <param name="lastModifiedTimestamp">The Last Modified Time Stamp</param>
        /// <param name="lastSyncTime">The Last Sync Time</param>
        /// <param name="washerGroupTypeId">The washer group type identifier.</param>
        /// <param name="noOfCmprtments">The no of cmprtments.</param>
        /// <param name="flushValveNumber">The flush valve number.</param>
        /// <param name="calibrationConductSS_Tank">The calibration conduct s s_ tank.</param>
        /// <param name="backflowControl">if set to <c>true</c> [back flow control].</param>
        /// <param name="factorFM_B_FM">The factor f m_ b_ fm.</param>
        /// <param name="acceptedDeviationRingLine">The accepted deviation ring line.</param>
        /// <param name="usePumpOfGroup1ForTunnel">if set to <c>true</c> [use pump of group1 for tunnel].</param>
        /// <param name="pHSensorEnabled">if set to <c>true</c> [p h sensor enabled].</param>
        /// <param name="concentration">The concentration.</param>
        /// <param name="stockSolutionDeadEnd">if set to <c>true</c> [stock solution dead end].</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="valveOutputAsTom">if set to <c>true</c> [valve output as tom].</param>
        /// <param name="flowSwitchNumber">The flow switch number.</param>
        /// <param name="flushTimeForFlushValve">The flush time for flush valve.</param>
        /// <param name="minimumFlowRate">The minimum flow rate.</param>
        /// <param name="productDensity">The product density.</param>
        /// <param name="maximumConcentration">The maximum concentration.</param>
        /// <param name="dosingLineMode">The dosing line mode.</param>
        public PumpsMetaData(int controllerEquipmentId,
            byte controllerEquipmentTypeId,
            bool isActive,
            int? productId,
            string productName,
            decimal pumpCalibration,
            bool? flowMeterSwitchFlag,
            short? maximumDosingTime,
            decimal? flowSwitchTimeout,
            short controllerEquipmentSetupId,
            string ecolabAccountNumber,
            int controllerId,
            string controllerTopicName,
            int controllerTypeId,
            string lfsChemicalName,
            decimal kFactor,
            bool tunnelHold,
            int flowDetectorType,
            bool flowSwitchAlarm,
            bool flowMeterAlarm,
            int flowMeterType,
            decimal flowAlarmDelay,
            decimal flowMeterPumpDelay,
            decimal flowMeterAlarmDelay,
            string lfsChemicalNametag,
            string kFactorTag,
            string calibrationTag,
            int controllerEquipmentTypeModelId,
            bool conventionalWasherGroupConnection,
            short axillaryPumpCalibration,
            bool flowmeterSwitchActivated,
            bool flushWhileDosing,
            bool weightControlledDosage,
            bool equipmentDoseAlone,
            bool lowLevelAlarm,
            bool leakageAlarm,
            short flushTime,
            short pumpingTime,
            short preFlushTime,
            short nightFlushPauseTime,
            short nightFlushTime,
            short acceptedDeviation,
            byte lineNumber,
            bool directDosingFlag,
            int directDosingMachineInternalId,
            int directDosingTunnelCompartmentId,
            DateTime lastModifiedTimestamp,
            DateTime lastSyncTime,
            int washerGroupTypeId,
            int? noOfCmprtments,
            byte? flushValveNumber,
            decimal? calibrationConductSS_Tank,
            bool backflowControl,
            short? factorFM_B_FM,
            Int16? acceptedDeviationRingLine,
            bool usePumpOfGroup1ForTunnel,
            bool pHSensorEnabled,
            int concentration,
            bool stockSolutionDeadEnd,
            int washerGroupNumber,
            bool valveOutputAsTom,
            int flowSwitchNumber,
            int flushTimeForFlushValve,
            int minimumFlowRate,
            decimal productDensity,
            int maximumConcentration,
            int dosingLineMode
            )
        {
            this.ControllerEquipmentId = controllerEquipmentId;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
            this.ProductId = productId;
            this.ProductName = productName;
            this.PumpCalibration = pumpCalibration;
            this.FlowMeterSwitchFlag = flowMeterSwitchFlag;
            this.MaximumDosingTime = maximumDosingTime;
            this.FlowSwitchTimeout = flowSwitchTimeout;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ControllerId = controllerId;
            this.ControllerTopicName = controllerTopicName;
            this.ControllerTypeId = controllerTypeId;
            this.LfsChemicalName = lfsChemicalName;
            this.KFactor = kFactor;
            this.TunnelHold = tunnelHold;
            this.FlowDetectorType = flowDetectorType;
            this.FlowSwitchAlarm = flowSwitchAlarm;
            this.FlowMeterAlarm = flowMeterAlarm;
            this.FlowMeterType = flowMeterType;
            this.FlowAlarmDelay = flowAlarmDelay;
            this.FlowMeterPumpDelay = flowMeterPumpDelay;
            this.FlowMeterAlarmDelay = flowMeterAlarmDelay;
            this.LfsChemicalNametag = lfsChemicalNametag;
            this.KfactorTag = kFactorTag;
            this.CalibrationTag = calibrationTag;
            this.ControllerEquipmentTypeModelId = controllerEquipmentTypeModelId;
            this.ConventionalWasherGroupConnection = conventionalWasherGroupConnection;
            this.AxillaryPumpCalibration = axillaryPumpCalibration;
            this.FlowmeterSwitchActivated = flowmeterSwitchActivated;
            this.FlushWhileDosing = flushWhileDosing;
            this.WeightControlledDosage = weightControlledDosage;
            this.EquipmentDoseAlone = equipmentDoseAlone;
            this.LowLevelAlarm = lowLevelAlarm;
            this.LeakageAlarm = leakageAlarm;
            this.FlushTime = flushTime;
            this.PumpingTime = pumpingTime;
            this.PreFlushTime = preFlushTime;
            this.NightFlushPauseTime = nightFlushPauseTime;
            this.NightFlushTime = nightFlushTime;
            this.AcceptedDeviation = acceptedDeviation;
            this.LineNumber = lineNumber;
            this.DirectDosingFlag = directDosingFlag;
            this.DirectDosingMachineInternalId = directDosingMachineInternalId;
            this.DirectDosingTunnelCompartmentId = directDosingTunnelCompartmentId;
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.LastModifiedTimestamp = DateTime.SpecifyKind(lastModifiedTimestamp, DateTimeKind.Utc);
            this.LastSyncTime = DateTime.SpecifyKind(lastSyncTime, DateTimeKind.Utc);
            this.IsActive = isActive;
            //this.WasherGroupId = washerGroupId;
            this.WasherGroupTypeId = washerGroupTypeId;
            this.NoOfCompartments = noOfCmprtments;
            this.FlushValveNumber = flushValveNumber;
            this.CalibrationConductSS_Tank = calibrationConductSS_Tank;
            this.BackflowControl = backflowControl;
            this.FactorFM_B_FM = factorFM_B_FM;
            this.AcceptedDeviationRingLine = acceptedDeviationRingLine;
            this.UsePumpOfGroup1ForTunnel = usePumpOfGroup1ForTunnel;
            this.pHSensorEnabled = pHSensorEnabled;
            this.Concentration = concentration;
            this.StockSolutionDeadEnd = stockSolutionDeadEnd;
            this.WasherGroupNumber = washerGroupNumber;
            this.ValveOutputAsTom = valveOutputAsTom;
            this.FlowSwitchNumber = flowSwitchNumber;
            this.FlushTimeForFlushValve = flushTimeForFlushValve;
            this.MinimumFlowRate = minimumFlowRate;
            this.ProductDensity = productDensity;
            this.MaximumConcentration = maximumConcentration;
            this.DosingLineMode = dosingLineMode;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PumpsMetaData"/> class.
        /// </summary>
        /// <param name="controllerEquipmentSetupId">The controller equipment setup identifier.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="controllerEquipmentId">The controller equipment identifier.</param>
        /// <param name="controllerEquipmentTypeId">The controller equipment type identifier.</param>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="productId">The product identifier.</param>
        /// <param name="pumpCalibration">The pump calibration.</param>
        /// <param name="kFactor">The k factor.</param>
        /// <param name="tunnelHold">if set to <c>true</c> [tunnel hold].</param>
        /// <param name="flowSwitchAlarm">if set to <c>true</c> [flow switch alarm].</param>
        /// <param name="flowMeterAlarm">if set to <c>true</c> [flow meter alarm].</param>
        /// <param name="flowMeterType">Type of the flow meter.</param>
        /// <param name="flowAlarmDelay">The flow alarm delay.</param>
        /// <param name="flowMeterPumpDelay">The flow meter pump delay.</param>
        /// <param name="flowMeterAlarmDelay">The flow meter alarm delay.</param>
        /// <param name="lfsChemicalName">Name of the LFS chemical.</param>
        /// <param name="flowDetectorType">Type of the flow detector.</param>
        /// <param name="lastModifiedTimestamp">The last modified time stamp.</param>
        public PumpsMetaData(short controllerEquipmentSetupId, string ecolabAccountNumber, int controllerId,
            byte controllerEquipmentId, byte controllerEquipmentTypeId, bool isActive, int? productId,
            decimal pumpCalibration, decimal kFactor, bool tunnelHold, bool flowSwitchAlarm, bool flowMeterAlarm,
            int flowMeterType, decimal flowAlarmDelay, decimal flowMeterPumpDelay, decimal flowMeterAlarmDelay, string lfsChemicalName,
            int flowDetectorType, DateTime lastModifiedTimestamp)
        {
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ControllerId = controllerId;
            this.ControllerEquipmentId = controllerEquipmentId;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
            this.IsActive = isActive;
            this.ProductId = productId;
            this.PumpCalibration = pumpCalibration;
            this.KFactor = kFactor;
            this.TunnelHold = tunnelHold;
            this.FlowSwitchAlarm = flowSwitchAlarm;
            this.FlowMeterAlarm = flowMeterAlarm;
            this.FlowMeterType = flowMeterType;
            this.FlowAlarmDelay = flowAlarmDelay;
            this.FlowMeterPumpDelay = flowMeterPumpDelay;
            this.FlowMeterAlarmDelay = flowMeterAlarmDelay;
            this.LfsChemicalName = lfsChemicalName;
            this.FlowDetectorType = flowDetectorType;
            this.LastModifiedTimestamp = lastModifiedTimestamp;
        }

        /// <summary>
        /// Constructor for Pump
        /// </summary>
        /// <param name="controllerEquipmentSetupId">Controller Equipment Setup Id</param>
        /// <param name="ecolabAccountNumber">Ecolab Account Number</param>
        /// <param name="controllerId">Controller Id</param>
        /// <param name="controllerEquipmentId">Controller Equipment Id</param>
        /// <param name="controllerEquipmentTypeId">Controller Equipment Type Id</param>
        /// <param name="controllerEquipmentTypeModelID">The controller equipment type model identifier.</param>
        /// <param name="lineNumber">The Line Number</param>
        /// <param name="isActive">IsActive Flag</param>
        /// <param name="productId">Product Id</param>
        /// <param name="pumpCalibration">Pump Calibration</param>
        /// <param name="flowMeterSwitchFlag">FlowMeter Switch Flag</param>
        /// <param name="maximumDosingTime">Maximum Dosing Time</param>
        /// <param name="flowSwitchTimeout">Flow Switch TimeOut</param>
        /// <param name="kFactor">The K-Factor value</param>
        /// <param name="tunnelHold">The tunnel hold</param>
        /// <param name="flowSwitchAlarm">The flowSwitch alarm</param>
        /// <param name="flowMeterAlarm">The flow meter alarm</param>
        /// <param name="flowMeterType">The flow meter type</param>
        /// <param name="flowSwitchNumber">The flow switch number.</param>
        /// <param name="flowAlarmDelay">The flow alarm delay</param>
        /// <param name="flowMeterPumpDelay">The flow meter pump delay</param>
        /// <param name="flowMeterAlarmDelay">The flow meter alarm delay</param>
        /// <param name="lfsChemicalName">The Lfs Chemical Name</param>
        /// <param name="flowDetectorType">The Flow Detector Type</param>
        /// <param name="conventionalWasherGroupConnection">The Conventional Washer Group Connection</param>
        /// <param name="axillaryPumpCalibration">The Auxilary Pump Calibration</param>
        /// <param name="flowmeterSwitchActivated">The Flow Meter Activated</param>
        /// <param name="flushWhileDosing">The Flush While Dosing</param>
        /// <param name="weightControlledDosage">The Weight Controlled Dosage</param>
        /// <param name="equipmentDoseAlone">The Equipment Dose Alone</param>
        /// <param name="lowLevelAlarm">The Low Level Alarm</param>
        /// <param name="leakageAlarm">The Leakage Alarm</param>
        /// <param name="flushTime">The Flush Time</param>
        /// <param name="pumpingTime">The Pumping Time</param>
        /// <param name="preFlushTime">The Pre Flush Time</param>
        /// <param name="nightFlushPauseTime">The Night Flush Pause Time</param>
        /// <param name="nightFlushTime">The Night Flush Time</param>
        /// <param name="acceptedDeviation">The Accepted Deviation</param>
        /// <param name="washerGroupNumber">The washer group number.</param>
        /// <param name="lastModifiedTimestamp">The Last Modified Time Stamp</param>
        /// <param name="flushValveNumber">The flush valve number.</param>
        /// <param name="calibrationConductSS_Tank">The calibration conduct s s_ tank.</param>
        /// <param name="backFlowControl">if set to <c>true</c> [back flow control].</param>
        /// <param name="factorFM_B_FM">The factor f m_ b_ fm.</param>
        /// <param name="acceptedDeviationRingLine">The accepted deviation ring line.</param>
        /// <param name="usePumpOfGroup1ForTunnel">if set to <c>true</c> [use pump of group1 for tunnel].</param>
        /// <param name="pHSensorEnabled">if set to <c>true</c> [p h sensor enabled].</param>
        /// <param name="concentration">The concentration.</param>
        /// <param name="stockSolutionDeadEnd">if set to <c>true</c> [stock solution dead end].</param>
        /// <param name="valveOutputAsTom">if set to <c>true</c> [valve output as tom].</param>
        public PumpsMetaData(short controllerEquipmentSetupId,
            string ecolabAccountNumber,
            int controllerId,
            byte controllerEquipmentId,
            byte controllerEquipmentTypeId,
            int controllerEquipmentTypeModelID,
            byte lineNumber,
            bool isActive,
            int? productId,
            decimal pumpCalibration,
            bool? flowMeterSwitchFlag,
            short? maximumDosingTime,
            decimal? flowSwitchTimeout,
            decimal kFactor,
            bool tunnelHold,
            bool flowSwitchAlarm,
            bool flowMeterAlarm,
            int flowMeterType,
            int flowSwitchNumber,
            decimal flowAlarmDelay,
            decimal flowMeterPumpDelay,
            decimal flowMeterAlarmDelay,
            string lfsChemicalName,
            int flowDetectorType,
            bool conventionalWasherGroupConnection,
            decimal axillaryPumpCalibration,
            bool flowmeterSwitchActivated,
            bool flushWhileDosing,
            bool weightControlledDosage,
            bool equipmentDoseAlone,
            bool lowLevelAlarm,
            bool leakageAlarm,
            short flushTime,
            short pumpingTime,
            short preFlushTime,
            short nightFlushPauseTime,
            short nightFlushTime,
            short acceptedDeviation,
            int washerGroupNumber,
            DateTime lastModifiedTimestamp,
            byte? flushValveNumber,
            decimal? calibrationConductSS_Tank,
            bool backFlowControl,
            short? factorFM_B_FM,
            short? acceptedDeviationRingLine,
            bool usePumpOfGroup1ForTunnel,
            bool pHSensorEnabled,
            int concentration,
            bool stockSolutionDeadEnd,
            bool valveOutputAsTom
            )
        {
            this.ControllerEquipmentSetupId = controllerEquipmentSetupId;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ControllerId = controllerId;
            this.ControllerEquipmentId = controllerEquipmentId;
            this.ControllerEquipmentTypeId = controllerEquipmentTypeId;
            this.ControllerEquipmentTypeModelId = controllerEquipmentTypeModelID;
            this.LineNumber = lineNumber;
            this.IsActive = isActive;
            this.ProductId = productId;
            this.PumpCalibration = pumpCalibration;
            this.FlowMeterSwitchFlag = flowMeterSwitchFlag;
            this.MaximumDosingTime = maximumDosingTime;
            this.FlowSwitchTimeout = flowSwitchTimeout;
            this.KFactor = kFactor;
            this.TunnelHold = tunnelHold;
            this.FlowSwitchAlarm = flowSwitchAlarm;
            this.FlowMeterAlarm = flowMeterAlarm;
            this.FlowMeterType = flowMeterType;
            this.FlowSwitchNumber = flowSwitchNumber;
            this.FlowAlarmDelay = flowAlarmDelay;
            this.FlowMeterPumpDelay = flowMeterPumpDelay;
            this.FlowMeterAlarmDelay = flowMeterAlarmDelay;
            this.LfsChemicalName = lfsChemicalName;
            this.FlowDetectorType = flowDetectorType;
            this.ConventionalWasherGroupConnection = conventionalWasherGroupConnection;
            this.AxillaryPumpCalibration = axillaryPumpCalibration;
            this.FlowmeterSwitchActivated = flowmeterSwitchActivated;
            this.FlushWhileDosing = flushWhileDosing;
            this.WeightControlledDosage = weightControlledDosage;
            this.EquipmentDoseAlone = equipmentDoseAlone;
            this.LowLevelAlarm = lowLevelAlarm;
            this.LeakageAlarm = leakageAlarm;
            this.FlushTime = flushTime;
            this.PumpingTime = pumpingTime;
            this.PreFlushTime = preFlushTime;
            this.NightFlushPauseTime = nightFlushPauseTime;
            this.NightFlushTime = nightFlushTime;
            this.AcceptedDeviation = acceptedDeviation;
            this.WasherGroupNumber = washerGroupNumber;
            this.LastModifiedTimestamp = DateTime.SpecifyKind(lastModifiedTimestamp, DateTimeKind.Utc);
            this.FlushValveNumber = flushValveNumber;
            this.CalibrationConductSS_Tank = calibrationConductSS_Tank;
            this.BackflowControl = backFlowControl;
            this.FactorFM_B_FM = factorFM_B_FM;
            this.AcceptedDeviationRingLine = acceptedDeviationRingLine;
            this.UsePumpOfGroup1ForTunnel = usePumpOfGroup1ForTunnel;
            this.pHSensorEnabled = pHSensorEnabled;
            this.Concentration = concentration;
            this.StockSolutionDeadEnd = stockSolutionDeadEnd;
            this.ValveOutputAsTom = valveOutputAsTom;
        }

        public PumpsMetaData(int controllerEquipmentId, byte controllerEquipmentTypeId, bool isActive, int? productId, string productName, decimal pumpCalibration,
            bool? flowMeterSwitchFlag, int? flowMeterCalibration, short? maximumDosingTime, short? flowSwitchTimeout, short controllerEquipmentSetupId,
            string ecolabAccountNumber, int controllerId, string controllerTopicName, int controllerTypeId, string lfsChemicalName, short flushTime, short pumpingTime,
             short preFlushTime, short nightFlushPauseTime, short nightFlushTime, short acceptedDeviation, byte lineNumber, decimal kFactor,
            bool tunnelHold, int flowDetectorType, bool flowSwitchAlarm, bool flowMeterAlarm, int flowMeterType, decimal flowAlarmDelay, int controllerEquipmentTypeModelId, bool conventionalWasherGroupConnection,
            bool directDosingFlag, int directDosingMachineInternalId, int directDosingTunnelCompartmentId, decimal flowMeterPumpDelay,
            decimal flowMeterAlarmDelay, string lfsChemicalNametag, string kFactorTag, string calibrationTag, DateTime lastModifiedTimeStamp, DateTime lastSyncTime, int washerGroupTypId, int noOfCompartments, int washerGroupNumber)
        {
            ControllerEquipmentId = controllerEquipmentId;
            ControllerEquipmentTypeId = controllerEquipmentTypeId;
            ProductId = productId;
            ProductName = productName;
            PumpCalibration = pumpCalibration;
            FlowMeterSwitchFlag = flowMeterSwitchFlag;
            FlowMeterCalibration = flowMeterCalibration;
            MaximumDosingTime = maximumDosingTime;
            FlowSwitchTimeout = flowSwitchTimeout;
            EcolabAccountNumber = ecolabAccountNumber;
            ControllerId = controllerId;
            ControllerTopicName = controllerTopicName;
            ControllerTypeId = controllerTypeId;
            LfsChemicalName = lfsChemicalName;
            FlushTime = flushTime;
            PumpingTime = pumpingTime;
            PreFlushTime = preFlushTime;
            NightFlushPauseTime = nightFlushPauseTime;
            NightFlushTime = nightFlushTime;
            AcceptedDeviation = acceptedDeviation;
            LineNumber = lineNumber;
            KFactor = kFactor;
            TunnelHold = tunnelHold;
            FlowDetectorType = flowDetectorType;
            FlowSwitchAlarm = flowSwitchAlarm;
            FlowMeterAlarm = flowMeterAlarm;
            FlowMeterType = flowMeterType;
            FlowAlarmDelay = flowAlarmDelay;
            ControllerEquipmentTypeModelId = controllerEquipmentTypeModelId;
            DirectDosingFlag = directDosingFlag;
            DirectDosingMachineInternalId = directDosingMachineInternalId;
            DirectDosingTunnelCompartmentId = directDosingTunnelCompartmentId;
            ConventionalWasherGroupConnection = conventionalWasherGroupConnection;
            FlowMeterPumpDelay = flowMeterPumpDelay;
            FlowMeterAlarmDelay = flowMeterAlarmDelay;
            LfsChemicalNametag = lfsChemicalNametag;
            KfactorTag = kFactorTag;
            CalibrationTag = calibrationTag;
            ControllerEquipmentSetupId = controllerEquipmentSetupId;
            LastModifiedTimestamp = DateTime.SpecifyKind(lastModifiedTimeStamp, DateTimeKind.Utc);
            LastSyncTime = DateTime.SpecifyKind(lastSyncTime, DateTimeKind.Utc);
            IsActive = isActive;
            this.WasherGroupTypeId = washerGroupTypId;
            this.NoOfCompartments = noOfCompartments;
            this.WasherGroupNumber = washerGroupNumber;
        }

        public PumpsMetaData(int controllerEquipmentId, byte controllerEquipmentTypeId, bool isActive, int? productId, string productName, decimal pumpCalibration, bool? flowMeterSwitchFlag, int? flowMeterCalibration, short? maximumDosingTime, short? flowSwitchTimeout, short controllerEquipmentSetupId, string ecolabAccountNumber, int controllerId, string controllerTopicName, int controllerTypeId, string lfsChemicalName, decimal kFactor, bool tunnelHold, int flowDetectorType, bool flowSwitchAlarm, bool flowMeterAlarm, int flowMeterType, decimal flowAlarmDelay, decimal flowMeterPumpDelay, decimal flowMeterAlarmDelay, string lfsChemicalNametag, string kFactorTag, string calibrationTag, DateTime lastModifiedTimestamp, DateTime lastSyncTime)
        {
            ControllerEquipmentId = controllerEquipmentId;
            ControllerEquipmentTypeId = controllerEquipmentTypeId;
            ProductId = productId;
            ProductName = productName;
            PumpCalibration = pumpCalibration;
            FlowMeterSwitchFlag = flowMeterSwitchFlag;
            FlowMeterCalibration = flowMeterCalibration;
            MaximumDosingTime = maximumDosingTime;
            FlowSwitchTimeout = flowSwitchTimeout;
            EcolabAccountNumber = ecolabAccountNumber;
            ControllerId = controllerId;
            ControllerTopicName = controllerTopicName;
            ControllerTypeId = controllerTypeId;
            LfsChemicalName = lfsChemicalName;
            KFactor = kFactor;
            TunnelHold = tunnelHold;
            FlowDetectorType = flowDetectorType;
            FlowSwitchAlarm = flowSwitchAlarm;
            FlowMeterAlarm = flowMeterAlarm;
            FlowMeterType = flowMeterType;
            FlowAlarmDelay = flowAlarmDelay;
            FlowMeterPumpDelay = flowMeterPumpDelay;
            FlowMeterAlarmDelay = flowMeterAlarmDelay;
            LfsChemicalNametag = lfsChemicalNametag;
            KfactorTag = kFactorTag;
            CalibrationTag = calibrationTag;
            ControllerEquipmentSetupId = controllerEquipmentSetupId;
            LastModifiedTimestamp = DateTime.SpecifyKind(lastModifiedTimestamp, DateTimeKind.Utc);
            LastSyncTime = DateTime.SpecifyKind(lastSyncTime, DateTimeKind.Utc);
            IsActive = isActive;
        }
        /// <summary>
        ///     Gets or sets the controller equipment Setup identifier.
        /// </summary>
        /// <value>The controller equipment Setup identifier.</value>
        public int ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>The controller equipment identifier.</value>
        public int ControllerEquipmentId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id identifier.
        /// </summary>
        /// <value>The controller equipment identifier.</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment type identifier.
        /// </summary>
        /// <value>The controller equipment type identifier.</value>
        public int ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the controller identifier.
        /// </summary>
        /// <value>The controller identifier.</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the controller name.
        /// </summary>
        /// <value>The controller name.</value>
        public string ControllerTopicName { get; set; }

        /// <summary>
        ///     Gets or sets the eco lab account number.
        /// </summary>
        /// <value>The eco lab account number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the flow meter calibration.
        /// </summary>
        /// <value>The flow meter calibration.</value>
        public int? FlowMeterCalibration { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [flow meter switch flag].
        /// </summary>
        /// <value>
        ///     <c>null</c> if [flow meter switch flag] contains no value, <c>true</c> if [flow meter switch flag]; otherwise,
        ///     <c>false</c>.
        /// </value>
        public bool? FlowMeterSwitchFlag { get; set; }

        /// <summary>
        ///     Gets or sets the flow switch time out.
        /// </summary>
        /// <value>The flow switch time out.</value>
        public decimal? FlowSwitchTimeout { get; set; }

        /// <summary>
        ///     Gets or sets the maximum dosing time.
        /// </summary>
        /// <value>The maximum dosing time.</value>
        public short? MaximumDosingTime { get; set; }

        /// <summary>
        ///     Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        public int? ProductId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets the pump calibration.
        /// </summary>
        /// <value>The pump calibration.</value>
        public decimal PumpCalibration { get; set; }

        /// <summary>
        ///     Gets or sets the controller Type Id
        /// </summary>
        /// <value>The controller type id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or Sets the Lfs Chemical Name
        /// </summary>
        /// <value>The Lfs Chemical Name</value>
        public string LfsChemicalName { get; set; }

        /// <summary>
        ///     Gets or Sets the K-Factor
        /// </summary>
        /// <value>The K-Factor value</value>
        public decimal KFactor { get; set; }

        /// <summary>
        ///     Gets or sets Tunnel hold
        /// </summary>
        /// <value>The Tunnel hold value</value>
        public bool TunnelHold { get; set; }

        /// <summary>
        ///     Gets or sets Flow Detector Type
        /// </summary>
        /// <value>The Flow Detector Type</value>
        public int FlowDetectorType { get; set; }

        /// <summary>
        ///     Gets or sets Flow Switch alarm
        /// </summary>
        /// <value>The Flow Switch alarm value</value>
        public bool FlowSwitchAlarm { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Alarm
        /// </summary>
        /// <value>The flow meter alarm</value>
        public bool FlowMeterAlarm { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Type
        /// </summary>
        /// <value>The Flow Meter Type</value>
        public int FlowMeterType { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Alarm Delay Time
        /// </summary>
        /// <value>The Flow Alarm Delay Time in seconds</value>
        public decimal FlowAlarmDelay { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Pump Delay Time
        /// </summary>
        /// <value>The Flow Meter Pump Delay Time in seconds</value>
        public decimal FlowMeterPumpDelay { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Alarm Delay Time
        /// </summary>
        /// <value>The Flow Meter Alarm Delay Time in seconds</value>
        public decimal FlowMeterAlarmDelay { get; set; }

        /// <summary>
        ///     Gets or sets the Lfs Chemical Name Tag
        /// </summary>
        /// <value>The Lfs Chemical Name Tag</value>
        public string LfsChemicalNametag { get; set; }

        /// <summary>
        ///     Gets or sets the K-Factor Tag
        /// </summary>
        /// <value>The K-Factor Tag</value>
        public string KfactorTag { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration Tag
        /// </summary>
        /// <value>The Calibration Tag</value>
        public string CalibrationTag { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerEquipmentTypeModelId
        /// </summary>
        /// <value>The Controller Equipment Type Model Id</value>
        public int ControllerEquipmentTypeModelId { get; set; }

        /// <summary>
        ///     Gets or sets the ConventionalWasherGroupConnection
        /// </summary>
        /// <value>The Conventional Washer Group Connection</value>
        public bool ConventionalWasherGroupConnection { get; set; }

        /// <summary>
        ///     Gets or sets the AxillaryPumpCalibration
        /// </summary>
        /// <value>The Axillary Pump Calibration</value>
        public decimal AxillaryPumpCalibration { get; set; }

        /// <summary>
        ///     Gets or sets the FlowmeterSwitchActivated
        /// </summary>
        /// <value>The Flowmeter Switch Activated</value>
        public bool FlowmeterSwitchActivated { get; set; }

        /// <summary>
        ///     Gets or sets the FlushWhileDosing
        /// </summary>
        /// <value>The Flush While Dosing</value>
        public bool FlushWhileDosing { get; set; }

        /// <summary>
        ///     Gets or sets the WeightControlledDosage
        /// </summary>
        /// <value>The Weight Controlled Dosage</value>
        public bool WeightControlledDosage { get; set; }

        /// <summary>
        ///     Gets or sets the EquipmentDoseAlone
        /// </summary>
        /// <value>The Equipment Dose Alone</value>
        public bool EquipmentDoseAlone { get; set; }

        /// <summary>
        ///     Gets or sets the LowLevelAlarm
        /// </summary>
        /// <value>The Low Level Alarm</value>
        public bool LowLevelAlarm { get; set; }

        /// <summary>
        ///     Gets or sets the LeakageAlarm
        /// </summary>
        /// <value>The Leakage Alarm</value>
        public bool LeakageAlarm { get; set; }

        /// <summary>
        ///     Gets or sets the FlushTime
        /// </summary>
        /// <value>The Flush Time</value>
        public short FlushTime { get; set; }

        /// <summary>
        ///     Gets or sets the PumpingTime
        /// </summary>
        /// <value>The Pumping Time</value>
        public short PumpingTime { get; set; }

        /// <summary>
        ///     Gets or sets the PreFlushTime
        /// </summary>
        /// <value>The Pre Flush Time</value>
        public short PreFlushTime { get; set; }

        /// <summary>
        ///     Gets or sets the NightFlushPauseTime
        /// </summary>
        /// <value>The Night Flush Pause Time</value>
        public short NightFlushPauseTime { get; set; }

        /// <summary>
        ///     Gets or sets the NightFlushTime
        /// </summary>
        /// <value>The Night Flush Time</value>
        public short NightFlushTime { get; set; }

        /// <summary>
        ///     Gets or sets the AcceptedDeviation
        /// </summary>
        /// <value>The Accepted Deviation</value>
        public short AcceptedDeviation { get; set; }

        /// <summary>
        /// Gets or Sets the LineNumber
        /// </summary>
        public byte LineNumber { get; set; }

        /// <summary>
        /// Gets or sets the DirectDosingFlag
        /// </summary>
        /// <value>The Direct Dosing Flag</value>
        public bool DirectDosingFlag { get; set; }

        /// <summary>
        ///     Gets or sets the DirectDosingMachineInternalId
        /// </summary>
        /// <value>The Direct Dosing Machine Internal Id</value>
        public int DirectDosingMachineInternalId { get; set; }

        /// <summary>
        ///     Gets or sets the DirectDosingTunnelCompartmentId
        /// </summary>
        /// <value>The Direct Dosing Tunnel Compartment Id</value>
        public int DirectDosingTunnelCompartmentId { get; set; }

        /// <summary>
        /// WasherGroupNumber
        /// </summary>
        public int WasherGroupNumber { get; set; }

        /// <summary>
        /// The Valve Output as TOM
        /// </summary>
        public bool ValveOutputAsTom { get; set; }

        /// <summary>
        /// FlowSwitchNumber
        /// </summary>
        public int FlowSwitchNumber { get; set; }

        /// <summary>
        /// WasherGroupTypeId
        /// </summary>
        public int WasherGroupTypeId { get; set; }

        /// <summary>
        /// NoOfCompartments
        /// </summary>
        public int? NoOfCompartments { get; set; }

        /// <summary>
        /// flushValveNumber
        /// </summary>
        public short? FlushValveNumber { get; set; }

        /// <summary>
        /// calibrationConductSS_Tank
        /// </summary>
        public Decimal? CalibrationConductSS_Tank { get; set; }

        /// <summary>
        /// BackFlowControl
        /// </summary>
        public bool BackflowControl { get; set; }

        /// <summary>
        /// AcceptedDeviationRingLine
        /// </summary>
        public short? AcceptedDeviationRingLine { get; set; }

        /// <summary>
        /// FactorFM_B_FM							
        /// </summary>
        public short? FactorFM_B_FM { get; set; }

        /// <summary>
        /// UsePumpOfGroup1ForTunnel
        /// </summary>
        public bool UsePumpOfGroup1ForTunnel { get; set; }

        /// <summary>
        /// pHSensorEnabled
        /// </summary>
        public bool pHSensorEnabled { get; set; }

        /// <summary>
        /// Concentration
        /// </summary>
        public int Concentration { get; set; }

        /// <summary>
        /// StockSolutionDeadEnd
        /// </summary>
        public bool StockSolutionDeadEnd { get; set; }

        /// <summary>
        /// FlushTimeForFlushValve
        /// </summary>
        public int FlushTimeForFlushValve { get; set; }

        /// <summary>
        /// Gets or Sets the LineCompartmentMappings
        /// </summary>
        /// <value>List of LineCompartmentMappingModel</value>
        public List<LineCompartmentMapping> LineCompartmentMappings { get; set; }

        /// <summary>
        ///     Gets or sets isActive
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets Minimum FlowRate
        /// </summary>
        /// <value> Minimum FlowRate </value>
        public int MinimumFlowRate { get; set; }

        /// <summary>
        ///     Gets or sets Product Density
        /// </summary>
        /// <value> Product Density </value>
        public decimal ProductDensity { get; set; }

        /// <summary>
        ///     Gets or sets Maximum Concentration
        /// </summary>
        /// <value> Maximum Concentration </value>
        public int MaximumConcentration { get; set; }

        /// <summary>
        ///     Gets or sets DosingLineMode
        /// </summary>
        /// <value> DosingLineMode </value>
        public int DosingLineMode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FlowDetectorTypeTag { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FlowSwitchAlarmTag { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FlowMeterAlarmTag { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FlowMeterTypeTag { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FlowAlarmDelayTag { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FlowMeterPumpDelayTag { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FlowMeterAlarmDelayTag { get; set; }

    }
}