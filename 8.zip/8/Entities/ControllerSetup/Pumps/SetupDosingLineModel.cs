﻿// -----------------------------------------------------------------------
// <copyright file="SetupDosingLineModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SetupDosingLineModel </summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup.Pumps
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Class for Setup Dosing Line Model
    /// </summary>
    public class SetupDosingLineModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SetupDosingLineModel"/> class.
        /// </summary>
        /// <param name="dosingLineMode">The dosing line mode.</param>
        /// <param name="enableAuxiliary">The enable auxiliary.</param>
        public SetupDosingLineModel(int dosingLineMode, int enableAuxiliary)
        {
            this.DosingLineMode = dosingLineMode;
            this.EnableAuxiliary = enableAuxiliary;
        }

        /// <summary>
        /// Gets or sets the dosing line mode.
        /// </summary>
        /// <value>
        /// The dosing line mode.
        /// </value>
        public int DosingLineMode { get; set; }

        /// <summary>
        /// Gets or sets the enable auxiliary.
        /// </summary>
        /// <value>
        /// The enable auxiliary.
        /// </value>
        public int EnableAuxiliary { get; set; }
    }
}
