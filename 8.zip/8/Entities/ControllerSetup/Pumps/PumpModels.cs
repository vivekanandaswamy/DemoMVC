﻿// -----------------------------------------------------------------------
// <copyright file="PumpModels.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Pump Models object</summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup.Pumps
{
    /// <summary>
        ///     Pump Model Class
        /// </summary>
    public class PumpModels
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="ProductModel" /> class.
        /// </summary>
        /// <param name="controllerEquipmentTypeModelId">The Controller Equipment Type Model Id</param>
        /// <param name="controllerEquipmentTypeModelName">The Controller Equipment Type Model Name</param>
        /// <param name="artNumberLang">The Art Number lang</param>
        /// <param name="teoreticalCalibration">The Teoretical Calibration</param>
        /// <param name="isMeType">The Is Machine Equipment Type</param>
        public PumpModels(int controllerEquipmentTypeModelId, string controllerEquipmentTypeModelName, string artNumberLang, int teoreticalCalibration, bool isMeType)
        {
            this.ControllerEquipmentTypeModelId = controllerEquipmentTypeModelId;
            this.ControllerEquipmentTypeModelName = controllerEquipmentTypeModelName;
            this.ArtNumberLang = artNumberLang;
            this.TeoreticalCalibration = teoreticalCalibration;
            this.IsMeType = isMeType;
        }

            /// <summary>
            ///     Gets or sets the ControllerEquipmentTypeModelId
            /// </summary>
            /// <value>The Controller Equipment Type Model Id</value>
            public int ControllerEquipmentTypeModelId { get; set; }

            /// <summary>
            ///     Gets or sets the ControllerEquipmentTypeModelName
            /// </summary>
            /// <value>The Controller Equipment Type Model Name</value>
            public string ControllerEquipmentTypeModelName { get; set; }

            /// <summary>
            ///     Gets or sets the ArtNumberLang.
            /// </summary>
            /// <value>The Art Number Lang.</value>
            public string ArtNumberLang { get; set; }

            /// <summary>
            ///     Gets or sets the TeoreticalCalibration.
            /// </summary>
            /// <value>The Teoretical Calibration.</value>
            public int TeoreticalCalibration { get; set; }

            /// <summary>
            ///     Gets or sets the IsMeType.
            /// </summary>
            /// <value>The Is Machine Equipment Type</value>
            public bool IsMeType { get; set; }
    }
}