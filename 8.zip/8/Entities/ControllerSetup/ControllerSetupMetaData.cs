﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupMetaData.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Setup MetaData object</summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup
{
    /// <summary>
    ///     Initializes a new instance of the <see cref="ControllerSetupMetaData" /> class.
    /// </summary>
    public class ControllerSetupMetaData
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupMetaData" /> class.
        /// </summary>
        /// <param name="controllerName">The controller Name</param>
        /// <param name="fieldGroupId">The field Group Id</param>
        /// <param name="fieldGroupName">The field Group Name</param>
        /// <param name="fieldGroupImageUrl">The field Group Image Url</param>
        /// <param name="fieldGroupHelpText">The field Group Help Text</param>
        /// <param name="controllerModelId">The controller model id</param>
        /// <param name="controllerTypeId">The Controller Type Id</param>
        /// <param name="fieldGroupTypeName">The field Group Type Name</param>
        /// <param name="fieldId">The field Id</param>
        /// <param name="fieldName">The field Name</param>
        /// <param name="fieldType">The field Type</param>
        /// <param name="fieldLabel">The field Label</param>
        /// <param name="fieldMinValue">The field Minimum Value</param>
        /// <param name="fieldMaxValue">The field Max Value</param>
        /// <param name="fieldIsMandatory">The field Is Mandatory</param>
        /// <param name="fieldIsEditable">The field Is Editable</param>
        /// <param name="fieldHelpText">The field Help Text</param>
        /// <param name="fieldHelpUrl">The field Help Url</param>
        /// <param name="tabIndex">The tab Index</param>
        /// <param name="controlType">The control Type</param>
        /// <param name="dataSourceId">The data Source Id</param>
        /// <param name="dataSourceKeyValue">The data Source Key Value</param>
        /// <param name="dataCategoryId">The data Category Id</param>
        /// <param name="fieldDefaultValue">The field Default Value</param>
        /// <param name="fieldCurrencyCode">The field Currency Code</param>
        /// <param name="fieldResourceKey">The field Resource Key </param>
        /// <param name="fieldGroupResourceKey">The field Group Resource Key</param>
        /// <param name="fieldGroupDo">The field Group DO</param>
        /// <param name="fieldDo">The field DO</param>
        /// <param name="accessToRole">The access To Role</param>
        /// <param name="mode">The Mode</param>
        public ControllerSetupMetaData(string controllerName, int fieldGroupId, string fieldGroupName, string fieldGroupImageUrl, string fieldGroupHelpText, short controllerModelId, int controllerTypeId, string fieldGroupTypeName, int fieldId, string fieldName, string fieldType, string fieldLabel, string fieldMinValue, string fieldMaxValue, bool fieldIsMandatory, bool fieldIsEditable, string fieldHelpText, string fieldHelpUrl, int tabIndex, string controlType, int dataSourceId, string dataSourceKeyValue, int dataCategoryId, string fieldDefaultValue, string fieldCurrencyCode, string fieldResourceKey, string fieldGroupResourceKey, int fieldGroupDo, int fieldDo, int accessToRole, string mode, string hasFieldTag, string tagDefaultValue, string fieldClassName, string controllerVersion, bool IsDosingLineConsumed)
        {
            this.ControllerName = controllerName;
            this.FieldGroupId = fieldGroupId;
            this.FieldGroupName = fieldGroupName;
            this.FieldGroupImageUrl = fieldGroupImageUrl;
            this.FieldGroupHelpText = fieldGroupHelpText;
            this.ControllerModelId = controllerModelId;
            this.ControllerTypeId = controllerTypeId;
            this.FieldGroupTypeName = fieldGroupTypeName;
            this.FieldId = fieldId;
            this.FieldName = fieldName;
            this.FieldType = fieldType;
            this.FieldLabel = fieldLabel;
            this.FieldMinValue = fieldMinValue;
            this.FieldMaxValue = fieldMaxValue;
            this.FieldIsMandatory = fieldIsMandatory;
            this.FieldIsEditable = fieldIsEditable;
            this.FieldHelpText = fieldHelpText;
            this.FieldHelpUrl = fieldHelpUrl;
            this.TabIndex = tabIndex;
            this.ControlType = controlType;
            this.DataSourceId = dataSourceId;
            this.DataSourceKeyValue = dataSourceKeyValue;
            this.DataCategoryId = dataCategoryId;
            this.FieldDefaultValue = fieldDefaultValue;
            this.FieldCurrencyCode = fieldCurrencyCode;
            this.FieldResourceKey = fieldResourceKey;
            this.FieldGroupResourceKey = fieldGroupResourceKey;
            this.FieldGroupDo = fieldGroupDo;
            this.FieldDo = fieldDo;
            this.AccessToRole = accessToRole;
            this.Mode = mode;
            this.HasFieldTag = hasFieldTag;
            this.TagDefaultValue = tagDefaultValue;
            this.TagValueCode = string.Empty;
            this.FieldClassName = fieldClassName;
            this.ControllerVersion = controllerVersion;
            this.IsDosingLineConsumed = IsDosingLineConsumed;
        }

        /// <summary>
        ///     Gets or sets the Controller Name
        /// </summary>
        /// <value>Controller Name</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Id
        /// </summary>
        /// <value>Field Group Id</value>
        public int FieldGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Name
        /// </summary>
        /// <value>Field Group Name</value>
        public string FieldGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Image Url
        /// </summary>
        /// <value>Field Group Image Url</value>
        public string FieldGroupImageUrl { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Help Text
        /// </summary>
        /// <value>Field Group Help Text</value>
        public string FieldGroupHelpText { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value>Controller Model Id</value>
        public short ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type Id
        /// </summary>
        /// <value>Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Type Name
        /// </summary>
        /// <value>Field Group Type Name</value>
        public string FieldGroupTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the Field Id
        /// </summary>
        /// <value>Parameter Field Id</value>
        public int FieldId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Name
        /// </summary>
        /// <value>Parameter Field Name</value>
        public string FieldName { get; set; }

        /// <summary>
        ///     Gets or sets the Field Type
        /// </summary>
        /// <value>Parameter Field Type</value>
        public string FieldType { get; set; }

        /// <summary>
        ///     Gets or sets the Field Label
        /// </summary>
        /// <value>Parameter Field Label</value>
        public string FieldLabel { get; set; }

        /// <summary>
        ///     Gets or sets the Field Minimum Value
        /// </summary>
        /// <value>Parameter Field Min Value</value>
        public string FieldMinValue { get; set; }

        /// <summary>
        ///     Gets or sets the Field Maximum Value
        /// </summary>
        /// <value>Parameter Field Max Value</value>
        public string FieldMaxValue { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether the Field Is Mandatory or not
        /// </summary>
        /// <value>Parameter Field Is Mandatory</value>
        public bool FieldIsMandatory { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether the Field Is Editable or not
        /// </summary>
        /// <value>Parameter Field Is Editable</value>
        public bool FieldIsEditable { get; set; }

        /// <summary>
        ///     Gets or sets the Field Help Text
        /// </summary>
        /// <value>Parameter Field Help Text</value>
        public string FieldHelpText { get; set; }

        /// <summary>
        ///     Gets or sets the Field Help Url
        /// </summary>
        /// <value>FieldHelpUrl</value>
        public string FieldHelpUrl { get; set; }

        /// <summary>
        ///     Gets or sets the Tab Index
        /// </summary>
        /// <value>The tab Index.</value>
        public int TabIndex { get; set; }

        /// <summary>
        ///     Gets or sets the Control Type
        /// </summary>
        /// <value>The Control Type.</value>
        public string ControlType { get; set; }

        /// <summary>
        ///     Gets or sets the Data Source Id
        /// </summary>
        /// <value>The data source Id.</value>
        public int DataSourceId { get; set; }

        /// <summary>
        ///     Gets or sets the Data Source Key Value
        /// </summary>
        /// <value>The Data source key value.</value>
        public string DataSourceKeyValue { get; set; }

        /// <summary>
        ///     Gets or sets the Data Category Id
        /// </summary>
        /// <value>The data category id.</value>
        public int DataCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Default Value
        /// </summary>
        /// <value>The field default value</value>
        public string FieldDefaultValue { get; set; }

        /// <summary>
        ///     Gets or sets the Field Currency Code
        /// </summary>
        /// <value>The Field Currency Code.</value>
        public string FieldCurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets the Field Resource Key
        /// </summary>
        /// <value>The field resource key.</value>
        public string FieldResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Resource Key
        /// </summary>
        /// <value>The field resource key</value>
        public string FieldGroupResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group DO
        /// </summary>
        /// <value>The Field Group DO</value>
        public int FieldGroupDo { get; set; }

        /// <summary>
        ///     Gets or sets the Field DO
        /// </summary>
        /// <value>The Field Do.</value>
        public int FieldDo { get; set; }

        /// <summary>
        ///     Gets or sets the Access To Role
        /// </summary>
        /// <value>The access to role</value>
        public int AccessToRole { get; set; }

        /// <summary>
        ///     Gets or sets Mode
        /// </summary>
        /// <value>The mode value.</value>
        public string Mode { get; set; }

        /// <summary>
        ///     Gets or sets the field has tag value or not
        /// </summary>
        /// <value>The Parameter Tag string  Value</value>
        public string HasFieldTag { get; set; }

        /// <summary>
        ///     Gets or sets the Tag Default Value
        /// </summary>
        /// <value>The Parameter Tag Default Value</value>
        public string TagDefaultValue { get; set; }

        /// <summary>
        ///     Gets or sets the Tag Value Code
        /// </summary>
        /// <value>The Parameter Tag Value Code</value>
        public string TagValueCode { get; set; }

        /// <summary>
        ///     Gets or sets the Tag Value Code
        /// </summary>
        /// <value>The Parameter Tag Value Code</value>
        public string FieldClassName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Version
        /// </summary>
        /// <value>The Parameter Controller Version</value>
        public string ControllerVersion { get; set; }

        /// <summary>
        /// get set the IsDosingLineConsumed
        /// </summary>
        public bool IsDosingLineConsumed { get; set; }
    }
}