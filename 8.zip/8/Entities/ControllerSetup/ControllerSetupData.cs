﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupData.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerSetupData object</summary>
// -----------------------------------------------------------------------

namespace Entities.ControllerSetup
{
    /// <summary>
    ///     class ControllerSetupData
    /// </summary>
    public class ControllerSetupData
    {
        #region "Constructor"

        /// <summary>
        ///     Constructor for the Setup data
        /// </summary>
        /// <param name="controllerId">The ControllerId</param>
        /// <param name="controllerModelId">The controllerModelId</param>
        /// <param name="controllerTypeId">The ControllerTypeId</param>
        /// <param name="fieldGroupId">The FieldGroupId</param>
        /// <param name="fieldId">The FieldId</param>
        /// <param name="value">The Value string</param>
        public ControllerSetupData(int controllerId, int controllerModelId, int controllerTypeId, int fieldGroupId, int fieldId, string value)
        {
            this.ControllerId = controllerId;
            this.ControllerModelId = controllerModelId;
            this.ControllerTypeId = controllerTypeId;
            this.FieldGroupId = fieldGroupId;
            this.FieldId = fieldId;
            this.Value = value;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets the Controller Id
        /// </summary>
        /// <value>The Parameter Controller Id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value>The Parameter Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Type Id
        /// </summary>
        /// <value>The Parameter Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Tab Id
        /// </summary>
        /// <value>The Parameter Tab Id</value>
        public int TabId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Group Id
        /// </summary>
        /// <value>The Parameter Field Group Id</value>
        public int FieldGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Id
        /// </summary>
        /// <value>The Parameter Field Id</value>
        public int FieldId { get; set; }

        /// <summary>
        ///     Gets or sets the Field Name
        /// </summary>
        /// <value>The Parameter Field Name</value>
        public string FieldName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Data
        /// </summary>
        /// <value>The Parameter Controller Data</value>
        public string Value { get; set; }

        #endregion
    }
}