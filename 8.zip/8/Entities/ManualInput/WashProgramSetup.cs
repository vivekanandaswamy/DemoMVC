﻿// -----------------------------------------------------------------------
// <copyright file="WashProgramSetup.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WashProgramSetup class </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.ManualInput
{
    /// <summary>
    ///     Entity class for WashProgramSetup
    /// </summary>
    public class WashProgramSetup
    {

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="programId"></param>
        /// <param name="description"></param>
        public WashProgramSetup(int programId, string description)
        {
            this.ProgramId = programId;
            this.Description = description;
        }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="programId">The program identifier.</param>
        /// <param name="description">formula description</param>
        public WashProgramSetup(int programId, string description, bool IsVisibleForFormula)
		{
			this.ProgramId = programId;
			this.Description = description;
            this.IsVisibleForFormula = IsVisibleForFormula;
		}

        /// <summary>
        ///     default constructor
        /// </summary>
        public WashProgramSetup()
        {
        }

        /// <summary>
        ///     Gets or sets the ProgramNumber.
        /// </summary>
        /// <value> formula number.</value>
        public Int16 ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> formula description.</value>
        public string Description { get; set; }

		/// <summary>
		/// Gets or sets ProgramId
		/// </summary>
		/// <value>programId</value>
		public int ProgramId { get; set; }
        /// <summary>
        /// Gets or Sets IsVisibleForFormula
        /// </summary>
        /// <value>IsVisibleForFormula</value>
        public bool IsVisibleForFormula { get; set; }
    }
}