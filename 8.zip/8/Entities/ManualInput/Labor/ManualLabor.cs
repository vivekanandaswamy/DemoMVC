﻿// -----------------------------------------------------------------------
// <copyright file="ManualLabor.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualLabor class </summary>

namespace Entities.ManualInput.ManualLabor
{
    using System;

    /// <summary>
    ///     Entity Class for ManualLabor
    /// </summary>
    public class ManualLabor : BaseEntity
    {
        #region "Constructor"

        /// <summary>
        ///     Initializes a new instance of the <see cref="ManualLabor" /> class.
        /// </summary>
        public ManualLabor()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ManualLabor" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="locationId">The location identifier.</param>
        /// <param name="manHourTypeId">Type of hour labor working.</param>
        /// <param name="startDate">Start date of the labor.</param>
        /// <param name="endDate">End date of the labor.</param>
        /// <param name="laborCost">Cost of the labor.</param>
        /// <param name="allocatedManHours">Number of hours allocated.</param>
        /// <param name="ecolabAccountNumber">The ecolab account number.</param>
        public ManualLabor(int id, int locationId, int manHourTypeId, DateTime startDate, DateTime endDate, decimal laborCost, int allocatedManHours, string ecolabAccountNumber)
        {
            this.Id = id;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.LocationId = locationId;
            this.ManHourTypeId = manHourTypeId;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.LaborCost = laborCost;
            this.AllocatedManHours = allocatedManHours;
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets Location Id
        /// </summary>
        /// <value>The location identifier.</value>
        public int LocationId { get; set; }

        /// <summary>
        ///     Gets or sets ManHourType Id
        /// </summary>
        /// <value>The man hour type identifier.</value>
        public int ManHourTypeId { get; set; }

        /// <summary>
        ///     Gets or sets Start Date
        /// </summary>
        /// <value>The start date.</value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets End Date
        /// </summary>
        /// <value>The end date.</value>
        public DateTime EndDate { get; set; }

        /// <summary>
        ///     Gets or sets the Labor Cost
        /// </summary>
        /// <value>The labor cost.</value>
        public decimal LaborCost { get; set; }

        /// <summary>
        ///     Gets or sets Allocated Man Hours
        /// </summary>
        /// <value>The allocated man hours.</value>
        public int AllocatedManHours { get; set; }

        /// <summary>
        ///     Gets or sets Ecolab Account Number
        /// </summary>
        /// <value>The Ecolab account number.</value>
        public string EcolabAccNum { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime.
        /// </summary>
        /// <value>The Parameter LastSyncTime.</value>
        public DateTime LastSyncTime { get; set; }

        #endregion
    }
}