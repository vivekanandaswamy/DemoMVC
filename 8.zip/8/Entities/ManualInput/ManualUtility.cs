﻿// -----------------------------------------------------------------------
// <copyright file="ManualUtility.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualUtility class </summary>
// -----------------------------------------------------------------------

namespace Entities.ManualInput
{
    using System;

    /// <summary>
    ///     Entity class for ManualUtility
    /// </summary>
    public class ManualUtility : BaseEntity
    {
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="meterId">The meter Id.</param>
        /// <param name="description"> formula description </param>
        /// <param name="meterTickUnit">meter tick unit.</param>
        /// <param name="utilityTypeId">utility type id.</param>
        /// <param name="groupId">The group id.</param>
        /// <param name="utilityTypeName">Utility Type name.</param>
        /// <param name="locationName">location name.</param>
        /// <param name="utilityId">The utility id.</param>
        /// <param name="recordedDate">The recorded date.</param>
        /// <param name="value">The value parameter.</param>
        /// <param name="usage">The usage parameter.</param>
        /// <param name="maxValueLimit">The maximum value limit.</param>
        /// <param name="myServiceMeterGuid">The MyServiceMeterGuid.</param>
        public ManualUtility(int meterId, string description, string meterTickUnit, string utilityTypeId, int groupId, string utilityTypeName, string locationName, int utilityId, DateTime recordedDate, decimal value, decimal usage, long maxValueLimit, Guid myServiceMeterGuid)
        {
            this.MeterId = meterId;
            this.Description = description;
            this.MeterTickUnit = meterTickUnit;
            this.UtilityTypeId = utilityTypeId;
            this.GroupId = groupId;
            this.UtilityTypeName = utilityTypeName;
            this.LocationName = locationName;
            this.Id = utilityId;
            this.RecordedDate = recordedDate;
            this.Value = (double)value;
            this.Usage = (double)usage;
            this.MaxValueLimit = maxValueLimit;
            this.MyServiceMeterGuid = myServiceMeterGuid;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ManualUtility()
        {
        }

        /// <summary>
        ///     Gets or sets the MeterId.
        /// </summary>
        /// <value> Meter Id.</value>
        public int MeterId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> meter description.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the MeterTickUnit.
        /// </summary>
        /// <value> meter tick unit.</value>
        public string MeterTickUnit { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityTypeId.
        /// </summary>
        /// <value> meter utility type id.</value>
        public string UtilityTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value> meter group id.</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityTypeName.
        /// </summary>
        /// <value> meter utility type name.</value>
        public string UtilityTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the LocationName.
        /// </summary>
        /// <value> meter location name.</value>
        public string LocationName { get; set; }

        /// <summary>
        ///     Gets or sets the RecordedDate.
        /// </summary>
        /// <value> manual recorded date.</value>
        public DateTime RecordedDate { get; set; }

        /// <summary>
        ///     Gets or sets the Value.
        /// </summary>
        /// <value> manual utility value.</value>
        public double Value { get; set; }

        /// <summary>
        ///     Gets or sets the Usage.
        /// </summary>
        /// <value> manual utility value usage.</value>
        public double Usage { get; set; }

        /// <summary>
        ///     Gets or sets the MaxValueLimit.
        /// </summary>
        /// <value> Max Value Limit.</value>
        public long MaxValueLimit { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime.
        /// </summary>
        /// <value>The Parameter LastSyncTime.</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets the MyServiceMeterGuid
        /// </summary>
        /// <value>The Parameter MyServiceMeterGuid.</value>
        public Guid MyServiceMeterGuid { get; set; }
    }
}