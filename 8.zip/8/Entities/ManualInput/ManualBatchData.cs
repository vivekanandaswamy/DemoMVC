﻿// -----------------------------------------------------------------------
// <copyright file="ManualBatchData.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ManualBatchData </summary>
// -----------------------------------------------------------------------

namespace Entities.ManualInput
{
    using System;

    /// <summary>
    ///     Entity class for ManualBatchData
    /// </summary>
    public class ManualBatchData : BaseEntity
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="batchId">The Parameter Batch Id</param>
        /// <param name="startDate">The Parameter Start Date</param>
        /// <param name="startTime">The Parameter Start Time</param>
        /// <param name="recordingValue">The Parameter Recording Value</param>
        public ManualBatchData(int batchId, DateTime startDate, TimeSpan startTime, decimal recordingValue)
        {
            this.Id = batchId;
            this.StartDate = startDate;
            this.StartTime = startTime;
            this.RecordingValue = (double)recordingValue;
        }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="batchId">The Parameter Batch Id</param>
        /// <param name="startDate">The start date.</param>
        /// <param name="actualWeight">The actual weight.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="formulName">Name of the formul.</param>
        /// <param name="totalRows">The total rows.</param>
        /// <param name="ecolabWasherId">The ecolab washer identifier.</param>
        public ManualBatchData(int batchId, DateTime startDate, int actualWeight, int programId, string formulName, int totalRows,int ecolabWasherId)
        {
            this.Id = batchId;
			this.StartDate = startDate;
			this.ActualWeight = actualWeight;
			this.ProgramId = programId;
			this.FormulaName = formulName;
            this.TotalRows = totalRows;
            this.EcolabWasherId = ecolabWasherId;
        }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="startDate">The start date.</param>
        /// <param name="startTime">The Parameter Start Time</param>
        public ManualBatchData(DateTime startDate, TimeSpan startTime)
        {
            this.StartDate = startDate;
            this.StartTime = startTime;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ManualBatchData()
        {
        }

        /// <summary>
        ///     Gets or sets the StartDate.
        /// </summary>
        /// <value> Start Date. </value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets the StartTime.
        /// </summary>
        /// <value> Start Time. </value>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        ///     Gets or sets the ActualLoad.
        /// </summary>
        /// <value> Actual Load . </value>
        public double RecordingValue { get; set; }

		/// <summary>
		/// Gets or sets ActualWeight
		/// </summary>
		/// <value>ActualWeight</value>
		public int ActualWeight { get; set; }

		/// <summary>
		/// Gets or sets ProgramId
		/// </summary>
		/// <value>Program Id.</value>
		public int ProgramId { get; set; }

		/// <summary>
		/// Gets or sets the formula name	
		/// </summary>
		/// <value>FormulaName</value>
		public string FormulaName { get; set; }

		/// <summary>
		/// Gets or sets the StartDate
		/// </summary>
		/// <value>StartDate</value>
		public string BatchStartDate { get; set; }

        /// <summary>
        /// Gets or sets the TotalRows
        /// </summary>
        /// <value>TotalRows</value>
        public int TotalRows { get; set; }

        /// <summary>
        /// Gets or sets the EcolabWasherId
        /// </summary>
        /// <value>EcolabWasherId</value>
        public int EcolabWasherId { get; set; }

    }
}