﻿// -----------------------------------------------------------------------
// <copyright file="ManualProduction.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Manual Production</summary>
// -----------------------------------------------------------------------

namespace Entities.ManualInput.ProductData
{
    using System;

    /// <summary>
    ///     Entity class for MIProduction
    /// </summary>
    public class ManualProduction : BaseEntity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ManualProduction"/> class.
        /// </summary>
        /// <param name="productionId">The production identifier.</param>
        /// <param name="formulaId">The formula identifier.</param>
        /// <param name="recordedDate">The recorded date.</param>
        /// <param name="value">The value.</param>
        /// <param name="formulaName">Name of the formula.</param>
        /// <param name="totalRows">The total rows.</param>
        public ManualProduction(int productionId, int formulaId, DateTime recordedDate, decimal value, string formulaName, int totalRows)
        {
            this.ProductionId = productionId;
            this.FormulaId = formulaId;
            this.FormulaName = formulaName;
            this.RecordedDate = recordedDate;
            this.Value = (double)value;
            this.TotalRows = totalRows;
        }

        //public ManualProduction(int batchId, DateTime startDate, int actualWeight, int programId, string formulName)
        //{
        //    this.Id = batchId;
        //    this.StartDate = startDate;
        //    this.ActualWeight = actualWeight;
        //    this.ProgramId = programId;
        //    this.FormulaName = formulName;
        //}

        /// <summary>
        ///     default constructor
        /// </summary>
        public ManualProduction()
        {
        }

        /// <summary>
        /// Gets or sets the TotalRows
        /// </summary>
        /// <value>TotalRows</value>
        public int TotalRows { get; set; }

        /// <summary>
        ///     Gets or sets the productionId.
        /// </summary>
        /// <value> Parameter production Id. </value>
        public int ProductionId { get; set; }
        /// <summary>
        ///     Gets or sets the WasherGroupId.
        /// </summary>
        /// <value> Parameter Washer Group Id. </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherId.
        /// </summary>
        /// <value> Parameter WasherId. </value>
        public int WasherId { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaId.
        /// </summary>
        /// <value> Parameter Formula Id. </value>
        public int FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets the RecordedDate.
        /// </summary>
        /// <value> Parameter Recorded Date. </value>
        public DateTime RecordedDate { get; set; }

        /// <summary>
        ///     Gets or sets the Value.
        /// </summary>
        /// <value> Parameter Value. </value>
        public double Value { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> Parameter Value. </value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the StartDate.
        /// </summary>
        /// <value> Parameter Value. </value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets the Formula Name.
        /// </summary>
        /// <value> Formula Name. </value>
        public string FormulaName { get; set; }
    }
}