﻿// -----------------------------------------------------------------------
// <copyright file="ManualRewash.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  fetching the values and saving the values.</summary>
// -----------------------------------------------------------------------

namespace Entities.ManualInput.Rewash
{
    using System;

    /// <summary>
    ///     Entity class for ManualRewash
    /// </summary>
    public class ManualRewash : BaseEntity
    {
        /// <summary>
        ///     Manual Rewash Constructor
        /// </summary>
        /// <param name="rewashId">The Parameter Rewash Id</param>
        /// <param name="recordedDate">The Parameter Recorded Date</param>
        /// <param name="value">The Parameter Value</param>
        public ManualRewash(int rewashId, DateTime recordedDate, decimal value)
        {
            this.Id = rewashId;
            this.RecordedDate = recordedDate;
            this.Value = (double)value;
        }

        /// <summary>
        /// Manual Rewash Constructor
        /// </summary>
        /// <param name="rewashId">The Parameter Rewash Id</param>
        /// <param name="recordedDate">The Parameter Recorded Date</param>
        /// <param name="formulaId">The Parameter Formula Id</param>
        /// <param name="rewashReasonId">The Parameter Rewash Reason Id</param>
        /// <param name="value">The Parameter Value</param>

        public ManualRewash(int rewashId, DateTime recordedDate, int formulaId, int rewashReasonId, decimal value)
        {
            this.Id = rewashId;
            this.RecordedDate = recordedDate;
            this.FormulaId = formulaId;
            this.RewashReasonId = rewashReasonId;
            this.Value = (double)value;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public ManualRewash()
        {
        }

        /// <summary>
        ///     Gets or sets the WasherGroupId.
        /// </summary>
        /// <value> Washer Group Id. </value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the FormulaId.
        /// </summary>
        /// <value>The Parameter  Formula Id. </value>
        public int FormulaId { get; set; }

        /// <summary>
        ///     Gets or sets the RewashReasonId.
        /// </summary>
        /// <value> RewashReasonId. </value>
        public int RewashReasonId { get; set; }

        /// <summary>
        ///     Gets or sets the RecordedDate.
        /// </summary>
        /// <value>The Parameter  Recorded Date. </value>
        public DateTime RecordedDate { get; set; }

        /// <summary>
        ///     Gets or sets the Value.
        /// </summary>
        /// <value>The Parameter  Value. </value>
        public double Value { get; set; }
    }
}