﻿// -----------------------------------------------------------------------
// <copyright file="RewashProduct.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RewashProduct </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.ManualInput.Rewash
{
    public class RewashProduct
    {
        public RewashProduct(int rewashId , int productId , decimal qty , decimal price, int totalrewashLoad, int custId , DateTime date)
        {
            RewashId = rewashId;
            ProductId = productId;
            Qunatity = qty;
            Price = price;
            TotalRewashLoad = totalrewashLoad;
            CustomerId = custId;
            Date = date;
        }

        public int RewashId { get; set; }

        public int ProductId { get; set; }

        public Decimal Qunatity { get; set; }

        public Decimal Price { get; set; }

        public int TotalRewashLoad { get; set; }

        public int CustomerId { get; set; }

        public DateTime Date { get; set; }
    }
}
