﻿// -----------------------------------------------------------------------
// <copyright file="RewashReason.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  fetching the values and saving the values.</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities.ManualInput.Rewash
{
    /// <summary>
    ///     Entity class for RewashReason
    /// </summary>
    public class RewashReason
    {
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="rewashReasonId"> rewash reason id</param>
        /// <param name="description"> rewash description </param>
        public RewashReason(int rewashReasonId, string description)
        {
            this.RewashReasonId = rewashReasonId;
            this.Description = description;
        }

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="rewashReasonId"> rewash reason id</param>
        /// <param name="description"> rewash description </param>
        public RewashReason(int rewashReasonId, string description, bool isDeleted, DateTime lastModifiedTime, DateTime lastSyncTime)
        {
            this.RewashReasonId = rewashReasonId;
            this.Description = description;
            this.LastModified = lastModifiedTime;
            this.LastSync = lastSyncTime;
            this.IsDeleted = isDeleted;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public RewashReason()
        {
        }

        /// <summary>
        ///     Gets or sets the RewashReasonId.
        /// </summary>
        /// <value> rewash reason id.</value>
        public int RewashReasonId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> rewash description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets IsDeleted
        /// </summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets LastModified
        /// </summary>
        public DateTime LastModified { get; set; }

        /// <summary>
        /// Gets or sets LastSync
        /// </summary>
        public DateTime? LastSync { get; set; }
    }
}