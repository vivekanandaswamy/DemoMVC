﻿// -----------------------------------------------------------------------
// <copyright file="GroupType.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The GroupType class </summary>
// -----------------------------------------------------------------------

namespace Entities.ManualInput
{
    /// <summary>
    ///     Entity class for GroupType
    /// </summary>
    public class GroupType
    {
        /// <summary>
        ///     Parameterized constructor.
        /// </summary>
        /// <param name="groupTypeId">The Parameter Group Type Id</param>
        /// <param name="groupDescription">The Parameter group Description</param>
        public GroupType(int groupTypeId, string groupDescription)
        {
            this.GroupTypeId = groupTypeId;
            this.GroupDescription = groupDescription;
        }

        /// <summary>
        ///     default constructor.
        /// </summary>
        public GroupType()
        {
        }

        /// <summary>
        ///     Gets or sets the GroupTypeID.
        /// </summary>
        /// <value> Group Type ID.</value>
        public int GroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupDescription.
        /// </summary>
        /// <value> Group Description.</value>
        public string GroupDescription { get; set; }
    }
}