﻿// -----------------------------------------------------------------------
// <copyright file="Alarm.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Alarm object</summary>
// -----------------------------------------------------------------------

using System;
namespace Entities
{
    /// <summary>
    ///     Entity class for Alarm
    /// </summary>
    public class Alarm : BaseEntity
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="startDate">Alarm StartDate</param>
        /// <param name="alarmCode">The alarm code.</param>
        /// <param name="machineName">machineName</param>
        /// <param name="alarmDescription">Alarm Description</param>
        public Alarm(string startDate, int alarmCode, string machineName, string alarmDescription)
        {
            this.StartDateFormatted = (Convert.ToDateTime(startDate).ToLocalTime()).ToString();
            this.Id = alarmCode;
            this.MachineName = machineName;
            this.AlarmDescription = alarmDescription;
        }

        /// <summary>
        /// Parameterized constructor for Alarm Sync
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="ecoalabAccountNumber">The ecoalab account number.</param>
        /// <param name="alarmCode">The alarm code.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="startDate">Alarm StartDate</param>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="machineInternalId">The machine internal identifier.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="menumber">The m e number.</param>
        /// <param name="batchId">The batch identifier.</param>
        /// <param name="valve">The valve.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <param name="machineId">The machine identifier.</param>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="endDate">The end date.</param>
        /// <param name="desiredQuatity">The desired quatity.</param>
        /// <param name="measuredQuantity">The measured quantity.</param>
        /// <param name="tempStatus">The temporary status.</param>
        /// <param name="probeNumber">The probe number.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="stepId">The step identifier.</param>
        public Alarm(int id, string ecoalabAccountNumber, int alarmCode, int controllerId, DateTime startDate, int groupId, int machineInternalId, int programId, int menumber, int batchId, int valve, int injectionNumber, int machineId, bool isActive, DateTime endDate, int desiredQuatity, int measuredQuantity, int tempStatus, int probeNumber, int userId, string stepId)
        {
            this.Id = id;
            this.EcoalabAccountNumber = ecoalabAccountNumber;
            this.EcolabAccountNumber = ecoalabAccountNumber;
            this.AlarmCode = alarmCode;
            this.ControllerId = controllerId;
            this.StartDate = startDate;
            this.GroupId = groupId;
            this.MachineInternalId = machineInternalId;
            this.ProgramId = programId;
            this.MENumber = menumber;
            this.BatchId = batchId;
            this.Valve = valve;
            this.InjectionNumber = injectionNumber;
            this.MachineId = machineId;
            this.IsActive = isActive;
            this.EndDate = endDate;
            this.DesiredQuatity = desiredQuatity;
            this.MeasuredQuantity = measuredQuantity;
            this.TempStatus = tempStatus;
            this.ProbeNumber = probeNumber;
            this.UserId = userId;
            this.StepId = stepId;
        }

        /// <summary>
        /// Parameterized constructor for Alarm Sync
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="ecoalabAccountNumber">The ecoalab account number.</param>
        /// <param name="alarmCode">The alarm code.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="startDate">Alarm StartDate</param>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="machineInternalId">The machine internal identifier.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="menumber">The m e number.</param>
        /// <param name="batchId">The batch identifier.</param>
        /// <param name="valve">The valve.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <param name="machineId">The machine identifier.</param>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="endDate">The end date.</param>
        /// <param name="desiredQuatity">The desired quatity.</param>
        /// <param name="measuredQuantity">The measured quantity.</param>
        /// <param name="tempStatus">The temporary status.</param>
        /// <param name="probeNumber">The probe number.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="stepId">The step identifier.</param>
        /// <param name="partitionOn">The partition on.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        public Alarm(int id, string ecoalabAccountNumber, int alarmCode, int controllerId, DateTime startDate, int groupId, int machineInternalId, int programId,
             int menumber, int batchId, int valve, int injectionNumber, int machineId, bool isActive, DateTime endDate, int desiredQuatity, int measuredQuantity,
             int tempStatus, int probeNumber, int userId, string stepId, DateTime partitionOn, DateTime lastSyncTime)
        {
            this.Id = id;
            this.EcoalabAccountNumber = ecoalabAccountNumber;
            this.EcolabAccountNumber = ecoalabAccountNumber;
            this.AlarmCode = alarmCode;
            this.ControllerId = controllerId;
            this.StartDate = startDate;
            this.GroupId = groupId;
            this.MachineInternalId = machineInternalId;
            this.ProgramId = programId;
            this.MENumber = menumber;
            this.BatchId = batchId;
            this.Valve = valve;
            this.InjectionNumber = injectionNumber;
            this.MachineId = machineId;
            this.IsActive = isActive;
            this.EndDate = endDate;
            this.DesiredQuatity = desiredQuatity;
            this.MeasuredQuantity = measuredQuantity;
            this.TempStatus = tempStatus;
            this.ProbeNumber = probeNumber;
            this.UserId = userId;
            this.StepId = stepId;
            this.PartitionOn = partitionOn;
            this.LastSyncTime = lastSyncTime;
        }

        /// <summary>
        /// Parameterized constructor for Alarm Sync
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="ecoalabAccountNumber">The ecoalab account number.</param>
        /// <param name="alarmCode">The alarm code.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="startDate">Alarm StartDate</param>
        /// <param name="groupId">The group identifier.</param>
        /// <param name="machineInternalId">The machine internal identifier.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="menumber">The m e number.</param>
        /// <param name="batchId">The batch identifier.</param>
        /// <param name="valve">The valve.</param>
        /// <param name="injectionNumber">The injection number.</param>
        /// <param name="machineId">The machine identifier.</param>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="endDate">The end date.</param>
        /// <param name="desiredQuatity">The desired quatity.</param>
        /// <param name="measuredQuantity">The measured quantity.</param>
        /// <param name="tempStatus">The temporary status.</param>
        /// <param name="probeNumber">The probe number.</param>
        /// <param name="userId">The user identifier.</param>
        /// <param name="stepId">The step identifier.</param>
        /// <param name="partitionOn">The partition on.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="alarmGroupMasterId">The alarm group master identifier.</param>
        public Alarm(int id, string ecoalabAccountNumber, int alarmCode, int controllerId, DateTime startDate, int groupId, int machineInternalId, int programId,
             int menumber, int batchId, int valve, int injectionNumber, int machineId, bool isActive, DateTime endDate, int desiredQuatity, int measuredQuantity,
             int tempStatus, int probeNumber, int userId, string stepId, DateTime partitionOn, DateTime lastSyncTime, int alarmGroupMasterId)
        {
            this.Id = id;
            this.EcoalabAccountNumber = ecoalabAccountNumber;
            this.EcolabAccountNumber = ecoalabAccountNumber;
            this.AlarmCode = alarmCode;
            this.ControllerId = controllerId;
            this.StartDate = startDate;
            this.GroupId = groupId;
            this.MachineInternalId = machineInternalId;
            this.ProgramId = programId;
            this.MENumber = menumber;
            this.BatchId = batchId;
            this.Valve = valve;
            this.InjectionNumber = injectionNumber;
            this.MachineId = machineId;
            this.IsActive = isActive;
            this.EndDate = endDate;
            this.DesiredQuatity = desiredQuatity;
            this.MeasuredQuantity = measuredQuantity;
            this.TempStatus = tempStatus;
            this.ProbeNumber = probeNumber;
            this.UserId = userId;
            this.StepId = stepId;
            this.PartitionOn = partitionOn;
            this.LastSyncTime = lastSyncTime;
            this.AlarmGroupMasterId = alarmGroupMasterId;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public Alarm()
        {
        }

        /// <summary>
        ///     Gets or sets the StartDate
        /// </summary>
        /// <value>start date</value>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///     Gets or sets the StartDate
        /// </summary>
        /// <value>start date</value>
        public string StartDateFormatted { get; set; }

        /// <summary>
        ///     Gets or sets the MachineName
        /// </summary>
        /// <value>Machine Name</value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmDescription
        /// </summary>
        /// <value>AlarmDescription</value>
        public string AlarmDescription { get; set; }
        /// <summary>
        ///     Gets or sets the StartDate
        /// </summary>
        /// <value>start date</value>
        public int AlarmCode { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerId
        /// </summary>
        /// <value>ControllerId</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId
        /// </summary>
        /// <value>GroupId</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineInternalId
        /// </summary>
        /// <value>MachineInternalId</value>
        public int MachineInternalId { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramId
        /// </summary>
        /// <value>ProgramId</value>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the MENumber
        /// </summary>
        /// <value>MENumber</value>
        public int MENumber { get; set; }

        /// <summary>
        ///     Gets or sets the BatchId
        /// </summary>
        /// <value>BatchId</value>
        public int BatchId { get; set; }

        /// <summary>
        ///     Gets or sets the Valve
        /// </summary>
        /// <value>Valve</value>
        public int Valve { get; set; }

        /// <summary>
        ///     Gets or sets the InjectionNumber
        /// </summary>
        /// <value>InjectionNumber</value>
        public int InjectionNumber { get; set; }

        /// <summary>
        ///     Gets or sets the MachineId
        /// </summary>
        /// <value>MachineId</value>
        public int MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the IsActive
        /// </summary>
        /// <value>IsActive</value>
        public bool IsActive { get; set; }

        /// <summary>
        ///     Gets or sets the EndDate
        /// </summary>
        /// <value>EndDate</value>
        public DateTime EndDate { get; set; }

        /// <summary>
        ///     Gets or sets the DesiredQuatity
        /// </summary>
        /// <value>DesiredQuatity</value>
        public int DesiredQuatity { get; set; }

        /// <summary>
        ///     Gets or sets the MeasuredQuantity
        /// </summary>
        /// <value>MeasuredQuantity</value>
        public int MeasuredQuantity { get; set; }

        /// <summary>
        ///     Gets or sets the TempStatus
        /// </summary>
        /// <value>TempStatus</value>
        public int TempStatus { get; set; }

        /// <summary>
        ///     Gets or sets the ProbeNumber
        /// </summary>
        /// <value>ProbeNumber</value>
        public int ProbeNumber { get; set; }

        /// <summary>
        ///     Gets or sets the UserId
        /// </summary>
        /// <value>UserId</value>
        public int UserId { get; set; }

        /// <summary>
        ///     Gets or sets the StepId
        /// </summary>
        /// <value>StepId</value>
        public string StepId { get; set; }

        /// <summary>
        ///     Gets or sets the PatitionOn
        /// </summary>
        /// <value>PartitionOn</value>
        public DateTime PartitionOn { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcoalabAccountNumber { get; set; }
        /// <summary>
        /// Gets or Sets the AlarmGroupMasterId.
        /// </summary>
        /// <value>The AlarmGroupMasterId.</value>
        public int AlarmGroupMasterId { get; set; }
    }
}