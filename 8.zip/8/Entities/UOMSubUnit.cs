﻿// -----------------------------------------------------------------------
// <copyright file="UOMSubUnit.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The UOMSubUnit object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     Entity class for UOMSubUnit
    /// </summary>
    public class UOMSubUnit
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="unitSystemId">The unit system identifier.</param>
        /// <param name="usageKey">The usage key.</param>
        /// <param name="unit">The unit.</param>
        /// <param name="subunit_Source">The sub unit_ source.</param>
        /// <param name="subunit_Target">The subunit_ target.</param>
        public UOMSubUnit(int unitSystemId, string usageKey, string unit, string subunit_Source,string subunit_Target)
        {
            this.UnitSystemId = unitSystemId;
            this.UsageKey = usageKey;
            this.Unit = unit;
            this.SubunitSource = subunit_Source;
            this.SubunitTarget = subunit_Target;
        }

        /// <summary>
        ///     default constructor
        /// </summary>
        public UOMSubUnit()
        {
        }

        /// <summary>
        ///     Gets or sets the UnitSystemId
        /// </summary>
        /// <value>UnitSystemId</value>
        public int UnitSystemId { get; set; }

        /// <summary>
        ///     Gets or sets the UsageKey 
        /// </summary>
        /// <value>UsageKey </value>
        public string UsageKey { get; set; }

        /// <summary>
        ///     Gets or sets the Unit 
        /// </summary>
        /// <value>Unit </value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit_Source
        /// </summary>
        /// <value>SubUnit_Source</value>
        public string SubunitSource { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit_Target
        /// </summary>
        /// <value>SubUnit_Target</value>
        public string SubunitTarget { get; set; }
    }
}