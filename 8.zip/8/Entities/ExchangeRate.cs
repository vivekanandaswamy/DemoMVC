﻿// -----------------------------------------------------------------------
// <copyright file="ExchangeRate.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Exchange Rate </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System;
    public class ExchangeRate
    {
        /// <summary>
        /// constructor ExchangeRate
        /// </summary>
        /// <param name="exchangeRateId">The exchange RateId .</param>
        /// <param name="currencyCode">The currency code.</param>
        /// <param name="rate">The rate.</param>
        /// <param name="targetCurrencyCode">The target currency code.</param>
        /// <param name="effectiveExchangeRateDate">The effective exchange rate date.</param>
        /// <param name="createdDate">The created date.</param>
        public ExchangeRate(int exchangeRateId, string currencyCode, double rate, string targetCurrencyCode, DateTime effectiveExchangeRateDate, DateTime createdDate)
        {
            this.ExchangeRateId = exchangeRateId;
            this.CurrencyCode = currencyCode;
            this.Rate = rate;
            this.TargetCurrencyCode = targetCurrencyCode;
            this.EffectiveExchangeRateDate = effectiveExchangeRateDate;
            this.CreatedDate = createdDate;
        }

        /// <summary>
        ///     default constructor ExchangeRate
        /// </summary>
        public ExchangeRate()
        {
        }

        /// <summary>
        ///     Gets or sets ExchangeRate Id
        /// </summary>
        /// <value>The ExchangeRate Id .</value>
        public int ExchangeRateId { get; set; }

        /// <summary>
        ///     Gets or sets CurrencyCode
        /// </summary>
        /// <value>The CurrencyCode .</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets Rate
        /// </summary>
        /// <value>The Rate .</value>
        public double Rate { get; set; }

        /// <summary>
        ///     Gets or sets TargetCurrencyCode
        /// </summary>
        /// <value>The TargetCurrencyCode .</value>
        public string TargetCurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets EffectiveExchangeRateDate
        /// </summary>
        /// <value>The EffectiveExchangeRateDate .</value>
        public DateTime EffectiveExchangeRateDate { get; set; }

        /// <summary>
        ///     Gets or sets CreatedDate
        /// </summary>
        /// <value>The CreatedDate .</value>
        public DateTime CreatedDate { get; set; }
    }
}
