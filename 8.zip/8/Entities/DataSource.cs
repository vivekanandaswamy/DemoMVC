// -----------------------------------------------------------------------
// <copyright file="DataSource.cs" company="Ecolab">
// �2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DataSource object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    using System.Collections.Generic;

    /// <summary>
    ///     Class DataSource
    /// </summary>
    public class DataSource
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="DataSource" /> class.
        /// </summary>
        public DataSource()
        {
            this.Fields = new List<Field>();
            this.FieldSources = new List<FieldSource>();
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="DataSource" /> class.
        /// </summary>
        /// <param name="id">The id. field</param>
        /// <param name="name">The name. field</param>
        /// <param name="description">The description.</param>
        public DataSource(int id, string name, string description)
        {
            this.Id = id;
            this.Name = name;
            this.Description = description;
        }

        /// <summary>
        ///     Gets or sets the id.
        /// </summary>
        /// <value>The id. field</value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name. field</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the fields.
        /// </summary>
        /// <value>The fields.</value>
        public List<Field> Fields { get; set; }

        /// <summary>
        ///     Gets or sets the field sources.
        /// </summary>
        /// <value>The field sources.</value>
        public List<FieldSource> FieldSources { get; set; }
    }
}