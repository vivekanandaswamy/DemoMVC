﻿// -----------------------------------------------------------------------
// <copyright file="ChainTextileCategory.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chain Textile Category </summary>
// -----------------------------------------------------------------------

using System;
namespace Entities
{
    public class ChainTextileCategory
    {
        /// <summary>
        /// constructor ChainTextileCategory
        /// </summary>
        /// <param name="textileId">The textile Id .</param>
        /// <param name="name">The name.</param>
        /// <param name="plantChainId">The plant chain identifier.</param>
        /// <param name="isDeleted">if set to <c>true</c> [is deleted].</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="resourceKey">The resource key.</param>
        public ChainTextileCategory(int textileId, string name, int plantChainId, bool isDeleted, DateTime lastModifiedTime, string resourceKey)
        {
            this.TextileId = textileId;
            this.Name = name;
            this.ChainId = plantChainId;
            this.IsDeleted = isDeleted;
            this.LastModifiedTime = DateTime.SpecifyKind(lastModifiedTime, DateTimeKind.Utc);
            this.ResourceKey = resourceKey;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChainTextileCategory"/> class.
        /// </summary>
        /// <param name="textileId">The textile identifier.</param>
        /// <param name="name">The name.</param>
        public ChainTextileCategory(int textileId, string name)
        {
            this.TextileId = textileId;
            this.Name = name;
        }

        /// <summary>
        ///     default constructor ChainTextileCategory
        /// </summary>
        public ChainTextileCategory()
        {
        }

        /// <summary>
        /// Chain Textile category
        /// </summary>
        /// <param name="textileId">textileId</param>
        /// <param name="name">name</param>
        /// <param name="ecolabSaturationId">ecolabSaturationId</param>
        /// <param name="chainId">chainId</param>
        /// <param name="isDeleted">isDeleted</param>
        /// <param name="lastModifiedTime">lastModifiedTime</param>
        public ChainTextileCategory(int textileId, string name, int ecolabSaturationId, int chainId, bool isDeleted, DateTime lastModifiedTime)
	    {
		    this.TextileId = textileId;
		    this.Name = name;
		    this.EcolabSaturationId = ecolabSaturationId;
		    this.ChainId = chainId;
		    this.IsDeleted = isDeleted;
		    this.LastModifiedTime = lastModifiedTime;
	    }

	    /// <summary>
        ///     Gets or sets Textile Id
        /// </summary>
        /// <value>The Textile Id .</value>
        public int TextileId { get; set; }

        /// <summary>
        ///     Gets or sets Name
        /// </summary>
        /// <value>The textile Name .</value>
        public string Name { get; set; }

        /// <summary>
        /// flag for reason deleted or not
        /// </summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets ChainId
        /// </summary>
        /// <value>The Parameter ChainId.</value>
        public int ChainId { get; set; }

        /// <summary>
        ///     Gets or sets LastModifiedTime
        /// </summary>
        /// <value>The Parameter LastModifiedTime.</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets LastSyncTime
        /// </summary>
        /// <value>The Parameter LastSyncTime.</value>
        public DateTime LastSyncTime { get; set; }

		/// <summary>
		/// Gets or sets the EcolabSaturationid
		/// </summary>
		/// <value>EcolabSaturationId</value>
	    public int EcolabSaturationId { get; set; }

        /// <summary>
        /// Gets or sets the ResourceKey
        /// </summary>
        /// <value>ResourceKey</value>
        public string ResourceKey { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is active.
        /// </summary>
        /// <value>IsActive</value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance TextileSaturation.
        /// </summary>
        /// <value>TextileSaturation</value>
        public int TextileSaturation { get; set; }
    }
}