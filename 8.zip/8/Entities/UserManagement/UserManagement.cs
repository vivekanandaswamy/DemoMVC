﻿// -----------------------------------------------------------------------
// <copyright file="UserManagement.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Access </summary>
// -----------------------------------------------------------------------

namespace Entities.UserManagement
{
    using System;

    /// <summary>
    ///     Class UserManagement
    /// </summary>
    public class UserManagement
    {
        #region Constructor

        /// <summary>
        ///     default constructor
        /// </summary>
        public UserManagement()
        {
        }

        /// <summary>
        /// UserManagement parameterized constructor
        /// </summary>
        /// <param name="userNumber">Parameter User Id</param>
        /// <param name="firstName">Parameter First Name</param>
        /// <param name="lastName">Parameter Last Name</param>
        /// <param name="loginName">Parameter Login Name</param>
        /// <param name="password">Parameter Password</param>
        /// <param name="email">Parameter Email</param>
        /// <param name="contactNo">Parameter ContactNo</param>
        /// <param name="levelId">Parameter LevelId</param>
        /// <param name="languageId">Parameter language id</param>
        /// <param name="languageName">Parameter ILanguage name</param>
        /// <param name="roleName">The role name of UserManagement.</param>
        /// <param name="ecolabAccountNumber">The Parameter Ecolab Account Number</param>
        /// <param name="title">The Parameter title.</param>
        /// <param name="mobile">The Parameter mobile.</param>
        /// <param name="fax">The Parameter fax .</param>
        /// <param name="contactId">Mapped Contact Id</param>
        /// <param name="uomId">The uom identifier.</param>
        /// <param name="currencyCode">The currency code.</param>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        public UserManagement(int userNumber, string firstName, string lastName, string loginName, string password, string email, string contactNo, int levelId, int languageId, string languageName, string roleName, string ecolabAccountNumber, string title, string mobile, string fax, int? contactId, int? uomId, string currencyCode, bool isActive, DateTime lastModifiedTime, DateTime lastSyncTime)
        {
            this.UserNumber = userNumber;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.LoginName = loginName;
            this.Password = password;
            this.Email = email;
            this.ContactNo = contactNo;
            this.LevelId = levelId;
            this.LanguageId = languageId;
            this.LanguageName = languageName;
            this.RoleName = roleName;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.Title = title;
            this.Mobile = mobile;
            this.Fax = fax;
            this.ContactId = contactId;
            this.UOMId = uomId;
            this.CurrencyCode = currencyCode;
            this.IsActive = isActive;
            this.LastModifiedTime = lastModifiedTime;
            this.LastSyncTime = lastSyncTime;
        }

        /// <summary>
        /// UserManagement parameterized constructor
        /// </summary>
        /// <param name="userNumber">Parameter UserId</param>
        /// <param name="firstName">Parameter FirstName</param>
        /// <param name="lastName">Parameter LastName</param>
        /// <param name="loginName">Parameter LoginName</param>
        /// <param name="password">Parameter Password</param>
        /// <param name="email">Parameter Email</param>
        /// <param name="contactNo">Parameter ContactNo</param>
        /// <param name="levelId">Parameter LevelId</param>
        /// <param name="languageId">Parameter language id</param>
        /// <param name="languageName">Parameter ILanguage name</param>
        /// <param name="roleName">The role name.</param>
        /// <param name="ecolabAccountNumber">The Parameter Ecolab Account Number</param>
        /// <param name="title">The Parameter title.</param>
        /// <param name="mobile">The Parameter mobile.</param>
        /// <param name="fax">The Parameter fax .</param>
        /// <param name="contactId">Mapped Contact Id</param>
        /// <param name="uomId">The uom identifier.</param>
        /// <param name="currencyCode">The currency code.</param>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="lastModifiedTime">The last modified time.</param>
        /// <param name="lastSyncTime">The last synchronize time.</param>
        /// <param name="maxLevel">Mapped Contact Id</param>
        public UserManagement(int userNumber, string firstName, string lastName, string loginName, string password, string email, string contactNo, int levelId, int languageId, string languageName, string roleName, string ecolabAccountNumber, string title, string mobile, string fax, int? contactId, int? uomId, string currencyCode, bool isActive, DateTime lastModifiedTime, DateTime lastSyncTime, int maxLevel)
        {
            this.UserNumber = userNumber;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.LoginName = loginName;
            this.Password = password;
            this.Email = email;
            this.ContactNo = contactNo;
            this.LevelId = levelId;
            this.LanguageId = languageId;
            this.LanguageName = languageName;
            this.RoleName = roleName;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.Title = title;
            this.Mobile = mobile;
            this.Fax = fax;
            this.ContactId = contactId;
            this.UOMId = uomId;
            this.CurrencyCode = currencyCode;
            this.IsActive = isActive;
            this.LastModifiedTime = lastModifiedTime;
            this.LastSyncTime = lastSyncTime;
            this.MaxLevel = maxLevel;
        }

        #endregion

        #region Properties

        /// <summary>
        ///     Gets or sets UserId
        /// </summary>
        /// <value> Parameter UserNumber</value>
        public int UserNumber { get; set; }

        /// <summary>
        ///     Gets or sets FirstName
        /// </summary>
        /// <value> Parameter First Name</value>
        public string FirstName { get; set; }

        /// <summary>
        ///     Gets or sets LastName
        /// </summary>
        /// <value> Parameter Last Name</value>
        public string LastName { get; set; }

        /// <summary>
        ///     Gets or sets LoginName
        /// </summary>
        /// <value> Parameter LoginName</value>
        public string LoginName { get; set; }

        /// <summary>
        ///     Gets or sets Password
        /// </summary>
        /// <value> Parameter LoginName</value>
        public string Password { get; set; }

        /// <summary>
        ///     Gets or sets Email
        /// </summary>
        /// <value> Parameter Email</value>
        public string Email { get; set; }

        /// <summary>
        ///     Gets or sets ContactNo
        /// </summary>
        /// <value> Parameter Contact Number</value>
        public string ContactNo { get; set; }

        /// <summary>
        ///     Gets or sets LevelId
        /// </summary>
        /// <value> Parameter Level Id</value>
        public int LevelId { get; set; }

        /// <summary>
        ///     Gets or sets LanguageId
        /// </summary>
        /// <value> Parameter Language Id</value>
        public int LanguageId { get; set; }

        /// <summary>
        ///     Gets or sets LanguageName
        /// </summary>
        /// <value> Parameter Language Name</value>
        public string LanguageName { get; set; }

        /// <summary>
        ///     Gets or sets RoleName
        /// </summary>
        /// <value> Parameter RoleName</value>
        public string RoleName { get; set; }

        /// <summary>
        ///     Gets or sets EcolabAccountNumber
        /// </summary>
        /// <value> Parameter EcolabAccountNumber</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets Title
        /// </summary>
        /// <value> Parameter Title</value>
        public string Title { get; set; }

        /// <summary>
        ///     Gets or sets Mobile
        /// </summary>
        /// <value> Parameter Mobile Number</value>
        public string Mobile { get; set; }

        /// <summary>
        ///     Gets or sets Fax
        /// </summary>
        /// <value> Parameter Fax number</value>
        public string Fax { get; set; }

        /// <summary>
        ///     Gets or Sets the ContactId
        /// </summary>
        /// <value> Parameter Contact Id</value>
        public int? ContactId { get; set; }

        /// <summary>
        ///     Gets or sets the UOMId.
        /// </summary>
        /// <value> The UOM Id.</value>
        public int? UOMId { get; set; }

        /// <summary>
        ///     Gets or sets the CurrencyCode.
        /// </summary>
        /// <value> the Currency Code.</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        /// Gets or sets LastSyncTime 
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        /// Gets or sets IsActive
        /// </summary>
        /// <value>Isactive</value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Get or sets LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        /// Get or sets MaxLevel
        /// </summary>
        /// <value>MaxLevel</value>
        public int MaxLevel { get; set; }

        #endregion
    }
}