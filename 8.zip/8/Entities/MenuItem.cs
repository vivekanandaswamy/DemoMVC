﻿// -----------------------------------------------------------------------
// <copyright file="MenuItem.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The MenuItem object</summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     Class MenuItem
    /// </summary>
    public class MenuItem
    {
        /// <summary>
        ///     The Menu Items
        /// </summary>
        /// <param name="sectionId">The Section Id</param>
        /// <param name="sectionName">The _Section Name </param>
        /// <param name="sectionCode">The Section Code</param>
        /// <param name="sectionType">The Section Type</param>
        /// <param name="controllerName">The Controller Name</param>
        /// <param name="viewName">The View Name</param>
        /// <param name="resourceClass">The Resource Class</param>
        /// <param name="resourceKey">The Resource Key</param>
        /// <param name="parentId">The Parent ID</param>
        public MenuItem(int sectionId, string sectionName, string sectionCode, string sectionType, string controllerName, string viewName, string resourceClass, string resourceKey, int parentId)
        {
            this.SectionId = sectionId;
            this.SectionName = sectionName;
            this.SectionCode = sectionCode;
            this.SectionType = sectionType;
            this.ControllerName = controllerName;
            this.ViewName = viewName;
            this.ResourceClass = resourceClass;
            this.ResourceKey = resourceKey;
            this.ParentId = parentId;
        }

        /// <summary>
        ///     Gets or sets the Section ID.
        /// </summary>
        /// <value>The Section ID.</value>
        public int SectionId { get; set; }

        /// <summary>
        ///     Gets or sets the Section Name.
        /// </summary>
        /// <value>The Section Name.</value>
        public string SectionName { get; set; }

        /// <summary>
        ///     Gets or sets the Section Code.
        /// </summary>
        /// <value>The Section Code.</value>
        public string SectionCode { get; set; }

        /// <summary>
        ///     Gets or sets the Parent ID.
        /// </summary>
        /// <value>The Parent ID.</value>
        public int ParentId { get; set; }

        /// <summary>
        ///     Gets or sets the Section Type.
        /// </summary>
        /// <value>The Section Type.</value>
        public string SectionType { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Name.
        /// </summary>
        /// <value>The Controller Name.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the View Name.
        /// </summary>
        /// <value>The View Name.</value>
        public string ViewName { get; set; }

        /// <summary>
        ///     Gets or sets the Resource Class.
        /// </summary>
        /// <value>The Resource Class.</value>
        public string ResourceClass { get; set; }

        /// <summary>
        ///     Gets or sets the Resource Key.
        /// </summary>
        /// <value>The Resource Key.</value>
        public string ResourceKey { get; set; }
    }
}