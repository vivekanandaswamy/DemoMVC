﻿// -----------------------------------------------------------------------
// <copyright file="CurrencyMaster.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Currency Master </summary>
// -----------------------------------------------------------------------

namespace Entities
{
    /// <summary>
    ///     class CurrencyMaster
    /// </summary>
    public class CurrencyMaster
    {
        #region "Constructor"

        /// <summary>
        ///     constructor CurrencyMaster
        /// </summary>
        /// <param name="currencyCode">The CurrencyMaster currencyCode .</param>
        /// <param name="currencyName">The CurrencyMaster currencyName.</param>
        public CurrencyMaster(string currencyCode, string currencyName)
        {
            this.CurrencyCode = currencyCode;
            this.CurrencyName = currencyName;
        }

        /// <summary>
        ///     default constructor CurrencyMaster
        /// </summary>
        public CurrencyMaster()
        {
        }

        #endregion

        #region "Properties"

        /// <summary>
        ///     Gets or sets CurrencyCode
        /// </summary>
        /// <value>Currency Code.</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets CurrencyName
        /// </summary>
        /// <value>Currency Name.</value>
        public string CurrencyName { get; set; }

        #endregion
    }
}