﻿// -----------------------------------------------------------------------
// <copyright file="Tanks.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tanks object</summary>
// -----------------------------------------------------------------------

namespace Entities.StorageTanks
{
    using System;
    using System.Collections.Generic;
    using Common;

    /// <summary>
    ///     class Tanks
    /// </summary>
    public class Tanks
    {
        /// <summary>
        ///     Default Constructor
        /// </summary>
        public Tanks()
        {
        }

        /// <summary>
        ///     Parameterized Constructor
        /// </summary>
        /// <param name="tankId"> The Storage Tank Id</param>
        /// <param name="tankName">The Tank Name</param>
        /// <param name="lowLevel">Low Level of the tank</param>
        /// <param name="emptyLevel">Empty Level of the Tank</param>
        /// <param name="callibrationLevel">Callibration Level of the Tank</param>
        /// <param name="inputType">The Input Type</param>
        /// <param name="levelDeviation">The Level Deviation</param>
        /// <param name="size">The Size</param>
        /// <param name="controllerId">The Controller Id</param>
        /// <param name="controllerName">The Controller Name</param>
        /// <param name="productId">The Product Id</param>
        /// <param name="productName">The Product Name</param>
        /// <param name="currentLevelTag">The Current Level Tag</param>
        /// <param name="levelDeviationTag">The level deviation tag</param>
        /// <param name="sizeTag">The Size Tag</param>
        /// <param name="currentLevel">The Current Level</param>
        public Tanks(
            int tankId,
            string tankName,
            decimal lowLevel,
            decimal emptyLevel,
            decimal callibrationLevel,
            string inputType,
            decimal levelDeviation,
            decimal size,
            int controllerId,
            string controllerName,
            int productId,
            string productName,
            string currentLevelTag,
            string levelDeviationTag,
            string sizeTag,
            decimal currentLevel,
            DateTime lastModifiedTime,
            DateTime lastSyncTime,
            string ecolabAccountNumber,
            decimal lowAlarmLevel_Display,
        decimal emptyLevel_Display,
            decimal calibrationLevel_Display,
            decimal currentLevel_Display,
            decimal levelDeviation_Display,
            decimal size_Display,
            bool isDelete
            )
        {
            TankId = tankId;
            TankName = tankName;
            ControllerId = controllerId;
            ControllerName = controllerName;
            EmptyLevel = emptyLevel;
            LowLevel = lowLevel;
            CallibrationLevel = callibrationLevel;
            InputType = inputType;
            LevelDeviation = levelDeviation;
            Size = size;
            ProductId = productId;
            ProductName = productName;
            CurrentLevelTag = currentLevelTag;
            LevelDeviationTag = levelDeviationTag;
            SizeTag = sizeTag;
            CurrentLevel = currentLevel;
            LastModifiedTimestamp = lastModifiedTime;
            LastSyncTime = lastSyncTime;
            EcolabAccountNumber = ecolabAccountNumber;
            LowLevelDisplay = lowAlarmLevel_Display;
            EmptyLevelDisplay = emptyLevel_Display;
            CalibrationLevelDisplay = calibrationLevel_Display;
            CurrentLevelDisplay = currentLevel_Display;
            LevelDeviationDisplay = levelDeviation_Display;
            SizeDisplay = size_Display;
            IsDelete = isDelete;
        }

        /// <summary>
        ///     Gets or sets the Tank Id
        /// </summary>
        /// <value>The Parameter Tank Id</value>
        public int TankId { get; set; }

        /// <summary>
        ///     Gets or sets the Tank Name
        /// </summary>
        /// <value>The Parameter Tank Name</value>
        public string TankName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Id
        /// </summary>
        /// <value>The Parameter Controller Id</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Name
        /// </summary>
        /// <value>The Parameter Controller Name</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Empty Level
        /// </summary>
        /// <value>The Parameter Empty Level</value>
        public decimal EmptyLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Low Level
        /// </summary>
        /// <value>The Parameter Low Level</value>
        public decimal LowLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Callibration Level
        /// </summary>
        /// <value>The Parameter Calibration Level</value>
        public decimal CallibrationLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Input Type
        /// </summary>
        /// <value>The Parameter Input Type</value>
        public string InputType { get; set; }

        /// <summary>
        ///     Gets or sets the Level Deviation
        /// </summary>
        /// <value>The Parameter Level Deviation</value>
        public decimal LevelDeviation { get; set; }

        /// <summary>
        ///     Gets or sets the Size
        /// </summary>
        /// <value>The Parameter Size</value>
        public decimal Size { get; set; }

        /// <summary>
        ///     Gets or sets the Current Level
        /// </summary>
        /// <value>The Parameter Size</value>
        public decimal CurrentLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Ecolab Account Number
        /// </summary>
        /// <value>The Parameter Ecolab Account Number</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Product Id
        /// </summary>
        /// <value>The Parameter Product Id</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets the Product Name
        /// </summary>
        /// <value>The Parameter Product Name</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets the Current Level Tag
        /// </summary>
        public string CurrentLevelTag { get; set; }

        /// <summary>
        ///     Gets or sets the Level Deviation Tag
        /// </summary>
        public string LevelDeviationTag { get; set; }

        /// <summary>
        ///     Gets or sets the Size Tag
        /// </summary>
        public string SizeTag { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimestamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        public List<ModuleTagsModel> moduleTags { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp at central
        /// </summary>
        /// <value>LastModifiedTimeStampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        /// Gets or sets the IsCentral
        /// </summary>
        /// <value>IsCentral</value>
        public string IsCentral { get; set; }

        /// <summary>
        ///     Gets or sets the LowLevelDisplay
        /// </summary>
        /// <value>The Parameter LowLevelDisplay  </value>
        public decimal LowLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the EmptyLevelDisplay
        /// </summary>
        /// <value>The Parameter EmptyLevelDisplay</value>
        public decimal EmptyLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the CalibrationLevelDisplay
        /// </summary>
        /// <value>The Parameter CalibrationLevelDisplay</value>
        public decimal CalibrationLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentLevelDisplay
        /// </summary>
        /// <value>The Parameter CurrentLevelDisplay</value>
        public decimal CurrentLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the LevelDeviationDisplay
        /// </summary>
        /// <value>The Parameter LevelDeviationDisplay </value>
        public decimal LevelDeviationDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the SizeDisplay 
        /// </summary>
        /// <value>The Parameter SizeDisplay Level</value>
        public decimal SizeDisplay { get; set; }

        /// <summary>
		/// Gets or sets the sku.
		/// </summary>
		/// <value>The sku.</value>
		public string Sku { get; set; }
    }
}