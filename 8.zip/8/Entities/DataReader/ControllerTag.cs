﻿// -----------------------------------------------------------------------
// <copyright file="ControllerTag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerTag </summary>
// -----------------------------------------------------------------------

namespace Entities.DataReader
{
    public class ControllerTag
    {
        public ControllerTag(int controllerId, string tagAddress, string tagType, int tagTypeId, string tagDescription, int controllerTypeId, string topicName)
        {
            this.ControllerId = controllerId;
            this.TagAddress = tagAddress;
            this.TagType = tagType;
            this.TagTypeId = tagTypeId;
            this.TagDescription = tagDescription;
            this.ControllerTypeId = controllerTypeId;
            this.TopicName = topicName;
        }

        public int ControllerId { get; set; }
        public string TagAddress { get; set; }
        public string TagType { get; set; }
        public int TagTypeId { get; set; }
        public string TagDescription { get; set; }
        public int ControllerTypeId { get; set; }
        public string TopicName { get; set; }
    }
}