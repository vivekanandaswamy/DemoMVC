﻿// -----------------------------------------------------------------------
// <copyright file="RatioDosing.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The RatioDosing </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.DataReader
{
    public class RatioDosing
    {
        public RatioDosing(int standardWeight)
        {
            this.StandardWeight = standardWeight;
        }

        public int StandardWeight { get; set; }
    }
}
