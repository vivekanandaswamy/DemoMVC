﻿// -----------------------------------------------------------------------
// <copyright file="AllenBradleyXmlTag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The AllenBradleyXmlTag </summary>
// -----------------------------------------------------------------------

namespace Entities.DataReader
{
    using System;
    public class AllenBradleyXmlTag
    {
        public AllenBradleyXmlTag()
        { }
        public AllenBradleyXmlTag(string tagAddress, string tagDesc, string data, DateTime dateTimestamp)
        {
            this.Desc = tagDesc;
            this.TagAddress = tagAddress;
            this.Value = data;
            this.DateTimestamp = dateTimestamp;
        }

        public AllenBradleyXmlTag(int controllerid, int washerid, string address, string value, DateTime timestamp, string tagtype)
        {
            this.Controllerid = controllerid;
            this.Washerid = washerid;
            this.TagAddress = address;
            this.Value = value;
            this.DateTimestamp = timestamp;
            this.TagType = tagtype;
        }

        public AllenBradleyXmlTag(int controllerid, int washerid, string address, string value, DateTime timestamp, string tagtype, int loadId)
        {
            this.Controllerid = controllerid;
            this.Washerid = washerid;
            this.TagAddress = address;
            this.Value = value;
            this.DateTimestamp = timestamp;
            this.TagType = tagtype;
            this.LoadId = loadId;
        }

        public string Desc { get; set; }
        public string TagAddress { get; set; }
        public string Value { get; set; }
        public DateTime DateTimestamp { get; set; }
        public int Controllerid { get; set; }
        public int Washerid { get; set; }
        public string TagType { get; set; }
        public int LoadId { get; set; }
    }
}
