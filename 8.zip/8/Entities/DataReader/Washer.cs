﻿// -----------------------------------------------------------------------
// <copyright file="Washer.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Washer </summary>
// -----------------------------------------------------------------------

namespace Entities.DataReader
{
    public class Washer
    {
        public Washer(int tagId, string tagAddress, string tagType, int tagTypeId, string tagDescription, int washerId, string washerGroupName, string washerGroupTypeName, string washerName, string topicName, int endofFormula, bool aweaActive, bool ratioDosingActive,int eTechWasherNumber)
        {
            this.TagId = tagId;
            this.TagAddress = tagAddress;
            this.TagType = tagType;
            this.TagDescription = tagDescription;
            this.WasherId = washerId;
            this.WasherGroupName = washerGroupName;
            this.WasherGroupTypeName = washerGroupTypeName;
            this.WasherName = washerName;
            this.TopicName = topicName;
            this.TagTypeId = tagTypeId;
            this.EndOfFormula = endofFormula;
            this.AWEAActive = aweaActive;
            this.RatioDosingActive = ratioDosingActive;
            this.ETechWasherNumber = eTechWasherNumber;
        }

        public int TagId { get; set; }
        public string TagAddress { get; set; }
        public string TagType { get; set; }
        public int TagTypeId { get; set; }
        public string TagDescription { get; set; }
        public int WasherId { get; set; }
        public string WasherGroupName { get; set; }
        public string WasherGroupTypeName { get; set; }
        public string WasherName { get; set; }
        public string TopicName { get; set; }
        public int EndOfFormula { get; set; }
        public bool AWEAActive { get; set; }
        public bool RatioDosingActive { get; set; }
        public int ETechWasherNumber { get; set; }
    }
}