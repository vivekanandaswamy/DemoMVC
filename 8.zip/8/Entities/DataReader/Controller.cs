﻿// -----------------------------------------------------------------------
// <copyright file="Controller.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller </summary>
// -----------------------------------------------------------------------

namespace Entities.DataReader
{
    using System;

    public class Controller
    {
        public Controller(short regionID, int controllerId,string ecolabAccountNumber, int controllerTypeId, string name, string opcServerName, string ipAddress, string amsnetIdAddress, string comportNumber, int webportFtpEnabled, string webportIp, string webportLogin, string webportPassword, int controllerModelId, string topicName, DateTime webportdatetime)
        {
            this.ControllerId = controllerId;
            this.EcolabAccountNumber = ecolabAccountNumber;
            this.ControllerTypeId = controllerTypeId;
            this.Name = name;
            this.ControllerTypeId = controllerTypeId;
            this.ControllerModelId = controllerModelId;
            this.OpcServerName = opcServerName;
            this.IpAddress = ipAddress;
            this.AMSNetIdAddress = amsnetIdAddress;
            this.Comport = comportNumber;
            this.TopicName = topicName;
            this.WebPortFtpEnabled = webportFtpEnabled == 1;
            this.WebPortLogin = webportLogin;
            this.WebPortPassword = webportPassword;
            this.WebPortIp = webportIp;
            this.Webportdatetime = webportdatetime;
            this.RegionID = regionID;
        }

        public int ControllerId { get; set; }
        public string EcolabAccountNumber { get; set; }
        public string Name { get; set; }
        public int ControllerTypeId { get; set; }
        public int ControllerModelId { get; set; }
        public string OpcServerName { get; set; }
        public string IpAddress { get; set; }
        public string AMSNetIdAddress { get; set; }
        public string Comport { get; set; }
        public string TopicName { get; set; }
        public bool WebPortFtpEnabled { get; set; }
        public string WebPortLogin { get; set; }
        public string WebPortPassword { get; set; }
        public string WebPortIp { get; set; }
        public DateTime Webportdatetime { get; set; }
        public short RegionID { get; set; }
    }
}