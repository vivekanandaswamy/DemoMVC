﻿// -----------------------------------------------------------------------
// <copyright file="ModuleTag.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ModuleTag </summary>
// -----------------------------------------------------------------------

namespace Entities.DataReader
{
    public class ModuleTag
    {
        public ModuleTag(int moduleTagId, string tagAddress, double deadBand, string moduleDescription, int moduleTypeId, string tagType, int tagTypeId, string tagDescription, int moduleId, int controllerId, string topicName, int controllerTypeId, string name, string opcServerName, string ipAddress, string comportNumber, int webportFtpEnabled, string webportLogin, string webportPassword, string webportIp, int controllerModelId, string unit, long rolloverPoint, decimal calibration, string utilityType)
        {
            this.ModuleId = moduleId;
            this.TagAddress = tagAddress;
            this.DeadBand = deadBand;
            this.ModuleTypeId = moduleTypeId;
            this.ModuleTagId = moduleTagId;
            this.TagType = tagType;
            this.TagTypeId = tagTypeId;
            this.TagDescription = tagDescription;
            this.ModuleDescription = moduleDescription;
            this.ControllerId = controllerId;
            this.TopicName = topicName;
            this.ControllerTypeId = controllerTypeId;
            this.Name = name;
            this.OpcServerName = opcServerName;
            this.IpAddress = ipAddress;
            this.Comportnumber = comportNumber;
            this.WebPortFtpEnabled = webportFtpEnabled == 1;
            this.WebPortLogin = webportLogin;
            this.WebPortPassword = webportPassword;
            this.WebPortIp = webportIp;
            this.ControllerModelId = controllerModelId;
            this.Unit = unit;
            this.Rolloverpoint = rolloverPoint;
            this.Calibration = calibration;
            this.UtilityType = utilityType;
        }

        public int ModuleTagId { get; set; }
        public string TagAddress { get; set; }
        public double DeadBand { get; set; }
        public string TagType { get; set; }
        public int ModuleTypeId { get; set; }
        public int TagTypeId { get; set; }
        public string TagDescription { get; set; }
        public string ModuleDescription { get; set; }
        public int ModuleId { get; set; }
        public int ControllerId { get; set; }
        public string TopicName { get; set; }
        public int ControllerTypeId { get; set; }
        public string Name { get; set; }
        public string OpcServerName { get; set; }
        public string IpAddress { get; set; }
        public string Comportnumber { get; set; }
        public bool WebPortFtpEnabled { get; set; }
        public string WebPortLogin { get; set; }
        public string WebPortPassword { get; set; }
        public string WebPortIp { get; set; }
        public int ControllerModelId { get; set; }
        public string Unit { get; set; }
        public long Rolloverpoint { get; set; }
        public decimal Calibration { get; set; }
        public string UtilityType { get; set; }
    }
}