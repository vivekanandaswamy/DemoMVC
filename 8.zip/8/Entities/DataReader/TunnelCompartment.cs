﻿// -----------------------------------------------------------------------
// <copyright file="TunnelCompartment.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelCompartment </summary>
// -----------------------------------------------------------------------

using System;

namespace Entities.DataReader
{
	public class TunnelCompartment
	{
		public TunnelCompartment(int compId, int programNumber, int controllerBatchId, DateTime startTime)
		{
			this.CompId = compId;
			this.ProgramNumber = programNumber;
			this.ControllerBatchId = controllerBatchId;
			this.StartTime = startTime;
		}

		public int CompId { get; set; }
		public int ProgramNumber { get; set; }
		public int ControllerBatchId { get; set; }
		public DateTime StartTime { get; set; }
	}
}
