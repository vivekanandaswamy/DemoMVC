﻿// -----------------------------------------------------------------------
// <copyright file="TagTypes.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tag Types </summary>
// -----------------------------------------------------------------------

namespace Entities
{

    /// <summary>
    ///     class TagType
    /// </summary>
    public class TagTypes : BaseEntity
    {
        /// <summary>
        ///     Default Constructor
        /// </summary>
        public TagTypes()
        {

        }

        /// <summary>
        /// Parameterised Constructor
        /// </summary>
        public TagTypes(int tagTypeId, string tagType, string tagDescription, string dataType, bool active)
        {
            this.TagTypeId = tagTypeId;
            this.TagType = tagType;
            this.TagDescription = tagDescription;
            this.DataType = dataType;
            this.Active = active;
        }

        /// <summary>
        ///     Gets or sets  TagTypeId
        /// </summary>
        /// <value>TagTypeId</value>
        public int TagTypeId { get; set; }

        /// <summary>
        ///     Gets or sets  TagType
        /// </summary>
        /// <value>TagType</value>
        public string TagType { get; set; }

        /// <summary>
        ///     Gets or sets  TagDescription
        /// </summary>
        /// <value>TagDescription</value>
        public string TagDescription { get; set; }

        /// <summary>
        ///     Gets or sets  DataType
        /// </summary>
        /// <value>DataType</value>
        public string DataType { get; set; }

        /// <summary>
        ///     Gets or sets  Active
        /// </summary>
        /// <value>Active</value>
        public bool Active { get; set; }
    }
}
