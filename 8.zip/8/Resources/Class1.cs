﻿// -----------------------------------------------------------------------
// <copyright file="Class1.cs" company="Ecolab">
// TODO: Update copyright text.
// </copyright>
// <summary>The Class1 object</summary>
// -----------------------------------------------------------------------

namespace Resources
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// class Class1
    /// </summary>
    public class Class1
    {
    }
}
