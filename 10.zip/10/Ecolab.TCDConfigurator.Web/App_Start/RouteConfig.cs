﻿// -----------------------------------------------------------------------
// <copyright file="RouteConfig.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RouteConfig object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web
{
    using System.Web.Http;
    using System.Web.Mvc;
    using System.Web.Routing;
    using Api;

    /// <summary>
    ///     Class RouteConfig
    /// </summary>
    public class RouteConfig
    {
        /// <summary>
        ///     The Register Routes
        /// </summary>
        /// <param name="routes">The route path</param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.IgnoreRoute("{resource}.ashx/{*pathInfo}");

            routes.MapHttpRoute("DefaultApi", "api/{controller}/{action}/{id}", new { id = RouteParameter.Optional }).RouteHandler = new SessionRouteHandler();
            
            routes.MapRoute("Default", "{controller}/{action}/{id}", new { controller = "Launch", action = "Index", id = UrlParameter.Optional });
            routes.MapRoute("Access", "{controller}/{action}/{id}", new { controller = "AccessDenied", action = "Index", id = UrlParameter.Optional });
            routes.MapRoute("DefaultExport", "{controller}/{action}/{id}", new { controller = "ExportMyServiceToCSV", action = "Index", id = UrlParameter.Optional });
            routes.MapRoute("DefaultHelper", "{controller}/{action}/{id}", new { controller = "ConfigHelper", action = "Index", id = UrlParameter.Optional });
        }
    }
}