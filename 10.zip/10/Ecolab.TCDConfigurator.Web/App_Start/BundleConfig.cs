﻿// -----------------------------------------------------------------------
// <copyright file="BundleConfig.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The BundleConfig object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Web.Optimization;

    /// <summary>
    ///     Class BundleConfig
    /// </summary>
    public class BundleConfig
    {
        //// For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        /// <summary>
        ///     TO Register Bundles
        /// </summary>
        /// <param name="bundles">include files in bundles</param>
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/bundles/CoreCss").Include(GetFiles("CoreCss")));

            bundles.Add(new StyleBundle("~/bundles/VisualizationCss").Include(GetFiles("VisualizationCss")));

            bundles.Add(new ScriptBundle("~/bundles/CoreScripts").Include(GetFilesForMultipleSets("CoreScripts")));

            bundles.Add(new ScriptBundle("~/bundles/Contact_JS").Include(GetFilesForMultipleSets("Contact_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Chemical_JS").Include(GetFilesForMultipleSets("Chemical_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Customer_JS").Include(GetFilesForMultipleSets("Customer_JS")));

            bundles.Add(new ScriptBundle("~/bundles/PlantSetup_JS").Include(GetFilesForMultipleSets("PlantSetup_JS")));

            bundles.Add(new ScriptBundle("~/bundles/ControllerSetup_JS").Include(GetFilesForMultipleSets("ControllerSetup_JS")));

            bundles.Add(new ScriptBundle("~/bundles/ControllerSetupAdvance_JS").Include(GetFilesForMultipleSets("ControllerSetupAdvance_JS")));

            bundles.Add(new ScriptBundle("~/bundles/ControllerSetupList_JS").Include(GetFilesForMultipleSets("ControllerSetupList_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Alarm_JS").Include(GetFilesForMultipleSets("Alarm_JS")));

            bundles.Add(new ScriptBundle("~/bundles/PlantUtilitySetup_JS").Include(GetFilesForMultipleSets("PlantUtilitySetup_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Dryer_JS").Include(GetFilesForMultipleSets("Dryer_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Finnisher_JS").Include(GetFilesForMultipleSets("Finnisher_JS")));

            bundles.Add(new ScriptBundle("~/bundles/LaborCost_JS").Include(GetFilesForMultipleSets("LaborCost_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Formula_JS").Include(GetFilesForMultipleSets("Formula_JS")));

            bundles.Add(new ScriptBundle("~/bundles/RedFlag_JS").Include(GetFilesForMultipleSets("RedFlag_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Utility_JS").Include(GetFilesForMultipleSets("Utility_JS")));

            bundles.Add(new ScriptBundle("~/bundles/ShiftLabor_JS").Include(GetFilesForMultipleSets("ShiftLabor_JS")));

            bundles.Add(new ScriptBundle("~/bundles/WasherGroup_JS").Include(GetFilesForMultipleSets("WasherGroup_JS")));

            bundles.Add(new ScriptBundle("~/bundles/WasherGroupFormula_JS").Include(GetFilesForMultipleSets("WasherGroupFormula_JS")));

            bundles.Add(new ScriptBundle("~/bundles/NavigationMenu_JS").Include(GetFilesForMultipleSets("NavigationMenu_JS")));

            bundles.Add(new StyleBundle("~/bundles/leftNavMenucss").Include(GetFiles("LeftNavMenuCss")));

            bundles.Add(new ScriptBundle("~/bundles/Pumps_JS").Include(GetFilesForMultipleSets("Pumps_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Meter_JS").Include(GetFilesForMultipleSets("Meter_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Washers_JS").Include(GetFilesForMultipleSets("Washers_JS")));

            bundles.Add(new ScriptBundle("~/bundles/ConventionalGeneral_JS").Include(GetFilesForMultipleSets("ConventionalGeneral_JS")));

            bundles.Add(new ScriptBundle("~/bundles/TunnelGeneral_JS").Include(GetFilesForMultipleSets("TunnelGeneral_JS")));

			bundles.Add(new ScriptBundle("~/bundles/TunnelConnections_JS").Include(GetFilesForMultipleSets("TunnelConnections_JS")));

            bundles.Add(new ScriptBundle("~/bundles/TunnelCompartment_JS").Include(GetFilesForMultipleSets("TunnelCompartment_JS")));

            bundles.Add(new ScriptBundle("~/bundles/StorageTanks_JS").Include(GetFilesForMultipleSets("StorageTanks_JS")));

            bundles.Add(new ScriptBundle("~/bundles/Sensor_JS").Include(GetFilesForMultipleSets("Sensor_JS")));

            bundles.Add(new ScriptBundle("~/bundles/HoldCondition_JS").Include(GetFilesForMultipleSets("HoldCondition_JS")));

            bundles.Add(new ScriptBundle("~/bundles/UserManagement_JS").Include(GetFilesForMultipleSets("UserManagement_JS")));

            bundles.Add(new ScriptBundle("~/bundles/TargetProduction_JS").Include(GetFilesForMultipleSets("TargetProduction_JS")));

			bundles.Add(new StyleBundle("~/bundles/FlushTimesAndSetupTom_JS").Include(GetFilesForMultipleSets("FlushTimesAndSetupTom_JS")));

            bundles.Add(new StyleBundle("~/bundles/ProductDeviation_JS").Include(GetFilesForMultipleSets("ProductDeviation_JS")));

			bundles.Add(new StyleBundle("~/bundles/AnalogueDosing_JS").Include(GetFilesForMultipleSets("AnalogueDosing_JS")));

            bundles.Add(new StyleBundle("~/bundles/PumpsProducts_JS").Include(GetFilesForMultipleSets("PumpsProducts_JS")));

            bundles.Add(new StyleBundle("~/bundles/MixingVessels_JS").Include(GetFilesForMultipleSets("MixingVessels_JS")));

            bundles.Add(new ScriptBundle("~/bundles/HelpPage_JS").Include(GetFilesForMultipleSets("HelpPage_JS")));

            bundles.Add(new StyleBundle("~/bundles/onlineHelpcss").Include(GetFiles("OnlineHelpCss")));
        }

        /// <summary>
        ///     Gets the script filenames for multiple sets
        /// </summary>
        /// <param name="setNames">comma separated set names</param>
        /// <returns>returns array of files</returns>
        private static string[] GetFilesForMultipleSets(string setNames)
        {
            string[] setNameList = setNames.Replace(" ", string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            var files = new List<string>();
            foreach (string set in setNameList)
            {
                files.AddRange(GetFiles(set));
            }

            return files.ToArray();
        }

        /// <summary>
        ///     Gets the script filenames by set name
        /// </summary>
        /// <param name="setName">set name</param>
        /// <returns>returns set of files for the set</returns>
        private static string[] GetFiles(string setName)
        {
            NameValueCollection filesConfig = (NameValueCollection) ConfigurationManager.GetSection("ScriptCombiner/Files");
            string[] sets = GetSetFiles(setName);
            var files = new string[sets.Length];

            for (int i = 0; i < sets.Length; i++)
            {
                if (filesConfig[sets[i]] != null)
                {
                    files[i] = filesConfig[sets[i]];
                }
            }

            return files;
        }

        /// <summary>
        ///     Gets the set details from config
        /// </summary>
        /// <param name="setName">set name</param>
        /// <returns>returns the file names in the set</returns>
        private static string[] GetSetFiles(string setName)
        {
            NameValueCollection setsConfig = (NameValueCollection) ConfigurationManager.GetSection("ScriptCombiner/Sets");
            string setDefinition = setsConfig[setName];

            if (string.IsNullOrEmpty(setDefinition))
            {
                return new string[0];
            }

            string[] fileNames = setDefinition.Replace(" ", string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            return fileNames;
        }
    }
}