﻿// -----------------------------------------------------------------------
// <copyright file="WebApiConfig.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>WebApiConfig </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web
{
    using System.Web.Http;

    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute("DefaultApi", "api/{controller}/{id}", new { id = RouteParameter.Optional });
        }
    }
}