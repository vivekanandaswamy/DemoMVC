﻿// -----------------------------------------------------------------------
// <copyright file="FilterConfig.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The FilterConfig object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web
{
    using System.Web.Mvc;
    using Utilities;

    /// <summary>
    ///     Class FilterConfig
    /// </summary>
    public class FilterConfig
    {
        /// <summary>
        ///     Register Global Filters
        /// </summary>
        /// <param name="filters">The parameter Filters</param>
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new ElmahHandledErrorLoggerFilter());
            filters.Add(new HandleErrorAttribute());
        }
    }
}