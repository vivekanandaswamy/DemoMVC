﻿
// -----------------------------------------------------------------------
// <copyright file="Global.asax.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>MvcApplication </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web
{
    using System.Web;
    using Infra;

    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            Bootstrapper.Bootstrap();
        }
    }
}