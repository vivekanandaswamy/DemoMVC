﻿// -----------------------------------------------------------------------
// <copyright file="WindsorDependencyResolver.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WindsorDependencyResolver object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Infra
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http.Dependencies;
    using Castle.Windsor;

    /// <summary>
    ///     WindsorDependencyResolver class.
    /// </summary>
    /// <remarks></remarks>
    internal sealed class WindsorDependencyResolver : IDependencyResolver
    {
        /// <summary>
        ///     The container.
        /// </summary>
        private readonly IWindsorContainer container;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WindsorDependencyResolver" /> class.
        /// </summary>
        /// <param name="container">The container.</param>
        public WindsorDependencyResolver(IWindsorContainer container)
        {
            if (container == null)
            {
                throw new ArgumentNullException("container");
            }

            this.container = container;
        }

        /// <summary>
        ///     Gets the service.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns>The object type.</returns>
        public object GetService(Type t)
        {
            return container.Kernel.HasComponent(t) ? container.Resolve(t) : null;
        }

        /// <summary>
        ///     Gets the services.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns>Array of object.</returns>
        public IEnumerable<object> GetServices(Type t)
        {
            return container.ResolveAll(t).Cast<object>().ToArray();
        }

        /// <summary>
        ///     Begins the scope.
        /// </summary>
        /// <returns>IDependency Scope.</returns>
        public IDependencyScope BeginScope()
        {
            return new WindsorDependencyScope(container);
        }

        /// <summary>
        ///     Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
        }
    }
}