﻿// -----------------------------------------------------------------------
// <copyright file="Bootstrapper.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Bootstrapper object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Infra
{
    using System.Configuration;
    using System.Web.Http;
    using System.Web.Mvc;
    using System.Web.Optimization;
    using System.Web.Routing;
    using Data.Access;
    using Ecolab.Infra;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess.DB;

    /// <summary>
    ///     Class Bootstrapper
    /// </summary>
    public class Bootstrapper
    {
        /// <summary>
        ///     Bootstraps this instance.
        /// </summary>
        public static void Bootstrap()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            Database.ApplicationMode = Entities.ApplicationMode.Central;
            Database.InitializeConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
            Database.InitializeConnection("MyService", ConfigurationManager.ConnectionStrings["MyServiceConnection"].ToString());
            ControllerBuilder.Current.SetControllerFactory(new WindsorControllerFactory(IoC.Container));
            GlobalConfiguration.Configuration.DependencyResolver = new WindsorDependencyResolver(IoC.Container);
            WindsorConfigurator.Configure();
            AutoMapperConfiguration.Configure();
        }
    }
}