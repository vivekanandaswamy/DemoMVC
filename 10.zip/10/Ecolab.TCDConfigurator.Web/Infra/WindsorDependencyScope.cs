﻿// -----------------------------------------------------------------------
// <copyright file="WindsorDependencyScope.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WindsorDependencyScope object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Infra
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http.Dependencies;
    using Castle.MicroKernel.Lifestyle;
    using Castle.Windsor;

    /// <summary>
    ///     Windsor Dependency Scope class
    /// </summary>
    /// <remarks></remarks>
    internal sealed class WindsorDependencyScope : IDependencyScope
    {
        /// <summary>
        ///     The container.
        /// </summary>
        private readonly IWindsorContainer container;

        /// <summary>
        /// </summary>
        private readonly IDisposable scope;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WindsorDependencyScope" /> class.
        /// </summary>
        /// <param name="container">The container.</param>
        public WindsorDependencyScope(IWindsorContainer container)
        {
            if (container == null)
            {
                throw new ArgumentNullException("container");
            }

            this.container = container;
            scope = container.BeginScope();
        }

        /// <summary>
        ///     Gets the service.
        /// </summary>
        /// <param name="t">The type.</param>
        /// <returns>The object type.</returns>
        public object GetService(Type t)
        {
            return container.Kernel.HasComponent(t) ? container.Resolve(t) : null;
        }

        /// <summary>
        ///     Gets the services.
        /// </summary>
        /// <param name="t">Type of the service.</param>
        /// <returns>Array of object.</returns>
        public IEnumerable<object> GetServices(Type t)
        {
            return container.ResolveAll(t).Cast<object>().ToArray();
        }

        /// <summary>
        ///     Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            scope.Dispose();
        }
    }
}