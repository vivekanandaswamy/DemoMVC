﻿// -----------------------------------------------------------------------
// <copyright file="WebMappingProfile.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Objects Mapping </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Infra
{
    using System;
    using System.Globalization;
    using AutoMapper;
	using Ecolab.Models;
    using Ecolab.Models.Common;
    using Ecolab.Models.ControllerSetup;
    using Ecolab.Models.ControllerSetup.Pumps;
    using Ecolab.Models.NavigationMenu;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Models.PlantSetup.Chemical;
    using Ecolab.Models.PlantSetup.Dryer;
    using Ecolab.Models.PlantSetup.Finnisher;
    using Ecolab.Models.PlantSetup.RedFlag;
    using Ecolab.Models.PlantSetup.ShiftLabor;
	using Ecolab.Models.PlantSetup.UserManagement;
    using Ecolab.Models.StorageTanks;
    using Ecolab.Models.WasherGroup;
    using Ecolab.Models.Washers;
    using Ecolab.Models.Washers.Conventional;
    using Ecolab.Models.Washers.Tunnel;
    using Models.Common;
    using Models.ControllerSetup;
    using Models.NavigationMenu;
    using Models.PlantSetup;
    using Models.PlantSetup.Dryer;
    using Models.PlantSetup.Finnisher;
    using Models.PlantSetup.Formula;
    using Models.PlantSetup.RedFlag;
    using Models.PlantSetup.ShiftLabor;
    using Models.StorageTanks;
	using Models.UserManagement;
    using Models.WasherGroup;
    using Models.Washers;
    using Models.Washers.Conventional;
    using Models.Washers.Tunnel;
	using ControllerModel = Models.ControllerSetup.ControllerModel;
	using LaborTypeCost = Ecolab.Models.PlantSetup.ShiftLabor.LaborTypeCost;
    using Model = Ecolab.Models;
    using PlantUtilityFactorTypes = Ecolab.Models.PlantSetup.PlantUtilityFactorTypes;
    using WasherGroup = Ecolab.Models.WasherGroup.WasherGroup;
    using WasherModelSize = Ecolab.Models.Washers.Conventional.WasherModelSize;
	using WebModel = Models;

    /// <summary>
    ///     class for WebMappingProfile
    /// </summary>
    public class WebMappingProfile : Profile
    {
        /// <summary>
        ///     Override this method in a derived class and call the CreateMap method to associate that map with this profile.
        ///     <see cref="T:AutoMapper.Mapper" /> class from this method.
        /// </summary>
        protected override void Configure()
        {
            //Model to WebModel
            Mapper.CreateMap<MetaData, MetaDataModel>();
            Mapper.CreateMap<ControllerSetupMetaData, ControllerSetupMetaDataModel>();
            Mapper.CreateMap<FieldSource, FieldSourceModel>();
            Mapper.CreateMap<Controller, ControllerModel>();
            Mapper.CreateMap<Ecolab.Models.ControllerSetup.ControllerModel, ControllerModelModel>();
            Mapper.CreateMap<ControllerType, ControllerTypeModel>();

            //WebModel to Model
            Mapper.CreateMap<ControllerModel, Controller>();
            Mapper.CreateMap<ControllerSetupDataModel, ControllerSetupData>();

            //AutoMapper.Mapper.AssertConfigurationIsValid();

            //Model to WebModel
            Mapper.CreateMap<Model.LanguageMaster, WebModel.LanguageMasterModel>();
            Mapper.CreateMap<Model.Plant, PlantModel>();
            Mapper.CreateMap<Model.PlantCustAddress, PlantCustAddressModel>();
            Mapper.CreateMap<Model.ShippingAddress, ShippingAddressModel>();
            Mapper.CreateMap<Model.CurrencyMaster, CurrencyMasterModel>();
            Mapper.CreateMap<Model.DimensionalUnitSystems, DimensionalUnitSystemsModel>();
            //WebModel to Model
            Mapper.CreateMap<PlantCustAddressModel, Model.PlantCustomer>();
            Mapper.CreateMap<PlantModel, Model.Plant>();

            //Model to WebModel
            Mapper.CreateMap<Model.PlantContact, PlantContactModel>();
            Mapper.CreateMap<PlantContactPosition, PlantContactPositionModel>();

            //WebModel to Model
            Mapper.CreateMap<PlantContactModel, Model.PlantContact>();

            //Model to WebModel
            Mapper.CreateMap<Model.PlantCustomer, PlantCustomerModel>();

            //WebModel to Model
            Mapper.CreateMap<PlantCustomerModel, Model.PlantCustomer>();

            //Model to WebModel
            Mapper.CreateMap<ProductMaster, ProductMasterModel>();
            Mapper.CreateMap<Chemicals, ChemicalsModel>();
			Mapper.CreateMap<SubstituteChemical, SubstituteChemicalModel>();

            //WebModel to Model
            Mapper.CreateMap<ProductMasterModel, ProductMaster>();
			Mapper.CreateMap<SubstituteChemicalModel, SubstituteChemical>();

            //Model to WebModel
            Mapper.CreateMap<Model.Alarm, WebModel.AlarmModel>();

            //Model to WebModel
            Mapper.CreateMap<PlantUtilityFactorTypes, Models.PlantSetup.PlantUtilityFactorTypes>();
            Mapper.CreateMap<PlantUtilityWaterTypeMaster, PlantUtilityWaterTypeMasterModel>();
            Mapper.CreateMap<PlantUtilityGasoilTypes, PlantUtilityGasoilTypeModel>();
            Mapper.CreateMap<PlantUtilityDimensionTypes, PlantUtilityDimesionTypesModel>();
            Mapper.CreateMap<Model.PlantUtilityUnitTypes, PlantUtilityUnitTypesModel>();
            //WebModel to Model
            Mapper.CreateMap<PlantUtilitySetupModel, PlantUtilitySetup>();

            //Model to WebModel
            Mapper.CreateMap<Finnisher, FinnisherModel>();
            Mapper.CreateMap<FinnisherGroup, FinnisherGroupModel>();
            Mapper.CreateMap<FinnisherType, FinnisherTypeModel>();

            //WebModel to Model
            Mapper.CreateMap<FinnisherModel, Finnisher>();
            Mapper.CreateMap<FinnisherGroupModel, FinnisherGroup>();
            Mapper.CreateMap<FinnisherTypeModel, FinnisherType>();

            //Model to WebModel
            Mapper.CreateMap<Dryer, DryerModel>();
            Mapper.CreateMap<DryerGroup, DryerGroupModel>();
            Mapper.CreateMap<DryerType, DryerTypeModel>();

            //WebModel to Model
            Mapper.CreateMap<DryerModel, Dryer>();
            Mapper.CreateMap<DryerGroupModel, DryerGroup>();
            Mapper.CreateMap<DryerTypeModel, DryerType>();

            //Model to WebModel
            Mapper.CreateMap<LaborCost, LaborCostModel>();
            //WebModel to Model
            Mapper.CreateMap<LaborCostModel, LaborCost>();

            //Model to WebModel
            Mapper.CreateMap<Model.Formula, FormulaModel>();
            Mapper.CreateMap<FormulaSegment, FormulaSegmentModel>();
            Mapper.CreateMap<Model.EcolabTextileCategory, EcolabTextileCategoryModel>();
            Mapper.CreateMap<Model.EcolabSaturation, EcolabSaturationModel>();
            Mapper.CreateMap<Model.PlantChainProgram, PlantChainProgramModel>();
            Mapper.CreateMap<Model.ChainTextileCategory, ChainTextileCategoryModel>();

            //WebModel to Model
            Mapper.CreateMap<FormulaModel, Model.Formula>();

            //AutoMapper.Mapper.AssertConfigurationIsValid();

            //Model to WebModel
            Mapper.CreateMap<RedFlag, RedFlagModel>();
            Mapper.CreateMap<RedFlagItem, ItemModel>();
            Mapper.CreateMap<RedFlagLocation, RedFlagLocationModel>();
            Mapper.CreateMap<RedFlagCategory,RedFlagCategoryModel>();
            //WebModel to Model
            Mapper.CreateMap<RedFlagModel, RedFlag>();
            Mapper.CreateMap<MachineSetup, MachineSetupModel>();
            Mapper.CreateMap<RedFlagCategoryModel, RedFlagCategory>();
            //Model to WebModel
            Mapper.CreateMap<Utility, UtilityModel>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
            {
                DateTime dt = src.InstallDate;
                return string.Format("{0:MM'/'dd'/'yyyy}", dt);
            }));

            Mapper.CreateMap<DeviceType, DeviceTypeModel>();

            Mapper.CreateMap<Utility, UtilityModel>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
            {
                DateTime dt = src.InstallDate;
                return string.Format("{0:MM'/'dd'/'yyyy}", dt);
            }));

            Mapper.CreateMap<DeviceType, DeviceTypeModel>();
            Mapper.CreateMap<DeviceModel, DevicemodelModel>();
            Mapper.CreateMap<DeviceType, DeviceTypeModel>();
            Mapper.CreateMap<DeviceModel, DevicemodelModel>();

            //WebModel to Model
            Mapper.CreateMap<UtilityModel, Utility>().ForMember(dt => dt.InstallDate, opt => opt.ResolveUsing(src =>
            {
                string dt = src.InstallDate;
                return DateTime.Parse(dt, CultureInfo.InvariantCulture);
            }));

            //Model to WebModel
            Mapper.CreateMap<Shift, ShiftModel>();
            Mapper.CreateMap<ShiftBreak, ShiftBreakModel>();
            Mapper.CreateMap<ShiftLabor, ShiftLaborModel>();
            Mapper.CreateMap<LaborType, LaborTypeModel>();
            Mapper.CreateMap<LaborTypeCost, Models.PlantSetup.ShiftLabor.LaborTypeCost>();
            Mapper.CreateMap<LaborTypeCost, LaborTypeCostModel>();
            Mapper.CreateMap<Ecolab.Models.PlantSetup.ShiftLabor.TargetProduction, WebModel.PlantSetup.ShiftLabor.TargetProduction>();

            //WebModel to Model
            Mapper.CreateMap<ShiftModel, Shift>();
            Mapper.CreateMap<ShiftBreakModel, ShiftBreak>();
            Mapper.CreateMap<ShiftLaborModel, ShiftLabor>();
            Mapper.CreateMap<LaborTypeModel, LaborType>();
            Mapper.CreateMap<Models.PlantSetup.ShiftLabor.LaborTypeCost, LaborTypeCost>();
            Mapper.CreateMap<LaborTypeCostModel, LaborTypeCost>();
            Mapper.CreateMap<WebModel.PlantSetup.ShiftLabor.TargetProduction, Ecolab.Models.PlantSetup.ShiftLabor.TargetProduction>();

            //Model to WebModel Mapping.
            Mapper.CreateMap<WasherGroup, Models.WasherGroup.WasherGroup>();
            Mapper.CreateMap<WasherGroupFormula, WasherGroupFormulaModel>();
            Mapper.CreateMap<WashStep, WashStepModel>();
            Mapper.CreateMap<WasherFormulaWashStep, WasherFormulaWashStepModel>();
            Mapper.CreateMap<WasherDosingProduct, WasherDosingProductModel>();
            Mapper.CreateMap<Ecolab.Models.WasherGroup.DrainDestinationList, WebModel.WasherGroup.DrainDestinationList>();
			Mapper.CreateMap<Ecolab.Models.WasherGroup.CopyFormula, Models.WasherGroup.CopyFormula>();
			Mapper.CreateMap<Ecolab.Models.WasherGroup.CopyFormulaContainer, Models.WasherGroup.CopyFormulaContainerModel>();

            //WebModel to Model Mapping.
            Mapper.CreateMap<Models.WasherGroup.WasherGroup, WasherGroup>();
            Mapper.CreateMap<WasherGroupFormulaModel, WasherGroupFormula>();
            Mapper.CreateMap<WashStepModel, WashStep>();
            Mapper.CreateMap<WasherFormulaWashStepModel, WasherFormulaWashStep>();
            Mapper.CreateMap<WasherDosingProductModel, WasherDosingProduct>();
            Mapper.CreateMap<WebModel.WasherGroup.DrainDestinationList, Ecolab.Models.WasherGroup.DrainDestinationList>();
			Mapper.CreateMap<Models.WasherGroup.CopyFormula, Ecolab.Models.WasherGroup.CopyFormula>();
			Mapper.CreateMap<Models.WasherGroup.CopyFormulaContainerModel, Ecolab.Models.WasherGroup.CopyFormulaContainer>();

            //Model to WebModel
            Mapper.CreateMap<TunnelWashStep, TunnelWashStepModel>();
            Mapper.CreateMap<TunnelWashStepProducts, TunnelWashStepProductsModel>();
            //WebModel to Model
            Mapper.CreateMap<TunnelWashStepModel, TunnelWashStep>();
            Mapper.CreateMap<TunnelWashStepProductsModel, TunnelWashStepProducts>();
			Mapper.CreateMap<Ecolab.Models.Washers.Tunnel.TunnelConnections, Web.Models.Washers.Tunnel.TunnelConnections>().ReverseMap();
            //Model to WebModel
            Mapper.CreateMap<Washers, WashersModel>();
            Mapper.CreateMap<Alarms, AlarmsModel>();
            //WebModel to Model
            Mapper.CreateMap<WashersModel, Washers>();
            Mapper.CreateMap<AlarmsModel, Alarms>();

            //Model to WebModel
            Mapper.CreateMap<Meter, MeterWebModel>();
            Mapper.CreateMap<Meter, MeterModel>();
            Mapper.CreateMap<ResourceMaster, ResourceMasterModel>();
            Mapper.CreateMap<GroupType, WebModel.GroupTypeModel>();
            Mapper.CreateMap<ParentMeter, ParentMeterModel>();
            Mapper.CreateMap<ConduitController, ConduitControllerModel>();
            Mapper.CreateMap<UOMMeter, UOMMeterModel>();
            Mapper.CreateMap<MachineSetup, MachineSetupModel>();

            //WebModel to Model MeterModel
            Mapper.CreateMap<MeterWebModel, Meter>();
            Mapper.CreateMap<MeterModel, Meter>();
            //Model to WebModel for Left NavigationMenu
            Mapper.CreateMap<NavigationMenu, NavigationMenuModel>();

            //Model to WebModel
            Mapper.CreateMap<PumpsModel, Models.ControllerSetup.Pumps.PumpsModel>();
            Mapper.CreateMap<ProductModel, Models.ControllerSetup.Pumps.ProductModel>();

            //WebModel to Model
            Mapper.CreateMap<Models.ControllerSetup.Pumps.PumpsModel, PumpsModel>();
            Mapper.CreateMap<Models.ControllerSetup.Pumps.ProductModel, ProductModel>();

            //ControllerInfoforPLC Model to WebModel
            Mapper.CreateMap<ControllerInfoForPlc, ControllerInfoForPlcModel>();

            //WebModel to Model
            Mapper.CreateMap<ControllerInfoForPlcModel, ControllerInfoForPlc>();

            //Model to WebModel
            Mapper.CreateMap<Washers, WashersModel>();
            //Mapper.CreateMap<Alarms, AlarmsModel>();
            //WebModel to Model
            Mapper.CreateMap<WashersModel, Washers>();
            //Mapper.CreateMap<AlarmsModel, Alarms>();

            //Model to WebModel
            Mapper.CreateMap<ConventionalGeneral, ConventionalGeneralModel>();
            Mapper.CreateMap<WasherModeList, WasherModeListModel>();
            Mapper.CreateMap<WasherModelList, WasherModelListModel>();
            Mapper.CreateMap<WasherModelSize, WasherModelSizeModel>();
            Mapper.CreateMap<LfsWasherNumber, LfsWasherNumberModel>();

            //WebModel to Model
            Mapper.CreateMap<ConventionalGeneralModel, ConventionalGeneral>();
            Mapper.CreateMap<WasherModeListModel, WasherModeList>();
            Mapper.CreateMap<WasherModelListModel, WasherModelList>();
            Mapper.CreateMap<WasherModelSizeModel, WasherModelSize>();
            Mapper.CreateMap<LfsWasherNumberModel, LfsWasherNumber>();

            //Model to WebModel
            Mapper.CreateMap<TunnelGeneral, TunnelGeneralModel>();
            Mapper.CreateMap<WashersList, WashersListModel>();
            Mapper.CreateMap<PressExtractor, PressExtractorModel>();
            Mapper.CreateMap<PumpsProductList, PumpsProductListModel>();
            Mapper.CreateMap<TunnelCompartment, TunnelCompartmentModel>();
            Mapper.CreateMap<PumpAssociation, PumpAssociationModel>();

            //WebModel to Model
            Mapper.CreateMap<TunnelGeneralModel, TunnelGeneral>();
            Mapper.CreateMap<WashersListModel, WashersList>();
            Mapper.CreateMap<PressExtractorModel, PressExtractor>();
            Mapper.CreateMap<PumpsProductListModel, PumpsProductList>();
            Mapper.CreateMap<TunnelCompartmentModel, TunnelCompartment>();
            Mapper.CreateMap<PumpAssociationModel, PumpAssociation>();

            //Model to WebModel
            Mapper.CreateMap<Tanks, TanksModel>();

            //WebModel to Model
            Mapper.CreateMap<TanksModel, Tanks>();

            //Model to WebModel
            Mapper.CreateMap<Sensor, SensorWebModel>();

            Mapper.CreateMap<SensorType, SensorTypeModel>();

            Mapper.CreateMap<UOMSensor, UOMSensorModel>();
            Mapper.CreateMap<SensorChemicalChart, SensorChemicalChartModel>();

            //WebModel to Model
            Mapper.CreateMap<SensorWebModel, Sensor>();

            // Model for washer & TUnnel tags mapping.
            Mapper.CreateMap<ConventionalTagModel, ConventionalTags>();
            Mapper.CreateMap<TunnelTagsModel, TunnelTags>();

            Mapper.CreateMap<ConventionalTags, ConventionalTagModel>();
            Mapper.CreateMap<TunnelTags, TunnelTagsModel>();

            //Model to WebModel
            Mapper.CreateMap<UserManagement, UserManagementModel>();

            //WebModel to Model
            Mapper.CreateMap<UserManagementModel, UserManagement>();

            // Model for Exchange Rate
            Mapper.CreateMap<ExchangeRate, WebModel.ExchangeRate>();

			Mapper.CreateMap<WasherFlushTime, WasherFlushTimeModel>().ReverseMap();
			Mapper.CreateMap<WasherTimeOutMachine, WasherTimeOutMachineModel>().ReverseMap();

            Mapper.CreateMap<ProductDeviation, ProductDeviationModel>().ReverseMap();
            Mapper.CreateMap<PumpsAndMECount, PumpsAndMECountModel>().ReverseMap();
			Mapper.CreateMap<Ecolab.Models.Washers.Tunnel.AnalogueDosing, Web.Models.Washers.Tunnel.AnalogueDosing>().ReverseMap();

			//WebModel to Model
			Mapper.CreateMap<WebModel.MissingFieldsModel, Model.MissingFields>();

			//Model to WebModel
			Mapper.CreateMap<Model.MissingFields, WebModel.MissingFieldsModel>();
            Mapper.CreateMap<WebModel.ControllerSetup.Pumps.LineCompartmentMappingModel, Model.ControllerSetup.Pumps.LineCompartmentMappingModel>();
           
            //Model to WebModel        

            Mapper.CreateMap<Model.ControllerSetup.Pumps.LineCompartmentMappingModel, WebModel.ControllerSetup.Pumps.LineCompartmentMappingModel>();
            Mapper.CreateMap<Ecolab.Models.WasherGroup.TunnelAnalogueControl, Models.WasherGroup.TunnelAnalogueControlModel>().ReverseMap();

            Mapper.CreateMap<Model.ControllerSetup.Pumps.SetupDosingLine, WebModel.ControllerSetup.Pumps.SetupDosingLineModel>().ReverseMap();            
        }
    }
}