﻿// -----------------------------------------------------------------------
// <copyright file="AutoMapperConfiguration.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The AutoMapper Configuration </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Infra
{
    using AutoMapper;
    using Services.Infra;

    /// <summary>
    ///     class for AutoMapperConfiguration
    /// </summary>
    public class AutoMapperConfiguration
    {
        /// <summary>
        ///     Configures the instance.
        /// </summary>
        public static void Configure()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile(new WebMappingProfile());
                cfg.AddProfile(new ServiceMappingProfile());
            });
        }
    }
}