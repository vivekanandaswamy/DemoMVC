﻿// -----------------------------------------------------------------------
// <copyright file="ConfiguratorHandler.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ConfiguratorHandler </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web
{
    using System;
    using System.Net.Mail;
    using System.Web;
    using System.Web.SessionState;
    using Ecolab.Models;
    using Newtonsoft.Json;

    public class ConfiguratorHandler : IHttpHandler, IRequiresSessionState
    {
        /// <summary>
        ///     You will need to configure this handler in the Web.config file of your
        ///     web and register it with IIS before being able to use it. For more information
        ///     see the following link: http://go.microsoft.com/?linkid=8101007
        /// </summary>

        #region IHttpHandler Members
        public bool IsReusable
        {
            // Return false in case your Managed Handler cannot be reused for another request.
            // Usually this would be false in case you have some state information preserved per request.
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            User objUser;
            if (context.Request.RequestType.ToLower() == "post" && context.Request.Form.Count > 0)
            {
                try
                { 

                    string str = context.Request.Form[0];
                    objUser = JsonConvert.DeserializeObject<User>(str);

                    MailAddress mail = new MailAddress(objUser.Email);
                    if (mail.Host.ToLower() == "ecolab.com" || mail.Host.ToLower() == "ecolab.ca")
                    {
                        const string pageToRedirect = "PlantSetup";
                        objUser.Email = objUser.Email + "," + mail.User + "@ecolab.ca";
                        string redirectUrl = string.Format("{0}?plantId={1}&email={2}", pageToRedirect, objUser.EcolabAccountNumber, objUser.Email);
                        context.Session.Clear();
                        context.Response.Redirect(redirectUrl);
                        context.Response.End();
                    }
                    else
                    {
                        context.Response.Redirect("AccessDenied");
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
           
        }
        #endregion
    }
}