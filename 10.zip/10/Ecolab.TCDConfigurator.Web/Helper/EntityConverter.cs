﻿// -----------------------------------------------------------------------
// <copyright file="EntityConverter.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The EntityConverter object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Helper
{
    using Ecolab.Models.ControllerSetup;
    using Ecolab.Models.PlantSetup;
    using Ecolab.Models.WasherGroup;
    using Models.PlantSetup;
    using Models.WasherGroup;
    using ControllerModel = Models.ControllerSetup.ControllerModel;
    using Map = AutoMapper.Mapper;
    using PlantUtilityFactorTypes = Models.PlantSetup.PlantUtilityFactorTypes;
    using ServiceChemModel = Ecolab.Models.PlantSetup.Chemical;
    using ServiceModel = Ecolab.Models;
    using WasherGroup = Models.WasherGroup.WasherGroup;
    using WebModel = Models;

    /// <summary>
    ///     class Entity Converter
    /// </summary>
    public class EntityConverter
    {
        #region "ControllerSetup"

        /// <summary>
        ///     Converts to Service Model.
        /// </summary>
        /// <param name="controllermodel">The controller model.</param>
        /// <returns> Web.Plant Customer Model. </returns>
        internal static Controller ConvertToServiceModel(ControllerModel controllermodel)
        {
            if (controllermodel == null)
            {
                return null;
            }

            return Map.Map<ControllerModel, Controller>(controllermodel);
        }

        #endregion

        #region "Plant"

        /// <summary>
        ///     Converts to WebModel.
        /// </summary>
        /// <param name="plant"> The plant. </param>
        /// <returns> Plant Model. </returns>
        internal static PlantModel ConvertToWebModel(ServiceModel.Plant plant)
        {
            if (plant == null)
            {
                return null;
            }

            return Map.Map<ServiceModel.Plant, PlantModel>(plant);
        }

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="plant"> The plant. </param>
        /// <returns> Plant Model. </returns>
        internal static ServiceModel.Plant ConvertToServiceModel(PlantModel plant)
        {
            if (plant == null)
            {
                return null;
            }

            return Map.Map<PlantModel, ServiceModel.Plant>(plant);
        }

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="currMasts">The Currency Masters.</param>
        /// <returns> Currency Master Model. </returns>
        internal static CurrencyMasterModel ConvertToWebModel(ServiceModel.CurrencyMaster currMasts)
        {
            if (currMasts == null)
            {
                return null;
            }

            return Map.Map<ServiceModel.CurrencyMaster, CurrencyMasterModel>(currMasts);
        }

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="langMasts">The Language Masters.</param>
        /// <returns> Language Master Model. </returns>
        internal static WebModel.LanguageMasterModel ConvertToWebModel(ServiceModel.LanguageMaster langMasts)
        {
            if (langMasts == null)
            {
                return null;
            }

            return Map.Map<ServiceModel.LanguageMaster, WebModel.LanguageMasterModel>(langMasts);
        }

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="dimeUnits">The Dimensional Unit Systems.</param>
        /// <returns> Dimensional Unit Systems Model. </returns>
        internal static DimensionalUnitSystemsModel ConvertToWebModel(ServiceModel.DimensionalUnitSystems dimeUnits)
        {
            if (dimeUnits == null)
            {
                return null;
            }

            return Map.Map<ServiceModel.DimensionalUnitSystems, DimensionalUnitSystemsModel>(dimeUnits);
        }

        #endregion

        #region "Plant Customer"

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="plantCustomers">The Plant Customer Model.</param>
        /// <returns> Web.Plant Customer Model. </returns>
        internal static PlantCustomerModel ConvertToWebModel(ServiceModel.PlantCustomer plantCustomers)
        {
            if (plantCustomers == null)
            {
                return null;
            }

            return Map.Map<ServiceModel.PlantCustomer, PlantCustomerModel>(plantCustomers);
        }

        /// <summary>
        ///     Converts to Service Model.
        /// </summary>
        /// <param name="plantCustomer">The plant Customer Model.</param>
        /// <returns> Web.Plant Customer Model. </returns>
        internal static ServiceModel.PlantCustomer ConvertToServiceModel(PlantCustomerModel plantCustomer)
        {
            if (plantCustomer == null)
            {
                return null;
            }

            return Map.Map<PlantCustomerModel, ServiceModel.PlantCustomer>(plantCustomer);
        }

        #endregion

        #region "PlantChemical"

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="prodMasts">The Product Master.</param>
        /// <returns> Web Model.Product Master. </returns>
        internal static ProductMasterModel ConvertToWebModel(ServiceChemModel.ProductMaster prodMasts)
        {
            if (prodMasts == null)
            {
                return null;
            }

            Map.CreateMap<ServiceChemModel.ProductMaster, ProductMasterModel>();
            return Map.Map<ServiceChemModel.ProductMaster, ProductMasterModel>(prodMasts);
        }

        /// <summary>
        ///     Convert To Service Model
        /// </summary>
        /// <param name="prodMast">The Product Master</param>
        /// <returns>Service Model.Product Master</returns>
        internal static ServiceChemModel.ProductMaster ConvertToServiceModel(ProductMasterModel prodMast)
        {
            if (prodMast == null)
            {
                return null;
            }

            Map.CreateMap<ProductMasterModel, ServiceChemModel.ProductMaster>();
            return Map.Map<ProductMasterModel, ServiceChemModel.ProductMaster>(prodMast);
        }

        #endregion

        #region "PlantUtility"

        /// <summary>
        ///     Converts to WebModel.
        /// </summary>
        /// <param name="plantUtilitySetup"> plant Utility Setup</param>
        /// <returns>Plant Model</returns>
        internal static PlantUtilityFactorTypes ConvertToWebModel(Ecolab.Models.PlantSetup.PlantUtilityFactorTypes plantUtilitySetup)
        {
            if (plantUtilitySetup == null)
            {
                return null;
            }

            return Map.Map<Ecolab.Models.PlantSetup.PlantUtilityFactorTypes, PlantUtilityFactorTypes>(plantUtilitySetup);
        }

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="plantUtilitySetupModel">The plant Utility Setup Model. </param>
        /// <returns> plant Utility Setup Model. </returns>
        internal static PlantUtilitySetup ConvertToServiceModel(PlantUtilitySetupModel plantUtilitySetupModel)
        {
            if (plantUtilitySetupModel == null)
            {
                return null;
            }

            return Map.Map<PlantUtilitySetupModel, PlantUtilitySetup>(plantUtilitySetupModel);
        }

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="waterTypes">The water Types.</param>
        /// <returns> Plant Utility Water Type Master Model. </returns>
        internal static PlantUtilityWaterTypeMasterModel ConvertToWebModel(PlantUtilityWaterTypeMaster waterTypes)
        {
            if (waterTypes == null)
            {
                return null;
            }

            return Map.Map<PlantUtilityWaterTypeMaster, PlantUtilityWaterTypeMasterModel>(waterTypes);
        }

        /// <summary>
        ///     Converts to WebModel.
        /// </summary>
        /// <param name="gasOilTypes">The gas Oil Types.</param>
        /// <returns> Currency Plant Utility Gas oil Type Model. </returns>
        internal static PlantUtilityGasoilTypeModel ConvertToWebModel(PlantUtilityGasoilTypes gasOilTypes)
        {
            if (gasOilTypes == null)
            {
                return null;
            }

            return Map.Map<PlantUtilityGasoilTypes, PlantUtilityGasoilTypeModel>(gasOilTypes);
        }

        /// <summary>
        ///     Converts to Web Model.
        /// </summary>
        /// <param name="dimensionTypes">The dimension Types.</param>
        /// <returns> plant set up Model. </returns>
        internal static PlantUtilityDimesionTypesModel ConvertToWebModel(PlantUtilityDimensionTypes dimensionTypes)
        {
            if (dimensionTypes == null)
            {
                return null;
            }

            return Map.Map<PlantUtilityDimensionTypes, PlantUtilityDimesionTypesModel>(dimensionTypes);
        }

        /// <summary>
        ///     Convertion of Unit types to web model properties.
        /// </summary>
        /// <param name="plantUtilityUnitTypes">The properties for unit types class.</param>
        /// <returns>Mapped properties from service class to model class for plantUtilityUnitTypes.</returns>
        internal static PlantUtilityUnitTypesModel ConvertToWebModel(ServiceModel.PlantUtilityUnitTypes plantUtilityUnitTypes)
        {
            if (plantUtilityUnitTypes == null)
            {
                return null;
            }

            return Map.Map<ServiceModel.PlantUtilityUnitTypes, PlantUtilityUnitTypesModel>(plantUtilityUnitTypes);
        }

        #endregion

        #region "WasherGroup"

        /// <summary>
        ///     Converts to Service Model.
        /// </summary>
        /// <param name="washerGroupDetails">washer group Details.</param>
        /// <returns> Web model for washer group </returns>
        internal static WasherGroup ConvertToWebModel(Ecolab.Models.WasherGroup.WasherGroup washerGroupDetails)
        {
            if (washerGroupDetails == null)
            {
                return null;
            }

            return Map.Map<Ecolab.Models.WasherGroup.WasherGroup, WasherGroup>(washerGroupDetails);
        }

        /// <summary>
        ///     Converts to Service Model.
        /// </summary>
        /// <param name="washerGroupFormulaDetails">washer group formula details.</param>
        /// <returns> Web model for washer group </returns>
        internal static WasherGroupFormulaModel ConvertToWebModel(WasherGroupFormula washerGroupFormulaDetails)
        {
            if (washerGroupFormulaDetails == null)
            {
                return null;
            }

            return Map.Map<WasherGroupFormula, WasherGroupFormulaModel>(washerGroupFormulaDetails);
        }

        /// <summary>
        ///     Converts to Service Model.
        /// </summary>
        /// <param name="washStepWashOperationDetails">wash steps wash operations details.</param>
        /// <returns> Web model for wash step </returns>
        internal static WashStepModel ConvertToWebModel(WashStep washStepWashOperationDetails)
        {
            if (washStepWashOperationDetails == null)
            {
                return null;
            }

            return Map.Map<WashStep, WashStepModel>(washStepWashOperationDetails);
        }

        #endregion
    }
}