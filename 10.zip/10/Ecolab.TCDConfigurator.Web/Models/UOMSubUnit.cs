﻿// -----------------------------------------------------------------------
// <copyright file="UOMSubUnit.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The UOMSubUnit object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models
{
    /// <summary>
    ///     Model class for UOMSubUnit
    /// </summary>
    public class UOMSubUnit
    {
        /// <summary>
        ///     Gets or sets the UnitSystemId
        /// </summary>
        /// <value>UnitSystemId</value>
        public int UnitSystemId { get; set; }

        /// <summary>
        ///     Gets or sets the UsageKey 
        /// </summary>
        /// <value>UsageKey </value>
        public string UsageKey { get; set; }

        /// <summary>
        ///     Gets or sets the Unit 
        /// </summary>
        /// <value>Unit </value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit_Source
        /// </summary>
        /// <value>SubUnit_Source</value>
        public string SubUnit_Source { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit_Target
        /// </summary>
        /// <value>SubUnit_Target</value>
        public string SubUnit_Target { get; set; }
    }
}