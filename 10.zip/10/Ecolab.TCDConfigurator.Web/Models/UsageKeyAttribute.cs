﻿// -----------------------------------------------------------------------
// <copyright file="UsageKeyAttribute.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Usage Key Attribute class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models
{
    using System;

    /// <summary>
    ///     UsageKeyAttribute Class
    /// </summary>
    public class UsageKeyAttribute : Attribute
    {
        public UsageKeyAttribute(string name,string propertyName = "")
        {
            this.Name = name;
            this.PropertyName = propertyName;
        }

        /// <summary>
        ///     Gets or Sets Name
        /// </summary>
        /// <value>Contains Name Value for the UsageKey</value>
        public string Name { get; private set; }

        /// <summary>
        ///     Gets or Sets PropertyName
        /// </summary>
        /// <value>Contains PropertyName Value for the UsageKey</value>
        public string PropertyName { get; private set; }
    }
}