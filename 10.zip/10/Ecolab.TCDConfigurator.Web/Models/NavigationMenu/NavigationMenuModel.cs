﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationMenu Model</summary>
// ----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.NavigationMenu
{
    /// <summary>
    ///     The NavigationMenuModel class
    /// </summary>
    public class NavigationMenuModel
    {
        /// <summary>
        ///     Gets or sets the Id
        /// </summary>
        /// <value> The Id of the menu item.</value>
        public int Id { get; set; }

        public int Number { get; set; }

        /// <summary>
        ///     Gets or sets the Name
        /// </summary>
        /// <value> The Name of the menu item.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the ParentId
        /// </summary>
        /// <value> The Parent Id</value>
        public int ParentId { get; set; }

        /// <summary>
        ///     Gets or sets the TypeId
        /// </summary>
        /// <value> The TypeId for menu item.</value>
        public int TypeId { get; set; }

        /// <summary>
        ///     Gets or sets the TypeName
        /// </summary>
        /// <value> The Type Name.</value>
        public string TypeName { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        /// <value> The ControllerTypeId.</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId
        /// </summary>
        /// <value> The ControllerModelId.</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupId
        /// </summary>
        /// <value> The WasherGroupId.</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the WasherTypeFlag
        /// </summary>
        /// <value> The WasherTypeFlag.</value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeId
        /// </summary>
        /// <value> The WasherGroupTypeId.</value>
        public int WasherGroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Hierarchy
        /// </summary>
        /// <value> The Hierarchy.</value>
        public string Hierarchy { get; set; }
    }
}