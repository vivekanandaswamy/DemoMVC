﻿// -----------------------------------------------------------------------
// <copyright file="MenuViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Menu ViewModel</summary>
// ----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.NavigationMenu
{
    using System.Collections.Generic;

    /// <summary>
    ///     The MenuViewModel class
    /// </summary>
    public class MenuViewModel
    {
        /// <summary>
        ///     Gets or sets the Menu
        /// </summary>
        /// <value> The menu item.</value>
        public NavigationMenuModel Menu { get; set; }

        /// <summary>
        ///     Gets or sets the sub Menu list
        /// </summary>
        /// <value> The Sub Menu list.</value>
        public List<SubMenuViewModel> SubMenus { get; set; }
    }
}