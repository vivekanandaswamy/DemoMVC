﻿// -----------------------------------------------------------------------
// <copyright file="NavigationMenuDataViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The NavigationMenu Data ViewModel</summary>
// ----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.NavigationMenu
{
    using System.Collections.Generic;

    /// <summary>
    ///     The NavigationMenuDataViewModel class
    /// </summary>
    public class NavigationMenuDataViewModel
    {
        /// <summary>
        ///     Gets or sets the NavigationMenu ViewModel List
        /// </summary>
        /// <value> The Navigation MenuViewModelList.</value>
        public List<NavigationMenuViewModel> NavigationMenuViewModelList { get; set; }

        /// <summary>
        ///     Gets or sets the NavigationMenu Model List
        /// </summary>
        /// <value> The NavigationMenu ModelList.</value>
        public List<NavigationMenuModel> NavigationMenuModelList { get; set; }
    }
}