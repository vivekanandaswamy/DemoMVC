﻿// -----------------------------------------------------------------------
// <copyright file="TanksModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tanks object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.StorageTanks
{
    using System;
    using System.Collections.Generic;
    using ControllerSetup;
    using ControllerSetup.Pumps;
    using Dcs.Entities;

    /// <summary>
    ///     class TanksModel
    /// </summary>
    public class TanksModel : BaseViewModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Tank Id
        /// </summary>
        public int TankId { get; set; }

        /// <summary>
        ///     Gets or sets the Tank Name
        /// </summary>
        public string TankName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Id
        /// </summary>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Name
        /// </summary>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Empty Level
        /// </summary>
        [UsageKeyAttribute("Volume_CommonUse_Short", "EmptyLevelDisplay")]
        public decimal EmptyLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Low Level
        /// </summary>
        [UsageKeyAttribute("Volume_CommonUse_Short", "LowLevelDisplay")]
        public decimal LowLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Callibration Level
        /// </summary>
        [UsageKeyAttribute("Volume_CommonUse_Short", "CalibrationLevelDisplay")]
        public decimal CallibrationLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Input Type
        /// </summary>
        public string InputType { get; set; }

        /// <summary>
        ///     Gets or sets the Current level
        /// </summary>
        [UsageKeyAttribute("Volume_CommonUse_Short", "CurrentLevelDisplay")]
        public decimal CurrentLevel { get; set; }

        /// <summary>
        ///     Gets or sets the Current level
        /// </summary>
        public string CurrentLevelAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Current Level Tag
        /// </summary>
        public string CurrentLevelTag { get; set; }

        /// <summary>
        ///     Gets or sets the Level Deviation
        /// </summary>
        [UsageKeyAttribute("Volume_CommonUse_Short", "LevelDeviationDisplay")]
        public decimal LevelDeviation { get; set; }

        /// <summary>
        ///     Gets or sets the Level Deviation Tag
        /// </summary>
        public string LevelDeviationTag { get; set; }

        /// <summary>
        ///     Gets or sets the Size
        /// </summary>
        [UsageKeyAttribute("Volume_CommonUse_Short", "SizeDisplay")]
        public decimal Size { get; set; }

        /// <summary>
        ///     Gets or sets the Size Tag
        /// </summary>
        public string SizeTag { get; set; }

        /// <summary>
        ///     Gets or sets the Product Id
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets the Product Name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets and sets the List of Controllers
        /// </summary>
        public List<ControllerModel> Controllers { get; set; }

        /// <summary>
        ///     Gets and sets the List of Controllers
        /// </summary>
        public List<ControllerSetup.Pumps.ProductModel> Products { get; set; }

        /// <summary>
        ///     Gets or sets the Override Plc Values
        /// </summary>
        public bool OverridePlcValues { get; set; }

        /// <summary>
        ///     Gets or sets the PLC Tags
        /// </summary>
        public List<OpcTag> PlcTags { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp at central
        /// </summary>
        /// <value>LastModifiedTimeStampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        /// Gets or sets the IsCentral
        /// </summary>
        /// <value>IsCentral</value>
        public String IsCentral { get; set; }

        /// <summary>
        ///     Gets or sets the Empty Level
        /// </summary>
        public string EmptyLevelAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Low Level
        /// </summary>
        public string LowLevelAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Callibration Level
        /// </summary>
        public string CallibrationLevelAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Level Deviation
        /// </summary>
        public string LevelDeviationAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Size
        /// </summary>
        public string SizeAsString { get; set; }

        /// <summary>
        ///     Gets or sets the LowLevelDisplay
        /// </summary>
        /// <value>The Parameter LowLevelDisplay  </value>
        public decimal LowLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the EmptyLevelDisplay
        /// </summary>
        /// <value>The Parameter EmptyLevelDisplay</value>
        public decimal EmptyLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the CalibrationLevelDisplay
        /// </summary>
        /// <value>The Parameter CalibrationLevelDisplay</value>
        public decimal CalibrationLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentLevelDisplay
        /// </summary>
        /// <value>The Parameter CurrentLevelDisplay</value>
        public decimal CurrentLevelDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the LevelDeviationDisplay
        /// </summary>
        /// <value>The Parameter LevelDeviationDisplay </value>
        public decimal LevelDeviationDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the SizeDisplay 
        /// </summary>
        /// <value>The Parameter SizeDisplay Level</value>
        public decimal SizeDisplay { get; set; }

        /// <summary>
        ///     Gets or sets the Current Level PlcOverride
        /// </summary>
        /// <value>CurrentLevelPlcOverride</value>
        public bool CurrentLevelPlcOverride { get; set; }

        /// <summary>
        ///     Gets or sets the Size PlcOverride
        /// </summary>
        /// <value>SizePlcOverride</value>
        public bool SizePlcOverride { get; set; }

        /// <summary>
        ///     Gets or sets the Level Deviation PlcOverride
        /// </summary>
        /// <value>Level Deviation PlcOverride</value>
        public bool LevelDeviationPlcOverride { get; set; }
        #endregion
    }
}