﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupPrintModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ControllerSetupPrintModel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Models
{
    using System.Collections.Generic;
    using ControllerSetup;
    using ControllerSetup.Pumps;

    public class ControllerSetupPrintModel
    {
        /// <summary>
        ///     Gets or sets the value ControllerGeneralData
        /// </summary>
        public List<MetaDataModel> ControllerGeneralData { get; set; }

        /// <summary>
        ///     Gets or sets the value ControllerAdvancedData
        /// </summary>
        public List<MetaDataModel> ControllerAdvancedData { get; set; }

        /// <summary>
        ///     Gets or sets the value PumpsValvesData
        /// </summary>
        public List<PumpsModel> PumpsValvesData { get; set; }

        /// <summary>
        ///     Gets the current Region Id
        /// </summary>
        public int RegionId { get; set; }
    }
}