﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Management View Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.UserManagement
{
    using System.Collections.Generic;
    using Ecolab.Models;

    /// <summary>
    ///     Model class UserManagementViewModel
    /// </summary>
    public class UserManagementViewModel
    {
        /// <summary>
        ///     Gets or sets UserManagementModel Object UserManagement
        /// </summary>
        public UserManagementModel UserManagement { get; set; }

        /// <summary>
        ///     Gets or sets List of UserRoles Object UserRole
        /// </summary>
        public IEnumerable<UserRoles> UserRole { get; set; }

        public IEnumerable<UserManagementModel> UserManagementList { get; set; }
    }
}