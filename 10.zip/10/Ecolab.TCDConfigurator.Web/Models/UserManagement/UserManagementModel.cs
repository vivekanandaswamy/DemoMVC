﻿// -----------------------------------------------------------------------
// <copyright file="UserManagementModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Management Model</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.UserManagement
{
    using System;

    /// <summary>
    ///     Model class UserManagementModel
    /// </summary>
    public class UserManagementModel
    {
        /// <summary>
        ///     Gets or sets UserId
        /// </summary>
        /// <value>The user Number.</value>
        public int UserNumber { get; set; }

        /// <summary>
        ///     Gets or sets FirstName
        /// </summary>
        /// <value>The First name.</value>
        public string FirstName { get; set; }

        /// <summary>
        ///     Gets or sets LastName
        /// </summary>
        /// <value>The last name.</value>
        public string LastName { get; set; }

        /// <summary>
        ///     Gets or sets LoginName
        /// </summary>
        /// <value>The Login name</value>
        public string LoginName { get; set; }

        /// <summary>
        ///     Gets or sets Password
        /// </summary>
        /// <value>The Password.</value>
        public string Password { get; set; }

        /// <summary>
        ///     Gets or sets Email
        /// </summary>
        /// <value>The Email value.</value>
        public string Email { get; set; }

        /// <summary>
        ///     Gets or sets ContactNo
        /// </summary>
        /// <value>The Contact No.</value>
        public string ContactNo { get; set; }

        /// <summary>
        ///     Gets or sets LevelId
        /// </summary>
        /// <value>The Level id.</value>
        public int LevelId { get; set; }

        /// <summary>
        ///     Gets or sets LanguageId
        /// </summary>
        /// <value>The Language id.</value>
        public int LanguageId { get; set; }

        /// <summary>
        ///     Gets or sets LanguageName
        /// </summary>
        /// <value>The Language Name.</value>
        public string LanguageName { get; set; }

        /// <summary>
        ///     Gets or sets RoleName
        /// </summary>
        /// <value>The Role Name.</value>
        public string RoleName { get; set; }

        /// <summary>
        ///     Gets or sets EcolabAccountNumber
        /// </summary>
        /// <value>The Ecolab account number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets Title
        /// </summary>
        /// <value>The Title value.</value>
        public string Title { get; set; }

        /// <summary>
        ///     Gets or sets Mobile
        /// </summary>
        /// <value>Mobile Number</value>
        public string Mobile { get; set; }

        /// <summary>
        ///     Gets or sets Fax
        /// </summary>
        /// <value>Fax number</value>
        public string Fax { get; set; }

        /// <summary>
        ///     Gets or Sets the ContactId
        /// </summary>
        /// <value> Parameter Contact Id</value>
        public int? ContactId { get; set; }

        /// <summary>
        ///     Gets or sets the UOMId.
        /// </summary>
        /// <value> The UOM Id.</value>
        public int UOMId { get; set; }

        /// <summary>
        ///     Gets or sets the CurrencyCode.
        /// </summary>
        /// <value> the Currency Code.</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets IsActive
        /// </summary>
        /// <value>Isactive</value>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        /// Gets or sets LastSyncTime 
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        /// Get or sets LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
        
        /// <summary>
        /// get or sets the max level 
        /// </summary>
        public int MaxLevel { get; set; }
    }
}