﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityGasoilTypeModel.cs" company="Ecolab">
// Model class for all the lists for plant Utility.
// </copyright>
// <summary>The Plant Utility Gas oil Type Model.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model class for all the lists for PlantUtilityGasoilTypeModel.
    /// </summary>
    public class PlantUtilityGasoilTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets WaterTypeId
        /// </summary>
        /// <value>Water Type Id.</value>
        public int GasoilTypeId { get; set; }

        /// <summary>
        ///     Gets or sets WaterTypeName
        /// </summary>
        /// <value>Water Type Name.</value>
        public string GasoilTypeName { get; set; }

        #endregion
    }
}