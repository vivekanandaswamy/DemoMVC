﻿// -----------------------------------------------------------------------
// <copyright file="PlantModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant object</summary>
// -----------------------------------------------------------------------;

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     class PlantModel
    /// </summary>
    public class PlantModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Ecoalab Account Number.
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Name.
        /// </summary>
        /// <value> The Name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the DataLiveTime.
        /// </summary>
        /// <value> The Data Live Time.</value>
        public int DataLiveTime { get; set; }

        /// <summary>
        ///     Gets or sets the BudgetCustomer.
        /// </summary>
        /// <value> The Budget Customer.</value>
        public bool BudgetCustomer { get; set; }

        /// <summary>
        ///     Gets or sets the AllowManualRewash.
        /// </summary>
        /// <value> The Allow Manual Rewash.</value>
        public bool AllowManualRewash { get; set; }

        /// <summary>
        ///     Gets or sets the ExportPath.
        /// </summary>
        /// <value> The Export Path.</value>
        public string ExportPath { get; set; }

        /// <summary>
        ///     Gets or sets the LanguageId.
        /// </summary>
        /// <value> The Language Id.</value>
        public int LanguageId { get; set; }

        /// <summary>
        ///     Gets or sets the UOMId.
        /// </summary>
        /// <value> The UOM Id.</value>
        public int UOMId { get; set; }

        /// <summary>
        ///     Gets or sets the CurrencyCode.
        /// </summary>
        /// <value> the Currency Code.</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets the WasteWaterPercentage.
        /// </summary>
        /// <value> The Waste Water Percentage.</value>
        public decimal WasteWaterPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the WasteWaterCostPerGallon.
        /// </summary>
        /// <value> The Waste Water Cost Per Gallon.</value>
        public string WasteWaterCostPerGallon { get; set; }

        /// <summary>
        ///     Gets or sets the PlantCategoryId.
        /// </summary>
        /// <value> The Plant Category Id.</value>
        public int PlantCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets the AcutalIsTarget.
        /// </summary>
        /// <value> The Acutal Is Target.</value>
        public bool AcutalIsTarget { get; set; }

        /// <summary>
        ///     Gets or sets the RegionId.
        /// </summary>
        /// <value> The Region Id.</value>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the RegionName.
        /// </summary>
        /// <value> The Region Name.</value>
        public string RegionName { get; set; }

        /// <summary>
        ///     Gets or sets the PlantChainId.
        /// </summary>
        /// <value> The Plant Chain Id.</value>
        public int PlantChainId { get; set; }

        /// <summary>
        ///     Gets or sets the PlantChainName.
        /// </summary>
        /// <value> The Plant Chain Name.</value>
        public string PlantChainName { get; set; }

        /// <summary>
        ///     Gets or sets the Logo.
        /// </summary>
        /// <value> The Logo.</value>
        public string Logo { get; set; }

        /// <summary>
        ///     Gets or sets the CreatedOn.
        /// </summary>
        /// <value> The CreatedOn.</value>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        ///     Gets or sets the CreatedBy.
        /// </summary>
        /// <value> The Created By.</value>
        public int CreatedBy { get; set; }

        /// <summary>
        ///     Gets or sets the ModifiedOn.
        /// </summary>
        /// <value> The Modified On.</value>
        public DateTime ModifiedOn { get; set; }

        /// <summary>
        ///     Gets or sets the ModifiedBy.
        /// </summary>
        /// <value> The Modified By.</value>
        public string ModifiedBy { get; set; }

        /// <summary>
        ///     Gets or sets the TMName.
        /// </summary>
        /// <value> The Teritory Manager Name.</value>
        public string TMName { get; set; }

        /// <summary>
        ///     Gets or sets the TMPhoneNumner.
        /// </summary>
        /// <value> The Teritory Manager PhoneNumner.</value>
        public string TMPhoneNumner { get; set; }

        /// <summary>
        ///     Gets or sets the DMName.
        /// </summary>
        /// <value> The DM Name.</value>
        public string DMName { get; set; }

        /// <summary>
        ///     Gets or sets the DMPhoneNumner.
        /// </summary>
        /// <value> The DM PhoneNumner.</value>
        public string DMPhoneNumner { get; set; }

        /// <summary>
        /// Gets or sets the helms number.
        /// </summary>
        /// <value>
        /// The helms number.
        /// </value>
        public string HelmsNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Chain.
        /// </summary>
        /// <value> The Chain.</value>
        public string Chain { get; set; }

        /// <summary>
        ///     Gets or sets the ChainUnitNumber.
        /// </summary>
        /// <value> The Chain Unit Number.</value>
        public string ChainUnitNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ChainRegions.
        /// </summary>
        /// <value> The Chain Regions.</value>
        public string ChainRegions { get; set; }

        /// <summary>
        ///     Gets or sets the CensusPriceKg.
        /// </summary>
        /// <value> The Census Price Kg.</value>
        public string CensusPriceKg { get; set; }

        /// <summary>
        ///     Gets or sets the Remarks.
        /// </summary>
        /// <value> The Remarks.</value>
        public string Remarks { get; set; }

        /// <summary>
        ///     Gets or sets the Rate.
        /// </summary>
        /// <value> The Rate.</value>
        public int Rate { get; set; }

        /// <summary>
        ///     Gets or sets the list of Units of measures.
        /// </summary>
        /// <value> The measures.</value>
        public List<DimensionalUnitSystemsModel> Uoms { get; set; }

        /// <summary>
        ///     Gets or sets the list of CurrencyCodes.
        /// </summary>
        /// <value> The CurrencyCodes.</value>
        public List<CurrencyMasterModel> CurrencyCodes { get; set; }

        /// <summary>
        ///     Gets or sets the the list of Languages.
        /// </summary>
        /// <value> The Languages.</value>
        public List<LanguageMasterModel> Languages { get; set; }

        /// <summary>
        ///     PlantCustAddressModel
        /// </summary>
        public virtual PlantCustAddressModel plantCustAddr { get; set; }

        /// <summary>
        ///     ShippingAddressModel
        /// </summary>
        public virtual ShippingAddressModel shippingAddr { get; set; }

        /// <summary>
        ///     Gets or sets the LanguageName
        /// </summary>
        public string LanguageName { get; set; }

        /// <summary>
        ///     Gets or sets the CurrencyName
        /// </summary>
        public string CurrencyName { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystem
        /// </summary>
        public string UnitSystem { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the Last Service Visit Date
        /// </summary>
        /// <value>LastServiceVisitDate</value>
        public DateTime? LastServiceVisitDate { get; set; }

        /// <summary>
        ///     Gets or sets the Next Service Visit Date
        /// </summary>
        /// <value>NextServiceVisitDate</value>
        public DateTime? NextServiceVisitDate { get; set; }

        /// <summary>
        ///     Gets or sets the Last Archive Date
        /// </summary>
        /// <value>LastArchiveDate</value>
        public DateTime? LastArchiveDate { get; set; }

        /// <summary>
        /// Gets or sets PlantStandardTurnTime
        /// </summary>
        public int PlantStandardTurnTime { get; set; }

        /// <summary>
        /// Gets or sets PlantContractNumber
        /// </summary>
        public string PlantContractNumber { get; set; }

        /// <summary>
        /// Gets or sets DayId
        /// </summary>
        public int DayId { get; set; }

        /// <summary>
        /// Gets or sets Start Time
        /// </summary>
        public string StartTime { get; set; }

        /// <summary>
        /// Gets or sets End Time
        /// </summary>
        /// <value>
        /// The end time.
        /// </value>
        public string EndTime { get; set; }

        /// <summary>
        ///     Gets or sets the EtechEnable.
        /// </summary>
        /// <value> The EtechEnable.</value>
        public bool IsETechEnable { get; set; }

        /// <summary>
        ///     Gets or sets the EtechIpAddress.
        /// </summary>
        /// <value> The EtechEnable.</value>
        public string EtechIpAddress { get; set; }
        #endregion
    }
}