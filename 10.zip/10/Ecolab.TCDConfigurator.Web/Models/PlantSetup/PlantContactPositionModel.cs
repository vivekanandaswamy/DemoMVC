﻿// -----------------------------------------------------------------------
// <copyright file="PlantContactPositionModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Contact Position Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    using System;

    /// <summary>
    ///     Model class for PlantContactPositionModel
    /// </summary>
    public class PlantContactPositionModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the PositionName
        /// </summary>
        /// <value>Position Name</value>
        public string PositionName { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        public short MyServiceCntctPosnId { get; set; }

        public DateTime MyServiceModDtTm { get; set; }
    }
}