﻿// -----------------------------------------------------------------------
// <copyright file="TargetProductionData.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TargetProductionData class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Class for TargetProductionData
    /// </summary>
    public class TargetProductionData
    {
        /// <summary>
        ///     Gets or sets the DisplayOrder
        /// </summary>
        /// <value> Parameter DisplayOrder</value>
        public int DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the DayData
        /// </summary>
        /// <value> Parameter DayData</value>
        public List<TargetProduction> DayData { get; set; }

        /// <summary>
        ///     Gets or sets the Date
        /// </summary>
        /// <value> Parameter Date</value>
        public string Date { get; set; }
    }
}