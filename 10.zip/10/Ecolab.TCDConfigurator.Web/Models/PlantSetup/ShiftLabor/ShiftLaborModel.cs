﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Shift Labor Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class for ShiftLaborModel
    /// </summary>
    public class ShiftLaborModel
    {
        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value> The labour Id for ShiftLaborModel. </value>
        public int? LaborId { get; set; }

        /// <summary>
        ///     Gets or sets the ShiftId.
        /// </summary>
        /// <value> The Shift Id for ShiftLaborModel. </value>
        public short ShiftId { get; set; }

        /// <summary>
        ///     Gets or sets the DayId.
        /// </summary>
        /// <value>The Day Id value.</value>
        public int DayId { get; set; }

        /// <summary>
        ///     Gets or sets the LaborTypeId.
        /// </summary>
        /// <value> Labor Type Id for ShiftLaborModel.</value>
        public int LaborTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the LaborTypeName.
        /// </summary>
        /// <value> Labor Type Name.</value>
        public string LaborTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the LocationId.
        /// </summary>
        /// <value> Location Id for ShiftLaborModel.</value>
        public int LocationId { get; set; }

        /// <summary>
        ///     Gets or sets the LoactionName.
        /// </summary>
        /// <value> Loaction Name for ShiftLaborModel.</value>
        public string LoactionName { get; set; }

        /// <summary>
        ///     Gets or sets the LaborHours.
        /// </summary>
        /// <value> The Man hours for ShiftLaborModel.</value>
        public int LaborHours { get; set; }

        /// <summary>
        ///     Gets or sets the LaborHours.
        /// </summary>
        /// <value> The Man hours for ShiftLaborModel.</value>
        public string LaborHoursAsString { get; set; }

        /// <summary>
        ///     Gets or sets the LaborCount.
        /// </summary>
        /// <value> Labor Count for ShiftLaborModel.</value>
        public int LaborCount { get; set; }

        /// <summary>
        ///     Gets or sets the PricePerHr.
        /// </summary>
        /// <value> PricePerHr for ShiftLaborModel. </value>
        public decimal PricePerHr { get; set; }

        /// <summary>
        ///     Gets or sets the PricePerHr.
        /// </summary>
        /// <value> PricePerHr for ShiftLaborModel. </value>
        public string PricePerHrAsString { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Locations
        /// </summary>
        /// <value> Locations  for ShiftLaborModel. </value>
        public List<GroupTypeModel> Locations { get; set; }

        /// <summary>
        ///     Gets or sets the Locations
        /// </summary>
        /// <value> LaborTypes for ShiftLaborModel. </value>
        public List<LaborTypeModel> LaborTypes { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime for ShiftLaborModel</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete for ShiftLaborModel</value>
        public bool IsDelete { get; set; }
    }
}