﻿// -----------------------------------------------------------------------
// <copyright file="TargetProdDetails.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TargetProdDetails class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     Class for TargetProdDetails
    /// </summary>
    public class TargetProdDetails
    {
        /// <summary>
        ///     Gets or sets the Sunday
        /// </summary>
        /// <value> Parameter Sunday</value>
        public TargetProductionData Sunday { get; set; }

        /// <summary>
        ///     Gets or sets the Monday
        /// </summary>
        /// <value> Parameter Monday</value>
        public TargetProductionData Monday { get; set; }

        /// <summary>
        ///     Gets or sets the Tuesday
        /// </summary>
        /// <value> Parameter Tuesday</value>
        public TargetProductionData Tuesday { get; set; }

        /// <summary>
        ///     Gets or sets the Wednesday
        /// </summary>
        /// <value> Parameter Wednesday</value>
        public TargetProductionData Wednesday { get; set; }

        /// <summary>
        ///     Gets or sets the Thursday
        /// </summary>
        /// <value> Parameter Thursday</value>
        public TargetProductionData Thursday { get; set; }

        /// <summary>
        ///     Gets or sets the Friday
        /// </summary>
        /// <value> Parameter Friday</value>
        public TargetProductionData Friday { get; set; }

        /// <summary>
        ///     Gets or sets the Saturday
        /// </summary>
        /// <value> Parameter Saturday</value>
        public TargetProductionData Saturday { get; set; }

        /// <summary>
        ///     Gets or sets the Shift
        /// </summary>
        /// <value> Parameter Shift</value>
        public List<string> Shift { get; set; }
    }
}