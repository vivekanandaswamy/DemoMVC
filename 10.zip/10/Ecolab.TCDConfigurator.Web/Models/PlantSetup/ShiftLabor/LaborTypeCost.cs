﻿// -----------------------------------------------------------------------
// <copyright file="LaborTypeCost.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Labor Type Cost Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.ShiftLabor
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class for LaborTypeCost
    /// </summary>
    public class LaborTypeCost
    {
        /// <summary>
        ///     Gets or sets the LaborCostId
        /// </summary>
        /// <value>Labor Cost Id</value>
        public int LaborCostId { get; set; }

        /// <summary>
        ///     Gets or sets the Cost
        /// </summary>
        /// <value>The Cost value.</value>
        public decimal Cost { get; set; }
    }
}