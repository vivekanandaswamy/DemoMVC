﻿// -----------------------------------------------------------------------
// <copyright file="ShippingAddressModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ShippingAddress object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     class for Shipping Address
    /// </summary>
    public class ShippingAddressModel
    {
        /// <summary>
        ///     Gets or sets ShippingAddr1
        /// </summary>
        /// <value> Shipping Address 1.</value>
        public string ShippingAddr1 { get; set; }

        /// <summary>
        ///     Gets or sets ShippingAddr2
        /// </summary>
        /// <value> Shipping Address 2.</value>
        public string ShippingAddr2 { get; set; }

        /// <summary>
        ///     Gets or sets Shippingcity
        /// </summary>
        /// <value> Shipping city.</value>
        public string Shippingcity { get; set; }

        /// <summary>
        ///     Gets or sets Shippingcountry
        /// </summary>
        /// <value> Shipping country.</value>
        public string Shippingcountry { get; set; }

        /// <summary>
        ///     Gets or sets Shippingzip
        /// </summary>
        /// <value> Shipping zip.</value>
        public string Shippingzip { get; set; }
    }
}