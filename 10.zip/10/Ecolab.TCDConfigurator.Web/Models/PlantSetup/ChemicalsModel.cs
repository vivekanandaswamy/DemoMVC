﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalsModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemicals Model </summary>
// -----------------------------------------------------------------------

using System;

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model entity for Chemicals
    /// </summary>
    public class ChemicalsModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the GroupTypeId.
        /// </summary>
        /// <value> Group Type Id.</value>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupDescription.
        /// </summary>
        /// <value> Group Description.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Cost.
        /// </summary>
        /// <value>The Cost value.</value>
        public double Cost { get; set; }

        /// <summary>
        ///     Gets or sets IncludeinCI
        /// </summary>
        public bool IncludeinCI { get; set; }

        /// <summary>
        ///     Gets or sets the Desired Units.
        /// </summary>
        /// <value> The Desired units.</value>
        public string DesiredUnits { get; set; }

		/// <summary>
		/// Gets or sets PriceInOunce
		/// </summary>
		public double PriceInOunce { get; set; }

        /// <summary>
        /// Gets or Sets the Controller Equipment Type Id
        /// </summary>
        /// <value>The Controller Equipment Type Id</value>
        public int ControllerEquipmentTypeId { get; set; }
        /// <summary>
		/// Gets or Sets the Controller Equipment Id
		/// </summary>
		/// <value>The Controller Equipment Id</value>
		public byte? ControllerEquipmentId { get; set; }

        /// <summary>
		/// Gets or Sets the Controller Equipment Setup Id
		/// </summary>
		/// <value>The Controller Equipment Setup Id</value>
		public Int16? ControllerEquipmentSetupId { get; set; }
        #endregion
    }
}