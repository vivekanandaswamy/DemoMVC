﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustomerModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Customer </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    using System;

    /// <summary>
    ///     class Plant Customer Model
    /// </summary>
    public class PlantCustomerModel
    {
        /// <summary>
        ///     Gets or sets CustomerId
        /// </summary>
        /// <value>Customer Id.</value>
        public int CustomerId { get; set; }

        /// <summary>
        ///     Gets or sets CustomerName
        /// </summary>
        /// <value>Customer Name.</value>
        public string CustomerName { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        /// <value>Is Deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets Id
        /// </summary>
        /// <value>the identifier feild.</value>
        public int? Id { get; set; }

        /// <summary>
        ///     Gets or sets EcoalabAccountNumber
        /// </summary>
        /// <value> Ecoalab Account Number.</value>
        public string EcoalabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }
    }
}