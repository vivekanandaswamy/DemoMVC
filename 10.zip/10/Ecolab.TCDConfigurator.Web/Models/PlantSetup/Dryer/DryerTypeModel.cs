﻿// -----------------------------------------------------------------------
// <copyright file="DryerTypeModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerType Model Class</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Dryer
{
    /// <summary>
    /// Model for DryerTypeModel
    /// </summary>
    public class DryerTypeModel
    {
        /// <summary>
        ///     Gets or sets the DryerType Id.
        /// </summary>
        /// <value> DryerType Id. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the DryerType Name.
        /// </summary>
        /// <value> DryerType Name. </value>
        public string Name { get; set; }
    }
}