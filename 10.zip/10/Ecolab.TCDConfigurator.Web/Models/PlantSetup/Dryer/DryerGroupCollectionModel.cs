﻿// -----------------------------------------------------------------------
// <copyright file="DryerGroupCollectionModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The DryerGroupCollectionModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Dryer
{
    using System.Collections.Generic;

	/// <summary>
	/// Model for DryerGroupCollectionModel
	/// </summary>
    public class DryerGroupCollectionModel
    {
        /// <summary>
        ///     Populates only filtered records
        /// </summary>
        public List<DryerGroupModel> DryerGroups { get; set; }

		/// <summary>
		/// Gets or sets the number of records matched.
		/// </summary>
		/// <value>
		/// The number of records matched.
		/// </value>
        public int NumberOfRecordsMatched { get; set; }
    }
}