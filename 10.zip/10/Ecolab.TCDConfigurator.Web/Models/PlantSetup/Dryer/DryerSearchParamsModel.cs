﻿// -----------------------------------------------------------------------
// <copyright file="DryerSearchParamsModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dryer Search Params Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Dryer
{
    /// <summary>
    /// Model for DryerSearchParamsModel
    /// </summary>
    public class DryerSearchParamsModel //: SearchParamsModel
    {
    }
}