﻿// -----------------------------------------------------------------------
// <copyright file="DryerModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dryer Model class </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Dryer
{
    using System;

    /// <summary>
    /// Model for DryerModel
    /// </summary>
    public class DryerModel
    {
        /// <summary>
        ///     Gets or sets the Dryer Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer Number.
        /// </summary>
        /// <value> Dryer Number. </value>
        public int Number { get; set; }

        /// <summary>
        ///     Gets or sets the DryerName.
        /// </summary>
        /// <value> The Name value. </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer Nominalload.
        /// </summary>
        /// <value> Nominalload. </value>
        [UsageKeyAttribute("Mass_CommonUse_TCD", "ConvertedNominalload")]
        public decimal Nominalload { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer GroupId.
        /// </summary>
        /// <value> Dryer GroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Dryer GroupName.
        /// </summary>
        /// <value> GroupName. </value>
        public string GroupName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ActualUnits.
        /// </summary>
        /// <value> ActualUnits.</value>
        public string ActualUnits { get; set; }

        /// <summary>
        ///     Gets or sets the ActualUnits.
        /// </summary>
        /// <value> ActualUnits.</value>
        public string DesiredUnits { get; set; }

        /// <summary>
        ///     Gets or sets the ConvertedNominalload.
        /// </summary>
        /// <value> ConvertedNominalload.</value>
        public decimal ConvertedNominalload { get; set; }

        /// <summary>
        ///     Gets or sets the ConvertedNominalload.
        /// </summary>
        /// <value> ConvertedNominalload.</value>
        public string ConvertedNominalloadAsString { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the DryerType.
        /// </summary>
        /// <value> DryerType. </value>
        public DryerTypeModel DryerType { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer Group
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimeStampDryerGroup { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimeStampDryer { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}