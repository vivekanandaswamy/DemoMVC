﻿// -----------------------------------------------------------------------
// <copyright file="UOMMeterModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>UOMMeterModel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    public class UOMMeterModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the Unit.
        /// </summary>
        /// <value> The Unit value.</value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit.
        /// </summary>
        /// <value>The SubUnit.</value>
        public string SubUnit { get; set; }

        #endregion
    }
}