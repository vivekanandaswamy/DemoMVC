﻿// -----------------------------------------------------------------------
// <copyright file="SensorWebModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Sensor Web Model object for SensorModel List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    using System;

    /// <summary>
    /// Sendor Web Model
    /// </summary>
    public class SensorWebModel
    {
        /// <summary>
        ///     Sensor Model Class
        /// </summary>
        /// <summary>
        ///     Gets or sets the SensorNumber
        /// </summary>
        /// <value>Sensor Number</value>
        public int? SensorNumber { get; set; }

        /// <summary>
        ///     Gets or sets the SensorName
        /// </summary>
        /// <value>SensorName</value>
        public string SensorName { get; set; }

        /// <summary>
        ///     Gets or sets the SensorType
        /// </summary>
        /// <value>SensorType</value>
        public int? SensorType { get; set; }

        /// <summary>
        ///     Gets or sets the SensorTypeName
        /// </summary>
        /// <value>Sensor Name Type</value>
        public string SensorTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber
        /// </summary>
        /// <value>Ecolab Account Number</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerId
        /// </summary>
        /// <value>ControllerId</value>
        public int? ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerName
        /// </summary>
        /// <value>Controller Number</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Model Id
        /// </summary>
        /// <value> Controller Model Id</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Region Id
        /// </summary>
        /// <value> Controller Region Id</value>
        public int ControllerRegionId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type Id
        /// </summary>
        /// <value> Controller Type Id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or Sets the Controller Type
        /// </summary>
        /// <value> Controller Type</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the SensorLocation
        /// </summary>
        /// <value>SensorLocation</value>
        public int? SensorLocationId { get; set; }

        /// <summary>
        ///     Gets or sets the SensorLocation
        /// </summary>
        /// <value>SensorLocation</value>
        public string SensorLocation { get; set; }

        /// <summary>
        ///     Gets or sets the MachineId
        /// </summary>
        /// <value>The Machine Id.</value>
        public int? MachineId { get; set; }

        /// <summary>
        ///     Gets or sets the MachineId
        /// </summary>
        /// <value>MachineId</value>
        public string MachineName { get; set; }

        /// <summary>
        ///     Gets or sets the OutputType
        /// </summary>
        /// <value>OutputType</value>
        public string OutputType { get; set; }

        /// <summary>
        ///     Gets or sets the ChemicalforChartId
        /// </summary>
        /// <value>ChemicalforChart</value>
        public int? ChemicalforChartId { get; set; }

        /// <summary>
        ///     Gets or sets the ChemicalforChart
        /// </summary>
        /// <value>ChemicalforChart</value>
        public string ChemicalforChart { get; set; }

        /// <summary>
        ///     Gets or sets the UOM
        /// </summary>
        /// <value>The UOM value. </value>
        public string UOM { get; set; }

        /// <summary>
        ///     Gets or sets the UOMName
        /// </summary>
        /// <value>The UOMName. </value>
        public string UOMName { get; set; }

        /// <summary>
        ///     Gets or sets the DashboardActualValue
        /// </summary>
        /// <value>Dashboard Actual Value</value>
        public bool DashboardActualValue { get; set; }

        /// <summary>
        ///     Gets or sets the AnalogueImputNumber
        /// </summary>
        /// <value>AnalogueImputNumber</value>
        public string AnalogueImputNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Value for Calibration 4mA
        /// </summary>
        /// <value>CalibrationValue4</value>
        public decimal CalibrationValue4 { get; set; }

        /// <summary>
        ///     Gets or sets the Value for Calibration 20mA
        /// </summary>
        /// <value>CalibrationValue20</value>
        public decimal CalibrationValue20 { get; set; }

        /// <summary>
        ///     Gets or sets the Tag address for Calibration 4mA
        /// </summary>
        /// <value>CalibrationTag4</value>
        public string CalibrationTag4 { get; set; }

        /// <summary>
        ///     Gets or sets the Tag address for Calibration 20mA
        /// </summary>
        /// <value>CalibrationTag20</value>
        public string CalibrationTag20 { get; set; }

        /// <summary>
        ///     Gets or sets the Override Plc Values
        /// </summary>
        public bool OverridePlcValues { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration20mA Override Plc Values
        /// </summary>
        public bool Calibration20Override { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration4mA Override Plc Values
        /// </summary>
        public bool Calibration4Override { get; set; }
        /// <summary>
        /// Gets or Sets the SensorNum
        /// </summary>
        /// <value>The Sensor Num</value>
        public int SensorNum { get; set; }
        /// <summary>
        /// Gets or Sets the Alarm Enable
        /// </summary>
        /// <value>The Alarm Enable</value>
        public bool AlarmEnable { get; set; }
        /// <summary>
        /// Gets or Sets the Minimum Alarm Value
        /// </summary>
        /// <value>The Minimum Alarm Value</value>
        public int MinimumAlarmValue { get; set; }
        /// <summary>
        /// Gets or Sets the Maximum Alarm Value
        /// </summary>
        /// <value>The Maximum Alarm Value</value>
        public int MaximumAlarmValue { get; set; }
        /// <summary>
        /// Gets  or Sets The External Sensor
        /// </summary>
        /// <value>The External Sensor</value>
        public int ExternalSensor { get; set; }
        /// <summary>
        /// Gets or Sets ISWaterEnergyLogSel
        /// </summary>
        /// <value>The ISWaterEnergyLogSel value</value>
        public bool ISWaterEnergyLogSel { get; set; }
        /// <summary>
        /// Gets or Sets LfsWasherNumber
        /// </summary>
        /// <value>The LfsWasherNumber value</value>
        public int LfsWasherNumber { get; set; }
        /// <summary>
        /// Gets or Sets Pump Number
        /// </summary>
        /// <value>The Pump Number value</value>
        public int PumpNumber { get; set; }
        /// <summary>
        /// Gets or Sets IsTunnel
        /// </summary>
        /// <value>The IsTunnel Value</value>
        public bool IsTunnel { get; set; }
        /// <summary>
        /// Gets or Sets OutputType Override
        /// </summary>
        /// <value>The OutputType Override Value</value>
        public bool OutputTypeOverride { get; set; }
        /// <summary>
        /// Gets or Sets SensorType Override
        /// </summary>
        /// <value>The SensorType Override Value</value>
        public bool SensorTypeOverride { get; set; }
        /// <summary>
        /// Gets or Sets MachineCompartment Override
        /// </summary>
        /// <value>The Machine Compartment Override Value</value>
        public bool MachineCompartmentOverride { get; set; }
        /// <summary>
        /// Gets or Sets IsTunnel 
        /// </summary>
        /// <value>The IsTunnel</value
    }
}