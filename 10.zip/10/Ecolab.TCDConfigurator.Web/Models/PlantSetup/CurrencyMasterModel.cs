﻿// -----------------------------------------------------------------------
// <copyright file="CurrencyMasterModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Currency Master </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    /// Model for CurrencyMasterModel
    /// </summary>
    public class CurrencyMasterModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets CurrencyCode
        /// </summary>
        /// <value>Currency Code.</value>
        public string CurrencyCode { get; set; }

        /// <summary>
        ///     Gets or sets CurrencyName
        /// </summary>
        /// <value>Currency Name.</value>
        public string CurrencyName { get; set; }

        #endregion
    }
}