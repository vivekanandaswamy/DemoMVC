﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Finnisher Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Finnisher
{
    using System;

    /// <summary>
    /// Model for FinnisherModel
    /// </summary>
    public class FinnisherModel
    {
        /// <summary>
        ///     Gets or sets the Finnisher Number.
        /// </summary>
        /// <value> Finnisher Number. </value>
        public int Number { get; set; }

        /// <summary>
        ///     Gets or sets the FinnisherName.
        /// </summary>
        /// <value>The Name value. </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the Finnisher GroupId.
        /// </summary>
        /// <value> Finnisher GroupId. </value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the Finnisher GroupName.
        /// </summary>
        /// <value> GroupName. </value>
        public string GroupName { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> IsDeleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the finisher number.
        /// </summary>
        public int FinisherId { get; set; }

        /// <summary>
        ///     Gets or sets the FinnisherType.
        /// </summary>
        /// <value> FinnisherType. </value>
        public FinnisherTypeModel FinnisherType { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Finnisher Group
        /// </summary>
        /// <value>LastModifiedTimeStampFinnisherGroup</value>
        public DateTime LastModifiedTimeStampFinnisherGroup { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Finnisher
        /// </summary>
        /// <value>LastModifiedTimeStampFinnisher</value>
        public DateTime LastModifiedTimeStampFinnisher { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }
    }
}