﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherTypeModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Finnisher Type Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Finnisher
{
    /// <summary>
    /// Model for FinnisherTypeModel
    /// </summary>
    public class FinnisherTypeModel
    {
        /// <summary>
        ///     Gets or sets the FinnisherType Id.
        /// </summary>
        /// <value> FinnisherType Id. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the FinnisherType Name.
        /// </summary>
        /// <value> FinnisherType Name. </value>
        public string Name { get; set; }
    }
}