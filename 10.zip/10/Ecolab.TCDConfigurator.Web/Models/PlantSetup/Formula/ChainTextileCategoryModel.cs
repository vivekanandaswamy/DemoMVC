﻿// -----------------------------------------------------------------------
// <copyright file="ChainTextileCategoryModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chain Textile Category Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Formula
{
    /// <summary>
    ///     class ChainTextileCategoryModel
    /// </summary>
    public class ChainTextileCategoryModel
    {
        /// <summary>
        ///     Gets or sets TextileId
        /// </summary>
        /// <value> Textile Id.</value>
        public int TextileId { get; set; }

        /// <summary>
        ///     Gets or sets Name
        /// </summary>
        /// <value> Name.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets EcolabTextileCategoryId
        /// </summary>
        /// <value> EcolabTextileCategoryId.</value>
        public int EcolabTextileCategoryId { get; set; }

        /// <summary>
        ///     Gets or sets Textile Saturation
        /// </summary>
        /// <value>The Textile Id .</value>
        public int TextileSaturation { get; set; }
    }
}