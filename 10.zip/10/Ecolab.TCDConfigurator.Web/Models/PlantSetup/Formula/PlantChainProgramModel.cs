﻿// -----------------------------------------------------------------------
// <copyright file="PlantChainProgramModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Chain Program Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.Formula
{
    /// <summary>
    ///     class PlantChainProgramModel
    /// </summary>
    public class PlantChainProgramModel
    {
        /// <summary>
        ///     Gets or sets PlantProgramId
        /// </summary>
        /// <value> PlantProgram Id.</value>
        public int PlantProgramId { get; set; }

        /// <summary>
        ///     Gets or sets ProgramMasterId
        /// </summary>
        /// <value> ProgramMaster Id.</value>
        public int ProgramMasterId { get; set; }

        /// <summary>
        ///     Gets or sets PlantProgramName
        /// </summary>
        /// <value> PlantProgram Name.</value>
        public string PlantProgramName { get; set; }

        /// <summary>
        /// Gets or sets the chain textile identifier.
        /// </summary>
        /// <value>The chain textile identifier.</value>
        public int FormulaCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the name of the chain textile.
        /// </summary>
        /// <value>The name of the chain textile.</value>
        public string FormulaCategoryName { get; set; }

        /// <summary>
        /// Gets or sets the formula segment identifier.
        /// </summary>
        /// <value>The formula segment identifier.</value>
        public int FormulaSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the name of the formula segment.
        /// </summary>
        /// <value>The name of the formula segment.</value>
        public string FormulaSegmentName { get; set; }

        /// <summary>
        /// Gets or sets the ecolab saturation identifier.
        /// </summary>
        /// <value>The ecolab saturation identifier.</value>
        public int EcolabSaturationId { get; set; }

        /// <summary>
        /// Gets or sets the name of the ecolab saturation.
        /// </summary>
        /// <value>The name of the ecolab saturation.</value>
        public string EcolabSaturationName { get; set; }
        /// <summary>
        ///     Gets or sets the Pieces.
        /// </summary>
        /// <value> The Pieces.</value>
        public int? EcolabTextileId { get; set; }

        /// <summary>
        ///     Gets or sets the TextileId.
        /// </summary>
        /// <value> The Textile Id.</value>
        public int? ChainTextileId { get; set; }
        /// <summary>
        /// chainTextileCategoryName
        /// </summary>
        public string EcolabCategoryName { get; set; }
        /// <summary>
        /// chainTextileCategoryName
        /// </summary>
        public string ChainTextileCategoryName { get; set; }
    }
}