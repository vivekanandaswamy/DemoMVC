﻿// -----------------------------------------------------------------------
// <copyright file="FormulaViewModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Formula View Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    using System.Collections.Generic;
    using Ecolab.Models;
    using Formula;

    /// <summary>
    ///     class FormulaViewModel
    /// </summary>
    public class FormulaViewModel
    {
        /// <summary>
        ///     Gets or sets the formula.
        /// </summary>
        /// <value>The formula.</value>
        public List<FormulaModel> formula { get; set; }

        /// <summary>
        ///     Gets or sets the ecolab Textile Category.
        /// </summary>
        /// <value>The ecolab Textile Category.</value>
        public List<EcolabTextileCategoryModel> EcolabTextileCategory { get; set; }

        /// <summary>
        ///     Gets or sets the ecolab Saturation.
        /// </summary>
        /// <value>The ecolab Saturation.</value>
        public List<EcolabSaturationModel> ecolabSaturation { get; set; }

        /// <summary>
        ///     Gets or sets the plant Chain Program.
        /// </summary>
        /// <value>The plant Chain Program.</value>
        public List<PlantChainProgramModel> plantChainProgram { get; set; }

        /// <summary>
        ///     Gets or sets the chain Textile Category.
        /// </summary>
        /// <value>The chain Textile Category.</value>
        public List<ChainTextileCategoryModel> chainTextileCategory { get; set; }

        /// <summary>
        /// Gets or sets the formula segments.
        /// </summary>
        /// <value>The formula segments.</value>
        public List<FormulaSegmentModel> FormulaSegments { get; set; }
        /// <summary>
        ///     Gets or sets the units.
        /// </summary>
        /// <value>The units.</value>
        public List<PlantUtilityUnitTypes> units { get; set; }

        /// <summary>
        ///     Gets or sets the plant Chain Program.
        /// </summary>
        /// <value>The plant Chain Program.</value>
        public List<PlantCustomer> CustomerList { get; set; }
    }
}