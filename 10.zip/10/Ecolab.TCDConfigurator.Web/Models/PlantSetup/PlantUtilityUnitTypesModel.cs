﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityUnitTypesModel.cs" company="Ecolab">
// Model class for all the lists for plant Utility.
// </copyright>
// <summary>The Plant Utility Unit Types Model.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     Properties class for PlantUtilityUnitTypesModel.
    /// </summary>
    public class PlantUtilityUnitTypesModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the name of the Unit.
        /// </summary>
        /// <value> The unit name value.</value>
        public string Unit { get; set; }

        /// <summary>
        ///     Gets or sets the Sub unit.
        /// </summary>
        /// <value> The sub unit value.</value>
        public string SubUnit { get; set; }

        /// <summary>
        ///     Gets or sets the unit Usage Key.
        /// </summary>
        /// <value> The unit usage key value.</value>
        public string UsageKey { get; set; }

        #endregion
    }
}