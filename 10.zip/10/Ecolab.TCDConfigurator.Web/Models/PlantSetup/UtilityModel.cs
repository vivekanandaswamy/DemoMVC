﻿// -----------------------------------------------------------------------
// <copyright file="UtilityModel.cs" company="Ecolab">
// Copyright © Ecolab . 
// </copyright>
// <summary>The Utility </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    using System;

    /// <summary>
    ///     Model class for UtilityModel(Water and Energy)
    /// </summary>
    public class UtilityModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the DeviceNumber.
        /// </summary>
        /// <value> Device Number.</value>
        public int? DeviceNumber { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceName.
        /// </summary>
        /// <value>The Parameter Device Name.</value>
        public string DeviceName { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceType.
        /// </summary>
        /// <value> Device Type.</value>
        public int DeviceTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceTypeDesc.
        /// </summary>
        /// <value> Device Type Name.</value>
        public string DeviceTypeDesc { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceModel.
        /// </summary>
        /// <value> Device Model.</value>
        public int DeviceModelId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupId.
        /// </summary>
        /// <value> GroupId.</value>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceModelDesc.
        /// </summary>
        /// <value> Device Model Name.</value>
        public string DeviceModelDesc { get; set; }

        /// <summary>
        ///     Gets or sets the DeviceNote.
        /// </summary>
        /// <value> Device Note.</value>
        public string DeviceNoteDesc { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Comment.
        /// </summary>
        /// <value> The Comment.</value>
        public string Comment { get; set; }

        /// <summary>
        ///     Gets or sets the InstallDate.
        /// </summary>
        /// <value> Install Date.</value>
        public string InstallDate { get; set; }

        /// <summary>
        ///     Gets or sets the IsDeleted.
        /// </summary>
        /// <value> Is Deleted.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustWtrEnrgDvcGUID
        /// </summary>
        /// <value>MyServiceCustWtrEnrgDvcGUID</value> 
        public Guid MyServiceCustWtrEnrgDvcGUID { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        /// Gets or sets the Last Modified Time Stamp At Central
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Device Id.</value>
        public int? Id { get; set; }

        #endregion
    }
}