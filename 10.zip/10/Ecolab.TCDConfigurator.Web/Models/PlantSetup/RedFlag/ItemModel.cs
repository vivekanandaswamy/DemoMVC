﻿// -----------------------------------------------------------------------
// <copyright file="ItemModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  ItemModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.RedFlag
{
    /// <summary>
    ///     Model service calss for ItemModel
    /// </summary>
    public class ItemModel
    {
        /// <summary>
        ///     Gets or sets the ItemId
        /// </summary>
        public int ItemId { get; set; }

        /// <summary>
        ///     Gets or sets the ItemName
        /// </summary>
        public string ItemName { get; set; }

        /// <summary>
        ///     Gets or sets the UOM
        /// </summary>
        public string UOM { get; set; }
    }
}