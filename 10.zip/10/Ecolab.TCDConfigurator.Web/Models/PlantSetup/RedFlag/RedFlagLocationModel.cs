﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagLocationModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  RedFlag Location </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup.RedFlag
{
    /// <summary>
    ///     Model service calss for RedFlagLocation
    /// </summary>
    public class RedFlagLocationModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the GroupTypeId.
        /// </summary>
        /// <value> Group Type Id.</value>
        public int GroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupDescription.
        /// </summary>
        /// <value> Group Description.</value>
        public string GroupDescription { get; set; }

        /// <summary>
        ///     Gets or sets the GroupMainType.
        /// </summary>
        /// <value> Group Main Type.</value>
        public int GroupMainType { get; set; }

        #endregion
    }
}