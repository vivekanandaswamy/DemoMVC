﻿// -----------------------------------------------------------------------
// <copyright file="LaborTypeModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>LaborTypeModel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     Web model class for LaborType
    /// </summary>
    public class LaborTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the LaborTypeId.
        /// </summary>
        /// <value> Labor TypeId.</value>
        public int LaborTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the Description.
        /// </summary>
        /// <value> Labor type name.</value>
        public string Description { get; set; }

        #endregion
    }
}