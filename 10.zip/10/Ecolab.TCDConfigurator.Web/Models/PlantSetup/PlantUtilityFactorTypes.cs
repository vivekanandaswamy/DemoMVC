﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityFactorTypes.cs" company="Ecolab">
// Model class for all the lists for plant Utility.
// </copyright>
// <summary>The Plant Utility Factor Types Model.</summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model class for all the lists for PlantUtilityFactorTypes.
    /// </summary>
    public class PlantUtilityFactorTypes
    {
        /// <summary>
        ///     Gets or sets the UtilityType.
        /// </summary>
        /// <value> The Utility Type.</value>
        public int UtilityId { get; set; }

        /// <summary>
        ///     Gets or sets the UtilityType.
        /// </summary>
        /// <value> The Utility Type.</value>
        public int UtilityType { get; set; }

        /// <summary>
        ///     Gets or sets the FactorType.
        /// </summary>
        /// <value> The Factor Type.</value>
        public string FactorType { get; set; }

        /// <summary>
        ///     Gets or sets the Temparature.
        /// </summary>
        /// <value> The Temparature.</value>
        [UsageKeyAttribute("Temperature_CandF", "Temperature")]
        public decimal Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the Temparature.
        /// </summary>
        /// <value> The Temparature.</value>
        public string TemperatureAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Energy.
        /// </summary>
        /// <value> The Energy.</value>
        public decimal EnergyContent { get; set; }

        /// <summary>
        ///     Gets or sets the Energy.
        /// </summary>
        /// <value> The Energy.</value>
        public string EnergyContentAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Price.
        /// </summary>
        /// <value> The Price.</value>
        public decimal Price { get; set; }

        /// <summary>
        ///     Gets or sets the Price.
        /// </summary>
        /// <value> The Price.</value>
        public string PriceAsString { get; set; }
        /// <summary>
        ///     Gets or sets the Location.
        /// </summary>
        /// <value> The Location.</value>
        public string Location { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerSteam.
        /// </summary>
        /// <value> The Boiler Steam.</value>
        public bool BoilerSteam { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public int BoilerType { get; set; }

        /// <summary>
        ///     Gets or sets the Steam.
        /// </summary>
        /// <value> The Steam percentage.</value>
        public decimal SteamPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Steam.
        /// </summary>
        /// <value> The Steam percentage.</value>
        public string SteamPercentageAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Boiler.
        /// </summary>
        /// <value> The Boiler percentage.</value>
        public decimal BoilerPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Boiler.
        /// </summary>
        /// <value> The Boiler percentage.</value>
        public string BoilerPercentageAsString { get; set; }

        /// <summary>
        ///     Gets or sets the Stack.
        /// </summary>
        /// <value> The Stack percentage.</value>
        public decimal StackPercentage { get; set; }

        /// <summary>
        ///     Gets or sets the Stack.
        /// </summary>
        /// <value> The Stack percentage.</value>
        public string StackPercentageAsString { get; set; }

        /// <summary>
        ///     Gets or sets the RewashFactor.
        /// </summary>
        /// <value> The Rewash Factor percentage.</value>
        public decimal RewashFactor { get; set; }

        /// <summary>
        ///     Gets or sets the RewashFactor.
        /// </summary>
        /// <value> The Rewash Factor percentage.</value>
        public string RewashFactorAsString { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public int FreeType { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerType.
        /// </summary>
        /// <value> The Boiler Type.</value>
        public string SubUnit { get; set; }

        /// <summary>
        ///     Gets or sets the energy content unit for plant utility.
        /// </summary>
        /// <value> The Energy Content Unit.</value>
        public string EnergyContentUnit { get; set; }

        /// <summary>
        ///     Gets or sets the energy price unit for plant utility.
        /// </summary>
        /// <value> The Energy Price Unit.</value>
        public string EnergyPriceUnit { get; set; }

        /// <summary>
        ///     Gets or sets the evaporation factor for plant utility.
        /// </summary>
        /// <value> The evaporation factor.</value>
        public decimal EvaporationFactor { get; set; }

        /// <summary>
        ///     Gets or sets the evaporation factor for plant utility.
        /// </summary>
        /// <value> The evaporation factor.</value>
        public string EvaporationFactorAsString { get; set; }

        /// <summary>
        ///     Gets or sets the BoilerTypeName.
        /// </summary>
        /// <value>Boiler Type Name.</value>
        public string BoilerTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the IsFactorUsed
        /// </summary>
        /// <value>IsFactorUsed.</value>
        public string IsFactorUsed { get; set; }

        /// <summary>
        /// Gets or sets the UtilityWaterType.
        /// </summary>
        public string UtilityWaterType { get; set; }

        /// <summary>
        /// Gets or sets the WaterFactorTypeId
        /// </summary>
        public int WaterFactorTypeId { get; set; }

        /// <summary>
        /// Gets or sets the GasOilTypeId.
        /// </summary>
        public int GasOilTypeId { get; set; }

        /// <summary>
        /// Gets or sets the GasOilType.
        /// </summary>
        public string GasOilType { get; set; }

        /// <summary>
        /// Gets or sets the EnergyPrice.
        /// </summary>
        public decimal EnergyPrice { get; set; }

        /// <summary>
        /// Gets or sets the EnergyPrice.
        /// </summary>
        public string EnergyPriceAsString { get; set; }

        /// <summary>
        /// Gets or sets the ElectricPrice.
        /// </summary>
        public decimal ElectricPrice { get; set; }

        /// <summary>
        /// Gets or sets the ElectricPrice.
        /// </summary>
        public string ElectricPriceAsString { get; set; }

		/// <summary>
		/// Gets or Sets the Water Utility Details Id
		/// </summary>
		/// <value>The Water Utility Details Id</value>
		public int WaterUtilityDetailsID { get; set; }
    }
}