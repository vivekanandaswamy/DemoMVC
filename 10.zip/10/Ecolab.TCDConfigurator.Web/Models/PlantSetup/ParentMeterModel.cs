﻿// -----------------------------------------------------------------------
// <copyright file="ParentMeterModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ParentMeter </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    public class ParentMeterModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the MeterID
        /// </summary>
        /// <value>Parent meter id</value>
        public int MeterId { get; set; }

        /// <summary>
        ///     Gets or sets the Description
        /// </summary>
        /// <value>Parent meter name</value>
        public string Description { get; set; }

        #endregion
    }
}