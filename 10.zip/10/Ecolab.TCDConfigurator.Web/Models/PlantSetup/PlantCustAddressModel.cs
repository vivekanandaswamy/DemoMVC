﻿// -----------------------------------------------------------------------
// <copyright file="PlantCustAddressModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PlantCustAddress object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     class for PlantCustAddressModel
    /// </summary>
    public class PlantCustAddressModel
    {
        /// <summary>
        ///     Gets or sets Billing Address 1
        /// </summary>
        /// <value> Billing Address 1.</value>
        public string BillingAddr1 { get; set; }

        /// <summary>
        ///     Gets or sets BillingAddr2
        /// </summary>
        /// <value> Billing Address 2.</value>
        public string BillingAddr2 { get; set; }

        /// <summary>
        ///     Gets or sets City
        /// </summary>
        /// <value> City.</value>
        public string City { get; set; }

        /// <summary>
        ///     Gets or sets Country
        /// </summary>
        /// <value> Country.</value>
        public string Country { get; set; }

        /// <summary>
        ///     Gets or sets Zip
        /// </summary>
        /// <value> Zip.</value>
        public string Zip { get; set; }
    }
}