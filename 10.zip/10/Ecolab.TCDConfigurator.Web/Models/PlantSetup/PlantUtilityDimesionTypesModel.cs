﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityDimesionTypesModel.cs" company="Ecolab">
// Model class for all the lists for plant Utility.
// </copyright>
// <summary>The Plant Utility Dimesion TypesModel.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    /// <summary>
    ///     Model class for all the lists for PlantUtilityDimesionTypesModel.
    /// </summary>
    public class PlantUtilityDimesionTypesModel
    {
        /// <summary>
        ///     Gets or sets the Unit.
        /// </summary>
        /// <value> The Price value.</value>
        public string Price { get; set; }

        /// <summary>
        ///     Gets or sets the SubUnit.
        /// </summary>
        /// <value> The SubUnit.</value>
        public string ElectricPrice { get; set; }

        /// <summary>
        ///     Gets or sets the OrderID.
        /// </summary>
        /// <value> The OrderID.</value>
        public string GasPrice { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystemId.
        /// </summary>
        /// <value> The Unit System Id.</value>
        public string Temperature { get; set; }

        /// <summary>
        ///     Gets or sets the UnitSystemId.
        /// </summary>
        /// <value> The Unit System Id.</value>
        public string EnergyContent { get; set; }
    }
}