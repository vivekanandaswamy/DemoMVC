﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilityListModel.cs" company="Ecolab">
// Model class for all the lists for plant Utility.
// </copyright>
// <summary>The plant utility class for list of details.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PlantSetup
{
    using System.Collections.Generic;

    /// <summary>
    ///     Model class for all the lists for plant Utility.
    /// </summary>
    public class PlantUtilityListModel
    {
        /// <summary>
        ///     Gets or sets the list of free water types  for plant utility setup.
        /// </summary>
        public List<PlantUtilityWaterTypeMasterModel> FreeWaterTypes { get; set; }

        /// <summary>
        ///     Gets or sets the list of gas oil types for plant utility setup.
        /// </summary>
        public List<PlantUtilityGasoilTypeModel> GasOilTypes { get; set; }

        /// <summary>
        ///     Gets or sets the list of factor types for plant utility setup.
        /// </summary>
        public List<PlantUtilityFactorTypes> FactorTypes { get; set; }

        /// <summary>
        ///     Gets or sets the list of dimension types for plant utility setup.
        /// </summary>
        public List<PlantUtilityDimesionTypesModel> DimensionTypes { get; set; }

        /// <summary>
        ///     Gets or sets the list of plant utility unit types for plant utility setup.
        /// </summary>
        public List<PlantUtilityUnitTypesModel> PlantUtilityEnergyContentUnits { get; set; }

        /// <summary>
        ///     Gets or sets the list of plant utility unit types for plant utility setup.
        /// </summary>
        public List<PlantUtilityUnitTypesModel> PlantUtilityEnergyPriceUnits { get; set; }
    }
}