﻿// -----------------------------------------------------------------------
// <copyright file="GroupTypeModel.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The GroupType </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models
{
    /// <summary>
    ///     Web model class for group type(Washer Group)
    /// </summary>
    public class GroupTypeModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets or sets the GroupTypeId.
        /// </summary>
        /// <value> Group Type Id.</value>
        public int GroupTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the GroupDescription.
        /// </summary>
        /// <value> Group Description.</value>
        public string GroupDescription { get; set; }

        /// <summary>
        ///     Gets or sets the GroupMainType.
        /// </summary>
        /// <value> Group Main Type.</value>
        public int GroupMainType { get; set; }

        /// <summary>
        ///     Gets or sets the IsTunnel.
        /// </summary>
        /// <value>Is Tunnel.</value>
        public bool IsTunnel { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId.
        /// </summary>
        /// <value> ControllerModelId.</value>
        public int ControllerModelId { get; set; }

        #endregion
    }
}