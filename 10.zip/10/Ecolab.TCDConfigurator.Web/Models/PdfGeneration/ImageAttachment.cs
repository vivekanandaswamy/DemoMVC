﻿// -----------------------------------------------------------------------
// <copyright file="ImageAttachment.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ImageAttachment </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Models.PdfGeneration
{
    using System.Drawing;

    /// <summary>
    ///     Class ImageAttachment
    /// </summary>
    public class ImageAttachment
    {
        #region Properties

        /// <summary>
        ///     Gets or sets the content for Pdf.
        /// </summary>
        /// <value>The content for Pdf.</value>
        public byte[] ContentForPdf { get; set; }

        /// <summary>
        ///     Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        public Point Position { get; set; }

        /// <summary>
        ///     Gets or sets the width.
        /// </summary>
        /// <value>The width.</value>
        public float Width { get; set; }

        #endregion Properties
    }
}