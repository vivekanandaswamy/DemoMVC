﻿// -----------------------------------------------------------------------
// <copyright file="HtmlContentForPdf.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Html Content For Pdf </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.PdfGeneration
{
    using System.Collections.Generic;

    /// <summary>
    ///     Class HtmlContentForPdf
    /// </summary>
    public class HtmlContentForPdf
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="HtmlContentForPdf" /> class.
        /// </summary>
        public HtmlContentForPdf()
        {
            Images = new List<ImageAttachment>();
            TocBookMarks = new List<KeyValuePair<string, string>>();
        }

        public string FooterHtmlText { get; set; }

        /// <summary>
        ///     Gets or sets the HTML text.
        /// </summary>
        /// <value>The HTML text.</value>
        public string HtmlText { get; set; }

        /// <summary>
        ///     Gets the images.
        /// </summary>
        /// <value>The List of Image Attachment.</value>
        public List<ImageAttachment> Images { get; private set; }

        /// <summary>
        ///     Gets or sets the page index style.
        /// </summary>
        /// <value>The page index style.</value>
        public string PageIndexStyle { get; set; }

        /// <summary>
        ///     Gets or sets the name of the report.
        /// </summary>
        /// <value>The name of the report.</value>
        public string ReportName { get; set; }

        /// <summary>
        ///     Gets or sets the Toc book marks.
        /// </summary>
        /// <value>The Toc book marks.</value>
        public List<KeyValuePair<string, string>> TocBookMarks { get; set; }

        /// <summary>
        ///     Gets or sets the Toc caption.
        /// </summary>
        /// <value>The Toc caption.</value>
        public string TocCaption { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this instance is header available in all pages.
        /// </summary>
        /// <value>
        ///     <c>true</c> if this instance is header available in all pages; otherwise, <c>false</c>.
        /// </value>
        public bool IsHeaderAvailableInAllPages { get; set; }

        /// <summary>
        ///     Gets or sets the header HTML text.
        /// </summary>
        /// <value>
        ///     The header HTML text.
        /// </value>
        public string HeaderHtmlText { get; set; }

        /// <summary>
        ///     Gets or Sets Logo Data
        /// </summary>
        public string Logo { get; set; }

        /// <summary>
        ///     Gets or Sets the Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        ///     gets or Sets the Breadcrumb
        /// </summary>
        public string Breadcrumb { get; set; }

        /// <summary>
        ///     Gets or sets the Plant Name
        /// </summary>
        public string PlantName { get; set; }

        /// <summary>
        ///     Gets or sets the Plant Location
        /// </summary>
        public string PlantLocation { get; set; }
    }
}