﻿// -----------------------------------------------------------------------
// <copyright file="ControllerTypeModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.ControllerSetup
{
    /// <summary>
    ///     class ControllerSupplierModel
    /// </summary>
    public class ControllerTypeModel
    {
        #region Properties

        /// <summary>
        ///     Gets and sets the Controller Type Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///     Gets and sets the Controller Name
        /// </summary>
        public string Name { get; set; }

        #endregion
    }
}