﻿// -----------------------------------------------------------------------
// <copyright file="ControllerDataModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Data Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.ControllerSetup.Pumps
{
    /// <summary>
    ///     Class Controller Data Model.
    /// </summary>
    public class ControllerDataModel
    {
        /// <summary>
        /// Gets or Sets the Id
        /// </summary>
        /// <value>Identifier.</value>
        public int Id { get; set; }

        /// <summary>
        /// gets or sets the label
        /// </summary>
        /// <value>The Label.</value>
        public string Label { get; set; }

        /// <summary>
        /// Gets or Sets the Value
        /// </summary>
        /// <value>The Value.</value>
        public int Value { get; set; }
    }
}