﻿// -----------------------------------------------------------------------
// <copyright file="PumpModelsModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Pump Model object for PumpModel List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.ControllerSetup.Pumps
{
    /// <summary>
    ///     Pump Model Class
    /// </summary>
    public class PumpModelsModel
    {
        /// <summary>
        ///     Gets or sets the ControllerEquipmentTypeModelId
        /// </summary>
        /// <value>The Controller Equipment Type Model Id</value>
        public int ControllerEquipmentTypeModelId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerEquipmentTypeModelName
        /// </summary>
        /// <value>The Controller Equipment Type Model Name</value>
        public string ControllerEquipmentTypeModelName { get; set; }

        /// <summary>
        ///     Gets or sets the ArtNumberLang.
        /// </summary>
        /// <value>The Art Number Lang.</value>
        public string ArtNumberLang { get; set; }

        /// <summary>
        ///     Gets or sets the TeoreticalCalibration.
        /// </summary>
        /// <value>The Teoretical Calibration.</value>
        public int TeoreticalCalibration { get; set; }

        /// <summary>
        ///     Gets or sets the IsMeType.
        /// </summary>
        /// <value>The Is Machine Equipment Type</value>
        public bool IsMeType { get; set; }
    }
}