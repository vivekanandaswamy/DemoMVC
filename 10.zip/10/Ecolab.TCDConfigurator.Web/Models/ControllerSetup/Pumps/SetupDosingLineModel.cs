﻿// -----------------------------------------------------------------------
// <copyright file="SetupDosingLineModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The SetupDosingLineModel </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.ControllerSetup.Pumps
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// Class for Setup Dosing Line Model
    /// </summary>
    public class SetupDosingLineModel
    {
        /// <summary>
        /// Gets or sets the dosing line mode.
        /// </summary>
        /// <value>
        /// The dosing line mode.
        /// </value>
        public int DosingLineMode { get; set; }

        /// <summary>
        /// Gets or sets the enable auxiliary.
        /// </summary>
        /// <value>
        /// The enable auxiliary.
        /// </value>
        public int EnableAuxiliary { get; set; }
    }
}