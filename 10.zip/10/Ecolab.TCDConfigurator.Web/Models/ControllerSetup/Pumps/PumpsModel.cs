﻿// -----------------------------------------------------------------------
// <copyright file="PumpsModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The  Pumps Model object for PumpsModel List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.ControllerSetup.Pumps
{
    using System;
    using System.Collections.Generic;
    using Dcs.Entities;

    /// <summary>
    ///     Pumps Model Class
    /// </summary>

    #region "Properties"
    public class PumpsModel
    {
        /// <summary>
		///     Gets or sets the controller equipment Setup identifier.
		/// </summary>
		/// <value>The controller equipment Setup identifier.</value>
		public int ControllerEquipmentSetupId { get; set; }

		/// <summary>
        ///     Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>The controller equipment identifier.</value>
        public int ControllerEquipmentId { get; set; }

        /// <summary>
		///     Gets or sets the Controller Model Id identifier.
		/// </summary>
		/// <value>The controller equipment identifier.</value>
		public int ControllerModelId { get; set; }

		/// <summary>
        ///     Gets or sets the controller equipment type identifier.
        /// </summary>
        /// <value>The controller equipment type identifier.</value>
        public int ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        public int? ProductId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets the pump calibration.
        /// </summary>
        /// <value>The pump calibration.</value>
        public decimal PumpCalibration { get; set; }

        /// <summary>
        ///     Gets or sets the pump calibration.
        /// </summary>
        /// <value>The pump calibration.</value>
        public string PumpCalibrationAsString { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [flow meter switch flag].
        /// </summary>
        /// <value><c>null/true/false</c>.</value>
        public bool? FlowMeterSwitchFlag { get; set; }

        /// <summary>
        ///     Gets or sets the maximum dosing time.
        /// </summary>
        /// <value>The maximum dosing time.</value>
        public Int16? MaximumDosingTime { get; set; }

        /// <summary>
        ///     Gets or sets the flow switch time out.
        /// </summary>
        /// <value>The flow switch time out.</value>
        public decimal? FlowSwitchTimeOut { get; set; }

        /// <summary>
        ///     Gets or sets the eco lab account number.
        /// </summary>
        /// <value>The eco lab account number.</value>
        public string EcolabAccountNumber { get; set; }

        /// <summary>
        ///     Gets or sets the controller identifier.
        /// </summary>
        /// <value>The controller identifier.</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the controller name.
        /// </summary>
        /// <value>The controller name.</value>
        public string ControllerTopicName { get; set; }

        /// <summary>
        ///     Gets or sets the controller Type Id
        /// </summary>
        /// <value>The controller type id</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or Sets the Lfs Chemical Name
        /// </summary>
        /// <value>The Lfs Chemical Name</value>
        public string LfsChemicalName { get; set; }

        /// <summary>
        ///     Gets or Sets the K-Factor
        /// </summary>
        /// <value>The K-Factor value</value>
        public decimal KFactor { get; set; }

        /// <summary>
        ///     Gets or Sets the K-Factor
        /// </summary>
        /// <value>The K-Factor value</value>
        public string KFactorAsString { get; set; }

        /// <summary>
        ///     Gets or sets Tunnel hold
        /// </summary>
        /// <value>The Tunnel hold value</value>
        public bool TunnelHold { get; set; }

        /// <summary>
        ///     Gets or sets Flow Detector Type
        /// </summary>
        /// <value>The Flow Detector Type</value>
        public int FlowDetectorType { get; set; }

        /// <summary>
        ///     Gets or sets Flow Switch alarm
        /// </summary>
        /// <value>The Flow Switch alarm value</value>
        public bool FlowSwitchAlarm { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Alarm
        /// </summary>
        /// <value>The flow meter alarm</value>
        public bool FlowMeterAlarm { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Type
        /// </summary>
        /// <value>The Flow Meter Type</value>
        public int FlowMeterType { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Alarm Delay Time
        /// </summary>
        /// <value>The Flow Alarm Delay Time in seconds</value>
        public decimal FlowAlarmDelay { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Pump Delay Time
        /// </summary>
        /// <value>The Flow Meter Pump Delay Time in seconds</value>
        public decimal FlowMeterPumpDelay { get; set; }

        /// <summary>
        ///     Gets or sets the Flow Meter Alarm Delay Time
        /// </summary>
        /// <value>The Flow Meter Alarm Delay Time in seconds</value>
        public decimal FlowMeterAlarmDelay { get; set; }

        /// <summary>
        ///     Gets or sets the Lfs Chemical Name Tag
        /// </summary>
        /// <value>The Lfs Chemical Name Tag</value>
        public string LfsChemicalNameTag { get; set; }

        /// <summary>
        ///     Gets or sets the K-Factor Tag
        /// </summary>
        /// <value>The K-Factor Tag</value>
        public string KfactorTag { get; set; }

        /// <summary>
        ///     Gets or sets the Calibration Tag
        /// </summary>
        /// <value>The Calibration Tag</value>
        public string CalibrationTag { get; set; }

        /// <summary>
		///     Gets or sets the ControllerEquipmentTypeModelId
		/// </summary>
		/// <value>The Controller Equipment Type Model Id</value>
		public int ControllerEquipmentTypeModelId { get; set; }

		/// <summary>
		///     Gets or sets the ConventionalWasherGroupConnection
		/// </summary>
		/// <value>The Conventional Washer Group Connection</value>
		public bool ConventionalWasherGroupConnection { get; set; }

		/// <summary>
		///     Gets or sets the AxillaryPumpCalibration
		/// </summary>
		/// <value>The Axillary Pump Calibration</value>
		public short AxillaryPumpCalibration { get; set; }

		/// <summary>
		///     Gets or sets the FlowmeterSwitchActivated
		/// </summary>
		/// <value>The Flowmeter Switch Activated</value>
		public bool FlowmeterSwitchActivated { get; set; }

		/// <summary>
		///     Gets or sets the FlushWhileDosing
		/// </summary>
		/// <value>The Flush While Dosing</value>
		public bool FlushWhileDosing { get; set; }

		/// <summary>
		///     Gets or sets the WeightControlledDosage
		/// </summary>
		/// <value>The Weight Controlled Dosage</value>
		public bool WeightControlledDosage { get; set; }

		/// <summary>
		///     Gets or sets the EquipmentDoseAlone
		/// </summary>
		/// <value>The Equipment Dose Alone</value>
		public bool EquipmentDoseAlone { get; set; }

		/// <summary>
		///     Gets or sets the LowLevelAlarm
		/// </summary>
		/// <value>The Low Level Alarm</value>
		public bool LowLevelAlarm { get; set; }

		/// <summary>
		///     Gets or sets the LeakageAlarm
		/// </summary>
		/// <value>The Leakage Alarm</value>
		public bool LeakageAlarm { get; set; }

		/// <summary>
		///     Gets or sets the FlushTime
		/// </summary>
		/// <value>The Flush Time</value>
		public short FlushTime { get; set; }

		/// <summary>
		///     Gets or sets the PumpingTime
		/// </summary>
		/// <value>The Pumping Time</value>
		public short PumpingTime { get; set; }

		/// <summary>
		///     Gets or sets the PreFlushTime
		/// </summary>
		/// <value>The Pre Flush Time</value>
		public short PreFlushTime { get; set; }

		/// <summary>
		///     Gets or sets the NightFlushPauseTime
		/// </summary>
		/// <value>The Night Flush Pause Time</value>
		public short NightFlushPauseTime { get; set; }

		/// <summary>
		///     Gets or sets the NightFlushTime
		/// </summary>
		/// <value>The Night Flush Time</value>
		public short NightFlushTime { get; set; }

		/// <summary>
		///     Gets or sets the AcceptedDeviation
		/// </summary>
		/// <value>The Accepted Deviation</value>
		public short AcceptedDeviation { get; set; }

		/// <summary>
		/// Gets or Sets the LineNumber
		/// </summary>
		public byte LineNumber { get; set; }

		/// <summary>
		/// Gets or sets the DirectDosingFlag
		/// </summary>
		/// <value>The Direct Dosing Flag</value>
		public bool DirectDosingFlag { get; set; }

		/// <summary>
		///     Gets or sets the DirectDosingMachineInternalId
		/// </summary>
		/// <value>The Direct Dosing Machine Internal Id</value>
		public int DirectDosingMachineInternalId { get; set; }

		/// <summary>
		///     Gets or sets the DirectDosingTunnelCompartmentId
		/// </summary>
		/// <value>The Direct Dosing Tunnel Compartment Id</value>
		public int DirectDosingTunnelCompartmentId { get; set; }

		/// <summary>
		/// Gets or sets the WasherGroupNumber
		/// </summary>
        /// <value> The Washer Group Number</value>
		public int WasherGroupNumber { get; set; }

		/// <summary>
		/// Gets or sets the WasherGroupTypeId
		/// </summary>
        /// <value>Washer Group Type Id.</value>
		public int WasherGroupTypeId { get; set; }
		/// <summary>
		/// Gets or sets NoOfCompartments
		/// </summary>
        /// <value>Number of Compartments.</value>
		public int NoOfCompartments { get; set; }

		/// <summary>
		/// Gets or sets flushValveNumber
		/// </summary>
        /// <value>Flush Valve Number</value>
		public short? FlushValveNumber { get; set; }

		/// <summary>
		/// Gets or sets calibrationConductSS_Tank
		/// </summary>
        /// <value>Calibration Conduct</value>
		public Decimal? CalibrationConductSS_Tank { get; set; }

		/// <summary>
		/// Gets or sets BackFlowControl
		/// </summary>
        /// <value>Back Flow Control</value>
		public bool BackFlowControl { get; set; }

		/// <summary>
		/// Gets or sets AcceptedDeviationRingLine
		/// </summary>
        /// <value>Accepted Deviation Ringline</value>
		public short? AcceptedDeviationRingLine { get; set; }

		/// <summary>
		/// Gets or sets UsePumpOfGroup1ForTunnel
		/// </summary>
        /// <value>Use pump of group1 for tunnel</value>
		public bool UsePumpOfGroup1ForTunnel { get; set; }

		/// <summary>
		/// Gets or sets pHSensorEnabled
		/// </summary>
        /// <value>pH Sensor Enabled</value>
		public bool pHSensorEnabled { get; set; }

		/// <summary>
		/// Gets or sets Concentration
		/// </summary>
        /// <value>Concentration</value>
		public int Concentration { get; set; }

		/// <summary>
		/// Gets or sets StockSolutionDeadEnd
		/// </summary>
        /// <value>Stock Solution DeadEnd</value>
		public bool StockSolutionDeadEnd { get; set; }

		/// <summary>
		/// Gets or Sets the LineCompartmentMappings
		/// </summary>
		/// <value>List of LineCompartmentMappingModel</value>
		public List<LineCompartmentMappingModel> LineCompartmentMappings { get; set; }

		/// <summary>
        ///     Gets or sets the Override Plc Values
        /// </summary>
        public bool OverridePlcValues { get; set; }

        /// <summary>
        ///     Gets or sets the PLC Tags
        /// </summary>
        public List<OpcTag> PlcTags { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp Dryer Group
        /// </summary>
        /// <value>LastModifiedTimeStampDryerGroup</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Override Plc Values
        /// </summary>
        /// <value>Lfs Override PLC values</value>
        public bool LfsOverridePlcValues { get; set; }

        /// <summary>
        ///     Gets or sets the Override Plc Values
        /// </summary>
        /// <value>KFactor override PLC values</value>
        public bool KFactorOverridePlcValues { get; set; }

        /// <summary>
        ///     Gets or sets the Override Plc Values
        /// </summary>
        /// <value>Calibration override PLC values</value>
        public bool CalibrationOverridePlcValues { get; set; }

		/// <summary>
		/// Gets or sets The Valve Output as TOM
		/// </summary>
        /// <value>TOM output</value>
		public bool ValveOutputAsTom { get; set; }

		/// <summary>
		/// Gets or sets FlowSwitchNumber
		/// </summary>
        /// <value>Flow Switch Number</value>
		public int FlowSwitchNumber { get; set; }

        /// <summary>
        /// Gets or sets FlushTimeForFlushValve
        /// </summary>
        /// <value>Flush time for flush valve</value>
        public int FlushTimeForFlushValve { get; set; }

        /// <summary>
        ///     Gets or sets Minimum FlowRate
        /// </summary>
        /// <value> Minimum FlowRate </value>
        public int MinimumFlowRate { get; set; }
		/// <summary>
		/// Gets or sets the FactorFM_B_FM.
		/// </summary>
		/// <value>FactorFM_B_FM.</value>
		public short? FactorFM_B_FM { get; set; }
		/// <summary>
		///     Gets or sets Product Density
		/// </summary>
		/// <value> Product Density </value>
		public decimal ProductDensity { get; set; }

        /// <summary>
        ///     Gets or sets Maximum Concentration
        /// </summary>
        /// <value> Maximum Concentration </value>
        public int MaximumConcentration { get; set; }
        /// <summary>
        /// Gets or sets HttpStatus Code
        /// </summary>
        /// <value>Http Status Code</value>
        public int HttpStatusCode { get; set; }
        /// <summary>
        /// Gets or sets Eorror
        /// </summary>
        /// <value>The Eorror.</value>
        public String Eorror { get; set; }
    }

    #endregion "Properties"
}