﻿// -----------------------------------------------------------------------
// <copyright file="ProductModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Product Model object for ProductModel List</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.ControllerSetup.Pumps
{
    /// <summary>
    ///     Class ProductModel.
    /// </summary>
    public class ProductModel
    {
        /// <summary>
        ///     Gets or sets the Product Id.
        /// </summary>
        /// <value>Product Id.</value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets PumpsProductId
        /// </summary>
        /// <value>Pumps Product Id.</value>
        public int PumpsProductId { get; set; }

        /// <summary>
        /// Gets or sets ControllerId
        /// </summary>
        /// <value>Controller Id.</value>
        public int ControllerId { get; set; }

        /// <summary>
        /// Gets or sets ChemicalNumber
        /// </summary>
        /// <value>Chemical Number</value>
        public int ChemicalNumber { get; set; }

        /// <summary>
        ///     Gets or sets the Product Name.
        /// </summary>
        /// <value>Product Name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets LowLevelAlarm
        /// </summary>
        /// <value>Low Level Alarm</value>
        public bool LowLevelAlarm { get; set; }

        /// <summary>
        /// Gets or sets WeightControlledDosage
        /// </summary>
        /// <value>Weight Controlled Dosage</value>
        public bool WeightControlledDosage { get; set; }

        /// <summary>
        /// Gets or sets ControllerEquipmentSetupId
        /// </summary>
        /// <value>Controller Equipment Setup Id.</value>
        public int ControllerEquipmentSetupId { get; set; }
    }
}