﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupMetaDataModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Controller Setup MetaData Model object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.ControllerSetup
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    ///     class ControllerSetupMetaDataModel
    /// </summary>
    public class ControllerSetupMetaDataModel
    {
        #region "Properties"

        /// <summary>
        ///     Gets and sets the Controller Name
        /// </summary>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Id
        /// </summary>
        public int FieldGroupId { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Name
        /// </summary>
        public string FieldGroupName { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Image Url
        /// </summary>
        public string FieldGroupImageUrl { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Help Text
        /// </summary>
        public string FieldGroupHelpText { get; set; }

        /// <summary>
        ///     Gets and sets the Controller Model Id
        /// </summary>
        public Int16 ControllerModelId { get; set; }

        /// <summary>
        ///     Gets and sets the Controller Type Id
        /// </summary>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Type Name
        /// </summary>
        public string FieldGroupTypeName { get; set; }

        /// <summary>
        ///     Gets and sets the Field Id
        /// </summary>
        public int FieldId { get; set; }

        /// <summary>
        ///     Gets and sets the Field Name
        /// </summary>
        public string FieldName { get; set; }

        /// <summary>
        ///     Gets and sets the Field Type
        /// </summary>
        public string FieldType { get; set; }

        /// <summary>
        ///     Gets and sets the Field Label
        /// </summary>
        public string FieldLabel { get; set; }

        /// <summary>
        ///     Gets and sets the Field Minimum Value
        /// </summary>
        public string FieldMinValue { get; set; }

        /// <summary>
        ///     Gets and sets the Field Maximum Value
        /// </summary>
        public string FieldMaxValue { get; set; }

        /// <summary>
        ///     Gets and sets the Field Is Mandatory or not
        /// </summary>
        public bool FieldIsMandatory { get; set; }

        /// <summary>
        ///     Gets and sets the Field Is Editable or not
        /// </summary>
        public bool FieldIsEditable { get; set; }

        /// <summary>
        ///     Gets and sets the Field Help Text
        /// </summary>
        public string FieldHelpText { get; set; }

        /// <summary>
        ///     Gets and sets the Field Help Url
        /// </summary>
        public string FieldHelpUrl { get; set; }

        /// <summary>
        ///     Gets and sets the Tab Index
        /// </summary>
        public int TabIndex { get; set; }

        /// <summary>
        ///     Gets and sets the Control Type
        /// </summary>
        public string ControlType { get; set; }

        /// <summary>
        ///     Gets and sets the Data Source Id
        /// </summary>
        public int DataSourceId { get; set; }

        /// <summary>
        ///     Gets and sets the Data Source Key Value
        /// </summary>
        public string DataSourceKeyValue { get; set; }

        /// <summary>
        ///     Gets and sets the Field Source Info
        /// </summary>
        public List<FieldSourceModel> DataSourceInfo { get; set; }

        /// <summary>
        ///     Gets and sets the Data Category Id
        /// </summary>
        public int DataCategoryId { get; set; }

        /// <summary>
        ///     Gets and sets the Field Default Value
        /// </summary>
        public string FieldDefaultValue { get; set; }

        /// <summary>
        ///     Gets and sets the Field Currency Code
        /// </summary>
        public string FieldCurrencyCode { get; set; }

        /// <summary>
        ///     Gets and sets the Field Resource Key
        /// </summary>
        public string FieldResourceKey { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group Resource Key
        /// </summary>
        public string FieldGroupResourceKey { get; set; }

        /// <summary>
        ///     Gets and sets the Field Group DO
        /// </summary>
        public int FieldGroupDO { get; set; }

        /// <summary>
        ///     Gets and sets the Field DO
        /// </summary>
        public int FieldDO { get; set; }

        /// <summary>
        ///     Gets or sets the Access To Role
        /// </summary>
        public int AccessToRole { get; set; }

        /// <summary>
        ///     Gets or sets Mode
        /// </summary>
        public string Mode { get; set; }

        /// <summary>
        ///     Gets or sets the field has tag value or not
        /// </summary>
        /// <value>The Parameter Tag boolean  Value</value>
        public string HasFieldTag { get; set; }

        /// <summary>
        ///     Gets or sets the Tag Default Value
        /// </summary>
        /// <value>The Parameter Tag Default Value</value>
        public string TagDefaultValue { get; set; }

        /// <summary>
        ///     Gets or sets the Tag Value Code
        /// </summary>
        /// <value>The Parameter Tag Value Code</value>
        public string TagValueCode { get; set; }

        /// <summary>
        ///     Gets or sets the Field Class Name
        /// </summary>
        /// <value>The Parameter Field Class Name</value>
        public string FieldClassName { get; set; }

        /// <summary>
        ///     Gets or sets the Field Class Name
        /// </summary>
        /// <value>The Parameter Field Class Name</value>
        public bool OverrideValues { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Version
        /// </summary>
        /// <value>The Parameter Controller Version</value>
        public string ControllerVersion { get; set; }
        #endregion
    }
}