﻿// -----------------------------------------------------------------------
// <copyright file="BaseViewModel.cs" company="Ecolab">
// This class is for fetching the values and saving the values to database.
// </copyright>
// <summary>The  fetching the values and saving the values.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models
{
    /// <summary>
    ///     Base class for Web Model
    /// </summary>
    public class BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the Id.
        /// </summary>
        /// <value> Id. </value>
        public int Id { get; set; }

        /// <summary>
        ///     Gets or sets the EcolabAccountNumber.
        /// </summary>
        /// <value> Ecolab Account Number. </value>
        public string EcolabAccountNumber { get; set; }

		/// <summary>
		///     Gets or sets the PlantId
		/// </summary>
		/// <value>The Plant Id</value>
		public int PlantId { get; set; }
    }
}