﻿// -----------------------------------------------------------------------
// <copyright file="WasherDosingProductModel.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The WasherDosingProduct is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.WasherGroup
{
    using System;

    /// <summary>
    ///     WasherDosingProduct class
    /// </summary>
    public class WasherDosingProductModel : BaseViewModel
    {
        #region Properties

        /// <summary>
        ///     Gets or sets WasherDosingSetupId
        /// </summary>
        public int WasherDosingSetupId { get; set; }

        /// <summary>
        ///     Gets or sets InjectionNumber
        /// </summary>
        public Int16 InjectionNumber { get; set; }

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets Quantity
        /// </summary>
        public decimal Quantity { get; set; }

        /// <summary>
        ///     Gets or sets DeleteFlag
        /// </summary>
        public bool DeleteFlag { get; set; }

        /// <summary>
        ///     Gets or sets IsDeleted
        /// </summary>
        public bool IsDeleted { get; set; }

		/// <summary>
		/// Gets or sets PriceInOunce
		/// </summary>
		public double PriceInOunce { get; set; }

        /// <summary>
		/// Gets or sets Delay
		/// </summary>
		public short Delay { get; set; }

        /// <summary>
        /// Gets or sets the ControllerEquipmentSetupId
        /// </summary>
        /// <value>The ControllerEquipmentSetupId</value>
        public short? ControllerEquipmentSetupId { get; set; }
        /// <summary>
        /// Gets or sets the ControllerEquipmentSetupId
        /// </summary>
        /// <value>The ControllerEquipmentSetupId</value>
        public byte? ControllerEquipmentId { get; set; }
        /// <summary>
        /// Gets or sets ControllerEquipmentTypeId.
        /// </summary>
        /// <value>The ControllerEquipmentTypeId.</value>
        public int ControllerEquipmentTypeId { get; set; }

        #endregion
    }
}