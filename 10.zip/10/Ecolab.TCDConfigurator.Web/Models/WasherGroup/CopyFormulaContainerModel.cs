﻿// -----------------------------------------------------------------------
// <copyright file="CopyFormulaContainerModel.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The washer group is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.WasherGroup
{
    using System;
	using System.Collections.Generic;
	using Ecolab.TCDConfigurator.Web.Models.PlantSetup;

    /// <summary>
    ///     Washer group class consists of all entities for washer group.
    /// </summary>
	public class CopyFormulaContainerModel : BaseViewModel
    {
		/// <summary>
		/// Gets or sets the FromWasherGroupId identifier.
		/// </summary>
		/// <value>
		/// The FromWasherGroupId identifier.
		/// </value>
		public List<CopyFormula> FormulaList { get; set; }

		/// <summary>
		/// Gets or sets the FromWasherGroupId identifier.
		/// </summary>
		/// <value>
		/// The FromWasherGroupId identifier.
		/// </value>
		public List<SubstituteChemicalModel> MissingChemicalList { get; set; }

		/// <summary>
		///     Gets or sets the LastModifiedTimestampAtCentral
		/// </summary>
		/// <value>LastModifiedTimestampAtCentral</value>
		public DateTime? LastModifiedTimestampAtCentral { get; set; }

		/// <summary>
		/// Gets or sets MaxNumberOfRecords
		/// </summary>
		public int MaxNumberOfRecords { get; set; }
    }
}