﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroupFormulaModel.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The washer group is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.WasherGroup
{
    using System;
    using System.Collections.Generic;
    using PlantSetup;

    public class WasherGroupFormulaModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the WasherGroupNumber
        /// </summary>
        public string WasherGroupNumber { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupName
        /// </summary>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupTypeName
        /// </summary>
        public string WasherGroupTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramNumber
        /// </summary>
        public short ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets the NominalLoad
        /// </summary>
        public short NominalLoad { get; set; }

        /// <summary>
        ///     Gets or sets the NominalLoad
        /// </summary>
        public string NominalLoadAsString { get; set; }

        /// <summary>
        ///     Gets or sets the TotalRunTime
        /// </summary>
        public int TotalRunTime { get; set; }

        /// <summary>
        ///     Gets or sets the ExtraTime
        /// </summary>
        public int ExtraTime { get; set; }

        /// <summary>
        ///     Gets or sets the LoadsPerMonth
        /// </summary>
        public short LoadsPerMonth { get; set; }

        /// <summary>
        ///     Gets or sets the LoadsPerMonth
        /// </summary>
        public string LoadsPerMonthAsString { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroupId
        /// </summary>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the ProgramId
        /// </summary>
        public int ProgramId { get; set; }

        /// <summary>
        ///     Gets or sets the NextAvailableStepNo
        /// </summary>
        public int NextAvailableStepNo { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTime
        /// </summary>
        /// <value>LastModifiedTime</value>
        public DateTime LastModifiedTime { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the LastModifiedTimestampAtCentral
        /// </summary>
        /// <value>LastModifiedTimestampAtCentral</value>
        public DateTime? LastModifiedTimestampAtCentral { get; set; }

        /// <summary>
        ///     Gets or sets the RunTime
        /// </summary>
        public string RunTime { get; set; }

        /// <summary>
        ///     Gets or sets the Formulas
        /// </summary>
        public List<FormulaModel> Formulas { get; set; }

        /// <summary>
        /// Gets or sets the available formula number.
        /// </summary>
        /// <value>Next Available Formula No value.</value>
        public int NextAvailableFormulaNo { get; set; }

        /// <summary>
        /// Gets or sets the max injections count
        /// </summary>
        public int MaxInjectionsCount { get; set; }

        /// <summary>
        /// Gets or sets the can add injections status
        /// </summary>
        public bool CanAddInjections { get; set; }

        /// <summary>
        /// Gets or sets the reference load 
        /// </summary>
        public int ReferenceLoad { get; set; }

        ///// <summary>
        /////     Gets or sets the Washer steps
        ///// </summary>
        ///// <value>The WashStepCount</value>
        //public int WashStepCount { get; set; }

        /// <summary>
        /// Gets or sets ControllerId
        /// </summary>
        public int? ControllerId { get; set; }

        /// <summary>
        /// Gets or sets ControllerModelId
        /// </summary>
        public int ControllerModelId { get; set; }

        /// <summary>
        /// Gets or sets FormulaNumberWithName
        /// </summary>
        public string FormulaNumberWithName { get; set; }

        /// <summary>
        ///     Gets or sets the Washer steps
        /// </summary>
        /// <value>The WashStepCount</value>
        public int WashStepCount { get; set; }

        /// <summary>
        ///     Gets or sets the Washer steps
        /// </summary>
        /// <value>The WashStepCount</value>
        public int StandardRunTime { get; set; }

        /// <summary>
        ///     Gets or sets the Washer steps
        /// </summary>
        /// <value>The WashStepCount</value>
        public string CompartmentStandardRunTime { get; set; }
        
        /// <summary>
        /// Gets or Sets IsPLCConnected
        /// </summary>
        public bool IsPLCConnected { get; set; }
    }
}