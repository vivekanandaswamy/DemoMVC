﻿// -----------------------------------------------------------------------
// <copyright file="DrainDestinationList.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>Gets or sets the Drain Destination values.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.WasherGroup
{
    /// <summary>
    /// Properties for drain destination model
    /// </summary>
    /// <seealso cref="Ecolab.TCDConfigurator.Web.Models.BaseViewModel" />
    public class DrainDestinationList : BaseViewModel
    {
        /// <summary>
        /// Gets or sets the drain destination identifier.
        /// </summary>
        /// <value>
        /// The drain destination identifier.
        /// </value>
        public int DrainDestinationId { get; set; }

        /// <summary>
        /// Gets or sets DrainDestinationName
        /// </summary>
        /// <value>
        /// Parameter DrainDestinationName
        /// </value>
        public string DrainDestinationName { get; set; }
    }
}
