﻿// -----------------------------------------------------------------------
// <copyright file="TunnelWashStepProductsModel.cs" company="Ecolab">
// This class is for initialising and declaring the entities.
// </copyright>
// <summary>The Tunnel Model is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.WasherGroup
{
    using System;

    /// <summary>
    ///     TunnelWashStepProductsModel class.
    /// </summary>
    public class TunnelWashStepProductsModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets TunnelDosingProductMappingId
        /// </summary>
        public int TunnelDosingProductMappingId { get; set; }

        /// <summary>
        ///     Gets or sets Tunnel Dosing Setup Id
        /// </summary>
        public int TunnelDosingSetupId { get; set; }

        /// <summary>
        ///     Gets or sets ControllerEquipmentSetupId
        /// </summary>
        public short ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets InjectionNumber
        /// </summary>
        public Int16 InjectionNumber { get; set; }

        /// <summary>
        ///     Gets or sets ProductId
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        ///     Gets or sets ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets Quantity
        /// </summary>
        public decimal Quantity { get; set; }

        /// <summary>
        ///     Gets or sets DelayTime
        /// </summary>
        public int DelayTime { get; set; }

        /// <summary>
        ///     Gets or sets CompartmentNumber
        /// </summary>
        public int CompartmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets GroupId
        /// </summary>
        public int GroupId { get; set; }

        /// <summary>
        ///     Gets or sets TotalInjections
        /// </summary>
        public int TotalInjections { get; set; }

		/// <summary>
		/// Gets or sets PriceInOunce
		/// </summary>
		public double PriceInOunce { get; set; }

        /// <summary>
        /// Gets or Sets The Controller Equipment Type
        /// </summary>
        /// <value>The Controlller Equipment Type</value>
        public int ControllerEquipmentType { get; set; }

        /// <summary>
        /// Gets or sets the ControllerEquipmentSetupId
        /// </summary>
        /// <value>The ControllerEquipmentSetupId</value>
        public byte? ControllerEquipmentId { get; set; }
    }
}