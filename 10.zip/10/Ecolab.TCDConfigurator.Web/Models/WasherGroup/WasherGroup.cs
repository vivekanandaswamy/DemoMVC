﻿// -----------------------------------------------------------------------
// <copyright file="WasherGroup.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The washer group is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.WasherGroup
{
	using System;

	/// <summary>
	///     Washer group class consists of all entities for washer group.
	/// </summary>
	public class WasherGroup : BaseViewModel
	{
		#region "Properties"

		/// <summary>
		///     Gets or sets the row number value for the washer groups.
		/// </summary>
		/// <value>Gets Row Number value.</value>
		public int RowNumber { get; set; }

		/// <summary>
		///     Gets or sets the Washer GroupId value for the washer groups.
		/// </summary>
		/// <value>Gets Washer GroupId value.</value>
		public int WasherGroupId { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Number value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Number value.</value>
		public string WasherGroupNumber { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Number value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Number value.</value>
		public int WasherGroupNumberInt { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Type Id value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Type Id value.</value>
		public byte WasherGroupTypeId { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Type Name value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Type Name value.  </value>
		public string WasherGroupTypeName { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Description value for the washer groups.
		/// </summary>
		/// <value> Washer Group Description value.</value>
		public string WasherGroupDescription { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Name value for the washer groups.
		/// </summary>
		/// <value> Washer Group Name value.</value>
		public string WasherGroupName { get; set; }

		/// <summary>
		///     Gets or sets the Row Total Count value for the washer groups.
		/// </summary>
		/// <value> Row Total Count value.</value>
		public int RowTotalCount { get; set; }

		/// <summary>
		///     Gets or sets the LastSyncTime
		/// </summary>
		/// <value>LastSyncTime</value>
		public DateTime LastSyncTime { get; set; }

		/// <summary>
		///     Gets or sets Max Number Of Records
		/// </summary>
		/// <value> Max Number Of Records </value>
		public int MaxNumberOfRecords { get; set; }

		/// <summary>
		///     Gets or sets the Last Modified Time Stamp
		/// </summary>
		/// <value>LastModifiedTimeStamp</value>
		public DateTime LastModifiedTimeStamp { get; set; }

		/// <summary>
		///     Gets or sets the Is Delete
		/// </summary>
		/// <value>IsDelete</value>
		public bool IsDelete { get; set; }

		/// <summary>
		///     Gets or sets the Washer Group Number value from MyService.
		/// </summary>
		/// <value>Gets Washer Group Number value from MyService.</value>
		public Int16 MyServiceWasherGroupNumber { get; set; }

		/// <summary>
		/// Gets or sets MyServiceWasherGroupGuid
		/// </summary>
		public Guid MyServiceWasherGroupGuid { get; set; }

		/// <summary>
		///     Gets or sets the My Service Last Modified Time
		/// </summary>
		/// <value>MyServiceLastModifiedTime</value>
		public DateTime MyServiceLastModifiedTime { get; set; }

		/// <summary>
		///     Gets or sets the ControllerCount
		/// </summary>
		/// <value>ControllerCount</value>
		public int ControllerCount { get; set; }

		/// <summary>
		/// Gets or sets ControllerId
		/// </summary>
		public int ControllerId { get; set; }

		/// <summary>
		/// Gets or sets ControllerModelId
		/// </summary>
		public int ControllerModelId { get; set; }

		/// <summary>
		/// Gets or sets ControllerTypeId
		/// </summary>
		public int ControllerTypeId { get; set; }

		/// <summary>
		/// Gets or sets WasherDosingNumber
		/// </summary>
		public int WasherDosingNumber { get; set; }

		/// <summary>
		/// Gets or sets WasherCounts
		/// </summary>
		public int WasherCount { get; set; }

        /// <summary>
        /// get or set UseFormulaFromGroupOne
        /// </summary>
        public bool UseGroup1Formulas { get; set; }

        #endregion
    }
}