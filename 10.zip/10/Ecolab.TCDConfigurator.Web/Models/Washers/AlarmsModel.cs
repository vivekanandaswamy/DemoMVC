﻿// -----------------------------------------------------------------------
// <copyright file="AlarmsModel.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The Washers is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.Washers
{
    using System;
    using System.Collections.Generic;

    public class AlarmsModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmMachineMappingId
        /// </summary>
        public int AlarmMachineMappingId { get; set; }

        /// <summary>
        ///     Gets or sets the AlarmMachineMappingIds
        /// </summary>
        public List<int> AlarmMachineMappingIds { get; set; }

        /// <summary>
        ///     Gets or sets the DisplayOrder
        /// </summary>
        public short DisplayOrder { get; set; }

        /// <summary>
        ///     Gets or sets the IsDefault
        /// </summary>
        public bool IsDefault { get; set; }

        /// <summary>
        ///     Gets or sets the Active
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        ///     Gets or sets the ResourceKey
        /// </summary>
        public string ResourceKey { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId
        /// </summary>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerTypeId
        /// </summary>
        public int ControllerTypelId { get; set; }

        /// <summary>
        ///     Gets or sets the ControllerModelId
        /// </summary>
        public int MachineNumber { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }
		/// <summary>
		/// Gets or Sets the IsBatchEjectCondition
		/// </summary>
		/// <value> Is Batch Eject Condition</value>
		public bool IsBatchEjectCondition { get; set; }

		/// <summary>
		/// Gets or Sets the Machine Id
		/// </summary>
		/// <value> The machine Identifier</value>
		public int TunnelId { get; set; }

        /// <summary>
		///     Gets or sets the Washer Group Type Id value for the washer groups.
		/// </summary>
		/// <value>Gets Washer Group Type Id value.</value>
		public byte WasherGroupTypeId { get; set; }
    }
}