﻿// -----------------------------------------------------------------------
// <copyright file="PumpsAndMECountModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>PumpsAndMECountModel </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Ecolab.TCDConfigurator.Web.Models.Washers
{
    /// <summary>
    ///     The PumpsAndMECountModel Class
    /// </summary>
    public class PumpsAndMECountModel
    {
        /// <summary>
        ///     gets the ID
        /// </summary>
        /// <value>The WasherProductDeviationID.</value>
        public int PumpsCount { get; set; }

        /// <summary>
        ///     gets the MECount 
        /// </summary>
        /// <value>The MECount.</value>
        public int MECount { get; set; }
    }
}