﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalGeneralModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel General object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Conventional
{
    using System;
    using System.Collections.Generic;
    using Dcs.Entities;

    /// <summary>
    ///     Class ConventionalGeneralModel.
    /// </summary>
    public class ConventionalGeneralModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name value.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the modelName.
        /// </summary>
        /// <value>The modelName.</value>
        public string ModelName { get; set; }

        /// <summary>
        ///     Gets or sets the sizeId.
        /// </summary>
        /// <value>The sizeId.</value>
        public int SizeId { get; set; }

        /// <summary>
        ///     Gets or sets the size.
        /// </summary>
        /// <value>The size value.</value>
        public string Size { get; set; }

        /// <summary>
        ///     Gets or sets the controller.
        /// </summary>
        /// <value>The controller.</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller.
        /// </summary>
        /// <value>The name of the controller.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherModeId.
        /// </summary>
        /// <value>The WasherModeId.</value>
        public Int16 WasherModeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the WasherMode.
        /// </summary>
        /// <value>The name of the WasherMode.</value>
        public string WasherModeName { get; set; }

        /// <summary>
        ///     Gets or sets the WasherModelId.
        /// </summary>
        /// <value>The WasherModelId.</value>
        public Int16 WasherModelId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer model.
        /// </summary>
        /// <value>The name of the washer model.</value>
        public string WasherModelName { get; set; }

        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public int LfsWasher { get; set; }

        /// <summary>
        ///     Gets or sets the EndOfFormula .
        /// </summary>
        /// <value> End of Formula.</value>
        public Int16 EndOfFormula { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool AweActive { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [Hold signal].
        /// </summary>
        /// <value>true/false.</value>
        public bool HoldSignal { get; set; }

        /// <summary>
        ///     Gets or sets the Hold Delay.
        /// </summary>
        /// <value>The Hold Delay.</value>
        public int HoldDelay { get; set; }

        /// <summary>
        ///     Gets or sets the TargetTurnTime.
        /// </summary>
        /// <value>The TargetTurnTime.</value>
        public int TargetTurnTime { get; set; }

        /// <summary>
        ///     Gets or sets the PlantWasherNumber.
        /// </summary>
        /// <value>The PlantWasherNumber.</value>
        public Int16 PlantWasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the MaxLoad.
        /// </summary>
        /// <value>The MaxLoad.</value>
        public Int16 MaxLoad { get; set; }

        /// <summary>
        ///     Gets or sets the WaterFlushTime.
        /// </summary>
        /// <value>WaterFlushTime.</value>
        public int WaterFlushTime { get; set; }

        /// <summary>
        ///     Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the washer group identifier.
        /// </summary>
        /// <value>The washer group identifier.</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the washer group identifier.
        /// </summary>
        /// <value>The washer group identifier.</value>
        public int WasherGroupIdNew { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer type.
        /// </summary>
        /// <value>The name of the washer type.</value>
        public string WasherTypeName { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        ///     Gets or sets the region identifier.
        /// </summary>
        /// <value>The region identifier.</value>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the role.
        /// </summary>
        /// <value>The role of logged user.</value>
        public int Role { get; set; }

        /// <summary>
        ///     Gets or sets the tags list for conventional.
        /// </summary>
        /// <value>Returns the list of tags.</value>
        public IEnumerable<ConventionalTagModel> ConventionalWasherTagList { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Data
        /// </summary>
        /// <value>The Parameter Controller Data</value>
        public List<OpcTag> PlcWasherTagModelTags { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustMchGrpGuid for Washer group
        /// </summary>
        /// <value>MyServiceCustMchGrpGuid</value>
        public Guid MyServiceCustMchGrpGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceCustMchGuid for washer 
        /// </summary>
        /// <value>MyServiceCustMchGuid</value>
        public Guid MyServiceCustMchGuid { get; set; }

        /// <summary>
        ///     Gets or sets the MyService Id.
        /// </summary>
        /// <value>The MyService Id..</value>
        public int MyServiceMCHId { get; set; }

        /// <summary>
        ///     Gets or sets the  IsValueDiffforEOF
        /// </summary>
        /// <value>IsValueDiffforEOF</value>
        public bool IsValueDiffforEOF { get; set; }

        /// <summary>
        ///     Gets or sets the IsValueDiffforMode
        /// </summary>
        /// <value>IsValueDiffforMode</value>
        public bool IsValueDiffforMode { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsValueDiffforHoldDelay { get; set; }

        /// <summary>
        ///     Gets or sets the IsValueDifffor Water Flush
        /// </summary>
        /// <value>IsValueDiffforWaterFlush</value>
        public bool IsValueDiffforWaterFlush { get; set; }

        /// <summary>
        ///     Gets or sets the IsValueDifffor Ratio dosing Active
        /// </summary>
        /// <value>IsValueDiffforRatiodosingActive</value>
        public bool IsValueDiffforRatiodosingActive { get; set; }

        /// <summary>
        ///  Gets or sets the IsValueDifffor AWEActive
        /// </summary>
        /// <value>IsValueDiffforAWEActive</value>
        public bool IsValueDiffforAWEActive { get; set; }

        /// <summary>
        ///  Gets or sets the IsValueDifffor HoldSignal
        /// </summary>
        /// <value>IsValueDiffforHoldSignal</value>
        public bool IsValueDiffforHoldSignal { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [RatioDosingActive].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool RatioDosingActive { get; set; }

		/// <summary>
		///     Gets or sets the Min Machine Load
		/// </summary>
		/// <value>Min Machine Load</value>
		public short MinMachineLoad { get; set; }

		/// <summary>
		///     Gets or sets the Max Machine Load
		/// </summary>
		/// <value>Max Machine Load</value>
		public short MaxMachineLoad { get; set; }

		/// <summary>
		///     Gets or sets the Program Selection By Time
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool ProgramSelectionByTime { get; set; }

		/// <summary>
		/// Gets or sets FlowSwitchNumber
		/// </summary>
		/// <value>Flow Switch Number</value>
		public int FlowSwitchNumber { get; set; }

		/// <summary>
		/// Gets or sets washerStopExternalSignal
		/// </summary>
		/// <value>washerStopExternalSignal</value>
		public bool WasherStopExternalSignal { get; set; }

		/// <summary>
		/// Gets or sets the WasherOnHoldSignalDelay
		/// </summary>
		/// <value>Washer on hold signal delay</value>
		public int WasherOnHoldSignalDelay { get; set; }

		/// <summary>
		///     Gets or sets the Value Outputs Used As TOM Signal
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool ValveOutputsUsedAsTomSignal { get; set; }

		/// <summary>
		///     Gets or sets the WE In TOM Mode
		/// </summary>
		/// <value><c>true/false</c>.</value>
		public bool WeInTomMode { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L1
		/// </summary>
		/// <value>true/false</value>
		public bool L1 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L2
		/// </summary>
		/// <value>true/false</value>
		public bool L2 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L3
		/// </summary>
		/// <value>true/false</value>
		public bool L3 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L4
		/// </summary>
		/// <value>true/false</value>
		public bool L4 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L5
		/// </summary>
		/// <value>true/false</value>
		public bool L5 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L6
		/// </summary>
		/// <value>true/false</value>
		public bool L6 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L7
		/// </summary>
		/// <value>true/false</value>
		public bool L7 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L8
		/// </summary>
		/// <value>true/false</value>
		public bool L8 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L9
		/// </summary>
		/// <value>true/false</value>
		public bool L9 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L10
		/// </summary>
		/// <value>true/false</value>
		public bool L10 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L11
		/// </summary>
		/// <value>true/false</value>
		public bool L11 { get; set; }

		/// <summary>
		/// Gets or sets the Lines Connected to Manifold L12
		/// </summary>
		/// <value>true/false</value>
		public bool L12 { get; set; }

        /// <summary>
		/// Gets or sets the ManiFold Flush Time
		/// </summary>
		/// <value>Mani fold flush time</value>
		public int ManifoldFlushTime { get; set; }

		/// <summary>
		/// Gets or sets OnHoldWESignalActive
		/// </summary>
		/// <value>OnHoldWESignalActive</value>
		public bool OnHoldWESignalActive { get; set; }

		/// <summary>
		/// Gets or sets the controller model id
		/// </summary>
		/// <value>Controller model id</value>
		public int ControllerModelId { get; set; }

		/// <summary>
        ///     Gets or sets a value indicating whether Pony Wahser or not.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool IsPony { get; set; }

		/// <summary>
		/// Gets or sets the controller type id
		/// </summary>
		/// <value>Controller type id</value>
		public int ControllerTypeId { get; set; }

		/// <summary>
		/// Gets or sets UseMe1OfGroup
		/// </summary>
		public byte? UseMe1OfGroup { get; set; }

		/// <summary>
		/// Gets or sets UseMe2OfGroup
		/// </summary>
		public byte? UseMe2OfGroup { get; set; }

		/// <summary>
		/// Gets or sets UsePumpOfGroup
		/// </summary>
		public byte? UsePumpOfGroup { get; set; }

		/// <summary>
		/// Gets or sets WasherStopUseFinalExtracting
		/// </summary>
		public bool? WasherStopUseFinalExtracting { get; set; }

		/// <summary>
		/// Gets or sets TemperatureAlarmYesNo
		/// </summary>
		public bool? TemperatureAlarmYesNo { get; set; }

		/// <summary>
		/// Gets or sets PhProbe
		/// </summary>
		public bool? PhProbe { get; set; }

		/// <summary>
		/// Gets or sets WeightCell
		/// </summary>
		public bool? WeightCell { get; set; }

		/// <summary>
		/// Gets or sets Temperature
		/// </summary>
		public bool? Temperature { get; set; }

		/// <summary>
		/// Gets or sets WaterCounter
		/// </summary>
		public bool? WaterCounter { get; set; }

        /// <summary>
        ///     Gets or sets the Date And Time When Batch Ejects
        /// </summary>
        /// <value>DateAndTimeWhenBatchEjects</value>
        public bool? DateAndTimeWhenBatchEjects { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix After
        /// </summary>
        /// <value>Auto Rinse Desamix After</value>
        public short? AutoRinseDesamixAfter { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 1 For
        /// </summary>
        /// <value>Auto Rinse Desamix 1 For</value>
        public short? AutoRinseDesamix1For { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 2 For
        /// </summary>
        /// <value>Auto Rinse Desamix 2 For</value>
        public short? AutoRinseDesamix2For { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 1
        /// </summary>
        /// <value>Temperature Alarm Probe 1</value>
        public bool? TemperatureAlarmProbe1 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 2
        /// </summary>
        /// <value>Temperature Alarm Probe 2</value>
        public bool? TemperatureAlarmProbe2 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 3
        /// </summary>
        /// <value>Temperature Alarm Probe 3</value>
        public bool? TemperatureAlarmProbe3 { get; set; }

        public int DefaultIdleTime { get; set; }

        /// <summary>
        /// InjectionRatio
        /// </summary>
        public decimal InjectionRatio { get; set; }

        /// <summary>
        ///     Gets or sets the ETechWasherNumber
        /// </summary>
        /// <value>ETechWasherNumber</value>
        public int ETechWasherNumber { get; set; }
        /// <summary>
        ///     Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>SignalAcceptanceTime</value>
        public int SignalAcceptanceTime { get; set; }

        /// <summary>
        ///     Gets or sets the KannegiesserDosageInPreparationTankMode
        /// </summary>
        /// <value>KannegiesserDosageInPreparationTankMode</value>
        public bool KannegiesserDosageInPreparationTankMode { get; set; }

        /// <summary>
        ///     Gets or sets the BatchOk
        /// </summary>
        /// <value>BatchOk</value>
        public bool BatchOk { get; set; }

        /// <summary>
        /// Gets or sets the Add Extracting Time To EOF Signal.
        /// </summary>
        /// <value>
        /// The name of the Add Extracting Time To EOF Signal.
        /// </value>
        public bool ExtractTimeForEOFSignal { get; set; }

    }
}