﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalTagModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ConventionalTagModel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Models.Washers.Conventional
{
    public class ConventionalTagModel
    {
        /// <summary>
        ///     Gets or sets the name of the WasherMode.
        /// </summary>
        /// <value>The name of the WasherMode.</value>
        public string WasherModeTag { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentFormula.
        /// </summary>
        /// <value>The CurrentFormula.</value>
        public string CurrentFormulaTag { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentInjection.
        /// </summary>
        /// <value>The CurrentInjection.</value>
        public string CurrentInjectionTag { get; set; }

        /// <summary>
        ///     Gets or sets the CurrentOperationCounter.
        /// </summary>
        /// <value>The CurrentOperationCounter.</value>
        public string CurrentOperationCounterTag { get; set; }

        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public string WasherNumberTag { get; set; }

        /// <summary>
        ///     Gets or sets the EndOfFormula .
        /// </summary>
        /// <value> End of Formula.</value>
        public string EndOfFormulaTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public string AutoWeightEntryActiveTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [Hold signal].
        /// </summary>
        /// <value>true/false.</value>
        public string HoldSignalTag { get; set; }

        /// <summary>
        ///     Gets or sets the Hold Delay.
        /// </summary>
        /// <value>The Hold Delay.</value>
        public string HoldDelayTag { get; set; }

        /// <summary>
        ///     Gets or sets the WaterFlushTime.
        /// </summary>
        /// <value>WaterFlushTime.</value>
        public string WaterFlushTimeTag { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string InjectionRatioTag { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer type.
        /// </summary>
        /// <value>The name of the washer type.</value>
        public string InjectionClassTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public string RatioDosingActiveTag { get; set; }

        /// <summary>
        ///     Gets or sets the region identifier.
        /// </summary>
        /// <value>The region identifier.</value>
        public string RatioDosingPercentageTag { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe formula].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public string AutoWeightEntryFormulaTag { get; set; }

		/// <summary>
		/// Gets or sets the automatic weight entry weight tag.
		/// </summary>
		/// <value>
		/// The automatic weight entry weight tag.
		/// </value>
        public string AutoWeightEntryWeightTag { get; set; }

        /// <summary>
        ///     Gets or sets TagDescription.
        /// </summary>
        /// <value>TagDescription.</value>
        public string TagDescription { get; set; }

        /// <summary>
        ///     Gets or sets a value for TagAddress.
        /// </summary>
        /// <value>TagAddress.</value>
        public string TagAddress { get; set; }
    }
}