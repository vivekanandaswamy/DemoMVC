﻿// <copyright file="TunnelConventionalDropDownModel.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>The Tunnel Conventional Drop Down Model</summary>
// ***********************************************************************

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Conventional
{
    using System.Collections.Generic;
    using Tunnel;
    using WasherGroup;

    /// <summary>
    ///     Class TunnelConventionalDropDownModel.
    /// </summary>
    public class TunnelConventionalDropDownModel
    {
        /// <summary>
        ///     Gets or sets the list of Washer step items.
        /// </summary>
        /// <value>The wash operation details.</value>
        public IEnumerable<WashStepModel> WashOperationDetails { get; set; }

        /// <summary>
        ///     Gets or sets the water inlet drain list.
        /// </summary>
        /// <value>The water inlet drain list.</value>
        public IEnumerable<PressExtractorModel> WaterInletDrainList { get; set; }

        /// <summary>
        ///     Gets or sets the water flow list.
        /// </summary>
        /// <value>The water flow list.</value>
        public IEnumerable<PressExtractorModel> WaterFlowList { get; set; }

        /// <summary>
        ///     Gets or sets the pumps product list.
        /// </summary>
        /// <value>The pumps product list.</value>
        public IEnumerable<PumpAssociationModel> PumpsProductList { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroup list.
        /// </summary>
        /// <value>The WasherGroup list.</value>
        public IEnumerable<WasherGroup> WasherGroupList { get; set; }
    }
}