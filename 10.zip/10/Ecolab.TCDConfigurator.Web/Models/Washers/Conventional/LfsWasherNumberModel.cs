﻿// -----------------------------------------------------------------------
// <copyright file="LfsWasherNumberModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>LfsWasherNumberModel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Models.Washers.Conventional
{
    using System;

    /// <summary>
    ///     Class LfsWasherNumberModel.
    /// </summary>
    public class LfsWasherNumberModel
    {
        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public Int16 LfsWasherMaxNumber { get; set; }
    }
}