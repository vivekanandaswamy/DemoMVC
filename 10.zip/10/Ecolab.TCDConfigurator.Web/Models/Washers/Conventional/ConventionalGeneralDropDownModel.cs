﻿// -----------------------------------------------------------------------
// <copyright file="ConventionalGeneralDropDownModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Conventional General DropDown Model </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Conventional
{
    using System.Collections.Generic;
    using Ecolab.Models.ControllerSetup;
    using WasherGroup;

    /// <summary>
    ///     Class ConventionalGeneralDropDownModel.
    /// </summary>
    public class ConventionalGeneralDropDownModel
    {
        /// <summary>
        ///     Gets or sets the washers model list.
        /// </summary>
        /// <value>The washers model list.</value>
        public IEnumerable<WasherModelListModel> WashersModelList { get; set; }

        /// <summary>
        ///     Gets or sets the Washer Mode list.
        /// </summary>
        /// <value>The Washer Mode list.</value>
        public IEnumerable<WasherModeListModel> WasherModeList { get; set; }

        /// <summary>
        ///     Gets or sets the controller list.
        /// </summary>
        /// <value>The controller list.</value>
        public IEnumerable<Controller> ControllerList { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroup list.
        /// </summary>
        /// <value>The WasherGroup list.</value>
        public IEnumerable<WasherGroup> WasherGroupList { get; set; }

		/// <summary>
		///     Gets or sets the WasherGroup list.
		/// </summary>
		/// <value>The WasherGroup list.</value>
		public IEnumerable<WasherGroup> WasherGroupListForDropDown { get; set; }
    }
}