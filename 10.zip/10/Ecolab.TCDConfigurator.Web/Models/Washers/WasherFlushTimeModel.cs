﻿// -----------------------------------------------------------------------
// <copyright file="WasherFlushTimeModel.cs" company="Ecolab">
// This class is for declaring the entities of washer group.
// </copyright>
// <summary>The WasherFlushTimeModel is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.Washers
{
	using System;

	public class WasherFlushTimeModel : BaseViewModel
	{
		/// <summary>
		///     Gets or sets the signalNumber
		/// </summary>
		/// <value>The Signal Number</value>
		public int WasherId { get; set; }

		/// <summary>
		///     Gets or sets the signalNumber
		/// </summary>
		/// <value>The Signal Number</value>
		public byte LineNumber { get; set; }

		/// <summary>
		///     Gets or sets the equipmentNumber
		/// </summary>
		/// <value>The Equipment Number</value>
		public int FlushTime { get; set; }

		/// <summary>
		///     Gets or sets the LastModifiedTime
		/// </summary>
		/// <value>The Last Modified Time</value>
		public DateTime LastModifiedTime { get; set; }

		/// <summary>
		///     Gets or sets the WasherFlushTypeId
		/// </summary>
		/// <value>The Washer Flush Type Id</value>
		public WasherFlushType WasherFlushTypeId { get; set; }

		/// <summary>
		///     Gets or sets the PumpCount
		/// </summary>
		/// <value>The PumpCount</value>
		public int PumpCount { get; set; }

		/// <summary>
		///     Gets or sets the MeCount
		/// </summary>
		/// <value>The MeCount</value>
		public int MeCount { get; set; }

		/// <summary>
		///     Gets or sets the WaterCount
		/// </summary>
		/// <value>The WaterCount</value>
		public int WaterCount { get; set; }

		/// <summary>
		///     Gets or sets the AirCount
		/// </summary>
		/// <value>The AirCount</value>
		public int AirCount { get; set; }
	}

	public enum WasherFlushType
	{
		Pump = 3,
		MainEquipment = 4,
		Air = 2,
		Water = 1,
	}
}