﻿// <copyright file="TunnelCompartmentModel.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>Tunnel Comaprtment Model Class</summary>
// ***********************************************************************

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;
    using Ecolab.TCDConfigurator.Web.Models.Washers.Conventional;

    /// <summary>
    ///     Class TunnelCompartmentModel.
    /// </summary>
    public class TunnelCompartmentModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the compartment number.
        /// </summary>
        /// <value>The compartment number.</value>
        public byte CompartmentNumber { get; set; }

        /// <summary>
        ///     Gets or sets the compartment number.
        /// </summary>
        /// <value>The compartment number.</value>
        public int tunnelCompartmentId { get; set; }

        /// <summary>
        ///     Gets or sets the wash step identifier.
        /// </summary>
        /// <value>The wash step identifier.</value>
        public int WashStepId { get; set; }

        /// <summary>
        ///     Gets or sets the waterinlet drain identifier.
        /// </summary>
        /// <value>The waterinlet drain identifier.</value>
        public Int16 WaterinletDrainId { get; set; }

        /// <summary>
        ///     Gets or sets the water flow identifier.
        /// </summary>
        /// <value>The water flow identifier.</value>
        public short WaterFlowId { get; set; }

        /// <summary>
        ///     Gets or sets the water level.
        /// </summary>
        /// <value>The water level.</value>
        public Decimal WaterLevel { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [temperature control by PMR].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool TemperatureControlByPMR { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [use press extract water].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool UsePressExtractWater { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [split compartment].
        /// </summary>
        /// <value>
        ///     <value><c>true/false</c>.</value>
        /// </value>
        public bool SplitCompartment { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [recycled water inlet].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool RecycledWaterInlet { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this <see cref="TunnelCompartmentModel" /> is steam.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool Steam { get; set; }

        /// <summary>
        ///     Gets or sets the pump association list.
        /// </summary>
        /// <value>The pump association list.</value>
        public List<PumpAssociationModel> PumpAssociationList { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        /// Gets or sets WasherGroupId
        /// </summary>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the drop downs in the tunnel
        /// </summary>
        /// <value> Returns the drop downs</value>
        public TunnelConventionalDropDownModel TunnelDropDowns { get; set; }

        /// <summary>
        ///     Gets or sets a value is iteration point.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool Iterationpoint { get; set; }

        /// <summary>
        ///     Gets or sets a value MyServiceWasherId.
        /// </summary>
        public Guid MyServiceWasherId { get; set; }

        /// <summary>
        /// Gets or sets the MyServiceDrainLookUpId
        /// </summary>
        /// <value>MyServiceDrainLookUpId</value>
        public int MyServiceDrainLookUpId { get; set; }

        /// <summary>
        /// Gets or sets the MyServiceTunnelWaterFlowTypeId
        /// </summary>
        /// <value>MyServiceTunnelWaterFlowTypeId</value>
        public int MyServiceTunnelWaterFlowTypeId { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this <see cref="TunnelCompartmentModel" /> is DosagePoint.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool DosagePoint { get; set; }

        /// <summary>
        /// Gets or sets the pH Probe
        /// </summary>
        /// <value> true/false </value>
        public bool PhProbe { get; set; }

        /// <summary>
        /// Gets or sets the Conductivity
        /// </summary>
        /// <value> true/false </value>
        public bool Conductivity { get; set; }

        /// <summary>
        /// Gets or sets the Temperature
        /// </summary>
        /// <value> true/false </value>
        public bool Temperature { get; set; }

        /// <summary>
        /// Gets or sets the Redox
        /// </summary>
        /// <value> true/false </value>
        public bool Redox { get; set; }

        /// <summary>
        /// ControllerEquipmentSetupId
        /// </summary>
        public int ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the compartment number.
        /// </summary>
        /// <value>The compartment number.</value>
        public byte NewCompartmentNumber { get; set; }
		/// <summary>
		/// The Machine Num,ber
		/// </summary>
		public int MachineNumber { get; set; }

		/// <summary>
		///     Gets or sets the New Tunnel Compartment Id.
		/// </summary>
		/// <value>The New Tunnel Compartment Id.</value>
		public int NewTunnelCompartmentId { get; set; }
    }
}