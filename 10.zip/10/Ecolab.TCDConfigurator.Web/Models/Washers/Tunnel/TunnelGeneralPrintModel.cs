﻿// -----------------------------------------------------------------------
// <copyright file="TunnelGeneralPrintModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel General object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
    using System.Collections.Generic;
    using ControllerSetup;
    using Conventional;
    using WasherGroup;

    /// <summary>
    ///     Class TunnelGeneralPrintModel
    /// </summary>
    public class TunnelGeneralPrintModel
    {
        /// <summary>
        ///     Gets or sets the value the Tunnel General Data
        /// </summary>
        /// <value>Tunnel General Data Object</value>
        public TunnelGeneralModel TunnelGeneralData { get; set; }

        /// <summary>
        ///     Gets or sets the value Washer Group Data
        /// </summary>
        /// <value>List of Controller Setup Data</value>
        public IEnumerable<WasherGroup> WasherGroupData { get; set; }

        /// <summary>
        ///     Gets or sets the value Controller Setup Data
        /// </summary>
        /// <value>List of Controller Model</value>
        public IEnumerable<ControllerModel> ControllerSetupData { get; set; }

        /// <summary>
        ///     Gets or sets the value Hold Conditions Data
        /// </summary>
        /// <value>Alarms Data object</value>
        public AlarmsData HoldConditionData { get; set; }

        /// <summary>
        /// Gets or Sets the value Batch Eject data
        /// </summary>
        public AlarmsData BatchEjectData { get; set; }

        /// <summary>
        ///     Gets or sets the value Tunnel Compartment Data
        /// </summary>
        /// <value>List of Tunnel Compartment Model</value>
        public List<TunnelCompartmentModel> TunnelCompartmentData { get; set; }

        /// <summary>
        ///     Gets or sets the value Tunnel General Drop Down Data
        /// </summary>
        /// <value>Returns the Tunnel General DropDown Data</value>
        public TunnelGeneralDropdownsModel TunnelGeneralDropDownData { get; set; }

        /// <summary>
        ///     Gets or sets the value Compartment Drop Down Data
        /// </summary>
        /// <value>Compartment Drop Down Data</value>
        public TunnelConventionalDropDownModel CompartmentDropDownData { get; set; }

        /// <summary>
        ///     Gets or sets the value Washer Mode List
        /// </summary>
        /// <value>List of Washer Modes</value>
        public IEnumerable<WasherModeListModel> WasherModeList { get; set; }

        /// <summary>
        ///     Gets or sets the value Tunnel Formula Data
        /// </summary>
        /// <value>Tunnel Group Formula Lists</value>
        public TunnelGroupFormulaLists TunnelFormulaData { get; set; }

        /// <summary>
        ///     Gets or sets the value Washers Data
        /// </summary>
        /// <value>List of Washers Model</value>
        public IEnumerable<WashersModel> WashersData { get; set; }

		/// <summary>
		/// Gets or Sets the value of FlushTimeAndSetupTomData
		/// </summary>
		public FlushTimesAndSetupTom FlushTimesAndSetupTomData { get; set; }

		/// <summary>
		/// Gets or Sets the value of analogueDosingdata
		/// </summary>
		public List<AnalogueDosing> AnalogueDosingData { get; set; }
		
		/// <summary>
		/// Gets or Sets the value of TunnelConnectionsdata
		/// </summary>
		public List<TunnelConnections> TunnelConnectionsdata { get; set; }
        /// <summary>
        /// Gets or Sets The Regon Id
        /// </summary>
        /// <value>The Region Id</value>
        public int RegionId { get; set; }
    }
}