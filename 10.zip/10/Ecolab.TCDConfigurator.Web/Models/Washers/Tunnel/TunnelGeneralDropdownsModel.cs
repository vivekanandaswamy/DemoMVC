﻿// <copyright file="TunnelGeneralDropdownsModel.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>The Tunnel General DropDown Model Class</summary>
// ***********************************************************************

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
    using System.Collections.Generic;
    using Ecolab.Models.ControllerSetup;
    using WasherGroup;

    public class TunnelGeneralDropdownsModel
    {
        /// <summary>
        ///     Gets or sets the washers model list.
        /// </summary>
        /// <value>The washers model list.</value>
        public IEnumerable<WashersListModel> WashersModelList { get; set; }

        /// <summary>
        ///     Gets or sets the press extractor list.
        /// </summary>
        /// <value>The press extractor list.</value>
        public IEnumerable<PressExtractorModel> PressExtractorList { get; set; }

        /// <summary>
        ///     Gets or sets the transfer type list.
        /// </summary>
        /// <value>The transfer type list.</value>
        public IEnumerable<PressExtractorModel> TransferTypeList { get; set; }

        /// <summary>
        ///     Gets or sets the washer mode list.
        /// </summary>
        /// <value>The washer mode list.</value>
        public IEnumerable<PressExtractorModel> WasherModeList { get; set; }

        /// <summary>
        ///     Gets or sets the controller list.
        /// </summary>
        /// <value>The controller list.</value>
        public IEnumerable<Controller> ControllerList { get; set; }

        /// <summary>
        ///     Gets or sets the WasherGroup list.
        /// </summary>
        /// <value>The WasherGroup list.</value>
        public IEnumerable<WasherGroup> WasherGroupList { get; set; }
    }
}