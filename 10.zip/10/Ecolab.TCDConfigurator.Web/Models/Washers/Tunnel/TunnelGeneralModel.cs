﻿// -----------------------------------------------------------------------
// <copyright file="TunnelGeneralModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Tunnel General object</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
    using System;
    using System.Collections.Generic;
    using Dcs.Entities;

    /// <summary>
    ///     Class TunnelGeneralModel.
    /// </summary>
    public class TunnelGeneralModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the model.
        /// </summary>
        /// <value>The model.</value>
        public short ModelId { get; set; }

        /// <summary>
        ///     Gets or sets the controller.
        /// </summary>
        /// <value>The controller.</value>
        public int ControllerId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller.
        /// </summary>
        /// <value>The name of the controller.</value>
        public string ControllerName { get; set; }

        /// <summary>
        ///     Gets or sets the controller Type Id.
        /// </summary>
        /// <value>The Parameter controller Type id.</value>
        public int ControllerTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller type.
        /// </summary>
        /// <value>The name of the controller type.</value>
        public string ControllerType { get; set; }

        /// <summary>
        ///     Gets or sets the controller Model Id.
        /// </summary>
        /// <value>The Parameter controller Model id.</value>
        public int ControllerModelId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller model.
        /// </summary>
        /// <value>The name of the controller model.</value>
        public string ControllerModel { get; set; }

        /// <summary>
        ///     Gets or sets the type of the washer.
        /// </summary>
        /// <value>The type of the washer.</value>
        public string WasherType { get; set; }

        /// <summary>
        ///     Gets or sets the size.
        /// </summary>
        /// <value>The size value.</value>
        public string Size { get; set; }

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The name value.</value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the plant washer number.
        /// </summary>
        /// <value>The plant washer number.</value>
        public short PlantWasherNumber { get; set; }

        /// <summary>
        ///     Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        /// <summary>
        ///     Gets or sets the washer capacity.
        /// </summary>
        /// <value>The washer capacity.</value>
        public short MaxLoad { get; set; }

        /// <summary>
        ///     Gets or sets the washer mode.
        /// </summary>
        /// <value>The washer mode.</value>
        public short WasherMode { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [awe active].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool AweActive { get; set; }

        /// <summary>
        ///     Gets or sets the no of compartments.
        /// </summary>
        /// <value>no of compartments.</value>
        public int NoofCompartments { get; set; }

        /// <summary>
        ///     Gets or sets the no of tanks.
        /// </summary>
        /// <value>The no of tanks.</value>
        public short? NoofTanks { get; set; }

        /// <summary>
        ///     Gets or sets the press/extractor.
        /// </summary>
        /// <value>The press extractor.</value>
        public short? PressExtractor { get; set; }

        /// <summary>
        ///     Gets or sets the type of the transfer.
        /// </summary>
        /// <value>The type of the transfer.</value>
        public short? TransferType { get; set; }

        /// <summary>
        ///     Gets or sets the program number.
        /// </summary>
        /// <value>The program number.</value>
        public short ProgramNumber { get; set; }

        /// <summary>
        ///     Gets or sets the EndOfFormula.
        /// </summary>
        /// <value>The EndOfFormula.</value>
        public short EndOfFormula { get; set; }

        /// <summary>
        ///     Gets or sets the washer group identifier.
        /// </summary>
        /// <value>The washer group identifier.</value>
        public int WasherGroupId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer group.
        /// </summary>
        /// <value>The name of the washer group.</value>
        public string WasherGroupName { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [tunnel or conventional].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WasherTypeFlag { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer model.
        /// </summary>
        /// <value>The name of the washer model.</value>
        public string WasherModelName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the washer type.
        /// </summary>
        /// <value>The name of the washer type.</value>
        public string WasherTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the region identifier.
        /// </summary>
        /// <value>The region identifier.</value>
        public int RegionId { get; set; }

        /// <summary>
        ///     Gets or sets the role of the logged user.
        /// </summary>
        public int Role { get; set; }

        /// <summary>
        ///     gets or sets the list of tunnel tags.
        /// </summary>
        public List<TunnelTagsModel> TunnelTagsList { get; set; }

        /// <summary>
        ///     Gets or sets the tunnel tags.
        /// </summary>
        public TunnelTagsModel TunnelTags { get; set; }

        /// <summary>
        ///     Gets or sets the Controller Data
        /// </summary>
        /// <value>The Parameter Controller Data</value>
        public List<OpcTag> PlcTunnelTagModelTags { get; set; }

        /// <summary>
        ///     Gets or sets the LastSyncTime
        /// </summary>
        /// <value>LastSyncTime</value>
        public DateTime LastSyncTime { get; set; }

        /// <summary>
        ///     Gets or sets Max Number Of Records
        /// </summary>
        /// <value> Max Number Of Records </value>
        public int MaxNumberOfRecords { get; set; }

        /// <summary>
        ///     Gets or sets the Last Modified Time Stamp
        /// </summary>
        /// <value>LastModifiedTimeStamp</value>
        public DateTime LastModifiedTimeStamp { get; set; }

        /// <summary>
        ///     Gets or sets the Is Delete
        /// </summary>
        /// <value>IsDelete</value>
        public bool IsDelete { get; set; }

        /// <summary>
        ///     Gets or sets the Formula Count
        /// </summary>
        /// <value> FormulaCount</value>
        public int FormulaCount { get; set; }

        /// <summary>
        /// Gets or sets MyServiceWasherGroupGuid
        /// </summary>
        public Guid MyServiceWasherGroupGuid { get; set; }

        /// <summary>
        /// Gets or sets MyServiceWasherGroupGuid
        /// </summary>
        public Guid MyServiceWashersGuid { get; set; }

        /// <summary>
        ///     Gets or sets the MyService Id.
        /// </summary>
        /// <value>The MyService Id..</value>
        public int MyServiceMCHId { get; set; }

        /// <summary>
        ///     Gets or sets the PressExtractorName.
        /// </summary>
        /// <value>The Press Extractor Name.</value>
        public string PressExtractorName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the transfer.
        /// </summary>
        /// <value>The name of the transfer.</value>
        public string TransferTypeName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the RegionCode.
        /// </summary>
        /// <value>The name of the RegionCode.</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the Model Type Id of the washer.
        /// </summary>
        /// <value>The Model Type Id of the washer.</value>
        public int MyServiceModelId { get; set; }

        /// <summary>
        ///     Gets or sets the MyService washer capacity.
        /// </summary>
        /// <value>The MyService washer capacity.</value>
        public int MyServiceMaxLoad { get; set; }

        /// <summary>
        ///     Gets or sets the IsValueDiffforMode
        /// </summary>
        /// <value>IsValueDiffforMode</value>
        public bool IsValueDiffforMode { get; set; }

        /// <summary>
        ///  Gets or sets the IsValueDiffforAWEActive
        /// </summary>
        /// <value>IsValueDiffforAWEActive</value>
        public bool IsValueDiffforAWEActive { get; set; }

        /// <summary>
        ///     Gets or sets the IsValueDifffor Ratio dosing Active
        /// </summary>
        /// <value>IsValueDiffforRatiodosingActive</value>
        public bool IsValueDiffforRatiodosingActive { get; set; }

        /// <summary>
        ///     Gets or sets the IsValueDifffor End of formula 
        /// </summary>
        /// <value>IsValueDiffforEOF</value>
        public bool IsValueDiffforEOF { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether [RatioDosingActive].
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool RatioDosingActive { get; set; }

        /// <summary>
        ///     Gets or sets the LfsWasher.
        /// </summary>
        /// <value>The LfsWasher.</value>
        public int LfsWasher { get; set; }

        /// <summary>
        ///     Gets or sets the Number Of Compartments Conveyor Belt
        /// </summary>
        /// <value>Number Of Compartments Conveyor Belt</value>
        public short NumberOfCompartmentsConveyorBelt { get; set; }

        /// <summary>
        ///     Gets or sets the Min Machine Load
        /// </summary>
        /// <value>Min Machine Load</value>
        public short MinMachineLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Max Machine Load
        /// </summary>
        /// <value>Max Machine Load</value>
        public short MaxMachineLoad { get; set; }

        /// <summary>
        ///     Gets or sets the Program Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ProgramSelectionByTime { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Selection By Time
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightSelectionByTime { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Selection By Analog Input
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightSelectionByAnalogInput { get; set; }

        /// <summary>
        ///     Gets or sets the TUN In TOM Mode
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool TunInTomMode { get; set; }

        /// <summary>
        ///     Gets or sets the Signal Stop TUN Active
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool SignalStopTunActive { get; set; }

        /// <summary>
        ///     Gets or sets the Signal Ejection TUN Active
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool SignalEjectionTunActive { get; set; }

        /// <summary>
        ///     Gets or sets the Delay Time For TUN Washing Programs
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool DelayTimeForTunWashingPrograms { get; set; }

        /// <summary>
        ///     Gets or sets the Kannegiesser Press Special Mode
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool KannegiesserPressSpecialMode { get; set; }

        /// <summary>
        ///     Gets or sets the Value Outputs Used As TOM Signal
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ValveOutputsUsedAsTomSignal { get; set; }

        /// <summary>
        ///     Gets or sets the Extended Clock Or Data Protocol
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool ExtendedClockOrDataProtocol { get; set; }

        /// <summary>
        ///     Gets or sets the Weight Correction (F.C.C)
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool WeightCorrectionFcc { get; set; }

        /// <summary>
        ///     Gets or sets the Date And Time When Batch Ejects
        /// </summary>
        /// <value>DateAndTimeWhenBatchEjects</value>
        public bool? DateAndTimeWhenBatchEjects { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix After
        /// </summary>
        /// <value>Auto Rinse Desamix After</value>
        public short? AutoRinseDesamixAfter { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 1 For
        /// </summary>
        /// <value>Auto Rinse Desamix 1 For</value>
        public short? AutoRinseDesamix1For { get; set; }

        /// <summary>
        ///     Gets or sets the Auto Rinse Desamix 2 For
        /// </summary>
        /// <value>Auto Rinse Desamix 2 For</value>
        public short? AutoRinseDesamix2For { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 1
        /// </summary>
        /// <value>Temperature Alarm Probe 1</value>
        public bool? TemperatureAlarmProbe1 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 2
        /// </summary>
        /// <value>Temperature Alarm Probe 2</value>
        public bool? TemperatureAlarmProbe2 { get; set; }

        /// <summary>
        ///     Gets or sets the Temperature Alarm Probe 3
        /// </summary>
        /// <value>Temperature Alarm Probe 3</value>
        public bool? TemperatureAlarmProbe3 { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether Pony Wahser or not.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool IsPony { get; set; }

        /// <summary>
        /// Gets or sets UseMe1OfGroup
        /// </summary>
        public byte? UseMe1OfGroup { get; set; }

        /// <summary>
        /// Gets or sets UseMe2OfGroup
        /// </summary>
        public byte? UseMe2OfGroup { get; set; }

        /// <summary>
        ///     Gets or sets the ETechWasherNumber
        /// </summary>
        /// <value>ETechWasherNumber</value>
        public int ETechWasherNumber { get; set; }
        /// <summary>
        ///     Gets or sets the SignalAcceptanceTime
        /// </summary>
        /// <value>SignalAcceptanceTime</value>
        public int SignalAcceptanceTime { get; set; }

        /// <summary>
        ///     Gets or sets the KannegiesserDosageInPreparationTankMode
        /// </summary>
        /// <value>KannegiesserDosageInPreparationTankMode</value>
        public bool KannegiesserDosageInPreparationTankMode { get; set; }

        /// <summary>
        ///     Gets or sets the BatchOk
        /// </summary>
        /// <value>BatchOk</value>
        public bool BatchOk { get; set; }

        /// <summary>
        /// Gets or sets the transfer per hour.
        /// </summary>
        /// <value>
        /// The transfer per hour.
        /// </value>
        public int TransferPerHour { get; set; }
    }
}