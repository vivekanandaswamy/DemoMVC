﻿// -----------------------------------------------------------------------
// <copyright file="WashersListModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Washers Model object for WasherList</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
    public class WashersListModel
    {
        /// <summary>
        ///     Gets or sets the name of the washer model.
        /// </summary>
        /// <value>The name of the washer model.</value>
        public string WasherModelName { get; set; }
    }
}