﻿// -----------------------------------------------------------------------
// <copyright file="PressExtractorModel.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PressExtractor Model object for PressExtractor List</summary>
// -----------------------------------------------------------------------

using System;
namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
    /// <summary>
    ///     Class PressExtractorModel.
    /// </summary>
    public class PressExtractorModel : BaseViewModel
    {
        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>The Parameter name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or Sets Region Code
        /// </summary>
        /// <value>Region Code</value>
        public string RegionCode { get; set; }

        /// <summary>
        ///     Gets or sets the sp_SP
        /// </summary>
        /// <value>The Parameter sp_SP</value>
        public string sp_SP { get; set; }

        /// <summary>
        ///     Gets or sets the nr_NR
        /// </summary>
        /// <value>The Parameter nr_NR</value>
        public string nr_NR { get; set; }

        /// <summary>
        ///     Gets or sets the nl_BE
        /// </summary>
        /// <value>The Parameter nl_BE</value>
        public string nl_BE { get; set; }

        /// <summary>
        /// Gets or Sets MyServicePropId
        /// </summary>
        /// <value>MyServicePropId</value>
        public Int16 MyServicePropId { get; set; }

        /// <summary>
        /// Gets or Sets MyServiceModDtTm
        /// </summary>
        /// <value>MyServiceModDtTm</value>
        public DateTime MyServiceModDtTm { get; set; }
    }
}