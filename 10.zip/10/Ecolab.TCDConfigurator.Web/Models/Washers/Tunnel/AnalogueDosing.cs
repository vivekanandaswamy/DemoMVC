﻿// <copyright file="AnalogueDosing.cs" company="Ecolab">
//     Copyright (c) Ecolab Company. All rights reserved.
// </copyright>
// <summary>The Tunnel Connections Class</summary>
// ***********************************************************************
namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
	#region Usings
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;
	#endregion

	/// <summary>
	/// Tunnel Connections Class
	/// </summary>
	public class AnalogueDosing : BaseViewModel
	{
		/// <summary>
		/// Gets or Sets The Level.
		/// </summary>
		/// <value>The Level.</value>
		public int Level { get; set; }

		/// <summary>
		/// Gets or Sets the SetPoint
		/// </summary>
		/// <value>The SetPoint</value>
		public decimal SetPoint { get; set; }

		/// <summary>
		/// Gets or Sets the PreQuantity
		/// </summary>
		/// <value>The Pre Quantity</value>
		public decimal PreQuantity { get; set; }

		/// <summary>
		/// Gets or Sets the Pre Pause Time
		/// </summary>
		public int PrePauseTime { get; set; }

		/// <summary>
		/// Gets or Sets the Quantity
		/// </summary>
		/// <value>The Quantity.</value>
		public int Quantity { get; set; }

		/// <summary>
		/// Gets or Sets the PauseTime
		/// </summary>
		/// <value>The PauseTime</value>
		public int PauseTime { get; set; }

		/// <summary>
		/// Gets or Sets the MaxTime.
		/// </summary>
		/// <value>The MaxTime.</value>
		public int MaxTime { get; set; }

		/// <summary>
		/// Gets or Sets the MinValue
		/// </summary>
		/// <value>The MinValue</value>
		public decimal MinValue { get; set; }

		/// <summary>
		/// Gets or Sets the MaxValue
		/// </summary>
		/// <value>The MaxValue</value>
		public decimal MaxValue { get; set; }

		/// <summary>
		/// Gets or Sets the MaxValue
		/// </summary>
		/// <value>The MaxValue</value>
		public int ControlDelay { get; set; }

		/// <summary>
		/// Gets or Sets the DelayAfterTransfer
		/// </summary>
		/// <value>The DelayAfterTransfer</value>
		public int DelayAfterTransfer { get; set; }		

		/// <summary>
		/// Gets or Sets the LastModifiedTime
		/// </summary>
		/// <value>The LastModifiedTime</value>
		public DateTime LastModifiedTime { get; set; }

		/// <summary>
		/// Gets or Sets the LastModifiedTime
		/// </summary>
		/// <value>The LastModifiedTime</value>
		public DateTime LastSyncTime { get; set; }

		/// <summary>
		/// Gets or Sets the MaxNumberOfRecords
		/// </summary>
		/// <value>The MaxNumberOfRecords</value>
		public int MaxNumberOfRecords { get; set; }

		/// <summary>
		/// Gets or Sets the WasherId
		/// </summary>
		/// <value>The Washer Id</value>
		public int WasherId { get; set; }	
		/// <summary>
		/// Gets or Sets the AnalogControlLevelTypeId
		/// </summary>
		/// <value>The AnalogControlLevelTypeId</value>
		public int AnalogControlLevelTypeId { get; set; }
		/// <summary>
		/// Gets or Sets the AnalogControlLevelId
		/// </summary>
		/// <value>The AnalogControlLevelId</value>
		public int AnalogControlLevelId { get; set; }
	}
}