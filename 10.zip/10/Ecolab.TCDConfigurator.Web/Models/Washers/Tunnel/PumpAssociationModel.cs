﻿// <copyright file="PumpAssociationModel.cs" company="Hewlett-Packard Company">
//     Copyright (c) Hewlett-Packard Company. All rights reserved.
// </copyright>
// <summary>The Pumps Association Model</summary>
// ***********************************************************************

namespace Ecolab.TCDConfigurator.Web.Models.Washers.Tunnel
{
    /// <summary>
    ///     The Tunnel namespace.
    /// </summary>
    public class PumpAssociationModel
    {
        /// <summary>
        ///     Gets or sets the controller equipment setup identifier.
        /// </summary>
        /// <value>The controller equipment setup identifier.</value>
        public short ControllerEquipmentSetupId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment identifier.
        /// </summary>
        /// <value>The controller equipment identifier.</value>
        public byte ControllerEquipmentId { get; set; }

        /// <summary>
        ///     Gets or sets the controller equipment type identifier.
        /// </summary>
        /// <value>The controller equipment type identifier.</value>
        public byte ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     Gets or sets the name of the controller equipment setup identifier.
        /// </summary>
        /// <value>The name of the controller equipment setup identifier.</value>
        public string ControllerEquipmentSetupIdName { get; set; }

        /// <summary>
        ///     Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value><c>true/false</c>.</value>
        public bool IsDeleted { get; set; }

        /// <summary>
        ///     Gets or sets the Formulas Associated.
        /// </summary>
        public int FormulaAssociated { get; set; }
    }
}