﻿// -----------------------------------------------------------------------
// <copyright file="ProductDeviationModel.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ProductDeviationModel </summary>
// -----------------------------------------------------------------------
namespace Ecolab.TCDConfigurator.Web.Models.Washers
{
    /// <summary>
    ///     The ProductDeviationModel Class
    /// </summary>
    public class ProductDeviationModel
    {
        /// <summary>
        ///     gets or sets the ID
        /// </summary>
        /// <value>The WasherProductDeviationID.</value>
        public int Id { get; set; }

        /// <summary>
        ///     gets or sets the Controller ID
        /// </summary>
        /// <value>The ControllerID.</value>
        public int ControllerID { get; set; }

        /// <summary>
        ///     gets or sets the Controller Equipment ID
        /// </summary>
        /// <value>The ControllerEquipmentID.</value>
        public int ControllerEquipmentID { get; set; }

        /// <summary>
        ///     gets or sets the Controller Equipment TypeId
        /// </summary>
        /// <value>The ControllerEquipmentTypeId.</value>
        public int ControllerEquipmentTypeId { get; set; }

        /// <summary>
        ///     gets or sets the WasherId
        /// </summary>
        /// <value>The WasherId.</value>
        public int WasherId { get; set; }

        /// <summary>
        ///     gets or sets the Product Name
        /// </summary>
        /// <value>The Product Name.</value>
        public string ProductName { get; set; }

        /// <summary>
        ///     gets or sets the Product Deviation Value
        /// </summary>
        /// <value>The Product Deviation Value.</value>
        public int ProductDeviationValue { get; set; }

        /// <summary>
        ///     gets or sets the ConventionalWasherGroupConnection Value
        /// </summary>
        /// <value>The ConventionalWasherGroupConnection Value.</value>
        public bool ConventionalWasherGroupConnection { get; set; }

        /// <summary>
        /// get set EnvisionDisplayName
        /// </summary>
        public string EnvisionDisplayName { get; set; }
    }
}
