﻿// -----------------------------------------------------------------------
// <copyright file="Helper.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Helper Base class for Views</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.App_Code
{
    using System.Collections.Generic;
    using System.Web.Mvc;
    using Controllers;
    using Services;
    using Services.Interfaces;

    public abstract class Helper<T> : WebViewPage<T>
    {
        /// <summary>
        ///     Localization Data
        /// </summary>
        private Dictionary<string, string> localizationData;

        private Dictionary<string, string> localizationUOMData;

        /// <summary>
        ///     Property for Localization Data
        /// </summary>
        public Dictionary<string, string> LocalizationData
        {
            get { return localizationData ?? ( localizationData = FetchLocalizationData() ); }
        }

        public Dictionary<string, string> LocalizationUomData
        {
            get { return localizationUOMData ?? (localizationUOMData = FetchLocalizationUomData()); }
        }

        /// <summary>
        ///     Get Localized value using the Key
        /// </summary>
        /// <param name="key">Localization Key</param>
        /// <param name="defaultValue">Return string if data is unavalilable for the Key</param>
        /// <returns>Localized value</returns>
        protected string Localize(string key, string defaultValue)
        {
            return LocalizationData.ContainsKey(key) ? LocalizationData[key] : defaultValue;
        }

        /// <summary>
        ///     Gets Localization Data
        /// </summary>
        /// <returns>Dictionary of Localization Data</returns>
        private Dictionary<string, string> FetchLocalizationData()
        {
            IUserService userService = new UserService();
            IPlantService plantService = new PlantService();
            LocaleController locale = new LocaleController(userService, plantService);
            return locale.FetchLocalizationData();
        }

        protected string LocalizeUom(string key, string defaultValue)
        {
            return !string.IsNullOrWhiteSpace(key) ? LocalizationUomData.ContainsKey(key) ? LocalizationUomData[key] : defaultValue : defaultValue;
        }

        private Dictionary<string, string> FetchLocalizationUomData()
        {
            IUserService userService = new UserService();
            IPlantService plantService = new PlantService();
            LocaleController locale = new LocaleController(userService, plantService);
            return locale.FetchLocalizationUomData();
        }
    }
}