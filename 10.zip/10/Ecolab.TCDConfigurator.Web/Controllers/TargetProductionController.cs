﻿// -----------------------------------------------------------------------
// <copyright file="TargetProductionController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Labor Cost Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     class for TargetProductionController
    /// </summary>
    public class TargetProductionController : BaseController
    {
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        public TargetProductionController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return this.View();
        }
    }
}