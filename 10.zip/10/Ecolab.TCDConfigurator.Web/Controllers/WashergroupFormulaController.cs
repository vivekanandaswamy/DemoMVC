﻿// -----------------------------------------------------------------------
// <copyright file="WashergroupFormulaController.cs" company="Ecolab">
// This web controller is for washer group formula.
// </copyright>
// <summary>The washer group formula is for get and set the data.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Collections.Generic;
    using System.Web.Mvc;
    using Services.Interfaces;
    using Services.Interfaces.WasherGroup;

    public class WashergroupFormulaController : BaseController
    {
        /// <summary>
        ///     Interface for washer group in service layer as IWasherGroupService
        /// </summary>
        private readonly IWasherGroupService washerGroupFormulaService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="WashergroupFormulaController" /> class.
        /// </summary>
        /// <param name="washerGroupFormulaService">The interface for WasherGroup formula.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        public WashergroupFormulaController(IWasherGroupService washerGroupFormulaService, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.washerGroupFormulaService = washerGroupFormulaService;
        }

        /// <summary>
        ///     This action method is for loading the washer group formula view.
        /// </summary>
        /// <returns>Washer group formula view.</returns>
        public ActionResult Index()
        {
            string path = Request.QueryString.Get("Path");
            if (Request.UrlReferrer != null)
            {
                string url = Request.UrlReferrer.ToString().ToLower();
                string washerGroupId = "WasherGroupId".ToLower();
                string washerId = Request.QueryString.Get("WasherId");
                if (url.Contains(washerGroupId))
                {
                    ViewBag.Path = "Washer";
                    ViewBag.washerId = washerId;
                }
            }
            ViewBag.WasherGroupTypeId = Request.QueryString.Get("WasherGroupTypeId");
            GetPageSetupViewBags();
            int washerGrpId = !string.IsNullOrEmpty(this.Request.QueryString.Get("Id")) ? int.Parse(this.Request.QueryString.Get("Id")) : 0;
            List<Ecolab.Models.WasherGroup.WasherGroup> washerGroupList = this.washerGroupFormulaService.GetWasherGroupDetails(washerGrpId, this.ViewBag.EcolabAccountNumber, 1, 1, string.Empty);
            this.ViewBag.ControllerModelId = washerGroupList != null && washerGroupList.Count > 0 ? washerGroupList[0].ControllerModelId : 0;
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}