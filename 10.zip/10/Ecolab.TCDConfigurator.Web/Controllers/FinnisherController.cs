﻿// -----------------------------------------------------------------------
// <copyright file="FinnisherController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Finnisher Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class Finnisher Controller
    /// </summary>
    public class FinnisherController : BaseController
    {
        public FinnisherController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        //
        // GET: /Finnisher/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}