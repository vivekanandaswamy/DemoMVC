﻿// -----------------------------------------------------------------------
// <copyright file="PrintController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Print Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Api;
    using Api.PlantSetup;
    using Api.Washers.Conventional;
    using Api.Washers.Tunnel;
    using Models;
    using Models.ControllerSetup;
    using Models.PdfGeneration;
    using Models.PlantSetup;
    using Models.WasherGroup;
    using Models.Washers.Conventional;
    using Models.Washers.Tunnel;
    using Newtonsoft.Json;
    using Services;
    using Services.ControllerSetup;
    using Services.ControllerSetup.Pumps;
    using Services.Interfaces;
    using Services.Interfaces.ControllerSetup;
    using Services.Interfaces.ControllerSetup.Pumps;
    using Services.Interfaces.PlantSetup;
    using Services.Interfaces.PlantSetup.Dryer;
    using Services.Interfaces.PlantSetup.Finnisher;
    using Services.Interfaces.PlantSetup.ShiftLabor;
    using Services.Interfaces.Plc;
    using Services.Interfaces.StorageTanks;
    using Services.Interfaces.WasherGroup;
    using Services.Interfaces.Washers;
    using Services.Interfaces.Washers.Conventional;
    using Services.Interfaces.Washers.Tunnel;
    using Services.PlantSetup;
    using Services.PlantSetup.Dryer;
    using Services.PlantSetup.Finnisher;
    using Services.PlantSetup.ShiftLabor;
    using Services.Plc;
    using Services.StorageTanks;
    using Services.WasherGroup;
    using Services.Washers;
    using Services.Washers.conventional;
    using Services.Washers.Tunnel;
    using Utilities;
    using Ecolab.TCDConfigurator.Web.Models.Washers;
    using Ecolab.Services.Visualization.Monitor;

    /// <summary>
    /// PrintController
    /// </summary>
    /// <seealso cref="Ecolab.TCDConfigurator.Web.Controllers.BaseController" />
    public class PrintController : BaseController
    {
        /// <summary>
        ///     Locale Controller
        /// </summary>
        private LocaleController locale;

        /// <summary>
        ///     Parameter Plant Location
        /// </summary>
        private string plantLocation;

        /// <summary>
        ///     Parameter Plant Name
        /// </summary>
        private string plantName;

        /// <summary>
        ///     Parameter Title
        /// </summary>
        private string title;

        /// <summary>
        ///     Initializes a new instance of the <see cref="PrintController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service</param>
        public PrintController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        [HttpGet]
        public void GetPdf(string page)
        {
            page = page.ToLower();
            this.title = string.IsNullOrEmpty(page) ? "Plant Setup" : page;
            this.locale = new LocaleController(this.UserService, this.PlantService);

            //The title has to be dynamically coming as part of the request             
            PlantModel plantDetails = this.GetPlantDetails();
            this.plantName = plantDetails.Name;
            this.plantLocation = plantDetails.RegionName;
            base.GetPageSetupViewBags();
            IPlantCustomerService customerService = new PlantCustomerService();
            string fileName = "Ecolab - " + this.locale.Localize("FIELD_PLANT SETUP", "Plant Setup") + " - {0} - " + DateTime.Now.ToShortDateString();
            switch (page)
            {
                case "general":
                    PlantSetupController plant = new PlantSetupController(this.UserService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_PlantGeneral", plant.Get())), string.Format(fileName, this.locale.Localize("FIELD_SETUP", "Setup")), this.Breadcrumb(page));
                    break;
                case "contact":
                    PlantContactService contactService = new PlantContactService();
                    Api.PlantSetup.ContactController contact = new Api.PlantSetup.ContactController(this.UserService, this.PlantService, contactService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Contact", contact.GetContact())), string.Format(fileName, this.locale.Localize("FIELD_CONTACTS", "Contacts")), this.Breadcrumb(page));
                    break;
                case "laborcost":
                    ILaborCostService laborCostService = new LaborCostService();
                    Api.PlantSetup.LaborCostController laborCost = new Api.PlantSetup.LaborCostController(this.UserService, this.PlantService, laborCostService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_LaborCost", laborCost.Fetch())), string.Format(fileName, this.locale.Localize("FIELD_LABORCOST", "Labor Cost")), this.Breadcrumb(page));
                    break;
                case "chemical":
                    IProductMasterService chemicalService = new ProductMasterService();
                    PlantChemicalController chemical = new PlantChemicalController(this.UserService, chemicalService, this.PlantService, null);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Chemical", chemical.GetPlantChemical())), string.Format(fileName, this.locale.Localize("FIELD_CHEMICALS", "Chemicals")), this.Breadcrumb(page));
                    break;
                case "formula":
                    IProgramMasterService formulaService = new ProgramMasterService();

                    PlantFormulaController formula = new PlantFormulaController(this.UserService, formulaService, customerService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Formula", formula.GetFormulaForPrint(1, 10000, 0))), string.Format(fileName, this.locale.Localize("FIELD_FORMULAS", "Formulas")), this.Breadcrumb(page));
                    break;
                case "redflag":
                    IRedFlagService redFlagService = new RedFlagService();
                    IMeterService meterService = new MeterService();
                    Api.PlantSetup.RedFlagController redFlag = new Api.PlantSetup.RedFlagController(this.UserService, this.PlantService, redFlagService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_RedFlag", redFlag.Get())), string.Format(fileName, this.locale.Localize("FIELD_REDFLAG", "Red Flag")), this.Breadcrumb(page));
                    break;
                case "customer":

                    Api.PlantSetup.CustomerController customer = new Api.PlantSetup.CustomerController(this.UserService, customerService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Customer", customer.GetCustomer())), string.Format(fileName, this.locale.Localize("FIELD_CUSTOMER", "Customer")), this.Breadcrumb(page));
                    break;
                case "dryer":
                    IDryerGroupService dryerGroupService = new DryerGroupService();
                    IDryerService dryerService = new DryerService();
                    Api.PlantSetup.DryerController dryer = new Api.PlantSetup.DryerController(this.UserService, this.PlantService, dryerGroupService, dryerService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Dryer", dryer.Get())), string.Format(fileName, this.locale.Localize("FIELD_DRYER", "Dryer")), this.Breadcrumb(page));
                    break;
                case "finisher":
                    IFinnisherGroupService finnisherGroupService = new FinnisherGroupService();
                    IFinnisherService finnisherService = new FinnisherService();
                    Api.PlantSetup.FinnisherController finnisher = new Api.PlantSetup.FinnisherController(this.UserService, finnisherGroupService, finnisherService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Finisher", finnisher.Get())), string.Format(fileName, this.locale.Localize("FIELD_FINNISHERS", "Finishers")), this.Breadcrumb(page));
                    break;
                case "utility":
                    IPlantUtilityService utilityService = new PlantUtilityService();
                    Api.PlantSetup.PlantUtilitySetupController utility = new Api.PlantSetup.PlantUtilitySetupController(this.UserService, this.PlantService, utilityService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Utility", utility.Get())), string.Format(fileName, this.locale.Localize("FIELD_UTILITY", "Utility")), this.Breadcrumb(page));
                    break;
                case "meter":
                    IMeterService meterService1 = new MeterService();
                    IPlcService plcService = new PlcService();
                    IPlantUtilityService plantUtilityService = new PlantUtilityService();
                    IWasherServices washerService = new WasherServices();
                    Api.PlantSetup.MeterController meter = new Api.PlantSetup.MeterController(this.UserService, meterService1, this.PlantService, plcService, plantUtilityService, washerService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Meter", meter.GetMeter())), string.Format(fileName, this.locale.Localize("FIELD_METERS", "Meters")), this.Breadcrumb(page));
                    break;
                case "sensor":
                    ISensorService sensorService = new SensorService();
                    IPlcService plcService1 = new PlcService();
                    Api.PlantSetup.SensorController sensor = new Api.PlantSetup.SensorController(this.UserService, sensorService, this.PlantService, plcService1);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Sensor", sensor.GetSensor())), string.Format(fileName, this.locale.Localize("FIELD_SENSORS", "Sensors")), this.Breadcrumb(page));
                    break;
                case "waterandenergy":
                    IUtilityService waterAndEnergyService = new UtilityService();
                    var waterAndEnergy = new Api.PlantSetup.UtilityController(UserService, waterAndEnergyService, PlantService);
                    DownloadPdf(
                        HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_WaterAndEnergy",
                            waterAndEnergy.GetUtility())),
                        string.Format(fileName, locale.Localize("FIELD_WATERENERGYDEVICE", "Water & Energy Device")),
                                Breadcrumb(page)
                                );
                    break;
                case "usermanagement":
                    IUserManagementService userManagementService = new UserManagementService();
                    Api.UserManagementController userManagement = new Api.UserManagementController(this.UserService, this.PlantService, userManagementService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_UserManagement", userManagement.FetchUserList())), string.Format(fileName, this.locale.Localize("FIELD_USERMANAGEMENT", "User Management")), this.Breadcrumb(page));
                    break;
                case "targetproduction":
                    IShiftBreakService targetProductionService = new ShiftBreakService();
                    Api.TargetProductionController targetProduction = new Api.TargetProductionController(this.UserService, this.PlantService, targetProductionService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_TargetProduction", targetProduction.FetchTargetProductionDetails())), string.Format(fileName, this.locale.Localize("FIELD_TARGETPRODUCTION", "Target Production")), this.Breadcrumb(page));
                    break;
                case "shiftlabor":
                    IShiftBreakService shiftBreakService = new ShiftBreakService();
                    ILaborService laborService = new LaborService();
                    Api.PlantSetup.ShiftLaborController shiftlabor = new Api.PlantSetup.ShiftLaborController(this.UserService, shiftBreakService, laborService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ShiftLabor", shiftlabor.Get())), string.Format(fileName, this.locale.Localize("FIELD_SHIFT", "Shift")), this.Breadcrumb(page));
                    break;
                case "controllersetuplist":
                    IControllerSetupService controllerSetupService = new ControllerSetupService();
                    Api.ControllerSetupController controllerSetupcontroller = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ControllerSetupList", controllerSetupcontroller.GetControllerDetails())), string.Format(fileName, this.locale.Localize("FIELD_CONTROLLERSETUPLIST", "Dispenser Setup List")), this.Breadcrumb(page));
                    break;
            }
            string pathName = "Ecolab - " + this.locale.Localize("FIELD_WASHER", "Washer") + " - {0} - " + DateTime.Now.ToShortDateString();
        }

        /// <summary>
        ///     Generates Pdf with the given data
        /// </summary>
        /// <param name="data">The Parameter Data</param>
        [HttpGet]
        public void GeneratePdf(string data)
        {
            PrintModel printObject = JsonConvert.DeserializeObject<PrintModel>(data);
            this.title = !string.IsNullOrEmpty(printObject.PageTitle) ? printObject.PageTitle.ToLower() : string.Empty;

            this.locale = new LocaleController(this.UserService, this.PlantService);
            PlantModel plant = this.GetPlantDetails();
            this.plantName = plant.Name;
            this.plantLocation = plant.RegionName;

            string fileName = "Ecolab - {0} - " + DateTime.Now.ToShortDateString();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            IPlcService plcService = new PlcService();

            switch (this.title)
            {
                case "washer list":
                    IWasherServices washerService = new WasherServices();
                    IWasherGroupService washerGroupService = new WasherGroupService();
                    IConventionalGeneralServices conventionalGeneralService = new ConventionalGeneralServices();
                    ITunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
                    Api.Washers.WasherController washerList = new Api.Washers.WasherController(washerService, washerGroupService, this.UserService, this.PlantService, conventionalGeneralService, tunnelGeneralServices);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_Washers", washerList.GetWashersDetails(printObject.EcolabAccountNumber))), string.Format(fileName, this.locale.Localize("FIELD_WASHER", "Washer")), this.Breadcrumb(this.title));
                    break;
                case "washer group":
                    WasherGroupPrintModel washerGroupPrintModel = this.GetWasherGroupDataWithWashersList(printObject);

                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_WasherGroup", washerGroupPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_WASHERGROUP", "WasherGroup")), this.Breadcrumb(this.title));
                    break;
                case "washergroup":
                    IWasherGroupService washerGroupservice = new WasherGroupService();
                    //Api.WasherGroupController washerGroup = new Api.WasherGroupController(washerGroupservice, this.UserService, this.PlantService);

                    IProgramMasterService programMasterService = new ProgramMasterService();
                    IWasherGroupFormulaService washerGrpFormulaService = new WasherGroupFormulaService();
                    IPlantUtilityService plantUtilityService = new PlantUtilityService();
                    IProductMasterService productMasterService = new ProductMasterService();
                    IWasherServices washerServices = new WasherServices();
                    WasherGroupFormulaController washerGroupFormula = new WasherGroupFormulaController(washerGroupservice, programMasterService, washerGrpFormulaService, plantUtilityService, productMasterService, this.PlantService, this.UserService, washerServices);
                    WasherGroupPrintModel washergroupPrintModel = new WasherGroupPrintModel();
                    washergroupPrintModel.WasherGroupWithWashers = new List<WasherGroupFormulaLists>();
                    washergroupPrintModel.WasherGroupWithWashers.Add(washerGroupFormula.GetWasherGroupWithWasherDetails(printObject.WasherGroupId, printObject.EcolabAccountNumber, 0, 12, string.Empty, printObject.RegionId));
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_WasherGroupWithWashers", washergroupPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_WASHERGROUP", "WasherGroup")), this.Breadcrumb(this.title));
                    break;
                case "storage tanks":
                    IStorageTanksService storageTankService = new StorageTanksService();
                    IPumpsService pumpServices = new PumpsServices();
                    Api.StorageTanksController storageTanks = new Api.StorageTanksController(this.UserService, storageTankService, controllerSetupService, pumpServices, plcService, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_StorageTank", storageTanks.GetTanksDetails(printObject.EcolabAccountNumber))), string.Format(fileName, this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks")), this.Breadcrumb(this.title));
                    break;
                case "storage tank":
                    IStorageTanksService storageTanksService = new StorageTanksService();
                    IPumpsService pumpsServices = new PumpsServices();
                    IPlcService plcServices = new PlcService();
                    Api.StorageTanksController storageTank = new Api.StorageTanksController(this.UserService, storageTanksService, controllerSetupService, pumpsServices, plcServices, this.PlantService);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_StorageTanksForm", storageTank.GetAddEditStorageTanksDetails(printObject.EcolabAccountNumber, printObject.StorageTankId).FirstOrDefault())), string.Format(fileName, this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks")), this.Breadcrumb(this.title));
                    break;
                case "conventional general":
                    ConventionGeneralPrintModel conventionalGeneralPrint = this.GetConventionalGeneralData(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ConventionalGeneral", conventionalGeneralPrint)), string.Format(fileName, this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General")), this.Breadcrumb(this.title));
                    break;
                case "conventionalgeneral":
                    ConventionGeneralPrintModel conventionGeneralPrintData = this.GetConventionalGeneralDataForHoldConditions(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ConventionalGeneral", conventionGeneralPrintData)), string.Format(fileName, this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General")), this.Breadcrumb(this.title));
                    break;
                case "tunnel general":
                    TunnelGeneralPrintModel tunnelGeneralPrint = this.GetTunnelGeneralData(printObject);
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_TunnelGeneral", tunnelGeneralPrint)), string.Format(fileName, this.locale.Localize("FIELD_TUNNELGENERAL", "Tunnel General")), this.Breadcrumb(this.title));
                    break;
                case "formula list":
                    WasherGroupFormulaLists washerGroupFormulaLists = GetFormulaList(printObject);
                    DownloadPdf(
                                HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_FormulaList", washerGroupFormulaLists)),
                        string.Format(fileName, locale.Localize("FIELD_FORMULAS", "Formulas")),
                                Breadcrumb(title)
                                );

                    break;
                case "formula washstep list":
                    ConventionGeneralPrintModel conventionGeneralPrintModel = GetConventionalWashStepData(printObject);
                    conventionGeneralPrintModel.RegionId = this.GetPlantDetails().RegionId;
                    DownloadPdf(
                        HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ConventionalWashStep",
                            conventionGeneralPrintModel)),
                        string.Format(fileName,
                            locale.Localize("FIELD_CONVENTIONALWASHSTEPS", "Conventional Wash Steps")),
                                Breadcrumb(title)
                                );
                    break;
                case "tunnel compartment list":
                    TunnelGeneralPrintModel tunnelGeneralPrintModel = GetTunnelCompartmentList(printObject);
                    DownloadPdf(
                        HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_TunnelWashStep",
                            tunnelGeneralPrintModel)),
                        string.Format(fileName, locale.Localize("FIELD_TUNNELWASHSTEPS", "Tunnel Wash Steps")),
                                Breadcrumb(title)
                                );
                    break;
                case "controller setup":
                    ControllerSetupPrintModel controllerSetupPrintModel = this.GetControllerSetupData(printObject);
                    controllerSetupPrintModel.RegionId = printObject.RegionId;
                    this.DownloadPdf(HttpUtility.HtmlDecode(RenderPartialViewToString(this, "_ControllerSetup", controllerSetupPrintModel)), string.Format(fileName, this.locale.Localize("FIELD_CONTROLLER SETUP", "Dispenser Setup")), this.Breadcrumb(this.title));
                    break;
            }
            string pathName = "Ecolab - " + this.locale.Localize("FIELD_WASHER", "Washer") + " - {0} - " + DateTime.Now.ToShortDateString();
        }

        /// <summary>
        ///     Creates PDF file
        /// </summary>
        /// <param name="htmlText">The content HTML of PDF file</param>
        /// <param name="fileName">File Name of Generated PDF file</param>
        /// <param name="breadcrumb">Page breadcrumb path in PDF</param>
        private void DownloadPdf(string htmlText, string fileName, string breadcrumb)
        {
            var pdfGenerator = new PdfGenerator();
            var contentForPdf = new HtmlContentForPdf
            {
                HtmlText = htmlText,
                Logo = GetPlantDetails().Logo,
                Title = plantName,
                PlantName = plantName,
                PlantLocation = plantLocation,
                Breadcrumb =
                    GetPlantDetails().plantCustAddr.BillingAddr1 + ","
                + GetPlantDetails().plantCustAddr.City + ","
                + GetPlantDetails().plantCustAddr.Country + "-" + GetPlantDetails().plantCustAddr.Zip
            };

            byte[] response = pdfGenerator.CreatePdf(contentForPdf);

            System.Web.HttpContext.Current.Response.Clear();
            System.Web.HttpContext.Current.Response.ContentType = "application/octet-stream";
            System.Web.HttpContext.Current.Response.AddHeader("Content-Type", "application/octet-stream");
            System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".pdf");
            System.Web.HttpContext.Current.Response.BinaryWrite(response);
            System.Web.HttpContext.Current.Response.End();
        }

        /// <summary>
        ///     Converts Partial view to string
        /// </summary>
        /// <param name="controller">The Controller</param>
        /// <param name="viewName">Name of the Partial View</param>
        /// <param name="model">Model data to be binded in view</param>
        /// <returns>Converted view as string</returns>
        private static string RenderPartialViewToString(Controller controller, string viewName, object model)
        {
            controller.ViewData.Model = model;
            using (StringWriter sw = new StringWriter())
            {
                ViewEngineResult viewResult = ViewEngines.Engines.FindPartialView(controller.ControllerContext, viewName);
                ViewContext viewContext = new ViewContext(controller.ControllerContext, viewResult.View, controller.ViewData, controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);
                return sw.ToString();
            }
        }

        /// <summary>
        ///     Generates a breadcrumb string
        /// </summary>
        /// <param name="page">The name of page</param>
        /// <returns>Breadcrumb as string</returns>
        private string Breadcrumb(string page)
        {
            page = page.ToLower();
            var breadcrumb = new List<string>();
            switch (page)
            {
                case "general":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    break;
                case "contact":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_CONTACTS", "Contacts"));
                    break;
                case "shiftlabor":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_SHIFT", "Shift"));
                    break;
                case "laborcost":
                    breadcrumb.Add(this.locale.Localize("FIELD_GENERAL", "General"));
                    breadcrumb.Add(this.locale.Localize("FIELD_LABORCOST", "Labor Cost"));
                    break;
                case "chemical":
                    breadcrumb.Add(this.locale.Localize("FIELD_CHEMICALS", "Chemicals"));
                    break;
                case "formula":
                    breadcrumb.Add(this.locale.Localize("FIELD_FORMULAS", "Formulas"));
                    break;
                case "redflag":
                    breadcrumb.Add(this.locale.Localize("FIELD_REDFLAG", "Red Flag"));
                    break;
                case "customer":
                    breadcrumb.Add(this.locale.Localize("FIELD_CUSTOMER", "Customer"));
                    break;
                case "dryer":
                    breadcrumb.Add(this.locale.Localize("FIELD_CLEANSIDE", "Clean Side"));
                    breadcrumb.Add(this.locale.Localize("FIELD_DRYER", "Dryer"));
                    break;
                case "finisher":
                    breadcrumb.Add(this.locale.Localize("FIELD_CLEANSIDE", "Clean Side"));
                    breadcrumb.Add(this.locale.Localize("FIELD_FINNISHERS", "Finishers"));
                    break;
                case "utility":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITY", "Utility"));
                    break;
                case "meter":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_METERS", "Meters"));
                    break;
                case "sensor":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_SENSORS", "Sensors"));
                    break;
                case "waterandenergy":
                    breadcrumb.Add(this.locale.Localize("FIELD_UTILITYFACTORS", "Utility Factors"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WATERENERGYDEVICE", "Water & Energy Device"));
                    break;
                case "usermanagement":
                    breadcrumb.Add(this.locale.Localize("FIELD_USERMANAGEMENT", "User Management"));
                    break;
                case "monitorsetup":
                    breadcrumb.Add(this.locale.Localize("FIELD_DASHBOARDSETUP", "Dashboard Setup"));
                    break;
                case "washer list":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    break;
                case "washer group":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERGROUP", "Washer Group"));
                    break;
                case "storage tanks":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks"));
                    break;
                case "storage tank":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_STORAGE TANKS", "Storage Tanks"));
                    break;
                case "conventional general":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General"));
                    break;
                case "conventionalgeneral":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_CONVENTIONALGENERAL", "Conventional General"));
                    break;
                case "tunnel general":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_TUNNELGENERAL", "Tunnel General"));
                    break;
                case "tunnelgeneral":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    breadcrumb.Add(this.locale.Localize("FIELD_TUNNELGENERAL", "Tunnel General"));
                    break;
                case "formula list":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    break;
                case "formula washstep list":
                    breadcrumb.Add(this.locale.Localize("FIELD_SETUP", "Setup"));
                    breadcrumb.Add(this.locale.Localize("FIELD_WASHERS", "Washers"));
                    break;
            }
            return string.Join(" > ", breadcrumb.ToArray());
        }

        /// <summary>
        ///     Gets WasherGroup Data with Washers
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private WasherGroupPrintModel GetWasherGroupDataWithWashersList(PrintModel printModel)
        {
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerServices = new WasherServices();
            Api.WasherGroupController washerGroup = new Api.WasherGroupController(washerGroupService, washerServices, this.UserService, this.PlantService);

            IProgramMasterService programMasterService = new ProgramMasterService();
            IWasherGroupFormulaService washerGrpFormulaService = new WasherGroupFormulaService();
            IPlantUtilityService plantUtilityService = new PlantUtilityService();
            IProductMasterService productMasterService = new ProductMasterService();

            WasherGroupFormulaController washerGroupFormula = new WasherGroupFormulaController(washerGroupService, programMasterService, washerGrpFormulaService, plantUtilityService, productMasterService, this.PlantService, this.UserService, washerServices);
            WasherGroupPrintModel washerGroupPrintModel = new WasherGroupPrintModel();
            washerGroupPrintModel.WasherGroupWithWashers = new List<WasherGroupFormulaLists>();
            washerGroupPrintModel.WasherGroupList = washerGroup.GetWasherGroupDetails(-1, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            for (int i = 0; i < washerGroupPrintModel.WasherGroupList.Count(); i++)
            {
                washerGroupPrintModel.WasherGroupWithWashers.Add(washerGroupFormula.GetWasherGroupWithWasherDetails(washerGroupPrintModel.WasherGroupList.ElementAt(i).WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty, printModel.RegionId));
            }

            return washerGroupPrintModel;
        }

        /// <summary>
        ///     Gets Conventional General Data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private ConventionGeneralPrintModel GetConventionalGeneralData(PrintModel printModel)
        {
            IConventionalGeneralServices conventionalGeneralService = new ConventionalGeneralServices();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerServices = new WasherServices();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            ITunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            ConventionGeneralPrintModel conventionalGeneralPrintModel = new ConventionGeneralPrintModel();
            ControllerModel controllerModel = new ControllerModel();
            IInjectionService injectionService = new InjectionService();
            IProductDeviationService productDeviationService = new ProductDeviationService();
            IFlushTimesAndSetupTomServices flushTimesAndTomServices = new FlushTimesAndSetupTomServices();

            ConventionalController conventionalController = new ConventionalController(conventionalGeneralService, controllerSetupService, washerGroupService, this.UserService, this.PlantService, injectionService, washerServices);
            Api.WasherGroupController washerGroupController = new Api.WasherGroupController(washerGroupService, washerServices, this.UserService, this.PlantService);
            Api.ControllerSetupController controllerSetupController = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
            Api.Washers.WasherController washerController = new Api.Washers.WasherController(washerServices, washerGroupService, this.UserService, this.PlantService, conventionalGeneralService, tunnelGeneralServices);

            FlushTimesAndSetupTomController flushTimesAndSetupTom = new FlushTimesAndSetupTomController(this.UserService, this.PlantService, tunnelGeneralServices, washerServices);
            Api.Washers.FlushTimesAndSetupTomController flushTimesAndSetupTomController = new Api.Washers.FlushTimesAndSetupTomController(this.UserService, this.PlantService, flushTimesAndTomServices, tunnelGeneralServices, washerGroupService);
            conventionalGeneralPrintModel.FlushTimesAndSetupTomData = flushTimesAndSetupTomController.GetData(printModel.WasherId, printModel.WasherGroupId,
                printModel.WasherGroupTypeId);

            Api.Washers.ProductDeviationController productDeviationController = new Api.Washers.ProductDeviationController(this.UserService, this.PlantService, productDeviationService, conventionalGeneralService, washerGroupService);

            conventionalGeneralPrintModel.ProductDeviationPrintData = productDeviationController.GetProductDeviationData(printModel.WasherId, printModel.WasherGroupId, printModel.ControllerId);

            conventionalGeneralPrintModel.ConventionalGeneralData = conventionalController.GetConventionalData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.RegionId);
            conventionalGeneralPrintModel.WasherGroupData = washerGroupController.GetWasherGroupDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            conventionalGeneralPrintModel.WasherModeList = conventionalController.GetWasherModeList(printModel.ControllerId, printModel.EcolabAccountNumber);

            if (printModel.ControllerId != 0)
            {
                controllerModel = controllerSetupController.GetControllerDetailById(printModel.ControllerId, printModel.EcolabAccountNumber);
            }
            conventionalGeneralPrintModel.HoldConditionData = washerController.GetAlarmSetupDetails(controllerModel.ControllerModelId, controllerModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, false);
            conventionalGeneralPrintModel.HoldConditionData.AlarmsModel = conventionalGeneralPrintModel.HoldConditionData.AlarmsModel.Where(a => a.Active);
            return conventionalGeneralPrintModel;
        }

        /// <summary>
        ///     Gets Conventional General Data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private ConventionGeneralPrintModel GetConventionalGeneralDataForHoldConditions(PrintModel printModel)
        {
            IConventionalGeneralServices conventionalGeneralService = new ConventionalGeneralServices();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerServices = new WasherServices();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            ITunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            ConventionGeneralPrintModel conventionalGeneralPrintModel = new ConventionGeneralPrintModel();
            IInjectionService injectionService = new InjectionService();
            IFlushTimesAndSetupTomServices flushTimesAndTomServices = new FlushTimesAndSetupTomServices();
            IProductDeviationService productDeviationService = new ProductDeviationService();

            ConventionalController conventionalGeneralController = new ConventionalController(conventionalGeneralService, controllerSetupService, washerGroupService, this.UserService, this.PlantService, injectionService, washerServices);
            Api.WasherGroupController washerGroupController = new Api.WasherGroupController(washerGroupService, washerServices, this.UserService, this.PlantService);
            Api.Washers.WasherController washerController = new Api.Washers.WasherController(washerServices, washerGroupService, this.UserService, this.PlantService, conventionalGeneralService, tunnelGeneralServices);

            FlushTimesAndSetupTomController flushTimesAndSetupTom = new FlushTimesAndSetupTomController(this.UserService, this.PlantService, tunnelGeneralServices, washerServices);
            Api.Washers.FlushTimesAndSetupTomController flushTimesAndSetupTomController = new Api.Washers.FlushTimesAndSetupTomController(this.UserService, this.PlantService, flushTimesAndTomServices, tunnelGeneralServices, washerGroupService);
            conventionalGeneralPrintModel.FlushTimesAndSetupTomData = flushTimesAndSetupTomController.GetData(printModel.WasherId, printModel.WasherGroupId,
                printModel.WasherGroupTypeId);

            Api.Washers.ProductDeviationController productDeviationController = new Api.Washers.ProductDeviationController(this.UserService, this.PlantService, productDeviationService, conventionalGeneralService, washerGroupService);

            conventionalGeneralPrintModel.ProductDeviationPrintData = productDeviationController.GetProductDeviationData(printModel.WasherId, printModel.WasherGroupId, printModel.ControllerId);

            conventionalGeneralPrintModel.ConventionalGeneralData = conventionalGeneralController.GetConventionalData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.RegionId);
            conventionalGeneralPrintModel.WasherModeList = conventionalGeneralController.GetWasherModeList(conventionalGeneralPrintModel.ConventionalGeneralData.ControllerId, printModel.EcolabAccountNumber);
            conventionalGeneralPrintModel.WasherGroupData = washerGroupController.GetWasherGroupDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            conventionalGeneralPrintModel.HoldConditionData = washerController.GetAlarmSetupDetails(printModel.ControllerModelId, printModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, false);
            conventionalGeneralPrintModel.HoldConditionData.AlarmsModel = conventionalGeneralPrintModel.HoldConditionData.AlarmsModel.Where(a => a.Active);

            return conventionalGeneralPrintModel;
        }

        /// <summary>
        ///     Gets Tunnel General Data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns TunnelGeneralPrintModel</returns>
        private TunnelGeneralPrintModel GetTunnelGeneralData(PrintModel printModel)
        {
            ITunnelGeneralServices tunnelGeneralService = new TunnelGeneralServices();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IWasherServices washerService = new WasherServices();
            IConventionalGeneralServices conventionalGeneralServices = new ConventionalGeneralServices();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            ITunnelCompartmentServices tunnelCompartmentService = new TunnelCompartmentServices();
            ITunnelGeneralServices tunnelGeneralServices = new TunnelGeneralServices();
            TunnelGeneralPrintModel tunnelGeneralPrintModel = new TunnelGeneralPrintModel();
            ControllerModel controllerModel = new ControllerModel();
            IInjectionService injectionService = new InjectionService();
            ITunnelConnectionServices tunnelConnectionService = new TunnelConnectionServices();

            IFlushTimesAndSetupTomServices flushTimesAndTomServices = new FlushTimesAndSetupTomServices();
            ITunnelAnalogueDosingControlServices analogueDosingControlServices = new TunnelAnalogueDosingControlServices();
            List<Ecolab.Models.Washers.Tunnel.AnalogueDosing> lstAnalogDosing = analogueDosingControlServices.FetchAnalogueDosingDataForMachineId(printModel.WasherId, printModel.EcolabAccountNumber);
            List<Models.Washers.Tunnel.AnalogueDosing> lstad = AutoMapper.Mapper.Map<List<Ecolab.Models.Washers.Tunnel.AnalogueDosing>, List<Models.Washers.Tunnel.AnalogueDosing>>(lstAnalogDosing);

            IEnumerable<Ecolab.Models.Washers.Tunnel.TunnelConnections> lstconn = tunnelConnectionService.FetchTunnelConnections(printModel.WasherId, printModel.ControllerId, printModel.EcolabAccountNumber);
            IEnumerable<Models.Washers.Tunnel.TunnelConnections> tunnelconn = AutoMapper.Mapper.Map<IEnumerable<Ecolab.Models.Washers.Tunnel.TunnelConnections>, List<Models.Washers.Tunnel.TunnelConnections>>(lstconn);

            TunnelController tunnelController = new TunnelController(tunnelGeneralService, controllerSetupService, washerGroupFormulaService, tunnelCompartmentService, washerGroupService, this.UserService, this.PlantService, tunnelConnectionService);
            Api.WasherGroupController washerGroupController = new Api.WasherGroupController(washerGroupService, washerService, this.UserService, this.PlantService);
            Api.ControllerSetupController controllerSetupController = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
            Api.Washers.WasherController washerController = new Api.Washers.WasherController(washerService, washerGroupService, this.UserService, this.PlantService, conventionalGeneralServices, tunnelGeneralServices);
            ConventionalController conventionalController = new ConventionalController(conventionalGeneralServices, controllerSetupService, washerGroupService, this.UserService, this.PlantService, injectionService, washerService);
            FlushTimesAndSetupTomController flushTimesAndSetupTom = new FlushTimesAndSetupTomController(this.UserService, this.PlantService, tunnelGeneralService, washerService);
            Api.Washers.FlushTimesAndSetupTomController flushTimesAndSetupTomController = new Api.Washers.FlushTimesAndSetupTomController(this.UserService, this.PlantService, flushTimesAndTomServices, tunnelGeneralService, washerGroupService);
            tunnelGeneralPrintModel.FlushTimesAndSetupTomData = flushTimesAndSetupTomController.GetData(printModel.WasherId, printModel.WasherGroupId,
                printModel.WasherGroupTypeId);
            tunnelGeneralPrintModel.TunnelConnectionsdata = tunnelconn.ToList();
            tunnelGeneralPrintModel.AnalogueDosingData = lstad;
            tunnelGeneralPrintModel.TunnelGeneralData = tunnelController.GetTunnelData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber);
            tunnelGeneralPrintModel.WasherGroupData = washerGroupController.GetWasherGroupDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty);
            tunnelGeneralPrintModel.TunnelGeneralDropDownData = tunnelController.GetDropDownData(printModel.EcolabAccountNumber, printModel.RegionId, "Tunnel", printModel.WasherGroupId);
            tunnelGeneralPrintModel.CompartmentDropDownData = tunnelController.GetCompartmentDropDownData(printModel.EcolabAccountNumber, printModel.RegionId, printModel.ControllerId, printModel.WasherId, printModel.WasherGroupId);

            tunnelGeneralPrintModel.TunnelCompartmentData = new List<TunnelCompartmentModel>();
            if (printModel.ControllerId != 0)
            {
                controllerModel = controllerSetupController.GetControllerDetailById(printModel.ControllerId, printModel.EcolabAccountNumber);
                tunnelGeneralPrintModel.WasherModeList = conventionalController.GetWasherModeList(printModel.ControllerId, printModel.EcolabAccountNumber);
            }
            for (int i = 1; i <= printModel.NumberOfCompartments; i++)
            {
                tunnelGeneralPrintModel.TunnelCompartmentData.Add(tunnelController.GetCompartmentData(printModel.WasherId, printModel.WasherGroupId, printModel.EcolabAccountNumber, Convert.ToByte(i), printModel.RegionId, printModel.ControllerId));
            }
            tunnelGeneralPrintModel.HoldConditionData = washerController.GetAlarmSetupDetails(controllerModel.ControllerModelId, controllerModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, false);
            tunnelGeneralPrintModel.HoldConditionData.AlarmsModel = tunnelGeneralPrintModel.HoldConditionData.AlarmsModel.Where(a => a.Active);
            tunnelGeneralPrintModel.BatchEjectData = washerController.GetAlarmSetupDetails(controllerModel.ControllerModelId, controllerModel.ControllerTypeId, printModel.MachineNumber, printModel.WasherGroupId, printModel.EcolabAccountNumber, printModel.WasherGroupTypeId, printModel.WasherId, true);
            tunnelGeneralPrintModel.BatchEjectData.AlarmsModel = tunnelGeneralPrintModel.BatchEjectData.AlarmsModel.Where(a => a.Active);

            return tunnelGeneralPrintModel;
        }

        /// <summary>
        ///     Gets Formulas List
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns WasherGroupFormulaLists</returns>
        private WasherGroupFormulaLists GetFormulaList(PrintModel printModel)
        {
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IProgramMasterService programMasterServcs = new ProgramMasterService();
            IPlantUtilityService plantUtilityService = new PlantUtilityService();
            IProductMasterService productMasterService = new ProductMasterService();
            IWasherServices washerServices = new WasherServices();
            var washerGroupFormulaLists = new WasherGroupFormulaLists();

            var washerGroupFormulaController = new WasherGroupFormulaController(washerGroupService, programMasterServcs,
                washerGroupFormulaService, plantUtilityService, productMasterService, PlantService, UserService,
                washerServices);

            washerGroupFormulaLists = washerGroupFormulaController.GetWasherGroupFormula(printModel.WasherGroupId,
                printModel.EcolabAccountNumber);
            washerGroupFormulaLists.RegionId = this.GetPlantDetails().RegionId;
            return washerGroupFormulaLists;
        }

        /// <summary>
        ///     Gets Conventional WashStep data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ConventionGeneralPrintModel</returns>
        private ConventionGeneralPrintModel GetConventionalWashStepData(PrintModel printModel)
        {
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IProgramMasterService prgMasterServcs = new ProgramMasterService();
            IPlantUtilityService plntUtltyService = new PlantUtilityService();
            IProductMasterService prdMasterService = new ProductMasterService();
            IWasherServices wshrSvc = new WasherServices();
            ConventionGeneralPrintModel conventionGeneralPrintModel = new ConventionGeneralPrintModel();
            IWasherServices washerServices = new WasherServices();
            WasherGroupFormulaController washerGroupFormula = new WasherGroupFormulaController(washerGroupService, prgMasterServcs, washerGroupFormulaService, plntUtltyService, prdMasterService, this.PlantService, this.UserService, washerServices);
            WasherGroupPrintModel washergroupPrintModel = new WasherGroupPrintModel();
            washergroupPrintModel.WasherGroupWithWashers = new List<WasherGroupFormulaLists> { washerGroupFormula.GetWasherGroupWithWasherDetails(printModel.WasherGroupId, printModel.EcolabAccountNumber, 0, 12, string.Empty, printModel.RegionId) };
            WasherGroupFormulaController washerGroupData = new WasherGroupFormulaController(washerGroupService, prgMasterServcs, washerGroupFormulaService, plntUtltyService, prdMasterService, this.PlantService, this.UserService, wshrSvc);
            conventionGeneralPrintModel.WasherGroupWithWashers = washergroupPrintModel;
            conventionGeneralPrintModel.FormulaData = washerGroupData.GetEditFormulaWashStepDetails(printModel.WasherGroupId, printModel.ProgramSetupId, printModel.DosingSetupId, printModel.EcolabAccountNumber, printModel.RegionId);
            return conventionGeneralPrintModel;
        }

        /// <summary>
        ///     Gets TunnelCompartment data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns TunnelGeneralPrintModel</returns>
        private TunnelGeneralPrintModel GetTunnelCompartmentList(PrintModel printModel)
        {
            IWasherGroupFormulaService washerGroupFormulaService = new WasherGroupFormulaService();
            IWasherGroupService washerGroupService = new WasherGroupService();
            IProgramMasterService programMasterService = new ProgramMasterService();
            IPlantUtilityService plantUtilitySrvice = new PlantUtilityService();
            IProductMasterService productMasterService = new ProductMasterService();
            IWasherServices washerService = new WasherServices();
            IConventionalGeneralServices conventionalGeneralService = new ConventionalGeneralServices();
            ITunnelGeneralServices tunnelServices = new TunnelGeneralServices();
            IEnumerable<WashersModel> washersModel = new List<WashersModel>();
            var tunnelGeneralPrintModel = new TunnelGeneralPrintModel();
            var washerGroupdata = new WasherGroupFormulaController(washerGroupService, programMasterService,
                washerGroupFormulaService, plantUtilitySrvice, productMasterService, PlantService, UserService,
                washerService);
            var washerController = new Api.Washers.WasherController(washerService, washerGroupService, UserService, PlantService, conventionalGeneralService, tunnelServices);

            washersModel = washerController.GetWashersDetails(printModel.EcolabAccountNumber);
            tunnelGeneralPrintModel.WashersData =
                washersModel.Where(x => x.WasherGroupId == printModel.WasherGroupId).ToList();
            tunnelGeneralPrintModel.TunnelFormulaData = washerGroupdata.GetTunnelGridDetails(printModel.ProgramSetupId,
                printModel.EcolabAccountNumber, printModel.CompartmentNumber, printModel.WasherGroupId,
                printModel.RegionId);
            tunnelGeneralPrintModel.RegionId = printModel.RegionId;
            return tunnelGeneralPrintModel;
        }

        /// <summary>
        ///     Gets ControllerSetup data
        /// </summary>
        /// <param name="printModel">The parameter PrintModel</param>
        /// <returns>Returns ControllerSetupPrintModel</returns>
		private ControllerSetupPrintModel GetControllerSetupData(PrintModel printModel)
        {
            ControllerSetupPrintModel controllerSetupPrintModel = new ControllerSetupPrintModel();
            IControllerSetupService controllerSetupService = new ControllerSetupService();
            IPumpsService pumpsService = new PumpsServices();
            IPlcService plcService = new PlcService();
            Api.ControllerSetupController controllerSetupcontroller = new Api.ControllerSetupController(this.UserService, this.PlantService, controllerSetupService);
            Api.PumpsController pumpsController = new Api.PumpsController(pumpsService, plcService, this.UserService, this.PlantService);
            controllerSetupPrintModel.ControllerGeneralData = controllerSetupcontroller.GetControllerSetupMetaDataWithValues(printModel.TabId, printModel.ControllerId);

            controllerSetupPrintModel.ControllerAdvancedData = controllerSetupcontroller.GetControllerSetupAdvanceMetaData(3, printModel.ControllerId);
            if (printModel.ControllerModelId != 5)
            {
                controllerSetupPrintModel.PumpsValvesData = pumpsController.GetPumps(printModel.EcolabAccountNumber, printModel.ControllerId, "All", 1);
            }
            return controllerSetupPrintModel;
        }
    }
}