﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerSetupController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    public class ControllerSetupController : BaseController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        public ControllerSetupController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <returns>Redirects to related view</returns>
        public ActionResult Index()
        {
            GetPageSetupViewBags();
            string controllerId = Request.QueryString.Get("ControllerId");
            string controllerModelId = Request.QueryString.Get("ControllerModelId");
            string controllerTypeId = Request.QueryString.Get("ControllerTypeId");
            if(!string.IsNullOrEmpty(controllerId) && !string.IsNullOrEmpty(controllerModelId) && !string.IsNullOrEmpty(controllerTypeId))
            {
                ViewBag.ControllerId = controllerId;
                ViewBag.ControllerModelId = controllerModelId;
                ViewBag.ControllerTypeId = controllerTypeId;
            }
            else
            {
                ViewBag.ControllerId = "-1";
                ViewBag.ControllerModelId = "-1";
                ViewBag.ControllerTypeId = "-1";
            }
            ViewBag.IsCentral = "Yes";
            return View();
        }

        /// <summary>
        ///     The Details Method
        /// </summary>
        /// <param name="id">The details based on Id</param>
        /// <returns>Returns the related view</returns>
        public ActionResult Details(int id)
        {
            return View();
        }

        /// <summary>
        ///     The Create Method
        /// </summary>
        /// <returns>Returns the related view</returns>
        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        ///     The Create Method
        /// </summary>
        /// <param name="collection">Collection of the data</param>
        /// <returns>Redirects to the related view</returns>
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        ///     The Edit method to get the values
        /// </summary>
        /// <param name="id">Edit the values based on Id</param>
        /// <returns>Redirects to the related view</returns>
        public ActionResult Edit(int id)
        {
            return View();
        }

        /// <summary>
        ///     Edit method to post the values
        /// </summary>
        /// <param name="id">pass the edited values based on Id</param>
        /// <param name="collection">The collection of data</param>
        /// <returns>Redirects to the related view </returns>
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        ///     Delete method to get the values to delete
        /// </summary>
        /// <param name="id">Delete the values based on Id</param>
        /// <returns>Returns the related view</returns>
        public ActionResult Delete(int id)
        {
            return View();
        }

        /// <summary>
        ///     Delete method to post the values
        /// </summary>
        /// <param name="id">delete the values based on Id</param>
        /// <param name="collection">The collection of values to delete</param>
        /// <returns>Redirects to the related view</returns>
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}