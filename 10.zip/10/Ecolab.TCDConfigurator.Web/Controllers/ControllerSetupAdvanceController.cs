﻿// -----------------------------------------------------------------------
// <copyright file="ControllerSetupAdvanceController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ControllerSetupAdvanceController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class ControllerSetupAdvanceController
    /// </summary>
    public class ControllerSetupAdvanceController : BaseController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="ControllerSetupAdvanceController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The plant service.</param>
        public ControllerSetupAdvanceController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <returns>Redirects to related view</returns>
        public ActionResult Index()
        {
            GetPageSetupViewBags();
            string controllerId = Request.QueryString.Get("ControllerId");
            string controllerModelId = Request.QueryString.Get("ControllerModelId");
            string controllerTypeId = Request.QueryString.Get("ControllerTypeId");
            if (!string.IsNullOrEmpty(controllerId) && !string.IsNullOrEmpty(controllerModelId) && !string.IsNullOrEmpty(controllerTypeId))
            {
                ViewBag.ControllerId = controllerId;
                ViewBag.ControllerModelId = controllerModelId;
                ViewBag.ControllerTypeId = controllerTypeId;
            }
            else
            {
                ViewBag.ControllerId = "-1";
                ViewBag.ControllerModelId = "-1";
                ViewBag.ControllerTypeId = "-1";
            }
			ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}