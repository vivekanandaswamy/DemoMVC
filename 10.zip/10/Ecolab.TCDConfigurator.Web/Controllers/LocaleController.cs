﻿// -----------------------------------------------------------------------
// <copyright file="LocaleController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Locale Controller  </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;
    using AutoMapper;
    using Ecolab.Models;
    using Entities;
    using Models;
    using Services.Interfaces;
    using LanguageMaster = Ecolab.Models.LanguageMaster;
    using Plant = Ecolab.Models.Plant;

    /// <summary>
    ///     Class LocaleController
    /// </summary>
    public class LocaleController : BaseController
    {
        /// <summary>
        ///     Localization Data
        /// </summary>
        private Dictionary<string, string> localizationData;

        /// <summary>
        ///     Locale Controller
        /// </summary>
        /// <param name="userService">user related service</param>
        /// <param name="plantService">Plant service</param>
        public LocaleController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Property for Localization Data
        /// </summary>
        public Dictionary<string, string> LocalizationData
        {
            get { return localizationData ?? (localizationData = FetchLocalizationData()); }
        }

        /// <summary>
        ///     Get Localization Data
        /// </summary>
        /// <returns>JSON Result</returns>
        //[OutputCache(Duration = 300)]
        public ActionResult GetLocalizationData(string locale = "")
        {
            Dictionary<string, string> data = GetData(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, locale);
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        ///     Gets Localization Data
        /// </summary>
        /// <param name="locale">Language type</param>
        /// <returns>Dictionary of Localization Data</returns>
        public Dictionary<string, string> FetchLocalizationData(string locale = "")
        {
            return GetData(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, locale);
        }

        /// <summary>
        ///     Get Localization Data
        /// </summary>
        /// <returns>JSON Result</returns>
        //[OutputCache(Duration = 300)]
        public ActionResult GetUomLocalizationData(string locale = "")
        {
            Dictionary<string, string> data = null;

            List<Locale> dataUom = UserService.GetResourceKeyValuesForUom(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, EcolabAccountNumber);

            if (dataUom != null)
            {
                data = dataUom.ToDictionary(e => e.Key, e => e.Value);
            }

            return this.Json(data, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Gets Localization Data
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <param name="locale">Language type</param>
        /// <returns>
        /// Dictionary of Localization Data
        /// </returns>
        private Dictionary<string, string> GetData(int userId, string locale = "")
        {
            List<Locale> data = null;
            if(string.IsNullOrEmpty(locale))
            {
                User user = GetCurrentUser();
                Plant plant = PlantService.GetPlantDetails(user.UserId, user.EcolabAccountNumber);
                List<LanguageMaster> languages = PlantService.GetLanguageDetails();
                List<LanguageMasterModel> objLanguages = Mapper.Map<List<LanguageMaster>, List<LanguageMasterModel>>(languages);
                LanguageMasterModel plantLanguage = objLanguages.Where(l => l.LanguageId == plant.LanguageId).FirstOrDefault();
                if(plantLanguage != null)
                {
                    data = UserService.GetResourcesByLocale(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId,plantLanguage.Locale, plant.EcoalabAccountNumber);
                }
            }
            else
            {
                data = UserService.GetResourcesByLocale(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId,locale, string.Empty);
            }

            if(data == null)
            {
                return null;
            }
            return data.ToDictionary(e => e.Key, e => e.Value);
        }

        /// <summary>
        ///     Get Localized value using the Key
        /// </summary>
        /// <param name="key">Localization Key</param>
        /// <param name="defaultValue">Return string if data is unavalilable for the Key</param>
        /// <returns>Localized value</returns>
        public string Localize(string key, string defaultValue)
        {
            return LocalizationData.ContainsKey(key) ? LocalizationData[key] : defaultValue;
        }

        /// <summary>
        /// Fetches the localization uom data.
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, string> FetchLocalizationUomData()
        {
            Dictionary<string, string> data = null;

            var dataUom = UserService.GetResourceKeyValuesForUom(GetCurrentUser() == null ? 0 : GetCurrentUser().UserId, EcolabAccountNumber);

            if (dataUom != null)
            {
                data = dataUom.ToDictionary(e => e.Key, e => e.Value);
            }
            return data.ToDictionary(e => e.Key, e => e.Value);
        }
    }
}