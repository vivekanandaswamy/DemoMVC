﻿// -----------------------------------------------------------------------
// <copyright file="ShiftLaborController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Shift Labor Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Shift Labor Controller
    /// </summary>
    public class ShiftLaborController : BaseController
    {
        /// <summary>
        ///     ShiftLaborController constructor
        /// </summary>
        /// <param name="userService">userService</param>
        /// <param name="plantService">plantService</param>
        public ShiftLaborController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Index
        /// </summary>
        /// <returns>Action Result</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return this.View();
        }
    }
}