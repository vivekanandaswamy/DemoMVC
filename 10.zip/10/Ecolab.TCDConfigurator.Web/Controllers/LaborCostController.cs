﻿// -----------------------------------------------------------------------
// <copyright file="LaborCostController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Labor Cost Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     class for LaborCostController
    /// </summary>
    public class LaborCostController : BaseController
    {
        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        public LaborCostController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        //
        // GET: /LaborCost/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}