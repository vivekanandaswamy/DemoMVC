﻿// -----------------------------------------------------------------------
// <copyright file="FormulaController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Formula Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    public class FormulaController : BaseController
    {
        public FormulaController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        //
        // GET: /Formula/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}