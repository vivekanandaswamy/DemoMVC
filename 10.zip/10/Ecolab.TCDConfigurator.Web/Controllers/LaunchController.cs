﻿// -----------------------------------------------------------------------
// <copyright file="LaunchController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Launch Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;

    /// <summary>
    ///     Class LaunchController
    /// </summary>
    public class LaunchController : Controller
    {
        //
        // GET: /Launch/

        public ActionResult Index()
        {
            return View();
        }
    }
}