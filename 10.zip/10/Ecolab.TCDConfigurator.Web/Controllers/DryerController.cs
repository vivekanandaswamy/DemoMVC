﻿// -----------------------------------------------------------------------
// <copyright file="DryerController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Dryer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class Dryer Controller
    /// </summary>
    public class DryerController : BaseController
    {
        public DryerController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        //
        // GET: /Dryer/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}