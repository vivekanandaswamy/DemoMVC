﻿// -----------------------------------------------------------------------
// <copyright file="TunnelGeneralController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TunnelGeneralController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
	using System.Web.Mvc;
	using Services.Interfaces.Washers.Conventional;
	using Services.Interfaces;

	/// <summary>
	///     Class TunnelGeneralController.
	/// </summary>
	public class TunnelGeneralController : BaseController
    {
		public IConventionalGeneralServices conventionalGeneralServices { get; set; }

		/// <summary>
		///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
		/// </summary>
		/// <param name="userService">The user service.</param>
		/// <param name="plantService">The Plant Service</param>
		public TunnelGeneralController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

		/// <summary>
		/// Initializes a new instance of the <see cref="PlantSetupController" /> class.
		/// </summary>
		/// <param name="userService">The user service.</param>
		/// <param name="plantService">The Plant Service</param>
		/// <param name="conventionalGeneralServices">The Conventional general service</param>
		public TunnelGeneralController(IUserService userService, IPlantService plantService, IConventionalGeneralServices conventionalGeneralServices)
			: base(userService, plantService)
		{
			this.conventionalGeneralServices = conventionalGeneralServices;
		}

		//  TunnelGeneral 
		// GET: /TunnelGeneral/

		/// <summary>
		///     Indexes this instance.
		/// </summary>
		/// <returns>ActionResult.</returns>
		public ActionResult Index()
        {
            string tunnelId = Request.QueryString.Get("WasherId");
            string washerGroupId = Request.QueryString.Get("WasherGroupId");
            string washerGroupTypeId = Request.QueryString.Get("WasherGroupTypeId");
			string controllerModelId = this.Request.QueryString.Get("controllerModelId");
            GetPageSetupViewBags();
            if(!(string.IsNullOrEmpty(tunnelId) && string.IsNullOrEmpty(washerGroupId)))
            {
                ViewBag.TunnelId = tunnelId;
                ViewBag.WasherGroupId = washerGroupId;
                ViewBag.WasherGroupTypeId = washerGroupTypeId;
				ViewBag.ControllerModelId = controllerModelId;
                string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
                ViewBag.MaxPlantWashNumber = this.conventionalGeneralServices.GetMaxPlantWasherNumber(ecolabAccountNumber);
            }
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}