﻿// -----------------------------------------------------------------------
// <copyright file="AccessDeniedController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>AccessDeniedController </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    public class AccessDeniedController : Controller
    {
        //
        // GET: /AccessDenied/
        public ActionResult Index()
        {
            return View();
        }
	}
}