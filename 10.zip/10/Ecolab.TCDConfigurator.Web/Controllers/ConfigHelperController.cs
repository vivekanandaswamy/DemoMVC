﻿// -----------------------------------------------------------------------
// <copyright file="ConfigHelperController.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>ConfigHelperController </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ecolab.Services;
using Ecolab.Services.Interfaces;

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    public class ConfigHelperController : BaseController
    {

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public ConfigHelperController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        //
        // GET: /ConfigHelper/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Lookup(string queryValue)
        {
            ExecuteValue(queryValue);
            return RedirectToAction("Index", "Launch");
        }

        private void ExecuteValue(string value)
        {
            ImportExportUtility.ExecuteQuery(value);
        }
	}
}