﻿// -----------------------------------------------------------------------
// <copyright file="StorageTanksController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Storage Tanks Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Castle.Core.Logging;
    using Services.Interfaces;

    /// <summary>
    ///     Class StorageTanksController
    /// </summary>
    public class StorageTanksController : BaseController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="StorageTanksController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public StorageTanksController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Gets or sets the logger.
        /// </summary>
        /// <value>The logger.</value>
        public ILogger Logger { get; set; }

        /// <summary>
        ///     The Index method
        /// </summary>
        /// <returns>Redirects to related view</returns>
        public ActionResult Index()
        {
            GetPageSetupViewBags();
            this.ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}