﻿// -----------------------------------------------------------------------
// <copyright file="UserManagement.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The User Management Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    /// Class for UserManagementController
    /// </summary>
    /// <seealso cref="Ecolab.TCDConfigurator.Web.Controllers.BaseController" />
    public class UserManagementController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserManagementController"/> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public UserManagementController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>Returns the ActionResult</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return this.View();
        }
    }
}