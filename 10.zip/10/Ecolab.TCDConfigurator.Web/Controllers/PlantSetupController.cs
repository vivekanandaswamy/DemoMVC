﻿// -----------------------------------------------------------------------
// <copyright file="PlantSetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Setup Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;
    using AutoMapper;
    using Ecolab.Models;
    using Ecolab.TCDConfigurator.Web.Helper;
    using Ecolab.TCDConfigurator.Web.Models.PlantSetup;
    using Services.Interfaces;

    /// <summary>
    ///     Class PlantSetupController
    /// </summary>
    public class PlantSetupController : BaseController
    {
		/// <summary>
		/// Gets or Sets the Plant Service object
		/// </summary>
		IPlantService plantService { get; set; }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public PlantSetupController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
			this.plantService = plantService;
        }

        /// <summary>
        ///     Get all the values related to Plant setup
        /// </summary>
        /// <returns>Returns the plant model</returns>
        public PlantModel Get()
        {
            User user = this.GetCurrentUser();
            List<CurrencyMaster> currencyCode = this.PlantService.GetCurrencyDetails();
            List<LanguageMaster> languages = this.PlantService.GetLanguageDetails();
            List<DimensionalUnitSystems> uoms = this.PlantService.GetDimensionalUnitSystems();

            PlantModel plantModel = new PlantModel();

            plantModel = Mapper.Map<Plant, PlantModel>(this.PlantService.GetPlantDetails(user.UserId, user.EcolabAccountNumber));
            plantModel.CurrencyCodes = currencyCode.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            plantModel.Languages = languages.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();
            plantModel.Uoms = uoms.Select(c => EntityConverter.ConvertToWebModel(c)).ToList();

            return plantModel;
        }

        //
        // GET: /PlantSetup/

        public ActionResult Index()
        {
            if (GetCurrentUser() == null)
            {
                return RedirectToAction("Index", "AccessDenied");
            }
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }

        /// <summary>
        /// Access Denied for Invalid User Log's In
        /// </summary>
        /// <returns></returns>
        public ActionResult AccessDenied()
        {
            return View("Launch/AccessDenied");
        }

		/// <summary>
		///  Fetches the Missing Fields
		/// </summary>
		/// <returns> The List of MissingFieldsModel</returns>
		[HttpPost]
		public ActionResult FetchMissingFields()
		{
			List<Models.MissingFieldsModel> missingFields = new List<Models.MissingFieldsModel>();
			missingFields = AutoMapper.Mapper.Map<List<Ecolab.Models.MissingFields>, List<Models.MissingFieldsModel>>(plantService.FetchMissingFields(this.EcolabAccountNumber));
			return this.PartialView("_MissingFields", missingFields);
		}
    }
}