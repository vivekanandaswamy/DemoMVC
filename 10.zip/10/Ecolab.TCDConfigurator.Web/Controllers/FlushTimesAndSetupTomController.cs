﻿// -----------------------------------------------------------------------
// <copyright file="FlushTimesAndSetupTomController.cs" company="Ecolab">
// This web controller is for compartments for tunnels.
// </copyright>
// <summary>This controller is for get or set the compartment controller.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Web.Mvc;
    using Ecolab.Models.Washers;
    using Ecolab.Models.Washers.Tunnel;
    using Services.Interfaces.Washers;
    using Models.Washers.Tunnel;
    using Services.Interfaces;
    using Services.Interfaces.Washers.Tunnel;

    public class FlushTimesAndSetupTomController : BaseController
    {
        /// <summary>
        ///     The Tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices mTunnelGeneralServices;

        /// <summary>
        ///  Interface for washer in service layer as IWasherServices
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="FlushTimesAndSetupTomController" /> class.
        /// </summary>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        /// <param name="tunnelGeneralServices">The Tunnel General Service</param>
        public FlushTimesAndSetupTomController(IUserService userService, IPlantService plantService, ITunnelGeneralServices tunnelGeneralServices, IWasherServices washerServices)
            : base(userService, plantService)
        {
            mTunnelGeneralServices = tunnelGeneralServices;
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     This action method is for loading the tunnel compartment view.
        /// </summary>
        /// <returns>Washer group formula view.</returns>
        public ActionResult Index()
        {
            string machineId = this.Request.QueryString.Get("machineId");
            string groupId = this.Request.QueryString.Get("groupId");
            string groupTypeId = this.Request.QueryString.Get("groupTypeId");
            string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
            System.Collections.Generic.IEnumerable<Washers> washerdtail = washerServices.GetWashersDetails(ecolabAccountNumber, int.Parse(groupId));
            int plantWasherNumber = 0;
            foreach (var washer in washerdtail)
            {
                if (washer.Id == int.Parse(machineId))
                    plantWasherNumber = washer.WasherNumber;
            }
            this.GetPageSetupViewBags();
            if (!string.IsNullOrWhiteSpace(machineId) && !string.IsNullOrWhiteSpace(groupId) && !string.IsNullOrWhiteSpace(groupTypeId))
            {
                TunnelGeneralModel tunnelData = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.mTunnelGeneralServices.GetTunnelData(Convert.ToInt32(machineId), Convert.ToInt32(groupId), this.EcolabAccountNumber));
                this.ViewBag.TunnelId = tunnelData.Id;
                this.ViewBag.WasherGroupId = tunnelData.WasherGroupId;
                this.ViewBag.WasherGroupTypeId = groupTypeId;
                this.ViewBag.ControllerId = tunnelData.ControllerId;
                this.ViewBag.Compartments = tunnelData.NoofCompartments;
                this.ViewBag.ControllerTypeId = tunnelData.ControllerTypeId;
                this.ViewBag.ControllerModelId = tunnelData.ControllerModelId;
                this.ViewBag.PlantWasherNumber = plantWasherNumber;
            }

            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}