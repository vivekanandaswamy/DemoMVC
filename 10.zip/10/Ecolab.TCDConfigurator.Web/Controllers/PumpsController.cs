﻿// -----------------------------------------------------------------------
// <copyright file="PumpsController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The PumpsController </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class PumpsController.
    /// </summary>
    public class PumpsController : BaseController
    {
        // GET: /Pumps/
        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public PumpsController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        /// <summary>
        ///     Indexes this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Index()
        {
            string controllerId = Request.QueryString.Get("ControllerId");
            string controllerModelId = Request.QueryString.Get("ControllerModelId");
            string controllerTypeId = Request.QueryString.Get("ControllerTypeId");
            if (!string.IsNullOrEmpty(controllerId))
            {
                ViewBag.ControllerId = controllerId;
                ViewBag.ControllerModelId = controllerModelId;
                ViewBag.ControllerTypeId = controllerTypeId;
            }
            else
            {
                ViewBag.ControllerId = "-1";
                ViewBag.ControllerModelId = "-1";
                ViewBag.ControllerTypeId = "-1";
            }
            ViewBag.IsCentral = "Yes";
            GetPageSetupViewBags();
            return View();
        }
    }
}