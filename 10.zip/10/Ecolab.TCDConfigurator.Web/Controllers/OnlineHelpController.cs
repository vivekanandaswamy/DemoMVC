﻿// -----------------------------------------------------------------------
// <copyright file="OnlineHelpController.cs" company="Ecolab">
// ©2016 Ecolab All rights reserved.
// </copyright>
// <summary>Online Help Controller</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using Ecolab.Services.Interfaces;

    /// <summary>
    /// Class for Online Help Controller
    /// </summary>
    /// <seealso cref="Ecolab.TCDConfigurator.Web.Controllers.BaseController" />
    public class OnlineHelpController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OnlineHelpController"/> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public OnlineHelpController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>Returns Action result</returns>
        public ActionResult Index()
        {
            this.GetPageSetupViewBags();
            this.ViewBag.IsCentral = "No";
            return this.PartialView("_OnlineHelp");
        }
    }
}