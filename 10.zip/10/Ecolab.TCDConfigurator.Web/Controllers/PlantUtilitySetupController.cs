﻿// -----------------------------------------------------------------------
// <copyright file="PlantUtilitySetupController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Plant Utility Setup Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using AutoMapper;
    using Ecolab.Models;
    using Ecolab.Models.PlantSetup;
    using Models.PlantSetup;
    using Services.Interfaces;
    using Services.Interfaces.PlantSetup;

    /// <summary>
    ///     Class PlantUtilitySetupController
    /// </summary>
    public class PlantUtilitySetupController : BaseController
    {
        /// <summary>
        ///     Plant Utility Service
        /// </summary>
        private readonly IPlantUtilityService utilityService;

        /// <summary>
        ///     plant Service
        /// </summary>
        protected readonly IPlantUtilityService PlantUtilityService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantUtilitySetupController" /> class.
        /// </summary>
        /// <param name="utilityService">The utility Service.</param>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public PlantUtilitySetupController(IPlantUtilityService utilityService, IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
            this.utilityService = utilityService;
        }

        //
        // GET: /PlantUtilitySetup/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
	        ViewBag.IsCentral = "Yes";
            return View();
        }

        /// <summary>
        ///     The plant Utility Setup save
        /// </summary>
        /// <param name="plantUtilitySetupModel">Save the plant  Utility Setup details</param>
        /// <returns>returns the action result</returns>
        [HttpPost]
        public ActionResult Save(PlantUtilitySetupModel plantUtilitySetupModel)
        {
            try
            {
                PlantUtilitySetup objPlantUtilitySetup = Mapper.Map<PlantUtilitySetupModel, PlantUtilitySetup>(plantUtilitySetupModel);
                User user = GetCurrentUser();
            }
            catch
            {
                //ErrorLog.GetDefault(null).Log(new Error(ex) { Message = ex.Message });
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            return Json(true, JsonRequestBehavior.AllowGet);
        }
    }
}