﻿// -----------------------------------------------------------------------
// <copyright file="RedFlagController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The RedFlag Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class RedFlagController
    /// </summary>
    public class RedFlagController : BaseController
    {
        /// <summary>
        /// </summary>
        /// <param name="userService"></param>
        /// <param name="plantService"></param>
        public RedFlagController(IUserService userService, IPlantService plantService) : base(userService, plantService)
        {
        }

        //
        // GET: /RedFlag/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}