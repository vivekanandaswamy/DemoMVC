﻿// -----------------------------------------------------------------------
// <copyright file="CustomerController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Customer Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class ContactController
    /// </summary>
    public class CustomerController : BaseController
    {
        /// <summary>
        ///     Plant Contact Service
        /// </summary>
        private readonly IPlantContactService plantContactService;

        /// <summary>
        ///     Parameterized constructor
        /// </summary>
        /// <param name="userService">User Service</param>
        /// <param name="plantService">Plant Service</param>
        /// <param name="plantContactService">Plant Contact Service</param>
        public CustomerController(IUserService userService, IPlantService plantService, IPlantContactService plantContactService) : base(userService, plantService)
        {
            this.plantContactService = plantContactService;
        }

        //
        // GET: /Customer/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}