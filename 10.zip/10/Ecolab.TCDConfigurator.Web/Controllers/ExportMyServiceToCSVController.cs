﻿// -----------------------------------------------------------------------
// <copyright file="ExportMyServiceToCSVController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The ExportMyServiceToCSV request handler </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System;
    using System.Collections.Generic;
	using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Web.Mvc;
    using Ecolab.Conduit.MyServiceSyncService.MyServiceAccess;
    using Ecolab.Services;
    using Ecolab.Services.Interfaces;
    using Entities.PlantSetup;

    /// <summary>
    ///     Class ExportMyServiceToCSVCController
    /// </summary>
    public class ExportMyServiceToCSVController : BaseController
    {

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public ExportMyServiceToCSVController(IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
        }

        //
        // GET: /Launch/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Export(string ecolabAccountNumber)
        {
            ImportExportUtility importExportUtility = new ImportExportUtility();
			string csvPath = ConfigurationManager.AppSettings["CsvGenerationPath"].ToString();
            importExportUtility.ExportMigrationData(ecolabAccountNumber, csvPath);
			importExportUtility.SaveIniFile(csvPath);

            return View("Index");
        }
    }
}