﻿// -----------------------------------------------------------------------
// <copyright file="BaseController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Base Controller Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System;
    using System.Configuration;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Net.Mail;
    using System.Threading;
    using System.Web.Mvc;
    using AutoMapper;
    using Entities;
    using Models.PlantSetup;
    using Services.Interfaces;
    using ServiceModel = Ecolab.Models;
    
    /// <summary>
    ///     Class BaseController
    /// </summary>
    public class BaseController : Controller
    {
        /// <summary>
        ///     plant Service
        /// </summary>
        protected readonly IPlantService PlantService;

        /// <summary>
        ///     User Service
        /// </summary>
        protected readonly IUserService UserService;

        /// <summary>
        ///     EcolabAccountNumber
        /// </summary>
        private string ecolabAccountNumber;

        /// <summary>
        ///     Initializes a new instance of the <see cref="PlantSetupController" /> class.
        /// </summary>
        /// <param name="userService">The user service.</param>
        /// <param name="plantService">The Plant Service</param>
        public BaseController(IUserService userService, IPlantService plantService)
        {
            UserService = userService;
            PlantService = plantService;
        }

        /// <summary>
        ///     Gets Ecolab Account Number
        /// </summary>
        protected string EcolabAccountNumber
        {
            get { return ecolabAccountNumber ?? (ecolabAccountNumber = GetPlantDetails().EcoalabAccountNumber); }
        }

        /// <summary>
        ///     Get Current User logged in
        /// </summary>
        /// <returns>The user details</returns>
        protected ServiceModel.User GetCurrentUser()
        {
            ServiceModel.User user = null;
            if (System.Web.HttpContext.Current.Session["Üser"] != null)
            {
                user = (ServiceModel.User)System.Web.HttpContext.Current.Session["Üser"];
            }
            else
            {
                string emailAddress = Request.QueryString["email"];
                string ecolabAccountNumber = Request.QueryString["plantId"];
                user = UserService.GetUserInformationByEmailandPlantId(emailAddress, ecolabAccountNumber);
                System.Web.HttpContext.Current.Session["Üser"] = user;
            }
            return user;
        }

        /// <summary>
        ///     Get Plant Details
        /// </summary>
        /// <returns>Plant Model Object</returns>
        protected PlantModel GetPlantDetails()
        {
            ServiceModel.Plant plantObj = PlantService.GetPlantDetails(GetCurrentUser().UserId, GetCurrentUser().EcolabAccountNumber);
            PlantModel plant = Mapper.Map<ServiceModel.Plant, PlantModel>(plantObj);
            return plant;
        }

        /// <summary>
        ///     Get Page Setup ViewBags
        /// </summary>
        protected void GetPageSetupViewBags()
        {
            //if (Request.IsAuthenticated)
            //{
             ServiceModel.User user = GetCurrentUser();
                PlantModel plantDetails = GetPlantDetails();
            int syncLapsTime =Convert.ToInt32(ConfigurationManager.AppSettings["SyncLapseTime"]);
            int syncHelath = PlantService.CheckPlantSynch(plantDetails.EcoalabAccountNumber, syncLapsTime);
                string roles = string.Join(",", user.Roles.Select(i => i.Code).ToArray());
            if(!string.IsNullOrEmpty(roles))
                {
                    List<MenuItem> menuItems = UserService.GetMenuSectionsByRoles(roles);
                    ViewBag.MenuItems = menuItems;
                    ViewBag.Roles = roles;
                    ViewBag.MaxLevel = user.Roles.Select(i => i.RoleId).Max();
                    ViewBag.RegionId = user.RegionId;
                    ViewBag.SyncHealth = syncHelath;
                    ViewBag.EcolabAccountNumber = !string.IsNullOrEmpty(Request.QueryString["plantId"])
                        ? Request.QueryString["plantId"]
                        : user.EcolabAccountNumber;
                    //ViewBag.PlantName = Request.QueryString["plantName"];
                    ViewBag.CountryName = user.CountryName;
                    ViewBag.RegionName = user.RegionName;
                    if (plantDetails != null)
                    {
                    ViewBag.AllowManualRewash = plantDetails.AllowManualRewash;
                    ViewBag.PlantName = plantDetails.Name;
                    ViewBag.PlantChainId = plantDetails.PlantChainId;
                    this.ViewBag.MaxNoOfRecordsPerPage = ConfigurationManager.AppSettings["MaxNoOfRecordsPerPage"];
                }
                }
            //}
        }

        /// <summary>
        /// Called before the action method is invoked.
        /// </summary>
        /// <param name="filterContext">Information about the current request and action.</param>
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (this.GetCurrentUser() != null)
            {
                ServiceModel.User user = this.GetCurrentUser();
                if (user.Locale != null)
                {
                    System.Globalization.CultureInfo[] cultures = System.Globalization.CultureInfo.GetCultures(System.Globalization.CultureTypes.AllCultures);
                    Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo(user.Locale);
                    Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(user.Locale);
                }
            }
        }
    }
}
