﻿// -----------------------------------------------------------------------
// <copyright file="TunnelCompartmentController.cs" company="Ecolab">
// This web controller is for compartments for tunnels.
// </copyright>
// <summary>This controller is for get or set the compartment controller.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Ecolab.Models.Washers;
    using Ecolab.Models.Washers.Tunnel;
    using Models.Washers.Tunnel;
    using Services.Interfaces;
    using Services.Interfaces.Washers;
    using Services.Interfaces.Washers.Tunnel;

    /// <summary>
    ///     Compartment controller class.
    /// </summary>
    public class TunnelCompartmentController : BaseController
    {
        /// <summary>
        ///     Interface for washer in service layer as IWasherServices
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     The _tunnel general services
        /// </summary>
        private readonly ITunnelGeneralServices tunnelGeneralServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="TunnelCompartmentController" /> class.
        /// </summary>
        /// <param name="washerServices">The interface for washer service.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="tunnelGeneralServices">The tunnel general services.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        public TunnelCompartmentController(IWasherServices washerServices, IUserService userService, ITunnelGeneralServices tunnelGeneralServices, IPlantService plantService) : base(userService, plantService)
        {
            this.washerServices = washerServices;
            this.tunnelGeneralServices = tunnelGeneralServices;
        }

        /// <summary>
        ///     This action method is for loading the tunnel compartment view.
        /// </summary>
        /// <returns>Washer group formula view.</returns>
        public ActionResult Index()
        {
            string tunnelId = Request.QueryString.Get("TunnelId");
            string washerGroupId = Request.QueryString.Get("WasherGroupId");
            string controllerId = Request.QueryString.Get("ControllerId");
            string compartments = Request.QueryString.Get("Compartments");
            string controllerTypeId = Request.QueryString.Get("ControllerTypeId");
            string controllerModelId = Request.QueryString.Get("ControllerModelId");

            int washerGroupTypeId = 2;
            string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
            System.Collections.Generic.IEnumerable<Washers> washerdetail = washerServices.GetWashersDetails(ecolabAccountNumber, int.Parse(washerGroupId));
            int plantWasherNumber = 0;
            foreach (var washer in washerdetail)
            {
                if (washer.Id == int.Parse(tunnelId))
                    plantWasherNumber = washer.WasherNumber;
            }
            TunnelGeneralModel tunneldata = AutoMapper.Mapper.Map<TunnelGeneral, TunnelGeneralModel>(this.tunnelGeneralServices.GetTunnelData(int.Parse(tunnelId), int.Parse(washerGroupId), ecolabAccountNumber));
            string washerName = tunneldata.Name;
            GetPageSetupViewBags();
            if (!(string.IsNullOrEmpty(tunnelId) && string.IsNullOrEmpty(controllerTypeId) && string.IsNullOrEmpty(washerGroupId) && string.IsNullOrEmpty(controllerId) && string.IsNullOrEmpty(compartments)))
            {
                ViewBag.TunnelId = tunnelId;
                ViewBag.WasherGroupId = washerGroupId;
                ViewBag.WasherGroupTypeId = washerGroupTypeId;
                ViewBag.ControllerId = controllerId;
                ViewBag.Compartments = compartments;
                ViewBag.ControllerTypeId = controllerTypeId;
                ViewBag.ControllerModelId = controllerModelId;
                this.ViewBag.PlantWasherNumber = plantWasherNumber;
                this.ViewBag.WasherName = washerName;
            }

            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}