﻿// -----------------------------------------------------------------------
// <copyright file="ChemicalController.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Chemical Controller </summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Services.Interfaces;

    /// <summary>
    ///     Class ChemicalController
    /// </summary>
    public class ChemicalController : BaseController
    {
        /// <summary>
        ///     production Master Service
        /// </summary>
        private readonly IProductMasterService prodMastService;

        /// <summary>
        ///     Initializes a new instance of the <see cref="HomeController" /> class.
        /// </summary>
        /// <param name="userService">The user Service</param>
        /// <param name="plantService">The plant service</param>
        /// <param name="prodMastService">The product Master Service</param>
        public ChemicalController(IUserService userService, IPlantService plantService, IProductMasterService prodMastService) : base(userService, plantService)
        {
            this.prodMastService = prodMastService;
        }

        //
        // GET: /Chemical/

        public ActionResult Index()
        {
            GetPageSetupViewBags();
            ViewBag.IsCentral = "Yes";
            return View();
        }
    }
}