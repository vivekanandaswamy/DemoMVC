﻿// -----------------------------------------------------------------------
// <copyright file="TunnelConnectionsController.cs" company="Ecolab">
// This web controller is for compartments for tunnels.
// </copyright>
// <summary>This controller is for get or set the compartment controller.</summary>
// -----------------------------------------------------------------------

namespace Ecolab.TCDConfigurator.Web.Controllers
{
    using System.Web.Mvc;
    using Ecolab.Models.Washers;
    using Services.Interfaces;
    using Services.Interfaces.Washers;

    /// <summary>
    ///     Compartment controller class.
    /// </summary>
    public class TunnelConnectionsController : BaseController
    {
        /// <summary>
        ///     Interface for washer in service layer as IWasherServices
        /// </summary>
        private readonly IWasherServices washerServices;

        /// <summary>
        ///     Initializes a new instance of the <see cref="TunnelCompartmentController" /> class.
        /// </summary>
        /// <param name="washerServices">The interface for washer service.</param>
        /// <param name="userService">The interface for UserService.</param>
        /// <param name="plantService">The interface for PlantService.</param>
        public TunnelConnectionsController(IWasherServices washerServices, IUserService userService, IPlantService plantService)
            : base(userService, plantService)
        {
            this.washerServices = washerServices;
        }

        /// <summary>
        ///     This action method is for loading the tunnel compartment view.
        /// </summary>
        /// <returns>Washer group formula view.</returns>
        public ActionResult Index()
        {
            string tunnelId = this.Request.QueryString.Get("TunnelId");
            string washerGroupId = this.Request.QueryString.Get("WasherGroupId");
            string controllerId = this.Request.QueryString.Get("ControllerId");
            string compartments = this.Request.QueryString.Get("Compartments");
            string controllerTypeId = this.Request.QueryString.Get("ControllerTypeId");
            string controllerModelId = this.Request.QueryString.Get("ControllerModelId");

            int washerGroupTypeId = 2;
            string ecolabAccountNumber = this.GetPlantDetails().EcoalabAccountNumber;
            System.Collections.Generic.IEnumerable<Washers> washerdtail = washerServices.GetWashersDetails(ecolabAccountNumber, int.Parse(washerGroupId));
            int plantWasherNumber = 0;
            foreach (var washer in washerdtail)
            {
                if (washer.Id == int.Parse(tunnelId))
                {
                    plantWasherNumber = washer.WasherNumber;
                    this.ViewBag.ControllerTypeId = washer.ControllerTypeId;
                    this.ViewBag.ControllerModelId = washer.ControllerModelId;
                }
            }
            this.GetPageSetupViewBags();
            if (!(string.IsNullOrEmpty(tunnelId) && string.IsNullOrEmpty(controllerTypeId) && string.IsNullOrEmpty(washerGroupId) && string.IsNullOrEmpty(controllerId) && string.IsNullOrEmpty(compartments)))
            {
                this.ViewBag.TunnelId = tunnelId;
                this.ViewBag.WasherGroupId = washerGroupId;
                this.ViewBag.WasherGroupTypeId = washerGroupTypeId;
                this.ViewBag.ControllerId = controllerId;
                this.ViewBag.Compartments = compartments;
                this.ViewBag.PlantWasherNumber = plantWasherNumber;
            }

            this.GetPageSetupViewBags();
            return this.View();
        }
    }
}