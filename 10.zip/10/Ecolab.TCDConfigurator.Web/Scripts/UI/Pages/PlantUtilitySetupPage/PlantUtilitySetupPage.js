Ecolab.Presenters.PlantUtilitySetupPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
var isshowsuccess = false;
Ecolab.Presenters.PlantUtilitySetupPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initPlantUtilitySetupView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onPlantUtilitySetupDataLoaded: function (data) { _this.onPlantUtilitySetupDataLoaded(data); },
            onSaved: function () { _this.onSaved(); },
            onSaveFailed: function (data, exception) { _this.onSaveFailed(data, exception); },
            onPlantUtilityDataSaved: function () { _this.onPlantUtilityDataSaved(); },
            onPlantUtilityDataSavedFailed: function (data, exception) { _this.onPlantUtilityDataSavedFailed(data, exception); },
            setEnergyContentData: function (data) { return _this.setEnergyContentData(data); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupView) {
            this.Views.PlantSetupView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function () { _this.onTabRendered(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); }
                }
            });
        }
        this.Views.PlantSetupView.setData(this.settings.accountInfo);
    },
    initPlantUtilitySetupView: function () {
        var _this = this;
        if (!this.Views.PlantUtilitySetupView) {
            this.Views.PlantUtilitySetupView = new Ecolab.Views.PlantUtilitySetup({
                containerSelector: '#tabUtilitiesSetupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onSavePage: function () { _this.savePage(); },
                    onCancelPage: function () { return _this.cancelPage(); },
                    getEnergyContent: function (gasTypeId) { return _this.getEnergyContent(gasTypeId); },
                    waterTypeConfirmation: function (message, previousVal, dropDownId) { return _this.waterTypeConfirmation(message,previousVal, dropDownId); },
                    waterTypeValidation: function (message) { _this.waterTypeValidation(message); }
                }
            });
        }

    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = "PlantSetup";
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabRendered: function () {
        this.loadPlantUtilitySetupData();
    },
    loadPlantUtilitySetupData: function () {
        this.Model.loadPlantUtilitySetupData();
    },
    onPlantUtilitySetupDataLoaded: function (data) {
        this.Views.PlantUtilitySetupView.setData(data);
        if (isshowsuccess) {
            this.onSaved();
        }
    },
    savePage: function (data) {
        var view = this.Views.PlantUtilitySetupView;
        if (view) {
            if (view.validate()) {
                var plantUtility = view.getData();
                if (plantUtility !== null) {
                    if (view.validateWaterTypes()) {
                    this.Model.savePlantutilityData(plantUtility);
                    this.isDirty = false;
                    }
                    else {
                        $("#successMsg").empty().removeAttr("class").addClass('errorutility').append("All free water types should be different.");
                        return false;
                    }
                } else {
                    $("#successMsg").empty();
                    return false;
                }
            }
            else {
                $("#successMsg").empty()
                return false;
            }
        }
    },
    onSaved: function () {
        $("#successMsg").empty().removeAttr("class").addClass('k-success-message').append($.GetLocaleKeyValue('FIELD_SAVEDSUCCESSFULLY', 'Saved successfully.'));
    },
    onSaveFailed: function (error) {
        this.Views.PlantUtilitySetupView.showErrorMessage(error);
        

    },
    onPlantUtilityDataSaved: function () {
        this.loadPlantUtilitySetupData();
        isshowsuccess = true;
        //show sucess message in view.
    },
    onPlantUtilityDataSavedFailed: function (data, exception) {
        if (exception == "60000") {
            this.onSaveFailed("<label data-localize = 'FIELD_RECORDSNOTINSYNCH' class='errorutility'>Record not in synch..Resynch is in progress.</label>");
        }
        else if (exception == "51030") {
            this.onSaveFailed("<label data-localize = 'FIELD_RECORDSCOUNTDOESNTMATCH' class='errorutility'>Record count does not match.</label>");
        }
        else if (exception == "51060") {
            this.onSaveFailed("<label data-localize = 'FIELD_CONECTIVITYISSUE' class='errorutility'>Unable to save changes , Connectivity issue, Please try again later.</label>");
        }
        else {
            this.onSaveFailed("<label class='errorutility'>Select different free WaterTypes.</label>");
        }
    },
    cancelPage: function () {
        return this.onBeforeNavigate();
    },
    getEnergyContent: function (gasTypeId) {
        return this.Model.getEnergyContent(gasTypeId)
    },
    setEnergyContentData: function (data) {
        this.Views.PlantUtilitySetupView.setEnergydata(data);
    },
    waterTypeConfirmation: function (message, previousVal, dropDownId) {
        if (message !== "") {
            var _this = this;
            var cDialog = $("#ConfirmDialog");
            cDialog.removeClass("hide");
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue("FIELD_CONFIRMATIONREQUIRED", "Confirmation Required"),
                BodyMessage: message, //$.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHERGROUP', 'Are you sure you want to delete this washer group?'),
                Buttons: {
                    Yes: {
                        Callback: function () {
                            cDialog.addClass("hide");
                            _this.savePage();
                        },
                        CallbackParameters: null
                    },
                    No: {
                        Callback: function () {
                            cDialog.addClass("hide");
                            _this.Views.PlantUtilitySetupView.setPreviousValue(previousVal, dropDownId);
                            return false;
                        },
                        CallbackParameters: null
                    }
                }
            };
            this.Views.confirmDialog.setData(dialogOptions);
        } else {
            // this.onSaveMetaDataInfoWithTags(isSaveAndClose);
            this.savePage(isSaveAndClose);
        }
    },
    waterTypeValidation: function (message) {
        if (message !== "") {
            var _this = this;
            var cDialog = $("#ConfirmDialog");
            cDialog.removeClass("hide");
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue("FIELD_CONFIRMATIONREQUIRED", "Confirmation Required"),
                BodyMessage: message, //$.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHERGROUP', 'Are you sure you want to delete this washer group?'),
                Buttons: {
                    Ok: {
                        Callback: function () {
                            cDialog.addClass("hide");
                            return false;
                        },
                        CallbackParameters: null
                    }
                }
            };
            this.Views.confirmDialog.setData(dialogOptions);
        } 
    }

};