﻿Ecolab.Presenters.HelpPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.isSaved = false; // is used to show the success message. This variable is added for Resync Error after save message.

};

Ecolab.Presenters.HelpPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.intNavigationMenu();
        this.intHelpNavigation();
        this.initHelpTemplate();

    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    intHelpNavigation: function () {
        var _this = this;
        if (!_this.Views.HelpNavigation) {
            var templateObject = _this.templateResolver(this.settings.accountInfo.Controller,
                                                        this.settings.accountInfo.Action,
                                                        this.settings.accountInfo.MaxLevel);
            _this.Views.HelpNavigation = new Ecolab.Views.HelpNavigation(
                             {
                                 containerSelector: '#hlpNavigationTemplate',
                                 templateDetails: templateObject,
                                 eventHandlers: {
                                     rendered: function () { _this.loadHelpNavigationData(); },
                                 }
                             });

            _this.Views.HelpNavigation.setNavigationData(this.settings.accountInfo);
        }
    },
    intNavigationMenu: function () {

        var navigationMenuLinks = { "Reports": "No", "Dashboard": "No", "ManualInputs": "No" };

        $.each(this.settings.accountInfo.MenuSections, function (key, data) {

            switch (data.ResourceKey) {

                case "MENUITEM_REPORTS":
                    navigationMenuLinks["Reports"] = "Yes";
                    break;
                case "MENUITEM_DASHBOARD":
                    navigationMenuLinks["Dashboard"] = "Yes";
                    break;
                case "MENITEM_MANUALINPUTS":
                    navigationMenuLinks["ManualInputs"] = "Yes";
                    break;
                default:
                    break;
            }

        })

        this.settings.accountInfo["HelpNavigationLinks"] = navigationMenuLinks;
    },
    initHelpTemplate: function () {
        var _this = this;
        var templateObject = _this.templateResolver(this.settings.accountInfo.Controller,
                                                    this.settings.accountInfo.Action,
                                                    this.settings.accountInfo.MaxLevel);
        _this.Views.HelpTemplate = new Ecolab.Views.HelpTemplate(
                        {
                            containerSelector: '#templateContainer',
                            templateDetails: templateObject,
                            eventHandlers: {
                                rendered: function () { _this.loadHelpData(); }
                            }
                        });

        _this.Views.HelpTemplate.setTemplateData(this.settings.accountInfo);
    },
    templateResolver: function (cntrl, act, maxLevel) {
        var helpTemplateName = '';
        var helpTemplateURl = '';
        var tagName = "";
        var hlpTemplatePath = "/Scripts/UI/Views/Help/HelpTemplates/";
        switch (cntrl) {

            case "Home":
                helpTemplateName = "Home";
                helpTemplateURl = hlpTemplatePath + "Home.html";
                tagName = "hlpHome";
                break;

            case "Dashboard":
                if (maxLevel >= 5) {
                    helpTemplateName = "Dashboard";
                    helpTemplateURl = hlpTemplatePath + "Dashboard.html";
                    tagName = "hlpDashboard";
                }
                break;

            case "Report":
                if (maxLevel > 2) {

                    var breadcrum = $("ol.breadcrumb li:nth-child(4)").text();
                    switch ($.trim(breadcrum)) {
                        case "Production Summary":
                            helpTemplateName = "RptProductionSummary";
                            helpTemplateURl = hlpTemplatePath + "RptProductionSummary.html";
                            tagName = "hlpRptProductionSummary";
                            break;
                        case "Production Details":
                            helpTemplateName = "RptProductionDetails";
                            helpTemplateURl = hlpTemplatePath + "RptProductionDetails.html";
                            tagName = "hlpRptProductionDetail";
                            break;
                        case "Alarms Summary":
                            helpTemplateName = "RptAlaramSummary";
                            helpTemplateURl = hlpTemplatePath + "RptAlaramSummary.html";
                            tagName = "hlpRptAlaramSummary";
                            break;
                        case "Alarms Details":
                            helpTemplateName = "RptAlaramDetail";
                            helpTemplateURl = hlpTemplatePath + "RptAlaramDetail.html";
                            tagName = "hlpRptAlaramDetail";
                            break;
                        case "Chemical Consumption":
                            helpTemplateName = "RptChemicalConsumption";
                            helpTemplateURl = hlpTemplatePath + "RptChemicalConsumption.html";
                            tagName = "hlpRptChemicalConsumption";
                            break;
                        case "Chemical Inventory":
                            helpTemplateName = "RptChemicalInventory";
                            helpTemplateURl = hlpTemplatePath + "RptChemicalInventory.html";
                            tagName = "hlpRptChemicalInventory";
                            break;
                        case "Operations Summary":
                            helpTemplateName = "RptOperationSummary";
                            helpTemplateURl = hlpTemplatePath + "RptOperationSummary.html";
                            tagName = "hlpRptOperationSummary";
                            break;
                        case "User log":
                            helpTemplateName = "RptUseLog";
                            helpTemplateURl = hlpTemplatePath + "RptUseLog.html";
                            tagName = "hlpRptUseLog";
                            break;
                        default:
                            helpTemplateName = "ReportsGeneral";
                            helpTemplateURl = hlpTemplatePath + "ReportsGeneral.html";
                            tagName = "ReportsAnchor";

                    }


                }
                break;

            case "ManualUtility":
                if (maxLevel > 2) {
                    helpTemplateName = "ManualInputUtility";
                    helpTemplateURl = "/Scripts/UI/Views/Help/HelpTemplates/ManualInputUtility.html";
                    tagName = "hlpManualInputUtility";
                }
                break;

            case "MIProduction":
                if (maxLevel > 2) {
                    helpTemplateName = "ManualInputProductionData";
                    helpTemplateURl = hlpTemplatePath + "ManualInputProductionData.html";
                    tagName = "hlpManualInputProductionData";
                }
                break;

            case "ManualBatch":
                if (maxLevel > 2) {
                    helpTemplateName = "ManualInputBatchData";
                    helpTemplateURl = hlpTemplatePath + "ManualInputBatchData.html";
                    tagName = "hlpManualInputBatchData";
                }
                break;

            case "ManualInputLabor":
                if (maxLevel > 2) {
                    helpTemplateName = "ManualInputLabour";
                    helpTemplateURl = hlpTemplatePath + "ManualInputLabour.html";
                    tagName = "hlpManualInputLabour";
                }
                break;

            case "ManualRewash":
                if (maxLevel > 2) {
                    helpTemplateName = "ManualInputRewash";
                    helpTemplateURl = hlpTemplatePath + "ManualInputRewash.html";
                    tagName = "hlpManualInputRewash";
                }
                break;

            case "PlantSetup":
                helpTemplateName = "HelpPlantSetupGeneral";
                helpTemplateURl = hlpTemplatePath + "HelpPlantSetupGeneral.html";
                tagName = "hlpGeneralSetup";
                break;

            case "Contact":
                if (maxLevel > 2) {
                    helpTemplateName = "Contacts";
                    helpTemplateURl = hlpTemplatePath + "Contacts.html";
                    tagName = "hlpGeneralContacts";
                }
                break;
            case "ShiftLabor":
                if (maxLevel >= 3) {
                    helpTemplateName = "Shift";
                    helpTemplateURl = hlpTemplatePath + "Shift.html";
                    tagName = "hlpGeneralShift";
                }
                break;
            case "TargetProduction":
                if (maxLevel >= 3) {
                    helpTemplateName = "TargetProduction";
                    helpTemplateURl = hlpTemplatePath + "TargetProduction.html";
                    tagName = "hlpGeneralTargetProduction";
                }
                break;
            case "LaborCost":
                if (maxLevel >= 3) {
                    helpTemplateName = "LaborCost";
                    helpTemplateURl = hlpTemplatePath + "LaborCost.html";
                    tagName = "hlpGeneralLabourCost";
                }
                break;

            case "Chemical":
                if (maxLevel >= 3) {
                    helpTemplateName = "Chemicals";
                    helpTemplateURl = hlpTemplatePath + "Chemicals.html";
                    tagName = "hlpChemicals";
                }
                break;

            case "Formula":
                if (maxLevel >= 3) {
                    helpTemplateName = "Formula";
                    helpTemplateURl = hlpTemplatePath + "FormulaList.html";
                    tagName = "hlpFormula";
                }
                break;

            case "Customer":
                if (maxLevel >= 3) {
                    helpTemplateName = "Customer";
                    helpTemplateURl = hlpTemplatePath + "Customer.html";
                    tagName = "hlpCustomer";
                }
                break;

            case "RedFlag":
                if (maxLevel >= 6 || maxLevel == 3) {
                    helpTemplateName = "RedFlag";
                    helpTemplateURl = hlpTemplatePath + "RedFlag.html";
                    tagName = "hlpRedFlag";
                }
                break;


            case "UserManagement":
                if (maxLevel >= 5) {
                    helpTemplateName = "UserManagement";
                    helpTemplateURl = hlpTemplatePath + "UserManagement.html";
                    tagName = "hlpUserManagement";
                }
                break;

                // utilityfactors

            case "Meter":
                helpTemplateName = "UtilityFactorsMeters";
                helpTemplateURl = hlpTemplatePath + "UtilityFactorsMeters.html";
                tagName = "hlpUtilityMeters";
                break;


            case "Sensor":
                helpTemplateName = "Sensors";
                helpTemplateURl = hlpTemplatePath + "Sensors.html";
                tagName = "hlpUtilitySensors";
                break;

            case "PlantUtilitySetup":
                helpTemplateName = "UtilityFactorsUtility";
                helpTemplateURl = hlpTemplatePath + "UtilityFactorsUtility.html";
                tagName = "hlpUtility";
                break;

            case "Utility":
                helpTemplateName = "UtilityWaterAndEnergy";
                helpTemplateURl = hlpTemplatePath + "UtilityWaterAndEnergy.html";
                tagName = "hlpUtilityWE";
                break;

                // Clean Side

            case "Dryer":
                if (maxLevel >= 5) {
                    helpTemplateName = "Dryer";
                    helpTemplateURl = hlpTemplatePath + "Dryer.html";
                    tagName = "hlpDryer";
                }
                break;

            case "Finnisher":
                if (maxLevel >= 5) {
                    helpTemplateName = "Finishers";
                    helpTemplateURl = hlpTemplatePath + "Finishers.html";
                    tagName = "hlpFinishers";
                }
                break;

            case "ControllerSetupList": case "ControllerSetup": case "TagManagement": case "Pumps": case "ControllerSetupAdvance":
                if (maxLevel >= 5) {
                    helpTemplateName = "DispenserSetup";
                    helpTemplateURl = hlpTemplatePath + "DispenserSetup.html";
                    tagName = "hlpDispenserSetup";
                }
                break;

                // Dashboard setup
            case "MonitorSetUp":
                if (maxLevel >= 5) {
                    helpTemplateName = "DashboardSetup";
                    helpTemplateURl = hlpTemplatePath + "DashboardSetup.html";
                    tagName = "hlpDashboardSetup";
                }
                break;

            case "StorageTanks":
                if (maxLevel >= 5) {
                    helpTemplateName = "StorageTanks";
                    helpTemplateURl = hlpTemplatePath + "StorageTanks.html";
                    tagName = "hlpStorageTanks";
                }
                break;
            case "WasherGroup": case "Washer": case "WasherGroupFormula": case "ConventionalGeneral": case "HoldCondition":
                if (maxLevel >= 5) {
                    helpTemplateName = "WasherGroups";
                    helpTemplateURl = hlpTemplatePath + "WasherGroups.html";
                    tagName = "hlpWasherGroups";
                }
                break;
            default:
                helpTemplateName = "Home";
                helpTemplateURl = hlpTemplatePath + "Home.html";
                tagName = "hlpHome";
                break;
        }

        if (helpTemplateName == "") {
            helpTemplateName = "Home";
            helpTemplateURl = hlpTemplatePath + "Home.html";
            tagName = "hlpHome";
        }
        return {
            template: helpTemplateName,
            url: helpTemplateURl,
            tagName: tagName
        };
    },

    loadHelpData: function () {

    },
    loadHelpNavigationData: function () {
    }
}


