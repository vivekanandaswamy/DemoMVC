Ecolab.Presenters.CustomerPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.CustomerPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onCustomerDataLoaded: function (data) { _this.onCustomerDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.Model.loadCustomerData();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.CustomerView) {
            this.Views.CustomerView = new Ecolab.Views.Customer(
                        {
                            containerSelector: '#tabCustomerContainer',
                            eventHandlers: {
                                onRendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onRuleClicked: function (id) { _this.navigateToConfigPage(id); },
                                savePage: function () { _this.savePage(); },
                                setIsDirty: function (flag) { _this.setIsDirty(flag); },
                                onSaveChangesCustomer: function (data, e, wnd, detailsTemplate, IsDelete) { return _this.SaveChangesForCustomer(data, e, wnd, detailsTemplate, IsDelete); },
                            }
                        });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup')
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadCustomerDataData: function () {

        this.Model.loadCustomerData(1);
    },
    onCustomerDataLoaded: function (data) {
        this.Views.CustomerView.setData(this.settings.accountInfo);
    },
    savePage: function () {
        this.Views.CustomerView.savePage();
    },
    setIsDirty: function (flag) {
        this.isDirty = false;
    },
    deletePage: function () {
        $('.k-delete').click();
    }
};