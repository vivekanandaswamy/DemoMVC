Ecolab.Presenters.StorageTanksPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.e = null;
    this.data = null;
    this.controllersandProducts = null;
    this.message = "";
};
Ecolab.Presenters.StorageTanksPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initStorageTanksTabsView();
        this.initStorageTanksView();
        this.initAddEditStorageTanksView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetStorageTanksDetailsReceived: function (data) { _this.onGetStorageTanksDetailsReceived(data); },
            onGetAddStorageTanksDataRecieved: function (data) { _this.onGetAddStorageTanksDataRecieved(data); },
            onGetEditStorageTanksDataRecieved: function (data) { _this.onGetEditStorageTanksDataRecieved(data); },
            onGetInlineEditStorageTanksDataRecieved: function (data) { _this.onGetInlineEditStorageTanksDataRecieved(data); },
            onGetInlineEditProductDataRecieved: function (data) { _this.onGetInlineEditStorageTanksDataRecieved(data); },
            onStorageTanksDeleted: function (data) { return _this.onStorageTanksDeleted(data); },
            onStorageTanksDeletionFailed: function (error, description) { return _this.onStorageTanksDeletionFailed(error, description); },
            onStorageTankCreated: function (data, isSaveAndClose) { _this.onStorageTankCreated(data, isSaveAndClose); },
            onStorageTankUpdated: function (data, isSaveAndClose) { _this.onStorageTankUpdated(data, isSaveAndClose); },
            onStorageTankUpdatedInline: function (data) { _this.onStorageTankUpdatedInline(data); },
            onStorageTankCreationFailed: function (error, description) { _this.onStorageTankCreationFailed(error, description); },
            onStorageTankUpdationFailed: function (error, description) { _this.onStorageTankUpdationFailed(error, description); },
            onStorageTankDeletionFailed: function (error, description) { _this.onStorageTankDeletionFailed(error, description); },
            onStorageTankInlineUpdationFailed: function (error, description) { _this.onStorageTankInlineUpdationFailed(error, description); },
            onValidateSuccess: function (data, isSaveAndClose) { _this.validateSuccess(data, isSaveAndClose); },
            onValidateFailed: function (error, description) { _this.validateFailed(error, description); },
            onGetStorageTanksOnControllerDataRecieved: function (data, controllerTypeId) { _this.onGetStorageTanksOnControllerDataRecieved(data, controllerTypeId); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.showStorageTanksBreadCrumb();
    },
    initStorageTanksTabsView: function () {

    },
    initStorageTanksView: function () {
        var _this = this;
        if (!this.Views.StorageTanksView) {
            this.Views.StorageTanksView = new Ecolab.Views.StorageTanks({
                containerSelector: '#tabContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRendered: function () { return _this.getStorageTanksDetails(); },
                    onAddEditStorageTanksClicked: function () { return _this.onAddEditStorageTanksClicked(); },
                    onDeleteStorageTanksClicked: function (id, lastmodifiedTimeStamp) { return _this.onDeleteStorageTanksClicked(id, lastmodifiedTimeStamp); },
                    onEditStorageTanksClicked: function (id) { return _this.onEditStorageTanksClicked(id); },
                    onGetInlineEditStorageTanksClicked: function (e, data) { return _this.onGetInlineEditStorageTanksClicked(e, data); },
                    onInlineEditStorageTanksClicked: function (storageTankData) { return _this.onInlineEditStorageTanksClicked(storageTankData); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); }
                }
            });
        }
        _this.getStorageTanksDetails();
    },
    initAddEditStorageTanksView: function () {
        var _this = this;
        if (!this.Views.AddEditStorageTanksView) {
            this.Views.AddEditStorageTanksView = new Ecolab.Views.AddEditStorageTanks({
                containerSelector: '#tabContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onrendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onStorageTankSaveClicked: function (storageTanksData, isSaveAndClose) { return _this.onStorageTankSaveClicked(storageTanksData, isSaveAndClose); },
                    onStorageTankUpdateClicked: function (storageTanksData, isSaveAndClose) { return _this.onStorageTankUpdateClicked(storageTanksData, isSaveAndClose); },
                    onBackButtonClick: function () { _this.onBackButtonClick(); },
                    onSavePage: function (isSaveAndClose) { _this.savePage(isSaveAndClose); },
                    onControllerChange: function (ecolabAccountNumber, controllerId, controllerTypeId) { _this.onStorageTankControllerChange(ecolabAccountNumber, controllerId, controllerTypeId); },
                }
            });
        }
    },

    showStorageTanksBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_STORAGE TANKS', 'Storage Tanks');
        breadCrumbData.url = "/StorageTanks";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onGeneralTabClicked: function () {
        this.loadControllerModelDataData();
    },
    onSetupTabClicked: function () {
    },
    navigateToConfigPage: function (id) {
    },
    getStorageTanksDetails: function () {
        this.Model.getStorageTanksDetails(this.settings.accountInfo.EcolabAccountNumber);
    },
    onGetStorageTanksDetailsReceived: function (data) {
        var _this = this;
        dr = {};
        dr.data = data;
        dr.message = this.message;
        this.settings.accountInfo.FileName = "StorageTanks";
        var tankId = _this.getQueryStringByName('tankId');
        if (tankId > 0) {
            _this.onEditStorageTanksClicked(tankId);
        } else
            this.Views.StorageTanksView.setData(dr);
    },
    onGetAddStorageTanksDataRecieved: function (data) {
        this.settings.accountInfo.FileName = "AddStorageTanks";
        this.Views.AddEditStorageTanksView.setData(data);
    },
    onGetEditStorageTanksDataRecieved: function (data) {
        var _this = this;
        this.settings.accountInfo.FileName = "AddStorageTanks";
        _this.findContainer('Storage Tanks', data[0].TankId);
        this.Views.AddEditStorageTanksView.setData(data);

    },
    onGetInlineEditStorageTanksDataRecieved: function (data) {
        this.controllersandProducts = data;
        this.Views.StorageTanksView.GetInlineControllerDetails(this.e, this.data, this.controllersandProducts);
    },

    onAddEditStorageTanksClicked: function () {
        this.Model.GetAddStorageTanks(this.settings.accountInfo.EcolabAccountNumber);
    },
    onStorageTankCreated: function (data, isSaveAndClose) {
        if (isSaveAndClose)
            window.location = "/StorageTanks";
        this.settings.accountInfo.TankId = data.TankId;
        this.message = '<label data-localize ="FIELD_STORAGETANKSCREATIONSUCCESSFULLY" class="k-success-message">Storage Tanks created successfully.</label>';
        this.loadNavigationMenuListView();
        this.Views.AddEditStorageTanksView.showMessage(this.message);
    },
    onStorageTankCreationFailed: function (storageTankData, description) {
        if (description == '60000') {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">Record not in synch..Resynch is in progress. </label>');
        }
        else if (description == '51030') {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">Record count does not match..Resynch is in progress. </label>');
        }
        else if (description == '51060') {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">Unable to save changes , Connectivity issue, Please try again later </label>');
        }
        else if (description == '303') {
            this.Views.AddEditStorageTanksView.showMessage($.GetLocaleKeyValue('FIELD_STORAGETANKSNAMEALREADYEXIST', 'Name already exists. Please use a different name.'));
        }
        else {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">' + this.buildErrorMessage(storageTankData, description, true) + '</label>');
        }

    },
    onStorageTankUpdated: function (data, isSaveAndClose) {
        if (isSaveAndClose)
            window.location = "/StorageTanks";
        this.message = '<label data-localize ="FIELD_STORAGETANKSUPDATEDSUCCESSFULLY" class="k-success-message">Storage Tanks updated successfully.</label>';
        this.Views.AddEditStorageTanksView.removeBorder();
        this.Views.AddEditStorageTanksView.showMessage(this.message);
        this.loadNavigationMenuListView();
    },
    onStorageTankUpdatedInline: function (data) {
        this.message = '<label data-localize ="FIELD_STORAGETANKSUPDATEDSUCCESSFULLY" class="k-success-message">Storage Tanks updated successfully.</label>';
        this.getStorageTanksDetails();
    },
    onStorageTankUpdationFailed: function (storageData, description) {
        //this.isValid = false;
        if (description.status == 300) {
            this.OverrideConformation(description);
        }
        else if (description == '60000') {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">Record not in synch..Resynch is in progress. </label>');
        }
        else if (description == '51030') {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">Record count does not match..Resynch is in progress. </label>');
        }
        else if (description == '51060') {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">Unable to save changes , Connectivity issue, Please try again later </label>');
        }
        else if (description == '303') {
            this.Views.AddEditStorageTanksView.showMessage($.GetLocaleKeyValue('FIELD_STORAGETANKSNAMEALREADYEXIST', 'Name already exists. Please use a different name.'));
        }
        else {
            this.Views.AddEditStorageTanksView.showMessage('<label class="k-error-message">' + this.buildErrorMessage(storageData, description, false) + '</label>');
        }
    },
    buildErrorMessage: function (storageData, description, isCreate) {
        //this.isValid = false;
        var message = '';
        if (jQuery.type(description) == "object") {
            message = $.GetLocaleKeyValue('FIELD_STORAGETANKSUPDATIONFAILED', 'Storage Tank updation failed.');
        } else {
            var error = description.split(',');
            var tagLocale = $.GetLocaleKeyValue('FIELD_TAG', 'Tag') + ' - ';
            if (parseInt(error[0]) == 303) {
                message = $.GetLocaleKeyValue('FIELD_STORAGETANKSNAMEALREADYEXIST', 'Name already exists. Please use a different name.');
            } else if (parseInt(error[0]) == 304) {
                message = $.GetLocaleKeyValue('FIELD_ASINGLEDISPENSERCANHAVEONLY8STORAGETANKS', 'Dispenser cannot have more than 8 Tanks.');
            }  else if (parseInt(error[0]) == 801 || parseInt(error[0]) == 802 || parseInt(error[0]) == 803 || parseInt(error[0]) == 909) {
                if (isCreate) {
                    message = '<span data-localize ="FIELD_STORAGETANKSCREATIONSUCCESSFULLY" class="k-success-message">Storage Tanks created successfully.</span>';
                }
                else {
                    message = '<span data-localize ="FIELD_STORAGETANKSUPDATEDSUCCESSFULLY" class="k-success-message">Storage Tanks updated successfully.</span>'
                }
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }

                    if (error[a] == 803) {
                        if (storageData.CurrentLevelTag) {
                            message = message + $.GetLocaleKeyValue('FIELD_CURRENTLEVEL', 'Current Level') + tagLocale + storageData.CurrentLevelTag;
                        }
                    } else if (error[a] == 802) {
                        if (storageData.LevelDeviationTag) {
                            message = message + $.GetLocaleKeyValue('FIELD_DEVIATION', 'Deviation') + tagLocale + storageData.LevelDeviationTag;
                        }
                    } else if (error[a] == 801) {
                        if (storageData.SizeTag) {
                            message = message + $.GetLocaleKeyValue('FIELD_SIZE', 'Size') + tagLocale + storageData.SizeTag;
                        }
                    }
                    else if (parseInt(error[0]) == 909) {
                        message =message+ $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.");
                    }
                }
                if (parseInt(error[0]) != 909) {
                    message = message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXIST', 'already exist');
                }
            } else if (parseInt(error[0]) == 804 || parseInt(error[0]) == 805 || parseInt(error[0]) == 806) {
                if (isCreate) {
                    message = '<span data-localize ="FIELD_STORAGETANKSCREATIONSUCCESSFULLY" class="k-success-message">Storage Tanks created successfully.</span>';
                }
                else {
                    message = '<span data-localize ="FIELD_STORAGETANKSUPDATEDSUCCESSFULLY" class="k-success-message">Storage Tanks updated successfully.</span>'
                }
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }

                    if (error[a] == 804) {
                        if (storageData.CurrentLevelTag) {
                            message = message + $.GetLocaleKeyValue('FIELD_CURRENTLEVEL', 'Current Level') + tagLocale + storageData.CurrentLevelTag;
                        }
                    } else if (error[a] == 805) {
                        if (storageData.LevelDeviationTag) {
                            message = message + $.GetLocaleKeyValue('FIELD_DEVIATION', 'Deviation') + tagLocale + storageData.LevelDeviationTag;
                        }
                    } else if (error[a] == 806) {
                        if (storageData.SizeTag) {
                            message = message + $.GetLocaleKeyValue('FIELD_SIZE', 'Size') + tagLocale + storageData.SizeTag;
                        }
                    }
                }
                message = message + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'is / are invalid');
            } else if (parseInt(error[0]) == 901 || parseInt(error[0]) == 902 || parseInt(error[0]) == 909) {
                if (isCreate) {
                    message = '<span data-localize ="FIELD_STORAGETANKSCREATIONSUCCESSFULLY" class="k-success-message">Storage Tanks created successfully.</span>';
                }
                else {
                    message = '<span data-localize ="FIELD_STORAGETANKSUPDATEDSUCCESSFULLY" class="k-success-message">Storage Tanks updated successfully.</span>'
                }
                if (parseInt(error[0]) == 909) {
                    message = message + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.");
                } else if (parseInt(error[0]) == 901) {
                    message = message + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.");
                } else if (parseInt(error[0]) == 902) {
                    message = message + $.GetLocaleKeyValue('FIELD_UNABLETOWRITEVALUESTOPLC', "Unable to write values to PLC.");
                }
            }
        }
        description = description.toString();
        if (description.indexOf('#') > 0) {
            var tankId = description.split('#')[1];
            if (tankId > 0) {
                this.settings.accountInfo.TankId = tankId;
            }
        }
        return message;
    },

    onStorageTankInlineUpdationFailed: function (storageData, description) {
        //this.isValid = false;
        if (description == '303') {
            this.message = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_STORAGETANKSNAMEALREADYEXIST', 'Name already exists. Please use a different name.') + '</label>';
        }
        else if (description == '60000') {
            this.message = '<label class="k-error-message">Record not in synch..Resynch is in progress. </label>';
        }
        else if (description == '51030') {
            this.message = '<label class="k-error-message">Record count does not match..Resynch is in progress. </label>';
        }
        else if (description == '51060') {
            this.message = '<label class="k-error-message">Unable to save changes , Connectivity issue, Please try again later </label>';
        }
        else {
            this.message = '<label class="k-error-message">' + this.buildErrorMessage(storageData, description, false) + '</label>';
        }
        
        this.getStorageTanksDetails();
    },
    onDeleteStorageTanksClicked: function (id, lastmodifiedTimeStamp) {
        this.DeleteConformation(id, lastmodifiedTimeStamp);
    },

    DeleteConformation: function (id, lastmodifiedTimeStamp) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODDELETETHISSTORAGETANK', 'Are you sure you want to delete this Storage Tank?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        dialog.addClass('hide');
                        var storageTankData = { TankId: id, EcolabAccountNumber: _this.settings.accountInfo.EcolabAccountNumber, LastModifiedTimeStamp: lastmodifiedTimeStamp };
                        _this.Model.DeleteStorageTanks(storageTankData);
                        return true;
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        dialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },


    onEditStorageTanksClicked: function (id) {
        this.Model.EditStorageTanks(id, this.settings.accountInfo.EcolabAccountNumber);
    },
    onGetInlineEditStorageTanksClicked: function (e, data) {
        this.e = e;
        this.data = data;
        var id = data.TankId;
        this.Model.InlineEditStorageTanks(id, this.settings.accountInfo.EcolabAccountNumber);

    },
    onInlineEditStorageTanksClicked: function (storageTankData) {
        this.Model.UpdateStorageTankInline(storageTankData);
    },
    onStorageTanksDeleted: function (data) {
        this.message = '<label data-localize ="FIELD_STORAGETANKSDELETEDSUCCESSFULLY" class="k-success-message">Storage tanks deleted successfully.</label>';
        this.loadNavigationMenuListView();
        this.getStorageTanksDetails();
    },
    onStorageTankDeletionFailed: function (dryerGroupData, description) {
        if (description == '60000') {
            this.message = '<label class="k-error-message">Record not in synch..Resynch is in progress. </label>';
        }
        else if (description == '51030') {
            this.message = '<label class="k-error-message">Record count does not match..Resynch is in progress. </label>';
        }
        else if (description == '51060') {
            this.message = '<label class="k-error-message">Unable to save changes , Connectivity issue, Please try again later </label>';
        }
        else {
            this.message = '<label data-localize ="FIELD_STORAGETANKDELETIONFAILED" class="k-error-message">Storage Tank deletion failed.</label>';
        }
        this.getStorageTanksDetails();
    },
    onStorageTankUpdateClicked: function (storageTankData, isSaveAndClose) {
        this.Model.UpdateStorageTank(storageTankData, isSaveAndClose);
    },
    onStorageTankSaveClicked: function (storageTankData, isSaveAndClose) {
        this.Model.createStorageTank(storageTankData, isSaveAndClose);
    },

    onStorageTankControllerChange: function (ecolabAccountNumber, controllerId, controllerTypeId) {
        this.Model.GetStorageTanksOnController(ecolabAccountNumber, controllerId, controllerTypeId);
    },

    onGetStorageTanksOnControllerDataRecieved: function (data, controllerTypeId) {
        this.Views.AddEditStorageTanksView.setTankDetailsOnControllerChange(data, controllerTypeId);
    },
    onBackButtonClick: function () {
        this.onStorageTanksClicked();
    },
    savePage: function (isSaveAndClose) {
        var fileName = this.settings.accountInfo.FileName;
        if (fileName == "AddStorageTanks") {
            var view = this.Views.AddEditStorageTanksView;
            if (view) {
                view.clearStatusMessage();
                if (view.validateStorageTanks()) {
                    var storageTanksData = view.getStorageTanksData();
                    if (this.HasDuplicateTags()) {
                        this.Views.AddEditStorageTanksView.showMessage('<label class="errorutility">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate Tags found.") + '</label>');
                       // this.isValid = false;
                        return false;

                    } else {
                        this.saveData(storageTanksData, isSaveAndClose);
                        this.isDirty = false;
                    }
                } else {
                    //this.isValid = false;
                    return false;
                }
            }
        } else if (fileName == "StorageTanks") {
            var view = this.Views.StorageTanksView;
            if (view) {
                if (view.validateStorageTank()) {
                    view.onTrSaveClicked();
                    this.isDirty = false;
                }
            }
        }
    },

    validateSuccess: function (data, isSaveAndClose) {
        var storageTankData = this.Views.AddEditStorageTanksView.getStorageTanksData();
        this.saveData(storageTankData, isSaveAndClose);
    },

    validateFailed: function (storagedata, description) {
        if (description.status == 300) {
            this.OverrideConformation(description);
        } else {
            this.onStorageTankUpdationFailed(storagedata, description);
        }
    },

    OverrideConformation: function (description) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_OVERRIDEPLCVALUES', 'Override PLC Values'),
            BodyMessage: description.Message,
            Buttons: {
                Yes: {
                    Callback: function () {
                        dialog.addClass('hide');
                        var storageTankData = _this.Views.AddEditStorageTanksView.getStorageTanksData();
                        storageTankData.PlcTags = description.PlcTags;
                        storageTankData.OverridePlcValues = true;
                        // _this.saveData(storageTankData);
                        _this.Model.WriteTagsToPLC(storageTankData, false);
                        return true;
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        dialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },

    saveData: function (storageTankData, isSaveAndClose) {
        if (storageTankData.TankId > 0 || this.settings.accountInfo.TankId) {
            if (this.onStorageTankUpdateClicked) {
                if (this.settings.accountInfo.TankId) {
                    storageTankData.TankId = this.settings.accountInfo.TankId
                }
                this.onStorageTankUpdateClicked(storageTankData, isSaveAndClose);
            }
        } else {
            if (this.onStorageTankSaveClicked) {
                this.onStorageTankSaveClicked(storageTankData, isSaveAndClose);
            }
        }
    },

    openCurrentNav: function (typeName, id) {
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + ']').parent('li');
        element.addClass('active');
    },
    findContainer: function (typeName, id) {
        var _this = this;
        //_this.loadNavigationMenuListView();
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return; //give up on loading the template
        setTimeout(function () { _this.openCurrentNav(typeName, id); }, 200);
        return;

    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
};