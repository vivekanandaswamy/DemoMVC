// JavaScript source code
Ecolab.Presenters.UserManagementPage = function (options) {
	this.settings = $.extend(this.defaults, options);
	this.userRoles = null;
};
Ecolab.Presenters.UserManagementPage.prototype = {
	initViews: function () {
		this.base.initViews.call(this);
		this.initPlantSetupTabsView();
		this.initListView();
		this.initAddEditUserManagementView();

		this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
		this.Views.confirmDialog.init();
	},
	initModel: function () {
		this.base.initModel.call(this);
		this.Model.init();
	},
	addModelOptions: function (modelOptions) {
		this.base.addModelOptions.call(this, modelOptions);
	},
	addModelEventHandlers: function (eventHandlers) {
		this.base.addModelEventHandlers.call(this, eventHandlers);
		$.extend(eventHandlers, this.getModelEventHandlers());
	},
	getModelEventHandlers: function () {
		var _this = this;
		return {
			onUserManagementDataLoaded: function (data) { _this.onUserManagementDataLoaded(data); },
			onUserManagementEditDataLoaded: function (data, isInline) { _this.onUserManagementEditDataLoaded(data, isInline); },
			onUserRolesLoaded: function (data) { _this.onUserRolesLoaded(data); },
			onUserManagementCreated: function (data) { _this.onUserManagementCreated(data) },
			onUserManagementCreationFailed: function (error, description) { _this.onUserManagementCreationFailed(error, description); },
			onUserManagementUpdated: function (data, isInline) { _this.onUserManagementUpdated(data, isInline) },
			onUserManagementUpdationFailed: function (error, description, isInline) { _this.onUserManagementUpdationFailed(error, description, isInline); },
			onUserManagementDeleted: function (data) { _this.onUserManagementDeleted(data) },
			onUserManagementDeletionFailed: function (error, description) { _this.onUserManagementDeletionFailed(error, description); }
		};
	},
	afterInit: function () {
		this.base.afterInit.call(this);
		this.showMainHeader();
		this.displayBreadCrumb();
	},
	initPlantSetupTabsView: function () {
		var _this = this;
		if (!this.Views.PlantSetupTabsView) {
			this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs({
				containerSelector: '#pageContainer',
				eventHandlers: {
					rendered: function () { _this.onTabsRendered(); },
					onRedirection: function (url) { return _this.RedirectLocation(url); },
					savePage: function () { return _this.savePage(true) }

				}
			});
		}
		this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
	},
	initListView: function () {
		var _this = this;
		if (!this.Views.UserManagementView) {
			this.Views.UserManagementView = new Ecolab.Views.UserManagement({
				containerSelector: '#divUserManagementContainer',
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					rendered: function () { _this.onUserManagementRendered(); },
					onAddUserManagementClicked: function () { _this.onAddUserManagementClicked(); },
					onEditUserManagementClicked: function (data) { _this.onEditUserManagementClicked(data); },
					onInlineEditUserManagementClicked: function (data, isInline) { _this.onUserManagementUpdateClicked(data, isInline); },
					onInlineEditUserManagementLinkClicked: function (e, data) { _this.onInlineEditUserManagementLinkClicked(e, data); },
					onDeleteUserManagementClicked: function (id) { _this.onDeleteUserManagementClicked(id); },
					onRedirection: function (url) { _this.RedirectLocation(url) }
				}
			});
		}
	},
	initAddEditUserManagementView: function () {
		var _this = this;
		if (!this.Views.AddEditUserManagementView) {
			this.Views.AddEditUserManagementView = new Ecolab.Views.AddEditUserManagement({
				containerSelector: '#addEditUserManagementPopupContainer',
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					rendered: function () { },
					onUserManagementSaveClicked: function (userManagementData) { _this.onUserManagementSaveClicked(userManagementData); },
					onUserManagementUpdateClicked: function (userManagementData, isInline) { _this.onUserManagementUpdateClicked(userManagementData, isInline); },
					onContactChange: function (request, callBack) { _this.loadContacts(request, callBack); },
				    onSaveChangesForUser: function (data, modalpop, select) { return _this.SaveChangesForUser(data, modalpop, select); }
				}
			});
		}
	},
	displayBreadCrumb: function () {
		var breadCrumbData = {};
		breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
		breadCrumbData.url = "/PlantSetup";
		this.showPlantBreadCrumb("plantSets", breadCrumbData);
	},
	onTabsRendered: function () {
		this.loadUserManagementData();
	},
	onUserManagementRendered: function () {
		if (!this.userRoles)
			this.loadUserRoles();
	},
	onAddUserManagementClicked: function () {
	    var data = this.Model.addNewUserManagement();
	    data.Roles = this.userRoles;
	    if ((this.settings.accountInfo.Roles == "TMA" || this.settings.accountInfo.Roles == "TRC") && this.settings.accountInfo.MaxLevel == 7) {
	        for (var i = data.Roles.length - 1; i >= 0; i--) {
	            if (data.Roles[i].RoleId === 4 || data.Roles[i].RoleId === 3 || data.Roles[i].RoleId === 5) {
	                data.Roles.splice(i, 1);
	            }
	        }
	    }
	    else if ((this.settings.accountInfo.Roles == "ENG" || this.settings.accountInfo.Roles == "TRE") && this.settings.accountInfo.MaxLevel == 8) {
	        for (var i = data.Roles.length - 1; i >= 0; i--) {
	            if (data.Roles[i].RoleId === 4) {
	                data.Roles.splice(i, 1);
	            }
	        }
	    }
		data.IsEdit = false;
		this.Views.AddEditUserManagementView.setData(data);
	},
	loadUserManagementData: function () {
		this.Model.loadUserManagementData();
	},
	loadUserRoles: function () {
		this.Model.loadUserRoles();
	},
	onUserManagementDataLoaded: function (data) {
		var drData = {};
		drData.allowEdit = (this.settings.accountInfo.MaxLevel >= 7);
		drData.data = data;
		this.Views.UserManagementView.setData(drData);
	},
	onUserRolesLoaded: function (userRoles) {
		var _this = this;
		this.userRoles = userRoles;
	},

	/////////////UserManagement////////////////
	//onAddUserManagementClicked: function (groupId, units) {
	//    var data = this.Model.addNewUserManagement(groupId, units, this.userRoles);
	//    this.Views.AddEditUserManagementView.setData(data);
	//},

	//Create UserManagement
	onUserManagementSaveClicked: function (userData) {
		this.Model.createUserManagement(userData);
	},
	onUserManagementCreated: function (userData) {
		$('#myModal').modal('hide');
		this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_USERCREATEDSUCCESSFULLY" class="k-success-message">User created successfully.</label>');
		this.loadUserManagementData();
	},
	onUserManagementCreationFailed: function (userManagementData, description) {
		if (description == 301) {
			this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERALREADYEXIST" class="k-error-message">User already exists. Please use a different User ID</label>');
		}
		else if (description == 302) {
			this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_CONTACTALREADYASSOCIATED" class="k-error-message">Contact already associated with a user. Please use a different Contact</label>');
		}
		else if (description == '51030') {
			this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">  Record count does not match..Resynch is in progress.</label>');
		}
		else if (description == '60000') {
			this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message"> Record not in synch..Resynch is in progress.</label>');
		}
		else if (description == '51060') {
		    this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message"> Unable to save changes , Connectivity issue, Please try again later.</label>');
		}
		else if (description == '501') {
		    this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_EMAILIDEXIST" class="k-error-message"> Email Id already exist.</label>');
		}
		else {
			this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERCREATIONFAILED" class="k-error-message">User creation failed.</label>');
		}
	},
	onInlineEditUserManagementLinkClicked: function (e, data) {
		this.Views.UserManagementView.showEditOnInlineEditLink(e, this.userRoles, data);
	},

	onEditUserManagementClicked: function (data) {
	    data.Roles = this.userRoles;
	    if ((this.settings.accountInfo.Roles == "TMA" || this.settings.accountInfo.Roles == "TRC") && this.settings.accountInfo.MaxLevel == 7) {
	        for (var i = data.Roles.length - 1; i >= 0; i--) {
	            if (data.Roles[i].RoleId === 4 || data.Roles[i].RoleId === 3 || data.Roles[i].RoleId === 5) {
	                data.Roles.splice(i, 1);
	            }
	        }
	    }
	    else if ((this.settings.accountInfo.Roles == "ENG" || this.settings.accountInfo.Roles == "TRE") && this.settings.accountInfo.MaxLevel == 8) {
	        for (var i = data.Roles.length - 1; i >= 0; i--) {
	            if (data.Roles[i].RoleId === 4) {
	                data.Roles.splice(i, 1);
	            }
	        }
	    }

		data.IsEdit = true;
		this.Views.AddEditUserManagementView.setData(data);
	},

	onUserManagementUpdateClicked: function (dryerData, isInline) {
		this.Model.updateUserManagement(dryerData, isInline);
	},
	savePage: function (isInline) {
		if (this.Views.UserManagementView) {
			if (this.Views.UserManagementView.validate()) {
				return this.Model.updateUserManagement(this.Views.UserManagementView.getUpdatedUserManagementEditableGridData(), isInline);
			} else
				return false;
		}
	},
	onUserManagementUpdated: function (dryerData) {
		$('#myModal').modal('hide');
		this.isDirty = false;
		this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_USERUPDATEDSUCCESSFULLY" class="k-success-message">User updated successfully.</label>');
		this.loadUserManagementData();
	},
	onUserManagementUpdationFailed: function (dryerData, description, isInline) {

		if (isInline) {
			var message = "";
			$.each(description, function (key, value) {
				if (key != "status") {
					message += "<b>" + $.GetLocaleKeyValue('FIELD_USERID', 'User Id') + ":" + key + " </b> "
					if (value == 301)
						message += $.GetLocaleKeyValue('FIELD_USERALREADYEXIST', 'User already exists. Please use a different User ID.') + "<br>";
					else if (value == 51030)
						message += $.GetLocaleKeyValue('FIELD_RECORDSCOUNTDOESNTMATCH', 'Record count does not match..Resynch is in progress.') + "<br>";
					else if (value == 60000)
						message += $.GetLocaleKeyValue('FIELD_RECORDSNOTINSYNCH', 'Record not in synch..Resynch is in progress.') + "<br>";
					else if (value == 302)
						message += $.GetLocaleKeyValue('FIELD_USERUPDATIONFAILED', 'No record exists.') + "<br>";
					else if (value == 501)
					    message += $.GetLocaleKeyValue('FIELD_EMAILIDEXIST', 'Email Id already exist.') + "<br>";
					else
						message += value + "<br>";
				}
			})
			if (message != '') {
				var Cdialog = $('#ConfirmDialog');
				Cdialog.removeClass('hide');
				var dialogOptions = {
					HeaderText: "Validation failed",
					BodyMessage: message,
					Buttons: {
						Ok: {
							Callback: function () {
								Cdialog.addClass('hide');
							},
							CallbackParameters: null
						}
					}

				};
				this.Views.confirmDialog.setData(dialogOptions);
				return false;
			}

		}
		else {
			var message = "";
			$.each(description, function (key, value) {
				if (key != "status") {
					message = value
				}
			})

			if (message == '301') {
				if (isInline)
					this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_USERALREADYEXIST" class="k-error-message">User already exists. Please use a different User ID.</label>');
				else
					this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERALREADYEXIST" class="k-error-message">User already exists. Please use a different User ID.</label>');
			}
		    else if (message == '501') {
			    if (isInline)
			        this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_EMAILIDEXIST" class="k-error-message">Email Id already exist.</label>');
			    else
			        this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_EMAILIDEXIST" class="k-error-message">Email Id already exist.</label>');
			}
			else if (message == '51030') {
				if (isInline) {
					this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">  Record count does not match..Resynch is in progress.</label>');
				} else {
					this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">  Record count does not match..Resynch is in progress.</label>');
				}
			}
			else if (message == '60000') {
				if (isInline) {
					this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message"> Record not in synch..Resynch is in progress.</label>');
				} else {
					this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERUPDATIONFAILED" class="k-error-message">User updation failed.</label>');
				}
			}
			else if (message == '51060') {
			    if (isInline) {
			        this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message"> Unable to save changes , Connectivity issue, Please try again later</label>');
			    } else {
			        this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message"> Unable to save changes , Connectivity issue, Please try again later</label>');
			    }
			}
			else if (message == '1') {
				if (isInline) {
					this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_USERUPDATIONFAILED" class="k-error-message">User updation failed.</label>');
				} else {
					this.Views.UserManagementView.showPopupErrorMessage('<label data-localize ="FIELD_USERUPDATIONFAILED" class="k-error-message">User updation failed.</label>');
				}
			}
			else if (message == '302') {
				this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_NORECORDEXIST" class="k-error-message">No record exists.</label>');
			}
			else {
				this.Views.UserManagementView.showErrorMessage('<label data-localize ="FIELD_USERUPDATIONFAILED" class="k-error-message">User updation failed.</label>');
			}
		}
	},

	//Delete UserManagement
	onDeleteUserManagementClicked: function (data) {
		var _this = this;
		var Cdialog = $('#ConfirmDialog');
		Cdialog.removeClass('hide');
		this.Views.confirmDialog.setData({
			HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
			BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISRECORD', 'Are you sure you want to delete this Record?'),
			Buttons: {
				Yes: {
					Callback: function () {
						Cdialog.addClass('hide');
						_this.Model.deleteUserManagement(data);
					}
				},

				No: {
					Callback: function () {
						Cdialog.addClass('hide');
					}
				}
			}
		});

	},
	onUserManagementDeleted: function () {
		this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_USERDELETEDSUCCESSFULLY" class="k-success-message">User deleted successfully.</label>');
		this.loadUserManagementData();
	},
	onUserManagementDeletionFailed: function (dryerData, description) {
		if (description == '51030') {
			this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
		} else if (description == '60000') {
			this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
		} else if (description == '51060') {
		    this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message"> Unable to save changes , Connectivity issue, Please try again later</label>');
		} else {
			this.Views.UserManagementView.showSucessMessage('<label data-localize ="FIELD_USERDELETIONFAILED" class="k-error-message">User deletion failed.</label>');
		}

	},
	loadContacts: function (request, callBack) {
		this.Model.loadContacts(request, callBack);
	}
}