Ecolab.Presenters.ControllerSetupAdvancePage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.maxInjectionClassCount = null;
};
Ecolab.Presenters.ControllerSetupAdvancePage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initControllerSetupTabsView();
        this.initControllerSetupView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetMetaDataReceived: function (data) { _this.onGetMetaDataReceived(data); },
            onGetMetaDataWithValuesReceived: function (data) { _this.onGetMetaDataWithValuesReceived(data); },
            onMetaDataSaved: function (data, isSaveAndClose) {
                _this.onMetaDataSaved(null, isSaveAndClose);
            },
            onMetaDataSavedFailed: function (data, exception) { _this.onMetaDataSavedFailed(data, exception); },
            onMetaTagDataSaved: function (data, isSaveAndClose) { _this.onMetaDataSaved(null, isSaveAndClose); },
            onMetaTagDataSavedFailed: function (data, exception) { _this.onMetaDataSavedFailed(data, exception); },
            onMaxInjectionClassCountRecieved: function(count) { _this.onMaxInjectionClassCountRecieved(count);}
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.showControllerBreadCrumb();
    },
    initControllerSetupTabsView: function () {
        var _this = this;
        if (!this.Views.ControllerSetupTabsView) {
            this.Views.ControllerSetupTabsView = new Ecolab.Views.ControllerSetupTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () { _this.loadMetaData(); },
                    advanceTabClicked: function () { _this.onAdvanceTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    setupTabClicked: function () { _this.onSetupTabClicked(); },
                    onBackButtonClick: function () { _this.onBackButtonClick(); }
                }
            });
        }
        if (this.settings.accountInfo.ControllerId != "-1") {
            var cData = {};
            cData.ControllerId = this.settings.accountInfo.ControllerId;
            cData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
            cData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
            this.Views.ControllerSetupTabsView.setController(cData);
            _this.findContainer('Controllers', cData.ControllerId);
        }
        this.Views.ControllerSetupTabsView.setData(this.settings.accountInfo);
    },
    initControllerSetupView: function () {
        var _this = this;
        if (!this.Views.ControllerSetupAdvanceView) {
            this.Views.ControllerSetupAdvanceView = new Ecolab.Views.ControllerSetupAdvance({
                containerSelector: '#tabAdvancedContainer',
                dynamicHTMLSelector: '#contentControllerParameters',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRendered: function () {},
                    onSaveMetaDataInfo: function (dataArr) { _this.onSaveMetaDataInfo(dataArr); },
                    onUpdateMetaDataInfo: function (dataArr) { _this.onUpdateMetaDataInfo(dataArr); },
                    onSavePage: function (message, isSaveAndClose) {return _this.confirmationPage(message, isSaveAndClose); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    dynamicRendered: function () { _this.GetMaxInjectionClassCount(); },
                    checkInjectionClassValidation: function (count) { return _this.checkInjectionClassValidation(count); }
                }
            });
        }

    },
    confirmationPage: function (message, isSaveAndClose) {
        if (message != "") {
            if (this.HasDuplicateTags()) {
                var view = this.Views.ControllerSetupAdvanceView;
                view.showMessage('<label class="errorutility">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</label>');
                return false;
            }
            var _this = this;
            var cDialog = $('#ConfirmDialog');
            cDialog.removeClass('hide');
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
                BodyMessage: message, //$.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISWASHERGROUP', 'Are you sure you want to delete this washer group?'),
                Buttons: {
                    Yes: {
                        Callback: function () {
                            cDialog.addClass('hide');
                            _this.savePage(isSaveAndClose);
                            _this.Views.ControllerSetupAdvanceView.cancelConfirmation(true);
                        },
                        CallbackParameters: null
                    },
                    No: {
                        Callback: function () {
                            cDialog.addClass('hide');
                            _this.Views.ControllerSetupAdvanceView.cancelConfirmation(false);
                            return false;
                        },
                        CallbackParameters: null
                    }
                }
            };
            this.Views.confirmDialog.setData(dialogOptions);
        } else {
          return  this.savePage(isSaveAndClose);
        }
    },

    savePage: function (isSaveAndClose) {
        var view = this.Views.ControllerSetupAdvanceView;
        if (view) {
            if (view.validate()) {
                if (this.HasDuplicateTags()) {
                    view.showMessage('<label class="errorutility">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found") + '</label>');
                    return false;
                } else {
                    var dataArr = view.getData();
                    if (this.onSaveMetaDataInfo) {
                        this.onSaveMetaDataInfo(dataArr, isSaveAndClose);
                    }
                    this.isDirty = false;
                }
            } else {
                return false;
            }
        }
    },
    showControllerBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_CONTROLLER SETUP', 'Controller Setup');
        breadCrumbData.url = "/ControllerSetupList";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onAdvanceTabClicked: function () {
        this.loadMetaData();
    },
    onSetupTabClicked: function () {
    },
    navigateToConfigPage: function (id) {
    },
    onBackButtonClick: function () {
        this.onControllerSetupClicked();
    },
    loadMetaData: function () {
        if (this.settings.accountInfo.ControllerId != "-1") {
            this.Model.getMetaData(3, this.settings.accountInfo.ControllerId);
        }
    },
    onSaveMetaDataInfo: function (dataArr, isSaveAndClose) {
        this.Model.saveMetaData(dataArr, isSaveAndClose);
    },
    onUpdateMetaDataInfo: function (dataArr) {
        this.Model.updateMetaData(dataArr);
    },
    onGetMetaDataReceived: function (data) {
        this.Views.ControllerSetupAdvanceView.setData(data);
        this.Views.ControllerSetupAdvanceView.setDynamicUI(data);
    },
    onGetMetaDataWithValuesReceived: function (data) {
        this.Views.ControllerSetupAdvanceView.setData(data);
        this.Views.ControllerSetupAdvanceView.setDynamicUI(data);
    },
    onMetaDataSaved: function (data, isSaveAndClose) {
        if (isSaveAndClose) {
            window.location = '/ControllerSetupList';
        }
        this.Views.ControllerSetupAdvanceView.onMetaDataSaved();
    },
    onMetaDataSavedFailed: function (data, exception) {
        if (exception.status === 300) {
            this.OverrideConformation(exception);
        }
        else {
            this.Views.ControllerSetupAdvanceView.onMetaDataSavedFailed(data, exception);
        }
    },
    openCurrentNav: function (typeName, id) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + ']').parent('li');
        element.addClass('open');
        element.children('ul').slideDown();
    },
    findContainer: function (typeName, id) {
        var _this = this;
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return; //give up on loading the template
        setTimeout(function () { _this.openCurrentNav(typeName, id); }, 200);
        return;

    },
    OverrideConformation: function (description) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_OVERRIDEPLCVALUES', 'Override PLC Values'),
            BodyMessage: description.Message,
            Buttons: {
                Yes: {
                    Callback: function () {
                        dialog.addClass('hide');
                        var view = _this.Views.ControllerSetupAdvanceView;
                        if (view) {
                            var dataArr = view.getData();
                            if (_this.onSaveMetaDataInfoWithTags) {
                                dataArr[0].PlcTagModelTags = description.PlcTags;
                                dataArr[0].OverridePlcValues = true;
                                _this.onSaveMetaDataInfoWithTags(dataArr);
                            }
                        }
                        return true;
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        dialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },
    onSaveMetaDataInfoWithTags: function (dataArr) {
        if (this.onSaveMetaDataInfo) {
            this.onSaveMetaDataInfo(dataArr);
        }
    },
    GetMaxInjectionClassCount: function () {
        this.Model.GetMaxInjectionClassCount(this.settings.accountInfo.ControllerId, this.settings.accountInfo.EcolabAccountNumber);
    },
    onMaxInjectionClassCountRecieved: function (count) {
        this.maxInjectionClassCount = count;
        if (this.maxInjectionClassCount > 0) {
            this.Views.ControllerSetupAdvanceView.DisableInjectionClass();
        }        
    },
    checkInjectionClassValidation: function (count) {
        if (count < this.maxInjectionClassCount) {
            return true;
        } else {
            return false;
        }        
    },
};