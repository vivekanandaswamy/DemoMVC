Ecolab.Presenters.ControllerSetupPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.ControllerId = null;
};
Ecolab.Presenters.ControllerSetupPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initControllerSetupTabsView();
        this.initControllerSetupView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onControllerModelDataLoaded: function (data) { _this.onControllerModelDataLoaded(data); },
            onControllerTypeDataLoaded: function (data) { _this.onControllerTypeDataLoaded(data); },
            onGetMetaDataReceived: function (data) { _this.onGetMetaDataReceived(data); },
            onGetMetaDataWithValuesReceived: function (data) { _this.onGetMetaDataWithValuesReceived(data); },
            onGetGeneralMetaDataWithValuesReceived: function (data) { _this.onGetGeneralMetaDataWithValuesReceived(data); },
            onMetaDataSaved: function (data, isSaveAndClose) { _this.onMetaDataSaved(data, isSaveAndClose); },
            onMetaDataSavedFailed: function (data, exception) { _this.onMetaDataSavedFailed(data, exception); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.showControllerBreadCrumb();
    },
    initControllerSetupTabsView: function () {
        var _this = this;
        if (!this.Views.ControllerSetupTabsView) {
            this.Views.ControllerSetupTabsView = new Ecolab.Views.ControllerSetupTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () { _this.loadControllerModelDataData(_this.settings.accountInfo.RegionId); },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    setupTabClicked: function () { _this.onSetupTabClicked(); },
                    onBackButtonClick: function () { _this.onBackButtonClick(); }
                }
            });
        }
        if (this.settings.accountInfo.ControllerId != "-1") {
            var cData = {};
            cData.ControllerId = this.settings.accountInfo.ControllerId;
            cData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
            cData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
            cData.isEdit = this.getQueryStringByName('ControllerModelId') ? true : false;
            this.Views.ControllerSetupTabsView.setController(cData);
            _this.findContainer('Controllers', cData.ControllerId)
        }
        this.Views.ControllerSetupTabsView.setData(this.settings.accountInfo);
    },
    initControllerSetupView: function () {
        var _this = this;
        if (!this.Views.ControllerSetupView) {
            this.Views.ControllerSetupView = new Ecolab.Views.ControllerSetup({
                containerSelector: '#tabGeneralContainer',
                dynamicHTMLSelector: '#contentControllerParameters',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onRendered: function () {
                    },
                    onControllerModelChange: function (id) { _this.onControllerModelChange(id); },
                    onControllerTypeChange: function (modelId, typeId) { _this.onControllerTypeChange(modelId, typeId); },
                    onSaveMetaDataInfo: function (dataArr) { _this.onSaveMetaDataInfo(dataArr); },
                    onUpdateMetaDataInfo: function (dataArr) { _this.onUpdateMetaDataInfo(dataArr); },
                    onSavePage: function (isSaveAndClose) { _this.savePage(isSaveAndClose); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    dynamicRendered: null
                }
            });
        }
    },
    savePage: function (isSaveAndClose) {
        var WebPortId = $('.webport').val();
        var filter = /^ftp:\/\/.*\/$/;
        var checkBox = $('.webportEnable').is(':checked');
        if (WebPortId != "" && checkBox) {
            if (!filter.test(WebPortId)) {
                $('.k-error-message-webport').text(" Webport IP format (ex:ftp://192.168.0.240/)");
                return false;
            }
            else {
                $('.k-error-message-webport').text("");
                var view = this.Views.ControllerSetupView;
                if (view) {
                    if (view.validate()) {
                        var dataArr = view.getData();
                        var mode = "Add";
                        if (this.settings.accountInfo.ControllerId != "-1") {
                            mode = "Update";
                        }
                        if (mode == "Add") {
                            if (this.onSaveMetaDataInfo) {
                                this.onSaveMetaDataInfo(dataArr, isSaveAndClose);
                            }
                        } else {
                            if (this.onUpdateMetaDataInfo) {
                                this.onUpdateMetaDataInfo(dataArr, isSaveAndClose);
                            }
                        }
                        this.isDirty = false;
                    } else {
                        return false;
                    }
                }
            }
        }
        else {
            $('.k-error-message-webport').text("");
            var view = this.Views.ControllerSetupView;
            if (view) {
                if (view.validate()) {
                    var dataArr = view.getData();
                    var mode = "Add";
                    if (this.settings.accountInfo.ControllerId != "-1") {
                        mode = "Update";
                    }
                    if (mode == "Add") {
                        if (this.onSaveMetaDataInfo) {
                            this.onSaveMetaDataInfo(dataArr, isSaveAndClose);
                        }
                    } else {
                        if (this.onUpdateMetaDataInfo) {
                            this.onUpdateMetaDataInfo(dataArr, isSaveAndClose);
                        }
                    }
                    this.isDirty = false;
                } else {
                    return false;
                }
            }
        }
    },
    showControllerBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_CONTROLLER SETUP', 'Controller Setup');
        breadCrumbData.url = "/ControllerSetupList";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onGeneralTabClicked: function () {
        this.loadControllerModelDataData();
    },
    onSetupTabClicked: function () {
    },
    navigateToConfigPage: function (id) {
    },
    onBackButtonClick: function () {
        this.onControllerSetupClicked();
    },
    loadControllerModelDataData: function (regionId) {
        this.Model.loadControllerModelData(regionId);
        if (this.settings.accountInfo.ControllerId != "-1") {
            this.Model.loadControllerTypeData(this.settings.accountInfo.ControllerModelId);
            this.Model.getMetaDataWithValues(this.settings.accountInfo.ControllerId, 1);
        }
    },
    loadControllerGeneralData: function (regionId) {
        //this.Model.loadControllerModelData(regionId);
        if (this.settings.accountInfo.ControllerId != "-1") {
            //this.Model.loadControllerTypeData(this.settings.accountInfo.ControllerModelId);
            this.Model.getGeneralMetaDataWithValues(this.settings.accountInfo.ControllerId, 1);
        }
    },
    onControllerModelDataLoaded: function (data) {
        this.Views.ControllerSetupView.setData(data);
    },
    onControllerTypeDataLoaded: function (data) {
        this.Views.ControllerSetupView.setControllerTypeData(data);
    },
    onControllerModelChange: function (controllerId) {
        this.Model.loadControllerTypeData(controllerId);
    },
    onControllerTypeChange: function (controllerModelId, controllerTypeId) {
        this.Model.getMetaData(controllerModelId, controllerTypeId, 1);
    },
    onSaveMetaDataInfo: function (dataArr, isSaveAndClose) {
        this.Model.saveMetaData(dataArr, isSaveAndClose);
    },
    onUpdateMetaDataInfo: function (dataArr, isSaveAndClose) {
        this.Model.updateMetaData(dataArr, isSaveAndClose);
    },
    onGetMetaDataReceived: function (data) {
        this.Views.ControllerSetupView.setDynamicUI(data);
    },
    onGetMetaDataWithValuesReceived: function (data) {
        this.Views.ControllerSetupView.setDynamicUI(data);
        //var _this = this;
        //if (_this.settings.accountInfo.ControllerId != '-1') {
        //    $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Dispenser updated successfully.'));
        //}
        //else {
        //    $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERSAVEDSUCCESSFULLY", 'Dispenser saved successfully.'));
        //}
    },    
    onGetGeneralMetaDataWithValuesReceived: function (data) {
        this.Views.ControllerSetupView.setDynamicUI(data);
        var _this = this;
        if (_this.settings.accountInfo.ControllerId != '-1') {
            $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Dispenser updated successfully.'));
        }
        else {
            $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERSAVEDSUCCESSFULLY", 'Dispenser saved successfully.'));
        }
    },
    onMetaDataSaved: function (data, isSaveAndClose) {
        this.Views.ControllerSetupView.onMetaDataSaved(data, this.Views.ControllerSetupTabsView, isSaveAndClose);
        this.loadControllerGeneralData();
    },
    onMetaDataSavedFailed: function (data, exception) {
        this.Views.ControllerSetupView.onMetaDataSavedFailed(data, this.Views.ControllerSetupTabsView, exception);
    },
    openCurrentNav: function (typeName, id) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + ']').parent('li');
        element.addClass('open');
        element.children('ul').slideDown();
    },
    findContainer: function (typeName, id) {
        var _this = this;
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return;//give up on loading the template
        setTimeout(function () { _this.openCurrentNav(typeName, id); }, 200);
        return;

    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
};