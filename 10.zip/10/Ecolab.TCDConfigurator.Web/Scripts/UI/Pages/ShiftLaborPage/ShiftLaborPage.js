﻿Ecolab.Presenters.ShiftLaborPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ShiftLaborPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
        this.initAddEditShiftView();
        this.initAddEditLaborView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
        this.messageVal = '';
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onShiftLaborDataLoaded: function (data) { _this.onShiftLaborDataLoaded(data); },
            onShiftCreated: function (data) { _this.onShiftCreated(data) },
            onShiftCreationFailed: function (error, description) { _this.onShiftAdditionFailed(error, description); },
            onShiftDeleted: function () { _this.onShiftDeleted() },
            onShiftDeletionFailed: function (error, description) { _this.onShiftDeletionFailed(error, description); },
            onLaborCreated: function (data, inline) {
                _this.onLaborCreated(data, inline)
            },
            onLaborCreateFailed: function (error, description, isInline) {
                _this.onAddLaborFailed(error, description, isInline);
            },
            onLaborDeleted: function (data) { _this.onLaborDeleted(data) },
            onLaborDeleteFailed: function (error, description) { _this.onDeleteLaborFailed(error, description); },
            onLaborUpdated: function (data) { _this.onLaborUpdated(data) },
            onLaborUpdateFailed: function (error, description) { _this.onEditLaborFailed(error, description); },
            onShiftToEditGet: function (data) { _this.onShiftToEditGet(data); },
            onShiftToEditGetFailed: function (error, description) { _this.onShiftToEditGetFailed(error, description); },
            onBreakDeleted: function () { _this.onBreakDeleted(); },
            onDeleteBreakFailed: function (error, description) { _this.ondeleteBreakFailed(error, description); },
            onAddLaborDataLoaded: function (laborModel) { _this.onAddLaborDataLoaded(laborModel) },
            onAddLaborDataLoadFailed: function (error, description) { _this.onAddLaborDataLoadFailed(error, description) },
            onLaborCostLoaded: function (cost) { _this.onLaborCostLoaded(cost); },
           
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
        //this.loadShiftLaborData();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function () { _this.loadShiftLaborData(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.ShiftLaborView) {
            this.Views.ShiftLaborView = new Ecolab.Views.ShiftLabor({
                containerSelector: '#divShiftLaborContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onAddShiftClicked: function (data) { _this.onAddShiftClicked(data); },
                    onDeleteShiftClicked: function (shiftId, dayId) { _this.onDeleteShiftClicked(shiftId, dayId); },
                    onEditShiftClicked: function (shiftId, dayId) { _this.onEditShiftClicked(shiftId, dayId); },
                    onDeleteBreakClicked: function (shiftId, dayId, breakId) { _this.onDeleteBreakClicked(shiftId, dayId, breakId); },
                    onAddLaborClicked: function (shiftId, dayId) { _this.onAddLaborClicked(shiftId, dayId); },
                    onDeleteLaborClicked: function (laborId) { _this.onDeleteLaborClicked(laborId); },
                    onEditLaborClicked: function (laborData) { _this.onEditLaborClicked(laborData); },
                    onEditLaborInlineClicked: function (laborData) { _this.onEditLaborInlineClicked(laborData); },
                    onCancelClicked: function (e) { _this.onCancelClicked(e); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    DeleteConformation: function (obj) { return _this.DeleteConformation(obj); },
                    DeleteConformationShift: function (shiftId, dayId) { return _this.DeleteConformationShift(shiftId, dayId); },
                }
            });
        }
    },
    initAddEditShiftView: function () {
        var _this = this;
        if (!this.Views.AddEditShift) {
            this.Views.AddEditShift = new Ecolab.Views.AddEditShift({
                containerSelector: '#addEditPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { _this.onAddEditShiftViewRendered(); },
                    onSaveClicked: function (shiftData) { _this.onSaveClicked(shiftData); },
                    onCancelClicked: function (e) { _this.onCancelClicked(e); },
                    onDeleteShiftBreak:function(breakObj){_this.EditDeleteConformationShiftBreak(breakObj);}
                }
            });
        }
    },
    initAddEditLaborView: function () {
        var _this = this;
        if (!this.Views.AddEditLabor) {
            this.Views.AddEditLabor = new Ecolab.Views.AddEditLabor({
                containerSelector: '#addEditPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { _this.onAddEditLaborViewRendered(); },
                    onLaborSaveClicked: function (laborData) { _this.onLaborSaveClicked(laborData); },
                    onCancelClicked: function (e) { _this.onCancelClicked(e); },
                    onLaborTypeChanged: function (id) { _this.onLaborTypeChanged(id); }
                }
            });
        }
    },

    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    loadShiftLaborData: function () {
        //this.showProgress();
        this.Model.loadShiftLaborData();
    },
    onShiftLaborDataLoaded: function (data) {
        //this.hideProgress();
        this.Views.ShiftLaborView.setData(data);
        this.Views.ShiftLaborView.showSucessMessage(this.messageVal);
        this.messageVal = '';
    },
    onAddShiftClicked: function () {
        var data = this.Model.addNewShift();
        this.Views.AddEditShift.setData(data);
    },
    onShiftCreated: function (data) {
        var message = '';
        if (data == "") {
            message = '<label data-localize ="FIELD_SHIFTUPDATEDSUCCESSFULLY" class="k-success-message">Shift updated successfully.</label>';
            this.loadShiftLaborData();
            this.onCancelClicked();
            this.messageVal = message;
            this.isDirty = false;
        }
        if (data.split('_')[0] == '201') {
            message = '<label data-localize ="FIELD_SHIFTUPDATEDSUCCESSFULLY" class="k-success-message">Shift updated successfully.</label>';
            this.loadShiftLaborData();
            this.onCancelClicked();
            this.messageVal = message;
            this.isDirty = false;
        }
        else if (data.split('_')[0] == '101') {
            message = '<label data-localize ="FIELD_SHIFTCREATEDSUCCESSFULLY" class="k-success-message">Shift created successfully.</label>';
            this.loadShiftLaborData();
            this.onCancelClicked();
            this.messageVal = message;
            this.isDirty = false;
        }
        else if (data.split('_')[0].indexOf('301') != -1) {
            message = '<span data-localize="FIELD_ALREADYEXISTS">Shift name overlapping with <strong></strong></span>';
        }
        
            $(data.split('#')).each(function (day, shift) {
                var code = shift.split('_')[1];
                if (code == 1) {
                    message += '<span data-localize="FIELD_SUNDAY">Sunday</span>';
                } if (code == 2) {
                    message += '<span data-localize="FIELD_MONDAY">Monday</span>';
                } if (code == 3) {
                    message += '<span data-localize="FIELD_TUESDAY">Tuesday</span>';
                } if (code == 4) {
                    message += '<span data-localize="FIELD_WEDNESDAY">Wednesday</span>';
                } if (code == 5) {
                    message += '<span data-localize="FIELD_THURSDAY">Thursday</span>';
                } if (code == 6) {
                    message += '<span data-localize="FIELD_FRIDAY">Friday</span>';
                } if (code == 7) {
                    message += '<span data-localize="FIELD_SATURDAY">Satruday</span>';
                }
                message = message + '  ';

            });
            this.messageVal = message;
            if (message.indexOf('Shift name') < 0) {
        if (message.indexOf('day') > 0) {
            this.Views.AddEditShift.showErrorMessage("Shift timings overlapping on <Strong>" + message + "</Strong>.");
        } else if (message.indexOf('Shift name overlapping') > 0) {
            this.Views.AddEditShift.showErrorMessage(message);
        }
        else {
            this.messageVal = message;
        }
            }
            else {
                this.Views.AddEditShift.showErrorMessage(message);
            }
        // this.onCancelClicked();
    },
    onShiftAdditionFailed: function (error, description) {
        this.onCancelClicked();
        if (description == '51030') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record Count not Match...Resynch is in progress.</label>');
            this.messageVal = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record Count not Match...Resynch is in progress.</label>';

        } else if (description == '60000') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            this.messageVal = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';

        } else if (description == '51060') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            this.messageVal = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>';

        } else if (description == 'Shift updation') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_SHIFTUPDATIONFAILED" class="k-error-message">Shift Updation Failed.</label>');
            this.messageVal = '<label data-localize ="FIELD_SHIFTUPDATIONFAILED" class="k-error-message">Shift Updation Failed.</label>';
        } else {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_SHIFTADDITIONFAILED" class="k-error-message">Shift addition failed.</label>');
            this.messageVal = '<label data-localize ="FIELD_SHIFTADDITIONFAILED" class="k-error-message">Shift addition failed</label>';
        }

    },
    onDeleteShiftClicked: function (shiftId, dayId) {
        this.Model.deleteShift(shiftId, dayId)
    },
    onShiftDeleted: function () {
        this.Views.ShiftLaborView.showSucessMessage('<label data-localize ="FIELD_SHIFTDELETEDSUCCESSFULLY" class="k-success-message">Shift deleted successfully.</label>');
        this.loadShiftLaborData();
        this.messageVal = '<label data-localize ="FIELD_SHIFTDELETEDSUCCESSFULLY" class="k-success-message">Shift deleted successfully.</label>';
    },
    onShiftDeletionFailed: function (error, description) {
        if (description == '51030') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record Count not Match...Resynch is in progress.</label>');
            this.messageVal = '<label data-localize ="" class="k-error-message">Record Count not Match...Resynch is in progress.</label>';

        } else if (description == '51060') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            this.messageVal = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>';

        } else if (description == '60000') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            this.messageVal = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';

        } else {
        this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_SHIFTDELETIONFAILED" class="k-error-message">Shift deletion failed.</label>');
        this.messageVal = '<label data-localize ="FIELD_SHIFTDELETIONFAILED" class="k-error-message">Shift deletion failed.</label>';
        }
    },

    //Function to get shift data based on the id clicked
    onEditShiftClicked: function (shiftId, dayId) {
        var shiftData = this.Model.GetShiftToEdit(shiftId, dayId);
    },

    //Set retured shift data from model to view
    onShiftToEditGet: function (shiftData) {

        this.Views.AddEditShift.setData(shiftData);
    },
    onShiftToEditGetFailed: function (error, description) {
        this.Views.ShiftLaborView.showErrorMessage(error, description);
    },
    //Event when delete break clicked
    onDeleteBreakClicked: function (shiftId, dayId, breakId) {
        this.DeleteConformationShiftBreak(shiftId, dayId, breakId)
    },
    onBreakDeleted: function () {
        this.loadShiftLaborData();
        this.Views.ShiftLaborView.showSucessMessage('<label data-localize ="FIELD_BREAKDELETEDSUCCESSFULLY" class="k-success-message">Break deleted successfully.</label>');
        this.messageVal = '<label data-localize ="FIELD_BREAKDELETEDSUCCESSFULLY" class="k-success-message">Break deleted successfully.</label>';
    },
    ondeleteBreakFailed: function (error, description) {
        if (description == '51030') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process..</label>');
            this.messageVal = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process..</label>';

        } else if (description == '51060') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            this.messageVal = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>';

        } else if (description == '60000') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            this.messageVal = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';

        } else {
        this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_BREAKDELETIONFAILED" class="k-error-message">Break deletion failed.</label>');
        this.messageVal = '<label data-localize ="FIELD_BREAKDELETIONFAILED" class="k-error-message">Break deletion failed.</label>';
        }
    },

    onDeleteLaborClicked: function (laborId) {
        this.Model.deleteLabor(laborId)
    },
    onLaborDeleted: function () {
        this.loadShiftLaborData();
        this.Views.ShiftLaborView.showSucessMessage('<label data-localize ="FIELD_LABORDELETEDSUCCESSFULLY" class="k-success-message">Labor deleted successfully.</label>');
        this.messageVal = '<label data-localize ="FIELD_LABORDELETEDSUCCESSFULLY" class="k-success-message">Labor deleted successfully.</label>';
    },
    onDeleteLaborFailed: function (error, description) {
        if (description == 51030) {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process.</label>');
            this.messageVal = '<label class="k-error-message">Record count Not match.. Resync in Process..</label>';
        }
        else if (description == 51060) {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            this.messageVal = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>';

        }
        else if (description == 60000) {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in Sync... Resync is in Progress</label>');
            this.messageVal = '<label class="k-error-message">Record not in Sync... Resync is in Progress</label>';
        }
        else {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_LABORDELETIONFAILED" class="k-error-message">Labor deletion failed.</label>');
            this.messageVal = '<label data-localize ="FIELD_LABORDELETIONFAILED" class="k-error-message">Labor deletion failed.</label>';
        }
        
    },
    onLaborUpdated: function () {
        //Add data to labor view
        // '<label data-localize ="FIELD_LABORUPDATEDSUCCESSFULLY" class="k-success-message">Labor updated successfully</label>'
    },
    onEditLaborFailed: function (error, description) {
        if (description == '51030') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process..</label>');
            this.messageVal = '<label data-localize ="" class="k-error-message">Record count Not match.. Resync in Process..</label>';

        } else if (description == '51060') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            this.messageVal = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>';

        } else if (description == '60000') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            this.messageVal = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';

        } else {

        this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_LABORUPDATIONFAILED" class="k-error-message">Labor updation failed.</label>');
        this.messageVal = '<label data-localize ="FIELD_LABORUPDATIONFAILED" class="k-error-message">Labor updation failed.</label>';
        }
    },
    onCancelClicked: function () {
        $('#myModal').modal('toggle');
    },
    onCancelLaborClicked: function () {
        $('#laborModal').modal('toggle');
    },
    onAddEditShiftViewRendered: function () {
    	$('#myModal').modal({
    		show: true,
    		backdrop: 'static',
    		keyboard: false
    	});
    },
    onSaveClicked: function (shiftData) {
        this.Model.createShift(shiftData);
    },
    onUpdateClicked: function (shiftData) {
        this.Model.updateShift(shiftData);
    },
    onAddLaborClicked: function (shiftId, dayId) {
        //call model and get ddls data
        var laborModel = {};
        laborModel = this.Model.addNewLabor(shiftId, dayId);
        this.Model.getLaborTypeAndLocation(laborModel);
    },
    onEditLaborClicked: function (dataFromRow) {
        //get data from table
        var laborModel = {
            labor:
                [{
                    ShiftId: dataFromRow.ShiftId,
                    LaborTypeId: dataFromRow.LaborTypeId,
                    LocationId: dataFromRow.LocationId,
                    DayId: dataFromRow.DayId,
                    LaborHours: dataFromRow.LaborHours,
                    PricePerHr: dataFromRow.PricePerHr,
                    LaborId: dataFromRow.LaborId,
                    LaborTypes: [],
                    Locations: []
                }]
        };
        this.Model.getLaborTypeAndLocation(laborModel);
    },
    onEditLaborInlineClicked: function (dataFromRow) {
        var inline = "istrue";
        this.Model.createLabor(dataFromRow, inline);
    },

    savePage: function () {
        var view = this.Views.ShiftLaborView;
        if (view) {
            if (view.validate()) {
                view.onSaveTrClicked();
                this.isDirty = false;
            }
        }
    },


    onAddLaborDataLoaded: function (data) {
        this.Views.AddEditLabor.setData(data);
    },
    onAddLaborDataLoadFailed: function (error, description) {
    },
    onAddEditLaborViewRendered: function () {
    	$('#laborModal').modal({
    		show: true,
    		backdrop: 'static',
    		keyboard: false
    	});
    },
    
    onLaborSaveClicked: function (laborData) {
        this.Model.createLabor(laborData, "isFalse");
    },
    onLaborCreated: function (data, inline) {
        var message = '';
        if (data == '201') {
            message = '<label data-localize ="FIELD_LABORUPDATEDSUCCESSFULLY" class="k-success-message">Labor updated successfully.</label>';
            this.messageVal = message;
        }
        else if (data == '101') {
            message = '<label data-localize ="FIELD_LABORCREATEDSUCCESSFULLY" class="k-success-message">Labor created successfully.</label>';
            this.messageVal = message;
        }
        if (inline == "isFalse") {
            this.onCancelLaborClicked();
        }
        this.loadShiftLaborData();
        this.Views.ShiftLaborView.showSucessMessage(message);

    },
    onAddLaborFailed: function (error, description, isInline) {
        
        

        if (description == "301") {
            if (isInline == 'istrue') {
                this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_LABORTYPEALREADYEXISTS" class="k-error-message">Labor type already exists for this location.</label>');
                this.messageVal = '<label data-localize ="FIELD_LABORTYPEALREADYEXISTS" class="k-error-message">Labor type already exists for this location.</label>';
            }
            else {
                this.Views.AddEditLabor.showErrorMessage(error, '<label data-localize ="FIELD_LABORTYPEALREADYEXISTS" class="k-error-message">Labor type already exists for this location.</label>');
                this.messageVal = '<label data-localize ="FIELD_LABORTYPEALREADYEXISTS" class="k-error-message">Labor type already exists for this location.</label>';
            }
           
        }
        else if (description == "51030") {
            if (isInline == 'istrue') {
                this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process..</label>');
            }
            else {
                this.Views.AddEditLabor.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process..</label>');
            }
            
            this.messageVal = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process.</label>';
            
        } 
        else if (description == "51060") {
            if (isInline == 'istrue') {
                this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            }
            else {
                this.Views.AddEditLabor.showErrorMessage(error, '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            }

            this.messageVal = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count Not match.. Resync in Process.</label>';

        }
        else if (description == "60000") {
            if (isInline == 'istrue') {
                this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            }
            else {
                this.Views.AddEditLabor.showErrorMessage(error, '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            }

            this.messageVal = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';

        }
        else {
            if (isInline == 'istrue') {
            this.Views.ShiftLaborView.showErrorMessage(error, '<label data-localize ="FIELD_LABORADDITIONFAILED" class="k-error-message">Labor addition failed.</label>');
            this.messageVal = '<label data-localize ="FIELD_LABORADDITIONFAILED" class="k-error-message">Labor addition failed.</label>';
        }
            else {
                this.Views.AddEditLabor.showErrorMessage(error, '<label data-localize ="FIELD_LABORUPDATIONFAILED" class="k-error-message">Labor addition failed.</label>');
                this.messageVal = '<label data-localize ="FIELD_LABORUPDATIONFAILED" class="k-error-message">Labor updation failed.</label>';
            }
        }
    },
    onLaborTypeChanged: function (id) {
        this.Model.loadLaborCost(id);
    },
    onLaborCostLoaded: function (cost) {
        this.Views.AddEditLabor.setCost(cost);
    },
    DeleteConformation: function (obj) {
        var _this = this;

        var returnVale = false;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYPUWANTTODELETETHISLABOR', 'Are you sure you want to delete this labor?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Views.ShiftLaborView.onConform(obj);
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        returnVale = false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return returnVale;
    },


    DeleteConformationShift: function (shiftId, dayId) {
        var _this = this;

        var returnVale = false;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYPUWANTTODELETETHISSHIFT', 'Are you sure you want to delete this shift?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Views.ShiftLaborView.onShiftDeletConform(shiftId, dayId);
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        returnVale = false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return returnVale;
    },

    DeleteConformationShiftBreak: function (shiftId, dayId, breakId) {
        var _this = this;

        var returnVale = false;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYPUWANTTODELETETHISBREAK', 'Are you sure you want to delete this break?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.isDirty = false;
                        _this.Model.deleteBreak(shiftId, dayId, breakId);
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        returnVale = false;
                        _this.isDirty = false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return returnVale;
    },

    EditDeleteConformationShiftBreak: function (breakObj) {
        var _this = this;

        var returnVale = false;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYPUWANTTODELETETHISBREAK', 'Are you sure you want to delete this break?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Views.AddEditShift.deleteShiftBreak(breakObj);
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        returnVale = false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return returnVale;
    },
};