Ecolab.Presenters.WasherGroupFormulaPage = function (options) {
	this.settings = $.extend(this.defaults, options);
	var washerGroupOutPutId = 0;
	var formulaId = 0;
	this.message = "";
	this.washerMessage = "";
	this.listMessage = "";
	this.url = window.location.href;
	this.isDirty = false;
	this.washerGroupTypeId = 0;
	this.washerGroupId = 0;
	this.programSetupId = 0;
	var dropDownChangeFromulaId = 0;
	var dropDownNewFormulaId = 0;
	this.addEditformulaData = null;
	this.importFormulaDetails;
	this.tunnelEdit = false;
    this.dropDownData = null;
    this.PlantChainIdByEcolabAccountNo = 0;
    this.washerGroupData = null;
};

Ecolab.Presenters.WasherGroupFormulaPage.prototype = {
	// initialising the base & view events.
	initViews: function () {
		this.base.initViews.call(this);
		this.initWasherGroupFormulaTabsView();
		this.initAddWasherGroupView();
		this.initFormulaView();
		this.initAddEditFormulaView();
		this.initAddWasherStepView();
		this.initTunnelWasherStepView();
		this.initTunnelWasherStepGridView();
		this.initTunnelGridProductListView();
		this.initImportFormulaView();
		this.initSubstituteChemicalView();
		//Convetional WashStep GridView
		//  this.initConventionalWasherStepGridView();
		this.initConventionalProducts();
		this.initConventionalAnalougeControl();
		this.initConventionalProductsGrid();

		//for confirmation box
		this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
		this.Views.confirmDialog.init();
	},

	// initialising the base & model events.
	initModel: function () {
		this.base.initModel.call(this);
		this.Model.init();
	},

	// Adding options to the model like pagesize and sort order etc.,
	addModelOptions: function (modelOptions) {
		this.base.addModelOptions.call(this, modelOptions);
	},

	// event is for adding the event handlers in the model to access them in presenter.
	addModelEventHandlers: function (eventHandlers) {
		this.base.addModelEventHandlers.call(this, eventHandlers);
		$.extend(eventHandlers, this.getModelEventHandlers());
	},

	// calling the callback events from model.
	getModelEventHandlers: function () {
		var _this = this;
		return {
			onWasherGroupDataLoad: function (washerGroupData) { _this.onWasherGroupDataLoad(washerGroupData); }, //Event is used for getting the data from the model.
			onFormulaDataLoad: function (washerGroupData) { _this.onFormulaDataLoad(washerGroupData); }, //Event is used for getting the data from the model.
			onWasherGroupCreated: function (washerGroupData, isSaveAndClose) { _this.onWasherGroupCreated(washerGroupData, isSaveAndClose); },
			onWasherGroupUpdated: function (washerGroupData, isSaveAndClose) { _this.onWasherGroupUpdated(washerGroupData, isSaveAndClose); },
			onWasherGroupCreationFailed: function (error, description) { _this.onWasherGroupCreationFailed(error, description); },
			onFormulaUpdationFailed: function (error, description) { _this.onFormulaUpdationFailed(error, description); },
			onWasherGrpUpdationFailed: function (error, description) { _this.onWasherGrpUpdationFailed(error, description); },
			onWasherGroupDeletionFailed: function (error, description) { _this.onWasherGroupDeletionFailed(error, description); }, //Event gets the error with error details.
			onGetAddFormulaDataRecieved: function (data) { _this.onGetAddFormulaDataRecieved(data); },
			onGetImportFormulaDataRecieved: function (data) { _this.onGetImportFormulaDataRecieved(data); },
			onGetEditFormulaDataRecieved: function (data) { _this.onGetEditFormulaDataRecieved(data); },
			onCopyFormulaCreated: function (formulaId) { _this.onCopyFormulaCreated(formulaId); },
			onFormulaCreationFailed: function (error, description) { _this.onFormulaCreationFailed(error, description); },
			onFormulaCreated: function (formulaId, formulaData, isSaveAndClose) { _this.onFormulaCreated(formulaId, formulaData, isSaveAndClose); },
			onCopyFormulaCreationFailed: function (error, description) { _this.onCopyFormulaCreationFailed(error, description); },
			onWasherGroupFormulaDeleted: function (washerGroupData, responseData) { _this.onWasherGroupFormulaDeleted(washerGroupData, responseData); },
			onWasherGroupWashStepDeleted: function (washerGroupData) { _this.onWasherGroupWashStepDeleted(washerGroupData); },
			onFormulaUpdated: function (data, formulaData, isSaveAndClose) { _this.onFormulaUpdated(data, formulaData, isSaveAndClose); },
			onInlineFormulaUpdated: function (data) { _this.onInlineFormulaUpdated(data); },
			onInlineFormulaUpdationFailed: function (error, description) { _this.onInlineFormulaUpdationFailed(error, description); },
			onWasherGroupFormulaDeletionFailed: function (error, description) { _this.onWasherGroupFormulaDeletionFailed(error, description); },
            onWasherFormulaSaveSuccess: function (data) { _this.onWasherFormulaSaveSuccess(data); },
            onWasherFormulaSaveFailed: function (error, description) { _this.onWasherFormulaSaveFailed(error, description); },
            onWasherFormulaUpdateSuccess: function (data) { _this.onWasherFormulaUpdateSuccess(data); },
            onWasherFormulaUpdateFailed: function (error, description) { _this.onWasherFormulaUpdateFailed(error, description); },
            onGetChainFormulaNames: function (data1) { _this.onGetChainFormulaNames(data1); },
            onGetChainFormulaNamesFialedDetails: function (data) { _this.onGetChainFormulaNamesFialedDetails(error, description); },
            onLoadDropDownDataLoaded: function (data) { _this.onLoadDropDownDataLoaded(data); },
            onGetPlantChainIdLoaded: function (data) { _this.onGetPlantChainIdLoaded(data); },
            onFormulaDataLoaded: function (data) { _this.onFormulaDataLoaded(data); },
            onGetChainFormulaData: function (data) { _this.onGetChainFormulaData(data); },
			//Wash Step Model events
			onWashStepDataLoad: function (washStepData) { _this.onWashStepDataLoad(washStepData); },
			onCopyWashStepDataLoad: function (washStepData) { _this.onCopyWashStepDataLoad(washStepData); },
			onWashStepCreationSuccess: function (washStepData, isSaveAndClose) { _this.onWashStepCreationSuccess(washStepData, isSaveAndClose); },
			onWashStepCreationFailed: function (errorData) { _this.onWashStepCreationFailed(errorData); },
			onTunnelWashStepCreationSuccess: function (washStepData, isSaveAndClose) { _this.onTunnelWashStepCreationSuccess(washStepData, isSaveAndClose); },
			onTunnelWashStepCreationFailed: function (errorData) { _this.onTunnelWashStepCreationFailed(errorData); },
			//Tunnel Wash Step call back methods
			onTunnelWashStepSetData: function (tunnelWasherData) { _this.onTunnelWashStepSetData(tunnelWasherData); },
			//onTunnelWashStepFailes: function (error, tunnelWashErrorData) { _this.onTunnelWashStepFailes(error,tunnelWashErrorData); }
			onTunnelGridViewSetData: function (tunnelGridViewData) { _this.onTunnelGridViewSetData(tunnelGridViewData); },
			onTunnelGridSuccess: function (responseData, isSaveAndClose) { _this.onTunnelGridSuccess(responseData, isSaveAndClose); },
			onTunnelGridFailed: function (responseData) { _this.onTunnelGridFailed(responseData); },
			onWasherDeleted: function (data) { _this.onWasherDeleted(data); },
			onWasherDeletionFailed: function (data) { _this.onWasherDeletionFailed(data); },

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			///             Covetional WashStep Product GridView functions                   ///
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			onProdutsDataRecieved: function (data) { _this.onConventionalProductGridView(data); },
			onProdcutsDataRecieveFailed: function (errorData) { _this.onConventionalProductGridViewFailed(errorData); },
			onproductsgridViewDataSuccess: function (data, isSaveandClose, formulaId) { _this.onproductsgridViewDataSuccess(data, isSaveandClose, formulaId); },
			onproductsgridViewDataFailed: function (errorData, formulaId) { _this.onproductsgridViewDataFailed(errorData, formulaId); },

			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			///             Covetional WashStep GridView functions                   ///
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			onWashStepgridViewDataSuccess: function (data, formulaId, isSaveandClose) { _this.onWashStepgridViewDataSuccess(data, formulaId, isSaveandClose); },
			onWashStepgridViewDataFailed: function (errorData) { _this.onWashStepgridViewDataFailed(errorData); },
			onProductGridViewRefreshDataRecieved: function (data) { _this.onProductGridViewRefreshDataRecieved(data); },
			onDropDownChangeFormulaUpdated: function (data, formulaData) { _this.onDropDownChangeFormulaUpdated(data, formulaData); },
			onChangeDropDownWashStepgridViewDataSuccess: function (data, formulaId) { _this.onChangeDropDownWashStepgridViewDataSuccess(data, formulaId); },
			onGetCompareFormulaData: function (data) { _this.onGetCompareFormulaData(data); },
			onGetCompareFormulaDataFailed: function (errorData) { },
			onGetDispenserAndFormulaChangeData: function (data) { _this.onGetDispenserAndFormulaChangeData(data); },
			onGetDispenserAndFormulaChangeDataFailed: function (errorData) { },
			onSaveSettingsSuccess: function (data) { _this.onSaveSettingsSuccess(data); },
            
            // Saving Formula Details to PLC
			onSaveFormulaDetailsToPLC: function (data) { _this.onSaveFormulaDetailsToPLC(data); },
			onSaveFormulaDetailsToPLCFailed: function (errorData, description) { _this.onSaveFormulaDetailsToPLCFailed(errorData, description); },
            onFindMissingChemicals: function (data) { _this.onFindMissingChemicals(data); },
            onGroupFormulaMoveupdated: function (data) { _this.onGroupFormulaMoveupdated(data); },
            onGroupFormulaMoveUpdationFailed: function (error, description) { _this.onGroupFormulaMoveUpdationFailed(error, description); }
		};
	},

	// for loading the events after initialising.
	afterInit: function () {
		this.base.afterInit.call(this);
		this.showMainHeader();
		this.showWasherGroupBreadCrumb();
        this.loadFormulaData();
        this.getPlantChainId();
		this.isDirty = false;

	},

	// initialising the washer group tabs view.
	initWasherGroupFormulaTabsView: function () {
		var _this = this;
		if (!this.Views.WasherGroupFormulaTabsView) {
			this.Views.WasherGroupFormulaTabsView = new Ecolab.Views.WasherGroupFormulaTabs({
				containerSelector: '#tabContainer', // Need to clarify the div id to be assign here
				eventHandlers: {
					rendered: function () { _this.onTabRendered(); },
					onFormulaTabClick: function () { _this.onFormulaTabClick(); },
					onWasherGroupClick: function () { _this.onWasherGroupClick(); },
					onBackButtonClick: function () { _this.onBackButtonClick(); },
					onDispenserAndFormulaChange: function (formulaId, controllerId, washerGroupId, washerId) { _this.onDispenserAndFormulaChange(formulaId, controllerId, washerGroupId, washerId); },
					onWashStepGridClicked: function (id) { _this.onEditFormulaClicked(id); },
					onConventionalWashStepGridViewClickFromCompareView: function (formulaId) { _this.onConventionalWashStepGridViewClickFromCompareView(formulaId); },
					onSendSettingsClicked: function (formulaId, controllerId, washerGroupId, washerId) { _this.onSendSettingsClicked(formulaId, controllerId, washerGroupId, washerId); },
				}
			});
		}

		this.Views.WasherGroupFormulaTabsView.setData(this.settings.accountInfo);
	},

	onConventionalWashStepGridViewClickFromCompareView: function (formulaId) {

	    this.onConventionalProductGridView(this.addEditformulaData, formulaId);
	},
	onWasherGroupClick: function () {
		var _this = this;
		var id = _this.getQueryStringByName('id');
		this.loadAddEditWasherGroupModelData(id);
	},

    onAddFormulaClicked: function (plantChainId) {
        if (plantChainId == undefined || plantChainId == '' || plantChainId == "" || plantChainId == null) {
            plantChainId = this.PlantChainIdByEcolabAccountNo;
        }
        this.Model.GetChainFormulaNames(plantChainId);
    },

	initAddWasherGroupView: function () {
		var _this = this;

		var id = _this.getQueryStringByName('id');
		if (!this.Views.AddWasherGroup) {
			this.Views.AddWasherGroup = new Ecolab.Views.AddWasherGroup({
				containerSelector: '#tabAddWasherGroupContainer', // Need to give the div id based on the html
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					onSavePage: function (isSaveAndClose) { _this.saveWasherGroupPage("WasherGroup", isSaveAndClose); },
					onAddNewWasher: function () { _this.onAddNewWasher(); },
					onWasherDeleteClicked: function (isTunnel, id) { return _this.onWasherDeleteClicked(isTunnel, id) },
					onRedirection: function (url) { return _this.RedirectLocation(url); },
				}
			});
		}
		//this.loadAddEditWasherGroupModelData(0);
	},
	initAddEditFormulaView: function () {
		var _this = this;
		if (!this.Views.AddEditFormulaView) {
			this.Views.AddEditFormulaView = new Ecolab.Views.AddFormula({
				containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					onrendered: function () { },
					onRedirection: function (url) { return _this.RedirectLocation(url); },
					onSavePage: function (isSaveAndClose) { _this.savePage("Formula", isSaveAndClose); },
					onFormulaSaveClicked: function (formulaData) { return _this.onFormulaSaveClicked(formulaData); },
					onWashStepClicked: function () { _this.onWashStepClicked(); },
					onWashStepDeleteClicked: function (id, programSetupId) { _this.onWashStepDeleteClicked(id, programSetupId); },
					onUpdateWashStepClicked: function (id) { _this.onUpdateWashStepClicked(id); },
					onCopyWashStepClicked: function (id) { _this.onCopyWashStepClicked(id); },
					onTunnelUpdateWashStepClicked: function (id) { _this.onTunnelUpdateWashStepClicked(id); },
					onFormulaTabClick: function () { _this.onFormulaTabClick(); },
					onFormulaBackButtonClick: function () { _this.onFormulaBackButtonClick(); },
					madeChangeFalse: function () { _this.madeChangeFalse(); },
					getConventionalProductsList: function (stepDetails, formulaName, chemicalList, nominalLoad, stepNumber, washOperation, washOperationId, referenceLoad, canAddInjections, injectionsAdded, maxInjectionsCount, controllerModelId, washersList)
					{ _this.getConventionalProductsList(stepDetails, formulaName, chemicalList, nominalLoad, stepNumber, washOperation, washOperationId, referenceLoad, canAddInjections, injectionsAdded, maxInjectionsCount, controllerModelId, washersList); },
					onSaveWashSteps: function () { _this.onSaveWashSteps(); },
					onConventionalWashStepGridViewClick: function (data, formulaId) { _this.onConventionalProductGridView(data, formulaId); },
					onCompareFormulaViewClicked: function (washerGroupId, formulaid) { _this.onCompareFormulaViewClicked(washerGroupId, formulaid); },
                    onAddFormulaClicked: function (plantChainId) { _this.onAddFormulaClicked(plantChainId); },
                    getChainFormulaData: function (plantProgramId) { _this.getChainFormulaData(plantProgramId); },
                    onWasherFormulaPopupSavePage: function () { return _this.WasherFormulaPopupSavePage(false); },
					
					onCancelClicked: function () { _this.onFormulaTabClick(); },
					onFourmulaNumberChanged: function (formulaId, newformulaId) { _this.onFourmulaNumberChanged(formulaId, newformulaId); },

					getConventionalAnalouge: function (stepDetails, formulaName, chemicalList, nominalLoad, stepNumber, washOperation, washOperationId, referenceLoad, canAddInjections, injectionsAdded, maxInjectionsCount, controllerModelId, washersList)
					{ _this.getConventionalAnalouge(stepDetails, formulaName, chemicalList, nominalLoad, stepNumber, washOperation, washOperationId, referenceLoad, canAddInjections, injectionsAdded, maxInjectionsCount, controllerModelId, washersList); },
				}
			});
		}
	},
	initFormulaView: function () {
		var _this = this;
		var id = _this.getQueryStringByName('id');
		if (!this.Views.WasherGroupFormulasListView) {
			this.Views.WasherGroupFormulasListView = new Ecolab.Views.WasherGroupFormulasList({
				containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					onAddEditFormulaClicked: function (nextAvailableFormulaNo) { return _this.onAddEditFormulaClicked(nextAvailableFormulaNo); },
					onRedirection: function (url) { return _this.RedirectLocation(url); },
					onDeleteFormulaListClicked: function (Id, washergrouptypename, lastModifiedTime) { _this.onDeleteFormulaListClicked(Id, washergrouptypename, lastModifiedTime); },
					onEditFormulaClicked: function (id) { return _this.onEditFormulaClicked(id); },
					onFormulaInlineUpdateClicked: function (formulaData) { return _this.onFormulaInlineUpdateClicked(formulaData); },
					onClearProductsCache: function () { return _this.onClearProductsCache(); },
					onImportFormulaClicked: function (nextAvailableFormulaNo) { return _this.onImportFormulaClicked(nextAvailableFormulaNo); },
					onSaveFormulaDetailsClicked: function (washerGroupId) { return _this.onSaveFormulaDetailsClicked(id); },
                    onUseFormulaFromGroupChkboxClicked: function (washergroupId, UseGroup1Formulas) { _this.onUseFormulaFromGroupChkboxClicked(washergroupId, UseGroup1Formulas); },
				}
			});
		}
		this.loadAddEditWasherGroupModelData(id);
	},

	onTabRendered: function () {
		var _this = this;
		var id = _this.getQueryStringByName('id');
		var formulaId = _this.getQueryStringByName('formulaId');
		var type = _this.getQueryStringByName('type');
		var redirectionType = _this.getQueryStringByName('data');
		var path = this.settings.accountInfo.Path;
		var washerId = this.settings.accountInfo.washerId;
		if (washerId == null && this.settings.accountInfo.TunnelId != null) {
			washerId = this.settings.accountInfo.TunnelId; // for passing the tunnelId if the group type is tunnel.
		}

		var MaxLevel = this.settings.accountInfo.MaxLevel;
		if (MaxLevel >= 6) {
			if (formulaId > 0) {
				_this.onEditFormulaClicked(formulaId);
				_this.findContainer('Formula', formulaId, id, 'Formulas');
			} else {
				if (redirectionType) {
					if (this.settings.accountInfo.WasherGroupId != undefined && id == 0)
						id = this.settings.accountInfo.WasherGroupId;
					_this.findContainer('Washer Groups', id, 0, 'WasherGroupWashers');
					this.loadAddEditWasherGroupModelData(id);
				} else if (path != null && washerId != null) {
					this.settings.accountInfo.WasherGroupId = id;
					this.onFormulaTabClick();
				}
				else {
					if (this.settings.accountInfo.WasherGroupId != undefined && id == 0)
						id = this.settings.accountInfo.WasherGroupId;
					_this.findContainer('Washer Groups', id, 0, 'WasherGroupWashers');
					this.loadAddEditWasherGroupModelData(id);
				}
				if (type == "Formulas") {
					this.settings.accountInfo.WasherGroupId = id;
					this.onFormulaTabClick();
				}
			}
		} else {
			_this.onFormulaTabClick();
		}
	},
	showWasherGroupBreadCrumb: function () {
		var breadCrumbData = {};
		breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHER GROUPS', 'Washer Groups');
		breadCrumbData.url = "/WasherGroup";
		this.showPlantBreadCrumb("plantSets", breadCrumbData);
	},
	onBackButtonClick: function () {
		this.onWasherGroupClicked();
	},
	loadAddEditWasherGroupModelData: function (washerGroupId) {
		var dir = this.isDirty;
		if (!dir) {
			var id = this.settings.accountInfo.WasherGroupId;
			if (id != undefined && id > 0)
				washerGroupId = id;
			this.washerActiveClass();

			this.Model.loadAddEditWasherGroupModelData(washerGroupId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
		} else {
			this.RedirctTab("WasherGroup");
		}
	},

    onGetChainFormulaNames: function (data1) {
        data1.ProgramId = 0;
        data1.PlantProgramId = 0;
        data1.Name = "";
        data1.Pieces = 0;
        data1.Rewash = false;
        data1.WeightDisplay = 0;
        data1.PlantCustomerId = 0;
        data1.PlantCustomer = this.dropDownData.CustomerList;
        data1.dropDownData = this.dropDownData;
        data1.Items = [];
        var obj = { EcolabTextileId: 0, EcolabSaturationId: 0, FormulaSegmentId: 0 };
        data1.Items.push(obj);


        this.Views.AddEditFormulaView.setDataAddFormula(data1);
        $('#myModal').modal({
            show: true,
            backdrop: 'static',
            keyboard: false
        });
    },

    onGetChainFormulaNamesFialedDetails: function (error, description, Window) {
        //this.Views.PumpsEdit.showCreatePumpsFailedChemicalData(error, description, Window);
    },

    loadFormulaData: function () {
        //this.Model.LoadDropDownData(this.settings.accountInfo.PlantChainId);
        this.Model.LoadDropDownData(this.PlantChainIdByEcolabAccountNo);
    },

    getPlantChainId: function () {
        this.Model.GetPlantChainId(this.settings.accountInfo.EcolabAccountNumber);
    },

    onLoadDropDownDataLoaded: function (data) {
        this.dropDownData = data;
        this.Model.loadFormulaData();
    },

    onGetPlantChainIdLoaded: function (data) {
        this.PlantChainIdByEcolabAccountNo = data;
    },

    onFormulaDataLoaded: function (data) {
        data.message = this.message;
        data.PlantChainId = this.settings.accountInfo.PlantChainId;
        data.accountInfo = this.settings.accountInfo;
        data.dropDownData = this.dropDownData;
        $.each(data.Items, function (i, v) {
            if (v.EcolabTextileId != 0) {
                v.FormulaCategory = v.EcolabTextileId;
                v.FormulaCategoryName = v.EcolabTextileCategoryName;
            } else if (v.ChainTextileId != 0) {
                v.FormulaCategory = v.ChainTextileId;
                v.FormulaCategoryName = v.ChainTextileCategory;
            }
        });
        //this.Views.FormulaView.setData(data);
    },

    getChainFormulaData: function (plantProgramId) {
        this.Model.getChainFormulaData(plantProgramId);
    },

    onGetChainFormulaData: function (data) {
        this.Views.AddEditFormulaView.BindChainFormulaData(data);
    },

    WasherFormulaPopupSavePage: function (isInline) {
        if (isInline == false) {
            var addEditFormulaView = this.Views.AddEditFormulaView;
            if (addEditFormulaView) {
                if (addEditFormulaView.validate()) {
                    var washerFormulaPopupData = addEditFormulaView.getWasherFormulaPopupData();
                    if (this.IsCopy) {
                        washerFormulaPopupData.ProgramId = 0;
                    }
                    if (washerFormulaPopupData.ProgramId > 0) {
                        this.onWasherFormulaUpdateClicked(washerFormulaPopupData);
                    } else {
                        this.onWasherFormulaSaveClicked(washerFormulaPopupData);
                    }
                } else {
                    return false;
                }
            }
            this.isDirty = false;
            this.IsCopy = false;
        } else {
            if (this.Views.AddEditFormulaView) {
                if (this.Views.AddEditFormulaView.validate()) {
                    return this.Model.onFormulaUpdate(this.Views.AddEditFormulaView.getFormulaEditableGridData());
                } else
                    return false;
            }
            this.isDirty = false;
        }
    },

    onWasherFormulaUpdateClicked: function (washerFormulaPopupData) {
        data = [];
        data[0] = washerFormulaPopupData
        this.Model.onWasherFormulaUpdate(data);
    },

    onWasherFormulaSaveClicked: function (washerFormulaPopupData) {
        this.Model.onWasherFormulaSave(washerFormulaPopupData);
    },
    onUseFormulaFromGroupChkboxClicked: function (washergroupid, UseGroup1Formulas) {
        this.moveFormulaFromGroupOne(washergroupid, UseGroup1Formulas);
    },
    onGroupFormulaMoveupdated: function (data) {
        if (data == true) {
            this.message = '<label data-localize ="FIELD_USEFORMULAFROMGROUPONE" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_USEFORMULAFROMGROUPONE', "Formulas from Group 1 used successfully.") + '</label>';
        }
        if (data == false) {
            this.message = '<label data-localize ="FIELD_NOTUSEFORMULAFROMGROUPONE" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_NOTUSEFORMULAFROMGROUPONE', "Formulas from Group 1 removed successfully.") + '</label>';
        }
        this.Views.WasherGroupFormulasListView.showMessageFormula(this.message);
        this.Views.WasherGroupFormulasListView.onUseFormulaFromGroupChkBox(data);
    },
    onGroupFormulaMoveUpdationFailed: function (error, description) {
        if (description == 51030) {
            this.Views.WasherGroupFormulasListView.showMessageFormula('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>');
        }
        else if (description == 60000) {
            this.Views.WasherGroupFormulasListView.showMessageFormula('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        }
        else if (description == 111) {
            this.Views.WasherGroupFormulasListView.showMessageFormula('<label class="k-error-message">Some Error Occured.</label>');
        }
        else {
            this.message = '<label data-localize ="FIELD_PLCERROR" class="k-error-message">' + description;
            this.Views.WasherGroupFormulasListView.showMessageFormula(this.message);
        }
    },

    onWasherFormulaSaveSuccess: function (data) {
        $('#myModal').modal('hide');
        this.isDirty = false;
        var WasherFormulaId;
        var WasherFormulaName;
        if (data != null && data != undefined && data != "") {
            var selectList = $('#ddlFormulaName option');
            selectList.sort(function (a, b) {
                a = a.value;
                b = b.value;
                return a - b;
            });
            $('#ddlFormulaName').html(selectList);

            if (data.ProgramId == 0 || data.ProgramId == 1) {
                WasherFormulaId = parseInt($('#ddlFormulaName > option:last').val()) + 1;
            }
            else {
                WasherFormulaId = data.ProgramId;
            }
            WasherFormulaName = data.Name;
        }
        $("#ddlFormulaName").append($("<option></option>").attr("value", WasherFormulaId).text(WasherFormulaName));
        this.Views.AddEditFormulaView.showSucessFailureMessage('<label data-localize ="FIELD_NEWFORMULADDEDSUCCESSFULLY" class="WasherFormula-Success-Message" style="color: green !important;">New Formula added successfully.</label>');
        this.loadFormulaData();
    },
    onWasherFormulaUpdateSuccess: function (data) {
        $('#myModal').modal('hide');
        this.isDirty = false;
        this.loadFormulaData();
        var WasherFormulaId;
        var WasherFormulaName;
        if (data != null && data != undefined && data != "") {
            WasherFormulaId = data.ProgramId;
            WasherFormulaName = data.Name;
        }
        $("#ddlFormulaName").append($("<option></option>").attr("value", WasherFormulaId).text(WasherFormulaName));
        this.Views.AddEditFormulaView.showSucessFailureMessage('<label data-localize ="FIELD_FORMULAUPDATEDSUCCESSFULLY" class="WasherFormula-Success-Message" style="color: green !important;">Formula updated successfully.</label>');
    },
    onWasherFormulaSaveFailed: function (error, description) {
        if (description == 51030) {
            this.isDirty = false;
            this.Views.AddEditFormulaView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>');
        }
        else if (description == 60000) {
            this.isDirty = false;
            this.Views.AddEditFormulaView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        }
        else if (description == 51031 || description == 303) {
            this.isDirty = false;
            this.Views.AddEditFormulaView.showErrorMessage('<label data-localize ="FIELD_FORMULAALREADYEXIST" class="k-error-message">Formula already exist.</label>');
        }
        else {
            this.isDirty = false;
            this.loadFormulaData();
            this.Views.AddEditFormulaView.showSucessFailureMessage('<label data-localize ="FIELD_FORMULACREATIONFAILED" class="k-error-message WasherFormula-Failure-Message">Formula creation failed.</label>');
        }
    },
    onWasherFormulaUpdateFailed: function (error, description) {
        if (this.isInline) {
            if (description == 51030) {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>';
            }
            else if (description == 60000) {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';
            }
            else if (description == 51031 || description == 303) {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_FORMULAALREADYEXIST" class="k-error-message">Formula already exist.</label>';
            }
            else {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_FORMULAUPDATIONFAILED" class="k-error-message">Formula updation failed.</label>';
            }
        } else {
            if (description == 51030) {
                this.isDirty = false;
                this.Views.AddEditFormulaView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>');
            }
            else if (description == 60000) {
                this.isDirty = false;
                this.Views.AddEditFormulaView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            }
            else if (description == 51031 || description == 303) {
                this.isDirty = false;
                this.Views.AddEditFormulaView.showErrorMessage('<label data-localize ="FIELD_FORMULAALREADYEXIST" class="k-error-message">Formula already exist.</label>');
            }
            else {
                this.isDirty = false;
                this.loadFormulaData();
                this.Views.AddEditFormulaView.showSucessFailureMessage('<label data-localize ="FIELD_FORMULAUPDATIONFAILED" class="k-error-message WasherFormula-Failure-Message">Formula updation failed.</label>');
            }
        }
	},

	//gets the data from model and passing to view to bind the data.
	onWasherGroupDataLoad: function (washerGroupData) {
	    if (washerGroupData.WasherGroupDetails.length == 0) {
			if (washerGroupData.NextAvailableWasherGroupNumber == 0) {
	            washerGroupData.NextAvailableWasherGroupNumber = 1;
	        }
			washerGroupData.WasherGroupDetails[0] = {
				WasherGroupId: 0,
				WasherGroupNumber: washerGroupData.NextAvailableWasherGroupNumber,
				WasherGroupName: '',
				WasherGroupTypeId: 1
			}
			washerGroupData.Mode = "Add";
		} else {
			this.washerGroupTypeId = washerGroupData.WasherGroupDetails[0].WasherGroupTypeId;
			this.settings.accountInfo.WasherGroupTypeId = washerGroupData.WasherGroupDetails[0].WasherGroupTypeId;
			this.settings.accountInfo.WasherGroupId = washerGroupData.WasherGroupDetails[0].WasherGroupId;
			this.WasherGroupId = washerGroupData.WasherGroupDetails[0].WasherGroupId;
			washerGroupData.Mode = "Edit";
		}
		this.settings.accountInfo.FileName = "WasherGroup";
		if (washerGroupData.WasherGroupDetails[0].WasherGroupTypeId == 2) {
			if (washerGroupData.WashersList[0] != null) {
				this.settings.accountInfo.Maxload = washerGroupData.WashersList[0].Maxload;
				this.settings.accountInfo.TunnelId = washerGroupData.WashersList[0].Id;
			}
		}
		else {
			if (washerGroupData.WashersList[0] != null) {
				this.settings.accountInfo.washerId = washerGroupData.WashersList[0].Id;
			}
		}        
		washerGroupData.washerMessage = this.washerMessage;
		this.Views.AddWasherGroup.setData(washerGroupData);
		
	},

	calculateTotalQuantity: function (nominalLoad, referenceLoad, quantity) {
		var nL = parseFloat(nominalLoad / 100);
		var totalQuantity = parseFloat(quantity * nL * referenceLoad) / 100;
		return totalQuantity.toFixed(2);
	},

	CalculateQuantity: function (nominalLoad, referenceLoad, totalQuantity) {
		var nL = parseFloat(nominalLoad / 100);
		var quantity = parseFloat(totalQuantity * 100) / (nL * referenceLoad);
		return quantity.toFixed(2);
	},
    calculateTotalQuantityForEU: function (nominalLoad, referenceLoad, quantity) {
        var nL = parseFloat(nominalLoad / 100);
        var totalQuantity = parseFloat(quantity * nL * referenceLoad);
        return totalQuantity.toFixed(2);
    },

    CalculateQuantityForEU: function (nominalLoad, referenceLoad, totalQuantity) {
        var nL = parseFloat(nominalLoad / 100);
        var quantity = parseFloat(totalQuantity) / (nL * referenceLoad);
        return quantity.toFixed(2);
    },
	onFormulaTabClick: function () {
		var id = this.washerGroupOutPutId;
		if (id == undefined)
			id = this.settings.accountInfo.WasherGroupId;
		if (this.isDirty != true) {
			if (id != undefined && id > 0) {
				this.formulasActiveClass();
				this.Model.loadWasherGroupModelData(id, this.settings.accountInfo.EcolabAccountNumber);
			} else {
				this.washerActiveClass();
				this.onWasherGroupClick();
			}
		} else {
			this.RedirctTab("Formula");
		}
	},
	onFormulaDataLoad: function (data) {
		dr = {};
		dr.data = data;
		dr.listMessage = this.listMessage;
		this.listMessage = "";
		this.settings.accountInfo.FileName = "FormulaList";
		if (data.WasherGroupDetails[0].WasherGroupTypeId == 2)
			data.Maxload = this.settings.accountInfo.Maxload;

		this.Views.WasherGroupFormulasListView.setData(dr);
	},
	////Events is for deleting the washer group based on the washer group id.

	saveWasherGroupPage: function (fileName, isSaveAndClose) {
		this.settings.accountInfo.FileName = fileName;
		this.savePage(null, isSaveAndClose);
	},
	updateNominalLoad: function (fileName, isSaveAndClose) {
	    this.tunnelEdit = true;
	    this.settings.accountInfo.FileName = fileName;
	    this.savePage(null, isSaveAndClose);
	},
	savePage: function (filename, isSaveAndClose) {
		var _this = this;
		this.isDirty = false;
		this.washerMessage = '';
		var fileName = this.settings.accountInfo.FileName;
		if (fileName == "FormulaList") {
			var view = this.Views.WasherGroupFormulasListView;
			if (view.validateFormula()) {
				view.getInlineData();
			}
		} else if (fileName == "Formula") {
			if (this.settings.accountInfo.WasherGroupTypeId == 1 || this.tunnelEdit != true) {
		        var addEditFormulaView = this.Views.AddEditFormulaView;

		        if (addEditFormulaView) {
		            if (addEditFormulaView.validateFormula()) {
		                var formulaData = this.Views.AddEditFormulaView.getFormulaData();
		                if (formulaData.Id > 0 || this.NewFormulaId > 0) {
		                    if (this.onFormulaUpdateClicked)
		                        this.onFormulaUpdateClicked(formulaData, isSaveAndClose);
		                } else {
		                    if (this.onFormulaSaveClicked) {
		                        this.onFormulaSaveClicked(formulaData, isSaveAndClose);
		                    }
		                }
		            }
		        }
		    }
		    else {
		        //var addEditFormulaView = this.Views.AddEditFormulaView;
		        var TunnelWasherStepView = this.Views.TunnelWasherStepView
		        if (TunnelWasherStepView) {
		            if (TunnelWasherStepView.validateFormula()) {
		                var formulaData = this.Views.TunnelWasherStepView.getFormulaData();
		                if (formulaData.Id > 0 || this.NewFormulaId > 0) {
		                    if (this.onFormulaUpdateClicked)
		                        this.onFormulaUpdateClicked(formulaData, isSaveAndClose);
		                } else {
		                    if (this.onFormulaSaveClicked) {
		                        this.onFormulaSaveClicked(formulaData, isSaveAndClose);
		                    }
		                }
		            }
		        }
		    }
		} else if (fileName == "WasherGroup") {
			var addWasherGroup = this.Views.AddWasherGroup;
			if (addWasherGroup) {
				if (addWasherGroup.validateWasherGroup()) {
					var washerGroupData = addWasherGroup.getWasherGroupsData();
					this.settings.accountInfo.WasherGroupTypeId = washerGroupData.WasherGroupTypeId;
					if (washerGroupData.WasherGroupId > 0) {
						this.onWasherGroupUpdateClicked(washerGroupData, isSaveAndClose);
					} else {
						this.onWasherGroupSaveClicked(washerGroupData, isSaveAndClose);
					}
				} else {
					return false;
				}
			}
		} else if (fileName == "WasherWashStep") {
			var washStepView = this.Views.AddWasherStepView;
			if (washStepView) {
				if (washStepView.validate()) {
					var washStepData = washStepView.getWashStepData();
					if (this.washerGroupOutPutId == undefined)
						this.washerGroupOutPutId = _this.getQueryStringByName('id');
					washStepData.RegionId = this.settings.accountInfo.RegionId;
					washStepData.WasherGroupId = this.washerGroupOutPutId;
					this.Model.saveWashStep(washStepData, isSaveAndClose);
				}
			}
		} else if (fileName == "TunnelWashStep") {
			var washStepView = this.Views.TunnelWasherStepView;
			if (washStepView) {
				if (washStepView.validateWasherStep()) {
					var washStepData = washStepView.getWashStepData();
					if (this.washerGroupOutPutId == undefined)
						this.washerGroupOutPutId = _this.getQueryStringByName('id');

					washStepData.WasherGroupId = this.washerGroupOutPutId;
					this.Model.saveTunnelWashStep(washStepData, this.settings.accountInfo.RegionId, isSaveAndClose);
				}
			}
		} else if (fileName == "TunnelWashStepGrid") {
			this.message = "";
			var tunnelWashStepGridView = this.Views.TunnelWashStepGridView;
			if (tunnelWashStepGridView) {
				var tunnelWashStepGridData = tunnelWashStepGridView.getTunnelWashStepGridData();
				if (this.settings.accountInfo.ProductsList != null) {
					var products = this.settings.accountInfo.ProductsList;
					for (var i = 0; i < products.length; i++) {
						var subProducts = [];
						subProducts = products[i];
						var index = subProducts[0].CompartmentNumber - 1;
						tunnelWashStepGridData[index].ProductsList = products[i];
					}
				}
				this.Model.saveTunnelWashStepGrid(tunnelWashStepGridData, this.settings.accountInfo.RegionId, isSaveAndClose);
			}
			if (this.settings.accountInfo.ProductsList && this.settings.accountInfo.ProductsList[0].isDirty) {
				this.settings.accountInfo.ProductsList = null;
			}
		} else if (fileName === "conventionalProductsGrid") {
			this.onSaveFormulaInjections(isSaveAndClose);
		}
	},
    moveFormulaFromGroupOne: function (washergroupid, usegroup1formulas) {
        var _this = this;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: usegroup1formulas ? $.GetLocaleKeyValue('', 'Do you want to stop using Formulas from Group 1') : $.GetLocaleKeyValue('', 'Do you want to continue using Formulas from Group 1'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        var washerGroupData = { WasherGroupId: washergroupid, EcolabAccountNumber: _this.settings.accountInfo.EcolabAccountNumber, UseGroup1Formulas: usegroup1formulas }
                        _this.washerGroupData = washerGroupData;
                        _this.moveFormulaFromGroup(washerGroupData);
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        Cdialog.addClass('hide');

                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return false;
    },
    moveFormulaFromGroup: function (washerGroupData) {
        this.Model.onMoveFormulaFromGroupOne(washerGroupData);
    },
	onSaveFormulaDetailsClicked: function (washerGroupId) {
	    var _this = this;
        this.Views.WasherGroupFormulasListView.showMessageFormula('<label class="k-success-message"></label>');
	    if (washerGroupId == undefined)
	        washerGroupId = _this.getQueryStringByName('id');
	    this.Model.saveFormulaDetailsToPLC(this.settings.accountInfo.EcolabAccountNumber, washerGroupId);
	},

	onAddEditFormulaClicked: function (nextAvailableFormulaNo) {
		var _this = this;
		_this.NewFormulaId = 0;// User is not able to create Washer Group Formula using deleted Formula Number. Once we refresh the page then add the formula it is creating successfully.
		var washerGroupId = this.washerGroupOutPutId;
		this.settings.accountInfo.NextAvailableFormulaNo = nextAvailableFormulaNo;
		if (washerGroupId == undefined)
			washerGroupId = _this.getQueryStringByName('id');
		this.Model.GetAddFormula(this.settings.accountInfo.EcolabAccountNumber, washerGroupId, this.settings.accountInfo.RegionId);
	},
	onGetAddFormulaDataRecieved: function (data) {
		this.programId = data.WasherGroupFormulaDetails[0].ProgramId;

		if (data.WashOperationDetails == null) data.WashOperationDetails = 0;
		if (data.WasheStepWaterTypes == null) data.WasheStepWaterTypes = 0;
		if (data.WasherGroupFormulaWashStepModel == null) data.WasherGroupFormulaWashStepModel = 0;
		if (data.WasherGroupDetails[0].WasherGroupTypeId == 2)
			data.Maxload = this.settings.accountInfo.Maxload;
		this.settings.accountInfo.FileName = "Formula";
		data.NextAvailableFormulaNo = this.settings.accountInfo.NextAvailableFormulaNo;
		this.Views.AddEditFormulaView.setData(data);
		this.Views.AddEditFormulaView.WashStepButtonEnabled();
	},

	onGetEditFormulaDataRecieved: function (data) {
	    this.addEditformulaData = data;
		data.message = this.message;
		this.message = "";
		this.settings.accountInfo.FileName = "Formula";
		this.Views.AddEditFormulaView.setData(data);
		//  this.Views.AddEditFormulaView.WashStepButtonEnabled();
	},
	onWasherGroupUpdateClicked: function (washerGroupData, isSaveAndClose) {
		this.Model.UpdateWasherGroup(washerGroupData, null, isSaveAndClose);
	},
	onWasherGroupSaveClicked: function (washerGroupData, isSaveAndClose) {
		this.Model.createWasherGroup(washerGroupData, isSaveAndClose);
	},
	onWasherGroupCreated: function (washerGroupId, isSaveAndClose) {
		var _this = this;
		if (washerGroupId == -1) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT', "Washer Group already exists for the plant.") + '</label>');
		} else if (isSaveAndClose) {
			window.location = '/WasherGroup';
		} else {
			_this.findContainer('Washer Groups', washerGroupId, 0, 'WasherGroupWashers')
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPCREATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPCREATEDSUCCESSFULLY', "Washer Group created successfully.") + '</label>');
			this.washerGroupOutPutId = washerGroupId;
			this.settings.accountInfo.WasherGroupId = washerGroupId;

			if (this.settings.accountInfo.WasherGroupTypeId == 2) {
				this.RedirectLocation('/TunnelGeneral' + '?WasherGroupId=' + this.settings.accountInfo.WasherGroupId + '&WasherGroupTypeId=' + this.settings.accountInfo.WasherGroupTypeId);
			} else {
				this.Views.AddWasherGroup.DisplayAddWasherButton();
			}
		}
	},

	onSaveFormulaDetailsToPLC: function (data) {
	    this.Views.WasherGroupFormulasListView.showMessageFormula('<label class="k-success-message">' + data + '</label>');
	},

	onSaveFormulaDetailsToPLCFailed: function (errorData, description) {
	    this.Views.WasherGroupFormulasListView.showMessageFormula('<label class="k-error-message">' + errorData + '</label>');
	},

	onWasherGroupCreationFailed: function (error, description) {
		if (description == 51000) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT', "Washer Group already exists for the plant.") + '</label>');
		} else if (description == 51030) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSCOUNTDOESNTMATCH', "Record count does not match..Resynch is in progress.") + '</label>');
		} else if (description == 51060) {
		    this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', "Unable to save changes , Connectivity issue, Please try again later.") + '</label>');
		} else if (description == 60000) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSNOTINSYNCH', "Record not in synch..Resynch is in progress.") + '</label>');
		}
	},

	onWasherGrpUpdationFailed: function (error, description) {
		if (description == 51000) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT', "Washer Group already exists for the plant.") + '</label>');
		} else if (description == 51030) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSCOUNTDOESNTMATCH', "Record count does not match..Resynch is in progress.") + '</label>');
		} else if (description == 51060) {
		    this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', "Unable to save changes , Connectivity issue, Please try again later.") + '</label>');
		} else if (description == 60000) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSNOTINSYNCH', "Record not in synch..Resynch is in progress.") + '</label>');
		}
	},
	onWasherGroupUpdated: function (washerGroupId, isSaveAndClose) {
		if (washerGroupId == -1) {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPALREADYEXISTSFORTHEPLANT', "Washer Group already exists for the plant.") + '</label>');
		} else if (isSaveAndClose) {
			window.location = '/WasherGroup';
		} else {
			this.Views.AddWasherGroup.showMessage('<label data-localize ="FIELD_WASHERGROUPUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHERGROUPUPDATEDSUCCESSFULLY', "Washer Group updated successfully.") + '</label>');
			this.washerGroupOutPutId = washerGroupId;
			this.settings.accountInfo.WasherGroupId = washerGroupId;
			var tunnelId = this.settings.accountInfo.TunnelId;
			if (this.settings.accountInfo.WasherGroupTypeId == 2) {
				if (tunnelId) {
					this.RedirectLocation('/TunnelGeneral' + '?WasherId=' + tunnelId + '&WasherGroupId=' + this.settings.accountInfo.WasherGroupId + '&WasherGroupTypeId=' + this.settings.accountInfo.WasherGroupTypeId);
				} else {
					this.RedirectLocation('/TunnelGeneral' + '?WasherGroupId=' + this.settings.accountInfo.WasherGroupId + '&WasherGroupTypeId=' + this.settings.accountInfo.WasherGroupTypeId);
				}
			} else {
				this.Views.AddWasherGroup.DisplayAddWasherButton();
			}
		}
	},

	//Events is for deleting the washer group based on the washer group id.
	onDeleteFormulaListClicked: function (id, washergrouptypename, lastModifiedTime) {
		this.settings.accountInfo.DeleteStatus = "Formulas";
		this.DeleteConfirmation(id, '', washergrouptypename, lastModifiedTime);
	},
	onWashStepDeleteClicked: function (Id, programSetupId) {
		this.settings.accountInfo.DeleteStatus = "WashStep";
		this.programSetupId = programSetupId;
		this.DeleteConfirmation(Id, '', '', '');
		this.settings.accountInfo.ConventionalProductsList = [];
	},

	//Event is for receving the response data after deletion and loading the washer group data.
	onWasherGroupFormulaDeleted: function (washerGroupData, responseData) {
	    if (responseData != null && responseData != undefined && responseData == false) {	        
	        this.listMessage = '<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULADELETEDSUCCESSFULLY', "Formula deleted successfully.") + '</label>' + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
	    }
	    else {
	        this.listMessage = '<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULADELETEDSUCCESSFULLY', "Formula deleted successfully.") + '</label>';
	    }
		this.onFormulaTabClick();
	},
	onWasherGroupFormulaDeletionFailed: function (error, description) {
		if (description == 51030) {
			this.listMessage = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSCOUNTDOESNTMATCH', "Record count does not match..Resynch is in progress.") + '</label>';
		} else if (description == 51060) {
		    this.listMessage = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', "Unable to save changes , Connectivity issue, Please try again later.") + '</label>';
		} else if (description == 60000) {
			this.listMessage = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSNOTINSYNCH', "Record not in synch..Resynch is in progress.") + '</label>';
		} else {
			this.listMessage = '<label data-localize ="FIELD_FORMULADELETIONFAILED" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULADELETIONFAILED', "Formula deletion failed.") + '</label>';
		}

		this.onFormulaTabClick();
	},
	onWasherGroupWashStepDeleted: function (washerGroupData) {
		this.message = '<label data-localize ="FIELD_WASHSTEPDELETEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_WASHSTEPDELETEDSUCCESSFULLY', "Wash step deleted successfully.") + '</label>';
		this.Model.GetEditFormula(this.settings.accountInfo.WasherGroupId, this.FormulaId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
	},
	//Event is used for handling the error details while deleting the washergroup.
	onWasherGroupDeletionFailed: function (error, description) {
		this.Views.WasherGroupFormulasListView.showMessage('<label data-localize ="FIELD_FORMULADELETIONFAILED" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULADELETIONFAILED', "Formula deletion failed.") + '</label>');
	},
	onFormulaSaveClicked: function (formulaData, isSaveAndClose) {
		var _this = this;
		formulaData.WasherGroupId = this.washerGroupOutPutId;
		if (formulaData.WasherGroupId == undefined)
			formulaData.WasherGroupId = _this.getQueryStringByName('id');
		this.Model.createFormula(formulaData, isSaveAndClose);
	},
	onFormulaUpdateClicked: function (formulaData, isSaveAndClose) {
		var _this = this;
		formulaData.ProgramId = this.programId;
		formulaData.WasherGroupId = this.washerGroupOutPutId;
		if (formulaData.WasherGroupId == undefined)
			formulaData.WasherGroupId = _this.getQueryStringByName('id');
		this.Model.updateFormula(formulaData, isSaveAndClose);
	},
	onFormulaInlineUpdateClicked: function (formulaData) {
		var _this = this;
		formulaData.WasherGroupId = this.washerGroupOutPutId;
		if (formulaData.WasherGroupId == undefined)
			formulaData.WasherGroupId = _this.getQueryStringByName('id');
		formulaData.EcolabAccountNumber = this.settings.accountInfo.EcolabAccountNumber;
		this.Model.updateInlineFormula(formulaData);
	},
	onFormulaCreated: function (formulaId, formulaData, isSaveAndClose) {
	    var isPLCConnected;
	    if (formulaId != null && (typeof formulaId == "string") && formulaId.split(',').length > 1) {
	        isPLCConnected = false;
	        formulaId = formulaId.split(',')[0];
	    }
	    else {
	        isPLCConnected = true;
        }        
		this.FormulaId = formulaId;
		var id = this.FormulaId;
		var washerGroupId = this.washerGroupOutPutId;
		this.NewFormulaId = this.FormulaId;
		if (isSaveAndClose) {
		    if (isPLCConnected) {
		        this.onFormulaTabClick();
		    }
			if (formulaId == 60000) {
				this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record not in synch..Resynch is in progress. </label>');
			}
			else if (formulaId == 51030) {
				this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record count does not match..Resynch is in progress. </label>');
			}
			else if (formulaId != 51000) {
			    this.message = '';
			    if (!isPLCConnected) {
			        this.message = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULACREATEDSUCCESSFULLY', "Formula created successfully.") + '<label>' + '. <label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
			        this.Model.GetEditFormula(this.settings.accountInfo.WasherGroupId, formulaId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
			        this.Views.AddEditFormulaView.WashStepButtonEnabled();
			    }
				this.onSaveWashSteps(formulaId, isSaveAndClose);
			}
			else
				this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>');
		} else if (formulaData.WasherGroupTypeName == "Conventional") {
			this.Views.AddEditFormulaView.WashStepButtonEnabled();
			if (formulaId == 60000) {
				this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record not in synch..Resynch is in progress. </label>');
			}
			else if (formulaId == 51030) {
				this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record count does not match..Resynch is in progress. </label>');
			}
			else if (formulaId != 51000) {
			    if (isPLCConnected) {
			        this.message = '<label data-localize ="FIELD_FORMULACREATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULACREATEDSUCCESSFULLY', "Formula created successfully.") + '<label>';
			    }
			    else {
			        this.message = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULACREATEDSUCCESSFULLY', "Formula created successfully.") + '<label>' + '. <label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
			    }
				this.Model.GetEditFormula(this.settings.accountInfo.WasherGroupId, formulaId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
				this.Views.AddEditFormulaView.WashStepButtonEnabled();
				this.onSaveWashSteps(formulaId, false, isPLCConnected);
			} else {
				this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>');
			}
		} else if (formulaData.WasherGroupTypeName == "Tunnel")
			this.onTunnelUpdateWashStepClicked(formulaId);
	},
	onFormulaCreationFailed: function (error, description) {
		if (description == 51000) {
			this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>');
		} else if (description == 60000) {
			this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record not in synch..Resynch is in progress. </label>');
		}
		else if (description == 51030) {
			this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record count does not match..Resynch is in progress. </label>');
		}
		else if (description == 51012)
		{
		    this.Views.AddEditFormulaView.showMessage('<label class="k-error-message"> Max 99 formulas can be created </label>');
		}
	},
	onFormulaUpdated: function (data, formulaData, isSaveAndClose) {
		var id = this.FormulaId;
	    this.isDirty = false;
		this.settings.accountInfo.DirtyFlag = false;
		var washerGroupId = this.washerGroupOutPutId;
		if (isSaveAndClose) {
			this.onSaveWashSteps(id, isSaveAndClose);
			this.settings.accountInfo.ConventionalProductsList = [];
		} else if (formulaData.WasherGroupTypeName == "Conventional") {
		    this.onSaveWashSteps(id, isSaveAndClose, data.IsPLCConnected);
			this.Views.AddEditFormulaView.WashStepButtonEnabled();
			//this.onEditFormulaClicked(id);
		} else if (formulaData.WasherGroupTypeName == "Tunnel") {
		    var saveMsg = '<label data-localize =FIELD_WASHSTEPSSAVEDSUCCESSFULLY" class="k-success-message">Tunnel WashStep saved Successfully.</label>';
		    if (!data.isPLCConnected)
		    {
		        this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
		    }
		    else { this.message = saveMsg;}
		    this.onTunnelUpdateWashStepClicked(id);
		}
	},

	onFormulaUpdationFailed: function (error, description) {
		if (description == 51000) {
			this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>');
		} else if (description == 51060) {
		    this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', "Unable to save changes , Connectivity issue, Please try again later.") + '</label>');
		} else if (description == 60000) {
			this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record not in synch..Resynch is in progress. </label>');
		}
		else if (description == 51030) {
			this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Record count does not match..Resynch is in progress. </label>');
		}
	},

	onInlineFormulaUpdated: function (data) {
		var id = this.FormulaId;
		var washerGroupId = this.washerGroupOutPutId;
		if (data.IsPLCConnected) {
		    this.listMessage = '<label data-localize ="FIELD_FORMULAUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>';
		}
		else {
		    this.listMessage = '<label data-localize ="FIELD_FORMULAUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>' + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
        }
		this.onFormulaTabClick();
	},
	onInlineFormulaUpdationFailed: function (error, description) {
		if (description == 51000) {
			this.listMessage = '<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>';
		} else if (description == 51060) {
		    this.listMessage = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', "Unable to save changes , Connectivity issue, Please try again later.") + '</label>';
		} else if (description == 60000) {
			this.listMessage = '<label class="k-error-message">Record not in synch..Resynch is in progress. </label>';
		}
		else if (description == 51030) {
			this.listMessage = '<label class="k-error-message">Record count does not match..Resynch is in progress. </label>';
		}
		this.onFormulaTabClick();
	},
	onEditFormulaClicked: function (id) {
		var _this = this;
		_this.formulasActiveClass();
		if (this.isDirty == false) {
			this.FormulaId = id;
			var washerGroupId = this.washerGroupOutPutId;
			if (washerGroupId == undefined)
			    washerGroupId = _this.getQueryStringByName('id');
			if (this.settings.accountInfo.WasherGroupTypeId == 1) {
			     this.Model.GetEditFormula(washerGroupId, id, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);			    
			    _this.findContainer('Formula', id, washerGroupId, 'Formulas');
			} else {
			    this.Model.loadTunneWashStep(id, this.settings.accountInfo.EcolabAccountNumber, 0, washerGroupId, this.settings.accountInfo.RegionId);
			}
		 
		} else {
			this.RedirctTab("washStep");
		}
	},
	onUpdateWashStepClicked: function (id) {
		var _this = this;
		var washerGroupId = this.washerGroupOutPutId;
		if (washerGroupId == undefined)
			washerGroupId = _this.getQueryStringByName('id');
		var formulaId = this.FormulaId;
		this.Model.GetEditWashStep(washerGroupId, id, formulaId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
	},
	onCopyWashStepClicked: function (id) {
		var _this = this;
		var washerGroupId = this.washerGroupOutPutId;
		if (washerGroupId == undefined)
			washerGroupId = _this.getQueryStringByName('id');
		var formulaId = this.FormulaId;
		this.Model.GetCopyWashStep(washerGroupId, id, formulaId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
	},

	/******************************************/
	//// Add Washerstep initilize
	initAddWasherStepView: function () {
		var _this = this;
		if (!this.Views.AddWasherStepView) {
			this.Views.AddWasherStepView = new Ecolab.Views.AddWashStep({
				containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					onFormulaTabClick: function () { _this.RedirctTab("Back"); },
					saveWashStep: function (isSaveAndClose) { _this.savePage("WasherWashStep", isSaveAndClose); },
					GetWashStepDetails: function (id) { _this.onUpdateWashStepClicked(id); },
					onChemicalNameChange: function (request, callBack) { _this.loadChemicals(request, callBack); },
					onFormulaBackButtonClick: function () { _this.onFormulaBackButtonClick(); },
					madeChangeFalse: function () { _this.madeChangeFalse(); },
					onRedirection: function (url) { return _this.cancelTab("Back"); },
					PrintRedirection: function (url) { return _this.RedirectLocation(url); },
					onBackToWashStepsClick: function (Id) { _this.onEditFormulaClicked(Id); },
					onConventionalWashStepGridViewClick: function (washerGroupId, id) { _this.onProductsViewCliked(washerGroupId, id); },
				}
			});
		}
	},
	madeChangeFalse: function () {
		this.isDirty = false;
	},

	//gets the model data for basic wash step details.
	onWashStepClicked: function () {
		this.Model.loadWashStepModelData(this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.EcolabAccountNumber, this.FormulaId, this.settings.accountInfo.RegionId);
	},
	// for setting the wash step basic data
	onWashStepDataLoad: function (washStepData) {
		if (washStepData.WasherGroupFormulaDetails == null) {
			washStepData.WasherGroupFormulaDetails = 1;
		}
		washStepData.FormulaId = this.FormulaId;
		if (washStepData.WasherGroupDetails[0].WasherGroupTypeId === 1) {
			this.settings.accountInfo.FileName = "WasherWashStep";
			if (washStepData.WasherGroupFormulaWashStepModel) {
				washStepData.filetredChemicalList = this.Views.AddWasherStepView.filterChemicals(washStepData.WasherGroupFormulaWashStepModel[0].WasherDosingProducts, washStepData.GetChemicalList);
			} else if (washStepData.GetChemicalList) {
				washStepData.filetredChemicalList = washStepData.GetChemicalList;
			}
			this.Views.AddWasherStepView.setData(washStepData);
		} else if (washStepData.WasherGroupDetails[0].WasherGroupTypeId === 2)
			this.Views.TunnelWasherStepView.setData(washStepData);
	},

	onCopyWashStepDataLoad: function (washStepData) {
		if (washStepData.WasherGroupFormulaDetails == null) {
			washStepData.WasherGroupFormulaDetails = 1;
		}
		washStepData.IsCopy = true;
		washStepData.WasherGroupFormulaWashStepModel[0].Id = 0;
		washStepData.WasherGroupFormulaWashStepModel[0].StepNumber = washStepData.WasherGroupFormulaDetails[0].NextAvailableStepNo;
		this.settings.accountInfo.FileName = "WasherWashStep";
		this.Views.AddWasherStepView.setData(washStepData);
	},
	//Event for save wash step details

	onWashStepCreationSuccess: function (response, isSaveAndClose) {
		this.Views.AddWasherStepView.onWashStepCreationSuccess(response, isSaveAndClose);
	},
	onWashStepCreationFailed: function (errorData) {
		this.Views.AddWasherStepView.onWashStepCreationFailed(errorData);
	},

	loadChemicals: function (request, callBack) {
		this.Model.loadChemicals(request, callBack);
	},

	/******************************************/
	//// Tunnel Washerstep initilize
	initTunnelWasherStepView: function () {
		var _this = this;
		if (!this.Views.TunnelWasherStepView) {
			this.Views.TunnelWasherStepView = new Ecolab.Views.TunnelWashStep({
				containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					saveTunnelWashStep: function (isSaveAndClose) { _this.savePage(null, isSaveAndClose); },
					GetCompartmentDetails: function (formulaId, compId, washergroupid) { _this.GetCompartmentDetails(formulaId, compId, washergroupid); },
					onFormulaTabClick: function () { _this.RedirctTab("Back"); },
					onGridViewClicked: function (fId, groupId) { _this.onTunnelGridViewClick(fId, groupId); },
					madeChangeFalse: function () { _this.madeChangeFalse(); },
					swapView: function () { _this.RedirctTab("Swap"); },
					onRedirection: function (url) { return _this.RedirctTab("cancel"); },
					onRedirection: function (url) { return _this.cancelTab("Back"); },
					PrintRedirection: function (url) { return _this.RedirectLocation(url); },
					clearMessage: function () { _this.clearMessage(); },
					updateNominalLoad: function (isSaveAndClose) { _this.updateNominalLoad("Formula", isSaveAndClose); },
				}
			});
		}
	},
	//gets the model data for basic tunnel wash step details.
	onTunnelUpdateWashStepClicked: function (id) {
	    this.settings.accountInfo.FileName = "TunnelWashStep";
		var _this = this;
		if (this.washerGroupOutPutId == undefined)
			this.washerGroupOutPutId = _this.getQueryStringByName('id');
		this.Model.loadTunneWashStep(id, this.settings.accountInfo.EcolabAccountNumber, 0, this.washerGroupOutPutId, this.settings.accountInfo.RegionId);
	},
	// for setting the tunnel wash step basic data
	onTunnelWashStepSetData: function (tunnelWashStepData) {
		this.settings.accountInfo.FileName = "TunnelWashStep";
		tunnelWashStepData.message = this.message;
		this.message = '';
		this.Views.TunnelWasherStepView.setData(tunnelWashStepData);
	},
	//Event for save wash step details

	onFormulaBackButtonClick: function () {
		this.onFormulaTabClick();
	},
	GetCompartmentDetails: function (formulaId, compId, washergroupid) {
	    var _this = this;
	    _this.settings.accountInfo.compId = compId;
		if (this.isDirty) {
		    var cDialog = $('#ConfirmDialog');
		    cDialog.removeClass('hide');
		    var dialogOptions = {
		        HeaderText: $.GetLocaleKeyValue('FIELD_PENDINGCHANGES', 'Pending Changes'),
		        BodyMessage: $.GetLocaleKeyValue('FIELD_DOYOUWANTTOSAVECHANGES', 'Do you want to save changes?'),
		        Buttons: {
		            Yes: {
		                Callback: function () {
		                    if (_this.savePage) {
								_this.savePage(null, null);
		                    }
		                    else {
		                        _this.isDirty = false;
		                    }
		                    cDialog.addClass('hide');
		                },
		                CallbackParameters: null
		            },
		            No: {
		                Callback: function () {
		                    cDialog.addClass('hide');
		                    _this.isDirty = false;
		                    _this.Model.loadTunneWashStep(formulaId, _this.settings.accountInfo.EcolabAccountNumber, compId, washergroupid, _this.settings.accountInfo.RegionId);
		                },
		                CallbackParameters: null
		            }
		        }
		    };
		    this.Views.confirmDialog.setData(dialogOptions);
		} else {
		    _this.Model.loadTunneWashStep(formulaId, _this.settings.accountInfo.EcolabAccountNumber, compId, washergroupid, _this.settings.accountInfo.RegionId);
		}
	},
	onTunnelWashStepCreationSuccess: function (response, isSaveAndClose) {
	    var saveMsg = '<label data-localize =FIELD_WASHSTEPSSAVEDSUCCESSFULLY" class="k-success-message">Tunnel WashStep saved Successfully.</label>';
	    if (response == 200 && !isSaveAndClose) {
	        this.settings.accountInfo.DirtyFlag = false;
	        this.message = saveMsg;
	        this.Views.TunnelWasherStepView.GetCompartmentDetails();
	    }
	    else if (response == 901 && !isSaveAndClose) {
	        this.settings.accountInfo.DirtyFlag = false;
	        this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
	        this.Views.TunnelWasherStepView.GetCompartmentDetails();
	    }
	    else if (response == 901 && isSaveAndClose) {
	        this.settings.accountInfo.DirtyFlag = false;
	        this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
	        this.Views.TunnelWasherStepView.GetCompartmentDetails();
	    }
	    else if (response == 200 && isSaveAndClose) {
	        this.onFormulaTabClick();
	        this.message = '';
	    }
	},
	onTunnelWashStepCreationFailed: function (errorData) {
		this.Views.TunnelWasherStepView.onWashStepCreationFailed(errorData);
	},

	// initialize the Tunnel grid view Mode
	initTunnelWasherStepGridView: function () {
		var _this = this;
		if (!this.Views.TunnelWashStepGridView) {
			this.Views.TunnelWashStepGridView = new Ecolab.Views.TunnelWashStepGridView({
				containerSelector: '#tabFormulaContainer', // Need to give the div id based on the html
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					onFormViewClicked: function (id) { _this.onFormViewClicked(id); },
					onFormulaTabClick: function (url) { return _this.RedirctTab(url); },
					onCancelclicked: function (url) { return _this.cancelTunnelGridView(url); },
					saveTunnelWashStepGrid: function (isSaveAndClose) { _this.savePage(null, isSaveAndClose); },
					getProductsList: function (productsList, dosingId) { _this.getProductsList(productsList, dosingId); },
					onValueChange: function () { _this.madeChange(); },
					madeChangeFalse: function () { _this.madeChangeFalse(); },
					swapView: function () { _this.RedirctTab("Grid"); },
					onRedirection: function (url) { return _this.cancelTab("Grid"); },
					PrintRedirection: function (url) { return _this.RedirectLocation(url); },
					clearMessage: function () { _this.clearMessage(); }
				}
			});
		}
	},

	// initialize the Tunnel grid view products list
	initTunnelGridProductListView: function () {
		var _this = this;
		if (!this.Views.ProductsListView) {
			this.Views.ProductsListView = new Ecolab.Views.ProductsList({
				containerSelector: '#tabFormulaAddEditContainer', // Need to give the div id based on the html
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					updateProducts: function (productsList) { _this.updateProducts(productsList); },
					onValueChange: function () { _this.madeChange(); },
				}
			});
		}
	},
	cancelTunnelGridView: function (url) {
		if (this.settings.accountInfo.ProductsList && this.settings.accountInfo.ProductsList[0].isDirty)
			this.madeChange();

		return this.RedirctTab(url);
	},

	updateProducts: function (productsList) {
		var prodarr = [];
		if (this.settings.accountInfo.ProductsList == undefined) {
			this.settings.accountInfo.ProductsList = prodarr;
			this.settings.accountInfo.ProductsList[0] = productsList;
		} else {
			var leng = this.settings.accountInfo.ProductsList.length;
			this.settings.accountInfo.ProductsList[leng] = productsList;
		}
	},

	//gets the model data for grid tunnel wash step details.
	onTunnelGridViewClick: function (fId, groupId) {
		this.Model.loadTunnelGridViewDetails(fId, this.settings.accountInfo.EcolabAccountNumber, 0, groupId, this.settings.accountInfo.RegionId);
	},
	// for setting the tunnel wash step basic data
	onTunnelGridViewSetData: function (tunnelGridViewData) {
		var arr = [];
		var data = [];
		for (var i = 0; i < 10; i++) {
			arr.push(i + 1);
		}
		tunnelGridViewData.arr = arr;
		this.settings.accountInfo.FileName = "TunnelWashStepGrid";
		tunnelGridViewData.message = this.message;
		this.message = '';
		this.Views.TunnelWashStepGridView.setData(tunnelGridViewData);
	},
	onFormViewClicked: function (id) {
		this.onTunnelUpdateWashStepClicked(id);
	},
	RedirctTab: function (url) {
		var _this = this;
		var washerGroupId = _this.settings.accountInfo.WasherGroupId;
		if (this.isDirty) {
			var cDialog = $('#ConfirmDialog');
			cDialog.removeClass('hide');
			var dialogOptions = {
				HeaderText: $.GetLocaleKeyValue('FIELD_PENDINGCHANGES', 'Pending Changes'),
				BodyMessage: $.GetLocaleKeyValue('FIELD_DOYOUWANTTOSAVECHANGES', 'You need save before you can proceed. Do you wish to save?'),
				Buttons: {
					Yes: {
						Callback: function () {
							cDialog.addClass('hide');
							if (url == "conventionalGrid") {
								return _this.onDropDownFormulaChanged();
							} else {
								_this.savePage();
							}
						},
						CallbackParameters: null
					},
					No: {
						Callback: function () {
							cDialog.addClass('hide');
							switch (url) {
								case "Back":
									_this.onFormulaTabClick();
									break;
								case "Swap":
									_this.Views.TunnelWasherStepView.onGridViewClicked();
									break;
								case "Grid":
									_this.Views.TunnelWashStepGridView.onFormViewClicked();
									break;
								case "WasherGroup":
									_this.isDirty = false;
									_this.loadAddEditWasherGroupModelData(washerGroupId);
									break;
								case "Formula":
									_this.isDirty = false;
									_this.onFormulaTabClick();
									break;
								case "Cancel":
									_this.isDirty = false;
									_this.onFormulaTabClick();
									break;
								case "conventionalGrid":
									_this.isDirty = false;
									_this.onEditFormulaClicked(_this.dropDownNewFormulaId);
									break;

								default:
									_this.isDirty = false;
									_this.onEditFormulaClicked(_this.FormulaId);
									break;
							}
							_this.isDirty = false;
							_this.settings.accountInfo.ConventionalProductsList = [];
						},
						CallbackParameters: null
					}
				}
			};
			this.Views.confirmDialog.setData(dialogOptions);
		} else {
			if (url == "Back" && _this.isDirty == false) {
				_this.onFormulaTabClick();
			} else if (url == "Swap" && _this.isDirty == false) {
				_this.Views.TunnelWasherStepView.onGridViewClicked();
			} else if (url == "Grid" && _this.isDirty == false) {
				_this.Views.TunnelWashStepGridView.onFormViewClicked();
			} else if (url == "WasherGroup" && _this.isDirty == false) {
				_this.loadAddEditWasherGroupModelData(washerGroupId);
			} else if (url == "conventionalGrid" && _this.isDirty == false) {
				_this.onEditFormulaClicked(_this.dropDownNewFormulaId);
			}
		}
	},

	madeChange: function () {
		var _this = this;
		_this.isDirty = true;
		this.message = "";
	},

	onTunnelGridSuccess: function (response, isSaveAndClose) {
	    var saveMsg = '<label data-localize ="FIELD_TUNNELWASHSTEPSSAVEDSUCCESSFULLY" class="k-success-message">Tunnel WashSteps saved successfully.</label>';
	    if (response == 901) {
	        this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
	    }
	    else {
	        this.message = saveMsg;
	    }
	    if (isSaveAndClose) {
	        this.onFormulaTabClick();
	    } else {
	        this.Views.TunnelWasherStepView.onGridViewClicked();
	    }
	},
	onTunnelGridFailed: function (response) {
		this.Views.TunnelWashStepGridView.onWashStepCreationFailed(response);
	},
	getProductsList: function (productsList, dosingId) {
		this.Views.ProductsListView.setData(productsList, dosingId);
	},

	onAddNewWasher: function () {
		if (this.settings.accountInfo.WasherGroupTypeId == 1) {
			this.RedirectLocation('/ConventionalGeneral' + '?WasherGroupId=' + this.settings.accountInfo.WasherGroupId);
		}
	},
	onWasherDeleteClicked: function (isTunnel, id) {
		this.settings.accountInfo.DeleteStatus = "Washers";
		this.DeleteConfirmation(id, isTunnel, '', '');
	},
	onWasherDeleted: function (washerGroupData) {
		this.washerMessage = '<label data-localize ="FIELD_WASHERDELETEDSUCCESSFULLY" class="k-success-message">Washer deleted successfully.</label>';
		this.settings.accountInfo.TunnelId = null;
		this.loadAddEditWasherGroupModelData(this.washerGroupId);
	},
	onWasherDeletionFailed: function (error, description) {
		this.washerMessage = '<label data-localize ="FIELD_WASHERDELETIONFAILED" class="k-error-message">Washer deletion failed.</label>';
		this.loadAddEditWasherGroupModelData(this.washerGroupId);
	},
	DeleteConfirmation: function (Id, flag, washerGroupTypeName, lastModifiedTime) {
		var _this = this;
		var Cdialog = $('#ConfirmDialog');
		Cdialog.removeClass('hide');
		var dialogOptions = {
			HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
			BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISRECORD', 'Are you sure you want to delete this Record?'),
			Buttons: {
				Yes: {
					Callback: function () {
						Cdialog.addClass('hide');
						_this.DeleteRecord(Id, flag, washerGroupTypeName, lastModifiedTime);
					},
					CallbackParameters: null
				},
				No: {
					Callback: function () {
						Cdialog.addClass('hide');
					},
					CallbackParameters: null
				}
			}
		};
		this.Views.confirmDialog.setData(dialogOptions);
		return false;
	},
	DeleteRecord: function (Id, flag, washerGroupTypeName, lastModifiedTime) {
		var _this = this;
		var pageName = _this.settings.accountInfo.DeleteStatus;
		var accountNumber = _this.settings.accountInfo.EcolabAccountNumber;
		var washerGroupId = _this.settings.accountInfo.WasherGroupId;
		var washerProgramSetupId = this.programSetupId;
		switch (pageName) {
			case "Washers":
				_this.Model.onDeleteWasher(flag, Id, accountNumber, washerGroupId);
				break;
			case "Formulas":
				var formulaData = { WasherGroupId: washerGroupId, Id: Id, EcolabAccountNumber: accountNumber, WasherGroupTypeName: washerGroupTypeName, LastModifiedTime: lastModifiedTime }
				_this.Model.onDeleteFormulaListClicked(formulaData);
				break;
			case "WashStep":
				var washStepData = { WasherGroupId: washerGroupId, Id: Id, EcolabAccountNumber: accountNumber, ProgramSetupId: washerProgramSetupId }
				_this.Model.WashStepDelete(washStepData);
				break;
		}
		this.settings.accountInfo.DeleteStatus = '';
	},
	clearMessage: function () {
		var _this = this;
		_this.message = '';
	},

	washerActiveClass: function () {
		var _this = this;
		this.message = '';
		$('#tabAddWasherGroup').parent().addClass('active');
		$('#tabFormula').parent().removeClass('active');
		$('#tabAddWasherGroupContainer').addClass('in active');
		$('#tabFormulaContainer').removeClass('in active');
		var id = _this.getQueryStringByName('id');
		_this.findContainer('Formula', id, 0, 'Washers')
	},
	formulasActiveClass: function () {
		var _this = this;
		$('#tabAddWasherGroup').parent().removeClass('active');
		$('#tabFormula').parent().addClass('active');
		$('#tabAddWasherGroupContainer').removeClass('in active');
		$('#tabFormulaContainer').addClass('in active');
		var id = _this.getQueryStringByName('id');
		_this.findContainer('Formula', id, 0, 'Formulas')
	},
	getQueryStringByName: function (name) {
		name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
		return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	},
	openCurrentNav: function (typeName, id, parentId, subTypeName) {
		var container = $(this.Views.NavigationMenuView.options.containerSelector);
		var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
		if (element.length == 0) {
			element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
			element.addClass('open');
			element.children('ul').slideDown();

			if (subTypeName == "WasherGroupWashers") {
				element = container.find('.cssmenu li a[typename="Formulas"][id=' + id + '][parentid=' + parentId + ']').parent('li');
				element.removeClass('open');
				element.children('ul').slideUp();

				element = container.find('.cssmenu li a[typename="' + subTypeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
				element.addClass('open');
			} else if (subTypeName == "Formulas") {
				element = container.find('.cssmenu li a[typename="WasherGroupWashers"][id=' + id + '][parentid=' + parentId + ']').parent('li');
				element.removeClass('open');
				element.children('ul').slideUp();

				element = container.find('.cssmenu li a[typename="' + subTypeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');
				element.addClass('open');
			}
			element.children('ul').slideDown();
		} else
			element.addClass('active');

		if (typeName == 'Formula') {
			var parentElement = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li').parent('ul').parent('li');
			parentElement.parent('ul').parent('li').addClass('open');
			parentElement.parent('ul').slideDown();
		}
	},
	findContainer: function (typeName, id, parentId, subTypeName) {
		var _this = this;
		_this.loadNavigationMenuListView();
		retryCount = (typeof retryCoutorgaetanksnt == "undefined" ? 10 : retryCount - 1);
		if (retryCount === 0) return; //give up on loading the template
		setTimeout(function () { _this.openCurrentNav(typeName, id, parentId, subTypeName); }, 200);
		return;
	},

	cancelTab: function (url) {
		var _this = this;
		//this.isDirty = false
		var washerGroupId = _this.settings.accountInfo.WasherGroupId;
		if (this.isDirty) {
			var cDialog = $('#ConfirmDialog');
			cDialog.removeClass('hide');
			var dialogOptions = {
				HeaderText: $.GetLocaleKeyValue('FIELD_PENDINGCHANGES', 'Pending Changes'),
				BodyMessage: $.GetLocaleKeyValue('FIELD_DOYOUWANTTOSAVECHANGES', 'Do you want to save changes?'),
				Buttons: {
					Yes: {
						Callback: function () {
							cDialog.addClass('hide');
							_this.savePage();
						},
						CallbackParameters: null
					},
					No: {
						Callback: function () {
							cDialog.addClass('hide');
							switch (url) {
								case "Back":
									_this.onFormulaTabClick();
									break;
								case "Swap":
									_this.Views.TunnelWasherStepView.onGridViewClicked();
									break;
								case "Grid":
									_this.Views.TunnelWashStepGridView.onFormViewClicked();
									break;
								case "WasherGroup":
									_this.isDirty = false;
									_this.loadAddEditWasherGroupModelData(washerGroupId);
									break;
								case "Formula":
									_this.isDirty = false;
									_this.onFormulaTabClick();
									break;
								case "Cancel":
									_this.isDirty = false;
									break;
								default:
									_this.onEditFormulaClicked(_this.FormulaId);
									break;
							}
							_this.isDirty = false;
						},
						CallbackParameters: null
					}
				}
			};
			this.Views.confirmDialog.setData(dialogOptions);
		} else {
			if (url == "Back" && _this.isDirty == false) {
				_this.onFormulaTabClick();
			} else if (url == "Swap" && _this.isDirty == false) {
				_this.Views.TunnelWasherStepView.onGridViewClicked();
			} else if (url == "Grid" && _this.isDirty == false) {
				_this.Views.TunnelWashStepGridView.onFormViewClicked();
			} else if (url == "WasherGroup" && _this.isDirty == false) {
				_this.loadAddEditWasherGroupModelData(washerGroupId);
			}
		}
		return false;
	},

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///             Covetional WashStep GridView functions                   ///
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// initialize the Convetional grid view Mode

	initConventionalWasherStepGridView: function () {
		var thisObject = this;
		if (!thisObject.Views.ConventionalWashStepGridView) {
			thisObject.Views.ConventionalWashStepGridView = new Ecolab.Views.ConventionalWashStepGridView({
				containerSelector: "#tabFormulaContainer",
				accountInfo: thisObject.settings.accountInfo,
				eventHandlers: {
				}
			});
		}
	},
	getConvetionalGridViewDetails: function () {
	},

	// initalize the conventional products pop up funcions
	initConventionalProducts: function () {
		var thisObject = this;
		if (!thisObject.Views.ConventionalProducts) {
			thisObject.Views.ConventionalProducts = new Ecolab.Views.ConventionalProducts({
				containerSelector: "#tabProductsContainer",
				accountInfo: thisObject.settings.accountInfo,
				eventHandlers: {
					updateConventionalProducts: function (productsList) { thisObject.updateConventionalProducts(productsList); }
				}
			});
		}
	},

	initConventionalAnalougeControl: function () {
		var thisObject = this;
		if (!thisObject.Views.ConventionalAnalougeControlForEurope) {
			thisObject.Views.ConventionalAnalougeControlForEurope = new Ecolab.Views.ConventionalAnalougeControlForEurope({
				containerSelector: "#tabProductsContainer",
				accountInfo: thisObject.settings.accountInfo,
				eventHandlers: {
					updateConventionalAnalougeControl: function (analogControls) { thisObject.updateConventionalAnalougeControl(analogControls); }
				}
			});
		}
	},

	getConventionalProductsList: function (stepDetails, formulaName, chemicalList, nominalLoad, stepNumber, washOperation, washOperationId, referenceLoad, canAddInjections, injectionsAdded, maxInjectionsCount, controllerModelId, washersList) {
		var data = [];
		var injections = [];
		data.Products = chemicalList;
		if (this.settings.accountInfo.ConventionalProductsList) {
			$.each(this.settings.accountInfo.ConventionalProductsList, function (index, item) {
				$.each(item, function (i, v) {
					if (v.StepNumber == stepNumber && v.IsDeleted != "true") {
						var added = true;
						$.grep(injections, function (item) { if (item.ProductId == v.ProductId && item.ControllerEquipmentSetupId == v.ControllerEquipmentSetupId) { added = false; } })
						if (added) {
							injections.push(v);
						}
					}
				})
			})
			if (injections.length > 0) {
                if (stepDetails == undefined) {
                    stepDetails = {};
                    stepDetails.WasherDosingProducts = {};
                }
                stepDetails.WasherDosingProducts = injections;
                $.each(injections, function (i, v) {
                    chemicalList = $.grep(chemicalList, function (item) { return item.ProductId != v.ProductId && item.ControllerEquipmentSetupId != v.ControllerEquipmentSetupId })
                })
				
			}
		}
		//if (chemicalList && stepDetails.WasherDosingProducts) {
		//    $.each(stepDetails.WasherDosingProducts, function (index, item) {
		//        var washerdosingproducts = $.grep(chemicalList, function (type) { return type.ControllerEquipmentSetupId == item.ControllerEquipmentSetupId && type.ProductId == item.ProductId });
		//        if (washerdosingproducts.length > 0) {
		//            item.ControllerEquipmentTypeId = washerdosingproducts[0].ControllerEquipmentTypeId;
		//        }
		        
		//    })		    
		//}
		data.stepDetails = stepDetails;
		data.FormulaName = formulaName;
		data.ChemicalList = chemicalList;
		data.EcolabAccountNumber = this.settings.accountInfo.EcolabAccountNumber;
		data.Nominalload = nominalLoad;
		data.accountInfo = this.settings.accountInfo;
		data.StepNumber = stepNumber;
		data.WashOperation = washOperation;
		data.WashOperationId = washOperationId;
		data.ReferenceLoad = referenceLoad;
		data.ControllerModelId = controllerModelId;
        data.WashersList = washersList;
		data.CanAddInjections = canAddInjections;


		this.Views.ConventionalProducts.setData(data);
	},


	getConventionalAnalouge: function (stepDetails, formulaName, chemicalList, stepNumber, washOperation, washOperationId, referenceLoad, controllerModelId, washersList) {
		var data = [];
		var injections = [];
		data.Products = chemicalList;
		if (this.settings.accountInfo.ConventionalProductsList) {
			$.each(this.settings.accountInfo.ConventionalProductsList, function (index, item) {
				//delete item.IsUpdated;
				//delete item.StepNumber;
				$.each(item, function (i, v) {
					if (v.StepNumber == stepNumber && v.IsDeleted != "true") {
						var added = true;
						$.grep(injections, function (item) { if (item.ProductId == v.ProductId) { added = false; } })
						if (added) {
							injections.push(v);
						}
					}
				})
			})
			if (injections.length > 0) {
                if (stepDetails == undefined) {
                    stepDetails = {};
                    stepDetails.WasherDosingProducts = {};
                }
				stepDetails.WasherDosingProducts = injections;
				$.each(injections, function (i, v) {
					chemicalList = $.grep(chemicalList, function (item) { return item.ProductId != v.ProductId })
				})
			}
		}
		data.stepDetails = stepDetails;
		data.FormulaName = formulaName;
		data.ChemicalList = chemicalList;
		data.EcolabAccountNumber = this.settings.accountInfo.EcolabAccountNumber;
		data.accountInfo = this.settings.accountInfo;
		data.StepNumber = stepNumber;
		data.WashOperation = washOperation;
		data.WashOperationId = washOperationId;
		data.ReferenceLoad = referenceLoad;
		data.ControllerModelId = controllerModelId;
        data.WashersList = washersList;
		this.Views.ConventionalAnalougeControlForEurope.setData(data);
	},
	updateConventionalProducts: function (productsList) {
		productsList = this.Views.ConventionalProducts.getConventionalWashStepdata();

		if (productsList != undefined) {
			if (this.settings.accountInfo.ConventionalProductsList == undefined) {
				this.settings.accountInfo.ConventionalProductsList = [];
				this.settings.accountInfo.ConventionalProductsList[0] = productsList;
				this.settings.accountInfo.ConventionalProductsList[0].IsUpdated = true;
				this.settings.accountInfo.ConventionalProductsList[0].StepNumber = productsList[0].StepNumber;
			} else {
				var objExists = jQuery.grep(this.settings.accountInfo.ConventionalProductsList, function (a) {
					return a[0].StepNumber != productsList[0].StepNumber;;
				});
				if (objExists.length > 0) {
					this.settings.accountInfo.ConventionalProductsList = objExists;
				}
				var leng = this.settings.accountInfo.ConventionalProductsList.length;
				this.settings.accountInfo.ConventionalProductsList[leng] = productsList;
				this.settings.accountInfo.ConventionalProductsList[leng].IsUpdated = true;
				this.settings.accountInfo.ConventionalProductsList[leng].StepNumber = productsList[0].StepNumber;
			}
		}
		this.Views.AddEditFormulaView.enableButtons();
		this.settings.accountInfo.DirtyFlag = true;
		//this.isDirty = true;
	},

	onSaveWashSteps: function (formulaId, isSaveAndClose, isPLCConnected) {
		var washStepview = this.Views.AddEditFormulaView;
		var productsView = this.Views.ConventionalProducts;
		var washStepData;
		var washStepLength;

		if (washStepview.validateFormula()) {
			washStepData = washStepview.getWashStepData();

			washStepLength = washStepData.length;

			if (washStepLength) {
				if (formulaId)
					for (var k = 0; k < washStepLength; k++) {
						washStepData[k].ProgramSetupId = formulaId;
					}
				//formulaId = washStepLength? washStepData[0].ProgramSetupId:formulaId;
				if (formulaId > 0) {
					if (this.settings.accountInfo.ConventionalProductsList) {
						var productsleng = this.settings.accountInfo.ConventionalProductsList.length;
						if (productsleng > 0) {
							if (productsView.validateWasherStep() && washStepLength != null && washStepData != null)
								for (var j = 0; j < washStepLength; j++) {
									for (var i = 0; i < productsleng; i++) {
										if (this.settings.accountInfo.ConventionalProductsList[i]
                                           && this.settings.accountInfo.ConventionalProductsList[i].StepNumber == washStepData[j].StepNumber
                                           && this.settings.accountInfo.ConventionalProductsList[i].IsUpdated) {
											if (washStepData[j].WashOperation == "Extract" || washStepData[j].WashOperation == "Drain") {
												this.settings.accountInfo.ConventionalProductsList[i] = undefined;
											} else {
												washStepData[j].WasherDosingProducts = this.settings.accountInfo.ConventionalProductsList[i];
											}
										}
									}
								}
                                
						}
					}
				}
				this.Model.onSaveWashSteps(washStepData, formulaId, isSaveAndClose);
				if (isPLCConnected != undefined && isPLCConnected != null && isPLCConnected == false) {
				    //this.Views.AddEditFormulaView.showMessage('<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>'
                    //        + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>');
				}
				else {
				   //this.Views.AddEditFormulaView.showMessage('<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>');
				}
			} else {
			    if (isPLCConnected != undefined && isPLCConnected != null && isPLCConnected == false) {
			        //this.Views.AddEditFormulaView.showMessage('<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '. <label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>' + '</label>');
			    }
			    else {
			        //this.Views.AddEditFormulaView.showMessage('<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>');
			    }
			}
		} else {
			return false;
		}
	},

	// initalize the conventional products grid funcions
	initConventionalProductsGrid: function () {
		var thisObject = this;
		if (!thisObject.Views.conventionalProductsGrid) {
			thisObject.Views.conventionalProductsGrid = new Ecolab.Views.ConventionalProductGridView({
				containerSelector: "#tabFormulaContainer",
				accountInfo: thisObject.settings.accountInfo,
				eventHandlers: {
					onSaveFormulaInjections: function (isSaveAndClose) { thisObject.onSaveFormulaInjections(isSaveAndClose); },
					onWashStepClicked: function () { thisObject.onWashStepClicked(); },
					onWashStepGridClicked: function (id) { thisObject.onEditFormulaClicked(id); },
					onWashStepGridCancelClicked: function (id) { thisObject.onEditFormulaClicked(id); },
					onCompareFormulaViewClicked: function (washerGroupId, formulaid) { thisObject.onCompareFormulaViewClicked(washerGroupId, formulaid); },
				}
			});
		}
	},
	
	onWashStepgridViewDataSuccess: function (data, formulaId, isSaveAndClose) {
		this.Views.AddEditFormulaView.showMessage('');
		if (data == 200 && !isSaveAndClose) {
			this.onEditFormulaClicked(formulaId);
			this.message = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>';
			this.settings.accountInfo.DirtyFlag = false;
			this.settings.accountInfo.ConventionalProductsList = [];
		}
		else if (data == 901 && !isSaveAndClose) {
		    this.onEditFormulaClicked(formulaId);
		    this.message = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>'
                            + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
		    this.settings.accountInfo.DirtyFlag = false;
		    this.settings.accountInfo.ConventionalProductsList = [];
		}
        else if (data == 901 && isSaveAndClose) {
            this.onEditFormulaClicked(formulaId);
            this.message = '<label class="k-success-message">' +$.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>'
                                    + '<label class="k-error-message"> ' +$.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
        		    this.settings.accountInfo.DirtyFlag = false;
        		    this.settings.accountInfo.ConventionalProductsList =[];
        }
        else if (data == 200 && isSaveAndClose)
        {
            this.onFormulaTabClick();
        }

	},

	onProductsViewCliked: function (washerGroupId, id) {
		this.Model.onProductsViewCliked(washerGroupId, id, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
	},

	onConventionalProductGridView: function (data, formulaId) {
		if (!this.isDirty && !this.settings.accountInfo.DirtyFlag) {
			this.settings.accountInfo.FileName = "conventionalProductsGrid";

		    //if (data.GetChemicalList && data.WasherGroupFormulaWashStepModel) {
		    //    $.each(data.WasherGroupFormulaWashStepModel, function (index, itemNew) {
		    //        if (itemNew.WasherDosingProducts) {
		    //            $.each(itemNew.WasherDosingProducts, function (index, item) {
		    //                var washerdosingproducts = $.grep(data.GetChemicalList, function (type) { return type.ControllerEquipmentSetupId == item.ControllerEquipmentSetupId && type.ProductId == item.ProductId });
		    //                item.ControllerEquipmentTypeId = washerdosingproducts[0].ControllerEquipmentTypeId;
		    //            })
		    //        }
		    //    })
		    //}
			this.Views.conventionalProductsGrid.setData(data);
		} else {
			if (!this.isDirty)
				this.isDirty = this.settings.accountInfo.DirtyFlag;
			this.settings.accountInfo.DirtyFlag = false;
			this.settings.accountInfo.FileName = "Formula";
			this.RedirctTab();
		}
	},
	onConventionalProductGridViewFailed: function (errorData) {
		// this.settings.accountInfo.FileName = "conventionalProductsGrid";
		this.Views.conventionalProductsGrid.showMessage("Unable to Fetch the data.");
	},

	onCompareFormulaViewClicked: function (washerGroupId, formulaId) {
	    this.Model.getCompareFormulaData(washerGroupId, formulaId);
	},

	onGetCompareFormulaData: function (data) {
	    this.Views.WasherGroupFormulaTabsView.setCompareFormulaView(data);
	},

	onDispenserAndFormulaChange: function (formulaId, controllerId, washerGroupId, washerId) {
	    this.Model.getDispenserAndFormulaChangeData(formulaId, controllerId, washerGroupId, washerId);
	},

	onGetDispenserAndFormulaChangeData: function (data) {
	    this.Views.WasherGroupFormulaTabsView.setCompareFormulaView(data);
	},

	onSendSettingsClicked: function (formulaId, controllerId, washerGroupId, washerId) {
	    this.Model.onSaveSettings(formulaId, controllerId, washerGroupId, washerId);
	},

	onSaveSettingsSuccess: function (data) {
	    this.Views.WasherGroupFormulaTabsView.setCompareFormulaView(data);
	},

	onSaveFormulaInjections: function (isSaveAndClose) {
		var gridView = this.Views.conventionalProductsGrid;
		if (gridView.validateWasherStep()) {
			var productsGridData = gridView.getProductsGridViewData();
			this.Model.onSaveFormulaInjections(productsGridData, isSaveAndClose, productsGridData.ProgramSetupId);
		}
	},

	onproductsgridViewDataSuccess: function (data, isSaveAndClose, formulaId) {
		if (!isSaveAndClose) {
			this.onProductGridViewRefresh(formulaId);

			this.Views.conventionalProductsGrid.showMessage(data);
		} else {
			this.onEditFormulaClicked(formulaId);
		}
	},
	onproductsgridViewDataFailed: function (errorData, formulaId) {
		this.Views.conventionalProductsGrid.showMessage(data);
	},

	onClearProductsCache: function () {
		this.settings.accountInfo.ConventionalProductsList = [];
	},

	onProductGridViewRefresh: function (id) {
		var _this = this;

		this.FormulaId = id;
		var washerGroupId = this.washerGroupOutPutId;
		if (washerGroupId == undefined)
			washerGroupId = _this.getQueryStringByName('id');
		this.Model.ProductGridViewRefresh(washerGroupId, id, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.RegionId);
	},
	onProductGridViewRefreshDataRecieved: function (data) {
		this.settings.accountInfo.FileName = "conventionalProductsGrid";
		this.Views.conventionalProductsGrid.setData(data);
	},

	onFourmulaNumberChanged: function (formulaId, newformulaId) {
		this.dropDownChangeFromulaId = formulaId;
		this.dropDownNewFormulaId = newformulaId;
		if (this.settings.accountInfo.DirtyFlag) {
			this.isDirty = this.settings.accountInfo.DirtyFlag;
			this.settings.accountInfo.DirtyFlag = false;
		}
		return this.RedirctTab("conventionalGrid");
	},

	onDropDownFormulaChanged: function () {
		var addEditFormulaView = this.Views.AddEditFormulaView;
		this.isDirty = false;
		if (addEditFormulaView) {
			if (addEditFormulaView.validateFormula()) {
				var formulaData = this.Views.AddEditFormulaView.getFormulaData();
				formulaData.Id = this.dropDownChangeFromulaId;
				var _this = this;
				formulaData.ProgramId = this.programId;
				formulaData.WasherGroupId = this.washerGroupOutPutId;
				if (formulaData.WasherGroupId == undefined)
					formulaData.WasherGroupId = _this.getQueryStringByName('id');

				this.Model.updateFormulaOnDropDownChange(formulaData);
				return true;
			} else {
				$("#ddlFormulaNumber").val(this.dropDownChangeFromulaId);
				$("#ddlFormulaNumber").next(".holder").text($("#ddlFormulaNumber option:selected").text());
				return false;
			}
		}
	},

	onDropDownChangeFormulaUpdated: function (data, formulaData) {
		var id = this.dropDownChangeFromulaId;
		var washerGroupId = this.washerGroupOutPutId;

		//this.message = '<label data-localize ="FIELD_FORMULAUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>';
		this.onDropDownChangeSaveWashSteps(id);
		this.onEditFormulaClicked(this.dropDownNewFormulaId);
		this.dropDownChangeFromulaId = 0;
		this.dropDownNewFormulaId = 0;
		this.settings.accountInfo.ConventionalProductsList = [];
	},

	onDropDownChangeSaveWashSteps: function (id) {
		var washStepview = this.Views.AddEditFormulaView;
		var productsView = this.Views.ConventionalProducts;
		var washStepData;
		var washStepLength;

		if (washStepview.validateFormula()) {
			washStepData = washStepview.getWashStepData();
			washStepLength = washStepData.length;
			if (washStepLength) {
				if (id)
					washStepData[0].ProgramSetupId = id;
				//formulaId = washStepLength? washStepData[0].ProgramSetupId:formulaId;
				if (id > 0) {
					if (this.settings.accountInfo.ConventionalProductsList) {
						var productsleng = this.settings.accountInfo.ConventionalProductsList.length;
						if (productsleng > 0) {
							if (productsView.validateWasherStep() && washStepLength != null && washStepData != null)
								for (var j = 0; j < washStepLength; j++) {
									for (var i = 0; i < productsleng; i++) {
										if (this.settings.accountInfo.ConventionalProductsList[i] && this.settings.accountInfo.ConventionalProductsList[i].StepNumber == washStepData[j].StepNumber && this.settings.accountInfo.ConventionalProductsList[i].IsUpdated) {
											if (washStepData[j].WashOperation == "Extract" || washStepData[j].WashOperation == "Drain") {
												this.settings.accountInfo.ConventionalProductsList[i] = undefined;
											} else {
												washStepData[j].WasherDosingProducts = this.settings.accountInfo.ConventionalProductsList[i];
											}
										}
									}
								}
						}
					}
				}
				this.Model.onChangeDropDownSaveWashSteps(washStepData, id);
			} else {
				this.Views.AddEditFormulaView.showMessage('<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAUPDATEDSUCCESSFULLY', "Formula updated successfully.") + '</label>');
			}
		} else {
			return false;
		}
	},

	onChangeDropDownWashStepgridViewDataSuccess: function (data, formulaId) {
		this.onEditFormulaClicked(this.dropDownNewFormulaId);
	},
	onWashStepgridViewDataFailed: function (description) {
		if (description == 51030) {
			this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSCOUNTDOESNTMATCH', "Record Count not Match...Resynch is in progress.") + '</label>');
		} else if (description == 51060) {
		    this.Views.AddEditFormulaView.showMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', "Unable to save changes , Connectivity issue, Please try again later.") + '</label>');
		} else if (description == 60000) {
			this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSNOTINSYNCH', "Record not in synch..Resynch is in progress.") + '</label>');
		}
		else if (description == 51000) {
		    this.Views.AddEditFormulaView.showMessage('<label class="k-error-message">Maximum Number of programs that can be associated to a WasherGroup already defined. </label>');
		}
	},

	initImportFormulaView: function () {
		var thisObject = this;
		if (!thisObject.Views.importFormula) {
			thisObject.Views.importFormula = new Ecolab.Views.ImportFormula({
			    containerSelector: "#tabFormulaContainer",
				accountInfo: thisObject.settings.accountInfo,
				eventHandlers: {
					//rendered: function () { thisObject.onImportFormulaViewRendered(); },
					onSaveFormulaClicked: function (data) { thisObject.onSaveFormulaClicked(data); },
					onCancelClicked: function (e) { thisObject.onCancelImportFormulaClicked(e); },
				}
			});
		}
	},

	initSubstituteChemicalView: function () {
	    var thisObject = this;
	    if (!thisObject.Views.SubstituteMissingChemical) {
	        thisObject.Views.SubstituteMissingChemical = new Ecolab.Views.SubstituteMissingChemical({
	            containerSelector: "#tabSubstituteMissingChemicalContainer",
	            accountInfo: thisObject.settings.accountInfo,
	            eventHandlers: {
	                rendered: function () { thisObject.onSubstituteChemicalViewRendered(); },
	                onSaveSubstituteChemicalClicked: function (data) { thisObject.onSaveSubstituteChemicalClicked(data); },
	                onCancelSubstituteChemicalsClicked: function (e) { thisObject.onCancelSubstituteChemicalsClicked(e); },
	            }
	        });
	    }
	},
	onImportFormulaClicked: function (nextAvailableFormulaNo) {
		var _this = this;
		var washerGroupId = this.washerGroupOutPutId;
		this.settings.accountInfo.NextAvailableFormulaNo = nextAvailableFormulaNo;
		if (washerGroupId == undefined)
			washerGroupId = _this.getQueryStringByName('id');
		this.Model.GetImportFormula(this.settings.accountInfo.EcolabAccountNumber, washerGroupId, this.settings.accountInfo.RegionId);
	},

	onGetImportFormulaDataRecieved: function (data) {
		var _this = this;
		var washerGroupId = this.washerGroupOutPutId;
		if (washerGroupId == undefined)
			washerGroupId = _this.getQueryStringByName('id');
		data.WasherGroupFormulaNumbers[0].WasherGroupId = washerGroupId;
		data.WasherGroupFormulaNumbers[0].NextAvailableFormulaNo = this.settings.accountInfo.NextAvailableFormulaNo;
		this.Views.importFormula.setData(data);
	},
	onCancelImportFormulaClicked: function () {
	    this.onFormulaTabClick();
	},
	onCancelSubstituteChemicalsClicked: function () {
		$('#myModal').modal('hide');
	},
	onSubstituteChemicalViewRendered: function () {
		$('#myModal').modal({
			show: true,
			backdrop: 'static',
			keyboard: false
		});
	},
	onSaveFormulaClicked: function (data) {
		var _this = this;
		var washerGroupId = this.washerGroupOutPutId;
		if (washerGroupId == undefined)
			washerGroupId = _this.getQueryStringByName('id');
	    $.each(data, function (i, v) {
	        v.ToWasherGroupId = washerGroupId;
	        v.EcolabAccountNumber = _this.settings.accountInfo.EcolabAccountNumber;
	    });
	    var findmissingChemicalData = { FormulaList: data };
	    _this.importFormulaDetails = data;
	    _this.Model.findMissingChemicals(findmissingChemicalData);
	},
	onSaveSubstituteChemicalClicked: function (data) {
		var _this = this;
		var saveData = { FormulaList: _this.importFormulaDetails, MissingChemicalList: data };
		this.Model.SaveCopyFormula(saveData)
	},
	onCopyFormulaCreated: function (formulaId, formulaData, isSaveAndClose) {
		
		if (formulaId == 60000) {
		    this.listMessage = '<label class="k-error-message">Record not in synch..Resynch is in progress. </label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (formulaId == 51030) {
		    this.listMessage = '<label class="k-error-message">Record count does not match..Resynch is in progress. </label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (formulaId == 51000) {
		    this.listMessage = '<label class="k-error-message">Maximum Number of programs that can be associated to a WasherGroup already defined. </label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (formulaId == 51001) {
		    this.listMessage = '<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (formulaId == 51002) {
		    this.listMessage = '<label class="k-error-message">Error occurred associating formula to the conventional washer group. </label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (formulaId == 51003) {
		    this.listMessage = '<label data-localize ="FIELD_YOUCANNOTCOPYFORMULASINCETUNNELSETTINGSARENOTIDENTICAL" class="k-error-message">You cannot copy formula since Tunnel settings are not identical.</label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (formulaId == 51033) {
            this.onCancelImportFormulaClicked();
            this.onCancelSubstituteChemicalsClicked();
            this.listMessage = '<label data-localize ="FIELD_FORMULAIMPORTEDSUCCESSFULLY" class="k-success-message">Formula Imported Successfully.</label>';
		}
		else {
		    this.listMessage = '<label data-localize ="FIELD_FORMULAIMPORTEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_FORMULAIMPORTEDSUCCESSFULLY', "Formula Imported successfully.") + '</label>';
		    this.onCancelImportFormulaClicked();
		    this.onCancelSubstituteChemicalsClicked();
		}
	},
	onCopyFormulaCreationFailed: function (error, description) {
	    if (description == 51000) {
	        this.listMessage = '<label class="k-error-message">Maximum Number of programs that can be associated to a WasherGroup already defined. </label>';
	        this.onCancelImportFormulaClicked();			
		}
	    else if (description == 60000) {
	        this.listMessage = '<label class="k-error-message">Record not in synch..Resynch is in progress. </label>';
	        this.onCancelImportFormulaClicked();
	        this.onCancelSubstituteChemicalsClicked();
	    } else if (description == 51060) {
	        this.listMessage = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', "Unable to save changes , Connectivity issue, Please try again later.") + '</label>';
	        this.onCancelImportFormulaClicked();
	        this.onCancelSubstituteChemicalsClicked();
		}
	    else if (description == 51030) {
	        this.listMessage = '<label class="k-error-message">Record count does not match..Resynch is in progress. </label>';
	        this.onCancelImportFormulaClicked();
	        this.onCancelSubstituteChemicalsClicked();
		}
		else if (description == 51001) {
		    this.listMessage = '<label data-localize ="FIELD_FORMULANUMBERALREADYEXISTS" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULANUMBERALREADYEXISTS', "Formula Number already exits.") + '<label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (description == 51002) {
		    this.listMessage = '<label class="k-error-message">Error occurred associating formula to the conventional washer group. </label>';
		    this.onCancelImportFormulaClicked();			
		}
		else if (description == 51003) {
		    this.listMessage = '<label data-localize ="FIELD_YOUCANNOTCOPYFORMULASINCETUNNELSETTINGSARENOTIDENTICAL" class="k-error-message">You cannot copy formula since Tunnel settings are not identical.</label>';
		    this.onCancelImportFormulaClicked();
		}
		else {
		    this.listMessage = '<label data-localize ="FIELD_FORMULAIMPORTFAILED" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FORMULAIMPORTFAILED', "Formula Import Failed.") + '</label>';
		    this.onCancelImportFormulaClicked();
		    this.onCancelSubstituteChemicalsClicked();		    
		}
	},
	onFindMissingChemicals: function (data) {	    
	    var _this = this;
		if (_this.settings.accountInfo.WasherGroupTypeId == 1 && data[0].length > 0) {
	        this.Views.SubstituteMissingChemical.setData(data);
	    }
	    else if (_this.settings.accountInfo.WasherGroupTypeId == 2 && data[2] == true) {	        
	        this.listMessage = '<label data-localize ="FIELD_YOUCANNOTCOPYFORMULASINCETUNNELSETTINGSARENOTIDENTICAL" class="k-error-message">You cannot copy formula since Tunnel settings are not identical.</label>';
	        this.onCancelImportFormulaClicked();
	    }
	    else {
	        var saveData = { FormulaList: _this.importFormulaDetails, MissingChemicalList: data[0] };	        
	        _this.Model.SaveCopyFormula(saveData);
	    }
	},

	updateConventionalAnalougeControl: function (analogControls) {
		this.Views.AddEditFormulaView.updateConventionalAnalougeControl(analogControls);
	}
}

function findMaxValue(element) {
    var maxValue = undefined;
    $('option', element).each(function () {
        var val = $(this).attr('value');
        val = parseInt(val, 10);
        if (maxValue === undefined || maxValue < val) {
            maxValue = val;
	}
    });
    return maxValue;
}