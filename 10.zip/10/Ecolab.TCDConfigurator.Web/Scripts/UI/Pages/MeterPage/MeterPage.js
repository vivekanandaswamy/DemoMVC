﻿Ecolab.Presenters.MeterPage = function(options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.MeterPage.prototype = {
    initViews: function() {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function() {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function(modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function(eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function() {
        var _this = this;
        return {
            onMeterDataLoaded: function(data) { _this.onMeterDataLoaded(data); },
            onloadUtilityLocationByUtilityIdLoaded: function(data) { _this.loadUtilityLocationDataLoaded(data); },
            onloadOnUtilityLocationChangeDataLoaded: function(data) { _this.loadOnUtilityLocationChangeDataLoaded(data); },
            //onloadParentDataByMeterIdLoaded: function (data) { _this.loadParentDataLoaded(data); },
            onloadMeterOnAddNewPopupDataLoaded: function(data) { _this.loadMeterOnAddNewPopupDataLoaded(data); },
            onloadUOMDataLoaded: function(data) { _this.loadUOMDataLoaded(data); },
            onloadMeterOnEditPopupDataLoaded: function (data) { _this.loadMeterOnEditPopupDataLoaded(data); },
            onMachineCompartmentChangeLoaded: function (data) { _this.onMachineCompartmentChangeLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); },
            onExternalAndInternalCountersFetched: function (data) { _this.onExternalAndInternalCountersFetched(data); }
        };
    },
    afterInit: function() {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function() {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
            {
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function() {},
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function() {
        var _this = this;
        if (!this.Views.MeterView) {
            this.Views.MeterView = new Ecolab.Views.Meter(
            {
                containerSelector: '#tabMeterContainer',
                eventHandlers: {
                    rendered: function() { _this.loadMeterData(); },
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                    onUtilityTypeChange: function(utilityId, id) { _this.loadUOMByUtilityTypeId(utilityId, id); },
                    onUtilityLocationChange: function(id) { _this.loadOnUtilityLocationChange(id); },
                    onAddNewMeterPopupLoad: function() { _this.loadMeterOnAddNewPopupLoad(); },
                    onMeterEditPopupLoad: function(id) { _this.loadMeterOnEditPopupLoad(id); },
                    loadOnMachineCompartmentChange: function (locationId, machineId) { _this.loadOnMachineCompartmentChange(locationId, machineId); },
                    savePage: function () { _this.savePage() },
                    setIsDirty: function (flag) { _this.setIsDirty(flag); },
                    onSaveChangesForMeters: function (data, e, wnd, detailsTemplate, detailsTemplateView, obj, dataSource, IsDelete) { return _this.SaveChangesForMeters(data, e, wnd, detailsTemplate, detailsTemplateView, obj, dataSource, IsDelete); },
                    fetchExternalAndInternalCounters: function (locatioId, washerId) { _this.fetchExternalOrInternalCounters(locatioId, washerId); }
                }
            });
            this.Views.MeterView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function() {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function(id) {
    },
    loadMeterData: function() {

        this.Model.loadMeterData();
    },
    onMeterDataLoaded: function(data) {
        this.Views.MeterView.setMeterData(data);
    },
    loadOnUtilityLocationChange: function(utilityLocationId) {
        this.Model.loadOnUtilityLocationChange(utilityLocationId);
    },
    loadOnUtilityLocationChangeDataLoaded: function(data) {
        this.Views.MeterView.SetOnUtilityLocationChangedData(data);
    },

    loadMeterOnAddNewPopupLoad: function() {
        this.Model.loadMeterOnAddNewPopupLoad();
    },
    loadMeterOnAddNewPopupDataLoaded: function(data) {
        this.Views.MeterView.setMeterOnAddNewPopupLoadData(data);
    },

    loadUOMByUtilityTypeId: function(utilityId, id) {
        this.Model.loadUOMByUtilityTypeId(utilityId, id);
    },
    loadUOMDataLoaded: function(data) {
        this.Views.MeterView.SetUOMData(data);
    },

    loadMeterOnEditPopupLoad: function(meterId) {
        this.Model.loadMeterOnEditPopupLoad(meterId);
    },
    loadMeterOnEditPopupDataLoaded: function(data) {
        this.Views.MeterView.SetMeterOnEditPopupLoad(data);
    },
    loadOnMachineCompartmentChange: function(locationId, machineId) {
        this.Model.loadOnMachineCompartmentChange(locationId, machineId);
    },
    onMachineCompartmentChangeLoaded: function(data) {
        this.Views.MeterView.onMachineCompartmentChangeLoaded(data);
    },
    savePage: function () {
        this.Views.MeterView.savePage();
    },
    setIsDirty: function (flag) {
        this.isDirty = flag;
    },
    deletedPage: function (e, data, wnd, detailsTemplate, _this) {
        this.Views.MeterView.onDelete(e, data, wnd, detailsTemplate, _this);
    },
    fetchExternalOrInternalCounters: function (locationId, washerId) {
        this.Model.fetchExternalOrInternalCounters(locationId, washerId);
    },
    onExternalAndInternalCountersFetched: function (data) {
        this.Views.MeterView.onExternalAndInternalCountersFetched(data);
    }
};