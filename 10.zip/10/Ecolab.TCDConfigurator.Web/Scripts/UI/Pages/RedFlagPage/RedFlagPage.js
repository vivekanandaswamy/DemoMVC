Ecolab.Presenters.RedFlagPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.RedFlagPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onRedFlagDataLoaded: function (data) { _this.onRedFlagDataLoaded(data); },
            onAddRedFlagDataLoaded: function (data) { _this.onAddRedFlagDataLoaded(data); },
            onEditRedFlagDataLoaded: function (data) { _this.onEditRedFlagDataLoaded(data); },
            onItemChangedDataLoaded: function (data) { _this.onItemChangedDataLoaded(data); },
            onLocationChangedDataLoaded: function (data) { _this.onLocationChangedDataLoaded(data); },
            onCategoryChangedDataLoaded: function (data) { _this.onCategoryChangedDataLoaded(data); },
            onLocationChangedDataLoadedMeter: function (data, itemId) { _this.onLocationChangedDataLoadedMeter(data, itemId); },
            onLocationChangedDataLoadedSensor: function (data) { _this.onLocationChangedDataLoadedSensor(data); },

            onLocationChangedDataLoadedFormulaCategory: function (data) { _this.onLocationChangedDataLoadedFormulaCategory(data); },
            onFormulaCategoryChangedDataLoaded: function (data) { _this.onFormulaCategoryChangedDataLoaded(data); },
            onFormulaChangeProductsdDataLoaded: function (data) { _this.onFormulaChangeProductsdDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
        this.loadRedFlagData();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.RedFlagView) {
            this.Views.RedFlagView = new Ecolab.Views.RedFlag({
                containerSelector: '#tabRedFlagContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    onAddRedFlagClicked: function () { _this.onAddRedFlagClicked(); },
                    onEditRedFlagClicked: function (id) { _this.onEditRedFlagClicked(id); },
                    onDeleteRedFlagClicked: function (id) { _this.onDeleteRedFlagClicked(id); },
                    onItemChanged: function (id, isEdit) { _this.onItemChanged(id, isEdit); },
                    onLocationChanged: function (id, itemId, locationId) { _this.onLocationChange(id, itemId, locationId); },
                    onCategoryChanged: function (categoryId) { _this.onCategoryChange(categoryId); },
                    onLocationChangedMeter: function (id, itemId, locationId) { _this.onLocationChangeMeter(id, itemId, locationId); },
                    onLocationChangedSensor: function (id, itemId, locationId) { _this.onLocationChangeSensor(id, itemId, locationId); },
                    onLocationChangedFormulaCategory: function (id, itemId, locationId) { _this.onLocationChangeFormulaCategory(id, itemId, locationId); },
                    onFormulaCategoryChanged: function (groupTypeId, formulaCategoryId) { _this.onFormulaCategoryChange(groupTypeId, formulaCategoryId); },
                    onFormulaChangedProducts: function (groupTypeId, formulaId) { _this.onFormulaChangeProducts(groupTypeId, formulaId); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    setIsDirtyFlag: function (flag) { return _this.setIsDirtyFlag(flag); },
                    onSaveChangesForRedFlag: function (data, e, wnd, detailsTemplate, detailsTemplateView, allowEdit, IsDelete, obj, grid) { return _this.SaveChangesForRedFlag(data, e, wnd, detailsTemplate, detailsTemplateView, allowEdit, IsDelete,obj, grid); }
                }
            });
            this.Views.RedFlagView.setData(this.settings.accountInfo);
        }
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    loadRedFlagData: function () {
        //this.Model.loadRedFlagData();
    },
    onRedFlagDataLoaded: function (data) {
        this.Views.RedFlagView.setRedFlagData(data);
    },
    onAddRedFlagClicked: function () {
        this.Model.loadItemData();
    },
    onAddRedFlagDataLoaded: function (data) {
        this.Views.RedFlagView.SetOnAddRedFlagDataLoaded(data);
    },
    onEditRedFlagClicked: function (id) {
        this.Model.onEditRedFlagClicked(id);
    },
    onEditRedFlagDataLoaded: function (data) {
        this.Views.RedFlagView.SetOnEditRedFlagDataLoaded(data);
    },
    onDeleteRedFlagClicked: function (id) {
        this.Model.onDeleteRedFlagClicked(id);
    },
    onDeleteRedFlagResponseLoaded: function (data) {
        ///
    },
    onItemChanged: function (id, itemId) {
        this.Model.loadOnItemChangedData(id, itemId);
    },
    onItemChangedDataLoaded: function (data) {
        this.Views.RedFlagView.SetOnItemChangedDataLoaded(data);
    },

    onLocationChange: function (id, itemId, locationId) {
        this.Model.loadOnLocationChangedData(id, itemId, locationId);
    },
    onLocationChangedDataLoaded: function (data) {
        this.Views.RedFlagView.SetOnLocationChangedDataLoaded(data);
    },

    onLocationChangeFormulaCategory: function (id, itemId, locationId) {
        this.Model.loadOnLocationChangedFormulaCategory(id, itemId, locationId);

    },
    onLocationChangedDataLoadedFormulaCategory: function (data) {     
        this.Views.RedFlagView.SetOnLocationChanged(data);
    },

    onFormulaCategoryChange: function (locationId, id) {
        this.Model.loadOnFormulaCategoryChanged(locationId, id);

    },
    onFormulaCategoryChangedDataLoaded: function (data) {        
        this.Views.RedFlagView.SetOnFormulaCategoryChanged(data);
    },

    onFormulaChangeProducts: function (locationId, formulaId) {

        this.Model.loadOnProductsFormulaChanged(locationId, formulaId);
    },

    onFormulaChangeProductsdDataLoaded: function (data) {
        this.Views.RedFlagView.SetOnFormulaChanged(data);
    },
    savePage: function () {
        this.Views.RedFlagView.savePage();
    },
    setIsDirtyFlag: function (flag) {
        this.isDirty = flag;
    },
    onCategoryChangedDataLoaded: function (data) {
        this.Views.RedFlagView.SetOnAddRedFlagListDataLoaded(data);
    },
    onCategoryChange: function (categoryId) {
        this.Model.loadRedFlagItemList(categoryId);
    },
    onLocationChangeMeter: function (locationId, itemId) {
        this.Model.loadOnLocationChangedDataMeter(locationId, itemId);
    },
    onLocationChangeSensor: function (locationId) {
        this.Model.loadOnLocationChangedDataSensor(locationId);
    },
    onLocationChangedDataLoadedMeter: function (data,itemId) {
        this.Views.RedFlagView.SetOnLocationChangedDataLoadedMeter(data, itemId);
    },
    onLocationChangedDataLoadedSensor: function (data) {
        this.Views.RedFlagView.SetOnLocationChangedDataLoadedSensor(data);
    },
    deletedPage: function (e, data, wnd, detailsTemplate, _this, grid) {
        this.Views.RedFlagView.onDelete(e, data, wnd, detailsTemplate, _this, grid);
    },
};