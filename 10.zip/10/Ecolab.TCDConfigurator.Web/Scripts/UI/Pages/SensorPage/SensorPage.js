﻿Ecolab.Presenters.SensorPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.SensorPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onSensorDataLoaded: function (data) { _this.onSensorDataLoaded(data); },
            loadUoMCallBack: function (data) { _this.loadUomCallBackLoaded(data); },
            onloadMachineCompartmentByUtilityLocationIdLoaded: function (data) { _this.loadMachineCompartmentDataLoaded(data); },
            loadDefaultDataLoaded: function (data) { _this.loadDefaultDataLoadedCallback(data); },
            onloadSensorOnAddNewPopupDataLoaded: function (data) { _this.loadSensorOnAddNewPopupDataLoaded(data); },
            onMachineCompartmentChangeLoaded: function (data) { _this.onMachineCompartmentChangeLoaded(data); },
            onControllerChangeLoaded: function (data) { _this.onControllerChangeLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); },
            onExternalAndInternalCountersFetched: function (data) { _this.onExternalAndInternalCountersFetched(data); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.SensorView) {
            this.Views.SensorView = new Ecolab.Views.Sensor(
                        {
                            containerSelector: '#tabSensorContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadSensorData(); },
                                onUtilityTypeChange: function (id) { _this.loadUoM(id); },
                                onUtilityLocationChange: function (id) { _this.loadMachineCompartmentByUtilityLocationId(id); },
                                onEditSensorPopupLoad: function (id) { _this.loadDefaultData(id) },
                                onAddNewSensorPopupLoad: function () { _this.loadSensorOnAddNewPopupLoad(); },
                                checkDuplicates: function () { return _this.HasDuplicateTags(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                loadOnMachineCompartmentChange: function (locationId, machineId) { _this.loadOnMachineCompartmentChange(locationId, machineId); },
                                loadOnControllerChange: function (locationId, machineId, controllerId) { _this.loadOnControllerChange(locationId, machineId, controllerId); },
                                savePage: function () { _this.savePage(); },
                                setIsDirty: function (flag) { _this.setIsDirty(flag); },
                                onSaveChangesForSensors: function (data, e, wnd, detailsTemplate, detailsTemplateView, allowEdit, obj, IsDelete) { return _this.SaveChangesForSensors(data, e, wnd, detailsTemplate, detailsTemplateView, allowEdit, obj, IsDelete); },
                                fetchExternalAndInternalCounters: function (locatioId, washerId, sensorId) { _this.fetchExternalOrInternalCounters(locatioId, washerId, sensorId); }
                            }
                        });
            this.Views.SensorView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadSensorData: function () {
        this.Model.loadSensorData();
    },
    onSensorDataLoaded: function (data) {
        this.Views.SensorView.setSensorData(data);
    },
    loadUoM: function (UtilityId) {
        this.Model.loadUoMModel(UtilityId);
    },
    loadUomCallBackLoaded: function (data) {
        this.Views.SensorView.SetUoMData(data);
    },
    loadMachineCompartmentByUtilityLocationId: function (UtilityLocationId) {
        this.Model.loadMachineCompartmentByUtilityLocationId(UtilityLocationId);
    },
    loadMachineCompartmentDataLoaded: function (data) {
        this.Views.SensorView.SetMachineCompartmentData(data);
    },

    loadDefaultData: function (SensorId) {
        this.Model.loadDefaultData(SensorId);
    },
    loadDefaultDataLoadedCallback: function (data) {
        this.Views.SensorView.SetDefaultData(data);
    },
    loadChemicalforChart: function (data) {
        this.Model.loadChemicalforChart(data);
    },
    loadChemicalforChartLoadedCallback: function (data) {
        this.Views.SensorView.SetChemicalforChart(data);
    },

    loadSensorOnAddNewPopupLoad: function () {
        this.Model.loadSensorOnAddNewPopupLoad();
    },
    loadSensorOnAddNewPopupDataLoaded: function (data) {
        this.Views.SensorView.SetDefaultDataOnAdd(data);
    },
    loadOnMachineCompartmentChange: function (locationId, machineId) {
        this.Model.loadOnMachineCompartmentChange(locationId, machineId);
    },
    onMachineCompartmentChangeLoaded: function (data) {
        this.Views.SensorView.onMachineCompartmentChangeLoaded(data);
    },
    loadOnControllerChange: function (locationId, machineId, controllerId) {
        this.Model.loadOnControllerChange(locationId, machineId, controllerId);
    },
    onControllerChangeLoaded: function (data) {
        this.Views.SensorView.onControllerChangeLoaded(data);
    },
    savePage: function () {
        this.Views.SensorView.savePage();
    },
    setIsDirty: function (flag) {
        this.isDirty = flag;
    },
    deletePage: function (e, data, wnd, detailsTemplate, _this) {
        this.Views.SensorView.onDelete(e, data, wnd, detailsTemplate, _this);
    },
    fetchExternalOrInternalCounters: function (locationId, washerId, sensorId)
    {
        this.Model.fetchExternalOrInternalCounters(locationId, washerId, sensorId);
    },
    onExternalAndInternalCountersFetched: function (data) {
        this.Views.SensorView.onExternalAndInternalCountersFetched(data);
    }
};