Ecolab.Presenters.ChemicalPage = function (options) {
	this.settings = $.extend(this.defaults, options);
	var substituteChemicalDetails = [];
};
Ecolab.Presenters.ChemicalPage.prototype = {
	initViews: function () {
		this.base.initViews.call(this);
		this.initPlantSetupTabsView();
		this.initListView();
		this.initSubstituteChemicalView();
	},
	initModel: function () {
		this.base.initModel.call(this);
		this.Model.init();
	},
	addModelOptions: function (modelOptions) {
		this.base.addModelOptions.call(this, modelOptions);
		modelOptions.SizeOfPage = this.settings.pageSize;
	},
	addModelEventHandlers: function (eventHandlers) {
		this.base.addModelEventHandlers.call(this, eventHandlers);
		$.extend(eventHandlers, this.getModelEventHandlers());
	},
	getModelEventHandlers: function () {
		var _this = this;
		return {
			onChemicalDataLoaded: function (data) { _this.onChemicalDataLoaded(data); },
			onInitialized: function () { _this.onModelInitialized(); },
			onGetWasherGroupList: function (data) { _this.onGetWasherGroupList(data); },
			onGetUnUsedPlantChemicalList: function (data) { _this.onGetUnUsedPlantChemicalList(data); },
			onCheckWasherGroupForProduct: function (data) { _this.onCheckWasherGroupForProduct(data); },
			onSaveSubstitueChemical: function (data) { _this.onSaveSubstitueChemical(data); }
			};
	},
	afterInit: function () {
		this.base.afterInit.call(this);
		this.showMainHeader();
		this.Model.loadChemicalData();
		this.onPageRendered();
	},
	initPlantSetupTabsView: function () {
		var _this = this;
		if (!this.Views.PlantSetupTabsView) {
			this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                        	containerSelector: '#pageContainer',
                        	eventHandlers: {
                        		rendered: function () { },
                        		onRedirection: function (url) { return _this.RedirectLocation(url); }
                        	}
                        });
		}
		this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
	},
	initListView: function () {
		var _this = this;
		if (!this.Views.ChemicalView) {
			this.Views.ChemicalView = new Ecolab.Views.Chemical(
                        {
                        	containerSelector: '#tabChemicalsContainer',
                        	eventHandlers: {
                        		onRendered: function () { },
                        		onRedirection: function (url) { return _this.RedirectLocation(url); },
                        		onSaveChangesForChemical: function (data, e, wnd, detailsTemplate, isDeleted, obj) { return _this.SaveChangesForChemical(data, e, wnd, detailsTemplate, isDeleted, obj); },
                        		onChemicalNameChange: function (request, callBack) { _this.loadChemicals(request, callBack); },
                        		onRuleClicked: function (id) { _this.navigateToConfigPage(id); },
                        		onSubstituteChemicalClicked: function (dataItem) { return _this.onSubstituteChemicalClicked(dataItem); }
                        	}
                        });
		}
	},
	onPageRendered: function () {
		var breadCrumbData = {};
		breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
		breadCrumbData.url = "/PlantSetup";
		this.showPlantBreadCrumb("plantSets", breadCrumbData);
	},
	navigateToConfigPage: function (id) {
	},
	loadChemicalDataData: function () {
		this.Model.loadChemicalData();
	},
	onChemicalDataLoaded: function (data) {
		this.Views.ChemicalView.setData(this.settings.accountInfo);
	},
	loadChemicals: function (request, callBack) {
		this.Model.loadChemicals(request, callBack);
	},
	initSubstituteChemicalView: function () {
		var thisObject = this;
		if (!thisObject.Views.SubstituteChemical) {
			thisObject.Views.SubstituteChemical = new Ecolab.Views.SubstituteChemical({
				containerSelector: "#tabSubstitueChemicalContainer",
				accountInfo: thisObject.settings.accountInfo,
				eventHandlers: {
					rendered: function () { thisObject.onSubstitueChemicalViewRendered(); },
					onSaveSubstitueChemicalClicked: function (data) { thisObject.onSaveSubstitueChemicalClicked(data); },
					onCancelClicked: function (e) { thisObject.onCancelSubstitueChemicalClicked(e); },
					onFromWasherGroupChanged: function (washerGroupId) { thisObject.onFromWasherGroupChanged(washerGroupId); },
				}
			});
		}
	},
	onSubstitueChemicalViewRendered: function () {
		var noEdits = this.SaveChangesForChemicalSubstitution();
		if (noEdits) {
			$('#myModal').modal({
				show: true,
				backdrop: 'static',
				keyboard: false
			});
		}
	},
	onSaveSubstitueChemicalClicked: function (data) {
		var _this = this;
		_this.Model.CheckWasherGroupForProduct(data);
	},
	onCancelSubstitueChemicalClicked: function () {
		$('#myModal').modal('toggle');
	},
	onSubstituteChemicalClicked: function (dataItem) {
		var _this = this;
		_this.substituteChemicalDetails = dataItem;
		_this.Model.GetWasherGroupList();
	},
	onGetWasherGroupList: function (dataItem) {
		var _this = this;
		var data = [];
		data = dataItem;
		data.SubstituteChemicalDetails = _this.substituteChemicalDetails;
		this.Views.SubstituteChemical.setData(data);
	},
	onFromWasherGroupChanged: function (washerGroupId) {
		var _this = this;
		_this.Model.GetUnUsedPlantChemicalList(washerGroupId);
	},
	onGetUnUsedPlantChemicalList: function (data) {
		var _this = this;
		this.Views.SubstituteChemical.LoadProducts(data);
	},
	onCheckWasherGroupForProduct: function (data) {
		var _this = this;

		if (data.WasherGroupIds.length > 0) {
			var _this = this;
			var Cdialog = $('#ConfirmDialog');
			Cdialog.removeClass('hide');
			var dialogOptions = {
				HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATION', 'Confirmation'),
				BodyMessage: $.GetLocaleKeyValue('FIELD_CHEMICALWILLBESUBSTITUTEDINALLTHECONNECTEDWASHERGROUPSDOYOUWANTTOCONTINUE', 'Chemical will be substituted in all the connected washer groups. Do you want to continue?'),
				Buttons: {
					Yes: {
						Callback: function () {
							_this.saveSubstitueChemical(data);
							Cdialog.addClass('hide');
						},

						CallbackParameters: null
					},
					No: {
						Callback: function () {
							Cdialog.addClass('hide');
						},
						CallbackParameters: null
					}
				}
			};
			this.Views.confirmDialog.setData(dialogOptions);
		}
		else {
			_this.saveSubstitueChemical(data);
		}
	},
	saveSubstitueChemical: function (data) {
		var _this = this;
		if (_this.Views.SubstituteChemical && _this.Views.SubstituteChemical.validate()) {
			_this.Model.SaveSubstitueChemical(data);
		}
	},
	onSaveSubstitueChemical: function (data) {
		var _this = this;
		if (data == 0 || data == 51030) {
			_this.onCancelSubstitueChemicalClicked();
			this.Views.ChemicalView.showMessage('<label data-localize ="FIELD_CHEMICALSUBSTITUTEDSUCCESSFULLY" class="k-success-message">Chemical substituted successfully.</label>')
		}		
		else {
			_this.onCancelSubstitueChemicalClicked();
			this.Views.ChemicalView.showMessage('<label data-localize ="FIELD_CHEMICALSUBSTITUTIONFAILED" class="k-error-message">Chemical substitution failed.</label>');
		}
	},

	savePage: function () {

	    $("#btnSave").click();
	    this.isDirty = false;
	},

	deletedPage: function (e, data, wnd, detailsTemplate,_this) {
	    this.Views.ChemicalView.onDelete(e, data, wnd, detailsTemplate,_this);
	}
};