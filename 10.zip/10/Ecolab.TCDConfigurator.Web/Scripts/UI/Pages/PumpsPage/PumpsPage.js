// JavaScript source code
Ecolab.Presenters.PumpsPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.products = null;
    this.pumpProducts = null;
    this.evnt = null;
    this.data = null;
    this.massage = null;
    this.controllerName = null;
    var compartmentValveData = null;
    var washerGroupTypeId = null;
};
Ecolab.Presenters.PumpsPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPumpsTabsView();
        this.initPumpsView();
        this.initPumpsEditView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onPumpsDataLoaded: function (data) { _this.onPumpsDataLoaded(data); },
            onProductsLoaded: function (products) { _this.onProductsLoaded(products); },
            onPumpProductsLoaded: function (pumpProducts) { _this.onPumpProductsLoaded(pumpProducts); },
            onPumpTypesLoaded: function (pumpTypes) { _this.onPumpTypesLoaded(pumpTypes); },
            onLineDataLoaded: function (lineData, isEdit) { _this.onLineDataLoaded(lineData, isEdit); },
            onControllerDataLoaded: function (data) { _this.onControllerDataLoaded(data); },
            onPumpUpdated: function (data, isSaveAndClose) { _this.onPumpUpdated(data, isSaveAndClose); },
            onPumpUpdatedEdit: function (data, isSaveAndClose) { _this.onPumpUpdatedEdit(data, isSaveAndClose); },
            onPumpUpdationFailed: function (error, description) { _this.onPumpUpdationFailed(error, description); },
            onPumpUpdationFailedEdit: function (error, description, data) { _this.onPumpUpdationFailedEdit(error, description, data); },
            onControllerNameLoaded: function (name) { _this.onControllerNameLoaded(name); },
            upDateIsDirty: function () { _this.upDateIsDirty(); },
            onValidateSuccess: function (data, isSaveAndClose) { _this.validateSuccess(data, isSaveAndClose); },
            onValidateFailed: function (error, description, localData) { _this.validateFailed(error, description, localData); },
            onGetCompartmentValveData: function (data, isEdit) { _this.onGetCompartmentValveData(data, isEdit); },
            onloadAuxiliaryData: function (data) { _this.onloadAuxiliaryData(data) },
            onCreatePumpsChemicalDetails: function (chemicalData, Window) { _this.onCreatePumpsChemicalDetails(chemicalData, Window); },
            onCreatePumpsChemicalFialedDetails: function (error, description, Window) { _this.onCreatePumpsChemicalFialedDetails(error, description, Window) }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },

    initPumpsTabsView: function () {
        var _this = this;

        if (!this.Views.PumpsTabView) {
            this.Views.PumpsTabView = new Ecolab.Views.ControllerSetupTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () {
                        _this.onTabsRendered(); //_this.loadControllerModelDataData(_this.settings.accountInfo.RegionId);
                    },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    setupTabClicked: function () { _this.onSetupTabClicked(); },
                    onBackButtonClick: function () { _this.onBackButtonClick(); },
                    setIsInlineGridEdit: function (flage) { _this.setIsInlineGridEdit(flage); }
                }
            });
        }
        if (this.settings.accountInfo.ControllerId != "-1") {
            var cData = {};
            cData.ControllerId = this.settings.accountInfo.ControllerId;
            cData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
            cData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
            _this.findContainer('Controllers', cData.ControllerId, 0);
            this.Views.PumpsTabView.setController(cData);
        }
        this.Views.PumpsTabView.setData(this.settings.accountInfo);
    },

    initPumpsView: function () {
        var _this = this;
        if (!this.Views.PumpsViews) {
            this.Views.PumpsViews = new Ecolab.Views.Pumps({
                containerSelector: '#tabPumpListContainer',
                dynamicHTMLSelector: '#contentControllerParameters',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onDropDownChange: function (option) { _this.onDropDownChange(option); },
                    onEditPumpClicked: function (e, data) { _this.onEditPumpClicked(e, data); },
                    onPumpsInlineEditClicked: function (data, isInline, isSaveAndClose) { _this.onPumpsInlineEditClicked(data, isInline, isSaveAndClose); },
                    onEditClicked: function (data, gridData) { _this.onEditClicked(data, gridData);},
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    setIsInlineGridEdit: function (flage) { _this.setIsInlineGridEdit(flage); },
                    savePage: function (isSaveAndClose) {_this.savePage(true, isSaveAndClose);},
                    onSaveChangesForPumps: function (data, gridData, device, obj) {return _this.SaveChangesForPumps(data, gridData, device, obj); }
                    }
            });
        }
    },

    initPumpsEditView: function () {
        var _this = this;
        if (!this.Views.PumpsEdit) {
            this.Views.PumpsEdit = new Ecolab.Views.PumpsEdit({
                containerSelector: '#tabPumpListContainer',
                dynamicHTMLSelector: '#contentControllerParameters',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { _this.onEditViewRendered(); },
                    onPumpsEditClicked: function (data, isInline) { _this.onPumpsInlineEditClicked(data, isInline, isSaveAndClose); },
                    onClancelClicked: function () { _this.onClancelClicked(); },
                    onLineNumberChanged: function (lineNo) { _this.onLineNumberChanged(lineNo); },
                    onGetAuxiliaryPumpData: function (lineNo) { _this.onGetAuxiliaryPumpData(lineNo); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    upDateIsDirty: function () { _this.upDateIsDirty(); },
                    setIsInlineGridEdit: function (flage) { _this.setIsInlineGridEdit(flage); },
                    savePage: function (isSaveAndClose) {_this.savePage(null, null, isSaveAndClose);},
                    onSaveChangesForPumps: function (data, gridData, device, obj) { return _this.SaveChangesForPumps(data, gridData, device, obj); },
                    onChemicalNameChange: function (request, callBack) { _this.loadChemicals(request, callBack); },
                    createPumpsChemicalDetails: function (requestData, Window) { _this.createPumpsChemicalDetails(requestData, Window); },
                    loadProducts: function () { _this.loadProducts(); },
                }
            });
        }
    },

    onEditViewRendered: function () {
        this.trackChanges();
    },

    loadChemicals: function (request, callBack) {
        this.Model.loadChemicals(request, callBack);
    },

    createPumpsChemicalDetails: function (requestData, Window) {
        this.Model.createPumpsChemicalDetails(requestData, Window);
    },

    onCreatePumpsChemicalDetails: function (chemicalData, Window) {
        this.chemicalData = chemicalData;
        this.Views.PumpsEdit.showCreatePumpsChemicalData(chemicalData, Window);
    },

    onCreatePumpsChemicalFialedDetails: function (error, description, Window) {
        this.Views.PumpsEdit.showCreatePumpsFailedChemicalData(error, description, Window);
    },

    onPumpsDataLoaded: function (data) {
        var _this = this;
        var drData = {};
        var count = data.length;
        var regExp = /\(([^)]+)\)/;
        drData.allowEdit = (this.settings.accountInfo.MaxLevel >= 7);
        drData.massage = this.massage;
        drData.count = count;
        drData.controllerName = this.controllerName;
        var controllerTopicName = regExp.exec(this.controllerName);
        drData.controllerTopicName = controllerTopicName[1];
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.data = data;
        var pumpId = _this.getQueryStringByName('PumpId');
        this.Views.PumpsViews.setData(drData);
        if (pumpId > 0) {
            _this.editPump(pumpId);
        }
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_CONTROLLER SETUP', 'Controller Setup');
        breadCrumbData.url = "/ControllerSetupList";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabsRendered: function () {
        this.getControllerName();
        this.loadProducts();
        this.loadPumpTypes();
        this.loadLineData(1);
        this.loadPumpsData();
        if (this.settings.accountInfo.ControllerModelId == 14) {
            this.loadPumpProductsData();
        }
        this.loadControllerData();
    },

    getControllerName: function () {
        this.Model.getControllerName(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.ControllerId);
    },
    loadPumpsData: function () {
        this.Model.loadPumpsData(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId);
    },

    onDropDownChange: function (option) {
        this.massage = '';
        this.Model.loadPumpsListOnDropdown(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId, option);
    },

    onEditPumpClicked: function (e, data) {
        this.evnt = e;
        this.data = data;
        this.loadProducts();
    },
    loadProducts: function () {
        this.Model.loadProducts(this.settings.accountInfo.EcolabAccountNumber);
    },
    loadPumpProductsData: function () {
        this.Model.loadPumpProductsData(this.settings.accountInfo.ControllerId, this.settings.accountInfo.EcolabAccountNumber);
    },
    loadPumpTypes: function () {
        this.Model.loadPumpTypes();
    },
    loadLineData: function (lineNo, equipmentId) {
        this.Model.loadLineData(lineNo, this.settings.accountInfo.ControllerId, equipmentId);
    },
    onLineNumberChanged: function (lineNo, equipmentId) {
        this.Model.loadLineData(lineNo, this.settings.accountInfo.ControllerId, equipmentId ? equipmentId : 0, true);
    },
    onGetAuxiliaryPumpData: function (lineNo) {
        this.Model.loadAuxiliaryData(lineNo, this.settings.accountInfo.ControllerId);
    },
    onloadAuxiliaryData: function (dosingData) {
        this.dosingData = dosingData;
        this.Views.PumpsEdit.showAuxiliaryData(dosingData);
    },
    onProductsLoaded: function (products) {
        var _this = this;
        this.products = products;
        this.Views.PumpsViews.showEditOnInlineEditLink(this.evnt, this.products, this.data);
    },
    onPumpProductsLoaded: function (pumpProducts) {
        var _this = this;
        this.pumpProducts = pumpProducts;
    },
    onPumpTypesLoaded: function (pumpTypes) {
        this.pumpTypes = pumpTypes;
    },
    onLineDataLoaded: function (lineData, isEdit) {
        this.lineData = lineData;
        if (isEdit) {
            if (this.settings.accountInfo.ControllerModelId == 14) {
                this.Views.PumpsEdit.setWasherCompartmentData(lineData);
            } else {
                this.Views.PumpsEdit.setLineData(lineData);
            }

        }
    },
    loadControllerData: function () {
        this.Model.loadControllerData(this.settings.accountInfo.ControllerId);
    },
    onControllerDataLoaded: function (data) {
        this.controllerData = data;
    },
    onPumpsInlineEditClicked: function (pumpData, isInline, isSaveAndClose) {
        //if (!isInline) {
        //    var view = this.Views.PumpsEdit;
        //    if (view) {
        //        if (view.validate()) {
        //            this.Model.updatePumpData(pumpData, isInline);
        //        }
        //    }
        //}
      
        this.Model.updatePumpData(pumpData, isInline, isSaveAndClose);
    },
    onPumpUpdated: function (data, isSaveAndClose) {
        this.isDirty = false;
        if (isSaveAndClose) {
            this.Views.PumpsViews.redirectToControllerSetup(this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId);
        } else {
            this.massage = '<label data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully.") + '</label>';
            this.loadPumpsData();
        }
    },
    onPumpUpdatedEdit: function (data, isSaveAndClose) {
        this.isDirty = false;
        if (isSaveAndClose) {
            this.Views.PumpsEdit.redirectToPumpsList(this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId);
        }
        data.massage = '<label data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully.") + '</label>';
        this.reLoadEditPage(data);
    },
    onGeneralTabClicked: function () {
        this.loadPumpsData();
    },
    onEditClicked: function (data, gridData) {
        var _this = this;
        var drData = {};
        drData.data = data;
        drData.MaxLevel = this.settings.accountInfo.MaxLevel;
        drData.IsCentral = this.settings.accountInfo.IsCentral;
        drData.ControllerName = this.controllerName;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        if (drData.ControllerModelId == 14) {
            drData.Products = this.pumpProducts;
        } else {
        drData.Products = this.products;
        }
        drData.EqupmentTypes = $.grep(this.pumpTypes, function (type) { return data.ControllerEquipmentTypeId == 1 ? !type.IsMeType : type.IsMeType });
        if (this.settings.accountInfo.ControllerModelId == 11 || this.settings.accountInfo.ControllerModelId == 7
            || this.settings.accountInfo.ControllerModelId == 10) {
            var i = 0;
            $.each(drData.EqupmentTypes, function () {
                if (drData.EqupmentTypes[i].ControllerEquipmentTypeModelName == "Pump") {
                    return false;
                }
                i++;
            });          
            if (i >= 0) {
                drData.EqupmentTypes.splice(i, 1);
            }
        }
        if (this.settings.accountInfo.ControllerModelId == 7 || this.settings.accountInfo.ControllerModelId == 11 || this.settings.accountInfo.ControllerModelId == 8
            || this.settings.accountInfo.ControllerModelId == 9 || this.settings.accountInfo.ControllerModelId == 14) {
            var i = 0;
            $.each(drData.EqupmentTypes, function () {
                if (drData.EqupmentTypes[i].ControllerEquipmentTypeModelName == "Washomix") {
                    return false;
                }
                i++;
            });
            if (i >= 0) {
                drData.EqupmentTypes.splice(i, 1);
            }
        }
        if (this.settings.accountInfo.ControllerModelId == 10) {
            var i = 0;
            $.each(drData.EqupmentTypes, function () {
                if (drData.EqupmentTypes[i].ControllerEquipmentTypeModelName == "Compactomix ") {
                    return false;
                }
                i++;
            });
            if (i >= 0) {
                drData.EqupmentTypes.splice(i, 1);
            }
        }
        
        drData.ControllerData = this.controllerData;
        if (this.settings.accountInfo.ControllerModelId == 7 || this.settings.accountInfo.ControllerModelId == 8 || this.settings.accountInfo.ControllerModelId == 9 || this.settings.accountInfo.ControllerModelId == 14) {
            _this.onLineNumberChanged(data.LineNumber, data.ControllerEquipmentSetupId);
            drData.LineData = [];
        } else if (this.settings.accountInfo.ControllerModelId == 11) {
                _this.Model.GetCompartmentValveData(data.ControllerEquipmentSetupId, true, data.WasherGroupNumber, data.ControllerEquipmentTypeId);
            drData.CompartmentValveData = [];
        }
        this.Views.PumpsEdit.setData(drData, gridData);
        _this.findContainer('Pumps', drData.data.ControllerEquipmentId, drData.data.ControllerId);

        this.trackChanges();
    },


    savePage: function (data, isInline, isSaveAndClose) {
        if (this.Views.PumpsEdit.isGridEdit != undefined && this.Views.PumpsEdit.isGridEdit == false) {
            pumpData = this.Views.PumpsViews.getDataForEditableGrid();
            this.Model.updatePumpData(pumpData, true, isSaveAndClose);

        } else {
            var _this = this;
            var view = this.Views.PumpsEdit;
            if (view) {
                if (view.validate()) {
                    if (this.HasDuplicateTags()) {
                        this.Views.PumpsEdit.showMessage('<label class="errorutility">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found.") + '</label>');
                        return false;
                    } else {
                        var pumpData = this.Views.PumpsEdit.getPumpData();
                    pumpData[0].ControllerModelId = this.settings.accountInfo.ControllerModelId;
                        //if (!isInline && view.options.accountInfo.MaxLevel >= 8) {
                        //    this.Model.ValidateTags(pumpData , isSaveAndClose);
                        //} else {
                    if (pumpData[0].ControllerModelId == 11) {
                        this.compartmentValveData = pumpData[0].LineCompartmentMappings;
                        this.washerGroupTypeId = pumpData[0].WasherGroupTypeId;
                    } else if (pumpData[0].ControllerModelId == 14) {
                        this.lineData = pumpData[0].LineCompartmentMappings;
                    }
                        _this.Model.updatePumpData(pumpData, isInline, isSaveAndClose);
                        // }
                    }
                }
            }
        }
    },

    validateSuccess: function (data, isSaveAndClose) {
        var _this = this;
        var pumpData = this.Views.PumpsEdit.getPumpData();
        _this.Model.updatePumpData(pumpData, false, isSaveAndClose);
    },

    validateFailed: function (data, description, localData) {
        if (description.status == 300) {
            this.OverrideConformation(description);
        } else {
            this.onPumpUpdationFailedEdit(data, description, localData);
        }
    },
    OverrideConformation: function (description) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_OVERRIDEPLCVALUES', 'Override PLC values.'),
            BodyMessage: description.Message,
            Buttons: {
                Yes: {
                    Callback: function () {
                        dialog.addClass('hide');
                        var pumpData = _this.Views.PumpsEdit.getPumpData();
                        var pumpDataList = [];
                        $(pumpData).each(function (key, item) {
                            item.PlcTags = description.PlcTags;
                            item.OverridePlcValues = true;
                            pumpDataList.push(item);
                        });
                       // pumpData.PlcTags = description.PlcTags;
                      //  pumpData.OverridePlcValues = true;
                        // _this.Model.updatePumpData(pumpData, false);
                        _this.Model.WriteTagsToPLC(pumpDataList, false);
                        return true;
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        dialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },

    reLoadEditPage: function (data) {
        var _this = this;
        var drData = {};
        drData.data = data[0];
        drData.MaxLevel = this.settings.accountInfo.MaxLevel;
        drData.ControllerName = this.controllerName;
        drData.IsCentral = this.settings.accountInfo.IsCentral;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.massage = data.massage; //'<label data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully.") + '</label>';
        if (drData.ControllerModelId == 14) {
            drData.Products = this.pumpProducts;
        } else {
        drData.Products = this.products;
        }
       // alert(drData.EqupmentTypes);
        drData.EqupmentTypes = $.grep(this.pumpTypes, function (type) { return data[0].ControllerEquipmentTypeId == 1 ? !type.IsMeType : type.IsMeType });
        if (this.settings.accountInfo.ControllerModelId == 7 || this.settings.accountInfo.ControllerModelId == 11
       || this.settings.accountInfo.ControllerModelId == 10) {
            var i = 0;
            $.each(drData.EqupmentTypes, function () {
                if (drData.EqupmentTypes[i].ControllerEquipmentTypeModelName == "Pump") {                   
                    return false;
                }
                i++;
            });
            if (i >= 0) {
                drData.EqupmentTypes.splice(i, 1);
            }
        }
        if (this.settings.accountInfo.ControllerModelId != 10) {
            var i = 0;
            $.each(drData.EqupmentTypes, function () {
                if (drData.EqupmentTypes[i].ControllerEquipmentTypeModelName == "Washomix") {
                    return false;
                }
                i++;
            });
            if (i >= 0) {
                drData.EqupmentTypes.splice(i, 1);
            }
        }
        if (this.settings.accountInfo.ControllerModelId == 10) {
            var i = 0;
            $.each(drData.EqupmentTypes, function () {
                if (drData.EqupmentTypes[i].ControllerEquipmentTypeModelName == "Compactomix ") {
                    return false;
                }
                i++;
            });
            if (i >= 0) {
                drData.EqupmentTypes.splice(i, 1);
            }
        }
      
        drData.CompartmentValveData = data[0].LineCompartmentMappings;
        drData.LineData = data[0].LineCompartmentMappings ? data[0].LineCompartmentMappings : this.lineData;
        if (this.settings.accountInfo.ControllerModelId == 7 || this.settings.accountInfo.ControllerModelId == 8 || this.settings.accountInfo.ControllerModelId == 9) {
            _this.onLineNumberChanged(data[0].LineNumber, data[0].ControllerEquipmentSetupId);
            drData.LineData = [];
        } else if (this.settings.accountInfo.ControllerModelId == 11) {
            _this.Model.GetCompartmentValveData(data[0].ControllerEquipmentSetupId, true, data[0].WasherGroupNumber, data[0].ControllerEquipmentTypeId);
        }
        drData.CompartmentValveData = [];
        drData.ControllerData = this.controllerData;
        drData.data.WasherGroupTypeId = this.washerGroupTypeId;
        this.Views.PumpsEdit.setData(drData);
        if (data[0].ControllerModelId == 11) {
            this.Views.PumpsEdit.setCompartmentValveData(drData.CompartmentValveData);
            this.Views.PumpsEdit.setDropDownValuesForPLC(drData);
        }
        else if (data[0].ControllerModelId == 14) {
            this.Views.PumpsEdit.setWasherCompartmentData(this.lineData);
        }
        this.isDirty = false;
    },
    onPumpUpdationFailed: function (error, description) {
        if (description.status) {
            if (description.status == 300) {
                this.massage = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully.") + " " + $.GetLocaleKeyValue('FIELD_INDATABASE ', "In DataBase.") + '</label>';
            }
        }
        else if (description == 51030) {
            this.massage = '<label class="k-error-message">Records count does not match..Resynch is in progress </label>';
        }else if (description == 51060) {
            this.massage = '<label class="k-error-message">Unable to save changes , Connectivity issue, Please try again later </label>';
        } else if (description == 60000) {
            this.massage = '<label class="k-error-message">Records are not in synch..Resynch is in progress </label>';
        } else {
            this.massage = '<label class="k-error-message">' + this.buildErrorMessage(description) + '</label>';
        }
        this.loadPumpsData();
        this.isDirty = false;
    },
    onPumpUpdationFailedEdit: function (error, description, data) {
        if (description.status == 300) {
            this.OverrideConformation(description);
        }
        var drData = {};
        drData.data = data[0];
        drData.MaxLevel = this.settings.accountInfo.MaxLevel;
        drData.ControllerName = this.controllerName;
        drData.IsCentral = this.settings.accountInfo.IsCentral;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;

        if (description == 51030) {
            drData.massage = '<label class="k-error-message">Records count does not match..Resynch is in progress </label>';
        } else if (description == 60000) {
            drData.massage = '<label class="k-error-message">Records are not in synch..Resynch is in progress </label>';
        } else if (description == 8014) {
            drData.massage = '<label class="k-error-message">Maximum Dosing Point limit reached.</label>'
        } else if (description == 51060) {
            drData.massage = '<label class="k-error-message">Unable to save changes , Connectivity issue, Please try again later </label>';
        } else {
            drData.massage = '<label class="k-error-message">' + this.buildErrorMessage(description, data) + '</label>';
        }
        var lastIndex = drData.massage.lastIndexOf(",");
        drData.massage = drData.massage.replaceAt(lastIndex, " ")

        drData.Products = this.products;
        drData.EqupmentTypes = $.grep(this.pumpTypes, function (type) { return data[0].ControllerEquipmentTypeId == 1 ? !type.IsMeType : type.IsMeType });
        drData.LineData = data[0].LineCompartmentMappings ? data[0].LineCompartmentMappings : this.lineData;
        drData.ControllerData = this.controllerData;
        this.Views.PumpsEdit.setData(drData);
        this.isDirty = false;
        data.massage = drData.massage;
        this.reLoadEditPage(data);
    },
    buildErrorMessage: function (description, data) {
        var message = '';
        if (jQuery.type(description) == "object") {
            message = $.GetLocaleKeyValue('FIELD_PUMPSUPDATEFAILED', "Pump details updation failed");
        } else {
            var error = description.split(',');
            var tagLocale = $.GetLocaleKeyValue('FIELD_TAG', 'Tag') + ' - ';
            //if (parseInt(error[0]) == 303) {
            //    message = $.GetLocaleKeyValue('FIELD_STORAGETANKSNAMEALREADYEXIST', 'Name already exists.Please use a different name');
            //} else 
            if (parseInt(error[0]) == 801 || parseInt(error[0]) == 802 || parseInt(error[0]) == 803) {
                message = '<span data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully.") + '</span>';
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }
                    if (error[a] == 801) {
                        if (data.LfsChemicalNameTag) {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_LFSCHEMICALNAME', 'LFS Chemical Name') + tagLocale + data.LfsChemicalNameTag + ', </div>';
                        }
                        else {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_LFSCHEMICALNAME', 'LFS Chemical Name') + tagLocale + $('#txtLfsChemicalNameTag').val() + ', </div>';
                        }
                    } else if (error[a] == 802) {
                        if (data.KfactorTag) {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_KFACTOR', 'K-Factor') + tagLocale + data.KfactorTag + ', </div>';
                        }
                        else {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_KFACTOR', 'K-Factor') + tagLocale + $('#txtKfactorTag').val() + ', </div>';
                        }
                    } else if (error[a] == 803) {
                        if (data.PumpCalibrationTag) {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CALIBRATION', 'Calibration') + tagLocale + data.CalibrationTag + ', </div>';
                        }
                        else {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CALIBRATION', 'Calibration') + tagLocale + $('#txtPumpCalibrationTag').val() + ', </div>';
                        }
                    }
                }
                message = message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXIST', 'already exist');
            } else if (parseInt(error[0]) == 804 || parseInt(error[0]) == 805 || parseInt(error[0]) == 806
                        || parseInt(error[0]) == 807 || parseInt(error[0]) == 808 || parseInt(error[0]) == 809
                            || parseInt(error[0]) == 8010 || parseInt(error[0]) == 8011 || parseInt(error[0]) == 8012
                                || parseInt(error[0]) == 8013) {
                message = '<span data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully.") + '</span>';
                for (var a = 0; a < error.length; a++) {
                    if (message != '' && !isNaN(error[a]) && error[a] != '') {
                        message = message + ', ';
                    }
                    if (error[a] == 804) {
                        if (data.LfsChemicalNameTag) {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_LFSCHEMICALNAME', 'LFS Chemical Name') + tagLocale + data.LfsChemicalNameTag + ', </div>';
                        }
                        else {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_LFSCHEMICALNAME', 'LFS Chemical Name') + tagLocale + $('#txtLfsChemicalNameTag').val() + ', </div>';
                        }
                    } else if (error[a] == 805) {
                        if (data.KfactorTag) {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_KFACTOR', 'K-Factor') + tagLocale + data.KfactorTag + ', </div>';
                        }
                        else {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_KFACTOR', 'K-Factor') + tagLocale + $('#txtKfactorTag').val() + ', </div>';
                        }
                    } else if (error[a] == 806) {
                        if (data.PumpCalibrationTag) {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CALIBRATION', 'Calibration') + tagLocale + data.CalibrationTag + ', </div>';
                        }
                        else {
                            message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CALIBRATION', 'Calibration') + tagLocale + $('#txtPumpCalibrationTag').val() + ', </div>';
                        }
                    }
                    else if (error[a] == 807) {
                        message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FLOWDETECTORTYPE', 'Flow Detector Type') + tagLocale + $('#ddlFlowDetectorType').val() + ', </div>';
                    }
                    else if (error[a] == 808) {
                        message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FLOWSWITCHALARM', 'Flow Switch Alarm') + tagLocale + $('#cbFlowSwitchAlarm').val() + ', </div>';
                    }
                    else if (error[a] == 809) {
                        message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FLOWMETERALARM', 'Flow Meter Alarm') + tagLocale + $('#cbFlowMeterAlarm').val() + ', </div>';
                    }
                    else if (error[a] == 8010) {
                        message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FLOWMETERTYPE', 'Flow Meter Type') + tagLocale + $('#txtFlowAlarmDelay').val() + ', </div>';
                    }
                    else if (error[a] == 8011) {
                        message = message + $.GetLocaleKeyValue('FIELD_FLOWMETERPUMPDELAY', 'Flow Meter Pump Delay') + tagLocale + $('#txtFlowMeterPumpDelay').val();
                    }
                    else if (error[a] == 8013) {
                        message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_FLOWMETERALARMDELAY', 'Flow Meter Alarm Delay') + tagLocale + $('#txtFlowMeterAlarmDelay').val() + ', </div>';
                    }
                    
                }
                message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'Is / are invalid.') + ', </div>';
            } else if (parseInt(error[0]) == 901 || parseInt(error[0]) == 902 || parseInt(error[0]) == 909) {
                message = '<span data-localize ="FIELD_PUMPSUPDATESUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PUMPSUPDATESUCCESSFULLY', "Pump details updated successfully.") + '</span>,';
                if (parseInt(error[0]) == 909) {
                    message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_UNABLETOWRITEVALUESTOPLC', "Unable to connect to PLC.") + ', </div>';
                } else if (parseInt(error[0]) == 901) {
                    message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + ', </div>';
                } else if (parseInt(error[0]) == 902) {
                    message = message + '<div id="statusMsg" class="k-error-message">' + $.GetLocaleKeyValue('FIELD_UNABLETOWRITEVALUESTOPLC', "Unable to connect to PLC.") + ', </div>';
                }
            } else if (parseInt(error[0]) == 8014) {
                message = message + $.GetLocaleKeyValue('FIELD_MAXIMUMDOSINGPOINTLIMITREACHED', "Maximum Dosing Point limit reached.");
            } else {
                message = $.GetLocaleKeyValue('FIELD_PUMPSUPDATEFAILED', "Pump details updattion failed.");
            }
        }
        return message;
    },
    onClancelClicked: function () {
        this.Views.PumpsEdit.redirectToPumpsList(this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId);
    },
    onControllerNameLoaded: function (data) {
        this.controllerName = data.ControllerName;
    },
    onBackButtonClick: function () {
        this.onControllerSetupClicked();
    },
    setIsInlineGridEdit: function (flage) {
        this.Views.PumpsViews.isGridEdit = flage;
    },
    upDateIsDirty: function () {
        this.isDirty = false;
    },
    editPump: function (id) {
        var _this = this;
        var controllerId = _this.getQueryStringByName('ControllerId');
        var container = $(this.Views.PumpsViews.options.containerSelector);
        var element = container.find('span[control-eqpid=' + id + '][controlid=' + controllerId + '].lnkUpdatePump ');
        _this.onEditClicked(this.Views.PumpsViews.getPumpData(element));
    },
    openCurrentNav: function (typeName, id, parentId) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');

        if (typeName == "Pumps") {
            element.addClass('active');
            element.parent('ul').parent('li').addClass('open');
            element.parent('ul').parent('li').parent('ul').parent('li').addClass('open');
            element.parent('ul').slideDown();
            element.parent('ul').parent('li').parent('ul').slideDown();
        }
        if (typeName == "Controllers") {
            element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + ']').parent('li');
            element.addClass('open');
            element.children('ul').children('li').addClass('open');
            element.children('ul').slideDown();
            element.children('ul').children('li').children('ul').slideDown();
        }
    },
    findContainer: function (typeName, id, parentId) {
        var _this = this;
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return; //give up on loading the template
        setTimeout(function () { _this.openCurrentNav(typeName, id, parentId); }, 200);
        return;

    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },

    onGetCompartmentValveData: function (data, isEdit) {
        this.compartmentValveData = data;
        if (isEdit) {
            this.Views.PumpsEdit.setCompartmentValveData(this.compartmentValveData);
        }
    },
    
}
String.prototype.replaceAt = function (index, character) {
    return this.substr(0, index) + character + this.substr(index + character.length);
};