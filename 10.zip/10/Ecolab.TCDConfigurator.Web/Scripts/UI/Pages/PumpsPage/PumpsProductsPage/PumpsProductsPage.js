// JavaScript source code
Ecolab.Presenters.PumpsProductsPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.products = null;
    this.evnt = null;
    this.data = null;
    this.massage = null;
    this.controllerName = null;
    var pumpsProductData = null;
    var washerGroupTypeId = null;
};
Ecolab.Presenters.PumpsProductsPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPumpsTabsView();
        this.initPumpsProductsView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onPumpsProductDataLoaded: function (data) { _this.onPumpsProductDataLoaded(data); },
            onProductsLoaded: function (products) { _this.onProductsLoaded(products); },
            onControllerNameLoaded: function (data) { _this.onControllerNameLoaded(data); },
            onPumpUpdated: function (data, isSaveAndClose) { _this.onPumpUpdated(data, isSaveAndClose) ;},
            onPumpUpdationFailed: function(data) {},
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },

    initPumpsTabsView: function () {
        var _this = this;

        if (!this.Views.initPumpsTabsView) {
            this.Views.initPumpsTabsView = new Ecolab.Views.ControllerSetupTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () {
                        _this.onTabsRendered(); //_this.loadControllerModelDataData(_this.settings.accountInfo.RegionId);
                    },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    setupTabClicked: function () { _this.onSetupTabClicked(); },
                    onBackButtonClick: function () { _this.onBackButtonClick(); },
                }
            });
        }
       

        if (this.settings.accountInfo.ControllerId != "-1") {
            var cData = {};
            cData.ControllerId = this.settings.accountInfo.ControllerId;
            cData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
            cData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
            _this.findContainer('Controllers', cData.ControllerId, 0);
            this.Views.initPumpsTabsView.setController(cData);
        }
        this.Views.initPumpsTabsView.setData(this.settings.accountInfo);
    },
    initPumpsProductsView: function () {
        var _this = this;
        if (!this.Views.PumpsProductsViews) {
            this.Views.PumpsProductsViews = new Ecolab.Views.PumpsProducts({
                containerSelector: '#tabProductListContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onClancelClicked: function () { _this.onClancelClicked(); },
                    savePage: function (isSaveAndClose) {
                        _this.savePage(isSaveAndClose);
                    }
                }
            });
        }
       
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_CONTROLLER SETUP', 'Controller Setup');
        breadCrumbData.url = "/ControllerSetupList";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabsRendered: function () {
        this.loadProducts();
        this.getControllerName();
    },

    findContainer: function (typeName, id, parentId) {
        var _this = this;
        retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
        if (retryCount === 0) return; //give up on loading the template
        setTimeout(function () { _this.openCurrentNav(typeName, id, parentId); }, 200);
        return;

    },
    openCurrentNav: function (typeName, id, parentId) {
        var _this = this;
        var container = $(this.Views.NavigationMenuView.options.containerSelector);
        var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + '][parentid=' + parentId + ']').parent('li');

        if (typeName == "Pumps") {
            element.addClass('active');
            element.parent('ul').parent('li').addClass('open');
            element.parent('ul').parent('li').parent('ul').parent('li').addClass('open');
            element.parent('ul').slideDown();
            element.parent('ul').parent('li').parent('ul').slideDown();
        }
        if (typeName == "Controllers") {
            element = container.find('.cssmenu li a[typename="' + typeName + '"][id=' + id + ']').parent('li');
            element.addClass('open');
            element.children('ul').children('li').addClass('open');
            element.children('ul').slideDown();
            element.children('ul').children('li').children('ul').slideDown();
        }
    },

    getControllerName: function () {
        this.Model.getControllerName(this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.ControllerId);
    },
    
    onControllerNameLoaded: function (data) {
        this.controllerName = data.ControllerName;
        this.loadPumpsProductData();
    },

    onControllerDataLoaded: function (data) {
        this.controllerData = data;
       
    },

    //Load Products
    loadProducts: function () {
        this.Model.loadProducts(this.settings.accountInfo.EcolabAccountNumber);
    },

    //On products recieved
    onProductsLoaded: function (products) {
        var _this = this;
        this.products = products;
    },

    onGeneralTabClicked: function () {
        this.loadPumpsProductData();
    },

    //Loading Pumps Product Data
    loadPumpsProductData: function () {
        this.Model.loadPumpsProductData(this.settings.accountInfo.ControllerId, this.settings.accountInfo.EcolabAccountNumber);
    },

    //on Pumps products recieved
    onPumpsProductDataLoaded : function(data){
        drData = [];
        var regExp = /\(([^)]+)\)/;
        var countOfChemical = [];
        drData.data = data;
        drData.products = this.products;
        drData.controllerName = this.controllerName;
        var controllerTopicName = regExp.exec(this.controllerName);
        for(var i = 1; i <= 10; i++){
            countOfChemical.push(i);
        }
        drData.countOfChemical = countOfChemical;
        drData.controllerTopicName = controllerTopicName[1];
        this.Views.PumpsProductsViews.setData(drData);
    },

    savePage: function (isSaveAndClose) {
        var view = this.Views.PumpsProductsViews;
        if (view) {
            var data = view.getPumpsProductData();
            data[0].ControllerId = this.settings.accountInfo.ControllerId;
            this.pumpsProductData = data;
            this.Model.saveData(data,  isSaveAndClose);
        }
    },

    onPumpUpdated: function(data, isSaveAndClose){
        if (isSaveAndClose) {
            this.Views.PumpsProductsViews.redirectToPumpsList(this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId);
        } else {
            this.reLoadPage(data);
        }
    },
   
    OverrideConformation: function (description) {
        var _this = this;
        var dialog = $('#ConfirmDialog');
        dialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_OVERRIDEPLCVALUES', 'Override PLC values.'),
            BodyMessage: description.Message,
            Buttons: {
                Yes: {
                    Callback: function () {
                        dialog.addClass('hide');
                        var pumpData = _this.Views.PumpsProductsEdit.getPumpData();
                        pumpData.PlcTags = description.PlcTags;
                        pumpData.OverridePlcValues = true;
                        // _this.Model.updatePumpData(pumpData, false);
                        _this.Model.WriteTagsToPLC(pumpData, false);
                        return true;
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        dialog.addClass('hide');
                        return false;
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
    },
    onBackButtonClick: function () {
        this.onControllerSetupClicked();
    },
    upDateIsDirty: function () {
        this.isDirty = false;
    },
    reLoadPage: function (data) {
        drData = [];

        var regExp = /\(([^)]+)\)/;
        var countOfChemical = [];
        drData.data = data;
        drData.products = this.products;
        drData.controllerName = this.controllerName;
        var controllerTopicName = regExp.exec(this.controllerName);
        for (var i = 1; i <= 10; i++) {
            countOfChemical.push(i);
        }
        drData.countOfChemical = countOfChemical;
        drData.controllerTopicName = controllerTopicName[1];
        drData.massage = '<label data-localize ="FIELD_PRODUCTSAVEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_PRODUCTSAVEDSUCCESSFULLY', "Products saved successfully.") + '</label>';
        this.Views.PumpsProductsViews.setData(drData);

        this.isDirty = false;

    },
    onClancelClicked: function () {
        this.Views.PumpsProductsViews.redirectToPumpsList(this.settings.accountInfo.ControllerId, this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId);
    },

    
};