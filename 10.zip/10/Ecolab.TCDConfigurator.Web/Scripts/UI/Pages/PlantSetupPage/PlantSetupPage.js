Ecolab.Presenters.PlantSetupPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.isSaved = false; // is used to show the success message. This variable is added for Resync Error after save message.
};
Ecolab.Presenters.PlantSetupPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onPlantSetupDataLoaded: function (data) { _this.onPlantSetupDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); },
            onPlantDataSaved: function () { _this.onPlantDataSaved(); },
            onPlantDataSavedFailed: function (data, exception) { _this.onPlantDataSavedFailed(data, exception); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#tabContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadPlantSetupDataData(); },
                                generalTabClicked: function () { _this.onGeneralTabClicked(); },
                                customerTabClicked: function () { _this.onCustomerTabClicked(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.PlantSetupView) {
            this.Views.PlantSetupView = new Ecolab.Views.PlantSetup(
                        {
                            containerSelector: '#tabSetupContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                onRendered: function() {},
                                onCancelPage: function () { return _this.cancelPage(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onSavePage: function () { _this.savePage(); },
                                onFtrClick: function () { _this.FtrClick(); },
                                onDeleteLogoClicked: function () { _this.onDeleteLogoClicked(); }
                            }
                        });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onGeneralTabClicked: function () {
        this.loadPlantSetupDataData();
    },
    onCustomerTabClicked: function () {
    },
    navigateToConfigPage: function (id) {
    },
    loadPlantSetupDataData: function () {
        this.Model.loadPlantSetupData();
    },
    onPlantSetupDataLoaded: function (data) {
        kendo.ui.progress($('body'), false);
        this.Views.PlantSetupView.setData(data);
        if (this.isSaved) {
            this.Views.PlantSetupView.onPlantDataSaved();
            this.isSaved = false;
        }
    },
    savePage: function () {
        var view = this.Views.PlantSetupView;
        if (view) {
            if (view.validate()) {
                var plant = view.getData();
                this.Model.savePlantSetupData(plant);
                this.isDirty = false;
            }
            else {
                return false;
            }
        }
    },
    FtrClick: function () {
        kendo.ui.progress($('body'), false);
      this.Model.FtrClick();
    },
    cancelPage: function () {
        return this.onBeforeNavigate();
    },
    onPlantDataSaved: function () {
        this.isSaved = true;
        this.Model.loadPlantSetupData();
    },
    onPlantDataSavedFailed: function (data, exception) {
        this.Views.PlantSetupView.onPlantDataSavedFailed(data, exception);
    },
    onFtrSuccess: function () {
        this.Views.PlantSetupView.onFtrSuccess();
    },
    onFtrFailed: function (data, exception) {
        this.Views.PlantSetupView.onFtrFailed(data, exception);
    },
    onDeleteLogoClicked: function () {
        var _this = this
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISLOGO', 'Are you sure you want to delete this Logo?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Views.PlantSetupView.deleteLogo()
                    }
                },

                No: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                    }
                }
            }
        });
    }
};