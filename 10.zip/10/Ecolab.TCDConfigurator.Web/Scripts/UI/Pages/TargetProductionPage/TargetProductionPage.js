Ecolab.Presenters.TargetProductionPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.TargetProductionPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initTargetProductionView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onTargetProductionDataLoaded: function (data) { _this.onTargetProductionDataLoaded(data); },
            onTargetProductionDataUpdated: function (data) { _this.onTargetProductionDataUpdated(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadTargetProductionData(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },                               
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },

    initTargetProductionView: function () {
        var _this = this;
        if (!this.Views.TargetProductionView) {
            this.Views.TargetProductionView = new Ecolab.Views.TargetProduction({
                containerSelector: '#divTargetProdContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onSaveClicked: function (laborCostViewModel) { _this.onSaveClicked(laborCostViewModel); }
                }
            });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup')
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);

    },
    savePage: function () {
        var _this = this;
        var view = this.Views.TargetProductionView;
        if (view) {
            if (view.validate()) {
                var data = this.Views.TargetProductionView.getTargetProdData();
                this.Model.updateTargetProductionData(data);
                this.isDirty = false;
            }
        }
    },
    navigateToConfigPage: function (id) {
    },

    loadTargetProductionData: function () {
        this.Model.loadTargetProductionData();
    },
    onTargetProductionDataLoaded: function (data) {
        this.Views.TargetProductionView.setData(data);
    },
    onSaveClicked: function (laborCostViewModel) {
        this.Model.updateTargetProductionData(laborCostViewModel);
    },
    onTargetProductionDataUpdationFailed: function (data, description) {
        this.Views.TargetProductionView.showMessage("501");
    },
    onTargetProductionDataUpdated: function (data) {
        this.Views.TargetProductionView.showMessage("201");
    },
};