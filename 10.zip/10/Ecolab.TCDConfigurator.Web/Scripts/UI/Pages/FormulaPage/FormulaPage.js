Ecolab.Presenters.FormulaPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.dropDownData = null;
    this.IsCopy = false;
    this.message = null;
    this.isView = null;
    this.isInline = false;
};
Ecolab.Presenters.FormulaPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
        this.initFormulaEditView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onFormulaDataLoaded: function (data) { _this.onFormulaDataLoaded(data); },
            onLoadDropDownDataLoaded: function (data) { _this.onLoadDropDownDataLoaded(data); },
            onAddFormulaClicked: function (plantChainId) { _this.onAddFormulaClicked(plantChainId); },
            onGetChainFormulaNames: function (data) { _this.onGetChainFormulaNames(data); },
            onGetChainFormulaData: function (data) { _this.onGetChainFormulaData(data); },
            onFormulaSaveSuccess: function (data) { _this.onFormulaSaveSuccess(data); },
            onFormulaSaveFailed: function (error, description) { _this.onFormulaSaveFailed(error, description); },
            onFormulaUpdateSuccess: function (data) { _this.onFormulaUpdateSuccess(data); },
            onFormulaUpdateFailed: function (error, description) { _this.onFormulaUpdateFailed(error, description); },
            onFormulaDataForUpdateLoaded: function (data, isCopy) { _this.onFormulaDataForUpdateLoaded(data, isCopy); },
            onFormulaDeleteSuccess: function (data) { _this.onFormulaDeleteSuccess(data); },
            onFormulaDeleteFailed: function (error, description) { _this.onFormulaDeleteFailed(error, description); },


            onloadFormulaOnAddNewPopupDataLoaded: function (data) { _this.loadFormularOnAddNewPopupDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); },
            onTextileSaturationReceicved: function (data, type) { _this.setTextileSaturation(data, type); },
            onFormulaDataForUpdateLoadedEdit: function (data, isCopy, formulaData) { _this.onFormulaDataForUpdateLoadedEdit(data, isCopy, formulaData); },
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();

        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {

        var _this = this;
        if (!this.Views.PlantSetupView) {
            this.Views.PlantSetupView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { _this.loadFormulaData(); },
                                savePage: function () { return _this.savePage(true) },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onSaveClicked: function (data) { _this.savePlantutilityData(data); }
                            }
                        });
        }
        // region = this.settings.accountInfo.RegionId;
        this.Views.PlantSetupView.setData(this.settings.accountInfo);

    },
    initListView: function () {
        var _this = this;
        if (!this.Views.FormulaView) {
            this.Views.FormulaView = new Ecolab.Views.FormulaList(
                        {
                            containerSelector: '#tabFormulaContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                onRendered: function () { },
                                onAddFormulaClicked: function (plantChainId) { _this.onAddFormulaClicked(plantChainId); },
                                onEditFormulaClicked: function (programId, plantChainId, isCopy, isView) { _this.onEditFormulaClicked(programId, plantChainId, isCopy, isView); },
                                onDeleteFormulaClicked: function (programId, lastmodifiedtime) { _this.onDeleteFormulaClicked(programId, lastmodifiedtime); },
                                onInlineUpdateFormulaClicked: function (formulaData) { _this.onInlineUpdateFormulaClicked(formulaData); },

                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                onRuleClicked: function (id) { _this.navigateToConfigPage(id); },
                                rendered: function () { },
                                setIsDirtyFalse: function () { _this.setIsDirtyFalse(); },
                                setIsDirty: function (flag) { _this.setIsDirty(flag); },
                                getTextileSaturation: function (textileId, type) { _this.getTextileSaturation(textileId, type); },
                                onUpdateEditFormulaClicked: function (programId, plantChainId, isCopy, isView, formulaData) { _this.onUpdateEditFormulaClicked(programId, plantChainId, isCopy, isView, formulaData); },
                            }
                        });

        }
    },
    initFormulaEditView: function () {
        var _this = this;
        if (!this.Views.FormulaEditView) {
            this.Views.FormulaEditView = new Ecolab.Views.FormulaEdit(
                        {
                            containerSelector: '#EditFormulaPopupContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                onRendered: function () { },
                                getChainFormulaData: function (plantProgramId) { _this.getChainFormulaData(plantProgramId); },
                                onSavePage: function () { return _this.savePage(false); },
                            }
                        });

        }
    },

    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadFormulaData: function () {
        this.Model.LoadDropDownData(this.settings.accountInfo.PlantChainId);
    },
    onFormulaDataLoaded: function (data) {
        data.message = this.message;
        data.PlantChainId = this.settings.accountInfo.PlantChainId;
        data.accountInfo = this.settings.accountInfo;
        data.dropDownData = this.dropDownData;
        $.each(data.Items, function (i, v) {
            if (v.EcolabTextileId != 0) {
                v.FormulaCategory = v.EcolabTextileId;
                v.FormulaCategoryName = v.EcolabTextileCategoryName;
            } else if (v.ChainTextileId != 0) {
                v.FormulaCategory = v.ChainTextileId;
                v.FormulaCategoryName = v.ChainTextileCategory;
            }
        });
        this.Views.FormulaView.setData(data);
    },
    onLoadDropDownDataLoaded: function (data) {
        this.dropDownData = data;
        this.Model.loadFormulaData();
    },
    loadFormulaOnAddNewPopupLoad: function () {
        this.Model.loadFormulaOnAddNewPopupLoad();
    },
    onAddFormulaClicked: function (plantChainId) {
        this.Model.GetChainFormulaNames(plantChainId);
    },
    onGetChainFormulaNames: function (data) {
        data.ProgramId = 0;
        data.PlantProgramId = 0;
        data.Name = "";
        data.Pieces = 0;
        data.Rewash = false;
        data.WeightDisplay = 0;
        data.PlantCustomerId = 0;
        data.PlantCustomer = this.dropDownData.CustomerList;
        data.dropDownData = this.dropDownData;
        data.Items = [];
        var obj = { EcolabTextileId: 0, EcolabSaturationId: 0, FormulaSegmentId: 0 };
        data.Items.push(obj);


        this.Views.FormulaEditView.setData(data);
        $('#myModal').modal({
        	show: true,
        	backdrop: 'static',
        	keyboard: false
        });
    },
    getChainFormulaData: function (plantProgramId) {
        this.Model.getChainFormulaData(plantProgramId);
    },
    onGetChainFormulaData: function (data) {
        this.Views.FormulaEditView.BindChainFormulaData(data);
    },
    
    onFormulaUpdateClicked: function (formulaData) {
        data = [];
        data[0] = formulaData
        this.Model.onFormulaUpdate(data);
    },
    onFormulaSaveClicked: function (formulaData) {
        this.Model.onFormulaSave(formulaData);
    },
    onEditFormulaClicked: function (programId, plantChainId, isCopy, isView) {
        this.isView = isView;
        this.Model.loadFormulaDataForUpdate(programId, isCopy);
    },
    onUpdateEditFormulaClicked: function (programId, plantChainId, isCopy, isView,formulaData) {
        this.isView = isView;
        this.Model.loadFormulaDataForUpdateEdit(programId, isCopy, formulaData);
    },
    onFormulaDataForUpdateLoaded: function (data, isCopy) {
        this.IsCopy = isCopy;
        data.IsCopy = isCopy;
        data.isView = this.isView;
        data.dropDownData = this.dropDownData;
        if (data.Items[0].EcolabTextileId != 0) {
            data.FormulaCategoryId = data.Items[0].EcolabTextileId;
            data.FormulaCategoryName = data.Items[0].EcolabTextileCategoryName;
        } else if (data.Items[0].ChainTextileId != 0) {
            data.FormulaCategoryId = data.Items[0].ChainTextileId;
            data.FormulaCategoryName = data.Items[0].ChainTextileCategory;
        }

        data.ProgramId = data.Items[0].ProgramId;
        data.Rewash = data.Items[0].Rewash;
        data.Pieces = data.Items[0].Pieces;
        data.PieceWeight = data.Items[0].PieceWeight;
        data.WeightDisplay = data.Items[0].WeightDisplay;
        data.PlantChainId = this.settings.accountInfo.PlantChainId;
        data.accountInfo = this.settings.accountInfo;
        if (isCopy) {
            data.Items[0].Name = '';
        }
        this.Views.FormulaEditView.setData(data);
        $('#myModal').modal({
            show: true,
            backdrop: 'static',
            keyboard: false
        });
    },

    onFormulaDataForUpdateLoadedEdit: function (data, isCopy, forumuladata) {
        this.IsCopy = isCopy;
        data.IsCopy = isCopy;
        data.isView = this.isView;
        data.dropDownData = this.dropDownData;
        if (data.Items[0].EcolabTextileId != 0) {
            data.FormulaCategoryId = data.Items[0].EcolabTextileId;
            data.FormulaCategoryName = data.Items[0].EcolabTextileCategoryName;
        } else if (data.Items[0].ChainTextileId != 0) {
            data.FormulaCategoryId = data.Items[0].ChainTextileId;
            data.FormulaCategoryName = data.Items[0].ChainTextileCategory;
        }

        data.ProgramId = data.Items[0].ProgramId;
        data.Rewash = data.Items[0].Rewash;
        data.Pieces = data.Items[0].Pieces;
        data.PieceWeight = data.Items[0].PieceWeight;
        data.WeightDisplay = data.Items[0].WeightDisplay;
        data.PlantChainId = this.settings.accountInfo.PlantChainId;
        data.accountInfo = this.settings.accountInfo;
        if (isCopy) {
            data.Items[0].Name = '';
        }
        var _this = this;
        //var url = '\FormulaList';
        //var addEditFormula = this.Views.FormulaEditView;
        //var forumuladata = addEditFormula.getFormulaData();
        var noEdits = _this.SaveChangesFormulaList(_this, data, forumuladata);
        if (noEdits) {
            this.Views.FormulaEditView.setData(data);
            $('#myModal').modal({
                show: true,
                backdrop: 'static',
                keyboard: false
            });
        }

    },
    onFormulaSaveSuccess: function (data) {
        $('#myModal').modal('hide');
        this.isDirty = false;
        this.loadFormulaData();
        this.message = '<label data-localize ="FIELD_NEWFORMULADDEDSUCCESSFULLY" class="k-success-message">New Formula added successfully.</label>';

    },
    onFormulaUpdateSuccess: function (data) {
        $('#myModal').modal('hide');
        this.isDirty = false;
        this.loadFormulaData();
        this.message = '<label data-localize ="FIELD_FORMULAUPDATEDSUCCESSFULLY" class="k-success-message">Formula updated successfully.</label>';
    },
    onFormulaSaveFailed: function (error, description) {
        if (description == 51030) {
            this.isDirty = false;
            this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>');
        }
        else if (description == 51060) {
            this.isDirty = false;
            this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
        }
        else if (description == 60000) {
            this.isDirty = false;
            this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        }
        else if (description == 51031 || description == 303) {
            this.isDirty = false;
            this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_FORMULAALREADYEXIST" class="k-error-message">Formula already exist.</label>');
        }
        else {
            this.isDirty = false;
            this.loadFormulaData();
            this.message = '<label data-localize ="FIELD_FORMULACREATIONFAILED" class="k-error-message">Formula creation failed.</label>';
        }
    },
    onFormulaUpdateFailed: function (error, description) {
        if (this.isInline) {
            if (description == 51030) {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>';
            }
            else if (description == 60000) {
                this.isDirty = false;
                this.loadFormulaData();
                this.message ='<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';
            }
            else if (description == 51060) {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>';
            }
            else if (description == 51031 || description == 303) {
                this.isDirty = false;
                this.loadFormulaData();
                this.message='<label data-localize ="FIELD_FORMULAALREADYEXIST" class="k-error-message">Formula already exist.</label>';
            }
            else {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_FORMULAUPDATIONFAILED" class="k-error-message">Formula updation failed.</label>';
            }
        } else {
            if (description == 51030) {
                this.isDirty = false;
                this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>');
            }
            else if (description == 60000) {
                this.isDirty = false;
                this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            }
            else if (description == 51060) {
                this.isDirty = false;
                this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            }
            else if (description == 51031 || description == 303) {
                this.isDirty = false;
                this.Views.FormulaEditView.showErrorMessage('<label data-localize ="FIELD_FORMULAALREADYEXIST" class="k-error-message">Formula already exist.</label>');
            }
            else {
                this.isDirty = false;
                this.loadFormulaData();
                this.message = '<label data-localize ="FIELD_FORMULAUPDATIONFAILED" class="k-error-message">Formula updation failed.</label>';
            }
        }        
    },
    onDeleteFormulaClicked: function (programId, lastmodifiedtime) {
        var _this = this;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISFORMULA', 'Are you sure you want to delete this formula?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Model.DeleteFormula(programId, lastmodifiedtime);
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                    },
                    CallbackParameters: null
                }
            }

        };
        this.Views.confirmDialog.setData(dialogOptions);
        return false;        
    },
    onFormulaDeleteSuccess: function (data) {
        $('#myModal').modal('hide');
        this.isDirty = false;
        this.loadFormulaData();
        this.message = '<label data-localize ="FIELD_FORMULADELETEDSUCCESSFULLY" class="k-success-message">Formula deleted sucessfully.</label>';

    },
    onFormulaDeleteFailed: function (error, description) {
        if (description == 51030) {
            this.isDirty = false;
            this.loadFormulaData();
            this.message = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress..</label>';
        }
        else if (description == 60000) {
            this.isDirty = false;
            this.loadFormulaData();
            this.message = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>';
        }
        else if (description == 51060) {
            this.isDirty = false;
            this.loadFormulaData();
            this.message = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>';
        }
        else if (description == 51031 || description == 303) {
            this.isDirty = false;
            this.loadFormulaData();
            this.message = '<label data-localize ="FIELD_FORMULAALREADYEXIST" class="k-error-message">Formula already exist.</label>';
        }
        else {
            this.isDirty = false;
            this.loadFormulaData();
            this.message = '<label data-localize ="FIELD_FORMULACREATIONFAILED" class="k-error-message">Formula creation failed.</label>';
        }
    },
    savePage: function (isInline) {
        if (isInline == false) {
            var addEditFormula = this.Views.FormulaEditView;
            if (addEditFormula) {
                if (addEditFormula.validate()) {
                    var formulaData = addEditFormula.getFormulaData();
                    if (this.IsCopy) {
                        formulaData.ProgramId = 0;
                    }
                    if (formulaData.ProgramId > 0) {
                        this.onFormulaUpdateClicked(formulaData);
                    } else {
                        this.onFormulaSaveClicked(formulaData);
                    }
                } else {
                    return false;
                }
            }
            this.isDirty = false;
            this.IsCopy = false;            
        } else {
            if (this.Views.FormulaView) {
                if (this.Views.FormulaView.validate()) {
                    return this.Model.onFormulaUpdate(this.Views.FormulaView.getFormulaEditableGridData());
                } else
                    return false;
            }
            this.isDirty = false;
        }
    },
    onInlineUpdateFormulaClicked: function(formuladata){
        this.isInline = true;
        this.Model.onFormulaUpdate(formuladata);
    },
};