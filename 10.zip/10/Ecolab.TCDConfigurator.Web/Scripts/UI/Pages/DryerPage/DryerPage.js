// JavaScript source code
Ecolab.Presenters.DryerPage = function(options) {
    this.settings = $.extend(this.defaults, options);
    this.dryerTypes = null;
};
Ecolab.Presenters.DryerPage.prototype = {
    initViews: function() {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
        this.initAddEditDryerGroupView();
        this.initAddEditDryerView();
    },
    initModel: function() {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function(modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function(eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function() {
        var _this = this;
        return {
            onDryerGroupDataLoaded: function(data) { _this.onDryerGroupDataLoaded(data); },
            onDryerTypesLoaded: function(data) { _this.onDryerTypesLoaded(data); },
            onDryerGroupCreated: function(data) { _this.onDryerGroupCreated(data); },
            onDryerGroupCreationFailed: function(error, description) { _this.onDryerGroupCreationFailed(error, description); },
            onDryerGroupUpdated: function() { _this.onDryerGroupUpdated(); },
            onDryerGroupUpdationFailed: function(error, description) { _this.onDryerGroupUpdationFailed(error, description); },
            onDryerGroupDeleted: function(data) { _this.onDryerGroupDeleted(data); },
            onDryerGroupDeletionFailed: function(error, description) { _this.onDryerGroupDeletionFailed(error, description); },
            onDryerCreated: function(data) { _this.onDryerCreated(data); },
            onDryerCreationFailed: function(error, description) { _this.onDryerCreationFailed(error, description); },
            onDryerUpdated: function(data, isInline) { _this.onDryerUpdated(data, isInline); },
            onDryerUpdationFailed: function(error, description, isInline) { _this.onDryerUpdationFailed(error, description, isInline); },
            onDryerDeleted: function(data) { _this.onDryerDeleted(data); },
            onDryerDeletionFailed: function(error, description) { _this.onDryerDeletionFailed(error, description); }
        };
    },
    afterInit: function() {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initPlantSetupTabsView: function() {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs({
                containerSelector: '#pageContainer',
                eventHandlers: {
                    rendered: function() { _this.onTabsRendered(); },
                    onRedirection: function(url) { return _this.RedirectLocation(url); },
                }
            });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function() {
        var _this = this;
        if (!this.Views.DryerView) {
            this.Views.DryerView = new Ecolab.Views.Dryer({
                containerSelector: '#divDryerContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function() { _this.onDryerRendered(); },
                    onAddDryerGroupClicked: function(data) { _this.onAddDryerGroupClicked(data); },
                    onEditDryerGroupClicked: function(data) { _this.onEditDryerGroupClicked(data); },
                    onDeleteDryerGroupClicked: function (data, dryerGroupData) { _this.onDeleteDryerGroupClicked(data, dryerGroupData); },
                    onAddDryerClicked: function(groupId, units) { _this.onAddDryerClicked(groupId, units); },
                    onEditDryerClicked: function(data) { _this.onEditDryerClicked(data); },
                    onDeleteDryerClicked: function (data, dryerData) { _this.onDeleteDryerClicked(data, dryerData); },
                    onInlineEditDryerClicked: function(data, isInline) { _this.onDryerUpdateClicked(data, isInline); },
                    onInlineEditDryerLinkClicked: function(e, data) { _this.onInlineEditDryerLinkClicked(e, data); },
                }
            });
        }
    },
    initAddEditDryerGroupView: function() {
        var _this = this;
        if (!this.Views.AddEditDryerGroupView) {
            this.Views.AddEditDryerGroupView = new Ecolab.Views.AddEditDryerGroup({
                containerSelector: '#addEditDyerGroupPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function() {},
                    onDryerGroupSaveClicked: function(dryerGroupData) { _this.onDryerGroupSaveClicked(dryerGroupData); },
                    onDryerGroupUpdateClicked: function(dryerGroupData) { _this.onDryerGroupUpdateClicked(dryerGroupData); },

                }
            });
        }
    },
    initAddEditDryerView: function() {
        var _this = this;
        if (!this.Views.AddEditDryer) {
            this.Views.AddEditDryer = new Ecolab.Views.AddEditDryer({
                containerSelector: '#addEditDyerGroupPopupContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function() {},
                    onDryerSaveClicked: function(dryerData) { _this.onDryerSaveClicked(dryerData); },
                    onDryerUpdateClicked: function(dryerData) { _this.onDryerUpdateClicked(dryerData); },
                }
            });
        }
    },
    displayBreadCrumb: function() {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabsRendered: function() {
        this.loadDryerGroupData();
    },
    onDryerRendered: function() {
        if (!this.dryerTypes)
            this.loadDryerTypes();
    },
    onAddDryerGroupClicked: function() {
        var data = this.Model.addNewDryerGroup();
        this.Views.AddEditDryerGroupView.setData(data);
    },
    onEditDryerGroupClicked: function(data) {
        this.Views.AddEditDryerGroupView.setData(data);
    },
    loadDryerGroupData: function() {
        this.Model.loadDryerGroupData();
    },
    loadDryerTypes: function() {
        this.Model.loadDryerTypes();
    },
    onDryerGroupDataLoaded: function(data) {
        var drData = {};
        drData.allowEdit = (this.settings.accountInfo.MaxLevel >= 7);
        drData.data = data;
        this.Views.DryerView.setData(drData);
    },
    onDryerTypesLoaded: function(dryerTypes) {
        var _this = this;
        this.dryerTypes = dryerTypes;
    },
    //Create Dryer Group
    onDryerGroupSaveClicked: function(dryerGroupData) {
        this.Model.createDryerGroup(dryerGroupData);
    },
    createDryerGroup: function(dryerGroupData) {
        this.Model.createDryerGroup(dryerGroupData);
    },
    onDryerGroupCreated: function(dryerGroupData) {
        $('#myModal').modal('hide');
        this.Views.DryerView.showSucessMessage('<label data-localize ="FIELD_DRYERGROUPADDEDSUCCESSFULLY" class="k-success-message">Dryer group added successfully.</label>');
        this.loadDryerGroupData();
    },
    onDryerGroupCreationFailed: function(dryerGroupData, description) {
        if (description == 301) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NAMEALREADYEXIST" class="k-error-message">Name already exists. Please use a different name.</label>');
        } else if (description == 302) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_DRYERGROUPDOESNOTEXIST" class="k-error-message">Dryer group does not exist.</label>');
        } else if (description == 51030) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
        } else if (description == 60000) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        } else if (description == 51060) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
        } else {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_DRYERGROUPADDITIONFAILED" class="k-error-message">Dryer group addition failed.</label>');
        }
    },

    //Update Dryer Group
    onDryerGroupUpdateClicked: function(dryerGroupData) {
        this.Model.updateDryerGroup(dryerGroupData);
    },
    onDryerGroupUpdated: function(dryerData) {
        $('#myModal').modal('hide');
        this.Views.DryerView.showSucessMessage('<label data-localize ="FIELD_DRYERGROUPUPDATEDSUCCESSFULLY" class="k-success-message">Dryer group updated successfully.</label>');
        this.loadDryerGroupData();
    },
    onDryerGroupUpdationFailed: function(dryerData, description) {
        if (description == 301) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NAMEALREADYEXIST" class="k-error-message">Name already exists. Please use a different name.</label>');
        } else if (description == 302) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NODRYERSEXISTS" class="k-error-message">No Dryers exists.</label>');
        } else if (description == 51030) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
        } else if (description == 60000) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        } else if (description == 51060) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
        } else {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_DRYERGROUPUPDATIONFAILED" class="k-error-message">Dryer group updation failed.</label>');
        }
    },

    //Delete Dryer Group
    onDeleteDryerGroupClicked: function (id, dryerGroupData) {
        dryerGroup = dryerGroupData;
        dryerGroup.Id = id;
        dryerGroup.Name = dryerGroupData.DryerGroupName;
        var _this = this;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISRECORD', 'Are you sure you want to delete this Record?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Model.deleteDryerGroup(dryerGroup);
                    }
                },

                No: {
                    Callback: function() {
                        Cdialog.addClass('hide');
                    }
                }
            }
        });
    },
    onDryerGroupDeleted: function(dryerGroupData) {
        this.Views.DryerView.showSucessMessage('<label data-localize ="FIELD_DRYERGROUPDELETEDSUCCESSFULLY" class="k-success-message">Dryer Group deleted successfully.</label>');
        this.loadDryerGroupData();
    },
    onDryerGroupDeletionFailed: function(dryerGroupData, description) {
        if (description == 501 ||description.status == 500) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_METERASSOCIATED" class="k-error-message">It is not possible to delete as the group/machine connected with Meters.</label>');
        } else if (description == 51030) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
        } else if (description == 51060) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
        } else if (description == 60000) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        } else {

            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_DRYERDELETIONFAILED" class="k-error-message">Dryer group deletion failed.</label>');
        }
    },

    /////////////Dryer////////////////
    onAddDryerClicked: function(groupId, units) {
        var data = this.Model.addNewDryer(groupId, units, this.dryerTypes);
        this.Views.AddEditDryer.setData(data);
    },

    //Create Dryer
    onDryerSaveClicked: function(dryerData) {
        this.Model.createDryer(dryerData);
    },
    onDryerCreated: function(dryerData) {
        $('#myModal').modal('hide');
        this.Views.DryerView.showSucessMessage('<label data-localize ="FIELD_DRYERADDEDSUCCESSFULLY" class="k-success-message">Dryer added successfully.</label>');
        this.loadDryerGroupData();
    },
    onDryerCreationFailed: function(dryerGroupData, description) {
        if (description == 301) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NAMEALREADYEXIST" class="k-error-message">Name already exists. Please use a different name.</label>');
        } else if (description == 302) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NUMBERALREADYEXIST" class="k-error-message">Number already exists. Please use a different number.</label>');
        } else if (description == 303) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NUMBERANDNAMEALREADYEXIST" class="k-error-message">Number & name already exists. Please use a different number & name.</label>');
        } else if (description == 51030) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
        } else if (description == 51060) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
        } else if (description == 60000) {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        } else {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_DRYERADDITIONFAILED" class="k-error-message">Dryer addition failed.</label>');
        }
    },
    onInlineEditDryerLinkClicked: function(e, data) {
        this.Views.DryerView.showEditOnInlineEditLink(e, this.dryerTypes, data);
    },

    //update dryer
    onEditDryerClicked: function(data) {
        data.DryerTypes = this.dryerTypes;
        this.Views.AddEditDryer.setData(data);
    },

    onDryerUpdateClicked: function(dryerData, isInline) {
        this.Model.updateDryer(dryerData, isInline);
    },
    onDryerUpdated: function(dryerData) {
        $('#myModal').modal('hide');
        this.Views.DryerView.showSucessMessage('<label data-localize ="FIELD_DRYERUPDATEDSUCCESSFULLY" class="k-success-message">Dryer updated successfully.</label>');
        this.loadDryerGroupData();
    },
    onDryerUpdationFailed: function(dryerData, description, isInline) {
        if (description == 301) {
            if (isInline)
                this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_NAMEALREADYEXIST" class="k-error-message">Name already exists. Please use a different name.</label>');
            else
                this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NAMEALREADYEXIST" class="k-error-message">Name already exists. Please use a different name.</label>');
        } else if (description == 302) {
            if (isInline)
                this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_NUMBERALREADYEXIST" class="k-error-message">Number already exists. Please use a different number.</label>');
            else
                this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NUMBERALREADYEXIST" class="k-error-message">Number already exists. Please use a different number.</label>');
        } else if (description == 303) {
            if (isInline)
                this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_NUMBERANDNAMEALREADYEXIST" class="k-error-message">Number & name already exists. Please use a different number & name.</label>');
            else
                this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_NUMBERANDNAMEALREADYEXIST" class="k-error-message">Number & name already exists. Please use a different number & name.</label>');
        } else if (description == 51030) {
            if (isInline) {
                this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
            } else {
                this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
            }
        } else if (description == 51060) {
            if (isInline) {
                this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            } else {
                this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
            }
        } else if (description == 60000) {
            if (isInline) {
                this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            } else {
                this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
            }
        } else {
            this.Views.DryerView.showErrorMessage('<label data-localize ="FIELD_DRYERDUPDATIONFAILED" class="k-error-message">Dryer updation failed.</label>');
        }
    },

    //Delete Dryer
    onDeleteDryerClicked: function (id, dryerData) {
        var dryer = {};
        dryer.DryerType = {};
        var _this = this;
        var Cdialog = $('#ConfirmDialog');
        Cdialog.removeClass('hide');
        dryer.Id = id;
        dryer.Number = dryerData.Number;
        dryer.GroupId = dryerData.GroupId;
        dryer.Name = dryerData.Name;
        dryer.Nominalload = dryerData.Nominalload;
        dryer.DesiredUnits = dryerData.DesiredUnits;
        dryer.DryerType.Id = dryerData.DryerTypeId;
        dryer.LastModifiedTimeStampDryer = dryerData.LastModifiedTimeStampDryer;
        this.Views.confirmDialog.setData({
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISRECORD', 'Are you sure you want to delete this Record?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        Cdialog.addClass('hide');
                        _this.Model.deleteDryer(dryer);
                    }
                },
                No: {
                    Callback: function() {
                        Cdialog.addClass('hide');
                    }
                }
            }
        });
    },
    onDryerDeleted: function() {
        this.Views.DryerView.showSucessMessage('<label data-localize ="FIELD_DRYERDELETEDSUCCESSFULLY" class="k-success-message">Dryer deleted successfully.</label>');
        this.loadDryerGroupData();
    },
    onDryerDeletionFailed: function(dryerData, description) {
        if (description == 501) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_METERASSOCIATED" class="k-error-message">It is not possible to delete as the group/machine connected with Meters.</label>');
        } else if (description == 51030) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
        } else if (description == 51060) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
        } else if (description == 60000) {
            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
        } else {

            this.Views.DryerView.showHomePageErrorMessage('<label data-localize ="FIELD_DRYERGROUPDELETIONFAILED" class="k-error-message">Dryer Group deletion failed.</label>');
        }
    },
    savePage: function () {
        var view = this.Views.DryerView;
        if (view) {
            view.clearStatusMessage();
            if (view.validate()) {
                view.onSaveTrClicked();
                this.isDirty = false;
            }
        }
    },
};