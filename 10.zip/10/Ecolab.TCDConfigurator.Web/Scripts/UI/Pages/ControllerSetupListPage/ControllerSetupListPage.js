﻿Ecolab.Presenters.ControllerSetupListPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.ControllerSetupListPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);

        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onControllerSetupListDataLoaded: function (data) { _this.onControllerSetupListDataLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.Model.loadControllerSetupListData();
        this.onPageRendered();
    },

    initListView: function () {
        var _this = this;
        if (!this.Views.ControllerSetupListView) {
            this.Views.ControllerSetupListView = new Ecolab.Views.ControllerSetupList(
                        {
                            containerSelector: '#tabContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                onRendered: function () { },
                                onRuleClicked: function (id) { _this.navigateToConfigPage(id); },
                                loadNavigationMenuListView: function (id) { _this.loadNavigationMenuView(); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); }
                            }
                        });
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_CONTROLLER SETUP', 'Dispenser Setup');
        breadCrumbData.url = "/ControllerSetupList";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadControllerSetupListDataData: function () {

        this.Model.loadControllerSetupListData(1);
    },
    onControllerSetupListDataLoaded: function (data) {
        this.Views.ControllerSetupListView.setData(this.settings.accountInfo);
    },
    loadNavigationMenuView: function () {
        this.loadNavigationMenuListView();
    }
};