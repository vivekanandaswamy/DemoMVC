Ecolab.Presenters.TunnelCompartmentPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.DropdownData = null;
    this.message = null;
    this.savedCompartmentData = null;
    this.originalSavedCompartments = null;
    this.compartmentData = null;
    this.oldCompartment = null;
    this.loadData = null;
};

//creating the proto type for Compartment presenter
Ecolab.Presenters.TunnelCompartmentPage.prototype = {
    //initiate the base views for compartments for tunnel.
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherTabsView();
        this.initTunnelCompartmentsView();
        this.initMovePump();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    // initiate the base model for compartments for tunnel.
    initmodel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    // adding the additional model options for the compatments for tunnel.
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    // adding the get model events from model
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    //getting the callback and error call back methods from the model.
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onSaved: function (data, isSaveAndClose) { _this.onSaved(data, isSaveAndClose); },
            onDropDownDataLoaded: function (data) { _this.onDropDownDataLoaded(data); },
            onSaveFailed: function (description, data) { _this.onSaveFailed(description, data); },
            onComaprtmentsLoad: function (data) { _this.onComaprtmentsLoad(data); },
            onCompartmentCountLoad: function (data) { _this.onCompartmentCountLoad(data); },
            onMovePumpSaved: function (data) { _this.onMovePumpSaved(data); },
            onMovePumpSavedFailed: function (description, data) { _this.onMovePumpSavedFailed(description, data); },
        }
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initWasherTabsView: function () {
        var _this = this;
        if (!this.Views.WasherTabsView) {
            this.Views.WasherTabsView = new Ecolab.Views.WasherTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () { _this.loadDropDownsData(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    ontabFormulaClicked: function () { _this.ontabFormulaClicked(); },
                }
            });
        }
        this.Views.WasherTabsView.setData(this.settings.accountInfo);
    },
    initTunnelCompartmentsView: function () {
        var _this = this;
        if (!this.Views.TunnelCompartmentView) {
            this.Views.TunnelCompartmentView = new Ecolab.Views.TunnelCompartment({
                containerSelector: '#tabCompartmentsContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    savePage: function (isSaveAndClose) { _this.savePage(isSaveAndClose); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    deleteConformation: function (ddl) { return _this.deleteConformation(ddl); },
                    moveConfirmation: function (ddl) { return _this.moveConfirmation(ddl); },
                    onCompartmentChange: function (Id, currCompartmentId) { _this.onCompartmentChange(Id, currCompartmentId); },
                    CompartmentPrint: function (data) { _this.CompartmentPrint(data); },
                    updateFlag: function () {
                        _this.updateFlag();
                    }
                }
            });
        }
    },
    CompartmentPrint: function (data) {
        this.RedirectLocation(data);
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHER GROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },

    ontabFormulaClicked: function () {
        this.RedirectLocation('./WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + '&WasherId=' + this.settings.accountInfo.TunnelId);
    },
    updateFlag: function () {
        this.isDirty = false;
    },
    loadCompartmentsModelData: function () {
        this.Model.loadCompartmentsModelData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.TunnelId, 1, this.settings.accountInfo.RegionId, this.settings.accountInfo.ControllerId)
    },
    //sets the data passing to view for binding.
    onComaprtmentsLoad: function (data) {
        this.compartmentData = data;
        drData = data;
        drData.DropdownData = data.TunnelDropDowns; //this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.Id = this.settings.accountInfo.TunnelId;
        drData.TotalCompartments = this.settings.accountInfo.Compartments;
        drData.ControllerId = this.settings.accountInfo.ControllerId;
        drData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.SavedCompartmentdata = this.savedCompartmentData;
        if (drData.CompartmentNumber == 0)
            drData.CompartmentNumber = 1;
        if (data.PumpAssociationList.length > 0)
            drData.IsDosagePoint = true;
        else
            drData.IsDosagePoint = false;

        var compartments = [];
        for (var i = 1; i <= this.settings.accountInfo.Compartments; i++) {
            compartments.push({
                Id: i
            });
        }
        drData.Compartments = compartments;
        drData.massage = this.message;
        this.Views.TunnelCompartmentView.setData(drData);
        this.Views.TunnelCompartmentView.onSaved(this.message);
        this.message = '';
    },
    loadDropDownsData: function () {
        this.Model.loadDropDownsData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.RegionId, this.settings.accountInfo.ControllerId, this.settings.accountInfo.TunnelId, this.settings.accountInfo.WasherGroupId);
    },
    onDropDownDataLoaded: function (data) {
        this.DropdownData = data;
        this.loadData = 1;
        this.getCompartmentCount();
    },
    savePage: function (isSaveAndClose) {
        var _this = this;
        var view = this.Views.TunnelCompartmentView;
        if (view) {
            if (view.validate()) {
                var tunnelData = this.Views.TunnelCompartmentView.getData();
                _this.Model.save(tunnelData, isSaveAndClose);
            }
        }
    },
    onSaved: function (data, isSaveAndClose) {
        var _this = this;
        this.isDirty = false;
        if (isSaveAndClose) {
            window.location = '/WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + "&data=List";
        }
        
        this.loadData = 0;
        this.getCompartmentCount();
        this.onCompartmentChange(data.CompartmentNumber);
        
        if (drData && drData.PumpAssociationList > 0) {
            this.Views.TunnelCompartmentView.updateDosagePoint(true);
        }

        else {
            $.each(drData.PumpAssociationList, function (key, value) {
                if (value.IsDeleted == 0) {
                    _this.Views.TunnelCompartmentView.updateDosagePoint(true);
                    return false;
                }
                else {
                    _this.Views.TunnelCompartmentView.updateDosagePoint(false);
                }
            });
        }
        this.message = "<label Class=\"k-success-message\">" + ($.GetLocaleKeyValue("FIELD_TUNNELDETAILSUPDATEDSUCCESSFULLY", 'Tunnel details updated successfully.')) + "</label>";
        drData.massage = this.message;
        drData.SavedCompartmentCount = this.savedCompartmentData;
    },
    onSaveFailed: function (description, data) {
        drData = data;
        drData.DropdownData = this.DropdownData;
        drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.RegionId = this.settings.accountInfo.RegionId;
        drData.Id = this.settings.accountInfo.TunnelId;
        drData.TotalCompartments = this.settings.accountInfo.Compartments;
        drData.ControllerId = this.settings.accountInfo.ControllerId;
        drData.ControllerTypeId = this.settings.accountInfo.ControllerTypeId;
        drData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        drData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        drData.SavedCompartmentCount = this.savedCompartmentData;
        if (drData.CompartmentNumber == 0)
            drData.CompartmentNumber = 1
        if (data.PumpAssociationList.length > 0)
            drData.IsDosagePoint = true;
        else
            drData.IsDosagePoint = false;

        var compartments = [];
        for (var i = 1; i <= this.settings.accountInfo.Compartments; i++) {
            compartments.push({
                Id: i
            })
        }
        drData.Compartments = compartments;
        drData.Mode = "Edit";
        if (description == '51001') {
            this.message = '<label data-localize ="FIELD_ANINVALIDWASHERGROUPPROVIDED" class="k-error-message">An invalid Washer Group provided.</label>';
        }
        else if (description == '51002') {
            this.message = '<label data-localize ="FIELD_SPECIFIEDPLANTWASHERNUMBERALREADYEXISTS" class="k-error-message">Specified Plant Washer Number or name already exists.</label>';
        }
        else if (description == '51003') {
            this.message = '<label data-localize ="FIELD_ANINVALIDCONTROLLERWASPROVIDED" class="k-error-message">An invalid Controller was provided.</label>';
        }
        else if (description == '51004') {
            this.message = '<label data-localize ="FIELD_ANASSOCIATEDFORMULACANNOTBESPECIFIEDASENDOFFORMULA" class="k-error-message">An associated formula cannot be specified as End-Of-Formula.</label>';
        }
        else if (description == '51005') {
            this.message = '<label data-localize ="FIELD_ANINVALIDWASHERMODEWASPROVIDED" class="k-error-message">An invalid Washer Mode was provided.</label>';
        }
        else if (description == '51030') {
            this.message = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">  Record count does not match..Resynch is in progress.</label>';
        }
        else if (description == '51060') {
            this.message = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">  Unable to save changes , Connectivity issue, Please try again later.</label>';
        }
        else if (description == '60000') {
            this.message = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message"> Record not in synch..Resynch is in progress.</label>';
        }
        drData.massage = this.message;
        this.Views.TunnelCompartmentView.setData(drData);
    },
    onCompartmentChange: function (id,currCompartmentId) {
        var _this = this;
        if (this.isDirty) {
            var cDialog = $('#ConfirmDialog');
            cDialog.removeClass('hide');
            var dialogOptions = {
                HeaderText: $.GetLocaleKeyValue('FIELD_PENDINGCHANGES', 'Pending Changes'),
                BodyMessage: $.GetLocaleKeyValue('FIELD_DOYOUWANTTOSAVECHANGES', 'Do you want to save changes?'),
                Buttons: {
                    Yes: {
                        Callback: function () {
                            if (_this.savePage) {
                                $('#ddlCompatment').val(currCompartmentId);
                                _this.savePage(false);
                            }
                            else {
                                _this.isDirty = false;
                            }
                            cDialog.addClass('hide');
                        },
                        CallbackParameters: null
                    },
                    No: {
                        Callback: function () {
                            cDialog.addClass('hide');
                            _this.isDirty = false;
                            _this.Model.loadCompartmentsModelData(_this.settings.accountInfo.EcoLabAccountNumber, _this.settings.accountInfo.WasherGroupId, _this.settings.accountInfo.TunnelId, id, _this.settings.accountInfo.RegionId, _this.settings.accountInfo.ControllerId)
                        },
                        CallbackParameters: null
                    }
                }
            };
            this.Views.confirmDialog.setData(dialogOptions);
        } else {
        this.Model.loadCompartmentsModelData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.TunnelId, id, this.settings.accountInfo.RegionId, this.settings.accountInfo.ControllerId)
        }
    },
    deleteConformation: function (ddl) {
        var _this = this;

        var returnVale = false;
        var cDialog = $('#ConfirmDialog');
        cDialog.removeClass('hide');
        var dialogOptions = {
            HeaderText: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            BodyMessage: $.GetLocaleKeyValue('FIELD_AREYOUSUREYOUWANTTODELETETHISCHEMICAL', 'Are Sure you want to delete Chemical?'),
            Buttons: {
                Yes: {
                    Callback: function () {
                        cDialog.addClass('hide');
                        _this.Views.TunnelCompartmentView.onConform(ddl);
                       // _this.savePage(false);
                    },
                    CallbackParameters: null
                },
                No: {
                    Callback: function () {
                        cDialog.addClass('hide');
                        returnVale = false;
                    },
                    CallbackParameters: null
                }
            }
        };
        this.Views.confirmDialog.setData(dialogOptions);
        return returnVale;
    },
    initMovePump: function () {
        var thisObject = this;
        if (!thisObject.Views.MovePump) {
            thisObject.Views.MovePump = new Ecolab.Views.MovePump({
                containerSelector: "#tabMovePumpContainer",
                accountInfo: thisObject.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { thisObject.onMovePumpViewRendered(); },
                    onCancelClicked: function (e) { thisObject.onCancelMovePumpClicked(e); },
                    onMovePumpClicked: function (data) { thisObject.onMovePumpClicked(data); },

                }
            });
        }
    },
    moveConfirmation: function (data) {
        var result = 0;

        this.originalSavedCompartments = $.extend(true, [], data.SavedCompartmentdata);
        $.each(data.SavedCompartmentdata, function (index, value) {
            if (value.CompartmentNumber == data.CompartmentNumber) {
                result = index;
            }
        });
        
        data.SavedCompartmentdata.splice(result, 1);
        data.SavedCompartmentdata.sort(function(a, b) {
            return parseFloat(a.CompartmentNumber) - parseFloat(b.CompartmentNumber);
        });
        data.count = data.SavedCompartmentdata.length;
        this.Views.MovePump.setData(data);
        data.SavedCompartmentdata = this.originalSavedCompartments;
        this.savedCompartmentData = this.originalSavedCompartments;
    },
    onCancelMovePumpClicked: function () {
        $('#myModal').modal('toggle');
    },
    onMovePumpViewRendered: function () {
    	$('#myModal').modal({
    		show: true,
    		backdrop: 'static',
    		keyboard: false
    	});
    },
    onMovePumpClicked: function (data) {
        var newCompartment = $.grep(this.savedCompartmentData, function (item) { return item.CompartmentNumber == data.newCompartmentNumber })

        var drData = {};
        drData.NewTunnelCompartmentId = newCompartment[0].tunnelCompartmentId;
        drData.tunnelCompartmentId = data.oldCompartmentId;
        drData.Id = this.settings.accountInfo.TunnelId;
        drData.ControllerEquipmentSetupId = data.controllerEquipmentSetupId;
        drData.EcolabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
        drData.NewCompartmentNumber = data.newCompartmentNumber;
        drData.CompartmentNumber = data.oldCompartmentNumber;
        drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
        drData.LastModifiedTimeStamp = data.LastModifiedTimeStamp;
        this.oldCompartment = data.oldCompartmentNumber;
        this.Model.MovePump(drData);
    },
    getCompartmentCount: function () {
        this.Model.getCompartmentCount(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.TunnelId);
    },
    onCompartmentCountLoad: function (data) {
        this.savedCompartmentData = data;
        if (this.loadData == 1) {
            this.loadCompartmentsModelData();
        }        
    },
    onMovePumpSaved: function (data) {
        var _this = this;
        this.isDirty = false;
        $('#myModal').modal('toggle');
        this.message = "<label Class=\"k-success-message\">" + ($.GetLocaleKeyValue("FIELD_PRODUCTSMOVEDSUCCESSFULLY", 'Products moved successfully.')) + "</label>"
        this.onCompartmentChange(this.oldCompartment);
    },
    onMovePumpSavedFailed: function(data){
        var _this = this;
        this.isDirty = false;
        $('#myModal').modal('toggle');
        if (data == 51030) {
            this.message = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">  Record count does not match..Resynch is in progress.</label>';
        }
        else if (data == 51060) {
            this.message = '<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">  Unable to save changes , Connectivity issue, Please try again later.</label>';
        }
        else if (data == 60000) {
            this.message = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message"> Record not in synch..Resynch is in progress.</label>';
        }
        else {
            this.message = "<label Class=\"k-error-message\">" + ($.GetLocaleKeyValue("FIELD_PRODUCTSMOVEDFAILED", 'Products moved Failed.')) + "</label>"
        }
        this.onCompartmentChange(this.oldCompartment);
    }
    
}