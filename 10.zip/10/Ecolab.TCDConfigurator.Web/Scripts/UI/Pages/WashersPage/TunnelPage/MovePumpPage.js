Ecolab.Presenters.MovePumpPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.DropdownData = null;
    this.message = null;
};

//creating the proto type for Compartment presenter
Ecolab.Presenters.MovePumpPage.prototype = {
    //initiate the base views for compartments for tunnel.
    initViews: function () {
        this.base.initViews.call(this);
        
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    // initiate the base model for compartments for tunnel.
    initmodel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    // adding the additional model options for the compatments for tunnel.
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    // adding the get model events from model
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    //getting the callback and error call back methods from the model.
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onSaved: function (data, isSaveAndClose) { _this.onSaved(data, isSaveAndClose); },
            onDropDownDataLoaded: function (data) { _this.onDropDownDataLoaded(data); },
            onSaveFailed: function (description, data) { _this.onSaveFailed(description, data); },
            onComaprtmentsLoad: function (data) { _this.onComaprtmentsLoad(data); },
        }
    },
    afterInit: function () {
        this.base.afterInit.call(this);
    },
    
}