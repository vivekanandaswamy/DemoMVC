﻿Ecolab.Presenters.TunnelConnectionsPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.DropdownData = null;
    this.message = null;
};

//creating the proto type for Compartment presenter
Ecolab.Presenters.TunnelConnectionsPage.prototype = {
    //initiate the base views for compartments for tunnel.
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherTabsView();
        this.initTunnelConnectionsView();
        //for confirmation box
        this.Views.confirmDialog = new Ecolab.Views.ConfirmDialog();
        this.Views.confirmDialog.init();
    },
    // initiate the base model for compartments for tunnel.
    initmodel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    // adding the additional model options for the compatments for tunnel.
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    // adding the get model events from model
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    //getting the callback and error call back methods from the model.
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetData: function (data) { _this.onGetData(data); },            
        }
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initWasherTabsView: function () {
        var _this = this;
        if (!this.Views.WasherTabsView) {
            this.Views.WasherTabsView = new Ecolab.Views.WasherTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () { _this.onTabsRendered(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    ontabFormulaClicked: function () { _this.ontabFormulaClicked(); },
                }
            });
        }
        this.Views.WasherTabsView.setData(this.settings.accountInfo);
    },
    initTunnelConnectionsView: function () {
        var _this = this;
        if (!this.Views.TunnelConnectionsView) {
            this.Views.TunnelConnectionsView = new Ecolab.Views.TunnelConnections({
                containerSelector: '#tabConnectionsContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {                    
                    onRendered: function () { _this.onTabsRendered(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                }
            });
        }
        //_this.onTabsRendered();
    },
    ontabFormulaClicked: function () {
        this.RedirectLocation('./WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + '&WasherId=' + this.settings.accountInfo.TunnelId);
    },
    updateFlag: function () {
        this.isDirty = false;
    },
    loadConectionsModelData: function () {        
        this.Model.loadConnectionsModelData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.TunnelId, 1, this.settings.accountInfo.RegionId, this.settings.accountInfo.ControllerId)
    },
    //sets the data passing to view for binding.
    onConnectionsLoad: function (data) {
        
    },
    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHER GROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    onTabsRendered: function () {        
        this.loadConectionsModelData(this.settings.accountInfo.TunnelId, this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.Compartments, this.settings.accountInfo.RegionId, this.settings.accountInfo.ControllerId);        
    },
    onGetData: function (data) {
        dr = [];
        dr.data = data;
        dr.TunnelId = this.settings.accountInfo.WasherId;        
        var hdnData = {
            TunnelId: this.settings.accountInfo.TunnelId
            ,WasherGroupId: this.settings.accountInfo.WasherGroupId
            , EcoLabAccountNumber:this.settings.accountInfo.EcoLabAccountNumber
            , Compartments: this.settings.accountInfo.Compartments
            , RegionId:this.settings.accountInfo.RegionId
            , ControllerId: this.settings.accountInfo.ControllerId
            , ControllerTypeId: this.settings.accountInfo.ControllerTypeId
            , ControllerModelId: this.settings.accountInfo.ControllerModelId
            , WasherGroupTypeId: this.settings.accountInfo.WasherGroupTypeId
        }
        dr.message = this.message;        
        this.Views.TunnelConnectionsView.setData(dr, hdnData);
    },
}