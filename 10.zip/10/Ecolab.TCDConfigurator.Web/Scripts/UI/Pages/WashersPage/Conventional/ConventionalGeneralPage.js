// JavaScript source code
Ecolab.Presenters.ConventionalGeneralPage = function (options) {
	this.settings = $.extend(this.defaults, options);
	this.DropdownData = null;
	this.message = null;
	this.ConventionalId = null;
	this.washerGroupId = 0;
	this.Mode = null;
	this.WasherModelId = null;
	this.LfsWasher = null;
	this.newWasherGroupId = null;
};
Ecolab.Presenters.ConventionalGeneralPage.prototype = {
	initViews: function () {
		this.base.initViews.call(this);
		this.initConventionalGeneralTabsView();
		this.initConventionalGeneralView();
	},
	initModel: function () {
		this.base.initModel.call(this);
		this.Model.init();
	},
	addModelOptions: function (modelOptions) {
		this.base.addModelOptions.call(this, modelOptions);
	},
	addModelEventHandlers: function (eventHandlers) {
		this.base.addModelEventHandlers.call(this, eventHandlers);
		$.extend(eventHandlers, this.getModelEventHandlers());
	},
	getModelEventHandlers: function () {
		var _this = this;
		return {
			onDropDownDataLoaded: function (data) { _this.onDropDownDataLoaded(data); },
			onSaved: function (data, isSaveAndClose) { _this.onSaved(data, isSaveAndClose); },
			onSizeListLoaded: function (data) { _this.onSizeListLoaded(data); },
			onLfsWasherListLoaded: function (data) { _this.onLfsWasherListLoaded(data); },
			onFlowSwitchNumberLoaded: function (data) { _this.onFlowSwitchNumberLoaded(data); },
			onWasherModeListLoaded: function (data) { _this.onWasherModeListLoaded(data); },
			onSaveFailed: function (description, data) { _this.onSaveFailed(description, data); },
			onConventionalDataLoaded: function (data) { _this.onConventionalDataLoaded(data); },
			onUpdate: function (data, isSaveAndClose) { _this.onUpdate(data, isSaveAndClose); },
			onUpdateFailed: function (description, data) { _this.onSaveFailed(description, data); },
			onFormulaDataLoad: function (WasherGroupData) { _this.onFormulaDataLoad(WasherGroupData); },
		};
	},
	afterInit: function () {
		this.base.afterInit.call(this);
		this.showMainHeader();
		this.displayBreadCrumb();
	},

	initConventionalGeneralTabsView: function () {
		var _this = this;

		if (!this.Views.ConventionalTabView) {
			this.Views.ConventionalTabView = new Ecolab.Views.WasherTabs({
				containerSelector: '#tabContainer',
				eventHandlers: {
					rendered: function () {
						_this.onTabsRendered(); //_this.loadControllerModelDataData(_this.settings.accountInfo.RegionId);
					},
					generalTabClicked: function () { _this.onGeneralTabClicked(); },
					onRedirection: function (url) { return _this.RedirectLocation(url); },
					setupTabClicked: function () { _this.onSetupTabClicked(); },
					ontabFormulaClicked: function () { _this.ontabFormulaClicked(); },
				}
			});
		}
		this.Views.ConventionalTabView.setData(this.settings.accountInfo);
	},

	initConventionalGeneralView: function () {
		var _this = this;
		if (!this.Views.ConventionalGeneralView) {
			this.Views.ConventionalGeneralView = new Ecolab.Views.ConventionalGeneral({
				containerSelector: '#tabGeneralContainer',
				accountInfo: _this.settings.accountInfo,
				eventHandlers: {
					rendered: function () { },
					savePage: function (isSaveAndClose) { _this.savePage(isSaveAndClose); },
					getSize: function (model) { _this.getSize(model); },
					getLfsWasher: function (controllerId) { _this.getLfsWasher(controllerId); },
					getWasherMode: function (controllerId) { _this.getWasherMode(controllerId); },
					onCancel: function () { _this.onCancel(); },
					onRedirection: function (url) { return _this.RedirectLocation(url); },
					madeChangeFalse: function () { _this.madeChangeFalse(); }
				}
			});
		}
	},
	onTabsRendered: function () {
		this.loadDropDownsData();
	},
	madeChangeFalse: function () {
		this.isDirty = false;
	},

	ontabFormulaClicked: function () {
		if (this.settings.accountInfo.ConventionalId) {
			this.RedirectLocation('./WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + '&WasherId=' + this.settings.accountInfo.ConventionalId);
		}
	},

	displayBreadCrumb: function () {
		var breadCrumbData = {};
		breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHER GROUPS', 'Washer Groups');
		breadCrumbData.url = "/WasherGroup";
		this.showPlantBreadCrumb("plantSets", breadCrumbData);
	},
	loadDropDownsData: function () {
		if (this.settings.accountInfo.WasherGroupId > 0) {
			this.washerGroupId = this.settings.accountInfo.WasherGroupId;
		}

		this.Model.loadDropDownsData(this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.RegionId, this.washerGroupId);
	},
	onDropDownDataLoaded: function (data) {
		this.DropdownData = data;
		this.loadConventionalView();
	},
	loadConventionalView: function () {
		var _this = this;

		var id = this.settings.accountInfo.ConventionalId;
		var washerGroupId = this.settings.accountInfo.WasherGroupId;
		if (id != null && washerGroupId != null) {
			_this.Model.getConventionalData(id, washerGroupId, this.settings.accountInfo.EcoLabAccountNumber, this.settings.accountInfo.RegionId);
		} else {
			drData = [];
			drData.DropdownData = this.DropdownData;
			drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
			drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
			drData.RegionId = this.settings.accountInfo.RegionId;
			drData.Id = this.settings.accountInfo.ConventionalId;
			drData.ControllerId = drData.DropdownData.WasherGroupList[0].ControllerId;
			drData.ControllerModelId = drData.DropdownData.WasherGroupList[0].ControllerModelId;
			drData.ControllerTypeId = drData.DropdownData.WasherGroupList[0].ControllerTypeId;
			if (drData.ControllerModelId == 11 && drData.WasherDosingNumber == 1) {
				drData.UsePumpOfGroup = 1;
			}
			else if (drData.ControllerModelId == 11 && drData.WasherDosingNumber == 2) {
				drData.UsePumpOfGroup = 2;
			}
			else {
				drData.UsePumpOfGroup = 0;
			}
			drData.MaxPlantWashNumber = this.settings.accountInfo.MaxPlantWashNumber;
			this.Views.ConventionalGeneralView.setData(drData);
		}
	},
	getSize: function (model) {
		var _this = this;
		_this.Model.getSizeList(model, this.settings.accountInfo.RegionId);
	},
	onSizeListLoaded: function (data) {
		this.Views.ConventionalGeneralView.LoadSizeDropDown(data, this.WasherModelId);
	},
	getLfsWasher: function (controllerId) {
		var _this = this;
		_this.Model.getLfsWasherList(controllerId, this.settings.accountInfo.EcoLabAccountNumber);
	},
	getWasherMode: function (controllerId) {
		var _this = this;
		_this.Model.getWasherModeList(controllerId, this.settings.accountInfo.EcoLabAccountNumber);
	},
	onLfsWasherListLoaded: function (data) {
		var arr = [];

		for (var i = 0; i < data.LfsWasherMaxNumber; i++) {
			arr.push(i + 1);
		}
		this.Views.ConventionalGeneralView.LoadLfsWasherDropDown(arr, this.LfsWasher);
	},
	onWasherModeListLoaded: function (data) {
		this.Views.ConventionalGeneralView.LoadWasherModeDropDown(data, this.Mode);
	},
	onFlowSwitchNumberLoaded: function (data) {
		var arr = [];

		for (var i = 0; i < data.FlowSwitchNumber; i++) {
			arr.push(i + 1);
		}
		this.Views.ConventionalGeneralView.LoadFlowSwitchNumberDropDown(arr, this.FlowSwitchNumber);
	},

	savePage: function (isSaveAndClose) {
		this.ConventionalId = this.settings.accountInfo.ConventionalId;
		var _this = this;
		var view = this.Views.ConventionalGeneralView;
		if (view) {
			if (view.validate()) {
				if (this.HasDuplicateTags()) {
					//view.showMessage('<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate tags found.") + '</label>');
					view.showMessage('<label class="errorutility">' + $.GetLocaleKeyValue('FIELD_DUPLICATETAGSFOUND', "Duplicate Tags found.") + '</label>');
					return false;
				} else {
					var conventionalData = this.Views.ConventionalGeneralView.getConventionalData();
					this.newWasherGroupId = conventionalData.WasherGroupIdNew;
					if ((this.ConventionalId > 0)) {
						conventionalData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
						conventionalData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
						conventionalData.RegionId = this.settings.accountInfo.RegionId;
						conventionalData.Id = this.ConventionalId;
						_this.Model.update(conventionalData, isSaveAndClose);
					} else {
						conventionalData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
						conventionalData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
						conventionalData.RegionId = this.settings.accountInfo.RegionId;
						_this.Model.save(conventionalData, isSaveAndClose);
					}
				}
			}
		}
	},

	onSaved: function (data, isSaveAndClose) {
		this.isDirty = false;
		this.settings.accountInfo.ConventionalId = data;
		if (isSaveAndClose) {
			window.location = '/WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + "&data=List";
		}
		this.message = '<label data-localize ="FIELD_CONVENTIONALSAVEDSUCCESSFULLY" class="k-success-message">Conventional saved successfully.</label>';
		if (this.newWasherGroupId != null) {
			this.settings.accountInfo.WasherGroupId = this.newWasherGroupId;
		}
		this.loadConventionalView();
		this.loadNavigationMenuListView();
		this.Views.ConventionalGeneralView.enableTabs();
		this.Views.ConventionalGeneralView.enableTabsAfterSaveClicked();
	},
	onSaveFailed: function (description, data) {
		description = description.toString();
		if (description.indexOf('@') > 0) {
			var washerId = description.split('@')[1];
			description = description.split('@')[0];
			this.settings.accountInfo.ConventionalId = washerId;
			data.Id = washerId;
			$("#hConventionalId").val(washerId);
			$("#hWashergroupId").val(data.WasherGroupId);
			$("#hControllerId").val(data.ControllerId);
		}
		drData = data;
		drData.DropdownData = this.DropdownData;
		var arr = [];

		for (var i = 0; i < this.settings.accountInfo.LfsWasher; i++) {
			arr.push(i + 1);
		}
		drData.LfsWasher = arr;
		drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
		drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
		drData.RegionId = this.settings.accountInfo.RegionId;
		drData.Id = this.settings.accountInfo.ConventionalId;
		drData.Mode = "Edit";
		var saveMsg = '<span data-localize ="FIELD_CONVENTIONALSAVEDSUCCESSFULLY" class="k-success-message">Conventional saved successfully.</span>';
		if (jQuery.type(description) != "object") {
			if (description == '51001') {
				this.message = '<label data-localize ="FIELD_ANINVALIDWASHERGROUPPROVIDED" class="k-error-message">An invalid Washer Group provided.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51002') {
				this.message = '<label data-localize ="FIELD_SPECIFIEDPLANTWASHERNUMBERALREADYEXISTS" class="k-error-message">Specified Plant Washer Number already exists.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51003') {
				this.message = '<label data-localize ="FIELD_ANINVALIDCONTROLLERWASPROVIDED" class="k-error-message">An invalid Controller was provided.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51004') {
				this.message = '<label data-localize ="FIELD_ANASSOCIATEDFORMULACANNOTBESPECIFIEDASENDOFFORMULA" class="k-error-message">An associated formula cannot be specified as End-Of-Formula.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51005') {
				this.message = '<label data-localize ="FIELD_ANINVALIDWASHERMODEWASPROVIDED" class="k-error-message">An invalid Washer Mode was provided.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51010') {
				this.message = '<label data-localize ="FIELD_LFSWASHERNUMBERALREADYEXIST" class="k-error-message">Lfs Washer Number already exist.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51012') {
			    this.message = '<label data-localize ="FIELD_ETechWASHERNUMBERALREADYEXIST" class="k-error-message">ETech Washer Number already exist.</label>';
			    this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '60000') {
                this.message = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message"> Record not in synch..Resynch is in progress.</label>';
                this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == "409") {
				this.message = '<label data-localize ="FIELD_INJECTIONSTATUS" class="k-error-message">InjectionStatus.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
			else if (description == '909') {
				this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
			} else if (description == '901') {
				this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
				this.loadConventionalView();
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
				this.Views.ConventionalGeneralView.enableTabsAfterSaveClicked();

			} else if (description == '902') {
				this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOWRITEVALUESTOPLC', "Unable to write values to PLC.") + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
				this.loadConventionalView();
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
				this.Views.ConventionalGeneralView.enableTabsAfterSaveClicked();
			}
			else if (description == '61000') {
				this.message = '<label class="k-error-message"> ' + "Maximum injection classes reached." + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
			}
			else if (description == '51060') {
			    this.message = '<label class="k-error-message"> ' + "Unable to save changes , Connectivity issue, Please try again later." + '</label>';
			    this.Views.ConventionalGeneralView.showMessage(this.message);
			    this.loadNavigationMenuListView();
			    this.Views.ConventionalGeneralView.enableTabs();
			}
			else if (description == '51011') {
				this.message = '<label class="k-error-message"> ' + "Products associated to selected controller are not part of this washergroup." + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
			}
			else if (description == 'Retri') {
				this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
				this.Views.ConventionalGeneralView.showTagMessage(this.message);
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
			}			
			else if (description == '51030') {
			    this.message = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">  Record count does not match..Resynch is in progress.</label>';
			    this.Views.ConventionalGeneralView.showMessage(this.message);
			}
			else if (description == 'PhonyWasher') {
				this.message = '<label data-localize ="FIELD_WASHERSAVEFAILED" class="k-error-message">Washer save failed.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
			else {
				this.message = saveMsg + '<label class="k-error-message"> ' + description + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'Is / are invalid.') + '</label>';
				this.Views.ConventionalGeneralView.showTagMessage(this.message, description);
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
			}
		} else {
			if (description.status == 300) {
				this.message = saveMsg + ' <label class="k-error-message">' + description.message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXISTINTHEMACHINE', 'Tags already exists in the Machine') + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
			}

			else {
				this.message = '<label data-localize ="FIELD_WASHERSAVEFAILED" class="k-error-message">Washer save failed.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
		}
	},

	onConventionalDataLoaded: function (data) {
		var _this = this;
		drData = data;
		if (data) {
			this.settings.accountInfo.ControllerId = data.ControllerId;
		}
		drData.DropdownData = this.DropdownData;
		drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
		drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
		drData.RegionId = this.settings.accountInfo.RegionId;
		drData.Id = this.settings.accountInfo.ConventionalId;
		drData.Mode = "Edit";
		this.Mode = data.WasherModeId;
		this.WasherModelId = data.WasherModelId;
		this.LfsWasher = data.LfsWasher;
		drData.message = this.message;
		var type = _this.getQueryStringByName('type');
		if (type == "WasherGroup")
			_this.findContainer('Washer', drData.Id);
		else
			_this.findContainer('Washers', drData.Id);
		this.Views.ConventionalGeneralView.setData(drData);
	},
	onUpdateFailed: function (description, data) {
		drData = data;
		drData.DropdownData = this.DropdownData;
		drData.EcoLabAccountNumber = this.settings.accountInfo.EcoLabAccountNumber;
		drData.WasherGroupId = this.settings.accountInfo.WasherGroupId;
		drData.RegionId = this.settings.accountInfo.RegionId;
		drData.Id = this.settings.accountInfo.ConventionalId;
		drData.Mode = "Edit";
		var saveMsg = '<span data-localize ="FIELD_CONVENTIONALUPDATEDSUCCESSFULLY" class="k-success-message">Conventional updated successfully.</span>';
		if (jQuery.type(description) != "object") {
			if (description == '51001') {
				this.message = '<label data-localize ="FIELD_ANINVALIDWASHERGROUPPROVIDED" class="k-error-message">An invalid Washer Group provided.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51002') {
				this.message = '<label data-localize ="FIELD_SPECIFIEDPLANTWASHERNUMBERALREADYEXISTS" class="k-error-message">Specified Plant Washer Number or name already exists.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51003') {
				this.message = '<label data-localize ="FIELD_ANINVALIDCONTROLLERWASPROVIDED" class="k-error-message">An invalid Controller was provided.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51004') {
				this.message = '<label data-localize ="FIELD_ANASSOCIATEDFORMULACANNOTBESPECIFIEDASENDOFFORMULA" class="k-error-message">An associated formula cannot be specified as End-Of-Formula.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51005') {
				this.message = '<label data-localize ="FIELD_ANINVALIDWASHERMODEWASPROVIDED" class="k-error-message">An invalid Washer Mode was provided.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51006') {
				this.message = '<label data-localize ="FIELD_ANINVALIDWASHERIDWASPROVIDEDFORUPDATING" class="k-error-message">An invalid Washer-ID was provided for Updating.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51010') {
				this.message = '<label data-localize ="FIELD_LFSWASHERNUMBERALREADYEXIST" class="k-error-message">Lfs Washer Number already exist.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '51012') {
			    this.message = '<label data-localize ="FIELD_ETechWASHERNUMBERALREADYEXIST" class="k-error-message">ETech Washer Number already exist.</label>';
			    this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '909') {
				this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_INVALIDCONTROLLERCONFIGURATION', "Invalid Controller configuration.") + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '901') {
				this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else if (description == '902') {
				this.message = saveMsg + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOWRITEVALUESTOPLC', "Unable to write values to PLC.") + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
			else if (description == '61000') {
				this.message = '<label class="k-error-message"> ' + "Maximum injection classes reached." + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
				this.loadNavigationMenuListView();
				this.Views.ConventionalGeneralView.enableTabs();
			}
			else if (description == '51060') {
			    this.message = '<label class="k-error-message"> ' + "Unable to save changes , Connectivity issue, Please try again later." + '</label>';
			    this.Views.ConventionalGeneralView.showMessage(this.message);
			    this.loadNavigationMenuListView();
			    this.Views.ConventionalGeneralView.enableTabs();
			}
			else if (description == '60000') {
			    this.message = '<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message"> Record not in synch..Resynch is in progress.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
			else if (description == '51030') {
			    this.message = '<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">  Record count does not match..Resynch is in progress.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
			else {
				this.message = saveMsg + ' <label class="k-error-message">' + description + ' ' + $.GetLocaleKeyValue('FIELD_ISAREINVALID', 'Is / are invalid.') + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
		} else {
			if (description.status == 300) {
				this.message = saveMsg + ' <label class="k-error-message">' + description.message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXISTINTHEMACHINE', 'Tags already exists in the Machine.') + '</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			} else {
				this.message = '<label data-localize ="FIELD_WASHERUPDATEFAILED" class="k-error-message">Washer updation failed.</label>';
				this.Views.ConventionalGeneralView.showMessage(this.message);
			}
		}
		drData.massage = this.message;
		this.Views.ConventionalGeneralView.setData(drData);
	},
	onUpdate: function (data, isSaveAndClose) {
		this.isDirty = false;
		if (isSaveAndClose) {
			window.location = '/WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + "&data=List";
		}
		this.message = '<label data-localize ="FIELD_CONVENTIONALUPDATEDSUCCESSFULLY" class="k-success-message">Conventional updated successfully.</label>';
		if (this.newWasherGroupId != null) {
			this.settings.accountInfo.WasherGroupId = this.newWasherGroupId;
		}
		this.loadConventionalView();
		this.Views.ConventionalGeneralView.enableTabsAfterSaveClicked();
	},
	onCancel: function () {
		this.onRedirection('./WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + "&data=Cancel");
	},
	openCurrentNav: function (typeName, id) {
		var container = $(this.Views.NavigationMenuView.options.containerSelector);
		var element = container.find('.cssmenu li.current-item a[typename="' + typeName + '"][id=' + id + ']').parent('li');
		element.addClass('active');
		if (typeName == "Washer") {
			element.parent('ul').parent('li').addClass('open');
			element.parent('ul').parent('li').parent('ul').parent('li').addClass('open');
			element.parent('ul').slideDown();
			element.parent('ul').parent('li').parent('ul').slideDown();
		}
	},
	findContainer: function (typeName, id) {
		var _this = this;
		var retryCount = (typeof retryCount == "undefined" ? 10 : retryCount - 1);
		if (retryCount === 0) return; //give up on loading the template
		setTimeout(function () { _this.openCurrentNav(typeName, id); }, 200);
		return;
	},
	getQueryStringByName: function (name) {
		name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
		return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	},
};