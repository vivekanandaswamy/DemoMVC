// JavaScript source code
Ecolab.Presenters.FlushTimesAndSetupTomPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.message = "";
    this.ControllerModelId = 0;
    this.MachineNumber = 0;
    this.AlaramInputData = [];
};
Ecolab.Presenters.FlushTimesAndSetupTomPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherTabsView();
        this.initFlushTimesAndSetupTomView();

    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetData: function (data) { _this.onGetData(data); },
            onDataSaved: function (data, isSaveAndClose) { _this.onDataSaved(data, isSaveAndClose); },
            onDataSavingFailed: function (description, data) { _this.onDataSavingFailed(description, data); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initWasherTabsView: function () {
        var _this = this;
        if (!this.Views.WasherTabsView) {
            this.Views.WasherTabsView = new Ecolab.Views.WasherTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () {
                        _this.onTabsRendered();
                    },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    ontabFormulaClicked: function () { _this.ontabFormulaClicked(); }
                    }
            });
        }
        this.Views.WasherTabsView.setData(this.settings.accountInfo);
    },
    initFlushTimesAndSetupTomView: function () {
        var _this = this;
        if (!this.Views.FlushTimesAndSetupTomView) {
            this.Views.FlushTimesAndSetupTomView = new Ecolab.Views.FlushTimesAndSetupTom({
                containerSelector: '#tabFlushTimesAndSetupTomContainer',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                   

                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onSavePage: function (isSaveAndClose) { _this.savePage(isSaveAndClose); },
                    onCancel: function () { _this.onCancel(); }
                }
            });
        }
    },

    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHER GROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    //Getting Alarm Details
    getData: function () {
        this.Model.getData(this.settings.accountInfo.TunnelId, this.settings.accountInfo.WasherGroupId, this.settings.accountInfo.WasherGroupTypeId);
    },
    ontabFormulaClicked: function () {
        var WasherGroupId = this.settings.accountInfo.WasherGroupId;
        this.RedirectLocation('./WasherGroupFormula?' + 'id=' + WasherGroupId);
    },
    onGetData: function (data) {
        dr = [];
        dr.data = data;
        dr.TunnelId = this.settings.accountInfo.WasherId;
        
        dr.message = this.message;
        this.Views.FlushTimesAndSetupTomView.setData(dr);
    },

    onTabsRendered: function () {
        this.getData();
        //this.Views.FlushTimesAndSetupTomView.setData(0);
    },
    //Save Method
    savePage: function (isSaveAndClose) {
        this.isDirty = false;
        var view = this.Views.FlushTimesAndSetupTomView;
        if (view) {
            if (view.Validate()) {
                var data = this.Views.FlushTimesAndSetupTomView.getFlushTimeAndSetupTomData();
                this.Model.saveData(data, isSaveAndClose);
            }
        }
    },
    onDataSaved: function (data, isSaveAndClose) {
        if (isSaveAndClose)
            window.location = '/WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + "&data=List";
        if (((dr.data.ControllerModelId == 8) && (dr.data.WasherGroupTypeId == 1)) || ((dr.data.ControllerModelId == 9) && (dr.data.WasherGroupTypeId == 1)) || ((dr.data.ControllerModelId == 14) && (dr.data.WasherGroupTypeId == 1)) || (dr.data.ControllerModelId == 11) || (dr.data.ControllerModelId == 10)) {
            this.message = $.GetLocaleKeyValue('FIELD_FLUSHTIMESSAVEDSUCCESSFULLY', 'Flush Times data saved successfully.');
        }
        else {
            this.message = $.GetLocaleKeyValue('FIELD_FLUSHTIMESANDSETUPTIMEOUTMACHINEDATASAVEDSUCCESSFULLY', 'Flush Times and Setup Time out Machine data saved successfully.');
        }
        this.isDirty = false;
        this.getData();
    },
    onDataSavingFailed: function (description, data) {
        data = data.toString();
        if (data.indexOf('@') > 0) {
            var response = data.split('@')[1];
            var errorCode = data.split('@')[0];
        } else {
            response = data;
        }
        if (((dr.data.ControllerModelId == 8) && (dr.data.WasherGroupTypeId == 1)) || ((dr.data.ControllerModelId == 9) && (dr.data.WasherGroupTypeId == 1)) || ((dr.data.ControllerModelId == 14) && (dr.data.WasherGroupTypeId == 1)) || (dr.data.ControllerModelId == 11) || (dr.data.ControllerModelId == 10)) {
            var saveMsg = $.GetLocaleKeyValue('FIELD_FLUSHTIMESSAVEDSUCCESSFULLY', 'Flush Times data saved successfully.');
        }
        else {
            var saveMsg = $.GetLocaleKeyValue('FIELD_FLUSHTIMESANDSETUPTIMEOUTMACHINEDATASAVEDSUCCESSFULLY', 'Flush Times and Setup Time out Machine data saved successfully.');
        }

        if (response == "0") {
            if (errorCode == "901") {
                this.message = saveMsg + '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', 'Unable to connect to PLC.');
            }
        } else {
        if (data == '51030') {
            this.message = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDCOUNTDOESNTMATCH', 'Record count does not match...Resynch is in progress.');
        }
        else if (data == '51060') {
            this.message = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', ' Unable to save changes , Connectivity issue, Please try again later.');
        }
        else if (data == '60000') {
            this.message = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDNOTINSYNCBETWEENPLANTANDCENTRAL', 'Record count does not match..Resynch is in progress. ');
        }
        else {
            this.message = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_DATASAVEFAILED', 'Data Save Failed.');
            //this.Views.FlushTimesAndSetupTomView.showMessage('<label class="k-error-message">Data Save Failed.</label>');
        }
        }
        
        this.getData();
    },
    onCancel: function () {
        this.onRedirection('./WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WasherGroupId + "&data=Cancel");
    },


}