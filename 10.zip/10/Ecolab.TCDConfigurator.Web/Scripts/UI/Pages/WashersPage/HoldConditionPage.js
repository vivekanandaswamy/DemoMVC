// JavaScript source code
Ecolab.Presenters.HoldConditionPage = function (options) {
    this.settings = $.extend(this.defaults, options);
    this.message = "";
    this.ControllerModelId = 0;
    this.MachineNumber = 0;
    this.AlaramInputData = [];
    this.IsBatchEjectCondition = false;
};
Ecolab.Presenters.HoldConditionPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initWasherTabsView();
        this.initHoldConditionView();

    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onGetAlarmData: function (data) { _this.onGetAlarmData(data); },
            onAlarmDataSaved: function (data, isSaveAndClose) { _this.onAlarmDataSaved(data, isSaveAndClose); },
            onAlarmDataSavingFailed: function (error, description) { _this.onAlarmDataSavingFailed(error, description); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.displayBreadCrumb();
    },
    initWasherTabsView: function () {
        var _this = this;
        if (!this.Views.WasherTabsView) {
            this.Views.WasherTabsView = new Ecolab.Views.WasherTabs({
                containerSelector: '#tabContainer',
                eventHandlers: {
                    rendered: function () {
                        _this.onTabsRendered();
                    },
                    generalTabClicked: function () { _this.onGeneralTabClicked(); },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    ontabFormulaClicked: function () { _this.ontabFormulaClicked(); },

                }
            });
        }
        this.Views.WasherTabsView.setData(this.settings.accountInfo);
    },
    initHoldConditionView: function () {
        var _this = this;
        if (this.settings.accountInfo.TabToSelect == 'tabBatchEjectCondition')
            this.IsBatchEjectCondition = true;
        if (!this.Views.HoldConditionView) {
            this.Views.HoldConditionView = new Ecolab.Views.HoldConditions({
                containerSelector: '#'+this.settings.accountInfo.TabToSelect+'Container',
                accountInfo: _this.settings.accountInfo,
                eventHandlers: {
                    rendered: function () { },
                    onRedirection: function (url) { return _this.RedirectLocation(url); },
                    onSavePage: function (isSaveAndClose) { _this.savePage(isSaveAndClose); },
                }
            });
        }
    },

    displayBreadCrumb: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_WASHER GROUPS', 'Washer Groups');
        breadCrumbData.url = "/WasherGroup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    //Getting Alarm Details
    getAlarmData: function (controllerModelId, machineNumber) {
        this.Model.getAlarmData(this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.ControllerTypeId, this.settings.accountInfo.MachineNumber, this.settings.accountInfo.WashergroupId, this.settings.accountInfo.EcolabAccountNumber, this.settings.accountInfo.WasherGroupTypeId, this.settings.accountInfo.TunnelId, this.IsBatchEjectCondition);
    },
    ontabFormulaClicked: function () {
        var WasherGroupId = this.settings.accountInfo.WashergroupId;
        this.RedirectLocation('./WasherGroupFormula?' + 'id=' + WasherGroupId);
    },
    onGetAlarmData: function (data) {
        dr = [];
        dr.data = data;
        dr.TunnelId = this.settings.accountInfo.TunnelId
        dr.WashergroupId = this.settings.accountInfo.WashergroupId
        dr.NoofCompartments = this.settings.accountInfo.NoofCompartments
        dr.ControllerModelId = this.settings.accountInfo.ControllerModelId
        dr.ControllerTypeId = this.settings.accountInfo.ControllerTypeId
        dr.ControllerId = this.settings.accountInfo.ControllerId
        
        dr.message = this.message;
        dr.MachineNumber = this.settings.accountInfo.MachineNumber;
        this.Views.HoldConditionView.setData(dr);
    },

    onTabsRendered: function () {
        this.getAlarmData(this.settings.accountInfo.ControllerModelId,this.settings.accountInfo.MachineNumber);
        //this.Views.HoldConditionView.setData(0);
    },
    //Save Method
    savePage: function (isSaveAndClose) {
        this.isDirty = false;
        var view = this.Views.HoldConditionView;
        if (view) {
            var AlarmData = this.Views.HoldConditionView.getAlarmData();
        }

        AlarmData.ControllerModelId = this.settings.accountInfo.ControllerModelId;
        AlarmData.ControllerTypelId = this.settings.accountInfo.ControllerTypeId;
        AlarmData.MachineNumber = this.settings.accountInfo.MachineNumber;


        AlarmData.WashergroupId = this.settings.accountInfo.WashergroupId;
        AlarmData.WasherGroupTypeId = this.settings.accountInfo.WasherGroupTypeId;
        AlarmData.WasherName = this.settings.accountInfo.WasherName;
        AlarmData.NoofCompartments = this.settings.accountInfo.NoofCompartments;
        AlarmData.TunnelId = this.settings.accountInfo.TunnelId;
        AlarmData.WasherGroupTypeName = this.settings.accountInfo.WasherGroupTypeName;
        AlarmData.IsBatchEjectCondition = this.IsBatchEjectCondition;
        AlarmData.Active = 1;
        this.Model.saveAlarmData(AlarmData, isSaveAndClose);

    },
    onAlarmDataSaved: function (data, isSaveAndClose) {
        controllerModelId = this.ControllerModelId;
        machineNumber = this.MachineNumber;
        if (isSaveAndClose)
            window.location = '/WasherGroupFormula?' + 'id=' + this.settings.accountInfo.WashergroupId + "&data=List";
        this.message = $.GetLocaleKeyValue('FIELD_SAVEDSUCCESSFULLY', 'Saved Successfully.');
        this.getAlarmData(this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.MachineNumber);
    },
    onAlarmDataSavingFailed: function (AlarmData, description) {
        description = description.toString();
        if (description.indexOf('@') > 0) {
            var response = description.split('@')[1];
            var errorCode = description.split('@')[0];
        }
        var saveMsg = '<label class="k-success-message"> ' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESSFULLY', 'Saved Successfully.') + '</label>';

        if (response == "0") {
            if (errorCode == "901") {
                this.message = saveMsg + ' ' + '<label class="k-error-message"> ' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</label>';
            }
        } else {
            this.message = '<label data-localize ="FIELD_ERROROCCUREDOVERWRITINGALARMDATA" class="k-error-message">' + description + '</label>';
        }
        this.getAlarmData(this.settings.accountInfo.ControllerModelId, this.settings.accountInfo.MachineNumber);
    },



}