Ecolab.Presenters.UtilityPage = function (options) {
    this.settings = $.extend(this.defaults, options);
};
Ecolab.Presenters.UtilityPage.prototype = {
    initViews: function () {
        this.base.initViews.call(this);
        this.initPlantSetupTabsView();
        this.initListView();
    },
    initModel: function () {
        this.base.initModel.call(this);
        this.Model.init();
    },
    addModelOptions: function (modelOptions) {
        this.base.addModelOptions.call(this, modelOptions);
        modelOptions.SizeOfPage = this.settings.pageSize;
    },
    addModelEventHandlers: function (eventHandlers) {
        this.base.addModelEventHandlers.call(this, eventHandlers);
        $.extend(eventHandlers, this.getModelEventHandlers());
    },
    getModelEventHandlers: function () {
        var _this = this;
        return {
            onDeviceDataLoaded: function (data) { _this.onDeviceDataLoaded(data); },
            onloadDeviceModelByDeviceTypeIdLoaded: function (data) { _this.onloadDeviceModelByDeviceTypeIdLoaded(data); },
            onloadUtilityOnAddNewPopupDataLoaded: function (data) { _this.loadUtilityOnAddNewPopupLoaded(data); },
            //onLoadUtilityEdit: function (data) { _this.onLoadUtilityEditLoaded(data); },
            onLoadUtilityEditLoaded: function (data) { _this.onLoadUtilityEditLoaded(data); },
            onInitialized: function () { _this.onModelInitialized(); }
        };
    },
    afterInit: function () {
        this.base.afterInit.call(this);
        this.showMainHeader();
        this.onPageRendered();
    },
    initPlantSetupTabsView: function () {
        var _this = this;
        if (!this.Views.PlantSetupTabsView) {
            this.Views.PlantSetupTabsView = new Ecolab.Views.PlantSetupTabs(
                        {
                            containerSelector: '#pageContainer',
                            eventHandlers: {
                                rendered: function () { },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                            }
                        });
        }
        this.Views.PlantSetupTabsView.setData(this.settings.accountInfo);
    },
    initListView: function () {
        var _this = this;
        if (!this.Views.UtilityView) {
            this.Views.UtilityView = new Ecolab.Views.Utility(
                        {
                            containerSelector: '#tabDeviceContainer',
                            accountInfo: _this.settings.accountInfo,
                            eventHandlers: {
                                rendered: function () { _this.loadDeivceData(); },
                                onAddNewUtilityPopupLoad: function () { _this.loadUtilityOnAddNewPopupLoad(); },
                                onloadDeviceModelByDeviceTypeId: function (id) { _this.loadDeviceModelByDeviceTypeId(id); },
                                onUtilityEditLoad: function (id) { _this.LoadUtilityEdit(id); },
                                onRedirection: function (url) { return _this.RedirectLocation(url); },
                                savePage: function () { _this.savePage() },
                                setIsDirty: function (flage) { _this.setIsDirty(flage) },
                                onSaveChangesForWaterEnergy: function (data, e, wnd, detailsTemplate, allowEdit, IsDelete) { return _this.SaveChangesForWaterEnergy(data, e, wnd, detailsTemplate, allowEdit, IsDelete); }
                            }
                        });
            this.Views.UtilityView.setData(this.settings.accountInfo);
        }
    },
    onPageRendered: function () {
        var breadCrumbData = {};
        breadCrumbData.name = $.GetLocaleKeyValue('FIELD_PLANT SETUP', 'Plant Setup');
        breadCrumbData.url = "/PlantSetup";
        this.showPlantBreadCrumb("plantSets", breadCrumbData);
    },
    navigateToConfigPage: function (id) {
    },
    loadDeivceData: function () {
        this.Model.loadDeviceData();
    },
    onDeviceDataLoaded: function (data) {
        this.Views.UtilityView.setDeviceData(data);
    },
    loadDeviceType: function () {
        this.Model.loadDeviceType();
    },
    loadUtilityOnAddNewPopupLoad: function () {
        this.Model.loadUtilityOnAddNewPopupLoad();
    },
    loadUtilityOnAddNewPopupLoaded: function (data) {       
        this.Views.UtilityView.setUtilityOnAddNewPopupLoadData(data);
    },
    onloadDeviceTypeLoaded: function (data) {        
        this.Views.UtilityView.setDeviceTypeData(data);
    },
    loadDeviceModelByDeviceTypeId: function (id) {
        this.Model.loadDeviceModelByDeviceTypeId(id);
    },
    onloadDeviceModelByDeviceTypeIdLoaded: function (data) {
        this.Views.UtilityView.setDeviceModelData(data);
    },   
    LoadUtilityEdit: function (id) {
        this.Model.LoadUtilityEdit(id);
    },
    onLoadUtilityEditLoaded: function (data) {
        this.Views.UtilityView.SetUtilityOnEditPopupLoad(data);
    },
    savePage: function () {
        this.Views.UtilityView.savePage();
    },
    setIsDirty: function (flage) {
        this.isDirty = flage;
    },
    deletePage: function (e, data, wnd, detailsTemplate, allowEdit, isDelete) {
        this.Views.UtilityView.onDelete(e, data, wnd, detailsTemplate, allowEdit, isDelete);
    }
};