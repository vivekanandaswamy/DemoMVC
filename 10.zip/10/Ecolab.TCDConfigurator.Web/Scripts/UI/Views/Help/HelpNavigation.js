﻿Ecolab.Views.HelpNavigation = function (options) {
    var defaults = {
        templateDetails: null,
        containerSelector: null,
        eventHandlers: {
            onRendered: function () { },
            onCancelPage: function () { },
            onRedirection: function () { },
            onSavePage: function () { }
        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;


    this.helpNavigationTemplate = new TemplateManager({
        templateName: 'HelpNavigation',
        templateUri: './Scripts/UI/Views/Help/HelpTemplates/HelpNavigation.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onNavigationRendered() } }
    });

};

Ecolab.Views.HelpNavigation.prototype = {

    initChildViews: function () {
        this.ChildView = {};
    },
    setNavigationData: function (data) {
        this.data = data;
        this.helpNavigationTemplate.Render(data, this);
    },

    onNavigationRendered: function () {
        var tagname = "#" + this.options.templateDetails.tagName;
        $(tagname).parentsUntil(".mainnav").toggleClass('active');
        $(tagname).parentsUntil(".mainnav").children('ul').slideToggle('fast');
        $(tagname).addClass('hlpActiveAnchor');

        var _this = this;
        _this.attachEvents();
        if (_this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();


        $('.helptree li').each(function () {

            if ($(this).children('ul').length > 0) {
                $(this).addClass('parent');
            }
        });

        $('.helptree li.parent > a').click(function () {
            $(this).parent().toggleClass('active');
            $(this).parent().children('ul').slideToggle('fast');

        });


        $('.helptree li > a').click(function () {
            $('.helptree li > a').removeClass('hlpActiveAnchor');
            $(this).addClass('hlpActiveAnchor');
        });
    },
    hasAccess: function () {

    },
    createChidTemplate: function (templatename, url) {
        var _this = this;
        _this.ChildView.HelpTemplate = new Ecolab.Views.HelpTemplate(
                         {
                             containerSelector: '#templateContainer',
                             templateDetails: { template: templatename, url: url },
                             eventHandlers: {
                                 rendered: function () { }
                             }
                         });

        _this.ChildView.HelpTemplate.setTemplateData(_this.data);
    },
    attachEvents: function () {
        var _this = this;
        if (!this.ChildView) {
            this.initChildViews();
        }
        var container = $(_this.options.containerSelector);

        // Home
        container.find('#hlpHome').click(function () {
            _this.createChidTemplate("Home", "/Scripts/UI/Views/Help/HelpTemplates/Home.html");
        });

        // Plant Setup -- General
        container.find('#hlpGeneralSetup').click(function () {
            _this.createChidTemplate("HelpPlantSetupGeneral", "/Scripts/UI/Views/Help/HelpTemplates/HelpPlantSetupGeneral.html");
        });

        // Plant Setup -- Contacts
        container.find('#hlpGeneralContacts').click(function () {
            _this.createChidTemplate("Contact", "/Scripts/UI/Views/Help/HelpTemplates/Contacts.html");
        });

        // Plant Setup -- ShiftLabor
        container.find('#hlpGeneralShift').click(function () {
            _this.createChidTemplate("Shift", "/Scripts/UI/Views/Help/HelpTemplates/Shift.html");
        });

        // Plant Setup -- LaborCost
        container.find('#hlpGeneralLabourCost').click(function () {
            _this.createChidTemplate("LaborCost", "/Scripts/UI/Views/Help/HelpTemplates/LaborCost.html");
        });


        // Plant Setup -- Chemicals
        container.find('#hlpChemicals').click(function () {
            _this.createChidTemplate("Chemicals", "/Scripts/UI/Views/Help/HelpTemplates/Chemicals.html");
        });

        // Plant Setup -- TargetProduction
        container.find('#hlpGeneralTargetProduction').click(function () {
            _this.createChidTemplate("TargetProduction", "/Scripts/UI/Views/Help/HelpTemplates/TargetProduction.html");
        });

        // Plant Setup -- Formula
        container.find('#hlpFormula').click(function () {
            _this.createChidTemplate("Formula", "/Scripts/UI/Views/Help/HelpTemplates/FormulaList.html");
        });

        // Plant Setup -- Customer
        container.find('#hlpCustomer').click(function () {
            _this.createChidTemplate("Customer", "/Scripts/UI/Views/Help/HelpTemplates/Customer.html");
        });

        // Plant Setup -- UserManagement
        container.find('#hlpUserManagement').click(function () {
            _this.createChidTemplate("UserManagement", "/Scripts/UI/Views/Help/HelpTemplates/UserManagement.html");
        });

        // Plant Setup -- DashboardSetup
        container.find('#hlpDashboard').click(function () {
            _this.createChidTemplate("DashboardSetup", "/Scripts/UI/Views/Help/HelpTemplates/DashboardSetup.html");
        });

        // Plant Setup -- RedFlag
        container.find('#hlpRedFlag').click(function () {
            _this.createChidTemplate("RedFlag", "/Scripts/UI/Views/Help/HelpTemplates/RedFlag.html");
        });

        // Plant Setup -- Dryer
        container.find('#hlpGeneralLabourCost').click(function () {
            _this.createChidTemplate("LaborCost", "/Scripts/UI/Views/Help/HelpTemplates/LaborCost.html");
        });

        // Plant Setup -- Finishers
        container.find('#hlpFinishers').click(function () {
            _this.createChidTemplate("Finishers", "/Scripts/UI/Views/Help/HelpTemplates/Finishers.html");
        });

        // Production Summary Report
        container.find('#hlpRptProductionSummary').click(function () {
            _this.createChidTemplate("RptProductionSummary", "/Scripts/UI/Views/Help/HelpTemplates/RptProductionSummary.html");
        });

        // Production  Details Report
        container.find('#hlpRptProductionDetail').click(function () {
            _this.createChidTemplate("RptProductionDetails", "/Scripts/UI/Views/Help/HelpTemplates/RptProductionDetails.html");
        });

        //  ChemicalConsumption Report
        container.find('#hlpRptChemicalConsumption').click(function () {
            _this.createChidTemplate("RptChemicalConsumption", "/Scripts/UI/Views/Help/HelpTemplates/RptChemicalConsumption.html");
        });

        //  Chemical Inventory Report
        container.find('#hlpRptChemicalInventory').click(function () {
            _this.createChidTemplate("RptChemicalInventory", "/Scripts/UI/Views/Help/HelpTemplates/RptChemicalInventory.html");
        });

        //  Operations Summary
        container.find('#hlpRptOperationSummary').click(function () {
            _this.createChidTemplate("RptOperationSummary", "/Scripts/UI/Views/Help/HelpTemplates/RptOperationSummary.html");
        });

        //  Use Log Report
        container.find('#hlpRptUseLog').click(function () {
            _this.createChidTemplate("RptUseLog", "/Scripts/UI/Views/Help/HelpTemplates/RptUseLog.html");
        });

        // General Report
        container.find('#ReportsAnchor').click(function () {
            _this.createChidTemplate("ReportsGeneral", "/Scripts/UI/Views/Help/HelpTemplates/ReportsGeneral.html");
        });

        // Alaram Summary
        container.find('#hlpRptAlaramSummary').click(function () {
            _this.createChidTemplate("RptAlaramSummary", "/Scripts/UI/Views/Help/HelpTemplates/RptAlaramSummary.html");
        });

        // Alaram Detail
        container.find('#hlpRptAlaramDetail').click(function () {
            _this.createChidTemplate("RptAlaramDetail", "/Scripts/UI/Views/Help/HelpTemplates/RptAlaramDetail.html");
        });


        // DispenserSetup
        container.find('#hlpDispenserSetup').click(function () {
            _this.createChidTemplate("DispenserSetup", "/Scripts/UI/Views/Help/HelpTemplates/DispenserSetup.html");
        });

        // Manual Input
        container.find('#hlpManualInput').click(function () {
            _this.createChidTemplate("ManualInput", "/Scripts/UI/Views/Help/HelpTemplates/ManualInput.html");
        });

        // Manual Utility
        container.find('#hlpManualInputUtility').click(function () {
            _this.createChidTemplate("ManualInputUtility", "/Scripts/UI/Views/Help/HelpTemplates/ManualInputUtility.html");
        });

        // Manual Production General
        container.find('#hlpManualInputProductionGeneral').click(function () {
            _this.createChidTemplate("ManualInputProductionGeneral", "/Scripts/UI/Views/Help/HelpTemplates/ManualInputProductionGeneral.html");
        });

        // Manual ProductionData
        container.find('#hlpManualInputProductionData').click(function () {
            _this.createChidTemplate("ManualInputProductionData", "/Scripts/UI/Views/Help/HelpTemplates/ManualInputProductionData.html");
        });

        // Manual BatchData
        container.find('#hlpManualInputBatchData').click(function () {
            _this.createChidTemplate("ManualInputBatchData", "/Scripts/UI/Views/Help/HelpTemplates/ManualInputBatchData.html");
        });

        // Manual Rewask
        container.find('#hlpManualInputRewash').click(function () {
            _this.createChidTemplate("ManualInputRewash", "/Scripts/UI/Views/Help/HelpTemplates/ManualInputRewash.html");
        });

        // Manual Labour
        container.find('#hlpManualInputLabour').click(function () {
            _this.createChidTemplate("ManualInputLabour", "/Scripts/UI/Views/Help/HelpTemplates/ManualInputLabour.html");
        });

        //UtilityFactors -Meters
        container.find('#hlpUtilityMeters').click(function () {
            _this.createChidTemplate("UtilityFactorsMeters", "/Scripts/UI/Views/Help/HelpTemplates/UtilityFactorsMeters.html");
        });

        //UtilityFactors -Sensors
        container.find('#hlpUtilitySensors').click(function () {
            _this.createChidTemplate("Sensors", "/Scripts/UI/Views/Help/HelpTemplates/Sensors.html");
        });

        //UtilityFactors -Utility
        container.find('#hlpUtility').click(function () {
            _this.createChidTemplate("UtilityFactorsUtility", "/Scripts/UI/Views/Help/HelpTemplates/UtilityFactorsUtility.html");
        });

        //UtilityFactors - Water and Energy
        container.find('#hlpUtilityWE').click(function () {
            _this.createChidTemplate("UtilityWaterAndEnergy", "/Scripts/UI/Views/Help/HelpTemplates/UtilityWaterAndEnergy.html");
        });

        // Clean Side
        container.find('#hlpDryer').click(function () {
            _this.createChidTemplate("Dryer", "/Scripts/UI/Views/Help/HelpTemplates/Dryer.html");
        });

        container.find('#hlpFinishers').click(function () {
            _this.createChidTemplate("Finishers", "/Scripts/UI/Views/Help/HelpTemplates/Finishers.html");
        });

        // Dashboard
        container.find('#hlpDashboard').click(function () {
            _this.createChidTemplate("Dashboard", "/Scripts/UI/Views/Help/HelpTemplates/Dashboard.html");
        });

        // Storage Tanks
        container.find('#hlpStorageTanks').click(function () {
            _this.createChidTemplate("StorageTanks", "/Scripts/UI/Views/Help/HelpTemplates/StorageTanks.html");
        });

        //Washer Groups
        container.find('#hlpWasherGroups').click(function () {
            _this.createChidTemplate("WasherGroups", "/Scripts/UI/Views/Help/HelpTemplates/WasherGroups.html");
        });


        //Washer Groups
        container.find('#hlpWashers').click(function () {
            _this.createChidTemplate("WasherGroups", "/Scripts/UI/Views/Help/HelpTemplates/WasherGroups.html");
        });

        //Dashboard Setup
        container.find('#hlpDashboardSetup').click(function () {
            _this.createChidTemplate("DashboardSetup", "/Scripts/UI/Views/Help/HelpTemplates/DashboardSetup.html");
        });


    }

};