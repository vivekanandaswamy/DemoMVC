﻿Ecolab.Views.HelpTemplate = function (options) {
    var defaults = {
        templateDetails: null,
        containerSelector: null,
        eventHandlers: {
            onRendered: function () { },
            onCancelPage: function () { },
            onRedirection: function () { },
            onSavePage: function () { }
        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    this.data = null;
    var _this = this;



    this.helpTemplate = new TemplateManager({
        templateName: this.options.templateDetails.template,
        templateUri: this.options.templateDetails.url,
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onTemplateRendered() } }
    });

};

Ecolab.Views.HelpTemplate.prototype = {
    setTemplateData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.helpTemplate.Render(data, this);
    },
    onTemplateRendered: function () {
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    }

};