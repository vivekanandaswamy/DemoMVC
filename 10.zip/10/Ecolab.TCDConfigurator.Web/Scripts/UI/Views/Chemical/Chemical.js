Ecolab.Views.Chemical = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onChemicalNameChange: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Chemical/ChemicalList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
    this.IsChemicalDelete = false;
};

var isNotEditableAfterDelete = false;

Ecolab.Views.Chemical.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
        $('.grid-add-new-record').insertBefore("#errorDiv");
        $(".k-grid-pager").find("a, ul").hide();
    },
    attachEvents: function () {
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel != 4 && this.data.MaxLevel != 5 && this.data.MaxLevel != 3);
        var wnd, detailsTemplate;
        var trIndex = null;
        var _this = this;
        var container = $(this.options.containerSelector);
        $("#btnCancel1").click(function () {
            var retVal = _this.options.eventHandlers.onRedirection('/Chemical');
            return retVal;
        });

        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/PlantChemical/GetPlantChemical",
                    dataType: "json"
                },
                create: {
                    url: "/api/PlantChemical/CreateChemical",
                    dataType: "json",
                    contentType: "application/json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALADDEDSUCCESSFULLY" class="k-success-message">Chemical added successfully.</label>');
                            Window.close();
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else if (jqXhr.responseText == '51030') {
                            $("#errorDiv").html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else if (jqXhr.responseText == '51060') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else if (jqXhr.responseText == '60000') {
                            $("#errorDiv").html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALADDITIONFAILED" class="k-error-message">Chemical addition failed.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    //url: "/api/PlantChemical/Put",
                    url: function () {
                        if (isNotEditableAfterDelete == false) {
                            return "/api/PlantChemical/Put"
                        }
                    },
                    dataType: "json",
                    contentType: "application/json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALUPDATEDSUCCESSFULLY" class="k-success-message">Chemical updated successfully.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else if (jqXhr.responseText == '51030') {
                            $("#errorDiv").html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else if (jqXhr.responseText == '51060') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else if (jqXhr.responseText == '60000') {
                            $("#errorDiv").html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else if (isNotEditableAfterDelete == false) {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALUPDATIONFAILED" class="k-error-message">Chemical updation failed.</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/PlantChemical/DeleteChemical",
                    dataType: "json",
                    contentType: "application/json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALDELETEDSUCCESSFULLY" class="k-success-message">Chemical deleted successfully.</label>');
                        }
                        else if (jqXhr.responseText == '51030') {
                            $("#errorDiv").html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else if (jqXhr.responseText == '51060') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else if (jqXhr.responseText == '60000') {
                            $("#errorDiv").html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            dataSource.cancelChanges();
                            Window.close();
                        }
                        else {
                            dataSource.cancelChanges();
                            $("#errorDiv").html('<label data-localize ="FIELD_CHEMICALDELETIONFAILED" class="k-error-message">Chemical deletion failed.</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                parameterMap: function (data, type) {
                    if (type == "update" || type == "create" || type == "destroy") {
                        return kendo.stringify(data.models);
                    }
                }
            },
            batch: true,
            pageSize: 50,
            schema: {
                model: {
                    id: "ProductId",
                    fields: {
                        ProductId: { editable: false, type: "number", nullable: false },
                        Name: { editable: false },
                        SKU: { editable: false },
                        Cost: {
                            editable: isInRole,
                            type: "text", validation: {
                                required: true,
                                maxlength: function (input) {
                                    if (input.is("[name='Cost']")) {
                                        input.attr("data-maxlength-msg", "cost should be greater than zero.");
                                        var pattern = new RegExp("^0*[1-9][0-9]*(\.[0-9]+)?|0+\.[0-9]*[1-9][0-9]*$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        }
                                        else { return false; }
                                    }
                                    return true;
                                }
                            },
                        },
                        DensityFactor: { editable: false },
                        Id: { editable: false },
                        AcceptedDeviation: { editable: false },
                        ProductCategoryId: { editable: false },
                        Type: { editable: false },
                        Supplier: { editable: false },
                        IncludeinCI: {
                            editable: function (e) {
                                if (_this.allowEdit)
                                    return true;
                                else
                                    return false;

                            }, type: "boolean"
                        },
                        PackagingSize: { editable: false },
                        Weight: { editable: false },
                        Volume: { editable: false },
                        IsDeleted: { editable: false },
                        ProductcategoryName: { editable: false }
                    }
                }
            }
        });
        var addNew;
        if (_this.allowEdit) {
            Command = [
                       //define the commands here
                        { name: "Delete", text: " ", click: onDelete }, { name: "update", text: " ", click: showDetails }, { name: "Substitute", text: " " }];
            addNew = [{ text: "<span data-localize='FIELD_ADDCHEMICAL'>Add Chemical</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];

        }
        else {
            Command = [{ name: "view", text: "", click: showDetails }];
        }

        function onDataBound(arg) {
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            $('.k-button-icontext.k-grid-Delete').find('span').addClass('k-icon k-delete');
            $('.k-button-icontext.k-grid-Substitute').find('span').addClass('k-icon k-substitute');
            $('.k-button-icontext.k-grid-Substitute').click(function (e) {
                var dataItem = $("#gridChemical").data("kendoGrid").dataItem($(e.currentTarget).closest("tr"));
                if (_this.options.eventHandlers.onSubstituteChemicalClicked)
                    _this.options.eventHandlers.onSubstituteChemicalClicked(dataItem);
            });
            _this.tm.Localize();
            updatePaging(this);

            var rows = this.tbody.children();
                var dataItems = this.dataSource.view();
                for (var i = 0; i < dataItems.length; i++) {
                    kendo.bind(rows[i], dataItems[i]);
                }
        }

        function updatePaging(current) {
            current.pager.element.find("a, ul").hide();
            if (current.dataSource.totalPages() > 1) {
                current.pager.element.find("a, ul").show();
            }
            if (current.dataSource.view().length == 0) {
                var currentPage = current.dataSource.page();
                if (currentPage > 1) {
                    current.dataSource.page(currentPage - 1);
                    current.dataSource.sync();
                    current.dataSource.read();
                }
            }
        }

        if (container.find('#gridChemical').data().kendoGrid)
            container.find('#gridChemical').data().kendoGrid.destroy();

        container.find("#gridChemical").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            createAt: "top",
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                { command: Command, width: "110px", attributes: { "class": "align-center" } },
                { field: "SKU", title: "<span data-localize='FIELD_SKUNUMBER'>SKU Number</span>", width: "15%" },
                { field: "Name", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "19%" },
                { field: "ProductcategoryName", title: "<span data-localize='FIELD_CATEGORY'>Category</span>", width: "16%" },
                {
                    field: "Cost",
                    headerTemplate: function () {
                        if (_this.data.RegionId == 1) {
                            return "<span data-localize='FIELD_PRICE'>Price</span>(<span data-localize='DOLLAR'><span class='glyphicon-usd'></span></span>)"
                        }
                        else if (_this.data.RegionId == 2) {
                            return "<span data-localize='FIELD_PRICE'>Price</span>(<span data-localize='EURO'><span class='glyphicon-euro'></span></span>)"
                        }
                    },
                    format: "{0:0.0000000}",
                    attributes: { "class": "align-right" },
                    headerAttributes: { "class": "align-right" },
                    width: "9%",
                    template: function (data) {
                    	if (_this.allowEdit) {
                    		return '<input type="text" pattern="^0*[1-9][0-9]*(\.[0-9]+)?|0+\.[0-9]*[1-9][0-9]*$" class="form-control k-input k-textbox enableSave recordingValue trackChange" name="txtCost_' + data.Id + '" id="txtCost_' + data.Id + '" required data-bind="value: Cost" />'
                    	}
                    	else {
                    		return data.CostAsString;
                    	}
                    },
                },
                { field: "PackagingSize", title: "<span data-localize='FIELD_PACKAGINGSIZE'>Packaging Size</span>", attributes: { "class": "align-right" }, headerAttributes: { "class": "align-right" }, width: "15%" },
                { field: "Supplier", title: "<span data-localize='FIELD_SUPPLIER'>Supplier</span>", width: "9%" },
                {
                    field: "IncludeinCI",
                    title: "<span data-localize='FIELD_INCLUDEINCI'>Include in C&I</span>",
                    width: "12%",
                    template: function (data) {
                        if (_this.allowEdit) {
                            //  '<input type="checkbox" name="IncludeinCI" data-type="boolean" disabled ' + (data.IncludeinCI ? 'checked' : '') + '/>';
                            //  return '<input type="checkbox" #= IncludeinCI ? \'checked="checked"\' : "" # class="chkbx trackChange" />';
                            return '<input type="checkbox" class="chkbx trackChange" name="IncludeinCI" data-type="boolean" ' + (data.IncludeinCI ? 'checked' : '') + '/>'

                        } else {
                            return '<input type="checkbox" class="chkbx trackChange" disabled name="IncludeinCI" data-type="boolean" ' + (data.IncludeinCI ? 'checked' : '') + '/>'
                        }
                    }
                },
                { field: "Id", attributes: { "style": "display:none" } },
            ],
            editable: "inline",
            cancel: function (e) {
                var dataSource = $("#gridChemical").data("kendoGrid").dataSource;
                var grid = $("#gridChemical").data("kendoGrid");
                grid.dataSource.read();
            }
        });

        $("#gridChemical .k-grid-content").on("change", "input.chkbx", function (e) {
            var grid1 = $("#gridChemical").data("kendoGrid"),
                dataItem = grid1.dataItem($(e.target).closest("tr"));

            dataItem.set("IncludeinCI", this.checked);
        });

        $('#btnCancel').click(function () {
            dataSource.cancelChanges(); //cancel changes
            Window.close();
            Window = null;
        });
        $('#btnSave').click(function () {
           
                var grid = $("#gridChemical").data("kendoGrid");

                if (_this.validate()) {
                    grid.saveChanges();
                }
        });


        grid = $("#gridChemical").data("kendoGrid");
        function onEdit(e) {
            clearStatusMessage();
            inlineEditSaveButton();
        }
        var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
        function createOverlay() {
            $("body").append('<div class="overlay_bg"></div>');
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-animation-container").hide();
            $("#deleteDetails").parent(".k-window").addClass('deletepopup');
        }
        function removeOverlay() {
            $(".overlay_bg").hide();
            $("#topnav, .leftmenu-container").removeClass("blur");
            $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
        }
        function onDelete(e) {
            if (_this.IsChemicalDelete == false)
            {
                _this.IsChemicalDelete = true;
                var detailsTemplate = kendo.template($("#editChemical").html());
                var data = this;
                var noEdits = _this.options.eventHandlers.onSaveChangesForChemical(data, e, wnd, detailsTemplate,false,_this);
                }
            else if (_this.IsChemicalDelete == true) {
                _this.IsChemicalDelete = false;
                createOverlay();
                clearStatusMessage();
                e.preventDefault();
                $("body").css("overflow-y", "hidden");
                var tr = $(e.target).closest("tr");
                var data = this.dataItem(tr);
                deletePopupTemplateWindow.content(deletePopupTemplate(data));
                deletePopupTemplateWindow.open().center();
                grid = $("#gridChemical").data("kendoGrid");
                grid.refresh();
                $(document).on('keyup', function (e) {
                    if (e.which == 27) {
                        $('#noButton').trigger('click');
                    }
                });
                $("#yesButton").click(function () {
                    grid.dataSource.remove(data);
                    grid.saveChanges();
                    deletePopupTemplateWindow.close();
                    removeOverlay();
                    $("body").css("overflow-y", "auto");
                });
                $("#noButton").click(function () {
                    deletePopupTemplateWindow.close();
                    removeOverlay();
                    $("body").css("overflow-y", "auto");
                });
            }
        }
        var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
            title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            visible: false,
            width: "298px",
            height: "auto",
            animation: false,
            draggable: false,
            resizable: false,
        }).data("kendoWindow");

        wnd = $("#details")
                        .kendoWindow({
                            title: $.GetLocaleKeyValue("FIELD_EDITCHEMICAL", 'Edit Chemical'),
                            modal: true,
                            resizable: false,
                            visible: false,
                            draggable: false,
                            width: "373px",
                            height: "auto",
                            open: onOpen,
                            close: function () {
                                $("#topnav, .leftmenu-container").removeClass("blur");
                                $("body").css("overflow-y", "auto");
                            },
                            activate: function (e) {
                                _this.tm.Localize();
                            }
                        }).data("kendoWindow");

        function onOpen() {
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-tooltip").parent(".k-animation-container").hide();
            $("body").css("overflow-y", "hidden");

            $('#cbIncludeinCI').change(function () {
                this.checked ? $('.inventoryExpense').removeClass("hide") : $('.inventoryExpense').addClass("hide");
                $('.inventoryExpense').find('input[name=type]:nth(1)').prop('checked', true);

            });
           
        }

        detailsTemplate = kendo.template($("#editChemical").html());
        var isInRole = false;
        if (_this.data != null) {
            isInRole = true;
        }

        function showDetails(e) {
            var detailsTemplate = kendo.template($("#editChemical").html());
            var data = this;
            var noEdits = _this.options.eventHandlers.onSaveChangesForChemical(data, e, wnd, detailsTemplate,true,_this);
            if (noEdits)
            {
                e.preventDefault();
                clearStatusMessage();
                var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
                wnd.content(detailsTemplate(dataItem));
                wnd.center().open();
                this.dataSource.cancelChanges();
            }
            
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator");
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSource.fetch(function () {
                    var chemical = dataSource.get(uid);
                    chemical.set("Cost", $("#txtCost").val());
                    var includeInCi = $("#cbIncludeinCI")[0].checked;
                    chemical.set("IncludeinCI", includeInCi);
                    chemical.set("InventoryExpense", includeInCi ? $('.inventoryExpense').find('input[name=type]:checked').val() : null);

                });
                var grid = $("#gridChemical").data("kendoGrid");
                grid.saveChanges();
                wnd.close();
                return true;
            }
            return false;
        });

        var Window, grid;
        $("#gridChemical a.grid-add-new-record").unbind("click");
        $("#gridChemical a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            e.preventDefault();
            var dataSource = $("#gridChemical").data("kendoGrid").dataSource;
            dataSource.cancelChanges();
            Window = $("<div id='popupEditor'>")
               .appendTo($("body"))
               .kendoWindow({
                   title: $.GetLocaleKeyValue("FIELD_ADDCHEMICAL", 'Add Chemical'),
                   modal: true,
                   resizable: false,
                   visible: false,
                   draggable: false,
                   width: "410px",
                   height: "auto",
                   open: function () {
                       $("#topnav, .leftmenu-container").addClass("blur");
                       $("body").css("overflow-y", "hidden");
                       $("#addNewChemBtnCancel").click(function () { Window.close(); });
                       
                   },
                   close: onClose,
                   content: {
                       //sets window template
                       template: kendo.template($("#addChemical").html())
                   },
                   activate: function (e) {
                       _this.tm.Localize();
                   }
               }).data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});

            //binds the editing window to the form
            kendo.bind(window.element, model);

            $('#txtNameAdd').autocomplete({
                autoFocus: true,
                minLength: 2,
                delay: 500,
                open: function () { $('.ui-autocomplete').width($(".ui-autocomplete-input").width() + 50); },
                source:
                    function (request, response) {
                        if (_this.options.eventHandlers.onChemicalNameChange)
                            _this.options.eventHandlers.onChemicalNameChange(request, chemicalsLoaded);

                        function chemicalsLoaded(data) {
                            response($.map(data, function (item) {
                                return { label: item.Name, value: item.Name, chemicalId: item.ProductId, cost: item.Cost, includeInCI: item.IncludeinCI }
                            }));
                        }
                    },
                select: function (event, ui) {
                    $("#txtNameAdd").attr("chemicalId", ui.item.chemicalId);
                    $("#txtCostAdd").val(ui.item.cost);
                    $("#cbIncludeinCIAdd").attr("checked", ui.item.includeInCI);
                    $("#cbIncludeinCIAdd").trigger('change');
                    $('#btnUpdate').prop('disabled', false);
                },
                focus: function (e, ui) {
                    return false;
                },
                close: function () {
                    $("#txtNameAdd").select();
                }

            }).autocomplete("widget").addClass("autoComplete");

            function _OnTransportRead(e) {
                var text = $.trim(e.data.filter.filters[0].value);
            }

            //initialize the validator
            var validator = $(Window.element).kendoValidator().data("kendoValidator");
            Window.element.find('#btnUpdate').unbind("click");
            Window.element.find('#btnUpdate').click(function (e) {
                if (validator.validate() == true) {

                    var dataSource = $("#gridChemical").data("kendoGrid").dataSource;

                    dataSource._data[0].ProductId = $("#txtNameAdd").attr('chemicalId');
                    dataSource._data[0].Cost = parseFloat($("#txtCostAdd").val().trim());
                    var includeInCi = $("#cbIncludeinCIAdd")[0].checked;
                    dataSource._data[0].IncludeinCI = includeInCi;
                    dataSource._data[0].InventoryExpense = includeInCi ? $('.inventoryExpenseAdd').find('input[name=type]:checked').val() : null;

                    dataSource.sync(); //sync changes

                    grid = $("#gridChemical").data("kendoGrid");
                    return true;
                }
                return false;
            });

            $('#cbIncludeinCIAdd').unbind("change");
            $('#cbIncludeinCIAdd').change(function () {
                this.checked ? $('.inventoryExpenseAdd').removeClass("hide") : $('.inventoryExpenseAdd').addClass("hide");
                $('.inventoryExpenseAdd').find('input[name=type]:nth(1)').prop('checked', true);
            });

            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                Window.element.remove();
                Window.destroy();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("body").css("overflow-y", "auto");
            }
        });

        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
        });

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
    },
    validate: function () {
    	var v1 = $('#frmChemical').validate({
    		rules: {
    		},

    		messages: {

    		}
    	});
    	$('[name*="txtCost_"]').each(function (index, item) {
    		$(this).rules('add', {
    			required: true,
    			min:1,
    			messages: { // optional custom messages
    				required: "This field is required",
    				min: "Cost is not valid"
    			}
    		});
    	});

    	var v2 = $('#frmChemical').valid();
    	return v2;
    },
    showMessage: function (message) {
        var _this = this;
        var messageDiv = $("#errorDiv");
        messageDiv.html(message);
    },
    onDelete: function (e, data, wnd, detailsTemplate,_this)
    {
        if (_this.IsChemicalDelete == false) {
            _this.IsChemicalDelete = true;
            var detailsTemplate = kendo.template($("#editChemical").html());
            var noEdits = _this.options.eventHandlers.onSaveChangesForChemical(data, e, wnd, detailsTemplate, false,_this);
        }
        else if (_this.IsChemicalDelete == true) {
            _this.IsChemicalDelete = false;
            $("body").append('<div class="overlay_bg"></div>');
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-animation-container").hide();
            $("#deleteDetails").parent(".k-window").addClass('deletepopup');
            $("#errorDiv").html('');
            e.preventDefault();
            $("body").css("overflow-y", "hidden");
            var tr = $(e.target).closest("tr");
            var data = data.dataItem(tr);
            grid = $("#gridChemical").data("kendoGrid");
            grid.refresh();
            var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
            var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
                title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
                visible: false,
                width: "298px",
                height: "auto",
                animation: false,
                draggable: false,
                resizable: false,
            }).data("kendoWindow");
            deletePopupTemplateWindow.content(deletePopupTemplate(data));
            deletePopupTemplateWindow.open().center();
            $(document).on('keyup', function (e) {
                if (e.which == 27) {
                    $('#noButton').trigger('click');
                }
            });
            $("#yesButton").click(function () {
                isNotEditableAfterDelete = true;
                grid.dataSource.remove(data);
                grid.dataSource.sync();
                grid.dataSource.read();
                deletePopupTemplateWindow.close();
                $(".overlay_bg").hide();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
                $("body").css("overflow-y", "auto");
            });
            $("#noButton").click(function () {
                deletePopupTemplateWindow.close();
                $(".overlay_bg").hide();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
                $("body").css("overflow-y", "auto");
            });
        }
    }
};