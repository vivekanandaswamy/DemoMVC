﻿Ecolab.Views.SubstituteChemical = function (options) {
	var defaults = {
		containerSelector: null,
		accountInfo: null,
		eventHandlers: {
			rendered: null,
			onCancelClicked: null,
			onSaveSubstitueChemicalClicked: null,
			onFromWasherGroupChanged: null,
			saveSubstitueChemical: null,
		}
	};
	this.options = $.extend(defaults, options);
	var _this = this;
	this.data = null;
	var index = null;
	this.tm = new TemplateManager({
		templateName: 'SubstituteChemical',
		templateUri: '/Scripts/UI/Views/Chemical/SubstituteChemical.html',
		paraShiftLabors: [],
		containerElement: this.options.containerSelector,
		eventHandlers: { onRendered: function () { _this.onRendered(); } }

	});

};
Ecolab.Views.SubstituteChemical.prototype = {
	setData: function (data) {
		this.data = data;
		this.tm.Render(data, this);
	},
	onRendered: function () {
		var _this = this;
		this.attachEvents();
		if (this.options.eventHandlers.rendered)
			this.options.eventHandlers.rendered();

		$(".custom-select").each(function () {
			if ($(this).is(":disabled")) {
				$(this).wrap("<span class='select-wrapper disabled'></span>");
			} else {
				$(this).wrap("<span class='select-wrapper'></span>");
			}

			$(this).after("<span class='holder'></span>");
		});
		$(".custom-select").change(function () {
			var selectedOption = $(this).find(":selected").text();
			$(this).next(".holder").text(selectedOption);
		});
		$(".custom-select").each(function () {
			var selectedOption = $(this).find(":selected").text();
			$(this).next(".holder").text(selectedOption);
		});
	},
	attachEvents: function () {
		var _this = this;
		var container = $(_this.options.containerSelector);
		container.find("#btnSaveSubstituteChemical").click(function () { _this.onSaveSubstitueChemicalClicked(); })
		container.find("#btnCancel").click(function (e) { _this.onCancelClicked(e); })
		container.find('#ddlWasherGroupFrom').change(function () {
			var washerGroupId = container.find('#ddlWasherGroupFrom').val();
			if (_this.options.eventHandlers.onFromWasherGroupChanged) {
				_this.options.eventHandlers.onFromWasherGroupChanged(washerGroupId);
			}
		});
		container.find('input[type=text]').mask('999');
		container.find('#increaseAmount').keyup(function () {
		    if (container.find('#Increaseby').prop('checked')) {
		        var currDosageAmt = container.find('#currDosageAmt').val();
		        var percentAmt = (parseFloat($(this).val() / 100) * currDosageAmt);
		        var newDosamt = parseFloat(currDosageAmt) + percentAmt;
		        container.find('#newDosageAmt').val(newDosamt);
		    }
		});
		container.find('#Increaseby').change(function() {
		    if ($(this).prop('checked'))
		        container.find('#decreaseAmount').val('');
		});
		container.find('#decreaseAmount').keyup(function () {
		    if (container.find('#Decreaseby').prop('checked')) {
		        var currDosageAmt = container.find('#currDosageAmt').val();
		        var newDosamt = currDosageAmt - (parseFloat($(this).val() / 100) * currDosageAmt);
		        if (newDosamt < 0)
		            newDosamt = 0;
		        container.find('#newDosageAmt').val(newDosamt);
		    }
		});
		container.find('#Decreaseby').change(function () {
		    if ($(this).prop('checked'))
		        container.find('#increaseAmount').val('');
		});
	},
	onCancelClicked: function () {
		if (this.options.eventHandlers.onCancelClicked) {
			this.options.eventHandlers.onCancelClicked();
		}
	},

	onSaveSubstitueChemicalClicked: function () {
		var _this = this;
		var container = $(_this.options.containerSelector);
		var data = {};

		data.WasherGroupId = container.find('#ddlWasherGroupFrom').val();
		data.OldProductId = _this.data.SubstituteChemicalDetails.ProductId;
		data.NewProductId = container.find('#ddlProduct').val();
		data.ScalarOption = $('input:radio[name=amount]:checked').val();
		if (data.ScalarOption == 1) {
			data.ScalarAmountPercent = container.find('#decreaseAmount').val();
		}
		else if (data.ScalarOption == 2) {
			data.ScalarAmountPercent = container.find('#increaseAmount').val();
		}
		else {
			data.ScalarAmountPercent = 0;
		}

		if (this.options.eventHandlers.onSaveSubstitueChemicalClicked) {
			this.options.eventHandlers.onSaveSubstitueChemicalClicked(data);
		}

	},
	showMessage: function (message) {
		var _this = this;
		var messageDiv = $("#divSubstituteErrorMessage");
		messageDiv.html(message);

	},
	LoadProducts: function (data) {
		var _this = this;
		var container = $(_this.options.containerSelector);
		var ddlProduct = container.find("#ddlProduct");
		ddlProduct.empty();
		if (data.length > 0) {
			$.each(data, function () {
				if (_this.data.SubstituteChemicalDetails.ProductId != this.ProductId) {
					ddlProduct.append('<option value="' + this.ProductId + '" data-localize="FIELD_' + this.Name.toUpperCase() + '">' + this.Name + '</option>');
				}
			});
		}
		else {
			ddlProduct.append('<option value="-1">--Select--</option>');
		}

		$(".custom-select").each(function () {
			var selectedOption = $(this).find(":selected").text();
			$(this).next(".holder").text(selectedOption);
		});
	},
	validate: function () {		
	    _this = this;
	    var container = $(this.options.containerSelector);	   
		var v1 = container.find('#frmSubstituteChemical').validate({
			rules: {			
				decreaseAmount : {
					required : function(element)
					{
						$(element).removeClass('brdr_red');
						if ($(element).parent().siblings('input[type=radio]').prop('checked'))
						{
							$(element).addClass('brdr_red');
							return true;							
						}
						return false;
						
					}
				},
				increaseAmount: {
					required: function (element) {
						$(element).removeClass('brdr_red');
						if ($(element).parent().siblings('input[type=radio]').prop('checked')) {
							$(element).addClass('brdr_red');
							return true;
						}
						return false;
					}
				},				
			},
			messages: {							
						
			},
			errorPlacement: function (error, element) {
				error.appendTo(element.parent().find("span.k-error-message"));
				if (element.hasClass("custom-select")) {
					error.appendTo(element.parent().parent().find("span.k-error-message"));
				}
				if (element.parent().hasClass("input-group")) {
					error.appendTo(element.parent().parent().find("span.k-error-message"));
				}
			}
		});
		var v2 = container.find('#frmSubstituteChemical').valid();
		return v2;
	},
}