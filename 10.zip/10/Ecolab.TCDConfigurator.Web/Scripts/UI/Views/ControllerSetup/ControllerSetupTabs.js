Ecolab.Views.ControllerSetupTabs = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.ControllerData = null;
    this.tm = new TemplateManager({
        templateName: 'ControllerSetupTabs',
        templateUri: './Scripts/UI/Views/ControllerSetup/ControllerSetupTabs.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.ControllerSetupTabs.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    setController: function (controllerData) {
        this.ControllerData = controllerData;
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    resetGrids: function () {
        var container = $(this.options.containerSelector);
        /*Handle Controller Setup List grid*/
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        $('#top-mainmenu-container').find('.main-menu-item-Setup').addClass('active');


        if (_this.data != null) {
            $('#' + _this.data.TabToSelect).parent().addClass('active');
            $('#' + _this.data.TabToSelect + 'Container').addClass('active');
        }

        container.find('#btnControllerSetupPrint').click(function () {
            var data = {
                TabId: 1,
                RegionId: _this.data.RegionId,
                EcolabAccountNumber: _this.data.EcolabAccountNumber,
                PageTitle: "Controller Setup",                
                ControllerId: _this.data.ControllerId,
                ControllerModelId: _this.data.ControllerModelId,
                ControllerTypeId: _this.data.ControllerTypeId
            };
            if (_this.data.ControllerId == null)
            {
                data.ControllerId = _this.ControllerData.ControllerId;
            }
            var data = JSON.stringify(data);
            var retVal = _this.options.eventHandlers.onRedirection(_this.data.PrintAction + "?data=" + data);
           
            return retVal;
        });

        container.find('#tabGeneral').click(function () {

            if ($(".new_tabs li.active a")[0].id == "tabPumpList" && _this.options.eventHandlers.setIsInlineGridEdit)
                _this.options.eventHandlers.setIsInlineGridEdit(true);

            var url = "/ControllerSetup";

            if (_this.ControllerData && _this.ControllerData.ControllerId != -1) {
                url = "/ControllerSetup?ControllerId=" + _this.ControllerData.ControllerId + "&ControllerModelId=" + _this.ControllerData.ControllerModelId + "&ControllerTypeId=" + _this.ControllerData.ControllerTypeId;
            }

            var retVal = _this.options.eventHandlers.onRedirection(url);
            return retVal;
        });
        container.find('#tabAdvanced').click(function () {
            var retVal = null;
            if ($(".new_tabs li.active a")[0].id == "tabPumpList" && _this.options.eventHandlers.setIsInlineGridEdit)
                _this.options.eventHandlers.setIsInlineGridEdit(true);

            if (_this.ControllerData.ControllerModelId != 5) {
                retVal = _this.options.eventHandlers.onRedirection('/ControllerSetupAdvance?ControllerId=' + _this.ControllerData.ControllerId + '&ControllerModelId=' + _this.ControllerData.ControllerModelId + '&ControllerTypeId=' + _this.ControllerData.ControllerTypeId + '&IsEdit=' + _this.ControllerData.isEdit);
                return retVal;
            }

        });
        container.find('#tabProductList').click(function () {
        
            var retVal = null;
            if ($(this).parent().hasClass('disabled')) {
                return false;
            }
            if (_this.ControllerData.ControllerModelId != null) {
                if (_this.ControllerData.ControllerModelId == 14) {
                    retVal = _this.options.eventHandlers.onRedirection('/PumpsProduct?ControllerId=' + _this.ControllerData.ControllerId + '&ControllerModelId=' + _this.ControllerData.ControllerModelId + '&ControllerTypeId=' + _this.ControllerData.ControllerTypeId);
                    return retVal;
                }
            }
        });

        container.find('#tabMixingVessels').click(function () {
            
            var retVal = null;
            if ($(this).parent().hasClass('disabled')) {
                return false;
            }
            if (_this.ControllerData.ControllerModelId != null) {
                if (_this.ControllerData.ControllerModelId == 10) {                   
                    retVal = _this.options.eventHandlers.onRedirection('/MixingVessels?ControllerId=' + _this.ControllerData.ControllerId + '&ControllerModelId=' + _this.ControllerData.ControllerModelId + '&ControllerTypeId=' + _this.ControllerData.ControllerTypeId);
                    return retVal;
                }
            }
        });

        container.find('#tabPumpList').click(function () {
            
            var retVal = null;
            if ($(this).parent().hasClass('disabled')) {
                return false;
            }

            if ($(".new_tabs li.active a")[0].id == "tabPumpList" && _this.options.eventHandlers.setIsInlineGridEdit)
                _this.options.eventHandlers.setIsInlineGridEdit(true);

            if (_this.ControllerData.ControllerModelId != null) {
                if (_this.ControllerData.ControllerModelId != 5) {
                    retVal = _this.options.eventHandlers.onRedirection('/Pumps?ControllerId=' + _this.ControllerData.ControllerId + '&ControllerModelId=' + _this.ControllerData.ControllerModelId + '&ControllerTypeId=' + _this.ControllerData.ControllerTypeId);
                    return retVal;
                }
            }
        });
        container.find('#tabTagManagement').click(function () {
            var retVal = null;
            if ($(".new_tabs li.active a")[0].id == "tabPumpList" && _this.options.eventHandlers.setIsInlineGridEdit)
                _this.options.eventHandlers.setIsInlineGridEdit(true);

            if (_this.ControllerData.ControllerModelId != 5) {
                retVal = _this.options.eventHandlers.onRedirection('/TagManagement?ControllerId=' + _this.ControllerData.ControllerId + '&ControllerModelId=' + _this.ControllerData.ControllerModelId + '&ControllerTypeId=' + _this.ControllerData.ControllerTypeId);
                return retVal;
            }
        });

        container.find("#bckbutton").click(function () {
            _this.onBackButtonClicked();
        });

      
    },

    onGeneralTabClicked: function () {
        if (this.options.eventHandlers.generalTabClicked)
            this.options.eventHandlers.generalTabClicked();
    },
    onBackButtonClicked: function () {
        this.options.eventHandlers.onBackButtonClick();
    }
};

//container.find('select').kendoDropDownList();
//container.find("#Input_Control_4_18, #Input_Control_4_20").kendoMobileSwitch({ onLabel: "YES", offLabel: "NO" });