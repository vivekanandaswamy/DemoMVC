Ecolab.Views.ControllerSetup = function (options) {
	var defaults = {
		containerSelector: null,
		dynamicHTMLSelector: null,
		metaData: null,
		originalData: null,
		eventHandlers: {
			rendered: function () { },
			dynamicRendered: function () { },
			onControllerModelSelected: null,
			onControllerTypeSelected: null,
			onSaveClicked: function () { },
			onCancelClicked: function () { },
			onRedirection: function () { },
			onSavePage: function () { }

		},
		accountInfo: null
	};
	this.options = $.extend(defaults, options);
	var _this = this;
	var isEdit = false;
    var hasPumps = true;
	this.tm = new TemplateManager({
		templateName: 'ControllerSetup',
		templateUri: './Scripts/UI/Views/ControllerSetup/ControllerSetup.html',
		parameters: [],
		containerElement: this.options.containerSelector,
		eventHandlers: { onRendered: function () { _this.onRendered(); } }
	});
	this.dynamicTm = new TemplateManager({
		templateName: 'DynamicTM',
		templateUri: './Scripts/UI/Views/ControllerSetup/Dynamic.html',
		parameters: [],
		containerElement: this.options.dynamicHTMLSelector,
		eventHandlers: { onRendered: function () { _this.onDynamicUIRendered(); } }
	});
	this.dataList = {};
};
Ecolab.Views.ControllerSetup.prototype = {
	setData: function (data) {
		this.data = data;
		this.dataList.ControllerModel = data;
		data = this.dataList;
		data.accountInfo = this.options.accountInfo;
		if (this.options.accountInfo.ControllerId != "-1" && this.options.accountInfo.ControllerModelId != "-1") {
			data.ControllerModelId = this.options.accountInfo.ControllerModelId;
		}
		else {
			data.ControllerModelId = -1;
		}
		this.tm.Render(data, this);
	},
	setControllerTypeData: function (data) {
		this.data = data;
		this.dataList.ControllerType = data;
		data = this.dataList;
		if (this.options.accountInfo.ControllerId != "-1" && this.options.accountInfo.ControllerModelId != "-1" && this.options.accountInfo.ControllerTypeId != "-1") {
			data.ControllerModelId = this.options.accountInfo.ControllerModelId;
			data.ControllerTypeId = this.options.accountInfo.ControllerTypeId;
		}
		else {
			data.ControllerModelId = -1;
			data.ControllerTypeId = -1;
		}
		this.tm.Render(data, this);
	},
	setDynamicUI: function (metaData) {
		this.originalData = metaData;
		var maxLevel = this.options.accountInfo.MaxLevel;
		if (this.options.accountInfo.MaxLevel >= 6)
			metaData.Mode = "Edit";
		else if (this.options.accountInfo.MaxLevel > 5)
			metaData.Mode = "View";
		if (this.options.accountInfo.ControllerId != "-1") {
			metaData.ControllerId = this.options.accountInfo.ControllerId;
		}
		else {
			metaData.ControllerId = -1;
		}
		metaData.MaxLevel = this.options.accountInfo.MaxLevel;
		$.each(metaData[0].FieldGroupInfo, function (index, value) {
			if (metaData[0].FieldGroupInfo[index].FieldLabel.indexOf("Multiplier") != -1 && metaData[0].FieldGroupInfo[index].ControllerTypeId == 2) {
				metaData[0].FieldGroupInfo[index].NoEdit = false;
			}
			else
				metaData[0].FieldGroupInfo[index].NoEdit = true;

			if (maxLevel == 5 && (metaData[0].FieldGroupInfo[index].FieldLabel == "OPC Server" || metaData[0].FieldGroupInfo[index].FieldLabel == "AMS Net ID Address")) {
				metaData[0].FieldGroupInfo[index].Mode = "View";
			}
		});
		hasPumps = metaData[0].HasPumps;
		this.metaData = metaData;
		var self = this;
		// TODO: Chnage this logic to render UI.
		// Delay the time so UI will render at the end.
		setTimeout(function () {
			self.dynamicTm.Render(metaData, this);
		}, 1000);

	},
	onRendered: function () {
		$('#btnContainer').addClass("hide");
		this.disableTabs();
		var _this = this;
		this.attachEvents();
		if (this.options.eventHandlers.rendered)
			this.options.eventHandlers.rendered();
		if (this.options.accountInfo.ControllerId == -1 && $('#ddlControllerType').val()) {
			$('#ddlControllerType').trigger('change');
		}
	},
	onDynamicUIRendered: function () {
		$('#btnContainer').removeClass("hide");
		var _this = this;
		this.attachDynamicEvents();
		isEdit = _this.getQueryStringByName('ControllerModelId') ? true : false;
		if (this.options.eventHandlers.dynamicRendered)
			this.options.eventHandlers.dynamicRendered();
		if (_this.dataList.ModelSelectedVal == 5 || this.options.accountInfo.ControllerModelId == 5) {
			$('.new_tabs li.tab').not('.active').addClass('disabled');
			$('.new_tabs li.tab').not('.active').find('a').removeAttr("data-toggle");
		}
		else {
			if (isEdit) {
				$('.new_tabs li.tab').not('.active').removeClass('disabled');
				$('.new_tabs li.tab').not('.active').find('a').attr("data-toggle", "tab");
				$('.new_tabs li.tab:eq(1)').not('.active').removeClass('disabled');
				$('.new_tabs li.tab:eq(1)').not('.active').find('a').attr("data-toggle", "tab");
			}
			else {
				//$('.new_tabs li.tab:eq(1)').not('.active').removeClass('disabled');
				//$('.new_tabs li.tab:eq(1)').not('.active').find('a').attr("data-toggle", "tab");
			}
			if (!hasPumps) {
				$('.new_tabs li.tab').find('a#tabPumpList').parent().addClass('disabled');
				$('.new_tabs li.tab').find('a#tabPumpList').removeAttr("data-toggle");
			}
		}
		$.each(_this.originalData[0].FieldGroupInfo, function (index, value) {
			if (_this.originalData[0].FieldGroupInfo[index].FieldLabel.indexOf("Multiplier") != -1 && _this.originalData[0].FieldGroupInfo[index].ControllerTypeId == 2) {
				var multiplierFields = $("span:contains('Multiplier')");
				multiplierFields.parent().parent().find('span.mandatoryIcon').remove();
			}
		});
		this.enableFields();

	},
	attachEvents: function () {
		var _this = this;
		var container = $(this.options.containerSelector);
		container.find('#ddlControllerModel').change(function () {
			if (container.find('#ddlControllerModel').val() != "Select") {
				var modelSelectedVal = $(this).val();
				_this.dataList.ModelSelectedVal = modelSelectedVal;
				modelSelectedVal == 5 ? $('.new_tabs li.tab').not('.active').hide() : $('.new_tabs li.tab:eq(1)').not('.active').show();
				_this.onControllerModelSelected(modelSelectedVal);
			}
			else {
				container.find('#contentControllerParameters').html('');
				container.find('#ddlControllerType').attr('disabled', 'disabled');
			}
		});
		container.find('#ddlControllerType').change(function () {
			if (container.find('#ddlControllerType').val() != "Select") {
				_this.dataList.TypeSelectedVal = $(this).val();
				_this.onControllerTypeSelected(_this.dataList.ModelSelectedVal, $(this).val());
			}
			else {
				container.find('#contentControllerParameters').html('');
			}
		});
		$('.checkBoxChecked').live('change', (function () {
			_this.enableFields();
		}));

		container.find('#btnCancel').click(function () { _this.onCancelClicked(); });
		container.find('#btnSave').click(function () { return _this.onSaveClicked(); });
		container.find('#btnSaveAndClose').click(function () { return _this.onSaveClicked(true); });
		container.find('select').kendoDropDownList();

	},
	onCancelClicked: function () {
		var retVal = this.options.eventHandlers.onRedirection('/ControllerSetupList');
		return retVal;
	},
	getData: function () {
		var ControllerId = 0;
		if (this.options.accountInfo.ControllerId != "-1") {
			ControllerId = this.options.accountInfo.ControllerId;
		}
		var container = $(this.options.dynamicHTMLSelector);
		var dataArr = [];
		var maxLevel = this.options.accountInfo.MaxLevel;
		var controllerModelId = parseInt($('#ddlControllerModel').val());
		var controllerTypeId = parseInt($('#ddlControllerType').val());
		for (i = 0; i < this.metaData.length; i++) {
			var fieldGroup = this.metaData[i];
			for (j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
				var controller = {};
				var field = fieldGroup.FieldGroupInfo[j];
				controller.ControllerId = ControllerId;
				controller.EcolabAccountNumber = this.options.accountInfo.EcolabAccountNumber;
				controller.ControllerModelId = controllerModelId;
				controller.ControllerTypeId = controllerTypeId;
				controller.FieldGroupId = field.FieldGroupId;
				controller.FieldId = field.FieldId;
				controller.FieldName = field.FieldName;
				if (field.FieldType == "CHECKBOX")
					controller.Value = String($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is(':checked'));
				else if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is("label"))
					controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).text();
				else if (maxLevel >= 6 && field.AccessToRole >= 8)
					controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val() ? $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val() : field.FieldDefaultValue;
				else
					controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val() != "" ? $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val() : $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).text();

				dataArr.push(controller);
			}
		}
		return dataArr;
	},
	onSaveClicked: function (isSaveAndClose) {
		return this.options.eventHandlers.onSavePage(isSaveAndClose);
	},
	validate: function () {
		var validator = $("#frmControllerSetupDetails").kendoValidator().data("kendoValidator");
		return validator.validate();
	},

	attachDynamicEvents: function () {
		var _this = this;
		var container = $(this.options.containerSelector);
        container.find("#Input_Control_4_21").mask('099.099.099.099.099.099');
		$(".k-datetimepicker").kendoDatePicker({ format: "MM/dd/yyyy" });
		$(".k-datetimepicker input").prop("readonly", true);
		$(".k-numerictextbox").kendoNumericTextBox({
			format: "#",
			min: 0,
			decimals: 0,
			spin: onSpin
		});
		function onSpin() {
			$(document).find('.buttonTrack').removeAttr('disabled');
			_this.isDirty = true;
		}
		container.find('select').kendoDropDownList();

		//For E - Control Central and Decentral
		if (this.options.accountInfo.ControllerId == -1 && container.find('.ControllerVersion').length > 0 && $('.ComPortNumber').length > 0) {
			var dropdownlist = container.find('.ControllerVersion').not(':visible').data("kendoDropDownList");
			if (dropdownlist.value() == 3) {
				$('.ComPortNumber').parent().parent().hide();
			}
			dropdownlist.bind("change", function (ctrl) {
				if (ctrl.sender.value() == 3) {
					$('.ComPortNumber').parent().parent().hide();
					$('.IPAddress').parent().parent().show();
				}
				else {
					$('.ComPortNumber').parent().parent().show();
					$('.IPAddress').parent().parent().hide();
				}
			});
		}
		else {
			if ($('.ControllerVersion').length > 0 && $('.ComPortNumber').length > 0 && $('.ControllerVersion').text() == "3") {
				$('.ComPortNumber').parent().parent().hide();
			}
			else {
				$('.IPAddress').parent().parent().hide();
			}
		}
		container.find($('input[type="text"]')).change(function () {
			if ($(this).val().trim() == '') {
				$(this).val($(this).val().trim());
			}
			else {
				$(this).val($(this).val().trim());
			}
		});
		$('.dispNumber').mask('999999');
		$('.factmultiplier').mask('999999');
		$('.OZSecondMultiplier').mask('999999');
		$('.QuantityMultiplier').mask('999999');
	},
	onControllerModelSelected: function (controllerId) {
		if (this.options.eventHandlers.onControllerModelChange) {
			this.options.eventHandlers.onControllerModelChange(controllerId);
		}
	},
	onControllerTypeSelected: function (controllerModelId, controllerTypeId) {
		if (this.options.eventHandlers.onControllerTypeChange) {
			this.options.eventHandlers.onControllerTypeChange(controllerModelId, controllerTypeId);
		}
	},
	onMetaDataSaved: function (data, tabView, isSaveAndClose) {
		var _this = this;
		if (_this.options.accountInfo.ControllerId != '-1') {
			$("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Dispenser updated successfully.'));
		}
        else
        {
            $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERSAVEDSUCCESSFULLY", 'Dispenser saved successfully.'));
		}

		// _this.options.accountInfo.ControllerId = data;

		if (data != null)
			_this.options.accountInfo.ControllerId = data;
		if ($("#errorDiv_msg").hasClass('k-success-message')) {
			$(".btn-success").attr('disabled', 'disabled');
			if ($('.dispNumber').find('input[type="text"]:nth-child(2)').length > 0) {
				$('.dispNumber').find('input[type="text"]:nth-child(2)').data("kendoNumericTextBox").enable(false);
			}

			var controllerModelId = parseInt($('#ddlControllerModel').val());
			if (tabView.data.IsCentral == 'No' && (controllerModelId == 5 || controllerModelId == 7 || controllerModelId == 8 || controllerModelId == 9 || controllerModelId == 11 || controllerModelId == 14)) {
				$('#tabTagManagement').parent().hide();
			}
		}
		if (!data) { data = _this.options.accountInfo.ControllerId;}
		if (data && tabView) {
			var cData = {};
			cData.ControllerId = data;
			var controllerModelId = parseInt($('#ddlControllerModel').val());
			var controllerTypeId = parseInt($('#ddlControllerType').val());
			cData.ControllerModelId = controllerModelId;
			cData.ControllerTypeId = controllerTypeId;
            cData.isEdit = true;
			tabView.setController(cData);
		}
		if (isSaveAndClose) {
			this.options.eventHandlers.onRedirection('/ControllerSetupList');
		}
		isEdit = _this.getQueryStringByName('ControllerModelId') ? true : false;
		if (!isEdit) {
			$('.new_tabs li.tab:eq(1)').not('.active').removeClass('disabled');
			$('.new_tabs li.tab:eq(1)').not('.active').find('a').attr("data-toggle", "tab");
			$('.new_tabs li.disabled').children('a').click(function (e) {
				e.preventDefault();
			});
            $('.new_tabs li.tab:eq(2)').not('.active').removeClass('disabled');
            $('.new_tabs li.tab:eq(2)').not('.active').find('a').attr("data-toggle", "tab");
            $('.new_tabs li.tab:eq(2)').children('a').click(function (e) {
                e.preventDefault();
            });
            $('.new_tabs li.tab:eq(3)').not('.active').removeClass('disabled');
            $('.new_tabs li.tab:eq(3)').not('.active').find('a').attr("data-toggle", "tab");
            $('.new_tabs li.tab:eq(3)').children('a').click(function (e) {
                e.preventDefault();
            });
		}
	},
	onMetaDataSavedFailed: function (data, tabView, exception) {
	    if (exception.message == "901" || exception.message == "902")
	    {
	        var message = '';
	        var _this = this;
	        if (_this.options.accountInfo.ControllerId != '-1') {
	            
	            message = '<span data-localize ="FIELD_CONTROLLERUPDATEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_CONTROLLERUPDATEDSUCCESSFULLY', "Dispenser updated successfully.") + '</span>';
	            message = message + '<span class="k-error-message">' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</span>';
	            $("#errorDiv_msg").empty().append(message);
	            $(".btn-success").attr('disabled', 'disabled');
	        }
	        else {
	            message = '<span data-localize ="FIELD_CONTROLLERSAVEDSUCCESSFULLY" class="k-success-message">' + $.GetLocaleKeyValue('FIELD_CONTROLLERSAVEDSUCCESSFULLY', 'Dispenser saved successfully.') + '</span>';
	            message = message + '<span class="k-error-message">' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', "Unable to connect to PLC.") + '</span>';
	            $("#errorDiv_msg").empty().append(message);
	            $(".btn-success").attr('disabled', 'disabled');
	        }
	        if (exception.errorData && tabView) {
	            var cData = {};
	            cData.ControllerId = exception.errorData[0].ControllerId;
	            var controllerModelId = parseInt($('#ddlControllerModel').val());
	            var controllerTypeId = parseInt($('#ddlControllerType').val());
	            cData.ControllerModelId = controllerModelId;
	            cData.ControllerTypeId = controllerTypeId;
	            cData.isEdit = true;
	            tabView.setController(cData);
	        }
	    }
	    else {
		$("#errorDiv_msg").empty().removeClass().addClass('k-error-message').append(exception);
	    }
	},
	disableTabs: function () {
		$('.new_tabs li.tab').not('.active').addClass('disabled');
		$('.new_tabs li.tab').not('.active').find('a').removeAttr("data-toggle");
		$('.new_tabs li.disabled').children('a').click(function (e) {
			e.preventDefault();
		});
	},
	enableFields: function () {

	    $("#Input_Control_5_75,#Input_Control_15_168,#Input_Control_11_113").parent().parent().addClass('colons');
	    $("#Input_Control_41_413,#Input_Control_44_425,#Input_Control_47_437,#Input_Control_50_448,#Input_Control_13_137").parent().parent().addClass('clear');
		$("#Input_Control_41_415,#Input_Control_44_427,#Input_Control_47_439,#Input_Control_50_450").parent().parent().parent().addClass('clear');
		var input = $("#Input_Control_5_73,#Input_Control_5_74,#Input_Control_5_75,#Input_Control_11_111,#Input_Control_11_112,#Input_Control_11_113,#Input_Control_13_143,#Input_Control_13_144,#Input_Control_13_145");

		if ($("#Input_Control_5_72,#Input_Control_11_110,#Input_Control_13_142").attr('checked')) {
			input.removeAttr("disabled", "disabled");
		}
		else {
			input.attr("disabled", "disabled");
			input.siblings('.k-tooltip-validation').remove();
		}
		var checkBox = $('.webportEnable').is(':checked');
		var loginFields = $('.webport');
		if (checkBox) {
			loginFields.removeAttr("disabled", "disabled");
			if (loginFields.parent().siblings().find(".mandatoryIcon").length == 0) {
				loginFields.parent().siblings().prepend('<span class="mandatoryIcon">*</span>')
			}
		}
		else {
			loginFields.attr('disabled', 'disabled');
			loginFields.siblings('.k-tooltip-validation').remove();
			loginFields.parent().siblings().find('span.mandatoryIcon').remove()
		}
	},
	getQueryStringByName: function (name) {
		name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
		return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	},
};