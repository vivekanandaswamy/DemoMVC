Ecolab.Views.Customer = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: function () { }
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Customer/CustomerList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.initValidator();
    this.allowEdit = false;
    this.validatetor;
    this.isCustomerDelete = false;
};

Ecolab.Views.Customer.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        _this.tm.Localize();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
        $('.grid-add-new-record').insertBefore("#errorDiv");
        $(".k-grid-pager").find("a, ul").hide();
    },
    savePage: function () {
        var _this = this;
        if (_this.validate()) {
            grid = $("#gridCustomer").data("kendoGrid");
            grid.saveChanges();
        }
    },
    setIsDirty: function (flage) {
        if (this.options.eventHandlers.setIsDirty)
            this.options.eventHandlers.setIsDirty(flage);
    },
    onCancelClick: function () {
        if (this.options.eventHandlers.onRedirection)
            this.options.eventHandlers.onRedirection("/Customer");
    },
    initValidator: function () {
        $.validator.addMethod(
                "regex",
                function (value, element, regexp) {
                    //debugger;
                    var check = false;
                    var re = new RegExp(regexp);
                    return this.optional(element) || re.test(value);
                },
                $.GetLocaleKeyValue("FIELD_PLEASECHECKYOURINPUT", "Please check your input.")
        );
        $.validator.addMethod(
                "number",
                function (value, element, regexp) {
                    if ($(element).val() != '')
                        return /^[0-9]*$/.test($(element).val());
                    else
                        return true;
                },
                $.GetLocaleKeyValue('FIELD_ENTERNUMBER', 'Please enter numbers.')
        );
    },

    validate: function () {
        //this.resetErrors();
        var pattern1 = /^[0-9]*$/;
        var v1 = $('#frmCustomer').validate({
            rules: {
                txtCustomerId: {
                    required: true,
                    regex: pattern1
                }
            },
            messages: {
                txtCustomerId: {
                    required: $.GetLocaleKeyValue("FIELD_PLEASEENTERCUSTOMERID", "Please enter the Customer ID."),
                    regex: $.GetLocaleKeyValue("FIELD_PLEASEENTERONLYNUMBERS", "Please enter only numbers.")
                },

            }

        });
        //var v2 = $('#frmCustomer').valid();
        //return v2;


        /******************************************************************************************
        Event handling
        ******************************************************************************************/
    },
    attachEvents: function () {

        $("#frmCustomer").kendoValidator();
        var _this = this;
        //debugger
        var wnd, detailsTemplate;
        var trIndex = null;
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel == 4 || this.data.MaxLevel > 5);
        var container = $(this.options.containerSelector);

        if (!_this.allowEdit) {
            $("#dvHideButtons").hide();
    } else {
             $("#dvHideButtons").show();
    }

        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Customer/GetCustomer",
                    dataType: "json"
                },
                create: {
                    url: "/api/Customer/CreateCustomer",
                    dataType: "json",
                    contentType: "application/json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {
                        $("#errorMessageAdd").hide().empty();
                        $("#errorDiv").empty();
                        if (textStatus == 'error') {
                            if (jqXhr.responseText == '51030') {
                                $("#errorMessageAdd").show();
                                $("#errorMessageAdd").html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                            else if (jqXhr.responseText == '60000') {
                                $("#errorMessageAdd").show();
                                $("#errorMessageAdd").html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                            else if (jqXhr.responseText == '51060') {
                                $("#errorMessageAdd").show();
                                $("#errorMessageAdd").html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }

                        }
                        else if (jqXhr.responseText == '301') {
                            $("#errorMessageAdd").show();
                            $("#errorMessageAdd").html('<label data-localize ="FIELD_CUSTOMERALREADYEXISTS" class="k-error-message">Customer ID already exists.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else {
                            if (window != null) {
                                window.close();
                                window.element.remove();
                            }
                            $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERADDEDSUCCESSFULLY" class="k-success-message">Customer added successfully.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    url: "/api/Customer/Put",
                    dataType: "json",
                    contentType: "application/json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        $("#errorMessageAdd").hide().empty();
                        $("#errorDiv").empty();
                        var ctrl = null;
                        if ($("#errorMessageAdd").length == 0 || (!wnd.element.is(":visible"))) {
                            ctrl = $("#errorDiv");
                        }
                        else {
                            ctrl = $("#errorMessageAdd");
                        }
                        if (textStatus == 'success') {
                            wnd.close();
                            $("#errorDiv").html('<label data-localize ="FIELD_CUSTOMERUPDATEDSUCCESSFULLY" class="k-success-message">Customer updated successfully.</label>');
                            grid.dataSource.read();
                             $("#btnSave").attr("disabled", "disabled");
                             $("#btnCancel").attr("disabled", "disabled");
                             _this.setIsDirty(false);
                        }
                        else if (jqXhr.responseText == '301') {
                            ctrl.show();
                            ctrl.html('<label data-localize ="FIELD_CUSTOMERALREADYEXISTS" class="k-error-message">Customer ID already exists.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else if (jqXhr.responseText == '51030') {
                            ctrl.show();
                            ctrl.html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else if (jqXhr.responseText == '60000') {
                            ctrl.show();
                            ctrl.html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else if (jqXhr.responseText == '51060') {
                            ctrl.show();
                            ctrl.html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else {
                            if (wnd.element.is(":visible")) {
                                ctrl.show();
                                ctrl.html('<label data-localize ="FIELD_CUSTOMERALREADYEXISTS" class="k-error-message">Customer ID already exists.</label>');

                            } else {
                                ctrl.html('<label data-localize ="FIELD_CUSTOMERALREADYEXISTS" class="k-error-message">Customer ID already exists.</label>');
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/Customer/DeleteCustomer",
                    dataType: "json",
                    contentType: "application/json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        $("#errorMessageAdd").hide().empty();
                        $("#errorDiv").empty();
                        var ctrl = null;
                        if ($("#errorMessageAdd").length == 0) {
                            ctrl = $("#errorDiv");
                        }
                        else {
                            ctrl = $("#errorMessageAdd");
                        }

                        if (textStatus == 'success') {
                            ctrl.html('<label data-localize ="FIELD_CUSTOMERDELETEDSUCCESSFULLY" class="k-success-message">Customer deleted successfully.</label>');
                        }
                        else if (jqXhr.responseText == '51030') {
                            ctrl.show();
                            ctrl.html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else if (jqXhr.responseText == '60000') {
                            ctrl.show();
                            ctrl.html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else if (jqXhr.responseText == '60000') {
                            ctrl.show();
                            ctrl.html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                        else {
                            dataSource.cancelChanges();
                            ctrl.html('<label data-localize ="FIELD_CUSTOMERDELETIONFAILED" class="k-error-message">Customer deletion failed.</label>');
                        }
                        _this.tm.Localize();
                    }

                },
                parameterMap: function (data, type) {
                    if (type == "update" || type == "create" || type == "destroy") {
                        return kendo.stringify(data.models);
                    }
                }
            },
            pageSize: _this.data.MaxNoOfRecordsPerPage == null ? 50 : parseInt(_this.data.MaxNoOfRecordsPerPage),
            batch: true,
            schema: {
                model: {
                    id: "Id",
                    fields: {
                        Id: { editable: false, type: "number" },
                        CustomerId: {
                            editable: true, type: "text", validation: {
                                required: true, min: "1",
                                onlyDigits: function (input) {
                                    //debugger;
                                    if (input.is("[name='CustomerId']")) {
                                        input.attr("data-onlyDigits-msg", $.GetLocaleKeyValue("FIELD_CUSTOMERIDISNOTVALID", "Customer ID is not valid."));
                                        var pattern = new RegExp("^[0-9]+$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        }
                                        else {
                                            return false;
                                        }
                                    }
                                    return true;

                                }
                            },
                        },
                        CustomerName: { validation: { required: true } }
                    }
                }
            }
        });

        //Set basing on roles Here
        var addNew, commands, editTitle, customWidth = "135px";
        if (_this.allowEdit) {
            _this.isView = false;
            commands = [
                //{ name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit },
                { name: "Delete", text: " ", click: onDelete }, { name: "update", text: " ", click: showDetails }
            ];
            addNew = [{ text: "<span data-localize='FIELD_ADDCUSTOMER'>Add Customer</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
            editTitle = $.GetLocaleKeyValue("FIELD_EDITCUSTOMER", 'Edit Customer');
        } else {
            _this.isView = true;
            commands = [{ name: "view", text: " ", click: showDetails }];
            addNew = "";
            customWidth = "55px";
            editTitle = "View Customer";
        }

        function onDataBound(arg) {
            $('.grid-add-new-record').removeClass('k-button k-button-icontext');
            $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            $('.k-button-icontext.k-grid-Delete').find('span').addClass('k-icon k-delete');
            _this.tm.Localize();
            updatePaging(this);
            var rows = this.tbody.children();
            var dataItems = this.dataSource.view();
            for (var i = 0; i < dataItems.length; i++) {
                kendo.bind(rows[i], dataItems[i]);
            }
            _this.validatetor = $("#frmCustomer").kendoValidator({
                errorTemplate: '<span class="errorMsg pull-right"><label  class="error">#=message#</label></span>'
            }).data("kendoValidator");
            if (!_this.validatetor.validate()) {
                $(".errorMsg").removeClass("k-invalid-msg").css("display", "inline");
            }
        }

        function updatePaging(current) {
            current.pager.element.find("a, ul").hide();
            if (current.dataSource.totalPages() > 1) {
                current.pager.element.find("a, ul").show();
            }
            if (current.dataSource.view().length == 0) {
                var currentPage = current.dataSource.page();
                if (currentPage > 1) {
                    current.dataSource.page(currentPage - 1);
                    current.dataSource.sync();
                    current.dataSource.read();
                }
            }
        }

        if (container.find('#gridCustomer').data().kendoGrid)
            container.find('#gridCustomer').data().kendoGrid.destroy();

        var gridCustomer = container.find("#gridCustomer").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            createAt: "top",
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                  { command: commands, width: "87px", attributes: { "class": "align-center" } },
                  {
                      field: "CustomerId", title: "<span data-localize='FIELD_NUMBER'>Number</span>", format: "{0:0}", attributes: { "class": "align-center" },
                      headerAttributes: { "class": "align-center" }, width: "12%",
                      template: function (data) {
                          var nameAndId = 'CustomerId_' + data.id;
                          if (_this.allowEdit)
                              return '<input type="text" class="k-input k-textbox trackChange" style="width:100%" id="' + nameAndId + '" name="' + nameAndId + '" value="' + data.CustomerId + '" data-bind="value:CustomerId">'
                          else
                              return data.CustomerId;
                      }
                  },
                  {
                      field: "CustomerName", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "20%",
                      template: function (data) {
                          var nameAndId = 'CustomerName_' + data.id;
                          if (_this.allowEdit)
                              return '<input type="text" class="k-input k-textbox trackChange"  style="width:100%" id="' + nameAndId + '" name="' + nameAndId + '" value="' + data.CustomerName + '" data-bind="value:CustomerName">'
                          else
                              return data.CustomerName
                      }
                  },
                  { field: "", title: "", headerAttributes: { "class": "left-no_border" }, attributes: { "class": "left-no_border" }, width: "60%" }
            ],
            editable: "inline",
            cancel: function (e) {
                var dataSource = $("#gridCustomer").data("kendoGrid").dataSource;
                var grid = $("#gridCustomer").data("kendoGrid");
                grid.dataSource.read();
            }
        });
        grid = $("#gridCustomer").data("kendoGrid");

        $('#btnSave').click(function () {
            _this.savePage();
        })
        $("#btnCancel1").click(function () {
            _this.onCancelClick();
        });
        function onEdit() {
            clearStatusMessage();
            inlineEditSaveButton();
        }
        var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
        function createOverlay() {
            $("body").append('<div class="overlay_bg"></div>');
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-animation-container").hide();
            $("#deleteDetails").parent(".k-window").addClass('deletepopup');
        }
        function removeOverlay() {
            $(".overlay_bg").hide();
            $("#topnav, .leftmenu-container").removeClass("blur");
            $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
        }
        function onDelete(e) {
            if (_this.isCustomerDelete == false) {
                _this.isCustomerDelete = true;
                var detailsTemplate = kendo.template($("#editCustomer").html());
                var data = this;
                var noEdits = _this.options.eventHandlers.onSaveChangesCustomer(data, e, wnd, detailsTemplate, false);
            }
            else if (_this.isCustomerDelete == true) {
                _this.isCustomerDelete = false;
            createOverlay();
            clearStatusMessage();
            e.preventDefault();
            $("body").css("overflow-y", "hidden");
            var tr = $(e.target).closest("tr");
            var data = this.dataItem(tr);
            deletePopupTemplateWindow.content(deletePopupTemplate(data));
            deletePopupTemplateWindow.open().center();
            grid = $("#gridCustomer").data("kendoGrid");
            grid.refresh();
            $(document).on('keyup', function (e) {
                if (e.which == 27) {
                    $('#noButton').trigger('click');
                }
            });
            $("#yesButton").click(function () {
                grid.dataSource.remove(data);
                grid.saveChanges();
                deletePopupTemplateWindow.close();
                removeOverlay();
                $("body").css("overflow-y", "auto");
            });
            $("#noButton").click(function () {
                deletePopupTemplateWindow.close();
                removeOverlay();
                $("body").css("overflow-y", "auto");
            });
        }
        }
        var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
            title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            visible: false,
            width: "298px",
            height: "auto",
            animation: false,
            draggable: false,
            resizable: false,
        }).data("kendoWindow");

        wnd = $("#details")
                        .kendoWindow({
                            title: $.GetLocaleKeyValue("FIELD_EDITCUSTOMER", 'Edit Customer'),
                            modal: true,
                            resizable: false,
                            visible: false,
                            draggable: false,
                            width: "373px",
                            height: "auto",
                            open: function () {
                                $("#topnav, .leftmenu-container").addClass("blur");
                                $(".k-tooltip").parent(".k-animation-container").hide();
                                $("body").css("overflow-y", "hidden");
                            },
                            close: function () {
                                $("#topnav, .leftmenu-container").removeClass("blur");
                                $("body").css("overflow-y", "auto");
                            },
                            activate: function (e) {
                                _this.tm.Localize();
                            }
                        }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editCustomer").html());


        function showDetails(e) {
            var detailsTemplate = kendo.template($("#editCustomer").html());
            var data = this;
            var noEdits = _this.options.eventHandlers.onSaveChangesCustomer(data, e, wnd, detailsTemplate, true);
            if (noEdits) {
                e.preventDefault();
            clearStatusMessage();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();
            this.dataSource.cancelChanges();
        }
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator")
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSource.fetch(function () {
                    var customer = dataSource.get(uid);
                    customer.set("CustomerId", $("#txtCustomerId").val());
                    customer.set("CustomerName", $("#txtCustomerName").val());
                    dataSource.sync();
                });
                var grid = $("#gridCustomer").data("kendoGrid");
                //grid.saveChanges()
                //wnd.close();
                //$("#errorDiv").html('Updated Successfully');
            }
            else {
                //$("#errorDiv").html('Updation failed');
                return false;
            }
        });        

        var grid;
        var window;
        $("#gridCustomer a.grid-add-new-record").unbind("click");
        $("#gridCustomer a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            e.preventDefault();
            var dataSource = $("#gridCustomer").data("kendoGrid").dataSource;
            dataSource.cancelChanges();
            window = $("<div id='popupEditor'>")
               .appendTo($("body"))
               .kendoWindow({
                   title: $.GetLocaleKeyValue("FIELD_ADDCUSTOMER", 'Add Customer'),
                   modal: true,
                   resizable: false,
                   visible: false,
                   draggable: false,
                   width: "373px",
                   height: "auto",
                   open: function () {
                       $("#topnav, .leftmenu-container").addClass("blur");
                       $("body").css("overflow-y", "hidden");
                   },
                   close: onClose,
                   content: {
                       //sets window template
                       template: kendo.template($("#newCustomer").html())
                   },
                   activate: function (e) {
                       _this.tm.Localize();
                   }
               })
               .data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});


            //binds the editing window to the form
            kendo.bind(window.element, model);

            //determines at what position to insert the record (needed for pageable grids)

            //initialize the validator
            var validator = $(window.element).kendoValidator().data("kendoValidator")
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function (e) {
                if (validator.validate() == true) {
                    var customer = {};
                    customer.CustomerId = $('#CustomerId').val();
                    customer.CustomerName = $('#CustomerName').val();
                    grid = $("#gridCustomer").data("kendoGrid");
                    grid.dataSource.cancelChanges();
                    grid.dataSource.insert(0, customer);
                    grid.saveChanges(); //sync changes
                    //window.close();
                    //window.element.remove();

                }
                else {
                    return false;
                }

            });
            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function (e) {
                dataSource.cancelChanges(model); //cancel changes
                window.close();
                window.element.remove();
            });
            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                window.element.remove();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("body").css("overflow-y", "auto");
            }

        });
        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
            window.close();
        });
        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
        $.validator.addMethod(
                "number",
                function (value, element, regexp) {
                    if ($(element).val() != '')
                        return /^[0-9]*$/.test($(element).val());
                    else
                        return true;
                },
                $.GetLocaleKeyValue('FIELD_ENTERNUMBER', 'Please enter numbers.')
        );
    },
    validate: function () {
        $('#frmCustomer').validate({
            rule: {},
            messages: {}
        });
        $('[name*="CustomerId_"]').each(function (index, element) {
            $(this).rules('add', {
                required: true,
                number: true,
                messages: { // optional custom messages
                    required: $.GetLocaleKeyValue('FIELD_FIELDREQUIRED', 'This field is required.'),
                    number : $.GetLocaleKeyValue('FIELD_INVALIDCUSTID', 'Please enter valid Number.')
                }
            });
        });
        $('[name*="CustomerName_"]').each(function (index, element) {
            $(this).rules('add', {
                required: true,
                messages: { // optional custom messages
                    required: $.GetLocaleKeyValue('FIELD_FIELDREQUIRED', 'This field is required.')
                }
            });
        });
        var v2 = $('#frmCustomer').valid();
        return v2;
    }
}


