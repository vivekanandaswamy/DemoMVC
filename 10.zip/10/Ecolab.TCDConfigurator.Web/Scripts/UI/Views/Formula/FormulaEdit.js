﻿Ecolab.Views.FormulaEdit = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { },
            rendered: function () { },
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'FormulaEdit',
        templateUri: './Scripts/UI/Views/Formula/FormulaEdit.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.FormulaEdit.prototype = {

    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();

    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find("#ddlChainFormulaName").change(function () {
            $('#txtPlantformulaName').val($(this).find('option:selected').text());
            $('#txtPlantformulaName').parent().find('span').empty();
            _this.getChainFormulaData($(this).val());
        });

        container.find("#txtNumberofweightedPieces").change(function () {
            _this.CalPieceWeight();
        });

        container.find("#txtWeight").change(function () {
            _this.CalPieceWeight();
        });

        container.find("#btnSave").click(function () {            
            _this.onSaveClicked(container.find("#hPlantChainId").val());
        });
        container.find("#btnCancel1").click(function () {
            _this.onCancelClicked();
        });
    },
    getChainFormulaData: function (plantProgramId) {
        if (this.options.eventHandlers.getChainFormulaData)
            this.options.eventHandlers.getChainFormulaData(plantProgramId);
    },
    BindChainFormulaData: function (data) {
        var container = $(this.options.containerSelector);

        var ddlFormulaCategory = container.find("#ddlFormulaCategory");
        ddlFormulaCategory.empty();
        ddlFormulaCategory.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlFormulaCategory.append('<option value="' + data[0].FormulaCategoryId + '" selected="selected">' + data[0].FormulaCategoryName + '</option>');
        });

        $("#ddlFormulaCategory").val(data[0].FormulaCategoryId)
        var selectedOption = $('#ddlFormulaCategory').find(":selected").text();
        $('#ddlFormulaCategory').next(".holder").text(selectedOption);

        var ddlTextileSaturation = container.find("#ddlTextileSaturation");
        ddlTextileSaturation.empty();
        ddlTextileSaturation.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlTextileSaturation.append('<option value="' + data[0].EcolabSaturationId + '" selected="selected">' + data[0].EcolabSaturationName + '</option>');
        });

        $("#ddlTextileSaturation").val(data[0].EcolabSaturationId)
        var selectedOption = $('#ddlTextileSaturation').find(":selected").text();
        $('#ddlTextileSaturation').next(".holder").text(selectedOption);

        var ddlFormulaSegment = container.find("#ddlFormulaSegment");
        ddlFormulaSegment.empty();
        ddlFormulaSegment.append('<option value="">-- Select --</option>');
        $.each(data, function () {
            ddlFormulaSegment.append('<option value="' + data[0].FormulaSegmentId + '" selected="selected">' + data[0].FormulaSegmentName + '</option>');
        });

        $("#ddlFormulaSegment").val(data[0].FormulaSegmentId)
        var selectedOption = $('#ddlFormulaSegment').find(":selected").text();
        $('#ddlFormulaSegment').next(".holder").text(selectedOption);
    },

    CalPieceWeight: function () {
        var container = $(this.options.containerSelector);


        container.find('#txtPieceWeight').val('0');
        var totalpieces = container.find("#txtNumberofweightedPieces").val();
        var weight = container.find("#txtWeight").val();


        if (totalpieces <= 0 && totalpieces != '') {
            container.find("#txtNumberofweightedPieces").val('0');
            return;
        }
        if (weight <= 0 && weight != '') {
            container.find("#txtWeight").val();
            return;
        }
        if (weight == '' || totalpieces == '') {
            return;
        }
        var pieceWeight = weight / totalpieces;
        container.find('#txtPieceWeight').val(pieceWeight.toFixed(2));
    },

    onSaveClicked: function (plantChainId) {
        var _this = this;
        if (_this.validate(plantChainId)) {
            if (this.options.eventHandlers.onSavePage) {
                this.options.eventHandlers.onSavePage();
            }
        }
    },

    validate: function (plantChianId) {
        if (plantChianId == "0") {
            var v1 = $('#frmAddEditFormula').validate({
                rules: {
                    txtPlantformulaName: { required: true },
                    ddlFormulaCategory: { required: true },
                    ddlTextileSaturation: { required: true },
                    ddlFormulaSegment: { required: true },
                },
                messages: {
                    txtPlantformulaName: {
                        required: $.GetLocaleKeyValue('FIELD_FORMULANAMEREQUIRED', 'Formula name required.')
                    },
                    ddlFormulaCategory: {
                        required: $.GetLocaleKeyValue('FIELD_FORMULACATEGORYREQUIRED', 'Formula Category required.')
                    },
                    ddlTextileSaturation: {
                        required: $.GetLocaleKeyValue('FIELD_TEXTILESATURATIONREQUIRED', 'Textile Saturation required.')
                    },
                    ddlFormulaSegment: {
                        required: $.GetLocaleKeyValue('FIELD_FORMULASEGMENTREQUIRED', 'Formula Segment required.')
                    },

                },
                errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.k-error-message"));

                    if (element.parent().hasClass("input-group")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                    if (element.hasClass("custom-select")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                }
            });            
        } else {
            var v1 = $('#frmAddEditFormula').validate({
                rules: {
                    txtPlantformulaName: { required: true },
                    ddlChainFormulaName: { required: true }

                },
                messages: {
                    txtPlantformulaName: {
                        required: $.GetLocaleKeyValue('FIELD_FORMULANAMEREQUIRED', 'Formula name required.')
                    },
                    ddlChainFormulaName: {
                        required: $.GetLocaleKeyValue('FIELD_CHAINFORMULANAMEREQUIRED', 'Chain Formula name required.')
                    }
                },
                errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.k-error-message"));

                    if (element.parent().hasClass("input-group")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                    if (element.hasClass("custom-select")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                }
            });
        }
        
        var v2 = $('#frmAddEditFormula').valid();
        return v2;
    },

    getFormulaData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var formulaData = {
            ProgramId: container.find("#txtPlantformulaName").attr("data-programid"),
            Name: container.find("#txtPlantformulaName").val(),
            PlantChainId: container.find("#txtPlantformulaName").attr("data-plantChainid"),
            PlantProgramId: container.find("#ddlChainFormulaName").val(),
            FormulaCategory: container.find("#ddlFormulaCategory").val(),
            EcolabSaturationId: container.find("#ddlTextileSaturation").val(),
            FormulaSegmentId: container.find("#ddlFormulaSegment").val(),
            CustomerId: container.find("#ddlPlantCustomer").val(),
            Rewash: container.find('#cbRewash').is(":checked") ? true : false,
            Pieces: container.find("#txtNumberofweightedPieces").val(),
            WeightDisplay: container.find("#txtWeight").val(),
            LastModifiedTimeStamp: container.find("#txtPlantformulaName").attr("data-LastModifiedTimeStamp"),
        };
        return formulaData;
    },

    showSucessMessage: function (msg) {
        $('#errorDiv').val(msg);
    },
    onCancelClicked: function () {
        $('#myModal').modal('hide');
    },
    showErrorMessage: function (msg) {
        $('#errorEditDiv').html(msg);
    },

}