﻿Ecolab.Views.Formula = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            setIsDirtyFalse: function () { },
            getTextileSaturation: function () { }
        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Formula/Formula.html',
        paraFormula: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });

    this.allowEdit = false;

    this.tmEdit = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Formula/Formula.html',
        paraFormula: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.FormulaData = null;
    this.isBatchEdit = null;
};

Ecolab.Views.Formula.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },
    setFormulaData: function (data) {
        var _this = this;
        this.FormulaData = data;
    },


    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {

        var _this = this;
       // this.attachEvents();
        
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span').addClass('k-icon k-addbtn');
        $('.grid-add-new-record').insertBefore("#errorDiv");
        $(".k-grid-pager").find("a, ul").hide();
    },

    initValidator: function () {
        $.validator.addMethod(
                "regex",
                function (value, element, regexp) {
                    var check = false;
                    var re = new RegExp(regexp);
                    return this.optional(element) || re.test(value);
                },
                $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', 'Enter only numerics.')
        );
    },

    validate: function () {
        //this.resetErrors();
        var pattern1 = /^[0-9]*$/;
        var v1 = $('#frmFormula').validate({
            rules: {
                txtFormulaName:
                    {
                        required: true
                    },
                txtcopyFormulaName: {
                    required: true
                },
                txtNumberofweightedPieces: {
                    regex: pattern1
                },
                txtWeight: {
                    digits: true
                },
                ddlEcolabTextileCategoryAdd: {
                    required: true,
                },
                ddlEcolabSaturationAdd: {
                    required: true,
                }
            },

            messages: {
                txtFormulaName: {
                    required: $.GetLocaleKeyValue('FIELD_FORMULANAMEREQUIRED', 'Formula name required.')
                },
                txtcopyFormulaName: {
                    required: $.GetLocaleKeyValue('FIELD_FORMULANAMEREQUIRED', 'Formula name required.')
                },
                ddlEcolabTextileCategoryAdd: {
                    required: $.GetLocaleKeyValue('FIELD_ECOLABTEXTILEREQUIRED', 'Ecolab Textile required.')
                },
                txtNumberofweightedPieces: {
                    regex: $.GetLocaleKeyValue('FIELD_INVALIDVALUESENTERONLYNUMBERS', 'Invalid values, enter only numbers.')
                },
                txtWeight: {
                    digits: $.GetLocaleKeyValue('FIELD_INVALIDVALUESENTERONLYNUMBERS', 'Invalid values, enter only numbers.')
                },
				ddlEcolabTextileCategory: {
					required: $.GetLocaleKeyValue('FIELD_ECOLABTEXTILEREQUIRED', 'Ecolab Textile required.')
				},
				ddlEcolabSaturation: {
					required: $.GetLocaleKeyValue('FIELD_ECOLABSATURATIONREQUIRED', 'Ecolab Saturation required.')
				},
                onsubmit: true,
                onkeyup: false,
                focusInvalid: false,
                errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.errorMsg"));
                }
            }
        });

        $('[name*="txtFormulaName_"]').each(function () {
            $(this).rules('add', {
                required: true,
                messages: { // optional custom messages
                    required: "This field is required"
                }
            });
        });

        var v2 = $('#frmFormula').valid();
        return v2;
    },

    

    setFormulaOnAddNewPopupLoadData: function (data) {
        var _this = this;
        this.FormulaData = data;
        this.attachEvents();

        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span').addClass('k-icon k-addbtn');
        $('.grid-add-new-record').insertBefore("#errorDiv");
        $(".k-grid-pager").find("a, ul").hide();
    },

    SetIsDirty: function (flage) {
        if (this.options.eventHandlers.setIsDirty)
            this.options.eventHandlers.setIsDirty(flage);
    },
    onCancel: function () {
        if (this.options.eventHandlers.onRedirection)
            this.options.eventHandlers.onRedirection("/Formula");
    },

    attachEvents: function () {
        var _this = this;
        _this.allowEdit = (this.data.MaxLevel > 5);
        $("#frmFormula").kendoValidator();
        var wnd, detailsTemplate;
        var trIndex = null;
        var container = $(this.options.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');

        function setMessage(message, isSuccess) {
            $("#errorDiv").attr('class', isSuccess ? 'k-success-message' : 'k-error-message').html(message);
        }

        function setIsDirtyFalse() {
            _this.options.eventHandlers.setIsDirtyFalse();
        }

        var dataSrc = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/PlantFormula/GetFormula",
                    dataType: "json",
                },

                update: {
                    url: "/api/PlantFormula/Put",
                    dataType: "json",
                    contentType: "application/json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        var isInline = _this.isBatchEdit;
                        var message;
                        if (textStatus == 'success') {
                            message = $.GetLocaleKeyValue("FIELD_FORMULAUPDATEDSUCCESSFULLY", "Formula updated successfully.");
                            setMessage(message, true);
                            setIsDirtyFalse();
                            $("#btnSave").attr("disabled", "disabled");
                            $("#btnCancel1").attr("disabled", "disabled");
                            _this.SetIsDirty(false);
                            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                            var grid = $("#gridFormula").data("kendoGrid");
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                            wnd.close();
                        }
                        else if (jqXhr.responseText == '51030') {
                            message = $.GetLocaleKeyValue("FIELD_RECORDSCOUNTDOESNTMATCH", "Record count does not match..Resynch is in progress.");
                            isInline ? setMessage(message) : $('#errorMessage').removeClass('hide').html('<span>' + message + '</span>');
                        }
                        else if (jqXhr.responseText == '60000') {
                            message = $.GetLocaleKeyValue("FIELD_RECORDSNOTINSYNCH", "Record not in synch..Resynch is in progress.");
                            isInline ? setMessage(message) : $('#errorMessage').removeClass('hide').html('<span>' + message + '</span>');
                        }
                        else if (jqXhr.responseText == '51031' || jqXhr.responseText == '303' || jqXhr.responseJSON == "Formula Name already exists.") {
                            message = $.GetLocaleKeyValue("FIELD_FORMULAALREADYEXIST", "Formula already exist.");
                            isInline ? setMessage(message) : $('#errorMessage').removeClass('hide').html('<span>' + message + '</span>');

                        } else {
                            $('#errorMessage').removeClass('hide').html('<span>' + $.GetLocaleKeyValue("FIELD_FORMULAUPDATIONFAILED", "Formula updation failed.") + '</span>');
                        }
                    }
                },
                destroy: {
                    url: "/api/PlantFormula/DeleteFormula",
                    dataType: "json",
                    contentType: "application/json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            var grid = $("#gridFormula").data("kendoGrid");
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_FORMULADELETEDSUCCESSFULLY", 'Formula deleted sucessfully.'));
                        }
                        else if (jqXhr.responseText == '51030') {
                            setMessage($.GetLocaleKeyValue("FIELD_RECORDSCOUNTDOESNTMATCH", "Record count does not match..Resynch is in progress."));
                        }
                        else if (jqXhr.responseText == '51031') {
                            setMessage($.GetLocaleKeyValue("FIELD_FORMULAALREADYEXIST", "Formula already exist."));
                        }
                        else if (jqXhr.responseText == '60000') {
                            setMessage($.GetLocaleKeyValue("FIELD_RECORDSNOTINSYNCH", "Record not in synch..Resynch is in progress."));
                        }
                        else {
                            $("#errorDiv").attr('class', 'k-success-message').html($.GetLocaleKeyValue("FIELD_FORMULADELETEDSUCCESSFULLY", 'Formula deleted sucessfully.'));
                        }
                    }
                },
                parameterMap: function (data, type) {
                    if (type == "update" || type == "create" || type == "destroy") {
                        return kendo.stringify(data.models);
                    }
                }
            },
           

            error: function (e) {
                if (($('.k-edit-form-container').find('div.k-edit-buttons.k-state-default'))) {
                    var error = '<div class= "errorMessageModal"><label>' + $.parseJSON(e.xhr.responseText) + '</label></div>';
                    var buttons = $('.k-edit-form-container').find('div.k-edit-buttons.k-state-default');
                    $('.k-edit-form-container').find('.errorMessageModal').remove();
                    buttons.before(error);
                } else {
                    $("#TmContactStatus").empty().removeClass().addClass('errorMessage').append('<label>' + e.xhr.responseText + '</label>');
                }
            },
            batch: true,
            requestStart: function (e) {
                var gridFormula = $("#gridFormula");
                if (_this.data.accountInfo.MaxLevel < 5 || _this.data.accountInfo.RoleName == "TRC") {
                    gridFormula.data("kendoGrid").hideColumn("CategoryName");
                }
            },
            //pageSize: 50,
            schema: {
                data: function (data) {
                    return data.Items;
                },
                total: function (data) {
                    return data.TotalCount;
                },
                model: {
                    id: "ProgramId",
                    fields: {
                        ProgramId: { editable: false, type: "number", nullable: false },
                        Name: {
                            editable: function (e) {
                                if (_this.allowEdit)
                                    return true;
                                else
                                    return false;

                            },
                            validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_FORMULANAMEREQUIRED", "Formula name required") }
                        },
                        CategoryName: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_CATEGORYNAMEREQUIRED", "Category name required") } },
                        EcolabSaturationName: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_SATURATIONNAMEREQUIRED", "Saturation name required") } },
                        PlantProgramName: { editable: true},
                        ChainTextileCategory: { editable: true},
                        Rewash: {
                            editable: function (e) {
                                if (_this.allowEdit)
                                    return true;
                                else
                                    return false;

                            },
                            type: "boolean"
                        },
                        Pieces: {
                            editable: true,
                            validation: {
                                onlyDigits: function (input) {
                                    if (input.is("[name='Pieces']")) {
                                        input.attr("data-onlyDigits-msg", $.GetLocaleKeyValue("FIELD_PIECESISNOTVALID", "Pieces is not valid."));
                                        var pattern = new RegExp("^[0-9]+$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        }
                                        else {
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            },
                        },
                        Weight: { editable: true },
                        PieceWeight: { editable: false }
                    }
                }
            },
            //serverPaging: false
        });

        //Set basing on roles Here
        var addNew, commands, editTitle, customWidth = "135px";
        if (_this.allowEdit) {
            _this.isView = false;
            commands = [
                { name: "Delete", text: " ", click: onDelete },
                { name: "update", text: " ", click: showDetails },
                { name: 'copy', text: "", click: copyRecord }
            ];

            addNew = [{ text: $.GetLocaleKeyValue('FIELD_ADDFORMULA', 'Add Formula'), className: "btn btn-sm btn-primary grid-add-new-record" }];
            editTitle = $.GetLocaleKeyValue("FIELD_EDITFORMULA", 'Edit Formula');
        } else {
            _this.isView = true;
            commands = [{ name: "view", text: " ", click: showDetails }];
            addNew = "";
            customWidth = "55px";
            editTitle = "View Customer";
        }

        function onDataBound(arg) {
            $('.k-button-icontext.k-grid-copy').find('span').addClass('k-icon k-custom-copy');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            $('.k-button-icontext.k-grid-Delete').find('span').addClass('k-icon k-delete');
            //updatePaging(this);

            var rows = this.tbody.children();
            var dataItems = this.dataSource.view();
            for (var i = 0; i < dataItems.length; i++) {
                kendo.bind(rows[i], dataItems[i]);
            }
            $('[name=EcolabSaturationNameDropDown]').kendoComboBox({
                autoBind: false,
                dataSource: _this.FormulaData.ecolabSaturation,
                change: function (e) {
                    var dataItem = e.sender.dataItem();
                    $("#btnSave").removeAttr("disabled");
                    $("#btnCancel1").removeAttr("disabled");
                    _this.SetIsDirty(true);
                }
            });

            $('[name=ChainTextileCategoryNameDropDown]').kendoComboBox({
                autoBind: false,
                dataSource: _this.FormulaData.chainTextileCategory,
                change: function (e) {
                    var dataItem = e.sender.dataItem();
                    $("#btnSave").removeAttr("disabled");
                    $("#btnCancel1").removeAttr("disabled");
                    _this.SetIsDirty(true);
                }
            });

            $('[name=EcolabTextileCategoryNameDropDown]').kendoComboBox({
                autoBind: false,
                dataSource: _this.FormulaData.ecolabTextileCategory,
                change: function (e) {
                    var dataItem = e.sender.dataItem();
                    $("#btnSave").removeAttr("disabled");
                    $("#btnCancel1").removeAttr("disabled");
                    _this.SetIsDirty(true);
                }
            });            
            //$('#gridFormula tbody [name=txtFormulaName]').focus(function () {
            //    $('#gridFormula').data("kendoGrid").editCell($(this).parent('td'));
            //});
        }

        function updatePaging(current) {
            current.pager.element.find("a, ul").hide();
            if (current.dataSource.totalPages() > 1) {
                current.pager.element.find("a, ul").show();
            }
            if (current.dataSource.view().length == 0) {
                var currentPage = current.dataSource.page();
                if (currentPage > 1) {
                    current.dataSource.page(currentPage - 1);
                    current.dataSource.sync();
                    current.dataSource.read();
                }
            }
        }

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }

        
        if (container.find('#gridFormula').data().kendoGrid)
            container.find('#gridFormula').data().kendoGrid.destroy();
        container.find("#gridFormula").kendoGrid({
            dataSource: dataSrc,
            //pageable: true,
            createAt: "top",
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            edit: function (e) {
                e.container.find('.ecolabSaturation').find('input').attr('disabled', true).attr('id', 'saturationId')
            },

            columns: [
                { command: commands, width: "98px", attributes: { "class": "align-center" } },
                {
                    field: "Name", title: "Name", title: "<span data-localize='FIELD_FORMULANAME'>Name</span>",
                    width: "15%",
                    template: function(data){
                        if (_this.allowEdit) {
                            return '<input type="text" class="input95percentage form-control k-input k-textbox enableSave recordingValue trackChange" name="txtFormulaName_' + data.ProgramId + '" id="txtFormulaName_' + data.ProgramId + '" data-bind="value: Name" />'
                        } else {
                            return data.Name;
                        }
                    
                    },
                    validate : {
                        required : true
                    }
                },
                {
                    field: "EcolabSaturationId",
                    title: "<span data-localize='FIELD_ECOLABSATURATION'>Textile Saturation</span>",
                    template: function (data) {
                        if (_this.allowEdit) {
                            return '<input class="trackChange" style="width:100%"  id="EcolabSaturationNameDropDown_' + data.EcolabSaturationId + '" name="EcolabSaturationNameDropDown" required data-text-field="EcolabSaturationName" data-value-field="EcolabSaturationId" data-role="combobox" data-bind="value:EcolabSaturationId"/>';
                        }
                        else {
                            return data.EcolabSaturationName;
                        }
                    },
                    width: "14%"
                },
                {
                    field: "ChainTextileId",
                    title: "<span data-localize='FIELD_TEXTILECATEGORY'>Textile Category</span>",
                    template: function (data) {
                        if (_this.allowEdit) {
                            return '<input class="trackChange" style="width:100%"  id="ChainTextileCategoryNameDropDown_' + data.TextileId + '" name="ChainTextileCategoryNameDropDown" required data-text-field="Name" data-value-field="TextileId" data-role="combobox" data-bind="value:ChainTextileId"/>';
                        } else {
                            return data.ChainTextileCategory;
                        }
                    },
                    width: "16%"
                },
                {
                    field: "TextileId",
                    title: "<span data-localize='FIELD_TEXTILECATEGORYECOLAB'>Textile Category Ecolab</span>",
                    template: function (data) {
                        if (_this.allowEdit) {
                            return '<input class="trackChange" style="width:100%"  id="EcolabTextileCategoryNameDropDown_' + data.TextileId + '" name="EcolabTextileCategoryNameDropDown" required data-text-field="CategoryName" data-value-field="TextileId" data-role="combobox" data-bind="value:TextileId"/>';
                        } else {
                            return data.CategoryName;
                        }                       

                    },
                    width: "16%"
                },
                {
                    field: "Rewash",
                    title: "<span data-localize='FIELD_REWASHFORMULA'>Rewash Formula</span>",
                    width: "12%",
                    template: function (data) {
                        if (_this.allowEdit) {
                            return '<input type="checkbox" class="chkbx trackChange" name="Rewash" data-type="boolean" ' + (data.Rewash ? 'checked' : '') + '/>'

                        } else {
                            return '<input type="checkbox" class="chkbx trackChange" disabled name="Rewash" data-type="boolean" ' + (data.Rewash ? 'checked' : '') + '/>'
                        }
                    }
                },
                {
                    field: "PieceWeight", title: "<span data-localize='FIELD_PIECEWEIGHT'>Piece Weight</span>(" + $.GetLocaleKeyValue("Weight_CommonUse", "lbs", "uomLocalizeData") + ")", attributes: { "class": "align-right" }, width: "10%"
                    , template: function (data) { return data.PieceWeightAsString; },
                }
            ],            
            editable: "inline",
            cancel: function (e) {
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                grid.dataSource.read();
            }
        });

        $("#gridFormula .k-grid-content").on("change", "input.chkbx", function (e) {
            var grid1 = $("#gridFormula").data("kendoGrid"),
                dataItem = grid1.dataItem($(e.target).closest("tr"));

            dataItem.set("Rewash", this.checked);
        });

        $('#btnSave').click(function () {
            _this.isBatchEdit = true;
            if (_this.validate()) {
                grid.saveChanges();
            }
        });

        $("#btnCancel1").click(function () {
            _this.onCancel();
        });

        grid = $("#gridFormula").data("kendoGrid");
        function onEdit(e) {
            clearStatusMessage();
            inlineEditSaveButton();
        }
        var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
        function createOverlay() {
            $("body").append('<div class="overlay_bg"></div>');
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-animation-container").hide();
            $("#deleteDetails").parent(".k-window").addClass('deletepopup');
        }
        function removeOverlay() {
            $(".overlay_bg").hide();
            $("#topnav, .leftmenu-container").removeClass("blur");
            $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
        }
        function onDelete(e) {
            e.preventDefault();
            createOverlay();
            clearStatusMessage();
            $("body").css("overflow-y", "hidden");
            var tr = $(e.target).closest("tr");
            var data = this.dataItem(tr);
            deletePopupTemplateWindow.content(deletePopupTemplate(data));
            deletePopupTemplateWindow.open().center();
            grid = $("#gridFormula").data("kendoGrid");
            grid.refresh();
            $(document).on('keyup', function (e) {
                if (e.which == 27) {
                    $('#noButton').trigger('click');
                }
            });
            $("#yesButton").click(function () {
                grid.dataSource.remove(data);
                grid.saveChanges();
                deletePopupTemplateWindow.close();
                removeOverlay();
                $("body").css("overflow-y", "auto");
            });
            $("#noButton").click(function () {
                deletePopupTemplateWindow.close();
                removeOverlay();
                $("body").css("overflow-y", "auto");
            });
        }
        var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
            title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            visible: false,
            width: "298px",
            height: "auto",
            animation: false,
            draggable: false,
            resizable: false,
        }).data("kendoWindow");

        wnd = $("#details")
                       .kendoWindow({
                           title: $.GetLocaleKeyValue("FIELD_EDITFORMULA", "Edit Formula"),
                           modal: true,
                           resizable: false,
                           visible: false,
                           draggable: false,
                           width: "450px",
                           height: "auto",
                           open: function () {
                               if (_this.FormulaData && _this.FormulaData.units != null && _this.FormulaData.units.length > 0) {
                               $('#spnWeightEdit').text('(' + _this.FormulaData.units[0].UsageKey + ')');

                               $('#spnPieceWeightEdit').text('(' + _this.FormulaData.units[0].UsageKey + ')');
                               }
                               $("#cbRewash").kendoMobileSwitch({
                                   onLabel: "YES",
                                   offLabel: "NO",
                                   change: function (e) {
                                       enable();
                                   }
                               });
                               $('select').kendoDropDownList();
                               editCalPieceWeight();
                               $("#topnav, .leftmenu-container").addClass("blur");
                               $(".k-tooltip").parent(".k-animation-container").hide();
                               $("body").css("overflow-y", "hidden");
                           },
                           close: function () {
                               $("#topnav, .leftmenu-container").removeClass("blur");
                               $("body").css("overflow-y", "auto");
                           }
                       }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editFormula").html());

        function showDetails(e) {
            clearStatusMessage();
            e.preventDefault();
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            dataItem.FormulaDataToLoadDropdown = _this.FormulaData;
            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();
            $("#ddlChainTextileCategory").change(function () {
                var selectedChainTextileId = $("#ddlChainTextileCategory").val().trim();
                getTextileSaturation(selectedChainTextileId,'edit');
            });

            this.dataSource.cancelChanges();
        }

        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator");
            var popupContainer = $(this).closest('#details-container');
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSrc.fetch(function () {
                    var formula = dataSrc.get(uid);
                    formula.set("Name", popupContainer.find("#txtFormulaName").val());
                    formula.set("TextileId", popupContainer.find("#ddlEcolabTextileCategory").val());
                    formula.set("CategoryName", popupContainer.find("#ddlEcolabTextileCategory option:selected").text());
                    formula.set("EcolabSaturationId", popupContainer.find("#txtEcolabSaturationEdit").attr('data-saturationId'));
                    formula.set("EcolabSaturationName", popupContainer.find("#txtEcolabSaturationEdit").val().trim());
                    formula.set("PlantProgramId", popupContainer.find("#ddlChainFormula").val());
                    formula.set("PlantProgramName", popupContainer.find("#ddlChainFormula option:selected").text());
                    formula.set("ChainTextileId", popupContainer.find("#ddlChainTextileCategory").val());
                    formula.set("ChainTextileCategory", popupContainer.find("#ddlChainTextileCategory option:selected").text());
                    formula.set("Rewash", popupContainer.find("#cbRewash").is(":checked"));
                    formula.set("Pieces", popupContainer.find("#txtNumberofweightedPieces").val());
                    formula.set("WeightDisplay", popupContainer.find("#txtWeight").val());
                    formula.set("Weight", popupContainer.find("#txtWeight").val());
                    formula.set("PieceWeight", popupContainer.find("#txtPieceWeight").val());
                    formula.set("CustomerId", popupContainer.find("#ddlCustomer option:selected").val());
                    dataSrc.sync();
                });

                var grid = $("#gridFormula").data("kendoGrid");
                //grid.cancelChanges();
                //grid.saveChanges();
                _this.isBatchEdit = false;
                grid.dataSource.read();
            }
            else {
                return false;
            }
        });

        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
            var grid = $("#gridFormula").data("kendoGrid");
            grid.dataSource._destroyed = [];
            grid.dataSource.read();
        });

        var grid;
        $("#gridFormula a.grid-add-new-record").unbind("click");
        $("#gridFormula a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            e.preventDefault();
            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
            var window = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                    title: $.GetLocaleKeyValue("FIELD_ADDFORMULA", "Add Formula"),
                    modal: true,
                    resizable: false,
                    visible: false,
                    draggable: false,
                    width: "450px",
                    height: "auto",
                    open: onAddNewOpen,
                    close: onClose,
                    content: {
                        //sets window template
                        template: kendo.template($("#newFormula").html())
                    }
                })
                .data("kendoWindow").center().open();
            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }

            function onClose(e) {
                //dataSource.cancelChanges(); //cancel changes
                window.element.remove();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("body").css("overflow-y", "auto");
            }

            function onAddNewOpen(e) {
                //grid.dataSource.cancelChanges();
                var ddlEcolabTextileCategoryAdd = $('#ddlEcolabTextileCategoryAdd');
                ddlEcolabTextileCategoryAdd.empty();
                ddlEcolabTextileCategoryAdd.append('<option value="">Select</option>');
                $.each(_this.FormulaData.ecolabTextileCategory, function () {
                    ddlEcolabTextileCategoryAdd.append('<option value="' + this.TextileId + '">' + this.CategoryName + '</option>');
                });
                if (_this.FormulaData && _this.FormulaData.units != null && _this.FormulaData.units.length > 0) {

                $('#spnWeightAdd').text('(' + _this.FormulaData.units[0].UsageKey + ')');

                $('#spnPieceWeightAdd').text('(' + _this.FormulaData.units[0].UsageKey + ')');
                }

                var ddlChainFormulaAdd = $('#ddlChainFormulaAdd');
                ddlChainFormulaAdd.empty();
                ddlChainFormulaAdd.append('<option value="">Select</option>');
                $.each(_this.FormulaData.plantChainProgram, function () {
                    ddlChainFormulaAdd.append('<option value="' + this.PlantProgramId + '">' + this.PlantProgramName + '</option>');
                });


                var ddlChainTextileCategoryAdd = $('#ddlChainTextileCategoryAdd');
                ddlChainTextileCategoryAdd.empty();
                ddlChainTextileCategoryAdd.append('<option value="">Select</option>');
                $.each(_this.FormulaData.chainTextileCategory, function () {
                    ddlChainTextileCategoryAdd.append('<option value="' + this.TextileId + '">' + this.Name + '</option>');
                });

                ddlChainTextileCategoryAdd.change(function () {
                    var selectedChainTextileId = $("#ddlChainTextileCategoryAdd").val().trim();
                    getTextileSaturation(selectedChainTextileId,'add');
                });

                var ddlCustomer = $("#ddlCustomerAdd");
                ddlCustomer.empty();
                ddlCustomer.append('<option value="-1">All</option>');
                $.each(_this.FormulaData.CustomerList, function () {
                    ddlCustomer.append('<option value="' + this.Id + '">' + this.CustomerName + '</option>');
                });

                $("#chkRewashFormulaAdd").kendoMobileSwitch({
                    onLabel: "YES", offLabel: "NO", change: function (e) {
                        enable1();
                    }
                });
                $('select').kendoDropDownList();
                calPieceWeightforAdd();
                $("#topnav, .leftmenu-container").addClass("blur");
                $("body").css("overflow-y", "hidden");
            }
            //dataSource.sync();
            grid = $("#gridFormula").data("kendoGrid");
            //grid.saveChanges()
            wnd.close();
            //wnd.destroy();
            grid.dataSource._destroyed = [];
            //grid.dataSource.read();

            detailsTemplate1 = kendo.template($("#newFormula").html());
            window.content();
            $(".cancelAddRowPopup, .k-window-action .k-icon .k-i-close").unbind("click");
            $(document).on("click", ".cancelAddRowPopup, .k-icon .k-i-close", function () {
                window.destroy();
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                //dataSource.cancelChanges();
                //grid.dataSource.read();
                $("#topnav, .leftmenu-container").removeClass("blur");
            });

            //binds the editing window to the form
            kendo.bind(window.element);

            //determines at what position to insert the record (needed for pageable grids)

            //initialize the validator
            var validator = $(window.element).kendoValidator().data("kendoValidator");
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function (e) {
                if (validator.validate() == true) {
                    dataSource._data = [];
                    var popupContainer = $(this).closest('#details-container');
                    var ddlEcolabTextileCategoryAdd = popupContainer.find("#ddlEcolabTextileCategoryAdd").val() ? popupContainer.find("#ddlEcolabTextileCategoryAdd").val() : null;
                    var ecolabSaturationId = popupContainer.find("#txtEcolabSaturationAdd").attr('data-saturationId');
                    var ecolabSaturationName = popupContainer.find("#txtEcolabSaturationAdd").val().trim();
                    var ddlChainFormulaAdd = popupContainer.find("#ddlChainFormulaAdd").val().trim();
                    var ddlChainTextileCategoryAdd = popupContainer.find("#ddlChainTextileCategoryAdd").val().trim();
                    var txtFormulaName = popupContainer.find("#txtFormulaNameAdd").val().trim();
                    var txtRewashFormula = popupContainer.find("#chkRewashFormulaAdd").is(":checked");
                    var txtNumberofweightedPieces = popupContainer.find("#txtaddNumberofweightedPiecesAdd").val().trim();
                    var txtWeight = popupContainer.find("#txtaddWeight").val().trim();

                    var txtPieceWeight = popupContainer.find("#txtPieceWeightAdd").val().trim();

                    dataSource._data.push({
                        TextileId: ddlEcolabTextileCategoryAdd,
                        EcolabSaturationId: ecolabSaturationId,
                        EecolabSaturationName: ecolabSaturationName,
                        PlantProgramId: ddlChainFormulaAdd,
                        ChainTextileId: ddlChainTextileCategoryAdd,
                        Name: txtFormulaName,
                        ProgramId: 0,
                        Rewash: txtRewashFormula,
                        Pieces: txtNumberofweightedPieces,
                        WeightDisplay: txtWeight,
                        Weight: txtWeight,
                        PieceWeight: txtPieceWeight,
                        CustomerId: $("#ddlCustomerAdd option:selected").val(),
                    });
                    // dataSource.sync(); //sync changes
                    var grid = $("#gridFormula").data("kendoGrid");
                    $.ajax({
                        type: "POST",
                        url: "/api/PlantFormula/CreateFormula",
                        data: JSON.stringify(dataSource._data[0]),
                        contentType: "application/json; charset=utf-8",
                        dataType: "Json",
                        error: function (error) {
                            if (error.responseText == '51030') {
                                $('#errorMessageAdd').removeClass('hide').html('<span>' + $.GetLocaleKeyValue("FIELD_RECORDCOUNTDOESNTMATCH", "Formula count does not match.Resynch is in progress.") + '</span>');
                            }
                            else if (error.responseText == '60000') {
                                $('#errorMessageAdd').removeClass('hide').html('<span>' + $.GetLocaleKeyValue("FIELD_RECORDSNOTINSYNCH", "Record not in synch..Resynch is in progress.") + '</span>');
                            }
                            else if (error.responseText == '51031' || error.responseText == '303') {
                                $('#errorMessageAdd').removeClass('hide').html('<span>' + $.GetLocaleKeyValue("FIELD_FORMULAALREADYEXIST", "Formula already exist.") + '</span>');
                            }
                            else {
                                $('#errorMessageAdd').removeClass('hide').html('<span>' + $.GetLocaleKeyValue('FIELD_FORMULANAMEALREADYEXISTS', 'Formula name already exists.') + '</span>');
                                //alert(JSON.parse(error.responseText));
                            }

                        },
                        success: function () {
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                            window.close();
                            window.destroy();
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_NEWFORMULADDEDSUCCESSFULLY", 'New Formula added successfully.'));
                        }
                    });

                }
                else {
                    return false;
                }
            });
            $(".cancelRowPopup").unbind("click");
            $(document).on("click", ".cancelRowPopup", function () {
                wnd.close();
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                //dataSource.cancelChanges();
                //grid.dataSource.read();
            });

        });

        function copyRecord(e) {
            e.preventDefault();
            var wnd, detailsTemplate;
            var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
            var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
            dataItem.PlantProgramId = 0;
            dataItem.FormulaDataToLoadDropdown = _this.FormulaData;
            wnd = $("#popup_edit")
                            .kendoWindow({
                                title: "Copy",
                                modal: true,
                                resizable: false,
                                visible: false,
                                draggable: false,
                                width: "373px",
                                open: function () {
                                    if (_this.FormulaData && _this.FormulaData.units != null && _this.FormulaData.units.length > 0) {

                                    $('#spnWeightCopy').text('(' + _this.FormulaData.units[0].UsageKey + ')');

                                    $('#spnPieceWeightCopy').text('(' + _this.FormulaData.units[0].UsageKey + ')');
                                    }

                                    $("#cbRewashCopy").kendoMobileSwitch({
                                        onLabel: "YES",
                                        offLabel: "NO",
                                        change: function (e) {
                                            enable2();
                                        }
                                    });
                                    $('select').kendoDropDownList();
                                    copyCalPieceWeight();
                                    $("#topnav, .leftmenu-container").addClass("blur");
                                    $(".k-tooltip").parent(".k-animation-container").hide();
                                    $("body").css("overflow-y", "hidden");
                                },
                                close: function () {
                                    $("#topnav, .leftmenu-container").removeClass("blur");
                                    $("body").css("overflow-y", "auto");
                                },
                                content: {
                                    //sets window template
                                    template: kendo.template($("#newFormula").html())
                                }
                            }).data("kendoWindow");
            detailsTemplate = kendo.template($("#popup_editor_copy").html());


            wnd.content(detailsTemplate(dataItem));
            wnd.center().open();

            //EcolabSaturationMapping
            $("#txtEcolabSaturationCopy").attr('data-saturationId', dataItem.EcolabSaturationId);
            
            $("#ddlChainTextileCategoryCopy").change(function () {
                var selectedChainTextileId = $("#ddlChainTextileCategoryCopy").val().trim();
                getTextileSaturation(selectedChainTextileId, 'copy');
            });

            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            var validator = $(wnd.element).kendoValidator().data("kendoValidator");
            $("#btnUpdatecopy").unbind("click");
            $("#btnUpdatecopy").on("click", function (e) {
                if (validator.validate() == true) {
                    var popupContainer = $(this).closest('.formula_popup');
                    dataSource._data[0].Name = popupContainer.find("#txtcopyFormulaName").val().trim();
                    dataSource._data[0].TextileId = popupContainer.find("#ddlEcolabTextileCategory").val().trim();
                    dataSource._data[0].EcolabSaturationId = popupContainer.find("#txtEcolabSaturationCopy").attr('data-saturationId');
                    dataSource._data[0].EcolabSaturationName = popupContainer.find("#txtEcolabSaturationCopy").val().trim();
                    dataSource._data[0].PlantProgramId = popupContainer.find("#ddlChainFormula").val().trim();
                    dataSource._data[0].ProgramId = 0;
                    dataSource._data[0].ChainTextileId = popupContainer.find("#ddlChainTextileCategoryCopy").val().trim();
                    dataSource._data[0].Rewash = popupContainer.find('#cbRewashCopy').is(":checked");
                    dataSource._data[0].Pieces = popupContainer.find("#txtNumberofweightedPieces").val().trim();
                    dataSource._data[0].WeightDisplay = popupContainer.find("#txtWeight").val().trim();
                    dataSource._data[0].Weight = popupContainer.find("#txtWeight").val().trim();
                    dataSource._data[0].PieceWeight = popupContainer.find("#txtPieceWeight").val().trim();
                    dataSource._data[0].CustomerId = popupContainer.find("#ddlCustomer").val().trim();
                    dataSource.sync();
                    var grid = $("#gridFormula").data("kendoGrid");
                    grid.saveChanges();
                    grid.dataSource.read();

                    $.ajax({
                        type: "POST",
                        url: "/api/PlantFormula/CreateFormula",
                        data: JSON.stringify(dataSource._data[0].toJSON()),
                        contentType: "application/json; charset=utf-8",
                        dataType: "Json",
                        error: function (error) {
                            if (error.responseText == '51030') {
                                $('#errorMessageCopy').removeClass('hide').html('<span>' + $.GetLocaleKeyValue("FIELD_RECORDCOUNTDOESNTMATCH", "Formula count does not match.Resynch is in progress.") + '</span>');
                            }
                            else if (error.responseText == '60000') {
                                $('#errorMessageCopy').removeClass('hide').html('<span>' + $.GetLocaleKeyValue("FIELD_RECORDSNOTINSYNCH", "Record not in synch..Resynch is in progress.") + '</span>');
                            }
                            else if (error.responseText == '51031' || error.responseText == '303') {
                                $('#errorMessageCopy').removeClass('hide').html('<span>' + $.GetLocaleKeyValue("FIELD_FORMULAALREADYEXIST", "Formula already exist.") + '</span>');
                            }
                            else {
                                $('#errorMessageCopy').removeClass('hide').html('<span>' + $.GetLocaleKeyValue('FIELD_FORMULANAMEALREADYEXISTS', 'Formula name already exists.') + '</span>');
                            }
                        },
                        success: function () {
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                            $("#errorDiv").empty().removeClass().addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_FORMULAADDEDSUCCESSFULLYFROMCOPY", 'Formula added successfully from copy'));
                            wnd.close();
                        }
                    });
                }
                else {
                    return false;
                }

            });

            $("#btnCancel").on("click", function (e) {
                wnd.close();
                var dataSource = $("#gridFormula").data("kendoGrid").dataSource;
                var grid = $("#gridFormula").data("kendoGrid");
                grid.dataSource._destroyed = [];
                grid.dataSource.read();
            });

            //this.dataSource.cancelChanges();
        }

        var formulasData;
        $.ajax({
            type: "GET",
            url: "/api/PlantFormula/GetCategories",
            contentType: "application/json; charset=utf-8",
            dataType: "Json",
            error: function () {
            },
            success: function (data) {
                formulasData = data.Data;

            }
        });

        function categoryDropDownEditor(container, options) {
            $('<input required data-text-field="CategoryName" data-value-field="TextileId" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: formulasData.TextileCategory,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("CategoryName", dataItem.CategoryName);
                 options.model.set("TextileId", dataItem.TextileId);
             }
         });

        }

        function plantProgramDropDownEditor(container, options) {
            $('<input data-text-field="PlantProgramName" data-value-field="PlantProgramId" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: formulasData.ChainProgram,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("PlantProgramName", dataItem.PlantProgramName);
                 options.model.set("PlantProgramId", dataItem.PlantProgramId);
             }
         });

        }

        function chainTextileDropDownEditor(container, options) {
            $('<input data-text-field="Name" data-value-field="TextileId" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: formulasData.ChainTextileCategory,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("ChainTextileCategory", dataItem.Name);
                 options.model.set("ChainTextileId", dataItem.TextileId);
                 getTextileSaturation(dataItem.TextileId, 'inline');
            }
        });

        }

        function getTextileSaturation(textileId, type) {
            if (_this.options.eventHandlers.getTextileSaturation)
                _this.options.eventHandlers.getTextileSaturation(textileId, type);
        }
    },

    setTextileSaturation: function (data, type) {
        switch (type) {
            case 'inline':
                {
                    $("#saturationId").val(data[0].EcolabSaturationName);
                    break;
                }
            case 'add':
                {
                    $('#txtEcolabSaturationAdd').val(data[0].EcolabSaturationName);
                    $('#txtEcolabSaturationAdd').attr('data-saturationId', data[0].EcolabSaturationId);
                    break;
                }
            case 'copy':
                {
                    $('#txtEcolabSaturationCopy').val(data[0].EcolabSaturationName);
                    $('#txtEcolabSaturationCopy').attr('data-saturationId', data[0].EcolabSaturationId);
                    break;
                }
            case 'edit':
                {
                    $('#txtEcolabSaturationEdit').val(data[0].EcolabSaturationName);
                    $('#txtEcolabSaturationEdit').attr('data-saturationId', data[0].EcolabSaturationId);
                    break;
                }

        }
    }
};