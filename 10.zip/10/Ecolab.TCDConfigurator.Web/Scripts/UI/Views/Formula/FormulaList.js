﻿Ecolab.Views.FormulaList = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            onRedirection: function () { },
            rendered: function () { },
        },
        accountInfo: null
    };

    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'FormulaList',
        templateUri: './Scripts/UI/Views/Formula/FormulaList.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.FormulaList.prototype = {

    // sets the washer group data from presenter js.
    setData: function (data) {
        data.accountInfo = this.options.accountInfo;
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            _this.options.eventHandlers.rendered();

    },
    //Event is for attaching the events to be fired in this view.
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);


        container.find(".btnAddFormula").click(function () {
            $('#errorDiv').text('');
            _this.onAddFormulaClicked($(this).attr('formula-plantchainid'));
        });
        container.find(".updateFormula").click(function () {
            $('#errorDiv').text('');
            //_this.onEditFormulaClicked($(this).attr('formula-id'), $(this).attr('formula-plantchainid'), false, false);
            _this.onUpdateEditFormulaClicked($(this).attr('formula-id'), $(this).attr('formula-plantchainid'), false, false, _this.getFormulaEditableGridData());
        });
        container.find(".copyFormula").click(function () {
            $('#errorDiv').text('');
            _this.onEditFormulaClicked($(this).attr('formula-id'), $(this).attr('formula-plantchainid'), true, false);
        });
        container.find(".viewFormula").click(function () {
            $('#errorDiv').text('');
            _this.onEditFormulaClicked($(this).attr('formula-id'), $(this).attr('formula-plantchainid'), false, true);
        });
        container.find(".deleteFormula").click(function () {
            $('#errorDiv').text('');
            _this.onDeleteFormulaClicked($(this).attr('formula-id'), $(this).attr('formula-lastmodifiedtime'));
        });
        container.find("#btnSave").click(function () {
            $('#errorDiv').text('');
            if (_this.validate(_this.data.PlantChainId)) {
                _this.onInlineUpdateFormulaClicked(_this.getFormulaEditableGridData());
            }
        });
        $('select[id*="ddlChainFormulaName_"]').change(function () {
            var currChainFormula = this;
            var programId = $(currChainFormula).parents('tr').attr('data-programid');
            var arr = $.grep(_this.data.dropDownData.plantChainProgram, function (ele) { return ele.PlantProgramId == $(currChainFormula).val(); });
            if (arr.length == 1) {
                $(currChainFormula).parents('tr').attr('data-plantprogramid', arr[0].PlantProgramId);
                $(currChainFormula).parents('tr').find('#lblTextileSaturation').html(arr[0].EcolabSaturationName);
                $(currChainFormula).parents('tr').attr('data-saturationid', arr[0].EcolabSaturationId)
                $(currChainFormula).parents('tr').find('#txtFormulaName_' + programId).val(arr[0].PlantProgramName);
                if (arr[0].ChainTextileId > 0) {
                    $(currChainFormula).parents('tr').find('#lblFormulaCategory').html(arr[0].ChainTextileCategoryName);
                    $(currChainFormula).parents('tr').attr('data-formulacategory', arr[0].ChainTextileId);
                } else {
                    $(currChainFormula).parents('tr').find('#lblFormulaCategory').html(arr[0].EcolabCategoryName);
                    $(currChainFormula).parents('tr').attr('data-formulacategory', arr[0].EcolabTextileId);
                }
                $(currChainFormula).parents('tr').find('#lblFormulaSegment').html(arr[0].FormulaSegmentName);
                $(currChainFormula).parents('tr').attr('data-formulasegment', arr[0].FormulaSegmentId);
            }
        });
        container.find("#btnCancelGrid").click(function () {           
            _this.redirectToFormulaPage();

        });
    },
    onAddFormulaClicked: function (plantChainId) {
        if (this.options.eventHandlers.onAddFormulaClicked)
            this.options.eventHandlers.onAddFormulaClicked(plantChainId);
    },
    onEditFormulaClicked: function (programId, plantChainId,isCopy, isView) {
        if (this.options.eventHandlers.onEditFormulaClicked)
            this.options.eventHandlers.onEditFormulaClicked(programId, plantChainId, isCopy, isView);
    },
    onUpdateEditFormulaClicked: function (programId, plantChainId, isCopy, isView, formulaData) {
        if (this.options.eventHandlers.onUpdateEditFormulaClicked)
            this.options.eventHandlers.onUpdateEditFormulaClicked(programId, plantChainId, isCopy, isView, formulaData);
    },
    onDeleteFormulaClicked: function (programId, lastmodifiedtime) {
        if (this.options.eventHandlers.onDeleteFormulaClicked)
            this.options.eventHandlers.onDeleteFormulaClicked(programId, lastmodifiedtime);
    },
    validate: function (plantChainId) {
        if (plantChainId == "0") {            
            var v1 = $('#frmFormula').validate({
                rules: {
                    
                },
                messages: {
                    
                },
                errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.k-error-message"));

                    if (element.parent().hasClass("input-group")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                    if (element.hasClass("custom-select")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                }
            });
                $('[name*="ddlTextileSaturation_"]').each(function () {
                    $(this).rules('add', {
                        required: true,
                        messages: { // optional custom messages
                            required: "This field is required"
                        }
                    });
                });
                    $('[name*="ddlFormulaCategory_"]').each(function () {
                        $(this).rules('add', {
                            required: true,
                            messages: { // optional custom messages
                                required: "This field is required"
                            }
                        });
                    });
                    $('[name*="ddlFormulaSegment_"]').each(function () {
                        $(this).rules('add', {
                            required: true,
                            messages: { // optional custom messages
                                required: "This field is required"
                            }
                        });
                    });           
            
                    $('[name*="txtFormulaName_"]').each(function () {
                        $(this).rules('add', {
                            required: true,
                            messages: { // optional custom messages
                                required: "This field is required"
                            }
                        });
                    });

        } else {
            var v1 = $('#frmFormula').validate({
                rules: {
                    txtPlantformulaName: { required: true },
                    ddlChainFormulaName: { required: true }

                },
                messages: {
                    txtPlantformulaName: {
                        required: $.GetLocaleKeyValue('FIELD_FORMULANAMEREQUIRED', 'Formula name required.')
                    },
                    ddlChainFormulaName: {
                        required: $.GetLocaleKeyValue('FIELD_CHAINFORMULANAMEREQUIRED', 'Chain Formula name required.')
                    }
                },
                errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.k-error-message"));

                    if (element.parent().hasClass("input-group")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                    if (element.hasClass("custom-select")) {
                        error.appendTo(element.parent().parent().find("span.k-error-message"));
                    }
                }
            });
            $('[name*="txtFormulaName_"]').each(function () {
                $(this).rules('add', {
                    required: true,
                    messages: { // optional custom messages
                        required: "This field is required"
                    }
                });
            });
            $('[name*="ddlChainFormulaName_"]').each(function () {
                $(this).rules('add', {
                    required: true,
                    messages: { // optional custom messages
                        required: "This field is required"
                    }
                });
            });
        }        

        var v2 = $('#frmFormula').valid();
        return v2;
    },
    getFormulaEditableGridData: function () {
        var formulaList = [];
        _this = this;
        $("#tblFormula tbody tr").each(function () {
            formulaList.push(_this.getUpdatedFormulaData(this));
        });
        return formulaList;
    },
    getUpdatedFormulaData: function (element) {
        _this = this;
        var tr = element; //$(element).parents('.trEditable').first();
        var plantChainId = $(tr).attr("data-plantchainid");
        var index = $(tr).attr("data-programid");
        var formula = {};
        formula.ProgramId = index;
        formula.PlantChainId = plantChainId;
        formula.Name = $(tr).find("#txtFormulaName_" + index).val();
        formula.Rewash = $(tr).find("#txtRewash_" + index).is(":checked");
        formula.LastModifiedTimeStamp = $(tr).attr("data-lastmodifiedtime");
        formula.Pieces = $(tr).attr("data-pieces");
        formula.WeightDisplay = $(tr).attr("data-weightdisplay");
        formula.CustomerId = $(tr).attr("data-customerId");
        if (plantChainId > 0) {
            formula.PlantProgramId = $(tr).attr("data-plantprogramid");
            formula.FormulaCategory = $(tr).attr("data-formulacategory");
            formula.EcolabSaturationId = $(tr).attr("data-saturationid");
            formula.FormulaSegmentId = $(tr).attr("data-formulasegment");
        } else {
            formula.PlantProgramId = $(tr).attr("data-plantprogramid");
            formula.FormulaCategory = $(tr).find("#ddlFormulaCategory_" + index).val();
            formula.EcolabSaturationId = $(tr).find("#ddlTextileSaturation_" + index).val();
            formula.FormulaSegmentId = $(tr).find("#ddlFormulaSegment_" + index).val();
        }
        
        return formula;
    },
    onInlineUpdateFormulaClicked: function (data) {
        if (this.options.eventHandlers.onInlineUpdateFormulaClicked)
            this.options.eventHandlers.onInlineUpdateFormulaClicked(data);
    },
    redirectToFormulaPage: function () {
        var retVal = this.options.eventHandlers.onRedirection('./Formula');
        return retVal;
    },
}