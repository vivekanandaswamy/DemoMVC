﻿Ecolab.Views.Meter = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onUtilityTypeChange: null,
            onUtilityLocationChange: null,
            onAddNewMeterPopupLoad: null,
            onMeterEditPopupLoad: null,
            loadOnMachineCompartmentChange: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;
    this.meterPopUpData = null;
    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Meter/Meter.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.initValidator();
    this.meterData = null;
    this.isEdit = null;
    this.allowEdit = false;
    this.controllerCount = 0;
    this.validatetor;
    this.IsMeterDelete = false;
};

var isNotEditableAfterDelete = false;

Ecolab.Views.Meter.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        $('.grid-add-new-record').removeClass('k-button k-button-icontext');
        $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
        $('.grid-add-new-record').insertBefore("#errorDiv");
        $(".k-grid-pager").find("a, ul").hide();
    },
    setMeterData: function (data) {
        this.meterData = data;
    },
    setMeterOnAddNewPopupLoadData: function (data) {
        this.meterPopUpData = data;
        var ddlUtilityType = $('#ddlUtilityTypeAdd');
        ddlUtilityType.empty();
        ddlUtilityType.append('<option value="">-- Select --</option>');
        if (data.UtilityType.length > 0) {
            $.each(data.UtilityType, function () {
                ddlUtilityType.append('<option value="' + this.ResourceId + '" data-localize="FIELD_' + this.Name.toUpperCase() + '">' + this.Name + '</option>');
            });
        }

        var ddlUtilityLocationAdd = $('#ddlUtilityLocationAdd');
        ddlUtilityLocationAdd.empty();
        ddlUtilityLocationAdd.append('<option value="">-- Select --</option>');
        if (data.UtilityLocation.length > 0) {
            $.each(data.UtilityLocation, function () {
                ddlUtilityLocationAdd.append('<option value="' + this.GroupTypeId + '" data-type="' + this.GroupMainType + '" data-istunnel="' + this.IsTunnel + '" >' + this.GroupDescription + '</option>');
            });
        }

        var ddlControllerAdd = $('#ddlControllerAdd');
        ddlControllerAdd.empty();
        ddlControllerAdd.append('<option value="">-- Select --</option>');
        if (data.Controller.length > 0) {
            $.each(data.Controller, function () {
                ddlControllerAdd.append('<option value="' + this.ControllerId + '" data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '" data-isWaterEnergyLogSel="' + this.ISWaterEnergyLogSel + '">' + this.Name + '</option>');
            });
        }
        var ddlWaterTypeAdd = $('#ddlWaterTypeAdd');
        ddlWaterTypeAdd.empty();
        ddlWaterTypeAdd.append('<option value="">-- Select --</option>');
        if (data.WaterType.length > 0) {
            $.each(data.WaterType, function () {
                if (ddlWaterTypeAdd.find('option[value=' + this.WaterTypeId + ']').length == 0)
                    ddlWaterTypeAdd.append('<option value="' + this.WaterTypeId + '">' + this.WaterTypeName + '</option>');
            });
        }
        this.data.WaterType = data.WaterType;
        var ddlCounterAdd = $('#ddlCounterAdd');
        ddlCounterAdd.empty();
        ddlCounterAdd.append('<option value="">-- Select --</option>');

        var ddlDigitalInputAdd = $('#ddlDigitalInputAdd');
        ddlDigitalInputAdd.empty();
        ddlDigitalInputAdd.append('<option value="">-- Select --</option>');
        for (var i = 1; i <= 32; i++) {
            ddlDigitalInputAdd.append('<option value="' + i + '">Digital Counter ' + i + '</option>');
        }
        $('.digitalInputFields').find('input').prop('disabled', true);
        $('.digitalInputFields').find('select').prop('disabled', true);
        $('#ddlAllowManualEntry').attr("checked", false);
    },
    SetMeterOnEditPopupLoad: function (data) {
        var _this = this
        this.meterPopUpData = data;
        var ddlUtilityType = $('#ddlUtilityType');
        ddlUtilityType.empty();
        ddlUtilityType.append('<option value="">-- Select --</option>');
        if (data.UtilityType.length > 0) {
            $.each(data.UtilityType, function () {
                ddlUtilityType.append('<option value="' + this.ResourceId + '"  data-localize="FIELD_' + this.Name.toUpperCase() + '">' + this.Name + '</option>');
            });
            ddlUtilityType.val(data.Meter.MeterType);
            if ((data.Meter.MeterType) == 1) {
                $('.ufactor').show();
                $('#txtUsageFactor').prop("required", true);
            } else {
                $('#txtUsageFactor').removeAttr("required");
                $('.ufactor').hide();
            }
        }

        if (data.Meter.MeterType == 2) {
            $('.waterTypeFields').show();
        }
        else {
            $('.waterTypeFields').hide();
            $('#ddlWaterType').prop('required', false);
        }

        var ddlUtilityLocation = $('#ddlUtilityLocation');
        ddlUtilityLocation.empty();
        ddlUtilityLocation.append('<option value="">-- Select --</option>');
        if (data.UtilityLocation.length > 0) {
            $.each(data.UtilityLocation, function () {
                ddlUtilityLocation.append('<option value="' + this.GroupTypeId + '"data-type="' + this.GroupMainType + '" data-istunnel="' + this.IsTunnel + '">' + this.GroupDescription + '</option>');
            });
            ddlUtilityLocation.val(data.Meter.UtilityId);
            var lblMachineCompartment = $('#lblMachineCompartment');
            var ddlLocation = $("#ddlUtilityLocation option:selected");
            if (ddlLocation.data('type') == "WasherGroup" && ddlLocation.data('istunnel') == true) {
                lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_COMPARTMENT', 'Compartment'));
                lblMachineCompartment.removeAttr('data-localize');
            } else {
                lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_MACHINE', 'Machine'));
                lblMachineCompartment.removeAttr('data-localize');
            }
        }
        var ddlMachineCompartment = $('#ddlMachineCompartment');
        ddlMachineCompartment.empty();
        ddlMachineCompartment.append('<option value="">-- Select --</option>');
        var groupType = $('#ddlUtilityLocation').find('option:selected').attr('data-type');
        var isTunnel = $('#ddlUtilityLocation').find('option:selected').attr('data-istunnel');
        if (data.MachineCompartment.length > 0) {
            $.each(data.MachineCompartment, function () {
                if (groupType == 2 && isTunnel == 'false' && this.MachineID != 0)
                    ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.PlantWasherNumber + ':' + this.MachineName + '</option>');
                else
                    ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
            });
            ddlMachineCompartment.val(data.Meter.MachineId);
        }

        var ddlParent = $('#ddlParent');
        ddlParent.empty();
        ddlParent.append('<option value="">-- Select --</option>');
        if (data.Parent.length > 0) {
            $.each(data.Parent, function () {
                ddlParent.append('<option value="' + this.MeterId + '">' + this.Description + '</option>');
            });
            if (ddlParent.find('option[value=' + data.Meter.ParentId + ']').length > 0) {
                ddlParent.val(data.Meter.ParentId);
            }
        }

        var ddlUom = $('#ddlUOM');
        ddlUom.empty();
        ddlUom.append('<option value="">-- Select --</option>');
        if (data.UOM.length > 0) {
            $.each(data.UOM, function () {
                ddlUom.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
            });
            if (ddlUom.find('option[value=' + data.Meter.MeterTickUnit + ']').length > 0) {
                ddlUom.val(data.Meter.MeterTickUnit);
            }
            ddlUom.prop("required", true);
        } else {
            ddlUom.removeAttr('required');
        }

        var ddlControllerAdd = $('#ddlController');
        ddlControllerAdd.empty();
        ddlControllerAdd.append('<option value="">-- Select --</option>');
        if (data.Controller.length > 0) {
            $.each(data.Controller, function () {
                ddlControllerAdd.append('<option value="' + this.ControllerId + '" data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '" data-isWaterEnergyLogSel="' + this.ISWaterEnergyLogSel + '">' + this.Name + '</option>');
            });
            ddlControllerAdd.find('option[value=' + data.Meter.ControllerId + ']').attr("selected", "selected");
        }

        if (data.Meter.ControllerName != null) {
            if (data.Meter.ControllerRegionId == 1 || data.Meter.ControllerModelId == 5) {
                $('.DigitalInputNumber').show();
                //$('#txtDigitalInputNumber').prop("required", true);
            } else {
                //$('#txtDigitalInputNumber').removeAttr("required");
                $('.DigitalInputNumber').hide();
            }
        }

        var ddlWaterTypeAdd = $('#ddlWaterType');
        ddlWaterTypeAdd.empty();
        ddlWaterTypeAdd.append('<option value="">-- Select --</option>');
        if (data.WaterType.length > 0) {
            $.each(data.WaterType, function () {
                if (ddlWaterTypeAdd.find('option[value=' + this.WaterTypeId + ']').length == 0)
                    ddlWaterTypeAdd.append('<option value="' + this.WaterTypeId + '">' + this.WaterTypeName + '</option>');
            });
        }
        if ($('#ddlWaterTypeView') != []) {
            var waterTypes = $.grep(data.WaterType, function (obj) { return obj.WaterTypeId == $('#ddlWaterTypeView').find('option:first').val(); });
            var waterTypeName = waterTypes.length > 0 ? waterTypes[0].WaterTypeName : "";
            $('#ddlWaterTypeView').find('option:first').text(waterTypeName);
        }

        var ddlCounterAdd = $('#ddlCounter');
        ddlCounterAdd.empty();
        ddlCounterAdd.append('<option value="">-- Select --</option>');

        this.disableDigitalInputFields(true);

        var ddlDigitalInputAdd = $('#ddlDigitalInput');
        ddlDigitalInputAdd.empty();
        ddlDigitalInputAdd.append('<option value="">-- Select --</option>');
        for (var i = 1; i <= 32; i++) {
            ddlDigitalInputAdd.append('<option value="' + i + '">Digital Counter ' + i + '</option>');
        }

        if (data.Meter.ISWaterEnergyLogSel && data.Meter.CounterNum == 0) {
            if (data.Meter.ExternalCounter != 0)
                $('#ddlDigitalInput').val(data.Meter.ExternalCounter);
            $("#ddlCounter").prop('disabled', true);
            $('.digitalInputFields').find('input').prop('disabled', false);
            $('.digitalInputFields').find('select').prop('disabled', false);
        }
        else {
            if (data.Meter.CounterNum != 0)
                $("#ddlCounter").val(data.Meter.CounterNum);
            $('.digitalInputFields').find('input').prop('disabled', true);
            $('.digitalInputFields').find('select').prop('disabled', true);
        }
        if (data.Counters.InternalCounters != '' && data.Counters.InternalCounters != null) {
            var usedInternalCountersArr = data.Counters.InternalCounters.split(',');
            $(usedInternalCountersArr).each(function (index, value) {
                if ($("#ddlCounter").find('option[value=' + value + ']').length > 0 && data.Meter.CounterNum != value)
                    $("#ddlCounter").find('option[value=' + value + ']').remove();
            });
        }
        if (data.Counters.ExternalCounters != '' && data.Counters.ExternalCounters != null) {
            var usedExternalCountersArr = data.Counters.ExternalCounters.split(',');
            $(usedExternalCountersArr).each(function (index, value) {
                if ($('#ddlDigitalInput').find('option[value=' + value + ']').length > 0 && data.Meter.ExternalCounter != value)
                    $('#ddlDigitalInput').find('option[value=' + value + ']').remove();
            });
        }
        $('#ddlAllowManualEntry').attr("checked", data.Meter.AllowManualEntry);
        $('#chkCounterUsage').prop('checked', data.Meter.CounterUsage);
        $('#chkRunTimeUsage').prop('checked', data.Meter.RunningTimeUsage);
        $('#txtCounterAlarmValue').prop('disabled', !data.Meter.CounterUsage);
        $('#txtCounterAlarmValue').val(data.Meter.CounterAlarmValue);
        $('#txtRuntimeAlarmValue').prop('disabled', !data.Meter.RunningTimeUsage);
        $('#txtRuntimeAlarmValue').val(data.Meter.RunningTimeAlarmValue);
        $('#chkWaterTypeFromFormula').prop('checked', data.Meter.WaterTypeFromFormulaSetup);
        if (data.Meter.WaterTypeFromFormulaSetup && data.Meter.MeterType == '2') {
            $('#spnWaterType').hide();
            $('#ddlWaterType').prop('required', false);
            $('#ddlWaterType').prop('disabled', true);
        }
        else if (data.Meter.MeterType == '2') {
            $('#spnWaterType').show();
            $('#ddlWaterType').prop('required', true);
            $('#ddlWaterType').prop('disabled', false);
        }
        $('#ddlWaterType').val(data.Meter.WaterType);
        $('#hdnIsWaterEnergyLogSel').val('true');
        if (_this.data.RegionId == 2) {
            $('.nonEUFields').hide();
            $('#txtMaxValueLimit').prop('required', false);
        }
        else {
            $('.nonEUFields').show();
        }
    },


    //Setting cascading data for Machine/compartment basing on Utility Location
    SetOnUtilityLocationChangedData: function (data) {
        var _this = this;
        var ddlMachineCompartment;
        var isTunnel;
        if (_this.isEdit == true) {
            ddlMachineCompartment = $('#ddlMachineCompartment');
            ddlMachineCompartment.empty();
            ddlMachineCompartment.append('<option value="">-- Select --</option>');
            var groupType = $('#ddlUtilityLocation').find('option:selected').attr('data-type');
            isTunnel = $('#ddlUtilityLocation').find('option:selected').attr('data-istunnel');
            if (data.MachineCompartment.length > 0) {
                $.each(data.MachineCompartment, function () {
                    if (groupType == 2 && isTunnel == 'false' && this.MachineID != 0)
                        ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.PlantWasherNumber + ':' + this.MachineName + '</option>');
                    else
                        ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
                });
            }
        } else if (_this.isEdit == false) {
            ddlMachineCompartment = $('#ddlMachineCompartmentAdd');
            ddlMachineCompartment.empty();
            ddlMachineCompartment.append('<option value="">-- Select --</option>');
            var groupType = $('#ddlUtilityLocationAdd').find('option:selected').attr('data-type');
            isTunnel = $('#ddlUtilityLocationAdd').find('option:selected').attr('data-istunnel');
            if (data.MachineCompartment.length > 0) {
                $.each(data.MachineCompartment, function () {
                    if (groupType == 2 && isTunnel == 'false' && this.MachineID != 0)
                        ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.PlantWasherNumber + ':' + this.MachineName + '</option>');
                    else
                        ddlMachineCompartment.append('<option value="' + this.MachineID + '" data-controllerid = "' + this.ControllerId + '">' + this.MachineName + '</option>');
                });
            }
        }
        _this.disableDigitalInputFields(_this.isEdit);
        if (_this.isEdit == false) {
            var ddlControllerAdd = $('#ddlControllerAdd');
            ddlControllerAdd.empty();
            ddlControllerAdd.append('<option value="">-- Select --</option>');
            if (data.Controller.length > 0)
                $.each(data.Controller, function () {
                    ddlControllerAdd.append('<option value="' + this.ControllerId + '" data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '" data-isWaterEnergyLogSel="' + this.ISWaterEnergyLogSel + '">' + this.Name + '</option>');
                });
        }
    },

    SetUOMData: function (data) {
        var _this = this;

        if (_this.isEdit == true) {
            var ddlParent = $('#ddlParent');
            ddlParent.empty();
            ddlParent.append('<option value="">-- Select --</option>');
            if (data.Parent.length > 0) {
                $.each(data.Parent, function () {
                    ddlParent.append('<option value="' + this.MeterId + '">' + this.Description + '</option>');
                });
            }

            var ddlUom = $('#ddlUOM');
            ddlUom.empty();
            ddlUom.append('<option value="">-- Select --</option>');
            if (data.UOM.length > 0) {
                $.each(data.UOM, function () {
                    ddlUom.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
                });
                ddlUom.prop("required", true);
            } else {
                ddlUom.removeAttr('required');
            }
        } else if (_this.isEdit == false) {
            var ddlParentAdd = $('#ddlParentAdd');
            ddlParentAdd.empty();
            ddlParentAdd.append('<option value="">-- Select --</option>');
            if (data.Parent.length > 0) {
                $.each(data.Parent, function () {
                    ddlParentAdd.append('<option value="' + this.MeterId + '">' + this.Description + '</option>');
                });
            }

            var ddlUomAdd = $('#ddlUOMAdd');
            ddlUomAdd.empty();
            ddlUomAdd.append('<option value="">-- Select --</option>');
            if (data.UOM.length > 0) {
                $.each(data.UOM, function () {
                    ddlUomAdd.append('<option value="' + this.SubUnit + '">' + $.GetLocaleKeyValue(this.SubUnit, this.SubUnit) + '</option>');
                });
                ddlUomAdd.prop("required", true);
            } else {
                ddlUomAdd.removeAttr('required');
            }
        }
    },

    onMachineCompartmentChangeLoaded: function (data) {
        var _this = this;
        var utilLocation;
        var machineId;
        if (_this.isEdit == true) {
            utilLocation = $('#ddlUtilityLocation');
            var ddlMachineCompartment = $('#ddlMachineCompartment');
            machineId = ddlMachineCompartment.val();
            var ddlController = $('#ddlController');
            ddlController.empty();
            ddlController.append('<option value="">-- Select --</option>');
            if (data.length > 0)
                $.each(data, function () {
                    ddlController.append('<option value="' + this.ControllerId + '" data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '" data-isWaterEnergyLogSel="' + this.ISWaterEnergyLogSel + '">' + this.Name + '</option>');
                });
            var selectedValue = ddlMachineCompartment.find('option:selected').attr('data-controllerid');
            if (ddlController.find('option[value=' + selectedValue + ']').length > 0) {
                ddlController.val(selectedValue);
                if (ddlController.val() != '' && ddlController.val() != null) {
                    ddlController.trigger('change');
                }
            }
        }
        else {
            utilLocation = $('#ddlUtilityLocationAdd');
            var ddlMachineCompartmentAdd = $('#ddlMachineCompartmentAdd');
            machineId = ddlMachineCompartmentAdd.val();
            var ddlControllerAdd = $('#ddlControllerAdd');
            ddlControllerAdd.empty();
            ddlControllerAdd.append('<option value="">-- Select --</option>');
            if (data.length > 0)
                $.each(data, function () {
                    ddlControllerAdd.append('<option value="' + this.ControllerId + '" data-typeid = "' + this.ControllerModelId + '" data-type = "' + this.ControllerType + '" data-regionid = "' + this.RegionId + '" data-isWaterEnergyLogSel = "' + this.ISWaterEnergyLogSel + '">' + this.Name + '</option>');
                });
            var selectedValue = ddlMachineCompartmentAdd.find('option:selected').attr('data-controllerid');
            if (ddlControllerAdd.find('option[value=' + selectedValue + ']').length > 0) {
                ddlControllerAdd.val(selectedValue);
                if (ddlControllerAdd.val() != '' && ddlControllerAdd.val() != null) {
                    ddlControllerAdd.trigger('change');
                }
            }
        }
        if (_this.options.eventHandlers.fetchExternalAndInternalCounters)
            _this.options.eventHandlers.fetchExternalAndInternalCounters(utilLocation.val(), machineId);
    },

    initValidator: function () {
        $.validator.addMethod(
            "regex",
            function (value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Please check your input."
        );
    },
    validate: function () {
        var pattern1 = /^[0-9]*$/;
        var v1 = $('#frmMeter').validate({
            rules: {
                txtDescription:
                    {
                        required: true
                    },
                txtCalibration_: {
                        required: true
                    },
            },

            messages: {
                txtDescription: {
                    required: $.GetLocaleKeyValue('FIELD_METERNAMEREQUIRED', 'Meter name is required.')
                },
                txtCalibration_: {
                    required: $.GetLocaleKeyValue('FIELD_KFACTORREQUIRED', 'K-Factor is required.')
                },
                
                onsubmit: true,
                onkeyup: false,
                focusInvalid: false,
                errorPlacement: function (error, element) {
                    error.appendTo(element.parent().find("span.errorMsg"));
                }
            }
        });

        $('[name*="txtDescription_"]').each(function () {
            $(this).rules('add', {
                required: true,
                messages: { // optional custom messages
                    required: "This field is required"
                }
            });
        });

        $('[name*="txtCalibration_"]').each(function () {
            $(this).rules('add', {
                    required: true,
                    messages: { // optional custom messages
                        required: "This field is required"
                    }
            });
        });

        
        var v2 = $('#frmMeter').valid();
        return v2;
    },
    savePage: function () {
        _this = this;
        if (_this.validatetor.validate()) { 
            grid = $("#gridMeter").data("kendoGrid");
            grid.saveChanges();
        }
    },
    setIsDirty: function (flag) {
        if (this.options.eventHandlers.setIsDirty)
            this.options.eventHandlers.setIsDirty(flag);
    },
    onCancelClick: function () {
        if (this.options.eventHandlers.onRedirection)
            this.options.eventHandlers.onRedirection("/Meter");
    },
    onDelete: function (e, data, wnd, detailsTemplate, _this) {
        if (_this.IsMeterDelete == false) {
            _this.IsMeterDelete = true;
            var detailsTemplate = kendo.template($("#editMeter").html());
            var detailsTemplateView = kendo.template($("#editMeterView").html());
            var data = this;
            var noEdits = _this.options.eventHandlers.onSaveChangesForMeters(data, e, wnd, detailsTemplate, detailsTemplateView, _this, dataSource, false);
        }
        else if (_this.IsMeterDelete == true) {
            _this.IsMeterDelete = false;
            $("body").append('<div class="overlay_bg"></div>');
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-animation-container").hide();
            $("#deleteDetails").parent(".k-window").addClass('deletepopup');
            $("#errorDiv").html('');
            e.preventDefault();
            $("body").css("overflow-y", "hidden");
            var tr = $(e.target).closest("tr");
            var grid = $("#gridMeter").data("kendoGrid");
            var data = grid.dataItem($(e.target).closest("tr"));
            var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
                title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
                visible: false,
                width: "298px",
                height: "auto",
                animation: false,
                draggable: false,
                resizable: false,
            }).data("kendoWindow");
            var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
            deletePopupTemplateWindow.content(deletePopupTemplate(data));
            deletePopupTemplateWindow.open().center();
            var grid = $("#gridMeter").data("kendoGrid");
            grid.refresh();
            $(document).on('keyup', function (e) {
                if (e.which == 27) {
                    $('#noButton').trigger('click');
                }
            });
            $("#yesButton").click(function () {
                isNotEditableAfterDelete = true;
                grid = $("#gridMeter").data("kendoGrid");
                grid.dataSource.remove(data);
                //grid.saveChanges();
                grid.dataSource.sync();
                grid.dataSource.read();
                deletePopupTemplateWindow.close();
                $(".overlay_bg").hide();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
                $("body").css("overflow-y", "auto");
                $("body").css("overflow-y", "auto");
            });
            $("#noButton").click(function () {
                deletePopupTemplateWindow.close();
                //removeOverlay();
                $(".overlay_bg").hide();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
                $("body").css("overflow-y", "auto");
            });
        }
    },
    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    attachEvents: function () {

        $("#tabUtilitiesContainer").addClass("active");
        $("#tabUtilities").parent("li").addClass("active");

        $("#frmMeter").kendoValidator();
        var _this = this;
        var wnd, detailsTemplate, detailsTemplateView;
        var container = $(this.options.containerSelector);
        _this.controllerCount = this.data.ControllerCount;

        //Set allow edit on role level
        _this.allowEdit = (this.data.MaxLevel >= 8);
        if (!_this.allowEdit)
            $("#dvHideButtons").hide();

        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        if (_this.data != null)
            $('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');


        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Meter/GetMeter",
                    dataType: "json"
                },
                create: {
                    url: "/api/Meter/CreateMeter",
                    dataType: "json",
                    contentType: "application/json",
                    type: "POST",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_METERADDEDSUCCESSFULLY" class="k-success-message">Meter added successfully.</label>');
                            kendoWindow.close();
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        } else {
                            var code = JSON.parse(jqXhr.responseText).split('#')[0].split(",");
                            var errorMessageAdd = $('#errorMessageAdd');
                            var errorMessage = '';
                            if (parseInt(code[0]) == 101 || parseInt(code[0]) == 201 || parseInt(code[0]) == 301 || parseInt(code[0]) == 401 || parseInt(code[0]) == 302 || parseInt(code[0]) == 501
                               || parseInt(code[0]) == 601 || parseInt(code[0]) == 602 || parseInt(code[0]) == 603 || parseInt(code[0]) == 701 || parseInt(code[0]) == 51030 || parseInt(code[0]) == 60000 || parseInt(code[0]) == 51060) {
                                errorMessage = '';
                                for (a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (code[a] == 101) {
                                        errorMessage = '<span>Maximum 6 Water meters can be connected to the same Washter-Tunnel</span>';
                                    } else if (code[a] == 201) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMTWOWATERMETERSCANBECONNECTEDTOTHESAMEWASHER-CONVENTIONAL">Maximum two Water Meters can be connected to the same Washer-Conventional.</span>';
                                    } else if (code[a] == 301) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MAXIMUMONEMETERWITHTHESAMEUTILITYCANBECONNECTEDTOONEMACHINE/COMPARTEMENT">Maximum one Meter with the same utility can be connected to one Machine / Compartement.</span>';
                                    } else if (code[a] == 401) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONTROLLERCANNOTBEEMPTYWHENUTILITYLOCATIONISSELECTED">Dispenser can not be empty when Utility Location is selected.</span>';
                                    } else if (code[a] == 302) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_DuplicateMeter" class="k-error-message">Duplicate meter names are not allowed.</span>';
                                    } else if (code[a] == 501) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_MACHINE/COMPARTMENTCANNOTBEEMPTYWHENUTILITYLOCATIONISSELECTED">Machine / Compartment can not be empty when Utility Location is selected.</span>';
                                    } else if (parseInt(code[a]) == 601) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_UTILITYLOCATION&MACHINE/COMPARTMENTCANNOTBEEMPTYWHENCONTROLLERISNOTUTILITYLOGGER">Utility Location & Machine / Compartment can not be empty when Dispenser is not UtilityLogger.</span>';
                                    } else if (parseInt(code[a]) == 602) {

                                    } else if (parseInt(code[a]) == 603) {

                                    } else if (parseInt(code[a]) == 701) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONTROLLEROFTYPEUTILITYLOGGERISUNAVAILABLE">Dispenser of type UtilityLogger is unavailable.</span>';
                                    } else if (parseInt(code[a]) == 51030) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record Count not Match...Resynch is in progress.</span>';
                                    } else if (parseInt(code[a]) == 60000) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</span>';
                                    } else if (parseInt(code[a]) == 51060) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</span>';
                                    }
                                }
                                errorMessageAdd.show();
                                errorMessageAdd.html('');
                                errorMessageAdd.html(errorMessage);
                            } else if (parseInt(code[0]) == 801 || parseInt(code[0]) == 802 || parseInt(code[0]) == 803
                                || parseInt(code[0]) == 804 || parseInt(code[0]) == 805 || parseInt(code[0]) == 806
                                 || parseInt(code[0]) == 901 || parseInt(code[0]) == 902 || parseInt(code[0]) == 909 || parseInt(code[0]) == 51030 || parseInt(code[0]) == 60000 || parseInt(code[0]) == 51060) {
                                errorMessage = '<span data-localize ="FIELD_METERADDEDSUCCESSFULLY" class="k-success-message">Meter added successfully.</span>';
                                for (a = 0; a < code.length; a++) {
                                        if (errorMessage != '') {
                                            errorMessage = errorMessage + '<br>';
                                        }
                                        if (parseInt(code[a]) == 801) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_INVALIDMETERTAG">Invalid Meter Tag.</span>';
                                        } else if (parseInt(code[a]) == 802) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_METERTAGALREADYEXISTS">Meter Tag already exists.</span>';
                                        } else if (parseInt(code[a]) == 803) {

                                        } else if (parseInt(code[a]) == 804) {

                                        } else if (parseInt(code[a]) == 805) {

                                        } else if (parseInt(code[a]) == 806) {

                                        } else if (parseInt(code[0]) == 901) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_UNABLETOCONNECTTOPLC">Unable to connect to PLC.</span>';
                                        } else if (parseInt(code[0]) == 902) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_UNABLETOWRITEVALUESTOPLC">Unable to write values to PLC.</span>';
                                        } else if (parseInt(code[a]) == 909) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_INVALIDCONTROLLERCONFIGURATION">Invalid Dispenser configuration.</span>';
                                        } else if (parseInt(code[a]) == 51030) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH">Record count does not match..Resynch is in progress.</span>';
                                        } else if (parseInt(code[a]) == 60000) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_RECORDSNOTINSYNCH">Record not in synch..Resynch is in progress.</span>';
                                        } else if (parseInt(code[a]) == 51060) {
                                            errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</span>';
                                        }
                                        kendoWindow.close();
                                        $("#errorDiv").html(errorMessage);
                                        grid.dataSource._destroyed = [];
                                        grid.dataSource.read();
                                    }
                                if (grid) {
                                    grid.dataSource._destroyed = [];
                                    grid.dataSource.read();
                                }
                                //dataSource.cancelChanges();

                            } else {
                                var code = JSON.parse(jqXhr.responseText).split(",");
                                if (parseInt(code[0]) == 901 || parseInt(code[0]) == 902) {
                                    errorMessage = '<label data-localize ="FIELD_METERADDEDSUCCESSFULLY" class="k-success-message">Meter added successfully.</label>';
                                    if (parseInt(code[0]) == 901) {
                                        errorMessage = errorMessage + '<label data-localize ="FIELD_UNABLETOCONNECTTOPLC" class="k-error-message">Unable to connect to PLC.</label>';
                                    } else if (parseInt(code[0]) == 902) {
                                        errorMessage = errorMessage + '<label data-localize ="FIELD_UNABLETOWRITEVALUESTOPLC" class="k-error-message">Unable to write values to PLC.</label>';
                                    }
                                    $("#errorDiv").html(errorMessage);
                                    kendoWindow.close();
                                    grid.dataSource._destroyed = [];
                                    grid.dataSource.read();
                                }
                                else {
                                    $("#errorDiv").html('<label data-localize ="FIELD_METERADDITIONFAILED" class="k-error-message">Meter addition failed.</label>');
                                    dataSource.cancelChanges();
                                    kendoWindow.close();
                                }
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                update: {
                    //url: "/api/Meter/Put",
                    url: function () {
                        if (isNotEditableAfterDelete == false) {
                            return "/api/Meter/Put"
                        }
                    },
                    dataType: "json",
                    contentType: "application/json",
                    type: "PUT",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_METERUPDATEDSUCCESSFULLY" class="k-success-message">Meter updated successfully.</label>');
                            wnd.close();
                            if (kendoWindow) {
                                kendoWindow.close();
                            }
                            var grid = $("#gridMeter").data("kendoGrid");
                            if (grid) {
                                grid.dataSource._destroyed = [];
                                grid.dataSource.read();
                            }
                            $("#btnSave").attr("disabled", "disabled");
                            $("#btnCancel1").attr("disabled", "disabled");
                            _this.setIsDirty(false);
                        } else {
                            var code = JSON.parse(jqXhr.responseText).split(",");
                            var errorMessageAdd = $('#errorMessage');
                            var errorMessage = '';
                            if (parseInt(code[0]) == 101 || parseInt(code[0]) == 201 || parseInt(code[0]) == 301 || parseInt(code[0]) == 501 || parseInt(code[0]) == 401 || parseInt(code[0]) == 302
                              || parseInt(code[0]) == 601 || parseInt(code[0]) == 405 || parseInt(code[0]) == 701 || parseInt(code[0]) == 60000 || parseInt(code[0]) == 51030 || parseInt(code[0]) == 51060) {
                                errorMessage = '';
                                for (a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (code[a] == 101) {
                                        errorMessage = '<span class="k-error-message" data-localize ="FIELD_MAXIMUM6WATERMETERSCANBECONNECTEDTOTHESAMEWASHTER-TUNNEL">Maximum 6 Water Meters can be connected to the same Washter-Tunnel.</span>';
                                    } else if (code[a] == 201) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_MAXIMUMTWOWATERMETERSCANBECONNECTEDTOTHESAMEWASHER-CONVENTIONAL">Maximum two Water Meters can be connected to the same Washer-Conventional</span>';
                                    } else if (code[a] == 301) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_MAXIMUMONEMETERWITHTHESAMEUTILITYCANBECONNECTEDTOONEMACHINE/COMPARTEMENT">Maximum one Meter with the same utility can be connected to one Machine / Compartement.</span>';
                                    } else if (code[a] == 501) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_MACHINE/COMPARTMENTCANNOTBEEMPTYWHENUTILITYLOCATIONISSELECTED">Machine / Compartment can not be empty when Utility Location is selected.</span>';
                                    } else if (code[a] == 401) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_CONTROLLERCANNOTBEEMPTYWHENUTILITYLOCATIONISSELECTED">Dispenser can not be empty when Utility Location is selected.</span>';
                                    } else if (code[a] == 302) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_DuplicateMeter" class="k-error-message">Duplicate meter names are not allowed.</span>';
                                    } else if (parseInt(code[a]) == 601) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_UTILITYLOCATION&MACHINE/COMPARTMENTCANNOTBEEMPTYWHENCONTROLLERISNOTUTILITYLOGGER">Utility Location & Machine / Compartment can not be empty when Dispenser is not UtilityLogger.</span>';
                                    } else if (parseInt(code[a]) == 405) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_UNABLETOUPDATELOCATIONORMACHINEWHENMAPPEDTOREDFLAG">Unable to update Location / Machine when it is mapped to a Red Flag.</span>';
                                    } else if (parseInt(code[a]) == 701) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_CONTROLLEROFTYPEUTILITYLOGGERISUNAVAILABLE">Dispenser of type UtilityLogger is unavailable.</span>';
                                    } else if (parseInt(code[a]) == 60000) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_RECORDSNOTINSYNCH">Record not in synch..Resynch is in progress.</span>';
                                    } else if (parseInt(code[a]) == 51030) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH">Record count does not match..Resynch is in progress.</span>';
                                    } else if (parseInt(code[a]) == 51060) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_CONECTIVITYISSUE">Unable to save changes , Connectivity issue, Please try again later.</span>';
                                    }
                                }
                                $("#errorDiv").html(errorMessage);
                                errorMessageAdd.show();
                                errorMessageAdd.html('');
                                errorMessageAdd.html(errorMessage);
                            } else if (parseInt(code[0]) == 801 || parseInt(code[0]) == 802 || parseInt(code[0]) == 901 || parseInt(code[0]) == 902 || parseInt(code[0]) == 909 || parseInt(code[0]) == 60000 || parseInt(code[0]) == 51030 || parseInt(code[0]) == 51060) {
                                errorMessage = '<span data-localize ="FIELD_METERUPDATEDSUCCESSFULLY" class="k-success-message">Meter updated successfully.</span>';
                                for (a = 0; a < code.length; a++) {
                                    if (errorMessage != '') {
                                        errorMessage = errorMessage + '<br>';
                                    }
                                    if (parseInt(code[a]) == 801) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_INVALIDMETERTAG">Invalid Meter Tag.</span>';
                                    } else if (parseInt(code[a]) == 802) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_METERTAGALREADYEXISTS">Meter Tag already exists.</span>';
                                    } else if (parseInt(code[0]) == 901) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_UNABLETOCONNECTTOPLC">Unable to connect to PLC.</span>';
                                    } else if (parseInt(code[0]) == 902) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_UNABLETOWRITEVALUESTOPLC">Unable to write values to PLC.</span>';
                                    } else if (parseInt(code[a]) == 909) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_INVALIDCONTROLLERCONFIGURATION">Invalid Dispenser configuration.</span>';
                                    } else if (parseInt(code[a]) == 60000) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_RECORDSNOTINSYNCH">Record not in synch..Resynch is in progress.</span>';
                                    } else if (parseInt(code[a]) == 51030) {
                                        errorMessage = errorMessage + '<span class="k-error-message" data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH">Record count does not match..Resynch is in progress.</span>';
                                    } else if (parseInt(code[a]) == 51060) {
                                        errorMessage = errorMessage + '<span data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</span>';
                                    } 
                                    wnd.close();
                                    $("#errorDiv").html(errorMessage);
                                }
                                if (grid) {
                                    grid.dataSource._destroyed = [];
                                    grid.dataSource.read();
                                }
                                //dataSource.cancelChanges();
                            }
                            else {
                                var code = JSON.parse(jqXhr.responseText).split(",");

                                if (parseInt(code[a]) == 60000) {
                                    errorMessage = errorMessage + '<span data-localize ="FIELD_RECORDSNOTINSYNCH">Record not in synch..Resynch is in progress.</span>';
                                } else if (parseInt(code[a]) == 51030) {
                                    errorMessage = errorMessage + '<span data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH">Record count does not match..Resynch is in progress.</span>';
                                } else if (parseInt(code[a]) == 51060) {
                                    errorMessage = errorMessage + '<span data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</span>';
                                } else {
                                    $("#errorDiv").html('<label data-localize ="FIELD_METERUPDATIONFAILED" class="k-error-message">Meter updation failed.</label>');
                                }

                                $("#errorDiv").html(errorMessage);
                                wnd.close();
                                if (kendoWindow) {
                                    kendoWindow.close();
                                }
                                var grid = $("#gridMeter").data("kendoGrid");
                                if (grid) {
                                    grid.dataSource._destroyed = [];
                                    grid.dataSource.read();
                                }
                                _this.setIsDirty(false);
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                destroy: {
                    url: "/api/Meter/DeleteMeter",
                    dataType: "json",
                    contentType: "application/json",
                    type: "DELETE",
                    complete: function (jqXhr, textStatus) {
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_METERDELETEDSUCCESSFULLY" class="k-success-message">Meter deleted successfully.</label>');
                        } else {
                            dataSource.cancelChanges();
                            var code = JSON.parse(jqXhr.responseText);
                            if (code == '404') {
                                $("#errorDiv").html('<label data-localize ="FIELD_UNABLETODELETEPARENTMETERWHENCHILDMETEREXISTS" class="k-error-message">Unable to delete parent Meter when child Meter exists.</label>');
                            } else if (code == '405') {
                                $("#errorDiv").html('<label data-localize ="FIELD_UNABLETODELETEMETERWHENMAPPEDREDFLAGEXISTS" class="k-error-message">Unable to delete Meter when a Red Flag is mapped to Location / Machine.</label>');
                            } else if (code == '51030') {
                                $("#errorDiv").html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match..Resynch is in progress.</label>');
                            } else if (code == '60000') {
                                $("#errorDiv").html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            } else if (code == '51060') {
                                $("#errorDiv").html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            } else {
                                $("#errorDiv").html('<label data-localize ="FIELD_METERDELETIONFAILED" class="k-error-message">Meter deletion failed</label>');
                            }
                        }
                        _this.tm.Localize();
                    }
                },
                parameterMap: function (data, type) {                  
                    if (type == "update" || type == "create" || type == "destroy") {
                        return kendo.stringify(data.models);
                    } else {
                        return data;
                    }
                },
            },
            requestStart: function (e) {
                var gridMeter = $("#gridMeter");
                gridMeter.data("kendoGrid").hideColumn("ParentName");
                gridMeter.data("kendoGrid").hideColumn("UsageFactor");
                gridMeter.data("kendoGrid").hideColumn("ControllerName");
                gridMeter.data("kendoGrid").hideColumn("DigitalInputNumber");
                gridMeter.data("kendoGrid").hideColumn("AllowManualEntry");
                gridMeter.data("kendoGrid").hideColumn("MaxValueLimit");
                gridMeter.data("kendoGrid").hideColumn("MeterId");

            },
            pageSize: 50,
            batch: true,
            schema: {
                model: {
                    id: "MeterId",
                    fields: {
                        MeterId: { editable: false, type: "number" },
                        Description: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_NAME", 'Name') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        MeterTypeName: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UTILITY-TYPE", 'Utility-Type') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        UtilityLocation: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UTILITYLOCATION", 'Utility Location') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        MachinecompartmentName: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_MACHINECOMPARTMENT", 'Machine/Compartment') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        ParentName: { editable: false },
                        Calibration: { editable: true, defaultValue: 0, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_KFACTOR", 'K-Factor') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        MeterTickUnit: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UOM", 'UOM') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        UsageFactor: { editable: true, defaultValue: 1, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_UFACTOR", 'U-Factor') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        ControllerName: { editable: false, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_CONTROLLER", 'Dispenser') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        DigitalInputNumber: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_DIGITALINPUTNUMBER", 'Digital Input Number') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        AllowManualEntry: { editable: true, validation: { required: true, validationMessage: $.GetLocaleKeyValue("FIELD_ALLOWMANUALENTRY", 'Allow Manual Entry') + ' ' + $.GetLocaleKeyValue("FIELD_REQUIRED", 'required') } },
                        MaxValueLimit: {
                            editable: true,
                            defaultValue: 10000,
                            validation: {
                                required: true,
                                validationMessage: "Meter Rollover Point required",
                                maxLength: function (input) {
                                    var pattern;
                                    if (input.is("[name='MaxValueLimit']") && input.val() != "") {
                                        input.attr("validationmessage", "Only numeric values are accepted");
                                        pattern = new RegExp("^[0-9]+$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        } else {
                                            return false;
                                        }
                                    } else if (input.is("[name='Calibration']") || input.is("[name='UsageFactor']") && input.val() != "") {
                                        input.attr("validationmessage", "Should be a number with maximum 4 decimal places");
                                        pattern = new RegExp("^.[0-9]{0,11}(?:\.[0-9]{1,4})?$");
                                        if (pattern.test(input.val())) {
                                            return true;
                                        } else {
                                            return false;
                                        }
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        });

        //Set basing on roles Here
        var addNew, commands, editTitle, customWidth = "8%";
        if (_this.controllerCount > 0) {
            if (_this.allowEdit) {

                commands = [
                    //{ name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit },
                    { name: "Delete", text: " ", click: onDelete }, { name: "update", text: " ", click: showDetails }];
                addNew = [{ text: "<span data-localize='FIELD_ADDMETER'>Add Meter</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
                editTitle = $.GetLocaleKeyValue("FIELD_EDITMETER", 'Edit Meter');

            } else {
                commands = [{ name: "view", text: "", click: showDetails }];
                addNew = "";
                customWidth = "55px";
                editTitle = $.GetLocaleKeyValue("FIELD_EDITMETER", 'View Meter');
            }
        } else {
            addNew = '<div class="k-error-message no-addbtn">Please add a Dispenser before adding a meter.</div>';
        }
        grid = $("#gridMeter").data("kendoGrid");
        function onEdit(e) {
            clearStatusMessage();
            inlineEditSaveButton();
        }
        var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
        function createOverlay() {
            $("body").append('<div class="overlay_bg"></div>');
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-animation-container").hide();
            $("#deleteDetails").parent(".k-window").addClass('deletepopup');
        }
        function removeOverlay() {
            $(".overlay_bg").hide();
            $("#topnav, .leftmenu-container").removeClass("blur");
            $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
        }
        function onDelete(e) {
            if (_this.IsMeterDelete == false) {
                _this.IsMeterDelete = true;
                detailsTemplate = kendo.template($("#editMeter").html());
                detailsTemplateView = kendo.template($("#editMeterView").html());
                var data = this;
                var noEdits = _this.options.eventHandlers.onSaveChangesForMeters(data, e, wnd, detailsTemplate, detailsTemplateView, _this, dataSource, false);
            }
            else if (_this.IsMeterDelete == true) {
                _this.IsMeterDelete = false;
            createOverlay();
            clearStatusMessage();
            e.preventDefault();
            $("body").css("overflow-y", "hidden");
            var tr = $(e.target).closest("tr");
            grid = $("#gridMeter").data("kendoGrid");
                //var data = this.dataItem(tr);
                var data = grid.dataItem($(e.target).closest("tr"));
            deletePopupTemplateWindow.content(deletePopupTemplate(data));
            deletePopupTemplateWindow.open().center();
            grid = $("#gridMeter").data("kendoGrid");
            grid.refresh();
            $(document).on('keyup', function (e) {
                if (e.which == 27) {
                    $('#noButton').trigger('click');
                }
            });
            $("#yesButton").click(function () {
                grid = $("#gridMeter").data("kendoGrid");
                grid.dataSource.remove(data);
                grid.saveChanges();
                deletePopupTemplateWindow.close();
                removeOverlay();
                $("body").css("overflow-y", "auto");
            });
            $("#noButton").click(function () {
                deletePopupTemplateWindow.close();
                removeOverlay();
                $("body").css("overflow-y", "auto");
            });
        }
        }
        var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
            title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            visible: false,
            width: "298px",
            height: "auto",
            animation: false,
            draggable: false,
            resizable: false,
        }).data("kendoWindow");

        function onDataBound(arg) {
            $('.grid-add-new-record').removeClass('k-button k-button-icontext');
            $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            $('.k-button-icontext.k-grid-Delete').find('span').addClass('k-icon k-delete');
            _this.tm.Localize();
            updatePaging(this);
            var rows = this.tbody.children();
            var dataItems = this.dataSource.view();
            for (var i = 0; i < dataItems.length; i++) {
                kendo.bind(rows[i], dataItems[i]);               
            }
            _this.validatetor = $("#frmMeter").kendoValidator({
                errorTemplate: '<span class="pull-right"><label  class="error">K-Factor is not valid</label></span>'
            }).data("kendoValidator");

            $('.k-delete').click(onDelete);
            $('.k-grid-update').click(showDetails);
            $('.k-custom-view').click(showDetails)
        }

        function updatePaging(current) {
            current.pager.element.find("a, ul").hide();
            if (current.dataSource.totalPages() > 1) {
                current.pager.element.find("a, ul").show();
            }
            if (current.dataSource.view().length == 0) {
                var currentPage = current.dataSource.page();
                if (currentPage > 1) {
                    current.dataSource.page(currentPage - 1);
                    current.dataSource.sync();
                    current.dataSource.read();
                }
            }
        }

        if (container.find('#gridMeter').data().kendoGrid)
            container.find('#gridMeter').data().kendoGrid.destroy();
        container.find("#gridMeter").kendoGrid({
            dataSource: dataSource,
            pageable: true,
            createAt: "top",
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,
            columns: [
                {
                    //command: commands,
                    width: "8%", attributes: { "class": "align-center" }
                    , template: function (data) {
                        var tempDiv = $('<div></div>');
                        if (_this.allowEdit) {
                            if (data.MyServiceMeterGuid != "00000000-0000-0000-0000-000000000000") {
                                tempDiv.append('<a class="k-button k-button-icontext k-grid-view" href="#"><span class="k-icon k-custom-view"></span></a>');
                            }
                            else {
                                tempDiv.append('<a class="k-button k-button-icontext k-grid-Delete" href="#"><span class="k-icon k-delete"></span> </a><a class="k-button k-button-icontext k-primary k-grid-update" href="#"><span class="k-icon k-update"></span> </a></td>');
                            }
                        }
                        return tempDiv.html();
                    }
                },
                //{ command: commands, width: "8%", attributes: { "class": "align-center" } },
                { field: "MeterId", width: "10%", title: "<span data-localize='FIELD_METERID'>Meter Id</span>", format: "{0:0}", attributes: { "class": "align-center" }, headerAttributes: { "class": "align-center" } },
                {
                    field: "Description", width: "10%", title: "<span data-localize='FIELD_NAME'>Name</span>",
                    template: function (data) {

                        if (_this.allowEdit) {

                            if (data.MyServiceMeterGuid != "00000000-0000-0000-0000-000000000000") {

                                return '<input type="text" class="k-input k-textbox trackChange" style="width:99%" name="txtDescription_' + data.MeterId + '" id="txtDescription_' + data.MeterId + '" value="' + data.Description + '"  data-bind="value:Description" disabled>'

                            }
                            else {

                                return '<input type="text" class="k-input k-textbox trackChange" style="width:99%" name="txtDescription_' + data.MeterId + '" id="txtDescription_' + data.MeterId + '" value="' + data.Description + '"  data-bind="value:Description" >'
                            }
                        } else {
                            return data.Description;
                        }
                        
                    }
                },
                {
                    field: "MeterTypeName", width: "13%", title: "<span data-localize='FIELD_UTILITYTYPE'>Utility-Type</span>", template: function (data) {
                        var typeUpper = data.MeterTypeName ? data.MeterTypeName.toUpperCase() : '';
                        return '<span data-localize="FIELD_' + typeUpper + '">' + data.MeterTypeName + '</span>';
                    }
                },
                { field: "UtilityLocation", width: "14%", title: "<span data-localize='FIELD_UTILITYLOCATION'>Utility Location</span>" },
                { field: "MachinecompartmentName", width: "18%", title: "<span data-localize='FIELD_MACHINECOMPARTMENT'>Machine/Compartment</span>" },
                { field: "ParentName", width: "10%", hidden: true, title: "<span data-localize='FIELD_PARENT'>Parent</span>" },
                {
                    field: "Calibration", width: "10%", attributes: { "class": "align-right" }, headerAttributes: { "class": "align-right" }, title: "<span data-localize='FIELD_KFACTOR'>K-Factor</span>"
                    , template: function (data) {
                        if (_this.allowEdit) {
                            if (data.MyServiceMeterGuid != "00000000-0000-0000-0000-000000000000") {
                                return '<input type="text" class="k-input k-textbox trackChange" pattern="^.[0-9]{0,11}(?:.[0-9]{1,3})?$" style="width:99%" value="' + data.Calibration + '" name="txtCalibration_' + data.MeterId + '" id="txtCalibration_' + data.MeterId + '" data-bind="value:Calibration" disabled>'
                            }
                            else {
                            return '<input type="text" class="k-input k-textbox trackChange" pattern="^.[0-9]{0,11}(?:.[0-9]{1,3})?$" style="width:99%" value="' + data.Calibration + '" name="txtCalibration_' + data.MeterId + '" id="txtCalibration_' + data.MeterId + '" data-bind="value:Calibration">'
                            }
                        } else {
                            return data.CalibrationAsString;
                        }
                        
                    },
                },
                {
                    field: "MeterTickUnit",
                    width: "16%",
                    title: "<span data-localize='FIELD_UOM'>UOM</span>",
                    template: function (data) { return data.MeterTickUnit != null ? $.GetLocaleKeyValue(data.MeterTickUnit, data.MeterTickUnit) : ''; },
                    editor: function (container, options) { container.append($.GetLocaleKeyValue(options.model.MeterTickUnit, options.model.MeterTickUnit)); }
                },
                { field: "UsageFactor", width: "10%", hidden: true, title: "U-factor" + "<br />" + "(Compression factor)", headerAttributes: { "data-localize": "FIELD_UFACTORCOMPRESSIONFACTOR" } },
                { field: "ControllerName", width: "10%", hidden: true, title: "Dispenser", headerAttributes: { "data-localize": "FIELD_CONTROLLER" } },
                { field: "DigitalInputNumber", width: "10%", hidden: true, title: "Digital" + "<br />" + "Input Number", headerAttributes: { "data-localize": "FIELD_DIGITALINPUTNUMBER" } },
                { field: "AllowManualEntry", width: "10%", hidden: true, title: "Allow" + "<br />" + "Manual Entry", headerAttributes: { "data-localize": "FIELD_ALLOWMANUALENTRY" } },
                {
                    field: "MaxValueLimit", width: "10%", hidden: true, title: "Meter" + "<br />" + "Roll-over Point", headerAttributes: {
                        "data-localize": "FIELD_METERROLLOVERPOINT"
                        , template: function (data) { return data.MaxValueLimitAsString; },

                    }
                }
            ],
            editable: "inline",
            cancel: function (e) {
                var dataSource = $("#gridMeter").data("kendoGrid").dataSource;
                var grid = $("#gridMeter").data("kendoGrid");
                grid.dataSource.read();
            }
        });

        wnd = $("#details")
            .kendoWindow({
                title: editTitle,
                modal: true,
                resizable: false,
                visible: false,
                draggable: false,
                width: "550px",
                maxHeight: "550px",
                open: onOpen,
                close: function () {
                    $("#topnav, .leftmenu-container").removeClass("blur");
                    $("body").css("overflow-y", "auto");
                },
                activate: function (e) {
                    _this.tm.Localize();
                }
            }).data("kendoWindow");

        detailsTemplate = kendo.template($("#editMeter").html());
        detailsTemplateView = kendo.template($("#editMeterView").html());

        $('#btnSave').click(function () {
            if (_this.validate()) {
                _this.savePage();
            }
        });
        $("#btnCancel1").click(function () {
            _this.onCancelClick();
        });

            //Impliment Cascading population of dropdowns here
            function onOpen(e) {
            if ($('#txtMeterIdView').text() == []) {
                if (_this.options.eventHandlers.onMeterEditPopupLoad)
                    _this.options.eventHandlers.onMeterEditPopupLoad($('#txtMeterId').text());
            }
            else {
                if (_this.options.eventHandlers.onMeterEditPopupLoad)
                    _this.options.eventHandlers.onMeterEditPopupLoad($('#txtMeterIdView').text());
            }
                $("#topnav, .leftmenu-container").addClass("blur");
                $(".k-tooltip").parent(".k-animation-container").hide();
                $("body").css("overflow-y", "hidden");
                $('#ddlUtilityType').change(function () {
                    _this.isEdit = true;
                    if ($(this).val() != '') {
                        if (_this.options.eventHandlers.onUtilityTypeChange)
                        _this.options.eventHandlers.onUtilityTypeChange($(this).val(), $('#editMeterView').find('.uid').attr('id'));
                }

                if ($('#ddlUtilityType').val() == 1) {
                    $('.ufactor').show();
                    $('#txtUsageFactor').prop("required", true);
                } else {
                    $('#txtUsageFactor').removeAttr("required");
                    $('.ufactor').hide();
            }

                if ($('#ddlUtilityType').val() != 2) {
                    $('.waterTypeFields').hide();
                    $('#ddlWaterType').prop('required', false);
                }
                else {
                    $('.waterTypeFields').show();
                    $('#ddlWaterType').prop('required', true);
                }
            });
                //Cascading data for Machine/Compartment basing on Utility Location
                $('#ddlUtilityLocation').change(function () {
                    _this.isEdit = true;

                    $('#ddlMachineCompartment').html('<option value="">-- Select --</option>');

                    if ($(this).val() != '') {
                        var lblMachineCompartment = $('#lblMachineCompartment');
                        var ddlLocation = $("#ddlUtilityLocation option:selected");
                        if (ddlLocation.data('type') == "WasherGroup" && ddlLocation.data('istunnel') == true) {
                        lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_COMPARTMENT', 'Compartment'));
                        lblMachineCompartment.removeAttr('data-localize');
                        } else {
                        lblMachineCompartment.text($.GetLocaleKeyValue('FIELD_MACHINE', 'Machine'));
                        lblMachineCompartment.removeAttr('data-localize');
                    }
                    if (_this.options.eventHandlers.onUtilityLocationChange)
                        _this.options.eventHandlers.onUtilityLocationChange($(this).val());
            }
            });
            $("#ddlAllowManualEntry").change(function () {

                if ($("#ddlAllowManualEntry").is(":checked") == true) {
                    $('*[data-container-for="ddlController"]').find('span').remove();
                    if($('#ddlController').val() == "")
                        $('#txtDigitalInputNumber').prop("disabled", true);
                    else
                        $('#txtDigitalInputNumber').prop("disabled", false);
                }
                else {
                    $('#txtDigitalInputNumber').prop("disabled", false);
                }
            });
            $("#ddlController").on('change', function () {

                var dispenserValue = $("#ddlController").find("option:selected").text();
                if ((dispenserValue == "-- Select --") && ($("#ddlAllowManualEntry").is(":checked") == true)) {
                    $('*[data-container-for="ddlController"]').find('span').remove();
                    $('#txtDigitalInputNumber').prop("disabled", true);
                }
                else {
                    $('#txtDigitalInputNumber').prop("disabled", false);
                }
                if (this.value != '' && $(this).find('option:selected').attr('data-isWaterEnergyLogSel') == 'true') {
                    $('.digitalInputFields').find('input').prop('disabled', false);
                    $('.digitalInputFields').find('select').prop('disabled', false);
                    $('#txtCounterAlarmValue').prop('disabled', !$('#chkCounterUsage').prop('checked'));
                    $('#txtRuntimeAlarmValue').prop('disabled', !$('#chkRunTimeUsage').prop('checked'));
                }
                else {
                    $('.digitalInputFields').find('input').prop('disabled', true);
                    $('.digitalInputFields').find('select').prop('disabled', true);
                }
            });
            $('#chkCounterUsage').change(function () {
                if ($(this).prop('checked')) {
                    $('#txtCounterAlarmValue').prop('disabled', false);
                    $('#txtCounterAlarmValue').prop('required', false);
                }
                else {
                    $('#txtCounterAlarmValue').prop('disabled', true);
                    $('#txtCounterAlarmValue').prop('required', true);
                }
            });
            $('#chkRunTimeUsage').change(function () {
                if ($(this).prop('checked')) {
                    $('#txtRuntimeAlarmValue').prop('disabled', false);
                    $('#txtRuntimeAlarmValue').prop('required', false);
                }
                else {
                    $('#txtRuntimeAlarmValue').prop('disabled', true);
                    $('#txtRuntimeAlarmValue').prop('required', true);
                }
            });
            _this.digitalInputFieldsEvents(true);
        }

            var grid;

            function showDetails(e) {
            grid = $("#gridMeter").data("kendoGrid");
                clearStatusMessage();
            detailsTemplate = kendo.template($("#editMeter").html());
            detailsTemplateView = kendo.template($("#editMeterView").html());
            var data = this;
            var noEdits = _this.options.eventHandlers.onSaveChangesForMeters(data, e, wnd, detailsTemplate, detailsTemplateView, _this, dataSource, true);
            if (noEdits) {
                e.preventDefault();
                var dataItem = grid.dataItem($(this).parents('tr'));
                dataItem.MeterDataToLoadDropdown = _this.meterData;
                dataItem.maxRole = _this.data.MaxLevel;
                dataItem.IsCentral = _this.data.IsCentral;
                if (_this.allowEdit) {
                    if (dataItem.MyServiceMeterGuid == "00000000-0000-0000-0000-000000000000" || dataItem.MyServiceMeterGuid == "null") {
                    wnd.content(detailsTemplate(dataItem));
                } else {

                    if (dataItem.ControllerName == null) {
                        dataItem.ControllerName = 'None';
                }
                wnd.content(detailsTemplateView(dataItem));
            }
                }
                wnd.center().open();

                wnd.element.find(".editRowPopup").unbind("click");
                wnd.element.find(".editRowPopup").click(function () {
                    var dispenserValue = $("#ddlController").find("option:selected").text();
                    if ((dispenserValue == "-- Select --") && ($("#ddlAllowManualEntry").is(":checked") == true)) {
                        $('*[data-container-for="ddlController"]').find('span').remove();
                }
                var validator = $(wnd.element).kendoValidator().data("kendoValidator");
                var uid = eval($(".uid").text());

                if (validator.validate()) {
                    dataSource.fetch(function () {
                        var meter = dataSource.get(uid);
                        meter.set("MeterId", $("#txtMeterId").text());
                        meter.set("Description", $("#txtDescription").val());

                        meter.set("MeterType", $("#ddlUtilityType").val().trim());
                        meter.set("UtilityId", $("#ddlUtilityLocation").val().trim());
                        meter.set("MachineId", $("#ddlMachineCompartment").val().trim());
                        meter.set("Calibration", $("#txtCalibration").val().trim());
                        meter.set("ParentId", $("#ddlParent").val().trim());
                        meter.set("MeterTickUnit", $("#ddlUOM").val().trim());
                        meter.set("UsageFactor", $("#txtUsageFactor").val().trim());
                        meter.ControllerId = $("#ddlController").val().trim();
                        meter.ControllerModelId = $("#ddlController option:selected").attr('data-typeid');
                        meter.ControllerType = $("#ddlController option:selected").attr('data-type');

                        if ($("#txtDigitalInputNumber").val() != undefined) {
                            meter.set("DigitalInputNumber", $("#txtDigitalInputNumber").val().trim());
                    }
                        meter.set("AllowManualEntry", $("#ddlAllowManualEntry")[0].checked);
                        meter.set("MaxValueLimit", $("#txtMaxValueLimit").val().trim());
                            meter.WaterTypeFromFormulaSetup = $('#chkWaterTypeFromFormula').prop('checked');
                            meter.WaterType = $('#ddlWaterType').val();
                            meter.CounterNum = $('#ddlCounter').val();
                            meter.ExternalCounter = $('#ddlDigitalInput').val();
                            meter.CounterUsage = $('#chkCounterUsage').prop('checked');
                            meter.RunningTimeUsage = $('#chkRunTimeUsage').prop('checked');
                            meter.CounterAlarmValue = $('#txtCounterAlarmValue').val();
                            meter.RunningTimeAlarmValue = $('#txtRuntimeAlarmValue').val();
                            meter.ISWaterEnergyLogSel = $('#hdnIsWaterEnergyLogSel').val() == 'true';
                });
                    grid.saveChanges();
                } else return false;
            });
                grid.dataSource.cancelChanges();
            }
        }

        $(document).on('change', '.ddlMachineCompartment', function () {
            _this.isEdit = true;
            var ddlController = $('#ddlController');
            ddlController.empty();
            ddlController.append('<option value="">-- Select --</option>');
            ddlController.trigger('change');
            if (_this.options.eventHandlers.loadOnMachineCompartmentChange)
                _this.options.eventHandlers.loadOnMachineCompartmentChange($('#ddlUtilityLocation').val(), $(this).val());

            var dispenserValue = $("#ddlController").find("option:selected").text();
            if ((dispenserValue == "-- Select --") && ($("#ddlAllowManualEntry").is(":checked") == true)) {
                $('*[data-container-for="ddlController"]').find('span').remove();
        }
        });

        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            dataSource.cancelChanges(); //cancel changes
            wnd.close();
        });
        window.userMaxRole = _this.data.MaxLevel;
        window.IsCentral = _this.data.IsCentral;
        var kendoWindow;
        $("#gridMeter a.grid-add-new-record").unbind("click");
        $("#gridMeter a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            e.preventDefault();
            var data = $("#gridMeter").data("kendoGrid").dataSource;
            data.cancelChanges();
            kendoWindow = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                        title: $.GetLocaleKeyValue("FIELD_ADDMETER", 'Add Meter'),
                    modal: true,
                    resizable: false,
                    visible: false,
                    draggable: false,
                    width: "550px",
                    maxHeight: "550px",
                    open: onAddNewOpen,
                    close: onClose,
                        content: {
                            //sets kendoWindow template
                            template: kendo.template($("#newMeter").html())
                },
                        activate: function (e) {
                    _this.tm.Localize();
            }
            })
                .data("kendoWindow").center().open();
            var index = data.indexOf((data.view() || [])[0]);
            if (index < 0) {
                index = 0;
        }
            //insets a new model in the data
            var model = data.insert(index, {
        });

            //binds the editing kendoWindow to the form
            kendo.bind(kendoWindow.element, model);

            //determines at what position to insert the record (needed for pageable grids)

            //initialize the validator

            var validator = $(kendoWindow.element).kendoValidator().data("kendoValidator");
            kendoWindow.element.find('#btnUpdate').unbind("click");
            kendoWindow.element.find('#btnUpdate').click(function (e) {

                if (validator.validate() == true) {
                    var meterIndex = data._data.length;
                    var meter = {
            };
            if (_this.MeterId && _this.MeterId > 0) {
                        meter.MeterId = _this.MeterId;
            }
            else {
                meter.MeterId = 0;
            }
            meter.Description = $("#txtDescriptionAdd").val().trim();
            meter.MeterType = $("#ddlUtilityTypeAdd").val().trim();
            meter.UtilityId = $("#ddlUtilityLocationAdd").val().trim();
            meter.MachineId = $("#ddlMachineCompartmentAdd").val().trim();
            meter.ParentId = $("#ddlParentAdd").val().trim();
            meter.Calibration = $("#txtCalibrationAdd").val().trim();
            meter.MeterTickUnit = $("#ddlUOMAdd").val().trim();
                    meter.UsageFactor = $("#txtUsageFactorAdd").val();
            meter.ControllerId = $("#ddlControllerAdd").val().trim();
            meter.ControllerModelId = $("#ddlControllerAdd option:selected").attr('data-typeid');
            meter.ControllerType = $("#ddlControllerAdd option:selected").attr('data-type');
            meter.DigitalInputNumber = $("#txtDigitalInputNumberAdd").val().trim();
            meter.AllowManualEntry = $("#ddlAllowManualEntryAdd")[0].checked;
            meter.MaxValueLimit = $("#txtMaxValueLimitAdd").val().trim();
                    meter.WaterTypeFromFormulaSetup = $('#chkWaterTypeFromFormulaAdd').prop('checked');
                    meter.WaterType = $('#ddlWaterTypeAdd').val();
                    meter.CounterNum = $('#ddlCounterAdd').val();
                    meter.ExternalCounter = $('#ddlDigitalInputAdd').val();
                    meter.CounterUsage = $('#chkCounterUsageAdd').prop('checked');
                    meter.RunningTimeUsage = $('#chkRunTimeUsageAdd').prop('checked');
                    meter.CounterAlarmValue = $('#txtCounterAlarmValueAdd').val();
                    meter.RunningTimeAlarmValue = $('#txtRuntimeAlarmValueAdd').val();
                    meter.ISWaterEnergyLogSel = $('#hdnIsWaterEnergyLogSelAdd').val() == 'true';
                    meter.UtilityLocation = $('#ddlUtilityLocationAdd option:selected').text();
                //In order to avoid multiple requests to server, we need to cancel the changes and then save new changes.
                grid = $("#gridMeter").data("kendoGrid");
                    grid.cancelChanges();

                    data.insert(0, meter);
                    if (_this.MeterId && _this.MeterId > 0) {
                        dataSource._data[0].dirty = true;
            }
                    grid.saveChanges();
                    data.page(1);
            } else {
                    return false;
        }

            });

            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function (e) {
                data.cancelChanges(); //cancel changes
                kendoWindow.close();
                kendoWindow = null;
            });

            function onClose(e) {
                data.cancelChanges(); //cancel changes
                kendoWindow.element.remove();
                kendoWindow.destroy();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("body").css("overflow-y", "auto");
        }
        });

        function onAddNewOpen() {
            if (_this.options.eventHandlers.onAddNewMeterPopupLoad)
                _this.options.eventHandlers.onAddNewMeterPopupLoad();
            $("#topnav, .leftmenu-container").addClass("blur");
            $("body").css("overflow-y", "hidden");
            //Cascading data for Utility Location basing on Utility Type
            $('#ddlUtilityTypeAdd').change(function () {
                _this.isEdit = false;
                if ($(this).val() != '') {
                    if (_this.options.eventHandlers.onUtilityTypeChange)
                        _this.options.eventHandlers.onUtilityTypeChange($(this).val());
                }
                if ($('#ddlUtilityTypeAdd').val() == 1) {
                    $('.ufactor').show();
                    $('#txtUsageFactorAdd').prop("required", true);
                } else {
                    $('#txtUsageFactorAdd').removeAttr("required");
                    $('.ufactor').hide();
        }

                if ($('#ddlUtilityTypeAdd').val() != 2) {
                    $('.waterTypeFields').hide();
                    $('#ddlWaterTypeAdd').prop('required', false);
                }
                else {
                    $('.waterTypeFields').show();
                }
        });

            //Cascading data for Machine/Compartment basing on Utility Location
            $('#ddlUtilityLocationAdd').change(function () {
                _this.isEdit = false;
                $('#ddlMachineCompartmentAdd').html('<option value="">-- Select --</option>');
                if ($(this).val() != '') {
                    var lblMachineCompartmentAdd = $('#lblMachineCompartmentAdd');
                    var ddlLocationAdd = $("#ddlUtilityLocationAdd option:selected");
                    if (ddlLocationAdd.data('type') == "WasherGroup" && ddlLocationAdd.data('istunnel') == true) {
                        lblMachineCompartmentAdd.text($.GetLocaleKeyValue('FIELD_COMPARTMENT', 'Compartment'));
                        lblMachineCompartmentAdd.removeAttr('data-localize');
                    } else {
                        lblMachineCompartmentAdd.text($.GetLocaleKeyValue('FIELD_MACHINE', 'Machine'));
                        lblMachineCompartmentAdd.removeAttr('data-localize');
                }
                if (_this.options.eventHandlers.onUtilityLocationChange)
                        _this.options.eventHandlers.onUtilityLocationChange($(this).val());
        }
            });
            $('#ddlMachineCompartmentAdd').change(function () {
                if (_this.options.eventHandlers.loadOnMachineCompartmentChange)
                    _this.options.eventHandlers.loadOnMachineCompartmentChange($('#ddlUtilityLocationAdd').val(), $(this).val());
            });

            $('#ddlControllerAdd').change(function () {
                var option = $(this).find('option:selected');
                if (option.attr('data-regionid') == null || option.attr('data-regionid') == 1 || option.attr('data-typeid') == 5) {
                    $('.DigitalInputNumber').show();
                    //$('#txtDigitalInputNumberAdd').prop("required", true);
                } else {
                    //$('#txtDigitalInputNumberAdd').removeAttr("required");
                    $('.DigitalInputNumber').hide();
                }
                if($('#ddlControllerAdd').val() == "" && $("#ddlAllowManualEntryAdd").is(":checked") == true)
                {
                    $('#txtDigitalInputNumberAdd').prop("disabled", true);
                }
                else
                {
                    $('#txtDigitalInputNumberAdd').prop("disabled", false);
                }
                if (this.value != '' && $(this).find('option:selected').attr('data-isWaterEnergyLogSel') == 'true') {
                    $('.digitalInputFields').find('input').prop('disabled', false);
                    $('.digitalInputFields').find('select').prop('disabled', false);
                    $('#txtCounterAlarmValueAdd').prop('disabled', !$('#chkCounterUsageAdd').prop('checked'));
                    $('#txtRuntimeAlarmValueAdd').prop('disabled', !$('#chkRunTimeUsageAdd').prop('checked'));
                }
                else {
                    $('.digitalInputFields').find('input').prop('disabled', true);
                    $('.digitalInputFields').find('select').prop('disabled', true);
                }
            });
            $('#txtCounterAlarmValueAdd').prop('disabled', false);
            $('#txtCounterAlarmValueAdd').prop('required', false);
            $('#txtRuntimeAlarmValueAdd').prop('disabled', false);
            $('#txtRuntimeAlarmValueAdd').prop('required', false);
            $('#chkCounterUsageAdd').change(function () {
                if ($(this).prop('checked')) {
                    $('#txtCounterAlarmValueAdd').prop('disabled', false);
                    $('#txtCounterAlarmValueAdd').prop('required', false);
                }
                else {
                    $('#txtCounterAlarmValueAdd').prop('disabled', true);
                    $('#txtCounterAlarmValueAdd').prop('required', true);
                }
            });
            $("#ddlAllowManualEntryAdd").change(function () {

                if ($("#ddlAllowManualEntryAdd").is(":checked") == true) {
                    $('*[data-container-for="ddlController"]').find('span').remove();
                    if ($('#ddlControllerAdd').val() == "")
                        $('#txtDigitalInputNumberAdd').prop("disabled", true);
                    else
                        $('#txtDigitalInputNumberAdd').prop("disabled", false);
                }
                else {
                    $('#txtDigitalInputNumberAdd').prop("disabled", false);
                }
            });
            $('#chkRunTimeUsageAdd').change(function () {
                if ($(this).prop('checked')) {
                    $('#txtRuntimeAlarmValueAdd').prop('disabled', false);
                    $('#txtRuntimeAlarmValueAdd').prop('required', false);
                }
                else {
                    $('#txtRuntimeAlarmValueAdd').prop('disabled', true);
                    $('#txtRuntimeAlarmValueAdd').prop('required', true);
                }
            });
            $("#ddlAllowManualEntryAdd").change(function () {

                if ($("#ddlAllowManualEntryAdd").is(":checked") == true) {
                    $('*[data-container-for="ddlController"]').find('span').remove();
                    $('#txtDigitalInputNumberAdd').prop("disabled", true);
                }
                else {
                    $('#txtDigitalInputNumberAdd').prop("disabled", false);
                }
            });
            _this.digitalInputFieldsEvents(false);
            $('.waterTypeFields').hide();
            if (_this.data.RegionId == 2) {
                $('.nonEUFields').hide();
                $('#txtMaxValueLimitAdd').prop('required', false);
            }
            else {
                $('.nonEUFields').show();
            }
        }

        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
    },

    disableDigitalInputFields: function (isEdit) {
        var ddlCounter;
        var ddlDigitalInput;
        var isTunnel;
        var counterNum;
        var txtCounterAlarmValue;
        var txtRuntimeAlarmValue;
        var chkRunTimeUsage;
        var chkCounterUsage;
        if (isEdit == true) {
            ddlCounter = $('#ddlCounter');
            ddlDigitalInput = $('#ddlDigitalInput');
            isTunnel = $('#ddlUtilityLocation').find('option:selected').attr('data-istunnel');
            txtCounterAlarmValue = $('#txtCounterAlarmValue');
            txtRuntimeAlarmValue = $('#txtRuntimeAlarmValue');
            chkRunTimeUsage = $('#chkRunTimeUsage');
            chkCounterUsage = $('#chkCounterUsage');
        } else if (isEdit == false) {
            ddlCounter = $('#ddlCounterAdd');
            ddlDigitalInput = $('#ddlDigitalInputAdd');
            isTunnel = $('#ddlUtilityLocationAdd').find('option:selected').attr('data-istunnel');
            txtCounterAlarmValue = $('#txtCounterAlarmValueAdd');
            txtRuntimeAlarmValue = $('#txtRuntimeAlarmValueAdd');
            chkRunTimeUsage = $('#chkRunTimeUsageAdd');
            chkCounterUsage = $('#chkCounterUsageAdd');
        }
        txtCounterAlarmValue.val('');
        txtRuntimeAlarmValue.val('');
        txtCounterAlarmValue.prop('disabled', true);
        txtRuntimeAlarmValue.prop('disabled', true);
        chkRunTimeUsage.prop('required', false);
        chkCounterUsage.prop('required', false);
        chkRunTimeUsage.prop('checked', false);
        chkCounterUsage.prop('checked', false);
        if (isTunnel == 'true') {
            counterNum = 6;
        }
        else {
            counterNum = 2;
        }
        ddlCounter.empty();
        ddlCounter.append('<option value="">-- Select --</option>');
        for (var i = 1; i <= counterNum; i++) {
            ddlCounter.append('<option value="' + i + '">Counter ' + i + '</option>');
        }
        $('.digitalInputFields').find('input').prop('disabled', true);
        $('.digitalInputFields').find('select').prop('disabled', true);
    },
    digitalInputFieldsEvents: function (isEdit) {
        var ddlCounter;
        var ddlDigitalInput;
        var location;
        var isWaterEnergyLogSel;
        var ddlwaterType;
        var checkWaterType;
        var waterType;
        var txtAlarmValue;
        var txtRuntimeAlarmValue;
        var chkCounterUsage;
        var chkRunTimeUsage;
        if (isEdit) {
            ddlwaterType = $('#ddlWaterType');
            ddlCounter = $('#ddlCounter');
            ddlDigitalInput = $('#ddlDigitalInput');
            checkWaterType = $('#chkWaterTypeFromFormula');
            waterType = $('#ddlWaterType');
            txtAlarmValue = $('#txtCounterAlarmValue');
            txtRuntimeAlarmValue = $('#txtRuntimeAlarmValue');
            chkCounterUsage = $('#chkCounterUsage');
            chkRunTimeUsage = $('#chkRunTimeUsage');
        }
        else {
            ddlwaterType = $('#ddlWaterTypeAdd');
            ddlCounter = $('#ddlCounterAdd');
            ddlDigitalInput = $('#ddlDigitalInputAdd');
            checkWaterType = $('#chkWaterTypeFromFormulaAdd');
            waterType = $('#ddlWaterTypeAdd');
            txtAlarmValue = $('#txtCounterAlarmValueAdd');
            txtRuntimeAlarmValue = $('#txtRuntimeAlarmValueAdd');
            chkCounterUsage = $('#chkCounterUsageAdd');
            chkRunTimeUsage = $('#chkRunTimeUsageAdd');
        }
        ddlCounter.change(function () {
            isWaterEnergyLogSel = isEdit ? $('#ddlController').find('option:selected').attr('data-iswaterenergylogsel') == 'true' : $('#ddlControllerAdd').find('option:selected').attr('data-iswaterenergylogsel') == 'true';
            if ($(this).val() == '') {
                if (isWaterEnergyLogSel) {
                    $(this).prop('disabled', true);
                    $('.digitalInputFields').find('input').prop('disabled', false);
                    $('.digitalInputFields').find('select').prop('disabled', false);
                    txtAlarmValue.prop('disabled', !chkCounterUsage.prop('checked'));
                    txtRuntimeAlarmValue.prop('disabled', !chkRunTimeUsage.prop('checked'));
                }
            }
            else {
                $('.digitalInputFields').find('input').prop('disabled', true);
                $('.digitalInputFields').find('select').prop('disabled', true);
            }
        });
        ddlDigitalInput.change(function () {
            if ($(this).val() == '') {
                $('.digitalInputFields').find('input').prop('disabled', true);
                $('.digitalInputFields').find('select').prop('disabled', true);
                ddlCounter.prop('disabled', false);
            }
            else {
                ddlCounter.prop('disabled', true);
            }
        });
        checkWaterType.change(function () {
            if ($(this).prop('checked')) {
                waterType.prop('disabled', true);
                waterType.prop('required', false);
                $('#spnWaterType').hide();
            }
            else {
                waterType.prop('disabled', false);
                waterType.prop('required', true);
                $('#spnWaterType').show();
            }
        });
        txtAlarmValue.mask('99999');
        txtRuntimeAlarmValue.mask('99999');
    },
    onExternalAndInternalCountersFetched: function (data, internalCounter, externalCounter) {
        var _this = this;
        var counter;
        var externalCounter;
        if (_this.isEdit) {
            counter = $('#ddlCounter');
            externalCounter = $('#ddlDigitalInput');
        }
        else {
            counter = $('#ddlCounterAdd');
            externalCounter = $('#ddlDigitalInputAdd');
        }

        if (data.InternalCounters != '' && data.InternalCounters != null) {
            var usedInternalCountersArr = data.InternalCounters.split(',');
            $(usedInternalCountersArr).each(function (index, value) {
                if (counter.find('option[value=' + value + ']').length > 0)
                    counter.find('option[value=' + value + ']').remove();
            });
        }
        if (data.ExternalCounters != '' && data.ExternalCounters != null) {
            var usedExternalCountersArr = data.ExternalCounters.split(',');
            $(usedExternalCountersArr).each(function (index, value) {
                if (externalCounter.find('option[value=' + value + ']').length > 0)
                    externalCounter.find('option[value=' + value + ']').remove();
            });
        }
    }
};