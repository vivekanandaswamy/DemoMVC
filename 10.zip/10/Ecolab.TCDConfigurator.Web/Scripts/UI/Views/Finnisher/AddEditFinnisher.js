﻿Ecolab.Views.AddEditFinnisher = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onAddFinnisherGroupClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AddEditFinnisher',
        templateUri: './Scripts/UI/Views/Finnisher/AddEditFinnisher.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.AddEditFinnisher.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    	$('#myModal').modal({
    		show: true,
    		backdrop: 'static',
    		keyboard: false
    	});

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find('#btnSaveFinnisher').click(function () {
            _this.clearStatusMessage();
            _this.onAddFinnisherClicked();
        })

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },
    getFinnisherData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            GroupId: container.find("#txtFinnisherName").attr("data-groupid"),
            FinisherId: container.find("#txtFinnisherName").attr("data-id"),
            Name: container.find("#txtFinnisherName").val(),
            Number:container.find("#txtFinnisherNumber").val(),
            FinnisherType: {
                Id: container.find("#ddlFinnisherType").val()
            },
            LastModifiedTimeStampFinnisher: _this.data.LastModifiedTimeStampFinnisher
        };
    },
    validateFinnisher: function () {
        _this = this
        _this.clearStatusMessage();
        var container = $(this.options.containerSelector);

        var v1 = container.find('#frmAddEditFinnisher').validate({
            rules: {
                txtFinnisherNumber: { required: true, number: true },
                txtFinnisherName: {
                    required: true,
                },
                ddlFinnisherType: {
                    required: function () {
                        if ($('#ddlFinnisherType').val() == "Select") {
                            return false;
                        }
                        return true;
                    },
                },
            },
            messages: {
                txtFinnisherNumber: {
                    required: $.GetLocaleKeyValue('FIELD_ENTERFINNISHERNUMBER', 'Please enter Finisher number.'),
                    number: $.GetLocaleKeyValue('FIELD_ENTERNUMBERSONLY', 'Please enter numbers only.')
                },
                txtFinnisherName: {
                    required: $.GetLocaleKeyValue('FIELD_ENTERFINNISHERNAME', 'Please enter Finisher name.'),
                },
                ddlFinnisherType: {
                    required: $.GetLocaleKeyValue('FIELD_SELECTFINNISHERTYPE', 'Please select Finisher type.'),
                },
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));

                if (element.hasClass('txtEditNominalLoad')) {
                    error.appendTo(element.parent().next('span.errorMsg'));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select") || element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().next("span.errorMsg"));
                }
            }
        });

        var v2 = container.find('#frmAddEditFinnisher').valid();
        return v2;
    },
    onAddFinnisherClicked: function () {
        var _this = this;
        if (_this.validateFinnisher()) {
            _this.isDirty = false;
            var FinnisherData = _this.getFinnisherData();
            if (FinnisherData.FinisherId > 0) {
                if (this.options.eventHandlers.onFinnisherUpdateClicked)
                    this.options.eventHandlers.onFinnisherUpdateClicked(_this.getFinnisherData());
            }
            else {
                if (this.options.eventHandlers.onFinnisherSaveClicked) {
                    this.options.eventHandlers.onFinnisherSaveClicked(_this.getFinnisherData());
                }
            }
        }
    },
    clearStatusMessage: function () {
        $("#finnisherErrorMsg").html('');
    }
}