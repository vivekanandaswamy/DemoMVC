﻿Ecolab.Views.AddEditFinnisherGroup = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onAddFinnisherGroupClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AddEditFinnisherGroup',
        templateUri: './Scripts/UI/Views/Finnisher/AddEditFinnisherGroup.html',
        paraShiftLabors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};
Ecolab.Views.AddEditFinnisherGroup.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    	$('#myModal').modal({
    		show: true,
    		backdrop: 'static',
    		keyboard: false
    	});
    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find('#btnSaveGroup').click(function () {
            _this.clearStatusMessage();
            _this.onAddFinnisherGroupClicked();
        })

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },
    getFinnisherGroupData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var FinnisherGroupModel = {};
        FinnisherGroupModel.Id = container.find("#txtFinnisherGroupName").attr("data-groupid");
        FinnisherGroupModel.LastModifiedTimeStampFinnisherGroup = _this.data.LastModifiedTimeStampFinnisherGroup;
        FinnisherGroupModel.Name = container.find("#txtFinnisherGroupName").val();
        return FinnisherGroupModel;
    },
    validateFinnisherGroup: function () {
        _this = this
        _this.clearStatusMessage();

        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmAddEditFinnisherGroup').validate({
            rules: {
                txtFinnisherGroupName: {
                    required: true,
                }
            },
            messages: {
                txtFinnisherGroupName: {
                    required: $.GetLocaleKeyValue('FIELD_ENTERFINNISHERGROUPNAME', 'Please enter Finnisher group Name.'),
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#frmAddEditFinnisherGroup').valid();
        return v2;
    },
    onAddFinnisherGroupClicked: function () {
        var _this = this;
        if (_this.validateFinnisherGroup()) {
            _this.isDirty = false;
            var FinnisherGroupData = _this.getFinnisherGroupData();
            if (FinnisherGroupData.Id > 0) {
                if (this.options.eventHandlers.onFinnisherGroupUpdateClicked)
                    this.options.eventHandlers.onFinnisherGroupUpdateClicked(_this.getFinnisherGroupData());
            }
            else {
                if (this.options.eventHandlers.onFinnisherGroupSaveClicked) {
                    this.options.eventHandlers.onFinnisherGroupSaveClicked(_this.getFinnisherGroupData());
                }
            }
        }
    },
    clearStatusMessage: function () {
        $("#finnisherErrorMsg").html('');
    }
}