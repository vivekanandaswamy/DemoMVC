﻿Ecolab.Views.BreadCrumb = function (options) {
    var _this = this;
    var defaults = {
        eventHandlers: {
        },

        containerSelector: '#breadCrumbContainer'
    };

    this.settings = $.extend(defaults, options);

    //creating the template manager
    this.tm = new TemplateManager({
        templateName: 'BreadCrumb',
        templateUri: '/Scripts/UI/Views/BreadCrumb/BreadCrumb.html',
        parameters: [],
        containerElement: this.settings.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
var IsCentralValue = "No";
Ecolab.Views.BreadCrumb.prototype = {

    setData: function (data,IsCentral) {
        if (data[0].name == 'Reports') {
            data[0].name = '';
            this.isReport = true;
        }
        IsCentralValue = IsCentral;
        this.tm.Render(data, this);
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.settings.containerSelector);
        container.find('#breadCrumb .link').click(function (event) {
            event.preventDefault();
            if (_this.settings.eventHandlers.breadCrumbLinkClicked)
                _this.settings.eventHandlers.breadCrumbLinkClicked(this.href);
        });

    },

    onRendered: function () {
        var _this = this;
        var container = $(this.settings.containerSelector);
        if (_this.isReport) {
            var bData = '<li> <a class="clsbreadcurmbReport" data-id="1" href="javascript:void(0)"> Reports </a> </li>' +
                '<li> <a class="clsbreadcurmbReport" data-id="1" href="javascript:void(0)"> Production Efficiency</a> </li>' +
                '<li> <a class="clsbreadcurmbReport" data-id="1" href="javascript:void(0)" data-localize ="FIELD_PRODUCTIONREPORTS">Production Reports</a>' +
                '</li><li> <a class="clsbreadcurmbReport">Production Summary</a></li>';
            $('.breadcrumb').children().not('.breadcrumb-home').remove();
            $('.breadcrumb').append(bData);
            
        }
        if (IsCentralValue == "Yes") {
            if($("#breadCrumbContainer").find("li:first").find("a").attr("href") == "/Home");
        {
                $("#breadCrumbContainer").find("li:first").find("a").attr("href", "/PlantSetup");
        }
        }
        this.attachEvents();
        var lastbrcdm = $(".breadcrumb li:last-child a").text();
        $(".breadcrumb li:last-child").html(lastbrcdm);
    }
};
