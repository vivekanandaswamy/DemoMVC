Ecolab.Views.ControllerSetupAdvance = function (options) {
    var defaults = {
        containerSelector: null,
        dynamicHTMLSelector: null,
        metaData: null,
        eventHandlers: {
            rendered: function () { },
            dynamicRendered: function () { },
            onSaveClicked: function () { },
            onCancelClicked: function () { },
            onRedirection: function () { },
            onSavePage: function () { }

        },
        accountInfo: null
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'ControllerSetupAdvance',
        templateUri: './Scripts/UI/Views/ControllerSetupAdvance/ControllerSetupAdvance.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.dynamicTm = new TemplateManager({
        templateName: 'DynamicTM',
        templateUri: './Scripts/UI/Views/ControllerSetupAdvance/Dynamic.html',
        parameters: [],
        containerElement: this.options.dynamicHTMLSelector,
        eventHandlers: { onRendered: function () { _this.onDynamicUIRendered(); } }
    });
    this.dataList = {};
};
Ecolab.Views.ControllerSetupAdvance.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        if (data.length > 0) {
            this.tm.Render(data[0].FieldGroupInfo[0], this);
        }
    },
    setDynamicUI: function (metaData) {
        this.options.accountInfo.RegionId = 2;
        if (this.options.accountInfo.MaxLevel > 5)
            metaData.Mode = "Edit";
        if (this.options.accountInfo.ControllerId != "-1") {
            metaData.ControllerId = this.options.accountInfo.ControllerId;
        } else {
            metaData.ControllerId = -1;

        }
        $.each(metaData[0].FieldGroupInfo, function (index, value) {
            var field = metaData[0].FieldGroupInfo[index];
            if (field.FieldLabel === "Set PLC Time") {
                metaData.DisplayOrder = field.FieldDO;
            }
        });
        var isEdit = this.getQueryStringByName('IsEdit');
        if (isEdit != "true") {
            if (isEdit != "undefined") {
                $('.new_tabs li.tab:eq(2)').addClass('disabled');
                $('.new_tabs li.tab:eq(2)').find('a').removeAttr("data-toggle");
                $('.new_tabs li.tab:eq(2)').children('a').click(function (e) {
                    e.preventDefault();
                });
            }
        }
        if (!metaData[0].HasPumps) {
            $('.new_tabs li.tab:eq(2)').addClass('disabled');
            $('.new_tabs li.tab:eq(2)').find('a').removeAttr("data-toggle");
            $('.new_tabs li.tab:eq(2)').children('a').click(function (e) {
                e.preventDefault();
            });
        }

        if (metaData.length > 0) {
            $.each(metaData, function (index, value) {
                metaData[index].FieldGroupName = metaData[index].FieldGroupInfo[0].FieldGroupName;
            });
        }

        metaData.MaxLevel = this.options.accountInfo.MaxLevel;
        this.metaData = metaData;
        this.dynamicTm.Render(metaData, this);
    },
    onRendered: function () {
        $('#btnContainer').addClass("hide");
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },
    onDynamicUIRendered: function () {
        $('#btnSave').attr('disabled');
        $('#btnSaveAndClose').attr('disabled');
        $('#btnContainer').removeClass("hide");
        this.attachDynamicEvents();
        if (this.options.eventHandlers.dynamicRendered)
            this.options.eventHandlers.dynamicRendered();

        var flag = $(".PLCTime").attr("checked");
        if (flag && this.data.accountInfo.IsCentral == "No") {
            $(".PLCTimeStamp").attr("enabled", "enabled");
        } else {
            $(".PLCTimeStamp").attr("disabled", "disabled");
        }
        $(".PLCTime, .PLCTimeStamp").parent().parent(".col-xs-12").appendTo("#generate_clmn");
        $("#generate_clmn").find(".col-lg-4.col-xs-4.nopadding.marg_btm10").hide();
        $("#generate_clmn").find(".col-lg-3.col-xs-3.marg_btm10").css("padding-left", "0");
        $(".AWE,.RatioDosing,.disableAWEA,.disableRatioDosing").attr("disabled", "disabled");
        kendo.ui.progress($('body'), false);
        this.borderRed();

        $(".custom-select").each(function () {
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth);
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        container.find('#btnCancel').click(function () { _this.onCancelClicked(); });
        container.find('#btnSave').click(function () { return _this.onSaveClicked(); });
        container.find('#btnSaveAndClose').click(function () {
            return _this.onSaveClicked(true);
        });

    },

    borderRed: function () {
        var _this = this;
        $.each(_this.data[0].FieldGroupInfo, function (index) {
            var field = _this.data[0].FieldGroupInfo[index];
            var overRide = field.OverrideValues;
            if (overRide) {
                    $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).addClass("brdr_red");
            }
        });
        _this.data.forEach(function (k, v) {
            k.FieldGroupInfo.forEach(function (ky, vl) {
                if (ky.OverrideValues == true && ky.FieldType == "CHECKBOX") {
                    $("#Input_Control_" + ky.FieldGroupId + "_" + ky.FieldId).wrap('<div class="squaredFour" />')
                    $("#Input_Control_" + ky.FieldGroupId + "_" + ky.FieldId).addClass("brdr_red squaredFour k-checkbox");
                    $("#Input_Control_" + ky.FieldGroupId + "_" + ky.FieldId).after('<label for="squaredFour" class="hide"></label>');
                    $("#Input_Control_" + ky.FieldGroupId + "_" + ky.FieldId).siblings('label').removeClass('hide');
                }
            });
        });
        var x = false;
        _this.data.forEach(function (k, v) {
            k.FieldGroupInfo.forEach(function (ky, vl) {
                if (ky.OverrideValues == true) {
                    x = true; return;
                }
            });
        });
        if (x) { $('#btnSave').removeAttr('disabled'); $('#btnSaveAndClose').removeAttr('disabled'); }
    },

    onCancelClicked: function () {
        var retVal = this.options.eventHandlers.onRedirection('/ControllerSetupList');
        return retVal;
    },

    checkConfirmation: function () {
        var message = '';
        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var field = fieldGroup.FieldGroupInfo[j];
                if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue') != undefined) {
                    var initialValue = parseInt($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue'));
                    var textValue = parseInt($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val());
                    if (initialValue > textValue && field.FieldLabel != 'Preflush Time(sec)' && field.FieldLabel != 'Postflush Time(sec)') {
                        if (field.FieldLabel != 'No. of Chemical Valves')
                            message = message + '<strong>' + field.FieldLabel + '</Strong><br/>';
                        else
                            message = message + '<strong>' + field.FieldLabel + '</Strong>';

                    }
                }
            }
        }
        if (message) message += ' Value(s) are decreased do you want to continue?';
        return message;
    },

    cancelConfirmation: function (isCancel) {
        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var field = fieldGroup.FieldGroupInfo[j];
                if (!isCancel) {
                    if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue') != undefined) {
                        var initialValue = parseInt($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue'));
                        var numerictextbox = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).data("kendoNumericTextBox");
                        if (numerictextbox != undefined) {
                            numerictextbox.value(initialValue);
                        }
                    }
                }
                else {//reset-refresh
                    $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('initialValue', parseInt($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val()));
                }
            }
        }
    },

    getData: function () {
        var controllerId = 0;
        var controllerModelId = 0;
        var controllerTypeId = 0;
        var maxLevel = this.options.accountInfo.MaxLevel;
        if (this.options.accountInfo.ControllerId != "-1") {
            controllerId = this.options.accountInfo.ControllerId;
            controllerModelId = this.options.accountInfo.ControllerModelId;
            controllerTypeId = this.options.accountInfo.ControllerTypeId;
        }
        var dataArr = [];
        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var controller = {};
                var field = fieldGroup.FieldGroupInfo[j];
                controller.ControllerId = controllerId;
                controller.TabId = 3;
                controller.EcolabAccountNumber = this.options.accountInfo.EcolabAccountNumber;
                controller.ControllerModelId = controllerModelId;
                controller.ControllerTypeId = controllerTypeId;
                controller.FieldGroupId = field.FieldGroupId;
                controller.FieldId = field.FieldId;
                controller.FieldName = field.FieldName;
                if (field.FieldType == "CHECKBOX") {
                    controller.Value = String($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is(':checked'));
                }
                else if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is("label"))
                    controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).text();
                else
                    controller.Value = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();
                controller.FieldTagValue = field.HasFieldTag;
                if (field.ControllerModelId == 11 || field.ControllerModelId == 8)
                {
                    controller.FieldTagAddress = field.TagDefaultValue;
                }
                else {
                controller.FieldTagAddress = $("#Tag_Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();
                }
                controller.Role = maxLevel;
                dataArr.push(controller);
            }
        }
        if (controllerModelId != "7" && controllerModelId != "11" && controllerModelId != "8")
            dataArr[0].PlcTagModelTags = this.getTagData();

        return dataArr;
    },

    getTagData: function () {

        var year = "", month = "", day = "", hour = "", minutes = "", seconds = "";
        var dateTime = new Date();
        year = dateTime.getFullYear();
        month = dateTime.getMonth();
        day = dateTime.getDay();
        hour = dateTime.getHours();
        minutes = dateTime.getMinutes();
        seconds = dateTime.getSeconds();

        for (var i = 0; i < this.metaData.length; i++) {
            var fieldGroup = this.metaData[i];
            var tags = [];
            for (var j = 0; j < fieldGroup.FieldGroupInfo.length; j++) {
                var field = fieldGroup.FieldGroupInfo[j];
                var tagAddress = $("#Tag_Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();
                var tagValues = {};
                var fieldTagId = null;

                if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('type') == "text") {
                    fieldTagId = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).val();
                }
                else if ($("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).attr('type') == "checkbox") {
                    fieldTagId = $("#Input_Control_" + field.FieldGroupId + "_" + field.FieldId).is(":checked") ? true : false;
                }

                if (field.FieldClassName != null && field.FieldClassName.indexOf("PLCTimeStamp") !== -1 && $('.PLCTime').is(':checked')) {
                    switch (field.FieldLabel) {
                        case "Year":
                            fieldTagId = year;
                            break;
                        case "Month":
                            fieldTagId = month;
                            break;
                        case "Day":
                            fieldTagId = day;
                            break;
                        case "Hour":
                            fieldTagId = hour;
                            break;
                        case "Minute":
                            fieldTagId = minutes;
                            break;
                        case "Second":
                            fieldTagId = seconds;
                            break;
                        default:
                            break;
                    }

                }
                if (field.FieldClassName != "PLCTimeStamp") {
                    tagValues.Address = tagAddress;
                    tagValues.Value = fieldTagId;
                    tagValues.IsValidTag = false;
                    tagValues.Topic = "ULTRAX1";
                    tagValues.TagType = field.HasFieldTag != null ? field.HasFieldTag : field.FieldName;
                    tags.push(tagValues);
                }
                else if (field.FieldClassName == "PLCTimeStamp" && $('.PLCTime').is(':checked')) {
                    tagValues.Address = tagAddress;
                    tagValues.Value = fieldTagId;
                    tagValues.IsValidTag = false;
                    tagValues.Topic = "ULTRAX1";
                    tagValues.TagType = field.HasFieldTag != null ? field.HasFieldTag : field.FieldName;
                    tags.push(tagValues);
                }
            }
        }

        tags.ControllerId = this.options.accountInfo.ControllerId;
        var controllerType;
        if (this.options.accountInfo.ControllerTypeId == 1) {
            controllerType = "Allen Bradley";
        } else {
            controllerType = "Beckhoff";
        }
        tags.ControllerType = controllerType;
        return tags;
    },
    onSaveClicked: function (isSaveAndClose) {

        return this.options.eventHandlers.onSavePage(this.checkConfirmation(), isSaveAndClose);
    },
    validate: function () {
        var validator = $("#frmControllerSetupDetails").kendoValidator({
            rules: {
                myRule: function (input) {
                    if (input.is("[data-role='numerictextbox']")) {
                        var min = parseInt($(input).attr("data-min"));
                        var max = parseInt($(input).attr("data-max"));
                        var val = parseInt(input.val());
                        if (val < min || val > max) {
                            return false;
                        }
                        return true;
                    }
                    return true;
                }
            },
            messages: {
                myRule: function (input) {
                    var min = $(input).attr("data-min");
                    var max = $(input).attr("data-max");
                    var msg = "Please enter number between " + min + " and " + max;
                    var customMsg = $(input).attr("data-val-msg");
                    if (customMsg) {
                        return customMsg;
                    }
                    else {
                        return msg;
                    }
                }
            }
        }).data("kendoValidator");
        //return validator.validate();
        if (validator.validate()) {
            var total = 0;
            $('.txtTCR input:text').each(function (i, obj) {
                if ($(obj).is(":visible")) {
                    total = total + parseInt($(obj).val());
                }
            });
            if (total > 24) {
                setTimeout(function () {
                    $("#errorDiv_msg").removeClass('k-success-message').attr('class', 'k-error-message').html(($.GetLocaleKeyValue("FIELD_TCRVALIDATIONMSG", 'Sum of TCR should not exceed 24')));
                }, 100);
                return false;
            }
            return true;
        }
    },

    attachDynamicEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        $(".k-datetimepicker").kendoDatePicker({ format: "MM/dd/yyyy" });
        $(".k-datetimepicker input").prop("readonly", true);
        $(".k-numerictextbox").kendoNumericTextBox({
            format: "{0:n0}",
            min: 0,
            decimals: 0,
            spinners: true,
            spin: onSpin
        });
        function onSpin() {
            $(document).find('.buttonTrack').removeAttr('disabled');
            _this.isDirty = true;
        }
        $('.k-checkbox').kendoMobileSwitch({
            onLabel: "YES",
            offLabel: "NO",
            change: function (e) {
                $('#btnSave').removeAttr('disabled');
                $('#btnCancel').removeAttr('disabled');
            }
        });

        container.find('select').kendoDropDownList();
        container.find(".tooltip-wanter").tooltip({ selector: ".tooltip-info", placement: "top" });
        container.find(".PLCTime").change(function () {
            var flag = $(".PLCTime").attr("checked");
            if (flag && _this.data.accountInfo.IsCentral == "No") {
                $(".PLCTimeStamp").removeAttr("disabled", "disabled");
            } else {
                $(".PLCTimeStamp").attr("disabled", "disabled");
            }
        });
        container.find('.ddldosing').change(function () {
            var otherInput = $(this).closest('.row').find('.dosingLinetext');
        });
        $(".k-formatted-value").hover(function () {
            var originaltitle = $(this).next(".tooltip-info").attr("data-original-title");
            $(this).attr("data-original-title", originaltitle);
        });

        $(".txtTCR").kendoNumericTextBox({
            spinners: false,
            decimals: 0,
            format: "{0:n0}"
        });

        if (_this.data.accountInfo.IsCentral == "Yes" && _this.options.accountInfo.ControllerModelId == '8') {
        $(".k-numerictextbox1").kendoNumericTextBox({
            spinners: false,
                decimals: 1,
                format: "#.#"
            });
        }
        else {
            $(".k-numerictextbox1").kendoNumericTextBox({
                spinners: false,
            decimals: 0,
            format: "{0:n0}"
        });
        }
        $(".k-numerictextbox2").kendoNumericTextBox({
            spinners: false,
            decimals: 1,
            format: "#.#"
        });

        if (_this.options.accountInfo.ControllerModelId == '7') {
            container.find('#Input_Control_19_216').mask('99');
            container.find("#Input_Control_19_216").bind('keyup', function (v) {
                var content = $('#Input_Control_19_216').val();
                if (content > 10) {
                    var contentVal = content.substring(0, 1);
                    $('#Input_Control_19_216').val(contentVal);
                    return false;
                }
                if (String.fromCharCode(v.keyCode).match(/[^0-9]/g)) {
                    return false;
                }
            });
            container.find('#Input_Control_19_215').mask('99');
            container.find("#Input_Control_19_215").bind('keyup', function (v) {
                var content = $('#Input_Control_19_215').val();
                if (content > 60) {
                    var contentVal = content.substring(0, 1);
                    $('#Input_Control_19_215').val(contentVal);
                    return false;
                }
                if (String.fromCharCode(v.keyCode).match(/[^0-9]/g)) {
                    return false;
                }
            });

            container.find('#Input_Control_20_221').mask('99999');
            container.find("#Input_Control_20_221").on('input', function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 65535 || parseFloat($(this).val() + '' + ch) < 1)
                    container.find("#Input_Control_20_221").val(ch);
                    return false;
            });

            container.find('#Input_Control_20_224').mask('99999');
            container.find("#Input_Control_20_224").keypress(function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 65535) {
                    return false;
                }

                $('#Input_Control_20_224').prev().css("display", "none");
                $('#Input_Control_20_224').css("display", "block");
            });

            container.find('#Input_Control_56_471').mask('99');
            container.find("#Input_Control_56_471").bind('keyup', function (v) {
                var content = $('#Input_Control_56_471').val();
                if (content > 60) {
                    var contentVal = content.substring(0, 1);
                    $('#Input_Control_56_471').val(contentVal);
                    return false;
                }
                if (String.fromCharCode(v.keyCode).match(/[^0-9]/g)) {
                    return false;
                }
            });

            container.find('#Input_Control_56_472').mask('99');
            container.find("#Input_Control_56_472").bind('keyup', function (v) {
                var content = $('#Input_Control_56_472').val();
                if (content > 10) {
                    var contentVal = content.substring(0, 1);
                    $('#Input_Control_56_472').val(contentVal);
                    return false;
                }
                if (String.fromCharCode(v.keyCode).match(/[^0-9]/g)) {
                    return false;
                }
            });

            container.find('#Input_Control_20_225').mask('99');
            container.find('#Input_Control_20_227').mask('999');
            container.find('#Input_Control_20_229').mask('999');

        }
        else if (_this.options.accountInfo.ControllerModelId == 8) {
            $('#Input_Control_40_403,#Input_Control_37_390').mask('9.9');
            container.find("#Input_Control_36_215,#Input_Control_39_215").mask('99');

            container.find("#Input_Control_39_215").on('input', function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60) {
                    container.find("#Input_Control_39_215").val(ch);
                    return false;
        }
            });

            container.find("#Input_Control_36_215").on('input', function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60) {
                    container.find("#Input_Control_36_215").val(ch);
                    return false;
                }
            });
        }
        else if (_this.options.accountInfo.ControllerModelId == 11) {
            $('#Input_Control_28_475,#Input_Control_28_474,#Input_Control_29_316,#Input_Control_33_355,#Input_Control_25_277,#Input_Control_32_474,#Input_Control_32_475,#Input_Control_24_474').mask('99');

            container.find("#Input_Control_28_474").on('input', function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60 || parseFloat($(this).val() + '' + ch) < 0) {
                    container.find("#Input_Control_28_474").val(ch);
                    return false;
                }
            });
            container.find("#Input_Control_28_475").keypress(function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 10 || parseFloat($(this).val() + '' + ch) < 0) {
                    return false;
                }
            });
            container.find("#Input_Control_32_475").keypress(function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 10 || parseFloat($(this).val() + '' + ch) < 0) {
                    return false;
                }
            });
            container.find("#Input_Control_32_474").on('input', function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60 || parseFloat($(this).val() + '' + ch) < 0) {
                    container.find("#Input_Control_32_474").val(ch);
                    return false;
                }
            });
            container.find("#Input_Control_24_474").on('input', function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60 || parseFloat($(this).val() + '' + ch) < 0) {
                    container.find("#Input_Control_24_474").val(ch);
                    return false;
                }
            });

        }

        container.find("#Input_Control_20_224").focusout(function () {
            $('#Input_Control_20_224').prev().css("display", "none");
            $('#Input_Control_20_224').css("display", "block").css("height", "18px");
        });

        if (_this.options.accountInfo.ControllerModelId == '14') {
            container.find("#Input_Control_48_215").mask('99');
            container.find("#Input_Control_48_215").keypress(function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60 || parseFloat($(this).val() + '' + ch) < 0)
                    return false;
            });

            container.find("#Input_Control_51_215").mask('99');
            container.find("#Input_Control_51_215").keypress(function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60 || parseFloat($(this).val() + '' + ch) < 0)
                    return false;
            });
        }

        if (_this.options.accountInfo.ControllerModelId == '9') {
            container.find("Input_Control_42_215").mask('99');
            container.find("#Input_Control_42_215").keypress(function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60 || parseFloat($(this).val() + '' + ch) < 0)
                    return false;
            });

            container.find("Input_Control_45_215").mask('99');
            container.find("#Input_Control_45_215").keypress(function (v) {
                var ch = String.fromCharCode(v.keyCode);
                if (parseFloat($(this).val() + '' + ch) > 60 || parseFloat($(this).val() + '' + ch) < 0)
                    return false;
            });
        }

        //Dosing Line Change Events
        container.find(".ddldosingLine").change(function (ctrl) {
            $(ctrl.target).parent().parent().parent().find("span.k-tooltip-validation").hide();
            if ($(ctrl.target).val() == "1") {
                $(ctrl.target).parent().parent().parent().find('.txtTCR').not(':visible').data("kendoNumericTextBox").enable(false);
            }
            else {
                $(ctrl.target).parent().parent().parent().find('.txtTCR').not(':visible').data("kendoNumericTextBox").enable(true);
                $(ctrl.target).parent().parent().parent().find('input[type=checkbox]').attr('checked', true);
            }
        });

        var tagfieldLength = $('#tabAdvancedContainer').find('.tagfield').length;
        if (tagfieldLength == 0) {
            $('#tabAdvancedContainer .column_brdr-right').removeClass('col-lg-5').addClass('col-lg-6');
            $('#tabAdvancedContainer .column_brdr-right').find(".col-xs-7").removeClass('col-xs-7').addClass('col-xs-3');
            $('#tabAdvancedContainer .column_brdr-right').find(".align-right.col-xs-5").removeClass('col-xs-5').addClass('col-xs-8').css("padding", "0");
        } else {
            $('#tabAdvancedContainer .column_brdr-right').removeClass('col-lg-6').addClass('col-lg-5');
            $('#tabAdvancedContainer .column_brdr-right').find(".col-xs-3").removeClass('col-xs-3').addClass('col-xs-7');
            $('#tabAdvancedContainer .column_brdr-right').find(".align-right.col-xs-8").removeClass('col-xs-8').addClass('col-xs-5').css("padding", "");
        }
        $("#Input_Control_49_442, #Input_Control_52_453").parent().parent().parent().prepend('<div class="col-xs-6 column_brdr-right col-lg-6"></div>');

        if (this.data[0].FieldGroupInfo[0].ControllerVersion == '3' && this.data[0].FieldGroupInfo[0].ControllerModelId == '10') {
            $('#Input_Control_55_462').parent().parent().hide();
            $('#Input_Control_55_463').parent().parent().addClass('clear');
        }

        if (this.metaData[0].message != "") {
            $("#errorDiv_msg").empty().removeClass('k-success-message').addClass('k-error-message').append(this.metaData[0].message);
        }

        $("input:checkbox[class='trackChange k-checkbox km-widget brdr_red']").each(function () {
            $('#' + $(this).attr("id")).parent().append("<span style='color:red' class='str' name='str'>*</span>");
        });


        $("input:checkbox[class='trackChange k-checkbox brdr_red km-widget']").parent().find('.km-switch-handle').addClass('brdr_red')

        $(".k-dropdown").each(function () {
            if ($('#' + $(this).attr("id")).hasClass('.brdr_red')) {
                $(this).parent().find('.k-dropdown-wrap').addClass("brdr_red");
            }
        });

        $(".k-dropdown.brdr_red").parent().find('.k-dropdown-wrap').addClass('brdr_red')

    },

    onMetaDataSaved: function () {
        $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully.'));
        if ($("#errorDiv_msg").hasClass('k-success-message')) {
            $(".btn-success").attr('disabled', 'disabled');
        }
        $('.new_tabs li.tab:eq(2)').not('.active').removeClass('disabled');
        $('.new_tabs li.tab:eq(2)').not('.active').find('a').attr("data-toggle", "tab");

        if ($("#Input_Control_22_248").data('kendoDropDownList') != undefined) {
            $("#Input_Control_22_248").data("kendoDropDownList").enable(false);
        }
        if ($("#Input_Control_22_253").data('kendoDropDownList') != undefined) {
            $("#Input_Control_22_253").data("kendoDropDownList").enable(false);
        }
        if ($("#Input_Control_22_258").data('kendoDropDownList') != undefined) {
            $("#Input_Control_22_258").data("kendoDropDownList").enable(false);
        }

        $('.brdr_red').removeClass('brdr_red');
        $('.str').empty();

        $(".trackChange.squaredFour").each(function () {
            $('#' + $(this).attr("id")).siblings().addClass('hide');
        });
    },

    onMetaDataSavedFailed: function (data, exception) {

        if (jQuery.type(exception) !== "object") {
            if (exception == "406") {
                $("#errorDiv_msg").empty().removeClass('k-success-message').addClass('k-error-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully,') + ',' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', 'Unable to connect to PLC.'));
                $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully.'));
                $("#statusMsg").empty().removeClass('k-success-message').addClass('k-error-message').append($.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', 'Unable to connect to PLC.'));
                $(".btn-success").attr('disabled', 'disabled');
            }
            else {
                $("#errorDiv_msg").empty().removeClass('k-success-message').addClass('k-error-message').append(exception);
            }
        } else {
            $('.new_tabs li.tab:eq(2)').not('.active').removeClass('disabled');
            $('.new_tabs li.tab:eq(2)').not('.active').find('a').attr("data-toggle", "tab");
            if (exception.status === 300) {
                $("#errorDiv_msg").empty().removeClass('k-success-message').addClass('k-error-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully,') + ',' + exception.message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXISTINTHEMACHINE', 'Tags already exists in the Machine.'));
                $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully.'));
                $("#statusMsg").empty().removeClass('k-success-message').addClass('k-error-message').append(exception.message + ' ' + $.GetLocaleKeyValue('FIELD_ALREADYEXISTINTHEMACHINE', 'Tags already exists in the Machine.'));
            } else if (exception.status === 400) {
                $("#errorDiv_msg").empty().removeClass("k-success-message").addClass("k-error-message").append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully,') + ',' + $.GetLocaleKeyValue("FIELD_HIGHISAREINVALID", "Tags Is / are invalid."));
                $("#errorDiv_msg").empty().removeClass("k-error-message").addClass("k-success-message").append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully.'));
                $("#statusMsg").empty().removeClass('k-success-message').addClass('k-error-message').append(exception.message + ' ' + $.GetLocaleKeyValue("FIELD_HIGHISAREINVALID", "Tags Is / are invalid."));
            } else if (exception.status === 406) {
                $("#errorDiv_msg").empty().removeClass('k-success-message').addClass('k-error-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully,') + ',' + $.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', 'Unable to connect to PLC.'));
                $("#errorDiv_msg").empty().removeClass('k-error-message').addClass('k-success-message').append($.GetLocaleKeyValue("FIELD_CONTROLLERUPDATEDSUCCESSFULLY", 'Controller saved successfully.'));
                $("#statusMsg").empty().removeClass('k-success-message').addClass('k-error-message').append($.GetLocaleKeyValue('FIELD_UNABLETOCONNECTTOPLC', 'Unable to connect to PLC.'));
                $("#btnSave").attr("disabled", "disabled");
                $('#btnSaveAndClose').attr("disabled", "disabled");
            }
        }
    },
    showMessage: function (message, isSuccess) {
        isSuccess ?
            $("#errorDiv_msg").removeClass('k-error-message').attr('class', 'k-success-message').html(message)
            : $("#errorDiv_msg").removeClass('k-success-message').attr('class', 'k-error-message').html(message);
    },
    getQueryStringByName: function (name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    checkInjectionClassValidation: function (count) {
        if (this.options.eventHandlers.checkInjectionClassValidation)
            var result = this.options.eventHandlers.checkInjectionClassValidation(count);

        if (result == true) {
            $('input[uniqueid=InjectionClasses]').parent().parent().parent().find('.k-error-message').empty().removeClass('k-success-message').addClass('k-error-message').append($.GetLocaleKeyValue('FIELD_CANNOTINCREASEDECREASEINJECTIONCLASSVALUE', 'Cannot increase/decrease Injection Class as it is already in use.'));
        }
    },
    DisableInjectionClass: function () {
        if (this.options.accountInfo.MaxLevel != 7) {
        var $ntb = $('input[uniqueid=InjectionClasses]').data("kendoNumericTextBox");
        //$ntb.attr('aria-disabled', true);
        $ntb.enable($ntb.element.is(':disabled'));
        //$('input[uniqueid=InjectionClasses]').attr('disabled', 'disabled');
    }
    }
};