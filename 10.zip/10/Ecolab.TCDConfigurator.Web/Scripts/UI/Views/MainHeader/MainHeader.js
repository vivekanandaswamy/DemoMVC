﻿Ecolab.Views.MainHeader = function (options) {
    var _this = this;

    var defaults = {
        eventHandlers: {
            logoutClicked: function () { },
            helpClicked: function () { },
            onRendered: function () { }
        },
        containerSelector: '#top-mainmenu-container',
        templateName: 'MainHeader'
    };

    this.settings = $.extend(defaults, options);

    //creating the template manager
    this.tm = new TemplateManager({
        templateName: 'MainHeader',
        templateUri: '/Scripts/UI/Views/MainHeader/MainHeader.html',
        parameters: [],
        containerElement: this.settings.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};

Ecolab.Views.MainHeader.prototype = {

    setData: function (accountInfo) {
        this.tm.Render(accountInfo, this);
        if (accountInfo != null && accountInfo.MenuSections != null) {
            if (accountInfo.MenuSections == null && accountInfo.MenuSections.length == 0) {
                $('#ulMissingFields').remove();
            }
        }
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.settings.containerSelector);
        $('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
        $('#top-mainmenu-container').find('.main-menu-item-' + this.tm.JsonData.SelectedMenuItem).addClass('active');
        container.find('.lnkPlant, .lnkMainMenu-Plant-Setup, .lnkCentralMainMenu-Home').click(function () {
            _this.onPlantSetupClicked();
        });

        container.find('.lnkController, .lnkMainMenu-Dispenser-Setup').click(function () {
            _this.onControllerSetupClicked();
        });


        container.find('.lnkStorage, .lnkMainMenu-Storage-Tanks').click(function () {
            _this.onStorageTanksClicked();
        });
        container.find('.lnkMainMenu-Home').click(function () {
            _this.onMainMenuHomeLinkClicked();
        });

        container.find('.lnkMainMenu-Dashboards').click(function () {
            _this.onMainMenuDashboardsLinkClicked();
        });

        container.find('.lnkProduction').click(function () {
            _this.onMainMenulnkProductionClicked();
        });

        container.find('.lnkChemical').click(function () {
            _this.onMainMenulnkChemicalLinkClicked();
        });

        container.find('.lnkMainMenu-Manual-Inputs').click(function () {
            _this.onManualInputLinkClicked();
        });

        container.find('.lnkWasher, .lnkMainMenu-Washer-Groups').click(function () {
            _this.onWasherGroupClicked();
        });

        $('#lnkMyProfile').click(function () {
            _this.onMyProfileClicked();
        });
        container.find('.lnkWashers, .lnkMainMenu-Washers').click(function () {
            _this.onWasherClicked();
        });

        $('#lnkAlarm').unbind('click');
        $('#lnkAlarm').click(function () {
            _this.onAlarmClicked();
        });

        $('.lnkMainMenu-Reports').unbind('click');
        $('.lnkMainMenu-Reports').click(function () {
            _this.onReportClicked();
        });

        $("#topnav .main-menu-item ul, .navbar-right-custom li ul").hover(function () {
            $(this).parent("li").addClass("hover");
        }, function () {
            $(this).parent("li").removeClass("hover");
        });
    },

    onRendered: function () {
        var _this = this;
        var container = $(this.settings.containerSelector);
        this.attachEvents();
    },

    onLogoutClicked: function () {
        if (this.settings.eventHandlers.logoutClicked)
            this.settings.eventHandlers.logoutClicked();
    },

    onMainMenuHomeLinkClicked: function () {
        if (this.settings.eventHandlers.mainMenuHomeLinkClicked)
            this.settings.eventHandlers.mainMenuHomeLinkClicked();
    },

    onMainMenuDashboardsLinkClicked: function () {
        if (this.settings.eventHandlers.mainMenuDashboardsLinkClicked)
            this.settings.eventHandlers.mainMenuDashboardsLinkClicked();
    },

    onPlantSetupClicked: function () {
        if (this.settings.eventHandlers.plantSetupClicked)
            this.settings.eventHandlers.plantSetupClicked();
    },

    onControllerSetupClicked: function () {
        if (this.settings.eventHandlers.controllerSetupClicked)
            this.settings.eventHandlers.controllerSetupClicked();
    },

    onMainMenulnkProductionClicked: function () {
        if (this.settings.eventHandlers.onMainMenulnkProductionClicked)
            this.settings.eventHandlers.onMainMenulnkProductionClicked();
    },

    onMainMenulnkChemicalLinkClicked: function () {
        if (this.settings.eventHandlers.onMainMenulnkChemicalLinkClicked)
            this.settings.eventHandlers.onMainMenulnkChemicalLinkClicked();
    },

    onManualInputLinkClicked: function () {
        if (this.settings.eventHandlers.onManualInputLinkClicked)
            this.settings.eventHandlers.onManualInputLinkClicked();
    },
    onWasherGroupClicked: function () {
        if (this.settings.eventHandlers.onWasherGroupClicked)
            this.settings.eventHandlers.onWasherGroupClicked();
    },
    onStorageTanksClicked: function () {
        if (this.settings.eventHandlers.storageTanksClicked)
            this.settings.eventHandlers.storageTanksClicked();
    },
    onMyProfileClicked: function () {
        if (this.settings.eventHandlers.myProfileClicked)
            this.settings.eventHandlers.myProfileClicked();
    },

    onAlarmClicked: function () {
        if (this.settings.eventHandlers.onAlarmClicked)
            this.settings.eventHandlers.onAlarmClicked();
    },
    onWasherClicked: function () {
        if (this.settings.eventHandlers.onWasherClicked)
            this.settings.eventHandlers.onWasherClicked();
    },

    onReportClicked: function () {
        if (this.settings.eventHandlers.onReportClicked)
            this.settings.eventHandlers.onReportClicked();
    },

};
