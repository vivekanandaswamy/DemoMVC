﻿Ecolab.Views.ControllerSetupList = function (options) {
	var defaults = {
		containerSelector: null,
		eventHandlers: {
			rendered: function () { },
			onRedirection: function () { },
		}
	};
	this.options = $.extend(defaults, options);
	var _this = this;
	this.data = null;

	this.tm = new TemplateManager({
		templateName: 'List',
		templateUri: './Scripts/UI/Views/ControllerSetupList/ControllerSetupList.html',
		parameters: [],
		containerElement: this.options.containerSelector,
		eventHandlers: { onRendered: function () { _this.onRendered(); } }
	});
	this.allowEdit = false;
};

Ecolab.Views.ControllerSetupList.prototype = {
	setData: function (data) {
		this.data = data;
		this.tm.Render(data, this);
	},

	/******************************************************************************************
    Event handling
    ******************************************************************************************/
	onRendered: function () {
		var _this = this;
		this.attachEvents();
		if (this.options.eventHandlers.rendered)
			this.options.eventHandlers.rendered();
		$('.grid-add-new-record').removeClass('k-button k-button-icontext');
		$('.grid-add-new-record').find('span').addClass('k-icon k-addbtn');

		if (_this.allowEdit && this.data.MaxLevel >= 6) {
			$('.grid-add-new-record').insertBefore("#controllerErrorDiv");
		}
		$(".k-grid-pager").find("a, ul").hide();

	},
	attachEvents: function () {
		var _this = this;
		_this.allowEdit = (this.data.MaxLevel != 5);
		_this.RegionId = (this.data.RegionId);
		var container = $(this.options.containerSelector);
		$('#top-mainmenu-container').find('.main-menu-item').removeClass('active');
		if (_this.data != null)
			$('#top-mainmenu-container').find('.main-menu-item-' + _this.data.SelectedMenuItem).addClass('active');
		// main - menu - item - ControllerSetupLists

		container.find('#btnControllerSetupListPrint').click(function () {
			var retVal = _this.options.eventHandlers.onRedirection(_this.data.PrintAction + "?page=" + _this.data.PageName);
			return retVal;
		});

		var dataSource = new kendo.data.DataSource({
			transport: {
				read: {
					url: "/api/ControllerSetup/GetControllerDetails",
					dataType: "json"
				},
				update: {
					url: "/api/ControllerSetup/UpdateControllerDetails",
					dataType: "json",
					type: "POST",
					complete: function (jqXhr, textStatus) {

						if (textStatus == 'success') {

							$("#gridControllerSetupList").data("kendoGrid").dataSource._destroyed = [];
							$("#gridControllerSetupList").data("kendoGrid").dataSource.read();
							$("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERUPDATEDSUCCESSFULLY" class="k-success-message">Dispenser updated successfully.</label>');
						}
						else if (textStatus == 'error') {
							if (jqXhr.responseText == '51030') {

								dataSource.cancelChanges();
								$("#controllerErrorDiv").html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">' + $.GetLocaleKeyValue("FIELD_RECORDSCOUNTDOESNTMATCH", "Record count does not match..Resynch is in progress.") + '</label>');
								$('#gridControllerSetupList').data('kendoGrid').refresh();

							} else if (jqXhr.responseText == '60000') {

								dataSource.cancelChanges();
								$("#controllerErrorDiv").html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">' + $.GetLocaleKeyValue("FIELD_RECORDSCOUNTDOESNTMATCH", "Record not in synch..Resynch is in progress..") + '</label>');
								$('#gridControllerSetupList').data('kendoGrid').refresh();
							}
							else if (jqXhr.responseText == '51060') {

							    dataSource.cancelChanges();
							    $("#controllerErrorDiv").html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue("FIELD_CONECTIVITYISSUE", "Unable to save changes , Connectivity issue, Please try again later.") + '</label>');
							    $('#gridControllerSetupList').data('kendoGrid').refresh();
							}

						}
						else {
							dataSource.cancelChanges();
							$("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERUPDATIONFAILED" class="k-error-message">Dispenser updation failed.</label>');
							$('#gridControllerSetupList').data('kendoGrid').refresh();
						}
					}

				},

				destroy: {
					url: "/api/ControllerSetup/DeleteController",
					dataType: "json",
					type: "DELETE",
					complete: function (jqXhr, textStatus) {
						if (textStatus == 'success') {
							$("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERDELETEDSUCCESSFULLY" class="k-success-message">Dispenser deleted successfully.</label>');
							$('#gridControllerSetupList').data('kendoGrid').refresh();
							_this.options.eventHandlers.loadNavigationMenuListView();
						}
						else if (textStatus == 'error') {
							if (jqXhr.responseText == '51030') {

								dataSource.cancelChanges();
								$("#controllerErrorDiv").html('<label data-localize ="FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">' + $.GetLocaleKeyValue("FIELD_RECORDSCOUNTDOESNTMATCH", "Record count does not match..Resynch is in progress.") + '</label>');
								$('#gridControllerSetupList').data('kendoGrid').refresh();

							} else if (jqXhr.responseText == '60000') {

								dataSource.cancelChanges();
								$("#controllerErrorDiv").html('<label data-localize ="FIELD_RECORDSNOTINSYNCH" class="k-error-message">' + $.GetLocaleKeyValue("FIELD_RECORDSCOUNTDOESNTMATCH", "Record not in synch..Resynch is in progress..") + '</label>');
								$('#gridControllerSetupList').data('kendoGrid').refresh();
							}
							else if (jqXhr.responseText == '51060') {

							    dataSource.cancelChanges();
							    $("#controllerErrorDiv").html('<label data-localize ="FIELD_CONECTIVITYISSUE" class="k-error-message">' + $.GetLocaleKeyValue("FIELD_CONECTIVITYISSUE", "Unable to save changes , Connectivity issue, Please try again later.") + '</label>');
							    $('#gridControllerSetupList').data('kendoGrid').refresh();
							}

						}
						else {
							dataSource.cancelChanges();
							$("#controllerErrorDiv").html('<label data-localize ="FIELD_CONTROLLERDELETIONFAILED" class="k-error-message">Dispenser deletion failed.</label>');
							$('#gridControllerSetupList').data('kendoGrid').refresh();
						}
					}
				},
				complete: function () {

				},

				error: function (e) {

					dataSource.cancelChanges();
					var error = '<div class= "errorMessageModal"><label>' + $.parseJSON(e.xhr.responseText) + '</label></div>';
					$("#controllerErrorDiv").html(error);
					$('#gridControllerSetupList').data('kendoGrid').refresh();

				},
			},



			pageSize: 50,
			schema: {
				model: {
					id: "ControllerId", // needed in edit button
					fields: {
						ControllerId: { editable: false, type: "number" },
						ControllerTypeId: { editable: false, type: "number" },
						ControllerNumber: { editable: false },
						TopicName: { editable: false },
						ControllerType: { editable: false },
						ControllerModelName: { editable: false },
						ControllerVersion: { editable: false },
						InstallDateAsString: { editable: true, type: "date" }
					}
				}
			}

		});
		var addNew;
		if (_this.allowEdit && this.data.MaxLevel < 6) {
			Command = [{ name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit }, { name: "Delete", text: " ", click: onDelete }, { name: "update", text: "", click: newWindow }];

		}
		else if (_this.allowEdit && this.data.MaxLevel >= 6) {
			addNew = [{ text: $.GetLocaleKeyValue("FIELD_ADDDISPENSER", "Add Dispenser"), className: "btn btn-sm btn-primary grid-add-new-record" }];
			Command = [{ name: "edit", text: { edit: "", cancel: "", update: "" }, click: onEdit }, { name: "Delete", text: " ", click: onDelete }, { name: "update", text: "", click: newWindow }];
		}
		else {
			Command = [{ name: "view", text: "", click: newWindow }];
		}

		function onDataBound(arg) {

			var colCount = $("#gridControllerSetupList").find('.k-grid-header colgroup > col').length;
			if (dataSource._view.length == 0) {
				$("#gridControllerSetupList").find('.k-grid-content tbody')
                    .append('<tr class="kendo-data-row"><td colspan="' +
                        colCount +
                        '" style="text-align:center"><b>Need To Add Dispenser!</b></td></tr>');
			}


			$('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
			$('.k-button-icontext.k-grid-Delete').find('span').addClass('k-icon k-delete');
			updatePaging(this);
		}

		function updatePaging(current) {
			current.pager.element.find("a, ul").hide();
			if (current.dataSource.totalPages() > 1) {
				current.pager.element.find("a, ul").show();
			}
			if (current.dataSource.view().length == 0) {
				var currentPage = current.dataSource.page();
				if (currentPage > 1) {
					current.dataSource.page(currentPage - 1);
					current.dataSource.sync();
					current.dataSource.read();
				}
			}
		}

		function clearStatusMessage() {
			$("#controllerErrorDiv").html('');
		}
		if (container.find('#gridControllerSetupList').data().kendoGrid)
			container.find('#gridControllerSetupList').data().kendoGrid.destroy();

		container.find("#gridControllerSetupList").kendoGrid({
			dataSource: dataSource,
			pageable: true,
			createAt: "top",
			sortable: {
				mode: "single",
				allowUnsort: false
			},
			dataBound: onDataBound,
			toolbar: addNew,
			columns: [
                { command: Command, attributes: { "class": "align-center" }, width: "78px" },
                { field: "ControllerNumber", title: "<span class='align-center' data-localize='FIELD_CONTROLLER_ControllerNumber'>Number</span>", attributes: { "class": "align-center" }, width: "100px" },
                { field: "TopicName", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "130px" },
                { field: "ControllerModelName", title: "<span data-localize='FIELD_CONTROLLER_ControllerModel'>Model</span>", width: "180px" },
                { field: "ControllerType", title: "<span data-localize='FIELD_CONTROLLERTYPE'>Type</span>", width: "150px" },
                { field: "InstallDateAsString", title: "<span data-localize='FIELD_CONTROLLER_InstallDate'>Install Date</span>", editor: dateTimeEditor, width: "160px", format: "{0:MM/dd/yyyy}" },
                { field: "", title: "", headerAttributes: { "class": "left-no_border" }, attributes: { "class": "left-no_border" } }
			],
			editable: "inline",
			cancel: function (e) {
				var dataSource = $("#gridControllerSetupList").data("kendoGrid").dataSource;
				grid.dataSource.read();
			}
		});

		grid = $("#gridControllerSetupList").data("kendoGrid");
		function onEdit() {
			clearStatusMessage();
			inlineEditSaveButton();
		}
		var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
		function createOverlay() {
			$("body").append('<div class="overlay_bg"></div>');
			$("#topnav, .leftmenu-container").addClass("blur");
			$(".k-animation-container").hide();
			$("#deleteDetails").parent(".k-window").addClass('deletepopup');
		}
		function removeOverlay() {
			$(".overlay_bg").hide();
			$("#topnav, .leftmenu-container").removeClass("blur");
			$("#deleteDetails").parent(".k-window").removeClass('deletepopup');
		}
		function onDelete(e) {
			createOverlay();
			clearStatusMessage();
			e.preventDefault();
			$("body").css("overflow-y", "hidden");
			var tr = $(e.target).closest("tr");
			var data = this.dataItem(tr);
			deletePopupTemplateWindow.content(deletePopupTemplate(data));
			deletePopupTemplateWindow.open().center();
			grid = $("#gridControllerSetupList").data("kendoGrid");
			grid.refresh();
			$(document).on('keyup', function (e) {
				if (e.which == 27) {
					$('#noButton').trigger('click');
				}
			});
			$("#yesButton").click(function () {
				grid.dataSource.remove(data);
				grid.saveChanges();
				deletePopupTemplateWindow.close();
				removeOverlay();
				$("body").css("overflow-y", "auto");
			})
			$("#noButton").click(function () {
				deletePopupTemplateWindow.close();
				removeOverlay();
				$("body").css("overflow-y", "auto");
			})
		}
		var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
			title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
			visible: false,
			width: "298px",
			height: "auto",
			animation: false,
			draggable: false,
			resizable: false,
		}).data("kendoWindow");

		$("#gridControllerSetupList a.grid-add-new-record").unbind("click");
		$("#gridControllerSetupList a.grid-add-new-record").on("click", function (e) {

			window.location.href = "./ControllerSetup";
		});


		function newWindow(e) {
			var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
			var controllerId = dataItem.ControllerId;
			var controllerTypeId = dataItem.ControllerTypeId;
			var controllerModelId = dataItem.ControllerModelId;
			window.location.href = "./ControllerSetup" + '?ControllerId=' + controllerId + '&ControllerTypeId=' + controllerTypeId + '&ControllerModelId=' + controllerModelId;
		}


		function dateTimeEditor(container, options) {

			var dtPicker = $('<input name="' + options.field + '"/>').appendTo(container)
			dtPicker.kendoDatePicker({
			});

			dtPicker.prop("readonly", true);

		}


	}



};