﻿Ecolab.Views.AddEditDryerGroup = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onAddDryerGroupClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AddEditDryerGroup',
        templateUri: './Scripts/UI/Views/Dryer/AddEditDryerGroup.html',
        paraShiftLabors: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }

    });
};
Ecolab.Views.AddEditDryerGroup.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    	$('#myModal').modal({
    		show: true,
    		backdrop: 'static',
    		keyboard: false
    	});
    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find('#btnSaveGroup').click(function () { _this.onAddDryerGroupClicked(); })

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },
    getDryerGroupData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        var dryerGroupModel = {};
        dryerGroupModel.Id = container.find("#txtDryerGroupName").attr("data-groupid");
        dryerGroupModel.Name = container.find("#txtDryerGroupName").val();
        dryerGroupModel.LastModifiedTimeStampDryerGroup = _this.data.LastModifiedTimeStampDryerGroup;
        return dryerGroupModel;
    },
    validateDryerGroup: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var v1 = container.find('#frmAddEditDryerGroup').validate({
            rules: {
                txtDryerGroupName: {
                    required: true,
                }
            },
            messages: {
                txtDryerGroupName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERDRYERGROUPNAME', "Please enter Dryer group name."),
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));
            }
        });

        var v2 = container.find('#frmAddEditDryerGroup').valid();
        return v2;
    },
    onAddDryerGroupClicked: function () {
        var _this = this;
        if (_this.validateDryerGroup()) {
            var dryerGroupData = _this.getDryerGroupData();
            if (dryerGroupData.Id > 0) {
                if (this.options.eventHandlers.onDryerGroupUpdateClicked)
                    this.options.eventHandlers.onDryerGroupUpdateClicked(_this.getDryerGroupData());
            }
            else {
                if (this.options.eventHandlers.onDryerGroupSaveClicked) {
                    this.options.eventHandlers.onDryerGroupSaveClicked(_this.getDryerGroupData());
                }
            }
        }
    },
}