﻿Ecolab.Views.AddEditDryer = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
            onAddDryerGroupClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AddEditDryer',
        templateUri: './Scripts/UI/Views/Dryer/AddEditDryer.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.AddEditDryer.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    	$('#myModal').modal({
    		show: true,
    		backdrop: 'static',
    		keyboard: false
    	});

        $(".custom-select").each(function () {
            if ($(this).is(":disabled")) {
                $(this).wrap("<span class='select-wrapper disabled'></span>");
            } else {
                $(this).wrap("<span class='select-wrapper'></span>");
            }
            var selectWth = $(this).parent().width();
            $(this).css("width", selectWth).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
        $(".custom-select").each(function () {
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        });
    },
    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
        container.find('#btnSaveDryer').click(function () {
            _this.clearStatusMessage();
            _this.onAddDryerClicked();
        });

        function centerModal() {
            $("#myModal").css('display', 'block');
            var $dialog = $("#myModal").find(".modal-dialog");
            var offset = ($(window).height() - $dialog.height()) / 2;
            // Center modal vertically in window
            $dialog.css("margin-top", offset);
        }

        $('.modal').on('show.bs.modal', centerModal);
        $(window).on("resize", function () {
            $('.modal:visible').each(centerModal);
        });
    },
    getDryerData: function () {
        var _this = this;
        var container = $(this.options.containerSelector);
        return {
            GroupId: container.find("#txtDryerNumber").attr("data-groupid"),
            Id: container.find("#txtDryerNumber").attr("data-id"),
            Number: container.find("#txtDryerNumber").val(),
            Name: container.find("#txtDryerName").val(),
            Nominalload: container.find("#txtDryerNominalLoad").val(),
            ConvertedNominalload: container.find("#txtDryerNominalLoad").val(),
            DryerType: {
                Id: container.find("#ddlDryerType").val()
            },
            LastModifiedTimeStampDryer: _this.data.LastModifiedTimeStampDryer
        };
    },
    validateDryer: function () {
        _this = this;
        _this.clearStatusMessage();
        var container = $(this.options.containerSelector);
        var decimalPattern = /^.[0-9]{0,11}(?:\.[0-9]{1,9})?$/;
        var numberPattern = '^[0-9]*$';

        $.validator.addMethod(
            "regex",
            function (value, element, regexp) {
                var check = false;
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            $.GetLocaleKeyValue('FIELD_PLEASECHECKYOURINPUT', "Please check your input.")
        );

        var v1 = container.find('#frmAddEditDryer').validate({
            rules: {
                txtDryerNumber: {
                    required: true,
                    regex: numberPattern
                },
                txtDryerName: {
                    required: true,
                },
                ddlDryerType: {
                    required: true,
                },
                txtDryerNominalLoad: {
                    required: true,
                    regex: decimalPattern
                }

            },
            messages: {
                txtDryerNumber: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERDRYERNUMBER', "Please enter Dryer number."),
                    regex: $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', "Enter only numerics")
                },
                txtDryerName: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERDRYERNAME', "Please enter Dryer name."),
                },
                ddlDryerType: {
                    required: "Please enter dryer type",
                },
                txtDryerNominalLoad: {
                    required: $.GetLocaleKeyValue('FIELD_PLEASEENTERNOMINALLOAD', "Please enter nominal load."),
                    regex: $.GetLocaleKeyValue('FIELD_ENTERONLYNUMERICS', "Enter only numerics.")
                }
            },
            onfocusout: function (element) {
                if (!this.checkable(element)) {
                    this.element(element);
                }
            },
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().find("span.errorMsg"));

                if (element.hasClass('txtEditNominalLoad')) {
                    error.appendTo(element.parent().next('span.errorMsg'));
                }
                if (element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select")) {
                    error.appendTo(element.parent().parent().find("span.errorMsg"));
                }
                if (element.hasClass("custom-select") || element.parent().hasClass("input-group")) {
                    error.appendTo(element.parent().parent().next("span.errorMsg"));
                }
            }

        });

        var v2 = container.find('#frmAddEditDryer').valid();
        return v2;
    },
    onAddDryerClicked: function () {
        var _this = this;
        if (_this.validateDryer()) {
            var dryerData = _this.getDryerData();
            if (dryerData.Id > 0) {
                if (this.options.eventHandlers.onDryerUpdateClicked)
                    this.options.eventHandlers.onDryerUpdateClicked(_this.getDryerData());
            } else {
                if (this.options.eventHandlers.onDryerSaveClicked) {
                    this.options.eventHandlers.onDryerSaveClicked(_this.getDryerData());
                }
            }
        }
    },
    clearStatusMessage: function () {
        $("#dryerErrorMsg").html('');
    }
};