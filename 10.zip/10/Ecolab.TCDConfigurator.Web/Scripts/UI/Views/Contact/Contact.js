Ecolab.Views.Contact = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/Contact/ContactList.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.positionData = null;
    this.allowEdit = false;
    this.isContactDelete = false;
};

Ecolab.Views.Contact.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        //this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
        //var messageLeft = $(".k-grid-toolbar .btn-primary").width() + 42;
        //$("#errorDiv").css("margin-left", messageLeft);
        $('.grid-add-new-record').insertBefore("#errorDiv");
        $(".k-grid-pager").find("a, ul").hide();        
    },
    setPositionData: function (data) {
        var _this = this;
        this.positionData = data;
        this.attachEvents();      
    },
    Save: function () {
       var grid = $("#gridContact").data("kendoGrid");
        grid.saveChanges();
    },
    SetIsDirty: function (flage) {
        if (this.options.eventHandlers.setIsDirty)
            this.options.eventHandlers.setIsDirty(flage);
    },
    onCancel: function () {
        if (this.options.eventHandlers.onRedirection)
            this.options.eventHandlers.onRedirection("/Contact");
        
    },
    attachEvents: function () {
        $("#tabGeneralContainer").addClass("active");
        $("#tabGeneral").parent("li").addClass("active");

        var _this = this;
        _this.allowEdit = (this.data.MaxLevel >= 6);
        var container = $(this.options.containerSelector);

        var dataSource = new kendo.data.DataSource({
            transport: {
                read: {
                    url: "/api/Contact/GetContact",
                    dataType: "json",
                },
                create: {
                    url: "/api/Contact/CreateContact",
                    dataType: "json",
                    contentType: "application/json",
                    type: "POST",
                    beforeSend: function (jqXhr, textStatus) {
                        kendo.ui.progress($('body'), true);
                    },
                    complete: function (jqXhr, textStatus) {
                        kendo.ui.progress($('body'), false);
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTADDEDSUCCESSFULLY" class="k-success-message">Contact added successfully.</label>');
                        }
                        else if (textStatus == 'error') {
                            if (jqXhr.responseText == '51030') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match.</label>');
                            }
                            else if (jqXhr.responseText == '60000') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            }
                            else if (jqXhr.responseText == '51060') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            }
                        }
                        else {
                            var code
                            if (jqXhr.responseText.indexOf('-') > -1) {
                                code = JSON.parse(jqXhr.responseText).split('-')[0].trim();
                            }
                            if (code == '303') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label class="k-error-message" > Email address already exist </label>');
                               
                            }
                            else {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize ="FIELD_CONTACTADDITIONFAILED" class="k-error-message">Contact addition failed.</label>');
                            }
                        }
                   
                        _this.tm.Localize();
                        if (grid && grid.dataSource) {
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                    }
                },
                update: {
                    url: "/api/Contact/Put",
                    dataType: "json",
                    contentType: "application/json",
                    type: "PUT",
                    beforeSend: function (jqXhr, textStatus) {
                        kendo.ui.progress($('body'), true);
                    },
                    complete: function (jqXhr, textStatus) {
                        kendo.ui.progress($('body'), false);
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTUPDATEDSUCCESSFULLY" class="k-success-message">Contact updated successfully.</label>');
                             $("#btnSave").attr("disabled", "disabled");
                             $("#btnCancel1").attr("disabled", "disabled");
                             _this.SetIsDirty(false);
                        }
                        else if (textStatus == 'error') {
                            if (jqXhr.responseText == '51030') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match.</label>');
                            }
                            else if (jqXhr.responseText == '60000') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            }
                            else if (jqXhr.responseText == '51060') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            }
                        }
                        else {
                            var code
                            if (jqXhr.responseText.indexOf('-') > -1) {
                                code = JSON.parse(jqXhr.responseText).split('-')[0].trim();
                            }
                            if (code == '303') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label class="k-error-message" > Email address already exist </label>');
                            }
                            else {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize ="FIELD_CONTACTUPDATIONFAILED" class="k-error-message">Contact updation failed.</label>');
                            }
                        }
                        _this.tm.Localize();
                        if (grid && grid.dataSource) {
                            grid.dataSource._destroyed = [];
                            grid.dataSource.read();
                        }
                    }
                },
                destroy: {
                    url: "/api/Contact/DeleteContact",
                    dataType: "json",
                    contentType: "application/json",
                    type: "DELETE",
                    beforeSend: function (jqXhr, textStatus) {
                        kendo.ui.progress($('body'), true);
                    },
                    complete: function (jqXhr, textStatus) {
                        kendo.ui.progress($('body'), false);
                        if (textStatus == 'success') {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTDELETEDSUCCESSFULLY" class="k-success-message">Contact deleted successfully.</label>');
                        }
                        else if (textStatus == 'error') {
                            if (jqXhr.responseText == '51030') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_RECORDSCOUNTDOESNTMATCH" class="k-error-message">Record count does not match.</label>');
                            }
                            else if (jqXhr.responseText == '60000') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_RECORDSNOTINSYNCH" class="k-error-message">Record not in synch..Resynch is in progress.</label>');
                            }
                            else if (jqXhr.responseText == '51060') {
                                dataSource.cancelChanges();
                                $("#errorDiv").html('<label data-localize = "FIELD_CONECTIVITYISSUE" class="k-error-message">Unable to save changes , Connectivity issue, Please try again later.</label>');
                            }
                        }
                        else {
                            $("#errorDiv").html('<label data-localize ="FIELD_CONTACTDELETIONFAILED" class="k-error-message">Contact deletion failed.</label>');
                        }
                        _this.tm.Localize();
                    }
                },
                parameterMap: function (data, type) {
                    if (type == "update" || type == "create" || type == "destroy") {
                        return kendo.stringify(data.models);
                    }
                }
            },
            error: function (e) {
                kendo.ui.progress($('body'), false);
                var code
                if (e.xhr.responseText.indexOf('-') > -1) {
                    code = JSON.parse(e.xhr.responseText).split('-')[0].trim();
                }
                if (code == '303') {
                    dataSource.cancelChanges();
                    $("#errorDiv").html('<label class="k-error-message" > Email address already exist </label>');
                } else {
                    $("#errorDiv").html('<label class="k-error-message">' + e.xhr.responseText + '</label>');
                }
            },
            pageSize: 50,
            batch: true,
            schema: {
                model: {
                    id: "Id",
                    fields: {
                        Id: { editable: false, type: "number" },
                        ContactFirstName: {},
                        ContactLastName: {},
                        ContactTitle: {},
                        Name: { editable: false },
                        ContactEmailAdresss: {
                            editable: true
                            //validation: {
                            //    required: true,
                            //    contactemailadresss: function (input) {                                    
                            //        if (input.is("[name='ContactEmailAdresss']") && input.val() != "") {
                            //            input.attr("data-contactemailadresss-msg", "Incorrect email Address");
                            //            return /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(input.val());
                            //        }
                            //        return true;
                            //    }
                            //}
                        },
                        ContactOfficePhone: { type: "text", spinners: false },
                        ContactMobilePhone: {
                            type: "text", validation: {
                                maxlength: function (input) {
                                    if (input.is("[name='ContactFirstName']") || input.is("[name='ContactPosition']") || input.is("[name='ContactTitle']") || input.is("[name='ContactLastName']")) {
                                        if (input.val().trim() == "") {
                                            return false;
                                        }
                                        else {
                                            return true;
                                        }
                                    }
                                    return true;
                                },
                            },
                        }
                    }
                }
            }
        });
        var addNew;
        if (_this.allowEdit) {
            addNew = [{ text: "<span data-localize='FIELD_ADDCONTACT'>Add Contact</span>", className: "btn btn-sm btn-primary grid-add-new-record" }];
            Command = [
                //define the commands here
                { name: "Delete", text: " ", click: onDelete }, { name: "update", text: " ", click: showDetails }]
        }
        else {
            Command = [{ name: "view", text: "", click: showDetails }];
        }

        function onDataBound(arg) {
          
            $('.k-button-icontext.k-grid-view').find('span').addClass('k-icon k-custom-view');
            $('.k-button-icontext.k-grid-Delete').find('span').addClass('k-icon k-delete');
            _this.tm.Localize();
            updatePaging(this);

            var rows = this.tbody.children();
            var dataItems = this.dataSource.view();
            for (var i = 0; i < dataItems.length; i++) {
                kendo.bind(rows[i], dataItems[i]);             
            }           
            $('[name=ContactPositionNameDropDown_]').kendoComboBox({
                autoBind: false,
                dataSource: _this.positionData,               
                change: function (e) {
                    var dataItem = e.sender.dataItem();
                    // options.model.set("ContactPositionName", dataItem.PositionName);
                    //options.model.set("ContactPositionId", dataItem.Id);
                    $("#btnSave").removeAttr("disabled");
                    $("#btnCancel1").removeAttr("disabled");
                    _this.SetIsDirty( true);
                }
            });
            $('.grid-add-new-record').removeClass('k-button k-button-icontext');
            $('.grid-add-new-record').find('span:first').addClass('k-icon k-addbtn');
            $('.grid-add-new-record').insertBefore("#errorDiv");
            $(".k-grid-pager").find("a, ul").hide();
        }

        function updatePaging(current) {
            current.pager.element.find("a, ul").hide();
            if (current.dataSource.totalPages() > 1) {
                current.pager.element.find("a, ul").show();
            }
            if (current.dataSource.view().length == 0) {
                var currentPage = current.dataSource.page();
                if (currentPage > 1) {
                    current.dataSource.page(currentPage - 1);
                    current.dataSource.sync();
                    current.dataSource.read();
                }
            }
        }

        if (container.find('#gridContact').data().kendoGrid)
            container.find('#gridContact').data().kendoGrid.destroy();

        container.find("#gridContact").kendoGrid({            
            dataSource: dataSource,
            pageable: true,
            createAt: "top",
            sortable: {
                mode: "single",
                allowUnsort: false
            },
            dataBound: onDataBound,
            toolbar: addNew,

            columns: [
            { command: Command, width: "90px", attributes: { "class": "align-center" } },
            {
                field: "ContactFirstName", template: "#: ContactLastName #, #: ContactFirstName #", title: "<span data-localize='FIELD_NAME'>Name</span>", width: "15%",
                editor: function (container, options) { container.append(options.model.ContactLastName + ', ' + options.model.ContactFirstName); },
                
            },
            {
                field: "ContactPositionId", title: "<span data-localize='FIELD_POSITION'>Position</span>", width: "20%",
                template: function (data) {
                    if (_this.allowEdit) {
                        return '<input class="trackChange" style="width:100%"  id="ContactPositionNameDropDown_#' +data.ContactPositionId + '" name="ContactPositionNameDropDown_" data-text-field="PositionName" data-value-field="Id" data-role="combobox" data-bind="value:ContactPositionId"/>';
                    }
                    else
                    {
                        return data.ContactPositionName;
                    }
                }
            },
            {
                field: "ContactOfficePhone", title: "<span data-localize='FIELD_OFFICEPHONE'>Office Phone</span>", format: "{0:0}",
                headerAttributes: { "class": "align-right" }, attributes: { "class": "align-right" }, width: "12%",
                template: function (data) {
                    var nameAndId = 'ContactOfficePhone_' + data.Id;
                    if (_this.allowEdit)
                        return '<input type="text" class="k-input k-textbox trackChange" style="width:100%" name="' + nameAndId + '" value="' + data.ContactOfficePhone + '" data-bind="value:ContactOfficePhone" id="' + nameAndId + '">';
                    else
                        return data.ContactOfficePhone
                }
            },
            {
                field: "ContactMobilePhone", title: "<span data-localize='FIELD_MOBILEPHONE'>Mobile Phone</span>", format: "{0:0}",
                headerAttributes: { "class": "align-right" }, attributes: { "class": "align-right" }, width: "12%",
                template: function (data) {
                    var nameAndId = 'ContactMobilePhone_' + data.Id;
                    if (_this.allowEdit)
                        return '<input type="text" class="k-input k-textbox trackChange" style="width:100%" name="' + nameAndId + '" value="' + data.ContactMobilePhone + '" data-bind="value:ContactMobilePhone" id="' + nameAndId + '">'
                    else
                        return data.ContactMobilePhone
                }
            },
            {
                field: "ContactEmailAdresss", title: "<span data-localize='FIELD_EMAIL'>E-mail</span>",
                template: function (data) {
                    var nameAndId = 'ContactEmailAdresss_' + data.Id;
                    if (_this.allowEdit)
                        return '<input type="text" class="k-input k-textbox trackChange" style="width:100%" name="' + nameAndId + '" value="' + data.ContactEmailAdresss + '" data-bind="value:ContactEmailAdresss" id="' + nameAndId + '">'
                    else
                        return data.ContactEmailAdresss;
                }
            },
            {
                field: "", title: "", headerAttributes: { "class": "left-no_border" }, attributes: { "class": "left-no_border" }, width: "12%",                
            }
            ],          
            editable: "inline",
            cancel: function (e) {
                var dataSource = $("#gridContact").data("kendoGrid").dataSource;
                var grid = $("#gridContact").data("kendoGrid");
                grid.dataSource.read();
            }
        });

        $('#btnSave').click(function () {          
            if (_this.validate())
            _this.Save();
        });
        $("#btnCancel1").click(function () {
            _this.onCancel();
        });

        grid = $("#gridContact").data("kendoGrid");

        function onEdit() {
            clearStatusMessage();
            inlineEditSaveButton();
        }
        var deletePopupTemplate = kendo.template($("#deletePopupTemplate").html());
        function createOverlay() {
            $("body").append('<div class="overlay_bg"></div>');
            $("#topnav, .leftmenu-container").addClass("blur");
            $(".k-animation-container").hide();
            $("#deleteDetails").parent(".k-window").addClass('deletepopup');
        }
        function removeOverlay() {
            $(".overlay_bg").hide();
            $("#topnav, .leftmenu-container").removeClass("blur");
            $("#deleteDetails").parent(".k-window").removeClass('deletepopup');
        }
        function onDelete(e) {
            if (_this.isContactDelete == false) {
                _this.isContactDelete = true;
                var detailsTemplate = kendo.template($("#editContact").html());
                var data = this;
                var noEdits = _this.options.eventHandlers.onSaveChangesContact(data, e, wnd, detailsTemplate, _this, false);
            }
            else if (_this.isContactDelete == true) {
                _this.isContactDelete = false;
                createOverlay();
                clearStatusMessage();
                e.preventDefault();
                $("body").css("overflow-y", "hidden");
                var tr = $(e.target).closest("tr");
                var data = this.dataItem(tr);
                deletePopupTemplateWindow.content(deletePopupTemplate(data));
                deletePopupTemplateWindow.open().center();
                grid = $("#gridContact").data("kendoGrid");
                grid.refresh();
                $(document).on('keyup', function (e) {
                    if (e.which == 27) {
                        $('#noButton').trigger('click');
                    }
                });
                $("#yesButton").click(function () {
                    grid.dataSource.remove(data);
                    grid.saveChanges();
                    deletePopupTemplateWindow.close();
                    removeOverlay();
                    $("body").css("overflow-y", "auto");
                })
                $("#noButton").click(function () {
                    deletePopupTemplateWindow.close();
                    removeOverlay();
                    $("body").css("overflow-y", "auto");
                })
            }
        }
        var deletePopupTemplateWindow = $("#deleteDetails").kendoWindow({
            title: $.GetLocaleKeyValue('FIELD_CONFIRMATIONREQUIRED', 'Confirmation Required'),
            visible: false,
            width: "298px",
            height: "auto",
            animation: false,
            draggable: false,
            resizable: false,
        }).data("kendoWindow");

        wnd = $("#details")
                       .kendoWindow({
                           title: $.GetLocaleKeyValue("FIELD_EDITCONTACT", 'Edit Contact'),
                           modal: true,
                           visible: false,
                           draggable: false,
                           resizable: false,
                           width: "373px",
                           height: "auto",
                           open: function () {
                               $("#topnav, .leftmenu-container").addClass("blur");
                               $(".k-tooltip").parent(".k-animation-container").hide();
                               $("body").css("overflow-y", "hidden");
                           },
                           close: function () {
                               $("#topnav, .leftmenu-container").removeClass("blur");
                               $("body").css("overflow-y", "auto");
                           },
                           activate: function (e) {
                               _this.tm.Localize();
                           }
                       }).data("kendoWindow").center();
        detailsTemplate = kendo.template($("#editContact").html());

        function showDetails(e) {
            clearStatusMessage();

            var detailsTemplate = kendo.template($("#editContact").html());
            var data = this;
            var noEdits = _this.options.eventHandlers.onSaveChangesContact(data, e, wnd, detailsTemplate, _this, true);
            if (noEdits) {
                e.preventDefault();
                var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
                dataItem.PositionData = _this.positionData;
                wnd.content(detailsTemplate(dataItem));
                wnd.center().open();
                this.dataSource.cancelChanges();
            }
        }
        $(".editRowPopup").unbind("click");
        $(document).on("click", ".editRowPopup", function () {
            var validator = $(wnd.element).kendoValidator().data("kendoValidator")
            var uid = eval($(".uid").attr("id"));
            if (validator.validate()) {
                dataSource.fetch(function () {
                    var Contact = dataSource.get(uid);
                    Contact.set("ContactFirstName", $("#txtContactFirstName").val().trim());
                    Contact.set("ContactTitle", $("#ddlContactTitleEdit").val().trim());
                    Contact.set("ContactLastName", $("#txtContactLastName").val().trim());
                    Contact.set("ContactPositionId", $("#ddlPosition").val().trim());
                    Contact.set("ContactPositionName", $("#ddlPosition option:selected").text().trim());
                    Contact.set("ContactEmailAdresss", $("#txtContactEmailAdresss").val().trim());
                    Contact.set("ContactOfficePhone", $("#txtContactOfficePhone").val().trim());
                    Contact.set("ContactMobilePhone", $("#txtContactMobilePhone").val().trim());
                    Contact.set("ContactFaxNumber", $("#txtContactFaxNumber").val().trim());
                    // dataSource.sync();
                });
                grid = $("#gridContact").data("kendoGrid");
                grid.saveChanges();
                wnd.close();
            }
            else {
                return false;
            }
        });
        $(".cancelRowPopup").unbind("click");
        $(document).on("click", ".cancelRowPopup", function () {
            wnd.close();
        });

        var grid;
        $("#gridContact a.grid-add-new-record").unbind("click");
        $("#gridContact a.grid-add-new-record").on("click", function (e) {
            clearStatusMessage();
            e.preventDefault();
            var dataSource = $("#gridContact").data("kendoGrid").dataSource;
            dataSource.cancelChanges();
            var window = $("<div id='popupEditor'>")
                .appendTo($("body"))
                .kendoWindow({
                    title: $.GetLocaleKeyValue("FIELD_ADDCONTACT", 'Add Contact'),
                    modal: true,
                    resizable: false,
                    visible: false,
                    draggable: false,
                    width: "373px",
                    height: "auto",
                    open: function () {
                        $("#topnav, .leftmenu-container").addClass("blur");
                        $("body").css("overflow-y", "hidden");
                    },
                    close: onClose,
                    activate: function (e) {
                        _this.tm.Localize();
                    }
                    //content: {
                    //    //sets window template

                    //    template: kendo.template($("#newContact").html())
                    //}
                })
                .data("kendoWindow").center().open();

            var index = dataSource.indexOf((dataSource.view() || [])[0]);
            if (index < 0) {
                index = 0;
            }
            //insets a new model in the dataSource
            var model = dataSource.insert(index, {});
            var data = {};
            data.PositionData = _this.positionData;
            detailsTemplate1 = kendo.template($("#newContact").html());
            window.content(detailsTemplate1(data));
            //binds the editing window to the form
            kendo.bind(window.element, model);
            window.center();
            //initialize the validator
            var validator = $(window.element).kendoValidator().data("kendoValidator")
            $("#btnUpdate").unbind("click");
            $("#btnUpdate").on("click", function (e) {
                if (validator.validate() == true) {
                    var contactIndex = dataSource._data.length;
                    var contact = {};
                    contact.ContactPositionId = $("#ddlPositionNew").val();
                    contact.ContactTitle = $("#ddlContactTitle").val();
                    contact.ContactFirstName = $("#ContactFirstName").val();
                    contact.ContactLastName = $("#ContactLastName").val();
                    contact.ContactPositionName = $("#ddlPositionNew option:selected").text();
                    contact.ContactEmailAdresss = $("#ConatctEmailAddress").val();
                    contact.ContactOfficePhone = $("#ContactOfficePhone").val();
                    contact.ContactMobilePhone = $("#ContactMobilePhone").val();
                    contact.ContactFaxNumber = $("#ContactFaxNumber").val();
                    grid.dataSource.cancelChanges();
                    grid.dataSource.insert(contactIndex, contact);
                    grid.saveChanges();
                    dataSource.page(1);
                    window.close();
                    window.element.remove();
                }
                else {
                    return false;
                }
            });
            $("#btnCancel").unbind("click");
            $("#btnCancel").on("click", function (e) {
                dataSource.cancelChanges(model); //cancel changes
                window.close();
                window.element.remove();
            });
            function onClose(e) {
                dataSource.cancelChanges(model); //cancel changes
                window.element.remove();
                $("#topnav, .leftmenu-container").removeClass("blur");
                $("body").css("overflow-y", "auto");
            }
        });
        function clearStatusMessage() {
            $("#errorDiv").html('');
        }
        function positionDropDownEditor(container, options) {
            $('<input required data-text-field="PositionName" data-value-field="Id" data-bind="value:' + options.field + '"/>')
         .appendTo(container)
         .kendoComboBox({
             autoBind: false,
             dataSource: _this.positionData,
             change: function (e) {
                 var dataItem = e.sender.dataItem();
                 options.model.set("ContactPositionName", dataItem.PositionName);
                 options.model.set("ContactPositionId", dataItem.Id);
             }
         });
        }
        $.validator.addMethod(
                "email",
                function (value, element, regexp) {
                    if ($(element).val() != '')
                        return /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test($(element).val())
                    else
                        return true;
                },
                $.GetLocaleKeyValue('FIELD_INVALIDEMAIL', 'Please enter valid Email address.')
        );
        $.validator.addMethod(
                "number",
                function (value, element, regexp) {
                    if ($(element).val() != '')
                        return /^[0-9]*$/.test($(element).val());
                    else
                        return true;
                },
                $.GetLocaleKeyValue('FIELD_ENTERNUMBER', 'Please enter numbers.')
        );
    },
    validate: function () {
        
        var v2 = $('#contactForm').valid();
        return v2;
    }
};