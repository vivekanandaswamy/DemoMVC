Ecolab.Views.LaborCost = function (options) {
    var defaults = {
        containerSelector: null,
        eventHandlers: {
            rendered: null,
            onSaveClicked: null
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.data = null;

    this.tm = new TemplateManager({
        templateName: 'List',
        templateUri: './Scripts/UI/Views/LaborCost/LaborCost.html',
        parameters: [],
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
    this.allowEdit = false;
};

$(".trackChange").live("keydown change click", function () {
    $(".buttonTrack").prop('disabled', false);
    $('#btnCancel').prop('disabled', false);
});

Ecolab.Views.LaborCost.prototype = {
    setData: function (data) {
        this.data = data;
        data.accountInfo = this.options.accountInfo;
        this.tm.Render(data, this);
    },

    /******************************************************************************************
    Event handling
    ******************************************************************************************/
    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(this.options.containerSelector);

        $("#tabGeneralContainer").addClass("active");
        $("#tabGeneral").parent("li").addClass("active");
        $('.tabLaborCost').addClass('active');
        _this.allowEdit = (this.data.MaxLevel >= 6);

        //Event for updating data
        container.find(".btnSave").click(function () {
            //Fetch prod data values
            _this.onSaveClicked();
        });

        //Event when cancel button clicked
        container.find(".btnCancel").click(function () {
            _this.CancelClicked();
        });
    },

    CancelClicked: function () {
        var retVal = this.options.eventHandlers.onRedirection('/PlantSetup');
        return retVal;
    },

    validate: function () {
        _this = this
        var container = $(this.options.containerSelector);
        var pattern1 = /^[0-9]+(\.[0-9]{0,9}?)?$/;
        $.validator.addMethod(
               "regex",
               function (value, element, regexp) {
                   var check = false;
                   var re = new RegExp(regexp);
                   return this.optional(element) || re.test(value);
               },
               "Please check your input."
       );

        var v1 = container.find('#frmLaborCost').validate({
            onsubmit: true,
            onkeyup: false,
            focusInvalid: false,
            errorPlacement: function (error, element) {
                error.appendTo(element.parent().parent().find("span.k-error-message"));
            }
        });

        container.find("input.laborCost").each(function () {
            $(this).rules('add', {
                required: true,
                regex: pattern1,
                messages: {
                    required: "Please enter labor cost.",
                    regex: "*"
                }
            });
        });

        var v2 = container.find('#frmLaborCost').valid();
        return v2;
    },

    clearMessage: function () {
        var container = $(this.options.containerSelector);
        container.find('#successMsg').html('');
    },
    showMessage: function (message) {
        var _this = this;
        var container = $(this.options.containerSelector);
        _this.clearMessage();
        var errLabel = '';
        switch (message) {
            case "201":
                errLabel = '<label class="k-success-message">' + $.GetLocaleKeyValue('FIELD_SAVEDSUCCESSFULLY', 'Saved successfully.') + '</label>';
                break;
            case "501":
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save failed.') + '</label>';
                break;
            case "51030":
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSCOUNTDOESNTMATCH', 'Record count does not match..Resynch is in progress.') + '</label>';
                break;
            case "51060":
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_CONECTIVITYISSUE', 'Unable to save changes , Connectivity issue, Please try again later.') + '</label>';
                break;
            case "60000":
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_RECORDSNOTINSYNCH', 'Record not in synch..Resynch is in progress.') + '</label>';
                break;
            default:
                errLabel = '<label class="k-error-message">' + $.GetLocaleKeyValue('FIELD_SAVEFAILED', 'Save failed.') + '</label>';
                break;
        }
        var messageDiv = container.find('#successMsg');
        messageDiv.html(errLabel);
    },

    onSaveClicked: function () {
        var _this = this;
        this.clearMessage();
        if (this.options.eventHandlers.onSaveClicked) {
            if (_this.validate() == true) {
                this.options.eventHandlers.onSaveClicked(this.getNewData());
            }
            
        }
    },
    getNewData: function () {
        var _this = this.data;
        var container = $(this.options.containerSelector);
        var laborCostViewModel = {};
        var laborCostModel = [];
        var content = container.find("tr.laborCost");
        for (var i = 0; i < content.length ; i++) {
            var objLaborCostModel = {};
            objLaborCostModel.LaborTypeId = $(content[i]).data('labortypeid');
            objLaborCostModel.Cost = $(content[i]).find('input').val();
            objLaborCostModel.LastModifiedTimeStamp = _this[i].LastModifiedTimeStamp;
            laborCostModel.push(objLaborCostModel);
        }
        laborCostViewModel.LaborCostModel = laborCostModel;
        return laborCostModel;
    }
};