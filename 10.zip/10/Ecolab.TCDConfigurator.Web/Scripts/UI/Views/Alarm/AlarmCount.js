﻿Ecolab.Views.AlarmCount = function (options) {
    var defaults = {
        containerSelector: null,
        accountInfo: null,
        eventHandlers: {
            rendered: null,
        }
    };
    this.options = $.extend(defaults, options);
    var _this = this;
    this.tm = new TemplateManager({
        templateName: 'AlarmCount',
        templateUri: '/Scripts/UI/Views/Alarm/AlarmCount.html',
        containerElement: this.options.containerSelector,
        eventHandlers: { onRendered: function () { _this.onRendered(); } }
    });
};
Ecolab.Views.AlarmCount.prototype = {
    setData: function (data) {
        this.data = data;
        this.tm.Render(data, this);
    },

    onRendered: function () {
        var _this = this;
        this.attachEvents();
        if (this.options.eventHandlers.rendered)
            this.options.eventHandlers.rendered();
    },

    attachEvents: function () {
        var _this = this;
        var container = $(_this.options.containerSelector);
    },
}