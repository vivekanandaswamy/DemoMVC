﻿;
Ecolab.Model.Common = function () {
    this.APIMethods = {
        GET: "GET",
        PUT: "PUT",
        POST: "POST",
        DELETE: "DELETE"
    };
};

Ecolab.Model.Common.registerErrorCallBack = function (errorCallback) {
    Ecolab.Model.Common.onServerRequestError = errorCallback;
}

Ecolab.Model.Common.prototype = {
    //TODO:set server url
    //The base url for server requests 
    ServerRequestBaseUrl: '',

    //TODO: get proxyoptions

    proxyOptions: window.proxyOptions,

    /// <summary>
    /// This method is used for all server requests by the model classes
    /// </summary>
    /// <param name="servicePath">The path for the controller (will be appeneded to the ServerRequestBaseUrl)</param>
    /// <param name="callbackMethod">A method to call if the server request is sucessfull</param>
    /// <param name="errorCallbackMethod">A method to call if the server request failed</param>
    /// <param name="callbackData">Data to send with the call back method</param>
    /// <param name="requestData">The data to send in the request body</param>
    /// <returns>return</returns>

    addTimeZoneOffset: function (o, localoffset) {
        var _this = this;
        for (i in o) {
            if (Object.prototype.toString.call(o[i]) === '[object Date]') {
                o[i] = o[i].add("s", localoffset * 60 * 60);
            }
            else
                if (typeof (o[i]) == "object") {
                    _this.addTimeZoneOffset(o[i], localoffset);
                }
        }
    },
    ServerRequest: function (methodType, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData, timeout, showProgress, dataTypeTo) {
        var _this = this;
        if (typeof requestData == 'undefined')
            requestData = {};
        //var localoffset = (new Date().getTimezoneOffset() / 60) + ServerTimeZoneOffset; //ServerTimeZoneOffset is set in server
        //this.addTimeZoneOffset(requestData, -localoffset);
        if (typeof callbackMethod == 'undefined' || callbackMethod == null)
            callbackMethod = function (data) { _this.ExecuteCallBack(callbackData, data); };
        if (typeof timeout == 'undefined' || timeout == null)
            timeout = 0;

        var url = _this.ServerRequestBaseUrl + servicePath;
        var dataType = "json";
        if (typeof dataTypeTo != 'undefined')
            dataType = dataTypeTo;

        $.ajax({
            type: methodType,
            url: url,
            data: JSON.stringify(requestData),
            contentType: "application/json; charset=utf-8",
            dataType: dataType,
            beforeSend: function () {
                if (typeof showProgress != 'undefined')
                    kendo.ui.progress($('body'), showProgress);
            },
            success: callbackMethod,
            error: function (xhr, desc, exceptionobj) { _this.ServerErrorParser(xhr, desc, exceptionobj, errorCallbackMethod) },
            callbackData: callbackData
        });
    },

    dateFilter: function dateFilter(k, v) {
        return (typeof v == "string"
  && (k = v.match(/([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})Z$/))) ? new Date(Date.UTC(k[1], k[2] - 1, k[3], k[4], k[5], k[6])) : v;
    },



    ApiRead: function (api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData) {
        var options = this.getApiOptions(api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData);
        $.Read(options);
    },

    ApiCreate: function (api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData) {
        var options = this.getApiOptions(api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData);
        $.Create(options);
    },
    ApiUpdate: function (api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData) {
        var options = this.getApiOptions(api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData);
        $.Update(options);
    },
    ApiDelete: function (api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData) {
        var options = this.getApiOptions(api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData);
        if (window.proxyOptions.useProxy == "true") {
            options.proxyUrl = options.proxyUrl + "&v=DELETE&u=";
            $.Create(options);
        }
        else
            $.Delete(options);
    },


    getApiOptions: function (api, servicePath, callbackMethod, errorCallbackMethod, callbackData, requestData) {
        var _this = this;

        if (typeof requestData == 'undefined')
            requestData = {};

        if (typeof callbackMethod == 'undefined'
            || callbackMethod == null)
            callbackMethod = function (data) { _this.ExecuteCallBack(callbackData, data); };
        var baseUrl = '';

        var options = {
            url: (proxyOptions.useProxy ? "" : baseUrl) + servicePath,
            dataType: 'json',
            proxyUrl: proxyOptions.useProxy ? baseUrl : "",
            success: callbackMethod,
            error: function (xhr, desc, exceptionobj) { _this.ServerErrorParser(xhr, desc, exceptionobj, errorCallbackMethod) }
        };

        options.data = requestData;
        return options;
    },


    /// <summary>
    /// The default call back for server requests
    /// </summary>
    /// <param name="param">description</param>
    /// <returns>return</returns>
    ServerRequestCallBack: function (requestDetails, resultData) {
    },

    /// <summary>
    /// This method is called when a server request failed. It parses the errors object and calls the error callback
    /// </summary>
    ServerErrorParser: function (xhr, desc, exceptionobj, errorCallBack) {
        var errors = this.ParseServerError(xhr);
        var isCallerHandlingValidationErrors = this.isCallerHandlingValidationErrors(errorCallBack);
        if (isCallerHandlingValidationErrors) //&& this.isHandledException(errors))
            errorCallBack(this.data, errors);
        else
            this.ServerRequestError(null, errors);
    },

    isHandledException: function (errors) {
        //TODO - need to clean this list..
        //all specific exceptions can be clubbed to ValidationException - unless there is a case for specific ones.
        if (errors.FaultType == "ValidationFault" || (errors.ExceptionType && errors.ExceptionType.indexOf('ValidationException') > 0)
		|| (errors.Error && errors.Error.Type && errors.Error.Type.indexOf('BadAdsException') > 0)
		|| (errors.Error && errors.Error.Type && errors.Error.Type.indexOf('BadFileException') > 0)
        || (errors.Error && errors.Error.Type && errors.Error.Type.indexOf('ValidationException') > 0))
            return true;
    },

    isCallerHandlingValidationErrors: function (errorCallBack) {
        return !(typeof errorCallBack == 'undefined' || errorCallBack == null);
    },

    /// <summary>
    /// This is the default error callback, if no error callback was set, it will be called and will log the user out
    /// </summary>
    ServerRequestError: function (data, errors) {
        if (Ecolab.Model.Common.onServerRequestError) {
            Ecolab.Model.Common.onServerRequestError(data, errors);
        }
    },


    /// <summary>
    /// This function parses the returned xhr objects and returns the error message
    /// </summary>
    /// <param name="xhr">The xhr object returned from the server call</param>
    /// <returns>return</returns>
    ParseServerError: function (xhr) {
        var responseText = xhr.responseText;

        if (responseText.endsWith('null')) //null is appeneded to the error json string when the method return type is an object
            responseText = responseText.substr(0, responseText.length - 4);

        if (responseText.endsWith('-1')) //-1 is appeneded to the error json string when the method return type is int
            responseText = responseText.substr(0, responseText.length - 2);

        if (responseText.indexOf("{\"d\":null}") >= 0)
            responseText = responseText.replace("{\"d\":null}", "");
        if (responseText.indexOf("{\"d\":-1}") >= 0)
            responseText = responseText.replace("{\"d\":-1}", "");
        var response = {};
        try {
            response = JSON.parse(responseText);
        }
        catch (error) {
            response = { Error: { errorCode: -1, message: 'unknown.error' } };
        }
        response.status = xhr.status;
        return response;
    },

    GetErrorMessage: function (errorObject) {
        var message = errorObject.Error.Message;

        try {
            var errors = eval((message.charAt(0) == "{" ? '[' + message + ']' : message));
            return errors;
        } catch (ex) { }

        return message;
    },

    ExecuteCallBack: function (callbackData, data) {
        if (callbackData == null || callbackData == undefined)
            return;
        if (typeof callbackData.callBack == "object") {
            callbackData.callBack.method.apply(callbackData.callBack.context, [data]);
        } else if (typeof callbackData.callBack == "function") {
            callbackData.callBack(data);
        }
    }
};

Ecolab.Model.Common._cacheItems = [];
/// <summary>
/// Retrieves an object from the cache.
/// The cache is an object in the page and will be destroyed and recreated for every new page.
/// TODO: Added support for expiration (is it really required?)
/// also, consider adding a global cache that will be usable between pages
/// </summary>
/// <param name="key">The key of the object to get</param>
/// <returns>The cached object if it's found, null if not</returns>
Ecolab.Model.Common.GetFromCache = function (key) {
    for (var itemIndex in Ecolab.Model.Common._cacheItems) {
        var cacheItem = Ecolab.Model.Common._cacheItems[itemIndex];
        if (cacheItem.key == key) {
            return cacheItem.value;
        }
    }
    return null;
};

/// <summary>
/// Adds an object to the cache
/// </summary>
/// <param name="key">The key of the object to get</param>
/// <param name="value">The object to add to the cache</param>
/// <param name="expires">an expiration date/definition</param>
Ecolab.Model.Common.AddToCache = function (key, value, expires) {
    //Try get from cache
    var cachedItem = Ecolab.Model.Common.GetFromCache(key);
    if (cachedItem != null) {
        cachedItem.value = value;
        cachedItem.expires = expires;
    } else {
        if (!expires) expires = 'never';
        Ecolab.Model.Common._cacheItems.push({ 'key': key, 'value': value, 'expires': expires });
    }
};

/// <summary>
/// Deletes an object from the cache
/// TODO: implement...
/// </summary>
/// <param name="key">The key of the object to get</param>
/// <returns>return</returns>
Ecolab.Model.Common.DeleteFromCache = function (key) {
};
