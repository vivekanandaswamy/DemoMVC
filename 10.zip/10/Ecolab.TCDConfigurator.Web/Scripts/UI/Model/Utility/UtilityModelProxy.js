Ecolab.Model.UtilityModelProxy = function () {
};

Ecolab.Model.UtilityModelProxy.prototype =
{
    loadUtilityOnAddNewPopupLoad: function (callBack, errorCallBack) {
        var url = "/Api/Utility/GetUtilityOnAddNew";
        this.ApiRead("Utility", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadDeviceData: function (callBack, errorCallBack) {       
        var url = "/Api/Utility/GetDeviceTypeDetails";
        this.ApiRead("Utility", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadDeviceType: function (callBack, errorCallBack) {        
        var url = "/Api/Utility/GetDeviceTypeDetails";
        this.ApiRead("Utility", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    loadDeviceModelByDeviceTypeId: function (id, callBack, errorCallBack) {
        var url = "/Api/Utility/GetDeviceModelDetails/{id}";
        var requestData = { "id": id };
        this.ApiRead("Utility", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    },   
    LoadUtilityEditProxy: function (id, callBack, errorCallBack) {
        var url = "/Api/Utility/GetUtilityOnEdit/{id}";
    var requestData = { "id": id };
    this.ApiRead("Utility", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
}
};

var base = new Ecolab.Model.Common();
Ecolab.Model.UtilityModelProxy.prototype = $.extend({}, Ecolab.Model.UtilityModelProxy.prototype, base);
Ecolab.Model.UtilityModelProxy.prototype.base = base;