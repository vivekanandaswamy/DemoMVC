// JavaScript source code
Ecolab.Model.FlushTimesAndSetupTomModelProxy = function () {
};

Ecolab.Model.FlushTimesAndSetupTomModelProxy.prototype =
{
    getData: function (machineId, groupId, groupTypeId, callBack, errorCallBack) {
        var url = "/Api/FlushTimesAndSetupTom/GetData?machineId=" + machineId + "&groupId=" + groupId + "&groupTypeId=" + groupTypeId;
        this.ApiRead("FlushTimesAndSetupTom", url, function (response) { callBack(response); }, null, null);
    },
    saveData: function (alarmData, callBack, errorCallBack) {
        var url = "Api/FlushTimesAndSetupTom/SaveFlushTimesAndSetupTom";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, alarmData);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.FlushTimesAndSetupTomModelProxy.prototype = $.extend({}, Ecolab.Model.FlushTimesAndSetupTomModelProxy.prototype, base);
Ecolab.Model.FlushTimesAndSetupTomModelProxy.prototype.base = base;