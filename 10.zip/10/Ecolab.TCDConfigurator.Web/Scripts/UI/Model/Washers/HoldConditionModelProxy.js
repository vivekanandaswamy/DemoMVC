// JavaScript source code
Ecolab.Model.HoldConditionModelProxy = function () {
};

Ecolab.Model.HoldConditionModelProxy.prototype =
{
    getAlarmData: function (controllerModelId, controllerTypelId, machineNumber, washerGroupId, ecoLabAccountNumber, washerGroupTypeId, TunnelId, isBatchEject, callBack, errorCallBack) {
        var url = "/Api/Washer/GetAlarmSetupDetails";
        var requestData = { "controllerModelId": controllerModelId, "controllerTypeId": controllerTypelId, "machineNumber": machineNumber, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNumber, "washerGroupTypeId": washerGroupTypeId, "tunnelId": TunnelId, "isBatchEjectCondition": isBatchEject };
        this.ApiRead("HoldCondition", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, false);
    },
    saveAlarmData: function (alarmData, callBack, errorCallBack) {
        var url = "Api/Washer/SaveAlarmStatus";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, alarmData);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.HoldConditionModelProxy.prototype = $.extend({}, Ecolab.Model.HoldConditionModelProxy.prototype, base);
Ecolab.Model.HoldConditionModelProxy.prototype.base = base;