// JavaScript source code
Ecolab.Model.ProductDeviationModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onSaveData: null,
            onDataSaved: null,
            onDataSavingFailed: null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.ProductDeviationModelProxy = new Ecolab.Model.ProductDeviationModelProxy();
};

Ecolab.Model.ProductDeviationModel.prototype = {
    init: function () {
    },
    //getting alarm data
    getData: function (machineId, groupId, controllerId) {
        var _this = this;
        this.ProductDeviationModelProxy.getData(machineId, groupId, controllerId, function (data) {
            _this.onGetData(data);
        });
    },
    onGetData: function (data) {
        var _this = this;
        _this.settings.eventHandlers.onGetData(data);
    },
    //Saving Alarm Data
    saveData: function (washerProductDeviationModel, isSaveAndClose) {
        var _this = this;
        this.ProductDeviationModelProxy.saveData(washerProductDeviationModel, function (data) {
            _this.settings.eventHandlers.onDataSaved(data, isSaveAndClose);
        }, function (error, description) { _this.settings.eventHandlers.onDataSavingFailed(error, description); });
    }
};