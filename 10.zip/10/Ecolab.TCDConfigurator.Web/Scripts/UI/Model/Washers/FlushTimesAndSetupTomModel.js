// JavaScript source code
Ecolab.Model.FlushTimesAndSetupTomModel = function(options) {
    var defaultOptions = {
        eventHandlers: {
            onSaveData: null,
            onDataSaved: null,
            onDataSavingFailed: null
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.FlushTimesAndSetupTomModelProxy = new Ecolab.Model.FlushTimesAndSetupTomModelProxy();
};

Ecolab.Model.FlushTimesAndSetupTomModel.prototype = {
    init: function() {
    },
    //getting alarm data
    getData: function(machineId, groupId, groupTypeId) {
        var _this = this;
        this.FlushTimesAndSetupTomModelProxy.getData(machineId, groupId, groupTypeId, function (data) {
            _this.onGetData(data);
        });
    },
    onGetData: function(data) {
        var _this = this;
        _this.settings.eventHandlers.onGetData(data);
    },
    //Saving Alarm Data
    saveData: function(flushAndSetupTomData, isSaveAndClose) {
        var _this = this;
        this.FlushTimesAndSetupTomModelProxy.saveData(flushAndSetupTomData, function (data) {
            _this.settings.eventHandlers.onDataSaved(data, isSaveAndClose);
        }, function(error, description) { _this.settings.eventHandlers.onDataSavingFailed(error, description); });
    }
};