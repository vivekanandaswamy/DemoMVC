Ecolab.Model.ProductDeviationModelProxy = function () {
};

Ecolab.Model.ProductDeviationModelProxy.prototype =
{
    getData: function (machineId, groupId, controllerId, callBack, errorCallBack) {
        
        var url = "/Api/ProductDeviation/GetProductDeviationData?machineId=" + machineId + "&groupId=" + groupId + "&controllerId=" + controllerId;
        this.ApiRead("WasherProductDeviationModel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null);
    },
    saveData: function (washerProductDeviationModel, callBack, errorCallBack) {
        var url = "Api/ProductDeviation/SaveProductDeviationData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, washerProductDeviationModel);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.ProductDeviationModelProxy.prototype = $.extend({}, Ecolab.Model.ProductDeviationModelProxy.prototype, base);
Ecolab.Model.ProductDeviationModelProxy.prototype.base = base;