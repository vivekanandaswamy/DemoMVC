// JavaScript source code
Ecolab.Model.WasherModelProxy = function () {
};

Ecolab.Model.WasherModelProxy.prototype =
{
    getWasherDetails: function (ecolabAccountNumber, callBack) {
        var requestData = { "ecolabAccountNumber": ecolabAccountNumber};
        var url = "/Api/Washer/GetWashersDetails";
        this.ApiRead("Washer", url, function (response) { callBack(response); }, null, null, requestData);
    },
    onDeleteWasher: function (isTunnel, id, ecolabAccountNumber, washerGroupId, callBack, errorCallBack) {
        var requestData = { "washerId": parseInt(id), "isTunnel": isTunnel, "ecolabAccountNumber": ecolabAccountNumber, "washerGroupId": washerGroupId };
        var url = "Api/Washer/WasherDelete";
        this.ApiRead("Washer", url, function (response) { callBack(response); }, null, null, requestData);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.WasherModelProxy.prototype = $.extend({}, Ecolab.Model.WasherModelProxy.prototype, base);
Ecolab.Model.WasherModelProxy.prototype.base = base;