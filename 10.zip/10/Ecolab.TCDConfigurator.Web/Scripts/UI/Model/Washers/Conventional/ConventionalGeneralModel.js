// JavaScript source code
Ecolab.Model.ConventionalGeneralModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDropDownDataLoaded: null,
            onSaved: function (isSaveAndClose) { },
            onSizeListLoaded: function () { },
            onLfsWasherListLoaded: function () { },
            onWasherModeListLoaded: function () { },
            onSaveFailed: function () { },
            onConventionalDataLoaded: function (data) { },
            onUpdate: function (isSaveAndClose) { },
            onUpdateFailed: function () { },
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.ConventionalGeneralModelProxy = new Ecolab.Model.ConventionalGeneralModelProxy();
};

Ecolab.Model.ConventionalGeneralModel.prototype = {
    init: function () {
    },
    loadDropDownsData: function (ecoLabAccountNumber, regionId, washerGroupId) {
        var _this = this;
        _this.ConventionalGeneralModelProxy.loadDropDownsData(ecoLabAccountNumber, regionId, washerGroupId, function (data) {
            _this.settings.eventHandlers.onDropDownDataLoaded(data);
        });
    },
    getSizeList: function (model, regionId) {
        var _this = this;
        _this.ConventionalGeneralModelProxy.getSizeList(model, regionId, function (data) {
            _this.settings.eventHandlers.onSizeListLoaded(data);
        });
    },
    getLfsWasherList: function (controllerId, ecoLabAccountNumber) {
        var _this = this;
        _this.ConventionalGeneralModelProxy.getLfsWasherList(controllerId, ecoLabAccountNumber, function (data) {
            _this.settings.eventHandlers.onLfsWasherListLoaded(data);
        });
    },
    getWasherModeList: function (controllerId, ecoLabAccountNumber) {
        var _this = this;
        _this.ConventionalGeneralModelProxy.getWasherModeList(controllerId, ecoLabAccountNumber, function (data) {
            _this.settings.eventHandlers.onWasherModeListLoaded(data);
        });
    },
    save: function (ConventionalData, isSaveAndClose) {
        var _this = this;
        var ConventionalDataOriginal = ConventionalData;
        _this.ConventionalGeneralModelProxy.saveConventionalData(ConventionalData, function (data) {
            _this.settings.eventHandlers.onSaved(data, isSaveAndClose);
        },
        function (error, description) {
            _this.settings.eventHandlers.onSaveFailed(description, ConventionalDataOriginal);
        });
    },
    update: function (ConventionalData, isSaveAndClose) {
        var _this = this;
        var ConventionalDataOriginal = ConventionalData;
        _this.ConventionalGeneralModelProxy.updateConventionalData(ConventionalData, function (data) {
            _this.settings.eventHandlers.onUpdate(data, isSaveAndClose);
        },
        function (error, description) {
            _this.settings.eventHandlers.onUpdateFailed(description, ConventionalData);
        });
    },

    getConventionalData: function (id, washerGroupId, ecoLabAccountNo, regionId) {
        var _this = this;
        _this.ConventionalGeneralModelProxy.getConventionalData(id, washerGroupId, ecoLabAccountNo, regionId, function (data) {
            _this.settings.eventHandlers.onConventionalDataLoaded(data);
        }, function (error, description) {
            return null;
        });
    },
    getMaxPlantWasherNumber: function (ecoLabAccountNo) {
        var _this = this;
        _this.ConventionalGeneralModelProxy.getMaxPlantWasherNumber(ecoLabAccountNo, function (data) {
            _this.settings.eventHandlers.onConventionalDataLoaded(data);
        }, function (error, description) {
            return null;
        });
    },
}