Ecolab.Model.TunnelConnectionsModelProxy = function () {
};
Ecolab.Model.TunnelConnectionsModelProxy.prototype = {
    loadConnectionsModelData: function (ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, regionId, controllerId, callBack, errorCallBack) {        
        var requestData = { "id": tunnelId, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNumber, "compartmentNumber": compartmentNumber, "regionId": regionId, "controllerId": controllerId };
        var url = "/Api/Tunnel/FetchTunnelConnectionsData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, null, null, requestData);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.TunnelConnectionsModelProxy.prototype = $.extend({}, Ecolab.Model.TunnelConnectionsModelProxy.prototype, base);
Ecolab.Model.TunnelConnectionsModelProxy.prototype.base = base;