Ecolab.Model.TunnelCompartmentModelProxy = function () {
};
Ecolab.Model.TunnelCompartmentModelProxy.prototype = {
    loadDropDownsData: function (ecoLabAccountNumber, regionId, controllerId, tunnelId, washerGroupId, callBack, errorCallBack) {

        var requestData = { "ecoLabAccountNumber": ecoLabAccountNumber, "regionId": regionId, "controllerId": controllerId, "tunnelId": tunnelId, "washerGroupId": washerGroupId };
        var url = "/Api/Tunnel/GetCompartmentDropDownData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, false);
    },
    saveTunnelData: function (tunnelData, callBack, errorCallBack) {
        var url = "/Api/Tunnel/SaveTunnelCompartmentData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, tunnelData);
    },
    loadCompartmentsModelData: function (ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, regionId, controllerId,callBack, errorCallBack) {
        var requestData = { "id": tunnelId, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNumber, "compartmentNumber": compartmentNumber, "regionId": regionId, "controllerId": controllerId };
        var url = "/Api/Tunnel/GetCompartmentData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData, false);
    },
    getCompartmentCount: function (ecoLabAccountNumber, washerGroupId, tunnelId, callBack, errorCallBack) {
        var requestData = { "tunnelId": tunnelId, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNumber};
        var url = "/Api/Tunnel/GetCompartmentCount";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, null, null, requestData, false);
    },
    MovePump: function (data, callBack, errorCallBack) {
        var url = "/Api/Tunnel/MovePump";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, data);
    }
}
var base = new Ecolab.Model.Common();
Ecolab.Model.TunnelCompartmentModelProxy.prototype = $.extend({}, Ecolab.Model.TunnelCompartmentModelProxy.prototype, base);
Ecolab.Model.TunnelCompartmentModelProxy.prototype.base = base;