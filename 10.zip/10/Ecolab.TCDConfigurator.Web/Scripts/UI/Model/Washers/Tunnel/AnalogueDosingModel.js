Ecolab.Model.AnalogueDosingModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onDropDownDataLoaded: null,
            onSaved: function () { },
            onSaveFailed: function () { },
            onDataSaved : null,
            onComaprtmentsLoad: function () { },
            onDataSavingFailed: function () { },
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.AnalogueDosingModelProxy = new Ecolab.Model.AnalogueDosingModelProxy();
};
Ecolab.Model.AnalogueDosingModel.prototype = {
    init: function () {
    },
    loadAnalogueDosingModelData: function (ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, regionId, controllerId) {
        var _this = this;
        _this.AnalogueDosingModelProxy.loadAnalogueDosingModelData(ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, regionId, controllerId, function (data) {
            _this.settings.eventHandlers.onGetData(data);
        });
    },
    saveData: function (analogueDosingData, isSaveAndClose) {
        var _this = this;        
        this.AnalogueDosingModelProxy.saveData(analogueDosingData, function (data) {
            _this.settings.eventHandlers.onDataSaved(data, isSaveAndClose);
        }, function (error, description) { _this.settings.eventHandlers.onDataSavingFailed(error, description); });
    }
}