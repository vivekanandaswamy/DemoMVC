Ecolab.Model.TunnelConnectionsModel = function (options) {    
    var defaultOptions = {
        eventHandlers: {
            onDropDownDataLoaded: null,
            onSaved: function () { },
            onSaveFailed: function () { },
            onComaprtmentsLoad: function () { },
        }
    };
    this.settings = $.extend(defaultOptions, options);
    this.TunnelConnectionsModelProxy = new Ecolab.Model.TunnelConnectionsModelProxy();
};
Ecolab.Model.TunnelConnectionsModel.prototype = {
    init: function () {
    },
    loadConnectionsModelData: function (ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, regionId, controllerId) {
        var _this = this;
        _this.TunnelConnectionsModelProxy.loadConnectionsModelData(ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, regionId, controllerId, function (data) {
            _this.settings.eventHandlers.onGetData(data);
        });
    },
}