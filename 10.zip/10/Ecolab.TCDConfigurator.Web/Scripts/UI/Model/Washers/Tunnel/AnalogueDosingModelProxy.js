Ecolab.Model.AnalogueDosingModelProxy = function () {
};
Ecolab.Model.AnalogueDosingModelProxy.prototype = {
    loadAnalogueDosingModelData: function (ecoLabAccountNumber, washerGroupId, tunnelId, compartmentNumber, regionId, controllerId, callBack, errorCallBack) {
        var requestData = { "id": tunnelId, "washerGroupId": washerGroupId, "ecoLabAccountNumber": ecoLabAccountNumber, "compartmentNumber": compartmentNumber, "regionId": regionId, "controllerId": controllerId };
        var url = "/Api/Tunnel/FetchAnalogueDosingData";
        this.ApiRead("Tunnel", url, function (response) { callBack(response); }, null, null, requestData);
    },
    saveData: function (analogueDosingData, callBack, errorCallBack) {        
        var url = "/Api/Tunnel/SaveAnalogueDosingData";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, analogueDosingData);
    },
}
var base = new Ecolab.Model.Common();
Ecolab.Model.AnalogueDosingModelProxy.prototype = $.extend({}, Ecolab.Model.AnalogueDosingModelProxy.prototype, base);
Ecolab.Model.AnalogueDosingModelProxy.prototype.base = base;