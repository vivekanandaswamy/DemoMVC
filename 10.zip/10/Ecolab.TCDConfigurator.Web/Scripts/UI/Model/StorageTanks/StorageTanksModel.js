Ecolab.Model.StorageTanksModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onGetStorageTanksDetailsReceived: null,
            onStorageTanksDeleted: null,
            onStorageTanksDeletionFailed: null,
            onGetAddStorageTanksDataRecieved: null,
            onGetEditStorageTanksDataRecieved: null,
            onGetInlineEditStorageTanksDataRecieved: null,
            onGetInlineEditProductDataRecieved: null,
            onStorageTankCreated: null,
            onStorageTankUpdated: null,
            onStorageTankUpdatedInline: null,
            onStorageTankCreationFailed: null,
            onStorageTankUpdationFailed: null,
            onStorageTankDeletionFailed: null,
            onStorageTankInlineUpdationFailed: null,
            onValidateFailed: null,
            onGetStorageTanksOnControllerDataRecieved: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.StorageTanksModelProxy = new Ecolab.Model.StorageTanksModelProxy();
};

Ecolab.Model.StorageTanksModel.prototype = {
    init: function () {
    },
    getStorageTanksDetails: function (ecolabAccountNumber) {
        var _this = this;
        this.StorageTanksModelProxy.getStorageTanksDetails(ecolabAccountNumber, function (Data) {
            _this.onGetStorageTanksDetailsReceived(Data);
        });
    },

    onGetStorageTanksDetailsReceived: function (data) {
        var _this = this;
        _this.settings.eventHandlers.onGetStorageTanksDetailsReceived(data);
    },

    GetAddStorageTanks: function (ecolabAccountNumber) {
        var _this = this;
        var id = -1;
        this.StorageTanksModelProxy.AddStorageTanks(ecolabAccountNumber, id, function (data) {
            _this.settings.eventHandlers.onGetAddStorageTanksDataRecieved(data);
        });
    },
    DeleteStorageTanks: function (StorageTankData) {
        var _this = this;
        this.StorageTanksModelProxy.DeleteStorageTanks(StorageTankData, function (data) {
            _this.settings.eventHandlers.onStorageTanksDeleted(data);
        },
        function (error, description) { _this.settings.eventHandlers.onStorageTankDeletionFailed(error, description); });
       
    },
    EditStorageTanks: function (id, ecolabAccountNumber) {
        var _this = this;
        this.StorageTanksModelProxy.EditStorageTanks(id, ecolabAccountNumber, function (data) {
            _this.settings.eventHandlers.onGetEditStorageTanksDataRecieved(data);
        });
    },
    InlineEditStorageTanks: function (id, ecolabAccountNumber) {
        var _this = this;
        this.StorageTanksModelProxy.AddStorageTanks(ecolabAccountNumber, id, function (data) {
            _this.settings.eventHandlers.onGetInlineEditStorageTanksDataRecieved(data);
        });
    },

    createStorageTank: function (StorageTankData, isSaveAndClose) {
        var _this = this;
        this.StorageTanksModelProxy.CreateStorageTank(StorageTankData, function (data) {
            _this.settings.eventHandlers.onStorageTankCreated(data, isSaveAndClose);
        }, function (error, description) { _this.settings.eventHandlers.onStorageTankCreationFailed(error, description); });
    },
    UpdateStorageTank: function (StorageTankData, isSaveAndClose) {
        var _this = this;
        this.StorageTanksModelProxy.UpdateStorageTank(StorageTankData, function (data) {
            _this.settings.eventHandlers.onStorageTankUpdated(data, isSaveAndClose);
        }, function (error, description) { _this.settings.eventHandlers.onStorageTankUpdationFailed(StorageTankData, description); });
    },
    UpdateStorageTankInline: function (StorageTankData) {
        var _this = this;
        this.StorageTanksModelProxy.UpdateStorageTank(StorageTankData, function (data) {
            _this.settings.eventHandlers.onStorageTankUpdatedInline(data);
        }, function (error, description) { _this.settings.eventHandlers.onStorageTankInlineUpdationFailed(error, description); });
    },

    ValidateTags: function (data, isSaveAndClose) {
        var _this = this;
        this.StorageTanksModelProxy.validateTags(data, function (data) {
            _this.settings.eventHandlers.onValidateSuccess(data, isSaveAndClose);
        }, function (error, description) { _this.settings.eventHandlers.onValidateFailed(error, description); });
    },
    GetStorageTanksOnController: function (ecolabAccountNumber, controllerId, controllerTypeId) {
        var _this = this;
        this.StorageTanksModelProxy.GetStorageTanksOnController(ecolabAccountNumber, controllerId, function (data) {
            _this.settings.eventHandlers.onGetStorageTanksOnControllerDataRecieved(data, controllerTypeId);
        });
    },

    WriteTagsToPLC: function (data, isInline, isSaveAndClose) {
        var _this = this;
        var localData = data;
        this.StorageTanksModelProxy.WriteTagsToPLC(data, function (data) {
            if (isInline)
                _this.settings.eventHandlers.onStorageTankUpdatedInline(data);
            else
                _this.settings.eventHandlers.onStorageTankUpdated(localData, isSaveAndClose);
        },
        function (error, description) {
            if (isInline)
                _this.settings.eventHandlers.onStorageTankInlineUpdationFailed(error, description);
            else
                _this.settings.eventHandlers.onStorageTankUpdationFailed(error, description, localData);
        });
    },

};

