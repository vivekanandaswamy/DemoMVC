﻿Ecolab.Model.MeterModel = function (options) {
    var defaultOptions = {
        eventHandlers: {
            onMeterDataLoaded: null,
            onExternalAndInternalCountersFetched : null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.MeterModelProxy = new Ecolab.Model.MeterModelProxy();
};

Ecolab.Model.MeterModel.prototype = {
    init: function () {
    },

    loadMeterData: function (callBackData) {
        var _this = this;
        this.MeterModelProxy.loadMeterData(function (meterData) {
            _this.settings.eventHandlers.onMeterDataLoaded(meterData, callBackData);
        });
    },

    loadOnUtilityLocationChange: function (UtilityLocationId, callBackData) {
        var _this = this;
        this.MeterModelProxy.loadOnUtilityLocationChange(UtilityLocationId, function (machineCompartmentData) {
            _this.settings.eventHandlers.onloadOnUtilityLocationChangeDataLoaded(machineCompartmentData, callBackData);
        });
    },
    
    loadMeterOnAddNewPopupLoad: function (callBackData) {
        var _this = this;
        this.MeterModelProxy.loadMeterOnAddNewPopupLoad(function (parentData) {
            _this.settings.eventHandlers.onloadMeterOnAddNewPopupDataLoaded(parentData, callBackData);
        });
    },
    
    loadUOMByUtilityTypeId: function (utilityId, id, callBackData) {
        var _this = this;
        this.MeterModelProxy.loadUOMByUtilityTypeId(utilityId, id, function (parentData) {
            _this.settings.eventHandlers.onloadUOMDataLoaded(parentData, callBackData);
        });
    },
    loadMeterOnEditPopupLoad: function (meterId,callBackData) {
        var _this = this;
        this.MeterModelProxy.loadMeterOnEditPopupLoad(meterId,function (parentData) {
            _this.settings.eventHandlers.onloadMeterOnEditPopupDataLoaded(parentData, callBackData);
        });
    },
    loadOnMachineCompartmentChange: function (locationId, machineId, callBackData) {
        var _this = this;
        this.MeterModelProxy.loadOnMachineCompartmentChange(locationId, machineId, function (parentData) {
            _this.settings.eventHandlers.onMachineCompartmentChangeLoaded(parentData, callBackData);
        });
    },
    fetchExternalOrInternalCounters: function (locationId, machineId, callBackData) {
    var _this = this;
    this.MeterModelProxy.fetchExternalOrInternalCounters(locationId, machineId, function (data) {
        _this.settings.eventHandlers.onExternalAndInternalCountersFetched(data, callBackData);
    });
}
};

