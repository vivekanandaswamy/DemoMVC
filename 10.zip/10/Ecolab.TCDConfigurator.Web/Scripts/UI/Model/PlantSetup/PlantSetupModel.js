Ecolab.Model.PlantSetupModel = function (options) {
    //  this.NumberOfItems = 0;
    var defaultOptions = {
        eventHandlers: {
            onContactDataLoaded: null,
            onPositionDataLoaded: null
        }
    };

    this.settings = $.extend(defaultOptions, options);
    this.PlantSetupModelProxy = new Ecolab.Model.PlantSetupModelProxy();
};

Ecolab.Model.PlantSetupModel.prototype = {
    init: function () {
    },
    loadPlantSetupData: function (data, callBackData) {
        var _this = this;
        this.PlantSetupModelProxy.loadPlantSetupData(data, function (plantSetupData) {
            _this.onDataLoaded(plantSetupData, callBackData);
        });
    },
    savePlantSetupData: function (data) {
        var _this = this;
        this.PlantSetupModelProxy.savePlantSetupData(data,
            function () { _this.onPlantDataSaved(); },
            function (data, exception) { _this.onPlantDataSavedFailed(data, exception); }
        );
    },
    FtrClick: function () {
        var _this = this;
        this.PlantSetupModelProxy.FtrClick(null,
            function () { _this.onFtrSuccess(); },
            function (data, exception) { _this.onFtrFailed(data, exception); }
        );
    },
    onDataLoaded: function (data, callBackData) {
        var _this = this;

        _this.settings.eventHandlers.onPlantSetupDataLoaded(data, callBackData);
    },
    loadPositionData: function (callBackData) {
        var _this = this;
        this.PlantSetupModelProxy.loadPositionData(function (plantSetupData) {
            _this.settings.eventHandlers.onPositionDataLoaded(plantSetupData, callBackData);
        });
    },
    loadMeterData: function (callBackData) {
        var _this = this;
        this.PlantSetupModelProxy.loadMeterData(function (plantSetupData) {
            _this.settings.eventHandlers.onMeterDataLoaded(plantSetupData, callBackData);
        });
    },
    onPlantDataSaved: function () {
        var _this = this;
        _this.settings.eventHandlers.onPlantDataSaved();
    },
    onPlantDataSavedFailed: function (data, exception) {
        var _this = this;
        _this.settings.eventHandlers.onPlantDataSavedFailed(data, exception);
    },
    onFtrSuccess: function () {
        var _this = this;
        _this.settings.eventHandlers.onFtrSuccess();
    },
    onFtrFailed: function (data, exception) {
        var _this = this;
        _this.settings.eventHandlers.onFtrFailed(data, exception);
    }
};

