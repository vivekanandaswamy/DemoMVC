Ecolab.Model.PlantSetupModelProxy = function () {
};

Ecolab.Model.PlantSetupModelProxy.prototype =
{
    loadPlantSetupData: function (id, callBack, errorCallBack) {
        var url = "Api/PlantSetup/Get";
        this.ApiRead("PlantSetup", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, null);
    },
    savePlantSetupData: function (requestData, callBack, errorCallBack) {
        var url = "Api/PlantSetup/Save";
        this.ServerRequest("POST",url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); },null, requestData);
    },
    FtrClick: function (requestData, callBack, errorCallBack) {
        var url = "Api/PlantSetup/FirstTimeRequest";
        this.ServerRequest("POST", url, function (response) { callBack(response); }, function (data, exception) { errorCallBack(data, exception); }, null, requestData);
    }
};

var base = new Ecolab.Model.Common();
Ecolab.Model.PlantSetupModelProxy.prototype = $.extend({}, Ecolab.Model.PlantSetupModelProxy.prototype, base);
Ecolab.Model.PlantSetupModelProxy.prototype.base = base;